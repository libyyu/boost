
EventDef = 
{
	UnityLog = "UNITY_LOG",
	PanelCreate = "PANEL_CREATE",
	PanelDestroy = "PANEL_DESTROY",
}

