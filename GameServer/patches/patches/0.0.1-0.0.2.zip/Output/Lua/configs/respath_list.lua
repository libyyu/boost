local respath_list = 
{
	ConsoleUI = "Assets/Arts/Prefab/ConsoleUI.prefab",
	LoadingUI = "Assets/Arts/Prefab/LoadingUI.prefab",
	LoginUI = "Assets/Arts/Prefab/LoginUI.prefab",
	MsgBoxUI = "Assets/Arts/Prefab/MsgBoxUI.prefab",
	ServerListUI = "Assets/Arts/Prefab/ServerListUI.prefab",
	WaitingUI = "Assets/Arts/Prefab/WaitingUI.prefab",
	BackgroundMusic = "Assets/Arts/Sound/background.mp3",
	UpdateUI = "Assets/Arts/Prefab/UpdateUI.prefab",
}

return respath_list