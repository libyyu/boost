﻿// Copyright 1998-2017 Epic Games, Inc. All Rights Reserved.

//	compile only within Editor, or it will generate code in final exe
#if WITH_EDITOR

#include "GameLogic/Input/AzureInputCtrl.h"
#include "Azure.h"
#include "AutomationTest.h"

//	Do NOT use EAutomationTestFlags::ClientContext, or it will run in game at startup
IMPLEMENT_SIMPLE_AUTOMATION_TEST(AzureTouchMessageQueueTests, "Azure.TouchMessageQueue", EAutomationTestFlags::EditorContext | EAutomationTestFlags::SmokeFilter)

namespace
{
	//	Ad-hoc Test Language (to simplify test code) for testing reducing AzureTouchMessageQueue
	struct AzureReduceTouchTest
	{
		AzureTouchMessageQueue QueueToReduce;
		AzureTouchMessageQueue QueueReducedResult;

		float LocationMarker = 1.0f;	//	used to generate touchLocation and automatically increases to differentiate from any other Touch Message and used to compare with reduce results 
		int TouchMarker = 1;			//	used to generate description when test fails. remains same between touchBegan and touchEnded. automatically increases for next touchBegan
		FString DescriptionBeforeReduce, DescriptionAfterReduce;	//	the final description is DescriptionBeforeReduce->DescriptionAfterReduce. used when test failes

		//	push back touch message to queue tail that is expected to be reduced
		void PushBackToReduce(ETouchType::Type TypeIn)
		{
			this->UpdateTouchMarkerBeforePushBack(TypeIn);
			this->AddDescriptionToReduce(TypeIn);

			this->QueueToReduce.PushBack(TypeIn, FVector2D(LocationMarker, LocationMarker));
			this->LocationMarker += 1.0f;

		}

		//	push back touch message to queue tail that is expected not to be reduced
		void PushBackToRemain(ETouchType::Type TypeIn)
		{
			this->UpdateTouchMarkerBeforePushBack(TypeIn);
			this->AddDescriptionToRemain(TypeIn);

			this->QueueToReduce.PushBack(TypeIn, FVector2D(LocationMarker, LocationMarker));
			this->QueueReducedResult.PushBack(TypeIn, FVector2D(LocationMarker, LocationMarker));
			this->LocationMarker += 1.0f;
		}
		void UpdateTouchMarkerBeforePushBack(ETouchType::Type TypeIn)
		{
			if (!this->IsReduceQueueEmpty() && TypeIn == ETouchType::Began)
			{
				++ this->TouchMarker;
			}
		}
		bool IsReduceQueueEmpty()const
		{
			return this->QueueToReduce.IsEmpty();
		}
		void AddDescriptionToReduce(ETouchType::Type TypeIn)
		{
			this->AddToDescriptionBeforeReduce(TypeIn);
		}
		void AddDescriptionToRemain(ETouchType::Type TypeIn)
		{
			this->AddToDescriptionBeforeReduce(TypeIn);
			this->AddDescriptionAfterReduce(TypeIn);
		}
		void AddToDescriptionBeforeReduce(ETouchType::Type TypeIn)
		{
			if (!DescriptionBeforeReduce.IsEmpty())
			{
				DescriptionBeforeReduce += GetSeperator();
			}
			DescriptionBeforeReduce += this->FormatType(TypeIn);
		}
		void AddDescriptionAfterReduce(ETouchType::Type TypeIn)
		{
			if (!DescriptionAfterReduce.IsEmpty())
			{
				DescriptionAfterReduce += GetSeperator();
			}
			DescriptionAfterReduce += this->FormatType(TypeIn);
		}
		static const TCHAR* GetSeperator()
		{
			return TEXT(",");
		}
		FString FormatType(ETouchType::Type TypeIn)const
		{
			static const TCHAR* InputType2String[ETouchType::NumTypes] = {
				TEXT("Began"),
				TEXT("Moved"),
				TEXT("Stationary"),
				TEXT("Ended"),
			};
			return FString::Printf(TEXT("%s%d"), InputType2String[TypeIn], this->TouchMarker);
		}

		void Run()
		{
			this->QueueToReduce.ReduceTooOftenTouches();
		}

		FString GetDescriptionWhenFailed()const
		{
			return this->DescriptionBeforeReduce + TEXT("->") + this->DescriptionAfterReduce;
		}
	};
}

bool AzureTouchMessageQueueTests::RunTest( const FString& Parameters )
{
	UE_LOG(LogAzure, Display, TEXT("Enter AzureTouchMessageQueueTests::RunTest"));	//	Log to raise attention

	//	Use CHECK_REDUCE_RESULT to get line info when failed
#define CHECK_REDUCE_RESULT(T) this->TestEqual(T.GetDescriptionWhenFailed(), T.QueueToReduce, T.QueueReducedResult)

	//	1 Reduce within only one touch

	//	1.1 not full touch 
	{
		//	1.1.1 Only TouchMoved
		AzureReduceTouchTest Test;
		Test.PushBackToReduce(ETouchType::Moved);
		Test.PushBackToRemain(ETouchType::Moved);
		Test.Run();
		CHECK_REDUCE_RESULT(Test);
	}
	{
		//	1.1.2 only TouchEnded
		AzureReduceTouchTest Test;
		Test.PushBackToRemain(ETouchType::Ended);
		Test.Run();
		CHECK_REDUCE_RESULT(Test);
	}
	{
		//	1.1.3 TouchMoved with TouchEnded
		AzureReduceTouchTest Test;
		Test.PushBackToReduce(ETouchType::Moved);
		Test.PushBackToRemain(ETouchType::Ended);
		Test.Run();
		CHECK_REDUCE_RESULT(Test);
	}

	//	1.2 full touch
	{
		//	1.2.1 only TouchBegan and TouchEnded
		AzureReduceTouchTest Test;
		Test.PushBackToRemain(ETouchType::Began);
		Test.PushBackToRemain(ETouchType::Ended);
		Test.Run();
		CHECK_REDUCE_RESULT(Test);
	}
	{
		//	1.2.2 TouchBegan、TouchMoved、TouchEnded
		AzureReduceTouchTest Test;
		Test.PushBackToRemain(ETouchType::Began);
		Test.PushBackToReduce(ETouchType::Moved);
		Test.PushBackToRemain(ETouchType::Ended);
		Test.Run();
		CHECK_REDUCE_RESULT(Test);
	}

	//	2 Reduce two touches
	{
		//	2.1 Both are not full
		AzureReduceTouchTest Test;
		Test.PushBackToReduce(ETouchType::Moved);
		Test.PushBackToRemain(ETouchType::Ended);
		Test.PushBackToRemain(ETouchType::Began);
		Test.PushBackToReduce(ETouchType::Moved);
		Test.Run();
		CHECK_REDUCE_RESULT(Test);
	}
	{
		//	2.2 First is full while second is not
		AzureReduceTouchTest Test;
		Test.PushBackToReduce(ETouchType::Began);
		Test.PushBackToReduce(ETouchType::Moved);
		Test.PushBackToReduce(ETouchType::Ended);
		Test.PushBackToRemain(ETouchType::Began);
		Test.PushBackToReduce(ETouchType::Moved);
		Test.Run();
		CHECK_REDUCE_RESULT(Test);
	}
	{
		//	2.3 First is not full while second is
		AzureReduceTouchTest Test;
		Test.PushBackToReduce(ETouchType::Moved);
		Test.PushBackToRemain(ETouchType::Ended);
		Test.PushBackToReduce(ETouchType::Began);
		Test.PushBackToReduce(ETouchType::Moved);
		Test.PushBackToReduce(ETouchType::Ended);
		Test.Run();
		CHECK_REDUCE_RESULT(Test);
	}
	{
		//	2.4 Both are full
		AzureReduceTouchTest Test;
		Test.PushBackToReduce(ETouchType::Began);
		Test.PushBackToReduce(ETouchType::Moved);
		Test.PushBackToReduce(ETouchType::Ended);
		Test.PushBackToRemain(ETouchType::Began);
		Test.PushBackToReduce(ETouchType::Moved);
		Test.PushBackToRemain(ETouchType::Ended);
		Test.Run();
		CHECK_REDUCE_RESULT(Test);
	}

	//	3 Reduce three touches(the second must be full)
	{
		//	3.1 First and third are not full
		AzureReduceTouchTest Test;
		Test.PushBackToReduce(ETouchType::Moved);
		Test.PushBackToRemain(ETouchType::Ended);
		Test.PushBackToReduce(ETouchType::Began);
		Test.PushBackToReduce(ETouchType::Moved);
		Test.PushBackToReduce(ETouchType::Ended);
		Test.PushBackToRemain(ETouchType::Began);
		Test.PushBackToReduce(ETouchType::Moved);
		Test.Run();
		CHECK_REDUCE_RESULT(Test);
	}
	{
		//	3.2 First is full while third is not
		AzureReduceTouchTest Test;
		Test.PushBackToReduce(ETouchType::Began);
		Test.PushBackToReduce(ETouchType::Moved);
		Test.PushBackToReduce(ETouchType::Ended);
		Test.PushBackToReduce(ETouchType::Began);
		Test.PushBackToReduce(ETouchType::Moved);
		Test.PushBackToReduce(ETouchType::Ended);
		Test.PushBackToRemain(ETouchType::Began);
		Test.PushBackToReduce(ETouchType::Moved);
		Test.Run();
		CHECK_REDUCE_RESULT(Test);
	}
	{
		//	3.3 First is not full while third is 
		AzureReduceTouchTest Test;
		Test.PushBackToReduce(ETouchType::Moved);
		Test.PushBackToRemain(ETouchType::Ended);
		Test.PushBackToReduce(ETouchType::Began);
		Test.PushBackToReduce(ETouchType::Moved);
		Test.PushBackToReduce(ETouchType::Ended);
		Test.PushBackToReduce(ETouchType::Began);
		Test.PushBackToReduce(ETouchType::Moved);
		Test.PushBackToReduce(ETouchType::Ended);
		Test.Run();
		CHECK_REDUCE_RESULT(Test);
	}
	{
		//	3.4 First and third are both full
		AzureReduceTouchTest Test;
		Test.PushBackToReduce(ETouchType::Began);
		Test.PushBackToReduce(ETouchType::Moved);
		Test.PushBackToReduce(ETouchType::Ended);
		Test.PushBackToReduce(ETouchType::Began);
		Test.PushBackToReduce(ETouchType::Moved);
		Test.PushBackToReduce(ETouchType::Ended);
		Test.PushBackToRemain(ETouchType::Began);
		Test.PushBackToReduce(ETouchType::Moved);
		Test.PushBackToRemain(ETouchType::Ended);
		Test.Run();
		CHECK_REDUCE_RESULT(Test);
	}
#undef CHECK_REDUCE_RESULT
	return true;
}

#endif	//	WITH_EDITOR