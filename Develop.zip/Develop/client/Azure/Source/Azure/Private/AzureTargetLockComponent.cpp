// Fill out your copyright notice in the Description page of Project Settings.

#include "AzureTargetLockComponent.h"
#include "WidgetLayoutLibrary.h"
#include "AzureEntryPoint.h"
#include "GameLogic/Player/GamePlayer.h"
#include "GUI/AzureHudTextMan.h"
#include "UserWidget.h"
#include "Kismet/GameplayStatics.h"
#include "HAL/IConsoleManager.h"
#include "AzureLuaIntegration.h"

// Sets default values for this component's properties
UAzureTargetLockComponent::UAzureTargetLockComponent()
{
	PrimaryComponentTick.bCanEverTick = true;
	PrimaryComponentTick.bStartWithTickEnabled = true;
	PrimaryComponentTick.TickGroup = TG_PostUpdateWork;
	PrimaryComponentTick.EndTickGroup = TG_PostUpdateWork;

	CurrentTime = FPlatformTime::Seconds();
	LastTickTime = CurrentTime;
}


// Called when the game starts
void UAzureTargetLockComponent::BeginPlay()
{
	Super::BeginPlay();
	PlayerController = UGameplayStatics::GetPlayerController(this->GetOwner(), 0);
}

// Called every frame
void UAzureTargetLockComponent::TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction)
{
	CurrentTime = FPlatformTime::Seconds();
	if (!UseScaleTime)
	{
		DeltaTime = CurrentTime - LastTickTime;
	}
	LastTickTime = CurrentTime;

	Super::TickComponent(DeltaTime, TickType, ThisTickFunction);

	if (PlayerController.IsValid())
	{
		TickUserWidget();
	}
}


void UAzureTargetLockComponent::OnComponentDestroyed(bool bDestroyingHierarchy)
{
	UActorComponent::OnComponentDestroyed(bDestroyingHierarchy);
}

void UAzureTargetLockComponent::AddLockWidget(UUserWidget * userWidget)
{
	userWidgets.Push(userWidget);
}

void UAzureTargetLockComponent::RemoveLockWidget(UUserWidget * userWidget)
{
	for (size_t i = 0; i < userWidgets.Num(); i++)
	{
		if (userWidgets[i].Get() == userWidget)
		{
			userWidgets.RemoveAt(i);
			i--;
		}
	}
}

void UAzureTargetLockComponent::SetParentComponent(USceneComponent* parentComponent)
{
	ParentComponent = parentComponent;
}

FVector UAzureTargetLockComponent::AdjustWorldOffset(const FVector& worldOffset)
{
	FVector adjustWorldOffset = worldOffset;
	float yoffset = adjustWorldOffset.Y;
	if (yoffset != 0) //��ͷ���ҷ���ƫ��
	{
		UCameraComponent *pCamera = AAzureEntryPoint::Instance ? AAzureEntryPoint::Instance->GetMainCameraComponent() : nullptr;
		if (pCamera)
		{
			adjustWorldOffset.Y = 0;
			adjustWorldOffset += yoffset * pCamera->GetRightVector();
		}
	}
	return adjustWorldOffset;
}

void UAzureTargetLockComponent::TickUserWidget()
{
	if (userWidgets.Num() <= 0)
	{
		return;
	}
	USceneComponent* pParent = ParentComponent.Get();
	if (pParent == nullptr)
	{
		return;
	}
	static float maxCameraSpaceDepth = IConsoleManager::Get().FindConsoleVariable(TEXT("Slate.CameraSpaceDepth"))->GetFloat();
	 
	FVector frameWorldOffset = AdjustWorldOffset(WorldOffset);

	FVector vCurPos = pParent->GetComponentLocation();
	FVector AttachPointWorldPosition = frameWorldOffset + vCurPos;

	FVector2D AttachPointScreenPosition;
	FVector4 NDCSpacePos;
	bool bSuc = PlayerController->ProjectWorldLocationToScreen(AttachPointWorldPosition, AttachPointScreenPosition, false, &NDCSpacePos);

	float Scale = UWidgetLayoutLibrary::GetViewportScale(this);

	for (size_t i = 0; i < userWidgets.Num(); i++)
	{
		UUserWidget * userWidget = userWidgets[i].Get();
		if (userWidget)
		{
			bool bVis = userWidget->GetVisibility() == ESlateVisibility::SelfHitTestInvisible;
			if (bSuc != bVis)
			{
				userWidget->SetVisibility(bSuc ? ESlateVisibility::SelfHitTestInvisible : ESlateVisibility::Collapsed);
			}
			if (bSuc)
			{
				userWidget->SetPositionInViewport(AttachPointScreenPosition + ScreenOffset * Scale);

				if (maxCameraSpaceDepth > 0)
				{
					userWidget->SetDepth(FMath::Clamp(1.0f - NDCSpacePos.W / maxCameraSpaceDepth, 0.0f, 1.0f));
				}
				else
				{
					userWidget->SetDepth(NDCSpacePos.Z);
				}
			}
		}
	}
}


