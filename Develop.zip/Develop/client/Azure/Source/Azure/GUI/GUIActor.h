// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "GameFramework/Actor.h"
#include "wLua/LuaInterface.h"
#include "AzureLuaFunction.h"
#include "GUIActor.generated.h"

UCLASS()
class AZURE_API AGUIActor : public AActor
{
	GENERATED_BODY()

private:

public:	
	// Sets default values for this actor's properties
	AGUIActor();

	// Called when the game starts or when spawned
	virtual void BeginPlay() override;
	virtual void BeginDestroy() override;

	// Called every frame
	virtual void Tick( float DeltaSeconds ) override;

	//UFUNCTION(BlueprintCallable, Category = "MyTest")
	TMap<int, FString> MyTestFunction(const TArray<int>& a,const TMap<FString,int32>& b);

	UFUNCTION(BlueprintCallable, Category = "MyTest")
	void MyTestFunction2(FAzureLuaFunction func);
};
