#pragma once

#include "CoreMinimal.h"
#include <unordered_map>
#include "wLua/LuaInterface.h"


class AzureObjMsgHandler
{
	template <typename ValueType>
	struct std_string_KeyFuncs : BaseKeyFuncs<TPair<std::string, ValueType>, std::string>
	{
		typedef BaseKeyFuncs<TPair<std::string, ValueType>, std::string> Super;
		static typename Super::KeyInitType GetSetKey(typename Super::ElementInitType Element) { return Element.Key; }
		static bool Matches(typename Super::KeyInitType A, typename Super::KeyInitType B) { return A == B; }
		static uint32 GetKeyHash(typename Super::KeyInitType Key) { return uint32(std::hash<std::string>{}(Key)); }
	};

	typedef TArray<wLua::lua_registry_handle> CALLBACKLIST;
	typedef TMap<std::string, CALLBACKLIST, FDefaultSetAllocator, std_string_KeyFuncs<CALLBACKLIST>> MSGCALLBACKLIST;
	typedef TMap<TWeakObjectPtr<class UWidget>, MSGCALLBACKLIST> OBJ_MSGCALLBACKLIST;
	typedef TSet<class UUserWidget*> UserWidgetSet;
	struct UserWidget_CallbackInfo
	{
		OBJ_MSGCALLBACKLIST objMsgCallbackList;
		UserWidgetSet childUserWidgetSet;
	};
	typedef TMap<class UUserWidget*, UserWidget_CallbackInfo> USERWIDGET_USERWIDGET_CALLBACKINFO;
public:
	bool AddHandler(class  UWidget* widget, const char* msgName);
	void RemoveAll(class UUserWidget* widget, bool bOnlyUnref);
	void RemoveAllHandlers(class UWidget* widget, bool bOnlyUnref);
	void RemoveAllHandlers(class UWidget* widget, const char* msgName, bool bOnlyUnref);

	//[-0,+0], ջ��Ӧ������Ϊ extraParamCount �Ĳ���
	void CallLua(class wLua::Lua* wlua, class UWidget* widget, const char* msgName, int extraParamCount);
protected:
	UserWidget_CallbackInfo* requireUserWidgetCallbackInfo(class UUserWidget* userWidget);
	CALLBACKLIST* requireMsgCallbackList(class  UWidget* widget, const char* msgName);
	CALLBACKLIST* getMsgCallbackList(class  UWidget* widget, const char* msgName);
	void RemoveAll(class UUserWidget* widget, bool isRemovingAllOnParent, bool bOnlyUnref);
	class UUserWidget* getUserWidget(class  UWidget* widget);
private:
	
	USERWIDGET_USERWIDGET_CALLBACKINFO obj_callbackList;
};

extern AzureObjMsgHandler* gAzureObjMsgHandler;