#pragma once

#include "CoreMinimal.h"
#include "Runtime/UMG/Public/IUMGMsgHandler.h"
#include <string>

namespace wLua
{
	class Lua;
};

struct lua_State;

class AzureMsgHandler : public IUMGMsgHandler
{

public:
	bool CallLuaBegin(int functable, const char* luafuncname, class UWidget * widget,lua_State *  wlua, bool checkObjFunc = false);
	/** the clicked object doesn't correspond to a Widget, only name available */
	bool CallLuaBeginNoWidget(int functable, const char* luafuncname, const FString& name, lua_State *  wlua);
	void CallLuaEnd(lua_State * wlua, int exteraParamCount);

public:
	static void Init();
	virtual int OnUserWidgetBeginDestroy(class UUserWidget * userWidget) override;

	virtual int OnClicked(int luafuncs, class  UWidget * widget) override;
	virtual int OnPressed(int luafuncs, class  UWidget * widget) override;
	virtual int OnReleased(int luafuncs, class  UWidget * widget) override;
	virtual int OnHovered(int luafuncs, class  UWidget * widget) override;
	virtual int OnUnhovered(int luafuncs, class  UWidget * widget) override;
	virtual int OnChecked(int luafuncs, class UCheckBox* widget, ECheckBoxState NewState) override;
	virtual int OnTextChanged(int luafuncs, class UWidget* widget, const class FText& InText) override;
	virtual int OnTextCommitted(int luafuncs, class UWidget* widget, const class FText& InText, ETextCommit::Type CommitMethod) override;
	virtual int OnScroll(int luafuncs, class  UWidget * widget) override;
	virtual int OnFocusChange(int luafuncs, class  UWidget * widget, bool bFocus);
private:
	UWidget* m_currentCallLua_widget;
	std::string m_currentCallLua_funcNameNoSuffix;
};