﻿#include "AzureScreenBulletMan.h"
#include "Components/CanvasPanel.h"
#include "AzureEntryPoint.h"
#include "AzureUtility.h"
#include "UserWidget.h"
#include "ConstructorHelpers.h"
#include "Engine/Font.h"
#include "CanvasPanelSlot.h"
#include "Blueprint/WidgetLayoutLibrary.h"

const int BULLETCACHESIZE = 50;
const FAnchors bullet_anchor = FAnchors(0, 0, 0, 0);


AzureScreenBulletMan::AzureScreenBulletMan()
{
	tempFont = FSlateFontInfo(LoadObject<UFont>(0, TEXT("/Game/UI/Fonts/HT7000")), 24, FName("Default"));
	sHudUserWidget = NULL;
}


AzureScreenBulletMan::~AzureScreenBulletMan()
{
	for (CGBullet *ent : CGBulletArr)
	{
		delete ent;
	}
	CGBulletArr.Empty();
	for (Entry *ent : EntryArr)
	{
		if (ent->label.IsValid())
			ent->label->RemoveFromParent();
		delete ent;
	}
	EntryArr.Empty();
	for (Entry *ent : UnusedEntryArr)
	{
		if (ent->label.IsValid())
			ent->label->RemoveFromParent();
		delete ent;
	}
	UnusedEntryArr.Empty();
	if (sHudUserWidget.IsValid())
		sHudUserWidget->RemoveFromParent();
	sHudUserWidget = nullptr;
}

UUserWidget * AzureScreenBulletMan::GetHudUserWidget()
{
	if (!sHudUserWidget.IsValid())
	{
		UClass * Class = LoadObject<UClass>(0, TEXT("/Game/UI/UMG/HUDRoot.HUDRoot_C"));
		if (Class)
		{
			if (!AAzureEntryPoint::Instance)
				return nullptr;

			UWorld * world = AAzureEntryPoint::Instance->GetWorld();
			sHudUserWidget = ::CreateWidget<UUserWidget>(world, Class);
			sHudUserWidget->Initialize();
			sHudUserWidget->AddToViewport(99999);
		}
	}
	if (!Inited)
		Init();
	return sHudUserWidget.Get();
}

void AzureScreenBulletMan::AddOneScreenBulletText(FText &InText, int fontSize, BULLET_TYPE bullettype, float lifeTime, FVector2D &velocity, int track_limit, bool bForce)
{
	UUserWidget *pHud = GetHudUserWidget();
	UCanvasPanel *pCanvas = pHud ? Cast<UCanvasPanel>(pHud->GetRootWidget()) : nullptr;
	if (pCanvas)
	{
		if (!bForce && !HasValidTrack(bullettype, track_limit))
			return;

		SetActive(true);
		Entry *ent = NULL;
		if (UnusedEntryArr.Num() > 0)
		{
			ent = UnusedEntryArr.Pop();
		}
		else
		{
			ent = new Entry;
		}
		ent->passTime = 0;
		if (!ent->label.IsValid())
		{
			ent->label = NewObject<UAzureHTMLTextBlock>(pCanvas->GetOuter(), UAzureHTMLTextBlock::StaticClass());
			UCanvasPanelSlot *Slot = pCanvas->AddChildToCanvas(ent->label.Get());
			if (Slot)
			{
				Slot->SetAnchors(bullet_anchor);
				Slot->SetAlignment(FVector2D(0, 0));
				Slot->SetAutoSize(true);
			}
		}
		
		tempFont.Size = fontSize;
		ent->label->SetFont(tempFont);
		ent->label->SetText(InText.ToString());
		ent->label->SetVisibility(ESlateVisibility::HitTestInvisible);
		FVector2D size = ent->label->GetTextSize();
		float viewportScale = UWidgetLayoutLibrary::GetViewportScale(AAzureEntryPoint::Instance);
		FVector2D screensize = UWidgetLayoutLibrary::GetViewportSize(AAzureEntryPoint::Instance);

		size = size * viewportScale;
		if (lifeTime > 0)
		{
			ent->liftTime = lifeTime;
			// 自动计算速度
			if (bullettype == BULLET_TYPE::RIGHT_TO_LEFT && velocity.X == 0)
			{
				velocity.X = -(screensize.X + size.X) / lifeTime;
			}
		}
		else if (velocity.X == 0)
		{
			ent->liftTime = lifeTime;
		}
		else
		{
			
			ent->liftTime = fabs((screensize.X + size.X) / velocity.X);
		}
		ent->moveSpeed = velocity;


		FVector2D startPos = DecideStartPos(bullettype, ent->liftTime, velocity, size, track_limit);
		ent->startpos = startPos;
		ent->ApplyOffset(startPos.X, startPos.Y);

		EntryArr.Add(ent);
	}
}

void AzureScreenBulletMan::AddOneCGBulletText(FText &InText, int fontSize, BULLET_TYPE bullettype, float lifeTime, FVector2D &velocity, float startTime, bool bForceShow)
{
	if (!bCGPlaying)
		return;
	if (startTime < CGPassTime)
		return;
	CGBullet *ent = new CGBullet;
	ent->InText = InText;
	ent->startTime = startTime;
	ent->bulletType = bullettype;
	ent->fontSize = fontSize;
	ent->liftTime = lifeTime;
	ent->moveSpeed = velocity;
	ent->bForceShow = bForceShow;

	CGBulletArr.Add(ent);
}

void AzureScreenBulletMan::Update(float dt)
{
	if (bCGPlaying)
		CGPassTime += dt;

	if (bCGPlaying && bCGActive)
	{
		for (int i = CGBulletArr.Num() - 1; i >= 0; --i)
		{
			CGBullet *ent = CGBulletArr[i];
			if (ent->startTime <= CGPassTime)
			{
				CGBulletArr.RemoveAt(i);
				if (CGPassTime - ent->startTime < 0.1)
				{
					LastBulletTime = CGPassTime;
					AddOneScreenBulletText(ent->InText, ent->fontSize, ent->bulletType, ent->liftTime, ent->moveSpeed, iCGTrackLimit, ent->bForceShow);
				}
				delete ent;
			}
		}
	}

	
	for (int i = EntryArr.Num() - 1; i >= 0; --i)
	{
		Entry *ent = EntryArr[i];
		ent->passTime += dt;
		if (bActive)
		{
			float totalEnd = ent->liftTime;
			if (ent->passTime > totalEnd)
			{
				EntryArr.RemoveAt(i);
				if (ent->label.IsValid())
					ent->label->SetVisibility(ESlateVisibility::Collapsed);
				if (UnusedEntryArr.Num() >= BULLETCACHESIZE)
				{
					if (ent->label.IsValid())
						ent->label->RemoveFromParent();
					delete ent;
				}
				else
					UnusedEntryArr.Add(ent);
				continue;
			}


			float x = ent->moveSpeed.X * ent->passTime + ent->startpos.X;
			float y = ent->moveSpeed.Y * ent->passTime + ent->startpos.Y;
			ent->ApplyOffset(x, y);
		}
	}

	if (bActive && EntryArr.Num() == 0)
	{
		SetActive(false);
	}
}

void AzureScreenBulletMan::SetActive(bool active)
{
	bActive = active;
	UUserWidget *pHud = GetHudUserWidget();
	if (pHud)
	{
		UCanvasPanel *pCanvas = Cast<UCanvasPanel>(pHud->GetRootWidget());
		if (pCanvas)
		{
			pCanvas->SetVisibility(active ? ESlateVisibility::HitTestInvisible : ESlateVisibility::Collapsed);
		}
	}
	if (!bActive)
	{
		for (Entry *ent : EntryArr)
		{
			if (ent->label.IsValid())
				ent->label->RemoveFromParent();
			delete ent;
		}
		EntryArr.Empty();
	}
}

void AzureScreenBulletMan::SetCGActive(bool active)
{
	bCGActive = active;
	if (!bCGActive)
		SetActive(false);
}

void AzureScreenBulletMan::SetCGTrackLimit(int limit)
{
	iCGTrackLimit = limit;
}

void AzureScreenBulletMan::StartCG(float interval, float startTime)
{
	for (CGBullet *ent : CGBulletArr)
	{
		delete ent;
	}
	CGBulletArr.Empty();
	bCGPlaying = true;
	fInterval = interval;
	LastBulletTime = -10;
	CGPassTime = startTime;
}

void AzureScreenBulletMan::StopCG(bool bRemoveBullet)
{
	for (CGBullet *ent : CGBulletArr)
	{
		delete ent;
	}
	CGBulletArr.Empty();
	bCGPlaying = false;
	CGPassTime = 0;
	if (bRemoveBullet)
		SetActive(false);
}

FVector2D AzureScreenBulletMan::DecideStartPos(BULLET_TYPE bullettype, float lifeTime, FVector2D &velocity, FVector2D &textSize, int track_limit)
{
	TArray<int32> ValidTracks;
	BulletTrack *validTrack;
	double curTime = FPlatformTime::Seconds();
	if (bullettype == RIGHT_TO_LEFT)
	{
		int tracknum = HorizontalTracks.Num();
		if (track_limit > 0 && track_limit < tracknum)
			tracknum = track_limit;
		bool bRemoveDown = false;
		bool bRemoveMid = false;
		for (int32 i = 0; i < tracknum; ++i)
		{
			BulletTrack &track = HorizontalTracks[i];
			if (track.validSecond == 0 || track.validSecond < curTime)
			{
				ValidTracks.Add(i);
				if (track.track_type == HORIZONTAL_UP)
					bRemoveMid = true;
				else if(track.track_type == HORIZONTAL_MID)
					bRemoveDown = true;
			}
			if (bRemoveMid && i >= HORIZONTAL_UP_TRACK) //先用Up的track 再用mid的 再用down的
				break;
			if (bRemoveDown && i >= HORIZONTAL_UP_TRACK + HORIZONTAL_MID_TRACK)
				break;
		}

		int32 validnum = ValidTracks.Num();
		if (validnum == 0)
			validTrack = &HorizontalTracks[FMath::RandRange(0, tracknum - 1)];
		else
			validTrack = &HorizontalTracks[ValidTracks[FMath::RandRange(0, validnum - 1)]];
		if (validTrack)
		{
			validTrack->validSecond = curTime + fabs(textSize.X / velocity.X) + 0.5;
			return validTrack->startPos;
		}
	}
	else if (bullettype == MIDDLE)
	{
		int tracknum = MiddleTracks.Num();
		if (track_limit > 0 && track_limit < tracknum)
			tracknum = track_limit;

		for (int32 i = 0; i < tracknum; ++i)
		{
			BulletTrack &track = MiddleTracks[i];
			if (track.validSecond == 0 || track.validSecond < curTime)
			{
				ValidTracks.Add(i);
			}
		}
		int32 validnum = ValidTracks.Num();
		if (validnum == 0)
			validTrack = &MiddleTracks[FMath::RandRange(0, tracknum - 1)];
		else
			validTrack = &MiddleTracks[ValidTracks[FMath::RandRange(0, validnum - 1)]];
		if (validTrack)
		{
			validTrack->validSecond = curTime + lifeTime + 0.5;
			return validTrack->startPos - FVector2D(textSize.X/2,0);
		}
	}
	return FVector2D(0, 0);
}

bool AzureScreenBulletMan::HasValidTrack(BULLET_TYPE bullettype, int track_limit)
{
	double curTime = FPlatformTime::Seconds();
	if (bullettype == RIGHT_TO_LEFT)
	{
		int tracknum = HorizontalTracks.Num();
		if (track_limit > 0 && track_limit < tracknum)
			tracknum = track_limit;
		for (int32 i = 0; i < tracknum; ++i)
		{
			BulletTrack &track = HorizontalTracks[i];
			if (track.validSecond == 0 || track.validSecond < curTime)
			{
				return true;
			}
		}	
	}
	else if (bullettype == MIDDLE)
	{
		int tracknum = MiddleTracks.Num();
		if (track_limit > 0 && track_limit < tracknum)
			tracknum = track_limit;
		for (int32 i = 0; i < tracknum; ++i)
		{
			BulletTrack &track = MiddleTracks[i];
			if (track.validSecond == 0 || track.validSecond < curTime)
			{
				return true;
			}
		}
	}
	return false;
}

void AzureScreenBulletMan::Init()
{
	Inited = true;

	HorizontalTracks.Empty();
	HorizontalTracks.AddDefaulted(HORIZONTAL_TRACK_NUM);
	MiddleTracks.Empty();
	MiddleTracks.AddDefaulted(MIDDLE_TRACK_NUM);
	FVector2D size = UWidgetLayoutLibrary::GetViewportSize(AAzureEntryPoint::Instance);

	//horizontal
	float miny = 30;
	float maxy = size.Y * 0.75;
	float disy = maxy / HORIZONTAL_TRACK_NUM;
	for (int32 i = 0; i < HorizontalTracks.Num(); ++i)
	{
		BulletTrack &track = HorizontalTracks[i];
		track.startPos.X = size.X;
		track.startPos.Y = miny + i * disy;
		
		if (i < HORIZONTAL_UP_TRACK)
			track.track_type = HORIZONTAL_UP;
		else if (i < HORIZONTAL_UP_TRACK + HORIZONTAL_MID_TRACK)
			track.track_type = HORIZONTAL_MID;
		else
			track.track_type = HORIZONTAL_DOWN;
	}

	//middle
	miny = 0;
	maxy = size.Y * 0.75;
	disy = (maxy - miny) / MIDDLE_TRACK_NUM;
	for (int32 i = 0; i < MiddleTracks.Num(); ++i)
	{
		BulletTrack &track = MiddleTracks[i];
		track.startPos.X = size.X / 2;
		track.startPos.Y = miny + i * disy;

		track.track_type = MIDDLE_TRACK;
	}
}

void AzureScreenBulletMan::Entry::ApplyOffset(float x,float y)
{
	if (label.IsValid())
	{
		float Scale = UWidgetLayoutLibrary::GetViewportScale(AAzureEntryPoint::Instance);
		UCanvasPanelSlot *CanvasPanelSlot = Cast<UCanvasPanelSlot>(label->Slot);
		if (CanvasPanelSlot)
		{
			FMargin Margin = CanvasPanelSlot->GetOffsets();
			Margin.Left = x / Scale;
			Margin.Top = y / Scale;
			CanvasPanelSlot->SetOffsets(Margin);
		}
	}

}
