#include "AzureMsgHandler.h"
//#include "../wLua/UObjectHeaders.h"
#include "Widget.h"
#include "CheckBox.h"
#include "EditableTextBox.h"
#include "Text.h"
#include "AzureEntryPoint.h"
#include "wLua/LuaInterface.h"
#include "Components/Slider.h"
#include "UMGcustom/Public/UMGCustomStatics.h"
#include "AzureObjMsgHandler.h"


extern std::unordered_map<UUserWidget*, wLua::lua_registry_handle> UserWidget2RegistryHandle;
extern wLua::Lua* AAzureEntryPoint_GetWLua();

static AzureMsgHandler *s_AzureMsgHandler = nullptr;
AzureObjMsgHandler* gAzureObjMsgHandler = nullptr;
void AzureMsgHandler::Init()
{
	s_AzureMsgHandler = new AzureMsgHandler;
	gAzureObjMsgHandler = new AzureObjMsgHandler;
	UUserWidget::SetMsgHandler(s_AzureMsgHandler);
}

int AzureMsgHandler::OnUserWidgetBeginDestroy(UUserWidget * userWidget)
{
	if (gAzureObjMsgHandler && userWidget)
	{
		gAzureObjMsgHandler->RemoveAll(userWidget, false);
	}

	wLua::lua_registry_handle luafuncs;
	std::unordered_map<UUserWidget*, wLua::lua_registry_handle>::iterator it = UserWidget2RegistryHandle.find(userWidget);
	if (it != UserWidget2RegistryHandle.end())
	{
		luafuncs = it->second;
		UserWidget2RegistryHandle.erase(userWidget);
	}

	userWidget->SetMsgTable(LUA_NOREF);

	wLua::Lua * wlua = nullptr;
	if (!AAzureEntryPoint::Instance)
		return 0;

	wlua = AAzureEntryPoint::Instance->GetWLua();
	if (!wlua)
		return 0;

	lua_State_Wrapper L = wlua->GetL();
	if (!L)
		return 0;

	if (luafuncs.IsValid())
	{
		wLua::lua_registry_handle::wlua_unref(L, LUA_REGISTRYINDEX, luafuncs);
	}
	return 1;
}

bool AzureMsgHandler::CallLuaBegin(int functable,const char* luafuncname, UWidget * widget, lua_State* L,bool checkObjFunc)
{
	if (!L || functable < 0)
		return false;

	m_currentCallLua_widget = widget;
	m_currentCallLua_funcNameNoSuffix = luafuncname;

	bool objFuncExist = checkObjFunc;
	lua_rawgeti(L, LUA_REGISTRYINDEX, functable);//t
	if (!lua_istable(L, -1))
	{
		lua_pop(L, 1);
		return false;
	}
	lua_getfield(L, -1, !checkObjFunc ? luafuncname : (astring(luafuncname)+"Obj").c_str());//t,func
	if (!lua_isfunction(L,-1))
	{
		if (!checkObjFunc)
		{
			lua_pop(L, 2);
			return false;
		}
		objFuncExist = false;
		lua_pop(L, 1);
		lua_getfield(L, -1, luafuncname);
		if (!lua_isfunction(L, -1))
		{
			lua_pop(L, 2);
			return false;
		}
	}
	if (!objFuncExist)
		lua_pushstring(L, TCHAR_TO_UTF8(*(widget->GetName()))); //t,func,widgetname
	else
		wLua::FLuaUtils::ReturnUObject(L, widget);
	return true;
}

bool AzureMsgHandler::CallLuaBeginNoWidget(int functable, const char* luafuncname, const FString& name, lua_State * L)
{
	if (!L || functable < 0)
		return false;

	m_currentCallLua_widget = nullptr;
	m_currentCallLua_funcNameNoSuffix = luafuncname;

	lua_rawgeti(L, LUA_REGISTRYINDEX, functable);//t
	if (!lua_istable(L, -1))
	{
		lua_pop(L, 1);
		return false;
	}
	lua_getfield(L, -1, luafuncname);//t,func
	if (!lua_isfunction(L, -1))
	{
		lua_pop(L, 2);
		return false;
	}
	lua_pushstring(L, TCHAR_TO_UTF8(*name));
	return true;
}

void AzureMsgHandler::CallLuaEnd(lua_State * L, int exteraParamCount)
{
	if (m_currentCallLua_funcNameNoSuffix != "")
	{
		if (!AAzureEntryPoint::Instance)
			return;

		wLua::Lua * wlua = AAzureEntryPoint::Instance->GetWLua();
		if (m_currentCallLua_widget)
		{
			//-> ..., extraParma_1, extraParma_2, ..., extraParma_n
			gAzureObjMsgHandler->CallLua(wlua, m_currentCallLua_widget, m_currentCallLua_funcNameNoSuffix.c_str(), exteraParamCount);
		}
		wlua->Call(1 + exteraParamCount);
		lua_pop(L, 1);
	}
		
	m_currentCallLua_widget = nullptr;
	m_currentCallLua_funcNameNoSuffix.clear();
}

int AzureMsgHandler::OnClicked(int luafuncs, UWidget * widget)
{

	lua_State_Wrapper L = AAzureEntryPoint::SafeGetL();
	if (CallLuaBegin(luafuncs, "onClick", widget,L,true))
	{
		CallLuaEnd(L,0);
	}

	return 1;
}

int AzureMsgHandler::OnPressed(int luafuncs, UWidget * widget)
{

	lua_State_Wrapper L = AAzureEntryPoint::SafeGetL();
	if (CallLuaBegin(luafuncs, "onPress", widget, L, true))
	{
		lua_pushboolean(L, true);
		CallLuaEnd(L, 1);
	}
	return 1;
}

int AzureMsgHandler::OnReleased(int luafuncs, UWidget * widget)
{

	lua_State_Wrapper L = AAzureEntryPoint::SafeGetL();
	if (CallLuaBegin(luafuncs, "onPress", widget, L, true))
	{
		lua_pushboolean(L, false);
		CallLuaEnd(L, 1);
	}
	return 1;
}

int AzureMsgHandler::OnHovered(int luafuncs, UWidget * widget)
{

	lua_State_Wrapper L = AAzureEntryPoint::SafeGetL();
	if (CallLuaBegin(luafuncs, "onHovered", widget, L))
	{
		lua_pushboolean(L, true);
		CallLuaEnd(L, 1);
	}
	return 1;
}

int AzureMsgHandler::OnUnhovered(int luafuncs, UWidget * widget)
{

	lua_State_Wrapper L = AAzureEntryPoint::SafeGetL();
	if (CallLuaBegin(luafuncs, "onHovered", widget, L))
	{
		lua_pushboolean(L, false);
		CallLuaEnd(L, 1);
	}
	return 1;
}

int AzureMsgHandler::OnChecked(int luafuncs, UCheckBox* widget, ECheckBoxState NewState)
{
	lua_State_Wrapper L = AAzureEntryPoint::SafeGetL();
	if (CallLuaBegin(luafuncs, "onToggle",widget, L, true))
	{
		lua_pushboolean(L, NewState == ECheckBoxState::Checked);
		CallLuaEnd(L, 1);
	}
	return 1;

}

int AzureMsgHandler::OnTextChanged(int luafuncs, UWidget* widget, const FText& InText)
{
	lua_State_Wrapper L = AAzureEntryPoint::SafeGetL();
	if (CallLuaBegin(luafuncs, "onTextChange", widget, L))
	{
		lua_pushstring(L, TCHAR_TO_UTF8(*InText.ToString()));
		CallLuaEnd(L, 1);
	}
	return 1;

}
int AzureMsgHandler::OnTextCommitted(int luafuncs, UWidget* widget, const FText& InText, ETextCommit::Type CommitMethod)
{
	if (CommitMethod != ETextCommit::OnEnter)
		return 0;
	lua_State_Wrapper L = AAzureEntryPoint::SafeGetL();
	if (CallLuaBegin(luafuncs, "onSubmit", widget, L))
	{
		//lua_pushstring(L,TCHAR_TO_UTF8(*InText.ToString()));
		wLua::FLuaUtils::ReturnUObject(L,widget);
		CallLuaEnd(L, 1);
	}
	return 1;

}
int AzureMsgHandler::OnScroll(int luafuncs, class  UWidget * widget)
{
	USlider *Slider = Cast<USlider>(widget);
	if (!Slider)
		return 0;

	lua_State_Wrapper L = AAzureEntryPoint::SafeGetL();
	if (CallLuaBegin(luafuncs, "onScroll", widget, L, true))
	{
		if (Slider)
		{
			lua_pushnumber(L, Slider->GetValue());
			CallLuaEnd(L, 1);
		}
	}
	return 1;
}

//------------------------------------------------------------------------------------------
void AzureMsgHandler_onSelect(UWidget *widget, const FString& id, int32 index)
{
	AzureMsgHandler *MsgHandler = s_AzureMsgHandler;
	UUserWidget *UserWidget = widget->GetUserWidget();
	if (UserWidget && MsgHandler)
	{
		lua_State_Wrapper L = AAzureEntryPoint::SafeGetL();
		if (MsgHandler->CallLuaBegin(UserWidget->GetMsgTable(), "onSelect", widget, L, true))
		{
			lua_pushstring(L, TCHAR_TO_UTF8(*id));
			lua_pushinteger(L, index);
			MsgHandler->CallLuaEnd(L, 2);
		}
	}
}
void AzureMsgHandler_onDoubleClick(UWidget *widget)
{
	AzureMsgHandler *MsgHandler = s_AzureMsgHandler;
	UUserWidget *UserWidget = widget->GetUserWidget();
	if (UserWidget && MsgHandler)
	{
		lua_State_Wrapper L = AAzureEntryPoint::SafeGetL();
		if (MsgHandler->CallLuaBegin(UserWidget->GetMsgTable(), "onDoubleClick", widget, L, true))
		{
			MsgHandler->CallLuaEnd(L, 0);
		}
	}
}
void AzureMsgHandler_onClickHTMLName(UWidget *widget, const FString& name)
{
	AzureMsgHandler *MsgHandler = s_AzureMsgHandler;
	UUserWidget *UserWidget = widget->GetUserWidget();
	if (UserWidget && MsgHandler)
	{
		lua_State_Wrapper L = AAzureEntryPoint::SafeGetL();
		if (MsgHandler->CallLuaBeginNoWidget(UserWidget->GetMsgTable(), "OnClickHTMLName", name, L))
		{
			MsgHandler->CallLuaEnd(L, 1 - 1);
		}
	}
}
void AzureMsgHandler_onClickHTML(UWidget *widget, const FString& href)
{
	AzureMsgHandler *MsgHandler = s_AzureMsgHandler;
	UUserWidget *UserWidget = widget->GetUserWidget();
	if (UserWidget && MsgHandler)
	{
		lua_State_Wrapper L = AAzureEntryPoint::SafeGetL();
		if (MsgHandler->CallLuaBegin(UserWidget->GetMsgTable(), "OnClickHTML", widget, L, true))
		{
			lua_pushstring(L, TCHAR_TO_UTF8(*href));
			MsgHandler->CallLuaEnd(L, 2 - 1);
		}
	}
}

//------------------------------------------------------------------------------------------
void AzureMsgHandler_onDragStart(UWidget *Dragged, const FVector2D& CurPosition)
{
	AzureMsgHandler *MsgHandler = s_AzureMsgHandler;
	UUserWidget *UserWidget = Dragged->GetUserWidget();
	if (UserWidget && MsgHandler)
	{
		lua_State_Wrapper L = AAzureEntryPoint::SafeGetL();
		if (MsgHandler->CallLuaBegin(UserWidget->GetMsgTable(), "onDragStart", Dragged, L, true))
		{
			lua_pushnumber(L, CurPosition.X);
			lua_pushnumber(L, CurPosition.Y);
			MsgHandler->CallLuaEnd(L, 2);
		}
	}
}
void AzureMsgHandler_onDragEnd(UWidget *Target, UWidget *Dragged)
{
	AzureMsgHandler *MsgHandler = s_AzureMsgHandler;
	UUserWidget *UserWidget = Dragged->GetUserWidget();
	if (UserWidget && MsgHandler)
	{
		lua_State_Wrapper L = AAzureEntryPoint::SafeGetL();
		if (MsgHandler->CallLuaBegin(UserWidget->GetMsgTable(), "onDragEnd", Dragged, L, true))
		{
			wLua::FLuaUtils::ReturnUObject(L, Target);
			MsgHandler->CallLuaEnd(L, 1);
		}
	}
}
void AzureMsgHandler_onDragCancel(UWidget *Dragged)
{
	AzureMsgHandler *MsgHandler = s_AzureMsgHandler;
	UUserWidget *UserWidget = Dragged->GetUserWidget();
	if (UserWidget && MsgHandler)
	{
		lua_State_Wrapper L = AAzureEntryPoint::SafeGetL();
		if (MsgHandler->CallLuaBegin(UserWidget->GetMsgTable(), "onDragCancel", Dragged, L, true))
		{
			MsgHandler->CallLuaEnd(L, 0);
		}
	}
}
void AzureMsgHandler_onDragIn(UWidget *Target, UWidget *Dragged)
{
	AzureMsgHandler *MsgHandler = s_AzureMsgHandler;
	UUserWidget *UserWidget = Dragged ? Dragged->GetUserWidget() : Target->GetUserWidget();
	if (UserWidget && MsgHandler)
	{
		lua_State_Wrapper L = AAzureEntryPoint::SafeGetL();
		if (MsgHandler->CallLuaBegin(UserWidget->GetMsgTable(), "onDragIn", Target, L, true))
		{
			wLua::FLuaUtils::ReturnUObject(L, Dragged);
			MsgHandler->CallLuaEnd(L, 1);
		}
	}
}
void AzureMsgHandler_onDragOut(UWidget *Target, UWidget *Dragged)
{
	AzureMsgHandler *MsgHandler = s_AzureMsgHandler;
	UUserWidget *UserWidget = Dragged ? Dragged->GetUserWidget() : Target->GetUserWidget();
	if (UserWidget && MsgHandler)
	{
		lua_State_Wrapper L = AAzureEntryPoint::SafeGetL();
		if (MsgHandler->CallLuaBegin(UserWidget->GetMsgTable(), "onDragOut", Target, L, true))
		{
			wLua::FLuaUtils::ReturnUObject(L, Dragged);
			MsgHandler->CallLuaEnd(L, 1);
		}
	}
}
void AzureMsgHandler_onDragOver(UWidget *Target, UWidget *Dragged, const FVector2D& Delta, const FVector2D& CurPosition)
{
	AzureMsgHandler *MsgHandler = s_AzureMsgHandler;
	UUserWidget *UserWidget = Dragged ? Dragged->GetUserWidget() : Target->GetUserWidget();
	if (UserWidget && MsgHandler)
	{
		lua_State_Wrapper L = AAzureEntryPoint::SafeGetL();
		if (MsgHandler->CallLuaBegin(UserWidget->GetMsgTable(), "onDragOver", Target, L, true))
		{
			wLua::FLuaUtils::ReturnUObject(L, Dragged);
			lua_pushnumber(L, Delta.X);
			lua_pushnumber(L, Delta.Y);
			lua_pushnumber(L, CurPosition.X);
			lua_pushnumber(L, CurPosition.Y);
			MsgHandler->CallLuaEnd(L, 5);
		}
	}
}
void AzureMsgHandler_onDrag(UWidget *Dragged, const FVector2D& Delta)
{
	AzureMsgHandler *MsgHandler = s_AzureMsgHandler;
	UUserWidget *UserWidget = Dragged->GetUserWidget();
	if (UserWidget && MsgHandler)
	{
		lua_State_Wrapper L = AAzureEntryPoint::SafeGetL();
		if (MsgHandler->CallLuaBegin(UserWidget->GetMsgTable(), "onDrag", Dragged, L, true))
		{
			lua_pushnumber(L, Delta.X);
			lua_pushnumber(L, Delta.Y);
			MsgHandler->CallLuaEnd(L, 2);
		}
	}
}

void AzureMsgHandler_onEditBoxFocusReceive(UWidget *Focused)
{
	AzureMsgHandler *MsgHandler = s_AzureMsgHandler;
	UUserWidget *UserWidget = Focused->GetUserWidget();
	if (UserWidget && MsgHandler)
	{
		lua_State_Wrapper L = AAzureEntryPoint::SafeGetL();
		if (MsgHandler->CallLuaBegin(UserWidget->GetMsgTable(), "onEditBoxFocusReceive", Focused, L))
		{
			MsgHandler->CallLuaEnd(L, 0);
		}
	}
}

void AzureMsgHandler_onEditBoxFocusLost(UWidget *Focused)
{
	AzureMsgHandler *MsgHandler = s_AzureMsgHandler;
	UUserWidget *UserWidget = Focused->GetUserWidget();
	if (UserWidget && MsgHandler)
	{
		lua_State_Wrapper L = AAzureEntryPoint::SafeGetL();
		if (MsgHandler->CallLuaBegin(UserWidget->GetMsgTable(), "onEditBoxFocusLost", Focused, L))
		{
			MsgHandler->CallLuaEnd(L, 0);
		}
	}
}
//------------------------------------------------------------------------------------------
void AzureMsgHandler_onTouchEvent(UWidget *Widget, int32 Event, const FTouchEventParam& EventParam)
{
	AzureMsgHandler *MsgHandler = s_AzureMsgHandler;
	UUserWidget *UserWidget = Widget->GetUserWidget();
	if (UserWidget && MsgHandler)
	{
		lua_State_Wrapper L = AAzureEntryPoint::SafeGetL();
		if (MsgHandler->CallLuaBegin(UserWidget->GetMsgTable(), "onTouchEvent", Widget, L))
		{
			lua_pushinteger(L, Event);
			//lua_pushlightuserdata(L, const_cast<void*>(EventParam));
			wLua::FLuaTouchEventParam::Return(L, EventParam);
			MsgHandler->CallLuaEnd(L, 2);
		}
	}
}

void AzureMsgHandler_onScroll(UWidget* InWidget, float InOffset)
{
	AzureMsgHandler *MsgHandler = s_AzureMsgHandler;
	UUserWidget *UserWidget = InWidget->GetUserWidget();
	if (UserWidget && MsgHandler)
	{
		lua_State_Wrapper L = AAzureEntryPoint::SafeGetL();
		if (MsgHandler->CallLuaBegin(UserWidget->GetMsgTable(), "onScroll", InWidget, L))
		{
			lua_pushnumber(L, InOffset);
			MsgHandler->CallLuaEnd(L, 1);
		}
	}
}

void AzureMsgHandler_onScrollBegin(UWidget* InWidget)
{
	AzureMsgHandler *MsgHandler = s_AzureMsgHandler;
	UUserWidget *UserWidget = InWidget->GetUserWidget();
	if (UserWidget && MsgHandler)
	{
		lua_State_Wrapper L = AAzureEntryPoint::SafeGetL();
		if (MsgHandler->CallLuaBegin(UserWidget->GetMsgTable(), "onScrollBegin", InWidget, L))
		{
			MsgHandler->CallLuaEnd(L, 0);
		}
	}
}

void AzureMsgHandler_onScrollEnd(UWidget* InWidget)
{
	AzureMsgHandler *MsgHandler = s_AzureMsgHandler;
	UUserWidget *UserWidget = InWidget->GetUserWidget();
	if (UserWidget && MsgHandler)
	{
		lua_State_Wrapper L = AAzureEntryPoint::SafeGetL();
		if (MsgHandler->CallLuaBegin(UserWidget->GetMsgTable(), "onScrollEnd", InWidget, L))
		{
			MsgHandler->CallLuaEnd(L, 0);
		}
	}
}
void AzureMsgHandler_onInertialScrollEnd(UWidget* InWidget, float InOffset)
{
	AzureMsgHandler *MsgHandler = s_AzureMsgHandler;
	UUserWidget *UserWidget = InWidget->GetUserWidget();
	if (UserWidget && MsgHandler)
	{
		lua_State_Wrapper L = AAzureEntryPoint::SafeGetL();
		if (MsgHandler->CallLuaBegin(UserWidget->GetMsgTable(), "onInertialScrollEnd", InWidget, L))
		{
			lua_pushnumber(L, InOffset);
			MsgHandler->CallLuaEnd(L, 1);
		}
	}
}

void AzureMsgHandler_onLongPress(UWidget *InWidget, bool InFinished)
{
	AzureMsgHandler *MsgHandler = s_AzureMsgHandler;
	UUserWidget *UserWidget = InWidget->GetUserWidget();
	if (UserWidget && MsgHandler)
	{
		lua_State_Wrapper L = AAzureEntryPoint::SafeGetL();
		if (MsgHandler->CallLuaBegin(UserWidget->GetMsgTable(), "onLongPress", InWidget, L, true))
		{
			lua_pushboolean(L, InFinished ? 1 : 0);
			MsgHandler->CallLuaEnd(L, 1);
		}
	}
}

#include "Animation/WidgetAnimation.h"
void AzureMsgHandler_onAnimationStarted(UUserWidget *InUserWidget, UWidgetAnimation *InAnimation)
{
	AzureMsgHandler *MsgHandler = s_AzureMsgHandler;
	UUserWidget *UserWidget = InUserWidget;
	if (UserWidget && MsgHandler)
	{
		lua_State_Wrapper L = AAzureEntryPoint::SafeGetL();
		if (MsgHandler->CallLuaBegin(UserWidget->GetMsgTable(), "onAnimationStarted", InUserWidget, L))
		{
			lua_pushstring(L, TCHAR_TO_UTF8(*InAnimation->GetName()));
			MsgHandler->CallLuaEnd(L, 1);
		}
	}
}
void AzureMsgHandler_onAnimationFinished(UUserWidget *InUserWidget, UWidgetAnimation *InAnimation)
{
	AzureMsgHandler *MsgHandler = s_AzureMsgHandler;
	UUserWidget *UserWidget = InUserWidget;
	if (UserWidget && MsgHandler)
	{
		lua_State_Wrapper L = AAzureEntryPoint::SafeGetL();
		if (MsgHandler->CallLuaBegin(UserWidget->GetMsgTable(), "onAnimationFinished", InUserWidget, L))
		{
			lua_pushstring(L, TCHAR_TO_UTF8(*InAnimation->GetName()));
			MsgHandler->CallLuaEnd(L, 1);
		}
	}
}

void AzureMsgHandler_onUIParticlePlay(UWidget *InWidget)
{
	AzureMsgHandler *MsgHandler = s_AzureMsgHandler;
	UUserWidget *UserWidget = InWidget->GetUserWidget();
	if (UserWidget && MsgHandler)
	{
		lua_State_Wrapper L = AAzureEntryPoint::SafeGetL();
		if (MsgHandler->CallLuaBegin(UserWidget->GetMsgTable(), "onUIParticlePlay", InWidget, L))
		{
			MsgHandler->CallLuaEnd(L, 0);
		}
	}
}

void AzureMsgHandler_onUIParticleEnd(UWidget *InWidget)
{
	AzureMsgHandler *MsgHandler = s_AzureMsgHandler;
	UUserWidget *UserWidget = InWidget->GetUserWidget();
	if (UserWidget && MsgHandler)
	{
		lua_State_Wrapper L = AAzureEntryPoint::SafeGetL();
		if (MsgHandler->CallLuaBegin(UserWidget->GetMsgTable(), "onUIParticleEnd", InWidget, L))
		{
			MsgHandler->CallLuaEnd(L, 0);
		}
	}
}

void AzureMsgHandler_onVirtualKeyboardShow(UWidget *InWidget, FPlatformRect InRect)
{
	AzureMsgHandler *MsgHandler = s_AzureMsgHandler;
	UUserWidget *UserWidget = InWidget->GetUserWidget();
	if (UserWidget && MsgHandler)
	{
		lua_State_Wrapper L = AAzureEntryPoint::SafeGetL();
		if (MsgHandler->CallLuaBegin(UserWidget->GetMsgTable(), "onVirtualKeyboardShow", InWidget, L))
		{
			lua_pushnumber(L, InRect.Left);
			lua_pushnumber(L, InRect.Right);
			lua_pushnumber(L, InRect.Top);
			lua_pushnumber(L, InRect.Bottom);
			MsgHandler->CallLuaEnd(L, 4);
		}
	}
}
void AzureMsgHandler_onVirtualKeyboardHide(UWidget *InWidget)
{
	AzureMsgHandler *MsgHandler = s_AzureMsgHandler;
	UUserWidget *UserWidget = InWidget->GetUserWidget();
	if (UserWidget && MsgHandler)
	{
		lua_State_Wrapper L = AAzureEntryPoint::SafeGetL();
		if (MsgHandler->CallLuaBegin(UserWidget->GetMsgTable(), "onVirtualKeyboardHide", InWidget, L))
		{
			MsgHandler->CallLuaEnd(L, 0);
		}
	}
}

void AzureMsgHandler_onScrollListInitFinish(UWidget *InWidget)
{
	AzureMsgHandler *MsgHandler = s_AzureMsgHandler;
	UUserWidget *UserWidget = InWidget->GetUserWidget();
	if (UserWidget && MsgHandler)
	{
		lua_State_Wrapper L = AAzureEntryPoint::SafeGetL();
		if (MsgHandler->CallLuaBegin(UserWidget->GetMsgTable(), "onScrollListInitFinish", InWidget, L, true))
		{
			MsgHandler->CallLuaEnd(L, 0);
		}
	}
}

void AzureMsgHandler_onInfiniteListAddChildFinish(UWidget *InWidget, int32 index)
{
	AzureMsgHandler *MsgHandler = s_AzureMsgHandler;
	UUserWidget *UserWidget = InWidget->GetUserWidget();
	if (UserWidget && MsgHandler)
	{
		lua_State_Wrapper L = AAzureEntryPoint::SafeGetL();
		if (MsgHandler->CallLuaBegin(UserWidget->GetMsgTable(), "onInfiniteListAddChildFinish", InWidget, L))
		{
			lua_pushnumber(L, index);
			MsgHandler->CallLuaEnd(L, 1);
		}
	}
}

void AzureMsgHandler_CallDynamicWidgetFunc(UUserWidget* UserWidget, const TMap<FString, float>& InFloatMap, const TMap<FString, FString>& InStringMap)
{
	AzureMsgHandler *MsgHandler = s_AzureMsgHandler;
	if (UserWidget && MsgHandler)
	{
		lua_State_Wrapper L = AAzureEntryPoint::SafeGetL();
		if (MsgHandler->CallLuaBegin(UserWidget->GetMsgTable(), "onDynamicBlueprintEvent", UserWidget, L, false))
		{
			lua_newtable(L);

			for (auto pair : InFloatMap)
			{
				lua_pushstring(L, TCHAR_TO_UTF8(*pair.Key));
				lua_pushnumber(L, pair.Value);
				lua_settable(L, -3);
			}

			for (auto pair : InStringMap)
			{
				lua_pushstring(L, TCHAR_TO_UTF8(*pair.Key));
				lua_pushstring(L, TCHAR_TO_UTF8(*pair.Value));
				lua_settable(L, -3);
			}

			MsgHandler->CallLuaEnd(L, 1);
		}
		else
		{
			UserWidget = Cast<UUserWidget>(UUMGCustomStatics::GetTopmostUserWidget(UserWidget));
			AzureMsgHandler_CallDynamicWidgetFunc(UserWidget, InFloatMap, InStringMap);
		}
	}
}

int AzureMsgHandler::OnFocusChange(int luafuncs, class  UWidget * widget, bool bFocus)
{
	lua_State_Wrapper L = AAzureEntryPoint::SafeGetL();
	if (bFocus)
	{
		if (CallLuaBegin(luafuncs, "onEditBoxFocusReceive", widget, L, true))
		{
			CallLuaEnd(L, 0);
		}
	}
	else
	{
		if (CallLuaBegin(luafuncs, "onEditBoxFocusLost", widget, L, true))
		{
			CallLuaEnd(L, 0);
		}
	}
	return 1;
}