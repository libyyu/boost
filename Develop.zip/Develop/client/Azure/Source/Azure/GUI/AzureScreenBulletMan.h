#pragma once

#include "CoreMinimal.h"
#include "SlateFontInfo.h"
#include "AzureHTMLTextBlock.h"

class UUserWidget;
//class UAzureHTMLTextBlock;

class AzureScreenBulletMan
{
public:

	enum
	{
		HORIZONTAL_TRACK_NUM = 11,

		HORIZONTAL_UP_TRACK = 3,
		HORIZONTAL_MID_TRACK = 5,
		HORIZONTAL_DOWN_TRACK = HORIZONTAL_TRACK_NUM - HORIZONTAL_MID_TRACK - HORIZONTAL_UP_TRACK,

		MIDDLE_TRACK_NUM = 8,
	};

	enum BULLET_TYPE
	{
		RIGHT_TO_LEFT = 1,
		MIDDLE = 2,
	};

	enum TRACK_TYPE
	{
		MIDDLE_TRACK = 0,

		HORIZONTAL_UP = 1,
		HORIZONTAL_MID = 2,
		HORIZONTAL_DOWN = 3,
	};

	struct BulletTrack
	{
		FVector2D startPos;
		double validSecond = 0;
		TRACK_TYPE track_type;
	};

	struct Entry
	{
		float passTime = 0;
		FVector2D startpos;
		TWeakObjectPtr<UAzureHTMLTextBlock> label;

		float liftTime = 0;
		FVector2D moveSpeed;
		Entry() { label = nullptr; }
		void ApplyOffset(float x, float y);
	};

	struct CGBullet
	{
		FText InText;
		float startTime = 0;
		float liftTime = 0;
		int fontSize = 0;
		FVector2D moveSpeed;
		BULLET_TYPE bulletType;
		bool bForceShow = false;
	};

	AzureScreenBulletMan();
	~AzureScreenBulletMan();

	UUserWidget *GetHudUserWidget();

	void AddOneScreenBulletText(FText &InText, int fontSize, BULLET_TYPE bullettype, float lifeTime, FVector2D &velocity, int track_limit, bool bForce);
	void AddOneCGBulletText(FText &InText, int fontSize, BULLET_TYPE bullettype, float lifeTime, FVector2D &velocity,float startTime, bool bForceShow);
	void Update(float dt);
	void SetActive(bool active);
	bool IsActive() { return bActive; }
	void SetCGActive(bool active);
	void SetCGTrackLimit(int limit);
	void StartCG(float interval,float startTime);
	void StopCG(bool bRemoveBullet);
	float GetCGPassTime() { if (bCGPlaying) return CGPassTime; else return 0; }
	FVector2D DecideStartPos(BULLET_TYPE bullettype, float lifeTime, FVector2D &velocity, FVector2D &textSize, int track_limit);
	bool HasValidTrack(BULLET_TYPE bullettype, int track_limit);

private:
	void Init();
	bool bActive = false;
	bool bCGActive = false;
	bool bCGPlaying = false;
	float fInterval = 0;
	float LastBulletTime = 0;
	bool Inited = false;
	float CGPassTime = 0;
	int iCGTrackLimit = 3;

	FSlateFontInfo tempFont;
	TWeakObjectPtr<UUserWidget> sHudUserWidget;
	TArray<Entry *> UnusedEntryArr;
	TArray<Entry *> EntryArr;
	TArray<CGBullet *> CGBulletArr;

	TArray<BulletTrack> HorizontalTracks;
	TArray<BulletTrack> MiddleTracks;
};