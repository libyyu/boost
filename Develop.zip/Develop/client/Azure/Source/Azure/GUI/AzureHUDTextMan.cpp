#include "Azure.h"
#include "AzureHudTextMan.h"
#include "AzureHudText.h"
#include "Components/CanvasPanel.h"
#include "AzureEntryPoint.h"
#include "AzurePateComponent.h"
#include "AzureUtility.h"
#include "GameFramework/Actor.h"
#include "ConstructorHelpers.h"
#include "AzureBMFont.h"
#include "ResourceLoader/AzureResourceLoader.h"

const int HUDTEXTCACHESIZE = 10;

AzureHudTextMan::AzureHudTextMan()
{
	sHudUserWidget = NULL;
	bActive = true;
}


AzureHudTextMan::~AzureHudTextMan()
{
	if (sHudUserWidget.IsValid())
		sHudUserWidget->RemoveFromParent();
	sHudUserWidget = nullptr;
	for (UAzureHudText *hudtext : sHudTextCacheArr)
	{
		delete hudtext;
	}
	sHudTextCacheArr.Empty();

	for (UAzureMultiSegmentsHudText *hudtext : sMultiSegsHudTextCacheArr)
	{
		delete hudtext;
	}
	sMultiSegsHudTextCacheArr.Empty();
	

	for (auto& pair : sMultiSegsMap)
	{
		delete pair.Value;
	}
	sMultiSegsMap.Empty();


	for (auto& pair : sMultiSegTimeLinesMap)
	{
		delete pair.Value;
	}
	sMultiSegTimeLinesMap.Empty();

}

UUserWidget * AzureHudTextMan::GetHudUserWidget()
{
	if (!sHudUserWidget.IsValid())
	{
		UClass * Class = LoadObject<UClass>(0, TEXT("/Game/UI/UMG/HUDRoot.HUDRoot_C"));
		if (Class)
		{
			if (!AAzureEntryPoint::Instance)
				return nullptr;

			UWorld * world = AAzureEntryPoint::Instance->GetWorld();
			sHudUserWidget = ::CreateWidget<UUserWidget>(world, Class);
			sHudUserWidget->Initialize();
			sHudUserWidget->AddToViewport();
		}
	}
	return sHudUserWidget.Get();
}

UAzureHudText * AzureHudTextMan::GetHudTextFromCache()
{
	UAzureHudText* HudText = nullptr;
	UUserWidget *pHud = GetHudUserWidget();
	if (pHud)
	{
		if (sHudTextCacheArr.Num() > 0)
			HudText = sHudTextCacheArr.Pop();
			//HudText->Init(Cast<UCanvasPanel>(pHud->GetRootWidget()));
		else
			HudText = new UAzureHudText();
			//HudText->Init(Cast<UCanvasPanel>(pHud->GetRootWidget()));
	}
	return HudText;
}

void AzureHudTextMan::GiveBackHudText(UAzureHudText *pHudText)
{
	//pHudText->SetActive(false);
	pHudText->Clear();
	if (sHudTextCacheArr.Num() >= HUDTEXTCACHESIZE)
		delete pHudText;
	else
		sHudTextCacheArr.Add(pHudText);
}

void AzureHudTextMan::SetHudText(AActor* obj , FString &InText , const FString &FontName , int fontSize , float lifeTime , FVector2D &InVelocity , float moveTime , float scaleFrom , float scaleFromTime , float scaleTo , float scaleToTime , FVector &InWoffset , FVector2D &InOffset)
{
	if (!obj || FontName.IsEmpty() || !bActive)
		return;
	UAzurePateComponent* comp = Cast<UAzurePateComponent>(obj->GetComponentByClass(UAzurePateComponent::StaticClass()));
	if (comp == nullptr)
	{
		comp = NewObject<UAzurePateComponent>(obj , TEXT("ObjectPate"));
		if (!AzureUtility::AddActorComponent(obj , comp))
		{
			return;
		}
	}
	TWeakObjectPtr<UAzurePateComponent> pWeakComp = comp;
	AsyncLoadBMFont(FontName, [=](UAzureBMFont* Font)
	{
		if (Font && pWeakComp.IsValid())
		{
			FString Text = InText;
			FVector2D velocity = InVelocity;
			FVector Woffset = InWoffset;
			FVector2D offset = InOffset;
			pWeakComp->SetHudTextString(Text , Font , fontSize , lifeTime , velocity , moveTime , scaleFrom , scaleFromTime , scaleTo , scaleToTime , Woffset , offset);
		}
	});
}


UAzureMultiSegmentsHudText * AzureHudTextMan::GetMultiSegsHudTextFromCache()
{
	UAzureMultiSegmentsHudText* HudText = nullptr;
	UUserWidget *pHud = GetHudUserWidget();
	if (pHud)
	{
		if (sMultiSegsHudTextCacheArr.Num() > 0)
			HudText = sMultiSegsHudTextCacheArr.Pop();
		else
			HudText = new UAzureMultiSegmentsHudText();
	}
	return HudText;
}

void AzureHudTextMan::GiveBackMultiSegsHudText(UAzureMultiSegmentsHudText *pHudText)
{
	pHudText->Clear();
	if (sMultiSegsHudTextCacheArr.Num() >= HUDTEXTCACHESIZE)
		delete pHudText;
	else
		sMultiSegsHudTextCacheArr.Add(pHudText);
}

void AzureHudTextMan::SetMultiSegmentsHudText(AActor* obj, FString &InText, FString &type, const FString &FontName, int fontSize, float scale, float alpha, FVector2D &InVelocity, FVector &InWoffset, FVector2D &InOffset)
{
	if (!obj || FontName.IsEmpty() || !bActive)
		return;
	UAzurePateComponent* comp = Cast<UAzurePateComponent>(obj->GetComponentByClass(UAzurePateComponent::StaticClass()));
	if (comp == nullptr)
	{
		comp = NewObject<UAzurePateComponent>(obj, TEXT("ObjectPate"));
		if (!AzureUtility::AddActorComponent(obj, comp))
		{
			return;
		}
	}
	TWeakObjectPtr<UAzurePateComponent> pWeakComp = comp;
	AsyncLoadBMFont(FontName, [=](UAzureBMFont* Font)
	{
		if (Font && pWeakComp.IsValid())
		{
			UAzureMultiSegments **ppMultiSegs = sMultiSegsMap.Find(type);
			if (ppMultiSegs)
			{
				FString Text = InText;
				FVector2D velocity = InVelocity;
				FVector Woffset = InWoffset;
				FVector2D offset = InOffset;
				pWeakComp->SetMultiSegsHudTextString(Text, Font, fontSize, scale, alpha, velocity, *ppMultiSegs, Woffset, offset);
			}
		}
	});
}

UAzureMultiSegmentKeysHudText * AzureHudTextMan::GetMultiSegKeysHudTextFromCache()
{
	UAzureMultiSegmentKeysHudText* HudText = nullptr;
	UUserWidget *pHud = GetHudUserWidget();
	if (pHud)
	{
		if (sMultiSegKeysHudTextCacheArr.Num() > 0)
			HudText = sMultiSegKeysHudTextCacheArr.Pop();
		else
			HudText = new UAzureMultiSegmentKeysHudText();
	}
	return HudText;
}

void AzureHudTextMan::GiveBackMultiSegKeysHudText(UAzureMultiSegmentKeysHudText *pHudText)
{
	pHudText->Clear();
	if (sMultiSegKeysHudTextCacheArr.Num() >= HUDTEXTCACHESIZE)
		delete pHudText;
	else
		sMultiSegKeysHudTextCacheArr.Add(pHudText);
}

void AzureHudTextMan::SetMultiSegmentKeysHudText(AActor* obj , const FString &InText , const FString &type , const FString &FontName , int fontSize , float inital_scale , float inital_alpha , const FVector &Woffset , const FVector2D &offset, int32 txt_ZOrder, int32 effect_ZOrder)
{
	if (!obj || FontName.IsEmpty() || !bActive)
		return;
	UAzurePateComponent* comp = Cast<UAzurePateComponent>(obj->GetComponentByClass(UAzurePateComponent::StaticClass()));
	if (comp == nullptr)
	{
		comp = NewObject<UAzurePateComponent>(obj , TEXT("ObjectPate"));
		if (!AzureUtility::AddActorComponent(obj , comp))
		{
			return;
		}
	}

	TWeakObjectPtr<UAzurePateComponent> pWeakComp = comp;
	AsyncLoadBMFont(FontName, [=](UAzureBMFont* Font)
	{
		if (Font && pWeakComp.IsValid())
		{
			UAzureMultiSegmentTimeLine **ppMultiSegTimeLine = sMultiSegTimeLinesMap.Find(type);
			if (ppMultiSegTimeLine)
			{
				pWeakComp->SetMultiSegKeysHudTextString(InText , Font , fontSize , inital_scale , inital_alpha , *ppMultiSegTimeLine , Woffset , offset, txt_ZOrder , effect_ZOrder);
			}
		}
	});
}

void AzureHudTextMan::SetMultiSegmentKeysHudTextWorldPos(AActor* obj , FString &InText , FString &type , const FString &FontName , int fontSize , float inital_scale , float inital_alpha , const FVector &WorldPos , const FVector2D &offset, int32 txt_ZOrder, int32 effect_ZOrder)
{
	if (!obj || FontName.IsEmpty() || !bActive)
		return;
	UAzurePateComponent* comp = Cast<UAzurePateComponent>(obj->GetComponentByClass(UAzurePateComponent::StaticClass()));
	if (comp == nullptr)
	{
		comp = NewObject<UAzurePateComponent>(obj , TEXT("ObjectPate"));
		if (!AzureUtility::AddActorComponent(obj , comp))
		{
			return;
		}
	}
	TWeakObjectPtr<UAzurePateComponent> pWeakComp = comp;
	AsyncLoadBMFont(FontName, [=](UAzureBMFont* Font)
	{
		if (Font && pWeakComp.IsValid())
		{
			UAzureMultiSegmentTimeLine **ppMultiSegTimeLine = sMultiSegTimeLinesMap.Find(type);
			if (ppMultiSegTimeLine)
			{
				FString Text = InText;
				pWeakComp->SetMultiSegKeysHudTextStringWorldPos(Text , Font , fontSize , inital_scale , inital_alpha , *ppMultiSegTimeLine , WorldPos , offset, txt_ZOrder, effect_ZOrder);
			}
		}
	});
}


void AzureHudTextMan::AsyncLoadBMFont(FString const &fontName, AsyncLoadBMFontCallbackFuncType && onLoad)
{
	UAzureBMFont **ppExistFont = sFontMap.Find(fontName);
	if (ppExistFont)
	{
		onLoad(*ppExistFont);
		return;
	}
	AzureResourceLoader::Get().LoadGameResAsync(fontName, [onLoad=std::move(onLoad), fontName, this](const TArray<UObject*>& res)
	{
		for (UObject* obj : res)
		{
			if (UAzureBMFont* pNewFont = Cast<UAzureBMFont>(obj))
			{
				sFontMap.Add(fontName, pNewFont);
				onLoad(pNewFont);
				return;
			}
		}
		UE_LOG(LogAzure, Error, TEXT("lua:%s: %s"), TEXT("Load BMFont Failed!! Font"), *fontName);
		onLoad(nullptr);
	});
}

bool AzureHudTextMan::AddTextSegments(FString &type , UAzureMultiSegments *seg)
{
	UAzureMultiSegments **ppMultiSegs = sMultiSegsMap.Find(type);
	if (ppMultiSegs)
		return false;
	sMultiSegsMap.Add(type , seg);
	return true;
}

bool AzureHudTextMan::AddTextSegmentTimeLine(FString &type , UAzureMultiSegmentTimeLine *timeLine)
{
	UAzureMultiSegmentTimeLine **ppMultiSegKeys = sMultiSegTimeLinesMap.Find(type);
	if (ppMultiSegKeys)
		return false;
	sMultiSegTimeLinesMap.Add(type , timeLine);
	return true;
}

void AzureHudTextMan::SetActive(bool active)
{
	bActive = active;
	UUserWidget *pHud = sHudUserWidget.Get();
	if (pHud)
		pHud->SetVisibility(active ? ESlateVisibility::SelfHitTestInvisible : ESlateVisibility::Collapsed);
}

void AzureHudTextMan::AddReferencedObjects(FReferenceCollector& Collector)
{
	for (auto& pair : sFontMap)
	{
		Collector.AddReferencedObject(pair.Value);
	}
}
