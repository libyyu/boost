#include "IPlatformAFileWrapper.h"
#include "Azure.h"
#include "AFI.h"
#include "AFileWrapper.h"
#include "HAL/PlatformFilemanager.h"
#include "ScopedPointer.h"
#include "HAL/PlatformTime.h"
#include "Misc/ScopeLock.h"
#include "StreamingAssetHelper.h"
#include "ACSWrapper.h"
#include "Misc/CommandLine.h"
#include "wLua/LuaInterface.h"

#include "AzureHelpFunc.h"
#include "Patcher/patcher.h"
#include "XmlFile.h"

#ifdef _LUA_JIT
#include "AzureLuaJIT.h"
#endif

#if PLATFORM_ANDROID
#include "Android/AndroidJNI.h"
#include "AndroidApplication.h"
#include "Android/AssetFILEWrapper.h"
#include "Android/AndroidFile.h"

#if ENABLE_AAB
#include "GooglePADFunctionLibrary.h"
#endif

extern "C" void AssetFILEWrapper_setupApk(const char* ApkPath);
extern "C" void AssetFILEWrapper_setupObb(const char* ObbPath);
extern "C" void AssetFILEWrapper_setupAAB(int useAABFlag, void* getAssetPackInfoFunc, const std::vector<std::string>& assetPackNames, const std::map<std::string, size_t>& pckToAssetPack);

extern jclass GPlayerActivityClass;
extern jobject GPlayerActivityObject;

extern FString GOBBFilePathBase;
extern FString GPackageName;
extern int32 GAndroidPackageVersion;

int32 GetMainOBBVersion()
{
	int32 version = GAndroidPackageVersion;
	if (JNIEnv* Env = FAndroidApplication::GetJavaEnv())
	{
		FString className = GPackageName;
		className = className.Replace(TEXT("."), TEXT("/"));
		className += TEXT("/OBBData");
		jclass OBBDataClass = FAndroidApplication::FindJavaClass(TCHAR_TO_UTF8(*className));
		jmethodID GetMainOBBVersionMethod = FJavaWrapper::FindStaticMethod(Env, OBBDataClass, "getMainOBBVersion", "()I", false);
		version = FJavaWrapper::CallStaticIntMethod(Env, OBBDataClass, GetMainOBBVersionMethod);
		UE_LOG(LogAzure, Warning, TEXT("MainOBBVersion=%d"), version);
	}
	return version;
}

int32 GetPatchOBBVersion()
{
	int32 version = GAndroidPackageVersion;
	if (JNIEnv* Env = FAndroidApplication::GetJavaEnv())
	{
		FString className = GPackageName;
		className = className.Replace(TEXT("."), TEXT("/"));
		className += TEXT("/OBBData");
		jclass OBBDataClass = FAndroidApplication::FindJavaClass(TCHAR_TO_UTF8(*className));
		jmethodID GetPatchOBBVersionMethod = FJavaWrapper::FindStaticMethod(Env, OBBDataClass, "getPatchOBBVersion", "()I", false);
		version = FJavaWrapper::CallStaticIntMethod(Env, OBBDataClass, GetPatchOBBVersionMethod);
		UE_LOG(LogAzure, Warning, TEXT("PatchOBBVersion=%d"), version);
	}
	return version;
}

int32 GetAssetPackInfo(const char* assetPackName, char* assetPackPath, int* storageMethod)
{
#if ENABLE_AAB
	int32 location = -1;
	FString strAssetPackName = UTF8_TO_TCHAR(assetPackName);
	EGooglePADErrorCode errorCode = UGooglePADFunctionLibrary::GetAssetPackLocation(strAssetPackName, location);
	if (errorCode != EGooglePADErrorCode::AssetPack_NO_ERROR)
	{
		UE_LOG(LogAzure, Warning, TEXT("GetAssetPackLocation failed, assetPackName=%s"), *strAssetPackName);
		return -1;
	}

	EGooglePADStorageMethod method = UGooglePADFunctionLibrary::GetStorageMethod(location);
	if (method == EGooglePADStorageMethod::AssetPack_STORAGE_FILES)
	{
		FString strAssetPackPath = UGooglePADFunctionLibrary::GetAssetsPath(location);
		if (strAssetPackPath.IsEmpty())
		{
			UE_LOG(LogAzure, Warning, TEXT("GetAssetsPath failed, assetPackName=%s, location=%d, method=0"), *strAssetPackName, location);

			UGooglePADFunctionLibrary::ReleaseAssetPackLocation(location);
			return -1;
		}

		UE_LOG(LogAzure, Log, TEXT("GetAssetsPath success, assetPackName=%s, location=%d, method=0, AssetPackPath=%s"), *strAssetPackName, location, *strAssetPackPath);

		strcpy(assetPackPath, TCHAR_TO_UTF8(*strAssetPackPath));
		*storageMethod = 0;
	}
	else if (method == EGooglePADStorageMethod::AssetPack_STORAGE_APK)
	{
		*storageMethod = 1;
	}
	else
	{
		UE_LOG(LogAzure, Warning, TEXT("GetStorageMethod failed, assetPackName=%s, location=%d"), *strAssetPackName, location);

		UGooglePADFunctionLibrary::ReleaseAssetPackLocation(location);
		return -1;
	}

	UE_LOG(LogAzure, Log, TEXT("GetAssetPackInfo success, assetPackName=%s, location=%d, method=%d, AssetPackPath=%s"), *strAssetPackName, location, *storageMethod, UTF8_TO_TCHAR(assetPackPath));

	UGooglePADFunctionLibrary::ReleaseAssetPackLocation(location);

	return 0;
#else
	return -1;
#endif // ENABLE_AAB
}

#endif

DEFINE_LOG_CATEGORY(LogIPlatformAFileWrapper);

FAFileWrapperHandle::FAFileWrapperHandle(AFileWrapper* _FileWrapper, FPlatformAFileWrapper* _Manager, bool _IsCompressed, bool _IsSepFile, int64 _FileOffset, int64 _StreamLen, ASysThreadMutex* _PackageLocker)
	: FileWrapper(_FileWrapper), PackageLocker(_PackageLocker), Manager(_Manager), IsCompressed(_IsCompressed), IsSepFile(_IsSepFile), FileOffset(_FileOffset), StreamLen(_StreamLen), CurPos(0)
{
	FPlatformAtomics::InterlockedIncrement(&_Manager->mOuterRefCount);
}

FAFileWrapperHandle::~FAFileWrapperHandle()
{
	if (!PackageLocker)
		delete FileWrapper;

	FPlatformAtomics::InterlockedDecrement(&Manager->mOuterRefCount);
}

int64 FAFileWrapperHandle::Tell()
{
	return CurPos;
}

bool FAFileWrapperHandle::Seek(int64 NewPosition)
{
	if (NewPosition > StreamLen || NewPosition < 0)
	{
		return false;
	}

	CurPos = NewPosition;
	return true;
}

bool FAFileWrapperHandle::SeekFromEnd(int64 NewPositionRelativeToEnd)
{
	check(NewPositionRelativeToEnd <= 0);
	return Seek(StreamLen + NewPositionRelativeToEnd);
}

bool FAFileWrapperHandle::Read(uint8* Destination, int64 BytesToRead)
{
	if (CurPos + BytesToRead > StreamLen)
		return false;

	int64 seek_pos = CurPos + FileOffset;
	CurPos += BytesToRead;
	ACSWrapper csa(PackageLocker);
	FileWrapper->fseek_wrapper((long)seek_pos, SEEK_SET);
	FileWrapper->fread_wrapper((void*)Destination, BytesToRead, 1);
	return true;
}

bool FAFileWrapperHandle::Write(const uint8* Source, int64 BytesToWrite)
{
	return false;
}

FALZ4FileWrapperHandle::FALZ4FileWrapperHandle(ALZ4File* InLZ4File, FString&& InFileName, FPlatformAFileWrapper* InManager, FCriticalSection* InCS)
{
	FPlatformAtomics::InterlockedIncrement(&InManager->mOuterRefCount);
	mLZ4File = InLZ4File;
	mPosition = 0;
	mSize = InLZ4File->GetUncompressedSize();
	mManager = InManager;
	mCS = InCS;
	mFileName = std::move(InFileName);
}

FALZ4FileWrapperHandle::~FALZ4FileWrapperHandle()
{
	mManager->ReleaseFileStream(mFileName);
	FPlatformAtomics::InterlockedDecrement(&mManager->mOuterRefCount);
}

int64 FALZ4FileWrapperHandle::Tell()
{
	return mPosition;
}

bool FALZ4FileWrapperHandle::Seek(int64 NewPosition)
{
	if (NewPosition < 0 || NewPosition > mSize)
		return false;

	mPosition = (unsigned int)NewPosition;
	return true;
}

bool FALZ4FileWrapperHandle::SeekFromEnd(int64 NewPositionRelativeToEnd)
{
	check(NewPositionRelativeToEnd <= 0);
	int64_t NewPos = (int64_t)mSize + NewPositionRelativeToEnd;
	return Seek(NewPos);
}

bool FALZ4FileWrapperHandle::Read(uint8* Destination, int64 BytesToRead)
{
	mCS->Lock();
	mLZ4File->Seek((long)mPosition);
	bool ret = mLZ4File->Read(Destination, (unsigned int)(int)BytesToRead);
	if (ret)
		mPosition += (unsigned int)(int)BytesToRead;
	mCS->Unlock();
	return ret;
}

bool FALZ4FileWrapperHandle::Write(const uint8* Source, int64 BytesToWrite)
{
	return false;
}

// static member
astring FPlatformAFileWrapper::PckDebugDir = "";
astring FPlatformAFileWrapper::AssetsPath = "";
astring FPlatformAFileWrapper::BackupAssetsPath = "";
#if PLATFORM_IOS
astring FPlatformAFileWrapper::CachePath = "";
#endif
#if PLATFORM_WINDOWS
	bool FPlatformAFileWrapper::SepFile = true;
#else
	bool FPlatformAFileWrapper::SepFile = false;
#endif

FString FPlatformAFileWrapper::Language = TEXT("");
FString FPlatformAFileWrapper::BuiltInLanguage = TEXT("");

FPlatformAFileWrapper* GPlatformAFileWrapper = nullptr;

static FDateTime sPckDateTime(2016, 1, 1);

class FPlatformAFileWrapperCustomInit
{
public:
	FPlatformAFileWrapper* WrapperFile;
	FPlatformAFileWrapperCustomInit();

	static void AFileWrapperCustomInit();
};

static FPlatformAFileWrapperCustomInit FPlatformAFileWrapperCustomInitInst;
extern void a_ConfigEngine();

void* AzureMalloc(size_t size)
{
	check(0);
	return FMemory::Malloc(size);
}

void* AzureRealloc(void* Ptr, size_t size)
{
	return FMemory::Realloc(Ptr, size);
}

void AzureFree(void* Ptr)
{
	FMemory::Free(Ptr);
}

void OnFileSystemFinalExit()
{
	af_CloseAllFilePackages();
}
FPlatformAFileWrapperCustomInit::FPlatformAFileWrapperCustomInit() : WrapperFile(NULL)
{
#if PLATFORM_WINDOWS && defined(_LUA_JIT)
#if defined(AZURE_UE_TARGET_DEBUG) || defined(AZURE_UE_TARGET_DEBUGGAME)
	const bool debug = true;
#else
	const bool debug = false;
#endif
	InitLoadLuaJITDll(debug);
#endif

#if defined(_LUA_JIT)
	
#else
	exp_init_azure_memory_function((void*)AzureMalloc, (void*)AzureRealloc, (void*)AzureFree);
#endif
	exp_set_run_in_editor(GIsEditor);
	AFile::SetSkipCheckFOURC();

	if (!GIsEditor)
		FPlatformFileManager::Get().SetUserCustomInitFunc(AFileWrapperCustomInit);

	FPlatformFileManager::Get().AzureSetOnFileSystemFinalExitFunc(OnFileSystemFinalExit);
}

extern void AzureLog(AzureLogType logType, const char* log);
extern void AzureException(const char* log);

#if PLATFORM_ANDROID && USE_ANDROID_FILE
class FAzureAndroidPartialFileCustomSource : public IAndroidPartialFileCustomSource
{
public:
	virtual bool GetFileInfo(const TCHAR* Filename, int64* OutFileOffset, int64* OutFileSize, FString* OutFileRootPath) override
	{
		if (!GPlatformAFileWrapper || !GPlatformAFileWrapper->HasInit())
			return false;

		FString StandardFilename(Filename);
		FPaths::MakeStandardFilename(StandardFilename);

		FString RelativeFilename;
		bool isGameFile = GPlatformAFileWrapper->GetRelativeFilenameToMountPoint(StandardFilename, RelativeFilename);

		bool isEngineFile;
		if (isGameFile)
			isEngineFile = false;
		else
			isEngineFile = GPlatformAFileWrapper->GetRelativeFilenameToEnginePoint(StandardFilename, RelativeFilename);

		if (isGameFile || isEngineFile)
		{
			char realFilePath[1024];
			a_int64 fileOffset;
			a_int64 fileSize;
			a_int64 compressedLen;
			bool isCompressed;
			bool isSepFile;
			bool bExists = af_GetFileInfoInRealPckFile(TCHAR_TO_UTF8(*RelativeFilename), realFilePath, sizeof(realFilePath), &fileOffset, &fileSize, &compressedLen, &isCompressed, &isSepFile);
			if (!bExists || isCompressed)
				return false;

			if (OutFileOffset)
				*OutFileOffset = fileOffset;
			if (OutFileSize)
				*OutFileSize = fileSize;
			if (OutFileRootPath)
				*OutFileRootPath = UTF8_TO_TCHAR(realFilePath);
			return true;
		}
		else
		{
			return false;
		}
	}
};
#endif


#if PLATFORM_IOS
extern AVFMEDIA_API bool(*GIOSMediaIOReadCB)(const char * url,uint8* data, long long offset, long long count,long long * contentLength);

bool GIOSMediaIOReadCFunc(const char * url,uint8 * data, long long offset, long long count,long long* contentLength)
{
	IFileHandle * file = GPlatformAFileWrapper->OpenRead(UTF8_TO_TCHAR(url));
	if (!file)
		return false;
    if(contentLength)
        *contentLength = (long long)(file->Size());
    file->Seek(offset);
	bool ret = file->Read(data, count);
    delete file;
    return ret;
}

#endif

void FPlatformAFileWrapperCustomInit::AFileWrapperCustomInit()
{
	static TUniquePtr<FPlatformAFileWrapper> AutoDestroySingleton(new FPlatformAFileWrapper());
	FPlatformAFileWrapper* WrapperFile = AutoDestroySingleton.Get();
	FPlatformAFileWrapperCustomInitInst.WrapperFile = WrapperFile;
	IPlatformFile& CurPlatformFile = FPlatformFileManager::Get().GetPlatformFile();
	WrapperFile->PreInit(&CurPlatformFile);
	GPlatformAFileWrapper = WrapperFile;


#if defined(_LUA_JIT)

#else
	exp_init_azure_memory_function((void*)AzureMalloc, (void*)AzureRealloc, (void*)AzureFree);
#endif


	if (!GIsEditor)
	{
		FPlatformFileManager::Get().SetPlatformFile(*WrapperFile);

		//Init Log to AzureMobile
		exp_init_AzureLog((void*)AzureLog);
		exp_init_AzureException((void*)AzureException);
	}

	WrapperFile->Initialize(WrapperFile->GetLowerLevel(), TEXT(""));

	if (!GIsEditor)
	{
		extern void a_InitConfigEngine();
		a_InitConfigEngine();
		a_ConfigEngine();
	}

#if PLATFORM_ANDROID && USE_ANDROID_FILE
	static FAzureAndroidPartialFileCustomSource androidPartialFileCustomSource;
	IAndroidPartialFile::GetPlatformPhysical().SetCustomSource(&androidPartialFileCustomSource);
#endif

#if PLATFORM_IOS
	GIOSMediaIOReadCB = GIOSMediaIOReadCFunc;
#endif

}

FPlatformAFileWrapper::FPlatformAFileWrapper()
	: LowerLevel(nullptr)
{

}

FPlatformAFileWrapper::~FPlatformAFileWrapper()
{
	mFileStreamLocker.Lock();
	check(mOuterRefCount == 0);
	check(mActiveFileStreams.Num() == 0);

	for (auto& Entry : mActiveFileStreams)
	{
		delete Entry.Value.Stream;
	}

	mFileStreamLocker.Unlock();
	InnerClosePackageFileHandle();
#if PLATFORM_IOS
	GIOSMediaIOReadCB = nullptr;
#endif

}

void FPlatformAFileWrapper::ReleaseFileStream(const FString& InFileName)
{
	FScopeLock SL(&mFileStreamLocker);
	auto pActiveEntry = mActiveFileStreams.Find(InFileName);

	if (pActiveEntry)
	{
		if (--pActiveEntry->RefCount <= 0)
		{
			mActiveFileStreams.Remove(InFileName);
			delete pActiveEntry->Stream;
		}
	}
}

void FPlatformAFileWrapper::InnerClosePackageFileHandle()
{
	mPackageFileHandleLocker.Lock();

	for (auto& it : PackageFileHandleMap)
	{
		delete it.second.FileWrapper;
		delete it.second.FileLocker;
	}

	PackageFileHandleMap.clear();
	mPackageFileHandleLocker.Unlock();
}

bool FPlatformAFileWrapper::CheckClosePackageFileHandle()
{
	if (mOuterRefCount > 0)
		return false;

	mFileStreamLocker.Lock();

	if (mActiveFileStreams.Num() > 0)
	{
		mFileStreamLocker.Unlock();
		return false;
	}

	mFileStreamLocker.Unlock();
	InnerClosePackageFileHandle();
	return true;
}

bool FPlatformAFileWrapper::Init()
{
	if (GIsEditor)
		FPlatformAFileWrapperCustomInit::AFileWrapperCustomInit();

	return true;
}

const FString& FPlatformAFileWrapper::GetResBaseFullPath()
{
#if PLATFORM_ANDROID
	static FString _fullpath;
	if (_fullpath.IsEmpty())
	{
		int useAABFlag = ShouldLoadAABPackages();
		if(useAABFlag == 1)
		{
			_fullpath = FString("aab://") / GetResBaseRelativePath();
		}
		else
		{
			int useObbFlag = ShouldLoadObbPackage();
			if (useObbFlag == 2)
				_fullpath = FString("obb://") / GetResBaseRelativePath();
			else
				_fullpath = StreamingAssetHelper::MakePath(GetResBaseRelativePath());
		}
	}
#else
	static FString _fullpath = StreamingAssetHelper::MakePath(GetResBaseRelativePath());
#endif

	return _fullpath;
}

void FPlatformAFileWrapper::SetupPaths()
{
	{
#if PLATFORM_WINDOWS
		FString path = FPaths::ProjectDir() / TEXT("Output");
#elif PLATFORM_IOS
		//FString path = FString([NSSearchPathForDirectoriesInDomains(NSCachesDirectory, NSUserDomainMask, YES) objectAtIndex:0]);
		NSString * nsPath = [NSSearchPathForDirectoriesInDomains(NSApplicationSupportDirectory, NSUserDomainMask, YES) objectAtIndex:0];
		NSFileManager * manager = [NSFileManager defaultManager];
		if (![manager fileExistsAtPath : nsPath])
		{
			NSError * error;
			BOOL ret = [manager createDirectoryAtPath : nsPath  withIntermediateDirectories : NO attributes : nil error : &error];
			if (!ret)
			{
				NSLog(@"Faile to create AppSupport dir: %@",error);
				exit(0);
			}
		}
		NSURL * URL = [NSURL fileURLWithPath: nsPath];
        NSError *error = nil;
        BOOL success = [URL setResourceValue: [NSNumber numberWithBool: YES]
                                      forKey: NSURLIsExcludedFromBackupKey error: &error];
        if(!success){
            NSLog(@"Faile to set nobackup attribute for AppSupport dir");
        }
        
        ////test begin
        //NSNumber * value = [NSNumber numberWithBool: NO];
        //NSLog(@" xxx1   %@  ", value);
        //NSString * testfile = [nsPath stringByAppendingString:  @"/package/lua.png"];
        //NSLog(@"test file:%@",testfile);
        //NSURL * url2 = [NSURL fileURLWithPath: testfile];
        //success = [url2 getResourceValue : &value forKey: NSURLIsExcludedFromBackupKey error: &error];
        //if(!success)
        //{
        //    NSLog(@"F111 dir: %@",error);
        //}
        //NSLog(@" xxx   %@   success:%@", value, success ? @"succ" : @"failed");
        ////test end

		FString path = FString(nsPath);

#else
		FString path = FPaths::ProjectPersistentDownloadDir();
#endif
		FPaths::MakeStandardFilename(path);
		path.RemoveFromEnd(FString(TEXT("/")), ESearchCase::CaseSensitive);
		AssetsPath = TCHAR_TO_UTF8(*path);
	}

	{
#if PLATFORM_ANDROID
		JNIEnv* env = FAndroidApplication::GetJavaEnv();
		jclass localGameActivityClass = FJavaWrapper::GameActivityClassID;
		jmethodID method =
			env->GetMethodID(localGameActivityClass, "getPackageResourcePath", "()Ljava/lang/String;");
		jstring jdataPath = (jstring)env->CallObjectMethod(FJavaWrapper::GameActivityThis, method);
		const char* dataPathstr = env->GetStringUTFChars(jdataPath, 0);
		astring dataPath = dataPathstr;
		env->ReleaseStringUTFChars(jdataPath, dataPathstr);
		UE_LOG(LogAzure, Warning, TEXT("ApkPath: %s"), ANSI_TO_TCHAR(dataPath.c_str()));
		AssetFILEWrapper_setupApk(dataPath.c_str());
		StreamingAssetHelper::SetStreamingAssetsPath(TEXT("assets://"));
#else

#if PLATFORM_IOS
		FString path = FString([[NSBundle mainBundle] bundlePath]) / TEXT("StreamingAssets");
#else
		FString path = FPaths::ProjectDir() / TEXT("StreamingAssets/win");
#endif

		FPaths::MakeStandardFilename(path);
		StreamingAssetHelper::SetStreamingAssetsPath(*path);
#endif
	}

	{
		FString path = GetResBaseFullPath();
#if !PLATFORM_ANDROID
		FPaths::MakeStandardFilename(path);
#endif
		path.RemoveFromEnd(FString(TEXT("/")), ESearchCase::CaseSensitive);
		BackupAssetsPath = TCHAR_TO_UTF8(*path);
	}

#if PLATFORM_IOS
	{
		// Use app's sandbox Documents subdirectory so that we can copy pck directory to iPhone via iTunes
		FString DocumentPath = [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) firstObject];
		FPaths::MakeStandardFilename(DocumentPath);
		PckDebugDir = TCHAR_TO_UTF8(*DocumentPath);
		PckDebugDir += "/pck";
	}
	{
		FString path = FString([NSSearchPathForDirectoriesInDomains(NSCachesDirectory, NSUserDomainMask, YES) objectAtIndex:0]);
		CachePath = TCHAR_TO_UTF8(*path);
	}
#else
	PckDebugDir = AssetsPath + "/pck";

#if PLATFORM_WINDOWS
	if (!GIsEditor)
	{
		FString param;
		FParse::Value(FCommandLine::Get(), TEXT("--pck="), param);
		if (!param.IsEmpty() && FPaths::DirectoryExists(param))
		{
			param.RemoveFromEnd(FString(TEXT("/")), ESearchCase::CaseSensitive);
			PckDebugDir = TCHAR_TO_UTF8(*param);
		}
	}
#endif

#endif
}

bool FPlatformAFileWrapper::Initialize(IPlatformFile* Inner, const TCHAR* CmdLine)
{
	if (IsInit)
		return true;

	// Inner is required.
	check(Inner != nullptr);

	if (Inner == this)
		return true;

	LowerLevel = Inner;

	MountPoint = FPaths::ProjectContentDir();
	FPaths::MakeStandardFilename(MountPoint);
	MountPointPathLen = MountPoint.Len();
	MoviesPoint = TEXT("Movies/");
	EntryPoint = TEXT("EntryPoint/");
	EnginePoint = FPaths::EngineDir();
	FPaths::MakeStandardFilename(EnginePoint);
	// EngineConfigPoint using /Azure/Config dir
	EngineConfigPoint = FPaths::ProjectConfigDir();
	FPaths::MakeStandardFilename(EngineConfigPoint);
	ProjectDir = FPaths::ProjectDir();
	FPaths::MakeStandardFilename(ProjectDir);

	SetupPaths();

	static const char* g_szPckDir[][2] = // --> Lua/pckdir.lua
	{
		{ "automove",	"package/automove.png" },
		{ "configs",	"package/configs.png" },
		{ "data",		"package/data.png" },
		{ "effects",	"package/effects.png" },
		{ "lua",		"package/lua.png" },
		{ "maps",		"package/maps.png" },
		{ "buildings",	"package/buildings.png" },
		{ "models",		"package/models.png" },
		{ "miscs",		"package/miscs.png" },
		{ "scenes",		"package/scenes.png" },
		{ "ui",			"package/ui.png" },
		{ "shadercode",	"package/shadercode.png" },
		{ "sound",		"package/sound.png" },
		{ "engine",		"package/engine.png" },
		{ "cinematics",	"package/cinematics.png" },
		{ "localization","package/localization.png" },
	};

#if PLATFORM_ANDROID
	int resOBBPackageLayer = -1;		//OBB for android(Google Play).
	int useObbFlag = ShouldLoadObbPackage();

#if ENABLE_AAB
	int resAABPackageLayer = -1; //AAB for android(Google Play).
	TMap<FString, int32> assetPackInfoMap;
	int useAABFlag = ShouldLoadAABPackages(&assetPackInfoMap);

	if (useAABFlag == 1)
	{
		std::vector<std::string> assetPackNames;
		std::map<std::string, size_t> pckToAssetPack;
		int32 assetPackType = 0; // 0:install-time, 1:fast-follow, 2: on-demand
		int32 index = 0;
		int iLen = sizeof(g_szPckDir) / sizeof(g_szPckDir[0]);
		for (int i = 0; i < iLen; ++i)
		{
			FString AssetPackKey(UTF8_TO_TCHAR(g_szPckDir[i][0]));
			if (assetPackInfoMap.Contains(AssetPackKey))
			{
				continue;
			}

			assetPackType = 0; // 0:install-time, 1:fast-follow, 2: on-demand
			std::string strAssetPackName("asset_");
			strAssetPackName += g_szPckDir[i][0];
			assetPackNames.emplace_back(strAssetPackName);

			std::string strPckPath("res_base/");
			strPckPath += g_szPckDir[i][1];
			pckToAssetPack.insert(std::make_pair(strPckPath, (size_t)((assetPackType << 8) | (index))));

			UE_LOG(LogIPlatformAFileWrapper, Log, TEXT("Pck Info, AssetPackName=%s, assetPackType=%d, index=%d, PckPath=%s."), UTF8_TO_TCHAR(strAssetPackName.c_str()), assetPackType, index, UTF8_TO_TCHAR(strPckPath.c_str()));
			
			++index;
		}

		std::string strPckPartKey("_pk");
		for (auto& Pair : assetPackInfoMap)
		{
			const char* pckName = TCHAR_TO_UTF8(*(Pair.Key));

			std::string strAssetPackName("asset_");
			strAssetPackName += pckName;
			assetPackNames.emplace_back(strAssetPackName);

			assetPackType = Pair.Value;
			if (assetPackType < 0 || assetPackType > 2)
			{
				assetPackType = 0;
			}

			// pckName:buildings_pk1 => strAssetPackName:asset_buildings_pk1, strPckPath：res_base/package/buildings.pk1.png
			std::string strPckPath("res_base/package/");
			strPckPath += pckName;
			std::string::size_type found = strPckPath.rfind(strPckPartKey);
			if (found != std::string::npos)
			{
				strPckPath.replace(found, strPckPartKey.length(), ".pk");
			}
			strPckPath += ".png";
			pckToAssetPack.insert(std::make_pair(strPckPath, (size_t)((assetPackType << 8) | (index))));

			UE_LOG(LogIPlatformAFileWrapper, Log, TEXT("Pck Info, AssetPackName=%s, assetPackType=%d, index=%d, PckPath=%s."), UTF8_TO_TCHAR(strAssetPackName.c_str()), assetPackType, index, UTF8_TO_TCHAR(strPckPath.c_str()));

			++index;
		}

		AssetFILEWrapper_setupAAB(useAABFlag, (void *)GetAssetPackInfo, assetPackNames, pckToAssetPack);
	}
	else // 注意是下面的if
#endif // ENABLE_AAB
	if (useObbFlag == 2) // 注意上面的else
	{
		FString obbDir = GOBBFilePathBase + FString(TEXT("/Android/obb/") + GPackageName);
		FString MainOBBName = FString::Printf(TEXT("main.%d.%s.obb"), GetMainOBBVersion(), *GPackageName);
		astring dataPath = TCHAR_TO_UTF8(*(FPaths::Combine(obbDir, MainOBBName)));

		UE_LOG(LogAzure, Log, TEXT("Main ObbPath: %s"), ANSI_TO_TCHAR(dataPath.c_str()));
		AssetFILEWrapper_setupObb(dataPath.c_str());
	}
#endif // PLATFORM_ANDROID

	af_SetAlgorithmID(161);
	int resourcePackageLayer;
	int resBasePackageLayer;
	{
		int layerIndex = 0;

		int32 config_engine_no_pck = 0;
		FParse::Value(FCommandLine::Get(), UTF8_TO_TCHAR("--config_engine_no_pck="), config_engine_no_pck);

		//layer: pck (debug dir)
		if (!config_engine_no_pck)
		{
			af_InitPackageLayer(layerIndex, PckDebugDir.c_str(), true);
			af_SetReadOnly(layerIndex, true);
			af_SetKeepFullPath(layerIndex, false);
			UE_LOG(LogIPlatformAFileWrapper, Log, TEXT("PckDebugDir: %s"), ANSI_TO_TCHAR(PckDebugDir.c_str()));
		}

		++layerIndex;

		//layer: resource
		resourcePackageLayer = layerIndex;
		af_InitPackageLayer(layerIndex, AssetsPath.c_str(), false/*SepFile*/);
		af_SetReadOnly(layerIndex, true);
		af_SetKeepFullPath(layerIndex, false);
		UE_LOG(LogIPlatformAFileWrapper, Log, TEXT("AssetsPath: %s"), ANSI_TO_TCHAR(AssetsPath.c_str()));

		++layerIndex;

		//layer: res base
		resBasePackageLayer = layerIndex;
		af_InitPackageLayer(layerIndex, BackupAssetsPath.c_str(), false);
		af_SetReadOnly(layerIndex, true);
		af_SetKeepFullPath(layerIndex, false);
		UE_LOG(LogIPlatformAFileWrapper, Log, TEXT("BackupAssetsPath: %s"), ANSI_TO_TCHAR(BackupAssetsPath.c_str()));

		++layerIndex;

#if PLATFORM_ANDROID
		//layer: Obb
		if (useObbFlag != 0)
		{
			FString obbDir = GOBBFilePathBase + FString(TEXT("/Android/obb/") + GPackageName);

			resOBBPackageLayer = layerIndex;
			af_InitPackageLayer(layerIndex, TCHAR_TO_UTF8(*obbDir), false);
			af_SetReadOnly(layerIndex, true);
			af_SetKeepFullPath(layerIndex, false);

			++layerIndex;
		}
#endif

		//layer: non-package files
		af_InitPackageLayer(layerIndex, AssetsPath.c_str(), true);
		af_SetReadOnly(layerIndex, false);
		af_SetKeepFullPath(layerIndex, false);

		++layerIndex;
	}

	{
		int iLen = sizeof(g_szPckDir) / sizeof(g_szPckDir[0]);
		for (int i = 0; i < iLen; ++i)
		{
			const char* strPckFile = g_szPckDir[i][1];
			const char* strFolder = g_szPckDir[i][0];

			if (!af_OpenFilePackage(resBasePackageLayer, strPckFile, strFolder))
			{
				UE_LOG(LogIPlatformAFileWrapper, Log, TEXT("Failed to open backup pck: %s"), ANSI_TO_TCHAR(strPckFile));
			}
		}

		if (ShouldOpenAssetPackages())
		{
			for (int i = 0; i < iLen; ++i)
			{
				const char* strPckFile = g_szPckDir[i][1];
				const char* strFolder = g_szPckDir[i][0];

				if (af_IsSepFileExist((AssetsPath + "/" + strPckFile).c_str()) && !af_OpenFilePackage(resourcePackageLayer, strPckFile, strFolder))
				{
					UE_LOG(LogIPlatformAFileWrapper, Log, TEXT("AssetsPath Failed to open: %s"), ANSI_TO_TCHAR(strPckFile));
				}
			}
		}

#if PLATFORM_ANDROID
		if (useObbFlag != 0)
		{
			FString PatchOBBName = FString::Printf(TEXT("patch.%d.%s.obb"), GetPatchOBBVersion(), *GPackageName);
			if (!af_OpenFilePackage(resOBBPackageLayer, TCHAR_TO_UTF8(*PatchOBBName), ""))
			{
				UE_LOG(LogIPlatformAFileWrapper, Warning, TEXT("OBB Failed to open: %s"), *PatchOBBName);
			}
		}
#endif
	}

	// 初始化内置语言
	BuiltInLanguage = GetBuiltInLanguage();
	Language = BuiltInLanguage;
	UE_LOG(LogIPlatformAFileWrapper, Log, TEXT("current package built-in language: %s"), *BuiltInLanguage);
	

	IsInit = true;
	return true;
}

int FPlatformAFileWrapper::ShouldLoadObbPackage()
{
	FString XmlFilePath = FString(GetResBaseRelativePath()) / TEXT("res_base_version.xml");
	auto XmlFileContent = StreamingAssetHelper::ReadFileText(*XmlFilePath);
	if (XmlFileContent.size() <= 0)
	{
		UE_LOG(LogIPlatformAFileWrapper, Error, TEXT("Content is empty for xml %s."), *XmlFilePath);
		return false;
	}
	char* Start = &XmlFileContent[0];
	if (XmlFileContent.size() >= 3 && (unsigned char)XmlFileContent[0] == 0xef && (unsigned char)XmlFileContent[1] == 0xbb && (unsigned char)XmlFileContent[2] == 0xbf)
	{
		Start = Start + 3;
	}
	FXmlFile XmlFile;
	if (!XmlFile.LoadFile(UTF8_TO_TCHAR(Start), EConstructMethod::ConstructFromBuffer))
	{
		UE_LOG(LogIPlatformAFileWrapper, Error, TEXT("Failed to parse content of xml %s."), *XmlFilePath);
		return false;
	}
	FXmlNode *RootNode = XmlFile.GetRootNode();
	if (!RootNode)
	{
		UE_LOG(LogIPlatformAFileWrapper, Error, TEXT("Failed to get root node for xml %s."), *XmlFilePath);
		return false;
	}
	FString AzurePatchObb = RootNode->GetAttribute(TEXT("azure_patch_obb"));
	if (AzurePatchObb.IsEmpty())
	{
		UE_LOG(LogIPlatformAFileWrapper, Warning, TEXT("No 'azure_patch_obb' attribute in root note for xml %s."), *XmlFilePath);
		return false;
	}
	return FCString::Atoi(*AzurePatchObb);
}

int FPlatformAFileWrapper::ShouldLoadAABPackages(TMap<FString, int32>* AssetPackInfos)
{
#if PLATFORM_ANDROID && ENABLE_AAB
	FString XmlFilePath = FString(GetResBaseRelativePath()) / TEXT("res_base_version.xml");
	auto XmlFileContent = StreamingAssetHelper::ReadFileText(*XmlFilePath);
	if (XmlFileContent.size() <= 0)
	{
		UE_LOG(LogIPlatformAFileWrapper, Error, TEXT("Content is empty for xml %s."), *XmlFilePath);
		return 0;
	}
	char* Start = &XmlFileContent[0];
	if (XmlFileContent.size() >= 3 && (unsigned char)XmlFileContent[0] == 0xef && (unsigned char)XmlFileContent[1] == 0xbb && (unsigned char)XmlFileContent[2] == 0xbf)
	{
		Start = Start + 3;
	}
	FXmlFile XmlFile;
	if (!XmlFile.LoadFile(UTF8_TO_TCHAR(Start), EConstructMethod::ConstructFromBuffer))
	{
		UE_LOG(LogIPlatformAFileWrapper, Error, TEXT("Failed to parse content of xml %s."), *XmlFilePath);
		return 0;
	}
	FXmlNode *RootNode = XmlFile.GetRootNode();
	if (!RootNode)
	{
		UE_LOG(LogIPlatformAFileWrapper, Error, TEXT("Failed to get root node for xml %s."), *XmlFilePath);
		return 0;
	}

	FXmlNode *AzureAssetPackAABNode = RootNode->FindChildNode(FString(TEXT("azure_asset_pack_aab")));
	if (nullptr == AzureAssetPackAABNode)
	{
		UE_LOG(LogIPlatformAFileWrapper, Warning, TEXT("No 'azure_asset_pack_aab' node in root note for xml %s."), *XmlFilePath);
		return 0;
	}

	FString AABFlag = AzureAssetPackAABNode->GetAttribute(TEXT("flag"));
	if (AABFlag.IsEmpty())
	{
		UE_LOG(LogIPlatformAFileWrapper, Warning, TEXT("No 'flag' attribute in 'azure_asset_pack_aab' note for xml %s."), *XmlFilePath);
		return 0;
	}

	if (nullptr != AssetPackInfos)
	{
		const TArray<FXmlNode*>& AzureAssetPackInfoNodes = AzureAssetPackAABNode->GetChildrenNodes();
		const int32 ChildCount = AzureAssetPackInfoNodes.Num();
		for (int32 ChildIndex = 0; ChildIndex < ChildCount; ++ChildIndex)
		{
			FXmlNode* TmpChildNode = AzureAssetPackInfoNodes[ChildIndex];
			if (TmpChildNode == nullptr || TmpChildNode->GetTag() != TEXT("azure_asset_pack_info"))
			{
				continue;
			}

			FString AssetPackName = TmpChildNode->GetAttribute(TEXT("asset_pack_name"));
			FString AssetPackType = TmpChildNode->GetAttribute(TEXT("asset_pack_type"));
			if (AssetPackName.IsEmpty() || AssetPackType.IsEmpty())
			{
				continue;
			}

			int32 iAssetPackType = FCString::Atoi(*AssetPackType); // 0:install-time, 1:fast-follow, 2: on-demand
			AssetPackInfos->Add(AssetPackName, iAssetPackType);

			UE_LOG(LogIPlatformAFileWrapper, Log, TEXT("Asset pack info, AssetPackName=%s, AssetPackType=%d."), *AssetPackName, iAssetPackType);
		}
	}

	//获取main.obb.png的storage method
	{
		// Force Initialize
		UGooglePADFunctionLibrary::Initialize();

		char assetPackPath[1024] = {0};
		int storageMethod = 0;
		if (GetAssetPackInfo("asset_main", assetPackPath, &storageMethod) != 0)
		{
			UE_LOG(LogIPlatformAFileWrapper, Log, TEXT("Get asset pack info failed, AssetPackName=asset_main"));

			return 0;
		}
	}

	return FCString::Atoi(*AABFlag);
#else
	return 0;
#endif // PLATFORM_ANDROID && ENABLE_AAB
}

bool FPlatformAFileWrapper::ShouldOpenAssetPackages()
{
	int ResBaseVersion(-1);
	if (!ReadResBaseVersion(ResBaseVersion))
	{
		UE_LOG(LogIPlatformAFileWrapper, Error, TEXT("Failed to get resource base version."));
		FPlatformMisc::LowLevelOutputDebugStringf(TEXT("Failed to get resource base version."));
		return false;
	}

	int SavedResVersion(-1), SavedResBaseVersion(-1);
	if (!ReadSavedResVersion(SavedResVersion, SavedResBaseVersion))
	{
		UE_LOG(LogIPlatformAFileWrapper, Log, TEXT("Failed to read saved resource version, probably because this is the first time to load."));
		FPlatformMisc::LowLevelOutputDebugStringf(TEXT("Failed to read saved resource version, probably because this is the first time to load."));
		return false;
	}

	if (SavedResBaseVersion != ResBaseVersion)
	{
		UE_LOG(LogIPlatformAFileWrapper, Log, TEXT("Locally saved res_base_version(%d) doesn't match BackupAssets res_base_version(%d), probably because it's a new install, or downloaded assets are reset, and package should/need not be loaded this time."), SavedResBaseVersion, ResBaseVersion);
		FPlatformMisc::LowLevelOutputDebugStringf(TEXT("Locally saved res_base_version(%d) doesn't match BackupAssets res_base_version(%d), probably because it's a new install, or downloaded assets are reset, and package should/need not be loaded this time."), SavedResBaseVersion, ResBaseVersion);
		return false;
	}

	return true;
}

bool FPlatformAFileWrapper::ReadResBaseVersion(int &ResBaseVersion)
{
	FString XmlFilePath = FString(GetResBaseRelativePath()) / TEXT("res_base_version.xml");
	auto XmlFileContent = StreamingAssetHelper::ReadFileText(*XmlFilePath);
	if (XmlFileContent.size() <= 0)
	{
		UE_LOG(LogIPlatformAFileWrapper, Error, TEXT("Content is empty for xml %s."), *XmlFilePath);
		return false;
	}
	char* Start = &XmlFileContent[0];
	if (XmlFileContent.size() >= 3 && (unsigned char)XmlFileContent[0] == 0xef && (unsigned char)XmlFileContent[1] == 0xbb && (unsigned char)XmlFileContent[2] == 0xbf)
	{
		Start = Start + 3;
	}
	FXmlFile XmlFile;
	if (!XmlFile.LoadFile(UTF8_TO_TCHAR(Start), EConstructMethod::ConstructFromBuffer))
	{
		UE_LOG(LogIPlatformAFileWrapper, Error, TEXT("Failed to parse content of xml %s."), *XmlFilePath);
		return false;
	}
	FXmlNode *RootNode = XmlFile.GetRootNode();
	if (!RootNode)
	{
		UE_LOG(LogIPlatformAFileWrapper, Error, TEXT("Failed to get root node for xml %s."), *XmlFilePath);
		return false;
	}
	FString VersionString = RootNode->GetAttribute(TEXT("value"));
	if (VersionString.IsEmpty())
	{
		UE_LOG(LogIPlatformAFileWrapper, Error, TEXT("Failed to get 'value' attribute in root note for xml %s."), *XmlFilePath);
		return false;
	}
	ResBaseVersion = FCString::Atoi(*VersionString);
	return true;
}

bool FPlatformAFileWrapper::ReadSavedResVersion(int& SavedResVersion, int& SavedResBaseVersion)
{
	utf16string DownloadedResourcePath;
	a_UTF8ArrayToUTF16String(AssetsPath.c_str(), AssetsPath.length(), DownloadedResourcePath);
	return PatcherSpace::Patcher::loadLocalVersion(make_wstring(DownloadedResourcePath), SavedResVersion, SavedResBaseVersion);
}

bool FPlatformAFileWrapper::FileExists(const TCHAR* Filename)
{
	if (!IsInit)
	{
		return LowerLevel->FileExists(Filename);
	}

	FString RelativeFilename;
	FString StandardFilename(Filename);
	FPaths::MakeStandardFilename(StandardFilename);

	if (GetRelativeFilenameToMountPoint(StandardFilename, RelativeFilename))
	{
		AutoRefCounter Ref(mOuterRefCount);

		if (mToDisable)
		{
			std::string szFileName = TCHAR_TO_UTF8(Filename);
			std::string szRelativeName = TCHAR_TO_UTF8(*RelativeFilename);
			std::string szStandardName = TCHAR_TO_UTF8(*StandardFilename);
			std::string log = "[0]ToMountPoint FileName:" + szFileName;
			log += ", RelativeName:" + szRelativeName;
			log += ", StandardName:" + szStandardName;
			AzureLog(AzureLogType::Error, log.c_str());
			check(false);
			return false;
		}

		return af_IsFileExist(TCHAR_TO_UTF8(*RelativeFilename));
	}
	else if (GetRelativeFilenameToEnginePoint(StandardFilename, RelativeFilename))
	{
		if (mToDisable)
		{
			std::string szFileName = TCHAR_TO_UTF8(Filename);
			std::string szRelativeName = TCHAR_TO_UTF8(*RelativeFilename);
			std::string szStandardName = TCHAR_TO_UTF8(*StandardFilename);
			std::string log = "[0]ToEnginePoint FileName:" + szFileName;
			log += ", RelativeName:" + szRelativeName;
			log += ", StandardName:" + szStandardName;
			AzureLog(AzureLogType::Error, log.c_str());

			check(false);
			return LowerLevel->FileExists(Filename);
		}

		AutoRefCounter Ref(mOuterRefCount);

		if (af_IsFileExist(TCHAR_TO_UTF8(*RelativeFilename)))
			return true;

		return LowerLevel->FileExists(Filename);
	}
	else
		return LowerLevel->FileExists(Filename);
}

int64 FPlatformAFileWrapper::FileSize(const TCHAR* Filename)
{
	if (!IsInit)
	{
		return LowerLevel->FileSize(Filename);
	}

	const int bufSize = 1024;
	char realPckOrFilePath[bufSize];
	int64 outFileOffset;
	int64 fileLen;
	int64 compressedLen;
	bool isCompressed;
	bool isSepFile;
	int64 Result = INDEX_NONE;
	FString RelativeFilename;

	FString StandardFilename(Filename);
	FPaths::MakeStandardFilename(StandardFilename);

	if (GetRelativeFilenameToMountPoint(StandardFilename, RelativeFilename))
	{
		AutoRefCounter Ref(mOuterRefCount);

		if (mToDisable)
		{
			std::string szFileName = TCHAR_TO_UTF8(Filename);
			std::string szRelativeName = TCHAR_TO_UTF8(*RelativeFilename);
			std::string szStandardName = TCHAR_TO_UTF8(*StandardFilename);
			std::string log = "[1]ToMountPoint FileName:" + szFileName;
			log += ", RelativeName:" + szRelativeName;
			log += ", StandardName:" + szStandardName;
			AzureLog(AzureLogType::Error, log.c_str());
			check(false);
			return INDEX_NONE;
		}

		if (af_GetFileInfoInRealPckFile(TCHAR_TO_UTF8(*RelativeFilename), realPckOrFilePath, bufSize, (a_int64*)&outFileOffset, (a_int64*)&fileLen, (a_int64*)&compressedLen, &isCompressed, &isSepFile))
		{
			Result = fileLen;
		}
	}
	else if (GetRelativeFilenameToEnginePoint(StandardFilename, RelativeFilename))
	{
		if (mToDisable)
		{
			std::string szFileName = TCHAR_TO_UTF8(Filename);
			std::string szRelativeName = TCHAR_TO_UTF8(*RelativeFilename);
			std::string szStandardName = TCHAR_TO_UTF8(*StandardFilename);
			std::string log = "[1]ToEnginePoint FileName:" + szFileName;
			log += ", RelativeName:" + szRelativeName;
			log += ", StandardName:" + szStandardName;
			AzureLog(AzureLogType::Error, log.c_str());
			check(false);
			return LowerLevel->FileSize(Filename);
		}

		AutoRefCounter Ref(mOuterRefCount);

		if (af_GetFileInfoInRealPckFile(TCHAR_TO_UTF8(*RelativeFilename), realPckOrFilePath, bufSize, (a_int64*)&outFileOffset, (a_int64*)&fileLen, (a_int64*)&compressedLen, &isCompressed, &isSepFile))
		{
			Result = fileLen;
		}
		else
		{
			Result = LowerLevel->FileSize(Filename);
		}
	}
	else
		Result = LowerLevel->FileSize(Filename);

	return Result;
}

bool FPlatformAFileWrapper::DeleteFile(const TCHAR* Filename)
{
	if (!IsInit)
	{
		return LowerLevel->DeleteFile(Filename);
	}

	if (IsRelativeToMountPoint(Filename))
	{
		return false;
	}
	else
		return LowerLevel->DeleteFile(Filename);
}

bool FPlatformAFileWrapper::IsReadOnly(const TCHAR* Filename)
{
	if (!IsInit)
	{
		return LowerLevel->IsReadOnly(Filename);
	}

	if (IsRelativeToMountPoint(Filename))
	{
		return true;
	}
	else
		return LowerLevel->IsReadOnly(Filename);
}

bool FPlatformAFileWrapper::MoveFile(const TCHAR* To, const TCHAR* From)
{
	if (!IsInit)
	{
		return LowerLevel->MoveFile(To, From);
	}

	if (IsRelativeToMountPoint(To) || IsRelativeToMountPoint(From))
	{
		return false;
	}
	else
		return LowerLevel->MoveFile(To, From);
}

bool FPlatformAFileWrapper::SetReadOnly(const TCHAR* Filename, bool bNewReadOnlyValue)
{
	if (!IsInit)
	{
		return LowerLevel->SetReadOnly(Filename, bNewReadOnlyValue);
	}

	if (IsRelativeToMountPoint(Filename))
	{
		return bNewReadOnlyValue;
	}
	else
		return LowerLevel->SetReadOnly(Filename, bNewReadOnlyValue);
}

FDateTime FPlatformAFileWrapper::GetTimeStamp(const TCHAR* Filename)
{
	if (!IsInit)
	{
		return LowerLevel->GetTimeStamp(Filename);
	}

	FString RelativeFilename;
	FString StandardFilename(Filename);
	FPaths::MakeStandardFilename(StandardFilename);

	if (GetRelativeFilenameToMountPoint(StandardFilename, RelativeFilename))
	{
		AutoRefCounter Ref(mOuterRefCount);

		if (mToDisable)
		{
			std::string szFileName = TCHAR_TO_UTF8(Filename);
			std::string szRelativeName = TCHAR_TO_UTF8(*RelativeFilename);
			std::string szStandardName = TCHAR_TO_UTF8(*StandardFilename);
			std::string log = "[2]ToMountPoint FileName:" + szFileName;
			log += ", RelativeName:" + szRelativeName;
			log += ", StandardName:" + szStandardName;
			AzureLog(AzureLogType::Error, log.c_str());
			check(false);
			return FDateTime::MinValue();
		}

		if (af_IsFileExist(TCHAR_TO_UTF8(*RelativeFilename)))
			return sPckDateTime;
		else
			return FDateTime::MinValue();
	}
	else if (GetRelativeFilenameToEnginePoint(StandardFilename, RelativeFilename))
	{
		if (mToDisable)
		{
			std::string szFileName = TCHAR_TO_UTF8(Filename);
			std::string szRelativeName = TCHAR_TO_UTF8(*RelativeFilename);
			std::string szStandardName = TCHAR_TO_UTF8(*StandardFilename);
			std::string log = "[2]ToEnginePoint FileName:" + szFileName;
			log += ", RelativeName:" + szRelativeName;
			log += ", StandardName:" + szStandardName;
			AzureLog(AzureLogType::Error, log.c_str());
			check(false);
			return LowerLevel->GetTimeStamp(Filename);
		}

		AutoRefCounter Ref(mOuterRefCount);

		if (af_IsFileExist(TCHAR_TO_UTF8(*RelativeFilename)))
			return sPckDateTime;
		else
			return LowerLevel->GetTimeStamp(Filename);
	}
	else
		return LowerLevel->GetTimeStamp(Filename);
}

void FPlatformAFileWrapper::GetTimeStampPair(const TCHAR* FilenameA, const TCHAR* FilenameB, FDateTime& OutTimeStampA, FDateTime& OutTimeStampB)
{
	if (!IsInit)
	{
		LowerLevel->GetTimeStampPair(FilenameA, FilenameB, OutTimeStampA, OutTimeStampB);
		return;
	}

	AutoRefCounter Ref(mOuterRefCount);
	OutTimeStampA = GetTimeStamp(FilenameA);
	OutTimeStampB = GetTimeStamp(FilenameB);
}

void FPlatformAFileWrapper::SetTimeStamp(const TCHAR* Filename, FDateTime DateTime)
{
	if (!IsInit)
	{
		LowerLevel->SetTimeStamp(Filename, DateTime);
		return;
	}

	if (IsRelativeToMountPoint(Filename))
	{

	}
	else
		LowerLevel->SetTimeStamp(Filename, DateTime);
}

FDateTime FPlatformAFileWrapper::GetAccessTimeStamp(const TCHAR* Filename)
{
	if (!IsInit)
	{
		return LowerLevel->GetAccessTimeStamp(Filename);
	}

	FString RelativeFilename;
	FString StandardFilename(Filename);
	FPaths::MakeStandardFilename(StandardFilename);

	if (GetRelativeFilenameToMountPoint(StandardFilename, RelativeFilename))
	{
		AutoRefCounter Ref(mOuterRefCount);

		if (mToDisable)
		{
			std::string szFileName = TCHAR_TO_UTF8(Filename);
			std::string szRelativeName = TCHAR_TO_UTF8(*RelativeFilename);
			std::string szStandardName = TCHAR_TO_UTF8(*StandardFilename);
			std::string log = "[3]ToMountPoint FileName:" + szFileName;
			log += ", RelativeName:" + szRelativeName;
			log += ", StandardName:" + szStandardName;
			AzureLog(AzureLogType::Error, log.c_str());
			check(false);
			return FDateTime::MinValue();
		}

		if (af_IsFileExist(TCHAR_TO_UTF8(*RelativeFilename)))
			return sPckDateTime;
		else
			return FDateTime::MinValue();
	}
	else if (GetRelativeFilenameToEnginePoint(StandardFilename, RelativeFilename))
	{
		if (mToDisable)
		{
			std::string szFileName = TCHAR_TO_UTF8(Filename);
			std::string szRelativeName = TCHAR_TO_UTF8(*RelativeFilename);
			std::string szStandardName = TCHAR_TO_UTF8(*StandardFilename);
			std::string log = "[3]ToEnginePoint FileName:" + szFileName;
			log += ", RelativeName:" + szRelativeName;
			log += ", StandardName:" + szStandardName;
			AzureLog(AzureLogType::Error, log.c_str());
			check(false);
			return LowerLevel->GetAccessTimeStamp(Filename);
		}

		AutoRefCounter Ref(mOuterRefCount);

		if (af_IsFileExist(TCHAR_TO_UTF8(*RelativeFilename)))
			return sPckDateTime;
		else
			return LowerLevel->GetAccessTimeStamp(Filename);
	}
	else
		return LowerLevel->GetAccessTimeStamp(Filename);
}

FString FPlatformAFileWrapper::GetFilenameOnDisk(const TCHAR* Filename)
{
	if (!IsInit)
	{
		return LowerLevel->GetFilenameOnDisk(Filename);
	}

	if (IsRelativeToMountPoint(Filename))
		return Filename;
	else
		return LowerLevel->GetFilenameOnDisk(Filename);
}

bool FPlatformAFileWrapper::ShouldAsyncReadFileUseHandleCaching(const FString& Filename)
{
	return false;// IsRelativeToMountPoint(Filename);
}

FString FPlatformAFileWrapper::ConvertToAbsolutePathForExternalAppForRead(const TCHAR* Filename)
{
	return LowerLevel->ConvertToAbsolutePathForExternalAppForRead(Filename);
}

FString FPlatformAFileWrapper::ConvertToAbsolutePathForExternalAppForWrite(const TCHAR* Filename)
{
	return LowerLevel->ConvertToAbsolutePathForExternalAppForWrite(Filename);
}

IFileHandle* FPlatformAFileWrapper::OpenRead(const TCHAR* Filename, bool bAllowWrite)
{
	if (!IsInit)
	{
		return LowerLevel->OpenRead(Filename, bAllowWrite);
	}

	const int bufSize = 1024;
	char strPckFileName[bufSize];
	int64 pckFileOffset;
	int64 fileLen;
	int64 compressedLen;
	bool isCompressed;
	bool isSepFile;
	FString RelativeFilename;
	FString StandardFilename(Filename);
	FPaths::MakeStandardFilename(StandardFilename);

	bool isGameFile, isEngineFile;
	isGameFile = GetRelativeFilenameToMountPoint(StandardFilename, RelativeFilename);

	if (isGameFile)
		isEngineFile = false;
	else
		isEngineFile = GetRelativeFilenameToEnginePoint(StandardFilename, RelativeFilename);

	if (isGameFile || isEngineFile)
	{
		AutoRefCounter Ref(mOuterRefCount);

		if (mToDisable)
		{
			UE_LOG(LogIPlatformAFileWrapper, Log, TEXT("Disallowed to read gamefile when disabled: %s"), Filename);

			if (isGameFile)
			{
				check(false);
				return nullptr;
			}
			else
			{
				return LowerLevel->OpenRead(Filename, bAllowWrite);
			}
		}

		// UE_LOG(LogIPlatformAFileWrapper, Log, TEXT("OpenRead, Filename=%s, StandardFilename=%s, RelativeFilename=%s"), Filename, *StandardFilename, *RelativeFilename);

		mPackageFileHandleLocker.Lock();
		mFileStreamLocker.Lock();
		ACTIVE_STREAM_ENTRY* pActiveEntry = mActiveFileStreams.Find(RelativeFilename);

		if (pActiveEntry)
		{
			pActiveEntry->RefCount++;
			FALZ4FileWrapperHandle* FileHandle = new FALZ4FileWrapperHandle(pActiveEntry->Stream, std::move(RelativeFilename), this, pActiveEntry->CS);
			mFileStreamLocker.Unlock();
			mPackageFileHandleLocker.Unlock();
			return FileHandle;
		}

		mFileStreamLocker.Unlock();

		char AnsiFilename[AMAX_PATH];
		strncpy(AnsiFilename, TCHAR_TO_UTF8(*RelativeFilename), AMAX_PATH);
		AnsiFilename[AMAX_PATH - 1] = 0;

		if (!af_GetFileInfoInRealPckFile(AnsiFilename, strPckFileName, bufSize, (a_int64*)&pckFileOffset, (a_int64*)&fileLen, (a_int64*)&compressedLen, &isCompressed, &isSepFile))
		{
			mPackageFileHandleLocker.Unlock();

			if (isGameFile)
			{
				UE_LOG(LogIPlatformAFileWrapper, Log, TEXT("Failed to GetFileInfo: %s"), Filename);
				return nullptr;
			}
			else
			{
				return LowerLevel->OpenRead(Filename, bAllowWrite);
			}
		}

		// UE_LOG(LogIPlatformAFileWrapper, Log, TEXT("OpenRead, Filename=%s, StandardFilename=%s, RelativeFilename=%s, PckFileName=%s, pckFileOffset=%lld, fileLen=%lld, compressedLen=%lld, isCompressed=%d, isSepFile=%d"), Filename, *StandardFilename, *RelativeFilename, UTF8_TO_TCHAR(strPckFileName), pckFileOffset, fileLen, compressedLen, isCompressed, isSepFile);

		AFileWrapper* fp = nullptr;
		ASysThreadMutex* PackageLocker = nullptr;

		// isCompressed肯定是package文件，因为分离文件没法获取原始文件长度，但有特殊情况见下行
		// isSepFile==true，即表示一个真正单独的分离文件，又可以表示一个b包文件，但需要单独的读句柄去访问
		if (isCompressed || !isSepFile)
		{
			if (isSepFile)
			{
				fp = FILE_Wrapper::Create(strPckFileName, "rb");
			}
			else
			{
				PACKAGE_FILE_HANDLE* Handle;
				TempPackageName = strPckFileName;

				auto it = PackageFileHandleMap.find(TempPackageName);
				if (it != PackageFileHandleMap.end())
					Handle = &(it->second);
				else
					Handle = nullptr;

				if (Handle)
				{
					fp = Handle->FileWrapper;
					PackageLocker = Handle->FileLocker;
				}
				else
				{
					fp = FILE_Wrapper::Create(strPckFileName, "rb");
					// UE_LOG(LogIPlatformAFileWrapper, Log, TEXT("OpenRead(FILE_Wrapper::Create1), Filename=%s, StandardFilename=%s, RelativeFilename=%s, PckFileName=%s, pckFileOffset=%lld, fileLen=%lld, compressedLen=%lld, isCompressed=%d, isSepFile=%d"), Filename, *StandardFilename, *RelativeFilename, UTF8_TO_TCHAR(strPckFileName), pckFileOffset, fileLen, compressedLen, isCompressed, isSepFile);

					if (fp == nullptr)
					{
						mPackageFileHandleLocker.Unlock();
						UE_LOG(LogIPlatformAFileWrapper, Log, TEXT("Failed to open real pck file: %s"), Filename);
						return nullptr;
					}

					PackageLocker = new ASysThreadMutex();
					PACKAGE_FILE_HANDLE handle{ fp, PackageLocker };
					PackageFileHandleMap[strPckFileName] = handle;
				}
			}
		}

		if (isCompressed)
		{
			ALZ4File* LZ4File = new ALZ4File();

			if (LZ4File->Attach(fp, compressedLen, PackageLocker == nullptr, PackageLocker, (long)pckFileOffset))
			{
				ACTIVE_STREAM_ENTRY ActiveEntry;
				ActiveEntry.Stream = LZ4File;
				ActiveEntry.CS = &mActiveSteramLocker[(++mCurActiveLockerIndex) % ACTIVE_STTREAM_LOCKER_COUNT];
				ActiveEntry.RefCount = 1;
				mFileStreamLocker.Lock();
				mActiveFileStreams.Add(RelativeFilename, ActiveEntry);
				FALZ4FileWrapperHandle* FileHandle = new FALZ4FileWrapperHandle(LZ4File, std::move(RelativeFilename), this, ActiveEntry.CS);
				mFileStreamLocker.Unlock();
				mPackageFileHandleLocker.Unlock();
				return FileHandle;
			}
			else
			{
				// AZURE TODO, At last do not support non lz4 file in package
				delete LZ4File;
			}

			mPackageFileHandleLocker.Unlock();
			//非法的 LZ4，很有可能是小包文件损坏
			af_InGameUpdate_CheckCorruptFile(AnsiFilename);
			fp = AFileImageWrapper::Create(AnsiFilename, "rb");
			pckFileOffset = 0;
			// UE_LOG(LogIPlatformAFileWrapper, Log, TEXT("OpenRead(AFileImageWrapper::Create), Filename=%s, StandardFilename=%s, RelativeFilename=%s, PckFileName=%s, pckFileOffset=%lld, fileLen=%lld, compressedLen=%lld, isCompressed=%d, isSepFile=%d"), Filename, *StandardFilename, *RelativeFilename, UTF8_TO_TCHAR(strPckFileName), pckFileOffset, fileLen, compressedLen, isCompressed, isSepFile);

			if (fp == nullptr)
			{
				UE_LOG(LogIPlatformAFileWrapper, Log, TEXT("Failed to read zip compressed file: %s"), Filename);
				return nullptr;
			}

			return new FAFileWrapperHandle(fp, this, isCompressed, isSepFile, pckFileOffset, fileLen, nullptr);
		}
		else
		{
			if (fp)
			{
				FAFileWrapperHandle* NewHandle = new FAFileWrapperHandle(fp, this, isCompressed, isSepFile, pckFileOffset, fileLen, PackageLocker);
				mPackageFileHandleLocker.Unlock();
				return NewHandle;
			}

			mPackageFileHandleLocker.Unlock();
			fp = FILE_Wrapper::Create(strPckFileName, "rb");
			// UE_LOG(LogIPlatformAFileWrapper, Log, TEXT("OpenRead(FILE_Wrapper::Create2), Filename=%s, StandardFilename=%s, RelativeFilename=%s, PckFileName=%s, pckFileOffset=%lld, fileLen=%lld, compressedLen=%lld, isCompressed=%d, isSepFile=%d"), Filename, *StandardFilename, *RelativeFilename, UTF8_TO_TCHAR(strPckFileName), pckFileOffset, fileLen, compressedLen, isCompressed, isSepFile);

			if (fp == nullptr)
			{
				UE_LOG(LogIPlatformAFileWrapper, Log, TEXT("Failed to read uncompressed file: %s"), Filename);
				return nullptr;
			}

			return new FAFileWrapperHandle(fp, this, isCompressed, isSepFile, pckFileOffset, fileLen, nullptr);
		}
	}
	else
		return LowerLevel->OpenRead(Filename, bAllowWrite);
}

IFileHandle* FPlatformAFileWrapper::OpenWrite(const TCHAR* Filename, bool bAppend, bool bAllowRead)
{
	if (!IsInit)
	{
		return LowerLevel->OpenWrite(Filename, bAppend, bAllowRead);
	}

	if (IsRelativeToMountPoint(Filename))
		return nullptr;
	else
		return LowerLevel->OpenWrite(Filename, bAppend, bAllowRead);
}

bool FPlatformAFileWrapper::DirectoryExists(const TCHAR* Directory)
{
	if (!IsInit)
	{
		return LowerLevel->DirectoryExists(Directory);
	}

	FString RelativeFilename;
	FString StandardFilename(Directory);
	FPaths::MakeStandardFilename(StandardFilename);

	if (GetRelativeFilenameToMountPoint(StandardFilename, RelativeFilename))
	{
		AutoRefCounter Ref(mOuterRefCount);

		if (mToDisable)
		{
			UE_LOG(LogIPlatformAFileWrapper, Error, TEXT("AFileSystem Disabled when call DirectoryExists: %s"), Directory);
			check(false);
			return false;
		}

		if (af_IsDirExist(TCHAR_TO_UTF8(*RelativeFilename), true))
			return true;
		else
			return false;
	}
	else if (GetRelativeFilenameToEnginePoint(StandardFilename, RelativeFilename))
	{
		if (mToDisable)
		{
			UE_LOG(LogIPlatformAFileWrapper, Error, TEXT("AFileSystem Disabled when call DirectoryExists: %s"), Directory);
			check(false);
			return LowerLevel->DirectoryExists(Directory);
		}

		AutoRefCounter Ref(mOuterRefCount);

		if (af_IsDirExist(TCHAR_TO_UTF8(*RelativeFilename), true))
			return true;
		else
			return LowerLevel->DirectoryExists(Directory);
	}
	else
		return LowerLevel->DirectoryExists(Directory);
}

static void MakeDirectoryFromPath(FString& Path)
{
	if (Path.Len() > 0 && Path[Path.Len() - 1] != '/')
	{
		Path += TEXT("/");
	}
}

bool FPlatformAFileWrapper::CreateDirectory(const TCHAR* InDirectory)
{
	if (!IsInit)
	{
		return LowerLevel->CreateDirectory(InDirectory);
	}

	// IsRelativeToMountPoint:directory: need end with '/'
	FString Directory(InDirectory);
	MakeDirectoryFromPath(Directory);
	if (IsRelativeToMountPoint(Directory))
		return false;

	// Directories can be created only under the normal path
	return LowerLevel->CreateDirectory(InDirectory);
}

bool FPlatformAFileWrapper::DeleteDirectory(const TCHAR* InDirectory)
{
	if (!IsInit)
	{
		return LowerLevel->DeleteDirectory(InDirectory);
	}

	// IsRelativeToMountPoint:directory: need end with '/'
	FString Directory(InDirectory);
	MakeDirectoryFromPath(Directory);
	if (IsRelativeToMountPoint(Directory))
		return false;

	// Directory does not exist in pak files so it's safe to delete.
	return LowerLevel->DeleteDirectory(InDirectory);
}

bool FPlatformAFileWrapper::IterateDirectory(const TCHAR* InDirectory, IPlatformFile::FDirectoryVisitor& Visitor)
{
	if (!IsInit)
	{
		return LowerLevel->IterateDirectory(InDirectory, Visitor);
	}

	// IsRelativeToMountPoint:directory: need end with '/'
	FString Directory(InDirectory);
	MakeDirectoryFromPath(Directory);
	if (IsRelativeToMountPoint(Directory))
		return false;

	return LowerLevel->IterateDirectory(InDirectory, Visitor);
}

bool FPlatformAFileWrapper::IterateDirectoryStat(const TCHAR* InDirectory, IPlatformFile::FDirectoryStatVisitor& Visitor)
{
	if (!IsInit)
	{
		return LowerLevel->IterateDirectoryStat(InDirectory, Visitor);
	}

	// IsRelativeToMountPoint:directory: need end with '/'
	FString Directory(InDirectory);
	MakeDirectoryFromPath(Directory);
	if (IsRelativeToMountPoint(Directory))
		return false;

	return LowerLevel->IterateDirectoryStat(InDirectory, Visitor);
}

void FPlatformAFileWrapper::SetLowerLevel(IPlatformFile* NewLowerLevel)
{
	LowerLevel = NewLowerLevel;
}

bool FPlatformAFileWrapper::FixFileNameForLanguage(const TCHAR* StandardFilenamePtr, FString& OutFilename) const
{
	OutFilename = StandardFilenamePtr;

	if (!GIsEditor && FCString::Strncmp(StandardFilenamePtr, *MountPoint, MountPointPathLen) == 0)
	{
		const TCHAR* subPath = StandardFilenamePtr + MountPointPathLen;
		if (!Language.IsEmpty())
		{
			const FString LanguageMountPoint = TEXT("L10N/") + Language + TEXT("/");
			if (FCString::Strnicmp(subPath, *LanguageMountPoint, LanguageMountPoint.Len()) == 0)
			{
				OutFilename = OutFilename.Replace(*LanguageMountPoint, TEXT(""));
				return true;
			}
		}
		if (!BuiltInLanguage.IsEmpty() && FCString::Stricmp(*Language, *BuiltInLanguage) != 0)
		{
			const FString BuiltInLanguageMountPoint = TEXT("L10N/") + BuiltInLanguage + TEXT("/");
			if (FCString::Strnicmp(subPath, *BuiltInLanguageMountPoint, BuiltInLanguageMountPoint.Len()) == 0)
			{
				OutFilename = OutFilename.Replace(*BuiltInLanguageMountPoint, TEXT(""));
				return true;
			}
		}		
	}
	return false;
}

// 获取基础语言，如果非多语言包，返回空
FString FPlatformAFileWrapper::GetBuiltInLanguage() const
{
	FString OutLang;
	FString XmlFilePath = FString(GetResBaseRelativePath()) / TEXT("res_base_version.xml");
	auto XmlFileContent = StreamingAssetHelper::ReadFileText(*XmlFilePath);
	if (XmlFileContent.size() <= 0)
	{
		UE_LOG(LogIPlatformAFileWrapper, Error, TEXT("Content is empty for xml %s."), *XmlFilePath);
		return OutLang;
	}
	char* Start = &XmlFileContent[0];
	if (XmlFileContent.size() >= 3 && (unsigned char)XmlFileContent[0] == 0xef && (unsigned char)XmlFileContent[1] == 0xbb && (unsigned char)XmlFileContent[2] == 0xbf)
	{
		Start = Start + 3;
	}
	FXmlFile XmlFile;
	if (!XmlFile.LoadFile(UTF8_TO_TCHAR(Start), EConstructMethod::ConstructFromBuffer))
	{
		UE_LOG(LogIPlatformAFileWrapper, Error, TEXT("Failed to parse content of xml %s."), *XmlFilePath);
		return OutLang;
	}
	FXmlNode *RootNode = XmlFile.GetRootNode();
	if (!RootNode)
	{
		UE_LOG(LogIPlatformAFileWrapper, Error, TEXT("Failed to get root node for xml %s."), *XmlFilePath);
		return OutLang;
	}
	FString tagLang = RootNode->GetAttribute(TEXT("language"));
	if (tagLang.IsEmpty())
	{
		UE_LOG(LogIPlatformAFileWrapper, Warning, TEXT("No 'language' attribute in root note for xml %s. not a multi-language package."), *XmlFilePath);
		return OutLang;
	}

	OutLang = tagLang;
	return OutLang;
}
