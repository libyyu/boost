// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Components/ActorComponent.h"
#include "AzureTargetLockComponent.generated.h"


UCLASS( ClassGroup=(Custom), meta=(BlueprintSpawnableComponent) )
class AZURE_API UAzureTargetLockComponent : public UActorComponent
{
	GENERATED_BODY()

public:	
	// Sets default values for this component's properties
	UAzureTargetLockComponent();

protected:
	// Called when the game starts
	virtual void BeginPlay() override;

public:	
	// Called every frame
	virtual void TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction) override;

	virtual void OnComponentDestroyed(bool bDestroyingHierarchy) override;

	UFUNCTION()
		void AddLockWidget(UUserWidget * userWidget);
	UFUNCTION()
		void RemoveLockWidget(UUserWidget * userWidget);

	UFUNCTION()
		void SetParentComponent(USceneComponent* parentComponent);

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		FVector WorldOffset;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		FVector2D ScreenOffset;

	FVector AdjustWorldOffset(const FVector& worldOffset);

	void TickUserWidget();
public:
	void SetUseScaleTime(bool bUse) { UseScaleTime = bUse; }
private:

	TWeakObjectPtr<APlayerController> PlayerController;
	TArray<TWeakObjectPtr<UUserWidget>> userWidgets;
	TWeakObjectPtr<USceneComponent> ParentComponent;

	bool UseScaleTime = false;

	double CurrentTime;

	/** Last absolute real time that we ticked */
	double LastTickTime;
};
