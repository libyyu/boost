// Copyright 1998-2018 Epic Games, Inc. All Rights Reserved.

#include "MaterialExpressionFogScaleCustomOutput.h"
#include "MaterialCompiler.h"

#define LOCTEXT_NAMESPACE "Azure"

UMaterialExpressionFogScaleCustomOutput::UMaterialExpressionFogScaleCustomOutput(const FObjectInitializer& ObjectInitializer)
: Super(ObjectInitializer)
{
#if WITH_EDITORONLY_DATA
	// Structure to hold one-time initialization
	struct FConstructorStatics
	{
		FText NAME_Azure;
		FConstructorStatics()
			: NAME_Azure(LOCTEXT("Azure", "Azure"))
		{
		}
	};
	static FConstructorStatics ConstructorStatics;

#if WITH_EDITORONLY_DATA
	MenuCategories.Add(ConstructorStatics.NAME_Azure);
#endif

	bCollapsed = true;

	// No outputs
	Outputs.Reset();
#endif
}

#if WITH_EDITOR
int32  UMaterialExpressionFogScaleCustomOutput::Compile(class FMaterialCompiler* Compiler, int32 OutputIndex)
{
	if (Input.GetTracedInput().Expression)
	{
		return Compiler->CustomOutput(this, OutputIndex, Input.Compile(Compiler));
	}
	else
	{
		return CompilerError(Compiler, TEXT("Input missing"));
	}
	return INDEX_NONE;
}


void UMaterialExpressionFogScaleCustomOutput::GetCaption(TArray<FString>& OutCaptions) const
{
	OutCaptions.Add(FString(TEXT("FogScale")));
}

FExpressionInput* UMaterialExpressionFogScaleCustomOutput::GetInput(int32 InputIndex)
{
	return &Input;
}
#endif // WITH_EDITOR
