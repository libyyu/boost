// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/HUD.h"
#include "AzureHUD.generated.h"

/**
 * 
 */
UCLASS()
class AZURE_API AAzureHUD : public AHUD
{
	GENERATED_BODY()
	
public:	
	virtual void DrawHUD() override;

	void DrawDebugText(const FString& Text, FLinearColor TextColor, float ScreenX, float ScreenY, UFont* Font = NULL, float Scale = 1.f, bool bScalePosition = false);
};
