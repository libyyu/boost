﻿// Fill out your copyright notice in the Description page of Project Settings.

#include "AzureGlobalCamera.h"
#include "Camera/CameraComponent.h"
#include "AzureEntryPoint.h"
#include "Utilities/AzureUtility.h"

static const FName _TraceTag_GlobalCamera = "GlobalCamera";

//static const float verticalLimitation = 15.0f;
static const float minDegree = 0.75f;
static const float sensitive = 6.5f;
static const float joystickSpeed = 15.0f;
static const float zoomButtonSpeed = 15.0f;
static const float minPitchDeg = -89.0f;
static const float maxPitchDeg = 89.0f;


// Sets default values
AAzureGlobalCamera::AAzureGlobalCamera() : ACameraActor()
{
 	// Set this actor to call Tick() every frame.  You can turn this off to improve performance if you don't need it.
	PrimaryActorTick.bCanEverTick = true;
	PrimaryActorTick.bHighPriority = true;

	GetCameraComponent()->bConstrainAspectRatio = false;
}

// Called when the game starts or when spawned
void AAzureGlobalCamera::BeginPlay()
{
	Super::BeginPlay();

}

void AAzureGlobalCamera::EndPlay(const EEndPlayReason::Type EndPlayReason)
{
	Super::EndPlay(EndPlayReason);
}

void AAzureGlobalCamera::BeginDestroy()
{
	Super::BeginDestroy();
}

void AAzureGlobalCamera::SetCameraMode(EAzureGlobalCameraMode Mode)
{
	if (m_Mode != Mode)
	{
		m_Mode = Mode;

		if (m_Mode == EAzureGlobalCameraMode::GCM_JOYSTICK)
		{
			m_beginRealPos = m_vRealPos;
			m_beginRotator = m_Rotator;
		}
	}
}

void AAzureGlobalCamera::InitPosAndRot(const FVector& pos, const FRotator& rot)
{
	m_beginRealPos = pos;
	m_beginRotator = rot;
	m_vRealPos = pos;
	m_Rotator = rot;

	if (m_Mode == EAzureGlobalCameraMode::GCM_NONE)
	{
		SetActorLocation(m_vRealPos);
		SetActorRotation(m_Rotator);
	}
}

void AAzureGlobalCamera::TransitTo(const FVector& pos, const FRotator& rot, float duration)
{
	FHitResult hitInfo;
	FVector vEnd = pos;

	FVector collisionPos;
	if (CheckCameraCollision(m_vRealPos, vEnd, collisionPos))
	{
		FVector vDir = vEnd - m_vRealPos;
		vDir.Normalize();
		vEnd = collisionPos - vDir * 10.0f;
	}

	// Max move range
	if (MaxMoveRange > 0.0f)
	{
		FVector vMin = m_beginRealPos - FVector(MaxMoveRange, MaxMoveRange, 0.0f);
		FVector vMax = m_beginRealPos + FVector(MaxMoveRange, MaxMoveRange, 0.0f);		vEnd = ClampVector(vEnd, vMin, vMax);	}

	if (m_MaxRangeBox.IsValid)
	{
		if (!m_MaxRangeBox.IsInside(vEnd))
		{
			vEnd = ClampVector(vEnd, m_MaxRangeBox.Min, m_MaxRangeBox.Max);
		}
	}

	m_bTransiting = true;
	m_SourcePos = m_vRealPos;
	m_SourceRot = m_Rotator;
	m_TargetPos = vEnd;
	m_TargetRot = rot;
	m_fTransitDuration = duration;
	m_fTransitTime = 0.0f;
}

void AAzureGlobalCamera::UpdateTransiting(float DeltaTime)
{
	m_fTransitTime += DeltaTime;
	if (m_fTransitTime >= m_fTransitDuration)
	{
		m_fTransitTime = 0.0f;
		m_fTransitDuration = 0.0f;
		m_bTransiting = false;
		m_vRealPos = m_TargetPos;
		m_Rotator = m_TargetRot;
	}
	else
	{
		m_vRealPos = FMath::InterpEaseIn(m_SourcePos, m_TargetPos, m_fTransitTime / m_fTransitDuration, 2.0f);
		m_Rotator = FMath::InterpEaseIn(m_SourceRot, m_TargetRot, m_fTransitTime / m_fTransitDuration, 2.0f);
	}

	SetActorLocation(m_vRealPos);
	SetActorRotation(m_Rotator);
}

void AAzureGlobalCamera::AddLocationInput(const FVector& Direction)
{
	m_LocationInput += Direction;
	m_bPushing = true;
}

void AAzureGlobalCamera::AddRotationInput(float fPitch, float fYaw)
{
	m_RotationInput.Pitch += fPitch;
	m_RotationInput.Yaw += fYaw;
	m_bPushing = true;
}

void AAzureGlobalCamera::UpdatePushing(float DeltaTime)
{
	FVector preRealPos = m_vRealPos;
	FVector deltaPos = m_LocationInput * 0.15f;
	m_vRealPos += deltaPos;

	FVector collisionPos;
	if (CheckCameraCollision(preRealPos, m_vRealPos, collisionPos))
		m_vRealPos = preRealPos;

	if (m_MaxRangeBox.IsValid)
	{
		if (!m_MaxRangeBox.IsInside(m_vRealPos))
		{
			m_vRealPos = ClampVector(m_vRealPos, m_MaxRangeBox.Min, m_MaxRangeBox.Max);
		}
	}

	m_LocationInput -= deltaPos;
	if (m_LocationInput.IsNearlyZero())
		m_LocationInput = FVector::ZeroVector;

	SetActorLocation(m_vRealPos);

	FRotator deltaRot = m_RotationInput * 0.15f;
	m_Rotator += deltaRot;
	m_RotationInput -= deltaRot;
	if (m_RotationInput.IsNearlyZero())
		m_RotationInput = FRotator::ZeroRotator;
	SetActorRotation(m_Rotator);

	if (m_RotationInput.IsZero() && m_LocationInput.IsZero())
		m_bPushing = false;
}

// Called every frame
void AAzureGlobalCamera::Tick( float DeltaTime )
{
	Super::Tick( DeltaTime );

	if (m_bTransiting)
	{
		UpdateTransiting(DeltaTime);
		return;
	}

	if (m_bPushing)
	{
		UpdatePushing(DeltaTime);
	}

	switch (m_Mode)
	{
	case EAzureGlobalCameraMode::GCM_JOYSTICK:
		UpdateJoystickMode(DeltaTime);
		break;
	case EAzureGlobalCameraMode::GCM_LOOKAT:
		UpdateLookAtMode(DeltaTime);
		break;
	default:
		break;
	}
}

void AAzureGlobalCamera::UpdateJoystickMode(float DeltaTime)
{
	FVector ModifiedRotationRate;
	ModifyRotationRate(ModifiedRotationRate, RotationRate);
	//RotationRate.Set(0, 0, 0);
	FRotator delta = FRotator(
		FMath::RadiansToDegrees(ModifiedRotationRate.X),
		FMath::RadiansToDegrees(ModifiedRotationRate.Y),
		0.f) * DeltaTime;

	if (FMath::Abs(delta.Pitch) < minDegree)
		delta.Pitch = 0.f;

	if (FMath::Abs(delta.Yaw) < minDegree)
		delta.Yaw = 0.f;

	m_Rotator -= delta;

	if (HorizontalLimitation > 0.0f)
	{
		float Yaw = AzureUtility::ClipDegreeToNormalRange(m_beginRotator.Yaw - m_Rotator.Yaw);
		if (Yaw > HorizontalLimitation)
		{
			m_Rotator.Yaw = m_beginRotator.Yaw - HorizontalLimitation;
			m_Rotator.Yaw = AzureUtility::ClipDegreeToNormalRange(m_Rotator.Yaw);
		}
		else if (Yaw < -HorizontalLimitation)
		{
			m_Rotator.Yaw = m_beginRotator.Yaw + HorizontalLimitation;
			m_Rotator.Yaw = AzureUtility::ClipDegreeToNormalRange(m_Rotator.Yaw);
		}
	}
	else
	{
		m_Rotator.Yaw = AzureUtility::ClipDegreeToNormalRange(m_Rotator.Yaw);
	}

	float fPitch = FMath::Clamp(m_Rotator.Pitch, minPitchDeg, maxPitchDeg);
	m_Rotator.Pitch = fPitch;

// 	float Pitch = AzureUtility::ClipDegreeToNormalRange(m_beginRotator.Pitch - m_Rotator.Pitch);
// 	if (Pitch > verticalLimitation)
// 	{
// 		m_Rotator.Pitch = m_beginRotator.Pitch - verticalLimitation;
// 		m_Rotator.Pitch = AzureUtility::ClipDegreeToNormalRange(m_Rotator.Pitch);
// 	}
// 	else if (Pitch < -verticalLimitation)
// 	{
// 		m_Rotator.Pitch = m_beginRotator.Pitch + verticalLimitation;
// 		m_Rotator.Pitch = AzureUtility::ClipDegreeToNormalRange(m_Rotator.Pitch);
// 	}

	FVector vDir = FVector::ZeroVector;
	FVector vCameraForward = FVector::ZeroVector;
	FVector vCameraRight = FVector::RightVector;
	FVector vCameraUp = FVector::UpVector;
	FVector preRealPos = m_vRealPos;
	FQuat qu(m_Rotator);
	FVector2D vJoyStick;
	bool bDir3D = false;

	// Move by joystick.
	if (CanMoveByJoystick && AzureUtility::GetCurrentJoyStickDir(vDir, bDir3D, false, &vJoyStick, &vCameraRight, &vCameraUp, &vCameraForward))
	{
		FVector vRight = (qu * FVector::RightVector);
		FVector vForward = (qu * FVector::ForwardVector);
		VEC_UP(vForward) = 0.0;
		vRight.Normalize();
		vForward.Normalize();
		m_vRealPos = m_vRealPos + vForward * (vJoyStick.Y * joystickSpeed) + vRight * (vJoyStick.X * joystickSpeed);
	}

	if (m_horizonalShift != 0)
	{
		FVector v = qu * FVector::ForwardVector;
		v.Normalize();
		m_vRealPos = m_vRealPos - v * zoomButtonSpeed * m_horizonalShift;
	}
	if (m_verticalShift != 0)
	{
		FVector v = FVector::UpVector;
		v.Normalize();
		m_vRealPos = m_vRealPos + v * zoomButtonSpeed * m_verticalShift;
	}

	// Do camera collision
	FVector collisionPos;
	if (CheckCameraCollision(preRealPos, m_vRealPos, collisionPos))
		m_vRealPos = preRealPos;
	
	// Max move range
	if (MaxMoveRange > 0.0f)
	{
		FVector vMin = m_beginRealPos - FVector(MaxMoveRange, MaxMoveRange, 0.0f);
		FVector vMax = m_beginRealPos + FVector(MaxMoveRange, MaxMoveRange, 0.0f);		if (m_vRealPos.X > vMax.X || m_vRealPos.X < vMin.X || m_vRealPos.Y > vMax.Y || m_vRealPos.Y < vMin.Y)			m_vRealPos = preRealPos;	}

	if (m_MaxRangeBox.IsValid)
	{
		if (!m_MaxRangeBox.IsInside(m_vRealPos))
		{
			m_vRealPos = ClampVector(m_vRealPos, m_MaxRangeBox.Min, m_MaxRangeBox.Max);
		}
	}

	SetActorLocation(m_vRealPos);
	SetActorRotation(m_Rotator);
}

void AAzureGlobalCamera::UpdateLookAtMode(float DeltaTime)
{
	if (lookAtSceneComp.IsValid())
	{
		FVector lookAtPos = lookAtSceneComp->GetComponentLocation();
		FVector camPos = m_vRealPos;
		FVector camDir = lookAtPos - camPos;

		FRotator lookAtRot = camDir.ToOrientationRotator();
		lookAtRot.Normalize();

		m_Rotator = lookAtRot;
	}

	SetActorLocation(m_vRealPos);
	SetActorRotation(m_Rotator);
}

bool AAzureGlobalCamera::CheckCameraCollision(const FVector& prePos, const FVector& targetPos, FVector& collisionPos)
{
	if (!CheckCollision)
		return false;

	const float fRadius = m_fCollideRadius;
	FHitResult hitInfo;
	FVector vEnd = targetPos;

	ECollisionChannel chn = AzureUtility::TRACE_CHN_BLOCKMOVE;
	bool bRet = AzureUtility::GetHitPosInWorld(prePos, vEnd, chn, hitInfo, fRadius, 0, true, FQuat::Identity, _TraceTag_GlobalCamera);
	if (bRet)
	{
		collisionPos = hitInfo.Location;
	}

	return bRet;
}

void AAzureGlobalCamera::ModifyRotationRate(FVector& outVec, const FVector& Vec)
{
#if PLATFORM_IOS
	outVec.X = Vec.Y;
	outVec.Y = Vec.Z;
	outVec.Z = Vec.X;
#elif PLATFORM_ANDROID
	FAzureSystemInfo::UIOrientation orientation = FAzureSystemInfo::getUIOrientation();

	switch (orientation)
	{
	case FAzureSystemInfo::UIOrientation_LandscapeLeft:
		outVec.X = Vec.Y;
		outVec.Y = Vec.X;
		outVec.Z = Vec.Z;
		break;
	case FAzureSystemInfo::UIOrientation_LandscapeRight:
		outVec.X = -Vec.Y;
		outVec.Y = -Vec.X;
		outVec.Z = Vec.Z;
		break;
	default:
		outVec = Vec;
		break;
	}
#else
	outVec = Vec;
#endif
}

void AAzureGlobalCamera::SetMaxRangeBox(const FVector& vMin, const FVector& vMax)
{
	if (vMax.X > vMin.X && vMax.Y > vMin.Y && vMax.Z > vMin.Z)
	{
		m_MaxRangeBox.IsValid = 1;
		m_MaxRangeBox.Min = vMin;
		m_MaxRangeBox.Max = vMax;
	}
	else
	{
		m_MaxRangeBox.Init();
	}
}