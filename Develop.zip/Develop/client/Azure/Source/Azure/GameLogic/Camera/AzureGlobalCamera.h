// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Camera/CameraActor.h"
#include "SharedPointer.h"
#include "UE4Related.h"

#include "AzureGlobalCamera.generated.h"

UENUM(BlueprintType)
enum class EAzureGlobalCameraMode : uint8
{
	GCM_NONE = 0,
	GCM_JOYSTICK = 1,
	GCM_LOOKAT = 2
};

UCLASS()
class AZURE_API AAzureGlobalCamera : public ACameraActor
{
	GENERATED_BODY()

public:	
	AAzureGlobalCamera();

	// Called when the game starts or when spawned
	virtual void BeginPlay() override;
	virtual void EndPlay(const EEndPlayReason::Type EndPlayReason) override;
	
	// Called every frame
	virtual void Tick( float DeltaSeconds ) override;
	virtual void BeginDestroy() override;

public:

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "GlobalCamera")
	FVector RotationRate = FVector::ZeroVector;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "GlobalCamera")
	float MaxMoveRange = 1000.0f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "GlobalCamera")
	bool CanMoveByJoystick = true;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "GlobalCamera")
	float HorizontalLimitation = 0.0f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "GlobalCamera")
	bool CheckCollision = true;

	UFUNCTION(BlueprintCallable, Category = "GlobalCamera")
	void SetCameraMode(EAzureGlobalCameraMode Mode);

	UFUNCTION(BlueprintCallable, Category = "GlobalCamera")
	void InitPosAndRot(const FVector& pos, const FRotator& rot);

	UFUNCTION(BlueprintCallable, Category = "GlobalCamera")
	void SetGlobalCameraValue(float verticalShift, float horizonalShift)
	{
		m_verticalShift = verticalShift;
		m_horizonalShift = horizonalShift;
	}

	UFUNCTION(BlueprintCallable, Category = "GlobalCamera")
	void TransitTo(const FVector& pos, const FRotator& rot, float duration);

	UFUNCTION(BlueprintCallable, Category = "GlobalCamera")
	bool IsTransiting() const { return m_bTransiting; }

	UFUNCTION(BlueprintCallable, Category = "GlobalCamera")
	void AddRotationInput(float fPitch, float fYaw);

	UFUNCTION(BlueprintCallable, Category = "GlobalCamera")
	void AddLocationInput(const FVector& Direction);

	UFUNCTION(BlueprintCallable, Category = "GlobalCamera")
	void SetMaxRangeBox(const FVector& vMin, const FVector& vMax);

	UFUNCTION(BlueprintCallable, Category = "GlobalCamera")
	void SetLookAtComponent(USceneComponent* comp)
	{
		lookAtSceneComp = comp;
	}

private:
	EAzureGlobalCameraMode m_Mode = EAzureGlobalCameraMode::GCM_JOYSTICK;

	FVector m_vRealPos = FVector::ZeroVector;
	FRotator m_Rotator = FRotator::ZeroRotator;
 	FRotator m_beginRotator = FRotator::ZeroRotator;
	FVector m_beginRealPos = FVector::ZeroVector;

	float m_verticalShift = 0.0f;
	float m_horizonalShift = 0.0f;

	FBox m_MaxRangeBox;

	float m_fCollideRadius = 0.3 * UE_METRE_TRANS;

	bool m_bTransiting = false;
	float m_fTransitDuration = 0.0f;
	float m_fTransitTime = 0.0f;
	FVector m_SourcePos;
	FRotator m_SourceRot;
	FVector m_TargetPos;
	FRotator m_TargetRot;

	bool m_bPushing = false;
	FRotator m_RotationInput;
	FVector m_LocationInput;

	void ModifyRotationRate(FVector& outVec, const FVector& Vec);
	void UpdateTransiting(float DeltaTime);
	void UpdatePushing(float DeltaTime);
	void UpdateJoystickMode(float DeltaTime);
	bool CheckCameraCollision(const FVector& prePos, const FVector& targetPos, FVector& collisionPos);

	// ����ģʽ�µĲ���
	TWeakObjectPtr<USceneComponent> lookAtSceneComp;

	void UpdateLookAtMode(float DeltaTime);
};
