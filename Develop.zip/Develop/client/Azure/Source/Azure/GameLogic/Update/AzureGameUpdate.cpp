// Fill out your copyright notice in the Description page of Project Settings.

#include "AzureGameUpdate.h"
#include "Azure.h"

#include "Engine/Engine.h"
#include "LogMacros.h"
#include "PlatformConfig.h"
#include "XmlParser.h"
#include "DirClient.h"
#include "StreamingAssetHelper.h"
#include "AzureHelpFunc.h"

#define LUA_LIB
#include "lua.hpp"

#include "UserWidget.h"
#include "Misc/FileHelper.h"
#include "Misc/Paths.h"
#include "Kismet/GameplayStatics.h"
#include "HAL/PlatformFilemanager.h"

#include "Patcher/patcher.h"
#include "Patcher/Launcher.h"

#include "Http.h"

#include <thread>
#include <mutex>
#include <condition_variable>
#include <string>
#include <functional>

#include "wLua/LuaInterface.h"

#include "HAL/Runnable.h"
#include "HAL/RunnableThread.h"

#if PLATFORM_IOS
#include "AzureExport.h"
#include "IOS/IOSPlatformMisc.h"
#endif

#if PLATFORM_ANDROID
#include "Android/AndroidJNI.h"
#include "Android/AndroidMisc.h"
#include "AndroidApplication.h"
#include <jni.h>
#endif

TAutoConsoleVariable<int32> CVarAzureGetWifiStateWithTimeOut(TEXT("s.WifiStateTimeOut"), 1, TEXT("get Wifi State with TimeOut"), ECVF_Default);

static std::mutex sAFWTMutex;
static std::condition_variable sAFWTEvent;
static std::vector<std::function<void(void)>> sAFWTVec;
static bool sAFWTTimeOutFlag = false;

bool AzureCallAsyncFunctionWithTimeOut(std::function<void(void)>&& func, std::function<void(void)>&& timeOutFunc, unsigned int timeOutMillisec)
{
	{
		std::lock_guard<std::mutex> lg(sAFWTMutex);

		if (sAFWTVec.size())
		{
			timeOutFunc();
			return false;
		}

		sAFWTVec.push_back(std::move(func));
		sAFWTVec.push_back(std::move(timeOutFunc));
		sAFWTTimeOutFlag = false;
	}
	
	sAFWTEvent.notify_one();

	static auto* realThread = new std::thread([]()
	{
		while (true)
		{
			{
				std::unique_lock<std::mutex> ul(sAFWTMutex);

				while (sAFWTVec.size() == 0)
				{
					sAFWTEvent.wait(ul);
				}
			}

			sAFWTVec[0]();

			{
				std::lock_guard<std::mutex> lg(sAFWTMutex);

				if (sAFWTTimeOutFlag)
					sAFWTVec[1]();

				sAFWTVec.clear();
			}
		}
	});

	unsigned int sleepspan = 0;
	unsigned int usedTime = 0;

	while (usedTime <= timeOutMillisec)
	{
		{
			std::lock_guard<std::mutex> lg(sAFWTMutex);

			if (sAFWTVec.size() == 0)
				return true;
		}

		std::this_thread::sleep_for(std::chrono::milliseconds(sleepspan));
		usedTime += sleepspan;
		sleepspan += 5;
	}

	std::lock_guard<std::mutex> lg(sAFWTMutex);

	if (sAFWTVec.size())
	{
		sAFWTTimeOutFlag = true;
		return false;
	}

	return true;
}

bool AzureHasActiveWiFiConnectionWithTimeOut()
{
	if (CVarAzureGetWifiStateWithTimeOut.GetValueOnAnyThread() == 0)
		return FPlatformMisc::HasActiveWiFiConnection();

	bool* ret = new bool;
	*ret = false;

	bool succ = AzureCallAsyncFunctionWithTimeOut([ret]() {
		*ret = FPlatformMisc::HasActiveWiFiConnection();
	},
	[ret]()
	{
		delete ret;
	},
	3000);

	if (succ)
	{
		bool temp = *ret;
		delete ret;
		return temp;
	}
	else
	{
		return false;
	}
}

namespace Thread
{
	class FAzureThreadRunnable : public IAzureThread, public FRunnable
	{
		std::function<void(void)> m_func;
		FRunnableThread *m_thread = nullptr;

	public:
		FAzureThreadRunnable(std::function<void(void)> InFunc, const TCHAR *InName)
		{
#if STATS
			FString Name = InName + FString::Printf(TEXT("_thread_%d"), FMath::Rand());
			InName = *Name;
#endif
			m_func = InFunc;
			m_thread = FRunnableThread::Create(this, InName);
		}

		virtual ~FAzureThreadRunnable()
		{
			if (m_thread != nullptr)
			{
				m_thread->WaitForCompletion();
				delete m_thread; m_thread = nullptr;
			}
		}

	public:
		virtual bool Joinable() const
		{
			return m_thread != nullptr;
		}
		virtual void Join()
		{
			if (m_thread != nullptr)
				m_thread->WaitForCompletion();
		}

	public:
		virtual uint32 Run()
		{
			if (m_func)
				m_func();
			return 0;
		}
	};

	IAzureThread* CreateThreadNamed(std::function<void(void)> InFunc, const TCHAR *InName)
	{
		return new FAzureThreadRunnable(InFunc, InName);
	}
	IAzureThread* CreateThread_Impl(std::function<void(void)> InFunc)
	{
		return new FAzureThreadRunnable(InFunc, TEXT("noname"));
	}
	void DestroyThread_Impl(IAzureThread*& InThread)
	{
		delete InThread; InThread = nullptr;
	}

	void SetupAzureThread()
	{
		CreateThread = CreateThread_Impl;
		DestroyThread = DestroyThread_Impl;
	}
}



// Sets default values
AAzureGameUpdate::AAzureGameUpdate()
{
 	// Set this actor to call Tick() every frame.  You can turn this off to improve performance if you don't need it.
	PrimaryActorTick.bCanEverTick = false;

}

// Called when the game starts or when spawned
void AAzureGameUpdate::BeginPlay()
{
	Super::BeginPlay();
	
}

// Called every frame
void AAzureGameUpdate::Tick( float DeltaTime )
{
	Super::Tick( DeltaTime );
}

extern wLua::Lua* AAzureEntryPoint_GetWLua();

namespace LuaPatcher
{
	using namespace PatcherSpace;

	struct FPatcher;
	static FPatcher *g_patcher;

	struct FPatcher
	{
		~FPatcher()
		{
			Thread::DestroyThread(thread_patcher);
		}

		//DECLARE_DELEGATE_RetVal_OneParam(int, FAsyncDelegate, lua_State*);
		typedef std::function<int(lua_State*)> FAsyncDelegate;
		FAsyncDelegate LuaAsyncDelegate;

		std::mutex mutex_wait;
		std::condition_variable cond_wait;
		volatile int32 AsyncRet = 0;

		int32 AsyncWait()
		{
			{
				std::unique_lock<std::mutex> lock(mutex_wait);
				cond_wait.wait(lock);
			}
			return AsyncRet;
		}
		void AsyncResume(int32 ret)
		{
			AsyncRet = ret;
			cond_wait.notify_one();
		}

		std::mutex mutex_patcher;
		Thread::IAzureThread *thread_patcher = nullptr;
		Patcher::ErrorCode error_code;
		bool is_thread_patcher_exit = false;
		void on_thread_patcher_exit(Patcher::ErrorCode code)
		{
			std::lock_guard<std::mutex> lock(mutex_patcher);
			error_code = code;
			is_thread_patcher_exit = true;
		}
		void stop_thread_patcher()
		{
			std::lock_guard<std::mutex> lock(mutex_patcher);
			Thread::DestroyThread(thread_patcher);
			is_thread_patcher_exit = false;
		}
		void startInitResource()
		{
			stop_thread_patcher();
			thread_patcher = Thread::CreateThreadNamed([this]() {
				Patcher::ErrorCode code = Patcher::ErrorCode::ErrorCode_OK;
				code = Patcher::instance().initresource();
				on_thread_patcher_exit(code);
			}, TEXT("initresource"));
		}
		void startExpansionPackUpdate()
		{
			// TODO expansionPackUpdateProc
		}
		void startAutoUpdate()
		{
			stop_thread_patcher();
			thread_patcher = Thread::CreateThreadNamed([this]() {
				Patcher::ErrorCode code = Patcher::ErrorCode::ErrorCode_OK;
				code = Patcher::instance().autoupdate();
				on_thread_patcher_exit(code);
			}, TEXT("autoupdate"));
		}
		void resetLocalVersion()
		{
			stop_thread_patcher();
			thread_patcher = Thread::CreateThreadNamed([this]() {
				Patcher::ErrorCode code = Patcher::ErrorCode::ErrorCode_OK;
				code = Patcher::instance().resetLocalVersion();
				on_thread_patcher_exit(code);
			}, TEXT("resetversion"));
		}
		bool IsBusy()
		{
			std::lock_guard<std::mutex> lock(mutex_patcher);
			return !is_thread_patcher_exit;
		}

		TMap<IHttpRequest*, TSharedPtr<IHttpRequest>> HttpRequests;
		//---------------------------------------------------------------------------------------------------------------------------------------
		Patcher::DownloadFileCallbackStruct downloadFileCallback;
		int downloadFile_raw(lua_State *L, char const* url, char const* localPath, int timeout, void* param, Patcher::DownloadFileCallbackStruct callback)
		{
			downloadFileCallback = callback;
			lua_pushstring(L, "downloadFile");
			lua_pushstring(L, url);
			lua_pushstring(L, localPath);
			lua_pushinteger(L, timeout);
			lua_pushlightuserdata(L, param);
			lua_pushlightuserdata(L, &downloadFileCallback);
			return 6;
		}
		int downloadFileResumable_raw(lua_State *L, char const* url, char const* localPath, char const* md5, void* param, Patcher::DownloadFileCallbackStruct callback)
		{
			downloadFileCallback = callback;
			lua_pushstring(L, "downloadFileResumable");
			lua_pushstring(L, url);
			lua_pushstring(L, localPath);
			lua_pushstring(L, md5);
			lua_pushlightuserdata(L, param);
			lua_pushlightuserdata(L, &downloadFileCallback);
			return 6;
		}
		double m_savedTotalProgress = 0;
		void backupTotalProgress(double totalProgress)
		{
			m_savedTotalProgress = totalProgress;
		}
		void restoreTotalProgress()
		{
			m_totalProgress = m_savedTotalProgress;
		}
		double m_totalProgress = 1;
		void setTotalProgress(double totalProgress)
		{
			std::lock_guard<std::mutex> lock(mutex_patcher);
			m_totalProgress = totalProgress;
		}
		double m_currentProgress = 0;
		void setCurrentProgress(double currentProgress)
		{
			std::lock_guard<std::mutex> lock(mutex_patcher);
			m_currentProgress = currentProgress;
		}
		astring m_statusText;
		bool m_statusText_Append;
		void setStatusText_raw(char const* statusText, bool statusText_Append)
		{
			std::lock_guard<std::mutex> lock(mutex_patcher);
			m_statusText = statusText;
			m_statusText_Append = statusText_Append;
		}
		astring m_errorMsg;
		void setErrorText_raw(char const* errorMsg)
		{
			std::lock_guard<std::mutex> lock(mutex_patcher);
			m_errorMsg = errorMsg;
		}
		void forEachFile(char const* dir, void* userdata, void (_STDCALL *func)(void* userdata, char const* filePath)) 
		{
			if (dir == nullptr || func == nullptr)
				return;

			struct FDirectoryVisitor : public IPlatformFile::FDirectoryVisitor
			{
				TArray<FString> Filenames;
				virtual bool Visit(const TCHAR* FilenameOrDirectory, bool bIsDirectory)
				{
					if (!bIsDirectory)
					{
						Filenames.Add(FPaths::ConvertRelativePathToFull(FilenameOrDirectory));
					}
					return true;
				}
			};
			
			FDirectoryVisitor DirectoryVisitor;
			FPlatformFileManager::Get().GetPlatformFile().GetPlatformPhysical().IterateDirectoryRecursively(UTF8_TO_TCHAR(dir), DirectoryVisitor);

			for (const auto& aName : DirectoryVisitor.Filenames)
			{
				func(userdata, TCHAR_TO_UTF8(*aName));
			}
		}
		void deleteDirectory(char const* dir) 
		{
			if (dir == nullptr)
				return;
			FPlatformFileManager::Get().GetPlatformFile().DeleteDirectoryRecursively(UTF8_TO_TCHAR(dir));
		}
		int copyResBaseFiles(lua_State *L) // CopyAssetDirectoryInThread
		{
			lua_pushstring(L, "copyResBaseFiles");
			return 1;
		}
		int checkDiskFreeSpace_raw(lua_State *L, char const* path, a_int64 size)
		{
			lua_pushstring(L, "checkDiskFreeSpace");
			lua_pushstring(L, path);
			lua_pushnumber(L, size);
			return 3;
		}
		int popMessageBox_raw(lua_State *L, char const* message, MessageBoxType::E type)
		{
			lua_pushstring(L, "popMessageBox");
			lua_pushstring(L, message);
			lua_pushinteger(L, type);
			return 3;
		}
		bool *m_wirelessDownloadingConfirmed = nullptr;
		bool m_wirelessDownloadingConfirmedValue = false;
		bool needConfirmWirelessDownloading(bool& bCanDownload) 
		{
			if (m_wirelessDownloadingConfirmed != nullptr)
			{
				bCanDownload = *m_wirelessDownloadingConfirmed;
				return false;
			}

			//if (false)	//Test
			{
				bool isWirelessNetwork = false;
//				MainThreadTask.RunUntilFinish(() = > isWirelessNetwork = (Application.internetReachability == NetworkReachability.ReachableViaCarrierDataNetwork));
				{
					std::lock_guard<std::mutex> lock(mutex_patcher);
					LuaAsyncDelegate = [](lua_State *L) {
						lua_pushstring(L, "HasActiveWiFiConnection");
						return 1;
					};
				}
				isWirelessNetwork = !AsyncWait();

				if (!isWirelessNetwork)
				{
					bCanDownload = true;
					return false;
				}
			}

			bCanDownload = true;
			return true;
		}
		void setConfirmWirelessDownloadingResult(bool& bCanDownload) 
		{
			m_wirelessDownloadingConfirmed = &m_wirelessDownloadingConfirmedValue;
			*m_wirelessDownloadingConfirmed = bCanDownload;
		}
		bool clearInstalledExpansionPack()
		{
			return true;
		}
		int isShowUpdateTip_raw(lua_State *L, a_uint64 totalPackSize)
		{
			lua_pushstring(L, "isShowUpdateTip");
			lua_pushnumber(L, totalPackSize);
			return 2;
		}
		int updateCurrentResourceDownloadTask_raw(lua_State *L, unsigned int totalPackCount, a_uint64 totalPackSize, a_uint64 downloadedSize)
		{
			lua_pushstring(L, "updateCurrentResourceDownloadTask");
			lua_pushnumber(L, totalPackCount);
			lua_pushnumber(L, totalPackSize);
			lua_pushnumber(L, downloadedSize);
			return 4;
		}
		//---------------------------------------------------------------------------------------------------------------------------------------
		void init_callback()
		{
			Patcher::instance().backupTotalProgress = [](double totalProgress) {
				g_patcher->backupTotalProgress(totalProgress);
			};
			Patcher::instance().restoreTotalProgress = []() {
				g_patcher->restoreTotalProgress();
			};
			Patcher::instance().setTotalProgress = [](double totalProgress) {
				g_patcher->setTotalProgress(totalProgress);
			};
			Patcher::instance().setCurrentProgress = [](double currentProgress) {
				g_patcher->setCurrentProgress(currentProgress);
			};
			Patcher::instance().setStatusText_raw = [](char const* statusText, bool statusText_Append) {
				g_patcher->setStatusText_raw(statusText, statusText_Append);
			};
			Patcher::instance().setErrorText_raw = [](char const* errorMsg) {
				g_patcher->setErrorText_raw(errorMsg);
			};
			Patcher::instance().forEachFile = [](char const* dir, void* userdata, void (_STDCALL *func)(void* userdata, char const* filePath)) {
				g_patcher->forEachFile(dir, userdata, func);
			};
			Patcher::instance().deleteDirectory = [](char const* dir) {
				g_patcher->deleteDirectory(dir);
			};
			Patcher::instance().copyResBaseFiles = []() {
				{
					std::lock_guard<std::mutex> lock(g_patcher->mutex_patcher);
					g_patcher->LuaAsyncDelegate = std::bind(&FPatcher::copyResBaseFiles, g_patcher, std::placeholders::_1);
				}
				return !!g_patcher->AsyncWait();
			};
			Patcher::instance().checkDiskFreeSpace_raw = [](char const* path, a_int64 size) {
				{
					std::lock_guard<std::mutex> lock(g_patcher->mutex_patcher);
					g_patcher->LuaAsyncDelegate = std::bind(&FPatcher::checkDiskFreeSpace_raw, g_patcher, std::placeholders::_1, path, size);
				}
				return !!g_patcher->AsyncWait();
			};
			Patcher::instance().popMessageBox_raw = [](char const* message, MessageBoxType::E type)
			{
				{
					std::lock_guard<std::mutex> lock(g_patcher->mutex_patcher);
					g_patcher->LuaAsyncDelegate = std::bind(&FPatcher::popMessageBox_raw, g_patcher, std::placeholders::_1, message, type);
				}
				return (MessageBoxResult::E)g_patcher->AsyncWait();
			};
			Patcher::instance().needConfirmWirelessDownloading = [](bool& bCanDownload) {
				return g_patcher->needConfirmWirelessDownloading(bCanDownload);
			};
			Patcher::instance().setConfirmWirelessDownloadingResult = [](bool& bCanDownload) {
				g_patcher->setConfirmWirelessDownloadingResult(bCanDownload);
			};
			Patcher::instance().clearInstalledExpansionPack = []() {
				return g_patcher->clearInstalledExpansionPack();
			};
			Patcher::instance().downloadFile_raw = [](char const* url, char const* localPath, int timeout, void* param, Patcher::DownloadFileCallbackStruct callback) {
				{
					std::lock_guard<std::mutex> lock(g_patcher->mutex_patcher);
					g_patcher->LuaAsyncDelegate = std::bind(&FPatcher::downloadFile_raw, g_patcher, std::placeholders::_1, url, localPath, timeout, param, callback);
				}
				return !!g_patcher->AsyncWait();
			};
			Patcher::instance().downloadFileResumable_raw = [](char const* url, char const* localPath, char const* md5, void* param, Patcher::DownloadFileCallbackStruct callback) {
				{
					std::lock_guard<std::mutex> lock(g_patcher->mutex_patcher);
					g_patcher->LuaAsyncDelegate = std::bind(&FPatcher::downloadFileResumable_raw, g_patcher, std::placeholders::_1, url, localPath, md5, param, callback);
				}
				return !!g_patcher->AsyncWait();
			};
			Patcher::instance().isShowUpdateTip_raw = [](a_uint64 totalPackSize) {
				{
					std::lock_guard<std::mutex> lock(g_patcher->mutex_patcher);
					g_patcher->LuaAsyncDelegate = std::bind(&FPatcher::isShowUpdateTip_raw, g_patcher, std::placeholders::_1, totalPackSize);
				}
				return !!g_patcher->AsyncWait();
			};
			Patcher::instance().updateCurrentResourceDownloadTask_raw = [](unsigned int totalPackCount, a_uint64 totalPackSize, a_uint64 downloadedSize) {
				{
					std::lock_guard<std::mutex> lock(g_patcher->mutex_patcher);
					g_patcher->LuaAsyncDelegate = std::bind(&FPatcher::updateCurrentResourceDownloadTask_raw, g_patcher, std::placeholders::_1, totalPackCount, totalPackSize, downloadedSize);
				}
				return !!g_patcher->AsyncWait();
			};
		}
	};
	//---------------------------------------------------------------------------------------------------------------------------------------
	static int Patcher_new(lua_State *L)
	{
		delete g_patcher;
		g_patcher = new FPatcher();

		double initTotalProgress = (1 <= lua_gettop(L)) ? luaL_optnumber(L, 1, 0.0) : 0.0;

		g_patcher->setTotalProgress(initTotalProgress);		//	�����ϴθ���Ŀ¼�Ľ�����ʾ
		g_patcher->backupTotalProgress(initTotalProgress);	//	���ڸ��¹����лָ��ܽ�����ʾ
		return 0;
	}
	static int Patcher_delete(lua_State *L)
	{
		delete g_patcher;
		g_patcher = nullptr;
		return 0;
	}
	static int Patcher_init(lua_State *L)
	{
		if (!g_patcher)
		{
			lua_pushboolean(L, 0);
			return 1;
		}

		g_patcher->init_callback();

		auto readUTF8ToUTF16 = [&](int idx, utf16string& strUtf16)
		{
			size_t len = 0;
			const char* strTemp = luaL_checklstring(L, idx, &len);
			a_UTF8ArrayToUTF16String(strTemp, len, strUtf16);
		};

		size_t len = 0;
		int n = 1;
		Patcher::PatcherConfig config;
		config.minimumResourceVersion.ver = luaL_checkint(L, n++);
		config.resBaseVersion.ver = luaL_checkint(L, n++);
		utf16string resBasePath; readUTF8ToUTF16(n++,  resBasePath);
		utf16string resourcePath; readUTF8ToUTF16(n++,  resourcePath);
		utf16string cachePath; readUTF8ToUTF16(n++,  cachePath);
		std::string stringTableContent = luaL_checkstring(L, n++);
		utf16string packprefix; readUTF8ToUTF16(n++,  packprefix);
		utf16string packext; readUTF8ToUTF16(n++,  packext);
		utf16string project; readUTF8ToUTF16(n++,  project);
		utf16string address; readUTF8ToUTF16(n++,  address);
		utf16string backup_address; readUTF8ToUTF16(n++,  backup_address);
		utf16string backup_ip; readUTF8ToUTF16(n++,  backup_ip);
		utf16string newVersionFromDirInfo; readUTF8ToUTF16(n++,  newVersionFromDirInfo);
		config.resBasePath = resBasePath.c_str();
		config.resourcePath = resourcePath.c_str();
		config.cachePath = cachePath.c_str();
		config.stringTableContent = stringTableContent.c_str();
		config.packprefix = packprefix.c_str();
		config.packext = packext.c_str();
		config.project = project.c_str();
		config.address = address.c_str();
		config.backup_address = backup_address.c_str();
		config.backup_ip = backup_ip.c_str();
		config.newVersionFromDirInfo = newVersionFromDirInfo.c_str();
		config.isEvaluation = !!lua_toboolean(L, n++);
		config.forceUpdateToLatest = !!lua_toboolean(L, n++);
		config.isMiniApp = !!lua_toboolean(L, n++);

		utf16string extraPackagePath; readUTF8ToUTF16(n++, extraPackagePath);
		config.extraResPath = extraPackagePath.c_str();

		const char* xmlVersionTag = luaL_optstring(L, n++, NULL);
		config.xmlVersionTag = (xmlVersionTag != nullptr) ? xmlVersionTag : "";

		utf16string packSubPath; readUTF8ToUTF16(n++, packSubPath);
		config.packSubPath = packSubPath.c_str();

		config.otherPackCount = luaL_checkint(L, n++);
		config.otherPackSize = (a_int64)luaL_checknumber(L, n++);
		config.otherFinishedPackCount = luaL_checkint(L, n++);
		config.otherDownloadedPackSize = (a_int64)luaL_checknumber(L, n++);

		Patcher::instance().init(config);

		lua_pushboolean(L, 1);
		return 1;
	}

	static int Patcher_async_call(lua_State *L)
	{
		if (!g_patcher)
			return 0;

		std::lock_guard<std::mutex> lock(g_patcher->mutex_patcher);

		if (!g_patcher->LuaAsyncDelegate)
			return 0;

		int32 argc = g_patcher->LuaAsyncDelegate(L);
		g_patcher->LuaAsyncDelegate = FPatcher::FAsyncDelegate();
		return argc;
	}

	static int Patcher_async_resume(lua_State *L)
	{
		if (!g_patcher)
			return 0;

		int32 ret = luaL_checkinteger(L, 1);
		g_patcher->AsyncResume(ret);

		return 0;
	}

	static int Patcher_is_busy(lua_State *L)
	{
		if (!g_patcher)
			return 0;
		lua_pushboolean(L, g_patcher->IsBusy() ? 1 : 0);
		return 1;
	}

	static int Patcher_startInitResource(lua_State *L)
	{
		if (!g_patcher)
			return 0;
		g_patcher->startInitResource();
		return 0;
	}
	static int Patcher_startAutoUpdate(lua_State *L)
	{
		if (!g_patcher)
			return 0;
		g_patcher->startAutoUpdate();
		return 0;
	}
	static int Patcher_resetLocalVersion(lua_State *L)
	{
		if (!g_patcher)
			return 0;
		g_patcher->resetLocalVersion();
		return 0;
	}
	static int Patcher_startExpansionPackUpdate(lua_State *L)
	{
		if (!g_patcher)
			return 0;
		g_patcher->startExpansionPackUpdate();
		return 0;
	}

	static int Patcher_getTotalProgress(lua_State *L)
	{
		if (!g_patcher)
			return 0;
		std::lock_guard<std::mutex> lock(g_patcher->mutex_patcher);
		lua_pushnumber(L, g_patcher->m_totalProgress);
		return 1;
	}
	static int Patcher_getCurrentProgress(lua_State *L)
	{
		if (!g_patcher)
			return 0;
		std::lock_guard<std::mutex> lock(g_patcher->mutex_patcher);
		lua_pushnumber(L, g_patcher->m_currentProgress);
		return 1;
	}
	static int Patcher_getStatusText(lua_State *L)
	{
		if (!g_patcher)
			return 0;
		std::lock_guard<std::mutex> lock(g_patcher->mutex_patcher);
		lua_pushstring(L, g_patcher->m_statusText.c_str());
		lua_pushboolean(L, g_patcher->m_statusText_Append ? 1 : 0);
		return 2;
	}
	static int Patcher_getErrorText(lua_State *L)
	{
		if (!g_patcher)
			return 0;
		std::lock_guard<std::mutex> lock(g_patcher->mutex_patcher);
		lua_pushstring(L, g_patcher->m_errorMsg.c_str());
		return 1;
	}
	static int Patcher_getErrorCode(lua_State *L)
	{
		if (!g_patcher)
			return 0;
		std::lock_guard<std::mutex> lock(g_patcher->mutex_patcher);
		lua_pushinteger(L, g_patcher->error_code);
		return 1;
	}
	static int Patcher_HttpCreateRequest(lua_State *L)
	{
		if (!g_patcher)
			return 0;

		FHttpModule& Http = FHttpModule::Get();
		TSharedRef<IHttpRequest> HttpRequest = Http.CreateRequest();
		IHttpRequest *httpRequest = &HttpRequest.Get();
		g_patcher->HttpRequests.Add(httpRequest, HttpRequest);
		lua_pushlightuserdata(L, httpRequest);
		return 1;
	}
	static int Patcher_HttpDestroyRequest(lua_State *L)
	{
		if (!g_patcher)
			return 0;

		IHttpRequest *HttpRequest = (IHttpRequest*)lua_touserdata(L, 1);
		if (!HttpRequest)
			return 0;

		int32 num = g_patcher->HttpRequests.Remove(HttpRequest);

		lua_pushboolean(L, num > 0 ? 1 : 0);
		return 1;
	}
	static int Patcher_HttpCancelRequest(lua_State *L)
	{
		if (!g_patcher)
			return 0;

		IHttpRequest *HttpRequest = (IHttpRequest*)lua_touserdata(L, 1);
		if (!HttpRequest)
			return 0;

		if (!g_patcher->HttpRequests.Find(HttpRequest))
			return 0;

		HttpRequest->CancelRequest();

		return 0;
	}
	static int Patcher_HttpProcessRequest(lua_State *L)
	{
		if (!g_patcher)
			return 0;

		IHttpRequest *HttpRequest = (IHttpRequest*)lua_touserdata(L, 1);
		if (!HttpRequest)
			return 0;

		if (!g_patcher->HttpRequests.Find(HttpRequest))
			return 0;

		bool ret = HttpRequest->ProcessRequest();

		lua_pushboolean(L, ret ? 1 : 0);
		return 1;
	}
	static int Patcher_HttpGetRequestStatus(lua_State *L)
	{
		if (!g_patcher)
			return 0;

		IHttpRequest *HttpRequest = (IHttpRequest*)lua_touserdata(L, 1);
		if (!HttpRequest)
			return 0;

		if (!g_patcher->HttpRequests.Find(HttpRequest))
			return 0;

		int32 status = (int32)HttpRequest->GetStatus();

		lua_pushinteger(L, status);
		return 1;
	}
	static int Patcher_HttpSetTimeout(lua_State *L)
	{
		lua_Integer timeout = luaL_checkinteger(L, 1);
		FHttpModule::Get().SetHttpTimeout(timeout / 1000.0f);
		return 0;
	}
	static int Patcher_HttpGetTimeout(lua_State *L)
	{
		lua_pushnumber(L, FHttpModule::Get().GetHttpTimeout() * 1000.0f);
		return 1;
	}
	static int Patcher_HttpSetOnComplete(lua_State *L)
	{
		if (!g_patcher)
			return 0;

		IHttpRequest *HttpRequest = (IHttpRequest*)lua_touserdata(L, 1);
		if (!HttpRequest)
			return 0;

		if (!g_patcher->HttpRequests.Find(HttpRequest))
			return 0;

		class FuncHolder
		{
			wLua::lua_registry_handle refID;

		public:
			FuncHolder(lua_State* InL)
			{
				refID = wLua::lua_registry_handle::wlua_ref(InL, LUA_REGISTRYINDEX);
			}
			~FuncHolder()
			{
				wLua::Lua *wLua = AAzureEntryPoint_GetWLua();
				if (wLua)
				{
					lua_State_Wrapper wL = wLua->GetL();
					wLua::lua_registry_handle::wlua_unref(wL, LUA_REGISTRYINDEX, refID);
				}
			}
			void OnComplete(FHttpRequestPtr InRequest, FHttpResponsePtr InResponse, bool bSucceeded)
			{
				wLua::Lua *wLua = AAzureEntryPoint_GetWLua();
				if (wLua)
				{
					lua_State_Wrapper wL = wLua->GetL();
					lua_rawgeti(wL, LUA_REGISTRYINDEX, refID);
					lua_pushlightuserdata(wL, InRequest.Get());
					lua_pushlightuserdata(wL, InResponse.Get());
					lua_pushboolean(wL, bSucceeded ? 1 : 0);
					wLua->Call(3);
				}
			}
		};

		TSharedPtr<FuncHolder> Holder = MakeShareable(new FuncHolder(L));
		HttpRequest->OnProcessRequestComplete().BindLambda([](FHttpRequestPtr InRequest,
			FHttpResponsePtr InResponse, bool bSucceeded, TSharedPtr<FuncHolder> InHolder) {
				InHolder->OnComplete(InRequest, InResponse, bSucceeded); }, Holder);

		lua_pushboolean(L, 1);
		return 1;
	}
	static int Patcher_HttpSetOnProgress(lua_State *L)
	{
		if (!g_patcher)
			return 0;

		IHttpRequest *HttpRequest = (IHttpRequest*)lua_touserdata(L, 1);
		if (!HttpRequest)
			return 0;

		if (!g_patcher->HttpRequests.Find(HttpRequest))
			return 0;

		class FuncHolder
		{
			wLua::lua_registry_handle refID;
		public:
			FuncHolder(lua_State* InL)
			{
				refID = wLua::lua_registry_handle::wlua_ref(InL, LUA_REGISTRYINDEX);
			}
			~FuncHolder()
			{
				wLua::Lua *wLua = AAzureEntryPoint_GetWLua();
				if (wLua)
				{
					lua_State_Wrapper wL = wLua->GetL();
					wLua::lua_registry_handle::wlua_unref(wL, LUA_REGISTRYINDEX, refID);
				}
			}
			void OnProgress(FHttpRequestPtr InRequest, int32 BytesSent, int32 BytesRcv)
			{
				wLua::Lua *wLua = AAzureEntryPoint_GetWLua();
				if (wLua)
				{
					lua_State_Wrapper wL = wLua->GetL();
					lua_rawgeti(wL, LUA_REGISTRYINDEX, refID);
					lua_pushlightuserdata(wL, InRequest.Get());
					lua_pushinteger(wL, BytesSent);
					lua_pushinteger(wL, BytesRcv);
					wLua->Call(3);
				}
			}
		};

		TSharedPtr<FuncHolder> Holder = MakeShareable(new FuncHolder(L));
		HttpRequest->OnRequestProgress().BindLambda([](FHttpRequestPtr InRequest, 
			int32 BytesSent, int32 BytesRcv, TSharedPtr<FuncHolder> InHolder) {
				InHolder->OnProgress(InRequest, BytesSent, BytesRcv); }, Holder);

		lua_pushboolean(L, 1);
		return 1;
	}
	static int Patcher_HttpSetURL(lua_State *L)
	{
		if (!g_patcher)
			return 0;

		IHttpRequest *HttpRequest = (IHttpRequest*)lua_touserdata(L, 1);
		if (!HttpRequest)
			return 0;

		if (!g_patcher->HttpRequests.Find(HttpRequest))
			return 0;

		const char *url = luaL_checkstring(L, 2);
		HttpRequest->SetURL(UTF8_TO_TCHAR(url));

		return 0;
	}
	static int Patcher_HttpSetVerb(lua_State *L)
	{
		if (!g_patcher)
			return 0;

		IHttpRequest *HttpRequest = (IHttpRequest*)lua_touserdata(L, 1);
		if (!HttpRequest)
			return 0;

		if (!g_patcher->HttpRequests.Find(HttpRequest))
			return 0;

		const char *verb = luaL_checkstring(L, 2);
		HttpRequest->SetVerb(UTF8_TO_TCHAR(verb));

		return 0;
	}
	static int Patcher_HttpSetHeader(lua_State *L)
	{
		if (!g_patcher)
			return 0;

		IHttpRequest *HttpRequest = (IHttpRequest*)lua_touserdata(L, 1);
		if (!HttpRequest)
			return 0;

		if (!g_patcher->HttpRequests.Find(HttpRequest))
			return 0;

		const char *name = luaL_checkstring(L, 2);
		const char *value = luaL_checkstring(L, 3);
		HttpRequest->SetHeader(UTF8_TO_TCHAR(name), UTF8_TO_TCHAR(value));

		return 0;
	}
	static int Patcher_HttpGetResponseCode(lua_State *L)
	{
		if (!g_patcher)
			return 0;

		IHttpRequest *HttpRequest = (IHttpRequest*)lua_touserdata(L, 1);
		if (!HttpRequest)
			return 0;

		if (!g_patcher->HttpRequests.Find(HttpRequest))
			return 0;

		FHttpResponsePtr Response = HttpRequest->GetResponse();
		if (!Response.IsValid())
			return 0;

		IHttpResponse *response = (IHttpResponse*)lua_touserdata(L, 2);
		if (Response.Get() != response)
			return 0;

		int32 code = response->GetResponseCode();

		lua_pushinteger(L, code);
		return 1;
	}
	static int Patcher_HttpGetResponseHeader(lua_State *L)
	{
		if (!g_patcher)
			return 0;

		IHttpRequest *HttpRequest = (IHttpRequest*)lua_touserdata(L, 1);
		if (!HttpRequest)
			return 0;

		if (!g_patcher->HttpRequests.Find(HttpRequest))
			return 0;

		FHttpResponsePtr Response = HttpRequest->GetResponse();
		if (!Response.IsValid())
			return 0;

		IHttpResponse *response = (IHttpResponse*)lua_touserdata(L, 2);
		if (Response.Get() != response)
			return 0;

		const FString key = UTF8_TO_TCHAR(luaL_checkstring(L, 3));
		const FString value = response->GetHeader(key);

		lua_pushstring(L, TCHAR_TO_UTF8(*value));
		return 1;
	}
	static int Patcher_HttpGetContentLength(lua_State *L)
	{
		if (!g_patcher)
			return 0;

		IHttpRequest *HttpRequest = (IHttpRequest*)lua_touserdata(L, 1);
		if (!HttpRequest)
			return 0;

		if (!g_patcher->HttpRequests.Find(HttpRequest))
			return 0;

		FHttpResponsePtr Response = HttpRequest->GetResponse();
		if (!Response.IsValid())
			return 0;

		int32 length = Response->GetContentLength();

		lua_pushinteger(L, length);
		return 1;
	}
	static int Patcher_HttpSaveContent(lua_State *L)
	{
		if (!g_patcher)
			return 0;

		IHttpRequest *HttpRequest = (IHttpRequest*)lua_touserdata(L, 1);
		if (!HttpRequest)
			return 0;

		if (!g_patcher->HttpRequests.Find(HttpRequest))
			return 0;

		FHttpResponsePtr Response = HttpRequest->GetResponse();
		if (!Response.IsValid())
			return 0;

		IHttpResponse *response = (IHttpResponse*)lua_touserdata(L, 2);
		if (Response.Get() != response)
			return 0;

		const char *path = luaL_checkstring(L, 3);

		const TArray<uint8>& content = response->GetContent();
		bool ret = writeToFileUTF8(path, (const char*)content.GetData(), (size_t)content.Num());

		lua_pushboolean(L, ret ? 1 : 0);
		return 1;
	}
	static int Patcher_HttpSaveContentAppend(lua_State *L)
	{
		if (!g_patcher)
			return 0;

		IHttpRequest *HttpRequest = (IHttpRequest*)lua_touserdata(L, 1);
		if (!HttpRequest)
			return 0;

		if (!g_patcher->HttpRequests.Find(HttpRequest))
			return 0;

		FHttpResponsePtr Response = HttpRequest->GetResponse();
		if (!Response.IsValid())
			return 0;

		IHttpResponse *response = (IHttpResponse*)lua_touserdata(L, 2);
		if (Response.Get() != response)
			return 0;

		const char *path = luaL_checkstring(L, 3);

		const TArray<uint8>& content = response->GetContent();
		int32 ret = 0;
		FILE *p = fopen(path, "ab");
		if (p != nullptr)
		{
			ret = (int32)fwrite((const char*)content.GetData(), (size_t)content.Num(), 1, p);
			fflush(p);
			fclose(p);
		}
		lua_pushboolean(L, ret);
		return 1;
	}
	static int Patcher_downloadFile_callOnFileStart(lua_State *L)
	{
		if (!g_patcher)
			return 0;

		Patcher::DownloadFileCallbackStruct *callback = (Patcher::DownloadFileCallbackStruct*)lua_touserdata(L, 1);
		if (&g_patcher->downloadFileCallback != callback)
			return 0;

		if (!callback->OnFileStart)
			return 0;

		void *param = lua_touserdata(L, 2);
		a_uint64 totalSize = lua_tonumber(L, 3);

		callback->OnFileStart(param, totalSize);

		return 0;
	}
	static int Patcher_downloadFile_callOnFileDone(lua_State *L)
	{
		if (!g_patcher)
			return 0;

		Patcher::DownloadFileCallbackStruct *callback = (Patcher::DownloadFileCallbackStruct*)lua_touserdata(L, 1);
		if (&g_patcher->downloadFileCallback != callback)
			return 0;

		if (!callback->OnFileDone)
			return 0;

		void *param = lua_touserdata(L, 2);

		callback->OnFileDone(param);

		return 0;
	}
	static int Patcher_downloadFile_callOnProgressChange(lua_State *L)
	{
		if (!g_patcher)
			return 0;

		Patcher::DownloadFileCallbackStruct *callback = (Patcher::DownloadFileCallbackStruct*)lua_touserdata(L, 1);
		if (&g_patcher->downloadFileCallback != callback)
			return 0;

		if (!callback->OnProgressChange)
			return 0;

		void *param = lua_touserdata(L, 2);
		int32 finishedSize = luaL_checkinteger(L, 3);

		bool ret = callback->OnProgressChange(param, finishedSize);

		lua_pushboolean(L, ret ? 1 : 0);
		return 1;
	}
	static int Patcher_downloadFile_callOnNetError(lua_State *L)
	{
		if (!g_patcher)
			return 0;

		Patcher::DownloadFileCallbackStruct *callback = (Patcher::DownloadFileCallbackStruct*)lua_touserdata(L, 1);
		if (&g_patcher->downloadFileCallback != callback)
			return 0;

		if (!callback->OnNetError)
			return 0;

		void *param = lua_touserdata(L, 2);
		int errorCode = luaL_checkinteger(L, 3);
		int internalErrCode = luaL_checkinteger(L, 4);

		callback->OnNetError(param, errorCode, internalErrCode);

		return 0;
	}
	static int Patcher_downloadFile_callOnRetError(lua_State *L)
	{
		if (!g_patcher)
			return 0;

		Patcher::DownloadFileCallbackStruct *callback = (Patcher::DownloadFileCallbackStruct*)lua_touserdata(L, 1);
		if (&g_patcher->downloadFileCallback != callback)
			return 0;

		if (!callback->OnRetError)
			return 0;

		void *param = lua_touserdata(L, 2);
		int errorCode = luaL_checkinteger(L, 3);

		callback->OnRetError(param, errorCode);

		return 0;
	}
	static int Patcher_getLocalVersion(lua_State *L)
	{
		int32 version = 0;
		if (g_patcher)
			version = Patcher::instance().getLocalVersion().ver;
		else
		{
			const char* rootDir = luaL_checkstring(L, 1);
			version = Patcher::getLocalVersion(rootDir).ver;
		}
		lua_pushinteger(L, version);
		return 1;
	}
	static int Patcher_getServerVersion(lua_State *L)
	{
		int32 version = 0;
		if (g_patcher)
		{
			version = Patcher::instance().getServerVersion().ver;
		}
		else
		{
			const char* rootDir = luaL_checkstring(L, 1);
			const char* zdirVersionTxt = luaL_checkstring(L, 2);
			const char* xmlVersionTag = (3 <= lua_gettop(L)) ? luaL_optstring(L, 3, NULL) : nullptr;
			version = Patcher::getServerVersion(rootDir, zdirVersionTxt, xmlVersionTag).ver;
		}
		lua_pushinteger(L, version);
		return 1;
	}
	static int Patcher_getUpdateTotalSize(lua_State *L)
	{
		lua_Number totalUpdateSize = (lua_Number)(int64)Patcher::instance().getUpdateTotalSize();
		lua_pushnumber(L, totalUpdateSize);
		return 1;
	}
	static int Patcher_getUpdateStage(lua_State *L)
	{
		int32 stage = (int32)Patcher::instance().getUpdateStage();
		//test
		//UE_LOG(LogAzure, Warning, TEXT("Patcher_getUpdateStage:%d,(int32)%d"), stage,(int32)stage);
		lua_pushinteger(L, stage);
		return 1;
	}
	static int Patcher_getInnerErrorCode(lua_State *L)
	{
		int32 innerErrorCode = (int32)Patcher::instance().getInnerErrorCode();
		lua_pushinteger(L, innerErrorCode);
		return 1;
	}
	static int Patcher_FileExists(lua_State *L)
	{
		const char *filename = luaL_checkstring(L, 1);
		AutoFILE f(OpenFileUTF8(filename, "r"));
		lua_pushboolean(L, (f != NULL) ? 1 : 0);
		return 1;
	}
	static int Patcher_CalFileMd5(lua_State *L)
	{
		const char *filename = luaL_checkstring(L, 1);
		char OutMD5[33]; OutMD5[32] = '\0';
		if (CalFileMd5UTF8(filename, OutMD5))
		{
			lua_pushstring(L, OutMD5);
			return 1;
		}
		return 0;
	}
	static int Patcher_UDeleteFile(lua_State *L)
	{
		const char *filename = luaL_checkstring(L, 1);
		bool ret = UDeleteFileUTF8(filename);
		lua_pushboolean(L, ret ? 1 : 0);
		return 1;
	}
	static int Patcher_GetFileSize(lua_State *L)
	{
		const char *filename = luaL_checkstring(L, 1);
		lua_Number size = (lua_Number)GetFileSizeUTF8(filename);
		lua_pushnumber(L, size);
		return 1;
	}
	static int Patcher_PackFinalize(lua_State *L)
	{
		bool ret = PackFinalize();
		lua_pushboolean(L, ret ? 1 : 0);
		return 1;
	}
	static int Patcher_MakeDir(lua_State *L)
	{
		const char *dir = luaL_checkstring(L, 1);
		MakeDirUTF8(dir);
		return 0;
	}

	static int Patcher_downloadFile(lua_State *L)
	{
		const char *url = luaL_checkstring(L, 1);
		const char *filename = luaL_optstring(L, 2, "");

		class FuncHolder
		{
			wLua::lua_registry_handle refIDPrgress;
			wLua::lua_registry_handle refIDComplete;
		public:
			astring Url;
			astring Filename;
			TSharedPtr<IHttpRequest> HttpRequest;
			FuncHolder(lua_State* InL)
			{
				lua_pushvalue(InL, 3);
				refIDComplete = wLua::lua_registry_handle::wlua_ref(InL, LUA_REGISTRYINDEX);
				lua_pushvalue(InL, 4);
				refIDPrgress = wLua::lua_registry_handle::wlua_ref(InL, LUA_REGISTRYINDEX);
			}
			~FuncHolder()
			{
				HttpRequest.Reset();
				wLua::Lua *wLua = AAzureEntryPoint_GetWLua();
				if (wLua)
				{
					lua_State_Wrapper wL = wLua->GetL();
					wLua::lua_registry_handle::wlua_unref(wL, LUA_REGISTRYINDEX, refIDComplete);
					wLua::lua_registry_handle::wlua_unref(wL, LUA_REGISTRYINDEX, refIDPrgress);
				}
			}
			void OnProgress(FHttpRequestPtr InRequest, int32 BytesSent, int32 BytesRcv)
			{
				wLua::Lua *wLua = AAzureEntryPoint_GetWLua();
				if (wLua)
				{
					lua_State_Wrapper wL = wLua->GetL();
					lua_rawgeti(wL, LUA_REGISTRYINDEX, refIDPrgress);
					lua_pushlightuserdata(wL, InRequest.Get());
					lua_pushinteger(wL, BytesSent);
					lua_pushinteger(wL, BytesRcv);
					wLua->Call(3);
				}
			}
			void OnComplete(FHttpRequestPtr InRequest, FHttpResponsePtr InResponse, bool bSucceeded)
			{
				if (bSucceeded && InResponse->GetResponseCode() != 200)
				{
					bSucceeded = false;
					UE_LOG(LogAzure, Warning, TEXT("[%s] download error code:%d"), UTF8_TO_TCHAR(Url.c_str()), InResponse->GetResponseCode());
				}

				bool bWrite = false;
				if (bSucceeded)
				{
					const TArray<uint8>& content = InResponse->GetContent();
					if (content.Num() > 0 && !Filename.empty())
					{
						const char* pathname = Filename.c_str();
						MakeDirUTF8(pathname);
						bWrite = writeToFileUTF8(pathname, (const char*)content.GetData(), (size_t)content.Num());
						if (!bWrite)
						{
							UE_LOG(LogAzure, Warning, TEXT("download failed to create file:%s"), UTF8_TO_TCHAR(pathname));
						}
					}
				}
				wLua::Lua *wLua = AAzureEntryPoint_GetWLua();
				if (wLua)
				{
					lua_State_Wrapper wL = wLua->GetL();
					lua_rawgeti(wL, LUA_REGISTRYINDEX, refIDComplete);
					lua_pushboolean(wL, bSucceeded ? 1 : 0);
					lua_pushstring(wL, Url.c_str());
					lua_pushstring(wL, Filename.c_str());
					if (bSucceeded && !bWrite)
					{
						const TArray<uint8>& content = InResponse->GetContent();
						lua_pushlstring(wL, (const char*)content.GetData(), (size_t)content.Num());
					}
					else
						lua_pushnil(wL);
					wLua->Call(4);
				}
				HttpRequest.Reset();
			}
		};

		FHttpModule& Http = FHttpModule::Get();
		TSharedRef<IHttpRequest> HttpRequest = Http.CreateRequest();
		TSharedPtr<FuncHolder> Holder = MakeShareable(new FuncHolder(L));
		Holder->HttpRequest = HttpRequest;
		Holder->Url = url;
		Holder->Filename = filename;
		HttpRequest->OnProcessRequestComplete().BindLambda([](FHttpRequestPtr InRequest,
			FHttpResponsePtr InResponse, bool bSucceeded, TSharedPtr<FuncHolder> InHolder) {
			InHolder->OnComplete(InRequest, InResponse, bSucceeded); }, Holder);
		HttpRequest->OnRequestProgress().BindLambda([](FHttpRequestPtr InRequest,
			int32 BytesSent, int32 BytesRcv, TSharedPtr<FuncHolder> InHolder) {
			InHolder->OnProgress(InRequest, BytesSent, BytesRcv); }, Holder);

		HttpRequest->SetURL(UTF8_TO_TCHAR(url));
		HttpRequest->SetVerb("Get");
		HttpRequest->SetHeader("User-Agent", "X-UnrealEngine-Agent");
		HttpRequest->SetHeader("Content-Type", "application/json");
		HttpRequest->ProcessRequest();

		lua_pushboolean(L, 1);
		return 1;
	}

	const luaL_Reg Lib_Patcher_Funcs[] =
	{
		{ "new", Patcher_new },
		{ "delete", Patcher_delete },
		{ "init", Patcher_init },
		{ "async_call", Patcher_async_call },
		{ "async_resume", Patcher_async_resume },
		{ "is_busy", Patcher_is_busy },
		{ "startInitResource", Patcher_startInitResource },
		{ "startAutoUpdate", Patcher_startAutoUpdate },
		{ "resetLocalVersion", Patcher_resetLocalVersion },
		{ "startExpansionPackUpdate", Patcher_startExpansionPackUpdate },
		{ "getTotalProgress", Patcher_getTotalProgress },
		{ "getCurrentProgress", Patcher_getCurrentProgress },
		{ "getStatusText", Patcher_getStatusText },
		{ "getErrorText", Patcher_getErrorText },
		{ "getErrorCode", Patcher_getErrorCode },
		{ "HttpSetTimeout", Patcher_HttpSetTimeout },
		{ "HttpGetTimeout", Patcher_HttpGetTimeout },
		{ "HttpCreateRequest", Patcher_HttpCreateRequest },
		{ "HttpDestroyRequest", Patcher_HttpDestroyRequest },
		{ "HttpCancelRequest", Patcher_HttpCancelRequest },
		{ "HttpProcessRequest", Patcher_HttpProcessRequest },
		{ "HttpGetRequestStatus", Patcher_HttpGetRequestStatus },
		{ "HttpSetOnComplete", Patcher_HttpSetOnComplete },
		{ "HttpSetOnProgress", Patcher_HttpSetOnProgress },
		{ "HttpSetURL", Patcher_HttpSetURL },
		{ "HttpSetVerb", Patcher_HttpSetVerb },
		{ "HttpSetHeader", Patcher_HttpSetHeader },
		{ "HttpGetResponseCode", Patcher_HttpGetResponseCode },
		{ "HttpGetResponseHeader", Patcher_HttpGetResponseHeader },
		{ "HttpGetContentLength", Patcher_HttpGetContentLength },
		{ "HttpSaveContent", Patcher_HttpSaveContent },
		{ "HttpSaveContentAppend", Patcher_HttpSaveContentAppend },
		{ "downloadFile_callOnFileStart", Patcher_downloadFile_callOnFileStart },
		{ "downloadFile_callOnFileDone", Patcher_downloadFile_callOnFileDone },
		{ "downloadFile_callOnProgressChange", Patcher_downloadFile_callOnProgressChange },
		{ "downloadFile_callOnNetError", Patcher_downloadFile_callOnNetError },
		{ "downloadFile_callOnRetError", Patcher_downloadFile_callOnRetError },
		{ "getLocalVersion", Patcher_getLocalVersion },
		{ "getServerVersion", Patcher_getServerVersion },
		{ "getUpdateTotalSize", Patcher_getUpdateTotalSize },
		{ "getUpdateStage", Patcher_getUpdateStage },
		{ "getInnerErrorCode", Patcher_getInnerErrorCode },
		{ "FileExists", Patcher_FileExists },
		{ "CalFileMd5", Patcher_CalFileMd5 },
		{ "UDeleteFile", Patcher_UDeleteFile },
		{ "GetFileSize", Patcher_GetFileSize },
		{ "PackFinalize", Patcher_PackFinalize },
		{ "MakeDir", Patcher_MakeDir },
		{ "DownloadFile", Patcher_downloadFile },

		{ NULL, NULL }
	};

	void Register(lua_State* L)
	{
		luaL_register(L, "Patcher", Lib_Patcher_Funcs);
		lua_pop(L, 1);
	}

	static int lua_downLoadUrl_inner(lua_State *L, char const* method)
	{
		const char *url = luaL_checkstring(L, 1);
		const char *filename = luaL_optstring(L, 2, "");

		class FuncHolder
		{
			wLua::lua_registry_handle refID;
		public:
			astring Url;
			astring Filename;
			TSharedPtr<IHttpRequest> HttpRequest;
			FuncHolder(lua_State* InL)
			{
				refID = wLua::lua_registry_handle::wlua_ref(InL, LUA_REGISTRYINDEX);
			}
			~FuncHolder()
			{
				HttpRequest.Reset();
				wLua::Lua *wLua = AAzureEntryPoint_GetWLua();
				if (wLua)
				{
					lua_State_Wrapper wL = wLua->GetL();
					wLua::lua_registry_handle::wlua_unref(wL, LUA_REGISTRYINDEX, refID);
				}
			}
			void OnComplete(FHttpRequestPtr InRequest, FHttpResponsePtr InResponse, bool bSucceeded)
			{
				if (bSucceeded && InResponse->GetResponseCode() != 200)
				{
					bSucceeded = false;
					UE_LOG(LogAzure, Warning, TEXT("[%s] download error code:%d"), UTF8_TO_TCHAR(Url.c_str()), InResponse->GetResponseCode());
				}

				bool bWrite = false;
				if (bSucceeded)
				{
					const TArray<uint8>& content = InResponse->GetContent();
					if (content.Num() > 0 && !Filename.empty())
					{
						const char* pathname = Filename.c_str();
						MakeDirUTF8(pathname);
						bWrite = writeToFileUTF8(pathname, (const char*)content.GetData(), (size_t)content.Num());
						if (!bWrite)
						{
							UE_LOG(LogAzure, Warning, TEXT("download failed to create file:%s"), UTF8_TO_TCHAR(pathname));
						}
					}
				}
				wLua::Lua *wLua = AAzureEntryPoint_GetWLua();
				if (wLua)
				{
					lua_State_Wrapper wL = wLua->GetL();
					lua_rawgeti(wL, LUA_REGISTRYINDEX, refID);
					lua_pushboolean(wL, bSucceeded ? 1 : 0);
					lua_pushstring(wL, Url.c_str());
					lua_pushstring(wL, Filename.c_str());
					if (bSucceeded && !bWrite)
					{
						const TArray<uint8>& content = InResponse->GetContent();
						lua_pushlstring(wL, (const char*)content.GetData(), (size_t)content.Num());
					}
					else
						lua_pushnil(wL);
					wLua->Call(4);
				}
				HttpRequest.Reset();
			}
		};

		FHttpModule& Http = FHttpModule::Get();
		TSharedRef<IHttpRequest> HttpRequest = Http.CreateRequest();
		TSharedPtr<FuncHolder> Holder = MakeShareable(new FuncHolder(L));
		Holder->HttpRequest = HttpRequest;
		Holder->Url = url;
		Holder->Filename = filename;
		HttpRequest->OnProcessRequestComplete().BindLambda([](FHttpRequestPtr InRequest,
			FHttpResponsePtr InResponse, bool bSucceeded, TSharedPtr<FuncHolder> InHolder) {
			InHolder->OnComplete(InRequest, InResponse, bSucceeded); }, Holder);

		HttpRequest->SetURL(UTF8_TO_TCHAR(url));
		HttpRequest->SetVerb(method);
		HttpRequest->SetHeader("User-Agent", "X-UnrealEngine-Agent");
		HttpRequest->SetHeader("Content-Type", "application/json");
		HttpRequest->ProcessRequest();

		lua_pushboolean(L, 1);
		return 1;
	}

	int lua_downLoadUrl(lua_State *L)
	{
		return lua_downLoadUrl_inner(L, "Get");
	}

	//POST��ʽ����
	int lua_downLoadUrlPost(lua_State *L)
	{
		return lua_downLoadUrl_inner(L, "POST");
	}

	int lua_getDiskFreeSpace(lua_State *L)
	{
		const FString path = UTF8_TO_TCHAR(luaL_checkstring(L, 1));
		uint64 TotalDiskSpace = 0;
		uint64 FreeDiskSpace = 0;
		if (FPlatformMisc::GetDiskTotalAndFreeSpace(path, TotalDiskSpace, FreeDiskSpace))
		{
			lua_pushnumber(L, (lua_Number)FreeDiskSpace);
			return 1;
		}

		lua_pushnumber(L, 0);
		return 1;
	}

	int lua_HasActiveWiFiConnection(lua_State *L)
	{
		bool ret = AzureHasActiveWiFiConnectionWithTimeOut();
		lua_pushboolean(L, ret ? 1 : 0);
		return 1;
	}

	int lua_GetNetworkConnectionType(lua_State *L)
	{
		if (CVarAzureGetWifiStateWithTimeOut.GetValueOnAnyThread() == 0)
		{
			lua_pushinteger(L, static_cast<int32>(FPlatformMisc::GetNetworkConnectionType()));
			return 1;
		}

		int32* ret = new int32;
		*ret = 0;

		bool succ = AzureCallAsyncFunctionWithTimeOut([ret]() {
			*ret = static_cast<int32>(FPlatformMisc::GetNetworkConnectionType());
		},
		[ret]()
		{
			delete ret;
		},
		3000);

		if (succ)
		{
			lua_pushinteger(L, *ret);
			delete ret;
		}
		else
		{
			lua_pushinteger(L, 0);
		}

		return 1;
	}
}