#include "CoreMinimal.h"
#include "Interfaces/IHttpRequest.h"
#include "HttpModule.h"
#include "Async/TaskGraphInterfaces.h"
#include "CurlHttp2.h"

#include "AFI.h"

struct AInGameUpdateDownloadDataImpl : public AInGameUpdateDownloadDataInterface
{
	AInGameUpdateDownloadDataImpl()
	{
	}

	virtual ~AInGameUpdateDownloadDataImpl()
	{
	}

	virtual void Release()
	{
		delete this;
	}

	virtual AInGameUpdateDownloadDataInterface::Status GetStatus() const override
	{
		if (bSucceeded)
			return AInGameUpdateDownloadDataInterface::Status::enumDataOk;
		else if (Request->GetStatus() == EHttpRequestStatus::Failed_ConnectionError)
			return AInGameUpdateDownloadDataInterface::Status::enumConnectionError;
		else if (bRangeError)
			return AInGameUpdateDownloadDataInterface::Status::enumRangeError;
		else
			return AInGameUpdateDownloadDataInterface::Status::enumDataFaild;
	}

	virtual void* GetUserData() const override
	{
		return userData;
	}

	bool bSucceeded = false;
	bool bUseRange = false;
	bool bRangeError = false;
	void* userData;
	FHttpRequestPtr Request;
	FHttpResponsePtr Response;
	AInGameUpdateDownloadCompleteFuncType callbackFunc;
	AInGameUpdateDownloadReceiveDataFuncType receiveDataFunc;
};

// Game thread
static void OnAzureInGameUpdateDownloadComplete(FHttpRequestPtr HttpRequest, FHttpResponsePtr HttpResponse, bool bSucceeded, AInGameUpdateDownloadDataImpl* UserData)
{
	if (!HttpResponse)
	{
		bSucceeded = false;
	}
	else
	{
		auto httpCode = HttpResponse->GetResponseCode();

		if (httpCode == 200)
		{
			if (UserData->bUseRange)
			{
				bSucceeded = false;
				UserData->bRangeError = true;
			}
		}
		else if (httpCode == 404 || httpCode == 416)
		{
			bSucceeded = false;
			UserData->bRangeError = true;
		}
		else if (httpCode != 206)
		{
			bSucceeded = false;
		}
	}

	UserData->bSucceeded = bSucceeded;
	UserData->Request = HttpRequest;
	UserData->Response = HttpResponse;
	auto callbackFunc = UserData->callbackFunc;
	callbackFunc(UserData);
}

// Any thread
static void AzureRequestCustomReceiveDataFunc(void* InUserData, const void* data, unsigned int size)
{
	AInGameUpdateDownloadDataImpl* UserData = (AInGameUpdateDownloadDataImpl*)InUserData;
	auto receiveDataFunc = UserData->receiveDataFunc;
	receiveDataFunc(UserData, data, size);
}

// Any thread
void AzureInGameUpdateDownloadFile(const char* szFile, uint64_t fileOffset, uint64_t downloadSize, int bytesPerSecond, void* InUserData,
	AInGameUpdateDownloadCompleteFuncType callbackFunc, AInGameUpdateDownloadReceiveDataFuncType receiveDataFunc, bool bStartAll)
{
	if (!FTaskGraphInterface::IsRunning())
		return;

	FFunctionGraphTask::CreateAndDispatchWhenReady([strFile = std::string(szFile), fileOffset, downloadSize, bytesPerSecond, InUserData, callbackFunc, receiveDataFunc]()
	{
		if (!af_InGameUpdate_IsInit())
			return;

		AInGameUpdateDownloadDataImpl* UserDataPtr = new AInGameUpdateDownloadDataImpl();
		UserDataPtr->userData = InUserData;
		UserDataPtr->callbackFunc = callbackFunc;
		UserDataPtr->receiveDataFunc = receiveDataFunc;

		TSharedPtr<IHttpRequest> Request = FHttpModule::Get().CreateRequest();
		FString url(UTF8_TO_TCHAR(strFile.c_str()));

		if (fileOffset != 0 || downloadSize != 0)
		{
			UserDataPtr->bUseRange = true;
			FString header;
			if (downloadSize)
				header = FString::Printf(TEXT("bytes=%llu-%llu"), fileOffset, fileOffset + downloadSize - 1);
			else
				header = FString::Printf(TEXT("bytes=%llu-"), fileOffset);
			Request->SetHeader(TEXT("Range"), header);
		}

		Request->SetVerb(TEXT("Get"));
		Request->SetURL(url);
		Request->SetSpeedLimit(bytesPerSecond);
		Request->OnProcessRequestComplete().BindStatic(&OnAzureInGameUpdateDownloadComplete, UserDataPtr);
		Request->SetCustomReceiveDataFunc(AzureRequestCustomReceiveDataFunc, UserDataPtr);
		Request->ProcessRequest();
	}, TStatId(), NULL, ENamedThreads::GameThread);
}


void AzureInGameUpdateDownloadFile_http2(const char* szFile, uint64_t fileOffset, uint64_t downloadSize, int bytesPerSecond, void* InUserData,
	AInGameUpdateDownloadCompleteFuncType callbackFunc, AInGameUpdateDownloadReceiveDataFuncType receiveDataFunc, bool bStartAll)
{
	if (!FTaskGraphInterface::IsRunning())
		return;

	struct _AInGameUpdateDownloadDataImpl : public AInGameUpdateDownloadDataInterface
	{
		_AInGameUpdateDownloadDataImpl() :
			userData(nullptr)
			, callbackFunc(nullptr)
			, receiveDataFunc(nullptr)
			, httpCode(0)
			, fileOffset(0)
			, downloadSize(0)
		{
		}

		virtual void Release()
		{
			delete this;
		}

		virtual AInGameUpdateDownloadDataInterface::Status GetStatus() const override
		{
			if (downLoadCode == SingleDownLoadStatus::Http2Status_OK)
			{
				AInGameUpdateDownloadDataInterface::Status status = AInGameUpdateDownloadDataInterface::Status::enumDataOk;

				if (httpCode == 200)
				{
					if (fileOffset > 0 || downloadSize > 0)
						status = AInGameUpdateDownloadDataInterface::Status::enumRangeError;
				}
				else if (httpCode == 404 || httpCode == 416)
				{
					status = AInGameUpdateDownloadDataInterface::Status::enumRangeError;
				}
				else if (httpCode != 206)
				{
					status = AInGameUpdateDownloadDataInterface::Status::enumDataFaild;
				}
				return status;
			}
			return AInGameUpdateDownloadDataInterface::Status::enumConnectionError;
		}

		virtual void* GetUserData() const override
		{
			return userData;
		}

		//Any thread
		static void OnAzureInGameUpdateDownloadComplete(SingleDownLoadStatus code,int httpCode, _AInGameUpdateDownloadDataImpl* UserData)
		{
			UserData->downLoadCode = code;
			UserData->httpCode = httpCode;
			auto callbackFunc = UserData->callbackFunc;
			if (callbackFunc)
				callbackFunc(UserData);
		}

		// Any thread
		static void AzureRequestCustomReceiveDataFunc(void* InUserData, const void* data, unsigned int size)
		{
			_AInGameUpdateDownloadDataImpl* UserData = (_AInGameUpdateDownloadDataImpl*)InUserData;
			auto receiveDataFunc = UserData->receiveDataFunc;
			if (receiveDataFunc)
				receiveDataFunc(UserData, data, size);
		}

		void* userData;
		std::string FileToDownload;
		AInGameUpdateDownloadCompleteFuncType callbackFunc;
		AInGameUpdateDownloadReceiveDataFuncType receiveDataFunc;
		SingleDownLoadStatus downLoadCode;
		int httpCode;
		uint64_t fileOffset;
		uint64_t downloadSize;
	};

	_AInGameUpdateDownloadDataImpl* UserDataPtr = new _AInGameUpdateDownloadDataImpl();
	UserDataPtr->userData = InUserData;
	UserDataPtr->FileToDownload = szFile;
	UserDataPtr->callbackFunc = callbackFunc;
	UserDataPtr->receiveDataFunc = receiveDataFunc;
	UserDataPtr->fileOffset = fileOffset;
	UserDataPtr->downloadSize = downloadSize;

	static TArray<FHttp2RequestCompleteDelegate> completeCBs;
	completeCBs.AddDefaulted();
	completeCBs.Top().BindStatic(&_AInGameUpdateDownloadDataImpl::OnAzureInGameUpdateDownloadComplete, UserDataPtr);
	CurlHttp2MultiDownloadWrapper::instance().PushDownloadTask(szFile, bytesPerSecond, fileOffset, downloadSize, UserDataPtr);
	if (bStartAll)
	{
		CurlHttp2MultiDownloadWrapper::instance().BeginDownLoad(_AInGameUpdateDownloadDataImpl::AzureRequestCustomReceiveDataFunc, completeCBs);
		completeCBs.Empty();
	}
}
