#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "FlockStateMachine.generated.h"

UENUM( BlueprintType )
enum class ELogicFSMState :uint8
{
	Flock_Idle ,
	Flock_Alert ,
	Flock_Escape ,
	Flock_Away ,
	Flock_Back ,
	Flock_Recover ,
	Flock_FlyToCam,
	Flock_Rest
};

class USphereComponent;

UCLASS()
class AZURE_API AFlockStateMachine : public AActor
{
	GENERATED_BODY()

public:

	AFlockStateMachine();

protected:

	// Called when the game starts or when spawned
	virtual void BeginPlay() override;

	virtual void EndPlay( const EEndPlayReason::Type EndPlayReason ) override;

	// Called every frame
	virtual void Tick( float DeltaTime ) override;

public:

	UPROPERTY( EditAnywhere , BlueprintReadOnly , Category = UserParams )
	bool isBird;

	UPROPERTY( EditAnywhere , BlueprintReadWrite , Category = UserParams )
	float backDelayDuring;

	UPROPERTY( EditAnywhere , BlueprintReadWrite , Category = UserParams )
	float escapeDuring;

	UPROPERTY( EditAnywhere , BlueprintReadWrite , Category = UserParams )
	float backDuring;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = UserParams)
	float restDuring;

	UPROPERTY( EditAnywhere , BlueprintReadWrite , Category = UserParams )
	float cullingDistance;

	UPROPERTY( EditAnywhere , BlueprintReadWrite , Category = UserParams )
	float animalScale;

	UPROPERTY( EditAnywhere , BlueprintReadWrite , Category = UserParams )
	float turnSpeed;

	UPROPERTY( EditAnywhere , BlueprintReadWrite , Category = UserParams )
	float probabilityOfFlyToCam;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = UserParams)
	float probabilityOfBirdToRest;

	UPROPERTY( EditAnywhere , BlueprintReadWrite , Category = UserParams )
	FVector2D flyToCamRange;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = UserParams)
	float ZStart;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = UserParams)
	float ZEnd;
public:

	UPROPERTY( EditAnywhere , BlueprintReadOnly , Category = UserCurves )
	class UCurveFloat *backCurve;

	void SetEnableByAmount( bool enable )
	{
		enableByAmount = enable;
	}

	UFUNCTION( BlueprintCallable , Category = Flock )
	void SetEnableByWeather( bool enable )
	{
		enableByWeather = enable;
	}

	USphereComponent * GetAwayRange() 
	{
		return awayRangePtr.Get();
	}

protected:

	UFUNCTION( BlueprintNativeEvent , Category = Flock )
	void EnterIdleState();

	UFUNCTION( BlueprintNativeEvent , Category = Flock )
	void UpdateIdleState( float DeltaTime );

	UFUNCTION( BlueprintNativeEvent , Category = Flock )
	void EnterEscapeState();

	UFUNCTION( BlueprintNativeEvent , Category = Flock )
	void UpdateEscapeState( float DeltaTime );

	UFUNCTION( BlueprintNativeEvent , Category = Flock )
	void EnterAwayState();

	UFUNCTION( BlueprintNativeEvent , Category = Flock )
	void UpdateAwayState( float DeltaTime );

	UFUNCTION( BlueprintNativeEvent , Category = Flock )
	void EnterFlyToCamState();

	UFUNCTION( BlueprintNativeEvent , Category = Flock )
	void UpdateFlyToCamState( float DeltaTime );

	UFUNCTION( BlueprintNativeEvent , Category = Flock )
	void EnterBackState();

	UFUNCTION( BlueprintNativeEvent , Category = Flock )
	void UpdateBackState( float DeltaTime );

	UFUNCTION(BlueprintNativeEvent, Category = Flock)
	void EnterRestState();

	UFUNCTION(BlueprintNativeEvent, Category = Flock)
	void UpdateRestState(float DeltaTime);

protected:

	UFUNCTION( BlueprintCallable , Category = Flock )
	void SetAnimBoolProperty( bool value, const FString &propertyName );

	UFUNCTION( BlueprintCallable , Category = Flock )
	void SetAnimIntProperty( int32 value , const FString &propertyName );

	UFUNCTION(BlueprintCallable, Category = Flock)
	FVector GetRayTracePos(FVector Location);

protected:
	
	UFUNCTION( BlueprintCallable , Category = Flock )
	AActor * GetHostPlayer();

	UFUNCTION( BlueprintCallable , Category = Flock )
	FVector GetCameraPosition();

	UFUNCTION( BlueprintCallable , Category = Flock )
	FTransform GetMainCameraTrans();

private:
	void OnBackDelay();
	bool RestPointsOk();
protected:

	UPROPERTY( BlueprintReadWrite , Category = Flock )
	ELogicFSMState curState;
	UPROPERTY( BlueprintReadWrite , Category = Flock )
	ELogicFSMState lastState;

	UPROPERTY( BlueprintReadWrite , Category = Flock )
	float stateDuring;
	UPROPERTY( BlueprintReadWrite , Category = Flock )
	FVector lastLoc;
	
	UPROPERTY( BlueprintReadWrite , Category = Flock )
	FVector awayCenter;
	UPROPERTY( BlueprintReadWrite , Category = Flock )
	float awayRadius;
	UPROPERTY( BlueprintReadWrite , Category = Flock )
	FVector nextAwayLoc;

	UPROPERTY( BlueprintReadWrite , Category = Flock )
	FVector idleCenter;
	UPROPERTY( BlueprintReadWrite , Category = Flock )
	float idleRadius;
	UPROPERTY( BlueprintReadWrite , Category = Flock )
	FVector nextIdleLoc;

protected:

	bool lastEnable;
	float lastCullScale;
	bool enableByAmount;
	bool enableByWeather;

	void ShowHideFlocks( bool isShow );
	void RefreshCullDistance( float cullScale );
	bool CheckPlayerNear();

	UFUNCTION( BlueprintCallable , Category = Flock )
	bool GetFlocksEnable();

	UFUNCTION( BlueprintCallable , Category = Flock )
	void GetFlocksCullDistanceScale();

private:

	TWeakObjectPtr<USphereComponent> idleRangePtr;

	TWeakObjectPtr<USphereComponent> awayRangePtr;

	TArray<TWeakObjectPtr<USphereComponent>> restRangePtr;//�����ݽŴ�

	TWeakObjectPtr<USkeletalMeshComponent> animalPtr;
	
	TWeakObjectPtr<APlayerController> savedPlayerCtrl;

	FTimerHandle timerHandle;
	float flyToCamDuration;
	bool isPlayerInRange;
	bool bBackToRest;
	ECollisionChannel posChannel;
};

