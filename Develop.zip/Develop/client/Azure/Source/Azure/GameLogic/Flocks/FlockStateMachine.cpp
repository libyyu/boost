#include "FlockStateMachine.h"
#include "TimerManager.h"
#include "AzureEntryPoint.h"
#include "components/SphereComponent.h"
#include "components/SkeletalMeshComponent.h"
#include "camera/CameraComponent.h"
#include "Kismet/KismetMathLibrary.h"
#include "kismet/GameplayStatics.h"
#include "curves/CurveFloat.h"
#include "Animation/AnimInstance.h"
#include "Azure.h"

AFlockStateMachine::AFlockStateMachine() :
	isBird(false),
	backDelayDuring(5.0f),
	escapeDuring(3.0f),
	backDuring(3.0f),
	restDuring(3.0f),
	cullingDistance(4000.0f),
	animalScale(1.0f),
	turnSpeed(0.1),
	probabilityOfFlyToCam(0.0f),
	flyToCamRange(30.0f, 80.0f),
	backCurve(nullptr),
	curState(ELogicFSMState::Flock_Idle),
	lastState(ELogicFSMState::Flock_Idle),
	stateDuring(0.0f),
	lastLoc(FVector::ZeroVector),
	awayCenter(FVector::ZeroVector),
	awayRadius(0.0f),
	nextAwayLoc(FVector::ZeroVector),
	idleCenter(FVector::ZeroVector),
	idleRadius(0.0f),
	nextIdleLoc(FVector::ZeroVector),
	lastEnable(true),
	lastCullScale(1.0f),
	enableByAmount(true),
	enableByWeather(true),
	idleRangePtr(nullptr),
	awayRangePtr(nullptr),
	animalPtr(nullptr),
	flyToCamDuration(0.0f),
	isPlayerInRange(false),
	bBackToRest(false),
	ZStart(1000.0f),
	ZEnd(-1000.0f)
{
	PrimaryActorTick.bCanEverTick = true;
	// ��������ȼ�������Tick���������ڶ�����ͼ��TaskGraph�߳�֮ǰִ��
	PrimaryActorTick.bHighPriority = true;
}

void AFlockStateMachine::BeginPlay()
{
	Super::BeginPlay();
	

	TArray<UActorComponent*> components;
	GetComponents(components);
	for (UActorComponent *oneComp : components)
	{
		const FString& compName = oneComp->GetName();
		if (compName == TEXT("IdleRange"))
		{
			idleRangePtr = Cast<USphereComponent>(oneComp);
		}
		else if (compName == TEXT("AwayRange"))
		{
			awayRangePtr = Cast<USphereComponent>(oneComp);
		}
		else if (compName == TEXT("Animal"))
		{
			animalPtr = Cast<USkeletalMeshComponent>(oneComp);
		}
		else if (compName.Contains(TEXT("RestRange")))
		{
			restRangePtr.AddUnique(Cast<USphereComponent>(oneComp));
		}
	}

	if (!idleRangePtr.IsValid() || !awayRangePtr.IsValid() || !animalPtr.IsValid())
	{
		UE_LOG(LogAzure, Error, TEXT("FlockStateMachine Error : Could not find range components"));
		this->SetActorTickEnabled(false);
		return;
	}

	curState = ELogicFSMState::Flock_Idle;
	EnterIdleState();

	animalPtr->SetCullDistance(cullingDistance);
	animalPtr->SetWorldScale3D(FVector::OneVector * animalScale);
}

void AFlockStateMachine::EndPlay(const EEndPlayReason::Type EndPlayReason)
{
	Super::EndPlay(EndPlayReason);

	idleRangePtr = nullptr;
	awayRangePtr = nullptr;
	animalPtr = nullptr;
	savedPlayerCtrl = nullptr;
}



void AFlockStateMachine::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);

	if (!idleRangePtr.IsValid()
		|| !awayRangePtr.IsValid())
		return;

	idleCenter = idleRangePtr->GetComponentLocation();
	idleRadius = idleRangePtr->GetScaledSphereRadius();

	awayCenter = awayRangePtr->GetComponentLocation();
	awayRadius = awayRangePtr->GetScaledSphereRadius();

	bool isShowFlock = true;
	isShowFlock = isShowFlock && GetFlocksEnable();
	isShowFlock = isShowFlock && CheckPlayerNear();

	if (lastEnable && !isShowFlock)
	{
		ShowHideFlocks(false);
	}
	else if (!lastEnable && isShowFlock)
	{
		ShowHideFlocks(true);
	}
	lastEnable = isShowFlock;

	if (!isShowFlock)
		return;

	GetFlocksCullDistanceScale();

	bool isDiffWithLast = curState != lastState;
	switch (curState)
	{
	case ELogicFSMState::Flock_Idle:
	{
		if (isDiffWithLast) EnterIdleState();
		UpdateIdleState(DeltaTime);

		if (isPlayerInRange)
		{
			float rand = UKismetMathLibrary::RandomFloat();
			if (rand < probabilityOfFlyToCam)
				curState = ELogicFSMState::Flock_FlyToCam;
			else
				curState = ELogicFSMState::Flock_Escape;
		}

		break;
	}

	case ELogicFSMState::Flock_Alert:
		break;

	case ELogicFSMState::Flock_Escape:
	{
		if (isDiffWithLast) EnterEscapeState();
		UpdateEscapeState(DeltaTime);
		break;
	}

	case ELogicFSMState::Flock_Away:
	{
		if (isDiffWithLast) EnterAwayState();
		UpdateAwayState(DeltaTime);

		if (!isPlayerInRange)	
		{
			if (backDelayDuring > 0.0f)
			{
				if (!timerHandle.IsValid())
				{
					GetWorldTimerManager().SetTimer(timerHandle, this, &AFlockStateMachine::OnBackDelay, backDelayDuring);
				}
			}
			else
				OnBackDelay();
		}
		if (isBird&&RestPointsOk()&&UKismetMathLibrary::RandomFloat() < probabilityOfBirdToRest)//�ڷ�Χ�������bird����ȥЪ��
		{
			bBackToRest = true;
			if (backDelayDuring > 0.0f)
			{
				if (!timerHandle.IsValid())
				{
					GetWorldTimerManager().SetTimer(timerHandle, this, &AFlockStateMachine::OnBackDelay, backDelayDuring);
				}
			}
			else
				OnBackDelay();
		}
		break;
	}

	case ELogicFSMState::Flock_FlyToCam:
	{
		if (isDiffWithLast) EnterFlyToCamState();
		UpdateFlyToCamState(DeltaTime);
		break;
	}

	case ELogicFSMState::Flock_Back:
	{
		if (isDiffWithLast) EnterBackState();
		UpdateBackState(DeltaTime);

		if (isPlayerInRange&&!bBackToRest)
		{
			curState = ELogicFSMState::Flock_Escape;
		}

		break;
	}

	case ELogicFSMState::Flock_Recover:
		break;
	case ELogicFSMState::Flock_Rest:
		if (isDiffWithLast) EnterRestState();
		UpdateRestState(DeltaTime);
		break;
	default:
		break;
	}
}

void AFlockStateMachine::EnterIdleState_Implementation()
{
	lastState = curState;
	stateDuring = 0.0f;
}

void AFlockStateMachine::UpdateIdleState_Implementation(float DeltaTime)
{
	//Ŀǰ��û���߼� ������
}

void AFlockStateMachine::EnterEscapeState_Implementation()
{
	if (!animalPtr.IsValid())
		return;

	FVector randV2d = (FMath::VRand() * FVector(1, 1, 0)).GetSafeNormal();
	nextAwayLoc = awayCenter + randV2d * awayRadius;

	lastState = curState;
	stateDuring = 0.0f;
	lastLoc = animalPtr->GetComponentLocation();
}

void AFlockStateMachine::UpdateEscapeState_Implementation(float DeltaTime)
{
	stateDuring += DeltaTime;

	float realEscapeDuring = FMath::Max(escapeDuring, 1.0f);

	if (!animalPtr.IsValid())
		return;

	if (stateDuring >= realEscapeDuring)
	{
		curState = ELogicFSMState::Flock_Away;
		animalPtr->SetWorldLocation(GetRayTracePos(nextAwayLoc));
	}
	else
	{
		FVector worldLoc = FMath::Lerp(lastLoc, nextAwayLoc, stateDuring / realEscapeDuring);

		FVector moveDir = (nextAwayLoc - lastLoc).GetSafeNormal();
		FVector lerpDir = FMath::Lerp(animalPtr->GetForwardVector(), moveDir, turnSpeed);
		FVector FloorPos = GetRayTracePos(worldLoc);
		FRotator Rot= UKismetMathLibrary::FindLookAtRotation(animalPtr->GetComponentLocation(),FloorPos);
		animalPtr->SetWorldLocationAndRotation(FloorPos, Rot);
			//animalPtr->SetWorldLocationAndRotation(worldLoc, lerpDir.Rotation());
	}
}

void AFlockStateMachine::EnterAwayState_Implementation()
{
	lastState = curState;
	stateDuring = 0.0f;
}

void AFlockStateMachine::UpdateAwayState_Implementation(float DeltaTime)
{
	//Ŀǰ��û���߼� ������
}

void AFlockStateMachine::EnterFlyToCamState_Implementation()
{
	lastState = curState;
	stateDuring = 0.0f;

	if (!animalPtr.IsValid())
		return;

	lastLoc = animalPtr->GetComponentLocation();

	FVector toPlayer = GetCameraPosition() - animalPtr->GetComponentLocation();
	float distance = toPlayer.Size();
	if (distance < 0.001f)
	{
		flyToCamDuration = 0.0f;
		return;
	}

	nextAwayLoc = (FMath::VRand() - FVector::ForwardVector) * FMath::RandRange(flyToCamRange.X, flyToCamRange.Y);
	flyToCamDuration = 1.0f;
}

void AFlockStateMachine::UpdateFlyToCamState_Implementation(float DeltaTime)
{
	if (stateDuring >= flyToCamDuration)
	{
		curState = ELogicFSMState::Flock_Escape;
	}
	else
	{
		if (!animalPtr.IsValid())
			return;

		const FTransform &camTrans = GetMainCameraTrans();

		FVector cameraAround = camTrans.TransformPosition(nextAwayLoc);
		FVector flyDir = (cameraAround - lastLoc).GetSafeNormal();

		FVector worldLoc = lastLoc + flyDir * 500.0f * DeltaTime;
		lastLoc = worldLoc;

		if ((worldLoc - cameraAround).IsNearlyZero(20.0f))
		{
			stateDuring = flyToCamDuration;
		}

		FRotator worldRot = UKismetMathLibrary::MakeRotFromX(cameraAround - lastLoc);
		FRotator lerpRot = UKismetMathLibrary::RLerp(animalPtr->GetComponentRotation(), worldRot, turnSpeed * 5.0f, true);
		FVector FloorPos = GetRayTracePos(worldLoc);
		FRotator Rot = UKismetMathLibrary::FindLookAtRotation(animalPtr->GetComponentLocation(), FloorPos);
		animalPtr->SetWorldLocationAndRotation(FloorPos, Rot);
		//	animalPtr->SetWorldLocationAndRotation(worldLoc, lerpRot);
	}
}


void AFlockStateMachine::EnterBackState_Implementation()
{
	if (!animalPtr.IsValid())
		return;

	FVector randV2d = (FMath::VRand() * FVector(1, 1, 0)).GetSafeNormal();
	if (bBackToRest) {//����Ϣ��
		int Index = UKismetMathLibrary::RandomInteger(restRangePtr.Num());
		nextIdleLoc = restRangePtr[Index]->GetComponentLocation() + randV2d *
			restRangePtr[Index]->GetScaledSphereRadius()*0.2f;
		lastState = curState;
		lastLoc = animalPtr->GetComponentLocation();
	}
	else {
		nextIdleLoc = idleCenter + randV2d * idleRadius * 0.2f;
	}
	lastState = curState;
	stateDuring = 0.0f;
	lastLoc = animalPtr->GetComponentLocation();
}

void AFlockStateMachine::UpdateBackState_Implementation(float DeltaTime)
{
	stateDuring += DeltaTime;

	if (!animalPtr.IsValid())
		return;

	float realBackDuring = FMath::Max(backDuring, 1.0f);
	if (stateDuring >= realBackDuring)
	{
		curState =bBackToRest?ELogicFSMState::Flock_Rest:ELogicFSMState::Flock_Idle;
		animalPtr->SetWorldLocation(GetRayTracePos(nextIdleLoc));
	}
	else
	{
		float timeFloat;
		if (::IsValid(backCurve))
		{
			timeFloat = backCurve->GetFloatValue(stateDuring / realBackDuring);
		}
		else
		{
			timeFloat = stateDuring / realBackDuring;
		}
		FVector worldLoc = FMath::Lerp(lastLoc, nextIdleLoc, timeFloat);

		if (isBird)
		{
			FRotator worldRot;
			if (timeFloat > 0.9f)
			{
				float lerpAlpha = FMath::Clamp((timeFloat - 0.9f) * 20.0f, 0.0f, 1.0f);

				FRotator oldRot = UKismetMathLibrary::MakeRotFromX(nextIdleLoc - lastLoc);
				FRotator newRot = UKismetMathLibrary::MakeRotFromYZ(animalPtr->GetRightVector(), FVector::UpVector);
				worldRot = UKismetMathLibrary::RLerp(oldRot, newRot, lerpAlpha, true);
			}
			else
			{
				worldRot = UKismetMathLibrary::MakeRotFromX(nextIdleLoc - lastLoc);
			}
			FRotator lerpRot = UKismetMathLibrary::RLerp(animalPtr->GetComponentRotation(), worldRot, turnSpeed, true);
			

			FVector FloorPos = GetRayTracePos(worldLoc);
			FRotator Rot = UKismetMathLibrary::FindLookAtRotation(animalPtr->GetComponentLocation(), FloorPos);
			animalPtr->SetWorldLocationAndRotation(FloorPos, Rot);
			//animalPtr->SetWorldLocationAndRotation(worldLoc, lerpRot);
		}
		else
		{
			FVector moveDir = (nextIdleLoc - lastLoc).GetSafeNormal();
			FVector lerpDir = FMath::Lerp(animalPtr->GetForwardVector(), moveDir, turnSpeed);

			FVector FloorPos = GetRayTracePos(worldLoc);
			FRotator Rot = UKismetMathLibrary::FindLookAtRotation(animalPtr->GetComponentLocation(), FloorPos);
			animalPtr->SetWorldLocationAndRotation(FloorPos, Rot);
				//animalPtr->SetWorldLocationAndRotation(worldLoc, lerpDir.Rotation());
		}
	}
}

void AFlockStateMachine::EnterRestState_Implementation()
{
	stateDuring = 0.0f;
	lastState = curState;
	bBackToRest = false;
	lastLoc = animalPtr->GetComponentLocation();
}

void AFlockStateMachine::UpdateRestState_Implementation(float DeltaTime)
{
	stateDuring += DeltaTime;

	float realRestDuring = FMath::Max(restDuring, 1.0f);
	if (stateDuring >= realRestDuring)
	{
		curState = ELogicFSMState::Flock_Idle;
		animalPtr->SetWorldLocation(GetRayTracePos(nextIdleLoc));
	}

}

void AFlockStateMachine::SetAnimBoolProperty(bool value, const FString &propertyName)
{
	UAnimInstance *animBP = animalPtr.IsValid() ? animalPtr->GetAnimInstance() : nullptr;
	UBoolProperty *prop = animBP ? FindField<UBoolProperty>(animBP->GetClass(), *propertyName) : nullptr;
	if (prop)
	{
		prop->SetPropertyValue_InContainer(animBP, value);
	}
}

void AFlockStateMachine::SetAnimIntProperty(int32 value, const FString &propertyName)
{
	UAnimInstance *animBP = animalPtr.IsValid() ? animalPtr->GetAnimInstance() : nullptr;
	UIntProperty *prop = animBP ? FindField<UIntProperty>(animBP->GetClass(), *propertyName) : nullptr;
	if (prop)
	{
		prop->SetPropertyValue_InContainer(animBP, value);
	}
}

FVector AFlockStateMachine::GetRayTracePos(FVector loc)
{
	FVector RealLocation = loc;
	FHitResult result;
	GetWorld()->LineTraceSingleByChannel(result, FVector(loc.X, loc.Y, loc.Z + ZStart), 
		FVector(loc.X, loc.Y, loc.Z + ZEnd), 
		ECollisionChannel::ECC_GameTraceChannel3);
	if (result.bBlockingHit)
		RealLocation.Z = result.Location.Z;
	return RealLocation;
}



AActor * AFlockStateMachine::GetHostPlayer()
{
	AActor *hostPlayer = AAzureEntryPoint::Instance ? AAzureEntryPoint::Instance->GetHostRootActor() : nullptr;
	if (::IsValid(hostPlayer))
	{
		return hostPlayer;
	}
	else
	{
		return UGameplayStatics::GetPlayerPawn(this, 0);
	}
}

FVector AFlockStateMachine::GetCameraPosition()
{
	APlayerController* playerController = AAzureEntryPoint::Instance ? AAzureEntryPoint::Instance->GetPlayerController() : nullptr;
#if WITH_EDITOR
	if (!::IsValid(playerController))
	{
		if (GetWorld() && GetWorld()->GetGameInstance())
		{
			playerController = GetWorld()->GetGameInstance()->GetFirstLocalPlayerController();
		}
	}
#endif

	FVector cameraLoc;
	FRotator cameraRot;
	if (::IsValid(playerController))
	{
		playerController->GetPlayerViewPoint(cameraLoc, cameraRot);
	}

	return cameraLoc;
}

FTransform AFlockStateMachine::GetMainCameraTrans()
{
	if (!savedPlayerCtrl.IsValid())
	{
		savedPlayerCtrl = UGameplayStatics::GetPlayerController(this, 0);
	}

	FVector CameraPosition;
	FRotator CameraRotation;
	savedPlayerCtrl->GetPlayerViewPoint(CameraPosition, CameraRotation);

	return FTransform(CameraRotation, CameraPosition);
}

void AFlockStateMachine::OnBackDelay()
{
	if (!this->IsValidLowLevel()) return;

	curState = ELogicFSMState::Flock_Back;
	timerHandle.Invalidate();
}

bool AFlockStateMachine::RestPointsOk()
{
	bool ret = restRangePtr.Num() > 0;
	for (auto Ptr : restRangePtr) 
	{
		ret = ret && Ptr.IsValid();
	}
	return ret;
}

void AFlockStateMachine::ShowHideFlocks(bool isShow)
{
	if (animalPtr.IsValid())
	{
		animalPtr->SetVisibility(isShow);
		animalPtr->bNoSkeletonUpdate = !isShow;
		animalPtr->SetComponentTickEnabled(isShow);
	}
}

void AFlockStateMachine::RefreshCullDistance(float cullScale)
{
	if (animalPtr.IsValid())
	{
		animalPtr->SetCullDistance(cullingDistance * cullScale);
	}
}

bool AFlockStateMachine::CheckPlayerNear()
{
	if (!GetHostPlayer()) return false;

	FVector curPlayerPos = GetHostPlayer()->GetActorLocation();
	float realDistance = FVector::DistSquared(curPlayerPos, idleCenter);

	if (realDistance >= cullingDistance * cullingDistance)
	{
		isPlayerInRange = false;
		return false;
	}
	else
	{
		isPlayerInRange = realDistance <= (idleRadius * idleRadius);
		return true;
	}
}

bool AFlockStateMachine::GetFlocksEnable()
{
	if (!enableByAmount || !enableByWeather)
	{
		if (lastEnable)
		{
			ShowHideFlocks(false);
			lastEnable = false;
		}
		return false;
	}

	static const IConsoleVariable* CVar = IConsoleManager::Get().FindConsoleVariable(TEXT("azure.Flocks"));

	bool isEnable = true;
	if (CVar != nullptr)
	{
		isEnable = (CVar->GetInt() == 1);
	}

	return isEnable;
}

void AFlockStateMachine::GetFlocksCullDistanceScale()
{
	static const IConsoleVariable* CVar = IConsoleManager::Get().FindConsoleVariable(TEXT("azure.FlocksCullDistanceScale"));

	float cullScale = 1.0f;
	if (CVar != nullptr)
	{
		cullScale = CVar->GetFloat();
	}

	if (!FMath::IsNearlyEqual(lastCullScale, cullScale, 0.0001f))
	{
		RefreshCullDistance(cullScale);
		lastCullScale = cullScale;
	}
}

