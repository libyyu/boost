﻿
#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "ParabolaEffect.generated.h"


UCLASS(Blueprintable, BlueprintType)

class AZURE_API AParabolaEffect : public AActor
{
	GENERATED_BODY()

public:
	// Attach the end to another component
	UFUNCTION(BlueprintImplementableEvent, BlueprintCallable, Category = "ParabolaEffect")
	void SetParameters(const FVector& Velocity, const float G, const float ElapsedTime);

	UFUNCTION(BlueprintImplementableEvent, BlueprintCallable, Category = "ParabolaEffect")
	void SetEnabled(bool bEnable);

	UFUNCTION(BlueprintImplementableEvent, BlueprintCallable, Category = "ParabolaEffect")
	void SetScalarProperty(FName PropertyName, float Value);

	UFUNCTION(BlueprintImplementableEvent, BlueprintCallable, Category = "ParabolaEffect")
	void SetVectorProperty(FName PropertyName, FVector4 Value);
};
