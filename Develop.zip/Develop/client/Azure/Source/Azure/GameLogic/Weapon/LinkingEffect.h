﻿
#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "LinkingEffect.generated.h"


UCLASS(Blueprintable, BlueprintType)

class AZURE_API ALinkingEffect : public AActor
{
	GENERATED_BODY()

public:
	// Attach the end to another component
	UFUNCTION(BlueprintImplementableEvent, BlueprintCallable, Category = "LinkingEffect")
		void AttachTo(USceneComponent* Component, FName SocketName, FVector RelativeLocation);

	UFUNCTION(BlueprintImplementableEvent, BlueprintCallable, Category = "LinkingEffect")
		void AttachToWorld(FVector WorldLocation);

	// Detach the end to world position
	UFUNCTION(BlueprintImplementableEvent, BlueprintCallable, Category = "LinkingEffect")
		void Detach();

	UFUNCTION(BlueprintImplementableEvent, BlueprintCallable, Category = "LinkingEffect")
		void SetScalarProperty(FName PropertyName, float Value);

	UFUNCTION(BlueprintImplementableEvent, BlueprintCallable, Category = "LinkingEffect")
		void SetVectorProperty(FName PropertyName, FVector4 Value);
};
