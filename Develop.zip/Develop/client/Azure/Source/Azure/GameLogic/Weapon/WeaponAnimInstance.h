// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "GameLogic/AnimRelated/BaseAnimInstance.h"
#include "WeaponAnimInstance.generated.h"

/**
 * 
 */
UCLASS()
class AZURE_API UWeaponAnimInstance : public UBaseAnimInstance
{
	GENERATED_BODY()
	
public:
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "UI", meta = (AllowPrivateAccess = "true"))
	bool IsUI;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Animation", meta = (AllowPrivateAccess = "true"))
	bool IsOpen;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Animation", meta = (AllowPrivateAccess = "true"))
	int32 OpenTypeIndex;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Animation", meta = (AllowPrivateAccess = "true"))
	bool IsSkipAnim;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Appearance", meta = (AllowPrivateAccess = "true"))
	int32 AppearanceTypeIndex;

public:
	UFUNCTION(Category = "UI")
	void SetIsUI(const bool InIsUI);

	UFUNCTION(BlueprintNativeEvent, Category = "Animation")
	void OnSetIsUI();
	void OnSetIsUI_Implementation() {};

	UFUNCTION(Category = "Animation")
	void Open(const int32 InOpenTypeIndex, const bool InIsSkipAnim);

	UFUNCTION(BlueprintNativeEvent, Category = "Animation")
	void OnOpen();
	void OnOpen_Implementation() {};

	UFUNCTION(Category = "Animation")
	void Close();

	UFUNCTION(BlueprintNativeEvent, Category = "Animation")
	void OnClose();
	void OnClose_Implementation() {};

	UFUNCTION(Category = "Appearance")
	void ChangeAppearance(const int32 InAppearanceTypeIndex);

	UFUNCTION(BlueprintNativeEvent, Category = "Appearance")
	void OnChangeAppearance();
	void OnChangeAppearance_Implementation() {};
};
