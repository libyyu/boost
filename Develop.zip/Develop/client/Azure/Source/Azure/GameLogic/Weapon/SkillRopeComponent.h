// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Components/SceneComponent.h"
#include "AttachableCable.h"
#include "SkillRopeComponent.generated.h"


UCLASS( ClassGroup=(Custom), meta=(BlueprintSpawnableComponent) )
class AZURE_API USkillRopeComponent : public USceneComponent
{
	GENERATED_BODY()

public:	
	// Sets default values for this component's properties
	USkillRopeComponent();

protected:
	// Called when the game starts
	virtual void BeginPlay() override;

public:	
	// Called every frame
	virtual void TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction) override;

	UFUNCTION()
		void SetEnabled(bool bEnabled);

	UFUNCTION()
		void SetAttachEndTo(AActor* Actor, FName ComponentProperty, FName SocketName);
	//
	//	// Actor ������λ�úͳ���ΪHead,��ʱ����ҪSetAttachHeadTo
		/*UFUNCTION(BlueprintNativeEvent, BlueprintCallable, Category = "Cable")
			void SetAttachHeadTo(AActor* Actor, FName ComponentProperty, FName SocketName);*/
	UFUNCTION()
		void DetachEnd();

	UFUNCTION()
		void SetCableLength(float Length);
	//
	UFUNCTION()
		void Reset();

	UFUNCTION()
		void Play(FVector _destPos , float _speed , float _backSpeed , float _lockTime);

	UFUNCTION()
		void InitCable(AAttachableCable* cable);

	UFUNCTION()
	void SetUseScaleTime(bool bUse) { UseScaleTime = bUse; }

	void updatePosition(float DeltaTime);

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		TWeakObjectPtr<AAttachableCable> attachableCable;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		FVector destPos;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		float speed;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		float backSpeed;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		float LockTime;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	FVector dir;
	
		
	enum CableState
	{
		Stop = 0,
		Forward = 1,
		Lock = 2,
		Backward = 3,
	};

	CableState state;

	bool UseScaleTime = false;

	double CurrentTime;

	/** Last absolute real time that we ticked */
	double LastTickTime;

	float LockTimeLeft;
};
