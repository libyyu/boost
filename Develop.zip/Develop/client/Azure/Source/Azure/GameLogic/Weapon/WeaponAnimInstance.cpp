// Fill out your copyright notice in the Description page of Project Settings.

#include "WeaponAnimInstance.h"

void UWeaponAnimInstance::SetIsUI(const bool InIsUI)
{
	IsUI = InIsUI;
	OnSetIsUI();
}

void UWeaponAnimInstance::Open(const int32 InOpenTypeIndex, const bool InIsSkipAnim)
{
	IsOpen = true;
	OpenTypeIndex = InOpenTypeIndex;
	IsSkipAnim = InIsSkipAnim;
	OnOpen();
}

void UWeaponAnimInstance::Close()
{
	IsOpen = false;
	OpenTypeIndex = 0;
	IsSkipAnim = false;
	OnClose();
}

void UWeaponAnimInstance::ChangeAppearance(const int32 InAppearanceTypeIndex)
{
	AppearanceTypeIndex = InAppearanceTypeIndex;
	OnChangeAppearance();
}