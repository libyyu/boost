// Fill out your copyright notice in the Description page of Project Settings.

#include "SkillRopeComponent.h"
#include "AttachableCable.h"

// Sets default values for this component's properties
USkillRopeComponent::USkillRopeComponent()
{
	// Set this component to be initialized when the game starts, and to be ticked every frame.  You can turn these features
	// off to improve performance if you don't need them.
	PrimaryComponentTick.bCanEverTick = true;



	state = Stop;
	attachableCable = nullptr;
	// ...
}


// Called when the game starts
void USkillRopeComponent::BeginPlay()
{
	Super::BeginPlay();
}


// Called every frame
void USkillRopeComponent::TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction)
{
// 	CurrentTime = FPlatformTime::Seconds();
// 	if (!UseScaleTime)
// 	{
// 		DeltaTime = CurrentTime - LastTickTime;
// 	}
// 	LastTickTime = CurrentTime;

	Super::TickComponent(DeltaTime, TickType, ThisTickFunction);

	updatePosition(DeltaTime);
}

void USkillRopeComponent::updatePosition(float DeltaTime)
{
	if (this->GetOwner() == nullptr || attachableCable == nullptr || state == Stop || attachableCable.Get() == nullptr)
	{
		return;
	}
	FVector nowPos = attachableCable->GetActorLocation();
	FVector newPos = nowPos;
	float deltaLength = 0.f;
	float length = 0.f;
	if (state == Forward)
	{
		deltaLength = speed * DeltaTime;
		float leftDist = (destPos - nowPos).Size();
		newPos = nowPos + dir * deltaLength;
		FVector delta = destPos - newPos;
		length = delta.Size();
		if ((length < 0.01f ) || (leftDist <= deltaLength))
		{
			newPos = destPos;
			if (LockTime > 0.001)
			{
				state = Lock;
			} 
			else
			{
				state = Backward;
			}
			length = 0.f;
		}
		//attachableCable->SetActorLocation(newPos);
	} 
	else if (state == Backward)
	{
		deltaLength = backSpeed * DeltaTime;
		FVector nowActorPos = GetComponentLocation();
		newPos = nowPos + dir * deltaLength;
		FVector delta = nowPos - nowActorPos;
		length = delta.Size();
		if (length < 0.01f || length <= deltaLength)
		{
			newPos = nowActorPos;
			state = Stop;
			length = 0.f;

			Reset();
		}
		else
		{
			delta.Normalize();
			newPos = nowPos - delta * deltaLength;
		}
		//attachableCable->SetActorLocation(newPos);
	}
	else
	{
		LockTimeLeft -= DeltaTime;
		if (LockTimeLeft <= 0.001f)
		{
			state = Backward;
		}
// 		FVector nowActorPos = GetComponentLocation();
// 		FVector delta = nowPos - nowActorPos;
// 		length = delta.Size();
	}
	//attachableCable->SetCableLength(length * 0.0001 * 0.5);
	attachableCable->SetActorLocation(newPos);
}

void USkillRopeComponent::SetEnabled(bool bEnabled)
{
	if (attachableCable == nullptr || attachableCable.Get() == nullptr)
	{
		return;
	}
	attachableCable->SetEnabled(bEnabled);
}

void USkillRopeComponent::SetAttachEndTo(AActor* Actor, FName ComponentProperty, FName SocketName)
{
	if (attachableCable == nullptr || attachableCable.Get() == nullptr)
	{
		return;
	}
	attachableCable->SetAttachEndTo(Actor, ComponentProperty, SocketName);
}

void USkillRopeComponent::DetachEnd()
{
	if (attachableCable == nullptr || attachableCable.Get() == nullptr)
	{
		return;
	}
	attachableCable->DetachEnd();
}

void USkillRopeComponent::SetCableLength(float Length)
{
	if (attachableCable == nullptr || attachableCable.Get() == nullptr)
	{
		return;
	}
	attachableCable->SetCableLength(Length);
}

void USkillRopeComponent::Reset()
{
	if (attachableCable == nullptr || attachableCable.Get() == nullptr)
	{
		return;
	}
	state = Stop;
	speed = 0;
	backSpeed = 0;
	LockTimeLeft = 0;
	LockTime = 0;
	attachableCable->SetActorLocation(GetComponentLocation());
	attachableCable->Reset();
	attachableCable->SetEnabled(false);
}

void USkillRopeComponent::Play(FVector _destPos, float _speed, float _backSpeed,  float _lockTime)
{
	if (this->GetOwner() == nullptr || attachableCable == nullptr || attachableCable.Get() == nullptr)
	{
		return;
	}

	Reset();

	destPos = _destPos;
	speed = _speed;
	backSpeed = _backSpeed;
	LockTimeLeft = _lockTime;
	LockTime = _lockTime;

	FVector startPos = GetComponentLocation();
	FVector delta = _destPos - startPos;
	float length = delta.Size();
	if (length > 0.01f)
	{
		delta.Normalize();
		dir = delta;
	} 
	else
	{
		dir = FVector::ForwardVector;
		length = 1.f;
	}
	//attachableCable->SetAttachEndTo(this->GetOwner(),"MainMeshComponent","RopeRoot");
	attachableCable->SetCableLength(0.1);
	attachableCable->SetActorLocation(startPos);
	attachableCable->SetActorRotation(dir.ToOrientationQuat());
	attachableCable->Reset();
	attachableCable->SetEnabled(true);
	state = Forward;
}

void USkillRopeComponent::InitCable(AAttachableCable* cable)
{
	attachableCable = cable;
	attachableCable->AddTickPrerequisiteComponent(this);
}

