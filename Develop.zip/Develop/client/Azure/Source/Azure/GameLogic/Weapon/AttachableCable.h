﻿
#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "AttachableCable.generated.h"


UCLASS(Blueprintable, BlueprintType)

class AZURE_API AAttachableCable : public AActor
{
	GENERATED_BODY()

		// Add interface functions to this class. This is the class that will be inherited to implement this interface.
public:
	UFUNCTION(BlueprintImplementableEvent, BlueprintCallable, Category = "Cable")
		void SetEnabled(bool bEnabled);

	
	UFUNCTION(BlueprintImplementableEvent, BlueprintCallable, Category = "Cable")
		void SetAttachEndTo(AActor* Actor, FName ComponentProperty, FName SocketName);
	UFUNCTION(BlueprintImplementableEvent, BlueprintCallable, Category = "Cable")
		void SetEndRelativeLocation(FVector Location);
//	// Actor 本身的位置和朝向即为Head,暂时不需要SetAttachHeadTo
	/*UFUNCTION(BlueprintNativeEvent, BlueprintCallable, Category = "Cable")
		void SetAttachHeadTo(AActor* Actor, FName ComponentProperty, FName SocketName);*/
	UFUNCTION(BlueprintImplementableEvent, BlueprintCallable, Category = "Cable")
		void DetachEnd();

	UFUNCTION(BlueprintImplementableEvent, BlueprintCallable, Category = "Cable")
		void SetCableLength(float Length);
//
	UFUNCTION(BlueprintImplementableEvent, BlueprintCallable, Category = "Cable")
		void Reset();


};
