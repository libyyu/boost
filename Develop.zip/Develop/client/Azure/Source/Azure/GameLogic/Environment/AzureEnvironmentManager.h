﻿// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
// #if UE_GAME
// #include "Azure.h"
// #endif
// #if WITH_EDITOR
// #include "Editor/AzureEditor/AzureEditor.h"
// #endif
#include "AzureObjectComponent.h"
#include "Public/TimerManager.h"
#include "Runtime/Engine/Classes/Engine/AzureEnvironment.h"
#include "Runtime/Engine/Classes/Curves/CurveFloat.h"
#include "Runtime/Engine/Classes/Curves/CurveVector.h"
#include "Runtime/Engine/Classes/Curves/CurveLinearColor.h"
#include "Runtime/Engine/Classes/Engine/ExponentialHeightFog.h"
#include "Runtime/Engine/Classes/Engine/DirectionalLight.h"
#include "Runtime/Engine/Classes/Engine/PointLight.h"
#include "Runtime/Engine/Classes/Engine/PostProcessVolume.h"
#include "Runtime/Engine/Classes/Animation/AnimInstance.h"
#include "Runtime/Engine/Classes/Kismet/GameplayStatics.h"
#include "Runtime/Engine/Classes/Components/StaticMeshComponent.h"
#include "Runtime/Engine/Classes/Components/DirectionalLightComponent.h"
#include "Runtime/Engine/Classes/Components/LightComponent.h"
#include "Runtime/Engine/Classes/Components/ExponentialHeightFogComponent.h"
#include "Runtime/Engine/Classes/Components/PointLightComponent.h"
#include "Runtime/Engine/Public/EngineUtils.h"
#include "Runtime/Landscape/Classes/LandscapeProxy.h"
#include "Runtime/Engine/Classes/Materials/MaterialInstanceDynamic.h"
#include "UObject/StrongObjectPtr.h"

#include "Engine/TextureRenderTarget.h"
#include "Engine/WindDirectionalSource.h"
#include "Components/WindDirectionalSourceComponent.h"

#include "AzureEnvironmentDefine.h"
#include "AzureEnvironmentPreset.h"
#include "AzureEnvironmentWind.h"
#include "AzureRefSky.h"
#include "AzureLensFlare.h"

#include "AzureEnvironmentManager.generated.h"

DECLARE_LOG_CATEGORY_EXTERN(LogAzureEnvironmentManager, Log, All);

class AAzureRefSky;
class AExponentialHeightFog;
class ADirectionalLight;
class APointLight;
class AStaticMeshActor;
class ALandscapeProxy;
class AEmitter;
class AAzureLensFlare;
class APostProcessVolume;
class AWindDirectionalSource;

class UMaterialInstanceDynamic;
class UMaterialInstanceConstant;
class UMaterialParameterCollection;

class UAzureEnvironmentPreset;
class AAzureEnvironmentActor;
class AAzureEnvironmentVolume;

UENUM(BlueprintType)
enum class EAzureEnvironmentTransitionType :uint8
{
	Time = 0,
	Distance
};

UCLASS(Blueprintable)
class AZURE_API UAzureEnvironmentTransition : public UObject
{
	GENERATED_BODY()

public:
	bool bEnable = false;
	bool bVolume = false;
	bool bDelay = false;
	EAzureEnvironmentTransitionType Type;

	float Alpha = 0;
	float Duration = 0;
	FVector Center = FVector::ZeroVector;
	FVector Extent = FVector::ZeroVector;
	float Distance = 0;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Preset")
	UAzureEnvironmentPreset* Preset;

public:
	void Update(const FVector& CameraPos, float DeltaTime);
};

UCLASS(Blueprintable, BlueprintType)
class AZURE_API AAzureEnvironmentManager : public AInfo
{
	GENERATED_BODY()

	static TSet<AAzureEnvironmentManager *> s_insts;
	static TSet<AAzureEnvironmentVolume *> s_AllEnvVolumes;

public:
	AAzureEnvironmentManager();
	virtual ~AAzureEnvironmentManager();

	virtual bool ShouldTickIfViewportsOnly() const override;
	virtual void OnConstruction(const FTransform& Transform) override;

protected:
	virtual void BeginPlay() override;
	virtual void EndPlay(const EEndPlayReason::Type EndPlayReason) override;

public:
	bool IsDayTime();

public:
	virtual void Tick(float DeltaTime) override;
	
public:
	void Init();
	void Clear();
	void Reset();

protected:
	void InitResources();
	void InitSunProperties();
	void InitMoonProperties();
	void InitWindProperties();
	void InitFogProperties();
	void InitGrassProperties();

public:
	void Update(float DeltaTime);

protected:
	void UpdateTimeOfDay(float DeltaTime);
	void UpdateCameraPos(float DeltaTime);
	void UpdatePresetData(float DeltaTime);
	void UpdateWeather(float DeltaTime);
	void UpdateShelter(float DeltaTime);

	void UpdateSunProperties(float DeltaTime);
	void UpdateMoonProperties(float DeltaTime);
	void UpdateStarProperties(float DeltaTime);
	void UpdateCloudProperties(float DeltaTime);
	void UpdateSkyProperties(float DeltaTime);
	void UpdateFogProperties(float DeltaTime);
	void UpdateWindProperties(float DeltaTime);
	void UpdateRainProperties(float DeltaTime);
	void UpdateSnowProperties(float DeltaTime);
	void UpdateGrassProperties(float DeltaTime);
	void UpdateLightningProperties(float DeltaTime);
	void UpdateBloomProperties(float DeltaTime);
	void UpdateBackgroundProperties(float DeltaTime);
	void UpdateCharacterProperties(float DeltaTime);
	void UpdateBuildingProperties(float DeltaTime);
	void UpdatePointLightProperties(float DeltaTime);
	void UpdateNightEmissiveProperties(float DeltaTime);
	void UpdatePostColorProperties(float DeltaTime);
	void UpdateOceanProperties(float DeltaTime);
	void UpdateSpecularIBLScaleProperties(float DeltaTime);
	void UpdateAmbientProperties(float DeltaTime);
	void UpdateAuroraProperties(float DeltaTime);
	void UpdateShootingstarProperties(float DeltaTime);
	void UpdateRainBowProperties(float DeltaTime);
	void UpdateCometProperties(float DeltaTime);

public:
	void Apply(float DeltaTime);
	static  TSet<AAzureEnvironmentManager *>& GetAllInstances() { return s_insts; }
	static  TSet<AAzureEnvironmentVolume *>& GetAllEnvVolumeInstances() { return s_AllEnvVolumes; }
	void GetDirectionalLights(TSet<ADirectionalLight*>& OutDirectionalLights);

protected:
	void ApplySunProperties(float DeltaTime);
	void ApplyMoonProperties(float DeltaTime);
	void ApplyStarProperties(float DeltaTime);
	void ApplyCloudProperties(float DeltaTime);
	void ApplySkyProperties(float DeltaTime);
	void ApplyFogProperties(float DeltaTime);
	void ApplyWindProperties(float DeltaTime);
	void ApplyRainProperties(float DeltaTime);
	void ApplySnowProperties(float DeltaTime);
	void ApplyGrassProperties(float DeltaTime);
	void ApplyBloomProperties(float DeltaTime);
	void ApplyLightningProperties(float DeltaTime);
	void ApplyBackgroundProperties(float DeltaTime);
	void ApplyCharacterProperties(float DeltaTime);
	void ApplyBuildingProperties(float DeltaTime);
	void ApplyPointLightProperties(float DeltaTime);
	void ApplyNightEmissiveProperties(float DeltaTime);
	void ApplyPostColorProperties(float DeltaTime);
	void ApplyOceanProperties(float DeltaTime);
	void ApplySpecularIBLScaleProperties(float DeltaTime);
	void ApplyAmbientProperties(float DeltaTime);
	void ApplyAuroraProperties(float DeltaTime);
	void ApplyShootingStarProperties(float DeltaTime);
	void ApplyRainBowProperties(float DeltaTime);
	void ApplyCometProperties(float DeltaTime);

public:
	UFUNCTION(BlueprintCallable)
		void Active();
	UFUNCTION(BlueprintCallable)
		void Deactive();

	UFUNCTION(BlueprintCallable)
		UAzureEnvironmentPreset* GetPreset(TSubclassOf<UAzureEnvironmentPreset> Class);
	UFUNCTION(BlueprintCallable)
		UAzureEnvironmentPreset* GetActivePreset();

	UFUNCTION(BlueprintCallable)
		int GetWeather();
	UFUNCTION(BlueprintCallable)
		void ChangeWeather(int Index);

	UFUNCTION(BlueprintCallable)
		void PushPreset(UAzureEnvironmentPreset* Preset, float Duration, bool bDelay = false);
	UFUNCTION(BlueprintCallable)
		void PushTransition(UAzureEnvironmentTransition* Transition);
	UFUNCTION(BlueprintCallable)
		void PopPreset(UAzureEnvironmentPreset* Preset, float Duration, bool bDelay = false);
	UFUNCTION(BlueprintCallable)
		void PopTransition(UAzureEnvironmentTransition* Transition);

	UFUNCTION(BlueprintCallable)
		void AddSimuWindAzureComp(UAzureObjectComponent* Comp);
	UFUNCTION(BlueprintCallable)
		void RemoveSimuWindAzureComp(UAzureObjectComponent* Comp);
	UFUNCTION(BlueprintCallable)
		void ClearSimuWindAzureComps();
	UFUNCTION(BlueprintCallable)
		void TickSimuWindAzureComps(float DeltaTime);
// 	UFUNCTION(BlueprintCallable)
// 		void TickAurora(float DeltaTime);
	UFUNCTION(BlueprintCallable)
		void TickHighFrequency(float DeltaTime);

	UFUNCTION(BlueprintCallable)
		void Dump();
	UFUNCTION(BlueprintCallable)
		void DumpPreset(int id);
	UFUNCTION(BlueprintCallable)
	void InitAurora();
	UFUNCTION(BlueprintCallable)
	void InitShootingstar();
	UFUNCTION(BlueprintCallable)
	void InitAllAurora();

	UFUNCTION(BlueprintCallable)
	void InitRainBow();

	UFUNCTION(BlueprintCallable)
	void InitAllRainBow();

	UFUNCTION(BlueprintCallable)
	void InitComet();


	UFUNCTION(BlueprintImplementableEvent, Category = "EnvironmentManager")
	void OnParameterChanged(float DeltaTime);

	void OnParameterChanged_Implementation(float DeltaTime){}

public:
	void LoadFromPreset(UAzureEnvironmentPreset* Preset);
	void SaveToPreset(UAzureEnvironmentPreset* Preset);

protected:
#if WITH_EDITORONLY_DATA
	class FEnvironmentTickHandler* EnvironmentTickHandler;
#endif

	UPROPERTY(Transient)
		TArray<UAzureEnvironmentTransition*> Transitions;

	UPROPERTY(Transient)
		UAzureEnvironmentTransition* CurrentWeather = nullptr;
	UPROPERTY(Transient)
		int CurrentWeatherIndex = -1;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Camera")
		FVector CameraLocation = FVector::ZeroVector;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Camera")
		FRotator CameraRotation = FRotator::ZeroRotator;

public:
	UPROPERTY(Transient)
		float TickInterval = 1 / 15.0f;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Interp, Category = "Time", meta = (UIMin = "0", UIMax = "24", ClampMin = "0", ClampMax = "24"))
		float TimeOfDay = 9;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Interp, Category = "Time")
		float TimeScale = 3600;

#if WITH_EDITORONLY_DATA
	UPROPERTY(Transient, EditAnywhere, BlueprintReadWrite, Category = "Edit")
		TSubclassOf<UAzureEnvironmentPreset> EditingPreset;

	UPROPERTY(Transient, EditAnywhere, BlueprintReadWrite, Category = "Edit")
		bool bBakePreview = false;
#endif

// 	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Category = "Tick")
// 		float TickNormalRate;
// 	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Category = "Tick")
// 		float TickChangeRate;

	UPROPERTY(EditInstanceOnly, BlueprintReadWrite, Category = "Environment")
		bool bEnable = true;
	UPROPERTY(EditInstanceOnly, BlueprintReadWrite, Category = "Environment")
		bool bUpdate = true;
	UPROPERTY(EditInstanceOnly, BlueprintReadWrite, Category = "Environment")
		bool bApply = true;
	UPROPERTY(EditInstanceOnly, BlueprintReadWrite, Category = "Environment")
		bool bIsPhotoMode = false;
	UPROPERTY(EditInstanceOnly, BlueprintReadWrite, Category = "Environment")
		AAzureRefSky* Sky = nullptr;
	UPROPERTY(EditInstanceOnly, BlueprintReadWrite, Category = "Environment")
		AExponentialHeightFog* Fog = nullptr;
	UPROPERTY(EditInstanceOnly, BlueprintReadWrite, Category = "Environment")
		AExponentialHeightFog* UnderWaterFog = nullptr;
	UPROPERTY(EditInstanceOnly, BlueprintReadWrite, Category = "Environment")
		AAzureLensFlare* SunFlare = nullptr;
	UPROPERTY(EditInstanceOnly, BlueprintReadWrite, Category = "Environment")
		bool bUpdateLightDirection = false;
	UPROPERTY(EditInstanceOnly, BlueprintReadWrite, Category = "Environment")
		TArray<ADirectionalLight*> SunLightSource;
	UPROPERTY(EditInstanceOnly, BlueprintReadWrite, Category = "Environment")
		ADirectionalLight* MoonLightSource = nullptr;
	UPROPERTY(EditInstanceOnly, BlueprintReadWrite, Category = "Environment")
		bool bWindTestMode = false;
	UPROPERTY(EditInstanceOnly, BlueprintReadWrite, Category = "Environment")
		AWindDirectionalSource* WindSource;
	UPROPERTY(EditInstanceOnly, BlueprintReadWrite, Category = "Environment")
		UCurveFloat* WindForceMulCurve;
	UPROPERTY(EditInstanceOnly, BlueprintReadWrite, Category = "Environment")
		UCurveFloat* WindForceAddCurve;
	
	UPROPERTY(EditInstanceOnly, BlueprintReadWrite, Category = "Environment")
		FBox FogMapBounds;
	UPROPERTY(EditInstanceOnly, BlueprintReadWrite, Category = "Environment")
		FBox GrassBlockBounds;
	UPROPERTY(EditInstanceOnly, BlueprintReadWrite, Category = "Environment")
		int GrassBlockInMap = 1;
 	UPROPERTY(EditInstanceOnly, BlueprintReadWrite, Category = "Environment")
 		TArray<APostProcessVolume*> PostProcessVolumesBloom;
	UPROPERTY(EditInstanceOnly, BlueprintReadWrite, Category = "Environment")
		TArray<APostProcessVolume*> PostProcessVolumesIndirectLight;
	UPROPERTY(EditInstanceOnly, BlueprintReadWrite, Category = "Environment")
		TArray<APostProcessVolume*> PostProcessVolumesPostColor;

	UPROPERTY()
		UMaterialParameterCollection* EnvironmentParam = nullptr;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Environment")
		TSubclassOf<UAzureEnvironmentPreset> DefaultPreset;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Environment")
		TArray<TSubclassOf<UAzureEnvironmentPreset>> WeatherPresets;
	UPROPERTY(Transient)
		EBasicWeather Weather = EBasicWeather::Normal;

	UPROPERTY(Transient, EditAnywhere, BlueprintReadWrite, Category = "Sky")
		FLinearColor SkyUpperColor;
	UPROPERTY(Transient, EditAnywhere, BlueprintReadWrite, Category = "Sky")
		FLinearColor SkyLowerColor;
	UPROPERTY(Transient, EditAnywhere, BlueprintReadWrite, Category = "Sky")
		float SkyFogDensity;
	UPROPERTY(Transient, EditAnywhere, BlueprintReadWrite, Category = "Sky")
		float SkyLightBrightness = 0;
	UPROPERTY(Transient, EditAnywhere, BlueprintReadWrite, Category = "Sky")
		float HorizonTilt = 0;
	UPROPERTY(Transient, EditAnywhere, BlueprintReadWrite, Category = "Sky")
		float HorizonFalloff = 0;
	UPROPERTY(Transient, EditAnywhere, BlueprintReadWrite, Category = "Sky")
		float Saturation = 1.0;

	UPROPERTY(Transient, EditAnywhere, BlueprintReadWrite, Category = "Sun")
		float SunZenith = 0;
	UPROPERTY(Transient, EditAnywhere, BlueprintReadWrite, Category = "Sun")
		float SunAzimuth = 0;
	UPROPERTY(Transient, EditAnywhere, BlueprintReadWrite, Category = "Sun")
		float SunRadius = 0;
	UPROPERTY(Transient, EditAnywhere, BlueprintReadWrite, Category = "Sun")
		float SunShine = 0;
	UPROPERTY(Transient, EditAnywhere, BlueprintReadWrite, Category = "Sun")
		FLinearColor SunColor;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Sun")
		bool bUseSunPS = false;
	UPROPERTY(Transient, BlueprintReadWrite, Category = "Sun")
		float SunPSThreshold;
	UPROPERTY()
		AEmitter* SunEmitter;
	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Category = "Sun")
		UParticleSystem* PS_SunTemplate;
	UPROPERTY(Transient, EditAnywhere, BlueprintReadWrite, Category = "Sun")
		FVector SunEffectScale = FVector::OneVector;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Sun")
		float SunEffectOffset = -1000000.0f;

	UPROPERTY(Transient, EditAnywhere, BlueprintReadWrite, Category = "SunLight")
		float UseLightShaft = 0;
	UPROPERTY(Transient, EditAnywhere, BlueprintReadWrite, Category = "SunLight")
		float LightShaftScale = 0;
	UPROPERTY(Transient, EditAnywhere, BlueprintReadWrite, Category = "SunLight")
		FLinearColor LightShaftTint;
	UPROPERTY(Transient)
		FRotator LightDirection = FRotator(-30.000000, 20.000000, 0.000000);

	UPROPERTY(Transient, EditAnywhere, BlueprintReadWrite, Category = "SunLight")
		float SunTemperature = 0;
	UPROPERTY(Transient, EditAnywhere, BlueprintReadWrite, Category = "SunLight")
		float SunTemperature2 = 0;
	UPROPERTY(Transient, EditAnywhere, BlueprintReadWrite, Category = "SunLight")
		float SunExternalIntensity = 0;
	UPROPERTY(Transient, EditAnywhere, BlueprintReadWrite, Category = "SunLight")
		float SunExternalIntensity2 = 0;
	UPROPERTY(Transient)
		FRotator SunDirection = FRotator(-30.000000, 20.000000, 0.000000);
	UPROPERTY(Transient)
		float SunHeight = 0.000000;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "SunLight")
		FLinearColor SpecularIBLScale;


	UPROPERTY(Transient, EditAnywhere, BlueprintReadWrite, Category = "Moon")
		float MoonZenith = 180;
	UPROPERTY(Transient, EditAnywhere, BlueprintReadWrite, Category = "Moon")
		float MoonAzimuth = 0;
	UPROPERTY(Transient, EditAnywhere, BlueprintReadWrite, Category = "Moon")
		float MoonRadius = 0;
	UPROPERTY(Transient, EditAnywhere, BlueprintReadWrite, Category = "Moon")
		float MoonShine = 0;
	UPROPERTY(Transient, EditAnywhere, BlueprintReadWrite, Category = "Moon")
		FLinearColor MoonColor;
	UPROPERTY(Transient, EditAnywhere, BlueprintReadWrite, Category = "Moon")
		float MoonBrightness = 0;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Moon")
		FLinearColor MoonLightDir;

	UPROPERTY(Transient, EditAnywhere, BlueprintReadWrite, Category = "Moon")
		float Moon2Zenith = 180;
	UPROPERTY(Transient, EditAnywhere, BlueprintReadWrite, Category = "Moon")
		float Moon2Azimuth = 0;
	UPROPERTY(Transient, EditAnywhere, BlueprintReadWrite, Category = "Moon")
		float Moon2Radius = 0;
	UPROPERTY(Transient, EditAnywhere, BlueprintReadWrite, Category = "Moon")
		float Moon2Shine = 0;
	UPROPERTY(Transient, EditAnywhere, BlueprintReadWrite, Category = "Moon")
		FLinearColor Moon2Color;
	UPROPERTY(Transient, EditAnywhere, BlueprintReadWrite, Category = "Moon")
		float Moon2Brightness = 0;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Moon")
		FLinearColor Moon2LightDir;

	UPROPERTY(Transient, EditAnywhere, BlueprintReadWrite, Category = "Moon")
		float Moon3Zenith = 180;
	UPROPERTY(Transient, EditAnywhere, BlueprintReadWrite, Category = "Moon")
		float Moon3Azimuth = 0;
	UPROPERTY(Transient, EditAnywhere, BlueprintReadWrite, Category = "Moon")
		float Moon3Radius = 0;
	UPROPERTY(Transient, EditAnywhere, BlueprintReadWrite, Category = "Moon")
		float Moon3Shine = 0;
	UPROPERTY(Transient, EditAnywhere, BlueprintReadWrite, Category = "Moon")
		FLinearColor Moon3Color;
	UPROPERTY(Transient, EditAnywhere, BlueprintReadWrite, Category = "Moon")
		float Moon3Brightness = 0;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Moon")
		FLinearColor Moon3LightDir;

	UPROPERTY(Transient, EditAnywhere, BlueprintReadWrite, Category = "Moon")
		float Moon4Zenith = 180;
	UPROPERTY(Transient, EditAnywhere, BlueprintReadWrite, Category = "Moon")
		float Moon4Azimuth = 0;
	UPROPERTY(Transient, EditAnywhere, BlueprintReadWrite, Category = "Moon")
		float Moon4Radius = 0;
	UPROPERTY(Transient, EditAnywhere, BlueprintReadWrite, Category = "Moon")
		float Moon4Shine = 0;
	UPROPERTY(Transient, EditAnywhere, BlueprintReadWrite, Category = "Moon")
		FLinearColor Moon4Color;
	UPROPERTY(Transient, EditAnywhere, BlueprintReadWrite, Category = "Moon")
		float Moon4Brightness = 0;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Moon")
		FLinearColor Moon4LightDir;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Moon")
		bool bUseMoonPS = false;
	UPROPERTY(Transient, BlueprintReadWrite, Category = "Moon")
		float MoonPSThreshold;
	UPROPERTY()
		AEmitter* MoonEmitter;
	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Category = "Moon")
		UParticleSystem* PS_MoonTemplate;
	UPROPERTY(Transient, EditAnywhere, BlueprintReadWrite, Category = "Moon")
		FVector MoonEffectScale = FVector::OneVector;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Moon")
		float MoonEffectOffset = -1000000.0f;


	UPROPERTY(Transient, EditAnywhere, BlueprintReadWrite, Category = "MoonLight")
		float MoonTemperature = 0;
	UPROPERTY(Transient, EditAnywhere, BlueprintReadWrite, Category = "MoonLight")
		float MoonExternalIntensity = 0;

	UPROPERTY(Transient)
		FRotator MoonDirection = FRotator(30.000000, 90.000000, 0.000000);
	UPROPERTY(Transient)
		FRotator Moon2Direction = FRotator(30.000000, 90.000000, 0.000000);
	UPROPERTY(Transient)
		FRotator Moon3Direction = FRotator(30.000000, 90.000000, 0.000000);
	UPROPERTY(Transient)
		FRotator Moon4Direction = FRotator(30.000000, 90.000000, 0.000000);
	
	UPROPERTY(Transient, EditAnywhere, BlueprintReadWrite, Category = "Star")
		float StarBrightness = 0;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Star")
		FLinearColor StarColor;
	UPROPERTY(Transient, EditAnywhere, BlueprintReadWrite, Category = "Star")
		float StarHeightThreshold = 0;
	UPROPERTY(Transient, EditAnywhere, BlueprintReadWrite, Category = "Star")
		float StarLerpWidth = 0;
	UPROPERTY(Transient, EditAnywhere, BlueprintReadWrite, Category = "Star")
		float GalaxyScale = 0;
	UPROPERTY(Transient, EditAnywhere, BlueprintReadWrite, Category = "Star")
		float GalaxyRotationAngle = 0;
	UPROPERTY(Transient, EditAnywhere, BlueprintReadWrite, Category = "Star")
		float GalaxyIntensity = 0;
	
	UPROPERTY(Transient, EditAnywhere, BlueprintReadWrite, Category = "Cloud")
		float CloudsDensity = 0;
	UPROPERTY(Transient, EditAnywhere, BlueprintReadWrite, Category = "Cloud")
		float CloudsTranslucent = 0;
	UPROPERTY(Transient, EditAnywhere, BlueprintReadWrite, Category = "Cloud")
		float CloudsScale = 0;
	UPROPERTY(Transient, EditAnywhere, BlueprintReadWrite, Category = "Cloud")
		float CloudsHardness = 0;
	UPROPERTY(Transient, EditAnywhere, BlueprintReadWrite, Category = "Cloud")
		float CloudsBlend = 0;
	UPROPERTY(Transient, EditAnywhere, BlueprintReadWrite, Category = "Cloud")
		float CloudsDistortion = 0;
	UPROPERTY(Transient, EditAnywhere, BlueprintReadWrite, Category = "Cloud")
		float CloudsScattering = 0;
	UPROPERTY(Transient, EditAnywhere, BlueprintReadWrite, Category = "Cloud")
		float CloudsAmbient = 0;
	UPROPERTY(Transient, EditAnywhere, BlueprintReadWrite, Category = "Cloud")
		float CloudsShadowSize = 0;
	UPROPERTY(Transient, EditAnywhere, BlueprintReadWrite, Category = "Cloud")
		float CloudsShadowSoft = 0;
	UPROPERTY(Transient, EditAnywhere, BlueprintReadWrite, Category = "Cloud")
		float CloudsHorizonDensity = 0;
	UPROPERTY(Transient, EditAnywhere, BlueprintReadWrite, Category = "Cloud")
		float CloudsHorizonAlpha = 0;
	UPROPERTY(Transient, EditAnywhere, BlueprintReadWrite, Category = "Cloud")
		float CloudsHorizonScattering = 0;
	UPROPERTY(Transient, EditAnywhere, BlueprintReadWrite, Category = "Cloud")
		FLinearColor CloudsUpperColor;
	UPROPERTY(Transient, EditAnywhere, BlueprintReadWrite, Category = "Cloud")
		float CloudsUpperBrightness = 0;
	UPROPERTY(Transient, EditAnywhere, BlueprintReadWrite, Category = "Cloud")
		FLinearColor CloudsLowerColor;
	UPROPERTY(Transient, EditAnywhere, BlueprintReadWrite, Category = "Cloud")
		float CloudsLowerBrightness = 0;
	UPROPERTY(Transient, EditAnywhere, BlueprintReadWrite, Category = "Cloud")
		FLinearColor CloudsBackgroundColor;
	UPROPERTY(Transient, EditAnywhere, BlueprintReadWrite, Category = "Cloud")
		float CloudsBackgroundBrightness = 0;

	UPROPERTY(Transient, EditAnywhere, BlueprintReadWrite, Category = "Cloud")
		FLinearColor CloudLayersScale = FLinearColor::White;
	//UPROPERTY(Transient, EditAnywhere, BlueprintReadWrite, Category = "Cloud")
	//	float CloudLayersSpeed = 0;
	//UPROPERTY(Transient)
		//FLinearColor CloudLayersPosition;
	//天边云相关参数
	UPROPERTY(Transient, EditAnywhere, BlueprintReadWrite, Category = "Cloud")
		FLinearColor FarHorizonCloudsLowerColor;
	UPROPERTY(Transient, EditAnywhere, BlueprintReadWrite, Category = "Cloud")
		FLinearColor FarHorizonCloudsUpperColor;
	UPROPERTY(Transient, EditAnywhere, BlueprintReadWrite, Category = "Cloud")
		FLinearColor FarHorizonCloudsSpeed = FLinearColor::Black;
	UPROPERTY(Transient, EditAnywhere, BlueprintReadWrite, Category = "Cloud")
		float FarHorizonCloudsMaxOpacity = 0;
	UPROPERTY(Transient, EditAnywhere, BlueprintReadWrite, Category = "Cloud")
		FLinearColor FarHorizonClouds1TilingOffset;
	UPROPERTY(Transient, EditAnywhere, BlueprintReadWrite, Category = "Cloud")
		FLinearColor FarHorizonClouds2TilingOffset;
	UPROPERTY(Transient, EditAnywhere, BlueprintReadWrite, Category = "Cloud")
		UTexture2D* FarHorizonCloudsTex;

	UPROPERTY(Transient, EditAnywhere, BlueprintReadWrite, Category = "Fog")
		float FogHeight = 0;
	UPROPERTY(Transient, EditAnywhere, BlueprintReadWrite, Category = "Fog")
		FLinearColor FogColor;
	UPROPERTY(Transient, EditAnywhere, BlueprintReadWrite, Category = "Fog")
		float FogDensity = 0;
	UPROPERTY(Transient, EditAnywhere, BlueprintReadWrite, Category = "Fog")
		float FogDensityOffset = 0;
	UPROPERTY(Transient, EditAnywhere, BlueprintReadWrite, Category = "Fog")
		float FogDensityScale = 0;
	UPROPERTY(Transient, EditAnywhere, BlueprintReadWrite, Category = "Fog")
		float FogStartDistance = 0;
	UPROPERTY(Transient, EditAnywhere, BlueprintReadWrite, Category = "Fog")
		float FogStartDistanceScale = 0;
	UPROPERTY(Transient, EditAnywhere, BlueprintReadWrite, Category = "Fog")
		float FogStartDistanceOffset = 0;
	UPROPERTY(Transient, EditAnywhere, BlueprintReadWrite, Category = "Fog")
		float FogHeightFalloff = 0;
	UPROPERTY(Transient, EditAnywhere, BlueprintReadWrite, Category = "Fog")
		float FogHeightFalloffScale = 0;
	UPROPERTY(Transient, EditAnywhere, BlueprintReadWrite, Category = "Fog")
		float FogHeightFalloffOffset = 0;
	UPROPERTY(Transient, EditAnywhere, BlueprintReadWrite, Category = "Fog")
		float FogDirInscatteringExponent = 0;
	UPROPERTY(Transient, EditAnywhere, BlueprintReadWrite, Category = "Fog")
		float FogDirInscatteringStartDist = 0;
	UPROPERTY(Transient, EditAnywhere, BlueprintReadWrite, Category = "Fog")
		FLinearColor FogDirInscatteringColor;
	UPROPERTY(Transient, EditAnywhere, BlueprintReadWrite, Category = "Fog")
		float FogMaxOpacity = 0;
	UPROPERTY(Transient, EditAnywhere, BlueprintReadWrite, Category = "Fog")
		FVector FogInscatteringDirection = FVector::ZeroVector;
	UPROPERTY(Transient, EditAnywhere, BlueprintReadWrite, Category = "Fog|UnderWater")
		bool EnableUnderWaterFog = false;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Fog|UnderWater")
		float UnderWaterFogHeight = 250;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Fog|UnderWater")
		float UnderWaterFogDensity = 0.1;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Fog|UnderWater")
		float UnderWaterFogStartDistance = 0.0;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Fog|UnderWater")
		float UnderWaterFogHeightFalloff = 2.0;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Fog|UnderWater")
		FLinearColor UnderWaterFogDirInscatteringColor = FLinearColor(0.04, 0.35, 0.86);

	UPROPERTY(VisibleAnywhere)
		UTextureRenderTarget2D* FogScaleMap = nullptr;
	UPROPERTY()
		UMaterialInstanceDynamic* FogScaleMapMaterial = nullptr;

	UPROPERTY(Transient, EditAnywhere, BlueprintReadWrite, Category = "Wind")
		float WindIntensity = 0;
	UPROPERTY(Transient, EditAnywhere, BlueprintReadWrite, Category = "Wind")
		float WindSpeed = 0;
	UPROPERTY(Transient, EditAnywhere, BlueprintReadWrite, Category = "Wind")
		float WindStrength = 0;
	UPROPERTY(Transient, EditAnywhere, BlueprintReadWrite, Category = "Wind")
		float WindMinGustAmount = 0;
	UPROPERTY(Transient, EditAnywhere, BlueprintReadWrite, Category = "Wind")
		float WindMaxGustAmount = 0;
	UPROPERTY(Transient, EditAnywhere, BlueprintReadWrite, Category = "Wind")
		FVector WindDirection = FVector::ForwardVector;
	UPROPERTY(Transient, EditAnywhere, BlueprintReadWrite, Category = "Wind")
		float WindDisturbance = 1.0f;
	UPROPERTY(Transient, EditAnywhere, BlueprintReadWrite, Category = "Wind")
		FVector WindDirectionDisturbance = FVector::ForwardVector;

	UPROPERTY(Transient)
		float WindForceMul = 1.f;
	UPROPERTY(Transient)
		float WindForceAdd = 0.f;
	UPROPERTY(Transient)
		double WindForceMulCurveStart = 0.f;
	UPROPERTY(Transient)
		double WindForceMulCurveScale = 1.f;
	UPROPERTY(Transient)
		double WindForceAddCurveStart = 0.f;
	UPROPERTY(Transient)
		double WindForceAddCurveScale = 1.f;
	UPROPERTY(Transient)
		float PhysForceBaseMultiply = 10000000.f;

	UPROPERTY(Transient)
		FVector WindLocation = FVector::ZeroVector;
	UPROPERTY(Transient)
		FVector LastWindDirection = FVector::ForwardVector;

	UPROPERTY(Transient)
		UAzureEnvironmentWind* SimuWind;
	UPROPERTY(Transient)
		TSet<TWeakObjectPtr<UActorComponent>> SimuWindForceComponents;

	UPROPERTY(Transient, EditAnywhere, BlueprintReadWrite, Category = "Shelter")
		bool bUnderShelter = false;

	UPROPERTY(Transient, EditAnywhere, BlueprintReadWrite, Category = "Rain")
		float RainIntensity = 0;
	UPROPERTY(Transient, EditAnywhere, BlueprintReadWrite, Category = "Rain")
		float RainRoughnessScale = 0;
	UPROPERTY(Transient, EditAnywhere, BlueprintReadWrite, Category = "Rain")
		float RippleIntensity = 0;
	UPROPERTY(Transient, EditAnywhere, BlueprintReadWrite, Category = "Rain")
		float RippleUVScale = 0;
	UPROPERTY(Transient, EditAnywhere, BlueprintReadWrite, Category = "Rain")
		float RippleTimeScale = 0;
	UPROPERTY(Transient, EditAnywhere, BlueprintReadWrite, Category = "Rain")
		float PuddleDepthScale = 0;
	UPROPERTY(Transient, EditAnywhere, BlueprintReadWrite, Category = "Rain")
		float PuddleWavesNormalIntensity = 0;
	UPROPERTY(Transient, EditAnywhere, BlueprintReadWrite, Category = "Rain")
		float PuddleWavesTimeScale = 0;
	UPROPERTY(Transient, EditAnywhere, BlueprintReadWrite, Category = "Rain")
		float PuddleWavesUVScale = 0;

	UPROPERTY(Transient, EditAnywhere, BlueprintReadWrite, Category = "Snow")
		float SnowIntensity = 0;
	UPROPERTY(Transient, EditAnywhere, BlueprintReadWrite, Category = "Snow")
		float SnowSide = 0;
	UPROPERTY(Transient, EditAnywhere, BlueprintReadWrite, Category = "Snow")
		float SnowSmooth = 0;
	UPROPERTY(Transient, EditAnywhere, BlueprintReadWrite, Category = "Snow")
		float SnowRoughnessScale = 0;
	UPROPERTY(Transient, EditAnywhere, BlueprintReadWrite, Category = "Snow")
		float SnowThreshold = 0;
	UPROPERTY(Transient, EditAnywhere, BlueprintReadWrite, Category = "Snow")
		FLinearColor SnowMaskAmount;
	UPROPERTY(Transient, EditAnywhere, BlueprintReadWrite, Category = "Snow")
		FVector SnowDirection = FVector::ZeroVector;

	UPROPERTY(VisibleAnywhere)
		UTextureRenderTarget2D* GrassColorMap = nullptr;
	UPROPERTY()
		UMaterialInstanceDynamic* GrassColorMapMaterial = nullptr;
	UPROPERTY(Transient)
		TSet<TWeakObjectPtr<ALandscapeProxy>> GrassColorMapSet;

	UPROPERTY(Transient, EditAnywhere, BlueprintReadWrite, Category = "Lightning")
		float LightningIntensity = 0;
	UPROPERTY(Transient, EditAnywhere, BlueprintReadWrite, Category = "Lightning")
		float LightningRate = 0;
	UPROPERTY(Transient, EditAnywhere, BlueprintReadWrite, Category = "Lightning")
		float LightningHeight = 0;
	UPROPERTY(Transient, EditAnywhere, BlueprintReadWrite, Category = "Lightning")
		bool bLightning = false;
	UPROPERTY(Transient, EditAnywhere, BlueprintReadWrite, Category = "Lightning")
		float LightningBrightnessScale = 1;
	UPROPERTY(Transient, EditAnywhere, BlueprintReadWrite, Category = "Lightning")
		float FogDirInscatteringColorLightningScale = 1;

	UPROPERTY(Transient, EditAnywhere, BlueprintReadWrite, Category = "Bloom")
		float BloomIntensity = 0;
	UPROPERTY(Transient, EditAnywhere, BlueprintReadWrite, Category = "Bloom")
		float BloomThreshold = 0;
	UPROPERTY(Transient, EditAnywhere, BlueprintReadWrite, Category = "Bloom")
		float BloomIntensityWithToneMapping = 0;
	UPROPERTY(Transient, EditAnywhere, BlueprintReadWrite, Category = "Bloom")
		float BloomThresholdWithToneMapping = 0;

	UPROPERTY(Transient, EditAnywhere, BlueprintReadWrite, Category = "LensFlare")
		bool bUseLensFlare = false;

	UPROPERTY(Transient, EditAnywhere, BlueprintReadWrite, Category = "Background")
		float WorldLayerDepth = 0;
	UPROPERTY(Transient, EditAnywhere, BlueprintReadWrite, Category = "Background")
		float WorldLayerFog = 0;
	UPROPERTY(Transient, EditAnywhere, BlueprintReadWrite, Category = "Background")
		FLinearColor WorldLayerColor;
	UPROPERTY(Transient)
		float WorldRotation = 0;
	UPROPERTY(Transient, EditAnywhere, BlueprintReadWrite, Category = "Background")
		float WorldRotationSpeed = 0;

	UPROPERTY(Transient, EditAnywhere, BlueprintReadWrite, Category = "Character")
		float CharacterDirectLightScale = 0;
	UPROPERTY(Transient, EditAnywhere, BlueprintReadWrite, Category = "Character")
		float CharacterIndirectLightScale = 0;
	UPROPERTY(Transient, EditAnywhere, BlueprintReadWrite, Category = "Character")
		FLinearColor CharacterIndirectLightColor;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Character")
		bool ShouldCopyDataFromSkin = true;
	UPROPERTY(Transient, EditAnywhere, BlueprintReadWrite, Category = "Character")
		float CharacterEquipDirectLightScale = 0;
	UPROPERTY(Transient, EditAnywhere, BlueprintReadWrite, Category = "Character")
		float CharacterEquipIndirectLightScale = 0;
	UPROPERTY(Transient, EditAnywhere, BlueprintReadWrite, Category = "Character")
		FLinearColor CharacterEquipIndirectLightColor;

	UPROPERTY(Transient, EditAnywhere, BlueprintReadWrite, Category = "Character")
		float CharacterTemperatureMax = 0;

	UPROPERTY(Transient, EditAnywhere, BlueprintReadWrite, Category = "Building")
		FLinearColor IndirectLightColor;
	UPROPERTY(Transient, EditAnywhere, BlueprintReadWrite, Category = "Building")
		float IndirectLightIntensity = 0;

	UPROPERTY(Transient, EditAnywhere, BlueprintReadWrite, Category = "PointLight")
		float PointLightIntensity = 0;

	UPROPERTY(Transient, EditAnywhere, BlueprintReadWrite, Category = "NightEmissive")
		float NightEmissivePositive = 0;
	UPROPERTY(Transient, EditAnywhere, BlueprintReadWrite, Category = "NightEmissive")
		float NightEmissiveNegative = 0;

	UPROPERTY(Transient, EditAnywhere, BlueprintReadWrite, Category = "PostColor")
		FLinearColor PostForegroundColorScale;
	UPROPERTY(Transient, EditAnywhere, BlueprintReadWrite, Category = "PostColor")
		FLinearColor PostBackgroundColorScale;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Ambient")
		FAzureAmbientSHCoefficients AmbientSH;

	

	UPROPERTY(Transient)
	UAzureEnvironmentPreset * TransitionPreSetCache;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Shootingstar")
	bool UseShootingstar = false;

	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Category = "Shootingstar")
	UParticleSystem* PS_ShootingStarTemplate;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Shootingstar")
	FTransform ShootingStarTransform;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Shootingstar")
	float ShootingStarThreshold;

	UPROPERTY()
	AEmitter* ShootingStar;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Comet")
	bool UseComet = false;

	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Category = "Comet")
	UParticleSystem* PS_CometTemplate;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Comet")
	FTransform CometTransform;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Comet")
	float CometThreshold;

	UPROPERTY()
	AEmitter* Comet;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Aurora")
	bool UseAurora = false;

	UPROPERTY(Transient, BlueprintReadWrite, Category = "Aurora")
	float AuroraTranslucent;

	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Category = "Aurora")
	TSubclassOf<class AStaticMeshActor> AuroraClass;

	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Category = "Aurora")
	UStaticMesh* SM_AuroraSimple;

	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Category = "Aurora")
	UStaticMesh* SM_AuroraComplex;

	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Category = "Aurora")
	UStaticMesh* SM_AuroraSpiral;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Aurora")
	FTransform AuroraSimpleTransform;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Aurora")
	FTransform AuroraComplexTransform;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Aurora")
	FTransform AuroraSpiralTransform;

	UPROPERTY()
	TArray<AStaticMeshActor*> AuroraList;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "RainBow")
	bool UseRainBow = false;

	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Category = "RainBow")
	UStaticMesh* SM_RainBowSmall;

	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Category = "RainBow")
	UStaticMesh* SM_RainBowLarge;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "RainBow")
	FTransform SmallRainBowTransform;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "RainBow")
	FTransform LargeRainBowTransform;

	UPROPERTY(Transient, BlueprintReadWrite, Category = "RainBow")
	float RainBowTranslucent;

	UPROPERTY()
	TArray<AStaticMeshActor*> RainBowList;

	static UAzureEnvironmentPreset* DefaultEnvironmentPreset;

protected:
	FVector2D RotateVec2(float Angle, FVector2D Vector);
	FLinearColor ColorSaturation(FLinearColor LinearColor, float Alpha);


	bool fogScaleMapDirty;
	TArray<float> TransitionsAlpha;

	float UpdateShelterTimer = 0.0f;

#if WITH_EDITOR
public:
	static void UpdateSptShadowFlag(UWorld* World, ULevel* Level);
	static void ClearSptShadowFlag(UWorld* World, ULevel* Level);
	static void SetSptShadowFlag(UWorld* World, ULevel* Level, bool bEnable);

// public:
// 	UFUNCTION(Category = "Test", meta = (CallInEditor = "true"))
// 	void Test();

#endif
};
