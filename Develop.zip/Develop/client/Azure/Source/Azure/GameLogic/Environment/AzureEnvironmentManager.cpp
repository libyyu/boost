﻿// Fill out your copyright notice in the Description page of Project Settings.

#include "AzureEnvironmentManager.h"
#include "SceneTypes.h"

#include "AzureEnvironmentActor.h"
#include "AzureEnvironmentPreset.h"
#include "AzureEnvironmentVolume.h"
#include "AzureEntryPoint.h"
#include "AzureBlueprintFunctionLibrary.h"
#include "Utilities/AzureUtility.h"

#include "Landscape/AzureLandscapeComponent.h"

#include "OceanMeshActor.h"

#if WITH_EDITOR
#include "UnrealEdGlobals.h"
#include "Editor/UnrealEdEngine.h"
#include "Editor.h"
#include "EditorSupportDelegates.h"
#include "LevelEditorViewport.h"
#include "InstancedFoliageActor.h"
#include "Components/HierarchicalInstancedStaticMeshComponent.h"
#endif

#include "LandscapeProxy.h"
#include "LandscapeComponent.h"

#include "Kismet/KismetMathLibrary.h"
#include "Kismet/KismetRenderingLibrary.h"
#include "Kismet/KismetMaterialLibrary.h"

DEFINE_LOG_CATEGORY(LogAzureEnvironmentManager);

namespace
{
	FName SkyUpperColorName = TEXT("SkyUpperColor");
	FName SkyLowerColorName = TEXT("SkyLowerColor");
	FName SkyFogDensityName = TEXT("SkyFogDensity");
	FName LightColorName = TEXT("LightColor");
	FName LightDirectionName = TEXT("LightDirection");

	FName GalaxyIntensityName = TEXT("GalaxyIntensity");

	FName WindLocationName = TEXT("WindLocation");

	FName Moon1ColorName = TEXT("Moon1Color");
	FName Moon1DirectionUpName = TEXT("Moon1DirectionUp");
	FName Moon1DirectionSideName = TEXT("Moon1DirectionSide");
	FName Moon1LightingDirectionName = TEXT("Moon1LightingDirection");
	FName Moon1DirectionFrontName = TEXT("Moon1DirectionFront");
	FName MoonLightDirName = TEXT("MoonLightDir");

	FName Moon2ColorName = TEXT("Moon2Color");
	FName Moon2DirectionUpName = TEXT("Moon2DirectionUp");
	FName Moon2DirectionSideName = TEXT("Moon2DirectionSide");
	FName Moon2LightingDirectionName = TEXT("Moon2LightingDirection");
	FName Moon2DirectionFrontName = TEXT("Moon2DirectionFront");
	FName Moon2LightDirName = TEXT("Moon2LightDir");

	FName Moon3ColorName = TEXT("Moon3Color");
	FName Moon3DirectionUpName = TEXT("Moon3DirectionUp");
	FName Moon3DirectionSideName = TEXT("Moon3DirectionSide");
	FName Moon3LightingDirectionName = TEXT("Moon3LightingDirection");
	FName Moon3DirectionFrontName = TEXT("Moon3DirectionFront");
	FName Moon3LightDirName = TEXT("Moon3LightDir");

	FName Moon4ColorName = TEXT("Moon4Color");
	FName Moon4DirectionUpName = TEXT("Moon4DirectionUp");
	FName Moon4DirectionSideName = TEXT("Moon4DirectionSide");
	FName Moon4LightingDirectionName = TEXT("Moon4LightingDirection");
	FName Moon4DirectionFrontName = TEXT("Moon4DirectionFront");
	FName Moon4LightDirName = TEXT("Moon4LightDir");


	FName FogMapScaleBiasName = TEXT("FogMapScaleBias");

	FName HorizonFalloffName = TEXT("HorizonFalloff");
	FName HorizonUpperColorName = TEXT("HorizonUpperColor");
	FName HorizonLowerColorName = TEXT("HorizonLowerColor");
	FName SkyLightColorName = TEXT("SkyLightColor");
	FName WorldLayerSettingsName = TEXT("WorldLayerSettings");
	FName BackgroundRotationName = TEXT("BackgroundRotation");
	FName CloudsDensityName = TEXT("CloudsDensity");
	FName CloudsTranslucentName = TEXT("CloudsTranslucent");
	FName CloudsHardnessName = TEXT("CloudsHardness");
	FName CloudsBlendName = TEXT("CloudsBlend");
	FName CloudsDistortionName = TEXT("CloudsDistortion");
	FName CloudsScatteringName = TEXT("CloudsScattering");
	FName CloudsAmbientName = TEXT("CloudsAmbient");
	FName CloudsShadowSizeName = TEXT("CloudsShadowSize");
	FName CloudsShadowSoftName = TEXT("CloudsShadowSoft");
	FName CloudsHorizonDensityName = TEXT("CloudsHorizonDensity");
	FName CloudsHorizonName = TEXT("CloudsHorizon");
	FName CloudsHorizonScatteringName = TEXT("CloudsHorizonScattering");
	FName CloudsLowerColorName = TEXT("CloudsLowerColor");
	FName CloudsUpperColorName = TEXT("CloudsUpperColor");
	FName CloudsBackgroundColorName = TEXT("CloudsBackgroundColor");
	FName LayerScaleName = TEXT("LayerScale");
	//FName LayerSpeedName = TEXT("LayerSpeed");
	//FName LayerPositionName = TEXT("LayerPosition");
	FName FarHorizonCloudsLowerColorName = TEXT("FarHorizonCloudsLowerColor");
	FName FarHorizonCloudsUpperColorName = TEXT("FarHorizonCloudsUpperColor");
	FName FarHorizonCloudsSpeedName = TEXT("FarHorizonCloudsSpeed");
	FName FarHorizonCloudsMaxOpacityName = TEXT("FarHorizonCloudsMaxOpacity");
	FName FarHorizonClouds1TilingOffsetName = TEXT("FarHorizonClouds1TilingOffset");
	FName FarHorizonClouds2TilingOffsetName = TEXT("FarHorizonClouds2TilingOffset");
	FName FarHorizonCloudsTexName = TEXT("FarHorizonClouds");

	FName SunRadiusName = TEXT("SunRadius");
	FName SunShineName = TEXT("SunShine");
	FName SunOnCloudsScaleName = TEXT("SunOnCloudsScale");
	FName SunColorName = TEXT("SunColor");
	FName SunDirectionName = TEXT("SunDirection");
	FName DynamicSunColorName = TEXT("DynamicSunColor");
	FName DynamicSunDirectionName = TEXT("DynamicSunDirection");
	FName StarsColorName = TEXT("StarsColor");
	FName StarHeightThresholdName = TEXT("StarHeightThreshold");
	FName StarLerpWidthName = TEXT("StarLerpWidth");
	FName MoonColorName = TEXT("MoonColor");
	FName MoonDirectionUpName = TEXT("MoonDirectionUp");
	FName MoonDirectionSideName = TEXT("MoonDirectionSide");
	FName MoonLightingDirectionName = TEXT("MoonLightingDirection");
	FName MoonDirectionFrontName = TEXT("MoonDirectionFront");
	FName GalaxyScaleName = TEXT("GalaxyScale");
	FName GalaxyRotationAngleName = TEXT("GalaxyRotationAngle");
	FName UseRainName = TEXT("UseRain");
	FName RainIntensityName = TEXT("RainIntensity");
	FName RainRoughnessScaleName = TEXT("RainRoughnessScale");
	FName UseSnowName = TEXT("UseSnow");
	FName SnowIntensityName = TEXT("SnowIntensity");
	FName SnowDirectionScaleName = TEXT("SnowDirectionScale");
	FName SnowSideName = TEXT("SnowSide");
	FName SnowSmoothName = TEXT("SnowSmooth");
	FName SnowRoughnessScaleName = TEXT("SnowRoughnessScale");
	FName SnowThresholdName = TEXT("SnowThreshold");
	FName SnowMaskAmountName = TEXT("SnowMaskAmount");
	FName SnowDirectionName = TEXT("SnowDirection");
	FName PuddleDepthScaleName = TEXT("PuddleDepthScale");
	FName RippleIntensityName = TEXT("RipplesIntensity");
	FName RippleUVScaleName = TEXT("RippleUVScale");
	FName RippleTimeScaleName = TEXT("RippleTimeScale");
	FName PuddleWavesNormalIntensityName = TEXT("PuddleWavesNormalIntensity");
	FName PuddleWavesTimeScaleName = TEXT("PuddleWavesTimeScale");
	FName PuddleWavesUVScaleName = TEXT("PuddleWavesUVScale");
	FName WindStrenghtName = TEXT("WindStrenght");
	FName WindWeightName = TEXT("WindWeight");
	FName WindDirectionName = TEXT("WindDirection");
	FName AuroraTranslucentName = TEXT("AuroraTranslucent");
	FName RainBowTranslucentName = TEXT("RainBowTranslucent");
	FName NightEmissivePositiveName = TEXT("NightEmissivePositive");
	FName NightEmissiveNegativeName = TEXT("NightEmissiveNegative");
	FName CharacterSkinIndirectLightScaleName = TEXT("CharacterSkinIndirectLightScale");
	FName CharacterSkinDirectLightScaleName = TEXT("CharacterSkinDirectLightScale");
	FName CharacterEquipIndirectLightScaleName = TEXT("CharacterEquipIndirectLightScale");
	FName CharacterEquipDirectLightScaleName = TEXT("CharacterEquipDirectLightScale");
	FName SpecularIBLScaleName = TEXT("SpecularIBLScale");

	FString ToneMapperFilmMobileConsoleName = TEXT("r.Mobile.TonemapperFilm");
};

ENGINE_API void GAzureSetMaterialsQualityLevel(UWorld* pWorld, EMaterialQualityLevel::Type level, bool bForce, bool bExcludeInputWorld);

TSet<AAzureEnvironmentManager *> AAzureEnvironmentManager::s_insts;
TSet<AAzureEnvironmentVolume *> AAzureEnvironmentManager::s_AllEnvVolumes;


namespace
{
	class BatchSetMaterialParamsHolder
	{
		UMaterialInstance * matInst;
	public:
		BatchSetMaterialParamsHolder(UMaterialInstance * InMatInst) : matInst(InMatInst)
		{
			matInst->BeginBatchModifyParamValues();
		}
		~BatchSetMaterialParamsHolder()
		{
			matInst->EndBatchModifyParamValues();
		}
	};
}

#define BATCHSETMATERIALPARAMSHOLDER(mat)	BatchSetMaterialParamsHolder	holder##mat(mat);

void UAzureEnvironmentTransition::Update(const FVector& CameraPos, float DeltaTime)
{
	if (Type == EAzureEnvironmentTransitionType::Time)
	{
		if (bDelay)
		{
			Duration -= DeltaTime;
			Duration = FMath::Max(Duration, 0.0f);
			if (Duration > 0.0f)
				return;
			else
				bDelay = false;
		}

		if (Alpha < 1.0f && bEnable)
		{
			if (Duration > 0.0f)
			{
				Alpha += DeltaTime / Duration;
			}
			else
			{
				Alpha = 1.0f;
			}

			Alpha = FMath::Min(Alpha, 1.0f);
		}

		if (Alpha > 0.0f && !bEnable)
		{
			if (Duration > 0.0f)
			{
				Alpha -= DeltaTime / Duration;
			}
			else
			{
				Alpha = 0.0f;
			}

			Alpha = FMath::Max(Alpha, 0.0f);
		}
	}
	else if (Type == EAzureEnvironmentTransitionType::Distance)
	{
		FVector Offset = CameraPos - Center;
		Offset = UAzureBlueprintFunctionLibrary::WorldWrapDistance(Offset);
		Offset.X = FMath::Abs(Offset.X);
		Offset.Y = FMath::Abs(Offset.Y);
		Offset.Z = FMath::Abs(Offset.Z);
		FVector AlphaV = (Extent - Offset);
		if (Distance > 0.0f)
		{
			AlphaV = AlphaV / Distance;
		}
		else
		{
			AlphaV.X = FMath::Sign(AlphaV.X);
			AlphaV.Y = FMath::Sign(AlphaV.Y);
			AlphaV.Z = FMath::Sign(AlphaV.Z);
		}
		float AlphaX = FMath::Clamp(AlphaV.X, 0.0f, 1.0f);
		float AlphaY = FMath::Clamp(AlphaV.Y, 0.0f, 1.0f);
		float AlphaZ = FMath::Clamp(AlphaV.Z, 0.0f, 1.0f);
		Alpha = FMath::Min3(AlphaX, AlphaY, AlphaZ);
	}
}

UAzureEnvironmentPreset* AAzureEnvironmentManager::DefaultEnvironmentPreset = nullptr;
// Sets default values
AAzureEnvironmentManager::AAzureEnvironmentManager()
	: FogMapBounds(ForceInit)
	, GrassBlockBounds(ForceInit)
	, fogScaleMapDirty(true)
{
	// Set this actor to call Tick() every frame.  You can turn this off to
	// improve performance if you don't need it.
	PrimaryActorTick.bCanEverTick = true;
	PrimaryActorTick.TickGroup = TG_PostPhysics;

	if (!DefaultEnvironmentPreset)
	{
		DefaultEnvironmentPreset = NewObject<UAzureEnvironmentPreset>(this, TEXT("DefaultEnvironmentPreset"));
		DefaultEnvironmentPreset->AddToRoot();
	}
#if WITH_EDITOR
	LoadFromPreset(DefaultEnvironmentPreset);
#endif
}

AAzureEnvironmentManager::~AAzureEnvironmentManager()
{
	
}

bool AAzureEnvironmentManager::ShouldTickIfViewportsOnly() const
{
	return true;
}

void AAzureEnvironmentManager::OnConstruction(const FTransform& Transform)
{
	Reset();
}

// Called when the game starts or when spawned
void AAzureEnvironmentManager::BeginPlay()
{
	Super::BeginPlay();

	TransitionPreSetCache = NewObject<UAzureEnvironmentPreset>(this);

	Init();

	AActor* Mgr = nullptr;
	if (AAzureEntryPoint::Instance != nullptr)
		Mgr = AAzureEntryPoint::Instance->GetEnvironmentManager();

	if (Mgr == nullptr)
	{
		Active();
	}
	else
	{
		Deactive();
	}
	s_insts.Add(this);
}

void AAzureEnvironmentManager::EndPlay(const EEndPlayReason::Type EndPlayReason)
{
	s_insts.Remove(this);
	Transitions.Empty();
	fogScaleMapDirty = true;
	for (AStaticMeshActor* AuroraMesh : AuroraList)
	{
		if (IsValid(AuroraMesh))
		{
			GetWorld()->DestroyActor(AuroraMesh);
			AuroraMesh = nullptr;
		}
	}
	AuroraList.Empty();

	if (IsValid(ShootingStar))
	{
		GetWorld()->DestroyActor(ShootingStar);
		ShootingStar = nullptr;
	}

	if (IsValid(Comet))
	{
		GetWorld()->DestroyActor(Comet);
		Comet = nullptr;
	}

	if (IsValid(SunEmitter))
	{
		GetWorld()->DestroyActor(SunEmitter);
		SunEmitter = nullptr;
	}

	if (IsValid(MoonEmitter))
	{
		GetWorld()->DestroyActor(MoonEmitter);
		MoonEmitter = nullptr;
	}

	Super::EndPlay(EndPlayReason);
}

bool AAzureEnvironmentManager::IsDayTime()
{
	float SunZ = UKismetMathLibrary::GetForwardVector(SunDirection).Z;
	float MoonZ = UKismetMathLibrary::GetForwardVector(MoonDirection).Z;
	return SunZ < MoonZ;
}

// Called every frame
void AAzureEnvironmentManager::Tick(float DeltaTime)
{
	if (bEnable)
	{
		TickHighFrequency(DeltaTime);

		//constexpr float fixDeltaTime = 1.f / 15.f;
		static float s_stepTime = 0.f;
		s_stepTime += DeltaTime;
		if (s_stepTime >= TickInterval)
		{
			Update(s_stepTime);
			Apply(s_stepTime);
			TickSimuWindAzureComps(s_stepTime);
			//TickAurora(s_stepTime);

			s_stepTime = 0.f;
		}
	}

}

void AAzureEnvironmentManager::Active()
{
	if (GetWorld() && GetWorld()->IsGameWorld())
	{
		for (auto Mgr : s_insts)
		{
			if(Mgr != this)
				Mgr->Deactive();
		}
	}

	if (AAzureEntryPoint::Instance != nullptr)
	{
		AAzureEntryPoint::Instance->SetEnvironmentManager(this);
	}

	bEnable = true;

	if (Sky)
	{
		Sky->GetRootComponent()->SetVisibility(true);
	}
	if (Fog)
	{
		Fog->GetRootComponent()->SetVisibility(true);
	}
	if (UnderWaterFog)
	{
		UnderWaterFog->GetRootComponent()->SetVisibility(true);
	}
	if (SunFlare)
	{
		SunFlare->GetRootComponent()->SetVisibility(true);
	}
	for (auto SunLight : SunLightSource)
	{
		if (IsValid(SunLight))
			SunLight->GetRootComponent()->SetVisibility(true);
	}
	if (MoonLightSource)
	{
		MoonLightSource->GetRootComponent()->SetVisibility(true);
	}
	if (WindSource)
	{
		WindSource->GetComponent()->SetActive(true);
	}
	for (auto Volume : PostProcessVolumesBloom)
	{
		if (IsValid(Volume))
			Volume->bEnabled = true;
	}
	for (auto Volume : PostProcessVolumesIndirectLight)
	{
		if (IsValid(Volume))
			Volume->bEnabled = true;
	}
	for (auto Volume : PostProcessVolumesPostColor)
	{
		if (IsValid(Volume))
			Volume->bEnabled = true;
	}

	Reset();
}

void AAzureEnvironmentManager::Deactive()
{
	bEnable = false;
	
	if (Sky)
	{
		Sky->GetRootComponent()->SetVisibility(false);
	}
	if (Fog)
	{
		Fog->GetRootComponent()->SetVisibility(false);
	}
	if (UnderWaterFog)
	{
		UnderWaterFog->GetRootComponent()->SetVisibility(false);
	}
	if (SunFlare)
	{
		SunFlare->GetRootComponent()->SetVisibility(false);
	}
	for (auto SunLight : SunLightSource)
	{
		if (IsValid(SunLight))
			SunLight->GetRootComponent()->SetVisibility(false);
	}
	if (MoonLightSource)
	{
		MoonLightSource->GetRootComponent()->SetVisibility(false);
	}
	if (WindSource)
	{
		WindSource->GetComponent()->SetActive(false);
	}
	for (auto Volume : PostProcessVolumesBloom)
	{
		if (IsValid(Volume))
			Volume->bEnabled = false;
	}
	for (auto Volume : PostProcessVolumesIndirectLight)
	{
		if (IsValid(Volume))
			Volume->bEnabled = false;
	}
	for (auto Volume : PostProcessVolumesPostColor)
	{
		if (IsValid(Volume))
			Volume->bEnabled = false;
	}

	if (AAzureEntryPoint::Instance != nullptr)
	{
		if (AAzureEntryPoint::Instance->GetEnvironmentManager() == this)
			AAzureEntryPoint::Instance->SetEnvironmentManager(nullptr);
	}

	Clear();
}

void AAzureEnvironmentManager::Reset()
{
	Clear();

	if (DefaultPreset.Get())
	{
		UAzureEnvironmentPreset* Preset = NewObject<UAzureEnvironmentPreset>(this, DefaultPreset);
		PushPreset(Preset, 0);
	}

	Init();

#if WITH_EDITOR
	if (EditingPreset.Get())
	{
		UAzureEnvironmentPreset* Preset = NewObject<UAzureEnvironmentPreset>(this, EditingPreset);
		PushPreset(Preset, 0);
	}
#endif

	Update(0);
	Apply(0);
}

void AAzureEnvironmentManager::Init()
{
	InitResources();
	InitSunProperties();
	InitMoonProperties();
	InitWindProperties();
	InitFogProperties();
	InitGrassProperties();
	InitAurora();
	InitShootingstar();
	InitRainBow();
	InitComet();
}

void AAzureEnvironmentManager::Clear()
{
	Transitions.Empty();

	CurrentWeather = nullptr;
	CurrentWeatherIndex = -1;
	fogScaleMapDirty = true;

	SimuWindForceComponents.Empty();

	TransitionPreSetCache = NewObject<UAzureEnvironmentPreset>(this);
}

void AAzureEnvironmentManager::InitResources()
{
#if WITH_EDITOR
	if (EnvironmentParam == nullptr)
	{
		FStringAssetReference ParamPath("/Game/Miscs/LightParam");
		EnvironmentParam = Cast<UMaterialParameterCollection>(ParamPath.TryLoad());
	}

	if (FogScaleMap == nullptr)
	{
		FStringAssetReference ParamPath("/Game/Miscs/FogScaleMap");
		FogScaleMap = Cast<UTextureRenderTarget2D>(ParamPath.TryLoad());
	}

	if (FogScaleMapMaterial == nullptr)
	{
		FStringAssetReference ParamPath("/Game/Miscs/FogScaleMapMaterial");
		UMaterial* Material = Cast<UMaterial>(ParamPath.TryLoad());
		FogScaleMapMaterial = UMaterialInstanceDynamic::Create(Material, this, NAME_None);
	}

	/*if (GrassColorMap == nullptr)
	{
		FStringAssetReference ParamPath("/Game/Miscs/GrassColorMap");
		GrassColorMap = Cast<UTextureRenderTarget2D>(ParamPath.TryLoad());
	}

	if (GrassColorMapMaterial == nullptr)
	{
		FStringAssetReference ParamPath("/Game/Miscs/GrassColorMapMaterial");
		UMaterial* Material = Cast<UMaterial>(ParamPath.TryLoad());
		GrassColorMapMaterial = UMaterialInstanceDynamic::Create(Material, this, NAME_None);
	}*/

	if (WindForceMulCurve == nullptr)
	{
		FStringAssetReference ParamPath("/Game/Scenes/SkyBox/CurvePreset/Global/WindForceMulCurve");
		WindForceMulCurve = Cast<UCurveFloat>(ParamPath.TryLoad());
	}

	if (WindForceAddCurve == nullptr)
	{
		FStringAssetReference ParamPath("/Game/Scenes/SkyBox/CurvePreset/Global/WindForceAddCurve");
		WindForceAddCurve = Cast<UCurveFloat>(ParamPath.TryLoad());
	}

	if (bUseLensFlare && GetWorld())
	{
		FActorSpawnParameters SpawnParameters;
		SpawnParameters.Owner = this;
		SunFlare = Cast<AAzureLensFlare>(GetWorld()->SpawnActor(AAzureLensFlare::StaticClass(), &FTransform::Identity, SpawnParameters));
	}
#endif
}

void AAzureEnvironmentManager::InitSunProperties()
{
	if (SunLightSource.IsValidIndex(0) && IsValid(SunLightSource[0]))
	{
		SunDirection = SunLightSource[0]->GetActorRotation();
		SunHeight = -(UKismetMathLibrary::GetForwardVector(SunDirection).Z);
		LightDirection = SunLightSource[0]->GetActorRotation();
	}
#if WITH_EDITOR
	if (bUseSunPS)
	{
		if (!IsValid(SunEmitter))
		{
			AEmitter* Emitter = Cast<AEmitter>(GetWorld()->SpawnActor(AEmitter::StaticClass()));		
			if (IsValid(Emitter))
			{
				Emitter->SetActorLabel(TEXT("SunEffect"));
				UParticleSystemComponent* ParticleSystemComponent = Emitter->GetParticleSystemComponent();
				if (IsValid(ParticleSystemComponent))
				{
					if (!IsValid(ParticleSystemComponent->Template))
					{
						ParticleSystemComponent->SetTemplate(PS_SunTemplate);
					}
					SunEmitter = Emitter;
				}
			}
		}
	}
	else
	{
		if (IsValid(SunEmitter))
		{
			GetWorld()->DestroyActor(SunEmitter);
			SunEmitter = nullptr;
			return;
		}
	}
#endif
}

void AAzureEnvironmentManager::InitMoonProperties()
{
	if (SunLightSource.IsValidIndex(0) && IsValid(SunLightSource[0]))
	{
		MoonDirection = SunDirection;
	}

#if WITH_EDITOR
	if (bUseMoonPS)
	{
		if (!IsValid(MoonEmitter))
		{
			AEmitter* Emitter = Cast<AEmitter>(GetWorld()->SpawnActor(AEmitter::StaticClass()));
			if (IsValid(Emitter))
			{
				Emitter->SetActorLabel(TEXT("MoonEffect"));
				UParticleSystemComponent* ParticleSystemComponent = Emitter->GetParticleSystemComponent();
				if (IsValid(ParticleSystemComponent))
				{
					if (!IsValid(ParticleSystemComponent->Template))
					{
						ParticleSystemComponent->SetTemplate(PS_MoonTemplate);
					}
					MoonEmitter = Emitter;
				}
			}
		}
	}
	else
	{
		if (IsValid(MoonEmitter))
		{
			GetWorld()->DestroyActor(MoonEmitter);
			MoonEmitter = nullptr;
			return;
		}
	}
#endif
}

void AAzureEnvironmentManager::InitWindProperties()
{
	if (SimuWind == nullptr)
	{
		SimuWind = NewObject<UAzureEnvironmentWind>();
	}
}

void AAzureEnvironmentManager::InitFogProperties()
{
	fogScaleMapDirty = true;
	FLinearColor FogMapScaleBias;
	if (FogMapBounds.GetSize().X > 0 && FogMapBounds.GetSize().Y > 0)
	{
		FogMapScaleBias.R = 1.0f / (FogMapBounds.Max.X - FogMapBounds.Min.X);
		FogMapScaleBias.G = 1.0f / (FogMapBounds.Max.Y - FogMapBounds.Min.Y);
		FogMapScaleBias.B = -FogMapBounds.Min.X * FogMapScaleBias.R;
		FogMapScaleBias.A = -FogMapBounds.Min.Y * FogMapScaleBias.G;
	}
	else
	{
		FogMapScaleBias.R = 1.0f;
		FogMapScaleBias.G = 1.0f;
		FogMapScaleBias.B = 0.0f;
		FogMapScaleBias.A = 0.0f;
	}

	if (FogScaleMap != nullptr)
		UKismetRenderingLibrary::ClearRenderTarget2D(this, FogScaleMap, FLinearColor::White);

	if (EnvironmentParam != nullptr)
		UKismetMaterialLibrary::SetVectorParameterValue(this, EnvironmentParam, FogMapScaleBiasName, FogMapScaleBias);
}

void AAzureEnvironmentManager::InitGrassProperties()
{
}

void AAzureEnvironmentManager::Update(float DeltaTime)
{
	if (!bUpdate)
		return;

	UpdateCameraPos(DeltaTime);
	UpdateTimeOfDay(DeltaTime);
	UpdatePresetData(DeltaTime);
	UpdateWeather(DeltaTime);
	UpdateShelter(DeltaTime);

	UpdateSunProperties(DeltaTime);
	UpdateMoonProperties(DeltaTime);
	UpdateStarProperties(DeltaTime);
	UpdateCloudProperties(DeltaTime);
	UpdateSkyProperties(DeltaTime);
	UpdateFogProperties(DeltaTime);
	UpdateWindProperties(DeltaTime);
	UpdateRainProperties(DeltaTime);
	UpdateSnowProperties(DeltaTime);
	//UpdateGrassProperties(DeltaTime);
	UpdateLightningProperties(DeltaTime);
	UpdateBloomProperties(DeltaTime);
	UpdateBackgroundProperties(DeltaTime);
	UpdateCharacterProperties(DeltaTime);
	UpdateBuildingProperties(DeltaTime);
	UpdatePointLightProperties(DeltaTime);
	UpdateNightEmissiveProperties(DeltaTime);
	UpdatePostColorProperties(DeltaTime);
	UpdateOceanProperties(DeltaTime);
	UpdateAmbientProperties(DeltaTime);
	UpdateAuroraProperties(DeltaTime);
	UpdateShootingstarProperties(DeltaTime);
	UpdateRainBowProperties(DeltaTime);
	UpdateSpecularIBLScaleProperties(DeltaTime);
	UpdateCometProperties(DeltaTime);
}

void AAzureEnvironmentManager::UpdateShelter(float DeltaTime)
{
	UpdateShelterTimer += DeltaTime;
	if (UpdateShelterTimer >= 3.0f)
	{
		UpdateShelterTimer = 0.0f;

		UWorld* pWorld = GetWorld();
		AActor* pHostActor = UAzureBlueprintFunctionLibrary::GetHostRootActor();
		if (pWorld && pHostActor)
		{
			FVector vStart = pHostActor->GetActorLocation();
			FVector vEnd = vStart;
			vEnd.Z += 10000.0f;

			FHitResult hitRes;
			FCollisionQueryParams Params(NAME_None, false); // Not Trace Complex!
			Params.AddIgnoredActor(pHostActor);

			FTraceDelegate Delegate;
			Delegate.BindLambda([this](const FTraceHandle& handle, FTraceDatum &traceData) {
				bUnderShelter = false;
				for (auto& hitResult : traceData.OutHits)
				{
					if (hitResult.bBlockingHit)
					{
						bUnderShelter = true;
						break;
					}
				}
			});

			pWorld->AsyncLineTraceByChannel(EAsyncTraceType::Test, vStart, vEnd, AzureUtility::TRACE_CHN_SHELTER, Params, FCollisionResponseParams::DefaultResponseParam, &Delegate);
		}
	}
}

void AAzureEnvironmentManager::UpdateCameraPos(float DeltaTime)
{
	CameraLocation = FVector::ZeroVector;
	CameraRotation = FRotator::ZeroRotator;

	bool gotCamera = false;

	if (GetWorld() && GetWorld()->IsGameWorld())
	{
		APlayerController *PlayerController = UGameplayStatics::GetPlayerController(this, 0);
		if (PlayerController)
		{
			PlayerController->GetPlayerViewPoint(CameraLocation, CameraRotation);
			gotCamera = true;
		}
	}

#if WITH_EDITOR
	if (!gotCamera || GUnrealEd->bIsSimulatingInEditor)
	{
		UEditorEngine *EEngine = Cast<UEditorEngine>(GEngine);
		if (GIsEditor && EEngine != NULL)
		{
			for (int32 Index = 0; Index < EEngine->AllViewportClients.Num(); Index++)
			{
				FEditorViewportClient* ViewportClient = EEngine->AllViewportClients[Index];
				if (ViewportClient && GetWorld() == ViewportClient->GetWorld())
				{
					if (ViewportClient->ViewportType == LVT_Perspective)
					{
						CameraLocation = ViewportClient->GetViewLocation();
						CameraRotation = ViewportClient->GetViewRotation();
					}
				}
			}
		}
	}
#endif
}

void AAzureEnvironmentManager::UpdateTimeOfDay(float DeltaTime)
{
	float NewTime = TimeOfDay + TimeScale * DeltaTime / 3600;
	TimeOfDay = NewTime - (FMath::TruncToInt(NewTime / MAX_TIME_OF_DAY) * MAX_TIME_OF_DAY);
}

void AAzureEnvironmentManager::UpdatePresetData(float DeltaTime)
{
	//remove transitions that been destroyed
	Transitions.RemoveAll([this](UAzureEnvironmentTransition* p) { if (!p) this->fogScaleMapDirty = true; return p == nullptr; });

	if (GetWorld())
	{
		for (UAzureEnvironmentTransition* Transition : Transitions)
		{
			if (Transition->bVolume)
			{
				bool bFound = false;
				for (AAzureEnvironmentVolume* Volume : GetAllEnvVolumeInstances())
				{
					if (Transition == Volume->GetTransition())
					{
						bFound = true;
						break;
					}
				}
				if (!bFound)
				{
					PopTransition(Transition);
				}
			}
		}

		FVector WrappedCameraLocation = UAzureBlueprintFunctionLibrary::WorldWrapPosition(CameraLocation);
		for (AAzureEnvironmentVolume* Volume : GetAllEnvVolumeInstances())
		{
			if (!(Volume && Volume->GetLevel() == GetLevel() && Volume->GetTransition()))
				continue;

			if (Volume->Transition == EAzureEnvironmentTransitionType::Time)
			{
				if (Volume->TransitionCurCooldown > 0)
				{
					Volume->TransitionCurCooldown -= DeltaTime;
					if (Volume->TransitionCurCooldown < 0)
					{
						Volume->TransitionCurCooldown = 0;
					}
					continue;
				}
			}

			bool bEncompasses = Volume->EncompassesPoint(WrappedCameraLocation, 10.0f);
			bool bFound = false;
			for (UAzureEnvironmentTransition* Transition : Transitions)
			{
				if (Transition == Volume->GetTransition())
				{
					bFound = true;
					break;
				}
			}

			UAzureEnvironmentTransition* Transition = Volume->GetTransition();

			if (bEncompasses && !bFound)
			{
				if (GetWorld()->IsGameWorld())
				{
					Volume->TransitionCurCooldown = Volume->TransitionCooldown;
				}
				PushTransition(Transition);
			}

			if (!bEncompasses && bFound)
			{
				if (GetWorld()->IsGameWorld())
				{
					Volume->TransitionCurCooldown = Volume->TransitionCooldown;
				}
				PopTransition(Transition);
			}
		}
	}

	//先执行移除逻辑 再更新PresetAlpha
	//确保Presset至少起效一帧 避免Duration为0时 Preset无效
	for (int Index = Transitions.Num() - 1; Index >= 0; Index--)
	{
		UAzureEnvironmentTransition* Transition = Transitions[Index];
		if (Transition->Alpha == 0 && !Transition->bEnable)
		{
			Transitions.RemoveAt(Index);
			fogScaleMapDirty = true;
		}
	}

	for (int Index = Transitions.Num() - 1; Index >= 0; Index--)
	{
		UAzureEnvironmentTransition* Transition = Transitions[Index];
		if(Transition->Preset)
			Transition->Preset->Evaluate(TimeOfDay);
		Transition->Update(CameraLocation, DeltaTime);
	}

	if (DefaultEnvironmentPreset)
		DefaultEnvironmentPreset->Evaluate(TimeOfDay);

#if UE_EDITOR
	if (GetWorld() && GetWorld()->WorldType == EWorldType::Editor)
	{
		for (int Index = Transitions.Num() - 1; Index >= 0; Index--)
		{
			UAzureEnvironmentTransition* Transition = Transitions[Index];
			if (Transition->Type == EAzureEnvironmentTransitionType::Time)
			{
				if (Transition->bEnable)
					Transition->Alpha = 1;
				else
					Transition->Alpha = 0;
			}
		}
	}
#endif

}

static EMaterialQualityLevel::Type _GetMaterialQualityLevel(EMaterialQualityLevel::Type level, EBasicWeather weather)
{
	if (level == EMaterialQualityLevel::Low)
		return EMaterialQualityLevel::Low;
	else if (level == EMaterialQualityLevel::High || level == EMaterialQualityLevel::HighRain || level == EMaterialQualityLevel::HighSnow)
	{
		if (weather == EBasicWeather::Normal)
			return EMaterialQualityLevel::High;
		else if (weather == EBasicWeather::Rain)
			return EMaterialQualityLevel::HighRain;
		else if (weather == EBasicWeather::Snow)
			return EMaterialQualityLevel::HighSnow;
	}
	else if (level == EMaterialQualityLevel::Highest || level == EMaterialQualityLevel::HighestRain || level == EMaterialQualityLevel::HighestSnow)
	{
		if (weather == EBasicWeather::Normal)
			return EMaterialQualityLevel::Highest;
		else if (weather == EBasicWeather::Rain)
			return EMaterialQualityLevel::HighestRain;
		else if (weather == EBasicWeather::Snow)
			return EMaterialQualityLevel::HighestSnow;
	}
	return EMaterialQualityLevel::Num;
}

void AAzureEnvironmentManager::UpdateWeather(float DeltaTime)
{
	EBasicWeather TargetWeather = Weather;
	float Alpha = 0.0f;

	for (int Index = 0; Index < Transitions.Num(); Index++)
	{
		if (Transitions[Index]->Preset)
		{
			if (Transitions[Index]->Preset->Weather != EBasicWeather::Default)
			{
				TargetWeather = Transitions[Index]->Preset->Weather;
				Alpha = Transitions[Index]->Alpha;
			}
		}
	}

	int32 MaterialQualityLevel = UKismetSystemLibrary::GetRenderingMaterialQualityLevel();

	if (TargetWeather != Weather && GetWorld() && Alpha >= 1.0f)
	{
		Weather = TargetWeather;
		if (GetWorld()->IsGameWorld())
		{
			bool bChangeMaterialQualityLevel = true;
#if UE_EDITOR
			if (UAzureBlueprintFunctionLibrary::GameInfo_GetBoolean(TEXT("system.debug_option('no_weather_change')")))
				bChangeMaterialQualityLevel = false;
#endif
			if (bChangeMaterialQualityLevel)
				GAzureSetMaterialsQualityLevel(GetWorld(), _GetMaterialQualityLevel((EMaterialQualityLevel::Type)MaterialQualityLevel, TargetWeather), true, false);
		}
	}
}

#define CHECK_ENVIRONMENT_PROPERTY(PROPERTY_NAME) TransitionPreSetCache->b##PROPERTY_NAME

#define BEGIN_ENVIRONMENT_PROPERTY	\
	{	\
	UAzureEnvironmentPreset* Preset = DefaultEnvironmentPreset; \
	for (int Index = -1; Index < Transitions.Num(); Index ++) \
	{ \
		auto Transition = Index >= 0 ? Transitions[Index] : nullptr; \
		auto TargetPreset = Transition ? Transition->Preset : nullptr; 


#define UPDATE_ENVIRONMENT_PROPERTY(PROPERTY_NAME) \
		if(Index == -1) { PROPERTY_NAME = Preset ? Preset->PROPERTY_NAME : PROPERTY_NAME; } \
		if(TargetPreset && TargetPreset->b##PROPERTY_NAME)	\
		{	\
			TransitionPreSetCache->b##PROPERTY_NAME = true;	\
			PROPERTY_NAME = FMath::Lerp(PROPERTY_NAME, TargetPreset->PROPERTY_NAME, Transition->Alpha); \
		}

#define END_ENVIRONMENT_PROPERTY	\
	}	\
	}

void AAzureEnvironmentManager::UpdateCharacterProperties(float DeltaTime)
{
	BEGIN_ENVIRONMENT_PROPERTY
	UPDATE_ENVIRONMENT_PROPERTY(CharacterIndirectLightScale);
	UPDATE_ENVIRONMENT_PROPERTY(CharacterDirectLightScale);
	UPDATE_ENVIRONMENT_PROPERTY(CharacterIndirectLightColor);
	if (!ShouldCopyDataFromSkin)
	{
		UPDATE_ENVIRONMENT_PROPERTY(CharacterEquipIndirectLightScale);
		UPDATE_ENVIRONMENT_PROPERTY(CharacterEquipDirectLightScale);
		UPDATE_ENVIRONMENT_PROPERTY(CharacterEquipIndirectLightColor);
	}
	
	UPDATE_ENVIRONMENT_PROPERTY(CharacterTemperatureMax);
	END_ENVIRONMENT_PROPERTY

#if WITH_EDITORONLY_DATA
	if (bBakePreview)
	{
		CharacterIndirectLightScale = 1.0;
		CharacterDirectLightScale = 1.0;
		CharacterIndirectLightColor = FLinearColor(1, 1, 1);

		CharacterEquipIndirectLightScale = ShouldCopyDataFromSkin ? CharacterIndirectLightScale : 1.0;
		CharacterEquipDirectLightScale = ShouldCopyDataFromSkin ? CharacterDirectLightScale : 1.0;
		CharacterEquipIndirectLightColor = ShouldCopyDataFromSkin ? CharacterIndirectLightColor : FLinearColor(1, 1, 1);
		
		CharacterTemperatureMax = 15000.0f;
	}
#endif
}

void AAzureEnvironmentManager::UpdateBuildingProperties(float DeltaTime)
{
	BEGIN_ENVIRONMENT_PROPERTY
	UPDATE_ENVIRONMENT_PROPERTY(IndirectLightColor);
	UPDATE_ENVIRONMENT_PROPERTY(IndirectLightIntensity);
	END_ENVIRONMENT_PROPERTY

#if WITH_EDITORONLY_DATA
	if (bBakePreview)
	{
		IndirectLightColor = FLinearColor(1, 1, 1);
		IndirectLightIntensity = 1.0;
	}
#endif
}

void AAzureEnvironmentManager::UpdatePointLightProperties(float DeltaTime)
{
	BEGIN_ENVIRONMENT_PROPERTY
	UPDATE_ENVIRONMENT_PROPERTY(PointLightIntensity);
	END_ENVIRONMENT_PROPERTY
}

void AAzureEnvironmentManager::UpdateNightEmissiveProperties(float DeltaTime)
{
	BEGIN_ENVIRONMENT_PROPERTY
	UPDATE_ENVIRONMENT_PROPERTY(NightEmissivePositive);
	UPDATE_ENVIRONMENT_PROPERTY(NightEmissiveNegative);
	END_ENVIRONMENT_PROPERTY
}

void AAzureEnvironmentManager::UpdatePostColorProperties(float DeltaTime)
{
	BEGIN_ENVIRONMENT_PROPERTY
	UPDATE_ENVIRONMENT_PROPERTY(PostForegroundColorScale);
	UPDATE_ENVIRONMENT_PROPERTY(PostBackgroundColorScale);
	END_ENVIRONMENT_PROPERTY

#if WITH_EDITORONLY_DATA
	if (bBakePreview)
	{
		PostForegroundColorScale = FLinearColor(1, 1, 1);
		PostBackgroundColorScale = FLinearColor(1, 1, 1);
	}
#endif
}

void AAzureEnvironmentManager::UpdateSunProperties(float DeltaTime)
{
	BEGIN_ENVIRONMENT_PROPERTY
	UPDATE_ENVIRONMENT_PROPERTY(SunZenith);
	UPDATE_ENVIRONMENT_PROPERTY(SunAzimuth);
	UPDATE_ENVIRONMENT_PROPERTY(SunRadius);
	UPDATE_ENVIRONMENT_PROPERTY(SunShine);
	UPDATE_ENVIRONMENT_PROPERTY(SunColor);

	UPDATE_ENVIRONMENT_PROPERTY(UseLightShaft);
	UPDATE_ENVIRONMENT_PROPERTY(LightShaftScale);
	UPDATE_ENVIRONMENT_PROPERTY(LightShaftTint);

	UPDATE_ENVIRONMENT_PROPERTY(SunTemperature);
	UPDATE_ENVIRONMENT_PROPERTY(SunTemperature2);
	UPDATE_ENVIRONMENT_PROPERTY(SunExternalIntensity);
	UPDATE_ENVIRONMENT_PROPERTY(SunExternalIntensity2);
	UPDATE_ENVIRONMENT_PROPERTY(SunPSThreshold);
	UPDATE_ENVIRONMENT_PROPERTY(SunEffectScale);
	END_ENVIRONMENT_PROPERTY

}

void AAzureEnvironmentManager::UpdateMoonProperties(float DeltaTime)
{
	BEGIN_ENVIRONMENT_PROPERTY
	UPDATE_ENVIRONMENT_PROPERTY(MoonZenith);
	UPDATE_ENVIRONMENT_PROPERTY(MoonAzimuth);
	UPDATE_ENVIRONMENT_PROPERTY(MoonRadius);
	UPDATE_ENVIRONMENT_PROPERTY(MoonShine);
	UPDATE_ENVIRONMENT_PROPERTY(MoonColor);
	UPDATE_ENVIRONMENT_PROPERTY(MoonBrightness);
	UPDATE_ENVIRONMENT_PROPERTY(MoonLightDir);

	UPDATE_ENVIRONMENT_PROPERTY(Moon2Zenith);
	UPDATE_ENVIRONMENT_PROPERTY(Moon2Azimuth);
	UPDATE_ENVIRONMENT_PROPERTY(Moon2Radius);
	UPDATE_ENVIRONMENT_PROPERTY(Moon2Shine);
	UPDATE_ENVIRONMENT_PROPERTY(Moon2Color);
	UPDATE_ENVIRONMENT_PROPERTY(Moon2Brightness);
	UPDATE_ENVIRONMENT_PROPERTY(Moon2LightDir);

	UPDATE_ENVIRONMENT_PROPERTY(Moon3Zenith);
	UPDATE_ENVIRONMENT_PROPERTY(Moon3Azimuth);
	UPDATE_ENVIRONMENT_PROPERTY(Moon3Radius);
	UPDATE_ENVIRONMENT_PROPERTY(Moon3Shine);
	UPDATE_ENVIRONMENT_PROPERTY(Moon3Color);
	UPDATE_ENVIRONMENT_PROPERTY(Moon3Brightness);
	UPDATE_ENVIRONMENT_PROPERTY(Moon3LightDir);

	UPDATE_ENVIRONMENT_PROPERTY(Moon4Zenith);
	UPDATE_ENVIRONMENT_PROPERTY(Moon4Azimuth);
	UPDATE_ENVIRONMENT_PROPERTY(Moon4Radius);
	UPDATE_ENVIRONMENT_PROPERTY(Moon4Shine);
	UPDATE_ENVIRONMENT_PROPERTY(Moon4Color);
	UPDATE_ENVIRONMENT_PROPERTY(Moon4Brightness);
	UPDATE_ENVIRONMENT_PROPERTY(Moon4LightDir);

	UPDATE_ENVIRONMENT_PROPERTY(MoonTemperature);
	UPDATE_ENVIRONMENT_PROPERTY(MoonExternalIntensity);

	UPDATE_ENVIRONMENT_PROPERTY(MoonPSThreshold);
	UPDATE_ENVIRONMENT_PROPERTY(MoonEffectScale);
	END_ENVIRONMENT_PROPERTY
}

void AAzureEnvironmentManager::UpdateStarProperties(float DeltaTime)
{
	BEGIN_ENVIRONMENT_PROPERTY
	UPDATE_ENVIRONMENT_PROPERTY(StarBrightness);
	UPDATE_ENVIRONMENT_PROPERTY(StarColor);
	UPDATE_ENVIRONMENT_PROPERTY(StarHeightThreshold);
	UPDATE_ENVIRONMENT_PROPERTY(StarLerpWidth);
	UPDATE_ENVIRONMENT_PROPERTY(GalaxyScale);
	UPDATE_ENVIRONMENT_PROPERTY(GalaxyRotationAngle);
	UPDATE_ENVIRONMENT_PROPERTY(GalaxyIntensity);
	END_ENVIRONMENT_PROPERTY
}

void AAzureEnvironmentManager::UpdateCloudProperties(float DeltaTime)
{
	BEGIN_ENVIRONMENT_PROPERTY
	UPDATE_ENVIRONMENT_PROPERTY(CloudsDensity);
	UPDATE_ENVIRONMENT_PROPERTY(CloudsTranslucent);
	UPDATE_ENVIRONMENT_PROPERTY(CloudsScale);
	UPDATE_ENVIRONMENT_PROPERTY(CloudsHardness);
	UPDATE_ENVIRONMENT_PROPERTY(CloudsBlend);
	UPDATE_ENVIRONMENT_PROPERTY(CloudsDistortion);
	UPDATE_ENVIRONMENT_PROPERTY(CloudsScattering);
	UPDATE_ENVIRONMENT_PROPERTY(CloudsAmbient);
	UPDATE_ENVIRONMENT_PROPERTY(CloudsShadowSize);
	UPDATE_ENVIRONMENT_PROPERTY(CloudsShadowSoft);
	UPDATE_ENVIRONMENT_PROPERTY(CloudsHorizonDensity);
	UPDATE_ENVIRONMENT_PROPERTY(CloudsHorizonAlpha);
	UPDATE_ENVIRONMENT_PROPERTY(CloudsHorizonScattering);
	UPDATE_ENVIRONMENT_PROPERTY(CloudsUpperColor);
	UPDATE_ENVIRONMENT_PROPERTY(CloudsUpperBrightness);
	UPDATE_ENVIRONMENT_PROPERTY(CloudsLowerColor);
	UPDATE_ENVIRONMENT_PROPERTY(CloudsLowerBrightness);
	UPDATE_ENVIRONMENT_PROPERTY(CloudsBackgroundColor);
	UPDATE_ENVIRONMENT_PROPERTY(CloudsBackgroundBrightness);
	UPDATE_ENVIRONMENT_PROPERTY(CloudLayersScale);
	//UPDATE_ENVIRONMENT_PROPERTY(CloudLayersSpeed);
	UPDATE_ENVIRONMENT_PROPERTY(FarHorizonCloudsLowerColor);
	UPDATE_ENVIRONMENT_PROPERTY(FarHorizonCloudsUpperColor);
	UPDATE_ENVIRONMENT_PROPERTY(FarHorizonCloudsSpeed);
	UPDATE_ENVIRONMENT_PROPERTY(FarHorizonCloudsMaxOpacity);
	UPDATE_ENVIRONMENT_PROPERTY(FarHorizonClouds1TilingOffset);
	UPDATE_ENVIRONMENT_PROPERTY(FarHorizonClouds2TilingOffset);
	//UPDATE_ENVIRONMENT_PROPERTY(FarHorizonCloudsTex);
	END_ENVIRONMENT_PROPERTY

	//天边云贴图过渡，前一半旧贴图渐隐，后一半新贴图渐出
	int32 transitionsCount = Transitions.Num();
	if (transitionsCount == 0)
		return;

	UAzureEnvironmentPreset * LastPreset = Transitions[transitionsCount - 1]->Preset ? Transitions[transitionsCount - 1]->Preset : DefaultEnvironmentPreset;
	FarHorizonCloudsTex = LastPreset->FarHorizonCloudsTex;
	
	if (transitionsCount >= 2)
	{
		UAzureEnvironmentPreset * LastLastPreset = Transitions[transitionsCount - 2]->Preset ? Transitions[transitionsCount - 2]->Preset : DefaultEnvironmentPreset;
		if (LastLastPreset->FarHorizonCloudsTex != FarHorizonCloudsTex)
		{
			float Alpha = Transitions[transitionsCount - 1]->Alpha;
			if (Alpha < 0.5f)
			{
				FarHorizonCloudsTex = LastLastPreset->FarHorizonCloudsTex;
				Alpha = 1.f - Alpha * 2.f;

			}
			else if (Alpha < 1.f)
			{
				Alpha = Alpha * 2.f - 1.f;
			}
			FarHorizonCloudsMaxOpacity = FarHorizonCloudsMaxOpacity * Alpha;
		}
	}
}

void AAzureEnvironmentManager::UpdateSkyProperties(float DeltaTime)
{
	BEGIN_ENVIRONMENT_PROPERTY
	UPDATE_ENVIRONMENT_PROPERTY(SkyUpperColor);
	UPDATE_ENVIRONMENT_PROPERTY(SkyLowerColor);
	UPDATE_ENVIRONMENT_PROPERTY(SkyFogDensity);
	UPDATE_ENVIRONMENT_PROPERTY(SkyLightBrightness);
	UPDATE_ENVIRONMENT_PROPERTY(HorizonTilt);
	UPDATE_ENVIRONMENT_PROPERTY(HorizonFalloff);
	END_ENVIRONMENT_PROPERTY

#if WITH_EDITORONLY_DATA
	if (bBakePreview)
	{
		SkyLightBrightness = 1.0;
	}
#endif
}

void AAzureEnvironmentManager::UpdateFogProperties(float DeltaTime)
{
	BEGIN_ENVIRONMENT_PROPERTY
	UPDATE_ENVIRONMENT_PROPERTY(FogHeight);
	UPDATE_ENVIRONMENT_PROPERTY(FogColor);
	UPDATE_ENVIRONMENT_PROPERTY(FogDensity);
	UPDATE_ENVIRONMENT_PROPERTY(FogDensityScale);
	UPDATE_ENVIRONMENT_PROPERTY(FogDensityOffset);
	UPDATE_ENVIRONMENT_PROPERTY(FogStartDistance);
	UPDATE_ENVIRONMENT_PROPERTY(FogStartDistanceScale);
	UPDATE_ENVIRONMENT_PROPERTY(FogStartDistanceOffset);
	UPDATE_ENVIRONMENT_PROPERTY(FogHeightFalloff);
	UPDATE_ENVIRONMENT_PROPERTY(FogHeightFalloffScale);
	UPDATE_ENVIRONMENT_PROPERTY(FogHeightFalloffOffset);
	UPDATE_ENVIRONMENT_PROPERTY(FogDirInscatteringExponent);
	UPDATE_ENVIRONMENT_PROPERTY(FogDirInscatteringStartDist);
	UPDATE_ENVIRONMENT_PROPERTY(FogDirInscatteringColor);
	UPDATE_ENVIRONMENT_PROPERTY(FogMaxOpacity);
	UPDATE_ENVIRONMENT_PROPERTY(FogInscatteringDirection);
	END_ENVIRONMENT_PROPERTY

#if WITH_EDITOR
	UKismetRenderingLibrary::ClearRenderTarget2D(this, FogScaleMap, FLinearColor::White);
#endif

// 	if (FogScaleMap && FogScaleMapMaterial && !FogMapBounds.GetSize().IsZero())
// 	{
// #if UE_GAME
// 		bool isDirty = fogScaleMapDirty;
// 		if (!isDirty)
// 		{
// 			int Index = 0;
// 			for (isDirty = (Transitions.Num() != TransitionsAlpha.Num()); !isDirty && Index < Transitions.Num(); Index++)
// 			{
// 				if (TransitionsAlpha[Index] != Transitions[Index]->Alpha)
// 				{
// 					isDirty = true;
// 				}
// 			}
// 		}
// 		if (!isDirty)
// 			return;
// #endif
// 		
// 		TransitionsAlpha.Empty();
// 
// 		UKismetRenderingLibrary::ClearRenderTarget2D(this, FogScaleMap, FLinearColor::White);
// 
// 		for (int Index = 0; Index < Transitions.Num(); Index++)
// 		{
// 			auto Transition = Transitions[Index];
// 			auto TargetPreset = Transition->Preset;
// 			TransitionsAlpha.Add(Transition->Alpha);
// 			if (TargetPreset && TargetPreset->bFogScaleMap && TargetPreset->FogScaleMap)
// 			{
// 				FogScaleMapMaterial->SetTextureParameterValue("FogScaleMap", TargetPreset->FogScaleMap);
// 				FogScaleMapMaterial->SetScalarParameterValue("Alpha", Transition->Alpha);
// 				UKismetRenderingLibrary::DrawMaterialToRenderTarget(this, FogScaleMap, FogScaleMapMaterial);
// 			}
// 		}
// 		fogScaleMapDirty = false;
// 	}
 }

void AAzureEnvironmentManager::UpdateWindProperties(float DeltaTime)
{
	BEGIN_ENVIRONMENT_PROPERTY
	UPDATE_ENVIRONMENT_PROPERTY(WindIntensity);
	UPDATE_ENVIRONMENT_PROPERTY(WindSpeed);
	UPDATE_ENVIRONMENT_PROPERTY(WindStrength);
	UPDATE_ENVIRONMENT_PROPERTY(WindMinGustAmount);
	UPDATE_ENVIRONMENT_PROPERTY(WindMaxGustAmount);
	UPDATE_ENVIRONMENT_PROPERTY(WindDirection);
	UPDATE_ENVIRONMENT_PROPERTY(WindDisturbance);
	UPDATE_ENVIRONMENT_PROPERTY(WindDirectionDisturbance);
	END_ENVIRONMENT_PROPERTY

}

void AAzureEnvironmentManager::UpdateRainProperties(float DeltaTime)
{
	BEGIN_ENVIRONMENT_PROPERTY
	UPDATE_ENVIRONMENT_PROPERTY(RainIntensity);
	UPDATE_ENVIRONMENT_PROPERTY(RainRoughnessScale);
	UPDATE_ENVIRONMENT_PROPERTY(PuddleDepthScale);
	UPDATE_ENVIRONMENT_PROPERTY(RippleIntensity);
	UPDATE_ENVIRONMENT_PROPERTY(RippleUVScale);
	UPDATE_ENVIRONMENT_PROPERTY(RippleTimeScale);
	UPDATE_ENVIRONMENT_PROPERTY(PuddleWavesNormalIntensity);
	UPDATE_ENVIRONMENT_PROPERTY(PuddleWavesTimeScale);
	UPDATE_ENVIRONMENT_PROPERTY(PuddleWavesUVScale);
	END_ENVIRONMENT_PROPERTY
}

void AAzureEnvironmentManager::UpdateSnowProperties(float DeltaTime)
{
	BEGIN_ENVIRONMENT_PROPERTY
	UPDATE_ENVIRONMENT_PROPERTY(SnowIntensity);
	UPDATE_ENVIRONMENT_PROPERTY(SnowSide);
	UPDATE_ENVIRONMENT_PROPERTY(SnowSmooth);
	UPDATE_ENVIRONMENT_PROPERTY(SnowRoughnessScale);
	UPDATE_ENVIRONMENT_PROPERTY(SnowThreshold);
	UPDATE_ENVIRONMENT_PROPERTY(SnowMaskAmount);
	UPDATE_ENVIRONMENT_PROPERTY(SnowDirection);
	END_ENVIRONMENT_PROPERTY
}

void AAzureEnvironmentManager::UpdateGrassProperties(float DeltaTime)
{
	if (GetWorld() == nullptr)
		return;

	struct LandscapeItem
	{
		ALandscapeProxy* Landscape;
		FBox Bounds;
		float Distance;
	};

	bool bUpdateBounds = GrassBlockBounds.GetSize().X == 0 || GrassBlockBounds.GetSize().Y == 0;
	int RealBlockInMap = bUpdateBounds ? 1 : GrassBlockInMap;
	FBox RealBlockBounds = bUpdateBounds ? FBox(ForceInit) : GrassBlockBounds;

	TArray<LandscapeItem> Landscapes;
	for (TActorIterator<ALandscapeProxy> ActorIt(GetWorld()); ActorIt; ++ActorIt)
	{
		ALandscapeProxy* Landscape = *ActorIt;
		FBox Bounds(ForceInit);

		for (ULandscapeComponent* Component : Landscape->LandscapeComponents)
		{
			Bounds += Component->Bounds.GetBox();

			if (bUpdateBounds)
			{
				RealBlockBounds += Component->Bounds.GetBox();
			}
		}

		FVector Center = Bounds.GetCenter();
		FVector Offset = UAzureBlueprintFunctionLibrary::WorldWrapDistance(Center - CameraLocation);
		float Distance = FMath::Max(FMath::Abs(Offset.X), FMath::Abs(Offset.Y));
		Landscapes.Add({ Landscape, Bounds, Distance });
	}

	Landscapes.Sort(
		[&](const LandscapeItem& A, const LandscapeItem& B) {
		return A.Distance < B.Distance;
	});

	bool bDirty = false;

	for (int i = 0; i < RealBlockInMap * RealBlockInMap && i < Landscapes.Num(); i++)
	{
		ALandscapeProxy* Landscape = Landscapes[i].Landscape;
		UActorComponent* Component = Landscape->GetComponentByClass(UAzureLandscapeComponent::StaticClass());

		if (Component == nullptr)
			continue;

		UAzureLandscapeComponent* AzureLandscapeComponent = Cast<UAzureLandscapeComponent>(Component);

		if (AzureLandscapeComponent->LandscapeGrassColorMap == nullptr)
			continue;

#ifndef WITH_EDITOR
		if (GrassColorMapSet.Find(Landscape) != nullptr)
			continue;
#endif

		if (GrassColorMap && GrassColorMapMaterial)
		{
			bDirty = true;
			FLinearColor GrassMapScaleBias;
 			GrassMapScaleBias.R = 1.0f / RealBlockInMap;
 			GrassMapScaleBias.G = 1.0f / RealBlockInMap;
			FVector RealBlockSize = RealBlockBounds.GetSize();
			const FBox& Bounds = Landscapes[i].Bounds;
			GrassMapScaleBias.B = FMath::Frac((Bounds.Min.X - RealBlockBounds.Min.X) / RealBlockSize.X * GrassMapScaleBias.R);
			GrassMapScaleBias.A = FMath::Frac((Bounds.Min.Y - RealBlockBounds.Min.Y) / RealBlockSize.Y * GrassMapScaleBias.G);
			GrassColorMapMaterial->SetTextureParameterValue("GrassColorMap", AzureLandscapeComponent->LandscapeGrassColorMap);
			GrassColorMapMaterial->SetVectorParameterValue("GrassMapScaleBias", GrassMapScaleBias);
			UKismetRenderingLibrary::DrawMaterialToRenderTarget(this, GrassColorMap, GrassColorMapMaterial);
		}
	}

	if (bDirty)
	{
		GrassColorMapSet.Empty();

		for (int i = 0; i < RealBlockInMap * RealBlockInMap && i < Landscapes.Num(); i++)
		{
			GrassColorMapSet.Add(Landscapes[i].Landscape);
		}
	}
}

void AAzureEnvironmentManager::UpdateLightningProperties(float DeltaTime)
{
	BEGIN_ENVIRONMENT_PROPERTY
	UPDATE_ENVIRONMENT_PROPERTY(LightningIntensity);
	UPDATE_ENVIRONMENT_PROPERTY(LightningRate);
	UPDATE_ENVIRONMENT_PROPERTY(LightningHeight);
	END_ENVIRONMENT_PROPERTY
}

void AAzureEnvironmentManager::UpdateBloomProperties(float DeltaTime)
{
	BEGIN_ENVIRONMENT_PROPERTY
	UPDATE_ENVIRONMENT_PROPERTY(BloomIntensity);
	UPDATE_ENVIRONMENT_PROPERTY(BloomThreshold);
	UPDATE_ENVIRONMENT_PROPERTY(BloomIntensityWithToneMapping);
	UPDATE_ENVIRONMENT_PROPERTY(BloomThresholdWithToneMapping);
	END_ENVIRONMENT_PROPERTY

#if WITH_EDITORONLY_DATA
	if (bBakePreview)
	{
		BloomIntensity = 0.0;
		BloomThreshold = 0.0;
		BloomIntensityWithToneMapping = 0.0;
		BloomThresholdWithToneMapping = 0.0;
	}
#endif
}

void AAzureEnvironmentManager::UpdateBackgroundProperties(float DeltaTime)
{
	BEGIN_ENVIRONMENT_PROPERTY
	UPDATE_ENVIRONMENT_PROPERTY(WorldLayerDepth);
	UPDATE_ENVIRONMENT_PROPERTY(WorldLayerFog);
	UPDATE_ENVIRONMENT_PROPERTY(WorldLayerColor);
	UPDATE_ENVIRONMENT_PROPERTY(WorldRotationSpeed);
	END_ENVIRONMENT_PROPERTY

	WorldRotation += WorldRotationSpeed * DeltaTime;
}

void AAzureEnvironmentManager::UpdateOceanProperties(float DeltaTime)
{

}

void AAzureEnvironmentManager::UpdateSpecularIBLScaleProperties(float DeltaTime)
{
	BEGIN_ENVIRONMENT_PROPERTY
	UPDATE_ENVIRONMENT_PROPERTY(SpecularIBLScale);
	END_ENVIRONMENT_PROPERTY
}

void AAzureEnvironmentManager::UpdateAmbientProperties(float DeltaTime)
{
	BEGIN_ENVIRONMENT_PROPERTY
	UPDATE_ENVIRONMENT_PROPERTY(AmbientSH);
	END_ENVIRONMENT_PROPERTY
}

void AAzureEnvironmentManager::UpdateAuroraProperties(float DeltaTime)
{
	if (UseAurora)
	{		
		BEGIN_ENVIRONMENT_PROPERTY
		UPDATE_ENVIRONMENT_PROPERTY(AuroraTranslucent);
		END_ENVIRONMENT_PROPERTY
		
	}
}


void AAzureEnvironmentManager::UpdateShootingstarProperties(float DeltaTime)
{
	if (UseShootingstar && IsValid(ShootingStar))
	{	
		BEGIN_ENVIRONMENT_PROPERTY
		UPDATE_ENVIRONMENT_PROPERTY(ShootingStarThreshold);
		END_ENVIRONMENT_PROPERTY		
	}	
}

void AAzureEnvironmentManager::UpdateRainBowProperties(float DeltaTime)
{
	if (UseRainBow)
	{
		BEGIN_ENVIRONMENT_PROPERTY
		UPDATE_ENVIRONMENT_PROPERTY(RainBowTranslucent);
		END_ENVIRONMENT_PROPERTY

	}
}

void AAzureEnvironmentManager::UpdateCometProperties(float DeltaTime)
{
	if (UseComet && IsValid(Comet))
	{
		BEGIN_ENVIRONMENT_PROPERTY
		UPDATE_ENVIRONMENT_PROPERTY(CometThreshold);
		END_ENVIRONMENT_PROPERTY
	}
}

void AAzureEnvironmentManager::Apply(float DeltaTime)
{
	if (!bApply)
		return;

	ApplySunProperties(DeltaTime);	
	ApplyMoonProperties(DeltaTime);
	ApplyStarProperties(DeltaTime);
	ApplyCloudProperties(DeltaTime);
	ApplySkyProperties(DeltaTime);
	ApplyFogProperties(DeltaTime);
	ApplyWindProperties(DeltaTime);
	ApplyRainProperties(DeltaTime);
	ApplySnowProperties(DeltaTime);
	//ApplyGrassProperties(DeltaTime);
	ApplyLightningProperties(DeltaTime);
	ApplyBloomProperties(DeltaTime);
	ApplyBackgroundProperties(DeltaTime);
	ApplyCharacterProperties(DeltaTime);	
	ApplyBuildingProperties(DeltaTime);
	ApplyPointLightProperties(DeltaTime);
	ApplyNightEmissiveProperties(DeltaTime);
	ApplyPostColorProperties(DeltaTime);
	ApplyOceanProperties(DeltaTime);
	ApplyAmbientProperties(DeltaTime);
	ApplyAuroraProperties(DeltaTime);
	ApplyShootingStarProperties(DeltaTime);
	ApplyRainBowProperties(DeltaTime);
	ApplySpecularIBLScaleProperties(DeltaTime);
	ApplyCometProperties(DeltaTime);
	
	OnParameterChanged(DeltaTime);
}

void AAzureEnvironmentManager::GetDirectionalLights(TSet<ADirectionalLight*>& OutDirectionalLights)
{
	OutDirectionalLights.Reset();
	for (auto SunLight : SunLightSource)
	{
		if (IsValid(SunLight))
			OutDirectionalLights.Add(SunLight);
	}
	if (IsValid(MoonLightSource))
	{
		OutDirectionalLights.Add(MoonLightSource);
	}
}

void AAzureEnvironmentManager::ApplySunProperties(float DeltaTime)
{
	FRotator Roll = UKismetMathLibrary::RotatorFromAxisAndAngle(FVector(0.000000, 0.000000, 1.000000), SunAzimuth);
	FRotator Pitch = UKismetMathLibrary::RotatorFromAxisAndAngle(FVector(0.000000, 1.000000, 0.000000), SunZenith);
	SunDirection = UKismetMathLibrary::ComposeRotators(Pitch, Roll);
	SunHeight = -(UKismetMathLibrary::GetForwardVector(SunDirection).Z);

	FVector SunDirectionValue = UKismetMathLibrary::GetForwardVector(SunDirection);
	FVector MoonDirectionValue = UKismetMathLibrary::GetForwardVector(MoonDirection);

	UMaterialInstanceDynamic* SkyMaterial = Sky == nullptr ? nullptr : Sky->GetDynamicMaterial();
	if (IsValid(SkyMaterial))
	{
		BATCHSETMATERIALPARAMSHOLDER(SkyMaterial);
 		SkyMaterial->SetScalarParameterValue(SunRadiusName, SunRadius * 0.001f);
		SkyMaterial->SetScalarParameterValue(SunShineName, SunShine * 0.01f * SunColor.A);
		SkyMaterial->SetScalarParameterValue(SunOnCloudsScaleName, 0.0f);
		SkyMaterial->SetVectorParameterValue(SunColorName, SunColor);
		SkyMaterial->SetVectorParameterValue(SunDirectionName, SunDirectionValue);
	}

	if (SunLightSource.IsValidIndex(0))
	{
		ADirectionalLight* MainDirectionalLight = SunLightSource[0];
		if (IsValid(MainDirectionalLight))
		{
			if (UDirectionalLightComponent* Component = Cast<UDirectionalLightComponent>(MainDirectionalLight->GetLightComponent()))
			{
				if (bUpdateLightDirection)
				{
					if (IsDayTime())
					{
						MainDirectionalLight->SetActorRotation(SunDirection);
					}
					else
					{
						MainDirectionalLight->SetActorRotation(MoonDirection);
					}
				}

				if (FogInscatteringDirection.IsZero())
				{
					if (IsDayTime())
					{
						Component->SetFogInscatteringOverrideDirection(SunDirectionValue);
					}
					else
					{
						Component->SetFogInscatteringOverrideDirection(MoonDirectionValue);
					}
				}
				else
				{
					Component->SetFogInscatteringOverrideDirection(FogInscatteringDirection);
				}
				
				bool bUseLightShaft = UseLightShaft > 0;
				if (!Component->bEnableLightShaftBloom && bUseLightShaft)
				{
					Component->SetEnableLightShaftBloom(true);
				}
				else if (Component->bEnableLightShaftBloom && !bUseLightShaft)
				{
					Component->SetEnableLightShaftBloom(false);
				}
				if (Component->bEnableLightShaftBloom)
				{
					Component->SetBloomScale(LightShaftScale);
					Component->SetBloomTint(LightShaftTint.ToFColor(true));
					Component->SetLightShaftOverrideDirection(SunDirectionValue);
				}
			}
		}
	}

	float MoonIntensity = FMath::Clamp(1.0f - SunHeight * 4.0f, 0.0f, 1.0f);
	if (IsValid(MoonLightSource))
	{
		ULightComponent* Component = MoonLightSource->GetLightComponent();
		if (IsValid(Component))
		{
			if (!(Component->IsActive()) && MoonIntensity > 0.0f)
			{
				Component->SetActive(MoonIntensity > 0.0f, false);
			}
			else if (Component->IsActive() && MoonIntensity <= 0.0f)
			{
				Component->SetActive(MoonIntensity > 0.0f, false);
			}

			Component->SetLightColor(MoonColor * MoonIntensity);
			Component->SetTemperature(MoonTemperature);
			Component->SetCharacterTemperatureMaxLimit(CharacterTemperatureMax);
			float LightningScale = bLightning ? LightningBrightnessScale : 1;
			Component->SetIntensity(MoonExternalIntensity * LightningScale);
		}
		else
		{
			MoonIntensity = 0.0f;
		}
	}
	else
	{
		MoonIntensity = 0.0f;
	}

	FLinearColor SunLightColor = SunColor;
	FVector SunLightDirection = SunDirectionValue;
	float SunIntensity = 0.0f;
	if (SunLightSource.IsValidIndex(0))
	{
		if (IsValid(SunLightSource[0]))
		{
			SunIntensity = FMath::Clamp(1.0f - MoonIntensity, 0.0f, 1.0f);
			ULightComponent* Component = SunLightSource[0]->GetLightComponent();
			if (IsValid(Component))
			{
				Component->SetActive(false, false);
				Component->SetLightColor(FLinearColor(SkyLightBrightness * SunIntensity,
					SkyLightBrightness * SunIntensity,
					SkyLightBrightness * SunIntensity,
					SkyLightBrightness * SunIntensity), true);
				Component->SetTemperature(SunTemperature);
				Component->SetCharacterTemperatureMaxLimit(CharacterTemperatureMax);
				float LightningScale = bLightning ? LightningBrightnessScale : 1;
				Component->SetIntensity(SunExternalIntensity * LightningScale);

				SunLightColor = FLinearColor(Component->LightColor) * Component->ComputeLightBrightness();
				if (Component->bUseTemperature)
				{
					SunLightColor *= FLinearColor::MakeFromColorTemperature(Component->Temperature);
				}
			}
			SunLightDirection = UKismetMathLibrary::GetForwardVector(SunLightSource[0]->GetActorRotation());
		}
	}

	if (SunLightSource.IsValidIndex(1))
	{
		if (IsValid(SunLightSource[1]))
		{
			SunIntensity = FMath::Clamp(1.0f - MoonIntensity, 0.0f, 1.0f);
			ULightComponent* Component = SunLightSource[1]->GetLightComponent();
			if (IsValid(Component))
			{
				Component->SetActive(false, false);
				Component->SetTemperature(SunTemperature2);
				Component->SetCharacterTemperatureMaxLimit(CharacterTemperatureMax);
				Component->SetIntensity(SunExternalIntensity2);
			}
		}
	}

	if (IsValid(SunFlare))
	{
		SunFlare->bEnable = (!(SunShine < 1.0f));
		SunFlare->SetActorLocation(SunLightDirection * -100000.0f + CameraLocation);
	}

	UKismetMaterialLibrary::SetVectorParameterValue(this, EnvironmentParam, LightColorName, SunLightColor);
	UKismetMaterialLibrary::SetVectorParameterValue(this, EnvironmentParam, LightDirectionName, SunLightDirection);

	if (IsDayTime())
	{
		UKismetMaterialLibrary::SetVectorParameterValue(this, EnvironmentParam, DynamicSunColorName, SunColor);
		UKismetMaterialLibrary::SetVectorParameterValue(this, EnvironmentParam, DynamicSunDirectionName, SunDirectionValue);
	}
	else
	{
		UKismetMaterialLibrary::SetVectorParameterValue(this, EnvironmentParam, DynamicSunColorName, MoonColor);
		UKismetMaterialLibrary::SetVectorParameterValue(this, EnvironmentParam, DynamicSunDirectionName, MoonDirectionValue);
	}

	if (bUseSunPS && IsValid(SunEmitter))
	{	
		SunEmitter->SetActorLocation(SunDirectionValue * SunEffectOffset);
		SunEmitter->SetActorRotation(SunDirection);
		SunEmitter->SetActorScale3D(SunEffectScale);
		UParticleSystemComponent* Component = SunEmitter->GetParticleSystemComponent();
		if (IsValid(Component))
		{
			bool isVisiable = SunPSThreshold > 0 && IsDayTime();
			if (!Component->IsVisible() && isVisiable)
			{
				Component->SetVisibility(true, true);
			}
			else if (Component->IsVisible() && !isVisiable)
			{
				Component->SetVisibility(false, true);
			}

		}
	}
	
}

void AAzureEnvironmentManager::ApplyMoonProperties(float DeltaTime)
{
	FRotator MoonRoll = UKismetMathLibrary::RotatorFromAxisAndAngle(FVector(0.000000, 0.000000, 1.000000), MoonAzimuth);
	FRotator MoonPitch = UKismetMathLibrary::RotatorFromAxisAndAngle(FVector(0.000000, 1.000000, 0.000000), MoonZenith);
	MoonDirection = UKismetMathLibrary::ComposeRotators(MoonPitch, MoonRoll);

	FRotator Moon2Roll = UKismetMathLibrary::RotatorFromAxisAndAngle(FVector(0.000000, 0.000000, 1.000000), Moon2Azimuth);
	FRotator Moon2Pitch = UKismetMathLibrary::RotatorFromAxisAndAngle(FVector(0.000000, 1.000000, 0.000000), Moon2Zenith);
	Moon2Direction = UKismetMathLibrary::ComposeRotators(Moon2Pitch, Moon2Roll);

	FRotator Moon3Roll = UKismetMathLibrary::RotatorFromAxisAndAngle(FVector(0.000000, 0.000000, 1.000000), Moon3Azimuth);
	FRotator Moon3Pitch = UKismetMathLibrary::RotatorFromAxisAndAngle(FVector(0.000000, 1.000000, 0.000000), Moon3Zenith);
	Moon3Direction = UKismetMathLibrary::ComposeRotators(Moon3Pitch, Moon3Roll);

	FRotator Moon4Roll = UKismetMathLibrary::RotatorFromAxisAndAngle(FVector(0.000000, 0.000000, 1.000000), Moon4Azimuth);
	FRotator Moon4Pitch = UKismetMathLibrary::RotatorFromAxisAndAngle(FVector(0.000000, 1.000000, 0.000000), Moon4Zenith);
	Moon4Direction = UKismetMathLibrary::ComposeRotators(Moon4Pitch, Moon4Roll);

	UMaterialInstanceDynamic* SkyMaterial = Sky == nullptr ? nullptr : Sky->GetDynamicMaterial();
	if (IsValid(SkyMaterial))
	{
		BATCHSETMATERIALPARAMSHOLDER(SkyMaterial);

		float Radius = MoonRadius > 0.0f ? MoonRadius : 1.0f;
		SkyMaterial->SetVectorParameterValue(Moon1ColorName, MoonColor * FLinearColor(MoonBrightness, MoonBrightness, MoonBrightness, MoonShine));
		SkyMaterial->SetVectorParameterValue(Moon1DirectionUpName, (UKismetMathLibrary::GetUpVector(MoonDirection) / Radius));
		SkyMaterial->SetVectorParameterValue(Moon1DirectionSideName, (UKismetMathLibrary::GetRightVector(MoonDirection) / Radius));
		SkyMaterial->SetVectorParameterValue(Moon1DirectionFrontName, (UKismetMathLibrary::GetForwardVector(MoonDirection) / Radius));
		SkyMaterial->SetVectorParameterValue(MoonLightDirName, MoonLightDir);

		float Radius2 = Moon2Radius > 0.0f ? Moon2Radius : 1.0f;
		SkyMaterial->SetVectorParameterValue(Moon2ColorName, Moon2Color * FLinearColor(Moon2Brightness, Moon2Brightness, Moon2Brightness, Moon2Shine));
		SkyMaterial->SetVectorParameterValue(Moon2DirectionUpName, (UKismetMathLibrary::GetUpVector(Moon2Direction) / Radius2));
		SkyMaterial->SetVectorParameterValue(Moon2DirectionSideName, (UKismetMathLibrary::GetRightVector(Moon2Direction) / Radius2));
		SkyMaterial->SetVectorParameterValue(Moon2DirectionFrontName, (UKismetMathLibrary::GetForwardVector(Moon2Direction) / Radius2));
		SkyMaterial->SetVectorParameterValue(Moon2LightDirName, Moon2LightDir);

		float Radius3 = Moon3Radius > 0.0f ? Moon3Radius : 1.0f;
		SkyMaterial->SetVectorParameterValue(Moon3ColorName, Moon3Color * FLinearColor(Moon3Brightness, Moon3Brightness, Moon3Brightness, Moon3Shine));
		SkyMaterial->SetVectorParameterValue(Moon3DirectionUpName, (UKismetMathLibrary::GetUpVector(Moon3Direction) / Radius3));
		SkyMaterial->SetVectorParameterValue(Moon3DirectionSideName, (UKismetMathLibrary::GetRightVector(Moon3Direction) / Radius3));
		SkyMaterial->SetVectorParameterValue(Moon3DirectionFrontName, (UKismetMathLibrary::GetForwardVector(Moon3Direction) / Radius3));
		SkyMaterial->SetVectorParameterValue(Moon3LightDirName, Moon3LightDir);

		float Radius4 = Moon4Radius > 0.0f ? Moon4Radius : 1.0f;
		SkyMaterial->SetVectorParameterValue(Moon4ColorName, Moon4Color * FLinearColor(Moon4Brightness, Moon4Brightness, Moon4Brightness, Moon4Shine));
		SkyMaterial->SetVectorParameterValue(Moon4DirectionUpName, (UKismetMathLibrary::GetUpVector(Moon4Direction) / Radius4));
		SkyMaterial->SetVectorParameterValue(Moon4DirectionSideName, (UKismetMathLibrary::GetRightVector(Moon4Direction) / Radius4));
		SkyMaterial->SetVectorParameterValue(Moon4DirectionFrontName, (UKismetMathLibrary::GetForwardVector(Moon4Direction) / Radius4));
		SkyMaterial->SetVectorParameterValue(Moon4LightDirName, Moon4LightDir);
	}

	if (bUseMoonPS && IsValid(MoonEmitter))
	{
		FVector MoonDirectionValue = UKismetMathLibrary::GetForwardVector(MoonDirection);

		MoonEmitter->SetActorLocation(MoonDirectionValue * MoonEffectOffset);
		MoonEmitter->SetActorRotation(MoonDirection);
		MoonEmitter->SetActorScale3D(MoonEffectScale);
		UParticleSystemComponent* Component = MoonEmitter->GetParticleSystemComponent();
		if (IsValid(Component))
		{
			bool isVisiable = MoonPSThreshold > 0 && !IsDayTime();
			if (!Component->IsVisible() && isVisiable)
			{
				Component->SetVisibility(true, true);
			}
			else if (Component->IsVisible() && !isVisiable)
			{
				Component->SetVisibility(false, true);
			}

		}
	}
}

void AAzureEnvironmentManager::ApplyStarProperties(float DeltaTime)
{
	UMaterialInstanceDynamic* SkyMaterial = Sky == nullptr ? nullptr : Sky->GetDynamicMaterial();
	if (IsValid(SkyMaterial))
	{
		BATCHSETMATERIALPARAMSHOLDER(SkyMaterial);

		SkyMaterial->SetVectorParameterValue(StarsColorName, StarColor * StarBrightness);
		SkyMaterial->SetScalarParameterValue(StarHeightThresholdName, StarHeightThreshold);
		SkyMaterial->SetScalarParameterValue(StarLerpWidthName, StarLerpWidth);
		SkyMaterial->SetScalarParameterValue(GalaxyScaleName, GalaxyScale);
		SkyMaterial->SetScalarParameterValue(GalaxyRotationAngleName, GalaxyRotationAngle);
		SkyMaterial->SetScalarParameterValue(GalaxyIntensityName, GalaxyIntensity);
	}
}

void AAzureEnvironmentManager::ApplyCloudProperties(float DeltaTime)
{
	//float WindDispersingLayer1 = 45.0f;
	//float WindDispersingLayer2 = -45.0f;
	//float WindCloudLayerScale1 = 1.0f;
	//float WindCloudLayerScale2 = 0.5f;
	//FVector2D WindForceTmp = FVector2D(WindDirection.X, WindDirection.Y) * CloudLayersSpeed;
	//FVector2D XY = -RotateVec2(WindDispersingLayer1, WindForceTmp) * WindCloudLayerScale1;
	//FVector2D ZW = RotateVec2(WindDispersingLayer2, WindForceTmp) * WindCloudLayerScale2;
	//CloudLayersPosition += FLinearColor(XY.X, XY.Y, ZW.X, ZW.Y) * DeltaTime;

	UMaterialInstanceDynamic* SkyMaterial = Sky == nullptr ? nullptr : Sky->GetDynamicMaterial();

	if (IsValid(SkyMaterial))
	{
		BATCHSETMATERIALPARAMSHOLDER(SkyMaterial);

		SkyMaterial->SetScalarParameterValue(CloudsDensityName, CloudsDensity);
		SkyMaterial->SetScalarParameterValue(CloudsTranslucentName, CloudsTranslucent);

		SkyMaterial->SetScalarParameterValue(CloudsHardnessName, CloudsHardness);
		SkyMaterial->SetScalarParameterValue(CloudsBlendName, CloudsBlend);
		SkyMaterial->SetScalarParameterValue(CloudsDistortionName, CloudsDistortion);
		SkyMaterial->SetScalarParameterValue(CloudsScatteringName, CloudsScattering);
		SkyMaterial->SetScalarParameterValue(CloudsAmbientName, CloudsAmbient);
		SkyMaterial->SetScalarParameterValue(CloudsShadowSizeName, CloudsShadowSize);
		SkyMaterial->SetScalarParameterValue(CloudsShadowSoftName, CloudsShadowSoft);
		SkyMaterial->SetScalarParameterValue(CloudsHorizonDensityName, CloudsHorizonDensity);
		SkyMaterial->SetScalarParameterValue(CloudsHorizonName, CloudsHorizonAlpha);
		SkyMaterial->SetScalarParameterValue(CloudsHorizonScatteringName, CloudsHorizonScattering);
		FLinearColor CloudsLowerColorColorTmp = CloudsLowerColor * CloudsLowerBrightness;
		CloudsLowerColorColorTmp.A = CloudsLowerColor.A;
		FLinearColor CloudsLowerColorValue = ColorSaturation(CloudsLowerColorColorTmp, Saturation);
		SkyMaterial->SetVectorParameterValue(CloudsLowerColorName, CloudsLowerColorValue);
		FLinearColor CloudsUpperColorValue = ColorSaturation(CloudsUpperColor * CloudsUpperBrightness, Saturation);
		SkyMaterial->SetVectorParameterValue(CloudsUpperColorName, CloudsUpperColorValue);
		FLinearColor CloudsBackgroundColorValue = CloudsBackgroundColor * (CloudsBackgroundColor.A * CloudsBackgroundBrightness);
		SkyMaterial->SetVectorParameterValue(CloudsBackgroundColorName, CloudsBackgroundColorValue);
		
		SkyMaterial->SetVectorParameterValue(LayerScaleName, CloudLayersScale * CloudsScale);
		//SkyMaterial->SetVectorParameterValue(LayerPositionName, CloudLayersPosition);
		//SkyMaterial->SetVectorParameterValue(LayerSpeedName, FLinearColor(0.0f, 0.0f, 0.0f, 0.0f));
		SkyMaterial->SetVectorParameterValue(FarHorizonCloudsLowerColorName, FarHorizonCloudsLowerColor);
		SkyMaterial->SetVectorParameterValue(FarHorizonCloudsUpperColorName, FarHorizonCloudsUpperColor);
		SkyMaterial->SetVectorParameterValue(FarHorizonCloudsSpeedName, FarHorizonCloudsSpeed);
		SkyMaterial->SetScalarParameterValue(FarHorizonCloudsMaxOpacityName, FarHorizonCloudsMaxOpacity);
		SkyMaterial->SetVectorParameterValue(FarHorizonClouds1TilingOffsetName, FarHorizonClouds1TilingOffset);
		SkyMaterial->SetVectorParameterValue(FarHorizonClouds2TilingOffsetName, FarHorizonClouds2TilingOffset);
		if (FarHorizonCloudsTex != nullptr)
			SkyMaterial->SetTextureParameterValue(FarHorizonCloudsTexName, FarHorizonCloudsTex);
	}
}

void AAzureEnvironmentManager::ApplySkyProperties(float DeltaTime)
{
	UMaterialInstanceDynamic* SkyMaterial = Sky == nullptr ? nullptr : Sky->GetDynamicMaterial();

	if (IsValid(SkyMaterial))
	{
		BATCHSETMATERIALPARAMSHOLDER(SkyMaterial);

		FVector rg = -(UKismetMathLibrary::GetForwardVector(SunDirection) * HorizonTilt);
		float a = SkyUpperColor.A;
		float b = -(SkyLowerColor.A * HorizonFalloff);
		FLinearColor HorizonFalloffValue(rg.X, rg.Y, b, a);
		SkyMaterial->SetVectorParameterValue(HorizonFalloffName, HorizonFalloffValue);

		SkyMaterial->SetVectorParameterValue(HorizonUpperColorName, SkyUpperColor);
		SkyMaterial->SetVectorParameterValue(HorizonLowerColorName, SkyLowerColor);

		FLinearColor SkyLightColorTmp = ((SkyUpperColor * 0.7f + SkyLowerColor * 0.5f) * SkyLightBrightness) * WorldLayerColor;
		SkyMaterial->SetVectorParameterValue(SkyLightColorName, SkyLightColorTmp);

		SkyMaterial->SetScalarParameterValue(SkyFogDensityName, SkyFogDensity);
	}

	UKismetMaterialLibrary::SetVectorParameterValue(this, EnvironmentParam, SkyUpperColorName, SkyUpperColor);
	UKismetMaterialLibrary::SetVectorParameterValue(this, EnvironmentParam, SkyLowerColorName, SkyLowerColor);
}

void AAzureEnvironmentManager::ApplyFogProperties(float DeltaTime)
{
	if (IsValid(Fog))
	{
		UExponentialHeightFogComponent* Component = Fog->GetComponent();
		if (IsValid(Component))
		{
			FVector Location = Fog->GetActorLocation();
			
			if (CHECK_ENVIRONMENT_PROPERTY(FogHeight))
			{
				Location.Z = FogHeight * 100;
				Fog->SetActorLocation(Location);
			}
			if (CHECK_ENVIRONMENT_PROPERTY(FogColor))
			{
				Component->SetFogInscatteringColor(FogColor);
			}
			if (CHECK_ENVIRONMENT_PROPERTY(FogDensity))
			{
				float NewFogDensity = FogDensity * FogDensityScale + FogDensityOffset;
				Component->SetFogDensity(NewFogDensity);
			}
			if (CHECK_ENVIRONMENT_PROPERTY(FogStartDistance))
			{
				float NewFogStartDistance = FogStartDistance * FogStartDistanceScale + FogStartDistanceOffset;
				Component->SetStartDistance(NewFogStartDistance);
			}
			if (CHECK_ENVIRONMENT_PROPERTY(FogHeightFalloff))
			{
				float NewFogHeightFalloff = FogHeightFalloff * FogHeightFalloffScale + FogHeightFalloffOffset;
				Component->SetFogHeightFalloff(NewFogHeightFalloff);
			}
			if (CHECK_ENVIRONMENT_PROPERTY(FogDirInscatteringExponent))
			{
				Component->SetDirectionalInscatteringExponent(FogDirInscatteringExponent);
			}
			if (CHECK_ENVIRONMENT_PROPERTY(FogDirInscatteringStartDist))
			{
				Component->SetDirectionalInscatteringStartDistance(FogDirInscatteringStartDist);
			}
			if (CHECK_ENVIRONMENT_PROPERTY(FogDirInscatteringColor))
			{
				float LightningScale = bLightning ? FogDirInscatteringColorLightningScale : 1;
				Component->SetDirectionalInscatteringColor(FogDirInscatteringColor * LightningScale);
			}
			if (CHECK_ENVIRONMENT_PROPERTY(FogMaxOpacity))
			{
				Component->SetFogMaxOpacity(FogMaxOpacity);
			}
			
		}
	}

	if (IsValid(UnderWaterFog))
	{
		UnderWaterFog->GetRootComponent()->SetHiddenInGame(!EnableUnderWaterFog);
		//UnderWaterFog->GetRootComponent()->SetVisibility(EnableUnderWaterFog);
		if (EnableUnderWaterFog) 
		{
			UExponentialHeightFogComponent* Component = UnderWaterFog->GetComponent();
			if (IsValid(Component))
			{
				FVector Location = UnderWaterFog->GetActorLocation();
				Location.Z = UnderWaterFogHeight * 100;
				UnderWaterFog->SetActorLocation(Location);

				Component->SetFogInscatteringColor(UnderWaterFogDirInscatteringColor);

				Component->SetFogDensity(UnderWaterFogDensity);

				Component->SetStartDistance(UnderWaterFogStartDistance);

				Component->SetFogHeightFalloff(UnderWaterFogHeightFalloff);
			}
		}
		
	}

	return;
}

void AAzureEnvironmentManager::ApplyWindProperties(float DeltaTime)
{
	if (WindDirection.IsNearlyZero())
		WindDirection = LastWindDirection;
	else
		LastWindDirection = WindDirection;

	WindDirection.Normalize();

	FVector Direction = WindDirection + WindDirectionDisturbance;
	Direction.Normalize();

	if (WindSource != nullptr)
	{				
		WindSource->GetComponent()->SetSpeed(WindSpeed * WindDisturbance);
		WindSource->GetComponent()->SetStrength(WindStrength * WindDisturbance);
		WindSource->GetComponent()->SetMinimumGustAmount(WindMinGustAmount);
		WindSource->GetComponent()->SetMaximumGustAmount(WindMaxGustAmount);
		WindSource->SetActorRotation(FQuat::FindBetween(FVector::ForwardVector, Direction));
	}

	if (EnvironmentParam != nullptr)
	{
		if (CHECK_ENVIRONMENT_PROPERTY(WindDirection))
			UKismetMaterialLibrary::SetVectorParameterValue(this, EnvironmentParam, WindDirectionName, Direction);
//		if (CHECK_ENVIRONMENT_PROPERTY(WindWeight))
//			UKismetMaterialLibrary::SetScalarParameterValue(this, EnvironmentParam, WindWeightName, WindWeight);
	}
}

void AAzureEnvironmentManager::ApplyRainProperties(float DeltaTime)
{
	if (EnvironmentParam == nullptr)
		return;

	if (CHECK_ENVIRONMENT_PROPERTY(RainRoughnessScale))
		UKismetMaterialLibrary::SetScalarParameterValue(this, EnvironmentParam, RainRoughnessScaleName, RainRoughnessScale);
	if (CHECK_ENVIRONMENT_PROPERTY(RainIntensity))
		UKismetMaterialLibrary::SetScalarParameterValue(this, EnvironmentParam, RainIntensityName, RainIntensity);
	if (CHECK_ENVIRONMENT_PROPERTY(RippleIntensity))
		UKismetMaterialLibrary::SetScalarParameterValue(this, EnvironmentParam, RippleIntensityName, RippleIntensity);
	if (CHECK_ENVIRONMENT_PROPERTY(RippleUVScale))
		UKismetMaterialLibrary::SetScalarParameterValue(this, EnvironmentParam, RippleUVScaleName, RippleUVScale);
	if (CHECK_ENVIRONMENT_PROPERTY(RippleTimeScale))
		UKismetMaterialLibrary::SetScalarParameterValue(this, EnvironmentParam, RippleTimeScaleName, RippleTimeScale);

	if (CHECK_ENVIRONMENT_PROPERTY(PuddleDepthScale))
		UKismetMaterialLibrary::SetScalarParameterValue(this, EnvironmentParam, PuddleDepthScaleName, PuddleDepthScale);
	if (CHECK_ENVIRONMENT_PROPERTY(PuddleWavesNormalIntensity))
		UKismetMaterialLibrary::SetScalarParameterValue(this, EnvironmentParam, PuddleWavesNormalIntensityName, PuddleWavesNormalIntensity);
	if (CHECK_ENVIRONMENT_PROPERTY(PuddleWavesTimeScale))
		UKismetMaterialLibrary::SetScalarParameterValue(this, EnvironmentParam, PuddleWavesTimeScaleName, PuddleWavesTimeScale);
	if (CHECK_ENVIRONMENT_PROPERTY(PuddleWavesUVScale))
		UKismetMaterialLibrary::SetScalarParameterValue(this, EnvironmentParam, PuddleWavesUVScaleName, PuddleWavesUVScale);
}

void AAzureEnvironmentManager::ApplySnowProperties(float DeltaTime)
{
	if (EnvironmentParam == nullptr)
		return;

	if (CHECK_ENVIRONMENT_PROPERTY(SnowIntensity))
		UKismetMaterialLibrary::SetScalarParameterValue(this, EnvironmentParam, SnowIntensityName, SnowIntensity);
	//if (CHECK_ENVIRONMENT_PROPERTY(SnowIntensity))
		//UKismetMaterialLibrary::SetScalarParameterValue(this, EnvironmentParam, SnowIntensityName, SnowIntensity);
	if (CHECK_ENVIRONMENT_PROPERTY(SnowSide))
		UKismetMaterialLibrary::SetScalarParameterValue(this, EnvironmentParam, SnowSideName, SnowSide);
	if (CHECK_ENVIRONMENT_PROPERTY(SnowSmooth))
		UKismetMaterialLibrary::SetScalarParameterValue(this, EnvironmentParam, SnowSmoothName, SnowSmooth);
	if (CHECK_ENVIRONMENT_PROPERTY(SnowRoughnessScale))
		UKismetMaterialLibrary::SetScalarParameterValue(this, EnvironmentParam, SnowRoughnessScaleName, SnowRoughnessScale);
	if (CHECK_ENVIRONMENT_PROPERTY(SnowThreshold))
		UKismetMaterialLibrary::SetScalarParameterValue(this, EnvironmentParam, SnowThresholdName, SnowThreshold);
	if (CHECK_ENVIRONMENT_PROPERTY(SnowMaskAmount))
		UKismetMaterialLibrary::SetVectorParameterValue(this, EnvironmentParam, SnowMaskAmountName, SnowMaskAmount);
	if (CHECK_ENVIRONMENT_PROPERTY(SnowDirection))
		UKismetMaterialLibrary::SetVectorParameterValue(this, EnvironmentParam, SnowDirectionName, SnowDirection);
}

void AAzureEnvironmentManager::ApplyGrassProperties(float DeltaTime)
{
	if (EnvironmentParam == nullptr)
		return;
}

void AAzureEnvironmentManager::ApplyLightningProperties(float DeltaTime)
{
	if (EnvironmentParam == nullptr)
		return;
}

void AAzureEnvironmentManager::ApplyBloomProperties(float DeltaTime)
{
	if (bIsPhotoMode)
		return;

	static const auto ConsoleVariable = IConsoleManager::Get().FindTConsoleVariableDataInt(*ToneMapperFilmMobileConsoleName);
	int32 ConsoleMobiletonemapperfilm = ConsoleVariable->GetValueOnGameThread();

	for (int32 index = 0; index < PostProcessVolumesBloom.Num(); ++index)
	{
		APostProcessVolume* ppvb = PostProcessVolumesBloom[index];
		if (IsValid(ppvb))
		{
			if (ConsoleMobiletonemapperfilm >= 1)
			{
				if (CHECK_ENVIRONMENT_PROPERTY(BloomIntensityWithToneMapping))
					PostProcessVolumesBloom[index]->Settings.BloomIntensity = BloomIntensityWithToneMapping;
				if (CHECK_ENVIRONMENT_PROPERTY(BloomThresholdWithToneMapping))
					PostProcessVolumesBloom[index]->Settings.BloomThreshold = BloomThresholdWithToneMapping;
			}
			else
			{
				if (CHECK_ENVIRONMENT_PROPERTY(BloomIntensity))
					PostProcessVolumesBloom[index]->Settings.BloomIntensity = BloomIntensity;
				if (CHECK_ENVIRONMENT_PROPERTY(BloomThreshold))
					PostProcessVolumesBloom[index]->Settings.BloomThreshold = BloomThreshold;
			}
		}
	}
}

void AAzureEnvironmentManager::ApplyBackgroundProperties(float DeltaTime)
{
	UMaterialInstanceDynamic* SkyMaterial = Sky == nullptr ? nullptr : Sky->GetDynamicMaterial();

	if (IsValid(SkyMaterial))
	{
		BATCHSETMATERIALPARAMSHOLDER(SkyMaterial);

		FLinearColor WorldLayerSettingsTmp(WorldLayerDepth, WorldLayerFog, 5.0f, 0.0f);
		SkyMaterial->SetVectorParameterValue(WorldLayerSettingsName, WorldLayerSettingsTmp);

		SkyMaterial->SetScalarParameterValue(BackgroundRotationName, WorldRotation / 360.0f);
	}
}

void AAzureEnvironmentManager::ApplyCharacterProperties(float DeltaTime)
{
	if (ShouldCopyDataFromSkin)
	{
		CharacterEquipIndirectLightColor = CharacterIndirectLightColor;
		CharacterEquipIndirectLightScale = CharacterIndirectLightScale;
		CharacterEquipDirectLightScale = CharacterDirectLightScale;
	}

	for (APostProcessVolume* ppvb : PostProcessVolumesIndirectLight)
	{
		if (IsValid(ppvb))
		{
			if (CHECK_ENVIRONMENT_PROPERTY(CharacterIndirectLightColor))
			{
				ppvb->Settings.bOverride_AzureIndirectCharacterSkinLightingColor = true;
				ppvb->Settings.AzureIndirectCharacterSkinLightingColor = CharacterIndirectLightColor;
			}
		
			ppvb->Settings.bOverride_AzureIndirectCharacterEquipLightingColor = true;
			ppvb->Settings.AzureIndirectCharacterEquipLightingColor = CharacterEquipIndirectLightColor;
				
		}
	}

	if (CHECK_ENVIRONMENT_PROPERTY(CharacterIndirectLightScale))
		UKismetMaterialLibrary::SetScalarParameterValue(this, EnvironmentParam, CharacterSkinIndirectLightScaleName, CharacterIndirectLightScale);
	if (CHECK_ENVIRONMENT_PROPERTY(CharacterDirectLightScale))
		UKismetMaterialLibrary::SetScalarParameterValue(this, EnvironmentParam, CharacterSkinDirectLightScaleName, CharacterDirectLightScale);
	

	UKismetMaterialLibrary::SetScalarParameterValue(this, EnvironmentParam, CharacterEquipIndirectLightScaleName, CharacterEquipIndirectLightScale);	
	UKismetMaterialLibrary::SetScalarParameterValue(this, EnvironmentParam, CharacterEquipDirectLightScaleName, CharacterEquipDirectLightScale);
	
}

void AAzureEnvironmentManager::ApplyBuildingProperties(float DeltaTime)
{
	for (APostProcessVolume* ppvb : PostProcessVolumesIndirectLight)
	{
		if (IsValid(ppvb))
		{
			if (CHECK_ENVIRONMENT_PROPERTY(IndirectLightColor))
				ppvb->Settings.IndirectLightingColor = IndirectLightColor;
			if (CHECK_ENVIRONMENT_PROPERTY(IndirectLightIntensity))
				ppvb->Settings.IndirectLightingIntensity = IndirectLightIntensity;
		}
	}
}

void AAzureEnvironmentManager::ApplyPointLightProperties(float DeltaTime)
{
	UWorld* World = GetWorld();
	if (World)
	{
		TArray<UActorComponent*> AllPointLightComponents;

		for (TActorIterator<AAzureEnvironmentActor> ActorIt(World); ActorIt; ++ActorIt)
		{
			AAzureEnvironmentActor* EnvironmentActor = Cast<AAzureEnvironmentActor>(*ActorIt);
			if (EnvironmentActor)
			{
				TArray<UActorComponent*> Components = EnvironmentActor->GetComponentsByClass(UPointLightComponent::StaticClass());
				if (Components.Num() > 0)
				{
					AllPointLightComponents.Append(Components);
				}
			}
		}

		for (TActorIterator<APointLight> ActorIt(World); ActorIt; ++ActorIt)
		{
			APointLight* PointLight = Cast<APointLight>(*ActorIt);
			if (PointLight)
			{
				UActorComponent* Component = PointLight->PointLightComponent;
				AllPointLightComponents.Add(Component);
			}
		}

		for (UActorComponent* Component : AllPointLightComponents)
		{
			UPointLightComponent* PointLightComponent = Cast<UPointLightComponent>(Component);
			if (PointLightComponent)
			{
				if (!PointLightComponent->IsAzureUseGlobalIntensity())
					continue;

				if (CHECK_ENVIRONMENT_PROPERTY(PointLightIntensity))
				{
					float Scale = PointLightComponent->GetAzureIntensityScale();
					float Intensity = PointLightIntensity * Scale;
					PointLightComponent->SetIntensity(Intensity);
					if (Intensity >= PointLightComponent->GetAzureIntensityThreshold())
					{
						if (!PointLightComponent->IsVisible())
						{
							PointLightComponent->SetVisibility(true, true);
						}
					}
					else
					{
						if (PointLightComponent->IsVisible())
						{
							PointLightComponent->SetVisibility(false, true);
						}
					}
				}
			}
		}
			
	}
}

void AAzureEnvironmentManager::ApplyNightEmissiveProperties(float DeltaTime)
{
	if (EnvironmentParam == nullptr)
		return;

	if (CHECK_ENVIRONMENT_PROPERTY(NightEmissivePositive))
		UKismetMaterialLibrary::SetScalarParameterValue(this, EnvironmentParam, NightEmissivePositiveName, NightEmissivePositive);
	if (CHECK_ENVIRONMENT_PROPERTY(NightEmissiveNegative))
		UKismetMaterialLibrary::SetScalarParameterValue(this, EnvironmentParam, NightEmissiveNegativeName, NightEmissiveNegative);
}

void AAzureEnvironmentManager::ApplyPostColorProperties(float DeltaTime)
{
	for (APostProcessVolume* ppvb : PostProcessVolumesPostColor)
	{
		if (IsValid(ppvb))
		{
			if (CHECK_ENVIRONMENT_PROPERTY(PostForegroundColorScale))
				ppvb->Settings.AzurePostForegroundColorScale = PostForegroundColorScale;
			if (CHECK_ENVIRONMENT_PROPERTY(PostBackgroundColorScale))
				ppvb->Settings.AzurePostBackgroundColorScale = PostBackgroundColorScale;
		}
	}
}

void AAzureEnvironmentManager::ApplyOceanProperties(float DeltaTime)
{
	UWorld* World = GetWorld();
	if (World)
	{
		for(auto OceanMesh : AOceanMeshActor::GetAllOceanMeshInstances())
		{
			OceanMesh->SetTimeOfDay(TimeOfDay);
			OceanMesh->UpdateMaterial();
		}
	}
}

void AAzureEnvironmentManager::ApplySpecularIBLScaleProperties(float DeltaTime)
{
	UWorld* World = GetWorld();
	if (World)
	{
		FSceneInterface* SceneInterface = World->Scene;
		if (SceneInterface)
		{
			if (CHECK_ENVIRONMENT_PROPERTY(SpecularIBLScale))
			{
				FVector Params(SpecularIBLScale);
				SceneInterface->AzureUpdateSpecularIBLScaleParams(Params);
				UKismetMaterialLibrary::SetVectorParameterValue(this, EnvironmentParam, SpecularIBLScaleName, Params);
			}
		}
	}
}

void AAzureEnvironmentManager::ApplyAmbientProperties(float DeltaTime)
{
	UWorld* World = GetWorld();
	if (World)
	{
		FSceneInterface* SceneInterface = World->Scene;
		if (SceneInterface)
		{
			if (CHECK_ENVIRONMENT_PROPERTY(AmbientSH))
			{
				FAzureGlobalSHIndirectLightingParams SHParams;
				FMemory::Memcpy(SHParams.SHCoefficients, AmbientSH.SHCoefficients, sizeof(AmbientSH.SHCoefficients));
				SceneInterface->AzureUpdateGlobalSHIndirectLightingParams(SHParams);
			}
		}
	}
}

void AAzureEnvironmentManager::ApplyAuroraProperties(float DeltaTime)
{
	if (UseAurora)
	{
		for (AStaticMeshActor* Aurora : AuroraList)
		{
			if (IsValid(Aurora))
			{
				UStaticMeshComponent* Component = Aurora->GetStaticMeshComponent();
				if (IsValid(Component))
				{
					if (AuroraTranslucent > 0)
					{
						if (!(Component->IsVisible()))
						{
							Component->SetVisibility(true, true);
						}
					}
					else
					{
						Component->SetVisibility(false, true);
					}

				}

			}
		}
		UKismetMaterialLibrary::SetScalarParameterValue(this, EnvironmentParam, AuroraTranslucentName, AuroraTranslucent);
	}
	
}

void AAzureEnvironmentManager::ApplyRainBowProperties(float DeltaTime)
{
	
	if (UseRainBow)
	{

		for (AStaticMeshActor* RainBow : RainBowList)
		{
			if (IsValid(RainBow))
			{
				UStaticMeshComponent* Component = RainBow->GetStaticMeshComponent();
				if (IsValid(Component))
				{
					if (RainBowTranslucent > 0)
					{
						if (!(Component->IsVisible()))
						{
							Component->SetVisibility(true, true);
						}
					}
					else
					{
						Component->SetVisibility(false, true);
					}

				}

			}
		}

		UKismetMaterialLibrary::SetScalarParameterValue(this, EnvironmentParam, RainBowTranslucentName, RainBowTranslucent);
	}
}

void AAzureEnvironmentManager::ApplyShootingStarProperties(float DeltaTime)
{
	if (UseShootingstar && IsValid(ShootingStar))
	{
		UParticleSystemComponent* Component = ShootingStar->GetParticleSystemComponent();
		if (IsValid(Component))
		{
			bool isVisiable = ShootingStarThreshold > 0 && !IsDayTime();
			if (!Component->IsVisible() && isVisiable)
			{
				Component->SetVisibility(true, true);
			}
			else if (Component->IsVisible() && !isVisiable)
			{
				Component->SetVisibility(false, true);
			}
				
		}
	}
}

void AAzureEnvironmentManager::ApplyCometProperties(float DeltaTime)
{
	if (UseComet && IsValid(Comet))
	{
		UParticleSystemComponent* Component = Comet->GetParticleSystemComponent();
		if (IsValid(Component))
		{
			bool isVisiable = CometThreshold > 0 && !IsDayTime();
			if (!Component->IsVisible() && isVisiable)
			{
				Component->SetVisibility(true, true);
			}
			else if (Component->IsVisible() && !isVisiable)
			{
				Component->SetVisibility(false, true);
			}

		}
	}
}

int AAzureEnvironmentManager::GetWeather()
{
	return CurrentWeatherIndex;
}

void AAzureEnvironmentManager::ChangeWeather(int WeatherIndex)
{
	if (WeatherIndex == CurrentWeatherIndex)
		return;

	UAzureEnvironmentTransition* TargetWeather = nullptr;
	if (WeatherIndex >= 0 && WeatherIndex < WeatherPresets.Num() && WeatherPresets[WeatherIndex].Get())
	{
		TargetWeather = NewObject<UAzureEnvironmentTransition>(this);
		TargetWeather->Type = EAzureEnvironmentTransitionType::Time;
		TargetWeather->Preset = NewObject<UAzureEnvironmentPreset>(this, WeatherPresets[WeatherIndex]);
		TargetWeather->bDelay = false;
		TargetWeather->Duration = 5;
	}

	if (WeatherIndex != CurrentWeatherIndex)
	{
		CurrentWeather->bDelay = true;
		CurrentWeather->Duration = 5;
		PopTransition(CurrentWeather);
		PushTransition(TargetWeather);
		CurrentWeather = TargetWeather;
		CurrentWeatherIndex = WeatherIndex;
	}
}

UAzureEnvironmentPreset* AAzureEnvironmentManager::GetPreset(TSubclassOf<UAzureEnvironmentPreset> Class)
{
	for (UAzureEnvironmentTransition* Transition : Transitions)
	{
		if (Transition->Preset && Transition->Preset->IsA(Class))
		{
			return Transition->Preset;
		}
	}

	return nullptr;
}

UAzureEnvironmentPreset* AAzureEnvironmentManager::GetActivePreset()
{
	if (Transitions.Num() > 0)
		return Transitions.Last()->Preset;
	return nullptr;
}

void AAzureEnvironmentManager::PushPreset(UAzureEnvironmentPreset* Target, float Duration, bool bDelay)
{
	if (Target == nullptr)
		return;

	UAzureEnvironmentTransition* TargetTransition = nullptr;

	for (auto Transition : Transitions)
	{
		//checkf(Transition,TEXT("Transition must not be nullptr! =%p"), Transition);
		if (Transition && !Transition->bVolume)
		{
			if (Transition->Preset == Target)
			{
				TargetTransition = Transition;
				break;
			}
		}
	}

	if (TargetTransition == nullptr)
	{
		TargetTransition = NewObject<UAzureEnvironmentTransition>();
		TargetTransition->Type = EAzureEnvironmentTransitionType::Time;
		TargetTransition->Preset = Target;
	}

	TargetTransition->bDelay = bDelay;
	TargetTransition->Duration = Duration;

	PushTransition(TargetTransition);
}

void AAzureEnvironmentManager::PushTransition(UAzureEnvironmentTransition* Target)
{
	if (Target == nullptr)
		return;

	bool bExists = false;
	for (auto Transition : Transitions)
	{
		if (Transition == Target)
		{
			bExists = true;
			break;
		}
	}

	if (bExists && Target->bEnable)
	{
		UE_LOG(LogAzureEnvironmentManager, Log, TEXT("Environment transition already exists %x"), Target);
		return;
	}

	if (!Target->bEnable)
	{
		Target->bEnable = true;
		Target->Alpha = 0;
	}

	fogScaleMapDirty = true;

	if (!bExists)
	{
		UClass* EditingClass = nullptr;

#if WITH_EDITORONLY_DATA
		EditingClass = EditingPreset.Get();
#endif

		Transitions.RemoveAll([this](UAzureEnvironmentTransition* p) { return p == nullptr; });
		Transitions.Add(Target);
		Transitions.StableSort(
			[&](const UAzureEnvironmentTransition& A, const UAzureEnvironmentTransition& B) {
			UAzureEnvironmentPreset* PA = A.Preset;
			UAzureEnvironmentPreset* PB = B.Preset;
			if (A.bEnable != B.bEnable)
			{
				if (A.bEnable) return false;
				if (B.bEnable) return true;
			}
			if (!PA)
				return false;
			if (!PB)
				return true;
			int PriorityA = (EditingClass && PA->IsA(EditingClass)) ? INT_MAX : PA->Priority;
			int PriorityB = (EditingClass && PB->IsA(EditingClass)) ? INT_MAX : PB->Priority;
			return PriorityA < PriorityB;
		});
	}
}

void AAzureEnvironmentManager::PopPreset(UAzureEnvironmentPreset* Source, float Duration, bool bDelay)
{
	if (Source == nullptr)
		return;

	UAzureEnvironmentTransition* SourceTransition = nullptr;

	if (Source != nullptr)
	{
		for (auto Transition : Transitions)
		{
			if (Transition && !Transition->bVolume)
			{
				if (Transition->Preset == Source)
				{
					SourceTransition = Transition;
					break;
				}
			}
		}
	}

	if (SourceTransition == nullptr)
	{
		UE_LOG(LogAzureEnvironmentManager, Log, TEXT("Can not find environment preset %x"), Source);
		return;
	}

	SourceTransition->bDelay = bDelay;
	SourceTransition->Duration = Duration;

	PopTransition(SourceTransition);
}

void AAzureEnvironmentManager::PopTransition(UAzureEnvironmentTransition* Source)
{
	if (Source == nullptr)
		return;

	bool bExists = false;
	for (auto Transition : Transitions)
	{
		if (Transition == Source)
		{
			bExists = true;
			break;
		}
	}

	if (!bExists)
	{
		UE_LOG(LogAzureEnvironmentManager, Log, TEXT("Can not find environment transition %x"), Source);
		return;
	}

	Source->bEnable = false;
}

void AAzureEnvironmentManager::LoadFromPreset(UAzureEnvironmentPreset* Preset)
{
	Preset->Evaluate(TimeOfDay);

	SkyUpperColor = Preset->SkyUpperColor;
	SkyLowerColor = Preset->SkyLowerColor;
	SkyLightBrightness = Preset->SkyLightBrightness;
	HorizonTilt = Preset->HorizonTilt;
	HorizonFalloff = Preset->HorizonFalloff;

	SunZenith = Preset->SunZenith;
	SunAzimuth = Preset->SunAzimuth;
	SunRadius = Preset->SunRadius;
	SunShine = Preset->SunShine;
	SunColor = Preset->SunColor;
	SunPSThreshold = Preset->SunPSThreshold;
	SunEffectScale = Preset->SunEffectScale;

	UseLightShaft = Preset->UseLightShaft;
	LightShaftScale = Preset->LightShaftScale;
	LightShaftTint = Preset->LightShaftTint;

	SunTemperature = Preset->SunTemperature;
	SunTemperature2 = Preset->SunTemperature2;
	SunExternalIntensity = Preset->SunExternalIntensity;
	SunExternalIntensity2 = Preset->SunExternalIntensity2;

	MoonZenith = Preset->MoonZenith;
	MoonAzimuth = Preset->MoonAzimuth;
	MoonRadius = Preset->MoonRadius;
	MoonShine = Preset->MoonShine;
	MoonColor = Preset->MoonColor;
	MoonBrightness = Preset->MoonBrightness;
	MoonLightDir = Preset->MoonLightDir;

	Moon2Zenith = Preset->Moon2Zenith;
	Moon2Azimuth = Preset->Moon2Azimuth;
	Moon2Radius = Preset->Moon2Radius;
	Moon2Shine = Preset->Moon2Shine;
	Moon2Color = Preset->Moon2Color;
	Moon2Brightness = Preset->Moon2Brightness;
	Moon2LightDir = Preset->Moon2LightDir;

	Moon3Zenith = Preset->Moon3Zenith;
	Moon3Azimuth = Preset->Moon3Azimuth;
	Moon3Radius = Preset->Moon3Radius;
	Moon3Shine = Preset->Moon3Shine;
	Moon3Color = Preset->Moon3Color;
	Moon3Brightness = Preset->Moon3Brightness;
	Moon3LightDir = Preset->Moon3LightDir;

	Moon4Zenith = Preset->Moon4Zenith;
	Moon4Azimuth = Preset->Moon4Azimuth;
	Moon4Radius = Preset->Moon4Radius;
	Moon4Shine = Preset->Moon4Shine;
	Moon4Color = Preset->Moon4Color;
	Moon4Brightness = Preset->Moon4Brightness;
	Moon4LightDir = Preset->Moon4LightDir;

	MoonPSThreshold = Preset->MoonPSThreshold;
	MoonEffectScale = Preset->MoonEffectScale;
	MoonTemperature = Preset->MoonTemperature;
	MoonExternalIntensity = Preset->MoonExternalIntensity;

	StarBrightness = Preset->StarBrightness;
	StarColor = Preset->StarColor;
	StarHeightThreshold = Preset->StarHeightThreshold;
	StarLerpWidth = Preset->StarLerpWidth;
	GalaxyScale = Preset->GalaxyScale;
	GalaxyRotationAngle = Preset->GalaxyRotationAngle;
	GalaxyIntensity = Preset->GalaxyIntensity;

	CloudsDensity = Preset->CloudsDensity;
	CloudsTranslucent = Preset->CloudsTranslucent;
	CloudsScale = Preset->CloudsScale;
	CloudsHardness = Preset->CloudsHardness;
	CloudsBlend = Preset->CloudsBlend;
	CloudsDistortion = Preset->CloudsDistortion;
	CloudsScattering = Preset->CloudsScattering;
	CloudsAmbient = Preset->CloudsAmbient;
	CloudsShadowSize = Preset->CloudsShadowSize;
	CloudsShadowSoft = Preset->CloudsShadowSoft;
	CloudsHorizonDensity = Preset->CloudsHorizonDensity;
	CloudsHorizonAlpha = Preset->CloudsHorizonAlpha;
	CloudsHorizonScattering = Preset->CloudsHorizonScattering;
	CloudsUpperColor = Preset->CloudsUpperColor;
	CloudsUpperBrightness = Preset->CloudsUpperBrightness;
	CloudsLowerColor = Preset->CloudsLowerColor;
	CloudsLowerBrightness = Preset->CloudsLowerBrightness;
	CloudsBackgroundColor = Preset->CloudsBackgroundColor;
	CloudsBackgroundBrightness = Preset->CloudsBackgroundBrightness;

	CloudLayersScale = Preset->CloudLayersScale;
	//CloudLayersSpeed = Preset->CloudLayersSpeed;

	FarHorizonCloudsLowerColor = Preset->FarHorizonCloudsLowerColor;
	FarHorizonCloudsUpperColor = Preset->FarHorizonCloudsUpperColor;
	FarHorizonCloudsSpeed = Preset->FarHorizonCloudsSpeed;
	FarHorizonCloudsMaxOpacity = Preset->FarHorizonCloudsMaxOpacity;
	FarHorizonClouds1TilingOffset = Preset->FarHorizonClouds1TilingOffset;
	FarHorizonClouds2TilingOffset = Preset->FarHorizonClouds2TilingOffset;
	FarHorizonCloudsTex = Preset->FarHorizonCloudsTex;

	FogColor = Preset->FogColor;
	FogDensity = Preset->FogDensity;
	FogDensityScale = Preset->FogDensityScale;
	FogDensityOffset = Preset->FogDensityOffset;
	FogStartDistance = Preset->FogStartDistance;
	FogStartDistanceScale = Preset->FogStartDistanceScale;
	FogStartDistanceOffset = Preset->FogStartDistanceOffset;
	FogHeightFalloff = Preset->FogHeightFalloff;
	FogHeightFalloffScale = Preset->FogHeightFalloffScale;
	FogHeightFalloffOffset = Preset->FogHeightFalloffOffset;
	FogDirInscatteringExponent = Preset->FogDirInscatteringExponent;
	FogDirInscatteringStartDist = Preset->FogDirInscatteringStartDist;
	FogDirInscatteringColor = Preset->FogDirInscatteringColor;
	FogMaxOpacity = Preset->FogMaxOpacity;
	FogInscatteringDirection = Preset->FogInscatteringDirection;

	WindIntensity = Preset->WindIntensity;
	WindSpeed = Preset->WindSpeed;
	WindStrength = Preset->WindStrength;
	WindMinGustAmount = Preset->WindMinGustAmount;
	WindMaxGustAmount = Preset->WindMaxGustAmount;
	WindDirection = Preset->WindDirection;
	WindDisturbance = Preset->WindDisturbance;
	WindDirectionDisturbance = Preset->WindDirectionDisturbance;

	RainIntensity = Preset->RainIntensity;
	RainRoughnessScale = Preset->RainRoughnessScale;
	PuddleDepthScale = Preset->PuddleDepthScale;
	RippleIntensity = Preset->RippleIntensity;
	RippleUVScale = Preset->RippleUVScale;
	RippleTimeScale = Preset->RippleTimeScale;
	PuddleWavesNormalIntensity = Preset->PuddleWavesNormalIntensity;
	PuddleWavesTimeScale = Preset->PuddleWavesTimeScale;
	PuddleWavesUVScale = Preset->PuddleWavesUVScale;

	SnowIntensity = Preset->SnowIntensity;
	SnowSide = Preset->SnowSide;
	SnowSmooth = Preset->SnowSmooth;
	SnowRoughnessScale = Preset->SnowRoughnessScale;
	SnowThreshold = Preset->SnowThreshold;
	SnowMaskAmount = Preset->SnowMaskAmount;
	SnowDirection = Preset->SnowDirection;

	LightningIntensity = Preset->LightningIntensity;
	LightningRate = Preset->LightningRate;
	LightningHeight = Preset->LightningHeight;

	BloomIntensity = Preset->BloomIntensity;
	BloomThreshold = Preset->BloomThreshold;
	BloomIntensityWithToneMapping = Preset->BloomIntensityWithToneMapping;
	BloomThresholdWithToneMapping = Preset->BloomThresholdWithToneMapping;

	WorldLayerDepth = Preset->WorldLayerDepth;
	WorldLayerFog = Preset->WorldLayerFog;
	WorldLayerColor = Preset->WorldLayerColor;
	WorldRotationSpeed = Preset->WorldRotationSpeed;

	CharacterIndirectLightScale = Preset->CharacterIndirectLightScale;
	CharacterDirectLightScale = Preset->CharacterDirectLightScale;
	CharacterIndirectLightColor = Preset->CharacterIndirectLightColor;

	CharacterEquipIndirectLightScale = ShouldCopyDataFromSkin ? Preset->CharacterIndirectLightScale : Preset->CharacterEquipIndirectLightScale;
	CharacterEquipDirectLightScale = ShouldCopyDataFromSkin ? Preset->CharacterDirectLightScale : Preset->CharacterEquipDirectLightScale;
	CharacterEquipIndirectLightColor = ShouldCopyDataFromSkin ? Preset->CharacterIndirectLightColor : Preset->CharacterEquipIndirectLightColor;
	CharacterTemperatureMax = Preset->CharacterTemperatureMax;

	IndirectLightIntensity = Preset->IndirectLightIntensity;
	IndirectLightColor = Preset->IndirectLightColor;

	PointLightIntensity = Preset->PointLightIntensity;

	NightEmissivePositive = Preset->NightEmissivePositive;
	NightEmissiveNegative = Preset->NightEmissiveNegative;

	PostForegroundColorScale = Preset->PostForegroundColorScale;
	PostBackgroundColorScale = Preset->PostBackgroundColorScale;

	AmbientSH = Preset->AmbientSH;

	AuroraTranslucent = Preset->AuroraTranslucent;
	ShootingStarThreshold = Preset->ShootingStarThreshold;
	RainBowTranslucent = Preset->RainBowTranslucent;
	CometThreshold = Preset->CometThreshold;
}

void AAzureEnvironmentManager::SaveToPreset(UAzureEnvironmentPreset* Preset)
{
	Preset->Weather = Weather;

	Preset->SkyUpperColor = SkyUpperColor;
	Preset->SkyLowerColor = SkyLowerColor;
	Preset->SkyLightBrightness = SkyLightBrightness;
	Preset->HorizonTilt = HorizonTilt;
	Preset->HorizonFalloff = HorizonFalloff;

	Preset->SunZenith = SunZenith;
	Preset->SunAzimuth = SunAzimuth;
	Preset->SunRadius = SunRadius;
	Preset->SunShine = SunShine;
	Preset->SunColor = SunColor;
	Preset->SunPSThreshold = SunPSThreshold;
	Preset->SunEffectScale = SunEffectScale;

	Preset->UseLightShaft = UseLightShaft;
	Preset->LightShaftScale = LightShaftScale;
	Preset->LightShaftTint = LightShaftTint;

	Preset->SunTemperature = SunTemperature;
	Preset->SunTemperature2 = SunTemperature2;
	Preset->SunExternalIntensity = SunExternalIntensity;
	Preset->SunExternalIntensity2 = SunExternalIntensity2;

	Preset->MoonZenith = MoonZenith;
	Preset->MoonAzimuth = MoonAzimuth;
	Preset->MoonRadius = MoonRadius;
	Preset->MoonShine = MoonShine;
	Preset->MoonColor = MoonColor;
	Preset->MoonBrightness = MoonBrightness;
	Preset->MoonLightDir = MoonLightDir;

	Preset->Moon2Zenith = Moon2Zenith;
	Preset->Moon2Azimuth = Moon2Azimuth;
	Preset->Moon2Radius = Moon2Radius;
	Preset->Moon2Shine = Moon2Shine;
	Preset->Moon2Color = Moon2Color;
	Preset->Moon2Brightness = Moon2Brightness;
	Preset->Moon2LightDir = Moon2LightDir;

	Preset->Moon3Zenith = Moon3Zenith;
	Preset->Moon3Azimuth = Moon3Azimuth;
	Preset->Moon3Radius = Moon3Radius;
	Preset->Moon3Shine = Moon3Shine;
	Preset->Moon3Color = Moon3Color;
	Preset->Moon3Brightness = Moon3Brightness;
	Preset->Moon3LightDir = Moon3LightDir;

	Preset->Moon4Zenith = Moon4Zenith;
	Preset->Moon4Azimuth = Moon4Azimuth;
	Preset->Moon4Radius = Moon4Radius;
	Preset->Moon4Shine = Moon4Shine;
	Preset->Moon4Color = Moon4Color;
	Preset->Moon4Brightness = Moon4Brightness;
	Preset->Moon4LightDir = Moon4LightDir;

	Preset->MoonPSThreshold = MoonPSThreshold;
	Preset->MoonEffectScale = MoonEffectScale;

	Preset->MoonTemperature = MoonTemperature;
	Preset->MoonExternalIntensity = MoonExternalIntensity;

	Preset->StarBrightness = StarBrightness;
	Preset->StarColor = StarColor;
	Preset->StarHeightThreshold = StarHeightThreshold;
	Preset->StarLerpWidth = StarLerpWidth;
	Preset->GalaxyScale = GalaxyScale;
	Preset->GalaxyRotationAngle = GalaxyRotationAngle;
	Preset->GalaxyIntensity = GalaxyIntensity;

	Preset->CloudsDensity = CloudsDensity;
	Preset->CloudsTranslucent = CloudsTranslucent;
	Preset->CloudsScale = CloudsScale;
	Preset->CloudsHardness = CloudsHardness;
	Preset->CloudsBlend = CloudsBlend;
	Preset->CloudsDistortion = CloudsDistortion;
	Preset->CloudsScattering = CloudsScattering;
	Preset->CloudsAmbient = CloudsAmbient;
	Preset->CloudsShadowSize = CloudsShadowSize;
	Preset->CloudsShadowSoft = CloudsShadowSoft;
	Preset->CloudsHorizonDensity = CloudsHorizonDensity;
	Preset->CloudsHorizonAlpha = CloudsHorizonAlpha;
	Preset->CloudsHorizonScattering = CloudsHorizonScattering;
	Preset->CloudsUpperColor = CloudsUpperColor;
	Preset->CloudsUpperBrightness = CloudsUpperBrightness;
	Preset->CloudsLowerColor = CloudsLowerColor;
	Preset->CloudsLowerBrightness = CloudsLowerBrightness;
	Preset->CloudsBackgroundColor = CloudsBackgroundColor;
	Preset->CloudsBackgroundBrightness = CloudsBackgroundBrightness;

	Preset->CloudLayersScale = CloudLayersScale;
	//Preset->CloudLayersSpeed = CloudLayersSpeed;

	Preset->FarHorizonCloudsLowerColor = FarHorizonCloudsLowerColor;
	Preset->FarHorizonCloudsUpperColor = FarHorizonCloudsUpperColor;
	Preset->FarHorizonCloudsSpeed = FarHorizonCloudsSpeed;
	Preset->FarHorizonCloudsMaxOpacity = FarHorizonCloudsMaxOpacity;
	Preset->FarHorizonClouds1TilingOffset = FarHorizonClouds1TilingOffset;
	Preset->FarHorizonClouds2TilingOffset = FarHorizonClouds2TilingOffset;
	Preset->FarHorizonCloudsTex = FarHorizonCloudsTex;

	Preset->FogColor = FogColor;
	Preset->FogDensity = FogDensity;
	Preset->FogDensityScale = FogDensityScale;
	Preset->FogDensityOffset = FogDensityOffset;
	Preset->FogStartDistance = FogStartDistance;
	Preset->FogStartDistanceScale = FogStartDistanceScale;
	Preset->FogStartDistanceOffset = FogStartDistanceOffset;
	Preset->FogHeightFalloff = FogHeightFalloff;
	Preset->FogHeightFalloffScale = FogHeightFalloffScale;
	Preset->FogHeightFalloffOffset = FogHeightFalloffOffset;
	Preset->FogDirInscatteringExponent = FogDirInscatteringExponent;
	Preset->FogDirInscatteringStartDist = FogDirInscatteringStartDist;
	Preset->FogDirInscatteringColor = FogDirInscatteringColor;
	Preset->FogMaxOpacity = FogMaxOpacity;
	Preset->FogInscatteringDirection = FogInscatteringDirection;

	Preset->WindIntensity = WindIntensity;
	Preset->WindSpeed = WindSpeed;
	Preset->WindStrength = WindStrength;
	Preset->WindMinGustAmount = WindMinGustAmount;
	Preset->WindMaxGustAmount = WindMaxGustAmount;
	Preset->WindDirection = WindDirection;
	Preset->WindDisturbance = WindDisturbance;
	Preset->WindDirectionDisturbance = WindDirectionDisturbance;

	Preset->RainIntensity = RainIntensity;
	Preset->RainRoughnessScale = RainRoughnessScale;
	Preset->PuddleDepthScale = PuddleDepthScale;
	Preset->RippleIntensity = RippleIntensity;
	Preset->RippleUVScale = RippleUVScale;
	Preset->RippleTimeScale = RippleTimeScale;
	Preset->PuddleWavesNormalIntensity = PuddleWavesNormalIntensity;
	Preset->PuddleWavesTimeScale = PuddleWavesTimeScale;
	Preset->PuddleWavesUVScale = PuddleWavesUVScale;

	Preset->SnowIntensity = SnowIntensity;
	Preset->SnowSide = SnowSide;
	Preset->SnowSmooth = SnowSmooth;
	Preset->SnowRoughnessScale = SnowRoughnessScale;
	Preset->SnowThreshold = SnowThreshold;
	Preset->SnowMaskAmount = SnowMaskAmount;
	Preset->SnowDirection = SnowDirection;

	Preset->LightningIntensity = LightningIntensity;
	Preset->LightningRate = LightningRate;
	Preset->LightningHeight = LightningHeight;

	Preset->BloomIntensity = BloomIntensity;
	Preset->BloomThreshold = BloomThreshold;
	Preset->BloomIntensityWithToneMapping = BloomIntensityWithToneMapping;
	Preset->BloomThresholdWithToneMapping = BloomThresholdWithToneMapping;

	Preset->WorldLayerDepth = WorldLayerDepth;
	Preset->WorldLayerFog = WorldLayerFog;
	Preset->WorldLayerColor = WorldLayerColor;
	Preset->WorldRotationSpeed = WorldRotationSpeed;

	Preset->CharacterIndirectLightScale = CharacterIndirectLightScale;
	Preset->CharacterDirectLightScale = CharacterDirectLightScale;
	Preset->CharacterIndirectLightColor = CharacterIndirectLightColor;
	Preset->CharacterEquipIndirectLightScale = ShouldCopyDataFromSkin ? CharacterIndirectLightScale : CharacterEquipIndirectLightScale;
	Preset->CharacterEquipDirectLightScale = ShouldCopyDataFromSkin ? CharacterDirectLightScale : CharacterEquipDirectLightScale;
	Preset->CharacterEquipIndirectLightColor = ShouldCopyDataFromSkin ? CharacterIndirectLightColor : CharacterEquipIndirectLightColor;
	Preset->CharacterTemperatureMax = CharacterTemperatureMax;

	Preset->IndirectLightIntensity = IndirectLightIntensity;
	Preset->IndirectLightColor = IndirectLightColor;

	Preset->PointLightIntensity = PointLightIntensity;

	Preset->NightEmissivePositive = NightEmissivePositive;
	Preset->NightEmissiveNegative = NightEmissiveNegative;

	Preset->PostForegroundColorScale = PostForegroundColorScale;
	Preset->PostBackgroundColorScale = PostBackgroundColorScale;

	Preset->AmbientSH = AmbientSH;
	Preset->AuroraTranslucent = AuroraTranslucent;
	Preset->ShootingStarThreshold = ShootingStarThreshold;
	Preset->RainBowTranslucent = RainBowTranslucent;
	Preset->CometThreshold = CometThreshold;
}

FVector2D AAzureEnvironmentManager::RotateVec2(float Angle, FVector2D Vector)
{
	float cosd = UKismetMathLibrary::DegCos(Angle);
	float sind = UKismetMathLibrary::DegSin(Angle);
	float x = Vector.X, y = Vector.Y;
	FVector2D Result((cosd * x) - (sind * y), (sind * x) + (cosd * y));
	return Result;
}

FLinearColor AAzureEnvironmentManager::ColorSaturation(FLinearColor LinearColor, float Alpha)
{
	FVector VectorRGB(LinearColor.R, LinearColor.G, LinearColor.B);
	float VectorBaseValue = FVector::DotProduct(VectorRGB, FVector(0.2125, 0.7154, 0.0721));
	FVector VectorBase(VectorBaseValue, VectorBaseValue, VectorBaseValue);
	FVector Vector = UKismetMathLibrary::VLerp(VectorBase, VectorRGB, Alpha);
	FLinearColor Result(Vector.X, Vector.Y, Vector.Z, LinearColor.A);
	return Result;
}

void AAzureEnvironmentManager::AddSimuWindAzureComp(UAzureObjectComponent* Comp)
{
	if (!Comp)
		return;

	AActor* pActor = Comp->GetOwner();
	TArray<UActorComponent*> Components = pActor->GetComponentsByClass(USkeletalMeshComponent::StaticClass());
	for (auto item : Components)
	{
		USkeletalMeshComponent* skeletalMesh = Cast<USkeletalMeshComponent>(item);
		if (skeletalMesh)
		{
			if (!SimuWindForceComponents.Contains(skeletalMesh))
			{
				SimuWindForceComponents.Add(skeletalMesh);
			}
		}
	}
}

void AAzureEnvironmentManager::RemoveSimuWindAzureComp(UAzureObjectComponent* Comp)
{
	if (!Comp)
		return;

	AActor* pActor = Comp->GetOwner();
	TArray<UActorComponent*> Components = pActor->GetComponentsByClass(USkeletalMeshComponent::StaticClass());
	for (auto item : Components)
	{
		USkeletalMeshComponent* skeletalMesh = Cast<USkeletalMeshComponent>(item);
		if (skeletalMesh)
		{
			if (SimuWindForceComponents.Contains(skeletalMesh))
				SimuWindForceComponents.Remove(skeletalMesh);
		}
	}
}

void AAzureEnvironmentManager::ClearSimuWindAzureComps()
{
	SimuWindForceComponents.Empty();
}

void AAzureEnvironmentManager::TickHighFrequency(float DeltaTime)
{
	if (SimuWind != nullptr)
	{
		WindLocation += WindDirection * SimuWind->m_fCombinedStrength * DeltaTime;
		WindLocation.X = FMath::Fmod(WindLocation.X, 1000);
		WindLocation.Y = FMath::Fmod(WindLocation.Y, 1000);
		WindLocation.Z = FMath::Fmod(WindLocation.Z, 1000);
	}

	if (EnvironmentParam != nullptr && SimuWind != nullptr)
	{
		UKismetMaterialLibrary::SetVectorParameterValue(this, EnvironmentParam, WindLocationName, WindLocation);
	}

}

void AAzureEnvironmentManager::TickSimuWindAzureComps(float DeltaTime)
{
	double CurTime = FPlatformTime::Seconds();

	if (WindForceMulCurve != nullptr)
	{
		float Duration = 1.0f;
		float Index = WindForceMulCurve->FloatCurve.Keys.Num() - 1;
		if (Index > 0)
		{
			Duration = WindForceMulCurve->FloatCurve.Keys[Index].Time;
			Duration = FMath::Max(Duration, 1.0f);
		}
		double Alpha = (CurTime - WindForceMulCurveStart) * WindForceMulCurveScale;
		if (Alpha > Duration)
		{
			Alpha = 0;
			WindForceMulCurveStart = CurTime;
			WindForceMulCurveScale = FMath::RandRange(0.8f, 1.2f);
		}
		WindForceMul = WindForceMulCurve->GetFloatValue(Alpha);
	}

	if (WindForceAddCurve != nullptr)
	{
		float Duration = 1.0f;
		float Index = WindForceAddCurve->FloatCurve.Keys.Num() - 1;
		if (Index > 0)
		{
			Duration = WindForceAddCurve->FloatCurve.Keys[Index].Time;
			Duration = FMath::Max(Duration, 1.0f);
		}
		double Alpha = (CurTime - WindForceAddCurveStart) * WindForceAddCurveScale;
		if (Alpha > Duration)
		{
			Alpha = 0;
			WindForceAddCurveStart = CurTime;
			WindForceAddCurveScale = FMath::RandRange(0.8f, 1.2f);
		}
		WindForceAdd = WindForceAddCurve->GetFloatValue(Alpha);
	}

	FVector SimuWindForce(0, 0, 0);

	if (SimuWind)
	{
		if (GetWorld())
		{
			SimuWind->SetStrength(WindSpeed);
			SimuWind->SetGustMin(WindMinGustAmount);
			SimuWind->SetGustMax(WindMaxGustAmount);
			SimuWind->SetDirection(WindDirection);
			SimuWind->Advance(true, FPlatformTime::Seconds());
		}

		FVector SimuDirection(SimuWind->m_afDirection[0], SimuWind->m_afDirection[1], SimuWind->m_afDirection[2]);
		FQuat SimuQuat = FQuat::FindBetweenVectors(FVector::ForwardVector, SimuDirection.GetSafeNormal());
		float SimuWindStrength = FMath::Max(SimuWind->m_fCombinedStrength * WindForceMul + WindForceAdd, 0.01f);
		SimuWindForce = SimuQuat * SimuDirection * SimuWindStrength;
	}

	SimuWindForce *= PhysForceBaseMultiply;

#if UE_EDITOR
	if (bWindTestMode)
	{
		UWorld* World = GetWorld();
		if (World)
		{
			TSet<UActorComponent*> Comps;
			for (TActorIterator<AActor> ActorIt(World); ActorIt; ++ActorIt)
			{
				AActor* Actor = *ActorIt;
				UActorComponent* Comp = Actor->GetComponentByClass(USkeletalMeshComponent::StaticClass());
				if (Comp)
				{
					Comps.Add(Comp);
				}
			}

			TSet<UActorComponent*> RemoveComps;
			for (auto Item : SimuWindForceComponents)
			{
				if (!Comps.Find(Item.Get()))
				{
					RemoveComps.Add(Item.Get());
				}
			}

			for (UActorComponent* Comp : RemoveComps)
			{
				SimuWindForceComponents.Remove(Comp);
			}

			for (UActorComponent* Comp : Comps)
			{
				if (SimuWindForceComponents.Contains(Comp))
				{
					SimuWindForceComponents.Add(Comp);
					USkeletalMeshComponent* SkelComp = Cast<USkeletalMeshComponent>(Comp);
					SkelComp->SetCollisionProfileName(UCollisionProfile::NoCollision_ProfileName);
				}
			}
		}
	}
#endif

	for (auto itr = SimuWindForceComponents.CreateIterator(); itr; ++itr)
	{
		float fRandComp = 1.0f; //FMath::RandRange(0.8f, 1.2f);

#if WITH_EDITOR
		if (bWindTestMode)
		{
			USkeletalMeshComponent* Comp = Cast<USkeletalMeshComponent>(itr->Get());
			if (Comp)
			{
				UAnimInstance* AnimInstance = Comp->GetPostProcessInstance();
				if (AnimInstance)
				{
					UStructProperty* Property = FindField<UStructProperty>(AnimInstance->GetClass(), "ExternalForce");
					if (Property)
					{
						*(Property->ContainerPtrToValuePtr<FVector>(AnimInstance)) = SimuWindForce * fRandComp;
					}
				}

				int Num = Comp->GetNumChildrenComponents();
				for (int i = 0; i < Num; i++)
				{
					USkeletalMeshComponent* SubComp = Cast<USkeletalMeshComponent>(Comp->GetChildComponent(i - 1));
					if (SubComp)
					{
						UAnimInstance* AnimInstance = SubComp->GetPostProcessInstance();
						if (AnimInstance)
						{
							UStructProperty* Property = FindField<UStructProperty>(AnimInstance->GetClass(), "ExternalForce");
							if (Property)
							{
								*(Property->ContainerPtrToValuePtr<FVector>(AnimInstance)) = SimuWindForce * fRandComp;
							}
						}
					}
				}
			}
		}
		else
#endif
		{
			if (itr->IsValid())
			{
				USkeletalMeshComponent* Comp = Cast<USkeletalMeshComponent>(itr->Get());
				if (Comp)
				{
					UAnimInstance* AnimInstance = Comp->GetPostProcessInstance();
					if (AnimInstance)
					{
						UStructProperty* Property = FindField<UStructProperty>(AnimInstance->GetClass(), "ExternalForce");
						if (Property)
						{
							*(Property->ContainerPtrToValuePtr<FVector>(AnimInstance)) = SimuWindForce * fRandComp;
						}
					}
				}
				else
					itr.RemoveCurrent();
			}
			else
			{
				itr.RemoveCurrent();
			}
		}
	}

	if (EnvironmentParam != nullptr && SimuWind != nullptr)
	{
		UKismetMaterialLibrary::SetScalarParameterValue(this, EnvironmentParam, WindStrenghtName, SimuWind->m_fCombinedStrength);
	}
}


void AAzureEnvironmentManager::InitShootingstar()
{
#if UE_EDITOR
	if (UseShootingstar)
	{
		if (!IsValid(ShootingStar))
		{
			AEmitter* ShootingStarEmitter = Cast<AEmitter>(GetWorld()->SpawnActor(AEmitter::StaticClass(), &ShootingStarTransform));
			if (IsValid(ShootingStarEmitter))
			{
				ShootingStarEmitter->SetActorLabel(TEXT("ShootingStartEffect"));
				UParticleSystemComponent* ParticleSystemComponent = ShootingStarEmitter->GetParticleSystemComponent();
				if (IsValid(ParticleSystemComponent))
				{
					if (!IsValid(ParticleSystemComponent->Template))
					{
						ParticleSystemComponent->SetTemplate(PS_ShootingStarTemplate);
					}
					ShootingStar = ShootingStarEmitter;
				}
			}
		}
	}
	else
	{
		if (IsValid(ShootingStar))
		{
			GetWorld()->DestroyActor(ShootingStar);
			ShootingStar = nullptr;
			return;
		}
	}
#endif
}

void AAzureEnvironmentManager::InitComet()
{
#if UE_EDITOR
	if (UseComet)
	{
		if (!IsValid(Comet))
		{
			AEmitter* CometEmitter = Cast<AEmitter>(GetWorld()->SpawnActor(AEmitter::StaticClass(), &CometTransform));
			if (IsValid(CometEmitter))
			{
				CometEmitter->SetActorLabel(TEXT("CometEffect"));
				UParticleSystemComponent* ParticleSystemComponent = CometEmitter->GetParticleSystemComponent();
				if (IsValid(ParticleSystemComponent))
				{
					if (!IsValid(ParticleSystemComponent->Template))
					{
						ParticleSystemComponent->SetTemplate(PS_CometTemplate);
					}
					Comet = CometEmitter;
				}
			}
		}
	}
	else
	{
		if (IsValid(Comet))
		{
			GetWorld()->DestroyActor(Comet);
			Comet = nullptr;
			return;
		}
	}
#endif
}


void AAzureEnvironmentManager::InitAllAurora()
{
#if UE_EDITOR
	TArray<FTransform *>  Transforms = { &AuroraSimpleTransform, &AuroraComplexTransform,  &AuroraSpiralTransform };
	TArray<UStaticMesh *> Meshes = { SM_AuroraSimple, SM_AuroraComplex, SM_AuroraSpiral };
	TArray<FString> LabelNames = { TEXT("SimpleAurora"), TEXT("ComplexAurora"), TEXT("SpiralAurora") };
	check(Transforms.Num() == Meshes.Num());


	bool isValid = AuroraList.Num() == Meshes.Num();
	for (AStaticMeshActor* AuroraMesh : AuroraList)
	{
		if (!isValid || !AuroraMesh->IsA(AuroraClass))
		{
			isValid = false;
			GetWorld()->DestroyActor(AuroraMesh);
		}
	}

	if (isValid)
		return;

	AuroraList.Empty();

	for (size_t i = 0; i < Transforms.Num(); ++i)
	{
		AStaticMeshActor* AuroraActor = Cast<AStaticMeshActor>(GetWorld()->SpawnActor(AuroraClass, Transforms[i]));
		if (!IsValid(AuroraActor))
			break;
		AuroraActor->SetActorLabel(LabelNames[i]);
		AuroraActor->GetStaticMeshComponent()->SetStaticMesh(Meshes[i]);
		AuroraList.Add(AuroraActor);

	}

	if (AuroraList.Num() != Meshes.Num())
	{
		for (AStaticMeshActor* AuroraMesh : AuroraList)
		{
			GetWorld()->DestroyActor(AuroraMesh);
		}
		AuroraList.Empty();
	}
#endif
}

void AAzureEnvironmentManager::InitAllRainBow()
{
#if UE_EDITOR
	TArray<FTransform *> Tansforms = { &SmallRainBowTransform, &LargeRainBowTransform };
	TArray<UStaticMesh *> Meshes = { SM_RainBowSmall, SM_RainBowLarge };
	TArray<FString> LabelNames = { TEXT("SmallRainBow"), TEXT("LargeRainBow") };
	check(Tansforms.Num() == Meshes.Num());


	bool isValid = RainBowList.Num() == Meshes.Num();
	for (AStaticMeshActor* RainBowMesh : RainBowList)
	{
		if (!isValid || !RainBowMesh->IsA(AuroraClass))
		{
			isValid = false;
			GetWorld()->DestroyActor(RainBowMesh);
		}
	}

	if (isValid)
		return;

	RainBowList.Empty();

	for (size_t i = 0; i < Tansforms.Num(); ++i)
	{
		AStaticMeshActor* RainBowActor = Cast<AStaticMeshActor>(GetWorld()->SpawnActor(AuroraClass, Tansforms[i]));
		if (!IsValid(RainBowActor))
			break;

		RainBowActor->SetActorLabel(LabelNames[i]);
		RainBowActor->GetStaticMeshComponent()->SetStaticMesh(Meshes[i]);
		RainBowList.Add(RainBowActor);

	}

	if (RainBowList.Num() != Meshes.Num())
	{
		for (AStaticMeshActor* RainBowMesh : RainBowList)
		{
			GetWorld()->DestroyActor(RainBowMesh);
		}
		RainBowList.Empty();
	}
#endif
}

void AAzureEnvironmentManager::InitAurora()
{
#if UE_EDITOR
	if (UseAurora)
	{
		InitAllAurora();
	}
	else	
	{
		for (AStaticMeshActor* AuroraMesh : AuroraList)
		{
			if (IsValid(AuroraMesh))
			{
				GetWorld()->DestroyActor(AuroraMesh);
			}
		}
		AuroraList.Empty();
	}
#endif
}

void AAzureEnvironmentManager::InitRainBow()
{
#if UE_EDITOR
	if (UseRainBow)
	{
		InitAllRainBow();
	}
	else
	{
		for (AStaticMeshActor* RainBowMesh : RainBowList)
		{
			if (IsValid(RainBowMesh))
			{
				GetWorld()->DestroyActor(RainBowMesh);
			}
		}
		RainBowList.Empty();
	}
#endif
}


void AAzureEnvironmentManager::Dump()
{
	UE_LOG(LogAzureEnvironmentManager, Log, TEXT("Environment Dump:"));
	for (int i = 0; i < Transitions.Num(); i++)
	{
		const UAzureEnvironmentTransition* Transition = Transitions[i];
		if (Transition && Transition->Preset)
		{
			UE_LOG(LogAzureEnvironmentManager, Log, TEXT("  Preset: %s"), *Transition->Preset->GetFName().ToString());
			UE_LOG(LogAzureEnvironmentManager, Log, TEXT("    ID: %d"), i);
			UE_LOG(LogAzureEnvironmentManager, Log, TEXT("    Alpha: %f"), Transition->Alpha);
			UE_LOG(LogAzureEnvironmentManager, Log, TEXT("    Priority: %d"), Transition->Preset->Priority);
		}
	}

	UObject* Object = this;
	UE_LOG(LogAzureEnvironmentManager, Log, TEXT("  Final Property:"));
	UClass* Class = Object->GetClass();
	for (TFieldIterator<UProperty> PropIt(Class); PropIt; ++PropIt)
	{
		if (PropIt->IsA(UFloatProperty::StaticClass()))
		{
			UFloatProperty* Prop = Cast<UFloatProperty>(*PropIt);
			FString Name = Prop->GetNameCPP();
			float Value = *(Prop->ContainerPtrToValuePtr<float>(Object));
			UE_LOG(LogAzureEnvironmentManager, Log, TEXT("    %s: %f"), *Name, Value);
		}
		else if (PropIt->IsA(UStructProperty::StaticClass()))
		{
			UStructProperty* Prop = Cast<UStructProperty>(*PropIt);
			FString Name = Prop->GetNameCPP();
			FString Type = Prop->GetCPPType(nullptr, 0);
			if (Type == "FVector")
			{
				FVector Value = *(Prop->ContainerPtrToValuePtr<FVector>(Object));
				UE_LOG(LogAzureEnvironmentManager, Log, TEXT("    %s: %f, %f, %f"), *Name, Value.X, Value.Y, Value.Z);
			}
			else if (Type == "FLinearColor")
			{
				FLinearColor Value = *(Prop->ContainerPtrToValuePtr<FLinearColor>(Object));
				UE_LOG(LogAzureEnvironmentManager, Log, TEXT("    %s: %f, %f, %f"), *Name, Value.R, Value.G, Value.B);
			}
		}
	}
}

void AAzureEnvironmentManager::DumpPreset(int id)
{
	if (id < 0 || id >= Transitions.Num())
	{
		UE_LOG(LogAzureEnvironmentManager, Log, TEXT("Preset id is wrong: %d"), id);
		return;
	}

	const UAzureEnvironmentTransition* Transition = Transitions[id];
	if (!Transition || !Transition->Preset)
	{
		UE_LOG(LogAzureEnvironmentManager, Log, TEXT("Preset is nullptr: %d"), id);
		return;
	}

	UObject* Object = Transition->Preset;
	UE_LOG(LogAzureEnvironmentManager, Log, TEXT("  Preset: %s"), *Object->GetFName().ToString());
	UClass* Class = Object->GetClass();
	for (TFieldIterator<UProperty> PropIt(Class); PropIt; ++PropIt)
	{
		if (PropIt->IsA(UFloatProperty::StaticClass()))
		{
			UFloatProperty* Prop = Cast<UFloatProperty>(*PropIt);
			FString Name = Prop->GetNameCPP();
			FString BoolName = "b" + Name;
			UBoolProperty* BoolProp = Cast<UBoolProperty>(Class->FindPropertyByName(*BoolName));
			if (BoolProp && BoolProp->GetPropertyValue_InContainer(Object))
			{
				float Value = *(Prop->ContainerPtrToValuePtr<float>(Object));
				UE_LOG(LogAzureEnvironmentManager, Log, TEXT("    %s: %f"), *Name, Value);
			}
		}
		else if (PropIt->IsA(UStructProperty::StaticClass()))
		{
			UStructProperty* Prop = Cast<UStructProperty>(*PropIt);
			FString Name = Prop->GetNameCPP();
			FString BoolName = "b" + Name;
			UBoolProperty* BoolProp = Cast<UBoolProperty>(Class->FindPropertyByName(*BoolName));
			if (BoolProp && BoolProp->GetPropertyValue_InContainer(Object))
			{
				FString Type = Prop->GetCPPType(nullptr, 0);
				if (Type == "FVector")
				{
					FVector Value = *(Prop->ContainerPtrToValuePtr<FVector>(Object));
					UE_LOG(LogAzureEnvironmentManager, Log, TEXT("    %s: %f, %f, %f"), *Name, Value.X, Value.Y, Value.Z);
				}
				else if (Type == "FLinearColor")
				{
					FLinearColor Value = *(Prop->ContainerPtrToValuePtr<FLinearColor>(Object));
					UE_LOG(LogAzureEnvironmentManager, Log, TEXT("    %s: %f, %f, %f"), *Name, Value.R, Value.G, Value.B);
				}
			}
		}
	}
}

#if WITH_EDITOR

void AAzureEnvironmentManager::UpdateSptShadowFlag(UWorld* World, ULevel* Level)
{
	SetSptShadowFlag(World, Level, true);
}

void AAzureEnvironmentManager::ClearSptShadowFlag(UWorld* World, ULevel* Level)
{
	SetSptShadowFlag(World, Level, false);
}

void AAzureEnvironmentManager::SetSptShadowFlag(UWorld* World, ULevel* Level, bool bEnable)
{
	TSet<UHierarchicalInstancedStaticMeshComponent*> InstStaticMeshComps;
	for (TActorIterator<AActor> ActorIt(World); ActorIt; ++ActorIt)
	{
		AActor* Actor = *ActorIt;
		for (UActorComponent * c : Actor->GetComponentsByClass(UStaticMeshComponent::StaticClass()))
		{
			UStaticMeshComponent* StaticMeshComp = Cast<UStaticMeshComponent>(c);
			UStaticMesh* StaticMesh = StaticMeshComp->GetStaticMesh();
			if (StaticMesh && StaticMesh->GetName().Find(TEXT("Spt_"), ESearchCase::IgnoreCase) == 0)
			{
				StaticMeshComp->bAzureDisableSelfStaticShadow = bEnable;
			}
		}
	}

	AInstancedFoliageActor* IFA = AInstancedFoliageActor::GetInstancedFoliageActorForLevel(Level);
	if (IFA)
	{
		for (auto& MeshPair : IFA->FoliageMeshes)
		{
			FFoliageMeshInfo& MeshInfo = *MeshPair.Value;
			if (MeshInfo.Component)
				InstStaticMeshComps.Add(MeshInfo.Component);
		}
	}

	for (UHierarchicalInstancedStaticMeshComponent* InstStaticMeshComp : InstStaticMeshComps)
	{
		UStaticMesh* StaticMesh = InstStaticMeshComp->GetStaticMesh();
		if (StaticMesh && StaticMesh->GetName().Find(TEXT("Spt_"), ESearchCase::IgnoreCase) == 0)
		{
			InstStaticMeshComp->bAzureDisableSelfStaticShadow = bEnable;
		}
	}
}

#endif
