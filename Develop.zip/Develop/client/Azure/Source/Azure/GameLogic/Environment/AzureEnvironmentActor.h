﻿#pragma once

#include "CoreMinimal.h"
#include "UObject/Interface.h"
#include "Particles/ParticleSystemComponent.h"
#include "AzureEnvironmentActor.generated.h"

class AAzureEnvironmentManager;

UCLASS(Blueprintable, BlueprintType)
class AZURE_API AAzureEnvironmentActor : public AActor
{
	GENERATED_BODY()

public:
	virtual bool ShouldTickIfViewportsOnly() const;

	UFUNCTION(BlueprintCallable, Category = "Environment")
	virtual AAzureEnvironmentManager* GetEnvironmentManager();

	/** find active environment manager, which is within the same level of this actor */
	UFUNCTION(BlueprintCallable, Category = "Environment")
	virtual AAzureEnvironmentManager* GetEnvironmentManagerInSameLevel();

	UFUNCTION(BlueprintCallable, Category = "Environment")
	virtual UAzureEnvironmentPreset* GetEnvironmentPreset(TSubclassOf<UAzureEnvironmentPreset> PresetClass);
};
