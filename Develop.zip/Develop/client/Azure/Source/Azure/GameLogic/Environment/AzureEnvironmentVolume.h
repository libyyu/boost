﻿#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Volume.h"
#include "AzureEnvironmentManager.h"

#include "AzureEnvironmentVolume.generated.h"

class UAzureEnvironmentPreset;
class UAzureEnvironmentTransition;

UCLASS(Blueprintable, BlueprintType)
class AZURE_API AAzureEnvironmentVolume : public AVolume
{
	GENERATED_BODY()

public:
	AAzureEnvironmentVolume();
	virtual void BeginPlay() override;
	virtual void EndPlay(const EEndPlayReason::Type EndPlayReason) override;

#if WITH_EDITOR
	virtual void OnConstruction(const FTransform& Transform) override;
	virtual void BeginDestroy() override;
#endif

public:
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Preset")
		EAzureEnvironmentTransitionType Transition;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Preset")
		float TransitionDistance = 1000;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Preset")
		float TransitionDuration = 5;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Preset")
		float TransitionCooldown = 10;
	UPROPERTY(Transient)
		float TransitionCurCooldown = 0;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Preset")
		TSubclassOf<UAzureEnvironmentPreset> Preset;

protected:
	UPROPERTY(Transient)
	UAzureEnvironmentTransition* PresetTransition;
	
	void Init();

public:
	UAzureEnvironmentTransition* GetTransition() { return PresetTransition; }
};
