﻿// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "Engine/StaticMeshActor.h"

#include "AzureRefSky.generated.h"

class UMaterialInstanceDynamic;

DEFINE_LOG_CATEGORY_STATIC(RefSky, All, All)

UCLASS(config = Engine, Blueprintable, BlueprintType)
class AZURE_API AAzureRefSky : public AStaticMeshActor
{
	GENERATED_BODY()

public:
	// Sets default values for this actor's properties
	AAzureRefSky();
	virtual void OnConstruction(const FTransform& Transform) override;

protected:
	// Called when the game starts or when spawned
	virtual void BeginPlay() override;

	virtual void EndPlay( const EEndPlayReason::Type EndPlayReason ) override;

public:
	// Called every frame
	//virtual void Tick(float DeltaTime) override;

public:
	UFUNCTION()
		UMaterialInstanceDynamic* GetDynamicMaterial() { return SkyMaterial; }

	UFUNCTION()
		UMaterialInstanceDynamic* CreateDynamicMaterial();

public:
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		UMaterialInterface* Material;

	UPROPERTY(Transient)
		UMaterialInstanceDynamic* SkyMaterial;
};
