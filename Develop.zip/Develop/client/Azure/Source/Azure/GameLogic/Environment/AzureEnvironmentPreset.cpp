﻿// Fill out your copyright notice in the Description page of Project Settings.

#include "AzureEnvironmentPreset.h"

UAzureEnvironmentPreset::~UAzureEnvironmentPreset()
{
	check(true);
}

void UAzureEnvironmentPreset::EvaluateSHAmbient(float Time)
{
	check(Time >= 0.0f && Time <= MAX_TIME_OF_DAY);

	if (AmbientsSHTimeofDayData.Num() == 0 || !bAmbientSH)
	{
		return;
	}

	if (AmbientsSHTimeofDayData.Num() == 1)
	{
		AmbientSH = AmbientsSHTimeofDayData[0].Coefficients;
		return;
	}

	int32 UpperBoundIndex = -1;
	int32 LowerBoundIndex = AmbientsSHTimeofDayData.Num() - 1;

	for (int32 Index = 0; Index < AmbientsSHTimeofDayData.Num(); Index++)
	{
		if (Time < AmbientsSHTimeofDayData[Index].Time)
		{
			UpperBoundIndex = Index;
			break;
		}
	}

	if (UpperBoundIndex == 0 || UpperBoundIndex == -1)  //Lerp from last to first element
	{
		UpperBoundIndex = 0;
		LowerBoundIndex = AmbientsSHTimeofDayData.Num() - 1;
	}
	else
	{
		LowerBoundIndex = UpperBoundIndex - 1;
	}

	const FAzureAmbientSHCoefficientsTimeofDay& UpperBound = AmbientsSHTimeofDayData[UpperBoundIndex];
	const FAzureAmbientSHCoefficientsTimeofDay& LowerBound = AmbientsSHTimeofDayData[LowerBoundIndex];

	float TimePassedLower = FMath::Fmod(Time - LowerBound.Time + MAX_TIME_OF_DAY, MAX_TIME_OF_DAY);
	float TimeInterval = FMath::Fmod(UpperBound.Time - LowerBound.Time + MAX_TIME_OF_DAY, MAX_TIME_OF_DAY);
	float LerpRatio = TimePassedLower / (TimeInterval + TIME_OF_DAY_MIN_TIME_INTERVAL);


	AmbientSH = FMath::Lerp(LowerBound.Coefficients, UpperBound.Coefficients, LerpRatio);
}

#if WITH_EDITOR
bool UAzureEnvironmentPreset::CanEditChange(const UProperty* InProperty) const
{
	bool bIsEditable = Super::CanEditChange(InProperty);

	if (bIsEditable)
	{
		const FName PropertyName = InProperty->GetFName();
		const FString ProertyString = PropertyName.ToString();
		if (ProertyString.Find("Value") != INDEX_NONE)
		{
			FString ProertyCurveString = ProertyString.Replace(TEXT("Value"), TEXT("Curve"));
			UObjectProperty *Proerty = FindField<UObjectProperty>(GetClass(), *ProertyCurveString);
			if (Proerty && Proerty->GetPropertyValue_InContainer(this) != nullptr)
			{
				bIsEditable = false;
			}
		}
	}

	return bIsEditable;
}

// Add default functionality here for any IGamePlayerInterface functions that are not pure virtual.
void UAzureEnvironmentPreset::PostEditChangeProperty(FPropertyChangedEvent& PropertyChangedEvent)
{
	Super::PostEditChangeProperty(PropertyChangedEvent);

	const FName PropertyName = PropertyChangedEvent.MemberProperty ? PropertyChangedEvent.MemberProperty->GetFName() : NAME_None;

	if (PropertyName == GET_MEMBER_NAME_CHECKED(UAzureEnvironmentPreset, AmbientsSHTimeofDayData))
	{
		Algo::SortBy(AmbientsSHTimeofDayData, &FAzureAmbientSHCoefficientsTimeofDay::Time);
	}
}
#endif //WITH_EDITOR