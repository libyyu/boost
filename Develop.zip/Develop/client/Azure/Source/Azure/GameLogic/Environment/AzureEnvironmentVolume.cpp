﻿// Fill out your copyright notice in the Description page of Project Settings.

#include "AzureEnvironmentVolume.h"
#include "Components/BrushComponent.h"
#include "Engine/CollisionProfile.h"

AAzureEnvironmentVolume::AAzureEnvironmentVolume()
{
	Transition = EAzureEnvironmentTransitionType::Distance;
	GetBrushComponent()->SetCollisionProfileName(UCollisionProfile::NoCollision_ProfileName);
	GetBrushComponent()->bAlwaysCreatePhysicsState = true;
}

#if WITH_EDITOR
void AAzureEnvironmentVolume::OnConstruction(const FTransform& Transform)
{
	Super::OnConstruction(Transform);
	Init();
}

void AAzureEnvironmentVolume::BeginDestroy()
{
	AAzureEnvironmentManager::GetAllEnvVolumeInstances().Remove(this);
	Super::BeginDestroy();
}
#endif

void AAzureEnvironmentVolume::BeginPlay()
{
	Super::BeginPlay();
	Init();
}

void AAzureEnvironmentVolume::EndPlay(const EEndPlayReason::Type EndPlayReason)
{
	AAzureEnvironmentManager::GetAllEnvVolumeInstances().Remove(this);
	Super::EndPlay(EndPlayReason);
}

void AAzureEnvironmentVolume::Init()
{
	if (Preset.Get())
	{
		PresetTransition = NewObject<UAzureEnvironmentTransition>(this);
		PresetTransition->bVolume = true;
		PresetTransition->Type = Transition;
		PresetTransition->Duration = TransitionDuration;
		PresetTransition->Distance = TransitionDistance;
		PresetTransition->Center = GetBounds().GetBox().GetCenter();
		PresetTransition->Extent = GetBounds().GetBox().GetExtent();
		PresetTransition->Preset = NewObject<UAzureEnvironmentPreset>(this, Preset);
	}
	else
	{
		PresetTransition = nullptr;
	}
	AAzureEnvironmentManager::GetAllEnvVolumeInstances().Add(this);
}


