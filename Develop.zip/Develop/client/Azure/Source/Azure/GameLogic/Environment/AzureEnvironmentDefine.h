﻿#pragma once

#include "CoreMinimal.h"
#include "SceneTypes.h"
#include "GameFramework/Actor.h"

#include "AzureEnvironmentDefine.generated.h"

#define MAX_TIME_OF_DAY 24.0f
#define TIME_OF_DAY_MIN_TIME_INTERVAL 0.05f

UENUM(BlueprintType)
enum class EBasicWeather : uint8
{
	Default,
	Normal,
	Rain,
	Snow
};

USTRUCT(Blueprintable, BlueprintType)
struct FSingleWind
{
	GENERATED_BODY()

	void Reset()
	{
		bValid = false;

		fCurStrength = 0.f;
		fPlayedTime = 0.f;
		fLastCheckTime = 0.f;

		vDir = FVector::ZeroVector;
		fTotalTime = 0.f;
		fBaseStrength = 0.f;
	}

	bool bValid = false;

	// 变化值
	float fCurStrength = 0.f;
	float fPlayedTime = 0.f;
	float fLastCheckTime = 0.f;

	//	非变化值
	FVector vDir = FVector::ZeroVector;
	float fTotalTime = 0.f;
	float fBaseStrength = 0.f;
};

static constexpr int RANDOM_WIND_MAX_COUNT = 4;

USTRUCT(Blueprintable, BlueprintType)
struct FWindGenerator
{
	GENERATED_BODY()

	void Reset()
	{
		fStartTime = 0;
		fPlayedTime = 0;
		vTotalStrength = FVector::ZeroVector;

		for (int i = 0; i < RANDOM_WIND_MAX_COUNT; ++i)
			randWind[i].Reset();
	}

	float fStartTime = 0.f;
	float fPlayedTime = 0.f;
	FVector vTotalStrength = FVector::ZeroVector;
	FSingleWind randWind[RANDOM_WIND_MAX_COUNT];
};

USTRUCT(Blueprintable, BlueprintType)
struct FAzureAmbientSHCoefficients
{
	GENERATED_BODY()

	UPROPERTY(EditAnywhere, Category = "SH Coefficients")
	FVector4 SHCoefficients[GLOBAL_SH_VECTOR_COUNT];
	//{ R.C0, R.C1, R.C2, R.C3 }, 
	//{ G.C0, G.C1, G.C2, G.C3 }, 
	//{ B.C0, B.C1, B.C2, B.C3 },
	//{ R.C4, R.C5, R.C6, R.C7 }, 
	//{ G.C4, G.C5, G.C6, G.C7 }, 
	//{ B.C4, B.C5, B.C6, B.C7 },
	//{ R.C8, R.C8, R.C8, R.C8 }

	FAzureAmbientSHCoefficients operator+(const FAzureAmbientSHCoefficients& Other) const
	{
		FAzureAmbientSHCoefficients Result;
		for (int32 Index = 0; Index < GLOBAL_SH_VECTOR_COUNT; Index++)
		{
			Result.SHCoefficients[Index] = SHCoefficients[Index] + Other.SHCoefficients[Index];
		}
		return Result;
	}

	FAzureAmbientSHCoefficients operator-(const FAzureAmbientSHCoefficients& Other) const
	{
		FAzureAmbientSHCoefficients Result;
		for (int32 Index = 0; Index < GLOBAL_SH_VECTOR_COUNT; Index++)
		{
			Result.SHCoefficients[Index] = SHCoefficients[Index] - Other.SHCoefficients[Index];
		}
		return Result;
	}

	FAzureAmbientSHCoefficients operator*(const float Factor) const
	{
		FAzureAmbientSHCoefficients Result;
		for (int32 Index = 0; Index < GLOBAL_SH_VECTOR_COUNT; Index++)
		{
			Result.SHCoefficients[Index] = SHCoefficients[Index] * Factor;
		}
		return Result;
	}
};

FORCEINLINE FAzureAmbientSHCoefficients operator*(const float Factor, const FAzureAmbientSHCoefficients& SHAmbient)
{
	FAzureAmbientSHCoefficients Result;
	for (int32 Index = 0; Index < GLOBAL_SH_VECTOR_COUNT; Index++)
	{
		Result.SHCoefficients[Index] = SHAmbient.SHCoefficients[Index] * Factor;
	}
	return Result;
}

USTRUCT(Blueprintable, BlueprintType)
struct FAzureAmbientSHCoefficientsTimeofDay
{
	GENERATED_BODY()

	UPROPERTY(EditAnywhere, meta = (UIMin = 0.0f, UIMax = 23.9f, DisplayName = "Time of Day"))
	float Time;

	UPROPERTY(EditAnywhere)
	FAzureAmbientSHCoefficients Coefficients;
};