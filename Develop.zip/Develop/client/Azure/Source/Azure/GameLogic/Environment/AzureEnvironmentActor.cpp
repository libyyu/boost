﻿// Fill out your copyright notice in the Description page of Project Settings.

#include "AzureEnvironmentActor.h"

#include "AzureEnvironmentManager.h"

#if WITH_EDITOR
#include "UnrealEdGlobals.h"
#include "Editor/UnrealEdEngine.h"
#endif

bool AAzureEnvironmentActor::ShouldTickIfViewportsOnly() const
{
	return true;
}

AAzureEnvironmentManager* AAzureEnvironmentActor::GetEnvironmentManager()
{
	for (auto& it : AAzureEnvironmentManager::GetAllInstances())
	{
		if (it->bEnable)
			return it;
	}
	return nullptr;
}

AAzureEnvironmentManager* AAzureEnvironmentActor::GetEnvironmentManagerInSameLevel()
{
	ULevel* selfLevel = GetLevel();
	for (auto& it : AAzureEnvironmentManager::GetAllInstances())
	{
		if (it->bEnable && it->GetLevel() == selfLevel)
			return it;
	}
	return nullptr;
}

UAzureEnvironmentPreset* AAzureEnvironmentActor::GetEnvironmentPreset(TSubclassOf<UAzureEnvironmentPreset> PresetClass)
{
	AAzureEnvironmentManager* Manager = GetEnvironmentManager();
	if (Manager)
	{
		return Manager->GetPreset(PresetClass);
	}
	return nullptr;
}
