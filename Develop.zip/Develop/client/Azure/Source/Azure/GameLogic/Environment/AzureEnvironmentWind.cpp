﻿// Fill out your copyright notice in the Description page of Project Settings.

#include "AzureEnvironmentWind.h"

UAzureEnvironmentWind::UAzureEnvironmentWind() :
	m_fStrength(0.0f),
	m_fLastTime(-1.0),
	m_fElapsedTime(0.0),
	m_fGust(0.0f),
	m_fGustTarget(0.0f),
	m_fGustRiseTarget(0.0f),
	m_fGustFallTarget(0.0f),
	m_fGustStart(0.0f),
	m_fGustAtStart(1.0f),
	m_fGustFallStart(0.0f),
	m_fStrengthTarget(0.0f),
	m_fStrengthChangeStartTime(0.0f),
	m_fStrengthChangeEndTime(0.0f),
	m_fStrengthAtStart(0.0f),
	m_fDirectionChangeStartTime(0.0f),
	m_fDirectionChangeEndTime(0.0f),
	m_fCombinedStrength(0.0f)

{
	m_afDirectionTarget[0] = m_afDirectionAtStart[0] = m_afDirectionMidTarget[0] = m_afDirection[0] = 1.0f;
	m_afDirectionTarget[1] = m_afDirectionAtStart[1] = m_afDirectionMidTarget[1] = m_afDirection[1] = 0.0f;
	m_afDirectionTarget[2] = m_afDirectionAtStart[2] = m_afDirectionMidTarget[2] = m_afDirection[2] = 0.0f;
}

inline float Interpolate(float fA, float fB, float fAmt)
{
	return (fA + (fB - fA) * fAmt);
}

inline float LinearSigmoid(float fInput, float fLinearness)
{
	float fSigmoid = 1.0f / (1.0f + exp(-Interpolate(-6.0f, 6.0f, fInput)));
	return Interpolate(fSigmoid, fInput, fLinearness);
}

inline float RandomFloat(float fMin, float fMax)
{
	return FMath::FRandRange(fMin, fMax);
}

inline void Normalize(float* pVector)
{
	float fMagnitude = FMath::Sqrt(pVector[0] * pVector[0] + pVector[1] * pVector[1] + pVector[2] * pVector[2]);
	if (fMagnitude != 0.0f)
	{
		pVector[0] /= fMagnitude;
		pVector[1] /= fMagnitude;
		pVector[2] /= fMagnitude;
	}
	else
	{
		pVector[0] = 0.0f;
		pVector[1] = 0.0f;
		pVector[2] = 0.0f;
	}
}

void UAzureEnvironmentWind::SetStrength(float fStrength)
{
	if (fStrength != m_fStrength)
	{
		m_fStrengthChangeStartTime = m_fLastTime;

		float fAmount = Interpolate(m_sParams.m_fStrengthResponse * 0.5f, m_sParams.m_fStrengthResponse, fabs(fStrength - m_fStrength));
		m_fStrengthChangeEndTime = m_fStrengthChangeStartTime + fAmount;
		m_fStrengthAtStart = m_fStrength;
		m_fStrengthTarget = fStrength;
	}
}

void UAzureEnvironmentWind::SetDirection(const FVector& vDir)
{
	if (vDir.X != m_afDirection[0] ||
		vDir.Y != m_afDirection[1] ||
		vDir.Z != m_afDirection[2])
	{
		m_afDirectionTarget[0] = vDir.X;
		m_afDirectionTarget[1] = vDir.Y;
		m_afDirectionTarget[2] = vDir.Z;

		float fDot = m_afDirection[0] * vDir.X + m_afDirection[1] * vDir.Y + m_afDirection[2] * vDir.Z;
		float fDistanceToTravel = 1.0f - ((fDot + 1.0f) * 0.5f);

		m_fDirectionChangeStartTime = m_fLastTime;
		float fAmount = Interpolate(m_sParams.m_fDirectionResponse * 0.5f, m_sParams.m_fDirectionResponse, fDistanceToTravel);
		m_fDirectionChangeEndTime = m_fDirectionChangeStartTime + fAmount;

		m_afDirectionAtStart[0] = m_afDirection[0];
		m_afDirectionAtStart[1] = m_afDirection[1];
		m_afDirectionAtStart[2] = m_afDirection[2];

		m_afDirectionMidTarget[0] = (m_afDirectionAtStart[0] + m_afDirectionTarget[0]) * 0.5f;
		m_afDirectionMidTarget[1] = (m_afDirectionAtStart[1] + m_afDirectionTarget[1]) * 0.5f;
		m_afDirectionMidTarget[2] = (m_afDirectionAtStart[2] + m_afDirectionTarget[2]) * 0.5f;
		Normalize(m_afDirectionMidTarget);
	}
}

void UAzureEnvironmentWind::SetGustMin(float InGustMin)
{
	m_sParams.m_fGustStrengthMin = InGustMin;
}

void UAzureEnvironmentWind::SetGustMax(float InGustMax)
{
	m_sParams.m_fGustStrengthMax = InGustMax;
}

void UAzureEnvironmentWind::SetGustFrequency(float fGustFreq)
{
	m_sParams.m_fGustFrequency = fGustFreq;
}

void UAzureEnvironmentWind::Gust(double fTime)
{
	const float c_fGustAdjust = 0.01f;
	if (fTime > m_fGustFallTarget || (fTime < m_fGustFallStart && fTime > m_fGustRiseTarget))
	{
		// it is legal to gust (you can't gust on the way out of a gust to prevent jerks)
		if (RandomFloat(0.0f, m_fElapsedTime) < (m_fElapsedTime * m_sParams.m_fGustFrequency * c_fGustAdjust))
		{
			// we got one, set it up
			m_fGustStart = fTime;
			m_fGustAtStart = m_fGust;
			m_fGustTarget = RandomFloat(m_sParams.m_fGustStrengthMin, m_sParams.m_fGustStrengthMax);
			if (m_fGustTarget > 1.0f - m_fStrength)
				m_fGustTarget = 1.0f - m_fStrength;

			float fAmount = Interpolate(m_sParams.m_fStrengthResponse * 0.5f, m_sParams.m_fStrengthResponse, fabs(m_fGustTarget - m_fStrength));
			if (m_fGustTarget > m_fGust)
				m_fGustRiseTarget = fTime + m_sParams.m_fGustRiseScalar * RandomFloat(fAmount * 1.0f, fAmount * 2.0f);
			else
				m_fGustRiseTarget = fTime + m_sParams.m_fGustFallScalar * RandomFloat(fAmount, fAmount * 2.0f);

			m_fGustFallStart = m_fGustRiseTarget + RandomFloat(m_sParams.m_fGustDurationMin, m_sParams.m_fGustDurationMax);
			m_fGustFallTarget = m_fGustFallStart + m_sParams.m_fGustFallScalar * RandomFloat(fAmount * 2.0f, fAmount * 3.0f);
		}
	}

	if (fTime < m_fGustRiseTarget)
	{
		// s-curve toward the target
		m_fGust = Interpolate(m_fGustAtStart, m_fGustTarget, LinearSigmoid((fTime - m_fGustStart) / (m_fGustRiseTarget - m_fGustStart), 0.0f));
	}
	else if (fTime > m_fGustFallStart && m_fGustFallTarget > 0.0f && m_fGustFallTarget > m_fGustFallStart)
	{
		// s-curve back to zero
		m_fGust = Interpolate(m_fGustTarget, 0.0f, LinearSigmoid((fTime - m_fGustFallStart) / (m_fGustFallTarget - m_fGustFallStart), 0.5f));
	}

	m_fGust = FMath::Max(0.0f, FMath::Min(1.0f, m_fGust));
}

void UAzureEnvironmentWind::Advance(bool bEnabled, double fTime)
{
	// keep track of time
	if (m_fLastTime == -1.0)
		m_fElapsedTime = 0.0;
	else
		m_fElapsedTime = fTime - m_fLastTime;
	m_fLastTime = fTime;

	if (bEnabled)
	{
		Gust(fTime);

		// adjust direction
		float fDirectionFactor = 1.0f;
		if (m_fDirectionChangeEndTime != m_fDirectionChangeStartTime)
			fDirectionFactor = FMath::Min(1.0, FMath::Max(0.0, (fTime - m_fDirectionChangeStartTime) / (m_fDirectionChangeEndTime - m_fDirectionChangeStartTime)));
		fDirectionFactor = LinearSigmoid(fDirectionFactor, 0.5f);

		if (fDirectionFactor < 0.5f)
		{
			// go toward the mid-vector (the mid vector prevents fast swoops when making 180 degree direction changes)
			fDirectionFactor *= 2.0f;
			m_afDirection[0] = Interpolate(m_afDirectionAtStart[0], m_afDirectionMidTarget[0], fDirectionFactor);
			m_afDirection[1] = Interpolate(m_afDirectionAtStart[1], m_afDirectionMidTarget[1], fDirectionFactor);
			m_afDirection[2] = Interpolate(m_afDirectionAtStart[2], m_afDirectionMidTarget[2], fDirectionFactor);
		}
		else
		{
			// go away from the mid-vector (the mid vector prevents fast swoops when making 180 degree direction changes)
			fDirectionFactor = (fDirectionFactor - 0.5f) * 2.0f;
			m_afDirection[0] = Interpolate(m_afDirectionMidTarget[0], m_afDirectionTarget[0], fDirectionFactor);
			m_afDirection[1] = Interpolate(m_afDirectionMidTarget[1], m_afDirectionTarget[1], fDirectionFactor);
			m_afDirection[2] = Interpolate(m_afDirectionMidTarget[2], m_afDirectionTarget[2], fDirectionFactor);
		}
		Normalize(m_afDirection);

		// adjust strength
		float fStrengthFactor = 1.0f;
		if (m_fStrengthChangeEndTime != m_fStrengthChangeStartTime)
			fStrengthFactor = FMath::Min(1.0, FMath::Max(0.0, (fTime - m_fStrengthChangeStartTime) / (m_fStrengthChangeEndTime - m_fStrengthChangeStartTime)));
		else
			fStrengthFactor = 0.0f;

		m_fStrength = Interpolate(m_fStrengthAtStart, m_fStrengthTarget, LinearSigmoid(fStrengthFactor, 0.0f));

		// combine it with the gust value
		m_fCombinedStrength = FMath::Max(0.0f, FMath::Min(1.0f, m_fStrength + m_fGust));
	}
}
