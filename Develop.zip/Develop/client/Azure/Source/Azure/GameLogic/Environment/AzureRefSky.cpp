﻿// Fill out your copyright notice in the Description page of Project Settings.

#include "AzureRefSky.h"

#include "Materials/MaterialInstance.h"
#include "Materials/MaterialInstanceDynamic.h"
#include "Components/StaticMeshComponent.h"

#include "Kismet/KismetMathLibrary.h"
#include "Kismet/KismetRenderingLibrary.h"
#include "Kismet/KismetMaterialLibrary.h"

// Sets default values
AAzureRefSky::AAzureRefSky() :
	SkyMaterial(nullptr)
{
	// Set this actor to call Tick() every frame.  You can turn this off to
	// improve performance if you don't need it.
	//PrimaryActorTick.bCanEverTick = true;
}

void AAzureRefSky::OnConstruction(const FTransform& Transform)
{
	CreateDynamicMaterial();
}

// Called when the game starts or when spawned
void AAzureRefSky::BeginPlay()
{
	Super::BeginPlay();

	CreateDynamicMaterial();
}

void AAzureRefSky::EndPlay(const EEndPlayReason::Type EndPlayReason)
{
}

//// Called every frame
//void AAzureRefSky::Tick(float DeltaTime)
//{
//	Super::Tick(DeltaTime);
//}

UMaterialInstanceDynamic* AAzureRefSky::CreateDynamicMaterial()
{
	if (Material == nullptr)
		return nullptr;

	UStaticMeshComponent* StaticMesh = GetStaticMeshComponent();
	if (StaticMesh == nullptr)
		return nullptr;

	SkyMaterial = UMaterialInstanceDynamic::Create(Material, this, NAME_None);
	StaticMesh->SetMaterial(0, SkyMaterial);

	return SkyMaterial;
}
