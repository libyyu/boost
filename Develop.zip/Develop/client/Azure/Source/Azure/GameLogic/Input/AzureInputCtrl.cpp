﻿//#include "Azure.h"
#include "AzureInputCtrl.h"
#include "AzureEntryPoint.h"
#include "WidgetInteractionComponent.h"
#include "WidgetComponent.h"
#include "wLua/LuaInterface.h"
#include "Azure.h"
#include "Kismet/KismetSystemLibrary.h"
#include "GameLogic/Player/GamePlayerManager.h"

#if PLATFORM_IOS
#include "IOS/IOSApplication.h"
#elif PLATFORM_ANDROID
#include "Android/AndroidApplication.h"
#endif

//	AzureRawTouch
bool AzureRawTouch::operator==(const AzureRawTouch& rhs)const
{
	return this->Type == rhs.Type
		&& this->TouchLocation == rhs.TouchLocation;
}

bool AzureRawTouch::operator!=(const AzureRawTouch& rhs)const
{
	return !(*this == rhs);
}

float AzureTouchState::m_InScopeSqDist = 10.f * 10.f;


AzureInputCtrl::AzureInputCtrl()
{
	
}

//	class AzureInputCtrl
void AzureInputCtrl::TickTouchStates(float fDeltaTime)
{
	m_LastTouchCount = m_TouchCount;
	m_TouchCount = 0;
	m_MaxValidTouchId = -1;

	for (uint32 i = 0; i < MaxTouchCount; ++i)
	{
		AzureTouchState& state = m_TouchStates[i];
		AzureTouch& RawTouch = state.RawTouch;

		if (RawTouch.ValidState == AzureTouchValidState::NOT_SET)
			continue;
		else if (RawTouch.ValidState == AzureTouchValidState::InValid)
		{
			state.Clear();
			continue;
		}

		state.LastTouch = state.ThisTouch;
		state.ThisTouch = RawTouch;
		state.Update();
		++m_TouchCount;
		m_MaxValidTouchId = i;

		// GEngine->AddOnScreenDebugMessage(-1, 5, FColor::Green, FString::Printf(TEXT("%d"), (int)state.ThisTouch.phase));

		if (RawTouch.phase == ETouchType::Type::Began)
			RawTouch.phase = ETouchType::Type::Stationary;
		else if (RawTouch.phase == ETouchType::Type::Moved)
			RawTouch.phase = ETouchType::Type::Stationary;
		else if (RawTouch.phase == ETouchType::Type::Ended)
			RawTouch.ValidState = AzureTouchValidState::InValid;
	}
}

void AzureInputCtrl::SendMsgJoystickPress()
{
	if (!AAzureEntryPoint::Instance)
		return;

	m_fLastSendMsgPress = (float)AAzureEntryPoint::Instance->GetCurFrameTime();
	if (false)
	{
		FString str = FString::Printf(TEXT("joystick-3 %0.4f %0.4f %0.4f"), m_fLastSendMsgPress, AAzureEntryPoint::Instance->m_curFrameTime, AAzureEntryPoint::Instance->m_realtimeSinceStartup);
		MyPrintString(str);
	}

	wLua::Lua* pLua = AAzureEntryPoint::Instance->GetWLua();
	lua_State_Wrapper L = pLua ? pLua->GetL() : nullptr;
	if (L)
	{
		lua_getglobal(L, "OnJoystickPress");
		lua_pushboolean(L, true);
		lua_pushnumber(L, m_fThisFrameJoystickX);
		lua_pushnumber(L, m_fThisFrameJoystickY);
		pLua->Call(3);
	}
}

void AzureInputCtrl::SendMsgJoystickRelease()
{
	if (!AAzureEntryPoint::Instance)
		return;

	wLua::Lua* pLua = AAzureEntryPoint::Instance->GetWLua();
	lua_State_Wrapper L = pLua ? pLua->GetL() : nullptr;
	if (L)
	{
		lua_getglobal(L, "OnJoystickPress");
		lua_pushboolean(L, false);
		pLua->Call(1);
	}
}

void AzureInputCtrl::CheckStartTouch()
{
	//uint32 curFrame = m_JoystickFrame;
	if (m_JoystickFrame == 0)
	{
		//	Touch started!
		m_JoystickFrame = m_curFrame;
		SendMsgJoystickPress();
	}
}

static constexpr float KEYPUSH_DELTA = 1.f;
bool AzureInputCtrl::InputKey(FKey Key, EInputEvent EventType, float AmountDepressed, bool bGamepad)
{
	if (AAzureEntryPoint::IsInit() && AAzureEntryPoint::Instance->m_bStarted)
	{
		wLua::Lua* pLua = AAzureEntryPoint::Instance->GetWLua();
		lua_State_Wrapper L = pLua ? pLua->GetL() : nullptr;
		if (L != nullptr)
		{
			//UE_LOG(LogTemp, Log, TEXT("InputKey: %s, type %d"), *Key.ToString(), (int32)EventType);

			//////////////////////////////////////////////////////////////////////////
			//	Call Lua
			lua_getglobal(L, "OnInputKey");
			lua_pushstring(L, TCHAR_TO_UTF8(*Key.GetFName().ToString()));
			lua_pushnumber(L, int(EventType));
			lua_pushnumber(L, AmountDepressed);
			lua_pushboolean(L, bGamepad);

			bool bRet = false;
			if (pLua->PCall(4, 1))
			{
				bRet = !!lua_toboolean(L, -1);
			}
			else
			{
				const char* errmsg = lua_tostring(L, -1);
				LUALOG_ERROR(errmsg);
			}
			lua_pop(L, 1);

			if (bRet)
				return true;
		}
	}

	return false;
}

bool AzureInputCtrl::InputAxis(FKey Key, float Delta, float DeltaTime, int32 NumSamples, bool bGamepad)
{
//#if PLATFORM_DESKTOP
	if (Delta != 0 && AAzureEntryPoint::IsInit() && AAzureEntryPoint::Instance->m_bStarted)
	{
		wLua::Lua* pLua = AAzureEntryPoint::Instance->GetWLua();
		lua_State_Wrapper L = pLua ? pLua->GetL() : nullptr;
		if (L != nullptr)
		{
			//FString str = FString::Printf(TEXT("InputAxis %s %f"),*Key.ToString(),Delta);
			//UKismetSystemLibrary::PrintString(GEngine->GetWorld(),str);

			if (Key == EKeys::MouseWheelAxis)
			{
				lua_getglobal(L, "OnMouseWheelAxis");
				lua_pushnumber(L, Delta);
				AAzureEntryPoint::Instance->GetWLua()->Call(1);
				return true;
			}
			else if (Key == EKeys::Gamepad_LeftX)
			{
				m_fThisFrameJoystickX = Delta;
				CheckStartTouch();
				return true;
			}
			else if (Key == EKeys::Gamepad_LeftY)
			{
				m_fThisFrameJoystickY = Delta;
				CheckStartTouch();
				return true;
			}
			else if (Key == EKeys::A)
			{
				m_fThisFrameJoystickX = Delta;
				CheckStartTouch();
				return true;
			}
			else if (Key == EKeys::W)
			{
				m_fThisFrameJoystickY = Delta;
				CheckStartTouch();
				return true;
			}
			else if (Key == EKeys::MouseX || Key == EKeys::MouseY)
			{
				lua_getglobal(L, "OnGameViewportMouseMove");
				if (lua_isfunction(L, -1))
				{
					float DeltaX = (Key == EKeys::MouseX) ? Delta : 0.0f;
					float DeltaY = (Key == EKeys::MouseY) ? Delta : 0.0f;
					lua_pushnumber(L, DeltaX);
					lua_pushnumber(L, DeltaY);
					AAzureEntryPoint::Instance->GetWLua()->Call(2);
				}
				else
				{
					lua_pop(L, 1);
				}
				return true;
			}
		}
	}
//#endif

	return false;
}

float AzureInputCtrl::GetJoystickX()
{
	return m_fThisFrameJoystickX;
}

float AzureInputCtrl::GetJoystickY()
{
	return m_fThisFrameJoystickY;
}

void AzureInputCtrl::TickJoyStickState(float fDeltaTime)
{
	{
		m_vLastFrameNotManualJoyStickValue = m_vNotManualJoyStickValue;
		m_vNotManualJoyStickValue = FVector2D::ZeroVector;
	}

	if (m_fThisFrameJoystickX == 0 && m_fThisFrameJoystickY == 0)
	{
		//	No Move this frame:
		m_vLastFrameJoyStickValue = FVector2D::ZeroVector;

		if (m_JoystickFrame != 0)
		{
			//	Touch ended!
			m_JoystickFrame = 0; // clear start frame
			SendMsgJoystickRelease();
		}
		return;
	}

	//	Has Move this frame:
	m_vLastFrameJoyStickValue.Set(m_fThisFrameJoystickX, m_fThisFrameJoystickY);

	if (!AAzureEntryPoint::Instance)
		return;

	if (false)
	{
		FString str = FString::Printf(TEXT("joystick-2 %0.4f %0.4f %0.4f %0.4f"), AAzureEntryPoint::Instance->GetCurFrameTime(), m_fLastSendMsgPress, AAzureEntryPoint::Instance->m_curFrameTime, AAzureEntryPoint::Instance->m_realtimeSinceStartup);
		MyPrintString(str);
	}


	if ((float)AAzureEntryPoint::Instance->GetCurFrameTime() - m_fLastSendMsgPress > Azure::JoystickPressSendInterval)
	{
		//	每隔一定时间发送press消息（以驱动客户端做特定操作，比如技能取消等）
		SendMsgJoystickPress();
	}

	//	Clear values for this frame
	m_fThisFrameJoystickX = 0;
	m_fThisFrameJoystickY = 0;
}


void AzureInputCtrl::TickWidgetInteraction(float fDeltaTime)
{
	if (m_TouchCount == 1)
	{
		AzureTouchState* touchState = GetTouchState(m_MaxValidTouchId);
		if (touchState && touchState->BeginTouch.IsValid())
		{
			if (touchState->ThisTouch.IsValid() && !touchState->HasMoved)
			{
				if (!AAzureEntryPoint::Instance)
					return;

				UWidgetInteractionComponent *widgetInteraction = AAzureEntryPoint::Instance->WidgetInteractionComp;
				if (widgetInteraction)
				{
					if (touchState->ThisTouch.phase == ETouchType::Began)
						widgetInteraction->PressPointerKey(FKey("LeftMouseButton"));
					else if(touchState->ThisTouch.phase == ETouchType::Ended)
						widgetInteraction->ReleasePointerKey(FKey("LeftMouseButton"));
				}
			}
		}
	}
}

void AzureInputCtrl::InputTouch(uint32 Handle, ETouchType::Type Type, const FVector2D& TouchLocation)
{
	if (Handle >= MaxTouchCount)
	{
		return;
	}

	if (Type != ETouchType::Began &&
		Type != ETouchType::Moved &&
		Type != ETouchType::Ended)
	{
		//	Other types are not important and ignored.
		return;
	}

	m_MsgQueue[Handle].PushBack(Type, TouchLocation);
}

void AzureInputCtrl::InputMotion(const FVector& Tilt, const FVector& RotationRate, const FVector& Gravity, const FVector& Acceleration)
{
	m_vTilt = Tilt;
	m_vRotationRate = RotationRate;
	m_vGravity = Gravity;
	m_vAcceleration = Acceleration;
}

void AzureInputCtrl::TickInputMotion(float fDeltaTime)
{
	if (!m_bEnableInputMotion)
		return;

	bool bAccelerationChanged = false;
	// 检测摇晃手机
	if (m_vLastAcceleration != m_vAcceleration)
	{
		FVector vDelta = m_vAcceleration - m_vLastAcceleration;
		float sqrMagnitude = vDelta.SizeSquared();
		if (sqrMagnitude >= m_shakeAccelerationThreshold * m_shakeAccelerationThreshold)
		{
			
			m_shakeSampleTimeCur = m_shakeSampleTime;//开始采样

			if (m_vLastShakeDir.SizeSquared()>= m_shakeAccelerationThreshold * m_shakeAccelerationThreshold)
			{
				const float fDotProduct = FVector::DotProduct(m_vLastShakeDir.GetSafeNormal(), vDelta.GetSafeNormal());
				if (fDotProduct<-0.7f)//转向
				{
					m_shakeCountCur++;
				}
			}
			m_vLastShakeDir = vDelta;

			if (m_shakeCountCur>m_shakeCount)
			{
				RaiseShakeEvent();
				m_shakeCountCur = 0;
				m_vLastShakeDir = FVector::ZeroVector;
			}
		}

		m_shakeSampleTimeCur -= fDeltaTime;
		if (m_shakeSampleTimeCur<=0)
		{
			m_shakeSampleTimeCur = 0;
			m_shakeCountCur = 0;
			m_vLastShakeDir = FVector::ZeroVector;
		}

		m_vLastAcceleration = m_vAcceleration;
		bAccelerationChanged = true;
	}

	if (!AAzureEntryPoint::Instance)
		return;

	if (bAccelerationChanged)
	{
		wLua::Lua* pLua = AAzureEntryPoint::Instance->GetWLua();
		lua_State_Wrapper L = pLua ? pLua->GetL() : nullptr;
		lua_getglobal(L, "OnAcceleration");
		lua_pushnumber(L, m_vAcceleration.X);
		lua_pushnumber(L, m_vAcceleration.Y);
		lua_pushnumber(L, m_vAcceleration.Z);
		pLua->Call(3);
	}

	if (m_vLastTilt != m_vTilt)
	{
		m_vLastTilt = m_vTilt;

		//gyro
		//AAzureEntryPoint::Instance->GetMainCameraCtrl()->OnInputMotion(m_vTilt);

		wLua::Lua* pLua = AAzureEntryPoint::Instance->GetWLua();
		lua_State_Wrapper L = pLua ? pLua->GetL() : nullptr;
		lua_getglobal(L, "OnTilt");
		lua_pushnumber(L, m_vTilt.X);
		lua_pushnumber(L, m_vTilt.Y);
		lua_pushnumber(L, m_vTilt.Z);
		pLua->Call(3);
	}

	if (m_vLastRotationRate != m_vRotationRate)
	{
		m_vLastRotationRate = m_vRotationRate;

		wLua::Lua* pLua = AAzureEntryPoint::Instance->GetWLua();
		lua_State_Wrapper L = pLua ? pLua->GetL() : nullptr;
		lua_getglobal(L, "OnRotationRate");
		lua_pushnumber(L, m_vRotationRate.X);
		lua_pushnumber(L, m_vRotationRate.Y);
		lua_pushnumber(L, m_vRotationRate.Z);
		pLua->Call(3);
	}

	if (m_vLastGravity != m_vGravity)
	{
		m_vLastGravity = m_vGravity;

		wLua::Lua* pLua = AAzureEntryPoint::Instance->GetWLua();
		lua_State_Wrapper L = pLua ? pLua->GetL() : nullptr;
		lua_getglobal(L, "OnGravity");
		lua_pushnumber(L, m_vGravity.X);
		lua_pushnumber(L, m_vGravity.Y);
		lua_pushnumber(L, m_vGravity.Z);
		pLua->Call(3);
	}

}

void AzureInputCtrl::OnReceivedFocus(FViewport* InViewport)
{
	if (!AAzureEntryPoint::Instance)
		return;
	wLua::Lua* wlua = AAzureEntryPoint::Instance->GetWLua();
	lua_State_Wrapper L = AAzureEntryPoint::Instance->GetL();
	if (!wlua || !L)
		return;

	lua_getglobal(L, "OnReceivedFocus");
	if (lua_isfunction(L, -1))
	{
		wlua->Call(0);
	}
	else
	{
		lua_pop(L, 1);
	}
}

void AzureInputCtrl::OnLostFocus(FViewport* InViewport)
{
	if (!AAzureEntryPoint::Instance)
		return;
	wLua::Lua* wlua = AAzureEntryPoint::Instance->GetWLua();
	lua_State_Wrapper L = AAzureEntryPoint::Instance->GetL();
	if (!wlua || !L)
		return;

	lua_getglobal(L, "OnLostFocus");
	if (lua_isfunction(L, -1))
	{
		wlua->Call(0);
	}
	else
	{
		lua_pop(L, 1);
	}
}

void AzureInputCtrl::OnActivated(FViewport* InViewport, const FWindowActivateEvent& InActivateEvent)
{
	if (!AAzureEntryPoint::Instance)
		return;
	wLua::Lua* wlua = AAzureEntryPoint::Instance->GetWLua();
	lua_State_Wrapper L = AAzureEntryPoint::Instance->GetL();
	if (!wlua || !L)
		return;

	lua_getglobal(L, "OnActivated");
	if (lua_isfunction(L, -1))
	{
		lua_pushinteger(L, int(InActivateEvent.GetActivationType()));
		wlua->Call(1);
	}
	else
	{
		lua_pop(L, 1);
	}
}

void AzureInputCtrl::OnDeactivated(FViewport* InViewport, const FWindowActivateEvent& InActivateEvent)
{
	if (!AAzureEntryPoint::Instance)
		return;
	wLua::Lua* wlua = AAzureEntryPoint::Instance->GetWLua();
	lua_State_Wrapper L = AAzureEntryPoint::Instance->GetL();
	if (!wlua || !L)
		return;

	lua_getglobal(L, "OnDeactivated");
	if (lua_isfunction(L, -1))
	{
		lua_pushinteger(L, int(InActivateEvent.GetActivationType()));
		wlua->Call(1);
	}
	else
	{
		lua_pop(L, 1);
	}
}

void AzureInputCtrl::OnPreDeactivated(FViewport* InViewport, const FWindowActivateEvent& InActivateEvent)
{
	if (!AAzureEntryPoint::Instance)
		return;
	wLua::Lua* wlua = AAzureEntryPoint::Instance->GetWLua();
	lua_State_Wrapper L = AAzureEntryPoint::Instance->GetL();
	if (!wlua || !L)
		return;

	lua_getglobal(L, "OnPreDeactivated");
	if (lua_isfunction(L, -1))
	{
		lua_pushinteger(L, int(InActivateEvent.GetActivationType()));
		wlua->Call(1);
	}
	else
	{
		lua_pop(L, 1);
	}
}

void AzureInputCtrl::OnSetIsSimulateInEditorViewport(bool bInIsSimulateInEditorViewport)
{
	if (!AAzureEntryPoint::Instance)
		return;
	wLua::Lua* wlua = AAzureEntryPoint::Instance->GetWLua();
	lua_State_Wrapper L = AAzureEntryPoint::Instance->GetL();
	if (!wlua || !L)
		return;

	lua_getglobal(L, "OnSetIsSimulateInEditorViewport");
	if (lua_isfunction(L, -1))
	{
		lua_pushboolean(L, bInIsSimulateInEditorViewport ? 1 : 0);
		wlua->Call(1);
	}
	else
	{
		lua_pop(L, 1);
	}
}

void AzureInputCtrl::EnableGyroCtrl(float vl, float hl, float md, float s)
{
	//AAzureEntryPoint::Instance->GetMainCameraCtrl()->InitGyro(m_vTilt, vl, hl, md, s);
}

void AzureInputCtrl::RaiseShakeEvent()
{
	if (!AAzureEntryPoint::Instance)
		return;

	wLua::Lua* pLua = AAzureEntryPoint::Instance->GetWLua();
	lua_State_Wrapper L = pLua ? pLua->GetL() : nullptr;
	lua_getglobal(L, "OnShake");
	pLua->Call(0);
}

void AzureInputCtrl::UpdateKeyboardInput(float fDeltaTime)
{
	if (!AAzureEntryPoint::IsInit())
		return;

	auto* PlayCtrl = AAzureEntryPoint::Instance->GetPlayerController();
	if (!PlayCtrl)
		return;
	
	for (TArray<FKey>::TIterator It(FKeyCodeArr); It; ++It)
	{
		const FKey& key = *It;
		if (PlayCtrl->IsInputKeyDown(key))
		{
			lua_State_Wrapper L = AAzureEntryPoint::Instance->GetL();
			lua_getglobal(L, "OnKeyboard");
			lua_pushstring(L, TCHAR_TO_UTF8(*key.ToString()));
			lua_pushinteger(L, 1);
			AAzureEntryPoint::Instance->GetWLua()->Call(2);
		}
		else if (PlayCtrl->WasInputKeyJustReleased(key))
		{
			lua_State_Wrapper L = AAzureEntryPoint::Instance->GetL();
			lua_getglobal(L, "OnKeyboard");
			lua_pushstring(L, TCHAR_TO_UTF8(*key.ToString()));
			lua_pushinteger(L, 0);
			AAzureEntryPoint::Instance->GetWLua()->Call(2);
		}
	}

	/*int k = -1;
	if (PlayCtrl->IsInputKeyDown(EKeys::PageUp))
	{
		//AAzureEntryPoint::Instance->GetMainCameraCtrl()->GetGameCam().OnGestureZoom(GESTURE_STATE::CHANGE, -0.3f * fDeltaTime);
	}
	else if (PlayCtrl->IsInputKeyDown(EKeys::PageDown))
	{
		//AAzureEntryPoint::Instance->GetMainCameraCtrl()->GetGameCam().OnGestureZoom(GESTURE_STATE::CHANGE, 0.3f * fDeltaTime);
	}
	else if (PlayCtrl->IsInputKeyDown(EKeys::Subtract))
	{
		k = 100;
	}
	else if (PlayCtrl->WasInputKeyJustReleased(EKeys::J))
	{
		k = 11;
	}
	else if (PlayCtrl->WasInputKeyJustReleased(EKeys::K))
	{
		k = 12;
	}
	else if (PlayCtrl->WasInputKeyJustReleased(EKeys::L))
	{
		k = 13;
	}
	else if (PlayCtrl->WasInputKeyJustReleased(EKeys::RightControl))
	{
		k = 14;
	}
	else
	{
		if (PlayCtrl->IsInputKeyDown(EKeys::Escape))//提供PC测试
			k = 200;
	}

	if (k != -1)
	{
		lua_State* L = AAzureEntryPoint::Instance->GetL();
		lua_getglobal(L, "OnKeyboard");
		lua_pushinteger(L, k);
		AAzureEntryPoint::Instance->GetWLua()->Call(1);
	}*/
}

void AzureInputCtrl::RegisterKey(FKey key)
{
	for (TArray<FKey>::TIterator It(FKeyCodeArr); It; ++It)
	{
		if (*It == key)
		{
			return;
		}
	}

	FKeyCodeArr.Add(key);
}
void AzureInputCtrl::UnregisterKey(FKey key)
{
	for (TArray<FKey>::TIterator It(FKeyCodeArr); It; ++It)
	{
		if (*It == key)
		{
			FKeyCodeArr.Remove(key);
			return;
		}
	}
}

void AzureInputCtrl::UnregisterAll()
{
	FKeyCodeArr.Empty();
}

void AzureInputCtrl::ClearAllMsg()
{
	m_fLastSendMsgPress = 0.0f;
	for (uint32 i = 0; i < MaxTouchCount; ++i)
	{
		m_MsgQueue[i].Clear();
	}
}

void AzureInputCtrl::Tick(float fDeltaTime)
{
	++m_curFrame;

	ReduceTooOftenTouches();

	for (uint32 i = 0; i < MaxTouchCount; ++i)
	{
		auto& qu = m_MsgQueue[i];
		if (!qu.IsEmpty())
		{
			AzureRawTouch QueueTouch = qu.PopFront();
			AzureTouchState& state = m_TouchStates[i];
			AzureTouch& touch = state.RawTouch;

			if (touch.ValidState == AzureTouchValidState::Valid || QueueTouch.Type == ETouchType::Type::Began)
			{
				touch.phase = QueueTouch.Type;
				touch.position = QueueTouch.TouchLocation;
				touch.ValidState = AzureTouchValidState::Valid;
			}
			else
			{
				// 错误状态，在没有Begin时就有Move,Stationary，或者End, 忽略掉
			}
		}
	}

	TickTouchStates(fDeltaTime);
	if (AAzureEntryPoint::IsInit())
	{
		if (AAzureEntryPoint::Instance->WidgetInteractionComp && AAzureEntryPoint::Instance->WidgetInteractionComp->GetHoveredWidgetComponent() && AAzureEntryPoint::Instance->WidgetInteractionComp->GetHoveredWidgetComponent()->GetUserWidgetObject())//被3d界面拦截
			TickWidgetInteraction(fDeltaTime);
		else
		{
			lua_State_Wrapper L = AAzureEntryPoint::Instance->GetWLua()->GetL();
			if (L != nullptr)
			{
				lua_getglobal(L, "CheckInputTouch");
				AAzureEntryPoint::Instance->GetWLua()->Call(0);
			}
		}	
	}

#if PLATFORM_DESKTOP
	UpdateKeyboardInput(fDeltaTime);
#endif

	TickJoyStickState(fDeltaTime);

	TickInputMotion(fDeltaTime);
}

void AzureInputCtrl::ReduceTooOftenTouches()
{
	for (uint32 i = 0; i < MaxTouchCount; ++i)
	{
		AzureTouchMessageQueue& CurrentQueue = m_MsgQueue[i];
		CurrentQueue.ReduceTooOftenTouches();
	}
}

void AzureInputCtrl::SetEnableInputMotion(bool b) 
{ 
	m_bEnableInputMotion = b; 
#if PLATFORM_IOS
	FIOSApplication::StartMotionUpdates(m_bEnableInputMotion);
#elif PLATFORM_ANDROID
	FAndroidApplication::StartMotionUpdates(m_bEnableInputMotion);
#endif
}

FString AzureInputCtrl::GetKeyShowText(const FName& KeyName)
{
	FKey key(KeyName);
	return key.GetDisplayName(false).ToString();
}


//	class AzureTouchMessageQueue
void AzureTouchMessageQueue::PushBack(ETouchType::Type Type, const FVector2D& TouchLocation)
{
	this->Queue.emplace_back(AzureRawTouch{ Type, TouchLocation });
}
AzureRawTouch AzureTouchMessageQueue::PopFront()
{
	AzureRawTouch Result = this->Queue.front();
	this->Queue.erase(this->Queue.begin());
	return Result;
}

bool AzureTouchMessageQueue::IsEmpty()const
{
	return this->Queue.empty();
}
int AzureTouchMessageQueue::Size()const
{
	return (int)(this->Queue.size());
}

void AzureTouchMessageQueue::Clear()
{
	Queue.clear();
}

FString AzureTouchMessageQueue::ToString()const
{
	FString Result;

	static const TCHAR* InputType2String[ETouchType::NumTypes] = {
		TEXT("Began"),
		TEXT("Moved"),
		TEXT("Stationary"),
		TEXT("ForceChanged"),
		TEXT("FirstMove"),
		TEXT("Ended"),
	};

	for (const auto& ThisTouch : this->Queue)
	{
		if (!Result.IsEmpty())
		{
			Result += TEXT(",");
		}
		Result += FString::Printf(TEXT("%s(%f,%f)"), InputType2String[ThisTouch.Type], ThisTouch.TouchLocation.X, ThisTouch.TouchLocation.Y);
	}
	
	return Result;
}

bool AzureTouchMessageQueue::operator==(const AzureTouchMessageQueue& rhs)const
{
	bool Result(true);
	while (true)
	{
		if (this->Size() != rhs.Size())
		{
			Result = false;
			break;
		}
		for (int i(0); i < this->Size(); ++ i)
		{
			if (this->GetAt(i) != rhs.GetAt(i))
			{
				Result = false;
				break;
			}
		}
		break;
	}
	return Result;
}

bool AzureTouchMessageQueue::operator!=(const AzureTouchMessageQueue& rhs)const
{
	return !(*this == rhs);
}

//	method for reducing touch frequency cause the producer(iOS\Android\Windows) can generate more than 1 touch message between tick, while we now consume only one each tick
//	the reducing algorithm references to Unity3D 4.3.1 source code (iOS:iphone::OnProcessTouchEvents within file iPhoneInputImpl.mm, Android: AddTouchEvent within TouchPhaseEmulation.cpp)
//	1.incomplete touch (missing touchBegan or touchEnded this tick) will not be removed in order to generate matching [touchBegan touchEnded] all the time
//	2.in between full touches are removed to reduce touch frequency
//	3.touchMoved are reduced to the latest one within same touch
//	4.touchMoved after touchBegan or before touchEnded within same touch is removed to reduce frequency
//	5.queue will NOT be reduced to none any way
void AzureTouchMessageQueue::ReduceTooOftenTouches()
{
	if (this->Size() <= 1)
	{
		return;		//	No need to reduce for only one touch message
	}
	if (!this->Validate())	// make sure queue is expected to avoid unexpected result for i.e. upgrading UE4 engine.
	{
		extern CORE_API bool GAzureRuntimeDebugFlag;
		if (GAzureRuntimeDebugFlag)
		{
			UE_LOG(LogAzure, Warning, TEXT("TouchMessageQueue::ReduceTooOftenTouches, invalid touch queue:%s"), *this->ToString());
		}
		return;
	}
	this->EraseAllFullTouchesExceptTheLatestIfAllAreFullTouches();	//	remove all unnecessary full touches first to avoid more message memory move later
	this->ReduceNotEndedTouchAtBack();	//	then reduce back touch before front touch to avoid more message move when reducing front touch
	this->ReduceTouchAtFront();
}

//	Message Queue is valid for reducing when:
//	1. has only three kind of messages (TouchBegan TouchMoved TouchEnded) cause TouchStationary has not been taken into account during reducing now
//	2. queue is in pattern: Began Moved Ended Began Moved Ended ...
bool AzureTouchMessageQueue::Validate()const
{
	bool Result(true);
	while (!this->IsEmpty())
	{
		if (!this->IsFrontTouchBegan() &&
			!this->IsFrontTouchEnded() &&
			!this->IsFrontTouchMoved())
		{
			Result = false;
			break;
		}
		bool TouchAlreadyBegan = this->IsFrontTouchBegan() || this->IsFrontTouchMoved();
		for (int i(1); i < this->Size(); ++i)
		{
			if (TouchAlreadyBegan)
			{
				if (this->IsTouchBeganAt(i))
				{
					Result = false;	// another TouchBegan before TouchEnded
					break;
				}
				else if (this->IsTouchEndedAt(i))
				{
					TouchAlreadyBegan = false;	// prepare next full touch if any
				}
				else if (!this->IsTouchMovedAt(i))	//	should be TouchMoved
				{
					Result = false;
					break;
				}
			}
			else
			{
				if (!this->IsTouchBeganAt(i))	//	Should only be touchBegan
				{
					Result = false;
					break;
				}
				else
				{
					TouchAlreadyBegan = true;
				}
			}
		}
		break;
	}
	return Result;
}

//	a full touch means message starts with touchBegan, with or without touchMoved in between, and ends with touchEnded
//	full touches means there may be more than one full touch
void AzureTouchMessageQueue::EraseAllFullTouchesExceptTheLatestIfAllAreFullTouches()
{
	int FromPosition = this->FindTouchBeganFromFront();
	int ToPosition = this->ReverseFindTouchEndedFromBack();
	if (FromPosition == 0 && ToPosition == this->GetBackPosition())
	{
		ToPosition = this->ReverseFindTouchEndedFrom(this->GetBackPosition() - 1);	//	Remain the latest full touch (avoid empty queue) if all messages are full touches
	}
	this->EraseMessagesBetween(FromPosition, ToPosition);	//	[FromPosition, ToPosition] may be invalid and is checked within method EraseMessagesBetween so the caller's code is simple
}

//	if there is touchBegan not at front, then it's considered back touch, others are considered front touch
void AzureTouchMessageQueue::ReduceNotEndedTouchAtBack()
{
	int touchBeganPosition = this->ReverseFindTouchBeganFromBack();
	if (touchBeganPosition != 0)
	{
		this->ReduceTouchBetween(touchBeganPosition, this->GetBackPosition());
	}
}

void AzureTouchMessageQueue::ReduceTouchAtFront()
{
	this->ReduceTouchBetween(0, this->FindLatestTouchMessageFrom(0));
}

//	Reduce within one full touch (may missing touchBegan and/or touchEnded)
//	algorithm includes:
//	1. more than one touchMoved message is reduced to the latest, and is reduced to none when there is touchBegan or touchEnded
//	2. touchBegan is not reduced
//	3. touchEnded is not reduced, even when touchBegan is there, which means touchEnded will be processed till next tick
void AzureTouchMessageQueue::ReduceTouchBetween(int FromPosition, int ToPosition)
{
	if (!this->IsPositionRangeValid(FromPosition, ToPosition))
	{
		return;
	}
	if (FromPosition == ToPosition)
	{
		return;	//	No need to reduce for only one touch message
	}
	if (this->IsTouchBeganAt(FromPosition))
	{
		//	TouchBegan is received this frame, Other messages should be reduced except TouchEnded
		if (this->IsTouchEndedAt(ToPosition))
		{
			this->EraseMessagesBetween(FromPosition + 1, ToPosition - 1);	//	TouchEnded cannot be reduced
		}
		else
		{
			this->EraseMessagesBetween(FromPosition + 1, ToPosition);		//	Other Input should be reduced when there's TouchBegan
		}
	}
	else if (this->IsTouchMovedAt(FromPosition))
	{
		//	TouchBegan was received in previous frame, TouchMoved should be reduced to the last one or none when there is TouchEnded
		this->EraseMessagesBetween(FromPosition, ToPosition - 1);
	}
}

void AzureTouchMessageQueue::EraseMessagesBetween(int FromPosition, int ToPosition)
{
	if (!this->IsPositionRangeValid(FromPosition, ToPosition))
	{
		return;
	}
	this->Queue.erase(this->Queue.begin() + FromPosition, this->Queue.begin() + (ToPosition + 1));
}

bool AzureTouchMessageQueue::IsFrontTouchBegan()const
{
	return this->IsTouchBeganAt(0);
}
bool AzureTouchMessageQueue::IsFrontTouchEnded()const
{
	return this->IsTouchEndedAt(0);
}
bool AzureTouchMessageQueue::IsFrontTouchMoved()const
{
	return this->IsTouchMovedAt(0);
}
bool AzureTouchMessageQueue::IsBackTouchEnded()const
{
	return this->IsTouchEndedAt(this->GetBackPosition());
}
bool AzureTouchMessageQueue::IsTouchBeganAt(int Position)const
{
	return this->GetTouchTypeAt(Position) == ETouchType::Began;
}
bool AzureTouchMessageQueue::IsTouchEndedAt(int Position)const
{
	return this->GetTouchTypeAt(Position) == ETouchType::Ended;
}
bool AzureTouchMessageQueue::IsTouchMovedAt(int Position)const
{
	return this->GetTouchTypeAt(Position) == ETouchType::Moved;
}

int AzureTouchMessageQueue::FindTouchBeganFromFront()const
{
	return this->FindTouchBeganFrom(0);
}
int AzureTouchMessageQueue::FindTouchBeganFrom(int FromPosition)const
{
	return this->FindTouchTypeFrom(ETouchType::Began, FromPosition);
}
int AzureTouchMessageQueue::ReverseFindTouchBeganFromBack()const
{
	return this->ReverseFindTouchBeganFrom(this->GetBackPosition());
}
int AzureTouchMessageQueue::ReverseFindTouchBeganFrom(int FromPosition)const
{
	return this->ReverseFindTouchTypeFrom(ETouchType::Began, FromPosition);
}
int AzureTouchMessageQueue::FindTouchEndedFromFront()const
{
	return this->FindTouchEndedFrom(0);
}
int AzureTouchMessageQueue::FindTouchEndedFrom(int FromPosition)const
{
	return this->FindTouchTypeFrom(ETouchType::Ended, FromPosition);
}
int AzureTouchMessageQueue::ReverseFindTouchEndedFromBack()const
{
	return this->ReverseFindTouchEndedFrom(this->GetBackPosition());
}
int AzureTouchMessageQueue::ReverseFindTouchEndedFrom(int FromPosition)const
{
	return this->ReverseFindTouchTypeFrom(ETouchType::Ended, FromPosition);
}
int AzureTouchMessageQueue::FindTouchTypeFrom(ETouchType::Type TypeIn, int FromPosition)const
{
	return this->FindTouchTypeBetween(TypeIn, FromPosition, this->GetBackPosition());
}
int AzureTouchMessageQueue::ReverseFindTouchTypeFrom(ETouchType::Type TypeIn, int FromPosition)const
{
	return this->ReverseFindTouchTypeBetween(TypeIn, FromPosition, 0);
}
int AzureTouchMessageQueue::FindTouchTypeBetween(ETouchType::Type TypeIn, int FromPosition, int ToPosition)const
{
	int Result = -1;
	for (int i = FromPosition; i <= ToPosition; ++i)
	{
		if (this->GetTouchTypeAt(i) == TypeIn)
		{
			Result = i;
			break;
		}
	}
	return Result;
}
int AzureTouchMessageQueue::ReverseFindTouchTypeBetween(ETouchType::Type TypeIn, int FromPosition, int ToPosition)const
{
	int Result = -1;
	for (int i = FromPosition; i >= ToPosition; --i)
	{
		if (this->GetTouchTypeAt(i) == TypeIn)
		{
			Result = i;
			break;
		}
	}
	return Result;
}
int AzureTouchMessageQueue::FindLatestTouchMessageFrom(int FromPosition)const
{
	int Result = this->FindTouchEndedFrom(FromPosition);	//	Return TouchEnded Position if exist
	if (!this->IsPositionValid(Result))
	{
		Result = this->GetBackPosition();					//	Or else return the last message
	}
	return Result;
}

ETouchType::Type AzureTouchMessageQueue::GetTouchTypeAt(int Position)const
{
	return this->GetAt(Position).Type;
}

bool AzureTouchMessageQueue::IsPositionRangeValid(int FromPosition, int ToPosition)const
{
	return 0 <= FromPosition
		&& FromPosition <= ToPosition
		&& ToPosition <= this->GetBackPosition();
}
bool AzureTouchMessageQueue::IsPositionValid(int Position)const
{
	return Position >= 0 && Position <= this->GetBackPosition();
}
int AzureTouchMessageQueue::GetBackPosition()const
{
	return this->Size() - 1;
}

const AzureRawTouch& AzureTouchMessageQueue::Front()const
{
	return this->Queue.front();
}
const AzureRawTouch& AzureTouchMessageQueue::Back()const
{
	return this->Queue.back();
}
const AzureRawTouch& AzureTouchMessageQueue::GetAt(int Position)const
{
	return this->Queue[Position];
}