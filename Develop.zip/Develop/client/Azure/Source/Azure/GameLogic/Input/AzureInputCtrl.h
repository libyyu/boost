﻿#pragma once

#include "CoreMinimal.h"
#include "Engine/EngineBaseTypes.h"
#include "InputCoreTypes.h"
#include <vector>
#include "ABaseDef.h"

enum class AzureTouchValidState
{
	NOT_SET = 0,
	InValid,
	Valid,
};

struct AzureRawTouch
{
	ETouchType::Type Type;
	FVector2D TouchLocation;

	bool operator==(const AzureRawTouch& rhs)const;
	bool operator!=(const AzureRawTouch& rhs)const;
};

struct AzureTouch
{
	ETouchType::Type phase;
	FVector2D position;
	AzureTouchValidState ValidState = AzureTouchValidState::NOT_SET;

	bool IsValid() const { return ValidState == AzureTouchValidState::Valid;  }
};

class AzureTouchState
{
protected:

	static float m_InScopeSqDist;

	inline bool IsInScope(const FVector2D& ptOrigin, const FVector2D& ptPos)
	{
		return FVector2D::DistSquared(ptOrigin, ptPos) < m_InScopeSqDist;
	}

public:

	AzureTouch RawTouch;
	AzureTouch ThisTouch;
	AzureTouch LastTouch;
	AzureTouch BeginTouch;
	AzureTouch EndTouch;

	bool HasMoved = false;

	bool IsPhaseChanged()
	{
		return ThisTouch.phase == ETouchType::Type::Began || ThisTouch.phase != LastTouch.phase;
	}

	void Update()
	{
		switch (ThisTouch.phase)
		{
		case ETouchType::Type::Began:
			BeginTouch = ThisTouch;
			HasMoved = false;
			break;

		case ETouchType::Type::Moved:
			if (!HasMoved && BeginTouch.IsValid() && !IsInScope(BeginTouch.position, ThisTouch.position))
				HasMoved = true;
			break;

		case ETouchType::Type::Stationary:
		case ETouchType::Type::ForceChanged:
		case ETouchType::Type::FirstMove:
			break;

		case ETouchType::Type::Ended:
			EndTouch = ThisTouch;
			break;

		default:
			check(false && "ThisTouch.phase NOT valid!");
		}
	}

	void Clear()
	{
		RawTouch.ValidState = AzureTouchValidState::NOT_SET;
		ThisTouch.ValidState = AzureTouchValidState::NOT_SET;
		LastTouch.ValidState = AzureTouchValidState::NOT_SET;
		BeginTouch.ValidState = AzureTouchValidState::NOT_SET;
		EndTouch.ValidState = AzureTouchValidState::NOT_SET;
		HasMoved = false;
	}

	static float get_InScopeSqDist()
	{
		return m_InScopeSqDist;
	}

	static void set_InScopeSqDist(float v)
	{
		m_InScopeSqDist = v;
	}
};

/* Touches queue from system for the same FingerId
*  method ReduceTooOftenTouches should be called first to reduce frequency so that we can process only one touch message each Tick
*  Only Began\Moved\Ended three touch types is expected currently, as shown in method Validate
*/
class AzureTouchMessageQueue
{
	avector<AzureRawTouch> Queue;

public:
	void PushBack(ETouchType::Type Type, const FVector2D& TouchLocation);
	AzureRawTouch PopFront();

	bool IsEmpty()const;
	int Size()const;
	void Clear();

	FString ToString()const;
	bool operator==(const AzureTouchMessageQueue& rhs)const;
	bool operator!=(const AzureTouchMessageQueue& rhs)const;

	void ReduceTooOftenTouches();

private:
	bool Validate()const;
	void EraseAllFullTouchesExceptTheLatestIfAllAreFullTouches();
	void ReduceNotEndedTouchAtBack();
	void ReduceTouchAtFront();
	void ReduceTouchBetween(int FromPosition, int ToPosition);
	void EraseMessagesBetween(int FromPosition, int ToPosition);

	bool IsFrontTouchBegan()const;
	bool IsFrontTouchEnded()const;
	bool IsFrontTouchMoved()const;
	bool IsBackTouchEnded()const;
	bool IsTouchBeganAt(int Position)const;
	bool IsTouchEndedAt(int Position)const;
	bool IsTouchMovedAt(int Position)const;

	int FindTouchBeganFromFront()const;
	int FindTouchBeganFrom(int FromPosition)const;
	int ReverseFindTouchBeganFromBack()const;
	int ReverseFindTouchBeganFrom(int FromPosition)const;
	int FindTouchEndedFromFront()const;
	int FindTouchEndedFrom(int FromPosition)const;
	int ReverseFindTouchEndedFromBack()const;
	int ReverseFindTouchEndedFrom(int FromPosition)const;
	int FindTouchTypeFrom(ETouchType::Type TypeIn, int FromPosition)const;
	int ReverseFindTouchTypeFrom(ETouchType::Type TypeIn, int FromPosition)const;
	int FindTouchTypeBetween(ETouchType::Type TypeIn, int FromPosition, int ToPosition)const;
	int ReverseFindTouchTypeBetween(ETouchType::Type TypeIn, int FromPosition, int ToPosition)const;
	int FindLatestTouchMessageFrom(int FromPosition)const;

	ETouchType::Type GetTouchTypeAt(int Position)const;

	bool IsPositionRangeValid(int FromPosition, int ToPosition)const;
	bool IsPositionValid(int Position)const;
	int GetBackPosition()const;

	const AzureRawTouch& Front()const;
	const AzureRawTouch& Back()const;
	const AzureRawTouch& GetAt(int Position)const;
};

class AzureInputCtrl
{
public:

	static constexpr uint32 MaxTouchCount = 5;

	static AzureInputCtrl& GetInstance()
	{
		static AzureInputCtrl inst;
		return inst;
	}

private:

	uint32 m_curFrame = 0;
	
	uint32 m_LastTouchCount = 0;
	uint32 m_TouchCount = 0;
	int m_MaxValidTouchId = -1;
	AzureTouchState m_TouchStates[MaxTouchCount];
	AzureTouchMessageQueue m_MsgQueue[MaxTouchCount];

	FVector2D m_vLastFrameJoyStickValue = FVector2D::ZeroVector;
	float m_fThisFrameJoystickX = 0;
	float m_fThisFrameJoystickY = 0;
	uint32 m_JoystickFrame = 0;
	float m_fLastSendMsgPress = 0;

	// 非玩家的手动输入，由代码直接控制的输入
	FVector2D m_vNotManualJoyStickValue = FVector2D::ZeroVector;
	FVector2D m_vLastFrameNotManualJoyStickValue = FVector2D::ZeroVector;

	bool m_bEnableInputMotion = false;
	FVector m_vTilt;
	FVector m_vRotationRate;
	FVector m_vGravity;
	FVector m_vAcceleration = FVector::ZeroVector;
	FVector m_vLastTilt;
	FVector m_vLastRotationRate;
	FVector m_vLastGravity;
	FVector m_vLastAcceleration = FVector::ZeroVector;

	// 摇动的加速度阈值，加速度突变超时此值认为是摇动
	float m_shakeAccelerationThreshold = 3.0f;
	// 摇动的采样时间
	float m_shakeSampleTime = 1.0f;
	float m_shakeSampleTimeCur = 0;
	// 采样时间内的有效次数 （大于此次数触发脚本事件）
	int m_shakeCount = 3;
	int m_shakeCountCur = 0;
	FVector m_vLastShakeDir = FVector::ZeroVector;
	//按键操作
	TArray<FKey> FKeyCodeArr;
protected:

	void CheckStartTouch();
	void SendMsgJoystickPress();
	void SendMsgJoystickRelease();
	void RaiseShakeEvent();

public:

	AzureInputCtrl();

	uint32 get_LastTouchCount() const
	{
		return m_LastTouchCount;
	}

	uint32 get_TouchCount() const
	{
		return m_TouchCount;
	}

	int get_MaxValidTouchId() const
	{
		return m_MaxValidTouchId;
	}

	AzureTouchState* GetTouchState(unsigned int index)
	{
		if (index < MaxTouchCount)
			return &m_TouchStates[index];
		else
			return nullptr;
	}

	FVector2D GetJoyStickValue() const
	{
		FVector2D value;
		if (!m_vLastFrameNotManualJoyStickValue.IsNearlyZero())
		{
			return m_vLastFrameNotManualJoyStickValue;
		}
		else
		{
			return m_vLastFrameJoyStickValue;
		}
	}

	FVector2D GetNotManualJoyStickValue() const
	{
		return m_vLastFrameNotManualJoyStickValue;
	}

	void SetJoystickValue(float x, float y)
	{
		m_fThisFrameJoystickX = x;
		m_fThisFrameJoystickY = y;
	}

	void SetNotManualJoyStickValue(float x, float y)
	{
		m_vNotManualJoyStickValue.X = x;
		m_vNotManualJoyStickValue.Y = y;
	}

	void SetNotManualJoyStickValueX(float x)
	{
		m_vNotManualJoyStickValue.X = x;
	}
	void SetNotManualJoyStickValueY(float y)
	{
		m_vNotManualJoyStickValue.Y = y;
	}

	void EnableGyroCtrl(float vl, float hl, float md, float s);
	bool GetEnableInputMotion() { return m_bEnableInputMotion; }
	void SetEnableInputMotion(bool b);
	void SetShakeParam(float shakeAccelerationThreshold,float shakeSampleTime, int shakeCount) {
		m_shakeAccelerationThreshold = shakeAccelerationThreshold;
		m_shakeSampleTime = shakeSampleTime;
		m_shakeCount = shakeCount;
	}

	void Tick(float fDeltaTime);
	void TickTouchStates(float fDeltaTime);
	void TickJoyStickState(float fDeltaTime);
	void TickWidgetInteraction(float fDeltaTime);
	void TickInputMotion(float fDeltaTime);

	void ReduceTooOftenTouches();

	bool InputKey(FKey Key, EInputEvent EventType, float AmountDepressed, bool bGamepad);
	bool InputAxis(FKey Key, float Delta, float DeltaTime, int32 NumSamples, bool bGamepad);
	void InputTouch(uint32 Handle, ETouchType::Type Type, const FVector2D& TouchLocation);
	void InputMotion(const FVector& Tilt, const FVector& RotationRate, const FVector& Gravity, const FVector& Acceleration);

	void OnReceivedFocus(FViewport* Viewport);
	void OnLostFocus(FViewport* Viewport);
	void OnActivated(FViewport* Viewport, const FWindowActivateEvent& InActivateEvent);
	void OnDeactivated(FViewport* Viewport, const FWindowActivateEvent& InActivateEvent);
	void OnPreDeactivated(FViewport* Viewport, const FWindowActivateEvent& InActivateEvent);
	void OnSetIsSimulateInEditorViewport(bool bInIsSimulateInEditorViewport);

	void UpdateKeyboardInput(float fDeltaTime);

	void RegisterKey(FKey key);
	void UnregisterKey(FKey key);
	void UnregisterAll();
	void ClearAllMsg();

	float GetJoystickX();
	float GetJoystickY();

	FString GetKeyShowText(const FName& KeyName);
};
