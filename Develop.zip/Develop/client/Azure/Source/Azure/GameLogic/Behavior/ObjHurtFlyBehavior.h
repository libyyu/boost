﻿#pragma once

#include "AzureBehavior.h"

//////////////////////////////////////////////////////////////////////////
class ObjHurtFlyBehavior : public AzureBehavior
{
protected:
	static constexpr  Azure::BehaviorType _type = Azure::BehaviorType::HurtFly;

	float m_t;//总时间
	float time;

	FVector m_vStart;
	FVector m_vDest;
	float topZ;//最高点高度值
	float m_v0_1;//第一段高度方向的初速度
	float m_a1;//第一段高度方向的加速度
	float m_a3;//第三段高度方向的加速度

	//抛物线上升---无重力浮空平移---抛物线下降3个阶段
	//如果配置的水平距离是0，或者背靠墙，就不平移，原地挑空
	float m_t1;//第一段，抛物线上升的时间
	float m_t2;//第二段，浮空的时间
	float m_t3;//第三段，抛物线下降的时间

	float m_x1;//第一段水平距离
	float m_x2;//第二段水平距离
	float m_x3;//第三段水平距离

	float m_x;//水平总距离
	FVector m_x_dir;//水平方向的单位向量

	bool b_z_error;
	float m_gravityScale;

	TWeakObjectPtr<class AGamePlayer> m_carrier;
	bool m_isOnCarrier;
	FRotator m_relRot;

public:

	ObjHurtFlyBehavior()
	{
		
	}

	static ObjHurtFlyBehavior* Create()
	{
		ObjHurtFlyBehavior* ret = (ObjHurtFlyBehavior*)AzureBehaviorCache::GetInstance().GetBehavior(_type);

		if (ret == nullptr)
			ret = new ObjHurtFlyBehavior();

		return ret;
	}

	Azure::BehaviorType get_Type() const override
	{
		return _type;
	}

	bool SetData(const FVector & vDest, float time_t, float h, float dis_x1, float time_t1, float dis_x2, float time_t2, class AGamePlayer * pCarrier, OnBehaviorFinish onFinish);
	bool Tick(float dt) override;
	virtual void OnRemoved(bool replace) override;

	void CalRelPosRot(const FVector & abs_pos, const FRotator & abs_rot,
		FVector & result_pos, FRotator & result_rot);

	FVector GetPosAfter(float time);
	void SetObjPos(class AGamePlayer * pObj, const FVector & pos);
};

