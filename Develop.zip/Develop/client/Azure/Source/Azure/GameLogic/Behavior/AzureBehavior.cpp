﻿#include "AzureBehavior.h"
#include "AzureBehaviorDef.h"


using namespace Azure;

size_t AzureBehaviorCache::MaxCacheNum[(int)BehaviorType::NumType] = {
	1,		//Move = 0,			
	1,		//Turn,				
	1,		//DecelMove,		
	10,		//Charge,			
	5,		//BezierMove,	

	1,		//HPMove,			
	1,		//HPJoystickMove,	
	3,		//HPAutoMove,		
	3,		//HPBezierMove,		
	3,		//HPTurnSyncServer,	

	3,		//HPLockTarget,		
	20,		//PitchTurn,		
	1,		//HPJump				// HostPlayer跳
	1,		//ObjServerMove			// ElsePlayer等收到服务器协议移动
	1,		//HPVehicleJoystickMove // 骑乘状态摇杆移动

	1,		//HurtFly				// 击飞
	1,		//ObjMove				// CG中单位根据characterMovement移动,用于CG
	1,		//HPRushDown			// 空中下冲技能
	1,		//ObjServerSkillMove	// ElsePlayer等收到服务器技能移动
	1,		//RootMotionMove

	1,		//ObjServerRootMotionMove
	1,		//HPBePush
	1,		//Glide
};

UAzureObjectComponent* AzureBehavior::get_ECObj()
{
	return _objcomp.Get();
}

void AzureBehavior::set_ECObj(UAzureObjectComponent* v)
{
	_objcomp = v;
}
