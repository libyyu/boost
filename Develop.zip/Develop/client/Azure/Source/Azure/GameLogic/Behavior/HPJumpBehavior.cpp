#include "HPJumpBehavior.h"
#include "AzureObjectComponent.h"
#include "AzureUtility.h"
#include "GameLogic/Input/AzureInputCtrl.h"
#include "GameLogic/Player/GamePlayer.h"
#include "GameLogic/Player/GamePlayer_Util.h"
#include "GameFramework/CharacterMovementComponent.h"

HPJumpBehavior* HPJumpBehavior::Create()
{
	HPJumpBehavior* ret = (HPJumpBehavior*)AzureBehaviorCache::GetInstance().GetBehavior(_type);

	if (ret == nullptr)
		ret = new HPJumpBehavior();

	ret->_create_framecount = GFrameNumber;

	return ret;
}

bool HPJumpBehavior::SetData(float _gravity_scale_down, OnBehaviorFinish onFinish, bool isSkillMove)
{
	set_OnFinish(onFinish);

	gravity_scale_down = _gravity_scale_down;
	//������ط���Э��ͬ��û�ã���ʱ��ɫ��û�л����Ծ���ٶȣ�����GamePlayer::OnJump�﷢

	//MyPrintString("JumpBeh Start");

	if (!_objcomp.IsValid())
		return false;
	
	AGamePlayer * pActor = Cast<AGamePlayer>(_objcomp->GetOwner());
	if (!pActor)
		return false;

	if (false)
	{		
		FString str = FString::Printf(TEXT("JumpBeh SetData Vel %0.1f %0.1f"),
			pActor->GetVelocity().X, pActor->GetVelocity().Y);
		MyPrintString(str);
	}
	return true;
}


void HPJumpBehavior::OnRemoved(bool replace)
{
	if (false)
	{
		if (!AAzureEntryPoint::Instance)
			return;

		double st = AAzureEntryPoint::Instance->GetRealtimeSinceStartup();
		FString str = FString::Printf(TEXT("JumpBeh End %0.3f"), st);
		MyPrintString("JumpBeh End");
	}	
}

bool HPJumpBehavior::TickInternal(float dt)
{
	if (!HPMoveBase::TickInternal(dt))
		return false;

	if (!_objcomp.IsValid())
		return true;

	AGamePlayer * pActor = Cast<AGamePlayer>(_objcomp->GetOwner());		
	if (!pActor)
		return true;

	FVector2D v = AzureInputCtrl::GetInstance().GetJoyStickValue();
	
	FVector dir1 = FVector::ZeroVector;
	FVector dir2 = FVector::ZeroVector;

	bool isInput = false;
	bool isReceiveInput = pActor->IsReceiveInputWhenJump();

	if (isReceiveInput)
	{
		if (v.Y != 0.0f)//Move Forward
		{
			const FRotator Rotation = pActor->GetControlRotation();
			const FRotator YawRotation(0, Rotation.Yaw, 0);

			const FVector Direction = FRotationMatrix(YawRotation).GetUnitAxis(EAxis::X);
			dir1 = Direction;
			isInput = true;
		}

		if (v.X != 0.0f)//Move Right
		{
			const FRotator Rotation = pActor->GetControlRotation();
			const FRotator YawRotation(0, Rotation.Yaw, 0);

			const FVector Direction = FRotationMatrix(YawRotation).GetUnitAxis(EAxis::Y);
			dir2 = Direction;
			isInput = true;
		}
	}


	if (isInput)//ִ����Ϸ�Լ�����ײ�赲�߼�
	{
		bool canMove = true;

		if (pActor->GetVelocity().Z > 0.0f)//�����׶β��ܲ���
			canMove = false;

		if (canMove)
		{
			if (v.Y != 0.0f)
				pActor->AddMovementInput(dir1, v.Y);

			if (v.X != 0.0f)
				pActor->AddMovementInput(dir2, v.X);

		}
		else
		{
			
		}		
	}
	
	if (false)
	{
		/*FString str = FString::Printf(TEXT("JumpBeh MoveDelta %0.3f %0.3f Vel %0.1f %0.1f"),
			move_delta.X, move_delta.Y, pActor->GetVelocity().X, pActor->GetVelocity().Y);*/
		FString str = FString::Printf(TEXT("JumpBeh Vel %0.1f -- %0.1f %0.1f"),
			pActor->GetVelocity().Size2D(), pActor->GetVelocity().X, pActor->GetVelocity().Y);
		MyPrintString(str);
	}

	if (!pActor->GetCharacterMovement()->IsFalling())
	{
		return true;
	}	
		
	if (pActor->m_fSyncPushMoveTimer >= Azure::host_jump_sync_interval)
	{
		if (false)
		{
			if (!AAzureEntryPoint::Instance)
				return true;

			double st = AAzureEntryPoint::Instance->GetRealtimeSinceStartup();
			static double last_st = st;

			//FString str = FString::Printf(TEXT("server move speed %0.1f"), vVelocity.Size());
			//MyPrintString(str);
			FString str = FString::Printf(TEXT("send jumpping %0.4f [%0.4f]--%0.3f"), pActor->m_fSyncPushMoveTimer,st - last_st, st);
			MyPrintString(str);

			last_st = st;
		}

		pActor->SyncPushMoveToServer("HPJump Tick", ESyncMoveSendType::Jumpping,true);
	}

	if (pActor->GetVelocity().Z <= 0.0f)
	{
		if (gravity_scale_down != pActor->GetCharacterMovement()->GravityScale)
			pActor->GetCharacterMovement()->GravityScale = gravity_scale_down;

		//FString str = FString::Printf(TEXT("TopZ %0.1f %0.1f"), pActor->GetActorLocation().Z, pActor->GetVelocity().Z);
		//UKismetSystemLibrary::PrintString(GEngine->GetWorld(), str);
	}

	return false; 
}
