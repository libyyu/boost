﻿#pragma once

#include "AzureNetDef.h"
#include "AzureBinaryWriter.h"
#include "AzureGPDataType.h"
#include "AzureCommand.h"
#include "AzureBehavior.h"

#define HPMOVE_LOG 0

namespace GNET
{
	class player_move : public Command
	{
	public:
		static constexpr int COMMAND_TYPE = (int)C2S::C2S_COMMAND::PLAYER_MOVE;
		FVector pos;                 //当前位置
		int timestamp;               //发包时间戳
		uint32 flags;                //标志
		FVector linear_velocity;     //移动速度
		uint16 use_time;             //使用的时间 单位是ms
		uint8 move_stamp;            //移动stamp
		uint32 extend_data;		     //扩展
		uint16 face_dir;			 //facedir:玩家朝向
		uint32 extend_data2;			 //跳跃第几段，用来播跳跃起始动作
/*		uint8 move_mode;			 //移动方式 0：四向移动 1：八向移动
		
		uint8 jump_type;	//跳跃类型：只在GP_MOVE_JUMP时有
		int8 land_type;		//落地类型：只在GP_MOVE_LANDING时有*/
		uint16 face_pitch_dir = 0;             //pitch 角度
		uint16 face_roll_dir = 0;             //roll 角度

		player_move()
			: Command(player_move::COMMAND_TYPE)
		{
		}

		virtual void marshal(AzureBinaryWriter& bw) const override
		{
			bw.Write(pos.X);
			bw.Write(pos.Y);
			bw.Write(pos.Z);
			bw.Write(timestamp);
			bw.Write(flags);
			bw.Write(linear_velocity.X);
			bw.Write(linear_velocity.Y);
			bw.Write(linear_velocity.Z);
			bw.Write(use_time);
			bw.Write(move_stamp);
			bw.Write(extend_data);
			bw.Write(face_dir);
			bw.Write(extend_data2);
			//if (flags & (int)GP_MOVE_FLAG::GP_MOVE_FACE_DIR_EX) //应服务器要求，发的时候不能加flag控制
			{
				bw.Write(face_pitch_dir);
				bw.Write(face_roll_dir);
			}
		}

		virtual void unmarshal(AzureBinaryReader& br) override
		{
			check(false);
		}
	};

	class player_skill_move : public Command                //PLAYER_SKILL_MOVE 玩家在技能中移动
	{
	public:
		static constexpr int COMMAND_TYPE = (int)C2S::C2S_COMMAND::PLAYER_SKILL_MOVE;

		FVector pos;                    //当前位置
		int timestamp;                  //发包时间戳
		uint16 flags;                   //标志
		uint16 move_dir;                //移动方向
		uint16 use_time;                //使用的时间 单位是ms
		uint16 speed;                   //速度
		uint8 move_stamp;

		uint16 face_dir;

		player_skill_move()
			: Command(player_skill_move::COMMAND_TYPE)
		{
		}

		virtual void marshal(AzureBinaryWriter& bw) const override
		{
			bw.Write(pos.X);
			bw.Write(pos.Y);
			bw.Write(pos.Z);
			bw.Write(timestamp);
			bw.Write(flags);
			bw.Write(move_dir);
			bw.Write(use_time);
			bw.Write(speed);
			bw.Write(move_stamp);

			/*if ((flags & (uint32)GP_MOVE_FLAG::GP_MOVE_DIR_DIFF) != 0)
			{
				bw.Write(face_dir);
			}*/
		}

		virtual void unmarshal(AzureBinaryReader& br) override
		{
			check(false);
		}
	};
};

class HPMoveBase : public AzureBehavior
{
protected:

	FVector _dir = FVector::ForwardVector;
	

	float _speed = 400.f;

	float _time_played = 0.f;
	float _turn_speed = 0.f;		//	TurnSpeed(Degree/second), 0 means turn immediately
	bool _finished = false;
	bool _is_skill_move = false;

	int _create_framecount = 0;

public:

	static constexpr float s_sync_speed_change = 100.0f;
	static constexpr float s_sync_yaw_change = 3.0f;
	static constexpr float s_sync_change_interval = 0.125f;

	static constexpr float s_trace_height_delta = 2.f * UE_METRE_TRANS;
	static constexpr float s_trace_distance = 10.f * UE_METRE_TRANS;

	static constexpr float s_max_height_changes = 10.5 * UE_METRE_TRANS;

	HPMoveBase();

	const FVector& GetMoveDir() const;

	virtual int GetMoveFlags();

	virtual bool Tick(float dt) override;

	virtual bool TickInternal(float dt);

	void ChangeSpeed(float speed);

protected:
	FVector GetNextMovePoint(const FVector& curpos, const FVector& move) const;
};