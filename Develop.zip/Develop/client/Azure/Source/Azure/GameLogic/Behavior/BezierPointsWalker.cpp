﻿#include "BezierPointsWalker.h"
#include "UE4Related.h"
#include "DrawDebugHelpers.h"

using namespace Azure;

///////////////////////////////////////////////////////////////////////////
//	
//	Class CBezierPointsWalker
//	
///////////////////////////////////////////////////////////////////////////

CBezierPointsWalker::CBezierPointsWalker()
{
	m_vCurPos = FVector::ZeroVector;
	m_vCurDir = FVector::ZeroVector;
}

CBezierPointsWalker::~CBezierPointsWalker()
{
}

bool CBezierPointsWalker::JudgeCurMoveEnd()
{
	if (m_iCurStartPoint == m_iMoveToIdx)
	{
		if (m_bReachPause)
		{
			m_bPaused = true;
		}
		else if (m_bAutoAdvancePoint)
		{
			RefreshCurDestAndDir();
		}
		else
		{
			m_bWalking = false;
		}
		return true;
	}
	else
		return false;
}

//	Start walk
bool CBezierPointsWalker::StartWalk(
	int iStartIdx/* = -1, -1 means not specify*/,
	int iMoveToIdx/* = -1, -1 means not specify*/,
	bool bReachPause/* = false, Pause when reach current DestPoint? */,
	bool bAutoAdvancePoint/* = true, Auto advance to next point? */
	)
{
	if (iStartIdx < 0)
		iStartIdx = 0;
	if (iStartIdx >= m_vPoints.Num())
		return false;

	m_iMoveToIdx = iMoveToIdx;
	if (m_iMoveToIdx < 0 || m_iMoveToIdx > m_vPoints.Num() - 1)
		m_iMoveToIdx = m_vPoints.Num() - 1;

	m_vCurPos = m_vPoints[iStartIdx];
	m_bMovedThisFrame = true;

	m_bReachPause = bReachPause;
	m_bAutoAdvancePoint = bAutoAdvancePoint;

	m_iCurStartPoint = iStartIdx;
	m_iCurDestPoint = iStartIdx;

	m_bPaused = false;
	m_bWalking = true;

	if (JudgeCurMoveEnd())
		return true;

	m_fForward = m_iCurStartPoint <= m_iMoveToIdx;
	RefreshCurDestAndDir();
	return true;
}

void CBezierPointsWalker::StopWalk()
{
	m_vPoints.Empty(m_vPoints.Max());
	m_vCurPos = FVector::ZeroVector;
	m_vCurDir = FVector::ZeroVector;
	m_iCurStartPoint = -1;
	m_iCurDestPoint = -1;
	m_fSpeed = 1.0f;
	m_iMoveToIdx = -1;
	m_fForward = true;
	m_bWalking = false;
	m_bPaused = false;
	m_bReachPause = false;
	m_bMovedThisFrame = false;
}

bool CBezierPointsWalker::AdvanceCurDestIdx()
{
	if (m_fForward)
		++m_iCurDestPoint;
	else
		--m_iCurDestPoint;

	if (m_iCurDestPoint < 0 || m_iCurDestPoint >= m_vPoints.Num())
	{
		if (m_bReachPause)
			m_bPaused = true;
		else
			m_bWalking = false;
		return false;
	}
	else
		return true;
}

void CBezierPointsWalker::RefreshCurDestAndDir()
{
	if (!AdvanceCurDestIdx())
		return;

	m_vCurDir = m_vPoints[m_iCurDestPoint] - m_vCurPos;
	VEC_UP(m_vCurDir) = 0;
	m_vCurDir.Normalize();
}

bool CBezierPointsWalker::ChangeStartIndex(int iStartIdx)
{
	if (!m_bWalking)
	{
		//	can Only changed when Walking!
		return false;
	}

	if (iStartIdx < 0)
		iStartIdx = 0;
	if (iStartIdx + 1 >= m_vPoints.Num())
		return false;

	m_vCurPos = m_vPoints[iStartIdx];
	m_bMovedThisFrame = true;

	m_iCurStartPoint = iStartIdx;
	m_iCurDestPoint = iStartIdx;

	if (JudgeCurMoveEnd())
		return true;

	m_bPaused = false;
	m_fForward = m_iCurStartPoint < m_iMoveToIdx;
	RefreshCurDestAndDir();
	return true;
}

bool CBezierPointsWalker::ChangeMoveToIndex(int iMoveToIdx, bool bReachPause)
{
	if (!m_bWalking)
	{
		//	can Only changed when Walking!
		return false;
	}

	m_iMoveToIdx = iMoveToIdx;
	if (m_iMoveToIdx < 0 || m_iMoveToIdx > m_vPoints.Num() - 1)
		m_iMoveToIdx = m_vPoints.Num() - 1;

	m_bReachPause = bReachPause;

	if (JudgeCurMoveEnd())
		return true;

	m_bPaused = false;
	m_fForward = m_iCurStartPoint < m_iMoveToIdx;

	m_iCurDestPoint = m_iCurStartPoint;
	RefreshCurDestAndDir();
	return true;
}

//	Get Nearest Pos, return point Index
int CBezierPointsWalker::GetNearestPos(const FVector& vFrom, float& fNearistDist, bool b3D) const
{
	if (m_vPoints.Num() <= 0)
		return -1;

	int iNearest = -1;
	float fNearDist = 100000000.f;
	for (int i = 0; i < m_vPoints.Num(); ++i)
	{
		FVector vDelta = m_vPoints[i] - vFrom;
		float fDistH = b3D ? vDelta.SizeSquared() : vDelta.SizeSquared2D();
		if (fDistH < fNearDist)
		{
			iNearest = i;
			fNearDist = fDistH;
		}
	}

	if (iNearest >= 0)
		fNearistDist = FMath::Sqrt(fNearDist);

	return iNearest;
}

//	Get Total Dist
float CBezierPointsWalker::GetTotalDist(bool b3DDist, int idxFrom, int idxEnd /* = -1 */)
{
	if (idxFrom < 0)
		return 0.f;

	if (idxEnd < 0)
		idxEnd = m_vPoints.Num();

	float fTotalDist = 0.f;
	if (b3DDist)
	{
		for (int i = idxFrom; i + 1 < m_vPoints.Num() && i + 1 < idxEnd; ++i)
		{
			FVector vDelta = m_vPoints[i + 1] - m_vPoints[i];
			fTotalDist += vDelta.Size();
		}
	}
	else
	{
		for (int i = idxFrom; i + 1 < m_vPoints.Num() && i + 1 < idxEnd; ++i)
		{
			FVector vDelta = m_vPoints[i + 1] - m_vPoints[i];
			fTotalDist += vDelta.Size();
		}
	}

	return fTotalDist;
}

//	Tick routine
bool CBezierPointsWalker::Tick(float fDeltaTime)
{
	if (!m_bWalking || m_bPaused)
		return m_bWalking;

	if (m_iCurDestPoint < 0 || m_iCurDestPoint >= m_vPoints.Num())
	{
		m_bWalking = false;
		return m_bWalking;
	}

	float fThisMoveDist = m_fSpeed * fDeltaTime;
	float fMoveDistLeft = fThisMoveDist;

	while (m_iCurDestPoint < m_vPoints.Num())
	{
		FVector vCurPathDest = m_vPoints[m_iCurDestPoint];

		m_vCurDir = vCurPathDest - m_vCurPos;
		float fTotalDeltaHei = VEC_UP(m_vCurDir);
		VEC_UP(m_vCurDir) = 0;
		float fCurPathDistH = 0;
		m_vCurDir.ToDirectionAndLength(m_vCurDir, fCurPathDistH);

		if (fMoveDistLeft < fCurPathDistH)
		{
			//	这次尚不足以走到nextpoint
			m_vCurPos += m_vCurDir * fThisMoveDist;
			VEC_UP(m_vCurPos) += fTotalDeltaHei * fMoveDistLeft / fCurPathDistH;
			m_bMovedThisFrame = true;
			break;
		}
		else
		{
			//	这次走过了nextpoint
			fMoveDistLeft -= fCurPathDistH;

			m_iCurStartPoint = m_iCurDestPoint;

			if (JudgeCurMoveEnd())
			{
				//	走到了终点
				m_vCurPos = vCurPathDest;
				m_bMovedThisFrame = true;
				break;
			}

			//	Advance m_iCurDestPoint
			if (!AdvanceCurDestIdx())
				break;
		}
	}

#if UE_BUILD_DEBUG
	if (!AAzureEntryPoint::Instance)
		return false;

	UWorld* pWorld = AAzureEntryPoint::Instance->GetWorld();
	if (pWorld)
	{
		for (int i = 0; i < m_vPoints.Num() - 1; ++i)
		{
			FVector& vCur = m_vPoints[i];
			FVector& vNext = m_vPoints[i + 1];
			DrawDebugLine(pWorld, vCur, vNext, FColor::Green);
		}

		DrawDebugSphere(pWorld, m_vCurPos, 0.3f*UE_METRE_TRANS, 10, FColor::Red);
	}
#endif

	return m_bWalking;
}