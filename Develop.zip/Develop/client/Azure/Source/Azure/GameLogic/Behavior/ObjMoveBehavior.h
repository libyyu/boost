#pragma once

#include "AzureBehavior.h"
//�ͻ������ƶ���Ŀǰ��cg��

class ObjMoveBehavior : public AzureBehavior
{
protected:
	static constexpr  Azure::BehaviorType _type = Azure::BehaviorType::ObjMove;
	FVector _dest;
public:

	ObjMoveBehavior()
	{
		
	}

	static ObjMoveBehavior* Create();

	Azure::BehaviorType get_Type() const override
	{
		return _type;
	}

	bool SetData(const FVector& vDest, OnBehaviorFinish onFinish);
	virtual void OnRemoved(bool replace) override;
	bool GetMoveVelocity(float dt, FVector &outVelocity);
protected:

	virtual bool Tick(float dt) override;
};