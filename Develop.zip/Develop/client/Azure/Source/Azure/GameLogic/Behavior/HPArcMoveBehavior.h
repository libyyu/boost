#pragma once

#include "HPMoveBase.h"

class HPArcMoveBehavior : public HPMoveBase
{
protected:
	static constexpr  Azure::BehaviorType _type = Azure::BehaviorType::HPArcMove;



public:


	Azure::BehaviorType get_Type() const override
	{
		return _type;
	}

	bool SetData(FVector vDest,FVector vO, float s, OnBehaviorFinish onFinish);
	virtual void OnRemoved(bool replace) override;
	
	static HPArcMoveBehavior* Create()
	{
		HPArcMoveBehavior* ret = (HPArcMoveBehavior*)AzureBehaviorCache::GetInstance().GetBehavior(_type);

		if (ret == nullptr)
			ret = new HPArcMoveBehavior();

		return ret;
	}
protected:

	FVector m_vStart;
	FVector m_vDest;
    FVector m_vO;                       // ת���Բ��
    float m_fAngularVelocity = 0;           // ���ٶ�
    float m_fSpeed = 0;
    float m_ftime = 0;
	float m_accumulativeTime = 0;
	float m_overTime = 0;
    bool m_bSync;
    int _createframecount = 0;
	float m_totalMoveAngle = 0;

	virtual bool TickInternal(float dt) override;

};