﻿#pragma once

#include "UE4Related.h"

namespace Azure
{
	// 0 cancel
	// 1 success
	// 2 clear
	enum class BehaviorFinishState
	{
		Cancel = 0,
		Success = 1,
		Clear = 2,
	};

	enum class BehaviorType
	{
		Invalid = -1,
		Move = 0,				    // 移动
		Turn = 1,					// 转向
		DecelMove = 2,				// 匀减速
		Charge = 3,					// 技能冲锋
		BezierMove = 4,				// BezierMove
		HPMove = 5,					// HostPlayer点地移动
		HPJoystickMove = 6,			// HostPlayer摇杆移动
		HPAutoMove = 7,				// HostPlayer自动移动
		HPBezierMove = 8,			// HostPlayer BezierMove 强制移动 载具参数移动
		HPTurnSyncServer = 9,		// HostPlayer转向并向服务器同步方向
		HPLockTarget = 10,			// HostPlayer锁定目标
		PitchTurn = 11,				// 转pitch
		HPJump = 12,					// HostPlayer跳
		ObjServerMove = 13,			// ElsePlayer等收到服务器协议移动
		HPVehicleJoystickMove = 14,	// 骑乘状态摇杆移动
		HurtFly = 15,				// 击飞
		ObjMove = 16,				// CG中单位根据characterMovement移动,用于CG
		HPRushDown = 17,				// 空中下冲技能
		ObjServerSkillMove = 18,		// ElsePlayer等收到服务器技能移动
		RootMotionMove = 19,			// AzureMoveBehavior的rootmotion版，不想用线性改变距离，根据rootmotion数据改变距离，并可以灵活控制移动朝向
		ObjServerRootMotionMove = 20,// ObjServerMove的rootmotion版，通过服务器实时同步的RootMotion参数预测和修正移动
		HPBePush = 21,				// 主角被推
		Glide = 22,                 // 滑翔
		HPArcMove = 23,             // 主角圆弧运动
		NumType,
	};

	enum class GlideCtrlMode //滑翔控制方式
	{
		Default = 0, 
		UseCameraDir = 1, //使用镜头的方向
		FixLandPos = 2, //固定着陆点
		TeamFollow = 3, //组队跟随状态
		FreeFalling = 4, //自由落体
	};

	static bool glb_IsBehaviorTypeOfHPMove(BehaviorType type)
	{
		return type >= BehaviorType::HPMove
			&& type <= BehaviorType::HPBezierMove;
	};

	extern float s_VERT_SLOPE_THRESH;						//	Vertical Slope Normal.Up Thresh: sin(90 - 0.01)度
	extern float s_SLOPE_UP_THRESH;							//	Slope Normal.Up Thresh: sin(90 - 65)度
	extern float s_SLOPE_TAN_THRESH;						//	Slope Tangent Thresh: tan(65)度
	extern float s_fMoveFloorDist;							//	Move Floor Dist

	extern float s_fPlayerMoveExt;
	extern float s_fPlayerMoveHalfHei;
	extern float s_fPlayerMoveRaiseHei_Ground;				//	某些地方拔高一定高度往前trace才能走上去，比如大台阶。。
	extern float s_fPlayerMoveRaiseHei_Air;
	extern float s_jump_up_gravityScale[3];
	extern float s_jump_down_gravityScale;

	extern float s_dash_time;
	extern float s_dash_time_move_input;
	extern float s_dash_angle;
	extern float s_dash_angle_dodge;
	
	extern float s_dash_stop_force_time;
	extern float s_dash_stop_turn180_force_time;
	extern float s_dash_braking_friction_factor;			// 疾跑刹车因数
	extern float s_inputAxisMaxValue;
	extern float s_moveRightTurnControllYawScale;
	extern float s_waitNextSyncScale;						//同步elsePlayer时，等待下一个同步包最大的预测时间系数
	extern float s_mesh_rel_rot;
	extern float aim_walk_backward_angle_limit;
	extern float start_walk_duration;
	extern float move_rot_speed;
	extern float start_walk_inpterrupt_time;
	extern float turn_at_rate_angle;
	extern float turn_speed_minus_angle;
	extern float turn_speed_minus_scale;

	extern float s_run_stop_force_time;
	extern float s_run_stop_turn180_force_time;
	extern float s_run_stop_speed_limit;
	extern float run_turn180_speed_limit;
	extern float run_stop_limit_time;

	extern float s_turn180_angle_limit;
	extern float capsule_to_floor_dis;
	extern float joystick_scale;

	extern float default_walk_speed;
	extern float default_walk_time_limit;
	extern float default_walk_input_limit;

	extern float config_runSpeed;
	extern float config_dashSpeed;

	extern bool bElsePlayerMoveSweep;
	extern bool bPlayerServerMovePredict;
	extern float server_move_wait_sync_time;
	extern float host_send_sync_info_interval;
	extern float player_receive_sync_info_interval;
	extern float vehicle_receive_sync_info_interval;
	extern float npc_server_move_delay_rate;
	extern float npc_min_sync_time;
	extern float host_jump_sync_interval;
	extern float run_walk_gear_scale;
	extern float host_turn_angle_limit;
	extern float host_turn_force_sync_time;

	extern float npc_lookat_angle_stop;
	extern float npc_lookat_return_origin_time;
	extern float npc_lookat_near_dis;
	extern float npc_lookat_near_angle;

	extern float npc_lookat_dis_delta;
	extern float npc_lookat_angle_delta;

	extern float host_lookat_npc_dis_limit;
	extern float host_lookat_npc_angle_limit;

	extern float trace_water_up_dis;
	extern float trace_water_dis;
	extern float trace_water_max_dis;

	extern float trace_sea_dis;

	extern bool s_moveRightNotTurn;
	extern float npc_sync_rotate_smooth;

	extern bool b_player_move_show;
	extern bool print_camera_debug;

	extern float ai_move_interval;
	extern float aim_pitch_anim_angle;
	extern float aim_factor_blend_time;

	extern float facetarget_delay;
	extern FString ArmAlphaStr;
	extern float bodyTurnMinAngle;
	extern float bodyTurnLimitAngle;
	
	extern float leanAdjustAngle;
	extern float leanSpeedGait_1;
	extern float leanAnimAngle;

	extern float blockforward_angle;
	extern float blockbackward_angle;

	extern FString tag_update_aim;

	extern float JoystickPressSendInterval;

	extern float start_move_key_time;
	extern bool cam_locktarget_follow_target_only;

	extern FString CamProtectBoneName1;
	extern FString CamProtectBoneName2;
	extern float CamProtect_AngleIn;
	extern float CamProtect_AngleOut;
	

	extern FString CamProtectMatParamName1;
	extern FString CamProtectMatParamName2;
	extern FString CamProtectMatParamName3;
	extern float CamProtect_Param1_Min;
	extern float CamProtect_Param1_Max;

	extern float CamProtect_Param2_Min;
	extern float CamProtect_Param2_Max;

	extern float CamProtect_Param3_Min;
	extern float CamProtect_Param3_Max;

	extern bool bTickCamAngleForTransparentMaterial;

	extern bool TurnLog;
	extern float SwimWaterSurfaceAngle;
	extern float SwimInWaterSocketZOffset;
};
