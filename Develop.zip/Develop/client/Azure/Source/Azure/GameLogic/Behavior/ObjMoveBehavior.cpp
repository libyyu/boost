﻿#include "ObjMoveBehavior.h"
#include "AzureObjectComponent.h"
#include "AzureUtility.h"
#include "AzureExport.h"
#include "GameLogic/Player/GamePlayer.h"

ObjMoveBehavior* ObjMoveBehavior::Create()
{
	ObjMoveBehavior* ret = (ObjMoveBehavior*)AzureBehaviorCache::GetInstance().GetBehavior(_type);

	if (ret == nullptr)
		ret = new ObjMoveBehavior();

	return ret;
}

bool ObjMoveBehavior::SetData(const FVector & vDest, OnBehaviorFinish onFinish)
{	
	_dest = vDest;
	set_OnFinish(onFinish);

	if (!_objcomp.IsValid())
		return false;

	AGamePlayer * pActor = Cast<AGamePlayer>(_objcomp->GetOwner());
	if (!pActor)
		return false;

	return true;
}

void ObjMoveBehavior::OnRemoved(bool replace)
{

}

bool ObjMoveBehavior::GetMoveVelocity(float dt,  FVector & outVelocity)
{
	if (!_objcomp.IsValid())
		return false;

	AGamePlayer * pActor = Cast<AGamePlayer>(_objcomp->GetOwner());
	if (!pActor) 
		return false;
	
	float max_speed = pActor->GetCharacterMovement()->MaxWalkSpeed;
	float moveDis = max_speed * dt;
	FVector cur_location = pActor->GetActorLocation();
	FVector dir = _dest - cur_location;
	dir.Z = 0;
	
	float dis = dir.Size();
	outVelocity = dir.GetSafeNormal() * max_speed;
	if (moveDis >= dis)
	{
		outVelocity *= dis / moveDis;
		return false;
	}

	return true;
}

bool ObjMoveBehavior::Tick(float dt)
{
	if (!_objcomp.IsValid())
		return true;

	AGamePlayer * pActor = Cast<AGamePlayer>(_objcomp->GetOwner());
	if (!pActor)
		return true;
	
	FVector velocity;
	bool bcontinue = GetMoveVelocity(dt, velocity);

	if (!bcontinue)
	{
		return true;
	}

	pActor->GetCharacterMovement()->bRequestedMoveUseAcceleration = false;
	pActor->GetCharacterMovement()->RequestDirectMove(velocity, false);
	
	return false;
}


