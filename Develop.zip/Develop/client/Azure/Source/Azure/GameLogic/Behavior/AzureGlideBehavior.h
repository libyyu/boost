#pragma once

#include "AzureBehavior.h"
#include "BezierPointsWalker.h"
#include "Array.h"
#include "GameFramework/Actor.h"
#include "../AzureCommonDef.h"

//////////////////////////////////////////////////////////////////////////
struct GlideParam
{
	float fForwardSpeed; //前进方向速度
	float fFallingSpeed; //下坠速度
	float fTurnSpeedInRadian; //转向速度
	float fLandDuration;  //减速落地时长
	float fLandMinSpeed;  //落地的最小速度
	float fFreeFallingSpeed; //自由下落速度
	FVector vLandPos; //落地位置
	Azure::GlideCtrlMode eCtrlMode; //控制模式
};

class AzureGlideBehavior : public AzureBehavior
{

protected:
	static constexpr  Azure::BehaviorType _type = Azure::BehaviorType::Glide;

public:
	AzureGlideBehavior()
	:m_bInit(false)
	{
		
	}

	static AzureGlideBehavior* Create()
	{
		AzureGlideBehavior* ret = static_cast<AzureGlideBehavior*>(AzureBehaviorCache::GetInstance().GetBehavior(_type));
		if (ret == nullptr)
			ret = new AzureGlideBehavior();
		return ret;
	}

	Azure::BehaviorType get_Type() const override
	{
		return _type;
	}

	bool SetData(const GlideParam& glideParam);

	bool Tick(float dt) override;

	void OnRemoved(bool replace) override;

protected:
	float GetNextMoveForwardSpeed() const;
	float GetNextFallingSpeed() const;
	float GetCollisionCheckDistance() const;
	void GetNextMoveDir(FVector& vNextMoveDir) const;
	void InterpretMoveDir(const FVector& vCurMoveDir, const FVector& vNextMoveDir, FVector& vOutMoveDir) const;
	void CalcDirFromTargetPos(FVector& vNextMoveDir) const;
	bool CanMoveTo(FVector vStartPos, FVector vEndPos) const;
	void SetAnimationParam(const FVector& vMoveDir, const FVector& vNextDir, float fFowardSpeed);
	AActor* GetMovableActor() const;
	FVector m_vCurMoveDir;
	FVector m_vLandPos;
	float m_fForwardSpeed;
	float m_fFallingSpeed;
	float m_fFreeFallingSpeed;
	float m_fLandMinSpeed;
	float m_fTurnSpeedInRadian;
	Azure::GlideCtrlMode m_eCtrlMode;
	bool  m_bInit;

	//着陆属性
	//来源于配置
	float m_fLandDuration; //整个着陆时长
	float m_fLandHeight; //着陆的高度

	//动态数据
	bool m_bLanding; //进入着陆过程
	bool m_bStartLand; //开始减速
	float m_fLandPassTime; //着陆过去的时长
	float m_fLandInitSpeedZ; //着陆纵向速度
	float m_fTestHeight; 
	float m_fMovePitch; //俯仰角度

	void OnEnterLanding(float currSpeedZ);
	//落地时速度
	bool GetLandSpeedZ(float& outLandSpeedZ, float& outSpeedScale, float dt) const;
	//记录落地过去的时间, 返回是否继续
	bool RecordLandPassTime(float dt);
	//返回落地时长
	void HandleLandingInLua() const;
	void HandleRemoveInLua() const;
	//重置落地数据
	void ResetLandData();
	//检查是否进入落地阶段,返回是否进入成功
	bool HandleLandingWhenCollision(float currSpeedZ);
};