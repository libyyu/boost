#include "HPJoystickMoveBehavior.h"
#include "AzureObjectComponent.h"
#include "AzureUtility.h"
#include "GameLogic/Input/AzureInputCtrl.h"
#include "GameLogic/Player/GamePlayer.h"
#include "AzureTimeManager.h"
#include "GameLogic/Player/GamePlayer_Util.h"
#include "GameLogic/Player/MyMovementComponent.h"
#include "Kismet/KismetMathLibrary.h"
#include "GameLogic/Player/GamePlayerManager.h"

HPJoystickMoveBehavior* HPJoystickMoveBehavior::Create()
{
	HPJoystickMoveBehavior* ret = (HPJoystickMoveBehavior*)AzureBehaviorCache::GetInstance().GetBehavior(_type);

	if (ret == nullptr)
		ret = new HPJoystickMoveBehavior();

	ret->_create_framecount = GFrameNumber;

	return ret;
}

bool HPJoystickMoveBehavior::SetData(float fMoveSpeed, float fTurnSpeed, OnBehaviorFinish onFinish, bool isSkillMove)
{
	set_OnFinish(onFinish);
	
	if (!_objcomp.IsValid())
		return false;

	is_skill_move = isSkillMove;
	enterDashTime = 0.0f;
	enterDashTime_move_input = 0.0f;

	//MyPrintString("JoyStick Enter");
	//FString str = FString::Printf(TEXT("enterDashTime %0.3f"), enterDashTime);
	//MyPrintString(str);	

	is_last_frame_input = false;

	AGamePlayer* pActor = Cast<AGamePlayer>(_objcomp->GetOwner());
	if (!pActor)
		return false;

	pActor->SyncPushMoveToServer("JoyMove Start", ESyncMoveSendType::StartMove, true, is_skill_move);

	if (pActor->GetVelocity().Size() < 0.01f)
		pActor->startWalkTime = Azure::start_walk_duration;

	if (!AAzureEntryPoint::Instance)
		return false;

	start_time = AAzureEntryPoint::Instance->GetRealtimeSinceStartup();

	
	if (IsDefaultWalkMode())
	{
		ReturnToDefaultWalk();
		default_walk_input_time = 0.0f;
		default_walk_stage = 1;
	}
	else
	{
		default_walk_input_time = 0.0f;
		default_walk_stage = 0;
	}

	return true;
}


void HPJoystickMoveBehavior::OnRemoved(bool replace)
{
	if (!_objcomp.IsValid())
		return;

	AGamePlayer* pActor = Cast<AGamePlayer>(_objcomp->GetOwner());
	if (pActor)
	{
		pActor->SyncPushMoveToServer("joyMove Stop", ESyncMoveSendType::Stop, true, is_skill_move);//�����ƶ�У���Ҫ����������ˣ���λ��У����ϸ��ˣ�����Ҫ�������������֮ǰ��
		
		RemoveDashState();
		
		pActor->startWalkTime = 0.0f;
		pActor->ClearTargetDirRotating();
	}
}

bool HPJoystickMoveBehavior::TickInternal(float dt)
{
	if (!HPMoveBase::TickInternal(dt))
		return false;

	if (!_objcomp.IsValid())
		return true;

	AGamePlayer* pActor = Cast<AGamePlayer>(_objcomp->GetOwner());
	if (!pActor)
		return true;

	if (!AAzureEntryPoint::Instance)
		return true;
	
	UpdateDashStopType();
	UpdateRunStopType();
	
	pActor->TickRotation(dt);

	FVector2D v = AzureInputCtrl::GetInstance().GetJoyStickValue();
	v *= Azure::joystick_scale;	

	FVector dir1 = FVector::ZeroVector;
	FVector dir2 = FVector::ZeroVector;

	double st = AAzureEntryPoint::Instance->GetRealtimeSinceStartup();
	float speed = pActor->GetVelocity().Size2D();
	float max_speed = pActor->GetCharacterMovement()->MaxWalkSpeed;
	
	const FRotator Rotation = GetActorControlRotation();
	const FRotator YawRotation(0, Rotation.Yaw, 0);

	bool isInput = false;
	if (v.Y != 0.0f)//Move Forward
	{
		dir1 = FRotationMatrix(YawRotation).GetUnitAxis(EAxis::X);
		isInput = true;	
	}

	if (v.X != 0.0f)//Move Right
	{		
		dir2 = FRotationMatrix(YawRotation).GetUnitAxis(EAxis::Y);
		isInput = true;
	}	

	FVector inputdir = dir1 * v.Y + dir2 * v.X;	

	if (false)
	{
		FVector dir1_t = FRotationMatrix(YawRotation).GetUnitAxis(EAxis::X);
		FVector v1 = pActor->GetActorLocation();
		FVector v2 = v1 + dir1_t * 300.0f;
		UKismetSystemLibrary::DrawDebugLine(pActor->GetWorld(), v1, v2, FLinearColor::Yellow);

		FVector dir2_t = FRotationMatrix(YawRotation).GetUnitAxis(EAxis::Y);
		v2 = v1 + dir2_t * 300.0f;
		UKismetSystemLibrary::DrawDebugLine(pActor->GetWorld(), v1, v2, FLinearColor::Green);

		v2 = v1 + inputdir * 400.0f;
		UKismetSystemLibrary::DrawDebugLine(pActor->GetWorld(), v1, v2, FLinearColor::Red);
	}
	

	if (isInput)
	{				
		if (pActor->m_bIsDashMove)
		{
			if (pActor->m_bIsDashReleaseInput && pActor->m_iPlayDashStop == 0)
			{				
				bool is180Turn = false;
				if(pActor->CanPlayDashStopByLua())
					is180Turn = PlayDashStop(inputdir);

				bool isNeedContinueDashAfter180Turn = false;
				if (isNeedContinueDashAfter180Turn)
				{
					//180ת���������				
					if (!is180Turn)
						RemoveDashState();
					else
						pActor->m_bIsDashReleaseInput = false;
				}
				else
				{
					RemoveDashState();
				}				

				isInput = false;
			}
			else
			{
				//pActor->targetDesiredDir = inputdir.GetSafeNormal();
			}
		}
		else
		{
			if (NeedForbidInputByDashStop())//�ڲ�ɲ����ǰһС��ʱ�䲻�������
			{
				isInput = false;
				pActor->targetDesiredDir = FVector::ZeroVector;
			}
			else if (NeedForbidInputByRunStop())//�ڲ�ɲ����ǰһС��ʱ�䲻�������
			{
				isInput = false;
				pActor->targetDesiredDir = FVector::ZeroVector;
			}
			else if (pActor->m_iPlayDashStop > 0)//�ڲ�ɲ������һ�ο��Ա���ϱ��ƶ�
			{				
				pActor->SetPlayDashAnim(0);

				pActor->targetDesiredDir = FVector::ZeroVector;

				//���ﲻ�õ����ˣ���ΪjoyMove Start�Ѿ��շ��ˣ�������joyMove StartҲ��һ֡
				//pActor->SyncPushMoveToServer("InterruptDashStop", ESyncMoveSendType::PlayDashStop, true, false);
			}
			else if (pActor->m_iPlayNormalStop > 0)
			{	
				if (pActor->m_iPlayNormalStop > 1)//
				{
					FVector v = pActor->GetActorForwardVector() * pActor->m_run_speed;
					pActor->GetMyMovementComponent()->SetVelocity(v);
				}				

				if (gGamePlayerManager.debug_printstring && false)
				{
					float trackpos = 0.f;
					if (pActor->IsPlayingRootMotion())
					{
						FAnimMontageInstance * pMontageInst = pActor->GetRootMotionAnimMontageInstance();
						trackpos = pMontageInst->GetPosition();
					}					

					double cur_time = st;
					FString str = FString::Printf(TEXT("interrupt normal stop %0.3f trackpos: %0.3f"), cur_time,trackpos);
					MyPrintString(str);
				}		
				
				pActor->SetPlayNormalStopAnim(0);
				pActor->SyncPushMoveToServer("InterruptDashStop", ESyncMoveSendType::InterruptNormalStop, true, false);		

				pActor->targetDesiredDir = inputdir.GetSafeNormal();
				start_time = st;
			}
			else
			{
				if (!pActor->IsEightDirMode() )
				{
					int turnValue = CheckPlayNormalTurn180(inputdir);
					//turnValue = 0;//��ʱ��ת��
					if (turnValue > 0)//��ɲ��ת��
					{
						PlayNormalStop(turnValue);
						pActor->targetDesiredDir = FVector::ZeroVector;
					}
					else
					{
						FRotator delta = UKismetMathLibrary::NormalizedDeltaRotator(pActor->GetActorRotation(), inputdir.Rotation());

						if (false)
						{
							FString str = FString::Printf(TEXT("turn at rate %0.2f %0.2f %0.2f %0.2f"), delta.Yaw, pActor->waitTurnBodyTime, pActor->GetActorRotation().Yaw, inputdir.Rotation().Yaw);
							MyPrintString(str);
						}

						if (!Azure::s_moveRightNotTurn)//�������ƽ�ƣ���Ҫ�ƻ�
						{
							if (pActor->waitTurnBodyTime <= 0.0f && FMath::Abs(delta.Yaw) < 45.0f)
							{
								pActor->TurnAtRate(v.X * Azure::s_moveRightTurnControllYawScale);//�����ƶ���ʱ���ƻ��ƶ����ο��Ķ���������Ϸ����2BС���
							}
						}
						

						DealDefaultWalkTime(dt, inputdir, speed);

						pActor->targetDesiredDir = inputdir.GetSafeNormal();
					}					
				}
			}
		}
	}
	else
	{
		if (pActor->m_bIsDashMove)
		{
			v.Y = Azure::s_inputAxisMaxValue;

			if (pActor->m_bIsDashUseControlDir)
			{
				const FRotator Rotation = GetActorControlRotation();
				const FRotator YawRotation(0, Rotation.Yaw, 0);

				const FVector Direction = FRotationMatrix(YawRotation).GetUnitAxis(EAxis::X);
				dir1 = Direction;
			}
			else
			{
				dir1 = pActor->GetActorForwardVector();
			}			

			pActor->m_bIsDashReleaseInput = true;		

			bool isNeedStopDashAfterReleaseInput = false;
			if (pActor->m_bIsDashReady)//ͨ�����ܽ��뼲�ܵ������
				isNeedStopDashAfterReleaseInput = true;

			if (isNeedStopDashAfterReleaseInput)
			{
				StopDash();
				isInput = false;
			}
			else
			{
				isInput = true;
			}
			//pActor->targetDesiredDir = dir1.GetSafeNormal();
		}
		else
		{
			if (!pActor->IsEightDirMode() )
			{
				if (is_last_frame_input)
				{
					if (CanPlayNormalStop(1))
					{
						double cur_time = st;
						if (cur_time - start_time > Azure::run_stop_limit_time)
						{
							if (false)
							{
								FString str = FString::Printf(TEXT("IsStartTimeLimit %0.2f %0.2f"), cur_time - start_time, Azure::run_stop_limit_time);
								MyPrintString(str);
							}

							if (speed >= Azure::s_run_stop_speed_limit)
							{
								pActor->targetDesiredDir = FVector::ZeroVector;
								PlayNormalStop(1);
							}
						}
						else
						{
							if (false)
							{
								FString str = FString::Printf(TEXT("IsStartTimeLimit %0.2f %0.2f"), cur_time - start_time, Azure::run_stop_limit_time);
								MyPrintString(str);
							}
						}
					}								
				}
			}
		}

		DealDefaultWalkTime(dt, FVector::ZeroVector, speed);
	}	

	if (isInput)//ִ����Ϸ�Լ�����ײ�赲�߼�
	{
		FVector inputdir2 = dir1 * v.Y + dir2 * v.X;//���ܻ�ģ�����룬Ҫ��ȡһ��
		float inputValue = inputdir2.Size();
		//float scale = 1.0f;//CalSpeedScaleByTurn(inputdir2);
		inputValue = LimitSpeedByGear(inputValue);

		if (false)
		{
			FString str = FString::Printf(TEXT("Gear old %0.3F new %0.3f speed %0.1f"), inputdir2.Size(),inputValue,speed);
			MyPrintString(str);
		}
		
		pActor->AddMovementInput(inputdir2.GetSafeNormal(), inputValue);


		if (!pActor->m_bIsDashMove)
			DealEnterDashTime(inputdir2, dt);		
	}
	else
	{
		ClearDashTime();		
	}
	
	bool isPlayStop = (pActor->m_iPlayDashStop > 0 || pActor->m_iPlayNormalStop > 0);
	bool isPlayDashStop = pActor->m_iPlayDashStop > 0;

	float fromStartTime = st - start_time;
	
	if (!isInput && speed < 0.01f && !isPlayStop && !pActor->IsTargetDirRotating())
	{
		//pActor->SyncPushMoveToServer("joyMove Stop", ESyncMoveSendType::Stop, true, is_skill_move); �����ƶ�У����˳�joystickMove����뷢�ˣ�Ҫ�������Բ��ϣ��ŵ�onRemoved�﷢
		return true;
	}	
	else if (is_last_frame_input && !isInput && !pActor->m_bIsDashMove && !isPlayStop)//�������ɿ����룬��ʼ���ٵ�ʱ��Ҳ��һ��
	{
		pActor->SyncPushMoveToServer("JoyMove LeaveMaxSpeed", ESyncMoveSendType::LeaveMaxSpeed, true, is_skill_move);
	}		
	else if (pActor->m_bBattleState && fromStartTime >= Azure::start_move_key_time && fromStartTime - dt < Azure::start_move_key_time)
	{
		pActor->SyncPushMoveToServer("JoyMove startwalkanim", ESyncMoveSendType::StartAnimTime, true, is_skill_move);
	}
	else if (pActor->m_fSyncPushMoveTimer >= Azure::host_send_sync_info_interval)// 
	{
		if (Azure::bPlayerServerMovePredict)//!isPlayStop 
		{
			if (isPlayStop)
			{
				pActor->SyncPushMoveToServer("JoyMove Tick1", ESyncMoveSendType::PlayingStop, true, is_skill_move);
			}	
			else
			{
				bool isKeyForTurnBigAngle = CheckNotKeySyncNeedChangeToKey(pActor);
				if(isKeyForTurnBigAngle)
					pActor->SyncPushMoveToServer("JoyMove Tick2", ESyncMoveSendType::None, true, is_skill_move);
				else
					pActor->SyncPushMoveToServer("JoyMove Tick3", ESyncMoveSendType::None, false, is_skill_move);
			}				
		}
		else
		{
			if(!isPlayStop)//��ɲ��������ʱ����ͬ�������ҽ�ʱ�����㣬�Ա��ڲ����ʱ��Ҫ����ͬ������������һ��ͬ��֡
				pActor->SyncPushMoveToServer("JoyMove Tick", ESyncMoveSendType::None, false, is_skill_move);
			else
				pActor->m_fSyncPushMoveTimer = 0.0f;			
		}
			

		if (false)
		{
			FString str = FString::Printf(TEXT("---JoyMove Tick %d %0.1F %d"),isInput,speed, pActor->GetCurrentMontage() == nullptr);
			MyPrintString(str);
			
			if (pActor->GetCurrentMontage() != nullptr)
			{
				FString name = pActor->GetCurrentMontage()->GetName();
				int a = 1;
			}
		}
	}

	if(pActor->move_sync_debug && false)
		pActor->send_path.Add(pActor->GetFeetLocation());

	is_last_frame_input = isInput;

	if (pActor->startWalkTime > 0.0f)
		pActor->startWalkTime -= dt;

	if (false)
	{
		FString str = FString::Printf(TEXT("JoyStickMoveSpeed %0.1f  %0.1f"), speed,max_speed);
		MyPrintString(str);
	}

	return false;
}

bool HPJoystickMoveBehavior::CheckNotKeySyncNeedChangeToKey(AGamePlayer * pActor)
{
	float turnAngleLimit = Azure::host_turn_angle_limit;
	float turnForceSyncTime = Azure::host_turn_force_sync_time;

	double st = AAzureEntryPoint::Instance->GetRealtimeSinceStartup();
	if (st - pActor->last_sync_time_key >= turnForceSyncTime)
	{
		FVector curFaceDir = pActor->GetActorForwardVector();
		float angle = AzureUtility::Angle(curFaceDir, pActor->last_sync_dir_key);
		if (angle >= turnAngleLimit)
			return true;
	}

	return false;
}

float HPJoystickMoveBehavior::LimitSpeedByGear(float inputValue)
{
	if (inputValue > 0.01f && inputValue < Azure::run_walk_gear_scale)
	{
		inputValue = Azure::run_walk_gear_scale;
	}
	else if (inputValue >= Azure::run_walk_gear_scale && inputValue < 1.0f)
	{
		inputValue = 1.0f;
	}

	return inputValue;
}

void HPJoystickMoveBehavior::DealDefaultWalkTime(float dt, const FVector & input,float speed)
{
	if (!_objcomp.IsValid())
		return;

	AGamePlayer* pActor = Cast<AGamePlayer>(_objcomp->GetOwner());
	if (!pActor)
		return;

	if (!IsDefaultWalkMode())
	{
		if (default_walk_stage != 0)
		{
			default_walk_input_time = 0.0f;
			default_walk_stage = 0;
			OnDefaultWalkTimeUp();

			//MyPrintString("default_walk_stage to 0");
		}
		
		return;
	}		

	if (default_walk_stage == 0)
	{
		default_walk_stage = 1;
		ReturnToDefaultWalk();

		//MyPrintString("default_walk_stage to 1");
	}
	else if (default_walk_stage == 1)
	{
		if (input.Size2D() >= Azure::default_walk_input_limit)
		{
			default_walk_input_time += dt;
			if (default_walk_input_time >= Azure::default_walk_time_limit)
			{
				OnDefaultWalkTimeUp();
				default_walk_stage = 2;

				//MyPrintString("default_walk_stage to 2");
			}

			if (false)
			{
				FString str = FString::Printf(TEXT("default_walk_input_time %0.3f"), default_walk_input_time);
				MyPrintString(str);
			}
		}
		else
		{
			if(default_walk_input_time > 0.0f)
				default_walk_input_time = 0.0f;

			//MyPrintString("default_walk_input_time to 0");
		}
	}
	else
	{
		if (speed < Azure::default_walk_speed && !pActor->IsPlayingNormalStop())
		{
			default_walk_stage = 1;
			ReturnToDefaultWalk();
			if (false)
			{
				double st = AAzureEntryPoint::Instance->GetRealtimeSinceStartup();
				FString str = FString::Printf(TEXT("ReturnToDefaultWalk 2 %0.4f"), st);
				MyPrintString("ReturnToDefaultWalk 2");
			}
		}
	}
}

void HPJoystickMoveBehavior::OnDefaultWalkTimeUp()
{	
	if (!_objcomp.IsValid())
		return;

	AGamePlayer* pActor = Cast<AGamePlayer>(_objcomp->GetOwner());
	if(pActor)
		pActor->SetMaxSpeed(pActor->m_run_speed);
}

void HPJoystickMoveBehavior::ReturnToDefaultWalk()
{
	if (!_objcomp.IsValid())
		return;

	AGamePlayer* pActor = Cast<AGamePlayer>(_objcomp->GetOwner());
	if (pActor)
		pActor->SetMaxSpeed(Azure::default_walk_speed);

	default_walk_input_time = 0.0f;
}

bool HPJoystickMoveBehavior::IsDefaultWalkMode()
{
	if (!_objcomp.IsValid())
		return false;

	AGamePlayer* pActor = Cast<AGamePlayer>(_objcomp->GetOwner());
	if (!pActor)
		return false;

	if (!pActor->m_isDefaultWalk)
		return false;

	if (pActor->IsEightDirMode())
		return false;

	return true;
}

float HPJoystickMoveBehavior::CalSpeedScaleByTurn(const FVector & inputdir)
{
	if (!_objcomp.IsValid())
		return 1.0f;

	AGamePlayer* pActor = Cast<AGamePlayer>(_objcomp->GetOwner());
	if (!pActor)
		return 1.0f;

	if (!pActor->GetCharacterMovement()->bOrientRotationToMovement)
		return 1.0f;

	float rate = 1.0f;

	FRotator delta = UKismetMathLibrary::NormalizedDeltaRotator(pActor->GetActorRotation(), inputdir.Rotation());

	float angle = FMath::Abs(delta.Yaw);
	if (angle > Azure::turn_speed_minus_angle)
	{
		float p = (angle - Azure::turn_speed_minus_angle) / (180.0f - Azure::turn_speed_minus_angle);
		float v1 = 1.0f;
		float v2 = Azure::turn_speed_minus_scale;
		rate = v1 * (1.0f - p) + v2 * p;		

		if (false)
		{
			FString str = FString::Printf(TEXT("inputValue %0.2f %0.2f %0.2f"), angle, inputdir.Size(), rate);
			MyPrintString(str);
		}
	}

	return rate;
}

void HPJoystickMoveBehavior::UpdateDashStopType()
{
	if (!_objcomp.IsValid())
		return;

	AGamePlayer* pActor = Cast<AGamePlayer>(_objcomp->GetOwner());
	if (!pActor)
		return;

	if (pActor->m_iPlayDashStop > 0)
	{
		if (!pActor->GetCurrentMontage() && !NeedForbidInputByDashStop())
		{
			if (pActor->m_iPlayDashStop > 1)//
			{
				FVector dashVelocity = pActor->GetActorForwardVector() * pActor->m_dash_speed;
				pActor->GetMyMovementComponent()->SetVelocity(dashVelocity);
			}			
			
			pActor->SetPlayDashAnim(0);
		}			
	}
}

void HPJoystickMoveBehavior::UpdateRunStopType()
{
	if (!_objcomp.IsValid())
		return;

	AGamePlayer* pActor = Cast<AGamePlayer>(_objcomp->GetOwner());
	if (!pActor)
		return;

	if (!AAzureEntryPoint::Instance)
		return;

	if (false)
	{
		double st = AAzureEntryPoint::Instance->GetRealtimeSinceStartup();
		FString str = FString::Printf(TEXT("UpdateRunStopType %d %d %0.4f"), pActor->m_iPlayNormalStop, pActor->GetCurrentMontage() == nullptr,st);
		MyPrintString(str);
	}
	
	if (pActor->m_iPlayNormalStop > 0)
	{
		if (!pActor->GetCurrentMontage() && !NeedForbidInputByRunStop())//
		{
			if (pActor->m_iPlayNormalStop > 1)//
			{
				FVector v = pActor->GetActorForwardVector() * pActor->m_run_speed;
				pActor->GetMyMovementComponent()->SetVelocity(v);

				//MyPrintString("RestoreSpeed");
			}

			pActor->SetPlayNormalStopAnim(0);
		}
	}
}

bool HPJoystickMoveBehavior::PlayDashStop(const FVector & input_dir)
{
	if (!_objcomp.IsValid())
		return false;

	AGamePlayer* pActor = Cast<AGamePlayer>(_objcomp->GetOwner());
	if (!pActor)
		return false;
	
	int dashStopType = 1;
	float angle = AzureUtility::Angle2(pActor->GetVelocity(),input_dir);
	if (angle > Azure::s_turn180_angle_limit)
	{
		dashStopType = 2;
	}
	else if (angle < -Azure::s_turn180_angle_limit)
	{
		dashStopType = 3;
	}
	else
	{
		if(input_dir.Size() > 0.0f)
			pActor->SetActorRotation(input_dir.Rotation());
	}

	pActor->SetPlayDashAnim(dashStopType);
	pActor->SyncPushMoveToServer("StartDashStop", ESyncMoveSendType::PlayDashStop, true, false);

	pActor->StartDashPlayTime(dashStopType);

	return (dashStopType != 1);
}



bool HPJoystickMoveBehavior::CanPlayNormalStop(int type)
{
	if (is_skill_move)//��糵�ȼ����ܱ��ƶ�
		return false;

	if (!_objcomp.IsValid())
		return false;

	AGamePlayer* pActor = Cast<AGamePlayer>(_objcomp->GetOwner());
	if (pActor)
	{
		if (!pActor->CanPlayNormalStopByLua(type))
			return false;
	}

	return true;
}

bool HPJoystickMoveBehavior::CanPlayDashStop(int type)
{
	if (!_objcomp.IsValid())
		return false;

	AGamePlayer* pActor = Cast<AGamePlayer>(_objcomp->GetOwner());
	if (pActor)
	{
		if (!pActor->CanPlayDashStopByLua())
			return false;
	}

	return true;
}

int HPJoystickMoveBehavior::CheckPlayNormalTurn180(const FVector & input)
{
	if (!_objcomp.IsValid())
		return 0;

	AGamePlayer* pActor = Cast<AGamePlayer>(_objcomp->GetOwner());	
	if (!pActor)
		return 0;

	if (!AAzureEntryPoint::Instance)
		return 0;
		
	FVector velo = pActor->GetVelocity();
	FVector facedir = pActor->GetActorForwardVector();

	int value = 0;
	float angle = AzureUtility::Angle2(velo, input);
	if (angle > Azure::s_turn180_angle_limit)
	{
		value = 2;
	}
	else if (angle < -Azure::s_turn180_angle_limit)
	{
		value = 3;
	}	
	
	if (value > 0)
	{
		if (!CanPlayNormalStop(2))
		{
			//MyPrintString("CheckPlayTurn180 lua limit");
			return 0;
		}

		double cur_time = AAzureEntryPoint::Instance->GetRealtimeSinceStartup();
		if (cur_time - start_time < Azure::start_walk_duration)//��ֹ�շ���λ���༼�ܻ�������Ϊ�������ƶ���������ɲ��
		{
			//MyPrintString("CheckPlayTurn180 start_time limit");
			return 0;
		}			

		if (false)
		{
			int b = 0;
			if (pActor->IsPlayingMontage())
				b = 1;

			FString str = FString::Printf(TEXT("CheckTurn180 value[%d] velo[%0.1f][%0.1f %0.1f] input[%0.1f] mon %d"), value,velo.Rotation().Yaw,
				velo.X,velo.Y,input.Rotation().Yaw,b);
			MyPrintString(str);
		}

		/*float speed = velo.Size2D();//�ŵ�Lua���ж�
		if (speed < Azure::run_turn180_speed_limit)
		{
			FString str = FString::Printf(TEXT("CheckPlayTurn180 speed limit %0.1f %0.1f"), speed, Azure::run_turn180_speed_limit);

			MyPrintString("CheckPlayTurn180 speed limit");
			return 0;
		}
		
		if (false && value > 1)
		{
			FString str = FString::Printf(TEXT("CheckPlay speed [%0.1f] [%0.2f %0.2f] [%0.2f %0.2f]"), speed, velo.X, velo.Y, input.X, input.Y);
			MyPrintString(str);
		}*/
	}
	

	if (false)
	{
		float speed = velo.Size2D();
		FString str = FString::Printf(TEXT("CheckPlayNormalTurn180 [%0.1f] [%0.1f] [%0.2f %0.2f] [%0.2f %0.2f]"),angle, speed, velo.X, velo.Y, input.X, input.Y);
		MyPrintString(str);
	}

	return value;
}

void HPJoystickMoveBehavior::PlayNormalStop(int play_type)
{
	if (!_objcomp.IsValid())
		return;

	AGamePlayer* pActor = Cast<AGamePlayer>(_objcomp->GetOwner());
	if (!pActor)
		return;

	pActor->SetPlayNormalStopAnim(play_type);
	pActor->StartRunStopPlayTime(play_type);

	pActor->SyncPushMoveToServer("StartNormalStop", ESyncMoveSendType::PlayNormalStop, true, false);
}

bool HPJoystickMoveBehavior::IsEnterDashInput(const FVector & inputValue)
{
	//if (inputValue.Size() < Azure::s_inputAxisMaxValue - 0.01f)
	//	return false;

	const FRotator Rotation = GetActorControlRotation();
	const FRotator YawRotation(0, Rotation.Yaw, 0);
	const FVector Direction = FRotationMatrix(YawRotation).GetUnitAxis(EAxis::X);

	float delta_yaw = AzureUtility::Angle(inputValue, Direction);
	return (delta_yaw <= Azure::s_dash_angle);
}

bool HPJoystickMoveBehavior::IsEnterDashInputByDodge(const FVector & inputValue)
{
	const FRotator Rotation = GetActorControlRotation();
	const FRotator YawRotation(0, Rotation.Yaw, 0);
	const FVector Direction = FRotationMatrix(YawRotation).GetUnitAxis(EAxis::X);

	float delta_yaw = AzureUtility::Angle(inputValue, Direction);
	return (delta_yaw <= Azure::s_dash_angle_dodge);
}

bool HPJoystickMoveBehavior::IsEnterDashInput2(const FVector & inputValue)
{
	if (inputValue.Size() < Azure::s_inputAxisMaxValue - 0.01f)
		return false;

	return IsEnterDashInput(inputValue);
}

void HPJoystickMoveBehavior::DealEnterDashTime(FVector inputValue, float dt)
{
	if (!_objcomp.IsValid())
		return;

	AGamePlayer* pActor = Cast<AGamePlayer>(_objcomp->GetOwner());
	if (!pActor)
		return;

	if (pActor->m_isWaitEnterDash)//���ܺ����
	{
		if (IsEnterDashInputByDodge(inputValue))
		{
			enterDashTime += dt;
			if (enterDashTime >= Azure::s_dash_time)
			{
				if (!pActor->m_bIsDashMove)
				{
					SetReadyEnterDash(true);
				}
			}

			enterDashTime_move_input = 0.0f;
		}
		else
		{
			ClearDashTime();
		}
	}
	else if (IsEnterDashInput2(inputValue))//ǰ���������
	{
		enterDashTime_move_input += dt;
		if (enterDashTime_move_input >= Azure::s_dash_time_move_input)
		{
			if (!pActor->m_bIsDashMove)
			{
				SetReadyEnterDashMoveInput(true);
			}
		}

		enterDashTime = 0.0f;
	}
	else
	{
		ClearDashTime();
	}
}

void HPJoystickMoveBehavior::RemoveDashState()
{
	ClearDashTime();

	if (!_objcomp.IsValid())
		return;

	AGamePlayer* pActor = Cast<AGamePlayer>(_objcomp->GetOwner());	
	if (pActor)
	{
		pActor->StopDashDirect();
	}
}

void HPJoystickMoveBehavior::ClearDashTime()
{
	enterDashTime = 0.0f;
	enterDashTime_move_input = 0.0f;

	SetReadyEnterDash(false);
	SetReadyEnterDashMoveInput(false);

	if (!_objcomp.IsValid())
		return;

	AGamePlayer* pActor = Cast<AGamePlayer>(_objcomp->GetOwner());
	if(pActor)
		pActor->m_isWaitEnterDash = false;
}

void HPJoystickMoveBehavior::StopDash()
{
	RemoveDashState();

	if (!_objcomp.IsValid())
		return;

	FVector2D v = AzureInputCtrl::GetInstance().GetJoyStickValue();
	if (v.Size() < 0.01f)//û������
	{
		AGamePlayer* pActor = Cast<AGamePlayer>(_objcomp->GetOwner());
		if (pActor && pActor->CanPlayDashStopByLua())
			PlayDashStop(FVector::ZeroVector);
	}
	
}

void HPJoystickMoveBehavior::SetReadyEnterDash(bool b)
{
	if (!_objcomp.IsValid())
		return;

	AGamePlayer* pActor = Cast<AGamePlayer>(_objcomp->GetOwner());
	if (!pActor)
		return;	

	if (pActor->m_bIsDashReady != b)
	{		
		pActor->m_bIsDashReady = b;

		if (!AAzureEntryPoint::Instance)
			return;

		lua_State_Wrapper L = AAzureEntryPoint::Instance->GetL();
		if (!L)
			return;

		lua_rawgeti(L, LUA_REGISTRYINDEX, _objcomp->GetLuaECObject()); // obj
		lua_getfield(L, -1, "OnReadyEnterDash"); // 
		lua_pushvalue(L, -2);
		lua_pushboolean(L, b);
		AAzureEntryPoint::Instance->GetWLua()->Call(2);
		lua_pop(L, 1);
	}
	
}

void HPJoystickMoveBehavior::SetReadyEnterDashMoveInput(bool b)
{
	if (!_objcomp.IsValid())
		return;

	AGamePlayer* pActor = Cast<AGamePlayer>(_objcomp->GetOwner());
	if (!pActor)
		return;

	if (pActor->m_bIsDashReadyMoveInput != b)
	{
		pActor->m_bIsDashReadyMoveInput = b;

		if (!AAzureEntryPoint::Instance)
			return;

		lua_State_Wrapper L = AAzureEntryPoint::Instance->GetL();
		if (!L)
			return;

		lua_rawgeti(L, LUA_REGISTRYINDEX, _objcomp->GetLuaECObject()); // obj
		lua_getfield(L, -1, "OnReadyEnterDashMoveInput"); // 
		lua_pushvalue(L, -2);
		lua_pushboolean(L, b);
		AAzureEntryPoint::Instance->GetWLua()->Call(2);
		lua_pop(L, 1);
	}

}

bool HPJoystickMoveBehavior::NeedForbidInputByDashStop()
{
	if (!_objcomp.IsValid())
		return false;

	AGamePlayer* pActor = Cast<AGamePlayer>(_objcomp->GetOwner());
	if (!pActor)
		return false;

	if (pActor->GetDashPlayTime() > 0.0f)
	{
		//FString str = FString::Printf(TEXT("dashPlayTimeForbid %0.3f"), pActor->GetDashPlayTime());
		//MyPrintString(str);
		return true;
	}		

	return false;
}

bool HPJoystickMoveBehavior::NeedForbidInputByRunStop()
{
	if (!_objcomp.IsValid())
		return false;

	AGamePlayer* pActor = Cast<AGamePlayer>(_objcomp->GetOwner());
	if (!pActor)
		return false;

	if (pActor->GetRunStopPlayTime() > 0.0f)
	{
		if (false)
		{
			FString str = FString::Printf(TEXT("runStopPlayTimeForbid %0.3f"), pActor->GetRunStopPlayTime());
			MyPrintString(str);
		}
		
		return true;
	}

	return false;
}



const FRotator HPJoystickMoveBehavior::GetActorControlRotation()
{
	if (!_objcomp.IsValid())
		return FRotator::ZeroRotator;

	AGamePlayer* pActor = Cast<AGamePlayer>(_objcomp->GetOwner());
	if (pActor)
	{
		return pActor->GetJoystickMoveRotation();
	}
	else
	{
		return FRotator::ZeroRotator;
	}
}



