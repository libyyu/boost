﻿#pragma once

#include "AzureBehavior.h"

////主角空中位移到当前地面坐标点
//////////////////////////////////////////////////////////////////////////
class HPRushDownBehavior : public AzureBehavior
{
protected:
	static constexpr  Azure::BehaviorType _type = Azure::BehaviorType::HPRushDown;

	float m_max_dis;
	float m_speed;

	FVector m_velocity;	
	float m_gravityScale;

	FVector m_start;
	
public:

	HPRushDownBehavior()
	{
		
	}

	Azure::BehaviorType get_Type() const override
	{
		return _type;
	}

	static HPRushDownBehavior* Create()
	{
		HPRushDownBehavior* ret = (HPRushDownBehavior*)AzureBehaviorCache::GetInstance().GetBehavior(_type);

		if (ret == nullptr)
			ret = new HPRushDownBehavior();

		return ret;
	}

	bool SetData(const FVector & vDir, float speed,float max_dis, OnBehaviorFinish onFinish);
	bool Tick(float dt) override;
	virtual void OnRemoved(bool replace) override;
};

