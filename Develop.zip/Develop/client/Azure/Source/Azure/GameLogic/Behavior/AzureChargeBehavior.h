#pragma once

#include "AzureBehavior.h"

class AzureChargeBehavior : public AzureBehavior
{
protected:

	static constexpr  Azure::BehaviorType _type = Azure::BehaviorType::Charge;

	FVector _Destination = FVector::ZeroVector;
	FVector _Velocity = FVector::ZeroVector;
	float _FinishedTime = 0;
	bool _bHostPlayer = false;

	float _fExt = 0;
	float _fAboveH1 = 0;
	float _fAboveH2 = 0;
	float _fAboveHFinal = 0;

	int _idSkill = 0;

public:

	bool get_IsHostPlayer() const
	{
		return _bHostPlayer;
	}
	void set_IsHostPlayer(bool v)
	{
		_bHostPlayer = v;
	}

	int get_Skill() const
	{
		return _idSkill;
	}
	void set_Skill(int v)
	{
		_idSkill = v;
	}

	AzureChargeBehavior()
	{
		
	}

	Azure::BehaviorType get_Type() const override
	{
		return _type;
	}

	static AzureChargeBehavior* Create()
	{
		AzureChargeBehavior* ret = (AzureChargeBehavior*)AzureBehaviorCache::GetInstance().GetBehavior(_type);

		if (ret == nullptr)
			ret = new AzureChargeBehavior();

		return ret;
	}

	bool SetData(bool bHostPlayer, int idSkill, FVector vDest, float time,
		OnBehaviorFinish onFinish, float fExt = 0, float fAboveH1 = 0, float fAboveH2 = 0, float fAboveHFinal = 0);

	void ChangeTargetPos(FVector vDest);

	virtual bool Tick(float dt) override;

	virtual void OnRemoved(bool replace) override;
};
