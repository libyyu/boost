﻿#pragma once

#include "AzureBehavior.h"

//////////////////////////////////////////////////////////////////////////
class AzureDecelMoveBehavior : public AzureBehavior
{
protected:


	static constexpr  Azure::BehaviorType _type = Azure::BehaviorType::DecelMove;

	FVector m_vDest;
	FVector m_vStartPos;
	
	float m_duration;
	float m_time;

	FVector m_vDir;
	float m_fDist;

	FVector m_vStartDir;
	bool isGamePlayerMove;

	TWeakObjectPtr<class AGamePlayer> m_carrier;
	bool m_isOnCarrier;

	TWeakObjectPtr<class AGamePlayer> m_pGamePlayer;
	TWeakObjectPtr<AActor> m_pObj;

public:

	AzureDecelMoveBehavior()
	{
		
	}

	static AzureDecelMoveBehavior* Create()
	{
		AzureDecelMoveBehavior* ret = (AzureDecelMoveBehavior*)AzureBehaviorCache::GetInstance().GetBehavior(_type);

		if (ret == nullptr)
			ret = new AzureDecelMoveBehavior();

		return ret;
	}

	Azure::BehaviorType get_Type() const override
	{
		return _type;
	}

	bool SetData(FVector vDest, float time, class AGamePlayer * pCarrier, OnBehaviorFinish onFinish);
	bool Tick(float dt) override;
	virtual void OnRemoved(bool replace) override;

	void GetCurPosAndDir(FVector & pos,FVector & dir);
	void SetCurPosAndDir(FVector pos);

	void DrawDestPos_SetData();
	void DrawTick();
};

