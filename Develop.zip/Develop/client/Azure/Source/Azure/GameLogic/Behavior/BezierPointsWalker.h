#pragma once

#include "../AzureCommonDef.h"

///////////////////////////////////////////////////////////////////////////
//	
//	Class CBezierPointsWalker
//	
///////////////////////////////////////////////////////////////////////////

class CBezierPointsWalker
{
public:		//	Types

public:		//	Constructor and Destructor

	CBezierPointsWalker();
	virtual ~CBezierPointsWalker();

public:		//	Attributes

public:		//	Operations

	//	Bind Points
	bool BindPoints(const Azure::VecPoint& vPoints)
	{
		if (m_bWalking)
		{
			//	Cannot BindPoints when walking!
			return false;
		}
		m_vPoints = vPoints;
		return true;
	}

	//	Start walk
	bool StartWalk(int iStartIdx = -1/*-1 means not specify*/,
		int iMoveToIdx = -1 /*-1 means not specify*/,
		bool bReachPause = false, /* Pause when reach current DestPoint? */
		bool bAutoAdvancePoint = true /* Auto advance to next point? */
	);

	//	Stop walk
	void StopWalk();

	//	Walking?
	bool IsWalking() const {
		return m_bWalking;
	}

	//	Change Start Index (can Only changed when Walking)
	bool ChangeStartIndex(int iStartIdx);

	//	Change Move to Index (can Only changed when Walking)
	bool ChangeMoveToIndex(int iMoveToIdx, bool bReachPause);
	int GetMoveToIndex() const {
		return m_iMoveToIdx;
	}

	//	Forward?
	bool IsForward() const {
		return m_bPaused;
	}

	//	Paused?
	void SetPaused(bool bPause);
	bool IsPaused() const {
		return m_bPaused;
	}
	bool IsReachPause() const {
		return m_bReachPause;
	}

	//	Speed
	void SetSpeed(float fSpeed) {
		m_fSpeed = fSpeed;
	}
	float GetSpeed() const {
		return m_fSpeed;
	}

	//	Tick routine
	bool Tick(float fDeltaTime);

	//	Get current position/Dir
	FVector GetPos() const {
		return m_vCurPos;
	}
	bool HasMoveThisFrame() const {
		return m_bMovedThisFrame;
	}
	FVector GetDir() const {
		return m_vCurDir;
	}

	//	Get Nearest Pos, return point Index
	int GetNearestPos(const FVector& vFrom, float& fNearistDist, bool b3D) const;

	//	Get Points
	const Azure::VecPoint& GetPoints() const {
		return m_vPoints;
	}
	int GetPointCount() const {
		return m_vPoints.Num();
	}
	const FVector* GetPoint(int idx) const {
		if (idx < 0 || idx >= m_vPoints.Num())
			return nullptr;
		else
			return &m_vPoints[idx];
	}

	//	Get Total Dist
	float GetTotalDist(bool b3DDist, int idxFrom, int idxEnd = -1);

	//	Cur Point Index
	int GetCurStartPointIdx() const {
		return m_iCurStartPoint;
	}
	int GetCurDestPointIdx() const {
		return m_iCurDestPoint;
	}

protected:	//	Attributes

	Azure::VecPoint	m_vPoints;			//	Points Vector
	FVector		m_vCurPos;				//	Current Pos
	FVector		m_vCurDir;				//	Current Dir
	int			m_iCurStartPoint = -1;	//	Current Start Point
	int			m_iCurDestPoint = -1;	//	Current Dest Point

	float		m_fSpeed = 1.0f;		//	Move Speed

	int			m_iMoveToIdx = -1;		//	Move To Index

	bool		m_fForward = true;		//	Forward?
	bool		m_bWalking = false;		//	Walking now?
	bool		m_bPaused = false;		//	Paused?
	bool		m_bReachPause = false;	//	Reach auto Pause?
	bool		m_bAutoAdvancePoint = false; //	Auto Advance to Point?
	bool		m_bMovedThisFrame = false;

protected:	//	Operations

	bool JudgeCurMoveEnd();

	bool AdvanceCurDestIdx();
	void RefreshCurDestAndDir();
};
