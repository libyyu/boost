#pragma once

#include "AzureBehavior.h"
#include "BezierPointsWalker.h"
#include "Array.h"
#include "GameFramework/Actor.h"
#include "../AzureCommonDef.h"

//////////////////////////////////////////////////////////////////////////

class AzureBezierMoveBehavior : public AzureBehavior
{

protected:
	static constexpr  Azure::BehaviorType _type = Azure::BehaviorType::BezierMove;

public:
	AzureBezierMoveBehavior()
	{
		
	}

	static AzureBezierMoveBehavior* Create()
	{
		AzureBezierMoveBehavior* ret = (AzureBezierMoveBehavior*)AzureBehaviorCache::GetInstance().GetBehavior(_type);
		if (ret == nullptr)
			ret = new AzureBezierMoveBehavior();
		return ret;
	}

	Azure::BehaviorType get_Type() const override
	{
		return _type;
	}

	bool SetData(const Azure::VecPoint& points, float fSpeed, bool bAllowChangeSpeed,
		bool bFlyMove, bool bForceTraceToGround, bool bReachPause,
		AActor* pFlwActor, int nFlwAdvancePtCount, int nStartAdvancePtCount, OnBehaviorFinish onFinish,
		float fMaxSpeed_Factor = 2.5, float fStiffness=-1, float fDamping=-1);

	bool Tick(float dt) override;

	void OnRemoved(bool replace) override;

protected:

	Azure::SPRINTPHY_POS m_TargetSpring;

	CBezierPointsWalker m_walker;
	TWeakObjectPtr<AActor> m_FlwActor;
	int m_nFlwAdvancePtCount = 0;
	int m_nStartAdvancePtCount = 0;
	//float m_fNoMoveRange = 3.f * UE_METRE_TRANS;

	float m_fOriginSpeed = 0;
	float m_fCurSpeed = 0;
	float m_fMaxSpeed_Factor = 2.5f;

	float m_fRefreshMoveToTimer = 0.f;
	float m_fSetActorSpeedTimer = 0.f;

	bool m_bAllowChangeSpeed = false;
	bool m_bFlyMove = false;
	bool m_bForceTraceToGround = false;
};