﻿//#include "Azure.h"
#include "AzureBezierMoveBehavior.h"
#include "AzureObjectComponent.h"
#include "UE4Related.h"
#include "AzureUtility.h"
#include "DrawDebugHelpers.h"

using namespace Azure;

//////////////////////////////////////////////////////////////////////////
//
//	Class AzureBezierMoveBehavior
//
//////////////////////////////////////////////////////////////////////////

bool AzureBezierMoveBehavior::SetData(const VecPoint& points, float fSpeed, bool bAllowChangeSpeed,
	bool bFlyMove, bool bForceTraceToGround, bool bReachPause,
	AActor* pFlwActor, int nFlwAdvancePtCount, int nStartAdvancePtCount, OnBehaviorFinish onFinish,
	float fMaxSpeed_Factor/* = 2.5*/, float fStiffness/*=-1*/, float fDamping/*=-1*/)
{
	if (points.Num() < 1)
		return false;

	AActor* pObj = _objcomp.IsValid() ? _objcomp->GetOwner() : nullptr;
	if (!pObj)
		return false;

	m_fOriginSpeed = fSpeed;
	m_fCurSpeed = fSpeed;
	m_fMaxSpeed_Factor = fMaxSpeed_Factor;

	m_bAllowChangeSpeed = bAllowChangeSpeed;
	if (fStiffness > 0)
		m_TargetSpring.param.fStiffness = fStiffness;
	if (fDamping > 0)
		m_TargetSpring.param.fDamping = fDamping;

	m_bFlyMove = bFlyMove;
	m_bForceTraceToGround = bForceTraceToGround;

	m_FlwActor = pFlwActor;
	m_nFlwAdvancePtCount = nFlwAdvancePtCount;
	m_nStartAdvancePtCount = nStartAdvancePtCount;
	//m_fNoMoveRange = fNoMoveRange;

	set_OnFinish(onFinish);

	m_fRefreshMoveToTimer = 0;
	m_fSetActorSpeedTimer = 0;

	m_walker.StopWalk();
	m_walker.BindPoints(points);
	m_walker.SetSpeed(fSpeed);

	int iStartIdx = -1, iMoveToIdx = -1;
	if (pFlwActor)
	{
		//	Decide StartIndex
		FVector vPos = pFlwActor->GetActorLocation();

		float fNearistDist = -1;
		int iNearestIdx = m_walker.GetNearestPos(vPos, fNearistDist, m_bFlyMove);
		if (iNearestIdx >= 0)
		{
			iStartIdx = iNearestIdx + m_nStartAdvancePtCount;
			if (iStartIdx < 0)
				iStartIdx = 0;
			else if (iStartIdx >= points.Num())
				iStartIdx = points.Num() - 1;

			iMoveToIdx = iStartIdx;
		}
	}

	if (m_walker.StartWalk(iStartIdx, iMoveToIdx, bReachPause))
	{
		FVector dir = m_walker.GetDir();
		if (!dir.IsZero())
			pObj->SetActorLocationAndRotation(m_walker.GetPos(), dir.ToOrientationRotator());
		else
			pObj->SetActorLocation(m_walker.GetPos());

		return true;
	}
	else
	{
		return false;
	}
}

bool AzureBezierMoveBehavior::Tick(float dt)
{
	AActor* pObj = _objcomp.IsValid() ? _objcomp->GetOwner() : nullptr;
	if (!pObj)
		return true;

	bool bMoving_Old = !m_walker.IsPaused() && m_walker.IsWalking();

	m_walker.Tick(dt);
	FVector newPos = m_walker.GetPos();
	FVector newDir = m_walker.GetDir();

	FVector oldPos = pObj->GetActorLocation();

	//bool bReachDest = m_walker.GetCurDestPointIdx() >= m_walker.GetPointCount();
	bool bWalking = m_walker.IsWalking();

	if (!newPos.IsZero())
	{
		if (m_walker.HasMoveThisFrame()
			&& m_bForceTraceToGround)
		{
			//	Trace Ground to get exact height
			FVector vTest(newPos);
			VEC_UP(vTest) += 2.f * UE_METRE_TRANS;

			float fHei = VEC_UP(newPos);
			if (AzureUtility::GetSupportPlaneHeight(fHei, vTest, Azure::s_fPlayerMoveExt))
				VEC_UP(newPos) = fHei;
		}

		if (!bWalking)
		{
			pObj->SetActorLocation(newPos);

			//	!Walking时结束Behavior(pause时不结束)
			return !bWalking;
		}

		if (!newDir.IsZero())
			pObj->SetActorLocationAndRotation(newPos, newDir.ToOrientationRotator());
		else
			pObj->SetActorLocation(newPos);

		if (m_FlwActor.Get())
		{
			//	根据FollowAct的位置，决定是否Walk/Pause，以及向何方向Walk
			//if (m_bAllowChangeSpeed)
			{
				UAzureObjectComponent* pAzureComp = Cast<UAzureObjectComponent>(m_FlwActor->GetComponentByClass(UAzureObjectComponent::StaticClass()));
				if (pAzureComp)
				{
					//	更新Speed。。
					float fCurHoriSpeed = 10;
					if (fCurHoriSpeed > 0)
						m_fOriginSpeed = fCurHoriSpeed;
				}
			}

			FVector vPos = m_FlwActor->GetActorLocation();

			m_fRefreshMoveToTimer += dt;
			if (m_fRefreshMoveToTimer >= 0.1f)
			{
				m_fRefreshMoveToTimer = 0;

				int idxIdealDest = m_walker.GetCurDestPointIdx();

				float fNearistDist = -1;
				int iNearestIdx = m_walker.GetNearestPos(vPos, fNearistDist, m_bFlyMove);
				if (iNearestIdx >= 0)
				{
					idxIdealDest = iNearestIdx + m_nFlwAdvancePtCount;
					if (idxIdealDest < 0)
						idxIdealDest = 0;
					else if (idxIdealDest >= m_walker.GetPointCount())
						idxIdealDest = m_walker.GetPointCount() - 1;
				}

				if (m_walker.GetMoveToIndex() < idxIdealDest)
				{
					m_walker.ChangeMoveToIndex(idxIdealDest, m_walker.IsReachPause());
					newDir = m_walker.GetDir();
				}
			}

			bool bMoving = !m_walker.IsPaused() && m_walker.IsWalking();
			if (m_bAllowChangeSpeed && bMoving)
			{
				//	根据距离加速？？
				int idxMoveTo = m_walker.GetMoveToIndex();
				if (idxMoveTo >= 0 && idxMoveTo < m_walker.GetPointCount())
				{
					int curDestIdx = m_walker.GetCurDestPointIdx();
					const FVector* ptCurDest = m_walker.GetPoint(curDestIdx);

					int curMoveToIdx = m_walker.GetMoveToIndex();

					FVector vFakeDest = vPos;
					if (FMath::Abs(curDestIdx - curMoveToIdx) > 0)
					{
						float fCurDistMoveTo = 0;
						if (ptCurDest)
						{
							FVector vDelta = *ptCurDest - vPos;
							fCurDistMoveTo = m_bFlyMove ? vDelta.Size() : vDelta.Size2D();
						}

						fCurDistMoveTo += m_walker.GetTotalDist(m_bFlyMove, curDestIdx, curMoveToIdx);

						vFakeDest.X += fCurDistMoveTo;
					}
					else
					{
						if (ptCurDest)
							vFakeDest = *ptCurDest;
					}

					float fMaxSpeed = m_fOriginSpeed * m_fMaxSpeed_Factor;

					float fSpeed = m_fOriginSpeed;
					m_TargetSpring.InterpPos(vPos, vFakeDest, dt, &fSpeed, &fMaxSpeed);
					m_fCurSpeed = FMath::Max(fSpeed, m_fOriginSpeed);

					//if (FMath::Abs(m_walker.GetCurStartPointIdx() - idxMoveTo) < m_nFlwAdvancePtCount)
					//{
					//	float fMaxSpeed = m_fOriginSpeed * s_fFarDistSpeedRatio_Max;
					//	m_SpeedSpring.InterpSpeed(m_fCurSpeed, fMaxSpeed, dt);
					//}
					//else
					//{
					//	m_SpeedSpring.InterpSpeed(m_fCurSpeed, m_fOriginSpeed, dt);
					//}
				}
			}
			else
			{
				m_fCurSpeed = m_fOriginSpeed;
			}

			m_walker.SetSpeed(m_fCurSpeed);

			m_fSetActorSpeedTimer += dt;
			if (m_fSetActorSpeedTimer > 0.046f || bMoving_Old != bMoving)
			{
				m_fSetActorSpeedTimer = 0;
				_objcomp->OnBezierMoveSpeedChange(bMoving ? m_fCurSpeed : 0);
			}
		}
	}

	return false;
}

void AzureBezierMoveBehavior::OnRemoved(bool replace)
{
}
