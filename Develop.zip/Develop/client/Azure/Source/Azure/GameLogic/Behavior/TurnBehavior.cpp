#include "TurnBehavior.h"
#include "AzureObjectComponent.h"
#include "Kismet/KismetSystemLibrary.h"
#include "GameLogic/Player/GamePlayer.h"
#include "AzureTimeManager.h"
#include "AzureEntryPoint.h"
#include "GameLogic/Player/GamePlayer_Util.h"
#include "HPMoveBase.h"

bool TurnBehavior::SetData(FVector vDest, bool limit_time, float param, GP_TURN_FLAG flag,AGamePlayer * pCarrier, OnBehaviorFinish onFinish)
{
	if (!_objcomp.IsValid())
		return false;

	AActor* obj = _objcomp->GetRotObj();
	if (!obj)
		return false;

	_objcomp->RemoveBehavior(Azure::BehaviorType::ObjServerMove);

	//MyPrintString("AddTureBehavior");

	m_Obj = obj;

	if (obj->IsA<AGamePlayer>())
	{
		m_isGamePlayer = true;
		m_pGamePlayer = Cast<AGamePlayer>(obj);

		m_pGamePlayer->m_bNeedTickServerMoveRotation = false;
	}
	else
	{
		m_isGamePlayer = false;
		m_pGamePlayer = nullptr;
	}


	set_OnFinish(onFinish);
	m_carrier = pCarrier;

	m_isOnCarrier = (pCarrier != nullptr);

	FVector ue_vDest;
	if (pCarrier) //����ڴ��ϣ�������������Գ���
		ue_vDest =  RELATIVE_DIR_FROM_SERVER(vDest);
	else
		ue_vDest = DIR_FROM_SERVER(vDest);
	
	VEC_UP(ue_vDest) = 0;

	if (ue_vDest.Size2D() < 1E-5f)
	{
		return false;
	}

	ue_vDest.Normalize();
	_flag = flag;

	if(false)
	{
		if (!AAzureEntryPoint::Instance)
			return false;

		double st = AAzureEntryPoint::Instance->GetRealtimeSinceStartup();
		FVector unitdir = ue_vDest.GetSafeNormal2D();
		FString str = FString::Printf(TEXT("TurnBehavior %0.2f %0.2f %0.1f [%x] ---%0.3f"), unitdir.X, unitdir.Y,unitdir.Rotation().Yaw, (int)flag,st);
		MyPrintString(str);
	}

	//����ڴ��ϣ�����������Գ��򣬷����Ǿ��Գ���
	_destdir = ue_vDest.Rotation();
	_startdir = GetCurRot();
	

	float fDeltaAngle = FMath::FindDeltaAngleDegrees(_startdir.Yaw, _destdir.Yaw);
	float speed = param;
	//cal time
	if ((uint32)_flag & (uint32)GP_TURN_FLAG::GP_TURN_STOP)
	{
		//�����ֹͣ��totalTime��timepassed���䣬����֮ǰ�ļ�ʱ
		_speed_for_anim = fDeltaAngle / _totaltime;

		if (m_isGamePlayer && Azure::TurnLog)
		{
			if (!AAzureEntryPoint::Instance)
				return false;

			double st = AAzureEntryPoint::Instance->GetRealtimeSinceStartup();
			FString str = FString::Printf(TEXT("object_turn Stop: timepassed total %0.4f,%0.4f---%0.3f"),
				_timepassed, _totaltime,st);

			UKismetSystemLibrary::PrintString(GEngine->GetWorld(), str, false);
		}
	}
	else
	{
		if (limit_time)
		{
			_totaltime = param;
			_speed_for_anim = fDeltaAngle / _totaltime;

			if (false)
			{
				FString str = FString::Printf(TEXT("_totaltime1 %0.3f"), _totaltime);
				MyPrintString(str);
			}
		}
		else if (speed <= 0.0f)
		{
			_totaltime = 0.0f;
			_speed_for_anim = 0;
		}
		else
		{
			_totaltime = FMath::Abs(fDeltaAngle) / speed;
			_speed_for_anim = speed;

			if (false)
			{
				FString str = FString::Printf(TEXT("_totaltime2 %0.3f"), _totaltime);
				MyPrintString(str);
			}

			if (fDeltaAngle < 0.0f)
				_speed_for_anim = -_speed_for_anim;
		}

		_timepassed = 0;
	}
	
	
	/////////////////////////////
	
	if (_totaltime > 0.5f && false && m_pGamePlayer.IsValid())
	{
		FString str = FString::Printf(TEXT("object_turn time > 0.5: Yaw [%0.1f] -> [%0.1f], DeltaAngle [%0.1f], speed[%0.1f],totalTime[%0.3f], synctime[%0.3f/%0.3f] finish %d"),
			_startdir.Yaw, _destdir.Yaw, fDeltaAngle, speed, _totaltime, m_pGamePlayer->sync_time, m_pGamePlayer->GetCharacterMovement()->NetworkSimulatedSmoothLocationTime, m_pGamePlayer->GetCharacterMovement()->bNetworkSmoothingComplete);

		UKismetSystemLibrary::PrintString(GEngine->GetWorld(), str, false);
	}

	if (m_pGamePlayer.IsValid() && Azure::TurnLog)
	{
		if (!AAzureEntryPoint::Instance)
			return false;

		double st = AAzureEntryPoint::Instance->GetRealtimeSinceStartup();
		//FNetworkPredictionData_Client_Character* ClientData = m_pGamePlayer->GetMyMovementComponent()->GetPredictionData_Client_Character_Self();
		/*FString str = FString::Printf(TEXT("object_turn: Yaw [%0.1f] -> [%0.1f], DeltaAngle [%0.1f], speed[%0.1f],totalTime[%0.3f],time[%0.3f] synctime[%0.3f/%0.3f] finish %d offset %0.1f"),
			_startdir.Yaw, _destdir.Yaw, fDeltaAngle, speed, _totaltime,st,obj->sync_time, obj->GetCharacterMovement()->NetworkSimulatedSmoothLocationTime,
			obj->GetCharacterMovement()->bNetworkSmoothingComplete, ClientData->MeshTranslationOffset.Size());*/

		if (m_pGamePlayer->m_isCarrier)
		{
			FString str = FString::Printf(TEXT("object_turn(ship): Yaw [%0.1f] -> [%0.1f]---DeltaAngle [%0.1f]----speed[%0.1f],totalTime[%0.3f],time[%0.3f] limitTime[%d] param[%0.3f] flag[%x] "),
				_startdir.Yaw, _destdir.Yaw, fDeltaAngle, speed, _totaltime, st, limit_time, param, (int)flag);

			UKismetSystemLibrary::PrintString(GEngine->GetWorld(), str, false);
		}
		else
		{
			FString str = FString::Printf(TEXT("object_turn(monster): Yaw [%0.1f] -> [%0.1f]---DeltaAngle [%0.1f]----speed[%0.1f],totalTime[%0.3f],time[%0.3f] limitTime[%d] param[%0.3f] flag[%x] "),
				_startdir.Yaw, _destdir.Yaw, fDeltaAngle, speed, _totaltime, st, limit_time, param, (int)flag);

			UKismetSystemLibrary::PrintString(GEngine->GetWorld(), str, false);
		}
	}


	if ((uint32)_flag & (uint32)GP_TURN_FLAG::GP_TURN_BLINK)
	{
		SetCurRot(_destdir);

		if (m_pGamePlayer.IsValid() && Azure::TurnLog)
		{
			if (!AAzureEntryPoint::Instance)
				return true;

			double st = AAzureEntryPoint::Instance->GetRealtimeSinceStartup();
			FString str = FString::Printf(TEXT("object_turn SetDataBlink: Yaw %0.1f---%0.3f"),
				_destdir.Yaw, st);

			UKismetSystemLibrary::PrintString(GEngine->GetWorld(), str, false);
		}		
	}

	return true;
}

FRotator TurnBehavior::GetCurRot()
{
	FRotator resultRot;
	FRotator r1 = _objcomp->GetRotObj()->GetActorRotation();
	if (m_isOnCarrier)
	{
		if (m_carrier.IsValid())
		{
			AGamePlayer * pCarrier = m_carrier.Get();
			FVector t2 = pCarrier->GetFeetLocation();
			FRotator r2 = pCarrier->GetActorRotation();

			FVector result_pos, result_dir;
			AzureUtility::CalRelativePosInfo(FVector::ZeroVector, r1, t2, r2, result_pos, result_dir);
			
			resultRot = result_dir.Rotation();
		}
		else
		{
			MyPrintString2("TurnBehavior carrier is not valid", FLinearColor::Red);
		}
	}
	else
	{
		resultRot = r1;
	}

	return resultRot;
}

void TurnBehavior::SetCurRot(const FRotator & rot)
{
	FRotator abs_rot;
	if (m_isOnCarrier)//����ڴ��ϣ�pos�����λ��
	{
		if (m_carrier.IsValid())
		{
			AGamePlayer * pCarrier = m_carrier.Get();
			FVector t2 = pCarrier->GetFeetLocation();
			FRotator r2 = pCarrier->GetActorRotation();
			FVector abs_pos,abs_dir;
			AzureUtility::CalAbsPosInfo(FVector::ZeroVector, rot, t2, r2, abs_pos, abs_dir);
			
			abs_rot = abs_dir.Rotation();
		}
		else
		{
			MyPrintString2("TurnBehavior carrier is not invalid 2", FLinearColor::Red);
			return;
		}
	}
	else
	{
		abs_rot = rot;
	}

	if (false)
	{
		if (!AAzureEntryPoint::Instance)
			return;

		double st = AAzureEntryPoint::Instance->GetRealtimeSinceStartup();
		static double lastst = st;
		FString str = FString::Printf(TEXT("onturn setrot %0.3f %0.3f %0.3f --%0.3f %0.3f"), abs_rot.Yaw, m_Obj->GetActorRotation().Yaw,abs_rot.Yaw - m_Obj->GetActorRotation().Yaw, st,st-lastst);
		MyPrintString(str);

		lastst = st;
	}
	
	m_Obj->SetActorRotation(abs_rot);
}

bool TurnBehavior::Tick(float dt)
{
	if (!m_Obj.IsValid())
		return true;

	if (!m_pGamePlayer.IsValid())
		return true;

	if ((uint32)_flag & (uint32)GP_TURN_FLAG::GP_TURN_BLINK)
	{
		//MyPrintString("ObjTurn tick End 1");
		return true;
	}

	//if (m_pGamePlayer->move_sync_debug)
		//MyPrintString("ObjTurn tick");

	_timepassed += dt;
	if (_timepassed >= _totaltime)
	{
		if (Azure::TurnLog)
		{
			if (!AAzureEntryPoint::Instance)
				return true;

			double st = AAzureEntryPoint::Instance->GetRealtimeSinceStartup();
			FString str = FString::Printf(TEXT("=====OnObjectTurnEnd %0.3f"), _destdir.Yaw,st);
			UKismetSystemLibrary::PrintString(GEngine->GetWorld(), str,false);
		}		

		SetCurRot(_destdir);

		if ((uint32)_flag & (uint32)GP_TURN_FLAG::GP_TURN_STOP)
		{
			m_pGamePlayer->SetABStandTurnDir(0);
			//MyPrintString("TurnEnd Stop");
		}

		//MyPrintString("ObjTurn tick End");
			
		return true;
	}

	FRotator dir = FMath::Lerp(_startdir, _destdir, _timepassed / _totaltime);
	FRotator curdir = GetCurRot();
	dir.Roll = curdir.Roll;
	dir.Pitch = curdir.Pitch;
	SetCurRot(dir);

	if(m_isGamePlayer)
	{
		m_pGamePlayer->SetABStandTurnDir(_speed_for_anim);

		if (false)
		{
			if (!AAzureEntryPoint::Instance)
				return true;

			double st = AAzureEntryPoint::Instance->GetRealtimeSinceStartup();
			FString str = FString::Printf(TEXT("SetABStandTurnDirTick %0.2f %0.3f"), _speed_for_anim,st);
			MyPrintString(str);
		}
		
	}
	
	if (m_pGamePlayer.IsValid() && Azure::TurnLog)
	{
		if (!AAzureEntryPoint::Instance)
			return true;

		double st = AAzureEntryPoint::Instance->GetRealtimeSinceStartup();
		if (m_pGamePlayer->m_isCarrier)
		{
			FString str = FString::Printf(TEXT("OnObjectTurnTick(ship) %0.1f %0.1f -- %0.1f --%0.3f"), _startdir.Yaw, _destdir.Yaw, dir.Yaw, st);
			MyPrintString(str);
		}
		else
		{
			FString str = FString::Printf(TEXT("OnObjectTurnTick(monster) %0.1f %0.1f -- %0.1f --%0.3f"), _startdir.Yaw, _destdir.Yaw, dir.Yaw, st);
			MyPrintString(str);
		}
	}
	return false;
}

void TurnBehavior::OnRemoved(bool reUse)
{
	if (!reUse)
	{		
		if(m_pGamePlayer.IsValid())
			m_pGamePlayer->SetABStandTurnDir(0);

		//MyPrintString("OnRemoved not reUse SetABStandTurnDir 0");
	}
	else
	{
		//MyPrintString("OnRemoved reUse");
	}
	
	if (m_pGamePlayer.IsValid() && Azure::TurnLog)
	{
		if (!AAzureEntryPoint::Instance)
			return;

		double st = AAzureEntryPoint::Instance->GetRealtimeSinceStartup();
		if (m_pGamePlayer->m_isCarrier)
		{
			FString str = FString::Printf(TEXT("OnObjectTurnOnRemoved(ship) %d %0.3f"), reUse, st);
			MyPrintString(str);
		}
		else
		{
			FString str;
			if(m_pGamePlayer->IsHostPlayer())				
				str = FString::Printf(TEXT("OnObjectTurnOnRemoved(hostPlayer) %d %0.3f"), reUse, st);
			else if(m_pGamePlayer->IsElsePlayer())
				str = FString::Printf(TEXT("OnObjectTurnOnRemoved(elsePlayer) %d %0.3f"), reUse, st);
			else
				str = FString::Printf(TEXT("OnObjectTurnOnRemoved(monster) %d %0.3f"), reUse, st);
			MyPrintString(str);
		}
	}
}

