﻿#include "HPMoveBehavior.h"
#include "AzureObjectComponent.h"
#include "AzureUtility.h"
#include "AzureExport.h"
#include "Blueprint/AIBlueprintHelperLibrary.h"
#include "GameLogic/Player/GamePlayer.h"
#include "GameLogic/Player/GamePlayer_Util.h"
#include "Kismet/KismetSystemLibrary.h"
#include "Navigation/PathFollowingManager.h"
#include "GameLogic/Player/MyMovementComponent.h"

HPMoveBehavior* HPMoveBehavior::Create()
{
	HPMoveBehavior* ret = (HPMoveBehavior*)AzureBehaviorCache::GetInstance().GetBehavior(_type);

	if (ret == nullptr)
		ret = new HPMoveBehavior();
	ret->_create_framecount = GFrameNumber;

	return ret;
}
bool HPMoveBehavior::SetData(const FVector& vDest, float time, HPMoveBehaviorFlag flag, OnBehaviorFinish onFinish)
{
	if (!_objcomp.IsValid())
		return false;

	AGamePlayer * pActor = Cast<AGamePlayer>(_objcomp->GetOwner());
	if (!pActor)
		return false;
	_flag = flag;
	is_find_path_move = (uint32)flag & (uint32)HPMoveBehaviorFlag::UseUeFindPathSystem;
	_immediately_stop = (uint32)flag & (uint32)HPMoveBehaviorFlag::ImmediatelyStopWhenComplete;
	_use_acclerated = (uint32)flag & (uint32)HPMoveBehaviorFlag::UseAccelerated;
	_notSyncPosInMoveing = (uint32)flag & (uint32)HPMoveBehaviorFlag::NotSyncPosInMoving;

	_start = pActor->GetFeetLocation();
	_dest = vDest;
	m_delta = _dest - _start;
	_moveDir = m_delta.GetSafeNormal2D();
	dis2D = m_delta.Size2D();
	
	cur_time = 0.0f;
	if (FMath::IsNearlyZero(time))
	{
		useFixedSpeed = false;
		_moveSpeed = 0;
		UpdateMaxMoveSpeed(pActor);
	}
	else
	{
		useFixedSpeed = true;
		_moveSpeed = (_dest - _start).Size2D() / time;
		_moveVelocity = _moveDir * _moveSpeed;
		duration = time * 2.0f;//多加点时间，不能恰好，这个只是防止卡住的时间
	}
	

	is_use_ue_find_path = false;
	set_OnFinish(onFinish);
	
	if (!_notSyncPosInMoveing)
		pActor->SyncPushMoveToServer("HPMove SetData", ESyncMoveSendType::None, true, false);

	if (is_find_path_move)//先尝试寻路，如果不能寻路就直接用直接移动方式处理
	{
		UAIBlueprintHelperLibrary::SimpleMoveToLocation(pActor->GetController(), vDest);

		AController * p = pActor->GetController();
		if (p && UPathFollowingManager::IsFollowingAPath(*p))//判断是否能寻路
			is_use_ue_find_path = true;
	}
	
	

	if (false)
	{
		FString str = FString::Printf(TEXT("shanbin time [%0.3f] "), duration);
		MyPrintString(str);
	}
	
	_moveHasFinished = false;
	return true;
}

void HPMoveBehavior::ChangeParam(const FVector& vDest, float fMoveSpeed, bool bSkillMove /*= false*/)
{
	
}

void HPMoveBehavior::OnRemoved(bool replace)
{
	if (!_objcomp.IsValid())
		return;

	AGamePlayer * pActor = Cast<AGamePlayer>(_objcomp->GetOwner());
	if (!pActor)
		return;

	if (_notSyncPosInMoveing)
	{
		pActor->SyncPushMoveToServer("HPMove OnRemoveSkillEnd", ESyncMoveSendType::ForceSyncPos, true, false);
	}
	else
	{
		if (!replace || _immediately_stop)//自动寻路路点替换时候不停止
		{
			AController * p = pActor->GetController();
			if (p && UPathFollowingManager::IsFollowingAPath(*p))
			{
				UPathFollowingManager::StopMovement(*p);
			}

		}

		bool middleSegmentMove = (uint32)_flag & (uint32)HPMoveBehaviorFlag::MiddleSegment;
		if (replace || (middleSegmentMove && _moveHasFinished))
		{
			// 中间阶段移动，且已经完成了，会立刻接下一段位移，不用发停止协议
			pActor->SyncPushMoveToServer("MoveOver", ESyncMoveSendType::None, true, false);
		}
		else
		{
			pActor->SyncPushMoveToServer("MoveOver", ESyncMoveSendType::Stop, true, false);

		}
		
		pActor->SetTargetDesiredDir(FVector::ZeroVector);
	}
}



bool HPMoveBehavior::TickInternal(float dt)
{
	if (!HPMoveBase::TickInternal(dt))
		return false;

	if (!_objcomp.IsValid())
		return true;

	AGamePlayer * pActor = Cast<AGamePlayer>(_objcomp->GetOwner());
	if (!pActor)
		return true;

	bool moveIsOver = false;
	if (is_use_ue_find_path)
	{
		moveIsOver = TickUePathFind(dt);
	}
	else if (_use_acclerated)
	{
		moveIsOver = TickUseAcclerated(dt);
	}
	else
	{
		moveIsOver = TickUseFixedSpeed(dt);
	}
	_moveHasFinished = moveIsOver;

	if (moveIsOver)
		return true;

	if (pActor->IsHostOrElsePlayer())
	{
		pActor->SetTargetDesiredDir(_moveDir);
	}
	

	if (!_notSyncPosInMoveing)
	{
		if (pActor->m_fSyncPushMoveTimer >= Azure::host_send_sync_info_interval)//
		{
			pActor->SyncPushMoveToServer("HPMove Tick", ESyncMoveSendType::None, false, false);
		}
	}
	
	return moveIsOver;
}

bool HPMoveBehavior::TickUePathFind(float dt)
{
	AGamePlayer * pActor = Cast<AGamePlayer>(_objcomp->GetOwner());
	if (!pActor)
		return true;

	AController * p = pActor->GetController();
	if (!UPathFollowingManager::IsFollowingAPath(*p))
	{
		return true;
	}
	return false;
}

bool HPMoveBehavior::TickUseAcclerated(float dt)
{
	AGamePlayer * pActor = Cast<AGamePlayer>(_objcomp->GetOwner());
	if (!pActor)
		return true;

	FVector delta = pActor->GetFeetLocation() - _start;
	//移动超过终点
	bool hasReached = (delta.Size2D() > dis2D || FMath::IsNearlyZero(dis2D, 0.1f));
	bool isOver = hasReached;
	if (!_immediately_stop)
	{
		bool hasStoped = pActor->GetVelocity().Size2D() <= MIN_flt;
		isOver = isOver && hasStoped;
	}

	if (isOver)
	{
		if (_immediately_stop)
		{
			FVector testPos;
			testPos.X = _dest.X;
			testPos.Y = _dest.Y;
			testPos.Z = pActor->GetFeetLocation().Z;
			float z = GetGamePlayerPosZ(testPos, pActor);
			pActor->SetFeetLocation(_dest.X, _dest.Y, z);
			pActor->GetMyMovementComponent()->SetVelocity(FVector::ZeroVector);
		}
	}


	if(!hasReached)
	{
		pActor->AddMovementInput(_moveDir);
	}

	return isOver;
}

bool HPMoveBehavior::TickUseFixedSpeed(float dt)
{
	AGamePlayer * pActor = Cast<AGamePlayer>(_objcomp->GetOwner());
	if (!pActor)
		return true;

	UpdateMaxMoveSpeed(pActor);
	FVector delta = pActor->GetFeetLocation() - _start;
	float angle = AzureUtility::Angle(m_delta.GetSafeNormal2D(), delta.GetSafeNormal2D());

	//如果没有遇到碰撞发生侧移，且移动超过终点
	int iFinish = 0;
	bool bNeedSetDestPos = false;

	

	if ((delta.Size2D() > dis2D || FMath::IsNearlyZero(dis2D, 0.1f)) && angle <= 30.0f)
	{ 
		/*FVector testPos;
		testPos.X = _dest.X;
		testPos.Y = _dest.Y;
		testPos.Z = pActor->GetFeetLocation().Z;
		float z = GetGamePlayerPosZ(testPos, pActor);

		if (!_immediately_stop)
		{
			return true;
		}

		pActor->SetFeetLocation(_dest.X, _dest.Y, z);*/
		iFinish = 1; //正常沿直线没有发生碰撞侧移，超过或到达需要移动的距离，停止
	}
	else if (cur_time >= duration)
	{
		iFinish = 3;//撞到建筑没发生侧移，一直顶着建筑走
	}

	if (iFinish > 0)//因为各种原因需要停止
	{
		/*if (_immediately_stop)
		{
			pActor->GetMyMovementComponent()->SetVelocity(FVector::ZeroVector);
		}*/

		if (iFinish == 1)//正常走完了
		{
			if (_immediately_stop) //完成了这次移动，需要立马停下，不需要继续HPMove，而任务寻路有多个寻路点，一段走完了，需要继续走另一段
			{
				FVector testPos;
				testPos.X = _dest.X;
				testPos.Y = _dest.Y;
				testPos.Z = pActor->GetFeetLocation().Z;
				float z = GetGamePlayerPosZ(testPos, pActor);
				pActor->SetFeetLocation(_dest.X, _dest.Y, z);
				pActor->GetMyMovementComponent()->SetVelocity(FVector::ZeroVector);
			}
			//当_immediately_stop 为false的时候，需要继续下一段寻路HPMove，就不用将速度将为0
		}
		else if (iFinish == 2)//如果发生侧移，结束当前段，根据_immediately_stop的值直接结束或进入一下段
		{
			if (_immediately_stop)
			{
				pActor->GetMyMovementComponent()->SetVelocity(FVector::ZeroVector);
			}
			//当_immediately_stop 为false的时候，需要继续下一段寻路HPMove，就不用将速度将为0
		}
		else if (iFinish == 3)
		{
			if (_immediately_stop)
			{
				pActor->GetMyMovementComponent()->SetVelocity(FVector::ZeroVector);
			}
		}
		
		return true;
	}
	else
	{
		cur_time += dt;

		//pActor->AddMovementInput(_fixedMoveVelocity);

		pActor->GetCharacterMovement()->bRequestedMoveUseAcceleration = false;
		pActor->GetCharacterMovement()->RequestDirectMove(_moveVelocity, false);
	}

	if (false)
	{
		FVector pos = pActor->GetActorLocation();
		FString str = FString::Printf(TEXT("delta %0.1f disstart %0.1f dis2D %0.1f"), _moveVelocity.Size2D() * dt, delta.Size2D(), dis2D);
		MyPrintString(str);
	}

	if (false)
	{
		FVector pos = pActor->GetActorLocation();
		FString str = FString::Printf(TEXT("MoveBeh pos [%0.1f %0.1f %0.1f] "), pos.X, pos.Y, pos.Z);
		MyPrintString(str);
	}
	return false;
}

bool HPMoveBehavior::HasReachedDestination()
{
	return false;
}

void HPMoveBehavior::UpdateMaxMoveSpeed(AGamePlayer * pActor)
{
	if (!pActor) return;
	if (useFixedSpeed) return;
	float max_speed = pActor->GetCharacterMovement()->MaxWalkSpeed;
	if (_moveSpeed == max_speed) return;

	_moveSpeed = max_speed;
	_moveVelocity = _moveDir * max_speed;

	FVector currentPos = pActor->GetFeetLocation();
	float leftDis2d = (_dest - currentPos).Size2D();
	float useTime = leftDis2d / max_speed;
	duration = cur_time + useTime * 2; //多加点时间，不能恰好，这个只是防止卡住的时间
}



