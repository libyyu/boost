#pragma once

#include "AzureBehavior.h"
#include "UE4Related.h"
#include "AzureUtility.h"
#include "Gamelogic/Network/AzureNetDef.h"

class TurnBehavior : public AzureBehavior
{
protected:
	static constexpr  Azure::BehaviorType _type = Azure::BehaviorType::Turn;

	FRotator _startdir = FRotator::ZeroRotator;
	FRotator _destdir = FRotator::ZeroRotator;
	GP_TURN_FLAG _flag = GP_TURN_FLAG::GP_TURN;
	float _totaltime = 0;
	float _timepassed = 0;
	float _speed_for_anim = 0;

	TWeakObjectPtr<class AGamePlayer> m_carrier;
	bool m_isOnCarrier;

	TWeakObjectPtr<AActor> m_Obj;
	bool m_isGamePlayer;
	TWeakObjectPtr<class AGamePlayer> m_pGamePlayer;

public:

	TurnBehavior()
	{
		
	}

	static TurnBehavior* Create()
	{
		TurnBehavior* ret = (TurnBehavior*)AzureBehaviorCache::GetInstance().GetBehavior(_type);

		if (ret == nullptr)
			ret = new TurnBehavior();

		return ret;
	}

	Azure::BehaviorType get_Type() const override
	{
		return _type;
	}

	bool SetData(FVector vDest, bool limit_time, float param, GP_TURN_FLAG flag, class AGamePlayer * pCarrier, OnBehaviorFinish onFinish);

	virtual bool Tick(float dt) override;

	virtual void OnRemoved(bool reUse) override;

	FRotator GetCurRot();

	void SetCurRot(const FRotator & rot);
};