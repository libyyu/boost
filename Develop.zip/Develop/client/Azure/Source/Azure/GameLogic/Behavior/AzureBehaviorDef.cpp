﻿#include "AzureBehaviorDef.h"

namespace Azure
{
	float s_VERT_SLOPE_THRESH = 1.74533e-4f;					//	Vertical Slope Normal.Up Thresh: sin(90 - 0.01)度
	float s_SLOPE_UP_THRESH = 0.4226f;							//	Slope Normal.Up Thresh: sin(90 - 65)度
	float s_SLOPE_TAN_THRESH = 2.1445f;							//	Slope Tangent Thresh: tan(65)度
	float s_fMoveFloorDist = 2.f;	// MoveFloorDist: 2cm
	float s_fPlayerMoveExt = 450.0f;
	float s_fPlayerMoveHalfHei = 0.9f * UE_METRE_TRANS;
	float s_fPlayerMoveRaiseHei_Ground = 0.55f * UE_METRE_TRANS;//	某些地方拔高一定高度往前trace才能走上去，比如大台阶。。
	float s_fPlayerMoveRaiseHei_Air = 0.15f * UE_METRE_TRANS;

	float s_jump_up_gravityScale[3];
	float s_jump_down_gravityScale = 5.0f;

	float s_dash_time = 0.5f;//前闪后长按前向进入疾跑的时间
	float s_dash_time_move_input = 2.0f;//长按前向进入疾跑的时间
	float s_dash_angle = 30.0f;//输入进入疾跑的夹角
	float s_dash_angle_dodge = 90.0f;//闪避进入疾跑的夹角
	float s_dash_stop_force_time = 0.5f;//疾跑正常刹车禁止输入打断时间，在这段时间内，刹车动作不能被打断
	float s_dash_stop_turn180_force_time = 0.7f;//疾跑180度转向刹车禁止输入打断时间，在这段时间内，刹车动作不能被打断
	float s_dash_braking_friction_factor = 0.125f;			// 疾跑刹车因数
	float s_inputAxisMaxValue = 2.0f;
	float s_moveRightTurnControllYawScale = 2.0f;
	float s_waitNextSyncScale = 3.0f;
	float s_mesh_rel_rot = -90.0f;//actor或character模型在蓝图里面向前向需要转的角度

	float aim_walk_backward_angle_limit = 135.0f;//瞄准移动时角度超过多少算向后移动
	float start_walk_duration = 0.5f;//起步持续时间，即开始移动多久内算起步
	float start_walk_inpterrupt_time = 0.3f;//起步可移动时间
	float move_rot_speed = 400.0f;//移动转身的速度
	float turn_at_rate_angle = 45.0f; //左右移动的角度小于多少要转镜头
	float turn_speed_minus_angle = 30.0f; //转身需要减速，角度大于多少时开始插值
	float turn_speed_minus_scale = 0.1f;//转身减速180度时速度减的最大，系数配置

	float s_run_stop_force_time = 0.5f;//正常跑刹车禁止输入打断时间，在这段时间内，刹车动作不能被打断
	float s_run_stop_turn180_force_time = 0.5f;//正常跑180度转向刹车禁止输入打断时间，在这段时间内，刹车动作不能被打断
	float s_run_stop_speed_limit = 200.0f; //要播放正常跑刹车得达到的速度
	float run_turn180_speed_limit = 200.0f; //要播放正常跑刹车转向得达到的速度
	float run_stop_limit_time	  = 3.0f; //开始移动后多久才能播正常刹车动作，避免起步刹车频繁播

	float s_turn180_angle_limit = 150.0f;//要播放刹车转身，输入和速度差角度得大于多少

	float capsule_to_floor_dis = 2.15f;//ue4胶囊体到地板的距离
	float joystick_scale = 1.0f;	//摇杆的输入缩放

	float default_walk_speed = 200.0f;	//默认走路场景的走路速度
	float default_walk_time_limit = 5.0f; //默认走路摇杆推到底多久转到正常跑步速度
	float default_walk_input_limit = 1.0f; //走路摇杆推到多少算是推到底

	float config_runSpeed = 450.0f; //配置的正常跑速度
	float config_dashSpeed = 850.0f; //配置的疾跑速度

	bool bElsePlayerMoveSweep = true; //elsePlayer移动时是否与周围建筑等碰撞检测
	bool bPlayerServerMovePredict = true; //elsePlayer ServerMove是否预测开关
	float server_move_wait_sync_time = 0.1f;//不预测的时候额外的等待下次同步的时间

	float host_send_sync_info_interval = 0.1f;//主角每隔多久给服务器同步位置
	float player_receive_sync_info_interval = 0.5f;//其他玩家每隔多久收到服务器同步的位置
	float vehicle_receive_sync_info_interval = 0.1f;//其他载具每隔多久收到服务器同步的位置
	float npc_server_move_delay_rate = 1.2f; //npc 等待下一个包的系数
	float npc_min_sync_time = 0.2f; //npc server move最小同步时间
	float host_jump_sync_interval = 0.1f;//主角跳的时候同步间隔

	float host_turn_angle_limit = 60.0f;//服务器0.5s广播一次非关键帧，在连续转圈的操作下，同步表现不好看，所以在角度发生一定变化时改非关键帧为关键帧
	float host_turn_force_sync_time = 0.15f;//角度判断的时间间隔，如果和上次的角度超过host_turn_angle_limit并且时间差超过host_turn_force_sync_time，就把这一次改成关键帧

	float run_walk_gear_scale = 200.0f / 450.0f;//这个数是走路档位缩放比，用来限制输入的大小，走路速度如果小于200（走配置），则固定在200，大于200，小于450，则固定在450

	float npc_lookat_angle_stop = 10.0f;//转向到多少的时候停止转向
	float npc_lookat_return_origin_time = 1.0f;//转向后，角色离开多久回到原转向
	float npc_lookat_near_dis = 100.0f; //距离过近后直接转向，不用转身过程
	float npc_lookat_near_angle = 45.0f; //距离过近后因为动画导致的骨骼抖动会使站在原地，npc都会左右转，判断角度差低于这个值就不再转了

	float npc_lookat_dis_delta = 10.0f;//距离容差值，因为是有动画，骨头是动的，站着不同距离也会有轻微改变，导致在距离边界处存在抖动可能，加个容差防抖
	float npc_lookat_angle_delta = 5.0f;//角度容差值，防抖

	float host_lookat_npc_dis_limit = 450.0f;  //主角盯NPC的距离限制
	float host_lookat_npc_angle_limit = 60.0f; //主角盯NPC的角度限制

	float trace_water_up_dis = 90.0f;//打线检测一个点是否在water surface上向上的位置 cm
	float trace_water_dis = 500.0f;//打线检测一个点是否在water surface上打线的距离 cm
	float trace_water_max_dis = 100000.0f;//打线检测一个点所在water surface的打线最远距离 cm
	float trace_sea_dis = 30000.0f;

	bool s_moveRightNotTurn = true; //主角左右移动的时候是否只是平移，不绕弧运动

	float npc_sync_rotate_smooth = 0.25f;//npc object move时的服务器时间间隔，客户端根据这个来做旋转平滑

	bool b_player_move_show = false;//显示player_move移动协议Log
	bool print_camera_debug = false; //打印相机调试信息

	float ai_move_interval = 0.25f;//服务器AI移动tick间隔


	//动画蓝图效率优化后提炼出来的可能需要修改的参数值 REFCX-9320 动画蓝图效率优化
	float aim_pitch_anim_angle = 42.0f;//aimoffset里pitch的角度
	float aim_factor_blend_time = 0.2f;//aim的融合时间

	float facetarget_delay = 0.5f; //facetarget blend time
	FString ArmAlphaStr = "ArmAlpha";
	float bodyTurnMinAngle = 30.0f;
	float bodyTurnLimitAngle = 170.0f;

	float leanAdjustAngle = 45.0f; //防止lean过头回调的角度
	float leanSpeedGait_1 = 240.0f;
	float leanAnimAngle = 40.0f; //动画里aimoffset的角度

	float blockforward_angle = 80.0f;//前后区分的界限，用两个角度来缓冲
	float blockbackward_angle = 100.0f;//前后区分的界限，用两个角度来缓冲

	FString tag_update_aim = "AnimBPUpdateAim";//需要调用update aim的NPC

	float JoystickPressSendInterval = 0.25f; //joystick 摇杆发送间隔

	float start_move_key_time = 0.267f; //为了播elsePlayer起步动作能衔接上，必须在发完StartMove后起步动画(持续0.2s多一点)播完前发一个关键帧(间隔0.1s)，否则下一个移动协议0.5s才到，动画播完了 

	bool cam_locktarget_follow_target_only = true;//有锁定目标的情况下，移动是否只和锁定目标有关的开关


	///cam protect 镜头裙底和谐参数 start
	FString CamProtectBoneName1 = "Bip001-Pelvis";
	FString CamProtectBoneName2 = "Bip001-Spine";
	

	float CamProtect_AngleIn = 40.0f;//俩角不一样大，留个缓冲，防止在临界区来回进出
	float CamProtect_AngleOut = 60.0f;

	
	FString CamProtectMatParamName1 = "Fresnel_glow";
	FString CamProtectMatParamName2 = "Fresnel_Alpha";
	FString CamProtectMatParamName3 = "Fresnel_lev1";
	float CamProtect_Param1_Min = 0.01f;
	float CamProtect_Param1_Max = 1.2f;

	float CamProtect_Param2_Min = 0.01f;
	float CamProtect_Param2_Max = 1.f;

	float CamProtect_Param3_Min = 0.01f;
	float CamProtect_Param3_Max = 5.f;

	bool bTickCamAngleForTransparentMaterial = true;
	///cam protect 镜头裙底和谐参数 end

	bool TurnLog = false;

	float SwimWaterSurfaceAngle = 45.0f;

	float SwimInWaterSocketZOffset = 20.0f;//根据在水里的身高，判断是否入水和出水，但是出水要多判断一点，要不会在入水出水间来回抖动，这个就是在水里时判断出水，多判断的那一点
}