#include "HPVehicleJoystickMoveBehavior.h"
#include "AzureObjectComponent.h"
#include "AzureUtility.h"
#include "GameLogic/Input/AzureInputCtrl.h"
#include "GameLogic/Player/GamePlayer.h"
#include "GameLogic/Player/VehicleCharacter.h"
#include "GameLogic/Player/CarrierCharacter.h"
#include "AzureTimeManager.h"

HPVehicleJoystickMoveBehavior* HPVehicleJoystickMoveBehavior::Create()
{
	HPVehicleJoystickMoveBehavior* ret = (HPVehicleJoystickMoveBehavior*)AzureBehaviorCache::GetInstance().GetBehavior(_type);
	if (ret == nullptr)
		ret = new HPVehicleJoystickMoveBehavior();

	ret->_create_framecount = GFrameNumber;
	return ret;
}

bool HPVehicleJoystickMoveBehavior::SetData(OnBehaviorFinish onFinish, float fMoveSpeed, bool _onlyAcceptNotManualInput/* = false*/)
{
	onlyAcceptNotManualInput = _onlyAcceptNotManualInput;
	lastHasInput = true;
	set_OnFinish(onFinish);

	if (!_objcomp.IsValid())
		return false;
	
	AGamePlayer* pActor = Cast<AGamePlayer>(_objcomp->GetOwner());

	if (!pActor)
		return false;

	if (pActor) {
		if (IsCarrierGamePlayer())
		{
			pActor->SyncPushMoveToServer("HPCarrierJoystick Start", ESyncMoveSendType::StartMove, true, false);
		}
		else
			pActor->SyncPushMoveToServer("HPVehicleJoystick Start", ESyncMoveSendType::StartMove, true, false);
	}

	return true;
}

bool HPVehicleJoystickMoveBehavior::IsCarrierGamePlayer() const
{
	if (!_objcomp.IsValid())
		return false;

	AGamePlayer* pActor = Cast<AGamePlayer>(_objcomp->GetOwner());
	if (!pActor) return false;
	return pActor->IsCarrierGamePlayer();
}

void HPVehicleJoystickMoveBehavior::OnRemoved(bool replace)
{
	
}

bool HPVehicleJoystickMoveBehavior::TickInternal(float dt)
{
	if (!HPMoveBase::TickInternal(dt))
		return false;
	
	if (!_objcomp.IsValid())
		return true;
	AGamePlayer* pActor = Cast<AGamePlayer>(_objcomp->GetOwner());
	// �ʹ�����ͬһ֡tick����
	if (_create_framecount == GFrameNumber)
		return false;

	if (pActor->IsA<ACarrierCharacterBase>()) {
		return TickVehicleMove(dt);
	}
	else {
		return true; //ֱ�ӽ���
	}

}


bool HPVehicleJoystickMoveBehavior::TickVehicleMove(float dt)
{
	if (!_objcomp.IsValid())
		return true;

	FVector2D v = onlyAcceptNotManualInput 
		? AzureInputCtrl::GetInstance().GetNotManualJoyStickValue() : AzureInputCtrl::GetInstance().GetJoyStickValue();
	
	ACarrierCharacterBase* pActor = Cast<ACarrierCharacterBase>(_objcomp->GetOwner());
	pActor->ApplyInputVector(v);
	bool b_over = pActor->CheckEndJoystickMove();
	bool hasInput = pActor->HasInput();
	bool releaseInputThisFrame = !hasInput && lastHasInput;
	bool syncPosInterval = pActor->m_fSyncPushMoveTimer >= Azure::host_send_sync_info_interval;
	bool isKeyFrame = b_over || releaseInputThisFrame;

	bool needSyncPos = syncPosInterval || releaseInputThisFrame || b_over;
	if (needSyncPos)//
	{
		ESyncMoveSendType sendType = ESyncMoveSendType::None;
		if (b_over)
		{
			sendType = ESyncMoveSendType::Stop;
		}
		else if (pActor->GetCharacterMovement()->IsFalling())
		{
			sendType = ESyncMoveSendType::Jumpping;
		}
		else if(releaseInputThisFrame || !hasInput)
		{
			sendType = ESyncMoveSendType::LeaveMaxSpeed;
		}

		pActor->SyncPushMoveToServer("HPVehicleJoystick Tick", sendType,  isKeyFrame, false);
	}
	lastHasInput = hasInput;
	return b_over;
}


