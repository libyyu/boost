﻿#include "HPArcMoveBehavior.h"
#include "AzureObjectComponent.h"
#include "AzureUtility.h"
#include "GameLogic/Player/GamePlayer.h"
#include "GameLogic/Player/AnimalVehicleCharacter.h"
#include "GameLogic/Player/GamePlayer_Util.h"
#include "DrawDebugHelpers.h"


bool HPArcMoveBehavior::SetData(FVector vDest, FVector vO, float s, OnBehaviorFinish onFinish)
{
	if (!_objcomp.IsValid())
		return false;

	AGamePlayer * pActor = Cast<AGamePlayer>(_objcomp->GetOwner());
	if (!pActor)
		return false;
	m_vDest = vDest;
	m_vO = vO;
	if (s <= 0)
	{
		s = pActor->GetMovementComponent()->GetMaxSpeed();
	}
	m_fSpeed = s;
	FVector curpos = pActor->GetFeetLocation();
	m_vStart = curpos;
	FVector crossA = FVector::CrossProduct(curpos - m_vO, vDest - m_vO);
	curpos.Z = 0;
	vO.Z = 0;
	vDest.Z = 0;
	
	float a = AzureUtility::AngleBetweenTwoDir((curpos - vO), (vDest - vO));
	m_totalMoveAngle = a;

	a = FMath::DegreesToRadians(a);
	float radius = (curpos - vO).Size();
	m_ftime = a * radius / s;
	m_accumulativeTime = 0;
	m_overTime = m_ftime + FMath::Max<float>(2.0f, m_ftime*0.2f);
	m_fAngularVelocity = (crossA.Z > 0 ? 1 : -1) * s / radius;

	//Debug.Log(string.Format("dst is {0}", vDest));

	//Debug.Log(string.Format("dst1 in c# is {0}", (vDest - vO).magnitude));
	//Debug.Log(string.Format("dst2 in c# is {0}", (curpos - vO).magnitude));

	pActor->SyncPushMoveToServer("BeginArcMove", ESyncMoveSendType::None, true, false);

	set_OnFinish(onFinish);

	if (AAnimalVehicleCharacter * pAnimVehicle = Cast<AAnimalVehicleCharacter>(pActor))
	{
		FVector destVerticleLine = vDest - vO;
		destVerticleLine.Z = 0;
		destVerticleLine.Normalize();
		FVector desiredDir = FVector::CrossProduct(FVector::UpVector, destVerticleLine) * (crossA.Z > 0 ? 1 : -1);
		pAnimVehicle->SetFixedDesiredDir(true, desiredDir);
	}

	return true;
}
void HPArcMoveBehavior::OnRemoved(bool replace)
{
	if (!_objcomp.IsValid())
		return;

	AGamePlayer * pActor = Cast<AGamePlayer>(_objcomp->GetOwner());
	if (!pActor)
		return;

	if (!replace)
		pActor->SyncPushMoveToServer("MoveOver", ESyncMoveSendType::None, true, false);

	if (AAnimalVehicleCharacter * pAnimVehicle = Cast<AAnimalVehicleCharacter>(pActor))
	{
		pAnimVehicle->SetFixedDesiredDir(false, FVector::ForwardVector);
	}
}


static FVector lastPos;
static FVector lastRequestV;
bool HPArcMoveBehavior::TickInternal(float dt)
{
	if (!HPMoveBase::TickInternal(dt))
		return false;

	if (!_objcomp.IsValid())
		return true;

	AGamePlayer * pActor = Cast<AGamePlayer>(_objcomp->GetOwner());
	if (!pActor)
		return true;

	auto SnapPosToSupportPlane = [](FVector &inOutPos)->bool
	{
		float Height = 0;
		if (!AzureUtility::GetSupportPlaneHeight(Height, inOutPos + FVector::UpVector*300, 20, 500))
			return false;
		inOutPos.Z = Height;
		return true;
	};
	FVector currentPos = pActor->GetFeetLocation();

	float accumulalativeMoveAngle = AzureUtility::AngleBetweenTwoDir((currentPos - m_vO), (m_vStart - m_vO));
	m_accumulativeTime += dt;
	if (m_accumulativeTime >= m_overTime || accumulalativeMoveAngle >= (m_totalMoveAngle-dt*m_fAngularVelocity))
	{
		// 保持移动，避免接自动寻路卡一下
		pActor->GetCharacterMovement()->RequestDirectMove(pActor->GetActorForwardVector()*m_fSpeed, false);
		pActor->SyncPushMoveToServer("ArcMove", ESyncMoveSendType::None, true);
		return true;
	}
	FVector newPos = AzureUtility::RotateAround(currentPos, m_vO, FVector::UpVector, FMath::RadiansToDegrees(dt*m_fAngularVelocity));

	FVector dir1 = newPos - currentPos;
	if (dir1 != FVector::ZeroVector)
		pActor->SetActorRotation(FRotationMatrix::MakeFromX(dir1).ToQuat());
	dir1.Normalize();
	FVector MoveVelocity = dir1 *m_fSpeed;

	pActor->GetCharacterMovement()->bRequestedMoveUseAcceleration = false;
	pActor->GetCharacterMovement()->RequestDirectMove(MoveVelocity, false);

	if ((pActor->m_fSyncPushMoveTimer >= Azure::host_send_sync_info_interval))
	{
		pActor->SyncPushMoveToServer("ArcMove");
	}


	lastPos = currentPos;
	lastRequestV = dir1;
	return false;

}


