#pragma once
#include "HPMoveBase.h"
#include "UE4Related.h"

class HPJumpBehavior : public HPMoveBase
{
protected:
	static constexpr  Azure::BehaviorType _type = Azure::BehaviorType::HPJump;

	float gravity_scale_down = 2.5f;
public:
	HPJumpBehavior()
	{
	
	}

	Azure::BehaviorType get_Type() const override
	{
		return _type;
	}

	static HPJumpBehavior* Create();

	bool SetData(float gravity_scale_down, OnBehaviorFinish onFinish, bool isSkillMove);

	virtual void OnRemoved(bool replace) override;

protected:

	virtual bool TickInternal(float dt) override;

};