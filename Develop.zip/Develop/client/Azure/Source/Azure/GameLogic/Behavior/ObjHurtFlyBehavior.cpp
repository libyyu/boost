﻿//#include "Azure.h"
#include "ObjHurtFlyBehavior.h"
#include "AzureObjectComponent.h"
#include "UE4Related.h"
#include "AzureUtility.h"
#include "Kismet/KismetSystemLibrary.h"
#include "GameLogic/Player/GamePlayer.h"
#include "GameLogic/Player/GamePlayer_Util.h"
#include "GameLogic/Player/MyMovementComponent.h"

using namespace Azure;

//////////////////////////////////////////////////////////////////////////
//击飞，分为3个段配置：第一段 抛物线上升段 第二段 漂浮(高度不变)移动段 第三段 抛物线下降段
//说明：第一段和第三段不一定是一个抛物线，如果第一段持续时间不为0，则1段和3段是两个不同参数的抛物线，加速度都不一样，如果没配，就是一个抛物线
//     由于水平距离和时间都有配置，水平方向的速度都不一定相同
//在技能段里的配置项：
//x--3段水平总距离
//h--击飞高度
//t--3段总时间
//x1--第一段水平距离
//t1--第一段时间
//x2--第二段水平距离
//t2--第二段时间

//参数说明：vDest是根据x结合场景阻挡和高度算出来的最终落地点
//如果是载具上，vDest传进来的这里也是绝对坐标
bool ObjHurtFlyBehavior::SetData(const FVector & vDest, float time_t, float h, float dis_x1,float time_t1,float dis_x2,float time_t2, AGamePlayer * pCarrier, OnBehaviorFinish onFinish)
{
	if (!_objcomp.IsValid())
		return false;

	AGamePlayer * pObj = Cast<AGamePlayer>(_objcomp->GetOwner());
	if (!pObj)
		return false;

	set_OnFinish(onFinish);

	m_carrier = pCarrier;
	m_isOnCarrier = (pCarrier != nullptr);

	//关重力
	m_gravityScale = pObj->GetCharacterMovement()->GravityScale;
	pObj->GetCharacterMovement()->GravityScale = 0.0f;

	//pObj->GetCharacterMovement()->SetMovementMode(MOVE_Falling);
	
	
	pObj->GetMyMovementComponent()->SetVelocity(FVector::ZeroVector);
	/////

	time = 0.0f;
	
	//计算各种参数
	if (m_isOnCarrier)
	{
		FVector abs_start = pObj->GetFeetLocation();
		FRotator abs_rot = pObj->GetActorRotation();
		CalRelPosRot(abs_start,abs_rot,m_vStart,m_relRot);

		FVector abs_dest = vDest;
		FRotator tmpRot;
		CalRelPosRot(abs_dest, abs_rot, m_vDest, tmpRot);
	}
	else
	{
		m_vStart = pObj->GetFeetLocation();
		m_vDest = vDest;
	}	

	m_x = (m_vDest - m_vStart).Size2D();
	m_x_dir = (m_vDest - m_vStart).GetSafeNormal2D();

	m_t = time_t;
	
	topZ = m_vStart.Z + h;
	
	b_z_error = false;
	if (topZ < m_vDest.Z || h <= 0)//topZ必须大于start,不小于dest
	{
		b_z_error = true;
	}

	bool time_error = false;
	if (time_t1 + time_t2 >= time_t)
		time_error = true;

	//s = v0 * t + 1/2 * a * t * t
	//计算v0和a,才能计算出最后的Z值
	//这里策划要配置水平方向距离，上升的高度，时间，所以a不是正常重力加速度9.8，根据目标点的位置会有不同，计算比较绕，详情
	//咨询姜志伟

	m_x1 = dis_x1;
	if (m_x1 > m_x)
		m_x1 = m_x;

	m_x2 = dis_x2;
	if (m_x1 + m_x2 > m_x)
		m_x2 = m_x - m_x1;

	m_x3 = m_x - m_x1 - m_x2;

	m_t1 = time_t1;
	if (m_t1 > m_t)
		m_t1 = m_t;

	m_t2 = time_t2;
	if (m_t1 + m_t2 > m_t)
		m_t2 = m_t - m_t1;

	m_t3 = m_t - m_t1 - m_t2;

	if (m_t > 0.0f && !b_z_error && !time_error)
	{
		if (time_t1 > 0)//t1不为0，两段抛物线不同,计算m_t1,m_t3,m_a1,m_a3,m_v0_1
		{
			m_t1 = time_t1;
			m_a1 = -2 * h / (time_t1 * time_t1);//m_a1是负的，朝下
			m_v0_1 = -m_a1 * time_t1;

			m_t3 = m_t - time_t1 - time_t2;
			float dz3 = FMath::Abs(m_vDest.Z - topZ);
			m_a3 = -2 * dz3 / (m_t3 * m_t3);

			if (false)
			{
				FString str = FString::Printf(TEXT("HurtFly Start 1 t1 t3 ma1 ma3 mv0: %0.3f %0.3f %0.1f %0.1f %0.1f"), m_t1, m_t3,m_a1,m_a3,m_v0_1);
				MyPrintString(str);
			}			
		}
		else//t1为0，两段抛物线是同一个，根据参数计算m_t1,m_t3,m_a1,m_a3,m_v0_1,m_x1,m_x3
		{
			float t1t3 = m_t - time_t2;

			float dz1 = FMath::Abs(m_vStart.Z - topZ);//就是h
			float dz3 = FMath::Abs(m_vDest.Z - topZ);
			float pt = FMath::Sqrt(dz3 / dz1);
			float t1 = t1t3 / (1 + pt);
			m_a1 = -2 * dz1 / (t1 * t1);
			m_a3 = m_a1;

			float s = h;
			m_v0_1 = h / t1 - 0.5f * m_a1 * t1;

			m_t1 = t1;
			m_t3 = t1t3 - m_t1;	

			float x1x3 = m_x - m_x2;
			m_x1 = x1x3 * t1 / t1t3;
			m_x3 = x1x3 - m_x1;

			if (false)
			{
				FString str = FString::Printf(TEXT("HurtFly Start 2 t1 t3 ma1 ma3 mv0: %0.3f %0.3f %0.1f %0.1f %0.1f"), m_t1, m_t3, m_a1, m_a3, m_v0_1);
				MyPrintString(str);

				str = FString::Printf(TEXT("HurtFly Start 2 x1 x3: %0.1f %0.1f"), m_x1,m_x3);
				MyPrintString(str);
			}
		}
		
		m_t2 = time_t2;
	}
	else if (b_z_error)
	{
		//如果Z方向距离有问题，即topZ不比start 和 dest都高，就在tick里线性插值位置
		MyPrintString("HurtFly Z error!!!!!!");
	}
	else//如果没配持续时间则tick时会直接结束
	{
		m_t = 0.0f;

		MyPrintString("HurtFly t error!!!!!!");
	}

	if (false)
	{
		FString str = FString::Printf(TEXT("HurtFly Start %0.3f"), pObj->GetCharacterMovement()->GravityScale);
		MyPrintString(str);
	}

	if (m_isOnCarrier && false)
	{
		FString str = FString::Printf(TEXT("HurtFlyOnShip m_vStart %0.1f %0.1f %0.1f"), m_vStart.X, m_vStart.Y, m_vStart.Z);
		MyPrintString2(str,FLinearColor::Yellow);

		str = FString::Printf(TEXT("HurtFlyOnShip m_vDest %0.1f %0.1f %0.1f"), m_vDest.X, m_vDest.Y, m_vDest.Z);
		MyPrintString(str);

		str = FString::Printf(TEXT("HurtFlyOnShip m_x_dir.Yaw m_relRot.Yaw %0.1f %0.1f"), m_x_dir.Rotation().Yaw,m_relRot.Yaw);
		MyPrintString(str);	
	}

	return true;
}

void ObjHurtFlyBehavior::CalRelPosRot(const FVector & abs_pos, const FRotator & abs_rot,
	FVector & result_pos, FRotator & result_rot)
{
	//这里计算开始位置和结束位置，如果没在船上，就是绝对位置
	//如果在船上，tick的是相对位置，再把相对位置转为绝对位置

	if (m_isOnCarrier)
	{
		if (m_carrier.IsValid())
		{
			AGamePlayer * pCarrier = m_carrier.Get();
			FVector t2 = pCarrier->GetFeetLocation();
			FRotator r2 = pCarrier->GetActorRotation();
			FVector rel_dir;
			AzureUtility::CalRelativePosInfo(abs_pos, abs_rot, t2, r2, result_pos, rel_dir);
			result_rot = rel_dir.Rotation();
		}
		else
		{
			MyPrintString2("ObjHurtFlyBehavior carrier is not valid", FLinearColor::Red);
		}
	}
	else
	{
		result_pos = abs_pos;
		result_rot = abs_rot;
	}
}

void ObjHurtFlyBehavior::SetObjPos(AGamePlayer * pObj,const FVector & pos)
{
	if (m_isOnCarrier)
	{
		if (m_carrier.IsValid())
		{
			AGamePlayer * pCarrier = m_carrier.Get();
			FVector t2 = pCarrier->GetFeetLocation();
			FRotator r2 = pCarrier->GetActorRotation();
			
			FVector abs_pos;
			FVector abs_dir;
			
			AzureUtility::CalAbsPosInfo(pos,m_relRot, t2, r2, abs_pos, abs_dir);

			pObj->SetFeetLocation2(abs_pos);
			pObj->SetActorRotation(abs_dir.Rotation());

			if (false)
			{
				FString str = FString::Printf(TEXT("HurtFlyOnShip SetPos %0.1f %0.1f %0.1f"), abs_pos.X, abs_pos.Y, abs_pos.Z);
				MyPrintString(str);
			}
		}
		else
		{
			MyPrintString2("ObjHurtFlyBehavior carrier is not invalid 2", FLinearColor::Red);
			return;
		}
	}
	else
	{
		pObj->SetFeetLocation2(pos);
	}
}

FVector ObjHurtFlyBehavior::GetPosAfter(float dt)
{
	if (!_objcomp.IsValid())
		return m_vDest;

	AGamePlayer * pObj = Cast<AGamePlayer>(_objcomp->GetOwner());
	if (!pObj)
		return m_vDest;

	float nextTime = time + dt;
	if (nextTime >= m_t)
	{
		return m_vDest;
	}


	//先计算水平方向位置
	FVector pos;

	if (nextTime < m_t1)
	{
		float p = nextTime / m_t1;
		pos = m_vStart + m_x1 * p * m_x_dir;

		if (false)
		{
			FString str = FString::Printf(TEXT("HurtFly TickXZ 1 p %0.3f dis %0.1f"), p, (pos - m_vStart).Size2D());
			MyPrintString(str);
		}
	}
	else if (nextTime >= m_t1 && nextTime < m_t1 + m_t2)
	{
		float p = (nextTime - m_t1) / m_t2;
		pos = m_vStart + m_x1 * m_x_dir + m_x2 * p * m_x_dir;

		if (false)
		{
			FString str = FString::Printf(TEXT("HurtFly TickXZ 2 p %0.3f dis %0.1f"), p, (pos - m_vStart).Size2D());
			MyPrintString(str);
		}
	}
	else
	{
		float p = (nextTime - m_t1 - m_t2) / m_t3;
		pos = m_vStart + m_x1 * m_x_dir + m_x2 * m_x_dir + m_x3 * p * m_x_dir;

		if (false)
		{
			FString str = FString::Printf(TEXT("HurtFly TickXZ 3 p %0.3f dis %0.1f"), p, (pos - m_vStart).Size2D());
			MyPrintString(str);
		}
	}

	//再单独计算Z方向自由落体运动
	if (!b_z_error)
	{
		if (nextTime < m_t1)
		{
			float s1 = m_v0_1 * nextTime + 0.5f * m_a1 * nextTime * nextTime;
			pos.Z = s1 + m_vStart.Z;

			if (false)
			{
				FString str = FString::Printf(TEXT("HurtFly Tick 1 m_t1--%0.3f, posZ--%0.1f,time--%0.3f"), m_t1, pos.Z, nextTime);
				MyPrintString(str);
			}
		}
		else if (nextTime >= m_t1 && nextTime < m_t1 + m_t2)
		{
			pos.Z = topZ;

			if (false)
			{
				FString str = FString::Printf(TEXT("HurtFly Tick 2 m_t1--%0.3f, m_t1 + m_t2 -- %0.3f,posZ--%0.1f, time--%0.3f"), m_t1, m_t1 + m_t2, pos.Z, nextTime);
				MyPrintString(str);
			}
		}
		else
		{
			float tmp_t = nextTime - m_t1 - m_t2;
			float s2 = 0.5f * (-m_a3) * tmp_t * tmp_t;//第二段抛物线，从最高点向下，v0* t + 1/2* a * t * t,v0是0,加速度用-a（a是负值，-a是正值），这样算出来的s2是个距离
			pos.Z = topZ - s2;

			if (false)
			{
				FString str = FString::Printf(TEXT("HurtFly Tick 3  m_t1 + m_t2 -- %0.3f,posZ--%0.1f, time--%0.3f,tmpt -- %0.3f"), m_t1 + m_t2, pos.Z, nextTime, tmp_t);
				MyPrintString(str);
			}
		}
	}
	else
	{
		// 直接插值移动
		if (nextTime < m_t) {
			float p = nextTime / m_t;
			pos.Z = m_vStart.Z * (1 - p) + m_vDest.Z * p;
		}
	}

	if (false)
	{
		FString str = FString::Printf(TEXT("HurtFly Tick %0.3f"), pObj->GetCharacterMovement()->GravityScale);
		MyPrintString(str);
	}
	return pos;
}

bool ObjHurtFlyBehavior::Tick(float dt)
{
	if (!_objcomp.IsValid())
		return true;

	AGamePlayer * pObj = Cast<AGamePlayer>(_objcomp->GetOwner());
	if (!pObj)
		return true;

	time += dt;
	if (time >= m_t)
	{
		SetObjPos(pObj,m_vDest);
		return true;
	}

	FVector position = GetPosAfter(0);
	SetObjPos(pObj, position);
	return false;
}

void ObjHurtFlyBehavior::OnRemoved(bool replace)
{
	if (!_objcomp.IsValid())
		return;

	AGamePlayer * pObj = Cast<AGamePlayer>(_objcomp->GetOwner());
	if (pObj && pObj->GetCharacterMovement())
		pObj->GetCharacterMovement()->GravityScale = m_gravityScale;

	m_carrier = nullptr;
	m_isOnCarrier = false;

	if (false)
	{
		FString str = FString::Printf(TEXT("HurtFly Remove %0.3f"), pObj->GetCharacterMovement()->GravityScale);
		MyPrintString(str);
	}
}

