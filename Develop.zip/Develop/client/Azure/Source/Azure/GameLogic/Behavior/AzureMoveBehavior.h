﻿#pragma once

#include "AzureBehavior.h"

//////////////////////////////////////////////////////////////////////////
class AzureMoveBehavior : public AzureBehavior
{
protected:
	static constexpr Azure::BehaviorType _type = Azure::BehaviorType::Move;

	FVector m_vDest;
	FVector m_curPos;
	float m_fSpeed;
	float m_fLastSpeed;

	FVector m_vDir;
	float m_fDist;
	float m_fTotalDist;
	FRotator _startRot;
	FRotator _destRot;

	FVector m_vStartDir;
	bool isGamePlayerMove;

	bool m_bTraceGround;

	TWeakObjectPtr<class AGamePlayer> m_carrier;
	bool m_isOnCarrier;
	float mCarrierSpeedScale;

	TWeakObjectPtr<class AGamePlayer> m_pGamePlayer;
	TWeakObjectPtr<AActor> m_pObj;

	int m_iUpdatePitch;

#pragma region Carrier
	int32 m_flag; 
	int32 m_flag2;
	uint32 m_extend_data2;
	bool m_carrier_move = false;

	FRotator m_startdir = FRotator::ZeroRotator;
	FRotator m_destdir = FRotator::ZeroRotator;

	GP_TURN_FLAG m_turnflag = GP_TURN_FLAG::GP_TURN;
	float m_totaltime = 0;
	float m_timepassed = 0;
	float m_speed_for_anim = 0;

	bool m_need_turn = false;
#pragma endregion
public:

	AzureMoveBehavior()
	{
		mCarrierSpeedScale = 1.0f;
	}

	static AzureMoveBehavior* Create()
	{
		AzureMoveBehavior* ret = (AzureMoveBehavior*)AzureBehaviorCache::GetInstance().GetBehavior(_type);

		if (ret == nullptr)
			ret = new AzureMoveBehavior();

		return ret;
	}

	Azure::BehaviorType get_Type() const override
	{
		return _type;
	}

	bool SetData(FVector vDest, float speed, bool bTraceGround, class AGamePlayer * pCarrier, int updatePitch, OnBehaviorFinish onFinish);
	
	bool SetData_Carrier(const FVector & vDest, float speed, bool bTraceGround, class AGamePlayer * pCarrier, int updatePitch, bool needTurn, const FVector vDirDest, bool limit_time, float param, GP_TURN_FLAG turnFlag, int32 flag, int32 flag2, uint32 extend_data2, OnBehaviorFinish onFinish);
	
	bool Tick(float dt) override;

	bool TickMove(float dt);
	bool TickTurn(float dt);


	virtual void OnRemoved(bool replace) override;

	void GetCurPosAndDir(FVector & pos, FVector & dir);
	void SetCurPos(const FVector & pos);
	void SetCurDir(const FVector & dir);
	
	void SetCurRot(const FRotator & rot);
	FRotator GetCurRot();

	bool GetCurPitch(const FVector& pos, const FVector& dir, float& Pitch);

	void SetTraceGround(bool value) { m_bTraceGround = value; }

	void DrawDestPos_SetData();
	void DrawTick();
	void DrawPosAndDir();

	float DealCarrierTickDis(float dt);
};

