﻿//#include "Azure.h"
#include "AzureMoveBehavior.h"
#include "AzureObjectComponent.h"
#include "UE4Related.h"
#include "AzureUtility.h"
#include "Kismet/KismetSystemLibrary.h"
#include "GameLogic/Player/GamePlayer.h"
#include "GameLogic/Player/GamePlayer_Util.h"
#include "Components/CapsuleComponent.h"
#include "DrawDebugHelpers.h"
#include "GameLogic/Player/CarrierCharacterBase.h"
using namespace Azure;

//////////////////////////////////////////////////////////////////////////

bool AzureMoveBehavior::SetData(FVector vDest, float s, bool bTraceGround, AGamePlayer * pCarrier, int updatePitch, OnBehaviorFinish onFinish)
{
	if (!_objcomp.IsValid())
		return false;

	m_pObj = Cast<AActor>(_objcomp->GetOwner());
	if (!m_pObj.IsValid())
		return false;

	_objcomp->RemoveBehavior(Azure::BehaviorType::ObjServerMove);
	
	m_carrier_move = false;
	m_need_turn = false;
	isGamePlayerMove = false;
	m_pGamePlayer = nullptr;
	if (m_pObj->IsA<AGamePlayer>())
	{
		m_pGamePlayer = Cast<AGamePlayer>(m_pObj);
		isGamePlayerMove = true;
		
		m_pGamePlayer->m_bNeedTickServerMoveRotation = false;
	}		

	set_OnFinish(onFinish);
	m_vDest = vDest;//如果在船上，vDest是相对坐标

	m_fSpeed = s;
	if (m_fSpeed <= 0.01f)//最后停止那下发的速度是0
	{
		if (m_fLastSpeed > 0.01f)
			m_fSpeed = m_fLastSpeed;
		else
		{
			//MyPrintString2("AzureMoveBehavior speed error !!!!!!!!", FLinearColor::Red);
			m_fLastSpeed = 0.0f;
		}
			

		//MyPrintString("StopFrame");
	}
	else
	{
		m_fLastSpeed = m_fSpeed;
	}

	m_iUpdatePitch = updatePitch;
	m_carrier = pCarrier;
	m_isOnCarrier = (pCarrier != nullptr);

	m_bTraceGround = bTraceGround;

	FVector vStartPos;
	GetCurPosAndDir(vStartPos,m_vStartDir);

	m_curPos = vStartPos;

	(vDest - vStartPos).ToDirectionAndLength(m_vDir, m_fDist);
	m_fTotalDist = m_fDist;

	if (isGamePlayerMove && m_pGamePlayer.IsValid())
	{
		USkeletalMeshComponent* SkeletalMesh = m_pGamePlayer->GetMesh();
		if (SkeletalMesh) {
			_startRot = SkeletalMesh->RelativeRotation;
			_destRot = _startRot;

			if (m_iUpdatePitch)
			{
				float angle = 0;
				FVector dir = m_pObj->GetActorForwardVector();
				if (GetCurPitch(m_vDest, dir, angle))
				{
					_destRot.Roll = angle;
				}
			}
		}
	}

	if(false)
	{
		if (!AAzureEntryPoint::Instance)
			return true;

		double st = AAzureEntryPoint::Instance->GetRealtimeSinceStartup();
		FVector unitdir = m_vDir.GetSafeNormal2D();
		FString str = FString::Printf(TEXT("AzureMove %0.1f %0.1f [%0.3f,%0.3f,%0.3f]---%0.3f"), unitdir.Rotation().Yaw, m_pObj->GetActorRotation().Yaw, m_vDir.X, m_vDir.Y, m_vDir.Z, st);
		MyPrintString(str);
	}
	
	if (false)
	{
		MyPrintString("start AzureMoveBehavior");
	}

	if (false)
	{
		DrawDestPos_SetData();
	}

	if (false)
	{
		if (!AAzureEntryPoint::Instance)
			return true;

		double st = AAzureEntryPoint::Instance->GetRealtimeSinceStartup();
		FString str = FString::Printf(TEXT("AzureMoveBehaviorSetData vDest %0.1f--%0.1f--%0.1f"), m_vDest.X, m_vDest.Y, m_vDest.Z);
		MyPrintString(str);
		str = FString::Printf(TEXT("AzureMoveBehaviorSetData vStartPos %0.1f--%0.1f--%0.1f"), vStartPos.X, vStartPos.Y, vStartPos.Z);
		MyPrintString(str);
		str = FString::Printf(TEXT("AzureMoveBehaviorSetData %0.3f--%0.3f"), (m_vDest - m_curPos).Size2D(),st);
		MyPrintString(str);
	}

	if (isGamePlayerMove && m_pGamePlayer.IsValid())
	{
		m_pGamePlayer->OnServerMoveBegin();
	}

	return true;
	// Debug.Log (string.Format ("MoveBehavior:SetData: SubType{0}, cur{1}, dest{2}, dist{3}, Dir{4}, speed{5}", eSubType, m_Trans.position, vDest, m_fDist, m_vDir, m_fSpeed));
}

bool AzureMoveBehavior::SetData_Carrier(const FVector & vDest, float speed, bool bTraceGround, class AGamePlayer * pCarrier, int updatePitch, bool needTurn, const FVector vDirDest, bool limit_time, float param, GP_TURN_FLAG turnFlag, int32 flag, int32 flag2, uint32 extend_data2, OnBehaviorFinish onFinish)
{
	if (!_objcomp.IsValid())
		return false;

	m_pObj = Cast<AActor>(_objcomp->GetOwner());
	if (!m_pObj.IsValid())
		return false;
	
	m_carrier_move = true;
	isGamePlayerMove = false;
	m_pGamePlayer = nullptr;
	if (m_pObj->IsA<AGamePlayer>())
	{
		m_pGamePlayer = Cast<AGamePlayer>(m_pObj);
		isGamePlayerMove = true;

		m_pGamePlayer->m_bNeedTickServerMoveRotation = false;
	}
	
	set_OnFinish(onFinish);
	m_vDest = vDest;//如果在船上，vDest是相对坐标

	m_fSpeed = speed;
	if (m_fSpeed <= 0.01f)//最后停止那下发的速度是0
	{
		if (m_fLastSpeed > 0.01f)
			m_fSpeed = m_fLastSpeed;
		else
		{
			m_fLastSpeed = 0.0f;
		}
	}
	else
	{
		m_fLastSpeed = m_fSpeed;
	}
	m_iUpdatePitch = updatePitch;
	m_carrier = pCarrier;
	m_isOnCarrier = (pCarrier != nullptr);
	m_bTraceGround = bTraceGround;
	
	m_flag = flag;
	m_flag2 = flag2;
	m_extend_data2 = extend_data2;

	FVector vStartPos;
	GetCurPosAndDir(vStartPos, m_vStartDir);

	m_curPos = vStartPos;
	

	(vDest - vStartPos).ToDirectionAndLength(m_vDir, m_fDist);
	m_fTotalDist = m_fDist;
	
	if (false)
	{
		FString str = FString::Printf(TEXT("SetDataCarrier %0.1f %0.1f %0.1f"), m_curPos.Z, m_pGamePlayer->GetFeetLocation().Z,m_fDist);
		MyPrintString(str);
	}

	if (isGamePlayerMove && m_pGamePlayer.IsValid())
	{
		USkeletalMeshComponent* SkeletalMesh = m_pGamePlayer->GetMesh();
		if (SkeletalMesh) {
			_startRot = SkeletalMesh->RelativeRotation;
			_destRot = _startRot;

			if (m_iUpdatePitch)
			{
				float angle = 0;
				FVector dir = m_pObj->GetActorForwardVector();
				if (GetCurPitch(m_vDest, dir, angle))
				{
					_destRot.Roll = angle;
				}
			}
		}
	}

	//朝向
	if (needTurn)
	{
		m_turnflag = turnFlag;
		FVector ue_vDest = vDirDest;
		VEC_UP(ue_vDest) = 0;
		if (ue_vDest.Size2D() < 1E-5f)
		{
			m_need_turn = false;
		}
		else
		{
			m_need_turn = true;
			ue_vDest.Normalize();
			m_destdir = ue_vDest.Rotation();
			m_startdir = m_pObj->GetActorRotation();

			float fDeltaAngle = FMath::FindDeltaAngleDegrees(m_startdir.Yaw, m_destdir.Yaw);
			float fspeed = param;

			if ((uint32)turnFlag & (uint32)GP_TURN_FLAG::GP_TURN_STOP)
			{
				//如果是停止，totalTime和timepassed不变，继续之前的计时
				m_speed_for_anim = fDeltaAngle / m_totaltime;
			}
			else
			{
				if (limit_time)
				{
					m_totaltime = param;
					m_speed_for_anim = fDeltaAngle / m_totaltime;

				}
				else if (fspeed <= 0.0f)
				{
					m_totaltime = 0.0f;
					m_speed_for_anim = 0;
				}
				else
				{
					m_totaltime = FMath::Abs(fDeltaAngle) / fspeed;
					m_speed_for_anim = fspeed;

					if (fDeltaAngle < 0.0f)
						m_speed_for_anim = -m_speed_for_anim;
				}

				m_timepassed = 0;
			}

			if ((uint32)turnFlag & (uint32)GP_TURN_FLAG::GP_TURN_BLINK)
			{
				SetCurRot(m_destdir);
			}
		}
	}
	else {
		m_need_turn = false;
	}
	
	if (false)
	{
		if (!AAzureEntryPoint::Instance)
			return true;

		double st = AAzureEntryPoint::Instance->GetRealtimeSinceStartup();
		FVector unitdir = m_vDir.GetSafeNormal2D();
		FString str = FString::Printf(TEXT("For Ship AzureMove %0.1f %0.1f [%0.3f,%0.3f,%0.3f]---%0.3f"), unitdir.Rotation().Yaw, m_pObj->GetActorRotation().Yaw, m_vDir.X, m_vDir.Y, m_vDir.Z, st);
		MyPrintString(str);
	}

	if (false)
	{
		MyPrintString("start AzureMoveBehavior");
	}

	if (false)
	{
		DrawDestPos_SetData();
	}

	if (false)
	{
		if (!AAzureEntryPoint::Instance)
			return true;

		double st = AAzureEntryPoint::Instance->GetRealtimeSinceStartup();
		FString str = FString::Printf(TEXT("For Ship AzureMoveBehaviorSetData vDest %0.1f--%0.1f--%0.1f"), m_vDest.X, m_vDest.Y, m_vDest.Z);
		MyPrintString(str);
		str = FString::Printf(TEXT("For Ship AzureMoveBehaviorSetData vStartPos %0.1f--%0.1f--%0.1f"), vStartPos.X, vStartPos.Y, vStartPos.Z);
		MyPrintString(str);
		str = FString::Printf(TEXT("For Ship AzureMoveBehaviorSetData %0.3f--%0.3f"), (m_vDest - m_curPos).Size2D(), st);
		MyPrintString(str);
	}
	
	if(isGamePlayerMove)
	{//船移动有控制舵角度
		bool hasValidDesirdYaw = (flag2 & (uint32)GP_MOVE_FLAG_EXTEND::GP_MOVE_EXTEND_HasDesiredYaw) != 0;
		// extenddata2低16位保存目标朝向
		ACarrierCharacterBase *vehicleObj = Cast< ACarrierCharacterBase >(m_pGamePlayer);
		uint16 desiredYaw = extend_data2 & 0xffff;
		extend_data2 = extend_data2 >> 16;
		if (hasValidDesirdYaw)
		{
			float decompressYaw = AzureUtility::DecompressDirH2_Yaw(desiredYaw);
			decompressYaw = FRotator::ClampAxis(decompressYaw);
			vehicleObj->SetDesiredYaw_Simulate(decompressYaw);
		}
		else
		{
			vehicleObj->ResetDesiredYawToDefault();
		}

		vehicleObj->OnGetMoveExtendFlag(flag2, extend_data2);
	}

	if (isGamePlayerMove && m_pGamePlayer.IsValid())
	{
		m_pGamePlayer->OnServerMoveBegin();
	}

	return true;
}

void AzureMoveBehavior::DrawDestPos_SetData()
{
	FVector draw_pos;
	FVector draw_dir;
	if (m_isOnCarrier)
	{
		if (m_carrier.IsValid())
		{
			AGamePlayer * pCarrier = m_carrier.Get();
			FVector t2 = pCarrier->GetFeetLocation();
			FRotator r2 = pCarrier->GetActorRotation();

			AzureUtility::CalAbsPosInfo(m_vDest, m_vStartDir.Rotation(), t2, r2, draw_pos, draw_dir);
		}
		else
		{
			MyPrintString2("AzureMoveBehavior carrier is not invalid", FLinearColor::Red);
		}
	}
	else
	{
		draw_pos = m_vDest;
		draw_dir = m_vStartDir;
	}

	FVector size(20, 20, 60);
	FVector v1 = draw_pos;
	v1.Z += 130.0f;
	UKismetSystemLibrary::DrawDebugBox(m_pObj->GetWorld(), v1, size, FLinearColor::Red,FRotator::ZeroRotator,2.0F);

	FVector v2 = v1 + draw_dir * 100;
	UKismetSystemLibrary::DrawDebugLine(m_pObj->GetWorld(), v1, v2, FLinearColor::Red,  2.0F);
}

void AzureMoveBehavior::DrawTick()
{
	FVector draw_pos;
	FVector draw_dir;
	if (m_isOnCarrier)
	{
		if (m_carrier.IsValid())
		{
			AGamePlayer * pCarrier = m_carrier.Get();
			FVector t2 = pCarrier->GetFeetLocation();
			FRotator r2 = pCarrier->GetActorRotation();

			AzureUtility::CalAbsPosInfo(m_vDest, m_vStartDir.Rotation(), t2, r2, draw_pos, draw_dir);
		}
		else
		{
			MyPrintString2("AzureMoveBehavior carrier is not invalid", FLinearColor::Red);
		}
	}
	else
	{
		draw_pos = m_vDest;
		draw_dir = m_vStartDir;
	}

	if (true)
	{
		FVector size(20, 20, 60);
		FVector v1 = draw_pos;
		v1.Z += 140.0f;
		UKismetSystemLibrary::DrawDebugBox(m_pObj->GetWorld(), v1, size, FLinearColor::Yellow, FRotator::ZeroRotator, 2.0F);

		FVector v2 = v1 + draw_dir * 100;
		UKismetSystemLibrary::DrawDebugLine(m_pObj->GetWorld(), v1, v2, FLinearColor::Yellow, 2.0F);
	}
	

	if (true)
	{
		FVector size(15, 15, 40);
		FVector v1 = draw_pos;
		v1.Z += 140.0f;
		UKismetSystemLibrary::DrawDebugBox(m_pObj->GetWorld(), v1, size, FLinearColor::Green, FRotator::ZeroRotator, 2.0F);

		FVector v2 = v1 + draw_dir * 100;
		UKismetSystemLibrary::DrawDebugLine(m_pObj->GetWorld(), v1, v2, FLinearColor::Green, 2.0F);
	}	
}

static bool MyTraceChannel(FHitResult& OutHitInfo, UWorld* pWorld, const FVector& Start, const FVector& End, ECollisionChannel channel, float offset, FCollisionQueryParams params = FCollisionQueryParams::DefaultQueryParam)
{
	if (!pWorld)
		return false;

	FHitResult hitIn;
	FHitResult hitOut;

	int nCountMax = 5;
	bool Success = true;
	FVector vStart = Start;
	FVector vEnd = End;

	while (Success && nCountMax > 0)
	{
		--nCountMax;

		hitIn.Init();
		Success = pWorld->LineTraceSingleByChannel(hitIn, vStart, vEnd, channel, params);
		if (!Success)
		{
			break;
		}
		
		const AActor* actor = hitIn.GetActor();
		if (!actor || !actor->IsA<AGamePlayer>())
		{
			OutHitInfo = hitIn;
			return true;
		}

		vStart = hitIn.Location;
		VEC_UP(vStart) -= offset;

		hitOut.Init();
		Success = pWorld->LineTraceSingleByChannel(hitOut, vStart, vEnd, channel, params);
		if (!Success)
		{
			break;
		}
		const AActor* actor2 = hitOut.GetActor();
		if (!actor2 || !actor2->IsA<AGamePlayer>())
		{
			OutHitInfo = hitOut;
			return true;
		}

		vStart = hitOut.Location;
		VEC_UP(vStart) -= offset;
	}

	return false;
}


bool AzureMoveBehavior::GetCurPitch(const FVector& pos, const FVector& dir, float& newPitch)
{
	newPitch = 0;

	if (isGamePlayerMove) {
		float radius = 0.3 * UE_METRE_TRANS;
		float halfHeight = 0.0f;
		if (isGamePlayerMove)
		{
			radius = m_pGamePlayer->GetCapsuleComponent()->GetScaledCapsuleRadius();
			halfHeight = m_pGamePlayer->GetCapsuleComponent()->GetScaledCapsuleHalfHeight();
		}

		FHitResult hitInfo;
		FVector vStart = pos;
		vStart.Z += halfHeight * 2.0f;

		float checkDis = 10000.0f;
		FVector vEnd = vStart;
		vEnd.Z -= checkDis;
//		TArray<AActor*> ignoreActors;
//		ignoreActors.Add(m_pObj);
//		bool ret = AzureUtility::GetHitPosInWorld(vStart, vEnd, AzureUtility::TRACE_CHN_TERRAIN_BUILDING, hitInfo, radius, halfHeight, true, FQuat::Identity, NAME_None, &ignoreActors);
		
		if (!AAzureEntryPoint::Instance)
			return false;

		UWorld* pWorld = AAzureEntryPoint::Instance->GetWorld();
		FCollisionQueryParams Params(NAME_None, false); // Not Trace Complex!
		Params.AddIgnoredActor(m_pObj.Get());	
		//bool ret = pWorld->LineTraceSingleByChannel(hitInfo, vStart, vEnd, AzureUtility::TRACE_CHN_TERRAIN_BUILDING, Params);

		const float fRadius = 35.0;
		bool ret = MyTraceChannel(hitInfo, pWorld, vStart, vEnd, AzureUtility::TRACE_CHN_TERRAIN_BUILDING, fRadius, Params);
		
		if (ret)
		{
			float RotationAngle = AzureUtility::Angle(FVector::UpVector, hitInfo.ImpactNormal);
			float angle = AzureUtility::Angle(hitInfo.ImpactNormal, dir);
			if (angle < 90.0f) //down
				newPitch = RotationAngle;
			else if (angle > 90.0f) //up
				newPitch = -RotationAngle;
			else
				newPitch = 0;

			//限制最大角度
			if (newPitch < -30 || newPitch > 30)
				newPitch = 0;

			if (m_iUpdatePitch == 2)
			{
				//画法线
				FVector hitP = hitInfo.Location;
				FVector ptM = hitP + hitInfo.ImpactNormal * 3000;
				DrawDebugLine(pWorld, hitP, ptM, FColor::Blue, false, 0.0f, 0, 50.0f);

				//画调整后的方向
				FVector right = m_pObj->GetActorRightVector();
				right.Z = 0;
				FVector new_dir = FVector::CrossProduct(right, hitInfo.ImpactNormal);
				ptM = pos + new_dir * 3000;
				DrawDebugLine(pWorld, pos, ptM, FColor::Red, false, 0.0f, 0, 50.0f);

				float RotationAngle = AzureUtility::Angle2(dir, new_dir);
				FString str = FString::Printf(TEXT("AzureMoveBehavior GetHitPosInWorld Actor %s, Component: %s, RotationAngle: %.2f"),
					hitInfo.Actor.IsValid() ? *(hitInfo.Actor->GetName()) : TEXT("<noname>"),
					hitInfo.Component.IsValid() ? *(hitInfo.Component->GetOwner()->GetName()) : TEXT("<noname>"), RotationAngle);
				MyPrintString2(str, FLinearColor::Red);
			}
			
			return true;
		}
	}
	return false;
}

void AzureMoveBehavior::GetCurPosAndDir(FVector & result_pos, FVector & result_dir)
{
	FVector abs_pos;
	if (isGamePlayerMove && m_pGamePlayer.IsValid())
		abs_pos = m_pGamePlayer->GetFeetLocation();
	else
		abs_pos = m_pObj->GetActorLocation();

	FRotator r1 = m_pObj->GetActorRotation();
	result_dir = m_pObj->GetActorForwardVector();
	
	if (m_isOnCarrier )
	{
		if (m_carrier.IsValid())
		{
			AGamePlayer * pCarrier = m_carrier.Get();
			FVector t2 = pCarrier->GetFeetLocation();
			FRotator r2 = pCarrier->GetActorRotation();
			AzureUtility::CalRelativePosInfo(abs_pos, r1, t2, r2, result_pos, result_dir);
		}
		else
		{
			MyPrintString2("AzureMoveBehavior carrier is not valid",FLinearColor::Red);
		}
	}
	else
	{
		result_pos = abs_pos;
	}
}

void AzureMoveBehavior::SetCurDir(const FVector & dir)
{
	float lastYaw = m_pObj->GetActorRotation().Yaw;

	FRotator rot = dir.Rotation();
	rot.Pitch = 0.0f;
	rot.Roll = 0.0f;
	m_pObj->SetActorRotation(rot);

	if (false)
	{
		FString str = FString::Printf(TEXT("AzureMove %s setrot %0.3f %0.3f %0.3f"), *m_pObj->GetName(),m_pObj->GetActorRotation().Yaw,rot.Yaw,lastYaw);
		MyPrintString(str);
	}
}

void AzureMoveBehavior::SetCurPos(const FVector & pos)
{
	FVector old_pos;
	if (isGamePlayerMove && m_pGamePlayer.IsValid())
		old_pos = m_pGamePlayer->GetFeetLocation();
	else
		old_pos = m_pObj->GetActorLocation();

	FVector abs_pos;
	if (m_isOnCarrier)//如果在船上，pos是相对位置
	{
		if (m_carrier.IsValid())
		{
			AGamePlayer * pCarrier = m_carrier.Get();
			FVector t2 = pCarrier->GetFeetLocation();
			FRotator r2 = pCarrier->GetActorRotation();
			FVector abs_dir;
			AzureUtility::CalAbsPosInfo(pos, m_vStartDir.Rotation(), t2, r2, abs_pos, abs_dir);
			m_pObj->SetActorRotation(abs_dir.Rotation());
		}
		else
		{
			MyPrintString2("AzureMoveBehavior carrier is not invalid 2", FLinearColor::Red);
			return;
		}
	}
	else
	{
		abs_pos = pos;
	}

	if (m_bTraceGround)
	{
		float liftHeight = 500.0f;
		float downHeight = 500.0f;

		FHitResult hitInfo;
		FVector vStart = abs_pos;
		vStart.Z += liftHeight;

		FVector vEnd = abs_pos;
		vEnd.Z -= downHeight;

		if (!AAzureEntryPoint::Instance)
			return;
		
		UWorld* pWorld = AAzureEntryPoint::Instance->GetWorld();
		FCollisionQueryParams Params(NAME_None, false); // Not Trace Complex!
		Params.AddIgnoredActor(m_pObj.Get());	
		bool ret = pWorld->LineTraceSingleByChannel(hitInfo, vStart, vEnd, AzureUtility::TRACE_CHN_TERRAIN_BUILDING, Params);
		if (ret)
			abs_pos.Z = hitInfo.Location.Z;
	}

	if (isGamePlayerMove && m_pGamePlayer.IsValid())
		m_pGamePlayer->SetFeetLocation2(abs_pos);
	else
		m_pObj->SetActorLocation(abs_pos);

	if (m_iUpdatePitch && isGamePlayerMove && m_pGamePlayer.IsValid())
	{
		USkeletalMeshComponent* SkeletalMesh = m_pGamePlayer->GetMesh();
		if (SkeletalMesh) {
			FRotator destRot = FMath::Lerp(_startRot, _destRot, (m_fTotalDist - m_fDist) / m_fTotalDist);
			SkeletalMesh->RelativeRotation = destRot;
			m_pGamePlayer->SetMeshRoll(destRot.Roll);
		}
	}
}

float AzureMoveBehavior::DealCarrierTickDis(float dt)
{	
	float deltaTime = 0.033f;
	float normalTickRate = GEngine->GetMaxTickRate(0.0f, false);
	if (normalTickRate > 0.0f)
	{
		deltaTime = 1.0f / normalTickRate;
	}
	else if (deltaTime < dt)
	{
		deltaTime = dt;
	}

	float use_time = Azure::ai_move_interval;
	float oneShipStepDis = m_fSpeed * use_time;

	float dis_p1 = 1.5f;
	float dis_p2 = 3.0f;

	float scale1 = 1.0f;
	float scale2 = 2.0f;

	float targetScale = 1.0f;
	if (m_fDist <= dis_p1 * oneShipStepDis || oneShipStepDis <= 0.001f)
	{
		targetScale = scale1;
	}
	else if (m_fDist >= dis_p2 * oneShipStepDis)//每次协议的船移动的距离
	{
		targetScale = scale2;
	}
	else if (m_fDist < dis_p2 * oneShipStepDis && m_fDist >= dis_p1 * oneShipStepDis)
	{
		float pDist = m_fDist / oneShipStepDis;
		float p = (pDist - dis_p1) / (dis_p2 - dis_p1);
		targetScale = scale1 * (1 - p) + scale2 * p;
	}

	static float scale_speed = 1.0f;
	float result = FMath::FInterpConstantTo(mCarrierSpeedScale, targetScale, dt, scale_speed);

	

	if (false)
	{
		double st = AAzureEntryPoint::Instance->GetRealtimeSinceStartup();
		float p = 0.0f;
		if (oneShipStepDis > 0.0f)
		{
			p = m_fDist / oneShipStepDis;
		}

		FString str = FString::Printf(TEXT("carrier move tick %0.3f %0.3f %0.3f %0.3f %0.3f"), deltaTime, mCarrierSpeedScale, targetScale, result,p);
		MyPrintString(str);
	}
	
	mCarrierSpeedScale = result;

	float fMove = deltaTime * m_fSpeed * mCarrierSpeedScale;

	return fMove;
}

void AzureMoveBehavior::SetCurRot(const FRotator & rot)
{
	FRotator abs_rot;
	if (m_isOnCarrier)//如果在船上，pos是相对位置
	{
		if (m_carrier.IsValid())
		{
			AGamePlayer * pCarrier = m_carrier.Get();
			FVector t2 = pCarrier->GetFeetLocation();
			FRotator r2 = pCarrier->GetActorRotation();
			FVector abs_pos, abs_dir;
			AzureUtility::CalAbsPosInfo(FVector::ZeroVector, rot, t2, r2, abs_pos, abs_dir);

			abs_rot = abs_dir.Rotation();
		}
		else
		{
			MyPrintString2("AzureMoveBehavior carrier is not invalid 2", FLinearColor::Red);
			return;
		}
	}
	else
	{
		abs_rot = rot;
	}

	if (false)
	{
		if (!AAzureEntryPoint::Instance)
			return;

		double st = AAzureEntryPoint::Instance->GetRealtimeSinceStartup();
		static double lastst = st;
		FString str = FString::Printf(TEXT("AzureMoveBehavior turn setrot %0.3f %0.3f %0.3f --%0.3f %0.3f"), abs_rot.Yaw, m_pObj->GetActorRotation().Yaw, abs_rot.Yaw - m_pObj->GetActorRotation().Yaw, st, st - lastst);
		MyPrintString(str);

		lastst = st;
	}

	m_pObj->SetActorRotation(abs_rot);
}

FRotator AzureMoveBehavior::GetCurRot()
{
	FRotator resultRot;
	FRotator r1 = _objcomp->GetRotObj()->GetActorRotation();
	if (m_isOnCarrier)
	{
		if (m_carrier.IsValid())
		{
			AGamePlayer * pCarrier = m_carrier.Get();
			FVector t2 = pCarrier->GetFeetLocation();
			FRotator r2 = pCarrier->GetActorRotation();

			FVector result_pos, result_dir;
			AzureUtility::CalRelativePosInfo(FVector::ZeroVector, r1, t2, r2, result_pos, result_dir);

			resultRot = result_dir.Rotation();
		}
		else
		{
			MyPrintString2("TurnBehavior carrier is not valid", FLinearColor::Red);
		}
	}
	else
	{
		resultRot = r1;
	}

	return resultRot;
}

bool AzureMoveBehavior::TickTurn(float dt)
{
	if ((uint32)m_turnflag & (uint32)GP_TURN_FLAG::GP_TURN_BLINK)
	{
		//MyPrintString("ObjTurn tick End 1");
		return true;
	}

	if (isGamePlayerMove && m_pGamePlayer.IsValid())
	{
		if (m_pGamePlayer->m_isCarrier)
		{
			float deltaTime = 0.033f;
			float normalTickRate = GEngine->GetMaxTickRate(0.0f, false);
			if (normalTickRate > 0.0f)
			{
				deltaTime = 1.0f / normalTickRate;
			}
			else if (deltaTime < dt)
			{
				deltaTime = dt;
			}

			dt = deltaTime;
		}
	}

	m_timepassed += dt;
	if (m_timepassed >= m_totaltime)
	{
		SetCurRot(m_destdir);

		if ((uint32)m_turnflag & (uint32)GP_TURN_FLAG::GP_TURN_STOP)
		{
			if (isGamePlayerMove && m_pGamePlayer.IsValid())
			{
				m_pGamePlayer->SetABStandTurnDir(0);
				//MyPrintString("TurnEnd Stop");
			}
		}

		return true;
	}

	FRotator dir = FMath::Lerp(m_startdir, m_destdir, m_timepassed / m_totaltime);
	FRotator curdir = GetCurRot();
	dir.Roll = curdir.Roll;
	dir.Pitch = curdir.Pitch;
	SetCurRot(dir);

	if (isGamePlayerMove && m_pGamePlayer.IsValid())
	{
		m_pGamePlayer->SetABStandTurnDir(m_speed_for_anim);
	}

	return false;
}
bool AzureMoveBehavior::TickMove(float dt)
{	
	static bool bPrint = false;
	static float z = m_curPos.Z;

	FVector delta = m_curPos - m_vDest;
	if (delta.Size() < 0.05f * UE_METRE_TRANS)
	{
		m_fDist = 0;
		SetCurPos(m_vDest);

		//FString str = FString::Printf(TEXT("AzureMoveBehavior EndTick 1 %0.1f %0.1f"), delta.Size(), m_fSpeed);
		//MyPrintString(str);

		if (bPrint)
		{
			double st = AAzureEntryPoint::Instance->GetRealtimeSinceStartup();
			//FString str = FString::Printf(TEXT("AzureMoveBehavior End1 %0.1f %0.1f %0.1f---%0.3f"), m_vDest.X, m_vDest.Y, m_vDest.Z, st);
			FString str = FString::Printf(TEXT("AzureMoveBehavior End1 %0.1f %0.1f---%0.3f"), m_vDest.Z - z,m_vDest.Z, st);
			MyPrintString(str);
			z = m_curPos.Z;
		}
		
		//移动结束
		return true;
	}

	float fMove = dt * m_fSpeed;

	if (isGamePlayerMove && m_pGamePlayer.IsValid())
	{
		if (m_pGamePlayer->m_isCarrier)
		{
			fMove = DealCarrierTickDis(dt);
		}
	}

	if (fMove >= m_fDist)
	{
		m_fDist = 0;

		SetCurPos(m_vDest);

		//FString str = FString::Printf(TEXT("AzureMoveBehavior EndTick 2 %0.1f %0.1f %0.1f"), fMove, m_fDist,m_fSpeed);
		//MyPrintString(str);

		if (bPrint)
		{
			double st = AAzureEntryPoint::Instance->GetRealtimeSinceStartup();
			//FString str = FString::Printf(TEXT("AzureMoveBehavior End2 %0.1f %0.1f %0.1f---%0.3f"), m_vDest.X, m_vDest.Y, m_vDest.Z, st);
			FString str = FString::Printf(TEXT("AzureMoveBehavior End1 %0.1f %0.1f---%0.3f"), m_vDest.Z - z, m_vDest.Z, st);
			MyPrintString(str);
			z = m_vDest.Z;
		}

		//移动结束
		return true;
	}

	if (isGamePlayerMove && m_pGamePlayer.IsValid())
	{
		if (false)
		{
			//double st = AAzureEntryPoint::Instance->GetRealtimeSinceStartup();
			//FString str = FString::Printf(TEXT("AzureMoveBehavior %0.3f %0.1f---%0.3f"), (m_vDest - m_curPos).Size2D(),m_fSpeed,st);
			FString str = FString::Printf(TEXT("AzureMoveBehavior Tick %0.1f %0.1f %0.1f"), m_vDir.Rotation().Pitch, m_vDir.Rotation().Yaw, m_vDir.Rotation().Roll);
			MyPrintString(str);
		}

		//if (m_pGamePlayer->m_isCarrier)
			//SetCurDir(m_vDir);
	}

	m_fDist -= fMove;

	m_curPos += fMove * m_vDir;
	SetCurPos(m_curPos);



	if (false)
		DrawTick();

	
	if (bPrint)
	{
		double st = AAzureEntryPoint::Instance->GetRealtimeSinceStartup();
		//FString str = FString::Printf(TEXT("AzureMoveBehavior %0.3f %0.1f---%0.3f"), (m_vDest - m_curPos).Size2D(),m_fSpeed,st);
		//FString str = FString::Printf(TEXT("AzureMoveBehavior Tick %0.1f %0.1f %0.1f---%0.3f"), m_curPos.X, m_curPos.Y, m_curPos.Z, st);
		
		FString str = FString::Printf(TEXT("AzureMoveBehavior Tick %0.1f %0.1f %0.1f %0.1f---%0.3f"), m_curPos.Z - z, m_fDist, m_curPos.Z, m_pGamePlayer->GetFeetLocation().Z,st);
		z = m_curPos.Z;
		MyPrintString(str);
	}

	return false;
}

bool AzureMoveBehavior::Tick(float dt)
{
	if (!_objcomp.IsValid())
		return true;

	if (!m_pObj.IsValid())
		return true;

	bool moveOver = TickMove(dt);
	bool turnOver = m_need_turn ? TickTurn(dt) : true;

	if (moveOver && turnOver)
	{
		if (isGamePlayerMove && m_pGamePlayer.IsValid())
		{
			m_pGamePlayer->OnServerMoveOver();
		}

		return true;
	}
	else
		return false;
}

void AzureMoveBehavior::OnRemoved(bool replace)
{
	m_carrier = nullptr;
	m_isOnCarrier = false;
}

void AzureMoveBehavior::DrawPosAndDir()
{
	FVector cur_pos;
	if (isGamePlayerMove)
		cur_pos = m_pGamePlayer->GetFeetLocation();
	else
		cur_pos = m_pObj->GetActorLocation();
	FRotator cur_rot = m_pObj->GetActorRotation();
	FVector cur_dir = m_pObj->GetActorForwardVector();

	//画当前位置方向
	{
		if (!AAzureEntryPoint::Instance)
			return;

		UWorld* pWorld = AAzureEntryPoint::Instance->GetWorld();
		FVector cur_dir = m_pObj->GetActorForwardVector();
		FVector ptM = cur_pos + cur_dir * 3000;
		DrawDebugLine(pWorld, cur_pos, ptM, FColor::Cyan, false, 0.0f, 0, 50.0f);

		cur_dir = m_pObj->GetActorRightVector();
		ptM = cur_pos + cur_dir * 3000;
		DrawDebugLine(pWorld, cur_pos, ptM, FColor::Purple, false, 0.0f, 0, 50.0f);

		cur_dir = m_pObj->GetActorUpVector();
		ptM = cur_pos + cur_dir * 3000;
		DrawDebugLine(pWorld, cur_pos, ptM, FColor::Orange, false, 0.0f, 0, 50.0f);
	}

}
