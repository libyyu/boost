﻿#include "HPMoveBase.h"
#include "AzureObjectComponent.h"
#include "AzureGameSession.h"
#include "AzureUtility.h"
#include "AzureTimeManager.h"
#include "UnrealMathUtility.h"
#include "GameLogic/Player/GamePlayer.h"

DEFINE_LOG_CATEGORY_STATIC(LogHPMoveBeh, Log, All);

HPMoveBase::HPMoveBase() : AzureBehavior()
{

}

const FVector& HPMoveBase::GetMoveDir() const
{
	return _dir;
}

int HPMoveBase::GetMoveFlags()
{
	return (int)GP_MOVE_FLAG::GP_MOVE_NONE;
}

bool HPMoveBase::Tick(float dt)
{
	//把m_fSyncPushMoveTimer的递加放到_create_framecount == GFrameNumber条件之前，因为ue4的physWalk和PhysFalling,不会等这个条件
	//在之前TickInterval里加这个时间，会造成起跳时m_fSyncPushMoveTimer少加一帧时间，使PhysFalling在0.1s里多走一个tick的距离，导致服务器拉人
	//起跳是这样，移动也同理

	if (!_objcomp.IsValid())
		return false;

	AGamePlayer * pActor = Cast<AGamePlayer>(_objcomp->GetOwner());
	if (!pActor)
		return false;

	if (pActor)
	{
		pActor->m_fSyncPushMoveTimer += dt;
	}

	static bool bPrint = false;
	if (b_player_move_show && bPrint)
	{
		if (!AAzureEntryPoint::Instance)
			return false;

		FString str = FString::Printf(TEXT("HPMoveBase syncTime %d %0.4f %0.4f"), (int)get_Type(), pActor->m_fSyncPushMoveTimer, AAzureEntryPoint::Instance->GetRealtimeSinceStartup());
		MyPrintString(str);
	}
	
	// 和创建的同一帧tick跳过
	if (_create_framecount == GFrameNumber)
		return false;
	
	bool bFinished = TickInternal(dt);
	return bFinished;
}

bool HPMoveBase::TickInternal(float dt)
{
	if (!_objcomp.IsValid())
		return false;

	_time_played += dt;

#if HPMOVE_LOG
	/*UE_LOG(LogHPMoveBeh, Log, TEXT("@%f[%I64u]: --------AzureHPBehavior::TickInternal: dt[%f], TimePlayed->[%f], m_fSyncPushMoveTimer->[%f]"),
		(float)AAzureEntryPoint::Instance->GetRealtimeSinceStartup(), AAzureEntryPoint::Instance->GetCurFrameCount(),
		dt, m_fTimePlayed, ECHostComponentInfo::m_fSyncPushMoveTimer + dt);*/
#endif

	return true;
}

FVector HPMoveBase::GetNextMovePoint(const FVector& curpos, const FVector& move) const
{
	FVector vDestThisTick = curpos + move;

	FHitResult hitInfo;
	float height;
	bool bRet = AzureUtility::GetSupportPlaneHeight(height, vDestThisTick + FVector(0, 0, s_trace_height_delta), 0.2, s_trace_distance, &hitInfo);
	if (bRet)
	{
		VEC_UP(vDestThisTick) = height;
	}
	
	//	当高度变化太大的时候，返回直接计算的结果，不做坡度平滑
	float height_diff = FMath::Abs(VEC_UP(curpos) - height);
	if (height_diff> s_max_height_changes)
	{
		return vDestThisTick;
	}

	FVector vDiff = vDestThisTick - curpos;
	vDiff.Normalize();
	vDestThisTick = curpos + vDiff * move.Size2D();
	bRet = AzureUtility::GetSupportPlaneHeight(height, vDestThisTick + FVector(0, 0, s_trace_height_delta), 0.2, s_trace_distance, &hitInfo);
	if (bRet)
	{
		VEC_UP(vDestThisTick) = height;
	}
	return vDestThisTick;
}

void HPMoveBase::ChangeSpeed(float speed)
{
	_speed = speed;
}
