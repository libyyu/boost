#pragma once
#include "HPMoveBase.h"
#include "HPJoystickMoveBehavior.h"
#include "UE4Related.h"

class HPVehicleJoystickMoveBehavior : public HPMoveBase
{
protected:
	bool onlyAcceptNotManualInput = false;

	bool lastHasInput = true;

	static constexpr  Azure::BehaviorType _type = Azure::BehaviorType::HPVehicleJoystickMove;
public:
	HPVehicleJoystickMoveBehavior()
	{
		
	}

	Azure::BehaviorType get_Type() const override
	{
		return _type;
	}

	static HPVehicleJoystickMoveBehavior* Create();

	bool SetData(OnBehaviorFinish onFinish, float fMoveSpeed, bool onlyAcceptNotManualInput = false);

	virtual void OnRemoved(bool replace) override;
protected:

	virtual bool TickInternal(float dt) override;

	bool TickVehicleMove(float dt); //��ǰ����������������ƶ�

protected:
	bool IsCarrierGamePlayer() const;

};