﻿//#include "Azure.h"
#include "AzureRootMotionBehavior.h"
#include "AzureObjectComponent.h"
#include "UE4Related.h"
#include "AzureUtility.h"
#include "Kismet/KismetSystemLibrary.h"
#include "GameLogic/Player/GamePlayer.h"
#include "GameLogic/Player/GamePlayer_Util.h"
#include "Animation/AnimMontage.h"

using namespace Azure;

//////////////////////////////////////////////////////////////////////////

bool AzureRootMotionBehavior::SetData(FVector vDest, float time_scale, UAnimMontage * pMontage, AGamePlayer * pCarrier, OnBehaviorFinish onFinish)
{
	if (!_objcomp.IsValid())
		return false;

	AActor * pObj = Cast<AActor>(_objcomp->GetOwner());
	if (!pObj)
		return false;

	if (!pMontage)
		return false;
	
	m_pGamePlayer = Cast<AGamePlayer>(pObj);

	m_pMontage = pMontage;

	set_OnFinish(onFinish);
	m_vDest = vDest;//如果在船上，vDest是相对坐标

	if (time_scale <= 0.0f)
		time_scale = 1.0f;

	m_time_scale = time_scale;
	m_animLength = pMontage->GetSectionLength(0);
	
	FTransform trans = pMontage->ExtractRootMotionFromTrackRange(0, m_animLength);
	m_animDist = trans.GetTranslation().Size2D();
	
	m_duration = m_time_scale * m_animLength;
	m_curTime = 0.0f;

	m_carrier = pCarrier;
	m_isOnCarrier = (pCarrier != nullptr);

	FVector vStartPos;
	GetCurPosAndDir(vStartPos,m_vStartDir);

	m_curPos = vStartPos;
	(vDest - vStartPos).ToDirectionAndLength(m_vDir, m_fDist);

	m_vStartPos = vStartPos;

	if(false)
	{
		if (!AAzureEntryPoint::Instance)
			return true;

		double st = AAzureEntryPoint::Instance->GetRealtimeSinceStartup();
		FVector unitdir = m_vDir.GetSafeNormal2D();
		FString str = FString::Printf(TEXT("AzureRootMotionBehavior %0.1f %0.1f ---%0.3f"), unitdir.Rotation().Yaw, m_pGamePlayer->GetActorRotation().Yaw, st);
		MyPrintString(str);
	}
	
	if (false)
	{
		MyPrintString("start AzureRootMotionBehavior");
	}

	if (false)
	{
		DrawDestPos_SetData();
	}

	if (false)
	{
		if (!AAzureEntryPoint::Instance)
			return true;

		double st = AAzureEntryPoint::Instance->GetRealtimeSinceStartup();
		FString str = FString::Printf(TEXT("AzureRootMotionBehavior SetData vDest %0.1f--%0.1f--%0.1f"), m_vDest.X, m_vDest.Y, m_vDest.Z);
		MyPrintString(str);
		
		str = FString::Printf(TEXT("AzureRootMotionBehavior SetData vStartPos %0.1f--%0.1f--%0.1f"), vStartPos.X, vStartPos.Y, vStartPos.Z);
		MyPrintString(str);
		
		str = FString::Printf(TEXT("AzureRootMotionBehavior SetData %0.3f--%0.3f"), (m_vDest - m_curPos).Size2D(),st);
		MyPrintString(str);

		str = FString::Printf(TEXT("AzureRootMotionBehavior SetData m_animLength %0.3f duration %0.3f"), m_animLength, m_duration);
		MyPrintString(str);
	}

	return true;
}

void AzureRootMotionBehavior::DrawDestPos_SetData()
{
	FVector draw_pos;
	FVector draw_dir;
	if (m_isOnCarrier)
	{
		if (m_carrier.IsValid())
		{
			AGamePlayer * pCarrier = m_carrier.Get();
			FVector t2 = pCarrier->GetFeetLocation();
			FRotator r2 = pCarrier->GetActorRotation();

			AzureUtility::CalAbsPosInfo(m_vDest, m_vStartDir.Rotation(), t2, r2, draw_pos, draw_dir);
		}
		else
		{
			MyPrintString2("AzureRootMotionBehavior carrier is not invalid", FLinearColor::Red);
		}
	}
	else
	{
		draw_pos = m_vDest;
		draw_dir = m_vStartDir;
	}

	FVector size(20, 20, 60);
	FVector v1 = draw_pos;
	v1.Z += 130.0f;
	UKismetSystemLibrary::DrawDebugBox(m_pGamePlayer->GetWorld(), v1, size, FLinearColor::Red,FRotator::ZeroRotator,2.0F);

	FVector v2 = v1 + draw_dir * 100;
	UKismetSystemLibrary::DrawDebugLine(m_pGamePlayer->GetWorld(), v1, v2, FLinearColor::Red,  2.0F);
}

void AzureRootMotionBehavior::DrawTick()
{
	FVector draw_pos;
	FVector draw_dir;
	if (m_isOnCarrier)
	{
		if (m_carrier.IsValid())
		{
			AGamePlayer * pCarrier = m_carrier.Get();
			FVector t2 = pCarrier->GetFeetLocation();
			FRotator r2 = pCarrier->GetActorRotation();

			AzureUtility::CalAbsPosInfo(m_vDest, m_vStartDir.Rotation(), t2, r2, draw_pos, draw_dir);
		}
		else
		{
			MyPrintString2("AzureRootMotionBehavior carrier is not invalid", FLinearColor::Red);
		}
	}
	else
	{
		draw_pos = m_vDest;
		draw_dir = m_vStartDir;
	}

	if (false)
	{
		FVector size(20, 20, 60);
		FVector v1 = draw_pos;
		v1.Z += 140.0f;
		UKismetSystemLibrary::DrawDebugBox(m_pGamePlayer->GetWorld(), v1, size, FLinearColor::Yellow, FRotator::ZeroRotator, 2.0F);

		FVector v2 = v1 + draw_dir * 100;
		UKismetSystemLibrary::DrawDebugLine(m_pGamePlayer->GetWorld(), v1, v2, FLinearColor::Yellow, 2.0F);
	}
	

	if (false)
	{
		FVector size(15, 15, 40);
		FVector v1 = draw_pos;
		v1.Z += 140.0f;
		UKismetSystemLibrary::DrawDebugBox(m_pGamePlayer->GetWorld(), v1, size, FLinearColor::Green, FRotator::ZeroRotator, 2.0F);

		FVector v2 = v1 + draw_dir * 100;
		UKismetSystemLibrary::DrawDebugLine(m_pGamePlayer->GetWorld(), v1, v2, FLinearColor::Green, 2.0F);
	}	
}

void AzureRootMotionBehavior::GetCurPosAndDir(FVector & result_pos, FVector & result_dir)
{
	FVector abs_pos;
	abs_pos = m_pGamePlayer->GetFeetLocation();
	

	FRotator r1 = m_pGamePlayer->GetActorRotation();
	result_dir = m_pGamePlayer->GetActorForwardVector();
	
	if (m_isOnCarrier )
	{
		if (m_carrier.IsValid())
		{
			AGamePlayer * pCarrier = m_carrier.Get();
			FVector t2 = pCarrier->GetFeetLocation();
			FRotator r2 = pCarrier->GetActorRotation();
			AzureUtility::CalRelativePosInfo(abs_pos, r1, t2, r2, result_pos, result_dir);
		}
		else
		{
			MyPrintString2("AzureRootMotionBehavior carrier is not valid",FLinearColor::Red);
		}
	}
	else
	{
		result_pos = abs_pos;
	}
}

void AzureRootMotionBehavior::SetCurPosAndDir(FVector pos)
{
	FVector abs_pos;
	if (m_isOnCarrier)//如果在船上，pos是相对位置
	{
		if (m_carrier.IsValid())
		{
			AGamePlayer * pCarrier = m_carrier.Get();
			FVector t2 = pCarrier->GetFeetLocation();
			FRotator r2 = pCarrier->GetActorRotation();
			FVector abs_dir;
			AzureUtility::CalAbsPosInfo(pos, m_vStartDir.Rotation(), t2, r2, abs_pos, abs_dir);
			m_pGamePlayer->SetActorRotation(abs_dir.Rotation());
		}
		else
		{
			MyPrintString2("AzureRootMotionBehavior carrier is not invalid 2", FLinearColor::Red);
			return;
		}
	}
	else
	{
		abs_pos = pos;
	}
	
	m_pGamePlayer->SetFeetLocation2(abs_pos);

	if (false)
	{
		if (!AAzureEntryPoint::Instance)
			return;

		double st = AAzureEntryPoint::Instance->GetRealtimeSinceStartup();
		//FString str = FString::Printf(TEXT("AzureRootMotionBehavior %0.3f %0.1f---%0.3f"), (m_vDest - m_curPos).Size2D(),m_fSpeed,st);
		FString str = FString::Printf(TEXT("AzureRootMotionBehavior Tick %0.1f %0.1f %0.1f--%0.3f--%0.3f"), abs_pos.X, abs_pos.Y, abs_pos.Z, m_curTime, st);
		MyPrintString(str);
	}
}

bool AzureRootMotionBehavior::Tick(float dt)
{	
	if (!m_pGamePlayer.IsValid())
		return true;

	if (m_curTime >= m_duration)
	{
		SetCurPosAndDir(m_vDest);

		if (false)
		{
			if (!AAzureEntryPoint::Instance)
				return true;

			double st = AAzureEntryPoint::Instance->GetRealtimeSinceStartup();
			FString str = FString::Printf(TEXT("AzureRootMotionBehavior End %0.1f %0.1f %0.1f---%0.3f"), m_vDest.X, m_vDest.Y, m_vDest.Z, st);
			MyPrintString(str);
		}

		return true;
	}

	float cur_animTime = m_curTime / m_time_scale;

	FTransform trans = m_pMontage->ExtractRootMotionFromTrackRange(0, cur_animTime);
	float cur_animDist = trans.GetTranslation().Size2D();

	float cur_dist = cur_animDist / m_animDist * m_fDist;
	
	m_curPos = m_vStartPos + cur_dist * m_vDir;
	SetCurPosAndDir(m_curPos);

	m_curTime += dt;

	if (false)
		DrawTick();

	if (false)
	{
		if (!AAzureEntryPoint::Instance)
			return true;

		double st = AAzureEntryPoint::Instance->GetRealtimeSinceStartup();
		//FString str = FString::Printf(TEXT("AzureRootMotionBehavior %0.3f %0.1f---%0.3f"), (m_vDest - m_curPos).Size2D(),m_fSpeed,st);
		//FString str = FString::Printf(TEXT("AzureRootMotionBehavior Tick %0.1f %0.1f %0.1f--%0.3f--%0.3f"), m_curPos.X, m_curPos.Y, m_curPos.Z,m_curTime, st);
		FString str = FString::Printf(TEXT("AzureRootMotionBehavior Tick %0.2f %0.2f--%0.3f"), cur_animDist, m_animDist, m_curTime);
		MyPrintString(str);
	}

	return false;
}

void AzureRootMotionBehavior::OnRemoved(bool replace)
{
	m_carrier = nullptr;
	m_isOnCarrier = false;
}

