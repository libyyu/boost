﻿#include "HPBezierMoveBehavior.h"
#include "AzureObjectComponent.h"
#include "AzureUtility.h"
#include "AzureExport.h"
#include "Blueprint/AIBlueprintHelperLibrary.h"
#include "GameLogic/Player/GamePlayer.h"
#include "GameLogic/Player/VehicleCharacter.h"
#include "GameLogic/Player/GamePlayer_Util.h"
#include "Kismet/KismetSystemLibrary.h"
#include "GameLogic/AnimRelated/CommonFunc.h"
#include "GameLogic/Player/MotorVehicleCharacter.h"
#include "GameLogic/Player/GamePlayerManager.h"


HPBezierMoveBehavior* HPBezierMoveBehavior::Create()
{
	HPBezierMoveBehavior* ret = (HPBezierMoveBehavior*)AzureBehaviorCache::GetInstance().GetBehavior(_type);

	if (ret == nullptr)
		ret = new HPBezierMoveBehavior();
	ret->_create_framecount = GFrameNumber;

	return ret;
}

void HPBezierMoveBehavior::DealEvents(const Azure::ArrayFloat & events)
{
	m_orign_events = events;

	int num = events.Num();

	m_real_events.SetNum(num); 

	int pointNum = m_spline.Points.Num();

	for (int i = 0; i < num; i++)
	{
		float tmp_percent = events[i];
		int headIndex = int(tmp_percent);
		int tailIndex = headIndex + 1;

		float result_percent = -1.0f;
		if (headIndex >= 0 && tailIndex < pointNum)
		{
			float p = tmp_percent - headIndex;
			result_percent = m_spline.Points[headIndex].InVal * (1.0f - p) + m_spline.Points[tailIndex].InVal * p;
		}
		else if (tailIndex >= pointNum)
		{
			result_percent = m_spline.Points[pointNum - 1].InVal;
		}

		m_real_events[i] = result_percent;
	}

	m_event_call_index = -1;
}

bool HPBezierMoveBehavior::SetData(const Azure::VecPoint& points, const Azure::VecPoint& arrive_dirs, const Azure::VecPoint& leave_dirs, const Azure::ArrayFloat& events, int steps, float speed, int move_type,bool ground,bool isloop,AGamePlayer * pCarrier, OnBehaviorFinish onFinish)
{
	if (!_objcomp.IsValid())
		return false;

	AGamePlayer * pActor = Cast<AGamePlayer>(_objcomp->GetOwner());
	if (!pActor)
		return false;

	if (speed <= 0.0f)
		return false;

	m_carrier = pCarrier;
	m_isOnCarrier = (pCarrier != nullptr);	

	set_OnFinish(onFinish);	

	m_steps = steps;
	_speed = speed;
	m_move_type = move_type;
	m_ground_move = ground;
	m_loop = isloop;

	
	pActor->SyncPushMoveToServer("HPBezierMoveBehavior SetData", ESyncMoveSendType::None, true, false);

	m_time = 0.0f;

	m_spline.Reset();
	m_spline2D.Reset();

	int num = points.Num();
	for (int i = 0; i < num; i++)
	{
		m_spline.AddPoint(i, points[i]);
		m_spline.Points[i].ArriveTangent = arrive_dirs[i];
		m_spline.Points[i].LeaveTangent = leave_dirs[i];
		m_spline.Points[i].InterpMode = CIM_CurveAuto;

		FVector p2d = points[i];
		p2d.Z = 0.0f;
		m_spline2D.AddPoint(i, p2d);
		m_spline2D.Points[i].ArriveTangent = arrive_dirs[i];
		m_spline2D.Points[i].ArriveTangent.Z = 0.0f;
		m_spline2D.Points[i].LeaveTangent = leave_dirs[i];
		m_spline2D.Points[i].LeaveTangent.Z = 0.0f;
		m_spline2D.Points[i].InterpMode = CIM_CurveAuto;
	}

	float length = GetSplineLength(m_spline, m_steps);

	length = ResetSplineKeyByLength(m_spline, m_steps);

	for (int k = 1; k < num - 1; k++)
	{
		m_spline2D.Points[k].InVal = m_spline.Points[k].InVal;
	}

	DealEvents(events);//这个要放在ResetSplineKeyByLength 后面，因为每个点的InVal会根据距离重算

	m_duration = length / speed;
	m_time = 0.0f;
	last_percent = 0.0f;
	last_segment = 0;

	m_totalDist = length;

	if (m_totalDist < 0.01f)
		return false;

	m_curDist = 0.0f;

	//初始化位置和方向，后续方向要interp，进入的时候先直接设方向
	FVector vDest, dir;
	CalPosDirByPercent(pActor, 0.0f, m_ground_move, vDest, dir);

	SetCurPos(vDest, dir);

	CheckPassPoint(0.0f);
	return true;
}

void HPBezierMoveBehavior::GetCurPosAndDir(FVector & result_pos, FVector & result_dir)
{
	if (!_objcomp.IsValid())
		return;

	AGamePlayer * pActor = Cast<AGamePlayer>(_objcomp->GetOwner());
	if (!pActor)
		return;

	FVector abs_pos = pActor->GetFeetLocation();

	FRotator r1 = pActor->GetActorRotation();
	result_dir = pActor->GetActorForwardVector();

	if (m_isOnCarrier)
	{
		if (m_carrier.IsValid())
		{
			AGamePlayer * pCarrier = m_carrier.Get();
			FVector t2 = pCarrier->GetFeetLocation();
			FRotator r2 = pCarrier->GetActorRotation();
			AzureUtility::CalRelativePosInfo(abs_pos, r1, t2, r2, result_pos, result_dir);
		}
		else
		{
			MyPrintString2("HPBezierMoveBehavior carrier is not valid", FLinearColor::Red);
		}
	}
	else
	{
		result_pos = abs_pos;
	}
}

void HPBezierMoveBehavior::OnRemoved(bool replace)
{
	if (!_objcomp.IsValid())
		return;

	CheckPassPoint(m_spline.Points.Num() - 1);

	AGamePlayer * pActor = Cast<AGamePlayer>(_objcomp->GetOwner());
	if (!pActor)
		return;
	
	if(!replace)
		pActor->SyncPushMoveToServer("HPBezierMoveBehavior Remove", ESyncMoveSendType::Stop, true, false);

	if (pActor->IsMotorVehicle())
	{
		AMotorVehicleCharacter * pMotor = Cast<AMotorVehicleCharacter>(pActor);
		if (pMotor)
			pMotor->EndForceMoveShow();
	}
}

void HPBezierMoveBehavior::SetCurPos(const FVector & pos,const FVector & dir)
{
	if (!_objcomp.IsValid())
		return ;

	AGamePlayer * pActor = Cast<AGamePlayer>(_objcomp->GetOwner());
	if (!pActor)
		return;

	FVector old_pos = pActor->GetFeetLocation();	

	FVector abs_pos;
	if (m_isOnCarrier)//如果在船上，pos是相对位置
	{
		if (m_carrier.IsValid())
		{
			AGamePlayer * pCarrier = m_carrier.Get();
			FVector t2 = pCarrier->GetFeetLocation();
			FRotator r2 = pCarrier->GetActorRotation();
			FVector abs_dir;
			AzureUtility::CalAbsPosInfo(pos, dir.Rotation(), t2, r2, abs_pos, abs_dir);
			pActor->SetActorRotation(abs_dir.Rotation());
		}
		else
		{
			MyPrintString2("HPBezierMoveBehavior carrier is not invalid 2", FLinearColor::Red);
			return;
		}
	}
	else
	{
		abs_pos = pos;
		float pitch = pActor->GetActorRotation().Pitch;
		FRotator rot = dir.Rotation();
		rot.Pitch = pitch;
		pActor->SetActorRotation(rot);
	}
	
	pActor->SetFeetLocation2(abs_pos);
	
	
	if (false)
	{
		FVector v1 = abs_pos;
		FVector v2 = v1 + FVector::UpVector * 200.0f;
		UKismetSystemLibrary::DrawDebugLine(pActor->GetWorld(), v1, v2, FLinearColor::Green,5.0f);
	}
	
}

FVector HPBezierMoveBehavior::CalPosDirByPercent(class AGamePlayer * pActor, float percent, bool bGround, FVector & pos, FVector & dir)
{
	FVector tmpPos = m_spline.Eval(percent, FVector::ZeroVector, nullptr);

	FVector curPos, curDir;
	GetCurPosAndDir(curPos,curDir);

	FVector delta;
	delta = m_spline.EvalDerivative(percent, FVector::ZeroVector, nullptr);
	
	delta.Z = 0.0f;

	if (bGround)//贴地
	{
		FVector testPos;
		testPos.X = tmpPos.X;
		testPos.Y = tmpPos.Y;
		testPos.Z = tmpPos.Z;
		float z = GetGamePlayerPosZ(testPos, pActor);
		tmpPos.Z = z;
	}

	pos = tmpPos;
	dir = delta;

	return curDir;
}

FVector HPBezierMoveBehavior::FindNearestPoint(class AGamePlayer * pActor, float percent, FVector & pos, FVector & nearestPos, FVector & dir, float & nearestPercent)
{
	FVector tmpPos = m_spline.Eval(percent, FVector::ZeroVector, nullptr);

	FVector curPos, curDir;
	GetCurPosAndDir(curPos, curDir);	

	curPos.Z = tmpPos.Z;//3维的，高度取个相近的，如果直接取玩家高度，算出来的最近点可能不是2D的最近点
	
	float minDis = 0.0f;
	float nearest_point_percent = 0.0f;

	if (true)
	{
		FVector curPos2D = curPos;
		curPos2D.Z = 0.0f;

		int32 nearest_segment = -1;
		nearest_point_percent = m_spline2D.InaccurateFindNearest(curPos2D, minDis, &nearest_segment);

		if (nearest_segment - last_segment > 2 || nearest_segment < last_segment)
		{
			//处理取最近点的特殊错误情况，例如曲线有交叉点会导致取到很后面的Percent,像50号曲线
			//写这段代码主要是为了处理曲线重叠情况时取最近点不是逐渐递增的问题

			float same_min_dis;
			float same_segment_nearest_percent = m_spline2D.InaccurateFindNearestOnSegment(curPos2D,last_segment, same_min_dis);

			int32 NumPoints = m_spline2D.Points.Num();
			int32 LastPoint = NumPoints - 1;

			if (last_segment + 1 < LastPoint)
			{
				float next_seg_min_dis;
				float next_seg_nearest_percent = m_spline2D.InaccurateFindNearestOnSegment(curPos2D, last_segment + 1, next_seg_min_dis);
				if (same_min_dis < next_seg_min_dis)
				{
					if (false)
					{					
						FString str = FString::Printf(TEXT("same segment min %0.1f %0.1f %d %d"), same_min_dis, next_seg_min_dis, last_segment, nearest_segment);
						MyPrintString(str);
					}
					
					nearest_point_percent = same_segment_nearest_percent;
					nearest_segment = last_segment;
				}					
				else
				{
					if (false)
					{
						FString str = FString::Printf(TEXT("next segment min %0.1f %0.1f %d %d"), same_min_dis, next_seg_min_dis, last_segment, nearest_segment);
						MyPrintString(str);
					}

					nearest_point_percent = next_seg_nearest_percent; 
					nearest_segment = last_segment + 1;
				}					
			}
			else
			{
				nearest_point_percent = same_segment_nearest_percent;
				nearest_segment = last_segment;

				if (false)
				{
					FString str = FString::Printf(TEXT("same segment only %0.1f %d %d"), same_min_dis, last_segment, nearest_segment);
					MyPrintString(str);
				}
			}
		}
		else
		{
			if (false)
			{
				FString str = FString::Printf(TEXT("no wrong segment happened %d %d"), last_segment, nearest_segment);
				MyPrintString(str);
			}
		}
		
		last_segment = nearest_segment;
	}
	
	FVector delta = m_spline.EvalDerivative(nearest_point_percent, FVector::ZeroVector, nullptr);
	delta.Z = 0.0f;

	FVector tmpNearestPos = m_spline.Eval(nearest_point_percent, FVector::ZeroVector, nullptr);
	float limitDis = pActor->m_forceMoveLimitDis;
	float maxAngle = pActor->m_forceMoveTurnMaxAngle;
	FVector d_nearest = tmpNearestPos - curPos;
	float returnAngle = 0.0f;
	if (d_nearest.Size2D() > limitDis)
	{	
		returnAngle = maxAngle;
	}
	else
	{
		returnAngle = d_nearest.Size2D() / limitDis * maxAngle;
	}
	
	FVector tmp_delta = tmpNearestPos - curPos;
	FVector tmp_curDir = curDir;
	tmp_delta.Z = 0.0f;
	tmp_curDir.Z = 0.0f;

	float real_angle = AzureUtility::Angle2(tmp_curDir, tmp_delta);
	if (real_angle > 0.0f)
		tmp_delta = delta.RotateAngleAxis(returnAngle, FVector::UpVector);
	else
		tmp_delta = delta.RotateAngleAxis(-returnAngle, FVector::UpVector);

	delta = tmp_delta;

	delta.Z = 0.0f;

	if (true)//贴地
	{
		FVector testPos;
		testPos.X = tmpPos.X;
		testPos.Y = tmpPos.Y;
		testPos.Z = tmpPos.Z;
		float z = GetGamePlayerPosZ(testPos, pActor);
		tmpPos.Z = z;
		tmpNearestPos.Z = z;
	}

	pos = tmpPos;
	nearestPos = tmpNearestPos;
	dir = delta;

	nearestPercent = nearest_point_percent;

	return curDir;
}

void HPBezierMoveBehavior::CheckPassPoint(float percent)
{
	int checkIndex = m_event_call_index + 1;

	int num = m_real_events.Num();
	for (int i = checkIndex; i < num; i++)//事件是按照比例从小到大排序的，可能有多个相等的
	{
		if (last_percent <= m_real_events[i] && percent >= m_real_events[i])
		{
			CallPassPointLua(i);
			m_event_call_index = i;
		}
	}

	last_percent = percent;
}

int HPBezierMoveBehavior::IsPassPoint(float p, float lastp)
{
	int checkIndex = m_event_call_index + 1;
	if (checkIndex < m_real_events.Num())
	{
		if (lastp <= m_real_events[checkIndex] && p >= m_real_events[checkIndex])
			return checkIndex;
	}

	return -1;
}

void HPBezierMoveBehavior::CallPassPointLua(int index)
{
	if (!_objcomp.IsValid())
		return;

	lua_State_Wrapper L = AAzureEntryPoint::Instance->GetL();
	if (!L)
		return;

	lua_rawgeti(L, LUA_REGISTRYINDEX, _objcomp->GetLuaECObject()); // obj
	lua_getfield(L, -1, "OnPassBezierPoint"); // 
	lua_pushvalue(L, -2);
	lua_pushnumber(L, index);
	AAzureEntryPoint::Instance->GetWLua()->Call(2);
	lua_pop(L, 1);
}

bool HPBezierMoveBehavior::TickInternal(float dt)
{
	if (!HPMoveBase::TickInternal(dt))
		return false;

	bool hr = false;
	if (m_move_type == 1)
	{
		hr = TickVehicleMove(dt);
	}
	else if (m_move_type == 2)
	{
		hr = TickFollowMove(dt);
	}
	
	return hr;
}

bool HPBezierMoveBehavior::TickVehicleMove(float dt)
{
	if (!_objcomp.IsValid())
		return true;

	AGamePlayer * pActor = Cast<AGamePlayer>(_objcomp->GetOwner());
	if (!pActor)
		return true;

	float percent = m_curDist / m_totalDist * m_spline.Points.Last().InVal;

	FVector vDest, vNearestPos, destDir, curDir, resultDir;
	float nearest_percent;

	curDir = FindNearestPoint(pActor, percent, vDest, vNearestPos, destDir, nearest_percent);
	curDir.Z = 0.0f;

	if (nearest_percent >= m_spline.Points.Last().InVal)
		return true;

	CheckPassPoint(nearest_percent);

	//MyPrintString(" ");
	if (pActor->IsMotorVehicle())
	{
		AMotorVehicleCharacter * pMotor = Cast<AMotorVehicleCharacter>(pActor);
		if (pMotor)
		{
			float angle = AzureUtility::Angle2(curDir, destDir);
			angle *= pActor->m_forceMoveAngleScale;
			pMotor->UpdateForceMoveShow(angle, _speed, dt);
		}
	}

	FRotator resultRot = FMath::RInterpTo(curDir.Rotation(), destDir.Rotation(), dt, pActor->m_forceMoveRotSpeed);
	resultDir = resultRot.Vector();

	if (false)
	{
		float c = curDir.Rotation().Yaw;
		float t = destDir.Rotation().Yaw;
		float r = resultDir.Rotation().Yaw;
		float d = dt * pActor->m_forceMoveRotSpeed;
		FString str = FString::Printf(TEXT("turn ctrd %0.1f %0.1f %0.1f %0.1f : %0.4f %0.1f"), c, t, r, d, dt, pActor->m_forceMoveRotSpeed);
		MyPrintString(str);
	}

	//SetCurPos(vDest, resultDir);
	pActor->AddMovementInput(resultDir);

	if (true)
	{
		FRotator rot = resultDir.Rotation();
		rot.Pitch = pActor->GetActorRotation().Pitch;
		rot.Roll = pActor->GetActorRotation().Roll;
		pActor->SetActorRotation(rot);
	}


	if (gGamePlayerManager.debug_bezier)
	{
		FVector p1 = pActor->GetActorLocation();
		FVector p2 = destDir.GetSafeNormal() * 500.0f + p1;
		UKismetSystemLibrary::DrawDebugLine(pActor->GetWorld(), p1, p2, FColor::Purple);

		FVector size(20, 20, 800);
		FVector nearPos = vNearestPos;
		nearPos.Z = p1.Z;
		UKismetSystemLibrary::DrawDebugBox(pActor->GetWorld(), nearPos, size, FColor::Purple);

		FVector p3 = p1;
		p3.Z -= 10.0f;
		FVector p4 = curDir.GetSafeNormal() * 500.0f + p1;
		UKismetSystemLibrary::DrawDebugLine(pActor->GetWorld(), p3, p4, FColor::Red);

		FVector p5 = p1;
		p5.Z -= 5.0f;
		FVector p6 = resultDir.GetSafeNormal() * 500.0f + p1;
		UKismetSystemLibrary::DrawDebugLine(pActor->GetWorld(), p5, p6, FColor::Green);

		AMotorVehicleCharacter * pMotor = Cast<AMotorVehicleCharacter>(pActor);
		if (pMotor)
		{
			FString str = FString::Printf(TEXT("%0.1f"), pMotor->currentWheelYaw);
			UKismetSystemLibrary::DrawDebugString(pActor->GetWorld(), (p4 + p2) / 2.0f, str, nullptr, FLinearColor::Red);
		}
	}

	m_time += dt;
	m_curDist += _speed * dt;

	if (pActor->m_fSyncPushMoveTimer >= Azure::host_send_sync_info_interval)//
	{
		pActor->SyncPushMoveToServer("HPBezierMoveBehavior Tick", ESyncMoveSendType::None, false, false);
	}

	//DrawDebugWholeSpline(pActor,dt);

	//画切线
	if (gGamePlayerManager.debug_bezier && false)
	{
		FVector tmpPos = vDest;
		tmpPos.Z += 200.0f;

		FVector tangent = m_spline.EvalDerivative(percent, FVector::ZeroVector, nullptr);
		DrawCurTangent(pActor, tmpPos, tangent);
	}

	if (gGamePlayerManager.debug_bezier && false)//画地面法线
	{
		FVector tmpPos = vDest;

		AMotorVehicleCharacter * pMotor = Cast<AMotorVehicleCharacter>(pActor);
		if (pMotor)
		{
			FVector p2 = pMotor->curGroundNomalDir.GetSafeNormal() * 500.0f + tmpPos;
			UKismetSystemLibrary::DrawDebugLine(pMotor->GetWorld(), tmpPos, p2, FLinearColor::Blue);
		}
	}

	return false;
}

bool HPBezierMoveBehavior::TickFollowMove(float dt)
{
	if (!_objcomp.IsValid())
		return true;

	AGamePlayer * pActor = Cast<AGamePlayer>(_objcomp->GetOwner());
	if (!pActor)
		return true;


	float percent = m_curDist / m_totalDist * m_spline.Points.Last().InVal;

	if (percent >= m_spline.Points.Last().InVal)
	{
		if (m_loop)
		{
			m_curDist -= m_totalDist;
			percent = m_curDist / m_totalDist * m_spline.Points.Last().InVal;
		}
		else
		{
			return true;
		}		
	}
		

	FVector curDir, vDest, dir;
	curDir = CalPosDirByPercent(pActor, percent, m_ground_move, vDest, dir);

	SetCurPos(vDest, dir);

	CheckPassPoint(percent);

	//MyPrintString(" ");
	if (pActor->IsMotorVehicle())
	{
		AMotorVehicleCharacter * pMotor = Cast<AMotorVehicleCharacter>(pActor);
		if (pMotor)
		{
			float angle = AzureUtility::Angle2(curDir, dir);
			angle *= pActor->m_forceMoveAngleScale;
			pMotor->UpdateForceMoveShow(angle, _speed, dt);
		}
	}	

	if (true)
	{
		FRotator rot = dir.Rotation();
		rot.Pitch = pActor->GetActorRotation().Pitch;
		rot.Roll = pActor->GetActorRotation().Roll;
		pActor->SetActorRotation(rot);
	}

	m_time += dt;
	m_curDist += _speed * dt;

	if (pActor->m_fSyncPushMoveTimer >= Azure::host_send_sync_info_interval)//
	{
		pActor->SyncPushMoveToServer("HPBezierMoveBehavior Follow Tick", ESyncMoveSendType::None, false, false);
	}

	return false;
}

void HPBezierMoveBehavior::StopLoop()
{
	m_loop = false;//中断循环后，会运行到终点，也就是起点位置（lua层里把起点加为最后一个点，终点），结束
}

void HPBezierMoveBehavior::DrawDebugWholeSpline(class AGamePlayer * pActor, float dt)
{
	if (true)
	{		
		int num = m_steps;
		float oneStep = m_spline.Points.Last().InVal / num;
		
		TArray<float> delta_dis;
		delta_dis.AddZeroed(num);
		FVector last_p;
		
		for (int i = 0; i < num; i++)
		{
			float percent = i * oneStep;
			FVector p1 = m_spline.Eval(percent, FVector::ZeroVector, nullptr);
			FVector p2 = p1;
			p2.Z += 1000.0f;
			UKismetSystemLibrary::DrawDebugLine(pActor->GetWorld(), p1, p2, FLinearColor::Yellow);

			FString str = FString::Printf(TEXT("%d"), i);
			UKismetSystemLibrary::DrawDebugString(pActor->GetWorld(),(p1 + p2)/2.0f, str, nullptr, FLinearColor::Red);

			if (i >= 1)
			{
				float d2 = (p1 - last_p).Size();
				delta_dis[i] = d2;
			}
			else
			{
				delta_dis[i] = 0.0f;
			}

			last_p = p1;
		}

		FVector size(20, 20, 1000);
		num = m_spline.Points.Num();
		for (int i = 0; i < num; i++)
		{
			FVector p1 = m_spline.Points[i].OutVal;
			p1.Z += size.Z / 2.0f;
			UKismetSystemLibrary::DrawDebugBox(pActor->GetWorld(), p1, size, FLinearColor::Green);

			FVector anchor_arrive = m_spline.Points[i].ArriveTangent + p1;
			UKismetSystemLibrary::DrawDebugLine(pActor->GetWorld(), p1, anchor_arrive, FLinearColor::Red);

			FVector anchor_leave = m_spline.Points[i].LeaveTangent + p1;
			UKismetSystemLibrary::DrawDebugLine(pActor->GetWorld(), p1, anchor_leave, FLinearColor::Blue);

		}

		FVector size2(20, 20, 500);
		num = m_real_events.Num();
		for (int i = 0; i < num; i++)
		{
			float pp = m_real_events[i];
			FVector p1 = m_spline.Eval(pp, FVector::ZeroVector, nullptr);;
			p1.Z += size2.Z / 2.0f;
			UKismetSystemLibrary::DrawDebugBox(pActor->GetWorld(), p1, size2, FLinearColor::Red);

			FString str = FString::Printf(TEXT("%d %0.2f"), i,pp);
			UKismetSystemLibrary::DrawDebugString(pActor->GetWorld(), p1, str, nullptr, FLinearColor::Green);
		}
	}
}

void HPBezierMoveBehavior::DrawCurTangent(AGamePlayer * pOwner, const FVector & pos, const FVector & dir)
{
	FVector p2 = dir.GetSafeNormal2D() * 500.0f + pos;
	UKismetSystemLibrary::DrawDebugLine(pOwner->GetWorld(), pos, p2, FLinearColor::Blue);

	FVector p3 = pos;
	p3.Z += 5.0f;
	p2 = pOwner->GetActorForwardVector().GetSafeNormal2D() * 500.0f + p3;
	UKismetSystemLibrary::DrawDebugLine(pOwner->GetWorld(), pos, p2, FLinearColor::Red);
}


