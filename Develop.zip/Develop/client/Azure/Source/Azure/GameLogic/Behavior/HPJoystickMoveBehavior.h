#pragma once
#include "HPMoveBase.h"
#include "UE4Related.h"

class HPJoystickMoveBehavior : public HPMoveBase
{
protected:
	static constexpr  Azure::BehaviorType _type = Azure::BehaviorType::HPJoystickMove;

	bool is_skill_move; 
	float enterDashTime = 0.0f;//���ܼ��ܽ��뼲�ܵļ�ʱ
	float enterDashTime_move_input = 0.0f;//����ǰ��������뼲�ܼ�ʱ

	bool is_last_frame_input = false;

	double start_time = 0.0f;

	float default_walk_input_time = 0.0f;
	int default_walk_stage = 0;//0 not default walk;1 default walk;2 default walk reach max speed

public:
	HPJoystickMoveBehavior()
	{
		
	}

	Azure::BehaviorType get_Type() const override
	{
		return _type;
	}

	static HPJoystickMoveBehavior* Create();

	bool SetData(float fMoveSpeed, float fTurnSpeed, OnBehaviorFinish onFinish, bool isSkillMove);

	virtual void OnRemoved(bool replace) override;

	void StopDash();

protected: 

	
	virtual bool TickInternal(float dt) override;

	void DealEnterDashTime(FVector inputValue,float dt);
	void ClearDashTime();
	void RemoveDashState();
	
	bool NeedForbidInputByDashStop();  
	bool NeedForbidInputByRunStop();
	
	virtual const FRotator GetActorControlRotation();
	bool PlayDashStop(const FVector & input_dir);
	
	void SetReadyEnterDash(bool b);
	void SetReadyEnterDashMoveInput(bool b);

	bool IsEnterDashInput(const FVector & inputValue);

	bool IsEnterDashInputByDodge(const FVector & inputValue);

	bool IsEnterDashInput2(const FVector & inputValue);

	void UpdateDashStopType();

	float CalSpeedScaleByTurn(const FVector & inputdir);

	void PlayNormalStop(int play_type);

	int CheckPlayNormalTurn180(const FVector & input);
	void UpdateRunStopType();

	bool CanPlayNormalStop(int type);

	//bool CanPlayDashStop(int type);

	void DealDefaultWalkTime(float dt,const FVector & input, float speed);

	bool IsDefaultWalkMode();

	void OnDefaultWalkTimeUp();

	void ReturnToDefaultWalk();

	float LimitSpeedByGear(float inputValue);

	bool CanPlayDashStop(int type);

	bool CheckNotKeySyncNeedChangeToKey(class AGamePlayer * pActor);
};