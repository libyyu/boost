#pragma once

#include "AzureBehavior.h"

void MyPrintString(FString str);
//ElsePlayer Monster

//////////////////////////////////////////////////////////////////////////
class ObjServerRootMotionMoveBehavior : public AzureBehavior
{
protected:
	static constexpr  Azure::BehaviorType _type = Azure::BehaviorType::ObjServerRootMotionMove;

	TWeakObjectPtr<class UAnimMontage> m_montage = nullptr;
public:

	ObjServerRootMotionMoveBehavior()
	{
		
	}

	Azure::BehaviorType get_Type() const override
	{
		return _type;
	}

	static ObjServerRootMotionMoveBehavior* Create()
	{
		ObjServerRootMotionMoveBehavior* ret = (ObjServerRootMotionMoveBehavior*)AzureBehaviorCache::GetInstance().GetBehavior(_type);

		if (ret == nullptr)
		{
			ret = new ObjServerRootMotionMoveBehavior();
		}

		return ret;
	}

    bool SetData(UAnimMontage * montage, bool bRelativePosition, bool bRelativeRotation, const FVector location, const FRotator rotator, float trackPosition, float smoothLocationTime);
	bool Tick(float dt) override;
	virtual void OnRemoved(bool replace) override;

	void UpdateSyncTime(class AGamePlayer * pObj, float smoothLocationTime);
};

