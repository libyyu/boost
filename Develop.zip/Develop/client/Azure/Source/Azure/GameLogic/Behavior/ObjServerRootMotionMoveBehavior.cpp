//#include "Azure.h"
#include "ObjServerRootMotionMoveBehavior.h"
#include "AzureObjectComponent.h"
#include "UE4Related.h"
#include "AzureUtility.h"
#include "GameLogic/Player/GamePlayer.h"
#include "GameLogic/Player/GamePlayer_Util.h"
#include "GameFramework/CharacterMovementComponent.h"
#include "Kismet/KismetSystemLibrary.h"
#include "AzureTimeManager.h"
#include "AzureGameSession.h"
#include "HPMoveBase.h"
#include "Animation/AnimMontage.h"

using namespace Azure;

//////////////////////////////////////////////////////////////////////////

bool ObjServerRootMotionMoveBehavior::SetData(
		UAnimMontage * montage, 
		bool bRelativePosition, 
		bool bRelativeRotation, 
		const FVector location, 
		const FRotator rotator,
		float trackPosition,
		float smoothLocationTime
	)
{
	if (!_objcomp.IsValid())
		return false;

	AGamePlayer * pObj = Cast<AGamePlayer>(_objcomp->GetOwner());
	if (!pObj) {
		return false;
	}

	// location is feet location, need apply offset to actor location
	int zOffset = pObj->GetActorLocation().Z - pObj->GetFeetLocation().Z;

	m_montage = montage;

	if (!AAzureEntryPoint::Instance)
		return false;

	double st = AAzureEntryPoint::Instance->GetRealtimeSinceStartup();

	// 构造RepRootMotion
	FRepRootMotionMontage RepRootMotion;
	UCharacterMovementComponent* CharacterMovement = pObj->GetCharacterMovement();
	const FAnimMontageInstance* RootMotionMontageInstance = pObj->GetRootMotionAnimMontageInstance();

	RepRootMotion.bIsActive = true;
	RepRootMotion.bRelativePosition = bRelativePosition;
	RepRootMotion.bRelativeRotation = bRelativeRotation;
	RepRootMotion.Location = location;
	RepRootMotion.Location.Z += zOffset;
	RepRootMotion.Rotation = rotator;
	RepRootMotion.MovementBase = pObj->GetBasedMovement().MovementBase;
	RepRootMotion.MovementBaseBoneName = pObj->GetBasedMovement().BoneName;
	RepRootMotion.AnimMontage = montage;
	RepRootMotion.Position = trackPosition;
	RepRootMotion.AuthoritativeRootMotion = CharacterMovement->CurrentRootMotion;

	// 更新SyncTime，供Mesh平滑
	UpdateSyncTime(pObj, smoothLocationTime);

    // 模拟收到同步协议，开始Actor移动模拟
	pObj->RepRootMotion = RepRootMotion;
	pObj->OnRep_RootMotion();

	return true;
}

void ObjServerRootMotionMoveBehavior::UpdateSyncTime(AGamePlayer * pObj, float smoothLocationTime)
{
	pObj->GetCharacterMovement()->NetworkSimulatedSmoothLocationTime = smoothLocationTime;

	float deltaTime = pObj->GetWorld()->GetDeltaSeconds();
	pObj->sync_time = pObj->GetCharacterMovement()->NetworkSimulatedSmoothLocationTime - deltaTime;
	pObj->sync_rot_time = pObj->GetCharacterMovement()->NetworkSimulatedSmoothRotationTime - deltaTime;

	if (pObj->sync_time < 0.0f)
		pObj->sync_time = 0.0f;

	if (pObj->sync_rot_time < 0.0f)
		pObj->sync_rot_time = 0.0f;
}

bool ObjServerRootMotionMoveBehavior::Tick(float dt)
{
	if (!_objcomp.IsValid())
		return true;

	AGamePlayer * pObj = Cast<AGamePlayer>(_objcomp->GetOwner());
	if (!pObj) {
		return true;
	}

	const FAnimMontageInstance* RootMotionMontageInstance = pObj->GetRootMotionAnimMontageInstance();
	if (RootMotionMontageInstance == nullptr || RootMotionMontageInstance->Montage != m_montage) {
		return true;
	}

	return false;
}

void ObjServerRootMotionMoveBehavior::OnRemoved(bool replace)
{
	if (!_objcomp.IsValid())
		return;

	AGamePlayer* obj = Cast<AGamePlayer>(_objcomp->GetOwner());
	if (!replace)
	{
		if (obj)
			obj->StopMyReplicatedMovement();
	}

	if (false)
	{
		if (!replace)
			MyPrintString("ObjServerRootMotionMoveBehavior End false");
		else
			MyPrintString("ObjServerRootMotionMoveBehavior End true");
	}
}

