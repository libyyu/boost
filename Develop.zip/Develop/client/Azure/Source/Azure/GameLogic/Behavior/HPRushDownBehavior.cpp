﻿//#include "Azure.h"
#include "HPRushDownBehavior.h"
#include "AzureObjectComponent.h"
#include "UE4Related.h"
#include "AzureUtility.h"
#include "Kismet/KismetSystemLibrary.h"
#include "GameLogic/Player/GamePlayer.h"
#include "GameLogic/Player/GamePlayer_Util.h"

using namespace Azure;

//////////////////////////////////////////////////////////////////////////
//vDest是目标点位置，t是上升下落总时间，h是击飞高度
//vDest是先根据击飞的水平距离，然后跟地形打线得出的值
bool HPRushDownBehavior::SetData(const FVector & vDir, float speed, float max_dis, OnBehaviorFinish onFinish)
{
	if (!_objcomp.IsValid())
		return false;

	AGamePlayer * pObj = Cast<AGamePlayer>(_objcomp->GetOwner());
	if (!pObj)
		return false;	

	_objcomp->RemoveBehavior(Azure::BehaviorType::HPJump);

	set_OnFinish(onFinish);

	m_max_dis = max_dis;
	m_speed = speed;

	m_start = pObj->GetFeetLocation();

	if (vDir.Size() < 0.001f || vDir.Z >= 0.0f)//方向有错误，Z向下，而且大小不能太小
	{
		m_velocity = -FVector::UpVector * speed;
	}
	else
	{
		m_velocity = vDir.GetSafeNormal() * speed;
	}

	if (m_max_dis <= 0.0f)
		m_max_dis = 10000.0f;
		
	//重力让lua代码控制，避免释放技能时，重力的状态控制被双方同时设置导致混乱
	m_gravityScale = pObj->GetCharacterMovement()->GravityScale;
	//pObj->GetCharacterMovement()->GravityScale = 0.0f;
	pObj->LaunchCharacter(m_velocity, true, true);

	if (false)
	{
		FString str = FString::Printf(TEXT("RushDown start--%0.3f velocity--%0.1f %0.1f %0.1f pos--%0.1f %0.1f %0.1f"), pObj->GetCharacterMovement()->GravityScale
		, m_velocity.X, m_velocity.Y, m_velocity.Z, m_start.X,m_start.Y,m_start.Z);
		MyPrintString(str);
	}

	if (false)
	{
		if (!AAzureEntryPoint::Instance)
			return false;

		double st = AAzureEntryPoint::Instance->GetRealtimeSinceStartup();
		FString str = FString::Printf(TEXT("RushDown Start--%0.3f"),st);
		MyPrintString(str);
	}

	return true;
}

bool HPRushDownBehavior::Tick(float dt)
{
	if (!_objcomp.IsValid())
		return true;

	AGamePlayer * pObj = Cast<AGamePlayer>(_objcomp->GetOwner());
	if (!pObj)
		return true;

	FVector curPos = pObj->GetFeetLocation();
	float dis = (curPos - m_start).Size();
	if (dis >= m_max_dis)
		return true;

	if (!pObj->GetCharacterMovement()->IsFalling())
	{
		if (false)
		{
			if (!AAzureEntryPoint::Instance)
				return true;

			double st = AAzureEntryPoint::Instance->GetRealtimeSinceStartup();
			FString str = FString::Printf(TEXT("RushDown TickReturn--%0.3f"),st);
			MyPrintString(str);
		}

		return true;
	}
		

	//pObj->GetCharacterMovement()->bRequestedMoveUseAcceleration = false;
	//pObj->GetCharacterMovement()->RequestDirectMove(m_velocity, false);

	if (false)
	{
		FString str = FString::Printf(TEXT("RushDown tick--%0.3f velocity--%0.1f %0.1f %0.1f pos--%0.1f %0.1f %0.1f"), pObj->GetCharacterMovement()->GravityScale
			, m_velocity.X, m_velocity.Y, m_velocity.Z, m_start.X, m_start.Y, m_start.Z);
		MyPrintString(str);
	}

	return false;
}

void HPRushDownBehavior::OnRemoved(bool replace)
{
	if (!_objcomp.IsValid())
		return;

	AGamePlayer * pObj = Cast<AGamePlayer>(_objcomp->GetOwner());
	if (pObj && pObj->GetCharacterMovement())
	{
		//pObj->GetCharacterMovement()->GravityScale = m_gravityScale;
		pObj->GetCharacterMovement()->Velocity = FVector(0, 0, 0);
		//pObj->SyncPushMoveToServer("HPRushDown End");落地的时候会再jump_end里同步

		if (false)
		{
			FString str = FString::Printf(TEXT("RushDown OnRemoved--%0.3f velocity--%0.1f %0.1f %0.1f pos--%0.1f %0.1f %0.1f"), pObj->GetCharacterMovement()->GravityScale
				, m_velocity.X, m_velocity.Y, m_velocity.Z, m_start.X, m_start.Y, m_start.Z);
			MyPrintString(str);
		}

		if (false)
		{
			if (!AAzureEntryPoint::Instance)
				return;

			double st = AAzureEntryPoint::Instance->GetRealtimeSinceStartup();
			FString str = FString::Printf(TEXT("RushDown OnRemoved--%0.3f"), st);
			MyPrintString(str);
		}
	}		
}

