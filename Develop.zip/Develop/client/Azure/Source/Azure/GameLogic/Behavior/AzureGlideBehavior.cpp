﻿//#include "Azure.h"
#include "AzureGlideBehavior.h"
#include "AzureObjectComponent.h"
#include "GameLogic/Player/GamePlayer.h"
#include "DrawDebugHelpers.h"
#include "AzureUtility.h"
#include "GameLogic/Input/AzureInputCtrl.h"

//////////////////////////////////////////////////////////////////////////
//
//	Class AzureBezierMoveBehavior
//
//////////////////////////////////////////////////////////////////////////

bool AzureGlideBehavior::SetData(const GlideParam& glideParam)
{
	m_vLandPos = glideParam.vLandPos;
	m_fForwardSpeed = glideParam.fForwardSpeed;
	m_fFallingSpeed = glideParam.fFallingSpeed;
	m_fFreeFallingSpeed = glideParam.fFreeFallingSpeed;
	m_fLandMinSpeed = FMath::Min(glideParam.fLandMinSpeed, m_fFallingSpeed);
	m_fTurnSpeedInRadian = glideParam.fTurnSpeedInRadian;
	m_eCtrlMode = glideParam.eCtrlMode;
	m_fLandDuration = glideParam.fLandDuration;
	float fallingSpeed = glideParam.eCtrlMode == GlideCtrlMode::FreeFalling ? m_fFreeFallingSpeed : m_fFallingSpeed;

	m_fLandHeight = FMath::Max(0.0f, (m_fForwardSpeed + fallingSpeed + m_fLandMinSpeed) * m_fLandDuration / 2.0f); //开始着陆的高度
	if (!m_bInit)
	{
		GetNextMoveDir(m_vCurMoveDir);
		ResetLandData();
	}
	m_bInit = true;
	return true;
}

bool AzureGlideBehavior::Tick(float dt)
{
	AActor* pActor = GetMovableActor();
	if (!pActor)
		return true;
	const float maxFPS = GEngine->GetMaxFPS();
	if (maxFPS > 0)
	{
		dt = 1 / maxFPS;
	}	
	
	FVector vLastPos = pActor->GetActorLocation();
	FVector vNextDir;
	GetNextMoveDir(vNextDir);

	FVector vSmoothNextDir;
	InterpretMoveDir(m_vCurMoveDir, vNextDir, vSmoothNextDir);

	const float fNextMoveZ = vSmoothNextDir.Z;
	const float fNextMoveH = vSmoothNextDir.Size2D();
	FVector vMoveDir;
	if (fNextMoveH > 0) 
	{
		//只处理水平方向
		vSmoothNextDir.Z = 0;
		m_vCurMoveDir.Z = 0;
		vSmoothNextDir.Normalize();
		m_vCurMoveDir.Normalize();

		//计算水平旋转旋转
		FVector vTurnDir = vSmoothNextDir - m_vCurMoveDir;
		const float fTurnSize = vTurnDir.Size();
		const float fDeltaTurn = m_fTurnSpeedInRadian * dt;
		
		if (fTurnSize <= fDeltaTurn)
		{
			vMoveDir = vSmoothNextDir;
		}
		else
		{
			vTurnDir.Normalize();
			vMoveDir = m_vCurMoveDir + vTurnDir * fDeltaTurn; //只限制水平转向速度
		}

		FRotator vActorRotator = vMoveDir.ToOrientationRotator();
		vActorRotator.Yaw = vActorRotator.Yaw; //平滑处理
		vActorRotator.Pitch = 0.0f;
		vActorRotator.Roll = 0.0f;
		pActor->SetActorRotation(vActorRotator);

		//恢复比例
		vMoveDir.Normalize();
		vMoveDir *= fNextMoveH;
		vMoveDir.Z = fNextMoveZ;
	}
	else
	{
		vMoveDir.X = 0;
		vMoveDir.Y = 0;
		vMoveDir.Z = -1; //方向向下
	}
	
	m_vCurMoveDir = vMoveDir;

	float fForwardSpeed = GetNextMoveForwardSpeed();
	vMoveDir*= fForwardSpeed;
	vMoveDir.Z = vMoveDir.Z - GetNextFallingSpeed();
	float landSpeedZ = 0.0f;
	float speedScale = 1.0f;
	if (GetLandSpeedZ(landSpeedZ, speedScale, dt))
	{
		vMoveDir *= speedScale;
		vMoveDir.Z = FMath::Min(0.0f, landSpeedZ);
	}

	//根据移动方向设置动作参数
	SetAnimationParam(vMoveDir, vNextDir, fForwardSpeed);

	landSpeedZ = vMoveDir.Z;
	if (FMath::IsNearlyZero(landSpeedZ))
	{
		return true; //下落速度为0，结束
	}
	FVector vTargetPos = vLastPos + vMoveDir * dt;
	m_fTestHeight += landSpeedZ * dt;
	const float checkHeight = GetCollisionCheckDistance();
	const float fCheckTime = checkHeight / -landSpeedZ;
	FVector vCheckMovePos = vLastPos + vMoveDir * FMath::Max(fCheckTime, dt);
	bool bCanContinueGlide = true;
	bool bFinalReturn = false;

	if (!CanMoveTo(vLastPos, vCheckMovePos)) //检查是否可以移动到目标
	{
		vCheckMovePos = vLastPos;
		const float fFallingDelta = -landSpeedZ * dt;
		vCheckMovePos.Z = vLastPos.Z - FMath::Max(checkHeight, fFallingDelta);
		if (!CanMoveTo(vLastPos, vCheckMovePos))
		{
			bCanContinueGlide = false;
		}
		else
		{
			vTargetPos.Z = vLastPos.Z - FMath::Min(checkHeight, fFallingDelta);
		}
	}
	else if (m_bStartLand && m_fLandHeight > checkHeight) //检查是否要退出着陆
	{
		vCheckMovePos = vTargetPos;
		vCheckMovePos.Z = vTargetPos.Z - m_fLandHeight;
		if (CanMoveTo(vLastPos, vCheckMovePos)) //目标高度高于着陆高度
		{
			m_bStartLand = false;
		}
	}

	//如果是固定点（GlideCtrlMode::FixLandPos），检查是否反向，这里简单比较Z值
	if (m_eCtrlMode == GlideCtrlMode::FixLandPos)
	{
		if (vTargetPos.Z <= m_vLandPos.Z)
		{
			bFinalReturn = true;
		}
	}
	if (!bCanContinueGlide)
	{
		if (!HandleLandingWhenCollision(landSpeedZ))
		{
			return true;
		}	
	}
	if (!RecordLandPassTime(dt))
	{
		return true;
	}
	pActor->SetActorLocation(vTargetPos);

	AGamePlayer* pOwner = Cast<AGamePlayer>(_objcomp.IsValid() ? _objcomp->GetOwner() : nullptr);
	AGamePlayer* pSyncActor = Cast<AGamePlayer>(pActor);
	if (m_eCtrlMode != GlideCtrlMode::TeamFollow && pOwner && pOwner->IsHostPlayer() && pSyncActor)
	{
		pSyncActor->m_fSyncPushMoveTimer += dt;
		if (pSyncActor->m_fSyncPushMoveTimer >= Azure::host_send_sync_info_interval)//
		{
			pSyncActor->SyncPushMoveToServer("Glide Tick", ESyncMoveSendType::Glide, true, false);
		}
	}
	if (false)
	{
		UWorld* pWorld = AAzureEntryPoint::Instance->GetWorld();
		if (pWorld)
		{
			DrawDebugDirectionalArrow(pWorld, vLastPos, vTargetPos, 10, FColor::Red, true, 100);
		}
		UE_LOG(LogAzure, Warning, TEXT("glide variable:%f, %f, %f, %f, %f, %f"), dt, vMoveDir.Size(), landSpeedZ, m_fTestHeight, vTargetPos.Z, vLastPos.Z);
	}
	return bFinalReturn;
}

void AzureGlideBehavior::OnRemoved(bool replace)
{
	if (!replace)
	{
		m_bInit = false;
		ResetLandData();
		HandleRemoveInLua();
	}
}

float AzureGlideBehavior::GetNextMoveForwardSpeed() const
{
	if (m_eCtrlMode == GlideCtrlMode::UseCameraDir)
	{
		FVector2D v = AzureInputCtrl::GetInstance().GetJoyStickValue();
		if (v.IsNearlyZero())
		{
			return 0;
		}
		else
		{
			return m_fForwardSpeed;
		}
	}
	else if (m_eCtrlMode == GlideCtrlMode::FreeFalling)
	{
		return 0;
	}
	else
	{
		return m_fForwardSpeed;
	}
}

float AzureGlideBehavior::GetNextFallingSpeed() const
{
	if (m_eCtrlMode == GlideCtrlMode::FreeFalling)
	{
		return m_fFreeFallingSpeed;
	}
	else
	{
		return m_fFallingSpeed;
	}
}

void AzureGlideBehavior::GetNextMoveDir(FVector& vNextMoveDir) const
{
	AActor* pObj = _objcomp.IsValid() ? _objcomp->GetOwner() : nullptr;
	if (!pObj)
	{
		//默认下落
		vNextMoveDir.X = 0;
		vNextMoveDir.Y = 0;
		vNextMoveDir.Z = -1;
		return;
	}
	if (m_eCtrlMode == GlideCtrlMode::UseCameraDir)
	{
		UCameraComponent * pCom = Cast<UCameraComponent>(pObj->FindComponentByClass<UCameraComponent>());
		FVector2D joystickValue = AzureInputCtrl::GetInstance().GetJoyStickValue();
		if(!pCom || joystickValue.IsNearlyZero())
		{
			//默认用玩家朝向
			vNextMoveDir = pObj->GetActorForwardVector();
		}
		else
		{
			joystickValue.Normalize();

			FVector cameraForwardVector = pCom->GetForwardVector();
			cameraForwardVector.Z = FMath::Min(cameraForwardVector.Z, 0.0f);
			FVector cameraRightVector = pCom->GetRightVector();

			vNextMoveDir = cameraForwardVector * joystickValue.Y + cameraRightVector * joystickValue.X;
			vNextMoveDir.Z = FMath::Min(vNextMoveDir.Z, 0.0f);
			if (vNextMoveDir.IsNearlyZero())
			{
				vNextMoveDir = pObj->GetActorForwardVector();
			}
			else
			{
				vNextMoveDir.Normalize();
			}
		}
	}
	else if (m_eCtrlMode == GlideCtrlMode::FixLandPos || m_eCtrlMode == GlideCtrlMode::TeamFollow)
	{
		CalcDirFromTargetPos(vNextMoveDir);
	}
	else if (m_eCtrlMode == GlideCtrlMode::FreeFalling)
	{
		vNextMoveDir = pObj->GetActorForwardVector();	
	}
	else
	{
		if (!m_bInit) 
		{
			vNextMoveDir = pObj->GetActorForwardVector();	
		}
		else
		{
			vNextMoveDir = m_vCurMoveDir;	
		}
	}
}

//平滑旋转方向
void AzureGlideBehavior::InterpretMoveDir(const FVector & vCurMoveDir, const FVector & vNextMoveDir, FVector & vOutMoveDir) const
{
	//如果vNextDir 和m_vCurMoveDir 角度过大（水平面）会出现旋转过程中，会有和垂直方向角度先变大后变小的情况
	FVector vNextDirH = FVector(vNextMoveDir.X, vNextMoveDir.Y, 0.0f);
	FVector vCurMoveDirH = FVector(vCurMoveDir.X, vCurMoveDir.Y, 0.0f);

	float fNextDirSize = vNextDirH.Size();
	float fCurMoveDirSize = vCurMoveDirH.Size();
	if (FMath::IsNearlyZero(fNextDirSize) || FMath::IsNearlyZero(fCurMoveDirSize))
	{
		vOutMoveDir = vNextMoveDir;
		return;
	}

	vNextDirH /= fNextDirSize;
	vCurMoveDirH /= fCurMoveDirSize;
	if (FMath::IsNearlyEqual(vNextDirH | vCurMoveDirH, -1.0f)) //方向相反，目标方向改为90度方向
	{
		vNextDirH = vNextDirH ^ FVector::UpVector;
	}
	vOutMoveDir.Z = 0;
	vOutMoveDir.X = vNextDirH.X * 0.125f + vCurMoveDirH.X * 0.875f;
	vOutMoveDir.Y = vNextDirH.Y * 0.125f + vCurMoveDirH.Y * 0.875f;
	vOutMoveDir.Normalize();

	float fOutMoveDirZ = vNextMoveDir.Z * 0.125f + vCurMoveDir.Z * 0.875f; //vNextMoveDir，vCurMoveDir已归一化
	float fOutMoveDirHSize = FMath::Sqrt(1 - fOutMoveDirZ * fOutMoveDirZ); //保持和垂直方向的夹角
	vOutMoveDir *= fOutMoveDirHSize;
	vOutMoveDir.Z = fOutMoveDirZ;
}

void AzureGlideBehavior::CalcDirFromTargetPos(FVector& vNextMoveDir) const
{
	AActor* pObj = _objcomp.IsValid() ? _objcomp->GetOwner() : nullptr;
	if (!pObj)
	{
		//默认下落
		vNextMoveDir.X = 0.0f;
		vNextMoveDir.Y = 0.0f;
		vNextMoveDir.Z = -1;
		return;
	}

	const FVector startPos = pObj->GetActorLocation();
	FVector direction = m_vLandPos - startPos;

	const float fLength2D = direction.Size2D();
	const float fLength3D = direction.Size();
	if (fLength2D == 0.0f || fLength3D == 0.0f)
	{
		//默认下落
		vNextMoveDir.X = 0.0f;
		vNextMoveDir.Y = 0.0f;
		vNextMoveDir.Z = -1;
		return;
	}
	FVector directionH = FVector(direction.X / fLength2D, direction.Y / fLength2D, 0.0f);

	if (m_fFallingSpeed == 0.0f)
	{
		//水平飞
		vNextMoveDir = pObj->GetActorForwardVector();
		vNextMoveDir.Z = 0.0f;
		vNextMoveDir.Normalize();
		return;
	}
	/*
	计算的目的是，下落速度和前进速度的合速度方向是从起始点到目标的方向
	设下列夹角名：
	<direction, horizon> = <d2h> =>DirToHorizon
	<vertical, direction> = <v2d> =>VerticalToDir
	<forward, direction> = <f2d> => ForwardToDir
	<forward, horizon> = <f2h> => ForwardToHorizon
	*/
	float fCosDirToHorizon = fLength2D / fLength3D;
	float fSinDirToHorizon = FMath::Abs(direction.Z) / fLength3D;
	float fSinVerticalToDir = fCosDirToHorizon; // sin(90 - <d2h>)
	float fSinForwardToDir = m_fFallingSpeed / m_fForwardSpeed * fSinVerticalToDir;
	float fCosForwardToDir = FMath::Sqrt(1 - fSinForwardToDir * fSinForwardToDir);
	
	/*
	展开：sin<f2h> = sin(<d2h> - <f2d>) = sin<d2h> * cos<f2d>  - cos<d2h> * sin<f2d>
	展开：cos<f2h> = cos(<d2h> - <f2d>) = cos<d2h> * cos<f2d>  + sin<d2h> * sin<f2d>
	*/
	float fSinForwardToHorizon = fSinDirToHorizon * fCosForwardToDir - fCosDirToHorizon * fSinForwardToDir;
	float fCosForwardToHorizon = fCosDirToHorizon * fCosForwardToDir + fSinDirToHorizon * fSinForwardToDir;
	vNextMoveDir = directionH * fCosForwardToHorizon;
	vNextMoveDir.Z = -fSinForwardToHorizon;
	vNextMoveDir.Normalize();
}

bool AzureGlideBehavior::CanMoveTo(FVector vStartPos, FVector vEndPos) const
{
	AActor* pObj = GetMovableActor();
	AGamePlayer* pGamePlayer = Cast<AGamePlayer>(pObj);
	if (!pGamePlayer)
	{
		return false;
	}

	float fRadius, fHalfHeight;
	pGamePlayer->GetCapsuleComponent()->GetScaledCapsuleSize(fRadius, fHalfHeight);
	FCollisionShape CollisionShape;
	CollisionShape.SetCapsule(fRadius, fHalfHeight);

	if (!AAzureEntryPoint::IsInit())
		return false;

	UWorld* pWorld = AAzureEntryPoint::Instance->GetWorld();
	if (!pWorld)
		return false;

	bool bBlock = false;
	FHitResult thisHitInfo;

	FCollisionQueryParams Params(NAME_None, false); // Not Trace Complex!
	
	bool bHitBlockMove = pWorld->SweepSingleByChannel(thisHitInfo, vStartPos, vEndPos, FQuat::Identity, AzureUtility::TRACE_CHN_BLOCKMOVE, CollisionShape, Params);
	if (bHitBlockMove)
	{
		return false;
	}
	bool bHitWaterSurface = pWorld->SweepSingleByChannel(thisHitInfo, vStartPos, vEndPos, FQuat::Identity, AzureUtility::TRACE_CHN_WATERSUFACE, CollisionShape, Params);
	if (bHitWaterSurface)
	{
		return false;
	}
	return true;
}

void AzureGlideBehavior::SetAnimationParam(const FVector & vMoveDir, const FVector & vNextDir, float fFowardSpeed)
{
	AActor* pActor = GetMovableActor();
	AGamePlayer* pGamePlayer = Cast<AGamePlayer>(pActor);
	if (!pGamePlayer)
	{
		return;
	}
	float moveHorizonSize = vMoveDir.Size2D();
	float nextHorizonSize = vNextDir.Size2D();
	if (FMath::IsNearlyZero(fFowardSpeed) || FMath::IsNearlyZero(moveHorizonSize) || FMath::IsNearlyZero(nextHorizonSize)) //没有前进速度
	{
		pGamePlayer->SetAnimGlidePitchAngle(0);
		pGamePlayer->SetAnimGlideTurnAngle(0);
		pGamePlayer->SetAnimGlideSpeed(0);
		pGamePlayer->FlushGlideAnimParam();
		if (!m_bLanding || (m_fLandDuration - m_fLandPassTime) > 0.1f) //着陆的最后0.1s不生效（避免最后一直为垂直的问题）
		{
			m_fMovePitch = 90.0f;
		}
	}
	else
	{
		FVector vMoveHorizon = FVector(vMoveDir.X, vMoveDir.Y, 0);
		FVector vNextHorizon = FVector(vNextDir.X, vNextDir.Y, 0);
		float pitchAngle = vMoveHorizon | vMoveDir / (moveHorizonSize * vMoveDir.Size()); //算cosine
		float turnAngle = vMoveHorizon | vNextHorizon / (moveHorizonSize * nextHorizonSize);//算cosine

		//取角度
		pitchAngle = 90.0f - FMath::RadiansToDegrees(FMath::FastAsin(FMath::Clamp(pitchAngle, 0.0f, 1.0f)));
		turnAngle = 90.0f - FMath::RadiansToDegrees(FMath::FastAsin(FMath::Clamp(turnAngle, 0.0f, 1.0f)));

		FVector vTurnCrossDir = vMoveHorizon ^ vNextHorizon;
		turnAngle = FMath::Sign(vTurnCrossDir.Z) * turnAngle;

		pGamePlayer->SetAnimGlidePitchAngle(pitchAngle);
		pGamePlayer->SetAnimGlideTurnAngle(turnAngle);
		pGamePlayer->SetAnimGlideSpeed(fFowardSpeed);
		pGamePlayer->FlushGlideAnimParam();
		if (!m_bLanding || (m_fLandDuration - m_fLandPassTime) > 0.1f) //着陆的最后0.1s不生效（避免最后一直为垂直的问题）
		{
			m_fMovePitch = pitchAngle;
		}
	}
}

AActor* AzureGlideBehavior::GetMovableActor() const
{
	AActor* pObj = _objcomp.IsValid() ? _objcomp->GetOwner() : nullptr;
	if (!pObj)
	{
		return nullptr;
	}
	AActor* pParentObj = pObj->GetAttachParentActor();
	if (pParentObj)
	{
		return pParentObj;
	}
	return pObj;
}

float AzureGlideBehavior::GetCollisionCheckDistance() const
{
	if (m_bLanding)
	{
		return 0.0f;
	}
	else if (m_bStartLand)
	{
		return FMath::Abs((m_fLandInitSpeedZ + m_fLandMinSpeed)* (m_fLandDuration + 0.2) / 2.0f); //0.2是避免离散累加的误差
	}
	else
	{
		return m_fLandHeight;
	}
}
bool AzureGlideBehavior::HandleLandingWhenCollision(float currSpeedZ)
{
	if (m_bLanding || m_fLandDuration <= 0.001f)
	{
		return false;//已经进入着陆，再遇到碰撞，结束落地
	}
	else
	{
		OnEnterLanding(currSpeedZ);
		return true;
	}
}

void AzureGlideBehavior::OnEnterLanding(float currSpeedZ)
{
	if (m_bLanding)
	{
		return;
	}
	if (!m_bStartLand)
	{
		m_fLandInitSpeedZ = currSpeedZ;
		m_bStartLand = true;
		return;
	}
	m_fTestHeight = GetCollisionCheckDistance();
	m_bLanding = true;
	HandleLandingInLua();
}

bool AzureGlideBehavior::RecordLandPassTime(float dt)
{
	if (m_bLanding)
	{
		m_fLandPassTime += dt;
		return m_fLandPassTime <= m_fLandDuration;
	}
	else
	{
		m_fLandPassTime = 0.0f;
		return true;
	}
}

void AzureGlideBehavior::ResetLandData()
{
	m_bLanding = false;
	m_bStartLand = false;
	m_fLandPassTime = 0.0f;
	m_fLandInitSpeedZ = 0.0f;
}

bool AzureGlideBehavior::GetLandSpeedZ(float& outLandSpeedZ, float& outSpeedScale, float dt) const
{
	if (m_bLanding)
	{
		float rate = FMath::Max(0.0f, m_fLandDuration - m_fLandPassTime - dt*0.5f) / m_fLandDuration;
		outLandSpeedZ = m_fLandInitSpeedZ * rate + m_fLandMinSpeed * (1 - rate);
		outSpeedScale = rate;
		return true;
	}
	else if (m_bStartLand)
	{
		outLandSpeedZ = m_fLandInitSpeedZ;
		outSpeedScale = 1.0f;
		return true;
	}
	return false;
}

void AzureGlideBehavior::HandleLandingInLua() const
{
	AActor* pObj = _objcomp.IsValid() ? _objcomp->GetOwner() : nullptr;
	if (!pObj)
	{
		return;
	}

	lua_State_Wrapper L = AAzureEntryPoint::Instance->GetL();
	UAzureObjectComponent* pAzureComp = Cast<UAzureObjectComponent>(pObj->GetComponentByClass(UAzureObjectComponent::StaticClass()));
	if (pAzureComp && L)
	{
		int top = lua_gettop(L);
		lua_getglobal(L, "OnGlideBehaviorLand");
		if (lua_isfunction(L, -1))
		{
			lua_rawgeti(L, LUA_REGISTRYINDEX, pAzureComp->GetLuaECObject()); // func obj
			AAzureEntryPoint::Instance->GetWLua()->PCall(1, 0);//duration
		}
		lua_settop(L, top);
	}
	else
	{
		return;
	}
}

void AzureGlideBehavior::HandleRemoveInLua() const
{
	AActor* pObj = _objcomp.IsValid() ? _objcomp->GetOwner() : nullptr;
	if (!pObj)
	{
		return;
	}

	lua_State_Wrapper L = AAzureEntryPoint::Instance->GetL();
	UAzureObjectComponent* pAzureComp = Cast<UAzureObjectComponent>(pObj->GetComponentByClass(UAzureObjectComponent::StaticClass()));
	if (pAzureComp && L)
	{
		int top = lua_gettop(L);
		lua_getglobal(L, "OnGlideBehaviorRemoved");
		if (lua_isfunction(L, -1))
		{
			lua_rawgeti(L, LUA_REGISTRYINDEX, pAzureComp->GetLuaECObject()); // func obj
			lua_pushnumber(L, m_fMovePitch);
			AAzureEntryPoint::Instance->GetWLua()->PCall(2, 0);//dir
		}
		lua_settop(L, top);
	}
	else
	{
		return;
	}
}