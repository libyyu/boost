#pragma once

#include "HPMoveBase.h"
#include "Math/InterpCurve.h"


class HPBezierMoveBehavior : public HPMoveBase
{
protected:
	static constexpr  Azure::BehaviorType _type = Azure::BehaviorType::HPBezierMove;

	TWeakObjectPtr<class AGamePlayer> m_pGamePlayer;
	TWeakObjectPtr<class AGamePlayer> m_carrier;
	bool m_isOnCarrier;


	float m_duration;
	float m_time;

	FInterpCurveVector m_spline;
	FInterpCurveVector m_spline2D;
	float m_steps = 100.0f;//���㳤�ȵ�ʱ��spline�ֳɶ��ٷݣ�Խ��Խ��׼�������ʱ��Ҳ�Գ�

	float last_percent = 0.0f;

	int32 last_segment = 0;

	float m_curDist = 0.0f;
	float m_totalDist = 0.0f;

	TArray<float> m_real_events;
	TArray<float> m_orign_events;
	int m_event_call_index;

	int m_move_type;//1�ؾ������ƶ� 2������
	bool m_ground_move;//�Ƿ�����
	bool m_loop;//�Ƿ�ѭ��

public:

	HPBezierMoveBehavior()
	{
		
	}

	Azure::BehaviorType get_Type() const override
	{
		return _type;
	}

	static HPBezierMoveBehavior* Create();

	bool SetData(const Azure::VecPoint& points, const Azure::VecPoint& arrive_dirs, const Azure::VecPoint& leave_dirs, const Azure::ArrayFloat& events, int steps, float speed, int move_type, bool ground, bool isloop, class AGamePlayer * pCarrier, OnBehaviorFinish onFinish);
	virtual void OnRemoved(bool replace) override;
	void GetCurPosAndDir(FVector & pos, FVector & dir);
	void SetCurPos(const FVector & pos, const FVector & dir);

	void DrawDebugWholeSpline(class AGamePlayer * pOwner, float dt);
	void DrawCurTangent(class AGamePlayer * pOwner,const FVector & pos,const FVector & dir);

	FVector CalPosDirByPercent(class AGamePlayer * pOwner, float percent, bool bGround,FVector & pos,FVector & dir);
	FVector FindNearestPoint(class AGamePlayer * pActor, float percent, FVector & pos,FVector & nearestPos, FVector & dir,float & nearestPercent);

	void StopLoop();

protected:

	virtual bool TickInternal(float dt) override;

	bool TickVehicleMove(float dt);

	bool TickFollowMove(float dt);

	void CheckPassPoint(float percent);
	void CallPassPointLua(int index);

	void DealEvents(const Azure::ArrayFloat & events);

	int IsPassPoint(float p,float lastp);

	
};