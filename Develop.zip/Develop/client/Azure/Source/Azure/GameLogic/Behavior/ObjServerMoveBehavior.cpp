﻿//#include "Azure.h"
#include "ObjServerMoveBehavior.h"
#include "AzureObjectComponent.h"
#include "UE4Related.h"
#include "AzureUtility.h"
#include "GameLogic/Player/GamePlayer.h"
#include "GameLogic/Player/VehicleCharacter.h"
#include "GameLogic/Player/GamePlayer_Util.h"
#include "GameFramework/CharacterMovementComponent.h"
#include "Kismet/KismetSystemLibrary.h"
#include "AzureTimeManager.h"
#include "AzureGameSession.h"
#include "HPMoveBase.h"
#include "Components/CapsuleComponent.h"
using namespace Azure;



bool IsEnterFalling_Flag(int32 flag, int32 flag2)
{
	if ((flag & (uint32)GP_MOVE_FLAG::GP_MOVE_JUMP) != 0)
		return true;

	if ((flag2 & (uint32)GP_MOVE_FLAG_EXTEND::GP_MOVE_EXTEND_JUMPSTART_FALL) != 0)
		return true;

	return false;
}

bool IsNotPressJumpStartFalling_Flag(int32 flag, int32 flag2)
{
	if ((flag2 & (uint32)GP_MOVE_FLAG_EXTEND::GP_MOVE_EXTEND_JUMPSTART_FALL) != 0)
		return true;

	return false;
}


bool IsJumppingAndLanding_Flag(int32 flag, int32 flag2)
{
	if ((flag2 & (uint32)GP_MOVE_FLAG_EXTEND::GP_MOVE_EXTEND_JUMPPING) != 0)
		return true;

	if ((flag & (uint32)GP_MOVE_FLAG::GP_MOVE_LANDING) != 0)
		return true;

	return false;
}


bool IsLanding_Flag(int32 flag, int32 flag2)
{
	if ((flag & (uint32)GP_MOVE_FLAG::GP_MOVE_LANDING) != 0)
		return true;

	return false;
}

bool IsJump_Flag(int32 flag, int32 flag2)
{
	if (IsEnterFalling_Flag(flag, flag2))
		return true;

	if (IsJumppingAndLanding_Flag(flag, flag2))
		return true;

	return false;
}

bool IsForceSync_Flag(int32 flag, int32 flag2)
{
	bool isForceSyncPos = ((flag2 & (uint32)GP_MOVE_FLAG_EXTEND::GP_MOVE_EXTEND_FORCE_SYNC_POS) != 0);
	return isForceSyncPos;
}

bool IsDashStop_Flag(int32 flag, int32 flag2)
{
	if ((flag & (uint32)GP_MOVE_FLAG::GP_MOVE_DASHSTOP) != 0)
		return true;

	return false;
}

bool IsRunStop_Flag(int32 flag, int32 flag2)
{
	if ((flag & (uint32)GP_MOVE_FLAG::GP_MOVE_RUNSTOP) != 0)
		return true;

	return false;
}

bool IsJumpStart_Flag(int32 flag, int32 flag2)
{
	if ((flag & (uint32)GP_MOVE_FLAG::GP_MOVE_JUMP) != 0)
		return true;

	return false;
}

bool IsMoveInput_Flag(int32 flag, int32 flag2)
{
	if ((flag2 & (uint32)GP_MOVE_FLAG_EXTEND::GP_MOVE_EXTEND_INPUT) != 0)
		return true;

	return false;
}

bool IsReleaseInput_Flag(int32 flag, int32 flag2)
{
	if((flag2 & (uint32)GP_MOVE_FLAG_EXTEND::GP_MOVE_EXTEND_RELEASE_INPUT) != 0)
		return true;

	return false;
}

bool IsRootMotion_Flag(int32 flag, int32 flag2)
{
	if ((flag2 & (uint32)GP_MOVE_FLAG_EXTEND::GP_MOVE_EXTEND_ROOTMOTION) != 0)
		return true;

	return false;
}

static bool IsStartMove_Flag(int32 flag, int32 flag2)
{
	if ((flag2 & (uint32)GP_MOVE_FLAG_EXTEND::GP_MOVE_EXTEND_START_MOVE) != 0)
		return true;

	return false;
}

bool ObjServerMoveBehavior::SetData_Player(const FVector & vDest, const FRotator & destRotator, float use_time, const FVector & vVelocity, int32 flag, int32 flag2, uint32 extend_data2, int32 timeStamp,int32 serverMoveType)
{
	if (!_objcomp.IsValid())
		return false;

	AGamePlayer * pObj = Cast<AGamePlayer>(_objcomp->GetOwner());
	if (!pObj)
		return false;

	if (!AAzureEntryPoint::Instance)
		return false;

	bool isHostPlayer = pObj->IsHostPlayer();//组队跟随的时候主角会走这里
	bool isElsePlayer = pObj->IsElsePlayer();
	bool isVehicle = pObj->IsVehicle();
	bool isCarrier = pObj->IsCarrierGamePlayer();

	double st = AAzureEntryPoint::Instance->GetRealtimeSinceStartup();
	double last_st = m_lastReceiveTime;


	float h = pObj->GetHalfHeight();
	FVector actorPos = vDest + FVector(0, 0, h);
 
	bool isCharPlayingRootMotion = pObj->IsPlayingRootMotion();

	if (pObj->move_sync_debug )//&& isCharPlayingRootMotion
	{		
		pObj->my_pos.Add(pObj->GetActorLocation() + FVector(0, 0, 30));
		pObj->my_dir.Add(pObj->GetVelocity().GetSafeNormal());
		pObj->rep_pos.Add(actorPos);	

		if (false)
		{
			FString str = FString::Printf(TEXT("elsePlayer dt[%0.3f]--t[%0.3f] --syncT[%0.3f] index--%d"), st - last_st, st,
				pObj->sync_time, pObj->rep_pos.Num());
			MyPrintString(str);
		}
	}	

	/////////////////////特殊处理部分开始

	if (pObj->receive_sync_dash_stop)
	{
		pObj->start_velocity = FVector::ZeroVector;
	}
	else if (pObj->receive_sync_run_stop)
	{
		pObj->start_velocity = FVector::ZeroVector;
	}
	else
	{
		pObj->start_velocity = pObj->GetVelocity();
	}

	if (false)
	{
		FString str = FString::Printf(TEXT("startVelocity %0.1f %0.1f %d"), pObj->start_velocity.X, pObj->start_velocity.Y, pObj->receive_sync_run_stop);
		MyPrintString(str);
	}


	pObj->m_waitNextSyncDuration = Azure::s_waitNextSyncScale * Azure::player_receive_sync_info_interval;
	pObj->m_waitNextSyncTime = pObj->m_waitNextSyncDuration;
	pObj->m_useTime = use_time;

	if (false)
	{
		FString str = FString::Printf(TEXT("m_waitNextSyncTime %0.3f"), pObj->m_waitNextSyncTime);
		MyPrintString(str);
	}

	FVector adjust_velocity = vVelocity;

	bool isDashStop = IsDashStop_Flag(flag, flag2);
	bool isRunStop = IsRunStop_Flag(flag, flag2);
	bool isPlayingRootMotion = IsRootMotion_Flag(flag, flag2);
	bool isStartMove = IsStartMove_Flag(flag, flag2);
	bool isJumpStart = IsJumpStart_Flag(flag, flag2);
	bool isForceSyncPos = IsForceSync_Flag(flag, flag2);
	bool bJumpLand = IsLanding_Flag(flag, flag2);
	
	pObj->m_servemove_flag = flag;
	pObj->m_servemove_flag2 = flag2;
	pObj->m_servermove_type = serverMoveType;
	
	
	if (!isPlayingRootMotion)
	{
		pObj->UpdateSyncTime(use_time, vDest, vVelocity, flag, flag2);//播rootmotion不要直接重置时间，因为不一定会调用smoothcorrection	
	}
	else
	{		
		pObj->receive_root_motion_flag = true;
	}

	
	if (pObj->GetCharacterMovement()->bOrientRotationToMovement)//移动方向和朝向相同的这样特殊处理
	{	
		if (isDashStop)
			adjust_velocity = FVector::ZeroVector;
	
		if (isRunStop)
			adjust_velocity = FVector::ZeroVector;
	}

	bool isReleaseInput = IsReleaseInput_Flag(flag,flag2);
	if (isReleaseInput)
	{
		pObj->receive_release_input = true;
		//MyPrintString("release input");
	}
	else
	{
		pObj->receive_release_input = false;
	}
		

	FVector predict_pos = actorPos;
	//处理波动导致的延迟和早到，计算此时的预测位置
	if (isJumpStart || isPlayingRootMotion || isRunStop || isDashStop || isStartMove || isForceSyncPos)
	{
		m_CurStartMoveTime = 0.0f;
	}

	bool isTeamFollow = (pObj->m_servermove_type == ServerMoveType::TeamFollow);

	bool isSelfPredict = (pObj->m_servermove_type == ServerMoveType::Normal);

	bool bPredict = (Azure::bPlayerServerMovePredict && isSelfPredict);
	m_bPredict = bPredict;

	if (bPredict)
	{
		if (m_CurStartMoveTime <= 0.001f)
		{
			if (!AAzureEntryPoint::Instance)
				return false;

			m_CurReceiveMoveTime = AAzureEntryPoint::Instance->GetRealtimeSinceStartup();
			m_CurStartMoveTime = m_CurReceiveMoveTime;
		
			if (false)
			{
				FString str = FString::Printf(TEXT("StartServerMove dt[%0.3f] startTime[%0.3f] syncT[%0.3f] %d"), st - last_st, m_CurStartMoveTime,pObj->sync_time, pObj->rep_pos.Num());
				MyPrintString(str);
			}
		}
		else
		{
			m_CurReceiveMoveTime += use_time;

			if (!AAzureEntryPoint::Instance)
				return false;

			float curTime = AAzureEntryPoint::Instance->GetRealtimeSinceStartup();
			if (curTime > m_CurReceiveMoveTime + Azure::host_send_sync_info_interval)
			{
				//dt 移动协议迟到了多久，迟到了这么久，假设按当前速度跑了dt
				float dt = curTime - m_CurReceiveMoveTime;
				FVector d_move = dt * adjust_velocity;

				bool bCanPredict = CheckPredictPos(pObj,actorPos,d_move, destRotator);

				if (bCanPredict)
				{
					actorPos.X += d_move.X;
					actorPos.Y += d_move.Y;
					predict_pos += d_move;
				}
				
				if (pObj->move_sync_debug)
				{
					if (bCanPredict)
					{
						FString str = FString::Printf(TEXT("Predict true synct[%0.3f] dt[%0.3f] dt2[%0.3f] alldt[%0.3f] alluse[%0.3f] use[%0.3f] --%d"), pObj->sync_time, st - last_st, curTime - m_CurReceiveMoveTime, curTime - m_CurStartMoveTime,
							m_CurReceiveMoveTime - m_CurStartMoveTime, use_time,
							pObj->rep_pos.Num());
						MyPrintString(str);
					}
					else
					{
						FString str = FString::Printf(TEXT("Predict false synct[%0.3f] dt[%0.3f] dt2[%0.3f] alldt[%0.3f] alluse[%0.3f] use[%0.3f] --%d"), pObj->sync_time, st - last_st, curTime - m_CurReceiveMoveTime, curTime - m_CurStartMoveTime,
							m_CurReceiveMoveTime - m_CurStartMoveTime, use_time,
							pObj->rep_pos.Num());
						MyPrintString(str);
					}
				}
			}
			else
			{
				m_CurReceiveMoveTime = curTime;//开始移动的帧到的时候可能已经是受波动影响晚到了，导致后面的时间一直落后use_time的堆叠时间，在这里修正一下，正常情况下当前时间应该比收到的包的use_time加和快
				m_CurStartMoveTime = m_CurReceiveMoveTime;			
				//MyPrintString(("modify receiveTime"));
			}		
		}
	}	
	//
	//////////////////////特殊处理部分结束

	if (isVehicle || isCarrier)
	{
		bool hasValidDesirdYaw = (flag2 & (uint32)GP_MOVE_FLAG_EXTEND::GP_MOVE_EXTEND_HasDesiredYaw) != 0;
		// 坐骑extenddata2低16位保存目标朝向
		ACarrierCharacterBase *vehicleObj = Cast<ACarrierCharacterBase>(pObj);
		uint16 desiredYaw = extend_data2 & 0xffff;
		extend_data2 = extend_data2 >> 16;
		if (hasValidDesirdYaw)
		{
			float decompressYaw = AzureUtility::DecompressDirH2_Yaw(desiredYaw);
			decompressYaw = FRotator::ClampAxis(decompressYaw);
			vehicleObj->SetDesiredYaw_Simulate(decompressYaw);
		}
		else
		{
			vehicleObj->ResetDesiredYawToDefault();
		}

		vehicleObj->OnGetMoveExtendFlag(flag2, extend_data2);
	}

	FRotator NotPredictDestRotator = destRotator;

	if (isTeamFollow)
	{
		if (pObj->GetMesh())
		{
			FVector dir = actorPos - pObj->GetMesh()->GetComponentLocation();
			dir.Z = 0.0f;
			if (!dir.IsNearlyZero(50.0f))
			{
				NotPredictDestRotator = dir.Rotation();
			}
		}
		
	}

	// 坐骑已经使用了extend_data2，不支持rootmotion
	if (bPredict)
	{
		if (!isPlayingRootMotion)
		{
			pObj->ReplicatedMovement.Location = actorPos;
			pObj->ReplicatedMovement.Rotation = destRotator;
			pObj->ReplicatedMovement.LinearVelocity = adjust_velocity;
			pObj->ReplicatedMovement.bRepPhysics = false;
			pObj->OnRep_ReplicatedMovement();

			if (pObj->move_sync_debug && false)//&& isCharPlayingRootMotion
			{
				if (true)
				{
					FString str = FString::Printf(TEXT("elsePlayer %0.1f %0.1f %0.1f"), actorPos.X, actorPos.Y, actorPos.Z);
					MyPrintString(str);
				}
			}
		}
		else
		{
			//pObj->GetCharacterMovement()->bNetworkSmoothingComplete = true;
			float trackPosition = extend_data2 * 0.00001f;

			pObj->RepRootMotion.bIsActive = true;
			pObj->RepRootMotion.bRelativePosition = false;
			pObj->RepRootMotion.bRelativeRotation = false;
			pObj->RepRootMotion.Location = vDest + FVector(0, 0, h);
			pObj->RepRootMotion.Rotation = destRotator;
			pObj->RepRootMotion.MovementBase = pObj->GetBasedMovement().MovementBase;
			pObj->RepRootMotion.MovementBaseBoneName = pObj->GetBasedMovement().BoneName;
			pObj->RepRootMotion.AnimMontage = pObj->GetCurrentMontage();
			pObj->RepRootMotion.Position = trackPosition;
			pObj->RepRootMotion.AuthoritativeRootMotion = pObj->GetCharacterMovement()->CurrentRootMotion;

			pObj->OnRep_RootMotion();

			if (pObj->move_sync_debug && false)
			{
				if (!AAzureEntryPoint::Instance)
					return false;

				float st = AAzureEntryPoint::Instance->GetRealtimeSinceStartup();
				FString str = FString::Printf(TEXT("root motion sync clientRM %d recpos %0.5f st %0.3f"), pObj->RepRootMotion.AnimMontage == nullptr, trackPosition, st);
				MyPrintString(str);
			}		
		}
	}
	else
	{
		pObj->ReplicatedMovement.Location = actorPos;
		pObj->ReplicatedMovement.Rotation = NotPredictDestRotator;
		pObj->ReplicatedMovement.LinearVelocity = adjust_velocity;
		pObj->ReplicatedMovement.bRepPhysics = false;
		pObj->OnRep_ReplicatedMovement();

		if (pObj->move_sync_debug && false)//&& isCharPlayingRootMotion
		{
			if (true)
			{
				FString str = FString::Printf(TEXT("elsePlayer %0.1f %0.1f %0.1f"), actorPos.X, actorPos.Y, actorPos.Z);
				MyPrintString(str);
			}
		}
	}
	

	/////////////////////////////
	if (false)
	{
		FString str = FString::Printf(TEXT("s2c_move face1: %0.1f face2: %0.1f "),
			destRotator.Yaw, destRotator.Yaw);

		UKismetSystemLibrary::PrintString(GEngine->GetWorld(), str, false);
	}

	//动画和模式处理部分
	//if (true)
	{
		if ((flag & (uint32)GP_MOVE_FLAG::GP_MOVE_JUMP) != 0)
		{
			//发送的地方GetSyncMoveExtendData ：extend_data2 = GetJumpType() + JumpCurrentCount * 10;
			int jump_count = extend_data2/10;//目前支持二段跳
			int jump_type = extend_data2 % 10;
		

			pObj->SetServerMoveUpGravityScale(jump_count);


			pObj->SetPrepareJump(jump_type);
			pObj->SetJumpCount(jump_count);
			pObj->SetJumpType(jump_type);

			pObj->SetElseRelativeMovementDirection(adjust_velocity);
		}
		else if((flag2 & (uint32)GP_MOVE_FLAG_EXTEND::GP_MOVE_EXTEND_PREPARE_JUMP) != 0)
		{
			pObj->SetPrepareJump(1);
		}
		else if (IsNotPressJumpStartFalling_Flag(flag,flag2))
		{
			pObj->SetPrepareJump(0);
			pObj->SetJumpType(0);
		}

		if (isElsePlayer)
		{
			if (adjust_velocity.Z <= 0.0F)
				pObj->SetServerMoveDownGravityScale();
		}

		if (IsEnterFalling_Flag(flag,flag2))
		{
			pObj->OnServerMoveEnterJump();
		}

		bool isMoveInput = IsMoveInput_Flag(flag, flag2);
		if (isMoveInput)
		{
			pObj->SetMoveInput(true);

			//MyPrintString("input true");
			//组队协议和发送协议不一致，随时可能在中间的位置停，这个时候Input就可能还有值，这是为了解决：
			//组队跟随状态下，队员原地走路问题
			//复现方法：队长带队卡在坡下一直按住前
			//建议位置：POS 1 367.4612109375 - 545.330234375
			if (isTeamFollow)
			{
				if (adjust_velocity.IsNearlyZero(0.1f) && !bJumpLand)
				{
					pObj->SetMoveInput(false);
					//MyPrintString("input false 1");
				}					
			}
		}
		else
		{
			pObj->SetMoveInput(false);
		}

		//播刹车动画用
		if (isDashStop)
		{
			pObj->sync_cache_dash_stop = true;
			pObj->sync_cache_dash_stop_type = extend_data2;

			pObj->receive_sync_dash_stop = true;
			pObj->receive_sync_dash_stop_type = extend_data2;

			if(bPredict)//如果预测，立马播，如果不预测，上一个同步协议同步完了在播
				pObj->SetPlayDashAnim(pObj->sync_cache_dash_stop_type);
			else
				pObj->SetPlayDashAnim(pObj->sync_cache_dash_stop_type);
		}
		else if (isRunStop)
		{
			pObj->sync_cache_run_stop = true;
			pObj->sync_cache_run_stop_type = extend_data2;

			pObj->receive_sync_run_stop = true;
			pObj->receive_sync_run_stop_type = extend_data2;

			if (bPredict)
				pObj->SetPlayNormalStopAnim(pObj->sync_cache_run_stop_type);
			else
				pObj->SetPlayNormalStopAnim(pObj->sync_cache_run_stop_type);
		}
		else
		{
			if (!isPlayingRootMotion)
				pObj->SetPlayDashAnim(0);

			if (!isPlayingRootMotion)
				pObj->SetPlayNormalStopAnim(0);
				

			pObj->receive_sync_dash_stop = false;
			pObj->receive_sync_dash_stop_type = 0;

			pObj->receive_sync_run_stop = false;
			pObj->receive_sync_run_stop_type = 0;
		}

		pObj->SetTargetDesiredDir(adjust_velocity);
		pObj->targetDesiredDir = adjust_velocity;


		if (isStartMove)
		{
			pObj->startWalkTime = Azure::start_walk_duration;
		}
	}

	if (pObj->move_sync_debug)//&& isCharPlayingRootMotion
	{
		pObj->rep_predict_pos.Add(predict_pos);

		FVector offset = pObj->GetActorRotation().RotateVector(pObj->GetBaseTranslationOffset());
		FVector mesh_Pos = actorPos + offset;
		pObj->rep_mesh_pos.Add(mesh_Pos);
		pObj->rep_mesh_dir.Add(pObj->GetMesh()->GetRightVector());
		pObj->rep_dir.Add(vVelocity.GetSafeNormal());
		pObj->rep_facedir.Add(destRotator.Quaternion().GetForwardVector());

		if (isElsePlayer)
		{
			//FString str = FString::Printf(TEXT("elsePlayer dt[%0.3f]--t[%0.3f] pos[%0.1f %0.1f %0.1f] vel[%0.1f %0.1f %0.1f] index--%d"), st - last_st, st,
			//	vDest.X, vDest.Y, vDest.Z, vVelocity.X, vVelocity.Y, vVelocity.Z, pObj->rep_pos.Num());

			//FString str = FString::Printf(TEXT("elsePlayer dt[%0.3f]--t[%0.3f] --syncT[%0.3f] index--%d"), st - last_st, st,
			//	pObj->sync_time, pObj->rep_pos.Num());
			//MyPrintString(str);
		}
	}

	if (false)
	{
		/*FString str = FString::Printf(TEXT("s2c_move pos[%0.1f,%0.1f,%0.1f] rot[%0.1f,%0.1f] vel[%0.1f,%0.1f,%0.1f]%0.1f %0.1F"),
			actorPos.X, actorPos.Y, actorPos.Z,
			pObj->ReplicatedMovement.Rotation.Yaw, pObj->GetActorRotation().Yaw,
			vVelocity.X, vVelocity.Y, vVelocity.Z,vVelocity.Size(), adjust_velocity.Size());*/

			/*FVector mesh_pos = pObj->GetMesh()->GetComponentLocation();
			FString str = FString::Printf(TEXT("s2c_move pos[%0.1f,%0.1f,%0.1f] mesh_pos[%0.1f,%0.1f,%0.1f]"),
				actorPos.X, actorPos.Y, actorPos.Z, mesh_pos.X, mesh_pos.Y, mesh_pos.Z);*/
				/*FString str = FString::Printf(TEXT("s2c_move face1: %0.1f face2: %0.1f x %0.1f y %0.1f"),
					facedir.Rotation().Yaw, facedir2d.Rotation().Yaw,facedir2d.X,facedir2d.Y);*/

					//FString str = FString::Printf(TEXT("s2c_move pos[%0.1f,%0.1f,%0.1f] actorPos[%0.1f,%0.1f,%0.1f]"),
					//	vDest.X, vDest.Y, vDest.Z, actorPos.X, actorPos.Y, actorPos.Z);

				/*FString str = FString::Printf(TEXT("s2c_move movedir facedir facedir2 [%0.1f,%0.1f,%0.1f]"),
					adjust_velocity.Rotation().Yaw, facedir.Rotation().Yaw, facedir2d.Rotation().Yaw);*/

					//double st = AAzureEntryPoint::Instance->GetRealtimeSinceStartup();
					//FString str = FString::Printf(TEXT("s2c_move pos[%0.1f,%0.1f,%0.1f] t:[%0.3f]"),
					//	actorPos.X, actorPos.Y, actorPos.Z,st);

					//UKismetSystemLibrary::PrintString(GEngine->GetWorld(), str,false);

					//FString str = FString::Printf(TEXT("moveYaw %0.1f"), delta.GetSafeNormal().Rotation().Yaw);
					//UKismetSystemLibrary::PrintString(GEngine->GetWorld(), str);

		if (false && isElsePlayer)
		{
			//FString str = FString::Printf(TEXT("elsePlayer dt[%0.3f]--t[%0.3f] [%x] [%x] "),st - last_st, st,flag, flag2);
			FString str = FString::Printf(TEXT("elsePlayer dt[%0.3f]--t[%0.3f] pos[%0.1f %0.1f %0.1f] vel[%0.1f %0.1f %0.1f] "), st - last_st, st,
				vDest.X, vDest.Y, vDest.Z, vVelocity.X, vVelocity.Y, vVelocity.Z);
			MyPrintString(str);
		}

		if (isElsePlayer)
		{
			//FString str = FString::Printf(TEXT("server move speed %0.1f"), vVelocity.Size());
			//MyPrintString(str);
			//FString str = FString::Printf(TEXT("else pos[%0.0f,%0.0f,%0.0f] facedir[%0.1f %0.1f] vel[%0.1f,%0.1f,%0.1f]%0.1f [%x] [%x] [%0.3f] [%0.3f]--%0.3f"),
			//	vDest.X, vDest.Y, vDest.Z,facedir.Rotation().Yaw,facedir2d.Rotation().Yaw,
			//	vVelocity.X, vVelocity.Y, vVelocity.Z, vVelocity.Size(), flag, flag2,st - last_st, pObj->sync_time,st);

			if (pObj->GetCurrentMontage())
			{
				FString str = FString::Printf(TEXT("--isPlayingMontage %0.3f"), pObj->GetMesh()->GetAnimInstance()->Montage_GetPosition(nullptr));
				MyPrintString(str);
			}

			FString str = FString::Printf(TEXT("else pos[%0.0f,%0.0f,%0.0f] [%x] [%x] [%0.3f] [%0.3f]--%0.3f"),
				vDest.X, vDest.Y, vDest.Z, flag, flag2, st - last_st, pObj->sync_time, st);
			MyPrintString(str);
		}
		else if (isHostPlayer && false)
		{
			FString str = FString::Printf(TEXT("HostPlayer s2c_move pos[%0.1f,%0.1f,%0.1f] vel[%0.1f,%0.1f,%0.1f]%0.1f %0.1F %d %d"),
				vDest.X, vDest.Y, vDest.Z,
				vVelocity.X, vVelocity.Y, vVelocity.Z, vVelocity.Size(), adjust_velocity.Size(), flag, flag2);
			MyPrintString(str);
		}
		else if (!isElsePlayer && !isHostPlayer && pObj->debug_ai)//
		{
			if (pObj->m_isCarrier)
			{
				FString str = FString::Printf(TEXT("npc s2c_move(ship) pos[%0.1f,%0.1f,%0.1f] facedir[%0.1f %0.1f] vel[%0.1f,%0.1f,%0.1f]%0.1f %0.1f [%x] [%x] [%0.3f]--%0.3f"),
					vDest.X, vDest.Y, vDest.Z, destRotator.Yaw, destRotator.Yaw,
					vVelocity.X, vVelocity.Y, vVelocity.Z, vVelocity.Size(), adjust_velocity.Size(), flag, flag2, st - last_st, st);
				MyPrintString(str);
			}
			else
			{
				FString str = FString::Printf(TEXT("npc s2c_move(monster) pos[%0.1f,%0.1f,%0.1f] facedir[%0.1f %0.1f] vel[%0.1f,%0.1f,%0.1f]%0.1f %0.1f [%x] [%x] [%0.3f]--%0.3f"),
					vDest.X, vDest.Y, vDest.Z, destRotator.Yaw, destRotator.Yaw,
					vVelocity.X, vVelocity.Y, vVelocity.Z, vVelocity.Size(), adjust_velocity.Size(), flag, flag2, st - last_st, st);
				MyPrintString(str);
			}

			/*FVector meshPos = pObj->GetMesh()->GetComponentLocation();
			str = FString::Printf(TEXT("npc s2c_move meshpos[%0.1f,%0.1f,%0.1f] [%0.3f]--%0.3f"), meshPos.X, meshPos.Y, meshPos.Z,
				 st - last_st, st);
			MyPrintString(str);*/
		}
	}

	return true;
}

bool ObjServerMoveBehavior::SetData_NPC(const FVector & vDest, const FRotator & destRotator, float use_time, const FVector & vVelocity, int32 flag, int32 flag2, uint32 extend_data2, int32 timeStamp)
{
	if (!_objcomp.IsValid())
		return false;

	AGamePlayer * pObj = Cast<AGamePlayer>(_objcomp->GetOwner());
	if (!pObj)
		return false;

	if (!AAzureEntryPoint::Instance)
		return false;

	double st = AAzureEntryPoint::Instance->GetRealtimeSinceStartup();
	double last_st = m_lastReceiveTime;


	float h = pObj->GetHalfHeight();
	FVector actorPos = vDest + FVector(0, 0, h);

	if (pObj->move_sync_debug)
	{
		pObj->my_pos.Add(pObj->GetActorLocation() + FVector(0, 0, 30));
		pObj->my_dir.Add(pObj->GetVelocity().GetSafeNormal());
	}

	pObj->start_velocity = pObj->GetVelocity();


	if (false)
	{
		FString str = FString::Printf(TEXT("startVelocity %0.1f %0.1f %d"), pObj->GetVelocity().X, pObj->GetVelocity().Y);
		MyPrintString(str);
	}

	pObj->UpdateSyncTime(use_time, vDest, vVelocity, flag, flag2);

	/////////////////////特殊处理部分开始
	FVector adjust_velocity = vVelocity;

	/*if (pObj->move_sync_debug)
	{
		if (vVelocity.Size2D() < 0.001f)
		{
			FString str = FString::Printf(TEXT("stoplastspeed: %0.1f %0.1f"), pObj->start_velocity.Size2D(), vVelocity.Size2D());
			MyPrintString(str);
		}
	}*/

	if (pObj->GetCharacterMovement()->bOrientRotationToMovement)//移动方向和朝向相同的这样特殊处理
	{	
		bool isStop = vVelocity.Size2D() < 0.001f;
		if (!isStop)
		{
			//将mesh的朝向调向mesh移动目标方向(即actor所在方向)，是模型朝向和移动方向看起来一直(0.5s才同步一次这时候发过来的actor方向不一定和模型移动方向一致）		
			FVector delta = actorPos - pObj->GetMeshCenterPos();
			if (delta.Size2D() > 1.0f)//防止载具等在垂直运动运动的时候产生的小数误差
			{
				if (false)
				{
					FString str = FString::Printf(TEXT("change dir: %0.1f %0.1f "),
						destRotator.Yaw, delta.Rotation().Yaw);

					UKismetSystemLibrary::PrintString(GEngine->GetWorld(), str, false);
				}

				//facedir2d = delta.GetSafeNormal2D();
			}
				
		}
	}

	//////////////////////特殊处理部分结束
	pObj->ReplicatedMovement.Location = actorPos;
	pObj->ReplicatedMovement.Rotation = destRotator;
	pObj->ReplicatedMovement.LinearVelocity = adjust_velocity;
	pObj->ReplicatedMovement.bRepPhysics = false;
	pObj->OnRep_ReplicatedMovement();

	if (false)
	{
		FString str = FString::Printf(TEXT("s2c_move face1: %0.1f face2: %0.1f "),
			destRotator.Yaw, destRotator.Yaw);

		UKismetSystemLibrary::PrintString(GEngine->GetWorld(), str, false);
	}

	if (pObj->move_sync_debug)
	{
		pObj->rep_pos.Add(actorPos);

		FVector offset = pObj->GetActorRotation().RotateVector(pObj->GetBaseTranslationOffset());
		FVector mesh_Pos = actorPos + offset;
		pObj->rep_mesh_pos.Add(mesh_Pos);
		pObj->rep_mesh_dir.Add(pObj->GetMesh()->GetRightVector());
		pObj->rep_dir.Add(vVelocity.GetSafeNormal());
		pObj->rep_facedir.Add(destRotator.Quaternion().GetForwardVector());
	}

	if (false)
	{
		if (pObj->debug_ai)
		{
			if (pObj->m_isCarrier)
			{
				FString str = FString::Printf(TEXT("npc s2c_move(ship) pos[%0.1f,%0.1f,%0.1f] facedir[%0.1f %0.1f] vel[%0.1f,%0.1f,%0.1f]%0.1f %0.1f [%x] [%x] [%0.3f]--%0.3f"),
					vDest.X, vDest.Y, vDest.Z, destRotator.Yaw, destRotator.Yaw,
					vVelocity.X, vVelocity.Y, vVelocity.Z, vVelocity.Size(), adjust_velocity.Size(), flag, flag2, st - last_st, st);
				MyPrintString(str);
			}
			else
			{
				FString str = FString::Printf(TEXT("npc s2c_move(monster) pos[%0.1f,%0.1f,%0.1f] facedir[%0.1f %0.1f] vel[%0.1f,%0.1f,%0.1f]%0.1f %0.1f [%x] [%x] [%0.3f]--%0.3f"),
					vDest.X, vDest.Y, vDest.Z, destRotator.Yaw, destRotator.Yaw,
					vVelocity.X, vVelocity.Y, vVelocity.Z, vVelocity.Size(), adjust_velocity.Size(), flag, flag2, st - last_st, st);
				MyPrintString(str);
			}

			/*FVector meshPos = pObj->GetMesh()->GetComponentLocation();
			str = FString::Printf(TEXT("npc s2c_move meshpos[%0.1f,%0.1f,%0.1f] [%0.3f]--%0.3f"), meshPos.X, meshPos.Y, meshPos.Z,
				 st - last_st, st);
			MyPrintString(str);*/
		}
	}

	return true;
}

bool ObjServerMoveBehavior::SetData(const FVector & vDest, const FRotator & rotator, float use_time, const FVector & vVelocity, int32 flag, int32 flag2, uint32 extend_data2, int32 timeStamp, int32 serverMoveType ,OnBehaviorFinish onFinish)
{
	set_OnFinish(onFinish);

	//MyPrintString("ObjServerMoveBehavior start");
	if (!_objcomp.IsValid())
		return false;

	_objcomp->RemoveBehavior(Azure::BehaviorType::Turn);

	AGamePlayer * pObj = Cast<AGamePlayer>(_objcomp->GetOwner());
	if (!pObj)
		return false;
	
	pObj->m_bNeedTickServerMoveRotation = true;

	bool isHostPlayer = pObj->IsHostPlayer();//组队跟随的时候会走这里
	bool isElsePlayer = pObj->IsElsePlayer();
	bool isVehicle = pObj->IsVehicle();
	bool isCarrier = pObj->IsCarrierGamePlayer();

	if (pObj)
	{
		pObj->OnServerMoveBegin();
	}

	bool result = false;
	if (isHostPlayer || isElsePlayer || isVehicle || isCarrier)
	{
		result = SetData_Player(vDest, rotator, use_time, vVelocity,  flag, flag2, extend_data2, timeStamp,serverMoveType);
	}
	else
	{
		result = SetData_NPC(vDest, rotator, use_time, vVelocity, flag, flag2, extend_data2, timeStamp);
	}

	if (!AAzureEntryPoint::Instance)
		return false;

	m_lastReceiveTime = AAzureEntryPoint::Instance->GetRealtimeSinceStartup();

	return result;
}

void ObjServerMoveBehavior::UpdateDashStopType()
{
	if (!_objcomp.IsValid())
		return;

	AGamePlayer* pActor = Cast<AGamePlayer>(_objcomp->GetOwner());
	if (pActor->m_iPlayDashStop > 1)
	{
		if (!pActor->GetCurrentMontage())
		{
			pActor->m_iPlayDashStop = 0;
		}
	}
}

bool ObjServerMoveBehavior::Tick(float dt)
{
	if (!_objcomp.IsValid())
		return true;

	AGamePlayer * pObj = Cast<AGamePlayer>(_objcomp->GetOwner());
	if (!pObj)
		return true;

	float speed = pObj->GetVelocity().Size();

	bool isPlayingNormalStop = pObj->IsPlayingNormalStop();
	bool isPlayingDashStop = pObj->IsPlayingDashStop();
	if (speed <= 0.000001f && pObj->GetCharacterMovement()->bNetworkSmoothingComplete && !isPlayingNormalStop && !isPlayingDashStop)
	{
		//bool r = pObj->GetMovementComponent()->IsMovingOnGround();
		//FString str = FString::Printf(TEXT("ServerMove tick1 true %0.2f %d"),speed,r);
		//UKismetSystemLibrary::PrintString(GEngine->GetWorld(), str);
		//if(pObj->move_sync_debug)
			//MyPrintString("ObjServerReturn true");

		pObj->OnServerMoveOver();
		pObj->SetPlayDashAnim(0);
		pObj->SetPlayNormalStopAnim(0);
		return true;
	}

	if (m_bPredict)
	{
		if (pObj->m_waitNextSyncTime > 0.0f)
		{
			pObj->m_waitNextSyncTime -= dt;
			if (pObj->m_waitNextSyncTime <= 0.0f)
			{
				//MyPrintString("m_waitNextSyncTime End");

				pObj->m_waitNextSyncTime = 0.0f;
				return true;
				//pObj->SetPlayDashAnim(0);
				//return true;
			}
		}
	}
	

	//UpdateDashStopType();

	if (pObj->startWalkTime > 0.0f)
		pObj->startWalkTime -= dt;
	
	if (false && pObj->move_sync_debug)
	{				
		//float LerpPercent = 1.f - (pObj->sync_time / pObj->GetCharacterMovement()->NetworkSimulatedSmoothLocationTime);
		//FString str = FString::Printf(TEXT("debugpath %0.2f %0.2f"), d, LerpPercent);
		//UKismetSystemLibrary::PrintString(GEngine->GetWorld(), str);

		//pObj->debug_path.Add(pObj->GetMesh()->GetComponentLocation());

		pObj->mesh_pos = pObj->GetMeshCenterPos();
		pObj->mesh_dir = pObj->GetMesh()->GetRightVector();


		//FString str = FString::Printf(TEXT("ship mesh %0.1f %0.1f %0.1f"), pObj->mesh_pos.X, pObj->mesh_pos.Y, pObj->mesh_pos.Z);
		//UKismetSystemLibrary::PrintString(GEngine->GetWorld(), str);
	}

	//if (pObj->move_sync_debug)
		//MyPrintString("ObjServer tick");

	return false;
}

void ObjServerMoveBehavior::OnRemoved(bool replace)
{
	if (!_objcomp.IsValid())
		return;

	//replace表示是否是被下一个相同的行为使用，如果是false，说明自己结束或被其他行为打断
	AGamePlayer* obj = Cast<AGamePlayer>(_objcomp->GetOwner());
	if (!replace)//被其他行为中断
	{
		if (obj)
		{
			obj->StopMyReplicatedMovement();
		
			obj->m_waitNextSyncTime = 0.0f;
			obj->startWalkTime = 0.0f;
		}			

		m_CurReceiveMoveTime = 0.0f;
		m_CurStartMoveTime = 0.0f;
	}	

	if (false)
	{
		if(!replace)
			MyPrintString("ObjServerMoveBehavior End false");
		else
			MyPrintString("ObjServerMoveBehavior End true");
	}
}

bool ObjServerMoveBehavior::CheckPredictPos(AGamePlayer * pOwner, const FVector & actorPos, const FVector & d_move, const FRotator& Rot)
{
	TArray<FHitResult> Hits;
	FComponentQueryParams Params(SCENE_QUERY_STAT(MoveComponent), pOwner);
	FCollisionResponseParams ResponseParam;
	pOwner->GetCapsuleComponent()->InitSweepCollisionParams(Params, ResponseParam);
	FVector TraceStart = actorPos;
	FVector TraceEnd = TraceStart + d_move;
	bool const bHadBlockingHit = pOwner->GetWorld()->ComponentSweepMulti(Hits, pOwner->GetCapsuleComponent(), TraceStart, TraceEnd, Rot, Params);

	if (bHadBlockingHit)
	{
		if (pOwner->move_sync_debug)
		{
			FString str = "";
			for (int32 HitIdx = 0; HitIdx < Hits.Num(); HitIdx++)
			{
				const FHitResult& TestHit = Hits[HitIdx];
				
				str = str + TestHit.Actor.Get()->GetName() + "_" + TestHit.Component.Get()->GetName() + " ";
			}
			MyPrintString(str);
		}

		return false;
	}
	else
	{
		return true;
	}
}

