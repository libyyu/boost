﻿#pragma once

#include "AzureBehavior.h"

//////////////////////////////////////////////////////////////////////////
class AzureRootMotionBehavior : public AzureBehavior
{
protected:
	static constexpr  Azure::BehaviorType _type = Azure::BehaviorType::RootMotionMove;

	FVector m_vDest;
	FVector m_curPos;

	float m_duration;
	float m_time_scale;
	float m_animLength;
	float m_curTime;

	FVector m_vDir;
	float m_fDist;
	float m_animDist;

	FVector m_vStartPos, m_vStartDir;

	TWeakObjectPtr<class AGamePlayer> m_carrier;
	bool m_isOnCarrier;

	TWeakObjectPtr<class AGamePlayer> m_pGamePlayer;
	TWeakObjectPtr<class UAnimMontage> m_pMontage;

public:

	AzureRootMotionBehavior()
	{
		
	}

	static AzureRootMotionBehavior* Create()
	{
		AzureRootMotionBehavior* ret = (AzureRootMotionBehavior*)AzureBehaviorCache::GetInstance().GetBehavior(_type);

		if (ret == nullptr)
			ret = new AzureRootMotionBehavior();

		return ret;
	}

	Azure::BehaviorType get_Type() const override
	{
		return _type;
	}

	bool SetData(FVector vDest, float speed, class UAnimMontage * pMontage, class AGamePlayer * pCarrier, OnBehaviorFinish onFinish);
	bool Tick(float dt) override;
	virtual void OnRemoved(bool replace) override;

	void GetCurPosAndDir(FVector & pos,FVector & dir);
	void SetCurPosAndDir(FVector pos);

	void DrawDestPos_SetData();
	void DrawTick();
};

