﻿#pragma once

#include "AzureBehavior.h"

void MyPrintString(FString str);
//ElsePlayer Monster
//等同步，逻辑是位置方向瞬间同步，然后用mesh去插值显示

enum ServerMoveType
{
	Normal = 1,
	TeamFollow = 2,
	ServerControl = 3,
};

//////////////////////////////////////////////////////////////////////////
class ObjServerMoveBehavior : public AzureBehavior
{
protected:
	static constexpr  Azure::BehaviorType _type = Azure::BehaviorType::ObjServerMove;

	float m_lastReceiveTime = 0.0f;
	float m_CurReceiveMoveTime = 0.0f;//从开始移动获得的移动协议总共的use_time时间和
	float m_CurStartMoveTime = 0.0f;
	bool m_bPredict = false;

public:

	ObjServerMoveBehavior()
	{
		
	}

	static ObjServerMoveBehavior* Create()
	{
		ObjServerMoveBehavior* ret = (ObjServerMoveBehavior*)AzureBehaviorCache::GetInstance().GetBehavior(_type);

		if (ret == nullptr)
		{
			ret = new ObjServerMoveBehavior();
		}			

		return ret;
	}

	Azure::BehaviorType get_Type() const override
	{
		return _type;
	}

	bool SetData(const FVector & vDest, const FRotator & rotator,float use_time, const FVector & vVelocity, int32 flag, int32 flag2, uint32 extend_data2, int32 timeStamp,int32 serverMoveType, OnBehaviorFinish onFinish);

	bool SetData_Player(const FVector & vDest, const FRotator & rotator, float use_time, const FVector & vVelocity, int32 flag, int32 flag2, uint32 extend_data2, int32 timeStamp,int serverMoveType);
	bool SetData_NPC(const FVector & vDest, const FRotator & rotator, float use_time, const FVector & vVelocity, int32 flag, int32 flag2, uint32 extend_data2, int32 timeStamp);

	bool Tick(float dt) override;
	virtual void OnRemoved(bool replace) override;

	void UpdateSyncTime(class AGamePlayer * pObj,float use_time,FVector target_pos, FVector velocity,int32 flag,int32 flag2);
	void UpdateDashStopType();

	bool CheckPredictPos(class AGamePlayer * pObj, const FVector & actorPos,const FVector & d_move, const FRotator& Rot);
};

