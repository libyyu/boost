﻿//#include "Azure.h"
#include "AzureDecelMoveBehavior.h"
#include "AzureObjectComponent.h"
#include "UE4Related.h"
#include "AzureUtility.h"
#include "Kismet/KismetSystemLibrary.h"
#include "GameLogic/Player/GamePlayer.h"
#include "GameLogic/Player/GamePlayer_Util.h"

using namespace Azure;

//////////////////////////////////////////////////////////////////////////
bool AzureDecelMoveBehavior::SetData(FVector vDest, float time, AGamePlayer * pCarrier, OnBehaviorFinish onFinish)
{
	if (!_objcomp.IsValid())
		return false;


	m_pObj = Cast<AActor>(_objcomp->GetOwner());
	if (!m_pObj.IsValid())
		return false;

	isGamePlayerMove = false;
	if (m_pObj->IsA<AGamePlayer>())
	{
		m_pGamePlayer = Cast<AGamePlayer>(m_pObj);
		isGamePlayerMove = true;
	}		

	set_OnFinish(onFinish);
	m_vDest = vDest;//如果在船上，vDest是相对坐标

	m_duration = time;
	m_time = 0.0f;

	m_carrier = pCarrier;
	m_isOnCarrier = (pCarrier != nullptr);

	GetCurPosAndDir(m_vStartPos,m_vStartDir);

	(m_vDest - m_vStartPos).ToDirectionAndLength(m_vDir, m_fDist);

	if(false)
	{
		if (!AAzureEntryPoint::Instance)
			return false;

		double st = AAzureEntryPoint::Instance->GetRealtimeSinceStartup();
		FVector unitdir = m_vDir.GetSafeNormal2D();
		FString str = FString::Printf(TEXT("AzureDecelMoveBehavior %0.1f %0.1f ---%0.3f"), unitdir.Rotation().Yaw, m_pObj->GetActorRotation().Yaw, st);
		MyPrintString(str);
	}
	
	if (false)
	{
		MyPrintString("start AzureMoveBehavior");
	}

	if (false)
	{
		DrawDestPos_SetData();
	}

	if (false)
	{
		if (!AAzureEntryPoint::Instance)
			return false;

		double st = AAzureEntryPoint::Instance->GetRealtimeSinceStartup();
		FString str = FString::Printf(TEXT("AzureDecelMoveBehavior SetData vDest %0.1f--%0.1f--%0.1f"), m_vDest.X, m_vDest.Y, m_vDest.Z);
		MyPrintString(str);
		str = FString::Printf(TEXT("AzureDecelMoveBehavior SetData vStartPos %0.1f--%0.1f--%0.1f"), m_vStartPos.X, m_vStartPos.Y, m_vStartPos.Z);
		MyPrintString(str);
		str = FString::Printf(TEXT("AzureDecelMoveBehavior SetData %0.3f--%0.3f"), (m_vDest - m_vStartPos).Size2D(),st);
		MyPrintString(str);
	}

	return true;
	// Debug.Log (string.Format ("MoveBehavior:SetData: SubType{0}, cur{1}, dest{2}, dist{3}, Dir{4}, speed{5}", eSubType, m_Trans.position, vDest, m_fDist, m_vDir, m_fSpeed));
}

void AzureDecelMoveBehavior::DrawDestPos_SetData()
{
	FVector draw_pos;
	FVector draw_dir;
	if (m_isOnCarrier)
	{
		if (m_carrier.IsValid())
		{
			AGamePlayer * pCarrier = m_carrier.Get();
			FVector t2 = pCarrier->GetFeetLocation();
			FRotator r2 = pCarrier->GetActorRotation();

			AzureUtility::CalAbsPosInfo(m_vDest, m_vStartDir.Rotation(), t2, r2, draw_pos, draw_dir);
		}
		else
		{
			MyPrintString2("AzureMoveBehavior carrier is not invalid", FLinearColor::Red);
		}
	}
	else
	{
		draw_pos = m_vDest;
		draw_dir = m_vStartDir;
	}

	FVector size(20, 20, 60);
	FVector v1 = draw_pos;
	v1.Z += 130.0f;
	UKismetSystemLibrary::DrawDebugBox(m_pObj->GetWorld(), v1, size, FLinearColor::Red,FRotator::ZeroRotator,2.0F);

	FVector v2 = v1 + draw_dir * 100;
	UKismetSystemLibrary::DrawDebugLine(m_pObj->GetWorld(), v1, v2, FLinearColor::Red,  2.0F);
}

void AzureDecelMoveBehavior::DrawTick()
{
	FVector draw_pos;
	FVector draw_dir;
	if (m_isOnCarrier)
	{
		if (m_carrier.IsValid())
		{
			AGamePlayer * pCarrier = m_carrier.Get();
			FVector t2 = pCarrier->GetFeetLocation();
			FRotator r2 = pCarrier->GetActorRotation();

			AzureUtility::CalAbsPosInfo(m_vDest, m_vStartDir.Rotation(), t2, r2, draw_pos, draw_dir);
		}
		else
		{
			MyPrintString2("AzureMoveBehavior carrier is not invalid", FLinearColor::Red);
		}
	}
	else
	{
		draw_pos = m_vDest;
		draw_dir = m_vStartDir;
	}

	if (true)
	{
		FVector size(20, 20, 60);
		FVector v1 = draw_pos;
		v1.Z += 140.0f;
		UKismetSystemLibrary::DrawDebugBox(m_pObj->GetWorld(), v1, size, FLinearColor::Yellow, FRotator::ZeroRotator, 2.0F);

		FVector v2 = v1 + draw_dir * 100;
		UKismetSystemLibrary::DrawDebugLine(m_pObj->GetWorld(), v1, v2, FLinearColor::Yellow, 2.0F);
	}
	

	if (true)
	{
		FVector size(15, 15, 40);
		FVector v1 = draw_pos;
		v1.Z += 140.0f;
		UKismetSystemLibrary::DrawDebugBox(m_pObj->GetWorld(), v1, size, FLinearColor::Green, FRotator::ZeroRotator, 2.0F);

		FVector v2 = v1 + draw_dir * 100;
		UKismetSystemLibrary::DrawDebugLine(m_pObj->GetWorld(), v1, v2, FLinearColor::Green, 2.0F);
	}	
}

void AzureDecelMoveBehavior::GetCurPosAndDir(FVector & result_pos, FVector & result_dir)
{
	FVector abs_pos;
	if (isGamePlayerMove)
		abs_pos = m_pGamePlayer->GetFeetLocation();
	else
		abs_pos = m_pObj->GetActorLocation();

	FRotator r1 = m_pObj->GetActorRotation();
	result_dir = m_pObj->GetActorForwardVector();
	
	if (m_isOnCarrier )
	{
		if (m_carrier.IsValid())
		{
			AGamePlayer * pCarrier = m_carrier.Get();
			FVector t2 = pCarrier->GetFeetLocation();
			FRotator r2 = pCarrier->GetActorRotation();
			AzureUtility::CalRelativePosInfo(abs_pos, r1, t2, r2, result_pos, result_dir);
		}
		else
		{
			MyPrintString2("AzureMoveBehavior carrier is not valid",FLinearColor::Red);
		}
	}
	else
	{
		result_pos = abs_pos;
	}
}

void AzureDecelMoveBehavior::SetCurPosAndDir(FVector pos)
{
	FVector abs_pos;
	if (m_isOnCarrier)//如果在船上，pos是相对位置
	{
		if (m_carrier.IsValid())
		{
			AGamePlayer * pCarrier = m_carrier.Get();
			FVector t2 = pCarrier->GetFeetLocation();
			FRotator r2 = pCarrier->GetActorRotation();
			FVector abs_dir;
			AzureUtility::CalAbsPosInfo(pos, m_vStartDir.Rotation(), t2, r2, abs_pos, abs_dir);
			m_pObj->SetActorRotation(abs_dir.Rotation());
		}
		else
		{
			MyPrintString2("AzureMoveBehavior carrier is not invalid 2", FLinearColor::Red);
			return;
		}
	}
	else
	{
		abs_pos = pos;
	}

	if (isGamePlayerMove)
		m_pGamePlayer->SetFeetLocation2(abs_pos);
	else
		m_pObj->SetActorLocation(abs_pos);
}

bool AzureDecelMoveBehavior::Tick(float dt)
{
	if (!_objcomp.IsValid())
		return true;

	AActor * pObj = Cast<AActor>(_objcomp->GetOwner());
	if (!pObj)
		return true;

	if (!m_pGamePlayer.IsValid())
		return true;

	//MyPrintString("Tick AzureMoveBehavior");

	if (m_time >= m_duration)
	{
		SetCurPosAndDir(m_vDest);

		//FString str = FString::Printf(TEXT("AzureMoveBehavior EndTick 1 %0.1f %0.1f"), delta.Size(), m_fSpeed);
		//MyPrintString(str);

		if (false)
		{
			if (!AAzureEntryPoint::Instance)
				return true;

			double st = AAzureEntryPoint::Instance->GetRealtimeSinceStartup();
			FString str = FString::Printf(TEXT("AzureDecelMoveBehavior End1 %0.1f %0.1f %0.1f---%0.3f"), m_vDest.X, m_vDest.Y, m_vDest.Z, st);
			MyPrintString(str);
		}

		return true;
	}

	float t2 = m_duration - m_time;
	float p = t2 / m_duration;
	float cur_dis = m_fDist * (1.0f - p * p);
	FVector curPos = m_vStartPos + cur_dis * m_vDir;

	SetCurPosAndDir(curPos);

	m_time += dt;

	if (false)
		DrawTick();

	if (false)
	{
		if (!AAzureEntryPoint::Instance)
			return false;

		double st = AAzureEntryPoint::Instance->GetRealtimeSinceStartup();
		//FString str = FString::Printf(TEXT("AzureMoveBehavior %0.3f %0.1f---%0.3f"), (m_vDest - m_curPos).Size2D(),m_fSpeed,st);
		FString str = FString::Printf(TEXT("AzureDecelMoveBehavior Tick %0.1f %0.2f---%0.3f"), cur_dis,(1.0f - p * p), st);
		MyPrintString(str);
	}

	return false;
}

void AzureDecelMoveBehavior::OnRemoved(bool replace)
{
	m_carrier = nullptr;
	m_isOnCarrier = false;
}

