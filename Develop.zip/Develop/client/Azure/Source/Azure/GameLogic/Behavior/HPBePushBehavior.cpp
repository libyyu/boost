﻿#include "HPBePushBehavior.h"
#include "AzureObjectComponent.h"
#include "AzureUtility.h"
#include "AzureExport.h"
#include "Blueprint/AIBlueprintHelperLibrary.h"
#include "GameLogic/Player/GamePlayer.h"
#include "GameLogic/Player/GamePlayer_Util.h"
#include "Navigation/PathFollowingManager.h"


HPBePushBehavior* HPBePushBehavior::Create()
{
	HPBePushBehavior* ret = (HPBePushBehavior*)AzureBehaviorCache::GetInstance().GetBehavior(_type);

	if (ret == nullptr)
		ret = new HPBePushBehavior();
	ret->_create_framecount = GFrameNumber;

	return ret;
}

bool HPBePushBehavior::SetData(const FVector& vDest, float speed, AGamePlayer * pCarrier, OnBehaviorFinish onFinish)
{
	if (!_objcomp.IsValid())
		return false;

	AGamePlayer * pActor = Cast<AGamePlayer>(_objcomp->GetOwner());
	if (!pActor)
		return false;

	m_vDest = vDest;
	m_fSpeed = speed;
	

	m_carrier = pCarrier;
	m_isOnCarrier = (pCarrier != nullptr);	
	
	FVector vStartPos;
	GetCurPosAndDir(vStartPos, m_vStartDir);

	m_curPos = vStartPos;

	(vDest - vStartPos).ToDirectionAndLength(m_vDir, m_fDist);

	set_OnFinish(onFinish);	
	
	if (pActor->m_fSyncPushMoveTimer >= Azure::host_send_sync_info_interval)//这里一开始加个限制，防止被怪逼在墙角，一直bePush，SetData和remove的发送会超过服务器1s 15次的限制
	{
		pActor->SyncPushMoveToServer("HPBePushBehavior SetData", ESyncMoveSendType::None, true, false);
	}
	

	return true;
}

void HPBePushBehavior::GetCurPosAndDir(FVector & result_pos, FVector & result_dir)
{
	if (!_objcomp.IsValid())
		return;

	AGamePlayer * pActor = Cast<AGamePlayer>(_objcomp->GetOwner());
	if (!pActor)
		return;

	FVector abs_pos = pActor->GetFeetLocation();

	FRotator r1 = pActor->GetActorRotation();
	result_dir = pActor->GetActorForwardVector();

	if (m_isOnCarrier)
	{
		if (m_carrier.IsValid())
		{
			AGamePlayer * pCarrier = m_carrier.Get();
			FVector t2 = pCarrier->GetFeetLocation();
			FRotator r2 = pCarrier->GetActorRotation();
			AzureUtility::CalRelativePosInfo(abs_pos, r1, t2, r2, result_pos, result_dir);
		}
		else
		{
			MyPrintString2("HPBePushBehavior carrier is not valid", FLinearColor::Red);
		}
	}
	else
	{
		result_pos = abs_pos;
	}
}

void HPBePushBehavior::OnRemoved(bool replace)
{
	if (!_objcomp.IsValid())
		return;

	AGamePlayer * pActor = Cast<AGamePlayer>(_objcomp->GetOwner());
	if (!pActor)
		return;
	
	if(!replace)
	pActor->SyncPushMoveToServer("HPBePushBehavior Remove", ESyncMoveSendType::Stop, true, false);
}

void HPBePushBehavior::SetCurPos(const FVector & pos)
{
	if (!_objcomp.IsValid())
		return ;

	AGamePlayer * pActor = Cast<AGamePlayer>(_objcomp->GetOwner());
	if (!pActor)
		return;

	FVector old_pos = pActor->GetFeetLocation();	

	FVector abs_pos;
	if (m_isOnCarrier)//如果在船上，pos是相对位置
	{
		if (m_carrier.IsValid())
		{
			AGamePlayer * pCarrier = m_carrier.Get();
			FVector t2 = pCarrier->GetFeetLocation();
			FRotator r2 = pCarrier->GetActorRotation();
			FVector abs_dir;
			AzureUtility::CalAbsPosInfo(pos, m_vStartDir.Rotation(), t2, r2, abs_pos, abs_dir);
			pActor->SetActorRotation(abs_dir.Rotation());
		}
		else
		{
			MyPrintString2("HPBePushBehavior carrier is not invalid 2", FLinearColor::Red);
			return;
		}
	}
	else
	{
		abs_pos = pos;
	}

	
	pActor->SetFeetLocation2(abs_pos);
	
	if (false)
	{
		FVector v1 = abs_pos;
		FVector v2 = v1 + FVector::UpVector * 200.0f;
		UKismetSystemLibrary::DrawDebugLine(pActor->GetWorld(), v1, v2, FLinearColor::Green,5.0f);
	}
	
}


bool HPBePushBehavior::TickInternal(float dt)
{
	if (!HPMoveBase::TickInternal(dt))
		return false;

	if (!_objcomp.IsValid())
		return true;

	AGamePlayer * pActor = Cast<AGamePlayer>(_objcomp->GetOwner());
	if (!pActor)
		return true;

	FVector delta = m_curPos - m_vDest;
	if (delta.Size() < 0.05f * UE_METRE_TRANS)
	{
		m_fDist = 0;
		SetCurPos(m_vDest);

		return true;
	}

	float fMove = dt * m_fSpeed;
	if (fMove >= m_fDist)
	{
		m_fDist = 0;

		SetCurPos(m_vDest);
		return true;
	}

	m_fDist -= fMove;

	m_curPos += fMove * m_vDir;
	SetCurPos(m_curPos);	
	
	if (pActor->m_fSyncPushMoveTimer >= Azure::host_send_sync_info_interval)//
	{
		pActor->SyncPushMoveToServer("HPBePushBehavior Tick", ESyncMoveSendType::None, false, false);
	}
	
	return false;
}



