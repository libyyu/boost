#pragma once

#include "HPMoveBase.h"


class HPBePushBehavior : public HPMoveBase
{
protected:
	static constexpr  Azure::BehaviorType _type = Azure::BehaviorType::HPBePush;

	FVector m_vDest;

	FVector m_curPos;
	float m_fSpeed;
	FVector m_vStartDir;
	FVector m_vDir;
	float m_fDist;

	TWeakObjectPtr<class AGamePlayer> m_pGamePlayer;
	TWeakObjectPtr<class AGamePlayer> m_carrier;
	bool m_isOnCarrier;

public:

	HPBePushBehavior()
	{
		
	}

	Azure::BehaviorType get_Type() const override
	{
		return _type;
	}

	static HPBePushBehavior* Create();

	bool SetData(const FVector& vDest, float speed, class AGamePlayer * pCarrier, OnBehaviorFinish onFinish);
	virtual void OnRemoved(bool replace) override;
	void GetCurPosAndDir(FVector & pos, FVector & dir);
	void SetCurPos(const FVector & pos);

protected:

	virtual bool TickInternal(float dt) override;
};