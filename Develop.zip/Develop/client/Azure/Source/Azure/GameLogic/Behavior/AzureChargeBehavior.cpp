﻿//#include "Azure.h"
#include "AzureChargeBehavior.h"
#include "AzureEntryPoint.h"
#include "AzureObjectComponent.h"
#include "UE4Related.h"
#include "AzureUtility.h"

using namespace Azure;

bool AzureChargeBehavior::SetData(bool bHostPlayer, int idSkill, FVector vDest, float time, OnBehaviorFinish onFinish, float fExt, float fAboveH1, float fAboveH2, float fAboveHFinal)
{
	if (time <= 0 || !_objcomp.IsValid())
	{
		set_IsValid(false);
		return false;
	}

	AActor * pOwner = get_ECObj()->GetOwner();
	if (!pOwner)
	{
		set_IsValid(false);
		return false;
	}
	//if (float.IsNaN(time) || float.IsInfinity(time)) {
	//	Debug.LogError(string.Format ("AzureChargeBehavior: time Invalid! {0}", time));
	//	return;
	//}

	set_IsHostPlayer(bHostPlayer);

	set_OnFinish(onFinish);

	set_Skill(idSkill);
	//m_ECObj->SetMoveSubType(eSubType);

	_fExt = fExt;
	_fAboveH1 = fAboveH1;
	_fAboveH2 = fAboveH2;
	_fAboveHFinal = fAboveHFinal;

	//if (AzureUtility::IsVectorInvalid (vDest)) {
	//	Debug.LogError(string.Format ("AzureChargeBehavior: vDest Invalid! {0}", vDest));
	//	return;
	//}

	FVector vCurPos = pOwner->GetActorLocation();

	//if (AzureUtility::IsVectorInvalid (vCurPos)) {
	//	Debug.LogError(string.Format ("AzureChargeBehavior: CurPos Invalid! {0}", vCurPos));
	//	return;
	//}

	float fGndHei = VEC_UP(vDest);

	if (_fAboveHFinal > 0)
	{
		if (get_IsHostPlayer())
		{
			//	HostPlayer: 一步步逐渐向dest拉，避免上房！
			fGndHei = AzureUtility::GetDestPosHeightFromCurPos(vDest, vCurPos, 1.0f * UE_METRE_TRANS, _fExt, _fAboveH1, _fAboveH2, _fAboveHFinal);
		}
		else
		{
			FVector vTest = vDest;
			VEC_UP(vTest) += _fAboveHFinal;
			AzureUtility::GetSupportPlaneHeight(fGndHei, vTest, _fExt);
		}
	}

	VEC_UP(vDest) = fGndHei;

	//if (float.IsNaN(vDest.y) || float.IsInfinity(vDest.y)) {
	//	Debug.LogError(string.Format ("AzureChargeBehavior: vDest.y Invalid! {0}", vDest.y));
	//	return;
	//}

	_Destination = vDest;

	if (time < 0.01f) {
		pOwner->SetActorLocation(_Destination);
		set_IsValid(false);
		return false;
	}

	FVector dis = vDest - vCurPos;
	_Velocity = dis / time;

	if (AAzureEntryPoint::Instance)
		_FinishedTime = float(AAzureEntryPoint::Instance->GetCurFrameTime() + time);
	else
		_FinishedTime = 0.0f;

	//Debug.LogWarning(string.Format ("AzureChargeBehavior:SetData: dest = {0}, src = {1}, dist = {2}, time = {3}, Vel = {4}",
	//                                vDest, m_ECObj.transform.position, dis, time, _Velocity));

	return true;
}

void AzureChargeBehavior::ChangeTargetPos(FVector vDest)
{
	//if (AzureUtility::IsVectorInvalid (vDest)) {
	//	Debug.LogError(string.Format ("Charge: ChangeTargetPos: vDest Invalid! {0}", vDest));
	//	return;
	//}
	if (!_objcomp.IsValid())
		return;

	AActor* obj = _objcomp->GetOwner();
	if (!obj)
		return;

	FVector vCurPos = obj->GetActorLocation();

	//if (AzureUtility::IsVectorInvalid (vCurPos)) {
	//	Debug.LogError(string.Format ("Charge: ChangeTargetPos: CurPos Invalid! {0}", vCurPos));
	//	return;
	//}

	float fGndHei = VEC_UP(vCurPos);

	if (get_IsHostPlayer())
	{
		//	HostPlayer: 一步步逐渐向dest拉，避免上房！
		fGndHei = AzureUtility::GetDestPosHeightFromCurPos(vDest, vCurPos, 1.0f * UE_METRE_TRANS, Azure::s_fPlayerMoveExt, 1.8f * UE_METRE_TRANS, 3.8f * UE_METRE_TRANS, 50.0f * UE_METRE_TRANS);
	}
	else
	{
		FVector vTest = vDest;
		VEC_UP(vTest) += 50.0f * UE_METRE_TRANS;
		AzureUtility::GetSupportPlaneHeight(fGndHei, vTest, _fExt);
	}

	//if (float.IsNaN(vDest.y) || float.IsInfinity(vDest.y)) {
	//	Debug.LogError(string.Format ("Charge: ChangeTargetPos: vDest.y Invalid! {0}", vDest.y));
	//	return;
	//}

	_Destination = vDest;

	FVector dis = vDest - vCurPos;

	if (!AAzureEntryPoint::Instance)
		return;

	float lefttime = _FinishedTime - (float)AAzureEntryPoint::Instance->GetCurFrameTime();

	if (lefttime < 0.05f)
	{
		//Debug.LogWarning(string.Format ("AzureChargeBehavior:ChangeTargetPos: dest = {0}, src = {1}, lefttime = {3}< 0.05f, position -> Dest.",
		//                                vDest, m_ECObj.transform.position, lefttime));
		obj->SetActorLocation(_Destination);
		_FinishedTime = 0;
		return;
	}

	//if (float.IsNaN(lefttime) || float.IsInfinity(lefttime)) {
	//	Debug.LogError(string.Format ("Charge: ChangeTargetPos: lefttime Invalid! {0}", lefttime));
	//	return;
	//}

	_Velocity = dis / lefttime;

	//Debug.LogWarning(string.Format ("AzureChargeBehavior:ChangeTargetPos: dest = {0}, src = {1}, dist = {2}, lefttime = {3}, Vel = {4}",
	//                                vDest, m_ECObj.transform.position, dis, lefttime, _Velocity));
}

bool AzureChargeBehavior::Tick(float dt)
{
	if (!_objcomp.IsValid())
		return true;

	if (!AAzureEntryPoint::Instance)
		return true;

	if (_FinishedTime <= AAzureEntryPoint::Instance->GetCurFrameTime())
	{
		AActor* obj = _objcomp->GetOwner();
		if (obj)
			obj->SetActorLocation(_Destination);
		return true;
	}

	AActor* obj = _objcomp->GetOwner();
	if(obj)
		obj->SetActorLocation(obj->GetActorLocation() + _Velocity * dt);
	return false;
}

void AzureChargeBehavior::OnRemoved(bool replace)
{

}
