﻿#pragma once

#include "CoreMinimal.h"
#include <functional>
#include "ABaseDef.h"

#include "AzureBehaviorDef.h"

class UAzureObjectComponent;

typedef std::function<void(Azure::BehaviorFinishState)> OnBehaviorFinish;

class AzureBehavior
{
protected:

	TWeakObjectPtr<UAzureObjectComponent> _objcomp = nullptr;

	OnBehaviorFinish _on_finish = nullptr;
	bool m_valid = true;

public:

	virtual ~AzureBehavior()
	{
	}

	virtual UAzureObjectComponent* get_ECObj();

	virtual void set_ECObj(UAzureObjectComponent* v);

	virtual Azure::BehaviorType get_Type() const
	{
		return Azure::BehaviorType::Invalid;
	}

	OnBehaviorFinish get_OnFinish()
	{
		return _on_finish;
	}

	void set_OnFinish(OnBehaviorFinish cb)
	{
		if (_on_finish != nullptr)
			_on_finish(Azure::BehaviorFinishState::Clear);
		_on_finish = cb;
	}

	void ClearOnFinish()
	{
		if (_on_finish != nullptr)
		{
			_on_finish(Azure::BehaviorFinishState::Clear);
			_on_finish = nullptr;
		}
	}

	bool get_IsValid() const
	{
		return m_valid;
	}
	void set_IsValid(bool v)
	{
		m_valid = v;
	}

	// 在charactermovement tick之后调用
	virtual bool Tick(float dt) = 0;
	virtual void OnRemoved(bool replace) = 0;
};

class AzureBehaviorCache
{
	static size_t MaxCacheNum[(int)Azure::BehaviorType::NumType];
	alist<AzureBehavior*> m_cache[(int)Azure::BehaviorType::NumType];

public:

	static AzureBehaviorCache& GetInstance()
	{
		static AzureBehaviorCache inst;
		return inst;
	}

	AzureBehaviorCache()
	{
	}

	~AzureBehaviorCache()
	{
		Clear();
	}

	AzureBehavior* GetBehavior(Azure::BehaviorType tp)
	{
		auto& cache = m_cache[(int)tp];

		if (cache.size() > 0)
		{
			AzureBehavior* beh = cache.back();
			cache.pop_back();
			return beh;
		}

		return nullptr;
	}

	void CacheBehavior(AzureBehavior* beh)
	{
		auto& cache = m_cache[(int)beh->get_Type()];

		//if (cache.size() < MaxCacheNum[(int)beh->get_Type()])
		if (cache.size() < 1)
		{
			beh->set_ECObj(nullptr);
			beh->set_IsValid(true);
			beh->set_OnFinish(nullptr);
			cache.push_back(beh);
		}
		else
			delete beh;
	}

	void Clear()
	{
		for (size_t i = 0; i < (size_t)Azure::BehaviorType::NumType; ++i)
		{
			auto& cache = m_cache[i];

			for (auto beh : cache)
				delete beh;

			cache.clear();
		}
	}
};
