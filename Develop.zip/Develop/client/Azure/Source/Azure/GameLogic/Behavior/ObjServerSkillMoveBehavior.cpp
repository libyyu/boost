﻿#include "ObjServerSkillMoveBehavior.h"
#include "AzureObjectComponent.h"
#include "AzureUtility.h"
#include "AzureExport.h"
#include "GameLogic/Player/GamePlayer.h"
#include "GameLogic/Player/GamePlayer_Util.h"
#include "GameLogic/Player/MyMovementComponent.h"

ObjServerSkillMoveBehavior* ObjServerSkillMoveBehavior::Create()
{
	ObjServerSkillMoveBehavior* ret = (ObjServerSkillMoveBehavior*)AzureBehaviorCache::GetInstance().GetBehavior(_type);

	if (ret == nullptr)
		ret = new ObjServerSkillMoveBehavior();

	return ret;
}

bool ObjServerSkillMoveBehavior::SetData(const FVector & vStart, float vStartYaw, const FVector & vDest, float speed, OnBehaviorFinish onFinish)
{
	if (!_objcomp.IsValid())
		return false;

	AGamePlayer * pActor = Cast<AGamePlayer>(_objcomp->GetOwner());
	if (!pActor)
		return false;

	m_dest = vDest;
	set_OnFinish(onFinish);

	m_start = pActor->GetFeetLocation();
	m_delta = m_dest - m_start;

	m_dis2D = m_delta.Size2D();

	if(speed <= 0.0f)
		speed = pActor->GetCharacterMovement()->MaxWalkSpeed;

	m_duration = m_dis2D / speed;
	m_cur_time = 0.0f;

	m_velocity = m_delta.GetSafeNormal2D() * speed;


	if (pActor->dodge_debug)
	{
		pActor->rep_dodge_target_pos = vDest;
	}

	pActor->m_server_skill_move = true;
	return true;
}

void ObjServerSkillMoveBehavior::OnRemoved(bool replace)
{
	if (!_objcomp.IsValid())
		return;

	AGamePlayer * pActor = Cast<AGamePlayer>(_objcomp->GetOwner());
	if(pActor)
		pActor->m_server_skill_move = false;
}

bool ObjServerSkillMoveBehavior::Tick(float dt)
{
	if (!_objcomp.IsValid())
		return true;

	AGamePlayer * pActor = Cast<AGamePlayer>(_objcomp->GetOwner());
	if (!pActor)
		return true;
	
	FVector delta = pActor->GetFeetLocation() - m_start;
	float angle = AzureUtility::Angle(m_delta, delta);

	//如果没有遇到碰撞发生侧移，且移动超过终点
	if (delta.Size2D() > m_dis2D && angle <= 10.0f)
	{
		FVector testPos;
		testPos.X = m_dest.X;
		testPos.Y = m_dest.Y;
		testPos.Z = pActor->GetFeetLocation().Z;
		float z = GetGamePlayerPosZ(testPos, pActor);

		pActor->SetFeetLocation(m_dest.X, m_dest.Y, z);
	}

	if (false)
	{
		FString str = FString::Printf(TEXT("MoveBeh angle [%0.1f] "), angle);
		MyPrintString(str);
	}


	if (m_cur_time >= m_duration)
	{
		pActor->GetMyMovementComponent()->SetVelocity(FVector::ZeroVector);
		return true;	
	}
	else
	{
		m_cur_time += dt;
		pActor->GetMyMovementComponent()->SetVelocity(m_velocity);

		if (false)
		{
			//FVector pos = pActor->GetActorLocation();
			//FString str = FString::Printf(TEXT("MoveBeh velocity [%0.1f %0.1f %0.1f] "), _velocity.X, _velocity.Y, _velocity.Z);
			//MyPrintString(str);
		}
	}
	
	return false;
}


