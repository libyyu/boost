﻿// Fill out your copyright notice in the Description page of Project Settings.

#include "AzureHomeExhibitionBase.h"
#include "Components/SkeletalMeshComponent.h"
#include "Components/SplineComponent.h"
#include "Animation/AnimInstance.h"
#include "Engine/CollisionProfile.h"
#include "UObject/StructOnScope.h"

#include "AzureEntryPoint.h"
#include "wLua/LuaInterface.h"

/**
	休息状态
*/
class FAzureHomeExhibitionStateIdle : public FAzureHomeExhibitionStateBase
{
public:
	FAzureHomeExhibitionStateIdle(AAzureHomeExhibitionBase* Owner)
		: FAzureHomeExhibitionStateBase(Owner)
	{
	}

	void OnEnter()
	{
		if (_Owner->MovePolicy == EHomeExhibitionMovePolicy::SPLINE)
			_curRestTime = 0.0f;
		else
		{
			_curRestTime = _Owner->IdleTime;
		}
	}

	void OnLeave()
	{
	}

	void OnUpdate(float DeltaSeconds)
	{
		if (_curRestTime - DeltaSeconds > 0.0f)
			_curRestTime -= DeltaSeconds;
		else
		{
			_curRestTime = 0.0f;
			_Owner->ChangeState(EHomeExhibitionState::MOVING);
		}
	}

protected:
	float _curRestTime = 0.0f;
};

/**
	移动状态
*/
class FAzureHomeExhibitionStateMove : public FAzureHomeExhibitionStateBase
{
public:
	FAzureHomeExhibitionStateMove(AAzureHomeExhibitionBase* Owner)
		: FAzureHomeExhibitionStateBase(Owner)
	{
	}

	void OnEnter()
	{
		_spline = _Owner->Spline;
		_mesh = _Owner->Entity;

		if (_mesh.IsValid())
		{
			_curPos = _mesh->RelativeLocation;

			Call_SetVelocity(_Owner->MoveSpeed);
		}

		if (_Owner->MovePolicy == EHomeExhibitionMovePolicy::RANDOM_POS)
		{
			FVector Dest = CalcRandomPos();
			_nextDestPos = Dest;

			FVector Dir = Dest - _curPos;
			Dir.ToDirectionAndLength(_moveDir, _moveDist);
			FRotator Rot = _moveDir.ToOrientationRotator();
			_mesh->SetRelativeRotation(Rot);
		}
		else
		{
			// 随机选择曲线的开始时间
			float Duration = _spline->Duration;
			_splinePlayTime = FMath::RandRange(0.0f, Duration);
		}
	}

	void OnLeave()
	{
		if (_mesh.IsValid())
		{
			Call_SetVelocity(0.0f);
		}

		_mesh = nullptr;
		_spline = nullptr;
	}

	void OnUpdate(float DeltaSeconds)
	{
		if (!_mesh.IsValid())
			return;

		bool bFinish = false;

		if (_Owner->MovePolicy == EHomeExhibitionMovePolicy::SPLINE)
		{
			bFinish = MoveSpline(DeltaSeconds);
		}
		else
		{
			bFinish = MoveLine(DeltaSeconds);
		}

		if (bFinish)
			_Owner->ChangeState(EHomeExhibitionState::IDLE);
	}

protected:
	TWeakObjectPtr<USceneComponent> _mesh;
	TWeakObjectPtr<USplineComponent> _spline;
	FVector _curPos;
	FVector _moveDir;
	FVector _nextDestPos;
	float _moveDist;
	float _splinePlayTime = 0.0;

	FVector CalcRandomPos()
	{
		FVector Pos = FMath::RandPointInBox(_Owner->RangeBox);
		if (_Owner->Move2D)
			Pos.Z = _mesh->RelativeLocation.Z;
		return Pos;
	}

	bool MoveLine(float DeltaSeconds)
	{
		float fMove = _Owner->MoveSpeed * DeltaSeconds;
		if (fMove >= _moveDist)
		{
			_mesh->SetRelativeLocation(_nextDestPos);
			return true;
		}

		_moveDist -= fMove;
		_curPos += _moveDir * fMove;
		_mesh->SetRelativeLocation(_curPos);
		return false;
	}

	bool MoveSpline(float DeltaSeconds)
	{
		FVector pos = _spline->GetLocationAtTime(_splinePlayTime, ESplineCoordinateSpace::Local, true);
		FRotator rotator = _spline->GetRotationAtTime(_splinePlayTime, ESplineCoordinateSpace::Local, true);
		_mesh->SetRelativeLocation(pos);
		_mesh->SetRelativeRotation(rotator);
		_splinePlayTime += DeltaSeconds;
		if (_splinePlayTime >= _spline->Duration)
		{
			if (_spline->IsClosedLoop())
				_splinePlayTime = 0.0f;
			else
				return true;
		}
		return false;
	}

	void Call_SetVelocity(float Velocity)
	{
		UFunction* Func = _Owner->FindFunction(TEXT("SetVelocity"));
		if (Func)
		{
			struct FDispatchParams
			{
				float velocity;
			} Params;
			Params.velocity = Velocity;

			if (Func->PropertiesSize != sizeof(FDispatchParams))
			{
				FStructOnScope params(Func);
				*(float*)(params.GetStructMemory() + 0) = Params.velocity;
				_Owner->ProcessEvent(Func, params.GetStructMemory());
				Params.velocity = *(float*)(params.GetStructMemory() + 0);
			}
			else
				_Owner->ProcessEvent(Func, &Params);
		}
	}
};

// Sets default values
AAzureHomeExhibitionBase::AAzureHomeExhibitionBase()
{
	// Set this actor to call Tick() every frame.  You can turn this off to improve performance if you don't need it.
	PrimaryActorTick.bCanEverTick = true;

	RootComponent = CreateDefaultSubobject<USceneComponent>(TEXT("Root"));
	RootComponent->SetMobility(EComponentMobility::Movable);

	Container = CreateDefaultSubobject<UStaticMeshComponent>(TEXT("Container"));
	Container->SetupAttachment(RootComponent);

	Entity = CreateDefaultSubobject<USceneComponent>(TEXT("Entity"));
	Entity->SetupAttachment(Container);

	EntityMesh = CreateDefaultSubobject<USkeletalMeshComponent>(TEXT("EntityMesh"));
	EntityMesh->SetCollisionProfileName(UCollisionProfile::NoCollision_ProfileName);
	EntityMesh->SetGenerateOverlapEvents(false);

	EntityMesh->SetupAttachment(Entity);

	Spline = CreateDefaultSubobject<USplineComponent>(TEXT("Spline"));
	Spline->SetupAttachment(Container);
}

void AAzureHomeExhibitionBase::BeginPlay()
{
	Super::BeginPlay();

	_stateCache.Add(EHomeExhibitionState::IDLE, new FAzureHomeExhibitionStateIdle(this));
	_stateCache.Add(EHomeExhibitionState::MOVING, new FAzureHomeExhibitionStateMove(this));

	_curState = GetCachedState(EHomeExhibitionState::IDLE);
}

void AAzureHomeExhibitionBase::BeginDestroy()
{
	for (auto& item : _stateCache)
	{
		delete item.Value;
	}

	Super::BeginDestroy();
}

void AAzureHomeExhibitionBase::Tick(float DeltaSeconds)
{
	Super::Tick(DeltaSeconds);

	if (_curState)
		_curState->OnUpdate(DeltaSeconds);
}

void AAzureHomeExhibitionBase::ChangeState(EHomeExhibitionState NewState)
{
	if (_curState)
		_curState->OnLeave();

	_curState = GetCachedState(NewState);
	_curState->OnEnter();
}

FAzureHomeExhibitionStateBase* AAzureHomeExhibitionBase::GetCachedState(EHomeExhibitionState NewState)
{
	return _stateCache[NewState];
}