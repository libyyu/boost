// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "ProceduralMeshComponent.h"

class UMaterialInterface;

class  AzureHomeUtil
{
public:
	//Material Param Names
	static FName VG_BaseColor;
	static FName VG_Normal;
	static FName VG_UVOffsetX;
	static FName VG_UVOffsetY;
	static FName VG_UScale;
	static FName VG_VScale;

	static FName VB_BaseColor;
	static FName VB_Normal;
	static FName VB_UVOffsetX;
	static FName VB_UVOffsetY;
	static FName VB_UScale;
	static FName VB_VScale;

	static FName TintColor;

public:	
	AzureHomeUtil() {}

	static void BuildQuad(TArray<FVector>& Vertices, TArray<int32>& Triangles, TArray<FVector>& Normals, TArray<FVector2D>& UV0, TArray<FColor>& VertexColors, TArray<FProcMeshTangent>& Tangents,
		FVector BottomRight, FVector BottomLeft, FVector TopLeft, FVector TopRight, FVector Normal, FProcMeshTangent Tangent, FColor c, float u_unit, float v_unit, bool bHorizontal, float rot_uv = 0.0f);
	//ˮƽ������
	static void GenerateTriangle(TArray<FVector>& Vertices, TArray<int32>& Triangles, TArray<FVector>& Normals, TArray<FVector2D>& UV0, TArray<FColor>& VertexColors, TArray<FProcMeshTangent>& Tangents,
		FVector vBevelStart, FVector vBevelEnd, bool OnRight, float Height, float GridSize);
	static void BuildTriangle(TArray<FVector>& Vertices, TArray<int32>& Triangles, TArray<FVector>& Normals, TArray<FVector2D>& UV0, TArray<FColor>& VertexColors, TArray<FProcMeshTangent>& Tangents,
		FVector P0, FVector P1, FVector P2, FVector Normal, FProcMeshTangent Tangent, FColor c, float uv_unit, float rot_uv = 0);
	//����¥��
	static void GenerateStairs(TArray<FVector>& Vertices, TArray<int32>& Triangles, TArray<FVector>& Normals, TArray<FVector2D>& UV0, TArray<FColor>& VertexColors, TArray<FProcMeshTangent>& Tangents,
		float step_w, float step_l, float step_h, int num_steps, float zStart, float u_unit, float v_unit);

	//������ֱ�ߵĽ���  Ҳ����FMath::SegmentIntersection2D (FMath���û�п��Ǿ���0.01f,�ʲ����ϼ�԰���󡣡���)
	static bool GetPointIntersection(const FVector2D& sp1, const FVector2D& ep1, const FVector2D& sp2, const FVector2D& ep2, FVector2D& outPoint);

	static void CopyTexture2D(UMaterialInstanceDynamic* pWallDynamic, UMaterialInstanceDynamic* pItemDynamic);
	static void SetRightWallMaterialParameter(UMaterialInstanceDynamic* pWallDynamic, float UOffset, float VOffset, float UScale, float VScale);
	static void SetLeftWallMaterialParameter(UMaterialInstanceDynamic* pWallDynamic, float UOffset, float VOffset, float UScale, float VScale);
	static void SetWallMaterialColor(UMaterialInstanceDynamic* pWallDynamic, const FLinearColor& TintColor);
};
