// Fill out your copyright notice in the Description page of Project Settings.

#include "AzureProceduralMeshActor.h"
#include "Engine.h"
#include "Materials/MaterialInstanceDynamic.h"
#include "AzureUtility.h"
#include "../ResourceLoader/AzureResourceLoader.h"

#if WITH_EDITOR
#include "PropertyEditorModule.h"
#endif

// Sets default values
AAzureProceduralMeshActor::AAzureProceduralMeshActor()
{
 	// Set this actor to call Tick() every frame.  You can turn this off to improve performance if you don't need it.
	PrimaryActorTick.bCanEverTick = true;

	if (!RootComponent)
	{
		ProceduralMeshComponent = CreateDefaultSubobject<UProceduralMeshComponent>(TEXT("ProceduralMeshComponent"));
		SetRootComponent(ProceduralMeshComponent);
	}

	
	
}
// Called when the game starts or when spawned
void AAzureProceduralMeshActor::BeginPlay()
{
	Super::BeginPlay();

}

void AAzureProceduralMeshActor::PostInitProperties()
{
	Super::PostInitProperties();
}

void AAzureProceduralMeshActor::PostLoad()
{
	Super::PostLoad();
}


#if WITH_EDITOR
void AAzureProceduralMeshActor::PostEditChangeProperty(FPropertyChangedEvent& PropertyChangedEvent)
{
	Super::PostEditChangeProperty(PropertyChangedEvent);
}

void AAzureProceduralMeshActor::RegisterCustomPropertyTypeLayout(FName PropertyTypeName, FOnGetPropertyTypeCustomizationInstance PropertyTypeLayoutDelegate)
{
	check(PropertyTypeName != NAME_None);


	static FName PropertyEditor("PropertyEditor");
	FPropertyEditorModule& PropertyModule = FModuleManager::GetModuleChecked<FPropertyEditorModule>(PropertyEditor);
	//FPropertyTypeLayoutCallback PropertyTypeLayoutCallback = PropertyModule.FindPropertyTypeLayoutCallback(PropertyTypeName,)
	PropertyModule.RegisterCustomPropertyTypeLayout(PropertyTypeName, PropertyTypeLayoutDelegate);
}

#endif

// Called every frame
void AAzureProceduralMeshActor::Tick( float DeltaTime )
{
	Super::Tick( DeltaTime );
		
}


int AAzureProceduralMeshActor::CreateMeshSection(const TArray<FVector>& Vertices, const TArray<int32>& Triangles, const TArray<FVector>& Normals, const TArray<FVector2D>& UV0, const TArray<FColor>& VertexColors, const TArray<FProcMeshTangent>& Tangents, bool bCreateCollision)
{
	int MeshSection = CreateSctionID();
	ProceduralMeshComponent->CreateMeshSection(MeshSection, Vertices, Triangles, Normals, UV0, VertexColors, Tangents, bCreateCollision);
	return MeshSection;
}

void AAzureProceduralMeshActor::UpdateMeshSection(int32 section_id, const TArray<FVector>& Vertices, const TArray<int32>& Triangles, const TArray<FVector>& Normals, const TArray<FVector2D>& UV0, const TArray<FColor>& VertexColors, const TArray<FProcMeshTangent>& Tangents)
{
	FProcMeshSection *Section = ProceduralMeshComponent->GetProcMeshSection(section_id);
	if (!Section) return;
	int32 NumVerts = Section->ProcVertexBuffer.Num();
	if (Vertices.Num() == NumVerts)
		ProceduralMeshComponent->UpdateMeshSection(section_id, Vertices, Normals, UV0, VertexColors, Tangents);
	else
		ProceduralMeshComponent->CreateMeshSection(section_id, Vertices, Triangles, Normals, UV0, VertexColors, Tangents, Section->bEnableCollision);
}

int AAzureProceduralMeshActor::CreateSctionID()
{
	if (SectionCache.Num())
		return SectionCache.Pop(false);

	return ProceduralMeshComponent->GetNumSections();
}

bool AAzureProceduralMeshActor::ReleaseSectionMesh(int32 section_id)
{
	if (section_id < 0)
		return false;
	ProceduralMeshComponent->ClearMeshSection(section_id);
	ProceduralMeshComponent->SetMaterial(section_id, nullptr);
	SectionCache.Push(section_id);
	return true;
}

void AAzureProceduralMeshActor::SetMaterial(int32 section_id, UMaterialInterface* Material)
{
	ProceduralMeshComponent->SetMaterial(section_id, Material);
}

UMaterialInterface* AAzureProceduralMeshActor::GetSectionMaterialInst(int32 section_id)
{
	return ProceduralMeshComponent->GetMaterial(section_id);
}

int32 AAzureProceduralMeshActor::GetSectionVerticesNum(int32 section_id)
{
	FProcMeshSection *Section = ProceduralMeshComponent->GetProcMeshSection(section_id);
	if (!Section)
		return 0;
	else
		return Section->ProcVertexBuffer.Num();
}

void AAzureProceduralMeshActor::SetMeshSectionVisible(int32 SectionIndex, bool bNewVisibility)
{
	ProceduralMeshComponent->SetMeshSectionVisible(SectionIndex, bNewVisibility);
}
bool AAzureProceduralMeshActor::IsMeshSectionVisible(int32 SectionIndex)
{
	return ProceduralMeshComponent->IsMeshSectionVisible(SectionIndex);
}
int32 AAzureProceduralMeshActor::GetNumSections()
{
	return ProceduralMeshComponent->GetNumSections();
}
int32 AAzureProceduralMeshActor::GetNumMaterials()
{
	return ProceduralMeshComponent->GetNumMaterials();
}
void AAzureProceduralMeshActor::ClearAllMeshSections()
{
	ProceduralMeshComponent->ClearAllMeshSections();
}

void AAzureProceduralMeshActor::SetCollisionProfileName(FString ProfileName)
{
	ProceduralMeshComponent->SetCollisionProfileName(*ProfileName);
}

void AAzureProceduralMeshActor::SetRelativeLocationAndRotationAndScale(FVector RelativeLocation, FRotator RelativeRotation, FVector RelativeScale3D)
{
	ProceduralMeshComponent->SetRelativeLocationAndRotation(RelativeLocation, RelativeRotation);
	ProceduralMeshComponent->SetRelativeScale3D(RelativeScale3D);
	ProceduralMeshComponent->RelativeLocation = RelativeLocation;
	ProceduralMeshComponent->RelativeRotation = RelativeRotation;
	ProceduralMeshComponent->RelativeScale3D = RelativeScale3D;
}

void AAzureProceduralMeshActor::SetRelativeLocationAndRotation(FVector RelativeLocation, FRotator RelativeRotation)
{
	ProceduralMeshComponent->SetRelativeLocationAndRotation(RelativeLocation, RelativeRotation);
	ProceduralMeshComponent->RelativeLocation = RelativeLocation;
	ProceduralMeshComponent->RelativeRotation = RelativeRotation;
}