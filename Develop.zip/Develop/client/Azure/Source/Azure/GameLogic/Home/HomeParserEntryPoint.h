﻿// Copyright 2015-2016 Code Respawn Technologies. MIT License

#pragma once

#include "AzureEntryPoint.h"

#include "HomeParserEntryPoint.generated.h"

UCLASS()
class AHomeParserEntryPoint : public AAzureEntryPoint
{
	GENERATED_BODY()

public:
	AHomeParserEntryPoint();

	// Called when the game starts or when spawned
	virtual void BeginPlay() override;
	virtual void EndPlay(const EEndPlayReason::Type EndPlayReason) override;

	// Called every frame
	virtual void Tick(float DeltaSeconds) override;
	virtual void BeginDestroy() override;

public:

	UPROPERTY(EditAnywhere, Category = "HomeParser")
	FString ConfigDir;

	// 场景ID，输出服务器配置可不填
	UPROPERTY(EditAnywhere, Category = "HomeParser")
	int32 SceneID = 0;

	UPROPERTY(EditAnywhere, Category = "HomeParser")
	bool OutputServer = false;

protected:
	void GenExtraGlobalVariables(TMap<FString, bool>& params) override;
	void GenExtraEntryPointParams(TMap<FString, FString>& params) override;
	void StartLua() override;
};