// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "Styling/SlateBrush.h"
#include "ProceduralMeshComponent.h"
#if WITH_EDITOR
#include "PropertyEditorDelegates.h"
#endif
#include "AzureProceduralMeshActor.generated.h"


class UMaterialInstance;
class UMaterialInstanceDynamic;

UCLASS()
class AZURE_API AAzureProceduralMeshActor : public AActor
{
	GENERATED_BODY()


public:	
	// Sets default values for this actor's properties
	AAzureProceduralMeshActor();

	// Called when the game starts or when spawned
	virtual void BeginPlay() override;
	virtual void PostInitProperties() override;
	virtual void PostLoad()override;
	// Called every frame
	virtual void Tick( float DeltaSeconds ) override;

#if WITH_EDITOR
	virtual void PostEditChangeProperty(FPropertyChangedEvent& PropertyChangedEvent) override;
	void RegisterCustomPropertyTypeLayout(FName PropertyTypeName, FOnGetPropertyTypeCustomizationInstance PropertyTypeLayoutDelegate);

#endif

	UFUNCTION()
	bool ReleaseSectionMesh(int32 section_id);
	UFUNCTION()
	void SetMaterial(int32 section_id, UMaterialInterface* Material);
	UFUNCTION()
	UMaterialInterface* GetSectionMaterialInst(int32 section_id);
	UFUNCTION()
	int32 GetSectionVerticesNum(int32 section_id);
	UFUNCTION()
	void SetMeshSectionVisible(int32 SectionIndex, bool bNewVisibility);
	UFUNCTION()
	bool IsMeshSectionVisible(int32 SectionIndex);
	UFUNCTION()
	int32 GetNumSections();
	UFUNCTION()
	int32 GetNumMaterials();
	UFUNCTION()
	void ClearAllMeshSections();
	UFUNCTION()
	void SetCollisionProfileName(FString ProfileName);
	UFUNCTION()
	void SetRelativeLocationAndRotationAndScale(FVector NewLocation, FRotator NewRotation, FVector NewScale3D);
	UFUNCTION()
	void SetRelativeLocationAndRotation(FVector NewLocation, FRotator NewRotation);
public:

	int CreateMeshSection(const TArray<FVector>& Vertices, const TArray<int32>& Triangles, const TArray<FVector>& Normals, const TArray<FVector2D>& UV0, const TArray<FColor>& VertexColors, const TArray<FProcMeshTangent>& Tangents, bool bCreateCollision);
	void UpdateMeshSection(int32 section_id, const TArray<FVector>& Vertices, const TArray<int32>& Triangles, const TArray<FVector>& Normals, const TArray<FVector2D>& UV0, const TArray<FColor>& VertexColors, const TArray<FProcMeshTangent>& Tangents);
protected:
	int CreateSctionID();

public:
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Azure", DisplayName = "ProceduralMeshComponent")
	UProceduralMeshComponent* ProceduralMeshComponent = NULL;

	TArray<int> SectionCache;
};
