// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "Styling/SlateBrush.h"
#include "Components/HierarchicalInstancedStaticMeshComponent.h"



#if WITH_EDITOR
#include "PropertyEditorDelegates.h"
#endif
#include "AzureHIMeshActor.generated.h"


UCLASS()
class AZURE_API AAzureHIMeshActor : public AActor
{
	GENERATED_BODY()


public:	
	// Sets default values for this actor's properties
	AAzureHIMeshActor();

	// Called when the game starts or when spawned
	virtual void BeginPlay() override;
	virtual void PostInitProperties() override;
	virtual void PostLoad()override;
	virtual void Destroyed() override;
	// Called every frame
	virtual void Tick( float DeltaSeconds ) override;

#if WITH_EDITOR
	virtual void PostEditChangeProperty(FPropertyChangedEvent& PropertyChangedEvent) override;
	void RegisterCustomPropertyTypeLayout(FName PropertyTypeName, FOnGetPropertyTypeCustomizationInstance PropertyTypeLayoutDelegate);

#endif
	UFUNCTION()
	int32 AddInstance(const FTransform& InstanceTransform);
	UFUNCTION()
	void ClearInstances();
	UFUNCTION()
	void RemoveInstance(int32 InstanceIndex);
	UFUNCTION()
	void UpdateInstance(int32 InstanceIndex, const FTransform& NewInstanceTransform);
	UFUNCTION()
	UStaticMesh* GetStaticMesh() const;
	UFUNCTION()
	bool SetStaticMesh(class UStaticMesh* NewMesh);
	UFUNCTION()
	void SetCollisionProfileName(FString ProfileName);

	UFUNCTION()
	UHierarchicalInstancedStaticMeshComponent* GetHIMComponent()
	{
		return pHierarchicalInstancedStaticMeshComponent;
	}

public:
	UPROPERTY(Transient)
	UHierarchicalInstancedStaticMeshComponent* pHierarchicalInstancedStaticMeshComponent = NULL;

	FString  MeshPath;
};
