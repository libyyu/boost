// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "Styling/SlateBrush.h"
#if WITH_EDITOR
#include "PropertyEditorDelegates.h"
#endif
#include "AzureHomeUtilActor.generated.h"

class UMaterialInstanceDynamic;
class UMaterialInterface;

UCLASS()
class AZURE_API AAzureHomeUtilActor : public AActor
{
	GENERATED_BODY()
public:	
	// Sets default values for this actor's properties
	AAzureHomeUtilActor();

	// Called when the game starts or when spawned
	virtual void BeginPlay() override;
	virtual void PostInitProperties() override;
	virtual void PostLoad()override;
	virtual void Destroyed() override;
	// Called every frame
	virtual void Tick( float DeltaSeconds ) override;
	
#if WITH_EDITOR
	virtual void PostEditChangeProperty(FPropertyChangedEvent& PropertyChangedEvent) override;
	void RegisterCustomPropertyTypeLayout(FName PropertyTypeName, FOnGetPropertyTypeCustomizationInstance PropertyTypeLayoutDelegate);

#endif

public:
	UFUNCTION()
	void InitMaskCache(int size);
	UFUNCTION()
	void ReleaseMaskCache();
	UFUNCTION()
	void ZeroMask(int size);
	UFUNCTION()
	UMaterialInstanceDynamic* CreateDynamicMaterialInstance(UMaterialInterface* Parent);
	UFUNCTION()
	void CopyTexture2D(UMaterialInstanceDynamic* pWallDynamic, UMaterialInstanceDynamic* pItemDynamic);
	void SetMask(int idx, char v);
	char GetMask(int idx);
	FQuat RotatorToFQuat(float InPitch, float InYaw, float InRoll);
public:
	char* MaskCache = nullptr;
	int MaskCacheSize = 0;
};
