// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"

#include "AzureHomeDoorBase.generated.h"

UCLASS()
class AZURE_API AAzureHomeDoorBase : public AActor
{
	GENERATED_BODY()

public:	
	// Sets default values for this actor's properties
	AAzureHomeDoorBase();

	UFUNCTION(BlueprintCallable, Category = "Azure")
	void OnApproachDoor(bool bApproach);
	
public:
	UPROPERTY(EditAnywhere, Category = "Azure")
	int32 put_index = 0;
};
