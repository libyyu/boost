// Fill out your copyright notice in the Description page of Project Settings.

#include "AzureHIMeshActor.h"
#include "Engine.h"
#include "Math/Color.h"
#include "AzureUtility.h"
#include "../ResourceLoader/AzureResourceLoader.h"
#include "Engine/World.h"

#if WITH_EDITOR
#include "PropertyEditorModule.h"
#endif

// Sets default values
AAzureHIMeshActor::AAzureHIMeshActor()
{
 	// Set this actor to call Tick() every frame.  You can turn this off to improve performance if you don't need it.
	PrimaryActorTick.bCanEverTick = true;

	if (!RootComponent)
	{
		UHierarchicalInstancedStaticMeshComponent* SceneComponent = CreateDefaultSubobject<UHierarchicalInstancedStaticMeshComponent>(TEXT("RootComponent"));
		SetRootComponent(SceneComponent);
		pHierarchicalInstancedStaticMeshComponent = SceneComponent;
		// Disable collision data.
		//pHierarchicalInstancedStaticMeshComponent->ContainsPhysicsTriMeshData(false);
	}

}

// Called when the game starts or when spawned
void AAzureHIMeshActor::BeginPlay()
{
	Super::BeginPlay();
	
	
}

void AAzureHIMeshActor::PostInitProperties()
{
	Super::PostInitProperties();
	
}

void AAzureHIMeshActor::PostLoad()
{
	Super::PostLoad();

}

void AAzureHIMeshActor::Destroyed()
{
	Super::Destroyed();
}

#if WITH_EDITOR
void AAzureHIMeshActor::PostEditChangeProperty(FPropertyChangedEvent& PropertyChangedEvent)
{
	Super::PostEditChangeProperty(PropertyChangedEvent);

	// Look for changed properties
	const FName PropertyName = (PropertyChangedEvent.Property != nullptr) ? PropertyChangedEvent.Property->GetFName() : NAME_None;
	const FName MemberPropertyName = (PropertyChangedEvent.MemberProperty != nullptr) ? PropertyChangedEvent.MemberProperty->GetFName() : NAME_None;

	if(PropertyName == "doTest1")
	{
	}
	
}

void AAzureHIMeshActor::RegisterCustomPropertyTypeLayout(FName PropertyTypeName, FOnGetPropertyTypeCustomizationInstance PropertyTypeLayoutDelegate)
{
	check(PropertyTypeName != NAME_None);


	static FName PropertyEditor("PropertyEditor");
	FPropertyEditorModule& PropertyModule = FModuleManager::GetModuleChecked<FPropertyEditorModule>(PropertyEditor);
	//FPropertyTypeLayoutCallback PropertyTypeLayoutCallback = PropertyModule.FindPropertyTypeLayoutCallback(PropertyTypeName,)
	PropertyModule.RegisterCustomPropertyTypeLayout(PropertyTypeName, PropertyTypeLayoutDelegate);
}

#endif

// Called every frame
void AAzureHIMeshActor::Tick( float DeltaTime )
{
	Super::Tick( DeltaTime );
		
}

int32 AAzureHIMeshActor::AddInstance(const FTransform& InstanceTransform)
{
	if (pHierarchicalInstancedStaticMeshComponent)
		return pHierarchicalInstancedStaticMeshComponent->AddInstance(InstanceTransform);
	return -1;
}

void AAzureHIMeshActor::ClearInstances()
{
	if (pHierarchicalInstancedStaticMeshComponent)
		pHierarchicalInstancedStaticMeshComponent->ClearInstances();
}

void AAzureHIMeshActor::RemoveInstance(int32 InstanceIndex)
{
	if (pHierarchicalInstancedStaticMeshComponent)
		pHierarchicalInstancedStaticMeshComponent->RemoveInstance(InstanceIndex);
}

void AAzureHIMeshActor::UpdateInstance(int32 InstanceIndex, const FTransform& NewInstanceTransform)
{
	if (pHierarchicalInstancedStaticMeshComponent)
		pHierarchicalInstancedStaticMeshComponent->UpdateInstanceTransform(InstanceIndex, NewInstanceTransform, -1.0f, true, true, true);
}

bool AAzureHIMeshActor::SetStaticMesh(UStaticMesh* NewMesh)
{
	if (pHierarchicalInstancedStaticMeshComponent)
		return pHierarchicalInstancedStaticMeshComponent->SetStaticMesh(NewMesh);
	return false;
}

UStaticMesh* AAzureHIMeshActor::GetStaticMesh() const
{
	if (pHierarchicalInstancedStaticMeshComponent)
		return pHierarchicalInstancedStaticMeshComponent->GetStaticMesh();
	return nullptr;
}

void AAzureHIMeshActor::SetCollisionProfileName(FString ProfileName)
{
	pHierarchicalInstancedStaticMeshComponent->SetCollisionProfileName(*ProfileName);
}

