// Copyright 1998-2018 Epic Games, Inc. All Rights Reserved.

/*==============================================================================
	VectorField.cpp: Implementation of vector fields.
==============================================================================*/

#include "AzureDrawLineComponent.h"
#include "RenderingThread.h"
#include "UniformBuffer.h"
#include "ShaderParameters.h"
#include "RHIStaticStates.h"
#include "PrimitiveSceneProxy.h"
#include "PrimitiveSceneProxy.h"
#include "Materials/Material.h"
#include "Engine/Engine.h"
#include "SceneManagement.h"
#include "DynamicMeshBuilder.h"

#include "Materials/MaterialInstanceDynamic.h"

/*------------------------------------------------------------------------------
	Scene proxy for visualizing vector fields.
------------------------------------------------------------------------------*/

class FDrawLineSceneProxy final : public FPrimitiveSceneProxy
{
public:
	SIZE_T GetTypeHash() const override
	{
		static size_t UniquePointer;
		return reinterpret_cast<size_t>(&UniquePointer);
	}

	/** Initialization constructor. */
	explicit FDrawLineSceneProxy( UAzureDrawLineComponent* AzureDrawLineComponent )
		: FPrimitiveSceneProxy(AzureDrawLineComponent)
	{
		bWillEverBeLit = false;
		pSelfComponent = AzureDrawLineComponent;
	}

	/** Destructor. */
	~FDrawLineSceneProxy()
	{
	}

	/**
	 *	Called when the rendering thread adds the proxy to the scene.
	 *	This function allows for generating renderer-side resources.
	 *	Called in the rendering thread.
	 */
	virtual void CreateRenderThreadResources() override
	{
	}

	/**
	 * Computes view relevance for this scene proxy.
	 */
	virtual FPrimitiveViewRelevance GetViewRelevance(const FSceneView* View) const override
	{
		FPrimitiveViewRelevance Result;
		Result.bDrawRelevance = IsShown(View); 
		Result.bDynamicRelevance = true;
		Result.bOpaqueRelevance = true;
		return Result;
	}

	/**
	 * Computes the memory footprint of this scene proxy.
	 */
	virtual uint32 GetMemoryFootprint() const override
	{
		return sizeof(*this) + GetAllocatedSize();
	}

	virtual void DrawStaticElements(FStaticPrimitiveDrawInterface* PDI) override
	{

	}

	virtual void GetDynamicMeshElements(const TArray<const FSceneView*>& Views, const FSceneViewFamily& ViewFamily, uint32 VisibilityMap, FMeshElementCollector& Collector) const override
	{
		FScopeLock ScopeLock(&pSelfComponent->CriticalSection);
		for (int32 ViewIndex = 0; ViewIndex < Views.Num(); ViewIndex++)
		{
			if (VisibilityMap & (1 << ViewIndex))
			{
				DrawLines(Views, ViewFamily, VisibilityMap, Collector, ViewIndex);
			}
		}
	}

	void DrawLines(const TArray<const FSceneView*>& Views, const FSceneViewFamily& ViewFamily, uint32 VisibilityMap, FMeshElementCollector& Collector, int ViewIndex) const
	{
		FPrimitiveDrawInterface* PDI = Collector.GetPDI(ViewIndex);
		for (int i = 0; i < pSelfComponent->Lines.Num(); i++)
		{
			FAZURE_DRAWLINE& line = pSelfComponent->Lines[i];
			PDI->DrawLine(line.Start, line.End, line.Color, line.DepthPriorityGroup, line.Thickness);
		}
	}
public:
	UAzureDrawLineComponent* pSelfComponent;
};

/*------------------------------------------------------------------------------
	UAzureDrawLineComponent implementation.
------------------------------------------------------------------------------*/
UAzureDrawLineComponent::UAzureDrawLineComponent(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
	UsedMaterial = nullptr;
}

FPrimitiveSceneProxy* UAzureDrawLineComponent::CreateSceneProxy()
{
	FDrawLineSceneProxy* Proxy = NULL;
	Proxy = new FDrawLineSceneProxy(this);
	return Proxy;
}

FBoxSphereBounds UAzureDrawLineComponent::CalcBounds(const FTransform& LocalToWorld) const
{
	FBoxSphereBounds NewBounds;
	NewBounds.Origin = FVector::ZeroVector;;
	NewBounds.BoxExtent = FVector(1000000);
	NewBounds.SphereRadius = 1000000;


	return NewBounds.TransformBy( LocalToWorld );
}

void UAzureDrawLineComponent::GetUsedMaterials(TArray<UMaterialInterface*>& OutMaterials, bool bGetDebugMaterials) const
{
	OutMaterials.Add(UsedMaterial);
}

void UAzureDrawLineComponent::OnRegister()
{
	Super::OnRegister();

}


void UAzureDrawLineComponent::OnUnregister()
{
	
	Super::OnUnregister();
}


void UAzureDrawLineComponent::SendRenderTransform_Concurrent()
{
	Super::SendRenderTransform_Concurrent();
}


void UAzureDrawLineComponent::PostInterpChange(UProperty* PropertyThatChanged)
{
	Super::PostInterpChange(PropertyThatChanged);
}

#if WITH_EDITOR
void UAzureDrawLineComponent::PostEditChangeProperty(FPropertyChangedEvent& PropertyChangedEvent)
{
	Super::PostEditChangeProperty(PropertyChangedEvent);
}

#endif // WITH_EDITOR

void UAzureDrawLineComponent::AddLine(const FVector& Start, const FVector& End, const FLinearColor& Color, uint8 DepthPriorityGroup, float Thickness)
{
	FScopeLock ScopeLock(&CriticalSection);
	Lines.Add(FAZURE_DRAWLINE(Start, End, Color, DepthPriorityGroup, Thickness));
}
void UAzureDrawLineComponent::RemoveAllLines()
{
	FScopeLock ScopeLock(&CriticalSection);
	Lines.Empty();
}
