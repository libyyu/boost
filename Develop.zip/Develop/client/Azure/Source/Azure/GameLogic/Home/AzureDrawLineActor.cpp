// Fill out your copyright notice in the Description page of Project Settings.

#include "AzureDrawLineActor.h"
#include "Engine.h"
#include "Math/Color.h"
#include "AzureUtility.h"
#include "Engine/World.h"

#if WITH_EDITOR
#include "PropertyEditorModule.h"
#endif

// Sets default values
AAzureDrawLineActor::AAzureDrawLineActor()
{
 	// Set this actor to call Tick() every frame.  You can turn this off to improve performance if you don't need it.
	PrimaryActorTick.bCanEverTick = true;

	if (!RootComponent)
	{
		UAzureDrawLineComponent* SceneComponent = CreateDefaultSubobject<UAzureDrawLineComponent>(TEXT("RootComponent"));
		SetRootComponent(SceneComponent);
		pAzureDrawLineComponent = SceneComponent;
	}

}

// Called when the game starts or when spawned
void AAzureDrawLineActor::BeginPlay()
{
	Super::BeginPlay();
	
	
}

void AAzureDrawLineActor::PostInitProperties()
{
	Super::PostInitProperties();
	
}

void AAzureDrawLineActor::PostLoad()
{
	Super::PostLoad();

}

void AAzureDrawLineActor::Destroyed()
{
	Super::Destroyed();
}

#if WITH_EDITOR
void AAzureDrawLineActor::PostEditChangeProperty(FPropertyChangedEvent& PropertyChangedEvent)
{
	Super::PostEditChangeProperty(PropertyChangedEvent);

	// Look for changed properties
	const FName PropertyName = (PropertyChangedEvent.Property != nullptr) ? PropertyChangedEvent.Property->GetFName() : NAME_None;
	const FName MemberPropertyName = (PropertyChangedEvent.MemberProperty != nullptr) ? PropertyChangedEvent.MemberProperty->GetFName() : NAME_None;

	if(PropertyName == "doTest1")
	{
	}
	
}

void AAzureDrawLineActor::RegisterCustomPropertyTypeLayout(FName PropertyTypeName, FOnGetPropertyTypeCustomizationInstance PropertyTypeLayoutDelegate)
{
	check(PropertyTypeName != NAME_None);


	static FName PropertyEditor("PropertyEditor");
	FPropertyEditorModule& PropertyModule = FModuleManager::GetModuleChecked<FPropertyEditorModule>(PropertyEditor);
	//FPropertyTypeLayoutCallback PropertyTypeLayoutCallback = PropertyModule.FindPropertyTypeLayoutCallback(PropertyTypeName,)
	PropertyModule.RegisterCustomPropertyTypeLayout(PropertyTypeName, PropertyTypeLayoutDelegate);
}

#endif

// Called every frame
void AAzureDrawLineActor::Tick( float DeltaTime )
{
	Super::Tick( DeltaTime );
		
}

void AAzureDrawLineActor::AddLine(const FVector& Start, const FVector& End, const FLinearColor& Color, int DepthPriorityGroup, float Thickness)
{
	pAzureDrawLineComponent->AddLine(Start,End,Color, (uint8)DepthPriorityGroup,Thickness);
}

void AAzureDrawLineActor::RemoveAllLines()
{
	pAzureDrawLineComponent->RemoveAllLines();
}
