// Copyright 1998-2018 Epic Games, Inc. All Rights Reserved.



#pragma once

#include "CoreMinimal.h"
#include "UObject/ObjectMacros.h"
#include "Components/PrimitiveComponent.h"
#include "AzureDrawLineComponent.generated.h"


class FPrimitiveSceneProxy;
class UWorld;

USTRUCT(BlueprintType)
struct FAZURE_DRAWLINE 
{
	GENERATED_USTRUCT_BODY()
	FAZURE_DRAWLINE()
	{
	}
	FAZURE_DRAWLINE(const FVector& s, const FVector& e, const FLinearColor& c, uint8 d, float t)
	{
		Start = s;
		End = e;
		Color = c;
		DepthPriorityGroup = d,
		Thickness = t;
	}
	FVector Start = FVector::ZeroVector;
	FVector End = FVector::ZeroVector;
	FLinearColor Color = FLinearColor::White;
	uint8 DepthPriorityGroup = 0;
	float Thickness = 0.0f;
};
/** 
 * A Component referencing a vector field.
 */
UCLASS()
class UAzureDrawLineComponent : public UPrimitiveComponent
{
	GENERATED_UCLASS_BODY()

public:


	//~ Begin UPrimitiveComponent Interface.
	virtual FPrimitiveSceneProxy* CreateSceneProxy() override;
	virtual FBoxSphereBounds CalcBounds(const FTransform& LocalToWorld) const override;
	virtual void GetUsedMaterials(TArray<UMaterialInterface*>& OutMaterials, bool bGetDebugMaterials) const override;
	//~ End UPrimitiveComponent Interface.

	//~ Begin UActorComponent Interface.
	virtual void OnRegister() override;
	virtual void OnUnregister() override;
	virtual void SendRenderTransform_Concurrent() override;
	//~ End UActorComponent Interface.

	//~ Begin UObject Interface.
	virtual void PostInterpChange(UProperty* PropertyThatChanged) override;
#if WITH_EDITOR
	virtual void PostEditChangeProperty(FPropertyChangedEvent& PropertyChangedEvent) override;
#endif // WITH_EDITOR
	
	void AddLine(const FVector& Start, const FVector& End, const FLinearColor& Color, uint8 DepthPriorityGroup, float Thickness);
	void RemoveAllLines();

	mutable FCriticalSection CriticalSection;
	// texture based
	UPROPERTY()
	UMaterialInstanceDynamic* UsedMaterial;
	UPROPERTY()
	TArray<FAZURE_DRAWLINE> Lines;
};



