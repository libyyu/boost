// Fill out your copyright notice in the Description page of Project Settings.

#include "AzureHomeDoorBase.h"

#include "AzureEntryPoint.h"
#include "wLua/LuaInterface.h"

// Sets default values
AAzureHomeDoorBase::AAzureHomeDoorBase()
{
}

void AAzureHomeDoorBase::OnApproachDoor(bool bApproach)
{
	if (!AAzureEntryPoint::Instance->IsInit())
		return;
	if (IsPendingKill())
		return;

	wLua::Lua* wlua = AAzureEntryPoint::Instance->GetWLua();
	lua_State_Wrapper L = AAzureEntryPoint::Instance->GetL();
	lua_getglobal(L, "OnApproachDoor");
	if (lua_isfunction(L, -1))
	{
		lua_pushinteger(L, put_index);
		lua_pushboolean(L, bApproach ? 1 : 0);
		wlua->Call(2);
	}
	else
	{
		lua_pop(L, 1);
	}
}