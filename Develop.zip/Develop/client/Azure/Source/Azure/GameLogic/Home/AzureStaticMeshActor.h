// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "Styling/SlateBrush.h"
#include "Components/StaticMeshComponent.h"


#if WITH_EDITOR
#include "PropertyEditorDelegates.h"
#endif
#include "AzureStaticMeshActor.generated.h"



UCLASS()
class AZURE_API AAzureStaticMeshActor : public AActor
{
	GENERATED_BODY()


public:	
	// Sets default values for this actor's properties
	AAzureStaticMeshActor();

	// Called when the game starts or when spawned
	virtual void BeginPlay() override;
	virtual void PostInitProperties() override;
	virtual void PostLoad()override;
	virtual void Destroyed() override;
	// Called every frame
	virtual void Tick( float DeltaSeconds ) override;

#if WITH_EDITOR
	virtual void PostEditChangeProperty(FPropertyChangedEvent& PropertyChangedEvent) override;
	void RegisterCustomPropertyTypeLayout(FName PropertyTypeName, FOnGetPropertyTypeCustomizationInstance PropertyTypeLayoutDelegate);

#endif
	UFUNCTION()
	bool SetStaticMesh(class UStaticMesh* NewMesh);
	UFUNCTION()
	class UStaticMesh* GetStaticMesh() const;
	UFUNCTION()
	UStaticMeshComponent* GetStaticMeshComponent();
	UFUNCTION()
	void SetCollisionProfileName(FString ProfileName);
	UFUNCTION()
	void SetRelativeLocationAndRotationAndScale(FVector NewLocation, FRotator NewRotation, FVector NewScale3D);
	UFUNCTION()
	int GetMaterialIndex(FName  MaterialSlot);
	UFUNCTION()
	UMaterialInterface* GetMaterial(int idx, UMaterialInterface* MaterialWall);
	UFUNCTION()
	void SetMaterial(int idx, UMaterialInterface* Mat);
public:
	UPROPERTY(Transient)
	UStaticMeshComponent* pStaticMeshComponent = NULL;
};
