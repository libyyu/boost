// Fill out your copyright notice in the Description page of Project Settings.

#include "AzureHomeUtil.h"
#include "Engine.h"
#include "Math/Color.h"
#include "Materials/MaterialInstanceDynamic.h"
#include "AzureUtility.h"
#include "../ResourceLoader/AzureResourceLoader.h"
#include "Engine/World.h"

FName AzureHomeUtil::VG_BaseColor = TEXT("VG_BaseColor");
FName AzureHomeUtil::VG_Normal = TEXT("VG_Normal");
FName AzureHomeUtil::VG_UVOffsetX = TEXT("VG_UVOffsetX");
FName AzureHomeUtil::VG_UVOffsetY = TEXT("VG_UVOffsetY");
FName AzureHomeUtil::VG_UScale = TEXT("VG_UScale");
FName AzureHomeUtil::VG_VScale = TEXT("VG_VScale");

FName AzureHomeUtil::VB_BaseColor = TEXT("VB_BaseColor");
FName AzureHomeUtil::VB_Normal = TEXT("VB_Normal");
FName AzureHomeUtil::VB_UVOffsetX = TEXT("VB_UVOffsetX");
FName AzureHomeUtil::VB_UVOffsetY = TEXT("VB_UVOffsetY");
FName AzureHomeUtil::VB_UScale = TEXT("VB_UScale");
FName AzureHomeUtil::VB_VScale = TEXT("VB_VScale");

FName AzureHomeUtil::TintColor = TEXT("TintColor");

void AzureHomeUtil::BuildQuad(TArray<FVector>& Vertices, TArray<int32>& Triangles, TArray<FVector>& Normals, TArray<FVector2D>& UV0, TArray<FColor>& VertexColors, TArray<FProcMeshTangent>& Tangents,
	FVector BottomRight, FVector BottomLeft, FVector TopLeft, FVector TopRight, FVector Normal, FProcMeshTangent Tangent, FColor c, float u_unit, float v_unit,bool bHorizontal,float rot_uv)
{
	int start_idx = Vertices.Num();
	static const int idx[] = { 0,1,2,2,3,0 };
	for (int i = 0; i < 6; ++i)
		Triangles.Add(start_idx + idx[i]);

	Vertices.Add(BottomLeft);
	Vertices.Add(BottomRight);
	Vertices.Add(TopRight);
	Vertices.Add(TopLeft);

	Tangents.Add(Tangent);
	Tangents.Add(Tangent);
	Tangents.Add(Tangent);
	Tangents.Add(Tangent);

	Normals.Add(Normal);
	Normals.Add(Normal);
	Normals.Add(Normal);
	Normals.Add(Normal); 

	if (bHorizontal)
	{	//ˮƽ��UV���㷽��
		u_unit = v_unit;//��Ϊбǽ�� u_unit�Դ� Ϊ�˺�����ˮƽ����һ�¹����⴦��
		float v_scale = 1 / v_unit;
		float u_scale = 1 / u_unit;
		//float rot_uv = 45;
		UV0.Add(FVector2D(BottomLeft.X * u_scale, BottomLeft.Y * v_scale).GetRotated(rot_uv));
		UV0.Add(FVector2D(BottomRight.X * u_scale, BottomRight.Y * v_scale).GetRotated(rot_uv));
		UV0.Add(FVector2D(TopRight.X * u_scale, TopRight.Y * v_scale).GetRotated(rot_uv));
		UV0.Add(FVector2D(TopLeft.X * u_scale, TopLeft.Y * v_scale).GetRotated(rot_uv));
	}
	else
	{   //��ֱ��UV���㷽��
		/*float u = (BottomRight - BottomLeft).Size() * 1 / u_unit;
		float v_scale = 1 / v_unit;
		UV0.Add(FVector2D(0.0f, BottomLeft.Z*v_scale));
		UV0.Add(FVector2D(u, BottomRight.Z*v_scale));
		UV0.Add(FVector2D(u, TopRight.Z*v_scale));
		UV0.Add(FVector2D(0.0f, TopLeft.Z*v_scale));*/
		float u_scale = 1 / u_unit;
		float v_scale = -1 / v_unit;
		float v_offset = 1;
		if (fabsf((BottomRight - BottomLeft).X)<=0.001f)
		{
			if (BottomLeft.Y > BottomRight.Y)
				u_scale = -u_scale;
			UV0.Add(FVector2D(BottomLeft.Y * u_scale, BottomLeft.Z*v_scale + v_offset).GetRotated(rot_uv));
			UV0.Add(FVector2D(BottomRight.Y * u_scale, BottomRight.Z*v_scale + v_offset).GetRotated(rot_uv));
			UV0.Add(FVector2D(TopRight.Y * u_scale, TopRight.Z*v_scale + v_offset).GetRotated(rot_uv));
			UV0.Add(FVector2D(TopLeft.Y * u_scale, TopLeft.Z*v_scale + v_offset).GetRotated(rot_uv));
		}
		else
		{
			if (BottomLeft.X > BottomRight.X)
				u_scale = -u_scale;
			UV0.Add(FVector2D(BottomLeft.X * u_scale, BottomLeft.Z*v_scale + v_offset).GetRotated(rot_uv));
			UV0.Add(FVector2D(BottomRight.X * u_scale, BottomRight.Z*v_scale + v_offset).GetRotated(rot_uv));
			UV0.Add(FVector2D(TopRight.X * u_scale, TopRight.Z*v_scale + v_offset).GetRotated(rot_uv));
			UV0.Add(FVector2D(TopLeft.X * u_scale, TopLeft.Z*v_scale + v_offset).GetRotated(rot_uv));
		}
		
	}
	

	VertexColors.Add(c);
	VertexColors.Add(c);
	VertexColors.Add(c);
	VertexColors.Add(c);
}

void AzureHomeUtil::BuildTriangle(TArray<FVector>& Vertices, TArray<int32>& Triangles, TArray<FVector>& Normals, TArray<FVector2D>& UV0, TArray<FColor>& VertexColors, TArray<FProcMeshTangent>& Tangents,
	FVector P0, FVector P1, FVector P2, FVector Normal, FProcMeshTangent Tangent, FColor c, float uv_unit, float rot_uv)
{
	int start_idx = Vertices.Num();
	static const int idx[] = { 0,1,2};
	for (int i = 0; i < 3; ++i)
		Triangles.Add(start_idx + idx[i]);

	Vertices.Add(P2); 
	Vertices.Add(P1);
	Vertices.Add(P0);

	Tangents.Add(Tangent);
	Tangents.Add(Tangent);
	Tangents.Add(Tangent);

	Normals.Add(Normal);
	Normals.Add(Normal);
	Normals.Add(Normal);
	UV0.Add(FVector2D(P2.X / uv_unit, P2.Y / uv_unit).GetRotated(rot_uv));
	UV0.Add(FVector2D(P1.X / uv_unit, P1.Y / uv_unit).GetRotated(rot_uv));
	UV0.Add(FVector2D(P0.X / uv_unit, P0.Y / uv_unit).GetRotated(rot_uv));

	VertexColors.Add(c);
	VertexColors.Add(c);
	VertexColors.Add(c);
}

void AzureHomeUtil::GenerateTriangle(TArray<FVector>& Vertices, TArray<int32>& Triangles, TArray<FVector>& Normals, TArray<FVector2D>& UV0, TArray<FColor>& VertexColors, TArray<FProcMeshTangent>& Tangents,
	FVector vBevelStart, FVector vBevelEnd, bool OnRight, float Height, float GridSize)
{

	FVector vDir = vBevelEnd - vBevelStart;
	FVector2D vDir2D(vDir.X, vDir.Y);
	vDir2D.Normalize();

	if (fabs(vDir.X) < 1 || fabs(vDir.Y) < 1)
		return;
	
	//		  5______________________ 3             
	//		   |	              �J|                               ^ Z
	//		 4 |______________ �J___|			   					|			
	//		   |            �J    �J  0 end							|
	//		   |         �J	   �J									|	
	//         |	  �J		�J										----------------->X
	//		   |   �J	 �J			OnRight = false				   /
	//		2  |�J    �J											  /
	//         |   �J											Y
	//		   |�J 1
	//        start 


	// Define the 6 corners of the triangle
	FVector p0 = vBevelEnd;
	FVector p1 = vBevelStart;
	FVector p2 = vBevelStart + FVector(0, 0, Height);
	FVector p3 = vBevelEnd + FVector(0, 0, Height);
	// Only for 45��
	FVector2D vCenter2D(vDir.X*0.5f, vDir.Y*0.5f);
	FVector2D vRot2D = OnRight ? vCenter2D.GetRotated(90) : vCenter2D.GetRotated(-90);
	FVector p4 = FVector(vBevelStart.X+ vCenter2D.X + vRot2D.X, vBevelStart.Y + vCenter2D.Y + vRot2D.Y, vBevelStart.Z);
	FVector p5 = p4 + FVector(0, 0, Height);

	// Now we create 3x faces, 4 vertices each
	FVector Normal;
	FProcMeshTangent Tangent;

	FVector2D Normal2D = OnRight ? vDir2D.GetRotated(-90): vDir2D.GetRotated(90);
	FVector2D Tangent2D = Normal2D.GetRotated(90);

	// (˳ʱ��Ϊǰ��)
	// face: 0-1-2-3
	Normal = FVector(Normal2D.X, Normal2D.Y, 0);
	Tangent = FProcMeshTangent(Tangent2D.X, Tangent2D.Y, 0);
	if (OnRight)
		BuildQuad(Vertices, Triangles, Normals, UV0, VertexColors, Tangents, p3, p2, p1, p0, Normal, Tangent, FColor(0, 0, 0), GridSize*FVector2D(1, 1).Size(), GridSize, false);
	else
		BuildQuad(Vertices, Triangles, Normals, UV0, VertexColors, Tangents, p0, p1, p2, p3, Normal, Tangent, FColor(0, 0, 0), GridSize*FVector2D(1,1).Size(), GridSize, false);

	// face: 1-4-5-2
	Normal2D = OnRight?vDir2D:-vDir2D;
	Normal2D.Y = 0;
	Normal2D.Normalize();
	Normal = FVector(Normal2D.X, Normal2D.Y, 0);
	Tangent2D = Normal2D.GetRotated(90);
	Tangent = FProcMeshTangent(Tangent2D.X, Tangent2D.Y, 0);
	if (OnRight)
		BuildQuad(Vertices, Triangles, Normals, UV0, VertexColors, Tangents, p2, p5, p4, p1, Normal, Tangent, FColor(0, 0, 0), GridSize, GridSize, false);
	else
		BuildQuad(Vertices, Triangles, Normals, UV0, VertexColors, Tangents, p1, p4, p5, p2, Normal, Tangent, FColor(0, 0, 0), GridSize, GridSize, false);

	// face: 0-3-5-4
	Normal2D = OnRight ? -vDir2D : vDir2D;
	Normal2D.X = 0;
	Normal2D.Normalize();
	Normal = FVector(Normal2D.X, Normal2D.Y, 0);
	Tangent2D = Normal2D.GetRotated(90);
	Tangent = FProcMeshTangent(Tangent2D.X, Tangent2D.Y, 0);
	if (OnRight)
		BuildQuad(Vertices, Triangles, Normals, UV0, VertexColors, Tangents, p0, p4, p5, p3, Normal, Tangent, FColor(0, 0, 0), GridSize, GridSize, false);
	else
		BuildQuad(Vertices, Triangles, Normals, UV0, VertexColors, Tangents, p0, p3, p5, p4, Normal, Tangent, FColor(0, 0, 0), GridSize, GridSize, false);


	// Top (+Z) face: 2-5-3
	Normal = FVector(0, 0, 1);
	Tangent = FProcMeshTangent(0, 1, 0);

	if (OnRight)
		BuildTriangle(Vertices, Triangles, Normals, UV0, VertexColors, Tangents, p3, p5, p2, Normal, Tangent, FColor(0, 255, 0), GridSize);
	else
		BuildTriangle(Vertices, Triangles, Normals, UV0, VertexColors, Tangents, p2, p5, p3, Normal, Tangent, FColor(0, 255, 0), GridSize);


	// Bottom (-Z) face: 0-4-1
	Normal = FVector(0, 0, -1);
	Tangent = FProcMeshTangent(0, -1, 0);
	if (OnRight)
		BuildTriangle(Vertices, Triangles, Normals, UV0, VertexColors, Tangents, p1, p4, p0, Normal, Tangent, FColor(0, 0, 255), GridSize);
	else
		BuildTriangle(Vertices, Triangles, Normals, UV0, VertexColors, Tangents, p0, p4, p1, Normal, Tangent, FColor(0, 0, 255), GridSize);
}



void AzureHomeUtil::GenerateStairs(TArray<FVector>& Vertices, TArray<int32>& Triangles, TArray<FVector>& Normals, TArray<FVector2D>& UV0, TArray<FColor>& VertexColors, TArray<FProcMeshTangent>& Tangents,
	float step_w, float step_l, float step_h, int num_steps, float zStart, float u_unit, float v_unit)
{
	FVector Normal;
	FProcMeshTangent Tangent;
	//       Start---------------------->End
	//
	//			 6______________________7                   ^   Z
	//			 /                     /|                   |
	//			/				   3  / |					|	
	//		 2 /_____________________/  |					|
	//		   |					 |  |4                  ----------------->X
	//         |	5				 |  /                  /
	//		   |					 | /                  / 
	//		   |_____________________|/                   Y
	//         1					  0

	// Bottom poly. (-Z) face: 1-0-4-5
	FVector p0 , p1, p2, p3, p4, p5, p6, p7;
	p1 = FVector(0, step_w*0.5f, 0);
	p0 = FVector(step_l*num_steps, step_w*0.5f, 0);
	p4 = FVector(step_l*num_steps, -step_w*0.5f, 0);
	p5 = FVector(0, -step_w*0.5f, 0);
	Normal = FVector(0, 0, -1);
	Tangent = FProcMeshTangent(0, -1, 0);
	BuildQuad(Vertices, Triangles, Normals, UV0, VertexColors, Tangents, p1, p0, p4, p5, Normal, Tangent, FColor(0, 0, 255), u_unit, v_unit, true);

	// Back poly.(+X) face: 4-0-3-7
	p4 = FVector(step_l*num_steps, -step_w*0.5f, 0);
	p0 = FVector(step_l*num_steps, step_w * 0.5f, 0);
	p3 = FVector(step_l*num_steps, step_w * 0.5f, step_h*num_steps);
	p7 = FVector(step_l*num_steps, -step_w*0.5f, step_h*num_steps);
	Normal = FVector(1, 0, 0);
	Tangent = FProcMeshTangent(0, 1, 0);
	BuildQuad(Vertices, Triangles, Normals, UV0, VertexColors, Tangents, p4, p0, p3, p7,  Normal, Tangent, FColor(64, 0, 0), u_unit, v_unit, false);

	
	for (int32 i = 0; i < num_steps; i++)
	{
		// Top of the step (+Z) face: 6-7-3-2
		p6 = FVector(step_l*i,				-step_w*0.5f,	step_h + i * step_h);
		p7 = FVector(step_l * i + step_l,	-step_w*0.5f,	step_h + i * step_h);
		p3 = FVector(step_l * i + step_l,	step_w * 0.5f,	step_h + i * step_h);
		p2 = FVector(step_l*i,				step_w * 0.5f,	step_h + i * step_h);
		Normal = FVector(0, 0, 1);
		Tangent = FProcMeshTangent(0, 1, 0);
		BuildQuad(Vertices, Triangles, Normals, UV0, VertexColors, Tangents, p6, p7, p3, p2, Normal, Tangent, FColor(0, 255, 0), u_unit, v_unit, true);

		// Fronts of steps.1-5-6-2
		p1 = FVector(step_l*i,	step_w*0.5f,		i * step_h);
		p5 = FVector(step_l*i,	-step_w * 0.5f,		i * step_h);
		p6 = FVector(step_l*i,	-step_w * 0.5f,		i * step_h+ step_h);
		p2 = FVector(step_l*i,	step_w*0.5f,		i * step_h+ step_h);
		Normal = FVector(-1, 0, 0);
		Tangent = FProcMeshTangent(0, -1, 0);
		BuildQuad(Vertices, Triangles, Normals, UV0, VertexColors, Tangents, p1, p5, p6, p2, Normal, Tangent, FColor(64, 0, 0), u_unit, v_unit, false);

		// Sides of the step
		// (+Y) face: 0-1-2-3
		p0 = FVector(step_l*num_steps,	step_w * 0.5f, i * step_h);
		p1 = FVector(step_l*i,			step_w * 0.5f, i * step_h);
		p2 = FVector(step_l*i,			step_w * 0.5f, i * step_h + step_h);
		p3 = FVector(step_l*num_steps,	step_w * 0.5f, i * step_h + step_h);
		Normal = FVector(0, 1, 0);
		Tangent = FProcMeshTangent(-1, 0, 0);
		BuildQuad(Vertices, Triangles, Normals, UV0, VertexColors, Tangents, p0, p1, p2, p3, Normal, Tangent, FColor(0, 255, 0), u_unit, v_unit, false);

		// (-Y) face: 5-4-7-6
		p5 = FVector(step_l*i ,			-step_w * 0.5f, i * step_h);
		p4 = FVector(step_l*num_steps,	-step_w * 0.5f, i * step_h);
		p7 = FVector(step_l*num_steps,	-step_w * 0.5f, i * step_h + step_h);
		p6 = FVector(step_l*i,			-step_w * 0.5f, i * step_h + step_h);
		Normal = FVector(0, -1, 0);
		Tangent = FProcMeshTangent(1, 0, 0);
		BuildQuad(Vertices, Triangles, Normals, UV0, VertexColors, Tangents, p5, p4, p7, p6, Normal, Tangent, FColor(0, 0, 255), u_unit, v_unit, false);
	}

}

bool AzureHomeUtil::GetPointIntersection(const FVector2D& ps1, const FVector2D& pe1, const FVector2D& ps2, const FVector2D& pe2, FVector2D& outPoint)
{
	// Get A,B,C of first line - points : ps1 to pe1
	float A1 = pe1.Y - ps1.Y;
	float B1 = ps1.X - pe1.X;
	float C1 = A1 * ps1.X + B1 * ps1.Y;

	// Get A,B,C of second line - points : ps2 to pe2
	float A2 = pe2.Y - ps2.Y;
	float B2 = ps2.X - pe2.X;
	float C2 = A2 * ps2.X + B2 * ps2.Y;

	// Get delta and check if the lines are parallel
	float delta = A1 * B2 - A2 * B1;
	if (fabsf(delta)<0.001f)
	{
		return false;
	}
	else
	{
		outPoint = FVector2D((B2*C1 - B1 * C2) / delta, (A1*C2 - A2 * C1) / delta);
		return true;
	}
}


void AzureHomeUtil::SetRightWallMaterialParameter(UMaterialInstanceDynamic* pWallDynamic,
	float UOffset, float VOffset, float UScale, float VScale)
{
	if (!pWallDynamic) return;
	UScale = 1 / UScale;
	VScale = 1 / VScale;
	pWallDynamic->SetScalarParameterValue(AzureHomeUtil::VG_UVOffsetX, UOffset);
	pWallDynamic->SetScalarParameterValue(AzureHomeUtil::VG_UVOffsetY, VOffset);
	pWallDynamic->SetScalarParameterValue(AzureHomeUtil::VG_UScale, UScale);
	pWallDynamic->SetScalarParameterValue(AzureHomeUtil::VG_VScale, VScale);
}

void AzureHomeUtil::SetLeftWallMaterialParameter(UMaterialInstanceDynamic* pWallDynamic,
	float UOffset, float VOffset, float UScale, float VScale)
{
	if (!pWallDynamic) return;
	UScale = 1 / UScale;
	VScale = 1 / VScale;
	pWallDynamic->SetScalarParameterValue(AzureHomeUtil::VB_UVOffsetX, UOffset);
	pWallDynamic->SetScalarParameterValue(AzureHomeUtil::VB_UVOffsetY, VOffset);
	pWallDynamic->SetScalarParameterValue(AzureHomeUtil::VB_UScale, UScale);
	pWallDynamic->SetScalarParameterValue(AzureHomeUtil::VB_VScale, VScale);
}

void AzureHomeUtil::SetWallMaterialColor(UMaterialInstanceDynamic* pWallDynamic, const FLinearColor& c)
{
	if (!pWallDynamic) return;
	pWallDynamic->SetVectorParameterValue(AzureHomeUtil::TintColor, c);
}

void AzureHomeUtil::CopyTexture2D(UMaterialInstanceDynamic* pWallDynamic, UMaterialInstanceDynamic* pItemDynamic)
{
	if (!pWallDynamic || !pItemDynamic) return;
	FName ParameterName = AzureHomeUtil::VG_BaseColor;
	UTexture* pTexture = nullptr;
	pTexture = pWallDynamic->K2_GetTextureParameterValue(ParameterName);
	if (pTexture)
		pItemDynamic->SetTextureParameterValue(ParameterName, pTexture);

	ParameterName = AzureHomeUtil::VG_Normal;
	pTexture = pWallDynamic->K2_GetTextureParameterValue(ParameterName);
	if (pTexture)
		pItemDynamic->SetTextureParameterValue(ParameterName, pTexture);

	ParameterName = AzureHomeUtil::VB_BaseColor;
	pTexture = pWallDynamic->K2_GetTextureParameterValue(ParameterName);
	if (pTexture)
		pItemDynamic->SetTextureParameterValue(ParameterName, pTexture);

	ParameterName = AzureHomeUtil::VB_Normal;
	pTexture = pWallDynamic->K2_GetTextureParameterValue(ParameterName);
	if (pTexture)
		pItemDynamic->SetTextureParameterValue(ParameterName, pTexture);
}