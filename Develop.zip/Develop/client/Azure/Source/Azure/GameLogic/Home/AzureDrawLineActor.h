// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "Styling/SlateBrush.h"
#include "AzureDrawLineComponent.h"



#if WITH_EDITOR
#include "PropertyEditorDelegates.h"
#endif
#include "AzureDrawLineActor.generated.h"


UCLASS()
class AZURE_API AAzureDrawLineActor : public AActor
{
	GENERATED_BODY()


public:	
	// Sets default values for this actor's properties
	AAzureDrawLineActor();

	// Called when the game starts or when spawned
	virtual void BeginPlay() override;
	virtual void PostInitProperties() override;
	virtual void PostLoad()override;
	virtual void Destroyed() override;
	// Called every frame
	virtual void Tick( float DeltaSeconds ) override;

#if WITH_EDITOR
	virtual void PostEditChangeProperty(FPropertyChangedEvent& PropertyChangedEvent) override;
	void RegisterCustomPropertyTypeLayout(FName PropertyTypeName, FOnGetPropertyTypeCustomizationInstance PropertyTypeLayoutDelegate);

#endif
	
	UFUNCTION()
	void AddLine(const FVector& Start, const FVector& End, const FLinearColor& Color, int DepthPriorityGroup, float Thickness);
	UFUNCTION()
	void RemoveAllLines();
	
public:
	UPROPERTY(Transient)
	UAzureDrawLineComponent* pAzureDrawLineComponent = NULL;
};
