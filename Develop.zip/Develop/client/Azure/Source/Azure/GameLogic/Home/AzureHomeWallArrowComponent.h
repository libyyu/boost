// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Components/ActorComponent.h"
#include "AzureHomeWallArrowComponent.generated.h"


UENUM()
enum class ArrowType : uint8
{
	ARROW_FORWARD = 1, //ǰ
	ARROW_BACK = 2,   //��
	ARROW_LEFT = 3,	//��
	ARROW_RIGHT = 4,	//��
};

UCLASS( ClassGroup=(Custom), meta=(BlueprintSpawnableComponent) )
class AZURE_API UAzureHomeWallArrowComponent : public UActorComponent
{
	GENERATED_BODY()

public:	
	// Sets default values for this component's properties
	UAzureHomeWallArrowComponent();

protected:
	// Called when the game starts
	virtual void BeginPlay() override;

public:	
	// Called every frame
	virtual void TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction) override;

	UFUNCTION()
	void SetWallInfo(int id, int wall_id, ArrowType type);

	UFUNCTION()
	bool GetWallInfo(int &id, int &wall_id, ArrowType &type);

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "HomeInfo", DisplayName = "ID")
	int ID = 0;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "HomeInfo", DisplayName = "WallId")
	int WallId = 0;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "HomeInfo", DisplayName = "Type")
	ArrowType Type = ArrowType::ARROW_FORWARD;
};
