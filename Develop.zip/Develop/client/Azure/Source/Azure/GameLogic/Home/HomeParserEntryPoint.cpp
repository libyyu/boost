﻿// Copyright 2015-2016 Code Respawn Technologies. MIT License

#include "HomeParserEntryPoint.h"
#include "Kismet/GameplayStatics.h"
#include "UObject/UObjectGlobals.h"
#include "Engine/World.h"
#include "wLua/LuaInterface.h"

//////////////////////////////////////////////////////////////////////////

// Sets default values
AHomeParserEntryPoint::AHomeParserEntryPoint()
	: AAzureEntryPoint()
{
}

// Called when the game starts or when spawned
void AHomeParserEntryPoint::BeginPlay()
{
	Super::BeginPlay();

}

void AHomeParserEntryPoint::StartLua()
{
	wlua->DoString("require [[Home.map_parser_entrypoint]]");
}

// Called every frame
void AHomeParserEntryPoint::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);

}

void AHomeParserEntryPoint::EndPlay(const EEndPlayReason::Type EndPlayReason)
{
	Super::EndPlay(EndPlayReason);
}

void AHomeParserEntryPoint::BeginDestroy()
{
	Super::BeginDestroy();

}

void AHomeParserEntryPoint::GenExtraEntryPointParams(TMap<FString, FString>& params)
{
	params.Emplace(TEXT("config_dir"), ConfigDir);
	params.Emplace(TEXT("scene_id"), FString::FromInt(SceneID));
	params.Emplace(TEXT("output_server"), OutputServer ? TEXT("true") : TEXT("false"));
}

void AHomeParserEntryPoint::GenExtraGlobalVariables(TMap<FString, bool>& params)
{
	params.Emplace(TEXT("GIsHomeParser"), true);
}