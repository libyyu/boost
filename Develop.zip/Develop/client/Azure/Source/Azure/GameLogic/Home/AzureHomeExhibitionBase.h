﻿// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"

#include "AzureHomeExhibitionBase.generated.h"

UENUM()
enum class EHomeExhibitionMovePolicy
{
	// 随机点直线移动
	RANDOM_POS = 0 UMETA(DisplayName = "RandomPos"),

	// 沿着曲线移动
	SPLINE = 1 UMETA(DisplayName = "Spline"),
};

enum EHomeExhibitionState
{
	IDLE = 0,
	MOVING = 1,
};

class USplineComponent;
class AAzureHomeExhibitionBase;
class USceneComponent;

class FAzureHomeExhibitionStateBase
{
public:
	FAzureHomeExhibitionStateBase(AAzureHomeExhibitionBase* Owner)
		: _Owner(Owner)
	{
	}

	virtual ~FAzureHomeExhibitionStateBase() {}

	virtual void OnEnter() = 0;
	virtual void OnLeave() = 0;
	virtual void OnUpdate(float DeltaSeconds) = 0;

	static FAzureHomeExhibitionStateBase* CreateState(EHomeExhibitionState stateType);

protected:
	AAzureHomeExhibitionBase* _Owner;
};

UCLASS()
class AZURE_API AAzureHomeExhibitionBase : public AActor
{
	GENERATED_BODY()

public:
	// Sets default values for this actor's properties
	AAzureHomeExhibitionBase();

	// Called when the game starts or when spawned
	virtual void BeginPlay() override;
	virtual void BeginDestroy() override;

	// Called every frame
	virtual void Tick(float DeltaSeconds) override;

	void ChangeState(EHomeExhibitionState NewState);
	FAzureHomeExhibitionStateBase* GetCachedState(EHomeExhibitionState NewState);

public:
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, meta = (AllowPrivateAccess = "true"))
	UStaticMeshComponent* Container;

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, meta = (AllowPrivateAccess = "true"))
	USceneComponent* Entity;

	UPROPERTY(VisibleAnywhere, BlueprintReadWrite)
	USkeletalMeshComponent* EntityMesh;

	UPROPERTY(VisibleAnywhere, BlueprintReadWrite)
	USplineComponent* Spline;

	// 移动策略
	UPROPERTY(EditAnywhere, Category = Azure)
	EHomeExhibitionMovePolicy MovePolicy = EHomeExhibitionMovePolicy::RANDOM_POS;

	// 移动速度
	UPROPERTY(EditAnywhere, Category = Azure)
	float MoveSpeed = 2.0f;

	// 移动间隙休息时长
	UPROPERTY(EditAnywhere, Category = Azure)
	float IdleTime = 3.0f;

	// 随机移动的范围
	UPROPERTY(EditAnywhere, Category = Azure)
	FBox RangeBox = 3.0f;

	// 是否只在XY平面移动
	UPROPERTY(EditAnywhere, Category = Azure)
	bool Move2D = false;

protected:
	FAzureHomeExhibitionStateBase* _curState;
	TMap<int, FAzureHomeExhibitionStateBase*> _stateCache;
};
