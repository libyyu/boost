// Fill out your copyright notice in the Description page of Project Settings.

#include "AzureHomeUtilActor.h"
#include "Engine.h"
#include "Math/Color.h"
#include "Materials/MaterialInstanceDynamic.h"
#include "AzureUtility.h"
#include "../ResourceLoader/AzureResourceLoader.h"
#include "AzureHomeUtil.h"
#include "Materials/MaterialInstanceDynamic.h"

#if WITH_EDITOR
#include "PropertyEditorModule.h"
#endif

// Sets default values
AAzureHomeUtilActor::AAzureHomeUtilActor()
{
 	// Set this actor to call Tick() every frame.  You can turn this off to improve performance if you don't need it.
	PrimaryActorTick.bCanEverTick = true;

}

// Called when the game starts or when spawned
void AAzureHomeUtilActor::BeginPlay()
{
	Super::BeginPlay();
	
	
}

void AAzureHomeUtilActor::PostInitProperties()
{
	Super::PostInitProperties();
	
}

void AAzureHomeUtilActor::PostLoad()
{
	Super::PostLoad();

}
void AAzureHomeUtilActor::Destroyed()
{
	Super::Destroyed();
	ReleaseMaskCache();
}

#if WITH_EDITOR
void AAzureHomeUtilActor::PostEditChangeProperty(FPropertyChangedEvent& PropertyChangedEvent)
{
	Super::PostEditChangeProperty(PropertyChangedEvent);
}

void AAzureHomeUtilActor::RegisterCustomPropertyTypeLayout(FName PropertyTypeName, FOnGetPropertyTypeCustomizationInstance PropertyTypeLayoutDelegate)
{
	check(PropertyTypeName != NAME_None);


	static FName PropertyEditor("PropertyEditor");
	FPropertyEditorModule& PropertyModule = FModuleManager::GetModuleChecked<FPropertyEditorModule>(PropertyEditor);
	//FPropertyTypeLayoutCallback PropertyTypeLayoutCallback = PropertyModule.FindPropertyTypeLayoutCallback(PropertyTypeName,)
	PropertyModule.RegisterCustomPropertyTypeLayout(PropertyTypeName, PropertyTypeLayoutDelegate);
}

#endif

// Called every frame
void AAzureHomeUtilActor::Tick( float DeltaTime )
{
	Super::Tick( DeltaTime );
		
}
void AAzureHomeUtilActor::InitMaskCache(int size)
{
	ReleaseMaskCache();
	if (size > 0)
	{
		MaskCacheSize = size;
		MaskCache = new char[size];
		ZeroMask(size);
	}
}

void AAzureHomeUtilActor::ReleaseMaskCache()
{
	if (MaskCache)
	{
		delete[] MaskCache;
		MaskCacheSize = 0;
	}
}
void AAzureHomeUtilActor::SetMask(int idx, char v)
{
	if ( MaskCache && idx>=0 && idx< MaskCacheSize )
		MaskCache[idx] = v;
}
char AAzureHomeUtilActor::GetMask(int idx)
{
	if (MaskCache && idx >= 0 && idx < MaskCacheSize)
		return MaskCache[idx];
	return 0;
}
void AAzureHomeUtilActor::ZeroMask(int size)
{
	if (MaskCache&&size>0)
	{
		if (size > MaskCacheSize)
			size = MaskCacheSize;
		FMemory::Memset(MaskCache, 0, size);
	}
	
}

FQuat AAzureHomeUtilActor::RotatorToFQuat(float InPitch, float InYaw, float InRoll)
{
	return FQuat(FRotator(InPitch, InYaw, InRoll));
}


UMaterialInstanceDynamic* AAzureHomeUtilActor::CreateDynamicMaterialInstance(UMaterialInterface* Parent)
{
	return UMaterialInstanceDynamic::Create(Parent, this);
}

void AAzureHomeUtilActor::CopyTexture2D(UMaterialInstanceDynamic* pWallDynamic, UMaterialInstanceDynamic* pItemDynamic)
{
	if (!pWallDynamic || !pItemDynamic) return;
	FName ParameterName = AzureHomeUtil::VG_BaseColor;
	UTexture* pTexture = nullptr;
	pTexture = pWallDynamic->K2_GetTextureParameterValue(ParameterName);
	if (pTexture)
		pItemDynamic->SetTextureParameterValue(ParameterName, pTexture);

	ParameterName = AzureHomeUtil::VG_Normal;
	pTexture = pWallDynamic->K2_GetTextureParameterValue(ParameterName);
	if (pTexture)
		pItemDynamic->SetTextureParameterValue(ParameterName, pTexture);

	ParameterName = AzureHomeUtil::VB_BaseColor;
	pTexture = pWallDynamic->K2_GetTextureParameterValue(ParameterName);
	if (pTexture)
		pItemDynamic->SetTextureParameterValue(ParameterName, pTexture);

	ParameterName = AzureHomeUtil::VB_Normal;
	pTexture = pWallDynamic->K2_GetTextureParameterValue(ParameterName);
	if (pTexture)
		pItemDynamic->SetTextureParameterValue(ParameterName, pTexture);
}