// Fill out your copyright notice in the Description page of Project Settings.

#include "AzureStaticMeshActor.h"
#include "Engine.h"
#include "Math/Color.h"
#include "AzureUtility.h"
#include "../ResourceLoader/AzureResourceLoader.h"
#include "Engine/World.h"

#if WITH_EDITOR
#include "PropertyEditorModule.h"
#endif

// Sets default values
AAzureStaticMeshActor::AAzureStaticMeshActor()
{
 	// Set this actor to call Tick() every frame.  You can turn this off to improve performance if you don't need it.
	PrimaryActorTick.bCanEverTick = true;

	if (!RootComponent)
	{
		UStaticMeshComponent* SceneComponent = CreateDefaultSubobject<UStaticMeshComponent>(TEXT("RootComponent"));
		SetRootComponent(SceneComponent);
		pStaticMeshComponent = SceneComponent;
	}

}

// Called when the game starts or when spawned
void AAzureStaticMeshActor::BeginPlay()
{
	Super::BeginPlay();
	
	
}

void AAzureStaticMeshActor::PostInitProperties()
{
	Super::PostInitProperties();
	
}

void AAzureStaticMeshActor::PostLoad()
{
	Super::PostLoad();

}

void AAzureStaticMeshActor::Destroyed()
{
	Super::Destroyed();
}

#if WITH_EDITOR
void AAzureStaticMeshActor::PostEditChangeProperty(FPropertyChangedEvent& PropertyChangedEvent)
{
	Super::PostEditChangeProperty(PropertyChangedEvent);

	// Look for changed properties
	const FName PropertyName = (PropertyChangedEvent.Property != nullptr) ? PropertyChangedEvent.Property->GetFName() : NAME_None;
	const FName MemberPropertyName = (PropertyChangedEvent.MemberProperty != nullptr) ? PropertyChangedEvent.MemberProperty->GetFName() : NAME_None;

	if(PropertyName == "doTest1")
	{
	}
	
}

void AAzureStaticMeshActor::RegisterCustomPropertyTypeLayout(FName PropertyTypeName, FOnGetPropertyTypeCustomizationInstance PropertyTypeLayoutDelegate)
{
	check(PropertyTypeName != NAME_None);


	static FName PropertyEditor("PropertyEditor");
	FPropertyEditorModule& PropertyModule = FModuleManager::GetModuleChecked<FPropertyEditorModule>(PropertyEditor);
	//FPropertyTypeLayoutCallback PropertyTypeLayoutCallback = PropertyModule.FindPropertyTypeLayoutCallback(PropertyTypeName,)
	PropertyModule.RegisterCustomPropertyTypeLayout(PropertyTypeName, PropertyTypeLayoutDelegate);
}

#endif

// Called every frame
void AAzureStaticMeshActor::Tick( float DeltaTime )
{
	Super::Tick( DeltaTime );
		
}


bool AAzureStaticMeshActor::SetStaticMesh(UStaticMesh* NewMesh)
{
	if (pStaticMeshComponent)
		return pStaticMeshComponent->SetStaticMesh(NewMesh);
	return false;
}

UStaticMesh* AAzureStaticMeshActor::GetStaticMesh() const
{
	if (pStaticMeshComponent)
		return pStaticMeshComponent->GetStaticMesh();
	return nullptr;
}
UStaticMeshComponent* AAzureStaticMeshActor::GetStaticMeshComponent()
{
	return pStaticMeshComponent;
}
void AAzureStaticMeshActor::SetCollisionProfileName(FString ProfileName)
{
	pStaticMeshComponent->SetCollisionProfileName(*ProfileName);
}

void AAzureStaticMeshActor::SetRelativeLocationAndRotationAndScale(FVector RelativeLocation, FRotator RelativeRotation, FVector RelativeScale3D)
{
	pStaticMeshComponent->SetRelativeLocationAndRotation(RelativeLocation, RelativeRotation);
	pStaticMeshComponent->SetRelativeScale3D(RelativeScale3D);
	pStaticMeshComponent->RelativeLocation = RelativeLocation;
	pStaticMeshComponent->RelativeRotation = RelativeRotation;
	pStaticMeshComponent->RelativeScale3D = RelativeScale3D;
}

int AAzureStaticMeshActor::GetMaterialIndex(FName  MaterialSlot)
{
	return pStaticMeshComponent->GetMaterialIndex(MaterialSlot);
}

UMaterialInterface* AAzureStaticMeshActor::GetMaterial(int idx, UMaterialInterface* MaterialWall)
{
	UMaterialInterface* MaterialInterface = pStaticMeshComponent->GetMaterial(idx);
	UMaterialInstanceDynamic* pDynamicMat = MaterialInterface ? Cast<UMaterialInstanceDynamic>(MaterialInterface) : nullptr;
	if (pDynamicMat == nullptr&&MaterialInterface != nullptr&&MaterialWall)
	{
		pDynamicMat = UMaterialInstanceDynamic::Create(MaterialWall, pStaticMeshComponent->GetOuter());
		Cast<UMeshComponent>(pStaticMeshComponent)->SetMaterial(idx, pDynamicMat);
	}
		
	return pDynamicMat;
}

void AAzureStaticMeshActor::SetMaterial(int idx, UMaterialInterface* Mat)
{
	return Cast<UMeshComponent>(pStaticMeshComponent)->SetMaterial(idx, Mat);
}