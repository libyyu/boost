//#include <Azure.h>
#include "pingclient.h"
#include "Protocols/Challenge.h"

namespace GNET
{
	//PingClient PingClient::instance;

	//const Protocol::Manager::Session::State *PingClient::GetInitState() const
	//{
	//	static Protocol::Manager::Session::State state;
	//	return &state;
	//}

	////struct Attr {
	////	public uint _attr;
	////	struct Mix {
	////		public byte load;
	////		public byte lambda;
	////		public byte anything;
	////		public byte doubleExp;
	////		public byte doubleMoney;
	////		public byte doubleObject;
	////		public byte doubleSP;
	////		public byte freeZone;
	////		public Mix(byte n)
	////		{
	////			load = n;
	////			lambda = n;
	////			anything = n;
	////			doubleExp = n;
	////			doubleMoney = n;
	////			doubleObject = n;
	////			doubleSP = n;
	////			freeZone = n;
	////		}
	////	}
	////	Mix _value;
	////};

	//class ServerStatus
	//{
	//public:
	//	uint32 ping;
	//	//Attr attr;
	//};

	//void PingClient::OnRecvProtocol(Session::ID session, Protocol *protocol)
	//{
	//	if (protocol && protocol->GetType()==Challenge::PROTOCOL_TYPE)
	//	{
	//		if (!m_callback)
	//			return;

	//		Challenge* p = (Challenge*)(protocol);

	//		ServerStatus status;
	//		// status.attr = *(Attr*)(p->nonce.begin());
	//		{
	//			Thread::Mutex::Scoped l(locker);
	//			status.ping = (cxxstd::GetTickCount() - pingmap[session]);

	//			if (status.ping <= 5)
	//				status.ping = 5;
	//			else if (status.ping > 9999)
	//				status.ping = 9999;
	//		}

	//		//printf("ping %u, got %u\n", session, status.ping);

	//		m_callback(&status, session, EVENT_PINGRETURN);
	//		Close(session);

	//		p->Destroy();
	//	}
	//}
}

