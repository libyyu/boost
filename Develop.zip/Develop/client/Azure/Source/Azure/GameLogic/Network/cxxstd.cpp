//#include <Azure.h>
#include "cxxstd.h"

#include <thread>
#include <chrono>

namespace cxxstd
{
	static std::chrono::system_clock::duration getDuration()
	{
		static const auto start = std::chrono::system_clock::now();
		auto now = std::chrono::system_clock::now();
		return now - start;
	}

	unsigned int GetTickCount()
	{
		auto duration = getDuration();
		auto milliseconds = std::chrono::duration_cast<std::chrono::milliseconds>(duration);
		return (unsigned int)milliseconds.count();
	}
	float GetTimeSeconds()
	{
		auto duration = getDuration();
		auto seconds = std::chrono::duration_cast<std::chrono::seconds>(duration);
		return (float)seconds.count();
	}

	void Sleep(unsigned int ms)
	{
		std::this_thread::sleep_for(std::chrono::milliseconds(ms));
	}
}