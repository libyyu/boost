#pragma once

namespace cxxstd
{
	unsigned int GetTickCount();
	float GetTimeSeconds();
	void Sleep(unsigned int ms);
}
