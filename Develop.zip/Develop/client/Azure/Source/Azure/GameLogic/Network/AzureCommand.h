#pragma once

#include "gnproto.h"
#include "AzureBinaryReader.h"
#include "AzureBinaryWriter.h"

namespace GNET
{
	class Command
	{
	protected:
		int m_type;

	public:
		Protocol* protocol = nullptr;
		int ReceivedSize = 0;

		Command(int t)
		{
			m_type = t;
		}

		virtual int getCommandType() const
		{
			return m_type;
		}

		virtual void marshal(AzureBinaryWriter& bw) const = 0;
		virtual void unmarshal(AzureBinaryReader& br) = 0;

		virtual bool IsSelfProcessing()
		{
			return false;
		}

		virtual void Process()
		{
		}

		virtual void Log()
		{
		}
	};
}
