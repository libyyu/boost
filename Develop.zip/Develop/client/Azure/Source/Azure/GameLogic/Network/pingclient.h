#pragma once

#include "CoreMinimal.h"
#include "cxxstd.h"
#include "gnconf.h"
#include "NetClient.h"

namespace GNET
{
	//class PingClient: public NetClient
	//{
	//	static PingClient instance;
	//	Thread::Mutex locker;
	//	ahash_map<Session::ID, uint32> pingmap;

	//public:

	//	static PingClient& GetInstance() 
	//	{ 
	//		return instance;
	//	}

	//	const Session::State *GetInitState() const;

	//	/*virtual bool InputPolicy(Protocol::Type type, size_t size) const override
	//	{
	//		return true;
	//	}*/

	//	astring Identification() const { return "GameClient"; }

	//	virtual void OnAddSession(Session::ID session) override
	//	{
	//		//Console.WriteLine("PingClient::OnAddSession");
	//		m_session = session;
	//		Thread::Mutex::Scoped l(locker);
	//		pingmap[session] = cxxstd::GetTickCount();
	//	}

	//	//virtual void OnDelSession(Session::ID session) override
	//	//{
	//	//	if (m_session != 0)
	//	//		Console.WriteLine("PingClient::OnDelSession");
	//	//	m_session = 0;
	//	//}

	//	//virtual void OnAbortSession(Session::ID session) override
	//	//{
	//	//	if (m_session != 0)
	//	//		Console.WriteLine("PingClient::OnAbortSession");
	//	//	m_session = 0;
	//	//}

	//	int Ping(const astring& host, int port)
	//	{
	//		return GNET::PingClient::ConnectTo(host, port);
	//	}

	//	virtual void OnRecvProtocol(Session::ID session, Protocol *protocol) override;

	//protected:
	//	static Session::ID ConnectTo(const astring& hostname, int port)
	//	{
	//		GetInstance().HostName = hostname;
	//		GetInstance().Port = port;
	//		return GNET::Protocol::Client(&GNET::PingClient::GetInstance(), hostname.c_str(), port);
	//	}
	//};
};
