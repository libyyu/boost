﻿#pragma once

#include "CoreMinimal.h"
#include "NetClient.h"
#include "Protocols/DirInfo.h"
#include "Protocols/CommonData.h"

namespace GNET
{
	class DirClient : public NetClient
	{
		volatile int m_requesting = -1; //not begin

		FCriticalSection m_csDirInfo;
		DirInfo* m_dirInfo = nullptr;

		Session::ID m_linkSid = 0;
		Session* m_linkSession = nullptr;
		Thread::IAzureThread *m_connectThread = nullptr; //连接线程
		float m_connectTimeout = 5000.0f; //超时时间
	protected:
		void _ConnectThreadProc()
		{
			if (!m_linkSession) 
			{
#ifdef WITH_ENGINE
				UE_LOG(LogTemp, Error, TEXT("link session not valid."));
#else
				printf("link session not valid.\n");
#endif
			}
			else
			{
#ifdef WITH_ENGINE
				float startTime = FPlatformTime::Seconds();
#endif
				if (!ActiveIO::Open(m_linkSession, HostName.c_str(), Port, m_connectTimeout))
				{//Open 成功后， 关闭连接的时候，会在Destroy的时候delete this;
#ifdef WITH_ENGINE
					float useTime = FPlatformTime::Seconds() - startTime;
					UE_LOG(LogTemp, Warning, TEXT("zdir link failed. overtime %.2f."), useTime);
#else
					printf("zdir link failed.\n");
#endif
					delete m_linkSession;
					m_linkSession = nullptr;

					m_linkSid = 0;
				}
				
			}
		}
		
		void _Connect()
		{
			m_connectThread = Thread::CreateThread(std::bind(&DirClient::_ConnectThreadProc, this));
		}
	public:
		DirClient() {}
		static DirClient& GetInstance();

		virtual void OnAddSession(Session::ID session) override
		{
			//UnityEngine.Debug.Log("DirClient::OnAddSession");
			m_session = session;
        }

		virtual void OnDelSession(Session::ID session) override
		{
			//if (this.session != null)
			//    UnityEngine.Debug.Log("DirClient::OnDelSession " + this.session.getPeerAddress().ToString());
            m_session = 0;
			m_linkSession = nullptr;
			m_linkSid = 0;
        }

		virtual void OnAbortSession(Session::ID session) override
		{
			//if (this.session != null)
			//    UnityEngine.Debug.Log("DirClient::OnAbortSession " + this.session.getPeerAddress().ToString());
			m_session = 0;
			m_linkSession = nullptr;
			m_linkSid = 0;
		}

		virtual astring Identification() const override
		{
            return "DirClient"; 
        }

		/*virtual int  PriorPolicy(Protocol::Type type) const override
		{
			return 1;
		}
		virtual bool InputPolicy(Protocol::Type type, size_t size) const override
		{
			return true;
		}*/
		virtual void OnCheckAddress(SockAddr &) const { }

		const Session::State *GetInitState() const;


		Session::ID GetSessionID()
        { 
            return m_session;
        }

        static Session::ID ConnectTo(const astring& hostname, int port, float timeOut = 5000.f)
        {
			DirClient::AbortRequest(GetInstance().m_linkSid);
			//GetInstance().Abort();
            GetInstance().HostName = hostname;
            GetInstance().Port = port;
			GetInstance().m_connectTimeout = timeOut;
			//UnityEngine.Debug.LogWarning("Connenting to dir server: " + hostname + ": " + port);
			DirClient::GetInstance().m_requesting = 1;
			GetInstance().m_linkSession = Protocol::ClientSession(&DirClient::GetInstance()); //session需要delete
			Manager::Session::ID sid = GetInstance().m_linkSession->GetSid();
			GetInstance().m_linkSid = sid;
			GetInstance()._Connect();
			return sid;
        }

		virtual void OnRecvProtocol(Session::ID session, Protocol *protocol) override
		{
			//UnityEngine.Debug.Log("DirClient:OnRecvProtocol. procotol type:" + protocol.getProtocolType().ToString());

            if(protocol->GetType()==DirInfo::PROTOCOL_TYPE)
		    {
                CommonData *p = (CommonData*)protocol;
                if(p!=nullptr)
                {
			        Close(m_session);

					m_csDirInfo.Lock();

					delete m_dirInfo;
					m_dirInfo = new DirInfo;
					m_dirInfo->unmarshal(*p->GetStreamData());

					m_csDirInfo.Unlock();

					p->Destroy();
					m_requesting = 0; //finish
                }
		    }
        }

        static Session::ID RequestInfo(const astring& host, int port, float timeOut = 5000.f)
		{
			PollIO::Init();
            return DirClient::ConnectTo(host, port, timeOut);
		}

		static void AbortRequest(Session::ID session)
		{
			GetInstance().Close(session);
			GetInstance().Abort();
		}

		void Abort()
		{
			if (m_connectThread != nullptr) {
				Thread::DestroyThread(m_connectThread);
				m_connectThread = nullptr;
			}
		}

		bool HasGotInfo()
		{
			return m_requesting==0;
		}

		TArray<char> GetServerList();
		TArray<char> GetVersion();
		TArray<char> GetVersionList();
	};
}
