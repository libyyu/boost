#pragma once

namespace S2C
{
	//	Command ID
	enum class S2C_COMMAND : int
	{
		PROTOCOL_COMMAND = -1,		//	Reserved for protocol

		OBJECT_MOVE = 26,
		OBJECT_TURN = 27,

		SERVER_TIMESTAMP = 31,

		OBJECT_NOTIFY_PROP_DELTA = 36,

		ENTER_TEAM_FOLLOW_MODE = 47,
		LEAVE_TEAM_FOLLOW_MODE = 48,

		OBJECT_PERFORM_SKILL = 86,

		OBJECT_STOP_SESSION = 91,

		BE_HURT = 116,
		OBJECT_BE_ATTACKED = 117,

		TEAM_FOLLOW_MOVE = 125,
		SELF_HIT = 330,
	};
}

namespace C2S
{
	enum class C2S_COMMAND : int
	{
		PLAYER_MOVE = 1,
		PLAYER_TURN = 2,

		TASK_NOTIFY = 22,

		PLAYER_SKILL_MOVE = 116,   // 206 �����ƶ�

	};
}

