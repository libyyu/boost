//#include <Azure.h>
#include "DirClient.h"
#include "AzureUtility.h"
#include "Misc/ScopeLock.h"

namespace GNET
{
	TArray<char> UncompressDataToArray(const void* data, int compressedDataSize, int uncompressedDataSize)
	{
		if (uncompressedDataSize > compressedDataSize)
		{
			return AzureUtility::UncompressDataToArray(data, compressedDataSize, uncompressedDataSize);
		}
		else
		{
			return TArray<char>((char*)data, compressedDataSize);// compressedDataSize == uncompressedDataSize
		}
	}

	const Protocol::Manager::Session::State *DirClient::GetInitState() const
	{
		static Protocol::Manager::Session::State state;
		return &state;
	}

	DirClient& DirClient::GetInstance()
	{
		static DirClient instance;
		return instance;
	}

	TArray<char> DirClient::GetServerList()
	{
		FScopeLock lock(&m_csDirInfo);

		if (m_dirInfo != nullptr)
			return UncompressDataToArray(m_dirInfo->serverList.begin(), m_dirInfo->serverList.size(), (int)m_dirInfo->serverListLength);
		else
			return TArray<char>();
	}

	TArray<char> DirClient::GetVersion()
	{
		FScopeLock lock(&m_csDirInfo);

		if (m_dirInfo != nullptr)
			return UncompressDataToArray(m_dirInfo->version.begin(), m_dirInfo->version.size(), (int)m_dirInfo->versionLength);
		else
			return TArray<char>();
	}

	TArray<char> DirClient::GetVersionList()
	{
		FScopeLock lock(&m_csDirInfo);

		if (m_dirInfo != nullptr)
			return UncompressDataToArray(m_dirInfo->versionList.begin(), m_dirInfo->versionList.size(), (int)m_dirInfo->versionListLength);
		else
			return TArray<char>();
	}
}
