//#include "Azure.h"
#include "AzureGameSession.h"
#include <list>
#include <mutex>
#include <vector>
#include "Protocols/KeepAlive.h"
#include "ABaseDef.h"

ahash_set<int> AzureGameSession::GameDataSendFilterList;
namespace GNET
{
	Protocol* newProtocolImpl(unsigned int type);
}
AzureGameSession::AzureGameSession()
{
	IsConnected = false;
	IsLinkBroken = false;
	IsExitConnect = false;
	LinkBrokenEvent = 0;
	AutoConnectTTL = 0;
	Port = 0;
	LinkID = 0;
	ConnectTime = 0;
	m_fElapsedTime = 0;

	GNET::newProtocol = GNET::newProtocolImpl;

	init();
}

AzureGameSession::~AzureGameSession()
{
	if (m_connectThread != nullptr)
	{
		InnerDestroyConnectThread();
	}
}

AzureGameSession& AzureGameSession::Instance()
{
	return gamesession;
}

void AzureGameSession::SendKeepAliveMsg(float fRealTimeSinceStartup)
{
	int32_t LastSendCode = GNET::KeepAlive::LastSendCode++;
	GNET::KeepAlive p(LastSendCode);
	GNET::KeepAlive::Lastsend = fRealTimeSinceStartup;
	gamesession.NetMan.LastSendAlive = cxxstd::GetTickCount();
	gamesession.SendNetData(&p);
#if !UE_BUILD_SHIPPING	//debug no KeepAlive disconnect
	//UE_LOG(LogTemp, Log, TEXT("Send_KeepAlive: code:%d"), LastSendCode);
#endif
	RecordProtoToDebugger(&p, true);
}

static bool IsEnableNetworkDebug()
{
	if (!AAzureEntryPoint::Instance)
		return false;

	lua_State_Wrapper L = AAzureEntryPoint::Instance->GetWLua()->GetL();
	bool bEnabled = false;
	lua_getglobal(L, "ENABLE_PROTOCOL_DEBUG");
	if (lua_isboolean(L, -1))
		bEnabled = lua_toboolean(L, -1) != 0;
	lua_pop(L, 1);
	return bEnabled;
}

void AzureGameSession::RecordC2SToDebugger(GNET::Command* cmd)
{
	if (!IsEnableNetworkDebug())
		return;
	
	AzureBinaryWriter bw;
	cmd->marshal(bw);

	AzureBinaryReader br(bw.GetData().begin(), bw.GetData().size());

	// ��C++�д�����Э��Ҳ��һ��ECNetworkDebugger
	if (!AAzureEntryPoint::Instance)
		return;

	wLua::Lua *pLua = AAzureEntryPoint::Instance->GetWLua();
	lua_State_Wrapper L = pLua->GetL();
	lua_getglobal(L, "RecordProtoHandledInCSharp");
	if (lua_isfunction(L, -1))
	{
		lua_pushnumber(L, cmd->getCommandType());
		AzureBinaryReader* brForLua = new AzureBinaryReader(std::move(br));
		AzureHelpFuncs::ReturnObject(L, brForLua, LuaAzureBinaryReader::mt_name);
		lua_pushnumber(L, 2);
		pLua->Call(3);
	}
	else
	{
		lua_pop(L, 1);
	}
}

void AzureGameSession::RecordProtoToDebugger(GNET::Protocol* proto, bool bC2S)
{
	if (!IsEnableNetworkDebug())
		return;

	OctetsStream stream;
	proto->marshal(stream);

	if (!AAzureEntryPoint::Instance)
		return;

	wLua::Lua *pLua = AAzureEntryPoint::Instance->GetWLua();
	lua_State_Wrapper L = pLua->GetL();
	lua_getglobal(L, "RecordProtoHandledInCSharp");
	if (lua_isfunction(L, -1))
	{
		lua_pushnumber(L, proto->GetType());
		GNET::Marshal::OctetsStream* ret = new GNET::Marshal::OctetsStream();
		*ret = std::move(stream);
		AzureHelpFuncs::ReturnObject(L, ret, luaOctetsStream::mt_name);
		lua_pushnumber(L, bC2S ? 3 : 4);
		pLua->Call(3);
	}
	else
	{
		lua_pop(L, 1);
	}
}

AzureGameSession AzureGameSession::gamesession;

std::mutex AzureGameSession::m_csSession;

ahash_map<uint32_t, uint32_t> AzureGameSession::resource_versions;

namespace GNET
{
	float KeepAlive::Lastsend = 0.0f;
	float KeepAlive::LastReceive = 0.0f;
	int32_t KeepAlive::LastSendCode = 0;

	struct ProtocolCache
	{
		std::mutex mutex;
		avector<CommonData*> lists;
		~ProtocolCache()
		{
			for (auto& data : lists)
				delete data;
		}
	};

	static ProtocolCache gCache;
	Protocol* newProtocolImpl(unsigned int type)
	{
		CommonData *data = 0;
		{
			std::lock_guard<std::mutex> lock(gCache.mutex);
			if (!gCache.lists.empty())
			{
				data = gCache.lists.back();
				gCache.lists.pop_back();
			}
		}

		if (data == nullptr)
			data = new CommonData(type);
		else
		{
			data->SetType(type);
		}

		return data;
	}

	void deleteProtocol(CommonData *data)
	{
		data->Reset();
		std::lock_guard<std::mutex> lock(gCache.mutex);
		gCache.lists.push_back(data);
	}
}
