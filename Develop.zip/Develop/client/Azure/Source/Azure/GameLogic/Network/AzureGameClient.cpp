#include "AzureGameClient.h"
#include <Azure.h>

namespace GNET
{
	const Protocol::Manager::Session::State *GameClient::GetInitState() const
	{
		static Protocol::Manager::Session::State state;
		return &state;
	}

	void GameClient::OnAddSession(Session::ID session) 
	{
		UE_LOG(LogAzure, Log, TEXT("GameClient::OnAddSession id = %d"), (int)session);

		std::lock_guard<std::mutex> lock(locker);
		{
			if (m_callback == nullptr)
				return;
			if (m_state != STATE::STATE_CONNECTING)
				return;
			m_session = session;
			if (m_callback != nullptr && m_state == STATE::STATE_CONNECTING && m_session == session)
				m_callback(nullptr, session, EVENT::EVENT_ADDSESSION);
		}
	}

	void GameClient::OnDelSession(Session::ID session)
	{
		UE_LOG(LogAzure, Log, TEXT("GameClient::OnDelSession id = %d"), (int)session);

		std::lock_guard<std::mutex> lock(locker);
		{
			if (m_session != session) return;

			if (m_callback != nullptr)
			{
				if (m_state == STATE::STATE_KEEPING)
				{
					m_state = STATE::STATE_CLOSED;
				}
				m_callback(nullptr, session, EVENT::EVENT_DISCONNECT);
			}

			m_session = 0;
		}
	}


}