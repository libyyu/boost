﻿#pragma once
#include "gnproto.h"
#include "gnetdef.h"

namespace GNET
{
    class NetClient : public Protocol::Manager
    {
	public:
		typedef int (*callback_t)(void *data, Session::ID session, EVENT protocolid);

	protected:
        callback_t m_callback;
        Session::ID m_session;

	public:
        void Attach(callback_t funptr) { m_callback = funptr; }
        void Detach() { m_callback = nullptr; }

	protected:
		virtual void OnAddSession(Session::ID session) override
        {
			m_session = session;
        }

		virtual void OnDelSession(Session::ID session) override
        {
			m_session = 0;
        }

	public:
		virtual astring Identification() const override
        {
            return "NetClient";
        }
        
	public:
		astring HostName;
		int Port;
	};

}