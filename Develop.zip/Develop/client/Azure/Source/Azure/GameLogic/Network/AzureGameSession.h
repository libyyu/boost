﻿#pragma once

#include "CoreMinimal.h"
#include "Azure.h"
#include "cxxstd.h"
#define LUA_LIB
#include "lua.hpp"
#include "wLuaClass.h"
#include "AzureGameClient.h"
#include "Protocols/CommonData.h"
#include "Protocols/Challenge.h"
#include "Protocols/Response.h"
#include "Protocols/KeyExchange.h"
#include "Protocols/ClientGreeting.h"
#include "pingclient.h"
#include "AzureCommand.h"
#include "Utilities/AzureSystemInfo.h"
#include "Utilities/PlatformConfig.h"
#include "AzureTimeManager.h"
#include "AzureEntryPoint.h"
#include "Utility/help_funcs.h"

#include <map>
#include <string>
#include <list>
#include <thread>
#include <mutex>

#if PLATFORM_WINDOWS
#else
#if defined(USE_ZULONGGCLOUD) && ENABLE_TSSSDK && (PLATFORM_ANDROID || PLATFORM_IOS)
#include "OneSDKTss.h"
#endif //ENABLE_TSSSDK
#endif

using GNET::Command;
using GNET::GameClient;
//using GNET::PingClient;
using GNET::Protocol;
using GNET::Octets;
using GNET::EVENT;
using GNET::CommonData;
using GNET::Challenge;
using GNET::Response;
using GNET::KeyExchange;
using GNET::ClientGreeting;
using OctetsStream = GNET::Marshal::OctetsStream;
using Session = GNET::Protocol::Manager::Session;

struct PINGTIME
{
	unsigned int idLink;
	unsigned int dwTime;
	unsigned int dwStatus;
	unsigned int dwLastPingTime;
};

// public delegate String PONRECEIVEHELPSTATES(Octets data, int myInt);

enum e_OT
{
	OT_Invalid,
	OT_Challenge,
	OT_RoleList,
	OT_SelectRole,
	OT_SelfDefInfo,
	OT_EnterGame,
	OT_Lag,
	OT_LagOffLine,

	OT_SelfAllData,
	OT_GetClientData,
};

struct OVERTIME
{
	bool Check;
	e_OT Type;
	float TTL;
	float LifeTime;

	OVERTIME()
	{
		Check = false;
		Type = OT_Invalid;
		TTL = 0;
		LifeTime = 0;
	}
};

class AzureGameSession
{
	//static System.Object m_csPingSection = new System.Object(); //CRITICAL_SECTION
	static std::mutex m_csSession;
	static AzureGameSession gamesession;

public:
	static ahash_set<int> GameDataSendFilterList;
public:
	volatile bool IsConnected = false;
	volatile bool IsLinkBroken = false;
	volatile bool IsExitConnect = false;
private:
	volatile int LinkBrokenEvent = 0;
	float AutoConnectTTL = 0.f;
public:
	GameClient NetMan;
	//public ProtocolHandle PrtcHandler = new ProtocolHandle();

public:
	astring IP;
	int Port = 0;

	float KeepAliveCheckInterval = 5.0f;

private:
	astring UserName;
	astring Password;
	astring RegionName;
	astring ServerName;

public:
	//Deviceinfo
	astring deviceinfo = "";
	//astring Appid = "1452827692979";
	//astring Client_version = "101";
	//astring Client_res_version = "0";
	astring Platform = "";
	astring Channel_id = "";
	astring Sub_channel_id = "";
	//astring Sdk_device_id = "";
	//astring Mac = "00-00-00-00-00-00";
	//astring Time_zone = "";
	astring Ext = "{\"home_account\":\"\",\"inner_login_token\":0}";
	//astring Sec_report_data = "";
	//astring Reg_channel_dis = "";

	int LinkID = 0;

	alist<GNET::Protocol*> NewPrtcList;        //New received protocols
	static ahash_map<uint32_t, uint32_t> resource_versions;

	unsigned int ConnectTime = 0;

	OVERTIME Overtime;

private:

	Thread::IAzureThread *m_connectThread = nullptr;

	float m_fElapsedTime = 0.f;

	float m_connectTimeout = 5.0f;

	Octets Nonce;

	void InnerDestroyConnectThread()
	{
		IsExitConnect = true;
		NetMan.SetBreakFlag(true);
		Thread::DestroyThread(m_connectThread);
		NetMan.SetBreakFlag(false);
	}

public:
	static int IOCallBack(void *data, Session::ID session, EVENT iEvent)
	{
		AzureGameSession& gs = gamesession;
		//if (gs == null)
		//   return 0;

		EVENT eEvent = (EVENT)iEvent;
		switch (eEvent)
		{
		case EVENT::EVENT_ADDSESSION:
		{
			gs.LinkID = session;
			gs.IsConnected = true;
			gs.IsLinkBroken = false;
			
			//Debug.Log(eEvent);
			//主动随便发点数据上去，避免有的负载均衡或者防火墙犯傻自己接了连接不及时建立和link的连接
			ClientGreeting clientGreeting;
			gs.SendNetData(&clientGreeting);
		}
		return 0;

		case EVENT::EVENT_DELSESSION:
		{
			if (gs.IsConnected)
			{
				gs.IsConnected = false;
				gs.IsLinkBroken = true;
				UE_LOG(LogAzure, Warning, TEXT("GameSession:IOCallBack: EVENT_DELSESSION!"));
			}

			//Debug.Log(eEvent);
		}
		return 0;

		case EVENT::EVENT_ABORTSESSION: // connect to server failed, so pop up a message window, make overtime check fire.
		{
			if (gs.IsConnected)
			{
				gs.IsConnected = false;
				gs.IsLinkBroken = true;
				UE_LOG(LogAzure, Warning, TEXT("GameSession:IOCallBack: EVENT_ABORTSESSION, Make LinkBroken!"));
			}

			gs.LinkBroken(false);

			// Debug.Log(eEvent);
		}
		return 0;

		case EVENT::EVENT_PINGRETURN:
		{
			//Debug.Log(eEvent);
		}
		return 0;

		case EVENT::EVENT_DISCONNECT: // connect to server failed, so pop up a message window, make overtime check fire.
		case EVENT::EVENT_DISCONNECT_ACTIVE:
		{
			if (gs.IsConnected)
			{
				gs.IsConnected = false;
				gs.IsLinkBroken = true;

				UE_LOG(LogAzure, Warning, TEXT("GameSession:IOCallBack: EVENT_DISCONNECT EVENT_DISCONNECT_ACTIVE, Make LinkBroken! %d"),int(eEvent));
			}

			gs.DoOvertimeCheck(false, e_OT::OT_Challenge, 0);
			// Debug.Log(eEvent);
		}
		return 0;

		case EVENT::EVENT_DECODEERR:
		{
			//Debug.Log(eEvent);
		}
		return 0;

		default:
			break;
		}

		GNET::Protocol *pProtocol = (GNET::Protocol*)data;
		if (pProtocol != nullptr)
			gs.AddNewProtocol(pProtocol);

		return 0;
	}

public:
	AzureGameSession();
	~AzureGameSession();

	void init()
	{
		//ProtocolList.RegisterProtocols();

		NetMan.Attach(IOCallBack);

		//PingClient::GetInstance().Attach(IOCallBack);
	}

public:
	static AzureGameSession& Instance();

	static void _ConnectThread()
	{
		AzureGameSession::Instance().ConnectThread();
	}

	bool Connect()
	{
//         if (m_connectThread != null)
//         {
//             IsExitConnect = true;
//             m_connectThread.Join();
//             //m_connectThread.Abort();
//             m_connectThread = null;
//             NetMan.Disconnect(false);
//         }
// 
//         // we use a thread to connect with the server, this can avoid the main thread blocked by firewalls when calling socket's connect
//         m_connectThread = new Thread(ConnectThread);
//         m_connectThread.IsBackground = true;
//         m_connectThread.Priority = System.Threading.ThreadPriority.BelowNormal;
//         m_connectThread.Start();

		if (m_connectThread != nullptr)
		{
			InnerDestroyConnectThread();
			NetMan.Disconnect(false);
		}

		m_connectThread = Thread::CreateThread(_ConnectThread);
		return true;
	}

	bool SendNetData(GNET::Protocol *prtc)
	{
		if (!IsConnected)
		{
#if !UE_BUILD_SHIPPING	//debug no KeepAlive disconnect
			UE_LOG(LogTemp, Log, TEXT("SendNetData Failed not connected: protocol:%d"), prtc ? prtc->GetType() : 0);
#endif
			return true;
		}

		if (!NetMan.SendProtocol(prtc))
		{
			return false;
		}

		return true;
	}

     bool SendGameData(const Command& cmd)
     {
         if (!IsConnected || AutoConnectTTL > 0)
             return true;

         if (!NetMan.SendCommand(cmd))
         {
             return false;
         }
 
         return true;
     }

	void Open()
	{
		Connect();
	}

	void Close()
	{
        if (m_connectThread != nullptr)
        {
			InnerDestroyConnectThread();
        }

        if (IsConnected)
        {
            IsConnected = false;
            NetMan.Disconnect(false);
        }

        GNET::PollIO::Close();
        ClearOldProtocols();

        LinkID = 0;
        UserName = "";
        Password = "";
	}

	void LinkBroken(bool bDisconnect)
	{
		if (!IsLinkBroken)
			return;

		IsLinkBroken = false;
		LinkBrokenEvent = bDisconnect ? 1 : 2;
	}

	void DoOvertimeCheck(bool bStart, e_OT eCheckID, float fTime)
	{
		if (bStart)
		{
			Overtime.Check = true;
			Overtime.Type = eCheckID;
			Overtime.TTL = fTime;
			Overtime.LifeTime = 0;
		}
		else
		{
			if (Overtime.Check && Overtime.Type == eCheckID)
				Overtime.Check = false;
		}
	}

	bool GetOvertimeCnt(e_OT& eOtType, float& fTTL, float& fLifeTime)
	{
		if (!Overtime.Check)
			return false;

		eOtType = Overtime.Type;
		fTTL = Overtime.TTL;
		fLifeTime = Overtime.LifeTime;
		return true;
	}

	int AddNewProtocol(GNET::Protocol *protocol)
	{
		protocol->Syncinfo.RecvTime = AzureTimeManager::GetInstance().GetMillisecondsFromEpoch();

		int iSize = 0;

		std::lock_guard<std::mutex> lock(m_csSession);
		{
			NewPrtcList.push_back(protocol);
			iSize = (int)NewPrtcList.size();
			//Debug.Log("RcvProc: " + protocol.getProtocolType());
		}

		return iSize;
	}

	int GetProtocols(alist<CommonData*>& datas)
	{
		{
			std::lock_guard<std::mutex> lock(m_csSession);
			while (NewPrtcList.size() > 0)
			{
				GNET::Protocol *p = NewPrtcList.front();
				if (p != nullptr && p->GetClassType() == GNET::enumProtCommonData)
				{
					CommonData* d = (CommonData*)p;
					datas.push_back(d);
				}
				NewPrtcList.pop_front();
			}
		}
		return (int)datas.size();
	}

	void ClearOldProtocols()
	{
		std::lock_guard<std::mutex> lock(m_csSession);
		for (auto p : NewPrtcList)
		{
			p->Destroy();
		}
		NewPrtcList.clear();
	}

	void ConnectThread()
	{
		AzureGameSession& gs = gamesession;
		if (gs.NetMan.Connect(IP, Port) == 0)
			return;
		gs.IsExitConnect = false;

		e_OT eOtType = e_OT::OT_Invalid;
		float fTTL = 0;
		float fLifeTime = 0;
		if (!gs.GetOvertimeCnt(eOtType, fTTL, fLifeTime))
		{
			// we only activate the overtime check when the timer has not been activated
			gs.DoOvertimeCheck(true, e_OT::OT_Challenge, m_connectTimeout);
		}

		volatile bool* breakFlag = gs.NetMan.GetBreakFlag();
		// Wait until connect is established
		while (!gs.IsConnected && !gs.IsExitConnect && !(*breakFlag))
		{
			cxxstd::Sleep(100);
		}

		gs.ConnectTime = cxxstd::GetTickCount();
		gs.DoOvertimeCheck(false, e_OT::OT_Challenge, 0);
	}

	void OnOvertimeHappen()
	{
		switch (Overtime.Type)
		{
		case e_OT::OT_Challenge:
		{
			IsExitConnect = true;
			IsLinkBroken = true;
			LinkBroken(false);
		}
		break;

		case e_OT::OT_SelectRole:
		case e_OT::OT_EnterGame:
		case e_OT::OT_SelfDefInfo:
		case e_OT::OT_SelfAllData:
		case e_OT::OT_GetClientData:
		case e_OT::OT_LagOffLine:
		{
			IsLinkBroken = true;
			LinkBroken(true);
		}
		break;

		case e_OT::OT_Lag:
		{
			++m_iLagTime;
		}
		break;

		default:
			return;
		}

		UE_LOG(LogAzure, Log, TEXT("OnOvertimeHappen: %d"), (int)Overtime.Type);
	}
	/*
		void server_Ping()
		{
			PingClient.ConnectTo(IP, Port);
		}

		void server_Ping(int idServer, int idxEntry, String addr, int nPort)
		{
			int idKey = (idxEntry << 16) + idServer;
			lock (m_csPingSection)
			{
				PINGTIME time;

				if (m_mapPing.TryGetValue(idKey, out time))
				{
					if (time.idLink == (uint)0 || Environment.TickCount - time.dwLastPingTime > 600000)
					{

						time.idLink = (uint)PingClient.GetInstance().Ping(addr, nPort).GetHashCode();
						time.dwLastPingTime = (uint)Environment.TickCount;
						time.dwTime = 99999999;
						time.dwStatus = 0;
						m_mapPing[idKey] = time;
					}
				}
				else
				{
					time = new PINGTIME();
					time.idLink = (uint)PingClient.GetInstance().Ping(addr, nPort).GetHashCode(); ;
					time.dwTime = 99999999;
					time.dwLastPingTime = (uint)Environment.TickCount;
					time.dwStatus = 0;
					m_mapPing[idKey] = time;
				}
			}
			return;
		}
	*/
	void Tick(float dt)
	{
		Update();
	}

	float m_fLastRealtimeSinceStartup = 0;
	bool m_bLastIsConnected;
	int m_iLagTime;
	bool Update()
	{
		bool bRet = true;

		float fRealtimeSinceStartup = cxxstd::GetTimeSeconds();
		float fRealDeltaTime = (m_fLastRealtimeSinceStartup == 0) ? 0 : fRealtimeSinceStartup - m_fLastRealtimeSinceStartup;

		// --------------------------------------
		// connection check
		if (m_bLastIsConnected && !IsConnected)
		{
		}

		if (IsLinkBroken)
		{
			LinkBroken(true);
			UE_LOG(LogAzure, Log, TEXT("LinkBroken happened-1:"));
		}			

		if (LinkBrokenEvent != 0)
		{
			int nEvent = LinkBrokenEvent;
			LinkBrokenEvent = 0;

			if (!AAzureEntryPoint::Instance)
				return bRet;

			wLua::Lua* Lua = AAzureEntryPoint::Instance->GetWLua();
			lua_State_Wrapper L = Lua ? Lua->GetL() : nullptr;
			if (L != nullptr)
			{
				lua_getglobal(L, "OnDisConnect");
				lua_pushnumber(L, nEvent);
				Lua->Call(1);
			}
		}

		// --------------------------------------
		// overtime check
		if (Overtime.Check)
		{
			Overtime.LifeTime += fRealDeltaTime;
			if (Overtime.LifeTime >= Overtime.TTL)
			{
				Overtime.Check = false;
				OnOvertimeHappen();
			}
		}

		// --------------------------------------
		// keep alive
		if (IsConnected)
		{
			m_fElapsedTime += fRealDeltaTime;
			if (m_fElapsedTime > KeepAliveCheckInterval)
			{
				m_fElapsedTime = 0;

				if (gamesession.NetMan.LastSendAlive != 0 && (gamesession.NetMan.LastSendAlive > gamesession.NetMan.LastRecvAnyProtocal))
				{
					IsLinkBroken = true;
					LinkBroken(true);

					UE_LOG(LogAzure, Log, TEXT("LinkBroken happened-2: lastsend lastrecv %d %d"), gamesession.NetMan.LastSendAlive, gamesession.NetMan.LastRecvAnyProtocal);
				}
				else
				{
					SendKeepAliveMsg(fRealtimeSinceStartup);
				}
			}

		}

		m_bLastIsConnected = IsConnected;
		m_fLastRealtimeSinceStartup = fRealtimeSinceStartup;

		return bRet;
	}

	void SendKeepAliveMsg(float fRealTimeSinceStartup);

	void SetConnectTimeout(float timeoutSeconds)
	{
		m_connectTimeout = timeoutSeconds;
	}

	void ConnectToServer(const astring& addr, int port, const astring& username, const astring& password)
	{
		IP = addr;
		Port = port;

		UserName = username;
		Password = password;

		GNET::PollIO::Init();
		Open();
	}

	//void SetDeviceInfo(const astring& appid, const astring& client_version,	const astring& client_res_version, 
	//	const astring& platform, const astring& channel_id, const astring& subchannel_id,
	//	const astring& sdk_device_id, const astring& mac, const astring& stimezone, const astring& ext, const astring& regChannelDis)
	//{
	//	Appid = appid;
	//	Client_version = client_version;
	//	Client_res_version = client_res_version;
	//	Platform = platform;
	//	Channel_id = channel_id;
	//	Sub_channel_id = subchannel_id;
	//	Sdk_device_id = sdk_device_id;
	//	Mac = mac;
	//	Time_zone = stimezone;
	//	Ext = ext;
	//	Reg_channel_dis = regChannelDis;
	//}
	void SetDeviceInfo(const astring& device_info, const astring& platform, const astring& channel_id, const astring& subchannel_id, const astring& ext)
	{
		deviceinfo = device_info;
		Platform = platform;
		Channel_id = channel_id;
		Sub_channel_id = subchannel_id;
		Ext = ext;
	}


	void SetResponseExt(const astring& ext)
	{
		Ext = ext;
	}
	bool OnPrtc_Challenge(OctetsStream& os)
	{
		using namespace GNET;
		try
		{
			Challenge prtc;
			prtc.unmarshal(os);
			UE_LOG(LogAzure, Log, TEXT("OnPrtc_Challenge"));
			//Debug.Log(string.Format("On protocol using C#: {0}", (NetProtocolType)Challenge.PROTOCOL_TYPE));

			std::string res_version = AzureHelpFuncs::GetUTF8FromOctets(prtc.res_version);

			if (!AAzureEntryPoint::Instance)
				return false;

			wLua::Lua* Lua = AAzureEntryPoint::Instance->GetWLua();
			lua_State_Wrapper L = Lua ? Lua->GetL() : nullptr;

			if (L == nullptr)
			{
				UE_LOG(LogAzure, Error, TEXT("OnPrtc_Challenge: lua_State is NIL!"));
				check(L != nullptr);
				return false;
			}

			{//	Notify Client to clear some states!
				lua_getglobal(L, "OnPrtc_Challenge");
				Lua->Call(0);
			}

			RecordProtoToDebugger(&prtc, false);

			{// 检查版本	
				lua_getglobal(L, "OnChallengeCheckVersion");
				lua_pushnumber(L, int(prtc.version));
				lua_pushstring(L, TCHAR_TO_UTF8( ANSI_TO_TCHAR(res_version.c_str()) ));
				bool ret = Lua->PCall(2, 1);
				if (ret)
				{
					bool bCheckSucc = lua_toboolean(L, -1);
					lua_pop(L, 1);
					if(!bCheckSucc)
					{
						return false;
					}
				}
				else
				{
					const char* errInfo = lua_tostring(L, -1);
					lua_pop(L, 1);
					UE_LOG(LogAzure, Warning, TEXT("OnChallengeCheckVersion failed: %s"), errInfo);
				}
			}

			//resource_versions = prtc.resource_versions;

			Octets id(UserName);
			Octets pwd(Password);
			Octets channel(Channel_id);

			Response p;

            {
// 				HMAC_MD5Hash hmac_md5;
// 				MD5Hash md5;
//              md5.Update(id);
//              md5.Update(pwd);
//              md5.Final(Nonce);
//              hmac_md5.SetParameter(Nonce);
// 
//              hmac_md5.Update(prtc.nonce);
//              p.identity = id;
//              p.userid = 0;
//              p.algo = prtc.algo;
//              hmac_md5.Final(p.response);
            }

			//使用token登录
			{
				p.identity = id;
				p.userid = 0;
				p.algo = prtc.algo;
				p.response = pwd;
				Nonce = pwd;

				p.ext = Ext;
			}
			{
				p.channel.replace(Channel_id.c_str(), Channel_id.size());
				//UE_LOG(LogAzure, Warning, TEXT("current Channel_id: %s"), ANSI_TO_TCHAR(Channel_id.c_str()));

				p.subchannel.replace(Sub_channel_id.c_str(), Sub_channel_id.size());

				//astring platform(TCHAR_TO_ANSI(AzurePlatformConfig::Get().GetPlatform()));
				p.platform.replace(Platform.c_str(), Platform.size());
				//UE_LOG(LogAzure, Warning, TEXT("current platform: %s"), ANSI_TO_TCHAR(platform.c_str()));
				
				//astring strInfo = GenerateDeviceInfo();
				//p.device_info.replace(strInfo.c_str(), strInfo.size());
				//UE_LOG(LogAzure, Warning, TEXT("current device_info: %s"), ANSI_TO_TCHAR(strInfo.c_str()));
				p.device_info.replace(deviceinfo.c_str(), deviceinfo.size());

				astring mac(TCHAR_TO_ANSI(FAzureSystemInfo::deviceUniqueIdentifier()));
				p.mac.replace(mac.c_str(), mac.size());
				//UE_LOG(LogAzure, Warning, TEXT("current Mac: %s"), ANSI_TO_TCHAR(mac.c_str()));
			}
			SendNetData(&p);
			RecordProtoToDebugger(&p, true);
		}
		catch (std::exception e)
		{
			UE_LOG(LogAzure, Error, TEXT("OnPrtc_Challenge: Exception! %s"), UTF8_TO_TCHAR(e.what()));
			return false;
		}

		return true;
	}

	bool OnPrtc_KeyExchange(OctetsStream& os)
	{
		KeyExchange prtc;
		prtc.unmarshal(os);

		UE_LOG(LogAzure, Log, TEXT("OnPrtc_KeyExchange"));
		//Debug.Log(string.Format("On protocol using C#: {0}", (NetProtocolType)KeyExchange.PROTOCOL_TYPE));

		if (!AAzureEntryPoint::Instance)
			return false;

		wLua::Lua* Lua = AAzureEntryPoint::Instance->GetWLua();
		lua_State_Wrapper L = Lua ? Lua->GetL() : nullptr;

		if (L == nullptr)
		{
			UE_LOG(LogAzure, Error, TEXT("OnPrtc_KeyExchange: lua_State is NIL!"));
			check(L != nullptr);
			return false;
		}

		//	Notify Client!
		lua_getglobal(L, "OnPrtc_KeyExchange");
		Lua->Call(0);

		RecordProtoToDebugger(&prtc, false);

		//Octets outKey = new Octets();
		//ECGameSession AzureGameSession = ECGameSession.Instance();
		//outKey = GenerateKey(Nonce, prtc.nonce, outKey);
		//NetMan.SetOSecurity(NetMan.GetSession(), "ARCFOURSECURITY", outKey);

		//GNET::Security random = GNET::Security::Create("RANDOM");
		GNET::Random random;
		random.Update(prtc.nonce.resize(16));
		Octets inKey;
		inKey = GenerateKey(Nonce, prtc.nonce, inKey);
		NetMan.SetISecurity(NetMan.GetSession(), GNET::DECOMPRESSSECURITY, inKey);
		SendNetData(&prtc);
		RecordProtoToDebugger(&prtc, true);

		return true;
	}

	Octets GenerateKey(Octets password, Octets nonce, Octets key)
	{
		GNET::HMAC_MD5Hash hash;
		hash.SetParameter(password);
		hash.Update(nonce);
		return hash.Final(key);
 	}

//	astring GenerateDeviceInfo()
//	{
//		//astring platform(TCHAR_TO_ANSI(AzurePlatformConfig::Get().GetPlatform()));
//		astring device_model(TCHAR_TO_ANSI(FAzureSystemInfo::deviceModel()));
//		astring device_name(TCHAR_TO_ANSI(FAzureSystemInfo::deviceName()));
//		astring device_type(TCHAR_TO_ANSI(FAzureSystemInfo::deviceTypeName()));
//		astring device_unique_identifier(TCHAR_TO_ANSI(FAzureSystemInfo::deviceUniqueIdentifier()));
//		astring operating_system(TCHAR_TO_ANSI(FAzureSystemInfo::operatingSystem()));
//		astring processor_count(TCHAR_TO_ANSI(*FString::FromInt(FAzureSystemInfo::processorCount())));
//		astring system_memory_size(TCHAR_TO_ANSI(*FString::FromInt(FAzureSystemInfo::systemMemorySize())));
//
//#if PLATFORM_WINDOWS
//#else
//#if defined(USE_ZULONGGCLOUD) && ENABLE_TSSSDK && (PLATFORM_ANDROID || PLATFORM_IOS)
//		struct OneSDKTssSdkAntiDataInfo *anti_data = (struct OneSDKTssSdkAntiDataInfo *) TssSDKGetReportData2();
//		if (anti_data != NULL)
//		{
//			Sec_report_data = (const char*)anti_data->AntiData;
//		}
//#endif //ENABLE_TSSSDK
//#endif
//		
//
//		astring strInfo;
//		strInfo += "\"{";
//		strInfo += "\"appid\":\"" + Appid + "\",";
//		strInfo += "\"client_version\":\"" + Client_version + "\",";
//		strInfo += "\"client_res_version\":\"" + Client_res_version + "\",";
//		strInfo += "\"channel_id\":\"" + Channel_id + "\",";
//		strInfo += "\"sdk_device_id\":\"" + Sdk_device_id + "\",";	
//		strInfo += "\"platform\":\"" + Platform + "\",";
//		strInfo += "\"device_model\":\"" + device_model + "\",";
//		strInfo += "\"device_name\":\"" + device_name + "\",";
//		strInfo += "\"device_type\":\"" + device_type + "\",";
//		strInfo += "\"device_unique_identifier\":\"" + device_unique_identifier + "\",";
//		strInfo += "\"operating_system\":\"" + operating_system + "\",";
//		strInfo += "\"processor_count\":\"" + processor_count + "\",";
//		strInfo += "\"system_memory_size\":\"" + system_memory_size + "\",";
//		strInfo += "\"mac\":\"" + Mac + "\",";
//		strInfo += "\"time_zone\":\"" + Time_zone + "\",";
//		strInfo += "\"ext\":\"\",";
//		strInfo += "\"sec_report_data\":\"" + Sec_report_data + "\",";
//		strInfo += "\"reg_channel_dis\":\"" + Reg_channel_dis + "\",";
//		strInfo += "}\"";
//
//		//	Notify Client!
//		
//
//		return strInfo;
//	}

	void RecordC2SToDebugger(GNET::Command* cmd);
	void RecordProtoToDebugger(GNET::Protocol* proto, bool bC2S);
};
