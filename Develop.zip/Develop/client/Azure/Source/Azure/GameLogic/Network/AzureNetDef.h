﻿#pragma once

#include "CoreMinimal.h"

enum class NETPRTC_PROC_RET
{
	NETPROCRET_FAIL = 0,	//	process fail
	NETPROCRET_SUCC,			//	process successfully
	NETPROCRET_POSTPONE_LOGIC,	//	protocol processing should be postponed for logic reason
	NETPROCRET_FINISH_NOTREMOVE,//	process finished but don't remove this protocol
	NETPROCRET_DELAY_SYNCSERVER,//	process should be delayed to sync server timestamp
};

enum class GP_MOVE_FLAG : uint32
{
	GP_MOVE_NONE		= 0,

	GP_MOVE_DASHSTOP			= 0x00000001, // 疾跑刹车
	GP_MOVE_RUNSTOP				= 0x00000002, // 正常跑刹车
	GP_MOVE_JUMP				= 0x00000004, // 主动起跳，不是被动起跳
	GP_MOVE_QINGGONG			= 0x00000008, // (reserved)
	GP_MOVE_SWIM				= 0x00000010, // (reserved)
	GP_MOVE_ACTION				= 0x00000020, // 非玩家操作导致的移动，服务器控制移动
	GP_MOVE_KEY					= 0x00000040, // 关键帧，组队跟随的时候队长如果移动距离过近会不转发，但是一些必要的时候为了表现不能省，加上这个标志位，必然会转发，不会被距离过近制裁
	GP_MOVE_WALK				= 0x00000080, // 
	GP_MOVE_POS_NOTIFY			= 0x00000100,
	GP_MOVE_QUICK_FLY			= 0x00000200, // 
	GP_MOVE_KNOCKBACK			= 0x00000400, // (no use)
	GP_MOVE_FACE_DIR			= 0x00000800,
	GP_MOVE_CLIMB				= 0x00001000, // 攀爬 (reserved)
	GP_MOVE_EXTRA_SYNCPOS		= 0x00002000, // (no use)	
	GP_MOVE_CARRIER				= 0x00004000, // 载具的移动协议
	GP_MOVE_SEND_SELF			= 0x00008000, // 这个移动也发给自己（服务器用） 
	GP_MOVE_FACE_DIR_EX			= 0x00010000, // 含有pitch，roll角度同步
	GP_MOVE_LANDING				= 0x00020000, // 
	GP_MOVE_GLOBAL_CO_SYS		= 0x00040000, // 使用绝对坐标值，如果有相对坐标
	GP_MOVE_BLINK				= 0x00080000, // 瞬移
	GP_REGION_LANDING			= 0x00100000, // 副本特定区域跳转
	GP_MOVE_SELF_PITCH_ANGLE	= 0x00200000, // 俯仰角，自身用
	GP_MOVE_MOUNT_GOTO_PLAYER	= 0x00400000,  //坐骑跑向玩家
	GP_MOVE_FLY					= 0x00800000,  // 飞行
	GP_MOVE_ASCEND				= 0x01000000,  // 上升 GROUND->FLY
	GP_MOVE_DESCEND				= 0x02000000,  // 下降 FLY->GROUND
	GP_MOVE_SHORT_JUMP			= 0x04000000,  // 服务器同场景跳转
	GP_MOVE_HOOK				= 0x08000000,  // 钩爪
	GP_MOVE_DEATH_LANDING		= 0x10000000,  // 空中死亡落地
};

enum class GP_MOVE_FLAG_EXTEND : uint32 //作为GP_MOVE_FLAG的补充，用来传递客户端表现用的旗标
{
	GP_MOVE_EXTEND_NONE = 0,

	GP_MOVE_EXTEND_JUMPSTART_FALL	= 0x00000001, // 被动进下落，不是主动起跳进的下落状态
	GP_MOVE_EXTEND_JUMPPING			= 0x00000002, // 跳跃中同步协议
	GP_MOVE_EXTEND_FORCE_SYNC_POS	= 0x00000004, // 技能等强制同步位置
	GP_MOVE_EXTEND_RELEASE_INPUT	= 0x00000008, // 移动时松开按键的那一刻
	GP_MOVE_EXTEND_INPUT			= 0x00000010, // 是否按着输入键
	GP_MOVE_EXTEND_ROOTMOTION		= 0x00000020, // 正常跑和疾跑的刹车动作，刹车180度转向用，动作都是rootmotion
	GP_MOVE_EXTEND_PREPARE_JUMP		= 0x00000040, // 准备跳
	GP_MOVE_EXTEND_START_MOVE		= 0x00000080, // 开始移动
	GP_MOVE_EXTEND_Walk				= 0x00000100, // 慢走
	GP_MOVE_EXTEND_Dash				= 0x00000200, // 疾跑
	GP_MOVE_EXTEND_STOP				= 0x00000400, // 移动结束，停住
	GP_MOVE_EXTEND_HasDesiredYaw	= 0x00000800, // 带有目标转向角，坐骑用
};

enum class GP_TURN_FLAG : uint32
{
	GP_TURN				= 0x00000001,
	GP_TURN_STOP		= 0x00000002,
	GP_TURN_PITCH_ANGLE = 0x00000004,
	GP_TURN_BLINK		= 0x00000008
};

class ID_FILTER
{
public:

	static constexpr uint64 OBJPREFLAG_PLAYER = 0x0;
	static constexpr uint64 OBJPREFLAG_NPC = 0x0100000000000000;
	static constexpr uint64 OBJPREFLAG_MATTER = 0x0200000000000000;
	static constexpr uint64 OBJPREFLAG_SUBOBJ = 0x0300000000000000;
	static constexpr uint64 OBJPREFLAG_DYNBLD = 0x0400000000000000;

	static constexpr uint64 OBJPREFLAG_SCENEMODELPROXY = 0x8000000000000000; // client only,

	static constexpr uint64 OBJPREFLAG_ALL = 0xFF00000000000000;
};
