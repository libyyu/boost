﻿#pragma once
#include <map>
#include <mutex>
#include "cxxstd.h"
#include "NetClient.h"
#include "gnetdef.h"
#include "CallID.h"
#include "Protocols/KeepAlive.h"
#include "Protocols/MarshalData.h"
#include "Protocols/CommonData.h"
#include "Protocols/GameDataSend.h"

#include "CoreMinimal.h"
#include "AzureCommand.h"

namespace GNET
{
	class GameClient : public NetClient
	{
		enum STATE
		{
			STATE_CLOSED,
			STATE_CONNECTING,
			STATE_KEEPING,
		};

	public:
		GameClient()
			:LastSendAlive(m_lastsend), LastRecvAlive(m_lastrecv), Ping(m_ping)
		{}

	public:

	private:
		int m_zoneid = 0;

		std::mutex locker;

		Octets m_nonce;
		STATE m_state = STATE_CLOSED;

		unsigned int m_lastsend = 0;
		unsigned int m_lastrecv = 0;

	public:
		unsigned int& LastSendAlive;
		unsigned int& LastRecvAlive;
		unsigned int LastRecvAnyProtocal = 0;

	private:
		unsigned int m_ping = 0;
	public:
		const unsigned int& Ping;

	public:

		Session::ID GetSession() { return m_session; }

	protected:
		virtual void OnAddSession(Session::ID session) override;
		virtual void OnDelSession(Session::ID session) override;

		virtual void OnAbortSession(Session::ID session) override
		{
			std::lock_guard<std::mutex> lock(locker);
			{
				if(m_session != session) return;

				if (m_callback != 0 && m_state == STATE::STATE_CONNECTING /*&& this.session == session*/)
					m_callback(0, session, EVENT::EVENT_ABORTSESSION);

				m_session = 0;

			}
		}
		public:
			const Session::State *GetInitState() const;

			virtual astring Identification() const override
			{
				return "GameClient";
			}
			/*virtual int  PriorPolicy(Protocol::Type type) const override
			{
				return 1;
			}
			virtual bool InputPolicy(Protocol::Type type, size_t size) const override
			{
				return true;
			}*/
			virtual void OnCheckAddress(SockAddr &) const { }

			bool SendProtocol(Protocol *protocol)
			{
				return (m_session != 0) && Send(m_session, protocol);
			}

			virtual void OnRecvProtocol(Session::ID session, Protocol *protocol) override
			{
				try
				{
					std::lock_guard<std::mutex> lock(locker);
					{
						if (m_session == session)
						{
							LastRecvAnyProtocal = cxxstd::GetTickCount();

							if (protocol->GetType() == KeepAlive::PROTOCOL_TYPE)
							{
								m_lastrecv = cxxstd::GetTickCount();
								m_ping = m_lastrecv - m_lastsend;
								//KeepAlive.LastReceive = EntryPoint.CurTime;
								//KeepAlive.IsSending = false;
#if !UE_BUILD_SHIPPING	//debug no KeepAlive disconnect

								CommonData *p = (CommonData*)protocol;
								Marshal::OctetsStream os;
								p->marshal(os);
								KeepAlive ka;
								ka.unmarshal(os);
								os.clear();
								
								//UE_LOG(LogTemp, Log, TEXT("Recv_KeepAlive code:%d"), ka.code);
#endif
								protocol->Destroy();
							}
							else if (protocol->GetType() == NetProtocolType::PROTOCOL_MARSHALDATA)
							{
								CommonData *p = (CommonData*)protocol;
								MarshalData md;

								md.unmarshal(*p->GetStreamData());

								Protocol *prtc = Protocol::DecodeMarshal(md.data);
								protocol->Destroy();
								if (prtc != nullptr)
									m_callback(prtc, session, (EVENT)WM::WM_IOPROTOCOL);
							}
							else
							{
								m_callback(protocol, session, (EVENT)WM::WM_IOPROTOCOL);
							}
						}
					}
				}
				catch (Marshal::Exception)
				{
					UE_LOG(LogTemp, Warning, TEXT("OnRecvProtocol: Marshal Exception!"));
				}
				catch (Protocol::Exception)
				{
					UE_LOG(LogTemp, Warning, TEXT("OnRecvProtocol: Protocol Exception!"));
				}
				catch (...)
				{
					UE_LOG(LogTemp, Warning, TEXT("OnRecvProtocol: Other Exception!"));
				}
			}

			bool SendCommand(const Command& cmd)
			{
				GameDataSend p;
				EncodeCommand(cmd, p.data);
				return SendProtocol(&p);
			}

			static void EncodeCommand(const Command& cmd, Octets& oct)
			{
				AzureBinaryWriter bw;
				unsigned short type = (unsigned short)cmd.getCommandType();
				bw.Write(type);
				cmd.marshal(bw);
				oct.swap(bw.GetData());
			}

			void SetZoneID(int zoneid)
			{
				m_zoneid = zoneid;
			}

			int GetZoneID()
			{
				return m_zoneid;
			}

			astring GetPeer()
			{
				return HostName;
			}

			void Disconnect(bool bShowErr = true)
			{
				Session::ID cur_session = m_session;
				Close(cur_session);

				if (m_callback != nullptr && cur_session != 0)
					m_callback(0, cur_session, bShowErr ? EVENT::EVENT_DISCONNECT : EVENT::EVENT_DISCONNECT_ACTIVE);

				m_session = 0;
				m_state = STATE::STATE_CLOSED;
				m_lastsend = m_lastrecv = 0;
				LastRecvAnyProtocal = 0;
			}

			Session::ID ConnectTo(const astring& hostname, int port)
			{
				HostName = hostname;
				Port = port;
				return Protocol::Client(this, hostname.c_str(), port);
			}

			Session::ID Connect(const astring& host, int port)
			{
				if (m_state != STATE::STATE_CLOSED)
					Disconnect();
				m_state = STATE::STATE_CONNECTING;
				return ConnectTo(host, port);
			}
	};
}
