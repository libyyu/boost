﻿// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Navigation/PathFollowingComponent.h"
#include "BMPathFollowingComponent.generated.h"

/**
 *生物矿移动组件
 */
UCLASS()
class AZURE_API UBMPathFollowingComponent : public UPathFollowingComponent
{
	GENERATED_BODY()

	virtual void BeginPlay() override;
};
