// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Components/ActorComponent.h"
#include "Components/SplineComponent.h"
#include "WLua/LuaRegistryRefWrapper.h"
#include "CommonBirdHover.generated.h"


UCLASS( ClassGroup=(Custom), meta=(BlueprintSpawnableComponent) )
class AZURE_API UCommonBirdHover : public UActorComponent
{
	GENERATED_BODY()

public:	
	// Sets default values for this component's properties
	UCommonBirdHover();

protected:
	// Called when the game starts
	virtual void BeginPlay() override;
	virtual void BeginDestroy() override;
public:	
	// Called every frame
	virtual void TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction) override;

	UPROPERTY(EditAnywhere)
	TArray<USplineComponent *> splineComponentList;

	UFUNCTION()
		int GetCurveCount()
	{
		return splineComponentList.Num();
	}

	UFUNCTION(BlueprintCallable)
	void Start(int curveIndex);
	void Start(int curveIndex, FTransform orginTransform, bool isLoop = false,  float startTime = 0.0f, TSharedPtr<LuaRegistryRefWrapper> luaCallbackRef = nullptr);

	UFUNCTION()
	void Stop();

private:

	float curPlayTime = 0;

	bool playing = false;

	bool isLoop = false;

	TWeakObjectPtr<USplineComponent> curSplineCom;

	FTransform originTransform;

	void TickCurveMove(float detalTime);

	void OnComplete();


	TSharedPtr<LuaRegistryRefWrapper> moveCompletedLuaCBPtr = nullptr;
};
