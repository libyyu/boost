// Fill out your copyright notice in the Description page of Project Settings.

#include "BiologicalMineController.h"
#include "BMPathFollowingComponent.h"
#include "AzureEntryPoint.h"
ABiologicalMineController::ABiologicalMineController(const FObjectInitializer & ObjectInitializer)
	: Super(ObjectInitializer.SetDefaultSubobjectClass<UBMPathFollowingComponent>(TEXT("PathFollowingComponent")))
{
}

void ABiologicalMineController::OnMoveCompleted(FAIRequestID RequestID, const FPathFollowingResult & Result)
{
	Super::OnMoveCompleted(RequestID, Result);
	if (moveCompletedLuaCallBack && RequestID == completedCallBackRequestID)
	{
		TSharedPtr<LuaRegistryRefWrapper> tempCompletedLuaCallBack = moveCompletedLuaCallBack;
		moveCompletedLuaCallBack = nullptr;

		if (!AAzureEntryPoint::Instance)
			return;

		lua_State_Wrapper temp_L = AAzureEntryPoint::Instance->GetL();
		if (temp_L)
		{
			tempCompletedLuaCallBack->PushToStack();
			lua_pushnumber(temp_L, Result.Code);
			AAzureEntryPoint::Instance->GetWLua()->Call(1);
		}

	}
}

void ABiologicalMineController::RegisterMoveCompletedCB(FAIRequestID RequestID, TSharedPtr<LuaRegistryRefWrapper> callBack)
{
	completedCallBackRequestID = RequestID;
	moveCompletedLuaCallBack = callBack;
}


EPathFollowingRequestResult::Type ABiologicalMineController::MoveToLocationEX(const FVector& Dest, float AcceptanceRadius, bool bStopOnOverlap, bool bUsePathfinding, bool bProjectDestinationToNavigation, bool bCanStrafe, TSubclassOf<UNavigationQueryFilter> FilterClass, bool bAllowPartialPaths, uint32 &reqID)
{
	auto PathFollowingComponent = GetPathFollowingComponent();
	// abort active movement to keep only one request running
	if (PathFollowingComponent && PathFollowingComponent->GetStatus() != EPathFollowingStatus::Idle)
	{
		PathFollowingComponent->AbortMove(*this, FPathFollowingResultFlags::ForcedScript | FPathFollowingResultFlags::NewRequest
			, FAIRequestID::CurrentRequest, EPathFollowingVelocityMode::Keep);
	}

	FAIMoveRequest MoveReq(Dest);
	MoveReq.SetUsePathfinding(bUsePathfinding);
	MoveReq.SetAllowPartialPath(bAllowPartialPaths);
	MoveReq.SetNavigationFilter(*FilterClass ? FilterClass : DefaultNavigationFilterClass);
	MoveReq.SetAcceptanceRadius(AcceptanceRadius);
	MoveReq.SetReachTestIncludesAgentRadius(bStopOnOverlap);
	MoveReq.SetCanStrafe(bCanStrafe);
	MoveReq.SetProjectGoalLocation(bProjectDestinationToNavigation);
	FPathFollowingRequestResult result = MoveTo(MoveReq);
	reqID = result.MoveId;
	return result.Code;
}

void ABiologicalMineController::BeginDestroy()
{
	moveCompletedLuaCallBack = nullptr;
	Super::BeginDestroy();
}
