// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Character.h"
#include "wLua/LuaInterface.h"
#include "BiologicalMine.generated.h"

UCLASS()
class AZURE_API ABiologicalMine : public ACharacter
{
	GENERATED_BODY()

public:
	// Sets default values for this character's properties
	ABiologicalMine();

protected:
	// Called when the game starts or when spawned
	virtual void BeginPlay() override;
	virtual void BeginDestroy() override;
public:	
	// Called every frame
	virtual void Tick(float DeltaTime) override;

	// Called to bind functionality to input
	virtual void SetupPlayerInputComponent(class UInputComponent* PlayerInputComponent) override;

	virtual void OnMovementModeChanged(EMovementMode PrevMovementMode, uint8 PreviousCustomMode) override;

	void InitLuaInterfaceRef(wLua::lua_registry_handle ObjRef);
	void UnRef();

private:
	wLua::lua_registry_handle m_LuaInterfaceTable;
};
