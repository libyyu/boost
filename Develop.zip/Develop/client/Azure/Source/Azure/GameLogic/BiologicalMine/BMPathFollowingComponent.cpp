// Fill out your copyright notice in the Description page of Project Settings.

#include "BMPathFollowingComponent.h"

void UBMPathFollowingComponent::BeginPlay()
{
	Super::BeginPlay();
	// �����Ǵ�ֱ����
	SetPreciseReachThreshold(1.0f, 1000.0f);
}
