// Fill out your copyright notice in the Description page of Project Settings.

#include "CommonBirdHover.h"
#include "AzureEntryPoint.h"
// Sets default values for this component's properties
UCommonBirdHover::UCommonBirdHover()
{
	// Set this component to be initialized when the game starts, and to be ticked every frame.  You can turn these features
	// off to improve performance if you don't need them.
	PrimaryComponentTick.bCanEverTick = true;

	// ...
}


// Called when the game starts
void UCommonBirdHover::BeginPlay()
{
	Super::BeginPlay();
	GetOwner()->GetComponents<USplineComponent>(splineComponentList);
	//��֤˳��
	splineComponentList.Sort([](const USplineComponent& A, const USplineComponent& B)
	{
		return A.GetName().Compare(B.GetName());
	});
}

void UCommonBirdHover::BeginDestroy()
{
	moveCompletedLuaCBPtr = nullptr;
	splineComponentList.Empty();
	Super::BeginDestroy();
}


// Called every frame
void UCommonBirdHover::TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction)
{
	Super::TickComponent(DeltaTime, TickType, ThisTickFunction);

	
	TickCurveMove(DeltaTime);
}



void UCommonBirdHover::Start(int curveIndex)
{
	FTransform transform = GetOwner()->GetActorTransform();
	auto rotator = transform.GetRotation().Rotator();
	rotator.Pitch = 0;
	rotator.Roll = 0;
	transform.SetRotation(rotator.Quaternion());

	Start(curveIndex, transform);
}

void UCommonBirdHover::Start(int curveIndex, FTransform _orginTransform, bool _isLoop, float startTime, TSharedPtr<LuaRegistryRefWrapper> luaCallbackRef)
{
	USplineComponent * spComp = splineComponentList[curveIndex];
	if (!spComp) return;
	FTransform spCompRelationTransform(spComp->RelativeRotation, spComp->RelativeLocation, spComp->RelativeScale3D);
	originTransform = spCompRelationTransform * _orginTransform;
	isLoop = _isLoop;

	this->curSplineCom = spComp;
	curPlayTime = isLoop ? FMath::Fmod(startTime, spComp->Duration) : startTime;
	playing = true;

	moveCompletedLuaCBPtr = luaCallbackRef;
}


void UCommonBirdHover::Stop()
{
	playing = false;
	isLoop = false;
}

void UCommonBirdHover::TickCurveMove(float DeltaTime)
{
	if (!playing) return;


	auto pos = curSplineCom->GetLocationAtTime(curPlayTime, ESplineCoordinateSpace::Local, true);
	auto rotator = curSplineCom->GetRotationAtTime(curPlayTime, ESplineCoordinateSpace::Local, true);

	pos = originTransform.TransformPosition(pos);
	auto quaternion = originTransform.TransformRotation(rotator.Quaternion());
	GetOwner()->SetActorLocationAndRotation(pos, quaternion);

	curPlayTime += DeltaTime;
	if (curPlayTime >= curSplineCom->Duration)
	{
		if (isLoop)
		{
			curPlayTime = 0;
		}
		else
		{
			OnComplete();
		}
	}
}

void UCommonBirdHover::OnComplete()
{
	playing = false;

	if (moveCompletedLuaCBPtr.IsValid())
	{
		if (!AAzureEntryPoint::Instance)
			return;

		lua_State_Wrapper L = AAzureEntryPoint::Instance->GetL();
		if (L)
		{
			moveCompletedLuaCBPtr->PushToStack();
			AAzureEntryPoint::Instance->GetWLua()->Call(0);
			moveCompletedLuaCBPtr = nullptr;
		}
	}
}








