// Fill out your copyright notice in the Description page of Project Settings.

#include "BiologicalMine.h"
#include "Azure/AzureEntryPoint.h"
// Sets default values
ABiologicalMine::ABiologicalMine()
{
 	// Set this character to call Tick() every frame.  You can turn this off to improve performance if you don't need it.
	PrimaryActorTick.bCanEverTick = true;

}

// Called when the game starts or when spawned
void ABiologicalMine::BeginPlay()
{
	Super::BeginPlay();
	
}

void ABiologicalMine::BeginDestroy()
{
	Super::BeginDestroy();
	UnRef();
}

// Called every frame
void ABiologicalMine::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);

}

// Called to bind functionality to input
void ABiologicalMine::SetupPlayerInputComponent(UInputComponent* PlayerInputComponent)
{
	Super::SetupPlayerInputComponent(PlayerInputComponent);

}

void ABiologicalMine::OnMovementModeChanged(EMovementMode PrevMovementMode, uint8 PreviousCustomMode)
{
	Super::OnMovementModeChanged(PrevMovementMode, PreviousCustomMode);
	if (m_LuaInterfaceTable.IsNoRef()) 
		return;

	if (!AAzureEntryPoint::Instance)
		return;

	lua_State_Wrapper L = AAzureEntryPoint::Instance->GetL();
	lua_rawgeti(L, LUA_REGISTRYINDEX, m_LuaInterfaceTable); // t
	lua_getfield(L, -1, "OnMovementModeChanged"); //t,f
	if (!lua_isfunction(L, -1))
	{
		lua_pop(L, 2);
		return;
	}
	///
	lua_pushvalue(L, -2);//t,f,t
	lua_pushinteger(L, PrevMovementMode);//t,f,t,i
	lua_pushinteger(L, PreviousCustomMode);//t,f,t,i,i
	AAzureEntryPoint::Instance->GetWLua()->PCall(3, 0);//t
	lua_pop(L, 1);
}


void ABiologicalMine::InitLuaInterfaceRef(wLua::lua_registry_handle ObjRef)
{
	UnRef();
	m_LuaInterfaceTable = ObjRef;
}

void ABiologicalMine::UnRef()
{
	if (!m_LuaInterfaceTable.IsNoRef())
	{
		if (AAzureEntryPoint::IsInit())
		{
			lua_State_Wrapper L = AAzureEntryPoint::Instance->GetL();
			wLua::lua_registry_handle::wlua_unref(L, LUA_REGISTRYINDEX, m_LuaInterfaceTable);
		}

		m_LuaInterfaceTable.Clear();
	}
}

