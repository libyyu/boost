// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "AIController.h"
#include "wLua/LuaInterface.h"
#include "wLua/LuaRegistryRefWrapper.h"
#include "BiologicalMineController.generated.h"

/**
 * 
 */
UCLASS()
class AZURE_API ABiologicalMineController : public AAIController
{
	GENERATED_BODY()

	ABiologicalMineController(const FObjectInitializer& ObjectInitializer);
	

	virtual void OnMoveCompleted(FAIRequestID RequestID, const FPathFollowingResult& Result) override;

public:

	void RegisterMoveCompletedCB(FAIRequestID RequestID, TSharedPtr<LuaRegistryRefWrapper> callBack);

	UFUNCTION()
	EPathFollowingRequestResult::Type MoveToLocationEX(const FVector& Dest, float AcceptanceRadius, bool bStopOnOverlap, bool bUsePathfinding, bool bProjectDestinationToNavigation, bool bCanStrafe, TSubclassOf<UNavigationQueryFilter> FilterClass, bool bAllowPartialPaths, uint32 &reqID);


	virtual void BeginDestroy() override;
private:
	FAIRequestID  completedCallBackRequestID;

	TSharedPtr<LuaRegistryRefWrapper> moveCompletedLuaCallBack;
};
