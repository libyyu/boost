﻿#pragma once

#include "CoreMinimal.h"
#include <ctime>
#include "Materials/MaterialInstanceDynamic.h"

struct CoolDownItem
{
	float CurTime;
	float MaxTime;
};

class AzureTimeManager
{
public:

	static unsigned char MoveStampSn;
	static double ServerDeltaTime;
	double m_dRecvTime = 0;
	int m_iServerTime = 0;
	//int m_iShutDownTime;
	int m_iTimeError = 0;
	int m_iTimeZoneBias = 0;

protected:

	TMap<int, CoolDownItem> CoolDownMap;

public:
	AzureTimeManager()
	{
		std::time_t orgin_seconds = 3600 * 24 * 7;
		std::tm tm_utc = *std::gmtime(&orgin_seconds);
		std::time_t seconds_utc = std::mktime(&tm_utc);
		int dtSeconds = (int)std::difftime(orgin_seconds, seconds_utc);

		Epoch = FDateTime(1970, 1, 1);
		Start = FDateTime::UtcNow();
		DiffTimeToUTC = FTimespan::FromSeconds(dtSeconds);

		LocalEpoch = Epoch; // +DiffTimeToUTC;
		m_iTimeZoneBias = -dtSeconds / 60;
	}

	~AzureTimeManager()
	{
	}

public:

	static FDateTime Epoch;
	static FDateTime LocalEpoch;
	static FTimespan DiffTimeToUTC;
	static FDateTime Start;
	static int64 ChallengeTimeError;

	static AzureTimeManager& GetInstance()
	{
		static AzureTimeManager mgr;
		return mgr;
	}

	//this is more accurate than double value
	static int64 GetSecondsFromEpochL()
	{
		FTimespan dtTime = FDateTime::UtcNow() - Epoch;
		return dtTime.GetTicks() / ETimespan::TicksPerSecond;
	}

	static double GetSecondsFromEpoch()
	{
		FTimespan dtTime = FDateTime::UtcNow() - Epoch;
		return dtTime.GetTotalSeconds();
	}

	static double GetMillisecondsFromEpoch()
	{
		FTimespan dtTime = FDateTime::UtcNow() - Epoch;
		return dtTime.GetTotalMilliseconds();
	}

	static double GetSecondsFromStart()
	{
		FTimespan dtTime = FDateTime::UtcNow() - Start;
		return dtTime.GetTotalSeconds();
	}

	static double GetMillisecondsFromStart()
	{
		FTimespan dtTime = FDateTime::UtcNow() - Start;
		return dtTime.GetTotalMilliseconds();
	}

	static void SetChallengeServerTime(int64 nTime)
	{
		ChallengeTimeError = GetSecondsFromEpochL() - nTime;
	}

	static int64 GetChallengeServerTime()
	{
		return GetSecondsFromEpochL() - ChallengeTimeError;
	}

	void SetServerShutDownTime(int iServerTime, double dRecvTime = 0)
	{
		double dOffset = 0;

		if (dRecvTime != 0)
			dOffset = GetMillisecondsFromEpoch() - dRecvTime;

		//m_iShutDownTime = iServerTime + (int)(dOffset * 0.001 + 0.5);
	}

	void SetServerTime(int iSeverTime, double dRecvTime = 0)
	{
		double dOffset = 0;

		if (dRecvTime == 0)
		{
			m_dRecvTime = GetMillisecondsFromEpoch();
		}
		else
		{
			m_dRecvTime = dRecvTime;
			dOffset = GetMillisecondsFromEpoch() - dRecvTime;
		}

		m_iServerTime = iSeverTime;

		m_iTimeError = iSeverTime + (int)(dOffset * 0.001 + 0.5 - GetSecondsFromEpoch());
	}

	int GetTimeError()
	{
		return m_iTimeError;
	}

	int GetServerGMTTime()
	{
		return (int)GetSecondsFromEpoch() + m_iTimeError;
	}

	FDateTime GetTimeStampDateTime(int iTimeStamp)
	{
		return LocalEpoch + FTimespan::FromSeconds(iTimeStamp);
	}

	int GetServerTimeThisWeek(int dayofweek, int hour, int minute, bool bToUniversalTime)
	{
		FDateTime curtimestamp = GetTimeStampDateTime(GetServerGMTTime());
		int curdayofweek = (int)curtimestamp.GetDayOfWeek();
		int y, m, d;
		curtimestamp.GetDate(y, m, d);
		FDateTime weekstart(y, m, d);
		weekstart -= FTimespan::FromDays(curdayofweek);
		FTimespan timespan(dayofweek - 1, hour, minute, 0);
		FDateTime ret = weekstart + timespan;

		if (bToUniversalTime)
			ret = ret - DiffTimeToUTC;

		return (int)((ret - LocalEpoch).GetTotalSeconds());
	}

	// biasInMinutes: GMT+0800 => -480
	void SetTimeZoneBias(int biasInMinutes)
	{
		m_iTimeZoneBias = biasInMinutes;
	}

	// return: in minutes, GMT+8 => -480
	int GetTimeZoneBias()
	{
		return m_iTimeZoneBias;
	}

	int GetSeverTimeStampDelta()
	{
		return (m_dRecvTime == 0) ? 0 : m_iServerTime + (int)((GetMillisecondsFromEpoch() - m_dRecvTime) / 1000);
	}

	void OnCmd_ServerTimeStamp(double dRecvTime, int time, int shutdown_timestamp);

	void SetCoolDownData(int cdidx, float curtime, float maxtime)
	{
		//Debug.Log("C# - ECTimerManager Set Cool Down Data");
		auto it = CoolDownMap.Find(cdidx);
		if (it != nullptr)
		{
			CoolDownItem& cdi = *it;
			cdi.CurTime = FMath::Clamp(curtime, 0.0f, maxtime);
			cdi.MaxTime = maxtime;
		}
		else
		{
			CoolDownItem cdi;
			cdi.CurTime = FMath::Clamp(curtime, 0.0f, maxtime);
			cdi.MaxTime = maxtime;
			CoolDownMap.Add(cdidx, cdi);
		}
	}

	void UpdateCoolDownData(int cdidx, float curtime)
	{
		auto it = CoolDownMap.Find(cdidx);
		if (it != nullptr)
		{
			CoolDownItem& cdi = *it;
			cdi.CurTime = FMath::Clamp(curtime, 0.0f, cdi.MaxTime);
		}
		else
		{
			CoolDownItem cdi;
			cdi.CurTime = curtime;
			cdi.MaxTime = curtime;
			CoolDownMap.Add(cdidx, cdi);
		}
	}

	const CoolDownItem* GetCoolDownData(int idx) const
	{
		auto it = CoolDownMap.Find(idx);
		return it;
	}

	void ClearCoolDownData()
	{
		CoolDownMap.Empty();
	}

	bool Tick(float fDeltaTime)
	{
		if (CoolDownMap.Num() > 0)
		{
			float nextTime;

			for (auto it : CoolDownMap)
			{
				//	it.Value is a copy! use find
				CoolDownItem* item = CoolDownMap.Find(it.Key);
				if (item == nullptr)
					continue;
				if (item->CurTime <= 0)
					continue;
				nextTime = item->CurTime - fDeltaTime;
				item->CurTime = nextTime > 0.0f ? nextTime : 0.0f;
			}
		}

		return true;
	}
};
