#include "AzureTimeManager.h"
#include "AzureEntryPoint.h"

extern wLua::Lua* AAzureEntryPoint_GetWLua();

unsigned char AzureTimeManager::MoveStampSn = 0;
double AzureTimeManager::ServerDeltaTime = 0;

FDateTime AzureTimeManager::Epoch;
FDateTime AzureTimeManager::LocalEpoch;
FTimespan AzureTimeManager::DiffTimeToUTC;
FDateTime AzureTimeManager::Start;
int64 AzureTimeManager::ChallengeTimeError = 0;

void AzureTimeManager::OnCmd_ServerTimeStamp(double dRecvTime, int time, int shutdown_timestamp)
{
	SetServerTime(time, dRecvTime);

	if (shutdown_timestamp == 0)
		SetServerShutDownTime(0);
	else
		SetServerShutDownTime(shutdown_timestamp, dRecvTime);

	//֪ͨ lua
	wLua::Lua* wlua = AAzureEntryPoint_GetWLua();
	if (wlua)
	{
		lua_State_Wrapper L = wlua->GetL();
		lua_getglobal(L, "OnSetServerTime");
		if (lua_isfunction(L, -1))
			wlua->Call(0);
		else
			lua_pop(L, 1);
	}
}
