#pragma once

#include "CoreMinimal.h"
#include "HAL/Runnable.h"

class DeadLockDetector : public FRunnable
{
	DeadLockDetector();
	virtual ~DeadLockDetector() {}

public:

	static DeadLockDetector& instance();
	void Start(float threshhold, float interval, bool crashOnDeadLock, bool enableANRCheck);
	void ForceStop();
	void SetActive(bool bActive);
	void Update();
	bool IsRunning() const;

	// ANR detect
	void BeginANRCheck();
	void EndANRCheck();

private:

	uint32 Run() override;
	void Stop() override;
	FRunnableThread* m_Thread = nullptr;
};
