#include "ScreenInfo.h"
#include "GameFramework/GameUserSettings.h"
#include "PlatformApplicationMisc.h"
#include "Engine.h"
#include "Slate/SceneViewport.h"

EWindowMode::Type FScreenInfo::GetFullScreenMode()
{
	return GSystemResolution.WindowMode;
}

float FScreenInfo::dpi()
{
	return FPlatformApplicationMisc::GetDPIScaleFactorAtPoint(0.f, 0.f);
}

int32 FScreenInfo::width()
{
	return GSystemResolution.ResX;
}
int32 FScreenInfo::height()
{
	return GSystemResolution.ResY;
}

void FScreenInfo::SetResolutionAndFullscreenMode(int32 width, int32 height, EWindowMode::Type fullscreenMode)
{
	UGameUserSettings *GameUserSettings = UGameUserSettings::GetGameUserSettings();
	if (GameUserSettings)
	{
		GameUserSettings->SetScreenResolution(FIntPoint(width, height));
		GameUserSettings->SetFullscreenMode(fullscreenMode);
		GameUserSettings->ApplyResolutionSettings(false);
	}
}

FIntPoint FScreenInfo::GetDesktopResolution()
{
	UGameUserSettings *GameUserSettings = UGameUserSettings::GetGameUserSettings();
	if (GameUserSettings)
	{
		return GameUserSettings->GetDesktopResolution();
	}
	else
	{
		return FIntPoint(0, 0);
	}
}

void FScreenInfo::SetAspectRatioLimit(FFloatInterval const& value)
{
	GEngine->GameViewport->GetWindow()->GetNativeWindow()->SetAzureAspectRatioLimit(value);
}

FFloatInterval FScreenInfo::GetAspectRatioLimit()
{
	return GEngine->GameViewport->GetWindow()->GetNativeWindow()->GetAzureAspectRatioLimit();
}

