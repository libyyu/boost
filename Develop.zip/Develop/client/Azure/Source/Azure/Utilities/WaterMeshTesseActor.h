// Fill out your copyright notice in the Description page of Project Settings.
/* waterMesh����ϸ���㷨���ο�pbrt3.7��
 * �򻯣����㲻��Ҫ����λ�ã������¼Ӷ���ֻ��ҪȡEdge�е㼴��
 * �¼��߼�������Ӧϸ������Ҫ�������������νӷ�
 */

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "WaterMeshTesseActor.generated.h"

class UProceduralMeshComponent;

struct SDFace;
struct SDFace;
#define EpsilonEqual 0.0001f
#define MapBlockSize 50800.0f
struct SDVertex {
	// SDVertex Constructor
	SDVertex()
		: P(FVector::ZeroVector), TesseLevel(0), edge(false) { }
	SDVertex(FVector pt)
		: P(pt), TesseLevel(0), edge(false)
	{
		edge = pt.X<-EpsilonEqual || pt.Y < -EpsilonEqual ||
			pt.X>(MapBlockSize - EpsilonEqual) || pt.Y>(MapBlockSize - EpsilonEqual);
	}


	bool operator==(const SDVertex& v) const
	{
		return (v.P-P).SizeSquared() < EpsilonEqual;
	}
	FVector P;
	FColor C;
	FVector2D Uv0;
	FVector2D Uv1;
	int TesseLevel;
	int index;
	bool edge;
};

struct SDFace {
	// SDFace Constructor
	SDFace() {
		for (int i = 0; i < 4; ++i)
			children[i] = NULL;
	}
	~SDFace()
	{
		for (int i = 0; i < 4; ++i)
		{
			if (children[i])
			{
				delete children[i];
				children[i] = NULL;
			}
		}
	}

	void ClearChildren()
	{
		for (int i = 0; i < 4; ++i)
		{
			if (children[i])
			{
				delete children[i];
				children[i] = NULL;
			}
		}
	}

	int index[3];
	SDFace *children[4];
};

struct FMapBlock
{
	bool IsInBlock(float x, float y)
	{
		return x > MinX && x<MaxX && y>MinY && y < MaxY;
	}
	FMapBlock(int x, int y)
	{
		PosX = x;
		PosY = y;
		MinX = PosX * MapBlockSize - 0.1f;
		MaxX = (PosX + 1) * MapBlockSize + 0.1f;
		MinY = PosY * MapBlockSize - 0.1f;
		MaxY = (PosY + 1) * MapBlockSize + 0.1f;
		Pos.X = PosX * MapBlockSize;
		Pos.Y = PosY * MapBlockSize;
		Pos.Z = 0.0f;
	}
	// block pos
	int PosX;
	int PosY;
	float MinX;
	float MaxX;
	float MinY;
	float MaxY;
	FVector Pos;

	// Raw Mesh Data
	TWeakObjectPtr<UMaterialInterface> Material;
	TArray<SDVertex> OrigVertexes;
	TArray<SDFace> OrigFaces;
	TArray<SDVertex> TesseVertexes;
	TArray<SDFace> TesseFaces;
	TWeakObjectPtr<UProceduralMeshComponent> DMesh;
};

USTRUCT(BlueprintType)
struct FTesseLevel
{
	GENERATED_BODY()
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = Param, meta = (DisplayName = "dist from camera"))
	float DistCamera;		// �������������
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = Param, meta = (DisplayName = "Mesh cell size"))
	float TesseMinEdge;		// ϸ�ֵ�����С���룬����������������ϸ��
};

UCLASS()
class AZURE_API AWaterMeshTesseActor : public AActor
{
	GENERATED_BODY()
	
public:	
	// Sets default values for this actor's properties
	AWaterMeshTesseActor();

	UFUNCTION(BlueprintCallable, Category = "Update")
	int UpdateTesseMesh(FVector pos);

	void AddMapBlock(int x, int y, UStaticMesh* StaticMesh);
	void RemoveMapBlock(int x, int y);
	void TesseDataDirty();
	void MapBlockChanged();

protected:
	// Called when the game starts or when spawned
	virtual void BeginPlay() override;
	void Tessellate(FVector pos);
	bool NeedTesse(const SDVertex& v0, const SDVertex& v1);
	int PointTesseLevel(FVector PosCenter, FVector PosTest);

public:	
	// Called every frame
	virtual void Tick(float DeltaTime) override;

	UPROPERTY(EditAnywhere)
	USceneComponent* Root;
	UPROPERTY(EditAnywhere)
	TArray<UProceduralMeshComponent*> DMeshes;
	UPROPERTY(EditAnywhere)
	UProceduralMeshComponent* DMeshBound;
	UPROPERTY(EditAnywhere)
	UMaterialInterface* MaterialBound;

	UPROPERTY(EditAnywhere)
	float TesseUpdateInterval;
	UPROPERTY(EditAnywhere)
	float TesseUpdateTimer;
	UPROPERTY(EditAnywhere)
	float TesseDistance;
	UPROPERTY(EditAnywhere)
	TArray<FTesseLevel> TesseParam;
	UPROPERTY(EditAnywhere)
	float BorderSize;

	// ԭʼMesh����
	TArray<FMapBlock> MapBlockRawData;
	FBox2D MapBlockBox2D;

	FVector CameraPos;

	// TestCode 
	UPROPERTY(EditAnywhere)
	int IterCountMax = 10;
	// TestCodeEnd

	static const int MAX_MAPBLOCK = 9;
};
