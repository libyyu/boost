// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "RegionWallActor.generated.h"

USTRUCT()
struct FRegionWallData
{
	GENERATED_USTRUCT_BODY()
public:

	UPROPERTY(VisibleAnywhere  , Category="区域墙")
	FVector Begin;

	UPROPERTY(VisibleAnywhere  , Category="区域墙")
	FVector End;

	UPROPERTY(VisibleAnywhere  , Category="区域墙")
	FVector Normal;
	
	UPROPERTY(VisibleAnywhere , Category="区域墙")
	float Yaw;

	UPROPERTY(EditAnywhere , Category="区域墙")
	bool DispNormal = true;
};

class UProceduralMeshComponent;

UCLASS(Blueprintable)
class AZURE_API ARegionWallActor : public AActor
{
	GENERATED_BODY()

public:
	// Sets default values for this character's properties
	ARegionWallActor();

	void InitPolygon(const FVector &location , const TArray<FVector> &points , int32 sceneID , int32 regionID , float wallHeightUpperOffset, float wallHeightBottomOffset, float tileU , float upupV, float upboV, float boupV, float boboV);
	void InitCircle(const FVector &location , int32 sceneID , int32 regionID , float radius , float wallHeightUpperOffset, float wallHeightBottomOffset, float tileU , float upupV, float upboV, float boupV, float boboV, int segNum);

	UFUNCTION(BlueprintNativeEvent , Category = "区域墙,BlueprintFunc")
	UMaterialInterface* GetWallMaterial();
	
	UFUNCTION(BlueprintNativeEvent , Category = "区域墙,BlueprintFunc")
	UMaterialInterface* GetWallMaterial2(int32 p1,int32 p2 ,float p3);

protected:
	virtual void BeginPlay() override;

	UPROPERTY(EditAnywhere , BlueprintReadOnly , Category="区域墙")
	USceneComponent *_SceneComp;

	UPROPERTY(EditAnywhere , BlueprintReadOnly , Category="区域墙")
	TArray<UStaticMeshComponent*> _StaticMeshComps;

	//UPROPERTY(EditAnywhere , BlueprintReadOnly , Category="区域墙")
	//UStaticMeshComponent* _StaticMeshComp_1;
	//UPROPERTY(EditAnywhere , BlueprintReadOnly , Category="区域墙")
	//UStaticMeshComponent* _StaticMeshComp_2;
	//UPROPERTY(EditAnywhere , BlueprintReadOnly , Category="区域墙")
	//UStaticMeshComponent* _StaticMeshComp_3;
	//UPROPERTY(EditAnywhere , BlueprintReadOnly , Category="区域墙")
	//UStaticMeshComponent* _StaticMeshComp_4;
	//UPROPERTY(EditAnywhere , BlueprintReadOnly , Category="区域墙")
	//UStaticMeshComponent* _StaticMeshComp_5;
	//UPROPERTY(EditAnywhere , BlueprintReadOnly , Category="区域墙")
	//UStaticMeshComponent* _StaticMeshComp_6;
	//UPROPERTY(EditAnywhere , BlueprintReadOnly , Category="区域墙")
	//UStaticMeshComponent* _StaticMeshComp_7;
	//UPROPERTY(EditAnywhere , BlueprintReadOnly , Category="区域墙")
	//UStaticMeshComponent* _StaticMeshComp_8;
	//UPROPERTY(EditAnywhere , BlueprintReadOnly , Category="区域墙")
	//UStaticMeshComponent* _StaticMeshComp_9;
	//UPROPERTY(EditAnywhere , BlueprintReadOnly , Category="区域墙")
	//UStaticMeshComponent* _StaticMeshComp_10;

	UPROPERTY(VisibleAnywhere , BlueprintReadOnly , Category="区域墙" , meta=(DisplayName="墙的显示网格"))
	UProceduralMeshComponent* _wallProceduralMeshComp;

	//UPROPERTY(VisibleAnywhere , BlueprintReadOnly , Category="区域墙" , meta=(DisplayName="墙的碰撞网格"))
	//UProceduralMeshComponent* _ColiisionProceduralMeshComp;


	UPROPERTY(EditAnywhere ,BlueprintReadWrite , Category="区域墙",meta=(DisplayName="墙的静态网格"))
	UStaticMesh *_WallStaticMesh;

	UPROPERTY(EditAnywhere , BlueprintReadWrite , Category="区域墙" , meta=(DisplayName="墙的材质"))
	UMaterialInterface* _WallMaterial;

	UPROPERTY(EditAnywhere , Category="区域墙" , meta=(DisplayName="墙的数据"))
	TArray<FRegionWallData> _WallDatas;

	UPROPERTY(EditAnywhere ,  Category="区域墙" , meta=(DisplayName="模型尺寸"))
	FVector MeshSize = FVector::OneVector;

	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "区域墙" , meta = (DisplayName = "默认半透明优先顺序"))
	int32 TranslucencySortPriority = 1;

	UPROPERTY(EditAnywhere ,  Category="区域墙",meta=(DisplayName="默认墙高"))
	float DefaultWallHeight = 500.0f;

	UPROPERTY(EditAnywhere ,  Category="区域墙",meta=(DisplayName="默认墙厚度"))
	float DefaultWallThickness = 5.0f;

	UPROPERTY(EditAnywhere , BlueprintReadOnly , Category="区域墙" , meta=(DisplayName="墙是否可见"))
	bool _WallVisible = false;
	bool _WallVisibleLast = true;

	UPROPERTY(EditAnywhere , BlueprintReadOnly , Category="区域墙" , meta=(DisplayName="阻挡是否有效"))
	bool _EnableCollision = false;
	bool _EnableCollisionLast = true;

	UPROPERTY(EditAnywhere , BlueprintReadOnly , Category="区域墙|调试" , meta=(DisplayName="调试线"))
	bool _DrawDebugLine;

	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "区域墙|调试", meta = (DisplayName = "调试线长度"))
	float _DrawDebugLineLength = 300.0f;

	UPROPERTY(EditAnywhere , BlueprintReadWrite , Category="区域墙|调试" , meta=(DisplayName="调试线色"))
	FColor _LineColor;

	UPROPERTY(EditAnywhere , BlueprintReadWrite , Category="区域墙|调试" , meta=(DisplayName="调试线宽"))
	float LineThickness = 5.0f;

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "区域墙|调试", meta = (DisplayName = "调试显示外立面"))
	bool _outterSide = false; // TA说其实单面网格就可以 用双面材质 双面网格调试时方便看
	
	//UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "区域墙|调试", meta = (DisplayName = "场景ID"))
	int32 _SceneID;		// 仅作标记用
	//UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "区域墙|调试", meta = (DisplayName = "区域ID"))
	int32 _RegionID;	// 仅作标记用

public:
	// Called every frame
	virtual void Tick(float DeltaTime) override;

#if WITH_EDITOR
	virtual void PostEditChangeProperty(FPropertyChangedEvent& PropertyChangedEvent) override;
	virtual void PostEditChangeChainProperty(FPropertyChangedChainEvent& PropertyChangedEvent) override;
#endif

	UFUNCTION(BlueprintCallable,Category = "区域墙,BlueprintFunc")
	void AddWall(const FVector &begin , const FVector &end);
	void AddWall(const FVector &begin , const FVector &end , float wallThickness , float wallHeight);

	float GetDefaultWallThickness() const
	{
		return DefaultWallThickness;
	}

	float GetDefaultWallHeight() const
	{
		return DefaultWallHeight;
	}

	void SetSceneIDRegionID(int32 SceneID , int32 RegionID);

	int32 GetSceneID()
	{
		return _SceneID;
	}
	int32 GetRegionID()
	{
		return _RegionID;
	}

	bool GetDrawDebugLine() const
	{
		return _DrawDebugLine;
	}
	void SetDrawDebugLine(bool val)
	{
		_DrawDebugLine = val;
	}

	bool GetWallVisible() const
	{
		return _WallVisible;
	}
	void SetWallVisible(bool val)
	{
		_WallVisible = val;
	}

	bool GetCollisionEnabled() const
	{
		return _EnableCollision;
	}
	void SetCollisionEnabled(bool val)
	{
		_EnableCollision = val;
	}

	void SetOutterSideEnabled(bool val)
	{
		_outterSide = val;
	}

};
