#include "AzureTextureReadback.h"

//use multiple buffers to allow more time for finish rendering, avoid GPU waiting
static int s_PboBufferCount = 1;
static FAutoConsoleVariableRef CVarPboBufferCount(
	TEXT("r.AzureTRB.PboBufferCount"),
	s_PboBufferCount,
	TEXT("The count of Azure Texture Readback PBO buffers. Use multiple buffers to allow more time for finish rendering, avoid GPU waiting."));

//Readback interval frames. Some mobile device can not finish readback every frame, which introduces gpu stall when call glMapBufferRange
static int s_ReadbackInterval = 1;
static FAutoConsoleVariableRef CVarRenderInterval(
	TEXT("r.AzureTRB.ReadbackInterval"),
	s_ReadbackInterval,
	TEXT("Readback interval frames. 1 means readback every frame."));

DECLARE_STATS_GROUP(TEXT("AzureTRB"), STATGROUP_AzureTRB, STATCAT_Advanced);
DECLARE_STATS_GROUP(TEXT("AzureTRBGL"), STATGROUP_AzureTRBGL, STATCAT_Advanced);

AAzureTextureReadback::AAzureTextureReadback()
	: m_sharedData(new FAzureTextureReadbackSharedData())
{
	PrimaryActorTick.bCanEverTick = true;
}

void AAzureTextureReadback::BeginPlay()
{
	Super::BeginPlay();
}

void AAzureTextureReadback::Tick( float DeltaSeconds )
{
	Super::Tick(DeltaSeconds);

	if (m_bReadbackEnabled && sourceTexture)
	{
		ENQUEUE_RENDER_COMMAND(SceneDrawCompletion)(
			[this](FRHICommandListImmediate& RHICmdList)
		{
			UpdateReadback_RenderThread(RHICmdList);
		});
	}
}

void AAzureTextureReadback::BeginDestroy()
{
	Super::BeginDestroy();

#if HAS_AZURE_OPENGL_PBO
	if (m_PboResource.Num() > 0)
	{
		for (int i=0; i<m_PboResource.Num(); ++i)
			BeginReleaseResource(m_PboResource[i]);
		ReleaseFence.BeginFence();
	}
#endif
}

bool AAzureTextureReadback::IsReadyForFinishDestroy()
{
	return Super::IsReadyForFinishDestroy() && ReleaseFence.IsFenceComplete();
}

void AAzureTextureReadback::FinishDestroy()
{
#if HAS_AZURE_OPENGL_PBO
	for (int i=0; i<m_PboResource.Num(); ++i)
	{
		if (m_PboResource[i])
		{
			delete m_PboResource[i];
			m_PboResource[i] = nullptr;
		}
	}
#endif

	Super::FinishDestroy();
}

bool AAzureTextureReadback::ReadPixel(int iX, int iY, FColor& outColor)
{
	if (m_bReadbackEnabled && sourceTexture)
	{
		int32 width = sourceTexture->GetSurfaceWidth();
		int32 index = iX + iY * width;
		FScopeLock lock(&m_sharedData->dataLock);
		if (index >= 0 && index < m_sharedData->textureDataForGameThread.Num())
		{
			FColor colorValue = m_sharedData->textureDataForGameThread[index];
			if (m_sharedData->dataFliped)
			{
				outColor = FColor(colorValue.B, colorValue.G, colorValue.R, colorValue.A);
			}
			else
			{
				outColor = colorValue;
			}
			return true;
		}
	}
	outColor = FColor::Red;
	return false;
}

void AAzureTextureReadback::EnableReadback(bool bEnabled)
{
	m_bReadbackEnabled = bEnabled;
}

bool AAzureTextureReadback::IsReadbackEnabled()
{
	return m_bReadbackEnabled;
}

#if WITH_EDITOR
void AAzureTextureReadback::PostEditChangeProperty( struct FPropertyChangedEvent& PropertyChangedEvent)
{
	if (PropertyChangedEvent.GetPropertyName() == TEXT("sourceTexture"))
	{
		
	}
}
#endif

void AAzureTextureReadback::UpdateReadback_RenderThread(FRHICommandListImmediate& RHICmdList)
{
	if (!sourceTexture || !sourceTexture->GetRenderTargetResource())
		return;

	if (sourceTexture->GetFormat() != PF_B8G8R8A8)	//current only support BGRA8 for max compatibility
		return;

#if HAS_AZURE_OPENGL_PBO
	if (IsOpenGLPlatform(GMaxRHIShaderPlatform))
	{
		UpdateReadbackOpenGLPBO_RenderThread(RHICmdList);
		return;
	}
#endif

	UpdateReadbackGeneric_RenderThread(RHICmdList);
}

void AAzureTextureReadback::UpdateReadbackGeneric_RenderThread(FRHICommandListImmediate& RHICmdList)
{
	DECLARE_SCOPE_CYCLE_COUNTER(TEXT("AzureTRB_UpdateReadbackGeneric"), STAT_AzureTRB_UpdateReadbackGeneric, STATGROUP_AzureTRB);
	FRenderTarget* RenderTarget = sourceTexture->GetRenderTargetResource();
	int32 width = sourceTexture->GetSurfaceWidth();
	int32 height = sourceTexture->GetSurfaceHeight();
	FIntRect rect(0, 0, width, height);
	RHICmdList.ReadSurfaceData(RenderTarget->GetRenderTargetTexture(), rect, m_sharedData->textureDataForReadback, FReadSurfaceDataFlags());
	{
		FScopeLock lock(&m_sharedData->dataLock);
		Swap(m_sharedData->textureDataForGameThread, m_sharedData->textureDataForReadback);
		m_sharedData->dataFliped = false;
	}
}

#if HAS_AZURE_OPENGL_PBO
void AAzureTextureReadback::UpdateReadbackOpenGLPBO_RenderThread(FRHICommandListImmediate& RHICmdList)
{
	DECLARE_SCOPE_CYCLE_COUNTER(TEXT("AzureTRB_UpdateReadbackOpenGLPBO"), STAT_AzureTRB_UpdateReadback, STATGROUP_AzureTRB);

	if (GFrameNumberRenderThread % s_ReadbackInterval != 0)
		return;

	if (s_PboBufferCount > m_PboResource.Num())
	{
		int addCount = s_PboBufferCount - m_PboResource.Num();
		for (int i=0; i<addCount; ++i)
			m_PboResource.Add(new FAzureOpenGLPBO);
	}

	int iReadbackFrame = GFrameNumberRenderThread / s_ReadbackInterval;
	int pboBufferIndexToStart = iReadbackFrame % s_PboBufferCount;
	int pboBufferIndexToFinish = (pboBufferIndexToStart + s_PboBufferCount - 1) % s_PboBufferCount;	//previous one in cyclic buffer

	int32 width = sourceTexture->GetSurfaceWidth();
	int32 height = sourceTexture->GetSurfaceHeight();
	int dataSize = width * height * sizeof(FColor);

	FAzureOpenGLPBO* pboResourceToFinish = m_PboResource[pboBufferIndexToFinish];
	if (!pboResourceToFinish)
		return;

	FAzureOpenGLPBORef& pboToFinishRHI = pboResourceToFinish->PboRHI;
	if (pboToFinishRHI && pboToFinishRHI->DataSize == dataSize)
	{
		FinishOpenGLPBOReadback_RenderThread(pboToFinishRHI);	//get readback result from last request
	}

	FAzureOpenGLPBO* pboResourceToStart = m_PboResource[pboBufferIndexToStart];
	if (!pboResourceToStart)
		return;

	FAzureOpenGLPBORef& pboToStartRHI = pboResourceToStart->PboRHI;
	if (!pboToStartRHI || pboToStartRHI->DataSize != dataSize)
	{
		pboToStartRHI = new FRHIAzureOpenGLPBO(dataSize, GL_PIXEL_PACK_BUFFER, true);
	}
	StartOpenGLPBOReadback_RenderThread(pboToStartRHI);
}

void AAzureTextureReadback::StartOpenGLPBOReadback_RenderThread(FAzureOpenGLPBORef PboRHI)
{
	//hold reference to rhi resource
	FTexture2DRHIRef renderTargetTexture = sourceTexture->GetRenderTargetResource()->GetRenderTargetTexture();
	AzureRunOnGLRenderContextThread([renderTargetTexture, PboRHI]()
	{
		DECLARE_SCOPE_CYCLE_COUNTER(TEXT("AzureTRBGL_StartOpenGLPBOReadback"), STAT_AzureTRBGL_StartOpenGLPBOReadback, STATGROUP_AzureTRBGL);
		FOpenGLTexture2D const* Texture = (FOpenGLTexture2D const*)renderTargetTexture.GetReference();
		
		//OpenGL ES does not support glGetTexImage, so bind texture to frame buffer, in order to use glReadPixels
		glBindFramebuffer(GL_FRAMEBUFFER, PboRHI->FboId);
		glFramebufferTexture2D(GL_FRAMEBUFFER, GL_COLOR_ATTACHMENT0, GL_TEXTURE_2D, Texture->Resource, 0);
		glBindBuffer(GL_PIXEL_PACK_BUFFER, PboRHI->PboId);
		glReadPixels(0, 0, Texture->GetSizeX(), Texture->GetSizeY(), GL_RGBA, GL_UNSIGNED_BYTE, nullptr);

		glBindFramebuffer(GL_FRAMEBUFFER, 0);
		glBindBuffer(GL_PIXEL_PACK_BUFFER, 0);
	});
}

void AAzureTextureReadback::FinishOpenGLPBOReadback_RenderThread(FAzureOpenGLPBORef PboRHI)
{
	//hold reference to rhi resource
	TSharedRef<FAzureTextureReadbackSharedData> sharedData = m_sharedData;
	AzureRunOnGLRenderContextThread([sharedData, PboRHI]()
	{
		DECLARE_SCOPE_CYCLE_COUNTER(TEXT("AzureTRBGL_FinishOpenGLPBOReadback"), STAT_AzureTRBGL_FinishOpenGLPBOReadback, STATGROUP_AzureTRBGL);
		glBindBuffer(GL_PIXEL_PACK_BUFFER, PboRHI->PboId);
		int dataSize = PboRHI->DataSize;
		FColor* data = (FColor*)glMapBufferRange(GL_PIXEL_PACK_BUFFER, 0, dataSize, GL_MAP_READ_BIT);
		if (data)
		{
			int len = dataSize/sizeof(FColor);
			sharedData->textureDataForReadback.Empty();
			sharedData->textureDataForReadback.AddUninitialized(len);
			FMemory::Memcpy(sharedData->textureDataForReadback.GetData(), data, len * sizeof(FColor));
			{
				DECLARE_SCOPE_CYCLE_COUNTER(TEXT("glUnmapBuffer"), STAT_glUnmapBuffer, STATGROUP_AzureTRBGL);
				glUnmapBuffer(GL_PIXEL_PACK_BUFFER);
			}
		}
		glBindBuffer(GL_PIXEL_PACK_BUFFER, 0);
		{
			FScopeLock lock(&sharedData->dataLock);
			Swap(sharedData->textureDataForGameThread, sharedData->textureDataForReadback);
			sharedData->dataFliped = true;	//glReadPixels reads RGBA8, which is different from texture format 'BGRA8'
		}
	});
}

#endif		//HAS_AZURE_OPENGL_PBO
