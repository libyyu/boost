#include "DeadLockDetector.h"
#include "Azure.h"
#include "AzureExport.h"
#include "Async/AsyncWork.h"
#include "AzureEntryPoint.h"
#include "Engine/World.h"
#include "HAL/RunnableThread.h"
#include "ECDebug.h"
#include <atomic>

extern CORE_API void(*GAzureBeginANRCheckFunc)();
extern CORE_API void(*GAzureEndANRCheckFunc)();
extern CORE_API volatile int GAzureANRErrorFlag;
#if PLATFORM_IOS
extern CORE_API bool GetIOSIsSuspended();
#endif

static void BeginANRCheckFunc()
{
	DeadLockDetector::instance().BeginANRCheck();
}

static void EndANRCheckFunc()
{
	DeadLockDetector::instance().EndANRCheck();
}

namespace
{
	volatile bool running = false;
	volatile bool applicationPause = false;
	float deadlock_threshhold = 25;
	float tick_interval = 0.1f;
	volatile int current_tick_count = 0;
	volatile int last_active_tick_count = 0;

	// ANR detect
	volatile int anr_tick_count = 0;
	volatile bool anr_checking_flag = false;

#if UE_EDITOR
	volatile bool editor_paused = false;
	volatile bool editor_stoped = false;
#endif

	bool m_crashOnDeadLock = false;
	bool m_enableANRCheck = false;
	volatile bool active_flag = false;

	bool IsActiveFlag()
	{
#if PLATFORM_IOS
		return (active_flag && !GetIOSIsSuspended());
#else
		return active_flag;
#endif
	}

	bool IsDeadLockDetected()
	{
		float timeSinceLastActivation = (current_tick_count - last_active_tick_count) * tick_interval;
		return timeSinceLastActivation > deadlock_threshhold;	//有死锁
	}

	bool IsANRDetected()
	{
		if (!anr_checking_flag)
			return false;

		float timeSinceLastActivation = (current_tick_count - anr_tick_count) * tick_interval;
		return timeSinceLastActivation > 4.8f;	//有ANR，安卓必须在5秒内有反应
	}

	bool ShouldCountTick()
	{
		if (FPlatformMisc::IsDebuggerPresent())
			return false;

		if (!AAzureEntryPoint::Instance || !AAzureEntryPoint::Instance->GetWorld())
			return false;
#if UE_EDITOR
		if (AAzureEntryPoint::Instance->GetWorld()->bDebugPauseExecution)	//Editor 暂停时不能计数
			return false;
#endif
		return IsActiveFlag() && !applicationPause;
	}

	static double getCurrentTime()
	{
		return FPlatformTime::Seconds();
	}

	void native_crash()
	{
		UE_LOG(LogAzure, Fatal, TEXT("DeadLockDetector, native_crash!"));
	}
};

class FDeadLockDetectorAsyncTask : public FNonAbandonableTask
{
public:
	TStatId GetStatId() const
	{
		RETURN_QUICK_DECLARE_CYCLE_STAT(FDeadLockDetectorAsyncTask, STATGROUP_ThreadPoolAsyncTasks);
	}

	void DoWork()
	{
#if UE_GAME
		if (!running)
			return;

		if (IsActiveFlag())
		{
			if (IsDeadLockDetected())	//有死锁
			{
				AzureDisableAllSafeChecking();
				//Debug.LogWarning("DeadLockDetector, dead lock detected");	//后面还会报错，且有用信息都在后面

				exp_lua_setup_hook_deadlock();
				FPlatformProcess::Sleep(4.0f);
				if (IsDeadLockDetected())	//lua_setup_hook_deadlock 可能恢复
				{
					if (m_crashOnDeadLock)
					{
						UE_LOG(LogAzure, Error, TEXT("DeadLockDetector, crash!"));
						native_crash();
					}
					running = false;
					return;
				}
			}
		}

		int tick_interval_ms = (int)(tick_interval * 1000);

		double beginTime = getCurrentTime();
		FPlatformProcess::Sleep(tick_interval_ms/1000.f);
		double passedTime = getCurrentTime() - beginTime;

		bool sleepAwakeTooEarly = passedTime < tick_interval * 0.5f;	//挂调试器，启动时 Sleep 可能很快结束，导致启动时判定为卡死
		if (!sleepAwakeTooEarly && ShouldCountTick())
		{
			//用 tick 数而非总时间判断死锁，自动适应调试器暂停
			++current_tick_count;
		}

		(new FAutoDeleteAsyncTask<FDeadLockDetectorAsyncTask>())->StartBackgroundTask();
#endif
	}

};


DeadLockDetector::DeadLockDetector()
{
    
}

DeadLockDetector& DeadLockDetector::instance()
{
	static DeadLockDetector  s_inst;
	return s_inst;
}

void DeadLockDetector::ForceStop()
{
	running = false;

#if UE_GAME
	if (m_Thread)
	{
		m_Thread->WaitForCompletion();
		delete m_Thread;
		m_Thread = nullptr;
	}
#endif
}

void DeadLockDetector::Start(float threshhold, float interval, bool crashOnDeadLock, bool enableANRCheck)
{
#if UE_GAME

	if (running)
		return;
	running = true;

	deadlock_threshhold = threshhold;
	tick_interval = interval;
	m_crashOnDeadLock = crashOnDeadLock;
	m_enableANRCheck = enableANRCheck;
	current_tick_count = 0;
	last_active_tick_count = current_tick_count;
	anr_tick_count = current_tick_count;

	// (new FAutoDeleteAsyncTask<FDeadLockDetectorAsyncTask>())->StartBackgroundTask();
	m_Thread = FRunnableThread::Create(this, TEXT("DeadLockDetector"), 0, TPri_BelowNormal);

	GAzureBeginANRCheckFunc = BeginANRCheckFunc;
	GAzureEndANRCheckFunc = EndANRCheckFunc;

#endif
}

void DeadLockDetector::Stop()
{
	FRunnable::Stop();
}

void DeadLockDetector::SetActive(bool bActive)
{
	active_flag = bActive;
}

void DeadLockDetector::Update()
{
	last_active_tick_count = current_tick_count;
}

bool DeadLockDetector::IsRunning() const
{
	return running;
}

uint32 DeadLockDetector::Run()
{
#if UE_GAME
	while (running)
	{
		if (IsActiveFlag())
		{
			if (IsDeadLockDetected())	//有死锁
			{
				AzureDisableLuaThreadChecking();
				//Debug.LogWarning("DeadLockDetector, dead lock detected");	//后面还会报错，且有用信息都在后面

				exp_lua_setup_hook_deadlock();
				FPlatformProcess::Sleep(4.0f);
				if (IsDeadLockDetected())	//lua_setup_hook_deadlock 可能恢复
				{
					if (m_crashOnDeadLock)
					{
						UE_LOG(LogAzure, Error, TEXT("DeadLockDetector, crash!, error flag %d"), GAzureANRErrorFlag);
						native_crash();
					}
					running = false;
					break;
				}
			}

			if (m_enableANRCheck && IsANRDetected())
			{
				UE_LOG(LogAzure, Error, TEXT("ANR, crash!, error flag %d"), GAzureANRErrorFlag);
				native_crash();
			}
		}

		int tick_interval_ms = (int)(tick_interval * 1000);

		double beginTime = getCurrentTime();
		FPlatformProcess::Sleep(tick_interval_ms / 1000.f);
		double passedTime = getCurrentTime() - beginTime;

		bool sleepAwakeTooEarly = passedTime < tick_interval * 0.5f;	//挂调试器，启动时 Sleep 可能很快结束，导致启动时判定为卡死
		if (!sleepAwakeTooEarly && ShouldCountTick())
		{
			//用 tick 数而非总时间判断死锁，自动适应调试器暂停
			++current_tick_count;
		}
	}
#endif

	return 0;
}

// ANR detect
void DeadLockDetector::BeginANRCheck()
{
	anr_tick_count = current_tick_count;
	std::atomic_thread_fence(std::memory_order::memory_order_acq_rel);
	anr_checking_flag = true;
}

void DeadLockDetector::EndANRCheck()
{
	anr_checking_flag = false;
}
