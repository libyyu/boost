#include "ThreadJobForLua.h"
#include "GenericPlatformProcess.h"
#include "wLua/LuaInterface.h"
#include "wLuaIntegration.h"

extern wLua::Lua* AAzureEntryPoint_GetWLua();

#if defined(AZURE_UE_TARGET_DEBUG) || defined(AZURE_UE_TARGET_DEBUGGAME) || PLATFORM_WINDOWS
#define LUA_THREAD_CHECK 1
#else
#define LUA_THREAD_CHECK 0
#endif

ThreadJobForLua* ThreadJobForLua::m_Instance = nullptr;
bool ThreadJobForLua::Processing = false;

ThreadJobForLua::ThreadJobForLua()
{
	m_StartEvent = FGenericPlatformProcess::GetSynchEventFromPool(false);
	m_FinishEvent = FGenericPlatformProcess::GetSynchEventFromPool(false);
}

ThreadJobForLua::~ThreadJobForLua()
{
	if (m_StartEvent)
		FGenericPlatformProcess::ReturnSynchEventToPool(m_StartEvent);

	if (m_FinishEvent)
		FGenericPlatformProcess::ReturnSynchEventToPool(m_FinishEvent);
}

void ThreadJobForLua::StartJob()
{
	if (m_HasPendingJob)
	{
		if (m_RunInMainThread)
		{
			m_JobTimeLimitReached = true;
			auto wlua = AAzureEntryPoint_GetWLua();
			lua_State_Wrapper L = wlua->GetL();
			lua_getglobal(L, "DoThreadJob");
			wlua->Call(0);
			m_JobTimeLimitReached = false;
			m_HasPendingJob = false;
		}
		else
		{
			Processing = true;
			m_StartEvent->Trigger();
		}
	}
}

uint32 ThreadJobForLua::Run()
{
	ThreadId = FPlatformTLS::GetCurrentThreadId();

	while (!m_QuitFlag)
	{
		m_StartEvent->Wait();

		if (m_QuitFlag)
			break;

#if LUA_THREAD_CHECK
		int OldThreadId = g_GetLuaThreadId();
		g_SetLuaCurrentThreadId();
#endif
		{	//��Ҫ��ס lua_State_Wrapper
			auto wlua = AAzureEntryPoint_GetWLua();
			lua_State_Wrapper L = wlua->GetUncheckedL();
			lua_getglobal(L, "DoThreadJob");
			wlua->Call(0, false);
		}

#if LUA_THREAD_CHECK
		g_SetLuaThreadId(OldThreadId);
#endif

		m_FinishEvent->Trigger();
	}

	m_FinishEvent->Trigger();
	return 0;
}
