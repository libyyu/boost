#include "DrawDebugHelpersExt.h"
#include "DrawDebugHelpers.h"

#if ENABLE_DRAW_DEBUG

void DrawDebugSector(const UWorld* InWorld, const FVector& Center, const FRotator& Rotator, float Radius, float Angle, float Height, int32 Segments, const FColor& Color, bool bPersistentLines/* = false*/, float LifeTime/* = -1.f*/, uint8 DepthPriority/* = 0*/, float Thickness/* = 0.f*/)
{
	float AngleDelta = Angle / Segments;
	FQuat Quat = (Rotator + FRotator(0, -Angle / PI * 90.0, 0)).Quaternion();
	FVector X = Quat.GetForwardVector();
	FVector Y = Quat.GetRightVector();
	FVector BottomCenter = Center - Quat.GetUpVector() * Height / 2;
	FVector TopCenter = BottomCenter + Quat.GetUpVector() * Height;
	FVector	LastVertex = BottomCenter + X * Radius;

	for (int32 SideIndex = 0; SideIndex < Segments; SideIndex++)
	{
		FVector	Vertex = BottomCenter + (X * FMath::Cos(AngleDelta * (SideIndex + 1)) + Y * FMath::Sin(AngleDelta * (SideIndex + 1))) * Radius;
		FVector TopVertex = Vertex + Quat.GetUpVector() * Height;
		FVector TopLastVertex = LastVertex + Quat.GetUpVector() * Height;
		DrawDebugLine(InWorld, LastVertex, Vertex, Color, bPersistentLines, LifeTime, DepthPriority, Thickness);
		DrawDebugLine(InWorld, TopLastVertex, TopVertex, Color, bPersistentLines, LifeTime, DepthPriority, Thickness);
		DrawDebugLine(InWorld, BottomCenter, LastVertex, Color, bPersistentLines, LifeTime, DepthPriority, Thickness);
		DrawDebugLine(InWorld, TopCenter, TopLastVertex, Color, bPersistentLines, LifeTime, DepthPriority, Thickness);
		DrawDebugLine(InWorld, LastVertex, TopLastVertex, Color, bPersistentLines, LifeTime, DepthPriority, Thickness);
		LastVertex = Vertex;
	}
	
	FVector TopLastVertex = LastVertex + Quat.GetUpVector() * Height;
	DrawDebugLine(InWorld, BottomCenter, LastVertex, Color, bPersistentLines, LifeTime, DepthPriority, Thickness);
	DrawDebugLine(InWorld, TopCenter, TopLastVertex, Color, bPersistentLines, LifeTime, DepthPriority, Thickness);
	DrawDebugLine(InWorld, BottomCenter, TopCenter, Color, bPersistentLines, LifeTime, DepthPriority, Thickness);
	DrawDebugLine(InWorld, LastVertex, TopLastVertex, Color, bPersistentLines, LifeTime, DepthPriority, Thickness);
}

void DrawDebug3DDonut(const UWorld* InWorld, const FVector& Center, const FRotator& Rotator, float InnerRadius, float OuterRadius, float Height, int32 Segments, const FColor& Color, bool bPersistentLines/* = false*/, float LifeTime/* = -1.f*/, uint8 DepthPriority/* = 0*/, float Thickness/* = 0.f*/)
{
	int32 minSegments = 4;
	Segments = FMath::Max(Segments, minSegments);
	FQuat Quat = Rotator.Quaternion();
	const FVector AxisX = Quat.GetForwardVector();
	const FVector AxisY = Quat.GetRightVector();
	const float AngleStep = 2.f * PI / float(Segments);
	FVector BottomCenter = Center - Quat.GetUpVector() * Height / 2;
	FVector TopCenter = BottomCenter + Quat.GetUpVector() * Height;

	float Angle = 0.f;
	for (int32 SideIndex = 0; SideIndex < Segments; SideIndex++)
	{
		FVector Direction = AxisX * FMath::Cos(Angle) + AxisY * FMath::Sin(Angle);
		const FVector BottomInnerVertex1 = BottomCenter + InnerRadius * Direction;
		const FVector BottomOuterVertex1 = BottomCenter + OuterRadius * Direction;

		const FVector TopInnerVertex1 = TopCenter + InnerRadius * Direction;
		const FVector TopOuterVertex1 = TopCenter + OuterRadius * Direction;

		Angle += AngleStep;
		Direction = AxisX * FMath::Cos(Angle) + AxisY * FMath::Sin(Angle);
		const FVector BottomInnerVertex2 = BottomCenter + InnerRadius * Direction;
		const FVector BottomOuterVertex2 = BottomCenter + OuterRadius * Direction;

		const FVector TopInnerVertex2 = TopCenter + InnerRadius * Direction;
		const FVector TopOuterVertex2 = TopCenter + OuterRadius * Direction;

		DrawDebugLine(InWorld, BottomInnerVertex1, BottomInnerVertex2, Color, bPersistentLines, LifeTime, DepthPriority, Thickness);
		DrawDebugLine(InWorld, BottomOuterVertex1, BottomOuterVertex2, Color, bPersistentLines, LifeTime, DepthPriority, Thickness);
		DrawDebugLine(InWorld, TopInnerVertex1, TopInnerVertex2, Color, bPersistentLines, LifeTime, DepthPriority, Thickness);
		DrawDebugLine(InWorld, TopOuterVertex1, TopOuterVertex2, Color, bPersistentLines, LifeTime, DepthPriority, Thickness);

		DrawDebugLine(InWorld, TopInnerVertex1, BottomInnerVertex1, Color, bPersistentLines, LifeTime, DepthPriority, Thickness);
		DrawDebugLine(InWorld, TopOuterVertex1, BottomOuterVertex1, Color, bPersistentLines, LifeTime, DepthPriority, Thickness);
		DrawDebugLine(InWorld, TopOuterVertex1, TopInnerVertex1, Color, bPersistentLines, LifeTime, DepthPriority, Thickness);
		DrawDebugLine(InWorld, BottomInnerVertex1, BottomOuterVertex1, Color, bPersistentLines, LifeTime, DepthPriority, Thickness);
	}
}

#endif // ENABLE_DRAW_DEBUG
