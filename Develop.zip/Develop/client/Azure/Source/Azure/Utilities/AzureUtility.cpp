﻿#include "AzureUtility.h"
#include "AzureEntryPoint.h"
#include "AzureExport.h"
#include "Azure.h"
#include "GameLogic/Input/AzureInputCtrl.h"
#include "AutoMove/AutoMoveExport.h"
#include "Engine/PostProcessVolume.h"
#include "Materials/MaterialInstanceConstant.h"
#include "Materials/MaterialInstanceDynamic.h"
#include "Components/SkeletalMeshComponent.h"
#include "Components/StaticMeshComponent.h"
#include "Components/CapsuleComponent.h"
#include "UObjectIterator.h"
#include "RawIndexBuffer.h"
#include "Components/DirectionalLightComponent.h"
#include "Camera/CameraComponent.h"
#include "GameFramework/PlayerController.h"
#include "AzureObjectComponent.h"
#include "Animation/AnimInstance.h"
#include "AnimationRuntime.h"
#include "GameLogic/Player/GamePlayer_Util.h"
#include "Components/BoxComponent.h"
#include "GameFramework/Character.h"
#include "DrawDebugHelpers.h"
#include "Kismet/KismetRenderingLibrary.h"
#include "GameLogic/Environment/AzureEnvironmentManager.h"

using namespace Azure;

int AzureUtility::pushFHitResult2Lua(lua_State * L, const FHitResult& result, bool bCheckAzureObj)
{
	lua_newtable(L);
	lua_pushboolean(L, result.bBlockingHit);
	lua_setfield(L, -2, "bBlockingHit");

	lua_pushboolean(L, result.bStartPenetrating);
	lua_setfield(L, -2, "bStartPenetrating");

	lua_pushnumber(L, result.Time);
	lua_setfield(L, -2, "Time");

	lua_pushnumber(L, result.Distance);
	lua_setfield(L, -2, "Distance");

	wLua::FLuaVector::Return(L, result.Location);
	lua_setfield(L, -2, "Location");

	wLua::FLuaVector::Return(L, result.ImpactPoint);
	lua_setfield(L, -2, "ImpactPoint");

	wLua::FLuaVector::Return(L, result.Normal);
	lua_setfield(L, -2, "Normal");

	wLua::FLuaVector::Return(L, result.ImpactNormal);
	lua_setfield(L, -2, "ImpactNormal");

	wLua::FLuaVector::Return(L, result.TraceStart);
	lua_setfield(L, -2, "TraceStart");

	wLua::FLuaVector::Return(L, result.TraceEnd);
	lua_setfield(L, -2, "TraceEnd");

	lua_pushnumber(L, result.PenetrationDepth);
	lua_setfield(L, -2, "PenetrationDepth");

	lua_pushinteger(L, result.Item);
	lua_setfield(L, -2, "Item");

	lua_pushstring(L, TCHAR_TO_UTF8(*result.BoneName.ToString()));
	lua_setfield(L, -2, "BoneName");

	lua_pushinteger(L, result.FaceIndex);
	lua_setfield(L, -2, "FaceIndex");

	AActor* pActor = result.GetActor();
	wLua::FLuaUtils::ReturnUObject(L, pActor);
	lua_setfield(L, -2, "Actor");

	UPrimitiveComponent* pComp = result.GetComponent();
	wLua::FLuaUtils::ReturnUObject(L, pComp);
	lua_setfield(L, -2, "Component");

	if (bCheckAzureObj && pActor)
	{
		UAzureObjectComponent* pAzureComp = FindActorAzureObjComp(pActor);
		if (pAzureComp)
		{
			wLua::FLuaUtils::ReturnUObject(L, pAzureComp);
			lua_setfield(L, -2, "HitAureComponet");
			lua_pushnumber(L, (int)pAzureComp->GetLuaECObject());
			lua_setfield(L, -2, "HitAureComponetID");
		}
	}

	return 1;
}


FHitResult AzureUtility::getFHitResult2Lua(lua_State * L, int ParamIndex)
{
	if (lua_isnoneornil(L, ParamIndex) || !lua_istable(L, ParamIndex)) {
		return FHitResult(0.0f);
	}

	FHitResult HitResult;

	luaL_checktype(L, ParamIndex, LUA_TTABLE);

	lua_getfield(L, ParamIndex, "bBlockingHit");
	HitResult.bBlockingHit = lua_toboolean(L, -1);
	lua_pop(L, 1);

	lua_getfield(L, ParamIndex, "bStartPenetrating");
	HitResult.bStartPenetrating = lua_toboolean(L, -1);
	lua_pop(L, 1);

	lua_getfield(L, ParamIndex, "Time");
	HitResult.Time = lua_tonumber(L, -1);
	lua_pop(L, 1);

	lua_getfield(L, ParamIndex, "Distance");
	HitResult.Distance = lua_tonumber(L, -1);
	lua_pop(L, 1);

	lua_getfield(L, ParamIndex, "Location");
	HitResult.Location = wLua::FLuaVector::Get(L, -1);
	lua_pop(L, 1);

	lua_getfield(L, ParamIndex, "ImpactPoint");
	HitResult.ImpactPoint = wLua::FLuaVector::Get(L, -1);
	lua_pop(L, 1);

	lua_getfield(L, ParamIndex, "Normal");
	HitResult.Normal = wLua::FLuaVector::Get(L, -1);
	lua_pop(L, 1);

	lua_getfield(L, ParamIndex, "ImpactNormal");
	HitResult.ImpactNormal = wLua::FLuaVector::Get(L, -1);
	lua_pop(L, 1);

	lua_getfield(L, ParamIndex, "TraceStart");
	HitResult.TraceStart = wLua::FLuaVector::Get(L, -1);
	lua_pop(L, 1);

	lua_getfield(L, ParamIndex, "TraceEnd");
	HitResult.TraceEnd = wLua::FLuaVector::Get(L, -1);
	lua_pop(L, 1);

	lua_getfield(L, ParamIndex, "PenetrationDepth");
	HitResult.PenetrationDepth = lua_tonumber(L, -1);
	lua_pop(L, 1);

	lua_getfield(L, ParamIndex, "Item");
	HitResult.Item = lua_tointeger(L, -1);
	lua_pop(L, 1);

	lua_getfield(L, ParamIndex, "BoneName");
	HitResult.BoneName = lua_tostring(L, -1);
	lua_pop(L, 1);

	lua_getfield(L, ParamIndex, "FaceIndex");
	HitResult.FaceIndex = lua_tointeger(L, -1);
	lua_pop(L, 1);

	lua_getfield(L, ParamIndex, "Actor");
	AActor* Actor = Cast<AActor>(wLua::FLuaUtils::GetUObject(L, -1, "Actor"));
	HitResult.Actor = Actor;
	lua_pop(L, 1);

	lua_getfield(L, ParamIndex, "Component");
	UPrimitiveComponent* Component = Cast<UPrimitiveComponent>(wLua::FLuaUtils::GetUObject(L, -1, "PrimitiveComponent"));
	HitResult.Component = Component;
	lua_pop(L, 1);

	return HitResult;
}

void AzureUtility::CallLuaSetCameraToTargetPos(const FVector & pos, bool ignore_lag)
{
	if (!AAzureEntryPoint::Instance)
		return;

	wLua::Lua * wlua = AAzureEntryPoint::Instance->GetWLua();
	if (wlua == nullptr)
		return;
	lua_State_Wrapper L = wlua->GetL();
	if (L == nullptr)
		return;

	lua_getglobal(L, "SetCameraToTargetPos");
	wLua::FLuaVector::Return(L, pos);
	lua_pushboolean(L, ignore_lag);
	wlua->Call(2);
}
//Warning: Ref把Player改成了Character，所以UAzureObjectComponent可能就在pActor上，也可能在它的爷爷上，目前这种做法比较丑陋，待优化！！
UAzureObjectComponent* AzureUtility::FindActorAzureObjComp(AActor* pActor)
{
	if (!pActor)
		return nullptr;

	auto comps = pActor->GetComponentByClass(UAzureObjectComponent::StaticClass());
	if (comps)
		return Cast<UAzureObjectComponent>(comps);
	
	AActor* pParentActor = nullptr;
	UProperty* Property = wLua::FindScriptPropertyHelper(pActor->GetClass(), TEXT("RootActor"));
	if (Property)
		Property->CopyCompleteValue(&pParentActor, Property->ContainerPtrToValuePtr<void>(pActor));
	if (!pParentActor)
		pParentActor = pActor->GetAttachParentActor();
	if (!pParentActor)
		return nullptr;
	comps = pParentActor->GetComponentByClass(UAzureObjectComponent::StaticClass());
	if (comps)
		return Cast<UAzureObjectComponent>(comps);

	//爷爷Actor
	pParentActor = pParentActor->GetAttachParentActor();
	if (!pParentActor)
		return nullptr;
	comps = pParentActor->GetComponentByClass(UAzureObjectComponent::StaticClass());
	if (comps)
		return Cast<UAzureObjectComponent>(comps);
	return nullptr;
}

bool AzureUtility::GetCurrentJoyStickDir(FVector& vDir, bool bDir3D, bool bIncludeZeroStickValue,
	FVector2D* pvJoyStickValue/* = NULL*/, FVector* pvCameraRight/* = NULL*/, FVector* pvCameraUp/* = NULL*/, FVector* pvCameraForward/* = NULL*/)
{
	if (!AAzureEntryPoint::Instance)
		return false;

	FVector2D v = AzureInputCtrl::GetInstance().GetJoyStickValue();

	if (pvJoyStickValue)
		*pvJoyStickValue = v;

	if (v.IsZero())
	{
		if (!bIncludeZeroStickValue)
			return false;

		vDir = FVector::ZeroVector;
		return true;
	}

	APlayerController* pCtrler = AAzureEntryPoint::Instance->GetPlayerController();
	if (!pCtrler)
		return false;

	FVector vpLocation;
	FRotator vpRotation;
	pCtrler->GetPlayerViewPoint(vpLocation, vpRotation);

	FQuat quat = vpRotation.Quaternion();

	FVector vCamForward = quat.GetForwardVector();
	if (pvCameraForward)
		*pvCameraForward = vCamForward;

	if (!bDir3D)
	{
		VEC_UP(vCamForward) = 0;
		vCamForward.Normalize();
	}

	FVector vCamRight = quat.GetRightVector();
	if (VEC_UP(vCamRight) != 0)
	{
		VEC_UP(vCamRight) = 0;
		vCamRight.Normalize();
	}

	if (pvCameraRight)
		*pvCameraRight = vCamRight;

	if (pvCameraUp)
		*pvCameraUp = quat.GetUpVector();

	vDir = vCamForward * v.Y + vCamRight * v.X;
	vDir.Normalize();
	return true;
}

void AzureUtility::EnableLightOfLevel(ULevel *level, bool bEnable)
{
	if (!level)
		return;
	for (TObjectIterator<UDirectionalLightComponent> LightIt; LightIt; ++LightIt)
	{
		UDirectionalLightComponent* Light = *LightIt;
		AActor *owner = Light->GetOwner();
		if (owner && owner->GetLevel() == level)
		{
			Light->SetVisibility(bEnable);
		}
	}
}

void AzureUtility::RaiseEventForUObject(UObject *pObject, FName FuncName, void* Parameters)
{
	if (pObject && !pObject->IsPendingKill())
	{
		UFunction* Function = pObject->FindFunction(FuncName);
		if (Function)
			pObject->ProcessEvent(Function, Parameters);
	}
}

bool AzureUtility::InterpFloat(float& fCurVal, float fDestVal, float fRatio, float fDeltaTime, float fMinSpeedThresh)
{
	if (fCurVal == fDestVal)
		return true;

	float fDelta = fDestVal - fCurVal;
	float fFabsDist = FMath::Abs(fDelta);

	float fMinDelta = fMinSpeedThresh * fDeltaTime;
	//float fMinDeltaToConstSpeed = fMinDelta * fRatio * 10.f;

	if (fFabsDist > fMinDelta)//fMinDeltaToConstSpeed)
	{
		float fDeltaRatio = fRatio * fDeltaTime;
		if (fDeltaRatio >= 1.0f)
		{
			fCurVal = fDestVal;
			return true;
		}
		fCurVal += fDelta * fDeltaRatio;
		return false;
	}
	else
	{
		fCurVal = fDestVal;
		return true;
	}
}

//	Interpolate float with const speed
//	Return: true-Reach, false-NotReach
bool AzureUtility::InterpFloatConstSpeed(float& fCurVal, float fDestVal, float fDeltaTime,
	float fSpeed, const float* pfDeltaDist/* = NULL*/)
{
	if (fDestVal == fCurVal)
		return true;

	float fDelta = pfDeltaDist ? *pfDeltaDist : (fDestVal - fCurVal);
	float fFabsDist = fabs(fDelta);

	float fMinDelta = fSpeed * fDeltaTime;
	float fFabsDelta = fabs(fMinDelta);

	if (fFabsDist < fFabsDelta)
	{
		fCurVal = fDestVal;
		return true;
	}
	else
	{
		fCurVal += fDelta > 0 ? fFabsDelta : -fFabsDelta;
		return false;
	}
}

bool AzureUtility::IsHitMoveBlock(const FVector& vStart, const FVector& vEnd, float fRadius, float fHalfHeight, const TArray<AActor*>& InIgnoreActors)
{
	FCollisionShape CollisionShape;
	if (fHalfHeight > 0)
		CollisionShape.SetCapsule(fRadius, fHalfHeight);
	else
		CollisionShape.SetSphere(fRadius);

	if (!AAzureEntryPoint::IsInit())
		return false;

	UWorld* pWorld = AAzureEntryPoint::Instance->GetWorld();
	if (!pWorld)
		return false;

	bool bBlock = false;
	FHitResult thisHitInfo;

	FCollisionQueryParams Params(NAME_None, false); // Not Trace Complex!
	Params.AddIgnoredActors(InIgnoreActors);
	
	bool bDir = pWorld->SweepSingleByChannel(thisHitInfo, vStart, vEnd, FQuat::Identity, TRACE_CHN_MONSTERBLOCKMOVE, CollisionShape, Params);
	if (bDir)
	{
		if (false)
		{
			FString str = FString::Printf(TEXT("bEndHitNameStartEnd %s"), *thisHitInfo.GetComponent()->GetName());
			MyPrintString(str);
		}

		bool bEnd = pWorld->SweepSingleByChannel(thisHitInfo, vEnd, vEnd, FQuat::Identity, TRACE_CHN_MONSTERBLOCKMOVE, CollisionShape, Params);
		if (bEnd)
		{
			//终点有碰撞，再判断起点是不是已经碰上了
			//如果起点已经碰上了，已经在怪物身体里可以走，以便走出来
			//如果起点没碰上怪，不能继续走，不能走到怪物碰撞里去
			bool bStart = pWorld->SweepSingleByChannel(thisHitInfo, vStart, vStart, FQuat::Identity, TRACE_CHN_MONSTERBLOCKMOVE, CollisionShape, Params);

			if (bStart)
				bBlock = false;
			else
				bBlock = true;

			if (false)
			{
				FString str = FString::Printf(TEXT("bEndHitNameEnd %s"), *thisHitInfo.GetComponent()->GetName());
				MyPrintString(str);
			}
		}
		else
		{
			//如果终点没有碰撞，就可以走
			bBlock = false;
		}
	}	

	if (false)
	{
		//FString str = FString::Printf(TEXT("IsHitMoveBlock start %d -- end %d"), bDir, bEnd);
		//MyPrintString(str);
	}
	

	return bBlock;
}

bool AzureUtility::GetHitPosInWorld(const FVector& vStart, const FVector& vEnd, ECollisionChannel Channel,
	FHitResult& hitInfo, float fRadius, float fHalfHeight, bool bBlockMoveIgnoreCapsuleOverlap/* = true*/, const FQuat& Rot/* = FQuat::Identity*/, FName traceTag/* = NAME_None*/, TArray<AActor*>* ignoreActors/* = nullptr*/)
{
	FCollisionShape CollisionShape;
	if (fHalfHeight > 0)
		CollisionShape.SetCapsule(fRadius, fHalfHeight);
	else
		CollisionShape.SetSphere(fRadius);

	return GetHitPosInWorld_ByShape(vStart, vEnd, Channel, hitInfo, CollisionShape, bBlockMoveIgnoreCapsuleOverlap, Rot, traceTag, ignoreActors);
}

bool AzureUtility::GetHitPosInWorld_ByShape(const FVector& vStart, const FVector& vEnd, ECollisionChannel Channel,
	FHitResult& hitInfo, const FCollisionShape& CollisionShape, bool bBlockMoveIgnoreCapsuleOverlap/* = true*/, const FQuat& Rot/* = FQuat::Identity*/, FName traceTag/* = NAME_None*/, TArray<AActor*>* ignoreActors/* = nullptr*/)
{
	if (!AAzureEntryPoint::IsInit())
		return false;

	UWorld* pWorld = AAzureEntryPoint::Instance->GetWorld();
	if (!pWorld)
		return false;

	bool bRet = false;
	FHitResult thisHitInfo;

	FCollisionQueryParams Params(traceTag, false); // Not Trace Complex!
	if (ignoreActors != nullptr)
	{
		for (int i = 0; i < ignoreActors->Num(); ++i)
			Params.AddIgnoredActor((*ignoreActors)[i]);
	}
	if (pWorld->SweepSingleByChannel(thisHitInfo, vStart, vEnd, Rot, Channel, CollisionShape, Params))
	{
		hitInfo = thisHitInfo;
		bRet = true;
	}

	if (bRet && bBlockMoveIgnoreCapsuleOverlap && Channel == TRACE_CHN_BLOCKMOVE
		&& hitInfo.bStartPenetrating && hitInfo.Component.IsValid() && hitInfo.Component->IsA(UCapsuleComponent::StaticClass()))
	{
		//	BlockMove: 卡在生物碰撞盒里了：让走！
		//	但需要继续碰撞地形和建筑
		bRet = false;
		hitInfo.Reset();

		Channel = TRACE_CHN_TERRAIN_BUILDING;
		thisHitInfo.Init();
		if (pWorld->SweepSingleByChannel(thisHitInfo, vStart, vEnd, Rot, Channel, CollisionShape, Params))
		{
			hitInfo = thisHitInfo;
			bRet = true;
		}
	}

	return bRet;
}

bool AzureUtility::GetSupportPlaneHeight(float& ret_height, const FVector& vPos, float fRadius, float fTraceDownDist/* = -1.f*/, FHitResult* pHitInfo/* = NULL*/, bool bStartPenetratingAsCollision/* = false*/)
{
	if (!AAzureEntryPoint::IsInit())
		return false;

	FHitResult hitInfo;
	FVector End = vPos;

	VEC_UP(End) -= fTraceDownDist;


	static const FName _TraceTag_GetSupportPlaneHei = "GetSupportPlaneHei";

	bool bRet = GetHitPosInWorld(vPos, End, TRACE_CHN_TERRAIN_BUILDING, hitInfo, fRadius, 0, true, FQuat::Identity, _TraceTag_GetSupportPlaneHei);
	if (pHitInfo)
		*pHitInfo = hitInfo;

	if (!bRet || (hitInfo.bStartPenetrating && !bStartPenetratingAsCollision))
		return false;

	ret_height = VEC_UP(hitInfo.Location) - fRadius;
	return true;
}

bool AzureUtility::CapsuleTraceSingle(UWorld* pWorld, const FVector& Start, const FVector& End, const FQuat& Quat, float Radius, float HalfHeight, ECollisionChannel Channel, bool bTraceComplex, const TArray<AActor*>& ActorsToIgnore, EDrawDebugTrace::Type DrawDebugType, FHitResult& OutHit, bool bIgnoreSelf, FLinearColor TraceColor, FLinearColor TraceHitColor, float DrawTime)
{
	static const FName CapsuleTraceSingleName(TEXT("AzureUtility::CapsuleTraceSingle"));
	FCollisionQueryParams Params(CapsuleTraceSingleName, bTraceComplex);
	Params.bReturnPhysicalMaterial = true;
	Params.bReturnFaceIndex = !UPhysicsSettings::Get()->bSuppressFaceRemapTable; // Ask for face index, as long as we didn't disable globally
	Params.bTraceAsyncScene = true;
	Params.AddIgnoredActors(ActorsToIgnore);

	bool const bHit = pWorld->SweepSingleByChannel(OutHit, Start, End, Quat, Channel, FCollisionShape::MakeCapsule(Radius, HalfHeight), Params);

	if (DrawDebugType != EDrawDebugTrace::Type::None)
	{
		bool bPersistent = DrawDebugType == EDrawDebugTrace::Type::Persistent;
		float LifeTime = (DrawDebugType == EDrawDebugTrace::Type::ForDuration) ? DrawTime : 0.f;
		const float LOCAL_KISMET_TRACE_DEBUG_IMPACTPOINT_SIZE = 16.f;
		if (bHit && OutHit.bBlockingHit)
		{
			// Red up to the blocking hit, green thereafter
			::DrawDebugCapsule(pWorld, Start, HalfHeight, Radius, Quat, TraceColor.ToFColor(true), bPersistent, LifeTime);
			::DrawDebugCapsule(pWorld, OutHit.Location, HalfHeight, Radius, Quat, TraceColor.ToFColor(true), bPersistent, LifeTime);
			::DrawDebugLine(pWorld, Start, OutHit.Location, TraceColor.ToFColor(true), bPersistent, LifeTime);
			::DrawDebugPoint(pWorld, OutHit.ImpactPoint, LOCAL_KISMET_TRACE_DEBUG_IMPACTPOINT_SIZE, TraceColor.ToFColor(true), bPersistent, LifeTime);

			::DrawDebugCapsule(pWorld, End, HalfHeight, Radius, Quat, TraceHitColor.ToFColor(true), bPersistent, LifeTime);
			::DrawDebugLine(pWorld, OutHit.Location, End, TraceHitColor.ToFColor(true), bPersistent, LifeTime);
		}
		else
		{
			// no hit means all red
			::DrawDebugCapsule(pWorld, Start, HalfHeight, Radius, Quat, TraceColor.ToFColor(true), bPersistent, LifeTime);
			::DrawDebugCapsule(pWorld, End, HalfHeight, Radius, Quat, TraceColor.ToFColor(true), bPersistent, LifeTime);
			::DrawDebugLine(pWorld, Start, End, TraceColor.ToFColor(true), bPersistent, LifeTime);
		}
	}

	return bHit;
}

bool AzureUtility::CapsuleTraceMulti(UWorld* pWorld, const FVector& Start, const FVector& End, const FQuat& Quat, float Radius, float HalfHeight, ECollisionChannel Channel, bool bTraceComplex, const TArray<AActor*>& ActorsToIgnore, EDrawDebugTrace::Type DrawDebugType, TArray<FHitResult>& OutHits, bool bIgnoreSelf, FLinearColor TraceColor/* = FLinearColor::Red*/, FLinearColor TraceHitColor/* = FLinearColor::Green*/, float DrawTime/* = 5.0f*/)
{
	static const FName CapsuleTraceMultiName(TEXT("AzureUtility::CapsuleTraceMulti"));
	FCollisionQueryParams Params(CapsuleTraceMultiName, bTraceComplex);
	Params.bReturnPhysicalMaterial = true;
	Params.bReturnFaceIndex = !UPhysicsSettings::Get()->bSuppressFaceRemapTable; // Ask for face index, as long as we didn't disable globally
	Params.bTraceAsyncScene = true;
	Params.AddIgnoredActors(ActorsToIgnore);

	bool const bHit = pWorld->SweepMultiByChannel(OutHits, Start, End, Quat, Channel, FCollisionShape::MakeCapsule(Radius, HalfHeight), Params);

	if (DrawDebugType != EDrawDebugTrace::Type::None)
	{
		bool bPersistent = DrawDebugType == EDrawDebugTrace::Persistent;
		float LifeTime = (DrawDebugType == EDrawDebugTrace::ForDuration) ? DrawTime : 0.f;
		static const float KISMET_TRACE_DEBUG_IMPACTPOINT_SIZE = 16.f;
		if (bHit && OutHits.Last().bBlockingHit)
		{
			// Red up to the blocking hit, green thereafter
			FVector const BlockingHitPoint = OutHits.Last().Location;
			::DrawDebugCapsule(pWorld, Start, HalfHeight, Radius, Quat, TraceColor.ToFColor(true), bPersistent, LifeTime);
			::DrawDebugCapsule(pWorld, BlockingHitPoint, HalfHeight, Radius, Quat, TraceColor.ToFColor(true), bPersistent, LifeTime);
			::DrawDebugLine(pWorld, Start, BlockingHitPoint, TraceColor.ToFColor(true), bPersistent, LifeTime);

			::DrawDebugCapsule(pWorld, End, HalfHeight, Radius, Quat, TraceHitColor.ToFColor(true), bPersistent, LifeTime);
			::DrawDebugLine(pWorld, BlockingHitPoint, End, TraceHitColor.ToFColor(true), bPersistent, LifeTime);
		}
		else
		{
			// no hit means all red
			::DrawDebugCapsule(pWorld, Start, HalfHeight, Radius, Quat, TraceColor.ToFColor(true), bPersistent, LifeTime);
			::DrawDebugCapsule(pWorld, End, HalfHeight, Radius, Quat, TraceColor.ToFColor(true), bPersistent, LifeTime);
			::DrawDebugLine(pWorld, Start, End, TraceColor.ToFColor(true), bPersistent, LifeTime);
		}

		// draw hits
		for (int32 HitIdx = 0; HitIdx < OutHits.Num(); ++HitIdx)
		{
			FHitResult const& Hit = OutHits[HitIdx];
			::DrawDebugPoint(pWorld, Hit.ImpactPoint, KISMET_TRACE_DEBUG_IMPACTPOINT_SIZE, (Hit.bBlockingHit ? TraceColor.ToFColor(true) : TraceHitColor.ToFColor(true)), bPersistent, LifeTime);
		}
	}

	return bHit;
}

bool AzureUtility::GetPosReachable(const FVector& pos)
{
	return exp_GetPixel_Reachable(VEC_RIGHT(pos)/UE_METRE_TRANS, VEC_FORWARD(pos)/UE_METRE_TRANS);
}

bool AzureUtility::GetPosMovable(const FVector& pos)
{
	return exp_GetPixel_Movable(VEC_RIGHT(pos)/UE_METRE_TRANS, VEC_FORWARD(pos)/UE_METRE_TRANS);
}

bool AzureUtility::CheckLinePointAvailable(bool bRealReachable, // true: reachmap, false: movemap
	const FVector& vStart, const FVector& vEnd, FVector& stoppoint)
{
	bool bRet = exp_CheckLinePointAvailable(bRealReachable,
		VEC_RIGHT(vStart)/UE_METRE_TRANS, VEC_FORWARD(vStart)/UE_METRE_TRANS,
		VEC_RIGHT(vEnd)/UE_METRE_TRANS, VEC_FORWARD(vEnd)/UE_METRE_TRANS,
		VEC_RIGHT(stoppoint), VEC_FORWARD(stoppoint)
	);
	VEC_RIGHT(stoppoint) *= UE_METRE_TRANS;
	VEC_FORWARD(stoppoint) *= UE_METRE_TRANS;
	return bRet;
}

bool AzureUtility::CheckArcPointAvailable(FVector vStart,FVector vEnd, FVector vAxis, FVector &outFirstInvalidePos)
{
	float oriZ = vStart.Z;
	vStart.Z = 0;
	vEnd.Z = 0;
	vAxis.Z = 0;


	float radius = (vStart - vAxis).Size();
	float angel = FMath::DegreesToRadians(AngleBetweenTwoDir(vStart - vAxis, vEnd - vAxis));
	// 每一步的弧长为1米
	float stepAngle = 100 / radius; 
	float total = angel / stepAngle;
	stepAngle = FMath::RadiansToDegrees(stepAngle);
	FVector lastpos = vStart;
	FVector tempStopPos;
	for (int i = 1; i < (int)total; ++i)
	{
		FVector t = RotateAround(vStart, vAxis, FVector::UpVector, i*stepAngle);
		if (!CheckLinePointAvailable(false, lastpos, t, outFirstInvalidePos))
		{
			//DrawDebugLine(AAzureEntryPoint::Instance->GetWorld(), FVector(t.X, t.Y, oriZ), FVector(t.X, t.Y, oriZ) + FVector::UpVector*1000, FColor::Orange, false, 3);
			return false;
		}
		lastpos = t;

		//DrawDebugLine(AAzureEntryPoint::Instance->GetWorld(), FVector(t.X, t.Y, oriZ), FVector(t.X, t.Y, oriZ) + FVector::UpVector * 1000, FColor::Green, false, 3);
	}

	return true;
}


bool AzureUtility::IsPosInCliffArea(const FVector& pos)
{
	return exp_GetPixel_Cliff(VEC_RIGHT(pos) / UE_METRE_TRANS, VEC_FORWARD(pos) / UE_METRE_TRANS);
}

bool AzureUtility::JudgeIsInsideTerrBuilding(const FVector& vPos, float fJudgeRadius, float fTestUpHei, float fYawDeg, int nCollisionSides, float fTestSidesLen)
{
	if (!AAzureEntryPoint::IsInit())
		return false;

	static const FName _TraceTag_JudgeIsUnderTerrBuilding = "IsInsideTerrBuilding";

	FHitResult hitInfo;
	FVector End;
	bool bRet;

	float fRoofUpHei = 0;

	//////////////////////////////////////////////////////////////////////////
	//	先向上
	End = vPos;
	VEC_UP(End) += fTestUpHei;
	bRet = GetHitPosInWorld(vPos, End, TRACE_CHN_TERRAIN_BUILDING, hitInfo, fJudgeRadius, 0, true, FQuat::Identity, _TraceTag_JudgeIsUnderTerrBuilding);

	if (nCollisionSides < 0)
	{
		//	<0：表示不检测顶的碰撞。其绝对值表示四周碰撞个数
		nCollisionSides = -nCollisionSides;

		//	但得使用顶的高度，用作后面向四周探测
		if (!bRet)
			fRoofUpHei = fTestUpHei;
		else
			fRoofUpHei = fTestUpHei* hitInfo.Time;
	}
	else
	{
		if (!bRet || hitInfo.bStartPenetrating)
			return false; // 向上碰不到，认为不在建筑里？

		fRoofUpHei = fTestUpHei* hitInfo.Time;
	}
	
	//////////////////////////////////////////////////////////////////////////
	//	再向四周
	if (nCollisionSides == 0) // <=0: 不向四周探测
		return true;

	if (nCollisionSides > 4)
		nCollisionSides = 4;

	FVector vStartPos = vPos;
	VEC_UP(vStartPos) += FMath::Max(fRoofUpHei - fJudgeRadius*0.5f, 0.f);

	FRotator rot(0, fYawDeg, 0);
	FVector vDir;
	int nCollideCount = 0;
	int nTryCount = 0;

	//	先向前
	++nTryCount;
	hitInfo.Init();
	vDir = rot.Vector();
	End = vStartPos + vDir * fTestSidesLen;
	bRet = GetHitPosInWorld(vStartPos, End, TRACE_CHN_TERRAIN_BUILDING, hitInfo, fJudgeRadius, 0, true, FQuat::Identity, _TraceTag_JudgeIsUnderTerrBuilding);
	if (bRet && !hitInfo.bStartPenetrating)
	{
		if (++nCollideCount >= nCollisionSides)
			return true;
	}
	if (nCollideCount + 4 - nTryCount  < nCollisionSides)
		return false;

	//	再转90度
	++nTryCount;
	hitInfo.Init();
	rot.Yaw += 90.f;
	vDir = rot.Vector();
	End = vStartPos + vDir * fTestSidesLen;
	bRet = GetHitPosInWorld(vStartPos, End, TRACE_CHN_TERRAIN_BUILDING, hitInfo, fJudgeRadius, 0, true, FQuat::Identity, _TraceTag_JudgeIsUnderTerrBuilding);
	if (bRet && !hitInfo.bStartPenetrating)
	{
		if (++nCollideCount >= nCollisionSides)
			return true;
	}
	if (nCollideCount + 4 - nTryCount < nCollisionSides)
		return false;

	//	再转90度
	++nTryCount;
	hitInfo.Init();
	rot.Yaw += 90.f;
	vDir = rot.Vector();
	End = vStartPos + vDir * fTestSidesLen;
	bRet = GetHitPosInWorld(vStartPos, End, TRACE_CHN_TERRAIN_BUILDING, hitInfo, fJudgeRadius, 0, true, FQuat::Identity, _TraceTag_JudgeIsUnderTerrBuilding);
	if (bRet && !hitInfo.bStartPenetrating)
	{
		if (++nCollideCount >= nCollisionSides)
			return true;
	}
	if (nCollideCount + 4 - nTryCount < nCollisionSides)
		return false;

	//	再转90度
	hitInfo.Init();
	rot.Yaw += 90.f;
	vDir = rot.Vector();
	End = vStartPos + vDir * fTestSidesLen;
	bRet = GetHitPosInWorld(vStartPos, End, TRACE_CHN_TERRAIN_BUILDING, hitInfo, fJudgeRadius, 0, true, FQuat::Identity, _TraceTag_JudgeIsUnderTerrBuilding);
	if (bRet && !hitInfo.bStartPenetrating)
	{
		if (++nCollideCount >= nCollisionSides)
			return true;
	}

	return false;
}

float AzureUtility::GetPreciseSupportHeiByPos(const FVector& curPos, float ext, float fAboveH1, float fAboveH2, float fAboveFinal)
{
	//	逐渐往上拉高（不要一次拉最高，避免上房），主要用于HostPlayer
	float fGndHei = VEC_UP(curPos);

	float fGndHei1 = fGndHei;
	FVector vTest = curPos;
	VEC_UP(vTest) = VEC_UP(curPos) + fAboveH1;
	bool bGotHei1 = GetSupportPlaneHeight(fGndHei1, vTest, ext);
	if (bGotHei1)
	{
		fGndHei = fGndHei1;
	}
	else
	{
		bool bGotHei2 = false;
		float fGndHei2 = fGndHei1;
		if (fAboveH2 > fAboveH1)
		{
			VEC_UP(vTest) = VEC_UP(curPos) + fAboveH2;
			bGotHei2 = GetSupportPlaneHeight(fGndHei2, vTest, ext);
		}

		if (!bGotHei2)
		{
			//	拉高到H2 trace不到，直接拉高到Final做trace
			if (fAboveFinal > fAboveH1 && fAboveFinal > fAboveH2)
			{
				VEC_UP(vTest) = VEC_UP(curPos) + fAboveFinal;
				GetSupportPlaneHeight(fGndHei, vTest, ext);
			}
			else
				fGndHei = fGndHei2;
		}
		else
		{
			//	拉高到H2有高度：使用H2的高度
			fGndHei = fGndHei2;
		}
	}

	//print("--- GetPreciseSupportHeiFromPos: x, y, z, H1, H2 => Y:", curPos.x, curPos.y, curPos.z, fGndHei1, fGndHei2, fGndHei);
	return fGndHei;
}

float AzureUtility::GetDestPosHeightFromCurPos(const FVector& vDestPos, const FVector& vCurPos, float fSplitDistH, float ext, float fAboveH1, float fAboveH2, float fAboveFinal)
{
	if (fSplitDistH < 0.5f * UE_METRE_TRANS)
		fSplitDistH = 0.5f * UE_METRE_TRANS; // 不能太密

	FVector vDirH = vDestPos - vCurPos;
	VEC_UP(vDirH) = 0;

	float fTotalDistH = 0;
	vDirH.ToDirectionAndLength(vDirH, fTotalDistH);

	int nSplit = FMath::FloorToInt(fTotalDistH / fSplitDistH);
	float fCurHei = VEC_UP(vCurPos);

	for (int i = 1; i < nSplit; ++i)
	{
		FVector vThisPos = vCurPos + vDirH * (i * UE_METRE_TRANS);
		VEC_UP(vThisPos) = fCurHei; // 以之前一格高度为基准获取新高度
		fCurHei = GetPreciseSupportHeiByPos(vThisPos, ext, fAboveH1, fAboveH2, fAboveFinal);
	}

	//	最后一个点
	FVector vFinalPos = vDestPos;
	VEC_UP(vFinalPos) = fCurHei; // 以之前一格高度为基准获取新高度
	fCurHei = GetPreciseSupportHeiByPos(vFinalPos, ext, fAboveH1, fAboveH2, fAboveFinal);
	return fCurHei;
}

FVector AzureUtility::GetDestJumpPos(const FVector& vStart, const FVector& vSpeedH, float total_time, float upward_time, float up_height, float down_height, float fSplitTime,
	float& retUpHei, float& retUpTime, float& retTotalTime)
{
	retUpHei = up_height;
	retUpTime = upward_time;
	retTotalTime = total_time;

	if (total_time <= 0 || upward_time < 0 || upward_time > total_time)
		return vStart;

	float _StartHeight = VEC_UP(vStart);
	float _MaxHeight = up_height + _StartHeight;

	float _StopHeight = _MaxHeight - down_height;

	float _UpAcceleration = 0;
	float _DownAcceleration = 0;
	float _StartYVelocity = 0;

	float _UpwardTime = upward_time;

	JumpPhase _CurPhase = JumpPhase::JP_UPWARD;

	if (_UpwardTime > 0) {
		_UpAcceleration = 2 * up_height / (_UpwardTime * _UpwardTime);
		_StartYVelocity = 2 * up_height / _UpwardTime;
	}
	else {
		_CurPhase = JumpPhase::JP_DOWNWARD;
	}

	float _DownTime = total_time - _UpwardTime;
	if (_DownTime > 0)
		_DownAcceleration = 2 * (_MaxHeight - _StopHeight) / (_DownTime * _DownTime);

	FVector cur_pos = vStart;
	FVector vStopPoint = cur_pos;

	float _TotalPlayed = 0;
	float _LastScecond = 0;
	float dt = fSplitTime;
	FVector delta = vSpeedH * dt;

	FVector vDirH = vSpeedH;
	VEC_UP(vDirH) = 0;
	vDirH.Normalize();

	while (true)
	{
		FVector prev_pos = cur_pos;
		cur_pos += delta;

		_TotalPlayed += dt;
		_LastScecond += dt;

		bool bReachStopHei = false;

		float preSeconds = _LastScecond;
		JumpPhase prePahse = _CurPhase;
		if (_CurPhase == JumpPhase::JP_UPWARD)
		{
			float h = _StartYVelocity*_LastScecond - 0.5f*_UpAcceleration*_LastScecond*_LastScecond + _StartHeight;

			bool bReachMaxHei = _StartYVelocity <= _UpAcceleration * _LastScecond;
			if (!bReachMaxHei && h <= _MaxHeight)
				VEC_UP(cur_pos) = h;

			if (bReachMaxHei || _LastScecond >= _UpwardTime)
			{
				VEC_UP(cur_pos) = _MaxHeight;
				_CurPhase = JumpPhase::JP_DOWNWARD;
				_LastScecond = 0;
			}
		}
		else if (_CurPhase == JumpPhase::JP_DOWNWARD)
		{
			float h = _MaxHeight - 0.5f*_DownAcceleration*_LastScecond*_LastScecond;

			bReachStopHei = h <= _StopHeight;
			if (!bReachStopHei)
			{
				VEC_UP(cur_pos) = h;
			}
		}

		bool bCanMove = CheckLinePointAvailable(true, prev_pos, cur_pos, vStopPoint);
		if (!bCanMove)
		{
			//	遇到不可达：直接返回
			cur_pos = prev_pos;
			_TotalPlayed -= dt;

			if (prePahse == JumpPhase::JP_UPWARD)
				retUpTime = preSeconds; // 并记录retUpTime
			break;
		}

		//	Trace
		FHitResult hitInfo;
		bool bRet = GetHitPosInWorld(prev_pos, cur_pos, TRACE_CHN_BLOCKMOVE, hitInfo, s_fPlayerMoveExt, s_fPlayerMoveHalfHei);

		if (bRet)
		{
			//	有碰撞
			float fHitHei = VEC_UP(hitInfo.Location) - s_fPlayerMoveHalfHei;
			if (fHitHei < VEC_UP(prev_pos) && fHitHei < VEC_UP(cur_pos))
			{
				//	高度保护！某些情况会拉到地底下？？
				cur_pos = prev_pos;
			}
			else
			{
				cur_pos = hitInfo.Location;
				VEC_UP(cur_pos) = fHitHei;
			}

			if (_CurPhase == JumpPhase::JP_UPWARD)
			{
				//	在上升，高度还是拉到尽量高？
				if (_MaxHeight > VEC_UP(cur_pos))
				{
					FVector vEndPos = cur_pos;
					VEC_UP(vEndPos) = _MaxHeight;
					bRet = GetHitPosInWorld(cur_pos, vEndPos, TRACE_CHN_BLOCKMOVE, hitInfo, s_fPlayerMoveExt, s_fPlayerMoveHalfHei);

					if (bRet)
					{
						//	不能到最高点：
						fHitHei = VEC_UP(hitInfo.Location) - s_fPlayerMoveHalfHei;

						if (fHitHei > VEC_UP(cur_pos))
							VEC_UP(cur_pos) = fHitHei;

						_MaxHeight = VEC_UP(cur_pos);
						retUpHei = _MaxHeight - _StartHeight; // 并记录retUpHei
					}
					else
					{
						//	能到最高点：
						VEC_UP(cur_pos) = _MaxHeight;
					}

					_TotalPlayed += dt;
					_LastScecond += dt;
				}
				else if (_MaxHeight < VEC_UP(cur_pos))
					VEC_UP(cur_pos) = _MaxHeight;

				//	开始下落
				_CurPhase = JumpPhase::JP_DOWNWARD;

				retUpTime = _LastScecond; // 并记录retUpTime
				_LastScecond = 0;
			}
			else
			{
				//	下降：直接返回
				break;
			}
		}

		if (_CurPhase == JumpPhase::JP_DOWNWARD && (bReachStopHei || _LastScecond >= _DownTime))
		{
			break;
		}
	}

	retTotalTime = _TotalPlayed;
	if (retTotalTime > total_time)
		retTotalTime = total_time;

	if (retUpTime > upward_time)
		retUpTime = upward_time;
	if (retUpTime > retTotalTime)
		retUpTime = retTotalTime;

	return cur_pos;
}

//	Flash move on direction
static const FName _TraceTag_FlashMoveOnDir = "FlashMoveOnDir";
float AzureUtility::FlashMoveOnDir(FVector& vDestPos, const FVector& vOrigStart,
	bool bForceDestOnGround, bool bCheckReachableOrMovable,
	const FVector& vDir, float fDist, bool bDist3D,
	float fStepDistH/*step dist horizontal*/,
	float fStepRaiseHei/*step raise height, < 0 means use default*/,
	float fMaxTotalRaiseHei/* Max total raise height*/,
	float fTraceDownDist/*Abs hight that trace down*/,
	float fStepFallHeight/*Abs step fall height*/)
{
	FVector vStartPos = vOrigStart;
	VEC_UP(vStartPos) += s_fPlayerMoveHalfHei + MIN_FLOOR_DIST;

	FVector vOrigStartPos = vStartPos;
	FVector vEndPos = vStartPos;

	FVector vStopPoint = vOrigStart;

	int nPredTestCount = 0;
	float fCurMovedDist = 0.f;
	FVector vMoved(ForceInitToZero);

	float fFaction = 0.f;
	bool bOnFlatGnd = true;

	float fSplitTraceDown = 0;
	float fTestDistH = fStepDistH;//bDist3D ? 0.25f : 0.9f;

	FVector vOriginDir = vDir;

	if (fDist < 0.1f)
		goto END;

	nPredTestCount = int(ceil(fDist / fTestDistH) + 0.5f);
	if (nPredTestCount < 1)
		goto END;

	VEC_UP(vOriginDir) = 0;
	vOriginDir.Normalize();

	if (fStepRaiseHei < 0.f)
		fStepRaiseHei = s_fPlayerMoveRaiseHei_Ground;

	if (fTraceDownDist < 0)
		fTraceDownDist = -fTraceDownDist;
	fSplitTraceDown = fTraceDownDist / nPredTestCount;

	if (fStepFallHeight < 0)
		fStepFallHeight = -fStepFallHeight;

	while (true)
	{
		float fThisTestDistH = fTestDistH;
		if (nPredTestCount > 1 // 不是一段走完
			&& fCurMovedDist + fTestDistH + 1e-1f > fDist)
		{
			//	最后一段：TestDist减半
			fThisTestDistH *= 0.5f;
		}

		FVector vDeltaH = vOriginDir * fThisTestDistH;
		bool bFlatGround = false;

		FVector vPrevEndPos = vEndPos;

		bool bCanMove = CheckLinePointAvailable(bCheckReachableOrMovable, vPrevEndPos, vStartPos + vDeltaH, vStopPoint);
		if (!bCanMove)
		{
			vEndPos = vPrevEndPos;
			break;
		}

		FHitResult hitInfo;
		bool bRet = GetHitPosInWorld(vStartPos, vStartPos + vDeltaH, TRACE_CHN_BLOCKMOVE, hitInfo, s_fPlayerMoveExt, s_fPlayerMoveHalfHei, true, FQuat::Identity, _TraceTag_FlashMoveOnDir);

		if (!bRet || hitInfo.Time > 0.2f)
		{
			//	Clear or moved some dist:
			vEndPos = vStartPos + vOriginDir*(hitInfo.Time*fThisTestDistH);

			//	Down trace to ground
			vStartPos = vEndPos;

			bool bStartSolid = false;

			float fRetHei = VEC_UP(vStartPos);

			hitInfo.Init();
			if (fSplitTraceDown > 0.f)
			{
				FVector vTemp = vStartPos;
				VEC_UP(vTemp) += fStepRaiseHei; // 抬高一点向下trace，否则会StartPenetrate..
				FVector vDown(0, 0, fSplitTraceDown + fStepRaiseHei);

				bool bRet1 = GetHitPosInWorld(vTemp, vTemp - vDown, TRACE_CHN_BLOCKMOVE, hitInfo, s_fPlayerMoveExt, s_fPlayerMoveHalfHei, true, FQuat::Identity, _TraceTag_FlashMoveOnDir);
				if (bRet1)
				{
					//	碰撞到地面：HitPos是准确的
					VEC_UP(hitInfo.Location) += MIN_FLOOR_DIST;
				}
				else
				{
					//	没碰到：用原位置直接下降高度
					hitInfo.Location = vStartPos;
					if (hitInfo.bStartPenetrating == 0)
					{
						VEC_UP(hitInfo.Location) -= fSplitTraceDown + MIN_FLOOR_DIST;
					}
					hitInfo.Normal = FVector::UpVector;
				}
			}
			else
			{
				hitInfo.Location = vStartPos;
				hitInfo.Normal = FVector::UpVector;
			}

			//	Check distance first
			vMoved = hitInfo.Location - vOrigStartPos;
			if (!bDist3D)
				VEC_UP(vMoved) = 0;
			vMoved.ToDirectionAndLength(vMoved, fCurMovedDist);
			if (fCurMovedDist > fDist + 1e-3f)
			{
				//	Dist Too Long: break
				vEndPos = vPrevEndPos;
				break;
			}

			if (VEC_UP(hitInfo.Normal) < s_SLOPE_UP_THRESH)
				bFlatGround = false;
			else
				bFlatGround = true;

			float fHitHei = VEC_UP(hitInfo.Location);
			if (fHitHei > fMaxTotalRaiseHei + VEC_UP(vOrigStartPos) // 总体不能超高
				|| bFlatGround && fHitHei > fStepRaiseHei + VEC_UP(vStartPos) // 不在坡上时：每一步也不能超高
				|| fHitHei + fStepFallHeight < VEC_UP(vStartPos) // 每一步不能下降太多
				)
			{
				//	Raise Too High or Fall Too low: break
				vEndPos = vPrevEndPos;
				break;
			}

			vEndPos = hitInfo.Location;
		}
		else
		{
			//	Not Clear:

			//	Step up some height and try again
			FVector vTemp = vStartPos;
			VEC_UP(vTemp) += fStepRaiseHei;

			hitInfo.Init();
			bRet = GetHitPosInWorld(vTemp, vTemp + vDeltaH, TRACE_CHN_BLOCKMOVE, hitInfo, s_fPlayerMoveExt, s_fPlayerMoveHalfHei, true, FQuat::Identity, _TraceTag_FlashMoveOnDir);
			if (!bRet || hitInfo.Time > 0.2f)
			{
				//	Clear or moved some dist:
				vEndPos = vTemp + vOriginDir*(hitInfo.Time*fThisTestDistH);

				//	Down trace to ground
				hitInfo.Init();
				if (fSplitTraceDown + fStepRaiseHei > 0.f)
				{
					vTemp = vEndPos;
					VEC_UP(vTemp) += fStepRaiseHei; // 抬高一点向下trace，否则会StartPenetrate..
					FVector vDown(0, 0, fSplitTraceDown + fStepRaiseHei);

					bool bRet1 = GetHitPosInWorld(vTemp, vTemp - vDown, TRACE_CHN_BLOCKMOVE, hitInfo, s_fPlayerMoveExt, s_fPlayerMoveHalfHei, true, FQuat::Identity, _TraceTag_FlashMoveOnDir);
					if (bRet1)
					{
						//	碰撞到地面：HitPos是准确的
						VEC_UP(hitInfo.Location) += MIN_FLOOR_DIST;
					}
					else
					{
						hitInfo.Location = vEndPos;
						if (hitInfo.bStartPenetrating == 0)
						{
							//	没碰到：用原位置直接下降高度
							VEC_UP(hitInfo.Location) -= fSplitTraceDown + MIN_FLOOR_DIST;
						}
						hitInfo.Normal = FVector::UpVector;
					}
				}
				else
				{
					hitInfo.Location = vEndPos;
					hitInfo.Normal = FVector::UpVector;
				}

				//	Check distance first
				vMoved = hitInfo.Location - vOrigStartPos;
				if (!bDist3D)
					VEC_UP(vMoved) = 0;
				vMoved.ToDirectionAndLength(vMoved, fCurMovedDist);
				if (fCurMovedDist > fDist + 1e-3f)
				{
					//	Dist Too Long: break
					vEndPos = vPrevEndPos;
					break;
				}

				if (VEC_UP(hitInfo.Normal) < s_SLOPE_UP_THRESH)
					bFlatGround = false;
				else
					bFlatGround = true;

				float fHitHei = VEC_UP(hitInfo.Location);
				if (fHitHei > fMaxTotalRaiseHei + VEC_UP(vOrigStartPos) // 总体不能超高
					|| bFlatGround && fHitHei > fStepRaiseHei + VEC_UP(vStartPos) // 不在坡上时：每一步也不能超高
					|| fHitHei + fStepFallHeight < VEC_UP(vStartPos) // 每一步不能下降太多
					)
				{
					//	Raise Too High or Fall Too low: break
					vEndPos = vPrevEndPos;
					break;
				}

				vEndPos = hitInfo.Location;
			}
			else
			{
				//	Not Clear: May be a wall is in front of us, end here
				vMoved = vStartPos - vOrigStartPos;
				if (!bDist3D)
					VEC_UP(vMoved) = 0;
				vMoved.ToDirectionAndLength(vMoved, fCurMovedDist);
				if (fCurMovedDist > fDist + 1e-3f)
				{
					//	Dist Too Long: break
					vEndPos = vPrevEndPos;
					break;
				}

				vEndPos = vStartPos;
				break;
			}
		}

		//	If continuously stand on slope, stop trying and end here
		if (!bOnFlatGnd && !bFlatGround)
		{
			//	TODO: Maybe we should check if the two slopes are back to back.
			//	If it is, that means host go over a mountain top
			vMoved = vStartPos - vOrigStartPos;
			if (!bDist3D)
				VEC_UP(vMoved) = 0;
			vMoved.ToDirectionAndLength(vMoved, fCurMovedDist);
			if (fCurMovedDist > fDist + 1e-3f)
			{
				//	Dist Too Long: break
				vEndPos = vPrevEndPos;
				break;
			}

			vEndPos = vStartPos;
			break;
		}

		bOnFlatGnd = bFlatGround;
		vStartPos = vEndPos;
	}

END:
	//	Calculate new position

	FVector vOrigEndPos = vEndPos;

	vMoved = vEndPos - vOrigStartPos;
	if (!bDist3D)
		VEC_UP(vMoved) = 0;
	vMoved.ToDirectionAndLength(vMoved, fCurMovedDist);

	if (fCurMovedDist > fDist + 1e-3f)
	{
		//	Dist Too Long: break
		//ASSERT(0 && "FlashMoveDir: Moved Dist Too Long!");

		vEndPos = vOrigStartPos;
		fCurMovedDist = 0.f;
	}
	else if (bForceDestOnGround && vEndPos != vOrigStartPos)
	{
		//	Force On Ground!
		FVector vTemp = vEndPos;
		VEC_UP(vTemp) += fStepRaiseHei; // 抬高一点向下trace，否则会StartPenetrate..
		FVector vDown(0, 0, 10000);
		FHitResult hitInfo;
		if (GetHitPosInWorld(vTemp, vTemp - vDown, TRACE_CHN_BLOCKMOVE, hitInfo, s_fPlayerMoveExt, s_fPlayerMoveHalfHei, true, FQuat::Identity, _TraceTag_FlashMoveOnDir)
			&& !hitInfo.bStartPenetrating)
		{
			//	碰撞到地面：HitPos是准确的
			VEC_UP(hitInfo.Location) += MIN_FLOOR_DIST;
			vEndPos = hitInfo.Location;
		}
	}

	vDestPos = vEndPos;
	VEC_UP(vDestPos) -= s_fPlayerMoveHalfHei;

	return fCurMovedDist;
}

//	判断点q是否在以(p1, p2)为中心，r为半径的圆柱之内
bool AzureUtility::IsPointInCylinder(const FVector& q, const FVector& p1, const FVector& p2, float r)
{
	FVector p2_p1 = p2 - p1;
	return FVector::DotProduct(q - p1, p2_p1) >= 0
		&& FVector::DotProduct(p2 - q, p2_p1) >= 0
		&& FVector::CrossProduct(q - p1, p2_p1).Size() <= r * p2_p1.Size();
}

TArray<char> AzureUtility::UncompressDataToArray(const void* data, int compressedDataSize, int uncompressedDataSize)
{
	TArray<char> arr;
	arr.AddUninitialized(uncompressedDataSize);
	if (!exp_zlib_uncompress(data, compressedDataSize, (unsigned char*)arr.GetData(), uncompressedDataSize))
		arr.Empty();
	return arr;
}

bool AzureUtility::AddActorSceneComponent(AActor* Obj, USceneComponent* SceneComp, bool bMustHaveRoot)
{
	USceneComponent * root = Obj->GetRootComponent();
	if (!root)
	{
		if (bMustHaveRoot)
			return false;

		Obj->SetRootComponent(SceneComp);
	}
	else
		SceneComp->AttachToComponent(root, FAttachmentTransformRules::KeepRelativeTransform);

	if (!SceneComp->IsRegistered())
		SceneComp->RegisterComponent();

	Obj->AddOwnedComponent(SceneComp);
	Obj->AddInstanceComponent(SceneComp);
	return true;
}

bool AzureUtility::AddActorComponent(AActor* Obj, UActorComponent* ActorComp)
{
	if (!Obj || !ActorComp)
		return false;

	USceneComponent * SceneCom = Cast<USceneComponent>(ActorComp);
	if (SceneCom)
	{
		bool ret = AddActorSceneComponent(Obj, SceneCom);
		return ret;
	}
	else
	{
		Obj->AddOwnedComponent(ActorComp);
		Obj->AddInstanceComponent(ActorComp);

		if (!ActorComp->IsRegistered())
			ActorComp->RegisterComponent();
	}
	return true;
}

bool AzureUtility::RemoveActorComponent(AActor * Obj, UActorComponent * ActorComp)
{
	if (!Obj || !ActorComp)
		return false;

	Obj->RemoveOwnedComponent(ActorComp);
	Obj->RemoveInstanceComponent(ActorComp);
	USceneComponent * SceneCom = Cast<USceneComponent>(ActorComp);
	if (SceneCom)
	{
		SceneCom->DetachFromComponent(FDetachmentTransformRules::KeepWorldTransform);
	}
	ActorComp->UnregisterComponent();
	ActorComp->DestroyComponent();

	return true;
}

bool AzureUtility::GetActorBonePose(FTransform& out, bool bWorldOrLocal, AActor* Obj, FString boneName)
{
	if (!Obj)
		return false;

	USkeletalMeshComponent *SkeletalMeshComponent = Obj->FindComponentByClass<USkeletalMeshComponent>();
	if (!SkeletalMeshComponent)
		return false;

	int32 BoneIndex = SkeletalMeshComponent->GetBoneIndex(*boneName);
	if (BoneIndex < 0)
		return false;

	if (bWorldOrLocal)
		out = SkeletalMeshComponent->GetBoneTransform(BoneIndex);
	else
		out = SkeletalMeshComponent->GetBoneTransform(BoneIndex, FTransform::Identity);

	return true;
}

void AzureUtility::SetShadowDistance(float dist)
{
	if (!AAzureEntryPoint::Instance)
		return;
	UWorld* pWorld = AAzureEntryPoint::Instance->GetWorld();
	if (!pWorld)
		return;

	float fDynamicShadowDistanceStationaryLight = dist;

	for (TObjectIterator<UDirectionalLightComponent> LightIt; LightIt; ++LightIt)
	{
		UDirectionalLightComponent* Light = *LightIt;
		if (Light && Light->IsVisible() && Light->GetWorld() == pWorld)
		{
			Light->SetDynamicShadowDistanceStationaryLight(fDynamicShadowDistanceStationaryLight);
		}
	}

}

float AzureUtility::GetShadowDistance()
{
	if (!AAzureEntryPoint::Instance)
		return 0.0f;
	UWorld* pWorld = AAzureEntryPoint::Instance->GetWorld();
	if (!pWorld)
		return 0.0f;

	for (TObjectIterator<UDirectionalLightComponent> LightIt; LightIt; ++LightIt)
	{
		UDirectionalLightComponent* Light = *LightIt;
		if (Light && Light->IsVisible() && Light->GetWorld() == pWorld)
		{
			return Light->DynamicShadowDistanceStationaryLight;
		}
	}
	return 0.0f;
}

void AzureUtility::SetShadowCascadesNum(int num)
{
	if (!AAzureEntryPoint::Instance)
		return;
	UWorld* pWorld = AAzureEntryPoint::Instance->GetWorld();
	if (!pWorld)
		return;

	for (TObjectIterator<UDirectionalLightComponent> LightIt; LightIt; ++LightIt)
	{
		UDirectionalLightComponent* Light = *LightIt;
		if (Light && Light->IsVisible() && Light->GetWorld() == pWorld)
		{
			Light->DynamicShadowCascades = num;
		}
	}
}

void AzureUtility::SetShadowBias(float bias)
{
	if (!AAzureEntryPoint::Instance)
		return;
	UWorld* pWorld = AAzureEntryPoint::Instance->GetWorld();
	if (!pWorld)
		return;

	for (TObjectIterator<UDirectionalLightComponent> LightIt; LightIt; ++LightIt)
	{
		UDirectionalLightComponent* Light = *LightIt;
		if (Light && Light->IsVisible() && Light->GetWorld() == pWorld)
		{
			Light->SetShadowBias(bias);
		}
	}
}

void AzureUtility::SetShadowBiasForEnvManager(AAzureEnvironmentManager * envManager, float bias)
{
	if (!AAzureEntryPoint::Instance)
		return;
	UWorld* pWorld = AAzureEntryPoint::Instance->GetWorld();
	if (!pWorld)
		return;

	static TSet<ADirectionalLight*> directionalLights;
	envManager->GetDirectionalLights(directionalLights);
	for (auto aLight : directionalLights)
	{
		ULightComponent* Light = aLight->GetLightComponent();
		if (Light)
		{
			Light->SetShadowBias(bias);
		}
	}
}

void AzureUtility::SetDepthOfField(bool bEnable, float fFocalRegion, float fScale, bool bEnableHighQuality, float fFarBlurSize, float fSpecifiedDofValue)
{
	if (!AAzureEntryPoint::Instance)
		return;

	UWorld* pWorld = AAzureEntryPoint::Instance->GetWorld();
	if (!pWorld)
		return;

	for (auto VolumeIt = pWorld->PostProcessVolumes.CreateIterator(); VolumeIt; ++VolumeIt)
	{
		APostProcessVolume* pVolume = dynamic_cast<APostProcessVolume*>(*VolumeIt);
		if (!pVolume)
			continue;
		if (pVolume->bHidden)
			continue;

		pVolume->Settings.bOverride_DepthOfFieldMethod = bEnable ? 1 : 0;
		if (bEnable)
			pVolume->Settings.DepthOfFieldMethod = DOFM_Gaussian;

		pVolume->Settings.bOverride_MobileHQGaussian = (bEnable && bEnableHighQuality) ? 1 : 0;
		pVolume->Settings.bMobileHQGaussian = (bEnable && bEnableHighQuality) ? 1 : 0;
		pVolume->Settings.bOverride_DepthOfFieldScale = bEnable ? 1 : 0;
		pVolume->Settings.bOverride_DepthOfFieldFocalDistance = bEnable ? 1 : 0;
		pVolume->Settings.bOverride_DepthOfFieldFocalRegion = bEnable ? 1 : 0;
		pVolume->Settings.bOverride_DepthOfFieldNearTransitionRegion = bEnable ? 1 : 0;
		pVolume->Settings.bOverride_DepthOfFieldFarTransitionRegion = bEnable ? 1 : 0;
		pVolume->Settings.bOverride_DepthOfFieldFarBlurSize = bEnable ? 1 : 0;
		pVolume->Settings.DepthOfFieldFocalDistance = 1;

		if (fSpecifiedDofValue >= 0.0f)
		{
			pVolume->Settings.DepthOfFieldFarBlurSize = fFarBlurSize * fSpecifiedDofValue;
			pVolume->Settings.DepthOfFieldFocalRegion = fFocalRegion * fSpecifiedDofValue;
			pVolume->Settings.DepthOfFieldScale = fScale * fSpecifiedDofValue;
		}
		else
		{
			pVolume->Settings.DepthOfFieldFarBlurSize = fFarBlurSize;
			pVolume->Settings.DepthOfFieldFocalRegion = fFocalRegion;
			pVolume->Settings.DepthOfFieldScale = fScale;
		}
	}
}

int32 AzureUtility::AddPostProcessBlendableToCamera(UMaterialInterface* Material, UCameraComponent* Camera, float Weight)
{
	int32 index = -1;
	if (Material && Camera)
	{
		index = Camera->PostProcessSettings.WeightedBlendables.Array.Num();
		Camera->PostProcessSettings.AddBlendable(Material, Weight);
	}
	return index;
}

void AzureUtility::RemovePostProcessBlendableFromCamera(UMaterialInterface* Material, UCameraComponent* Camera)
{
	if (Material && Camera)
	{
		Camera->PostProcessSettings.RemoveBlendable(Material);
	}
}

void AzureUtility::SetPostProcessBlendWeight(UCameraComponent* Camera, int32 Index, float Weight)
{
	if (Camera && Index >= 0)
	{
		Camera->PostProcessSettings.WeightedBlendables.Array[Index].Weight = Weight;
	}
}

void AzureUtility::AddPostProcessMaterial(UMaterialInterface *Material, float fWeight)
{
	if (!Material)
		return;

	if (!AAzureEntryPoint::Instance)
		return;
	UWorld* pWorld = AAzureEntryPoint::Instance->GetWorld();
	if (!pWorld)
		return;

	for (auto VolumeIt = pWorld->PostProcessVolumes.CreateIterator(); VolumeIt; ++VolumeIt)
	{
		APostProcessVolume* pVolume = Cast<APostProcessVolume>(*VolumeIt);
		if (!pVolume)
			continue;

		pVolume->Settings.AddBlendable(Material, fWeight);
	}
}

void AzureUtility::RemovePostProcessMaterial(UMaterialInterface *Material)
{
	if (!Material)
		return;

	if (!AAzureEntryPoint::Instance)
		return;
	UWorld* pWorld = AAzureEntryPoint::Instance->GetWorld();
	if (!pWorld)
		return;

	for (auto VolumeIt = pWorld->PostProcessVolumes.CreateIterator(); VolumeIt; ++VolumeIt)
	{
		APostProcessVolume* pVolume = Cast<APostProcessVolume>(*VolumeIt);
		if (!pVolume)
			continue;

		pVolume->Settings.RemoveBlendable(Material);
	}
}

void AzureUtility::AddPostProcessColorLUTTexture(UMaterialInterface *pParentMat, UTexture *pTexture, float fWeight)
{
	if (!pParentMat)
		return;
	if (!pTexture)
		return;
	if (!AAzureEntryPoint::Instance)
		return;
	UWorld* pWorld = AAzureEntryPoint::Instance->GetWorld();
	if (!pWorld)
		return;

	for (auto VolumeIt = pWorld->PostProcessVolumes.CreateIterator(); VolumeIt; ++VolumeIt)
	{
		APostProcessVolume* pVolume = Cast<APostProcessVolume>(*VolumeIt);
		if (!pVolume)
			continue;
		UMaterialInstanceDynamic *pExist = nullptr;
		for (int32 i = 0, count = pVolume->Settings.WeightedBlendables.Array.Num(); i < count; ++i)
		{
			UMaterialInstanceDynamic *pDyn = Cast<UMaterialInstanceDynamic>(pVolume->Settings.WeightedBlendables.Array[i].Object);
			if (pDyn && pDyn->Parent == pParentMat)
			{
				pExist = pDyn;
				break;
			}
		}
		if (!pExist)
		{
			pExist = UMaterialInstanceDynamic::Create(pParentMat, pVolume);
			pVolume->Settings.AddBlendable(pExist, fWeight);
		}

		pExist->SetTextureParameterValue(TEXT("LUT"), pTexture);
	}
}

void AzureUtility::RemovePostProcessColorLUTTexture()
{
	if (!AAzureEntryPoint::Instance)
		return;
	UWorld* pWorld = AAzureEntryPoint::Instance->GetWorld();
	if (!pWorld)
		return;
	UMaterialInterface *pParentMat = LoadObject<UMaterialInterface>(0, TEXT("/Game/Miscs/MobileColorGrading.MobileColorGrading"));
	if (!pParentMat)
		return;

	for (auto VolumeIt = pWorld->PostProcessVolumes.CreateIterator(); VolumeIt; ++VolumeIt)
	{
		APostProcessVolume* pVolume = Cast<APostProcessVolume>(*VolumeIt);
		if (!pVolume)
			continue;

		for (int32 i = 0, count = pVolume->Settings.WeightedBlendables.Array.Num(); i < count; ++i)
		{
			UMaterialInstanceDynamic *pDyn = Cast<UMaterialInstanceDynamic>(pVolume->Settings.WeightedBlendables.Array[i].Object);

			if (pDyn && pDyn->Parent == pParentMat)
			{
				// this might remove multiple
				pVolume->Settings.WeightedBlendables.Array.RemoveAt(i);
				--i;
				--count;
			}
		}
	}
}

void AzureUtility::SetScreenTint(bool bEnable, FLinearColor &lc, float saturation, float contrast, float vignette, UMaterialInterface *Material)
{
	if (!AAzureEntryPoint::Instance)
		return;
	UWorld* pWorld = AAzureEntryPoint::Instance->GetWorld();
	if (!pWorld)
		return;

	for (auto VolumeIt = pWorld->PostProcessVolumes.CreateIterator(); VolumeIt; ++VolumeIt)
	{
		APostProcessVolume* pVolume = Cast<APostProcessVolume>(*VolumeIt);
		if (!pVolume)
			continue;

		//pVolume->Settings.bOverride_FilmWhitePoint = bEnable ? 1 : 0;
		//pVolume->Settings.bOverride_FilmSaturation = bEnable ? 1 : 0;
		//pVolume->Settings.bOverride_FilmContrast = bEnable ? 1 : 0;
		if (bEnable)
		{
			//pVolume->Settings.FilmWhitePoint = lc;
			//pVolume->Settings.FilmSaturation = saturation;
			//pVolume->Settings.FilmContrast = contrast;

			if (Material)
				pVolume->Settings.AddBlendable(Material, 1);
		}
		else
		{
			if (Material)
				pVolume->Settings.RemoveBlendable(Material);
		}

		pVolume->Settings.bOverride_VignetteIntensity = vignette > 0;
		pVolume->Settings.VignetteIntensity = vignette;

		// Do not break, Apply to All PostProcessVolumes!
		//break;
	}
}

void AzureUtility::SetScreenFringeIntensity(float fringeIntensity)
{
	if (!AAzureEntryPoint::Instance)
		return;
	UWorld* pWorld = AAzureEntryPoint::Instance->GetWorld();
	if (!pWorld)
		return;
	for (auto VolumeIt = pWorld->PostProcessVolumes.CreateIterator(); VolumeIt; ++VolumeIt)
	{
		APostProcessVolume* pVolume = Cast<APostProcessVolume>(*VolumeIt);
		if (!pVolume)
			continue;

		pVolume->Settings.bOverride_SceneFringeIntensity = fringeIntensity > 0 ? 1 : 0;
		pVolume->Settings.SceneFringeIntensity = fringeIntensity;
		break;
	}
}

float AzureUtility::GetCurWorldVignetteIntensity()
{
	if (!AAzureEntryPoint::Instance)
		return 0;
	UWorld* pWorld = AAzureEntryPoint::Instance->GetWorld();
	if (!pWorld)
		return 0;
	float ret = 0;
	for (auto VolumeIt = pWorld->PostProcessVolumes.CreateIterator(); VolumeIt; ++VolumeIt)
	{
		APostProcessVolume* pVolume = Cast<APostProcessVolume>(*VolumeIt);
		if (!pVolume)
			continue;
		ret = pVolume->Settings.bOverride_VignetteIntensity ? pVolume->Settings.VignetteIntensity : 0;
		break;
	}
	return ret;
}

void AzureUtility::SetPostProcessFilmSaturation(float saturation)
{
	if (!AAzureEntryPoint::Instance)
		return;
	UWorld* pWorld = AAzureEntryPoint::Instance->GetWorld();
	if (!pWorld)
		return;
	for (auto VolumeIt = pWorld->PostProcessVolumes.CreateIterator(); VolumeIt; ++VolumeIt)
	{
		APostProcessVolume* pVolume = Cast<APostProcessVolume>(*VolumeIt);
		if (!pVolume)
			continue;
		pVolume->Settings.bOverride_FilmSaturation = saturation != -1 ? 1 : 0;
		pVolume->Settings.FilmSaturation = pVolume->Settings.bOverride_FilmSaturation == 1 ? saturation : 1;
		break;
	}
}

void AzureUtility::SetPostProcessColorSaturation(const FVector4& saturation)
{
	if (!AAzureEntryPoint::Instance)
		return;

	UWorld* pWorld = AAzureEntryPoint::Instance->GetWorld();
	if (!pWorld)
		return;
	
	for (auto VolumeIt = pWorld->PostProcessVolumes.CreateIterator(); VolumeIt; ++VolumeIt)
	{
		APostProcessVolume* pVolume = Cast<APostProcessVolume>(*VolumeIt);
		if (!pVolume)
			continue;

		pVolume->Settings.bOverride_ColorSaturation = saturation.X != -1 ? 1 : 0;
		if (pVolume->Settings.bOverride_ColorSaturation == 1)
		{
			pVolume->Settings.ColorSaturation = saturation;
		}
		else
		{
			pVolume->Settings.ColorSaturation.Set(1, 1, 1, 1);
		}
		break;
	}
}

float AzureUtility::GetCurWorldPostProcessFilmSaturation()
{
	if (!AAzureEntryPoint::Instance)
		return -1.0f;

	UWorld* pWorld = AAzureEntryPoint::Instance->GetWorld();
	if (!pWorld)
		return -1.0f;

	float ret = -1.0f;
	for (auto VolumeIt = pWorld->PostProcessVolumes.CreateIterator(); VolumeIt; ++VolumeIt)
	{
		APostProcessVolume* pVolume = Cast<APostProcessVolume>(*VolumeIt);
		if (!pVolume)
			continue;
		ret = pVolume->Settings.bOverride_FilmSaturation ? pVolume->Settings.FilmSaturation : -1.0f;
		break;
	}
	return ret;
}

FVector4 AzureUtility::GetCurWorldPostProcessColorSaturation()
{
	FVector4 ret(-1, -1, -1, -1);
	if (!AAzureEntryPoint::Instance)
		return ret;
	UWorld* pWorld = AAzureEntryPoint::Instance->GetWorld();
	if (!pWorld)
		return ret;
	for (auto VolumeIt = pWorld->PostProcessVolumes.CreateIterator(); VolumeIt; ++VolumeIt)
	{
		APostProcessVolume* pVolume = Cast<APostProcessVolume>(*VolumeIt);
		if (!pVolume)
			continue;
		ret = pVolume->Settings.bOverride_ColorSaturation ? pVolume->Settings.ColorSaturation : ret;
		break;
	}
	return ret;
}

UObject* AzureUtility::GetModelSkinComponent(const UMeshComponent* pMasterPoseComponent, const FName& Name)
{
	if (!pMasterPoseComponent)
		return nullptr;

	const TArray<USceneComponent*>& children = pMasterPoseComponent->GetAttachChildren();
	for (int32 ComponentIdx = children.Num() - 1; ComponentIdx >= 0; --ComponentIdx)
	{
		USceneComponent* pChildComponent = children[ComponentIdx];
		if (pChildComponent->GetFName() == Name)
		{
			if (pChildComponent->IsA(USkinnedMeshComponent::StaticClass())
				|| pChildComponent->IsA(UStaticMeshComponent::StaticClass()))
			{
				return pChildComponent;
			}
		}
	}
	return nullptr;
}

int s_RemoveMeshCmpRenameChoice = 0;
//	1: Rename with no flag
//	2: Rename with flag REN_ForceNoResetLoaders
//	Others: DoNothing (Not Rename)
static FAutoConsoleVariableRef CVarRemoveMeshCmpRenameChoice(
	TEXT("util.RemoveMeshCmpRenameChoice"),
	s_RemoveMeshCmpRenameChoice,
	TEXT("remove mesh component Rename choice: 1: Rename with no flag; 2: Rename with flag REN_ForceNoResetLoaders; Others: DoNothing (Not Rename)"),
	ECVF_Default
);
void AzureUtility::RemoveSkinOrStaticMeshComponent(USceneComponent* pInComp, bool bDestroyComp)
{
	if (!pInComp)
		return;

	USkinnedMeshComponent* pSkinnedComp = Cast<USkinnedMeshComponent>(pInComp);
	if (pSkinnedComp)
	{
		pSkinnedComp->SetMasterPoseComponent(nullptr);
		pSkinnedComp->SetSkeletalMesh(nullptr);
	}
	else
	{
		UStaticMeshComponent* pStaticComp = Cast<UStaticMeshComponent>(pInComp);
		if (pStaticComp)
		{
			pStaticComp->SetStaticMesh(nullptr);
		}
	}

	if (bDestroyComp)
	{
		pInComp->DetachFromComponent(FDetachmentTransformRules::KeepRelativeTransform);

		// Avoid NewObject find this destroying component..
		switch (s_RemoveMeshCmpRenameChoice)
		{
		case 1:
			pInComp->Rename(NULL);
			break;
		case 2:
			pInComp->Rename(NULL, NULL, REN_ForceNoResetLoaders);
			break;
		default: // do nothing
			break;
		}

		pInComp->DestroyComponent();
	}
}

bool AzureUtility::RemoveModelSkin(UMeshComponent* pMasterPoseComponent, const FName& Name, bool bDestroyComponent/* = false*/)
{
	if (!pMasterPoseComponent)
		return false;
	
	const TArray<USceneComponent*>& children = pMasterPoseComponent->GetAttachChildren();
	for (int32 ComponentIdx = children.Num() - 1; ComponentIdx >= 0; --ComponentIdx)
	{
		USceneComponent* pChildComponent = children[ComponentIdx];
		if (pChildComponent && pChildComponent->GetFName() == Name)
		{
			RemoveSkinOrStaticMeshComponent(pChildComponent, bDestroyComponent);
			return true;
		}
	}
	return false;
}

bool AzureUtility::AddModelSkin(UMeshComponent* pMasterPoseComponent, UMeshComponent* pSlavePoseComponent, const FName &SocketName, bool bSlave)
{
	if (!pMasterPoseComponent || !pSlavePoseComponent)
		return false;

	pSlavePoseComponent->AttachToComponent(pMasterPoseComponent, FAttachmentTransformRules::KeepRelativeTransform, SocketName);

	if (!pSlavePoseComponent->IsRegistered())
		pSlavePoseComponent->RegisterComponent();

	if (bSlave)
		SetSlaveSkinComponent(pMasterPoseComponent, pSlavePoseComponent);

	return true;
}

bool AzureUtility::UpdateAllSlaveBoneMap(USkinnedMeshComponent* pMasterPoseComponent)
{
	if (!pMasterPoseComponent)
		return false;

	auto children = pMasterPoseComponent->GetAttachChildren();
	for (int32 ComponentIdx = children.Num() - 1; ComponentIdx >= 0; --ComponentIdx)
	{
		USceneComponent* pChildComponent = children[ComponentIdx];
		USkinnedMeshComponent* pSlavePoseComponent = Cast<USkinnedMeshComponent>(pChildComponent);
		if (pSlavePoseComponent)
			pSlavePoseComponent->UpdateMasterBoneMap();
	}
	return true;
}

bool AzureUtility::SetSlaveSkinComponent(UMeshComponent* pMasterComp, UMeshComponent* pSlaveComp)
{
	USkinnedMeshComponent *pSkinnedMeshComMaster = Cast<USkinnedMeshComponent>(pMasterComp);
	USkinnedMeshComponent *pSkinnedMeshComSlave = Cast<USkinnedMeshComponent>(pSlaveComp);
	if (pSkinnedMeshComMaster && pSkinnedMeshComSlave)
	{
		pSkinnedMeshComSlave->SetMasterPoseComponent(pSkinnedMeshComMaster);
		return true;
	}
	else
		return false;
}

TArray<class UMaterialInterface*> AzureUtility::CreateDynamicMaterialForMeshComponent(UMeshComponent *pCom, UMaterialInterface *pSorceMaterial)
{
	TArray<class UMaterialInterface*> OutMaterials;
	int32 material_num = pCom->GetNumMaterials();
	if (material_num > 0)
	{
		OutMaterials.AddZeroed(material_num);
		//USkinnedMeshComponent *pSkinnedMesh = Cast<USkinnedMeshComponent>(pCom);

		for (int32 i = 0; i < material_num; ++i)
		{
			UMaterialInterface *material = pCom->GetMaterial(i);			
			if (!material)
				continue;

			//if (pSkinnedMesh && pSkinnedMesh->SkeletalMesh)
			//{
			//	const FSkeletalMaterial &SkeletalMaterial = pSkinnedMesh->SkeletalMesh->Materials[i];
			//	if (SkeletalMaterial.MaterialSlotName.ToString().StartsWith(TEXT("eye"))) //眼睛相关的材质不要有材质变化
			//	{
			//		UMaterialInstanceDynamic *pDynMaterial = pCom->CreateAndSetMaterialInstanceDynamic(i);
			//		OutMaterials[i] = pDynMaterial;
			//		continue;
			//	}
			//}

			UMaterialInstanceDynamic *pDynMaterial = pCom->CreateDynamicMaterialInstance(i, pSorceMaterial);
			if (pDynMaterial)
			{
				UTexture* OutValue = nullptr;
				if (material->GetTextureParameterValue(TEXT("BaseColor"), OutValue))
					pDynMaterial->SetTextureParameterValue(TEXT("BaseColor"), OutValue);
				if (material->GetTextureParameterValue(TEXT("RMO"), OutValue))
					pDynMaterial->SetTextureParameterValue(TEXT("RMO"), OutValue);
				if (material->GetTextureParameterValue(TEXT("Normal"), OutValue))
					pDynMaterial->SetTextureParameterValue(TEXT("Normal"), OutValue);
				pDynMaterial->SetScalarParameterValue(TEXT("Dissolve"), 0);
				OutMaterials[i] = pDynMaterial;
			}
		}
	}
	return OutMaterials;
}

void AzureUtility::CopySkinMeshComponent(USkeletalMeshComponent * src, USkeletalMeshComponent * des)
{
	if (!src || !des) return;
	
	des->SetRelativeTransform(src->GetRelativeTransform());
	des->SetSkeletalMesh(src->SkeletalMesh);
	des->SetAnimInstanceClass(src->AnimClass);

	const TArray<USceneComponent*> childArray = src->GetAttachChildren();
	for (USceneComponent* childComp : childArray)
	{
		childComp->AttachToComponent(des, FAttachmentTransformRules::KeepRelativeTransform, childComp->GetAttachSocketName());
	}
}

void AzureUtility::CalRelativePosInfo(const FVector & abs_pos, const FRotator & abs_rot, const FVector & carrier_pos, const FRotator & carrier_rot, FVector & rel_pos, FVector & rel_dir)
{
	FTransform tran1(abs_rot, abs_pos);
	FTransform tran2(carrier_rot, carrier_pos);

	FTransform tran3 = tran1 * tran2.Inverse();
	
	rel_pos = tran3.GetLocation();
	rel_dir = tran3.GetUnitAxis(EAxis::X);
}

void AzureUtility::CalcRelativeTransform(const FVector& abs_pos, const FVector& abs_rot, const FVector& abs_scale, const FVector& parent_pos, const FVector& parent_rot, const FVector& parent_scale,
	FVector& rel_pos, FVector& rel_rot, FVector& rel_scale)
{
	FTransform tran1(FRotator(abs_rot.X, abs_rot.Y, abs_rot.Z), abs_pos, abs_scale);
	FTransform tran2(FRotator(parent_rot.X, parent_rot.Y, parent_rot.Z), parent_pos, parent_scale);

	FTransform tran3 = tran1 * tran2.Inverse();

	rel_pos = tran3.GetLocation();
	rel_scale = tran3.GetScale3D();

	FRotator rot = tran3.GetRotation().Rotator();
	rel_rot = FVector(rot.Pitch, rot.Yaw, rot.Roll);
}

void AzureUtility::CalAbsPosInfo(const FVector & rel_pos, const FRotator & rel_rot, const FVector & carrier_pos, const FRotator & carrier_rot, FVector & abs_pos, FVector & abs_dir)
{
	FTransform tran1(rel_rot, rel_pos);
	FTransform tran2(carrier_rot, carrier_pos);

	FTransform tran3 = tran1 * tran2;
	abs_pos = tran3.GetLocation();
	abs_dir = tran3.GetUnitAxis(EAxis::X);
}

void AzureUtility::CalcWorldTransformByRelative(const FVector& rel_pos, const FVector& rel_rot, const FVector& rel_scale, const FVector& parent_pos, const FVector& parent_rot, const FVector& parent_scale, FVector& out_pos, FVector& out_rot, FVector& out_scale)
{
	FTransform tran1(FRotator(rel_rot.X, rel_rot.Y, rel_rot.Z), rel_pos, rel_scale);
	FTransform tran2(FRotator(parent_rot.X, parent_rot.Y, parent_rot.Z), parent_pos, parent_scale);

	FTransform tran3 = tran1 * tran2;
	out_pos = tran3.GetLocation();
	out_scale = tran3.GetScale3D();

	FRotator rot = tran3.GetRotation().Rotator();
	out_rot = FVector(rot.Pitch, rot.Yaw, rot.Roll);
}

void AzureUtility::ApplyCutWound(UMeshComponent* MeshComponent, const FTransform& Transform, UTexture* Scar, int Mask, FVector Scale, float Duration)
{
	TArray<UMaterialInterface*> Materials = MeshComponent->GetMaterials();
	int32 Index = 0;
	for (UMaterialInterface* Material : Materials)
	{
		if (Material)
		{
			UMaterialInstanceDynamic* MID = Cast<UMaterialInstanceDynamic>(Material);
			if (!MID)
			{
				MID = UMaterialInstanceDynamic::Create(Material, Material->GetOuter());
				MeshComponent->SetMaterial(Index, MID);
			}
			FVector Position = Transform.GetLocation() / Transform.GetScale3D();
			FVector BasisX = Transform.GetRotation().GetForwardVector();
			FVector BasisY = Transform.GetRotation().GetRightVector();
			FVector BasisZ = Transform.GetRotation().GetUpVector();
			FVector InverseScale = FVector::OneVector / Scale;
			float Time = MeshComponent->GetWorld()->GetTimeSeconds();

			float TimeA = MID->K2_GetScalarParameterValue("ProjectorA_Time");
			float TimeB = MID->K2_GetScalarParameterValue("ProjectorB_Time");
			TArray<FStringFormatArg> Arg;
			Arg.Add(TimeA < TimeB ? TEXT("A") : TEXT("B"));

			MID->SetVectorParameterValue(*FString::Format(TEXT("Projector{0}_BasisPosition"), Arg), Position);
			MID->SetVectorParameterValue(*FString::Format(TEXT("Projector{0}_BasisX"), Arg), BasisX);
			MID->SetVectorParameterValue(*FString::Format(TEXT("Projector{0}_BasisY"), Arg), BasisY);
			MID->SetVectorParameterValue(*FString::Format(TEXT("Projector{0}_BasisZ"), Arg), BasisZ);
			MID->SetVectorParameterValue(*FString::Format(TEXT("Projector{0}_Scale"), Arg), InverseScale);
			MID->SetScalarParameterValue(*FString::Format(TEXT("Projector{0}_Time"), Arg), Time);
			MID->SetScalarParameterValue(*FString::Format(TEXT("Projector{0}_Duration"), Arg), Duration);
			MID->SetScalarParameterValue(*FString::Format(TEXT("WoundPartMask{0}"), Arg), Mask);
			MID->SetTextureParameterValue(*FString::Format(TEXT("Projector{0}_Texutre"), Arg), Scar);
		}
		++Index;
	}
}

void AzureUtility::CutWound(ACharacter* Attacker, ACharacter* Attackee, FName AttackSocket, FName HitBone, float Roll, UTexture* Scar, UDataTable* DataTable, FVector Scale, float Duration, bool FixedSize, bool debug)
{
	USkeletalMeshComponent* AttackerSkeletalMesh = Attacker->GetMesh();
	if (!AttackerSkeletalMesh)
	{
		UE_LOG(LogTemp, Warning, TEXT("Attacker GetComponent USkeletalMeshComponent failed."));
		return;
	}
	uint16 Mask = 255U;
	if (DataTable)
	{
		UStrProperty* BoneName = Cast<UStrProperty>(DataTable->FindTableProperty("BoneName"));
		UArrayProperty* BodyPartID = Cast<UArrayProperty>(DataTable->FindTableProperty("BodyPartID"));

		if (BoneName && BodyPartID)
		{
			for (auto RowIt = DataTable->GetRowMap().CreateConstIterator(); RowIt; ++RowIt)
			{
				uint8* RowData = RowIt.Value();
				FString Name = BoneName->GetPropertyValue_InContainer(RowData, 0);
				FName PropertyBoneName = *Name.Replace(TEXT(" "), TEXT("-"));
				if (PropertyBoneName.IsEqual(HitBone))
				{
					auto InData = BodyPartID->GetPropertyValuePtr_InContainer(RowData, 0);
					FScriptArrayHelper ArrayHelper(BodyPartID, InData);
					Mask = 0U;
					for (int32 ArrayEntryIndex = 0; ArrayEntryIndex < ArrayHelper.Num(); ++ArrayEntryIndex)
					{
						const uint8* ArrayEntryData = ArrayHelper.GetRawPtr(ArrayEntryIndex);
						Mask += 1 << (*ArrayEntryData - 1);
					}
					break;
				}
			}
		}
	}

	USkeletalMeshComponent* AttackeeSkeletalMesh = Attackee->GetMesh();
	if (!AttackeeSkeletalMesh)
	{
		UE_LOG(LogTemp, Warning, TEXT("Attackee GetComponent USkeletalMeshComponent failed."));
		return;
	}
	
	FTransform AttackerTransform = Attacker->GetTransform();
	if (FixedSize)
	{
		const FVector& attackerTranslate = Attacker->GetCharacterMovement()->GetActorFeetLocation();
		const FVector& attackeeTranslate = Attackee->GetCharacterMovement()->GetActorFeetLocation();
		FVector Direction = attackeeTranslate - attackerTranslate;
		float Distance = FVector::Distance(attackeeTranslate, attackerTranslate);
		Direction.Normalize();
		AttackerTransform.SetTranslation(AttackerTransform.GetTranslation() + Direction * (Distance - Attackee->GetMovementComponent()->UpdatedComponent->Bounds.SphereRadius));
	}
	else
	{
		AttackerTransform.SetTranslation(AttackerSkeletalMesh->GetSocketTransform(AttackSocket).GetTranslation());
	}
	
	FQuat WeaponQuat = FRotator(0, 0, Roll).Quaternion();
	FQuat AttackerQuat = AttackerTransform.Rotator().Quaternion();
	FTransform AttackerWeaponTransform = FTransform(FRotator(AttackerQuat*WeaponQuat), AttackerTransform.GetTranslation());


	FTransform InversedHitBoneTransform = AttackeeSkeletalMesh->GetSocketTransform(HitBone).Inverse();
	int32 BoneIndex = AttackeeSkeletalMesh->GetBoneIndex(HitBone);
	const FReferenceSkeleton& RefSkeleton = AttackeeSkeletalMesh->SkeletalMesh->RefSkeleton;
	FTransform ComponentSpaceTransform = FAnimationRuntime::GetComponentSpaceTransformRefPose(RefSkeleton, BoneIndex);
	FTransform ScarTransform = (AttackerWeaponTransform * InversedHitBoneTransform * ComponentSpaceTransform).Inverse();

	AzureUtility::ApplyCutWound(AttackeeSkeletalMesh, ScarTransform, Scar, Mask, Scale, Duration);

	if (debug)
	{
		DrawDebugCoordinateSystem(Attacker->GetWorld(), AttackerWeaponTransform.GetTranslation(), FRotator(AttackerWeaponTransform.GetRotation()), 100, false, 10.f);
		DrawDebugCoordinateSystem(Attacker->GetWorld(), InversedHitBoneTransform.Inverse().GetTranslation(), FRotator(InversedHitBoneTransform.Inverse().GetRotation()), 40, false, 10.f);
	}
}

void AzureUtility::CutWoundTree(AActor* Attackee, FVector Position, FVector Dir, float Roll, FVector Scale, UTexture* Scar, float Duration)
{
	UStaticMeshComponent* AttackeeMesh = Cast<UStaticMeshComponent>(Attackee->GetComponentInChildren(TEXT("StaticMeshComponent")));
	if (!AttackeeMesh)
	{
		UE_LOG(LogTemp, Warning, TEXT("Attackee GetComponent UStaticMeshComponent failed."));
		return;
	}

	int Mask = 255;
	FVector Forward = Dir.ToOrientationQuat().GetForwardVector();
	FVector Right = Dir.ToOrientationQuat().GetRightVector();
	FVector Up = Dir.ToOrientationQuat().GetUpVector();
	FVector BasisX = Forward;
	FVector BasisY = Right.RotateAngleAxis(Roll, Forward);
	FVector BasisZ = FVector::CrossProduct(BasisY, BasisX);
	FVector InverseScale = FVector::OneVector / Scale;
	float Time = AttackeeMesh->GetWorld()->GetTimeSeconds();

	TArray<UMaterialInterface*> Materials = AttackeeMesh->GetMaterials();
	int32 Index = 0;
	for (UMaterialInterface* Material : Materials)
	{
		if (Material)
		{
			UMaterialInstanceDynamic* MID = Cast<UMaterialInstanceDynamic>(Material);
			if (!MID)
			{
				MID = UMaterialInstanceDynamic::Create(Material, Material->GetOuter());
				AttackeeMesh->SetMaterial(Index, MID);
			}

			float TimeA = MID->K2_GetScalarParameterValue("ProjectorA_Time");
			float TimeB = MID->K2_GetScalarParameterValue("ProjectorB_Time");
			TArray<FStringFormatArg> Arg;
			Arg.Add(TimeA < TimeB ? TEXT("A") : TEXT("B"));

			MID->SetVectorParameterValue(*FString::Format(TEXT("Projector{0}_BasisPosition"), Arg), Position);
			MID->SetVectorParameterValue(*FString::Format(TEXT("Projector{0}_BasisX"), Arg), BasisX);
			MID->SetVectorParameterValue(*FString::Format(TEXT("Projector{0}_BasisY"), Arg), BasisY);
			MID->SetVectorParameterValue(*FString::Format(TEXT("Projector{0}_BasisZ"), Arg), BasisZ);
			MID->SetVectorParameterValue(*FString::Format(TEXT("Projector{0}_Scale"), Arg), InverseScale);
			MID->SetScalarParameterValue(*FString::Format(TEXT("Projector{0}_Time"), Arg), Time);
			MID->SetScalarParameterValue(*FString::Format(TEXT("Projector{0}_Duration"), Arg), Duration);
			MID->SetScalarParameterValue(*FString::Format(TEXT("WoundPartMask{0}"), Arg), Mask);
			MID->SetTextureParameterValue(*FString::Format(TEXT("Projector{0}_Texutre"), Arg), Scar);
		}
		++Index;
	}
}

void AzureUtility::CutPersistentWound(ACharacter* Attacker, ACharacter* Attackee, UMaterialInterface* Painter, FName AttackSocket, FName HitBone, float Roll, UTexture* Scar, FVector Scale, float DepthFadeRange, float Opacity, bool FixedSize, bool debug)
{
	USkeletalMeshComponent* AttackerSkeletalMesh = Attacker->GetMesh();
	if (!AttackerSkeletalMesh)
	{
		UE_LOG(LogTemp, Warning, TEXT("Attacker GetComponent USkeletalMeshComponent failed."));
		return;
	}

	if (!Painter)
	{
		UE_LOG(LogTemp, Warning, TEXT("CutPersistentWound Painter is nil."));
		return;
	}

	FTransform AttackerTransform = Attacker->GetTransform();
	AttackerTransform.SetTranslation(AttackerSkeletalMesh->GetSocketTransform(AttackSocket).GetTranslation());
	if (FixedSize)
	{
		const FVector& attackerTranslate = Attacker->GetCharacterMovement()->GetActorFeetLocation();
		const FVector& attackeeTranslate = Attackee->GetCharacterMovement()->GetActorFeetLocation();
		FVector Direction = attackeeTranslate - attackerTranslate;
		float Distance = FVector::Distance(attackeeTranslate, attackerTranslate);
		Direction.Normalize();
		AttackerTransform.SetTranslation(Attacker->GetTransform().GetTranslation() + Direction * (Distance - Attackee->GetMovementComponent()->UpdatedComponent->Bounds.SphereRadius));
	}
	FQuat WeaponQuat = FRotator(0, 0, Roll).Quaternion();
	FQuat AttackerQuat = AttackerTransform.Rotator().Quaternion();
	FTransform AttackerWeaponTransform = FTransform(FRotator(AttackerQuat*WeaponQuat), AttackerTransform.GetTranslation());

	USkeletalMeshComponent* AttackeeSkeletalMesh = Attackee->GetMesh();
	if (!AttackeeSkeletalMesh)
	{
		UE_LOG(LogTemp, Warning, TEXT("Attackee GetComponent USkeletalMeshComponent failed."));
		return;
	}

	FTransform InversedHitBoneTransform = AttackeeSkeletalMesh->GetSocketTransform(HitBone).Inverse();
	int32 BoneIndex = AttackeeSkeletalMesh->GetBoneIndex(HitBone);
	const FReferenceSkeleton& RefSkeleton = AttackeeSkeletalMesh->SkeletalMesh->RefSkeleton;
	FTransform ComponentSpaceTransform = FAnimationRuntime::GetComponentSpaceTransformRefPose(RefSkeleton, BoneIndex);
	FTransform ScarTransform = (AttackerWeaponTransform * InversedHitBoneTransform * ComponentSpaceTransform);
	AzureUtility::ApplyCutPersistentWound(AttackeeSkeletalMesh, Painter , ScarTransform, Scar, DepthFadeRange,Scale, Opacity);
	if (debug)
	{
		DrawDebugCoordinateSystem(Attacker->GetWorld(), AttackerWeaponTransform.GetTranslation(), FRotator(AttackerWeaponTransform.GetRotation()), 200, false, 10.f);
		DrawDebugCoordinateSystem(Attacker->GetWorld(), InversedHitBoneTransform.Inverse().GetTranslation(), FRotator(InversedHitBoneTransform.Inverse().GetRotation()), 150, false, 10.f);
	}
}

void AzureUtility::ApplyCutPersistentWound(USkeletalMeshComponent* Skeletal, UMaterialInterface* Painter, const FTransform& Transform, UTexture* Scar, float DepthFadeRange, FVector Scale, float Opacity)
{
	if (!Painter || !Skeletal)
	{
		return;
	}
	TArray<UMaterialInterface*> Materials = Skeletal->GetMaterials();
	int32 Index = 0;
	
	UMaterialInstanceDynamic* MPainter = Cast<UMaterialInstanceDynamic>(Painter);
	if (!MPainter)
	{
		MPainter = UMaterialInstanceDynamic::Create(Painter, Painter->GetOuter());

		//FVector Position = Transform.GetLocation() / Transform.GetScale3D();
		FVector Position = Transform.GetLocation();
		FVector BasisX = Transform.GetRotation().GetForwardVector();
		FVector BasisY = Transform.GetRotation().GetRightVector();
		FVector BasisZ = Transform.GetRotation().GetUpVector();

		FVector DepthFadeRanges = Scale;
		float depth = FMath::Max(Scale.Y, Scale.Z);
		DepthFadeRanges.X = 100 * DepthFadeRange;
		DepthFadeRanges.Y = 2 * 100 * DepthFadeRange;
		DepthFadeRanges.Z = 0;

		Scale /= Skeletal->GetOwner()->GetTransform().GetScale3D();
		FVector InverseScale = FVector::OneVector / Scale;

		MPainter->SetVectorParameterValue("BasisPosition", Position);
		MPainter->SetVectorParameterValue("BasisX", BasisX);
		MPainter->SetVectorParameterValue("BasisY", BasisY);
		MPainter->SetVectorParameterValue("BasisZ", BasisZ);
		MPainter->SetVectorParameterValue("ProjectorRangeScale", Scale);
		MPainter->SetVectorParameterValue("ProjectorDepthFadeRanges", DepthFadeRanges);
		MPainter->SetScalarParameterValue("Opacity", Opacity);
		MPainter->SetTextureParameterValue("StampTex", Scar);

		//UE_LOG(LogTemp, Warning, TEXT("ApplyCutPersistentWound StampTex %s DepthFadeRanges x%f y:%f z:%f scale x%f y%f z:%f"),*Scar->GetPathName(), DepthFadeRanges.X, DepthFadeRanges.Y, DepthFadeRanges.Z, Scale.X, Scale.Y, Scale.Z);
	}

	for (UMaterialInterface* Material : Materials)
	{
		if (Material)
		{
			UMaterialInstanceDynamic* MID = Cast<UMaterialInstanceDynamic>(Material);
			if (!MID)
			{
				MID = UMaterialInstanceDynamic::Create(Material, Material->GetOuter());
				Skeletal->SetMaterial(Index, MID);
			}

			UTexture* rt = MID->K2_GetTextureParameterValue("RT");
			if (rt)
			{
				UTextureRenderTarget2D* RT = Cast<UTextureRenderTarget2D>(rt);

				if (RT)
				{
					UKismetRenderingLibrary::DrawMaterialToRenderTarget(Skeletal->GetWorld(), RT, MPainter);
				}
			}
		}
		++Index;
	}
}

void AzureUtility::ClearCutPersistentWound(USkeletalMeshComponent* Skeletal)
{
	if (!Skeletal)
	{
		return;
	}
	TArray<UMaterialInterface*> Materials = Skeletal->GetMaterials();
	int32 Index = 0;

	for (UMaterialInterface* Material : Materials)
	{
		if (Material)
		{
			UMaterialInstanceDynamic* MID = Cast<UMaterialInstanceDynamic>(Material);
			if (!MID)
			{
				MID = UMaterialInstanceDynamic::Create(Material, Material->GetOuter());
				Skeletal->SetMaterial(Index, MID);
			}

			UTexture* rt = MID->K2_GetTextureParameterValue("RT");
			if (rt)
			{
				UTextureRenderTarget2D* RT = Cast<UTextureRenderTarget2D>(rt);

				if (RT)
				{
					UKismetRenderingLibrary::ClearRenderTarget2D(Skeletal->GetWorld(), RT);
				}
			}
		}
		++Index;
	}
}

FName AzureUtility::GetNearestBone(USkinnedMeshComponent* SkeletalMesh, FVector Location)
{
	FName HitBone = NAME_None;
	float Nearest = FLT_MAX;
	float Current = 0;
	TArray<FName> BoneNames;
	SkeletalMesh->GetBoneNames(BoneNames);
	for (const FName& Name : BoneNames)
	{
		Current = FVector::Distance(SkeletalMesh->GetBoneLocation(Name), Location);
		if (Current < Nearest)
		{
			Nearest = Current;
			HitBone = Name;
		}
	}
	return HitBone;
}

FName AzureUtility::GetNearestPhysicBodyName(USkeletalMeshComponent* SkeletalMesh, FVector Location)
{
	FName NearestBoneName = NAME_None;
	float Nearest = FLT_MAX;
	float Current = 0;

	for (FBodyInstance* body : SkeletalMesh->Bodies)
	{
		FName boneName = SkeletalMesh->GetBoneName(body->InstanceBoneIndex);
		if (boneName != NAME_None)
		{
			Current = FVector::Distance(SkeletalMesh->GetBoneLocation(boneName), Location);
			if (Current < Nearest)
			{
				Nearest = Current;
				NearestBoneName = boneName;
			}
		}
	}
	return NearestBoneName;
}


FName AzureUtility::GetNearestPhysicBodyName(USkeletalMeshComponent * SkeletalMesh, FName boneName)
{
	if (SkeletalMesh->GetBodyInstance(boneName))
	{
		return boneName;
	}

	FVector location = SkeletalMesh->GetBoneLocation(boneName);
	return GetNearestPhysicBodyName(SkeletalMesh, location);
}

FName AzureUtility::GetNearestBoneInCollider(USkinnedMeshComponent* SkeletalMesh, FVector Location, UPrimitiveComponent* ColliderComponent, FName ParentBoneName)
{
	FName HitBone = NAME_None;
	if (!ParentBoneName.IsNone()) {
		const int32 ParentBoneIndex = SkeletalMesh->GetBoneIndex(ParentBoneName);
		if (ParentBoneIndex == INDEX_NONE)
		{
			return HitBone;
		}
	}

	float Nearest = FLT_MAX;
	FVector BoneLocation;
	float Current = 0;
	TArray<FName> BoneNames;
	SkeletalMesh->GetBoneNames(BoneNames);
	bool isInsideCollider = false;
	FBoxSphereBounds bounds = ColliderComponent->CalcBounds(ColliderComponent->GetComponentTransform());
	FBox box = bounds.GetBox();
	for (const FName& Name : BoneNames)
	{
		if (!ParentBoneName.IsNone() && !Name.IsEqual(ParentBoneName) && !SkeletalMesh->BoneIsChildOf(Name, ParentBoneName)) {
			continue;
		}
		BoneLocation = SkeletalMesh->GetBoneLocation(Name);
		if (box.IsInside(BoneLocation)) {
			Current = FVector::Distance(BoneLocation, Location);
			if (Current < Nearest)
			{
				Nearest = Current;
				HitBone = Name;
			}
		}
	}
	return HitBone;
}

bool AzureUtility::CheckIsInWaterMap(const FVector & V)
{
	return exp_GetPixel_Water(V.Y / UE_METRE_TRANS, V.X / UE_METRE_TRANS);
}

bool AzureUtility::CheckIsInWater(const FVector & testPos)
{
	bool isInWaterMap = CheckIsInWaterMap(testPos);
	if (!isInWaterMap)
		return false;

	FHitResult hitInfo;
	FVector vStart = testPos;
	vStart.Z += Azure::trace_water_up_dis;

	FVector vEnd = vStart;
	vEnd.Z -= Azure::trace_water_dis;

	if (!AAzureEntryPoint::Instance)
		return false;

	UWorld* pWorld = AAzureEntryPoint::Instance->GetWorld();
	FCollisionQueryParams Params(NAME_None, false); // Not Trace Complex!
	//Params.AddIgnoredActor(CharacterOwner);

	bool hit_terrain_building = pWorld->LineTraceSingleByChannel(hitInfo, vStart, vEnd, AzureUtility::TRACE_CHN_TERRAIN_BUILDING, Params);
	float z1 = 0.0f;
	if (hit_terrain_building)
		z1 = hitInfo.Location.Z;

	bool hit_water_surface = pWorld->LineTraceSingleByChannel(hitInfo, vStart, vEnd, AzureUtility::TRACE_CHN_WATERSUFACE, Params);
	float z2 = 0.0f;
	if (hit_water_surface)
		z2 = hitInfo.Location.Z;

	if (hit_terrain_building && hit_water_surface)
	{
		if (z1 > z2)//在岸边或桥上，下面有水,则认为不在水里，其他情况认为在水里或水下，大前提是在水图里
			return false;

		//如果hit_terrain_building 但没有hit_water_surface，可能是在水下，也可能在很高的桥上
		//既没有hit_terrain_building，也没有hit_water_surface，也可能水很深，打的深度不够，在水下
		//这里只为了区分在水图里，但是其实在岸边或桥上的情况
	}
	else if (hit_terrain_building && !hit_water_surface)//在很高的桥上，水下接近水底的地方这个条件也会满足，所有在主角swim状态不要调用这个来判断
	{
		return false;
	}

	return true;
}

bool AzureUtility::CheckIsInWater_Swim(const FVector& pos, FHitResult& hitInfo)
{
	FVector vEnd = pos;
	FVector vStart = pos;
	vStart.Z += Azure::trace_water_dis;

	if (!AAzureEntryPoint::Instance)
		return false;

	UWorld* pWorld = AAzureEntryPoint::Instance->GetWorld();
	FCollisionQueryParams Params(NAME_None, false); // Not Trace Complex!
	//Params.AddIgnoredActor(CharacterOwner);

	bool hit_water_surface = false;
	bool success = pWorld->LineTraceSingleByChannel(hitInfo, vStart, vEnd, AzureUtility::TRACE_CHN_WATERSUFACE, Params);
	if (success)
	{
		APhysicsVolume* pVolume = Cast<APhysicsVolume>(hitInfo.Actor.Get());
		if (pVolume)
		{
			if (pVolume->bWaterVolume)
			{
				hit_water_surface = true;
			}
		}
	}

	return hit_water_surface;
}

/*
// Helper function for ConvertMeshesToStaticMesh
void AzureUtility::SkinnedMeshToRawMeshes(USkinnedMeshComponent* InSkinnedMeshComponent, int32 InOverallMaxLODs, const FMatrix& InComponentToWorld, TArray<FRawMesh>& OutRawMeshes)
{
	// Export all LODs to raw meshes
	const int32 NumLODs = InSkinnedMeshComponent->MeshObject->GetSkeletalMeshResource().LODModels.Num();

	for (int32 OverallLODIndex = 0; OverallLODIndex < InOverallMaxLODs; OverallLODIndex++)
	{
		int32 LODIndexRead = FMath::Min(OverallLODIndex, NumLODs - 1);

		FRawMesh& RawMesh = OutRawMeshes[OverallLODIndex];
		const int32 BaseVertexIndex = RawMesh.VertexPositions.Num();

		FSkeletalMeshLODInfo& SrcLODInfo = InSkinnedMeshComponent->SkeletalMesh->LODInfo[LODIndexRead];

		// Get the CPU skinned verts for this LOD
		TArray<FFinalSkinVertex> FinalVertices;
		InSkinnedMeshComponent->GetCPUSkinnedVertices(FinalVertices, LODIndexRead);

		FSkeletalMeshResource& SkeletalMeshResource = InSkinnedMeshComponent->MeshObject->GetSkeletalMeshResource();
		FStaticLODModel& StaticLODModel = SkeletalMeshResource.LODModels[LODIndexRead];

		// Copy skinned vertex positions
		for (int32 VertIndex = 0; VertIndex < FinalVertices.Num(); ++VertIndex)
		{
			RawMesh.VertexPositions.Add(InComponentToWorld.TransformPosition(FinalVertices[VertIndex].Position));
		}

		const uint32 NumTexCoords = FMath::Min(StaticLODModel.VertexBufferGPUSkin.GetNumTexCoords(), (uint32)MAX_MESH_TEXTURE_COORDS);
		const int32 NumSections = StaticLODModel.Sections.Num();
		FRawStaticIndexBuffer16or32Interface& IndexBuffer = *StaticLODModel.MultiSizeIndexContainer.GetIndexBuffer();

		for (int32 SectionIndex = 0; SectionIndex < NumSections; SectionIndex++)
		{
			const FSkelMeshSection& SkelMeshSection = StaticLODModel.Sections[SectionIndex];
			if (!SkelMeshSection.bDisabled)
			{
				// Build 'wedge' info
				const int32 NumWedges = SkelMeshSection.NumTriangles * 3;
				for (int32 WedgeIndex = 0; WedgeIndex < NumWedges; WedgeIndex++)
				{
					const int32 VertexIndexForWedge = IndexBuffer.Get(SkelMeshSection.BaseIndex + WedgeIndex);

					RawMesh.WedgeIndices.Add(BaseVertexIndex + VertexIndexForWedge);

					const FFinalSkinVertex& SkinnedVertex = FinalVertices[VertexIndexForWedge];
					const FVector TangentX = InComponentToWorld.TransformVector(SkinnedVertex.TangentX);
					const FVector TangentZ = InComponentToWorld.TransformVector(SkinnedVertex.TangentZ);
					const FVector4 UnpackedTangentZ = SkinnedVertex.TangentZ;
					const FVector TangentY = (TangentX ^ TangentZ).GetSafeNormal() * UnpackedTangentZ.W;

					RawMesh.WedgeTangentX.Add(TangentX);
					RawMesh.WedgeTangentY.Add(TangentY);
					RawMesh.WedgeTangentZ.Add(TangentZ);

					for (uint32 TexCoordIndex = 0; TexCoordIndex < MAX_MESH_TEXTURE_COORDS; TexCoordIndex++)
					{
						if (TexCoordIndex >= NumTexCoords)
						{
							RawMesh.WedgeTexCoords[TexCoordIndex].AddDefaulted();
						}
						else
						{
							RawMesh.WedgeTexCoords[TexCoordIndex].Add(StaticLODModel.VertexBufferGPUSkin.GetVertexUV(VertexIndexForWedge, TexCoordIndex));
						}
					}

					if (StaticLODModel.ColorVertexBuffer.IsInitialized())
					{
						RawMesh.WedgeColors.Add(StaticLODModel.ColorVertexBuffer.VertexColor(VertexIndexForWedge));
					}
					else
					{
						RawMesh.WedgeColors.Add(FColor::White);
					}
				}

				int32 MaterialIndex = SkelMeshSection.MaterialIndex;
				// use the remapping of material indices for all LODs besides the base LOD 
				if (LODIndexRead > 0 && SrcLODInfo.LODMaterialMap.IsValidIndex(SkelMeshSection.MaterialIndex))
				{
					MaterialIndex = FMath::Clamp<int32>(SrcLODInfo.LODMaterialMap[SkelMeshSection.MaterialIndex], 0, InSkinnedMeshComponent->SkeletalMesh->Materials.Num());
				}

				// copy face info
				for (uint32 TriIndex = 0; TriIndex < SkelMeshSection.NumTriangles; TriIndex++)
				{
					RawMesh.FaceSmoothingMasks.Add(0); // Assume this is ignored as bRecomputeNormals is false
				}
			}
		}
	}
}*/

void AzureUtility::DebugUObject(AActor * p)
{
	if (!p)
		return;

	FString str;

	TArray<UObject *> AllCollectedComponents;
	p->CollectDefaultSubobjects(AllCollectedComponents, true);

	int num = AllCollectedComponents.Num();
	str = FString::Printf(TEXT("AllCollectedComponents Num %d"), num);
	MyPrintString(str);

	for (int i = 0; i < num; i++)
	{
		str = FString::Printf(TEXT("  %d: %s"), i, *AllCollectedComponents[i]->GetName());
		MyPrintString(str);
	}

	TArray<UObject *> DirectCollectedComponents;
	p->CollectDefaultSubobjects(DirectCollectedComponents, false);

	num = DirectCollectedComponents.Num();
	str = FString::Printf(TEXT("DirectCollectedComponents Num %d"), num);
	MyPrintString(str);

	for (int i = 0; i < num; i++)
	{
		str = FString::Printf(TEXT("  %d: %s"), i, *DirectCollectedComponents[i]->GetName());
		MyPrintString(str);
	}
}

void AzureUtility::RotateAround(FTransform & inOutTrans, FVector point, FVector axis, float angle)
{
	FTransform anchorTrans{ FRotationMatrix::MakeFromZ(axis).ToQuat(), point };
	inOutTrans.SetToRelativeTransform(anchorTrans);
	inOutTrans = inOutTrans * FTransform{ FRotator{0, angle, 0} } *anchorTrans;
}

FVector AzureUtility::RotateAround(FVector pos, FVector point, FVector axis, float angle)
{
	FTransform trans{ pos };
	RotateAround(trans, point, axis, angle);
	return trans.GetLocation();
}

float AzureUtility::AngleBetweenTwoDir(FVector dir1, FVector dir2)
{
	dir1.Normalize();
	dir2.Normalize();
	float angle = FMath::Acos( FVector::DotProduct(dir1, dir2));
	angle = FMath::RadiansToDegrees(angle);
	return angle;
}
