#include "ECDebug.h"
#include "Azure.h"
#include "ABaseDef.h"
#include "wLua/LuaInterface.h"
#include "AzureEntryPoint.h"
#include "Tickable.h"
#include "Misc/ScopeLock.h"
#include "FileSystem/IPlatformAFileWrapper.h"
#include "DeadLockDetector.h"
#include "LuaUtility/LuaUtility.h"
class ECDebugImp : public FOutputDevice, public FTickableGameObject
{
	wLua::Lua * m_wlua;

	enum class LogType
	{
		Error = 0,
		Assert = 1,
		Warning = 2,
		Log = 3,
		Exception = 4,
		Other = 10,
	};

	struct LogMessage
	{
		LogType type;
		astring str;
		astring catagory;
	};
	avector<LogMessage> m_savedLog;

	struct FLogOutput
	{
		FString message;
		ELogVerbosity::Type type;
		FName category;
	};
	avector<FLogOutput> m_LogOutput;
	avector<FLogOutput> m_LogOutput2;
	avector<FLogOutput> * m_LogOutputCurrent;

	float LastTime = 0;
	bool checkTime(float DeltaTime)
	{
		if (LastTime < 0.05f)
		{
			LastTime += DeltaTime;
			return true;
		}
		LastTime = 0;
		return false;
	}

	FCriticalSection OutputCS;

public:
	ECDebugImp(wLua::Lua *wlua):m_wlua(wlua)
	{
		m_LogOutputCurrent = &m_LogOutput;
		FOutputDeviceRedirector::Get()->AddOutputDevice(this);
	}

	virtual ~ECDebugImp()
	{
		FOutputDeviceRedirector::Get()->RemoveOutputDevice(this);
	}

	virtual void Tick(float DeltaTime) override
	{
		if (checkTime(DeltaTime))
			return;
		
		avector<FLogOutput> * LogOutputTemp;
		{
			FScopeLock Lock(&OutputCS);
			LogOutputTemp = m_LogOutputCurrent;
			m_LogOutputCurrent = m_LogOutputCurrent == &m_LogOutput ? &m_LogOutput2 : &m_LogOutput;
		}

		if (!LogOutputTemp->empty())
		{
			for (const auto& output : *LogOutputTemp)
				SerializeOutput(output);
			LogOutputTemp->clear();
		}
	}
	virtual bool IsTickable() const override { return true; }
	virtual TStatId GetStatId() const override { RETURN_QUICK_DECLARE_CYCLE_STAT(ECDebugImp, STATGROUP_Tickables); }

	virtual void Serialize(const TCHAR* V, ELogVerbosity::Type Verbosity, const class FName& Category) override
	{
		FScopeLock Lock(&OutputCS);

		m_LogOutputCurrent->push_back(FLogOutput());
		FLogOutput& LogOutput = m_LogOutputCurrent->back();
		LogOutput.message = V;
		LogOutput.type = Verbosity;
		LogOutput.category = Category;
	}

	void SerializeOutput(const FLogOutput& Output)
	{
		astring utf8 = TCHAR_TO_UTF8(*Output.message);
		astring catagory = TCHAR_TO_UTF8(*Output.category.ToString());
		if (Output.type == ELogVerbosity::Log || Output.type == ELogVerbosity::Display)
		{
			Log(LogType::Log, utf8, catagory);
		}
		else if (Output.type == ELogVerbosity::Warning)
		{
			Log(LogType::Warning, utf8, catagory);
		}
		else if (Output.type == ELogVerbosity::Error)
		{
			Log(LogType::Error, utf8, catagory);
		}
		// TODO
		else if (Output.type == ELogVerbosity::Fatal)
		{
			Log(LogType::Exception, utf8, catagory);
		}
		else
		{
			//Log(LogType::Other, utf8);
		}
	}
	void SaveLog(LogType type, const astring& str, const astring& catagory)
	{
		m_savedLog.push_back(LogMessage());
		LogMessage& msg = m_savedLog.back();
		msg.type = type;
		msg.str = str;
		msg.catagory = catagory;
	}
	bool RawLog(LogType type, const astring& str, const astring& catagory)
	{
		lua_State_Wrapper L = m_wlua->GetL();
		lua_checkstack(L, 5);
		lua_getglobal(L, "OnAzureLog");
		if (lua_isfunction(L, -1))
		{
			lua_pushinteger(L, (int)type);
			lua_pushstring(L, str.c_str());
			lua_pushstring(L, catagory.c_str());
			m_wlua->Call(3);
			return true;
		}
		else
		{
			lua_pop(L, 1);
			return false;
		}
	}
	void Log(LogType type, const astring& str, const astring& catagory)
	{
		if (m_wlua == nullptr)
		{
			SaveLog(type, str, catagory);
			return;
		}

		if (m_savedLog.size() > 0)
		{
			for (auto& msg : m_savedLog)
			{
				if (!RawLog(msg.type, msg.str, msg.catagory))
				{
					SaveLog(type, str, catagory);
					return;
				}
			}
			m_savedLog.clear();
		}
		if (!RawLog(type, str, catagory))
		{
			SaveLog(type, str, catagory);
		}
	}
};

#if PLATFORM_WINDOWS
#include "AzureLogTextBox.h"
#endif

void ECDebug::RegisterLogCallback(wLua::Lua *wlua)
{
	if (!m_DebugImp.IsValid())
	{
		m_DebugImp = MakeShareable(new ECDebugImp(wlua));
	}

#if PLATFORM_WINDOWS
	if (AAzureEntryPoint::Instance)
	{
		astring LuaPath = FPlatformAFileWrapper::GetAssetsPath(); +"/" + AAzureEntryPoint::Instance->LuaPath;
		UAzureLogTextBox::SetLuaPath(UTF8_TO_TCHAR(LuaPath.c_str()));
	}
#endif
}

//get lua stack in debugger
char const* luastack()
{
	extern char *const a_luastack();
	return a_luastack();
}

//get lua stack in debugger
char const* luastack(lua_State* L)
{
	extern char *const a_luastack(lua_State* L);
	return a_luastack(L);
}

//deref weak object ptr in debugger
FUObjectItem* weakobjitem(int ObjectIndex)
{
	FUObjectItem* const ObjectItem = GUObjectArray.IndexToObject(ObjectIndex);
	return ObjectItem;
}

void AzureDisableLuaThreadChecking()
{
	g_EnableLuaThreadChecking(false);
}

void AzureDisableDeadLockDetector()
{
	DeadLockDetector::instance().SetActive(false);
}

void AzureDisableAllSafeChecking()
{
	AzureDisableDeadLockDetector();
	AzureDisableLuaThreadChecking();
}
