#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "Engine/TextureRenderTarget2D.h"
#include "AzureOpenGLPBO.h"
#include "AzureTextureReadback.generated.h"

/** shared data between game thread and RHI thread */
struct FAzureTextureReadbackSharedData
{
	TArray<FColor> textureDataForGameThread;
	TArray<FColor> textureDataForReadback;
	bool dataFliped = false;
	FCriticalSection dataLock;
};

/**
	Azure: a texture readback actor.
	Texture content is read every frame. Most time consuming work will be done by non-main thread.
	Data is typically accessed in one pixel each time.
*/
UCLASS()
class AZURE_API AAzureTextureReadback : public AActor
{
	GENERATED_BODY()

public:	
	// Sets default values for this actor's properties
	AAzureTextureReadback();

	virtual void BeginPlay() override;
	virtual void Tick( float DeltaSeconds ) override;
	virtual void BeginDestroy() override;
	virtual bool IsReadyForFinishDestroy() override;
	virtual void FinishDestroy() override;

	/** read pixel color value, return true if success */
	UFUNCTION(BlueprintCallable)
	bool ReadPixel(int iX, int iY, FColor& outColor);

	/** turn on/off readback */
	UFUNCTION(BlueprintCallable)
	void EnableReadback(bool bEnabled);

	UFUNCTION(BlueprintCallable)
	bool IsReadbackEnabled();

	/** source render target to read. Format should be RGBA8��as this frame provide the best compatibility and best performance */
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	UTextureRenderTarget2D* sourceTexture;

private:
	bool m_bReadbackEnabled = true;

	//all data that GL thread want to access, need be reference counted
	TSharedRef<FAzureTextureReadbackSharedData> m_sharedData;

#if WITH_EDITOR
	virtual void PostEditChangeProperty( struct FPropertyChangedEvent& PropertyChangedEvent) override;
#endif

	void UpdateReadback_RenderThread(FRHICommandListImmediate& RHICmdList);
	void UpdateReadbackGeneric_RenderThread(FRHICommandListImmediate& RHICmdList);

#if HAS_AZURE_OPENGL_PBO
	void UpdateReadbackOpenGLPBO_RenderThread(FRHICommandListImmediate& RHICmdList);
	void StartOpenGLPBOReadback_RenderThread(FAzureOpenGLPBORef PboRHI);
	void FinishOpenGLPBOReadback_RenderThread(FAzureOpenGLPBORef PboRHI);

	//on OpenGL rhi, utilize pbo to avoid gpu stall
	TArray<FAzureOpenGLPBO*> m_PboResource;
#endif

	/** see UTexture::ReleaseFence */
	FRenderCommandFence ReleaseFence;
};
