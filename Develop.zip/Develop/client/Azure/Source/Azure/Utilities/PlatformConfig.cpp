//������platformConfig ���� lua ��ȡ�Ա�ɸ�����ش���
#if 0

#include "PlatformConfig.h"
#include "StreamingAssetHelper.h"
#include "Azure.h"

static bool _load_config(const TCHAR* szPath, FXmlFile& doc)
{
	auto ansiContent = StreamingAssetHelper::ReadFileText(szPath);
	if (ansiContent.size() > 0)
	{
		if (doc.LoadFile(UTF8_TO_TCHAR(&ansiContent[0]), EConstructMethod::ConstructFromBuffer))
		{
			return true;
		}
		else
		{
			UE_LOG(LogAzure, Warning, TEXT("Failed to load %s"), szPath);
			return false;
		}
	}
	else
	{
		UE_LOG(LogAzure, Warning, TEXT("Failed to read %s"), szPath);
	}
	return false;
}

AzurePlatformConfig& AzurePlatformConfig::Get()
{
	static AzurePlatformConfig Instance;
	return Instance;
}

void AzurePlatformConfig::Init()
{
	_load_config(TEXT("config/platform.xml"), PlatformConfig);
	_load_config(TEXT("config/all_platform_config.xml"), AllPlatformConfig);

	InitPlatformString();
	InitSpecialRegion();
	InitAllConfigNode();
}

void AzurePlatformConfig::InitAllConfigNode()
{
	m_allConfig = nullptr;
	FXmlFile *Config = GetAllPlatformConfig();
	if (Config)
	{
		FXmlNode *Root = Config->GetRootNode();
		if (Root)
		{
			m_allConfig = Root->FindChildNode(GetPlatform());
		}
	}
}

void AzurePlatformConfig::InitPlatformString()
{
	m_platformString = TEXT("default");

	FXmlNode *RootNode = GetPlatformConfig()->GetRootNode();
	if (RootNode)
	{
		m_platformString = RootNode->GetAttribute(TEXT("value"));
	}

	if (m_platformString == TEXT("default"))
	{
#if PLATFORM_DESKTOP
		m_platformString = TEXT("pc");
#elif PLATFORM_IOS
		m_platformString = TEXT("ios");
#elif PLATFORM_ANDROID
		m_platformString = TEXT("android-qa");
#else
		m_platformString = TEXT("other");
#endif
	}
}

void AzurePlatformConfig::InitSpecialRegion()
{
	m_specialRegion.Empty();
	FXmlNode *RootNode = GetPlatformConfig()->GetRootNode();
	if (RootNode)
	{
		m_specialRegion = RootNode->GetAttribute(TEXT("special_region"));
	}
}

void AzurePlatformConfig::Release()
{
	PlatformConfig.Clear();
	AllPlatformConfig.Clear();
	m_allConfig = nullptr;
	m_platformString.Empty();
	m_specialRegion.Empty();
}

FXmlFile* AzurePlatformConfig::GetPlatformConfig()
{
	return &PlatformConfig;
}

FXmlFile* AzurePlatformConfig::GetAllPlatformConfig()
{
	return &AllPlatformConfig;
}

const TCHAR* AzurePlatformConfig::GetPlatform()
{
	return *m_platformString;
}

const TCHAR* AzurePlatformConfig::GetSpecialRegion()
{
	return *m_specialRegion;
}

FXmlNode* AzurePlatformConfig::GetAllConfig()
{
	return m_allConfig;
}

FXmlNode* AzurePlatformConfig::GetConfig(const TCHAR *configName)
{
	FXmlNode *allConfig = GetAllConfig();
	if (allConfig)
	{
		return allConfig->FindChildNode(configName);
	}
	return nullptr;
}

#endif
