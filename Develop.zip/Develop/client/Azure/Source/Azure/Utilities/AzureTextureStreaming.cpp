// Fill out your copyright notice in the Description page of Project Settings.

#include "AzureTextureStreaming.h"
#include "Components/MeshComponent.h"
#include "Engine/Texture2D.h"
#include "ContentStreaming.h"
#include "Azure.h"

#if PLATFORM_SUPPORTS_TEXTURE_STREAMING
namespace
{
	bool IsTextureStreamingEnabled()
	{
		return IStreamingManager::Get().IsTextureStreamingEnabled();
	}
	bool IsCanCollectTexturesInActor(const AActor* InActor)
	{
		return InActor != nullptr
			&& !InActor->IsPendingKill()
			&& !InActor->bHidden;
	}
	bool IsCanCollectTexturesInComponent(const UMeshComponent* InMeshComponent)
	{
		return InMeshComponent != nullptr
			&& InMeshComponent->CanEverRender();
	}

	static constexpr uint32 NumInlinedActors = 24;
	typedef TArray<const AActor*, TInlineAllocator<NumInlinedActors>> InlineConstActorArray;	// intend to avoid heap allocation
}
#endif

FAzureFullMipsManager& FAzureFullMipsManager::Get()
{
	static FAzureFullMipsManager Instance;
	return Instance;
}

void FAzureFullMipsManager::Enable()
{
	if (IsEnabled())
	{
		return;
	}
	bEnabled = true;
}

void FAzureFullMipsManager::Disable()
{
	if (!IsEnabled())
	{
		return;
	}
	bEnabled = false;
	ClearTextureClearMemory();
}

bool FAzureFullMipsManager::IsEnabled()const
{
	return bEnabled;
}

void FAzureFullMipsManager::AddActor(AActor* InActor, FName InTag)
{
#if PLATFORM_SUPPORTS_TEXTURE_STREAMING
	if (InActor != nullptr)
	{
		if (FName* ExistedTag = RegisteredActors.Find(InActor))
		{
			UE_LOG(LogAzure, Warning, TEXT("FAzureFullMipsManager::AddActor, Actor %s already existed as %s and REPLACED!"), *GetNameSafe(InActor), *ExistedTag->ToString());
			*ExistedTag = InTag;
		}
		else
		{
			RegisteredActors.Add(InActor, InTag);
		}
	}
#endif
}

void FAzureFullMipsManager::RemoveActor(AActor* InActor)
{
#if PLATFORM_SUPPORTS_TEXTURE_STREAMING
	if (InActor != nullptr)
	{
		RegisteredActors.Remove(InActor);
	}
#endif
}

void FAzureFullMipsManager::RemoveActorByTag(FName InTag)
{
#if PLATFORM_SUPPORTS_TEXTURE_STREAMING
	for (auto It = RegisteredActors.CreateIterator(); It; ++It)
	{
		if (It.Value() == InTag)
		{
			It.RemoveCurrent();
		}
	}
#endif
}
void FAzureFullMipsManager::ListActors()const
{
#if PLATFORM_SUPPORTS_TEXTURE_STREAMING
	UE_LOG(LogAzure, Log, TEXT("FAzureFullMipsManager::ListActors->"));

	UE_LOG(LogAzure, Log, TEXT("Registered Actors(%d)->"), RegisteredActors.Num());
	for (const auto& Pair : RegisteredActors)
	{
		const TWeakObjectPtr<AActor>& Actor = Pair.Key;
		const FName& Tag = Pair.Value;
		UE_LOG(LogAzure, Log, TEXT("Tag:%s, Actor:%s, Will Provide Texture:%s"),
			*Tag.ToString(),
			*GetNameSafe(Actor.Get()),
			IsCanCollectTexturesInActor(Actor.Get()) ? TEXT("YES") : TEXT("NO")
		);
	}

	TArray<const AActor*> ValidActors;
	CollectActorsIncludingAttached(ValidActors);
	UE_LOG(LogAzure, Log, TEXT("All Valid Actors(%d)->"), ValidActors.Num());
	for (const AActor* ThisActor : ValidActors)
	{
		UE_LOG(LogAzure, Log, TEXT("Actor:%s"), *GetNameSafe(ThisActor));
	}
#endif
}

void FAzureFullMipsManager::ListTextures()const
{
#if PLATFORM_SUPPORTS_TEXTURE_STREAMING
	UE_LOG(LogAzure, Log, TEXT("FAzureFullMipsManager::ListTextures(%d)->"), FullMipTextures.Num());
	for (const TWeakObjectPtr<UTexture2D>& WeakTexture : FullMipTextures)
	{
		UE_LOG(LogAzure, Log, TEXT("Texture %s"), *GetFullNameSafe(WeakTexture.Get()));
	}
#endif
}

void FAzureFullMipsManager::Reset()
{
#if PLATFORM_SUPPORTS_TEXTURE_STREAMING
	RegisteredActors.Empty();
	ClearTextureClearMemory();
#endif
}

void FAzureFullMipsManager::Update()
{
#if PLATFORM_SUPPORTS_TEXTURE_STREAMING
	if (IsEnabled())
	{
		ClearTexturesWhenTextureStreamingClosed();
		UpdateTexturesWhenTextureStreamingOpen();
	}
#endif
}

void FAzureFullMipsManager::ClearTexturesWhenTextureStreamingClosed()
{
#if PLATFORM_SUPPORTS_TEXTURE_STREAMING
	if (bSavedTextureStreamingEnabled != IsTextureStreamingEnabled())
	{
		bSavedTextureStreamingEnabled = IsTextureStreamingEnabled();

		//	Restore and clear textures when r.TextureStreaming changes from open to closed
		if (!bSavedTextureStreamingEnabled)
		{
			ClearTextureClearMemory();
		}
	}
#endif
}

void FAzureFullMipsManager::UpdateTexturesWhenTextureStreamingOpen()
{
#if PLATFORM_SUPPORTS_TEXTURE_STREAMING
	if (IsTextureStreamingEnabled())
	{
		//	Clear first to ensure all unused textures are restored to not force mip levels to be resident
		ClearTextureReserveMemory();

		//	Mark newly collected textures now
		CollectTextures(FullMipTextures);
		ForceMiplevelsToBeResident(FullMipTextures);
	}
#endif
}

void FAzureFullMipsManager::CollectTextures(Textures& OutTextures)const
{
#if PLATFORM_SUPPORTS_TEXTURE_STREAMING
	TArray<const AActor*> ValidActors;
	CollectActorsIncludingAttached(ValidActors);
	for (const AActor* ThisActor : ValidActors)
	{
		CollectTexturesInActor(ThisActor, OutTextures);
	}
#endif
}

void FAzureFullMipsManager::CollectActorsIncludingAttached(TArray<const AActor*>& OutActors)const
{
#if PLATFORM_SUPPORTS_TEXTURE_STREAMING
	OutActors.Reset();

	TArray<const AActor*> NullActors;
	//	Init with valid out most Actors
	for (const auto& Pair : RegisteredActors)
	{
		const AActor* ThisActor = Pair.Key.Get();
		if (ThisActor)
		{
			if (IsCanCollectTexturesInActor(ThisActor))
			{
				OutActors.AddUnique(ThisActor);

				TArray<class AActor*> TempActors;
				ThisActor->GetAttachedActors(TempActors);
				for(auto actor : TempActors)
					OutActors.AddUnique(actor);
			}
		}
		else
		{
			NullActors.Add(ThisActor);
		}
	}

	for (auto actor : NullActors)
		RegisteredActors.Remove(actor);

#endif
}

void FAzureFullMipsManager::CollectTexturesInActor(const AActor* InActor, Textures& OutTextures)const
{
#if PLATFORM_SUPPORTS_TEXTURE_STREAMING
	TArray<UTexture*> Textures;

	TArray<UActorComponent*> MeshComponentsInActor = InActor->GetComponentsByClass(UMeshComponent::StaticClass());
	for (UActorComponent* Component : MeshComponentsInActor)
	{
		if (UMeshComponent* MeshComponent = Cast<UMeshComponent>(Component))
		{
			if (IsCanCollectTexturesInComponent(MeshComponent))
			{
				Textures.Reset();
				MeshComponent->GetUsedTextures(Textures, EMaterialQualityLevel::Num);

				for (UTexture* Texture : Textures)
				{
					if (UTexture2D* Texture2D = Cast<UTexture2D>(Texture))
					{
						if (IsStreamingTexture(Texture2D))
						{
							OutTextures.AddUnique(Texture2D);
						}
					}
				}
			}
		}
	}
#endif
}

void FAzureFullMipsManager::ClearTextureReserveMemory()
{
#if PLATFORM_SUPPORTS_TEXTURE_STREAMING
	SetTextureForceResidentFlag(FullMipTextures, false);
	FullMipTextures.Reset();	//	reserve memory for later use
#endif
}

void FAzureFullMipsManager::ClearTextureClearMemory()
{
#if PLATFORM_SUPPORTS_TEXTURE_STREAMING
	SetTextureForceResidentFlag(FullMipTextures, false);
	FullMipTextures.Empty();
#endif
}

void FAzureFullMipsManager::ClearForceMiplevelsToBeResident(Textures& InTextures)
{
#if PLATFORM_SUPPORTS_TEXTURE_STREAMING
	SetTextureForceResidentFlag(InTextures, false);
#endif
}

void FAzureFullMipsManager::ForceMiplevelsToBeResident(Textures& InTextures)
{
#if PLATFORM_SUPPORTS_TEXTURE_STREAMING
	SetTextureForceResidentFlag(InTextures, true);
#endif
}

void FAzureFullMipsManager::SetTextureForceResidentFlag(Textures& InTextures, bool bForceMiplevelsToBeResident)
{
#if PLATFORM_SUPPORTS_TEXTURE_STREAMING
	const int32 CinematicTextureGroups = 0;
	const float Seconds = -1.0f;

	for (TWeakObjectPtr<UTexture2D>& WeakTexture : InTextures)
	{
		if (UTexture2D* Texture2D = WeakTexture.Get())
		{
			Texture2D->SetForceMipLevelsToBeResident(Seconds, CinematicTextureGroups);
			Texture2D->bForceMiplevelsToBeResident = bForceMiplevelsToBeResident;
		}
	}
#endif
}