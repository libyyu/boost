// Fill out your copyright notice in the Description page of Project Settings.

#include "SkeletalMeshHelper.h"
#include "DrawDebugHelpers.h"
#include "Components/SkeletalMeshComponent.h"
#include "Rendering/SkeletalMeshRenderData.h"
#include "Rendering/SkeletalMeshLODRenderData.h"
#include "Containers/IndirectArray.h"
#include "SkeletalRenderPublic.h"

bool USkeletalMeshHelper::GetAnimatedVertexLocations(USkeletalMeshComponent * Mesh, bool isWorldSpace, TArray<FVector>& Locations, bool IsUseHighLODModel)
{
	if (!Mesh || !Mesh->SkeletalMesh)
	{
		return false;
	}

	Locations.Empty();

	TIndirectArray< FSkeletalMeshLODRenderData>& LODRenderDataArray = Mesh->GetSkeletalMeshRenderData()->LODRenderData;
	int32 LODLevel = IsUseHighLODModel ? 0 : LODRenderDataArray.Num() - 1;
	const FSkeletalMeshLODRenderData& LODData = LODRenderDataArray[LODLevel];
	FSkinWeightVertexBuffer& SkinWeightBuffer = *(Mesh->GetSkinWeightBuffer(LODLevel));
	if (!SkinWeightBuffer.GetNeedsCPUAccess())
	{
		return false;
	}

	TArray<FMatrix> RefToLocals;
	Mesh->GetCurrentRefToLocalMatrices(RefToLocals, LODLevel);
	USkeletalMeshComponent::ComputeSkinnedPositions(Mesh, Locations, RefToLocals, LODData, SkinWeightBuffer);

	if (isWorldSpace) {
		FTransform ToWorld = Mesh->GetComponentTransform();
		FVector WorldLocation = ToWorld.GetLocation();

		for (FVector& EachVectex : Locations)
		{
			EachVectex = WorldLocation + ToWorld.TransformVector(EachVectex);
		}
	}

	return true;
}

bool USkeletalMeshHelper::GetTriangleIndices(USkeletalMeshComponent * Mesh, TArray<uint32>& TriangleIndices, bool IsUseHighLODModel)
{
	if (!Mesh || !Mesh->SkeletalMesh)
	{
		return false;
	}
	TIndirectArray< FSkeletalMeshLODRenderData>& LODRenderDataArray = Mesh->GetSkeletalMeshRenderData()->LODRenderData;
	int32 LODLevel = IsUseHighLODModel ? 0 : LODRenderDataArray.Num() - 1;
	const FSkeletalMeshLODRenderData& LODData = LODRenderDataArray[LODLevel];
	/*
	FMultiSizeIndexContainerData IndicesData;
	LODData.MultiSizeIndexContainer.GetIndexBufferData(IndicesData);
	int32 IndicesNum = IndicesData.Indices.Num();
	TriangleIndices.Empty();
	TriangleIndices.SetNum(IndicesNum);
	for (int32 i = 0; i < IndicesNum; i++)
	{
		int32 Index = 0;
		UInt32ToInt32(IndicesData.Indices[i], &Index);
		TriangleIndices[i] = (Index);
	}
	*/

	LODData.MultiSizeIndexContainer.GetIndexBuffer(TriangleIndices);
	return true;
}

bool USkeletalMeshHelper::GetPlaneLineIntersectPoint(const FVector& PlaneNormal, const FVector& PlanePoint, const FVector& LineVector, const FVector& LinePoint, FVector& OutPoint)
{
	float vp1, vp2, vp3, n1, n2, n3, v1, v2, v3, m1, m2, m3, t, vpt;
	vp1 = PlaneNormal.X;
	vp2 = PlaneNormal.Y;
	vp3 = PlaneNormal.Z;

	n1 = PlanePoint.X;
	n2 = PlanePoint.Y;
	n3 = PlanePoint.Z;

	v1 = LineVector.X;
	v2 = LineVector.Y;
	v3 = LineVector.Z;

	m1 = LinePoint.X;
	m2 = LinePoint.Y;
	m3 = LinePoint.Z;

	vpt = v1 * vp1 + v2 * vp2 + v3 * vp3;

	if (vpt != 0)
	{
		t = ((n1 - m1) * vp1 + (n2 - m2) * vp2 + (n3 - m3) * vp3) / vpt;
		OutPoint.X = m1 + v1 * t;
		OutPoint.Y = m2 + v2 * t;
		OutPoint.Z = m3 + v3 * t;
		return true;
	}
	else
	{
		return false;
	}
}

bool USkeletalMeshHelper::IsPointinTriangle(const FVector& A, const FVector& B, const FVector& C, const FVector& P)
{
	FVector v0 = C - A;
	FVector v1 = B - A;
	FVector v2 = P - A;

	float dot00 = v0 | v0;
	float dot01 = v0 | v1;
	float dot02 = v0 | v2;
	float dot11 = v1 | v1;
	float dot12 = v1 | v2;

	float inverDeno = 1 / (dot00 * dot11 - dot01 * dot01);

	float u = (dot11 * dot02 - dot01 * dot12) * inverDeno;
	if (u < 0 || u > 1) // if u out of range, return directly
	{
		return false;
	}

	float v = (dot00 * dot12 - dot01 * dot02) * inverDeno;
	if (v < 0 || v > 1) // if v out of range, return directly
	{
		return false;
	}

	return u + v <= 1;
}

bool USkeletalMeshHelper::LineTraceOnSkeletalMesh(USkeletalMeshComponent * Mesh, const FVector& StartPoint, const FVector& EndPoint, const FBox& InBoxBound, bool IsUseHighLODModel, FVector& OutHitPoint)
{
	bool isSuccess;

	TArray<FVector> VertextLocations;
	isSuccess = GetAnimatedVertexLocations(Mesh, true, VertextLocations, IsUseHighLODModel);
	if (!isSuccess)
	{
		return false;
	}

	TArray<uint32> TriangleIndices;
    isSuccess =	GetTriangleIndices(Mesh, TriangleIndices, IsUseHighLODModel);
	if (!isSuccess)
	{
		return false;
	}

	FVector LineVector = EndPoint - StartPoint;
	FVector TriangleVertex0, TriangleVertex1, TriangleVertex2, TriangleNormal;
	FVector CurHitPoint, NearestHitPoint;
	float MinDistance = -1;
	for (int32 TriangleIndex = 0; TriangleIndex < TriangleIndices.Num() / 3; TriangleIndex++)
	{
		TriangleVertex0 = VertextLocations[TriangleIndices[TriangleIndex * 3]];
		TriangleVertex1 = VertextLocations[TriangleIndices[TriangleIndex * 3 + 1]];
		TriangleVertex2 = VertextLocations[TriangleIndices[TriangleIndex * 3 + 2]];

		if (InBoxBound.IsValid != 0) 
		{
			if (!InBoxBound.IsInside(TriangleVertex0) || !InBoxBound.IsInside(TriangleVertex1) || !InBoxBound.IsInside(TriangleVertex2))
			{
				continue;
			}
		}

		TriangleNormal = FVector::CrossProduct(TriangleVertex0 - TriangleVertex1, TriangleVertex2 - TriangleVertex1);
		TriangleNormal.Normalize();

		isSuccess = GetPlaneLineIntersectPoint(TriangleNormal, TriangleVertex0, LineVector, StartPoint, CurHitPoint);
		if (isSuccess)
		{
			if (IsPointinTriangle(TriangleVertex0, TriangleVertex1, TriangleVertex2, CurHitPoint))
			{
				FVector TriangleCenter = (TriangleVertex0 + TriangleVertex1 + TriangleVertex2) / 3;
				/*
				DrawDebugLine(Mesh->GetWorld(), TriangleVertex0, TriangleVertex1, FColor::Green, false, 0.5);
				DrawDebugLine(Mesh->GetWorld(), TriangleVertex1, TriangleVertex2, FColor::Green, false, 0.5);
				DrawDebugLine(Mesh->GetWorld(), TriangleVertex2, TriangleVertex0, FColor::Green, false, 0.5);
				DrawDebugDirectionalArrow(Mesh->GetWorld(), TriangleCenter, TriangleCenter + TriangleNormal*50, 10, FColor::Green, false, 0.5);
				DrawDebugPoint(Mesh->GetWorld(), CurHitPoint, 10, FColor::Blue, false, 0.5);
				*/
				
				float Distance = FVector::Distance(StartPoint, CurHitPoint);
				if (MinDistance < 0 || Distance < MinDistance)
				{
					MinDistance = Distance;
					NearestHitPoint = CurHitPoint;
				}
			}
		}
	}

	if (MinDistance >= 0) {
		OutHitPoint = NearestHitPoint;
		return true;
	}
	return false;
}


