#include "CoreMinimal.h"
#include <stdlib.h>
#include <string.h>

#if UE_GAME
#if PLATFORM_WINDOWS

	#include <malloc.h>

	FORCEINLINE void* azure_aligned_alloc(size_t size, size_t alignment)
	{
		void* ret = _aligned_malloc(size, alignment);
		check((((uintptr_t)ret) & (uintptr_t)(alignment - 1)) == 0);
		return ret;
	}

	FORCEINLINE void azure_aligned_free(void* ptr)
	{
		_aligned_free(ptr);
	}

	#define SUPPORT_AZURE_LUA_ALLOCATOR 1

#elif PLATFORM_IOS || PLATFORM_ANDROID

	#include <stdlib.h>

	FORCEINLINE void* azure_aligned_alloc(size_t size, size_t alignment)
	{
		void* ret;
		posix_memalign(&ret, alignment, size);
		check((((uintptr_t)ret) & (uintptr_t)(alignment - 1)) == 0);
		return ret;
	}

	FORCEINLINE void azure_aligned_free(void* ptr)
	{
		::free(ptr);
	}

	#define SUPPORT_AZURE_LUA_ALLOCATOR 1

#endif
#endif

#ifndef SUPPORT_AZURE_LUA_ALLOCATOR
#define SUPPORT_AZURE_LUA_ALLOCATOR 0
#endif


#if SUPPORT_AZURE_LUA_ALLOCATOR

#if UE_GAME && PLATFORM_WINDOWS && !UE_BUILD_SHIPPING
	#define AZURE_LUA_ALLOCATOR_STAT	1
#else
	#define AZURE_LUA_ALLOCATOR_STAT	0
#endif

// Fast memory functions for lua only
namespace AzureLuaMemFunc
{
	//void* (*LuaReallocFuncPtr)(void *ud, void* Ptr, size_t osize, size_t nsize) = nullptr;

	const unsigned int MemPageSize = 1024 * 16;
	const unsigned int MallocOverhead = 32;
	const uintptr_t MemPagePtrMask = (uintptr_t)~((uintptr_t)(MemPageSize - 1));
	const unsigned int MemBigPageSize = 1024 * 32;
	const uintptr_t MemBigPagePtrMask = (uintptr_t)~((uintptr_t)(MemBigPageSize - 1));
	const unsigned int MemPageFixedOverhead = 32;
	const unsigned int MemBlockMaxMediumSize = 2032;
	const unsigned int MemBlockMaxSize = 10896;
	const unsigned int UsableBlockSizeMax = MemBlockMaxSize;
	unsigned int NormalBlockMaxAllocCount = 0;
	unsigned int BigBlockMaxAllocCount = 0;
	unsigned int NormalBlockCurAllocCount = 0;
	unsigned int BigBlockCurAllocCount = 0;
	unsigned int NormalBlockExtraBudgetMultiplier = 0;
	unsigned int BigBlockExtraBudgetMultiplier = 0;
	const unsigned int ExtraBudgetDivisorBits = 8;

	const unsigned int MemBlockSizes[] =
	{
		16, 32, 48, 64, 80, 96,	112, 128,
		160, 192, 224, (272), 320, 368, 416, (480),
		(544), (624), (736), (816), (896), (1008), (1152), (1360), (1632),
		MemBlockMaxMediumSize, //(2032),
		(2336), (2720),	(3264), (4080), (4672), (5440), (6544), (8176),
		MemBlockMaxSize // 10896
	};

	const unsigned int TotalMemBucketCount = sizeof(MemBlockSizes) / sizeof(MemBlockSizes[0]);
	unsigned int MemBlockMaxCounts[TotalMemBucketCount];

	typedef uint8 BLOCK_BASE_TYPE;
	typedef BLOCK_BASE_TYPE* BLOCK_PTR;

	struct MemPageInfo
	{
		MemPageInfo* NextPageAddr;
		MemPageInfo* PrevPageAddr;
		BLOCK_PTR FirstBlockAddr;
		uint16 FreeBlockCount;
		//uint16 MaxBlockCount;
	};

	union BucketHeader
	{
		struct
		{
			MemPageInfo* FirstPageAddr;
			unsigned int TotalPageCount;
			//unsigned int TotalFreePageCount;
		};

		BLOCK_PTR FirstBlockAddr;
	};

	static TArray<void*> FreeMemPages;
	static TArray<void*> FreeMemBigPages;
	static BucketHeader BucketHeaders[TotalMemBucketCount];
	static unsigned char IndexFromSizeMap[UsableBlockSizeMax + 1];

#if AZURE_LUA_ALLOCATOR_STAT

	struct StatInfoPerBucket
	{
		unsigned int CurAllocSize;
		unsigned int PeakAllocSize;
		unsigned int RealUsedSize;
		unsigned int PeakUsedSize;

		void AddAllocSize(unsigned int Size)
		{
			CurAllocSize += Size;

			if (CurAllocSize > PeakAllocSize)
				PeakAllocSize = CurAllocSize;
		}

		void SubAllocSize(unsigned int Size)
		{
			CurAllocSize -= Size;
		}

		void AddRealUsedSize(unsigned int Size)
		{
			RealUsedSize += Size;

			if (RealUsedSize > PeakUsedSize)
				PeakUsedSize = RealUsedSize;
		}

		void SubRealUsedSize(unsigned int Size)
		{
			RealUsedSize -= Size;
		}
	};

	struct TotalStat
	{
		unsigned int TotalUserAllocSize = 0;
		unsigned int PeakTotalUserAllocSize = 0;
		unsigned int ManagedAllocSize = 0;
		unsigned int PeakManagedAllocSize = 0;
		unsigned int NormalBlockAllocSize = 0;
		unsigned int PeakNormalBlockSize = 0;
		unsigned int BigBlockAllocSize = 0;
		unsigned int PeakBigBlockAllocSize = 0;
		unsigned int UnmanagedAllocSize = 0;
		unsigned int PeakUnmanagedAllocSize = 0;

		void AddTotalUserAllocSize(unsigned int Size)
		{
			TotalUserAllocSize += Size;

			if (TotalUserAllocSize > PeakTotalUserAllocSize)
				PeakTotalUserAllocSize = TotalUserAllocSize;
		}

		void SubTotalUserAllocSize(unsigned int Size)
		{
			TotalUserAllocSize -= Size;
		}

		void AddManagedAllocSize(unsigned int Size)
		{
			ManagedAllocSize += Size;

			if (ManagedAllocSize > PeakManagedAllocSize)
				PeakManagedAllocSize = ManagedAllocSize;
		}

		void SubManagedAllocSize(unsigned int Size)
		{
			ManagedAllocSize -= Size;
		}

		void AddNormalBlockAllocSize(unsigned int Size)
		{
			NormalBlockAllocSize += Size;

			if (NormalBlockAllocSize > PeakNormalBlockSize)
				PeakNormalBlockSize = NormalBlockAllocSize;
		}

		void SubNormalBlockAllocSize(unsigned int Size)
		{
			NormalBlockAllocSize -= Size;
		}

		void AddBigBlockAllocSize(unsigned int Size)
		{
			BigBlockAllocSize += Size;

			if (BigBlockAllocSize > PeakBigBlockAllocSize)
				PeakBigBlockAllocSize = BigBlockAllocSize;
		}

		void SubBigBlockAllocSize(unsigned int Size)
		{
			BigBlockAllocSize -= Size;
		}

		void AddUnmanagedAllocSize(unsigned int Size)
		{
			UnmanagedAllocSize += Size;

			if (UnmanagedAllocSize > PeakUnmanagedAllocSize)
				PeakUnmanagedAllocSize = UnmanagedAllocSize;
		}

		void SubUnmanagedAllocSize(unsigned int Size)
		{
			UnmanagedAllocSize -= Size;
		}
	};

	static StatInfoPerBucket BucketStats[TotalMemBucketCount];
	static TotalStat sTotalStat;

#endif

	void LogStat(bool bClearPeak)
	{
#if AZURE_LUA_ALLOCATOR_STAT

		UE_LOG(LogTemp, Warning, TEXT("TotalUser: %dK, PeakUser: %dK, Managed: %dK, PeakManaged: %dK, Unmanaged: %dK, PeakUnmanaged: %dK"),
			sTotalStat.TotalUserAllocSize / 1024,
			sTotalStat.PeakTotalUserAllocSize / 1024,
			sTotalStat.ManagedAllocSize / 1024,
			sTotalStat.PeakManagedAllocSize / 1024,
			sTotalStat.UnmanagedAllocSize / 1024,
			sTotalStat.PeakUnmanagedAllocSize / 1024
		);

		UE_LOG(LogTemp, Warning, TEXT("NormalBlockUser: %dK, PeakNormal: %dK, NormalTotalAlloc: %dK,  BigBlockUser: %dK, PeakBig: %dK, BigTotalAlloc: %dK, NormalBlockFree: %dK, BigBlockFree: %dK"),
			sTotalStat.NormalBlockAllocSize / 1024,
			sTotalStat.PeakNormalBlockSize / 1024,
			NormalBlockCurAllocCount * MemPageSize / 1024,
			sTotalStat.BigBlockAllocSize / 1024,
			sTotalStat.PeakBigBlockAllocSize / 1024,
			BigBlockCurAllocCount * MemBigPageSize / 1024,
			FreeMemPages.Num() * MemPageSize / 1024,
			FreeMemBigPages.Num() * MemBigPageSize / 1024
		);

		if (bClearPeak)
		{
			sTotalStat.PeakTotalUserAllocSize = 0;
			sTotalStat.PeakManagedAllocSize = 0;
			sTotalStat.PeakNormalBlockSize = 0;
			sTotalStat.PeakBigBlockAllocSize = 0;
			sTotalStat.PeakUnmanagedAllocSize = 0;
		}

		for (unsigned int i = 0; i < TotalMemBucketCount; ++i)
		{
			UE_LOG(LogTemp, Warning, TEXT("Index: %d, BlockSize: %d, Alloc %dK, PeakAlloc: %dK, RealUsed: %dK, PeakReal: %dK"),
				i,
				MemBlockSizes[i],
				BucketStats[i].CurAllocSize / 1024,
				BucketStats[i].PeakAllocSize / 1024,
				BucketStats[i].RealUsedSize / 1024,
				BucketStats[i].PeakUsedSize / 1024
			);

			if (MemBlockMaxMediumSize == MemBlockSizes[i])
			{
				UE_LOG(LogTemp, Warning, TEXT("Big Block Start"));
			}

			if (bClearPeak)
			{
				BucketStats[i].PeakAllocSize = 0;
				BucketStats[i].PeakUsedSize = 0;
			}
		}
#endif
	}

	FORCEINLINE bool CheckCurrentAllocSizeExceeding(unsigned int& BlockCurAllocCount, const unsigned int BlockMaxAllocCount,
		const unsigned int ExtraBudgetMultiplier, TArray<void*>& CurFreePages)
	{
		if (BlockCurAllocCount > BlockMaxAllocCount)
		{
			unsigned CurFreeCount = CurFreePages.Num();
			unsigned int ExtraFreeBudget = (((BlockCurAllocCount - CurFreeCount) * ExtraBudgetMultiplier) >> ExtraBudgetDivisorBits);

			if (CurFreeCount >= ExtraFreeBudget)
				return true;
		}

		return false;
	}

	void InitLuaAllocatorRaw(unsigned int NormalBlockMemReserved, unsigned int BigBlockMemReserved,
		unsigned int NormalBlockMaxAllocSize, unsigned int BigBlockMaxAllocSize,
		float NormalBlockExtraBudgetRatio, float BigBlockExtraBudgetRatio)
	{
#if !UE_GAME
		return;
#endif

		static bool sInitFlag = false;

		if (sInitFlag)
			return;

		sInitFlag = true;

		{
#if AZURE_LUA_ALLOCATOR_STAT
			FMemory::Memset(BucketStats, 0, sizeof(BucketStats));
#endif
			FMemory::Memset(BucketHeaders, 0, sizeof(BucketHeaders));
			check(sizeof(MemPageInfo) <= MemPageFixedOverhead);
			unsigned int CurBucketIndex = 0;
			unsigned int CurBlockSize = MemBlockSizes[CurBucketIndex];
			check(!(CurBlockSize % 16));

			for (unsigned int i = 0; i <= UsableBlockSizeMax; ++i)
			{
				if (i > CurBlockSize)
				{
					CurBlockSize = MemBlockSizes[++CurBucketIndex];
					check(!(CurBlockSize % 16));
				}

				IndexFromSizeMap[i] = CurBucketIndex;
			}

			{
				FreeMemPages.Reserve(4096 - 1);
				FreeMemBigPages.Reserve(1024 - 1);
			}

			{
				for (unsigned int i = 0; i < TotalMemBucketCount; ++i)
				{
					auto CurBlockSize = MemBlockSizes[i];

					if (CurBlockSize <= MemBlockMaxMediumSize)
						MemBlockMaxCounts[i] = (MemPageSize - MallocOverhead - MemPageFixedOverhead) / CurBlockSize;
					else
						MemBlockMaxCounts[i] = (MemBigPageSize - MallocOverhead - MemPageFixedOverhead) / CurBlockSize;
				}
			}
		}

		NormalBlockMaxAllocCount = NormalBlockMaxAllocSize / MemPageSize;
		BigBlockMaxAllocCount = BigBlockMaxAllocSize / MemBigPageSize;

		NormalBlockExtraBudgetRatio = FMath::Clamp(NormalBlockExtraBudgetRatio, 0.0f, 1.0f);
		BigBlockExtraBudgetRatio = FMath::Clamp(BigBlockExtraBudgetRatio, 0.0f, 1.0f);
		NormalBlockExtraBudgetMultiplier = (unsigned int)(NormalBlockExtraBudgetRatio * (float)(1 << ExtraBudgetDivisorBits));
		BigBlockExtraBudgetMultiplier = (unsigned int)(BigBlockExtraBudgetRatio * (float)(1 << ExtraBudgetDivisorBits));

		unsigned int i;

		for (i = 0; i < NormalBlockMemReserved / MemPageSize; ++i)
		{
			void* MemPage = azure_aligned_alloc(MemPageSize - MallocOverhead, MemPageSize);
			FreeMemPages.Push(MemPage);
			NormalBlockCurAllocCount++;
		}

		for (i = 0; i < BigBlockMemReserved / MemBigPageSize; ++i)
		{
			void* MemPage = azure_aligned_alloc(MemBigPageSize - MallocOverhead, MemBigPageSize);
			FreeMemBigPages.Push(MemPage);
			BigBlockCurAllocCount++;
		}
	}

	void ReleaseLuaAllocator()
	{
		for (void* p : FreeMemPages)
		{
			azure_aligned_free(p);
		}
		for (void* p : FreeMemBigPages)
		{
			azure_aligned_free(p);
		}
	}

	FORCEINLINE MemPageInfo* AllocOnePage(unsigned int BucketIndex)
	{
		unsigned int BlockSize = MemBlockSizes[BucketIndex];
		MemPageInfo* MemPage;
		unsigned int CurMemPageSize;
		TArray<void*>* CurFreePages;
		unsigned int* pCurAllocCount;

		if (BlockSize <= MemBlockMaxMediumSize)
		{
			CurMemPageSize = MemPageSize;
			CurFreePages = &FreeMemPages;
			pCurAllocCount = &NormalBlockCurAllocCount;
		}
		else
		{
			CurMemPageSize = MemBigPageSize;
			CurFreePages = &FreeMemBigPages;
			pCurAllocCount = &BigBlockCurAllocCount;
		}

		if (CurFreePages->Num())
		{
			MemPage = (MemPageInfo*)CurFreePages->Pop(false);
		}
		else
		{
			MemPage = (MemPageInfo*)azure_aligned_alloc(CurMemPageSize - MallocOverhead, CurMemPageSize);
			(*pCurAllocCount)++;
		}

		MemPage->NextPageAddr = nullptr;
		MemPage->PrevPageAddr = nullptr;
		BLOCK_PTR pFirtBlock = (BLOCK_PTR)MemPage + MemPageFixedOverhead;
		*(BLOCK_PTR*)pFirtBlock = nullptr;
		MemPage->FirstBlockAddr = pFirtBlock;
		unsigned int BlockCount = MemBlockMaxCounts[BucketIndex];
		MemPage->FreeBlockCount = BlockCount;

#if AZURE_LUA_ALLOCATOR_STAT
		BucketStats[BucketIndex].AddAllocSize(CurMemPageSize);
#endif
		return MemPage;
	}

	FORCEINLINE void FreeOnePage(unsigned int BlockSize, unsigned int BucketIndex, MemPageInfo* pPage)
	{
		if (BlockSize <= MemBlockMaxMediumSize)
		{
			if (CheckCurrentAllocSizeExceeding(NormalBlockCurAllocCount, NormalBlockMaxAllocCount, NormalBlockExtraBudgetMultiplier, FreeMemPages))
			{
				azure_aligned_free(pPage);
				NormalBlockCurAllocCount--;
			}
			else
			{
				FreeMemPages.Push(pPage);
			}

#if AZURE_LUA_ALLOCATOR_STAT
			BucketStats[BucketIndex].SubAllocSize(MemPageSize);
#endif
		}
		else
		{
			if (CheckCurrentAllocSizeExceeding(BigBlockCurAllocCount, BigBlockMaxAllocCount, BigBlockExtraBudgetMultiplier, FreeMemBigPages))
			{
				azure_aligned_free(pPage);
				BigBlockCurAllocCount--;
			}
			else
			{
				FreeMemBigPages.Push(pPage);
			}

#if AZURE_LUA_ALLOCATOR_STAT
			BucketStats[BucketIndex].SubAllocSize(MemBigPageSize);
#endif
		}
	}

	FORCEINLINE void* AllocOneBlock(unsigned int nsize)
	{
		const unsigned int BucketIndex = IndexFromSizeMap[nsize];
		BucketHeader& Header = BucketHeaders[BucketIndex];

#if AZURE_LUA_ALLOCATOR_STAT
		BucketStats[BucketIndex].AddRealUsedSize(nsize);
#endif

		auto* CurPage = Header.FirstPageAddr;

		if (!CurPage)
		{
			CurPage = AllocOnePage(BucketIndex);
			Header.FirstPageAddr = CurPage;
		}

		BLOCK_PTR CurAddr = CurPage->FirstBlockAddr;

		if (--CurPage->FreeBlockCount == 0)
		{
			CurPage->FirstBlockAddr = nullptr;
			auto* NextPage = CurPage->NextPageAddr;

			if (NextPage)
			{
				NextPage->PrevPageAddr = nullptr;
				Header.FirstPageAddr = NextPage;
			}
			else
			{
				Header.FirstPageAddr = nullptr;
			}
		}
		else
		{
			BLOCK_PTR NextFreePtr = *(BLOCK_PTR*)CurAddr;

			if (NextFreePtr == nullptr)
			{
				const auto BlockSize = MemBlockSizes[BucketIndex];
				NextFreePtr = CurAddr + BlockSize;
				*(BLOCK_PTR*)NextFreePtr = nullptr;
			}

			CurPage->FirstBlockAddr = NextFreePtr;
		}

		return CurAddr;
	}

	FORCEINLINE void FreeOneBlock(void* Ptr, size_t osize)
	{
		const unsigned int BucketIndex = IndexFromSizeMap[osize];

#if AZURE_LUA_ALLOCATOR_STAT
		BucketStats[BucketIndex].SubRealUsedSize(osize);
#endif

		const auto BlockSize = MemBlockSizes[BucketIndex];
		MemPageInfo* pPageInfo;

		if (BlockSize <= MemBlockMaxMediumSize)
		{
			pPageInfo = (MemPageInfo*)(((uintptr_t)Ptr) & MemPagePtrMask);
		}
		else
		{
			pPageInfo = (MemPageInfo*)(((uintptr_t)Ptr) & MemBigPagePtrMask);
		}

		const auto CurBlockCount = ++pPageInfo->FreeBlockCount;

		if (CurBlockCount == MemBlockMaxCounts[BucketIndex])
		{
			MemPageInfo* pPrevPage = pPageInfo->PrevPageAddr;
			MemPageInfo* pNextPage = pPageInfo->NextPageAddr;

			if (pPrevPage)
				pPrevPage->NextPageAddr = pNextPage;
			else
			{
				BucketHeader& Header = BucketHeaders[BucketIndex];
				Header.FirstPageAddr = pNextPage;
			}

			if (pNextPage)
				pNextPage->PrevPageAddr = pPrevPage;

			FreeOnePage(BlockSize, BucketIndex, pPageInfo);
		}
		else
		{
			BLOCK_PTR OldHead = pPageInfo->FirstBlockAddr;
			pPageInfo->FirstBlockAddr = (BLOCK_PTR)Ptr;
			*(BLOCK_PTR*)Ptr = OldHead;

			if (CurBlockCount == 1)
			{
				BucketHeader& Header = BucketHeaders[BucketIndex];
				auto* OldHeadPageAddr = Header.FirstPageAddr;
				Header.FirstPageAddr = pPageInfo;
				pPageInfo->PrevPageAddr = nullptr;

				if (OldHeadPageAddr)
				{
					pPageInfo->NextPageAddr = OldHeadPageAddr;
					OldHeadPageAddr->PrevPageAddr = pPageInfo;
				}
				else
				{
					pPageInfo->NextPageAddr = nullptr;
				}
			}
		}
	}

	void* LuaRealloc(void *ud, void* Ptr, size_t osize, size_t nsize)
	{
		(void)ud;

#if AZURE_LUA_ALLOCATOR_STAT
		sTotalStat.AddTotalUserAllocSize(nsize);
		sTotalStat.SubTotalUserAllocSize(osize);

		if (nsize > UsableBlockSizeMax)
			sTotalStat.AddUnmanagedAllocSize(nsize);
		else
		{
			sTotalStat.AddManagedAllocSize(nsize);
			const unsigned int BucketIndex = IndexFromSizeMap[nsize];
			const auto BlockSize = MemBlockSizes[BucketIndex];

			if (BlockSize > MemBlockMaxMediumSize)
				sTotalStat.AddBigBlockAllocSize(nsize);
			else
				sTotalStat.AddNormalBlockAllocSize(nsize);
		}

		if (osize > UsableBlockSizeMax)
			sTotalStat.SubUnmanagedAllocSize(osize);
		else
		{
			sTotalStat.SubManagedAllocSize(osize);
			const unsigned int BucketIndex = IndexFromSizeMap[osize];
			const auto BlockSize = MemBlockSizes[BucketIndex];

			if (BlockSize > MemBlockMaxMediumSize)
				sTotalStat.SubBigBlockAllocSize(osize);
			else
				sTotalStat.SubNormalBlockAllocSize(osize);
		}
#endif

		if (nsize == 0)
		{
			if (Ptr)
			{
				if (osize > UsableBlockSizeMax) // UE alloc
				{
					//FMemory::Free(Ptr);
					::free(Ptr);
				}
				else
				{
					FreeOneBlock(Ptr, osize);
				}
			}

			return nullptr;
		}

		if (Ptr)
		{
			if (osize > UsableBlockSizeMax) // UE alloc
			{
				if (nsize > UsableBlockSizeMax)
				{
					//void *NewPtr = FMemory::Realloc(Ptr, nsize);
					void *NewPtr = ::realloc(Ptr, nsize);
					return NewPtr;
				}
				else
				{
					void* NewBlock = AllocOneBlock(nsize);
					//FMemory::Memcpy(NewBlock, Ptr, nsize);
					//FMemory::Free(Ptr);
					::memcpy(NewBlock, Ptr, nsize);
					::free(Ptr);
					return NewBlock;
				}
			}
			else // Self alloc
			{
				if (nsize > UsableBlockSizeMax)
				{
					//void* NewPtr = FMemory::Malloc(nsize);
					//FMemory::Memcpy(NewPtr, Ptr, osize);
					void* NewPtr = ::malloc(nsize);
					::memcpy(NewPtr, Ptr, osize);
					FreeOneBlock(Ptr, osize);
					return NewPtr;
				}
				else
				{
					const unsigned int OldBucketIndex = IndexFromSizeMap[osize];
					const unsigned int NewBucketIndex = IndexFromSizeMap[nsize];

					if (OldBucketIndex == NewBucketIndex)
					{
						return Ptr;
					}
					else
					{
						void* NewPtr = AllocOneBlock(nsize);
						//FMemory::Memcpy(NewPtr, Ptr, nsize > osize ? osize : nsize);
						::memcpy(NewPtr, Ptr, nsize > osize ? osize : nsize);
						FreeOneBlock(Ptr, osize);
						return NewPtr;
					}
				}
			}
		}
		else
		{
			if (nsize > UsableBlockSizeMax) // UE alloc
			{
				//return FMemory::Malloc(nsize);
				return ::malloc(nsize);
			}
			else
			{
				return AllocOneBlock(nsize);
			}
		}
	}

	void InitLuaAllocator(unsigned int NormalBlockMemReserved, unsigned int BigBlockMemReserved,
		unsigned int NormalBlockMaxAllocSize, unsigned int BigBlockMaxAllocSize,
		float NormalBlockExtraBudgetRatio, float BigBlockExtraBudgetRatio)
	{
		wLua::LuaReallocFuncPtr = LuaRealloc;
		InitLuaAllocatorRaw(NormalBlockMemReserved, BigBlockMemReserved,
			NormalBlockMaxAllocSize, BigBlockMaxAllocSize,
			NormalBlockExtraBudgetRatio, BigBlockExtraBudgetRatio);
	}
}

#else

	namespace AzureLuaMemFunc
	{
		void InitLuaAllocator(unsigned int NormalBlockMemReserved, unsigned int BigBlockMemReserved,
			unsigned int NormalBlockMaxAllocSize, unsigned int BigBlockMaxAllocSize,
			float NormalBlockExtraBudgetRatio, float BigBlockExtraBudgetRatio)
		{
			wLua::LuaReallocFuncPtr = nullptr;
		}

		void ReleaseLuaAllocator()
		{
		}

		void LogStat(bool bClearPeak)
		{
		}
	}

#endif


namespace AzureLuaMemFunc
{
	void * AnsiLuaAlloc(void *ud, void *ptr, size_t osize, size_t nsize)
	{
		return ::realloc(ptr, nsize);
	}
}
