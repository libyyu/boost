// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "Styling/SlateBrush.h"
#if WITH_EDITOR
#include "PropertyEditorDelegates.h"
#endif
#include "AzureLensFlare.generated.h"



class USpringArmComponent;
class UCanvas;
class UMaterialInstanceDynamic;
class UMaterialInstance;
class AAzureLensFlare;

USTRUCT(BlueprintType)
struct FAZURE_FLARE_TEXTURE_TYPE
{
	GENERATED_USTRUCT_BODY()
		FAZURE_FLARE_TEXTURE_TYPE()
	{

	}

	FAZURE_FLARE_TEXTURE_TYPE(float _u, float _v, float _us, float _vs)
	{
		uv[0] = _u;
		uv[1] = _v;
		uvs[0] = _us;
		uvs[1] = _vs;
	}
	UPROPERTY(EditAnywhere, Category = "Lens Flares", DisplayName = "uv")
		float uv[2];
	UPROPERTY(EditAnywhere, Category = "Lens Flares", DisplayName = "uvsize")
		float uvs[2];
};


USTRUCT(BlueprintType)
struct FAZURE_FLARE_TEXTURE_PARAM
{
	GENERATED_USTRUCT_BODY()
	FAZURE_FLARE_TEXTURE_PARAM()
	{
		scale = 1.0f;
		TintColor = FLinearColor::White;
		sub_idx = 0;
	}

	FAZURE_FLARE_TEXTURE_PARAM(float _scale,float _u, float _v, float _us, float _vs, FLinearColor _TintColor, AAzureLensFlare* _Flare)
	{
		scale = _scale;
		u = _u;
		v = _v;
		us = _us;
		vs = _vs;
		TintColor = _TintColor;
		Flare = _Flare;
		sub_idx = 0;
	}


	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Lens Flares", DisplayName = "scale")
	float scale;
	UPROPERTY(EditAnywhere, Category = "Lens Flares", DisplayName = "u")
	float u;
	UPROPERTY(EditAnywhere, Category = "Lens Flares", DisplayName = "v")
	float v;
	UPROPERTY(EditAnywhere, Category = "Lens Flares", DisplayName = "usize")
	float us;
	UPROPERTY(EditAnywhere, Category = "Lens Flares", DisplayName = "vsize")
	float vs;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Lens Flares", DisplayName = "TintColor")
	FLinearColor TintColor;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Lens Flares", DisplayName = "Flare")
	AAzureLensFlare* Flare = NULL;
	UPROPERTY(EditAnywhere, Category = "Lens Flares", DisplayName = "sub_idx")
	int sub_idx;
};



UENUM()
enum class EAZURE_FLARE_ELEMENT_TYPE : uint8
{
	Default,
	Element4,
	Element5,
	Element11,
	Custom,
};

UCLASS()
class AZURE_API AAzureLensFlare : public AActor
{
	GENERATED_BODY()


public:	
	// Sets default values for this actor's properties
	AAzureLensFlare();

	// Called when the game starts or when spawned
	virtual void BeginPlay() override;
	virtual void PostInitProperties() override;
	virtual void PostLoad()override;
	// Called every frame
	virtual void Tick( float DeltaSeconds ) override;

	void RenderFlare(UCanvas* Canvas);
	void ElementDefault();
#if WITH_EDITOR
	virtual void PostEditChangeProperty(FPropertyChangedEvent& PropertyChangedEvent) override;
	void RegisterCustomPropertyTypeLayout(FName PropertyTypeName, FOnGetPropertyTypeCustomizationInstance PropertyTypeLayoutDelegate);

#endif

public:
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Lens Flares", DisplayName = "BokehShape", meta = (ForceRebuildProperty = "Elements"))
	class UTexture* LensFlareBokehShape = NULL;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Lens Flares", DisplayName = "ScaleSize")
	float fScale = 1;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Lens Flares", DisplayName = "FadeSpeed")
	float fFadeSpeed = 5.0f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Lens Flares", DisplayName = "Alpha")
	float fAlpha = 1.0f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Lens Flares", DisplayName = "TraceInterval")
	float fTraceInterval = 0.2f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Lens Flares", DisplayName = "Enable")
	bool bEnable = true;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Lens Flares", DisplayName = "TimeOfDay")
	float fTimeOfDay = .0f;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Lens Flares", DisplayName = "CurveTimeOfDayColor")
	class UCurveLinearColor* CurveTimeOfDayColor = NULL;
	
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Lens Flares", DisplayName = "ActiveRange\n(0=NoLimit)")
	int fActiveRange = 0;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Lens Flares", DisplayName = "CurveCycleTime(s)")
	float CurveCycleTime = 2.0f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Lens Flares", DisplayName = "CurveLinearColor")
	class UCurveLinearColor* CurveLinearColor = NULL;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Lens Flares", DisplayName = "ElementType", meta = (ForceRebuildProperty = "Elements"))
	EAZURE_FLARE_ELEMENT_TYPE ElementType;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Lens Flares", DisplayName = "Elements")
	TArray<FAZURE_FLARE_TEXTURE_PARAM> Elements;

	//class UTexture* DefaultTexture;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Lens Flares", DisplayName = "DefaultMaterial")
	UMaterialInstance* DefaultMaterialInstance = NULL;

	FLinearColor CurveColor;
	FLinearColor CurveTimeColor;
	float fCurveTime;

	float fDestAlpha;
	float fCurAlpha;
	float fLastAlpha;
	float fInterval;
	bool bInit = false;

	EAZURE_FLARE_ELEMENT_TYPE ElementTypeLast;
};
