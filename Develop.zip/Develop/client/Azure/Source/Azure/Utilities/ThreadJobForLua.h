#pragma once

#include "CoreMinimal.h"
#include "Runnable.h"
#include "RunnableThread.h"
#include "Event.h"

class ThreadJobForLua : public FRunnable
{
private:

	static ThreadJobForLua* m_Instance;

	FRunnableThread* m_Thread = nullptr;
	FEvent* m_StartEvent = nullptr;
	FEvent* m_FinishEvent = nullptr;

	bool m_HasPendingJob = false;
	bool m_RunInMainThread = false;
	volatile bool m_QuitFlag = false;
	volatile bool m_JobTimeLimitReached = false;

public:

	volatile uint32 ThreadId = 0;
	static bool Processing;

	ThreadJobForLua();
	virtual ~ThreadJobForLua();

	static ThreadJobForLua* Instance()
	{
		return m_Instance;
	}

	static void SetHasPendingJob()
	{
		if (m_Instance != nullptr)
			m_Instance->m_HasPendingJob = true;
	}

	static bool JobTimeLimitReached()
	{
		return m_Instance->m_JobTimeLimitReached;
	}

	static void ExplicitInit(bool runInMainThread)
	{
		if (m_Instance != nullptr)
			return;

		m_Instance = new ThreadJobForLua();
		m_Instance->m_RunInMainThread = runInMainThread;
		m_Instance->InnerInit();
	}

	static void Destroy()
	{
		if (m_Instance != nullptr)
		{
			m_Instance->InnerDestroy();
			delete m_Instance;
			m_Instance = nullptr;
		}
	}

	void StartJob();

	bool WaitForJobFinish()
	{
		if (m_RunInMainThread)
			return true;

		if (Processing)
		{
			m_JobTimeLimitReached = true;
			m_FinishEvent->Wait();
			m_JobTimeLimitReached = false;
			m_HasPendingJob = false;
			Processing = false;
			return true;
		}

		return false;
	}

private:

	void InnerInit()
	{
		if (!m_RunInMainThread)
		{
			m_Thread = FRunnableThread::Create(this, TEXT("ThreadJobForLua"));
		}
	}

	void InnerDestroy()
	{
		m_QuitFlag = true;

		if (!WaitForJobFinish())
		{
			m_StartEvent->Trigger();
			m_FinishEvent->Wait();
		}

		if (m_Thread)
		{
			m_Thread->WaitForCompletion();
			delete m_Thread;
			m_Thread = nullptr;
		}
	}

	uint32 Run() override;
};
