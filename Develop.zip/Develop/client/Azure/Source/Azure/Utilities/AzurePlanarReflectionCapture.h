// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Engine/PlanarReflection.h"
#include "AzurePlanarReflectionCapture.generated.h"

UCLASS()
class AZURE_API AAzurePlanarReflectionCapture : public APlanarReflection
{
	GENERATED_BODY()

public:

	AAzurePlanarReflectionCapture(const FObjectInitializer& ObjectInitializer);

protected:
	// Called when the game starts or when spawned
	virtual void BeginPlay() override;

	// Called every frame
	virtual void Tick( float DeltaTime ) override;

	virtual void EndPlay( const EEndPlayReason::Type EndPlayReason ) override;

public:

	UFUNCTION( BlueprintCallable , Category = AzurePlanarReflection )
	void AddComponentInShowList( UPrimitiveComponent *compToShow );

	UFUNCTION( BlueprintCallable , Category = AzurePlanarReflection )
	void RemoveComponentFromShowList( UPrimitiveComponent *compToHide );

	static AAzurePlanarReflectionCapture *GetInstance() 
	{
		return captureInstance;
	}

	static void SetQualityLevel( int32 quality ) 
	{
		reflectionQuality = quality;
	}

	static int32 GetQualityLevel()
	{
		return reflectionQuality;
	}

protected:

	void AutoSelectReflectionHeight();

protected:

	UPROPERTY( EditAnywhere , Category = AzurePlanarReflection )
	bool isReflectHostPlayer;

	UPROPERTY( EditAnywhere , Category = AzurePlanarReflection )
	TArray<float> multiReflectionHeights;

	TWeakObjectPtr<APlayerController> savedPlayerCtrl;

	static AAzurePlanarReflectionCapture* captureInstance;
	static int32 reflectionQuality;//0-none 1-staticOnly 2-staticAndDynamic
};
