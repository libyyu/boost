#pragma once

#include "CoreMinimal.h"

#include <string>
#include <vector>
#include "ABaseDef.h"

class StreamingAssetHelper
{
protected:
	
	static FString m_DebugDir;
	static FString m_StreamingAssetsPath;

public:

	static const FString& GetDebugDir()
	{
		return m_DebugDir;
	}

	static void SetDebugBaseDir(const FString& debugDir)
	{
		m_DebugDir = debugDir / TEXT("streamingassets");
	}

	static const FString& GetStreamingAssetsPath()
	{
		return m_StreamingAssetsPath;
	}

	static void SetStreamingAssetsPath(const TCHAR* path)
	{
		m_StreamingAssetsPath = path;
	}

	static FString MakePath(const TCHAR* subPath)
	{
		return m_StreamingAssetsPath / subPath;
	}

	static avector<char> ReadFileText(const TCHAR* filePath);
};
