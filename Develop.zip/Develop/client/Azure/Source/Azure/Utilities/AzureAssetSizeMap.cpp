// Fill out your copyright notice in the Description page of Project Settings.

#include "AzureAssetSizeMap.h"
#include "Azure.h"
#include "StringConv.h"
#include "HAL/UnrealMemory.h"
#include "Misc/FileHelper.h"
#include "AzureExport.h"

bool FAzureAssetSizeMap::Init()
{
	if (Inited)
		return true;

	return LoadFromFile(TEXT("Configs/InGameUpdateList.json"));
}

bool FAzureAssetSizeMap::LoadFromFile(const FString& filePath)
{
	ABYTE* pBuffer;
	ADWORD nFileLength;
	if (!exp_af_ReadFileAllBytes(TCHAR_TO_UTF8(*filePath), &pBuffer, &nFileLength))
	{
		UE_LOG(LogAzure, Error, TEXT("FAzureAssetSizeMap::LoadFromFile: Cannot find the file for %s !"), *filePath);
		return false;
	}

	FString JsonString;
	FFileHelper::BufferToString(JsonString, pBuffer, nFileLength);
	exp_af_ReleaseFileBuffer(pBuffer);

	if (!FromJson(JsonString))
	{
		UE_LOG(LogAzure, Error, TEXT("FAzureAssetSizeMap::LoadFromFile: Failed to parse json from %s !"), *filePath);
		return false;
	}

	Inited = true;
	return true;
}

void FAzureAssetSizeMap::CalcAssetSizeRecursively(const FName& fileName, const FileInfo& fileInfo, TSet<FName>& alreadyAdded, uint32& nSize)
{
	if (alreadyAdded.Contains(fileName))
		return;

	alreadyAdded.Add(fileName);
	nSize += GetCompressedFileSize(fileInfo);

	// Dependencies
	const TArray<FName>& depends = GetDepFileNames(fileInfo);
	for (auto& name : depends)
	{
		FileInfo* pInfo = InGameUpdateFiles.Find(name);
		if (pInfo)
			CalcAssetSizeRecursively(name, *pInfo, alreadyAdded, nSize);
	}
}

const FAzureAssetSizeMap::FileInfo* FAzureAssetSizeMap::FindFileInfo(const FName& assetName, FName& fileName)
{
	static const TCHAR* FILE_EXTS[] = {
		TEXT(".uasset"),
		TEXT(".umap"),
	};

	for (auto ext : FILE_EXTS)
	{
		fileName = FName(*(assetName.ToString() + ext));
		const FileInfo* pInfo = InGameUpdateFiles.Find(fileName);
		if (pInfo)
			return pInfo;
	}

	return NULL;
}

uint32 FAzureAssetSizeMap::GetAssetSize(const FName& assetName)
{
	if (!Inited && !Init())
		return 0;

	const uint32* pAssetSize = InGameAssetSize.Find(assetName);
	if (pAssetSize)
		return *pAssetSize;

	FName fileName;
	const FileInfo* pInfo = FindFileInfo(assetName, fileName);
	if (!pInfo)
		return 0;

	TSet<FName> alreadyAdded;
	uint32& assetSize = InGameAssetSize.Add(assetName);
	CalcAssetSizeRecursively(fileName, *pInfo, alreadyAdded, assetSize);
	return assetSize;
}

void FAzureAssetSizeMap::AddFileInfoToMap(const FName& fileName, const FileInfo& fileInfo, TMap<FName, uint32>& sizeMap)
{
	if (sizeMap.Contains(fileName))
		return;

	sizeMap.Add(fileName, FAzureAssetSizeMap::GetCompressedFileSize(fileInfo));

	// Dependencies
	const TArray<FName>& depends = GetDepFileNames(fileInfo);
	for (auto& name : depends)
	{
		FileInfo* pInfo = InGameUpdateFiles.Find(name);
		if (pInfo)
			AddFileInfoToMap(name, *pInfo, sizeMap);
	}
}

uint64 FAzureAssetSizeMap::GetAssetListSize(const TArray<FName>& assetList)
{
	if (!Inited && !Init())
		return 0;

	uint64 totalSize = 0;
	TMap<FName, uint32> assetSizeMap;

	for (auto& assetName : assetList)
	{
		FName fileName;
		const FileInfo* pInfo = FindFileInfo(assetName, fileName);
		if (!pInfo)
			continue;

		AddFileInfoToMap(fileName, *pInfo, assetSizeMap);
	}

	for (auto KeyValueIt = assetSizeMap.CreateIterator(); KeyValueIt; ++KeyValueIt)
	{
		totalSize += KeyValueIt.Value();
	}

	return totalSize;
}

void FAzureAssetSizeMap::GetAssetListSizeDetail(const TArray<FName>& assetList, TMap<FName, uint32>& fileInfo)
{
	if (!Inited && !Init())
		return;

	for (auto& assetName : assetList)
	{
		FName fileName;
		const FileInfo* pInfo = FindFileInfo(assetName, fileName);
		if (!pInfo)
			continue;

		AddFileInfoToMap(fileName, *pInfo, fileInfo);
	}
}

void FAzureAssetSizeMap::CollectDepends(const FName& assetName, const FString& pattern, const FileInfo& fileInfo, TSet<FName>& depends)
{
	if (depends.Contains(assetName))
		return;

	if (assetName.ToString().MatchesWildcard(pattern))
		depends.Add(assetName);

	// Dependencies
	const TArray<FName>& subDepends = GetDepFileNames(fileInfo);
	for (auto& name : subDepends)
	{
		if (!name.ToString().MatchesWildcard(pattern))
			continue;

		FileInfo* pInfo = InGameUpdateFiles.Find(name);
		if (pInfo)
			CollectDepends(name, pattern, *pInfo, depends);
	}
}

bool FAzureAssetSizeMap::GetAssetDependencies(const FName& assetName, const FString& pattern, TSet<FName>& depends)
{
	if (!Inited && !Init())
		return false;

	FName fileName;
	const FileInfo* pInfo = FindFileInfo(assetName, fileName);
	if (!pInfo)
		return false;

	CollectDepends(assetName, pattern, *pInfo, depends);
	return true;
}

void FAzureAssetSizeMap::Serialize(FJsonSerializerBase& Serializer, bool bFlatObject)
{
	if (!bFlatObject)
	{
		Serializer.StartObject();
	}

	//	Serialize InGameUpdateFiles
	SerializeMap(Serializer, TEXT("InGameUpdateFiles"), InGameUpdateFiles);

	if (!bFlatObject)
	{
		Serializer.EndObject();
	}
}

void FAzureAssetSizeMap::SerializeMap(FJsonSerializerBase& Serializer, const TCHAR* Name, TMap<FName, FileInfo>& Value)
{
	static const FString NameFileMD5 = TEXT("FileMD5");
	static const FString NameOrigFileSize = TEXT("OrigFileSize");
	static const FString NameCompressedFileSize = TEXT("CompressedFileSize");
	static const FString NameDepFileNames = TEXT("DepFileNames");

	if (Serializer.IsSaving())
	{
		Serializer.StartObject(Name);
		for (auto KeyValueIt = Value.CreateIterator(); KeyValueIt; ++KeyValueIt)
		{
			const FName& FileName = KeyValueIt.Key();

			Serializer.StartObject(*FileName.ToString());
			{
				const FileInfo& FieldValue = KeyValueIt.Value();

				FString FileMD5String = LexToString(GetFileMD5(FieldValue));
				Serializer.Serialize(*NameFileMD5, FileMD5String);

				int64 OrigFileSize = GetOrigFileSize(FieldValue);
				Serializer.Serialize(*NameOrigFileSize, OrigFileSize);

				int64 CompressedFileSize = GetCompressedFileSize(FieldValue);
				Serializer.Serialize(*NameCompressedFileSize, CompressedFileSize);

				TArray<FName> DepFileNames = GetDepFileNames(FieldValue);
				SerializeArray(Serializer, *NameDepFileNames, DepFileNames);
			}
			Serializer.EndObject();
		}
		Serializer.EndObject();
	}
	else
	{
		Value.Empty();

		TSharedPtr<FJsonObject> JsonObject = Serializer.GetObject();
		if (JsonObject->HasTypedField<EJson::Object>(Name))
		{
			const TSharedPtr<FJsonObject>& JsonMap = JsonObject->GetObjectField(Name);
			for (auto KeyValueIt = JsonMap->Values.CreateConstIterator(); KeyValueIt; ++KeyValueIt)
			{
				const FString& FileName = KeyValueIt.Key();
				const TSharedPtr<FJsonObject>& JsonFileInfo = KeyValueIt.Value()->AsObject();

				check(JsonFileInfo->HasTypedField<EJson::String>(NameFileMD5));
				FString FileMD5String = JsonFileInfo->GetStringField(NameFileMD5);
				FMD5Hash FileMD5;
				LexFromString(FileMD5, *FileMD5String);

				bool bRet = false;

				int64 OrigFileSize = 0;
				bRet = JsonFileInfo->TryGetNumberField(NameOrigFileSize, OrigFileSize);
				check(bRet);

				int64 CompressedFileSize = 0;
				bRet = JsonFileInfo->TryGetNumberField(NameCompressedFileSize, CompressedFileSize);
				check(bRet);

				TArray<FName> DepFileNames;
				FJsonSerializerReader DepFileNamesSerializer(JsonFileInfo);
				SerializeArray(DepFileNamesSerializer, *NameDepFileNames, DepFileNames);

				Value.Emplace(FName(*FileName), MakeTuple(FileMD5, OrigFileSize, CompressedFileSize, DepFileNames));
			}
		}
	}
}

const FMD5Hash& FAzureAssetSizeMap::GetFileMD5(const FileInfo& InFileInfo)
{
	return InFileInfo.Get<0>();
}

int64 FAzureAssetSizeMap::GetOrigFileSize(const FileInfo& InFileInfo)
{
	return InFileInfo.Get<1>();
}

int64 FAzureAssetSizeMap::GetCompressedFileSize(const FileInfo& InFileInfo)
{
	return InFileInfo.Get<2>();
}

const TArray<FName>& FAzureAssetSizeMap::GetDepFileNames(const FileInfo& InFileInfo)
{
	return InFileInfo.Get<3>();
}

bool FAzureAssetSizeMap::IsFileInfoValid(const FileInfo& InFileInfo)
{
	return GetFileMD5(InFileInfo).IsValid()
		&& GetOrigFileSize(InFileInfo) >= 0
		&& GetCompressedFileSize(InFileInfo) > 0;
}

void FAzureAssetSizeMap::SerializeMap(FJsonSerializerBase& Serializer, const TCHAR* Name, TMap<FName, TArray<FName>>& Value)
{
	if (Serializer.IsSaving())
	{
		Serializer.StartObject(Name);
		for (auto KeyValueIt = Value.CreateIterator(); KeyValueIt; ++KeyValueIt)
		{
			SerializeArray(Serializer, *KeyValueIt.Key().ToString(), KeyValueIt.Value());
		}
		Serializer.EndObject();
	}
	else
	{
		Value.Empty();

		TSharedPtr<FJsonObject> JsonObject = Serializer.GetObject();
		if (JsonObject->HasTypedField<EJson::Object>(Name))
		{
			const TSharedPtr<FJsonObject>& JsonMap = JsonObject->GetObjectField(Name);
			for (auto KeyValueIt = JsonMap->Values.CreateConstIterator(); KeyValueIt; ++KeyValueIt)
			{
				const FString& FieldName = KeyValueIt.Key();
				TArray<FString> FieldValue;
				bool Ret = JsonMap->TryGetStringArrayField(FieldName, FieldValue);
				check(Ret);

				Value.Emplace(FName(*FieldName), StringArray2NameArray(FieldValue));
			}
		}
	}
}

void FAzureAssetSizeMap::SerializeArray(FJsonSerializerBase& Serializer, const TCHAR* Name, TArray<FName>& Value)
{
	if (Serializer.IsSaving())
	{
		TArray<FString> JsonStringArray = NameArray2StringArray(Value);
		Serializer.SerializeArray(Name, JsonStringArray);
	}
	else
	{
		Value.Empty();

		TArray<FString> JsonStringArray;
		Serializer.SerializeArray(Name, JsonStringArray);

		Value = StringArray2NameArray(JsonStringArray);
	}
}

TArray<FString> FAzureAssetSizeMap::NameArray2StringArray(const TArray<FName>& NameArray)
{
	TArray<FString> StringArray;
	StringArray.Reserve(NameArray.Num());
	for (const FName& Item : NameArray)
	{
		StringArray.Emplace(Item.ToString());
	}
	return StringArray;
}

TArray<FName> FAzureAssetSizeMap::StringArray2NameArray(const TArray<FString>& StringArray)
{
	TArray<FName> NameArray;
	NameArray.Reserve(StringArray.Num());
	for (const FString& Item : StringArray)
	{
		NameArray.Emplace(FName(*Item));
	}
	return NameArray;
}