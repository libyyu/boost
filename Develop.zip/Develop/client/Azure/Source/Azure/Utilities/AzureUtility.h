﻿#pragma once

#include "Engine/EngineTypes.h"
#include "Engine/DataTable.h"
#include "UE4Related.h"
#include "Components/MeshComponent.h"
#include "Components/SkinnedMeshComponent.h"
//#include "RawMesh.h"
#include "GameLogic/Behavior/AzureBehaviorDef.h"
#include "Kismet/KismetSystemLibrary.h"
#include "GameFramework/CharacterMovementComponent.h"
#include "Materials/MaterialInstance.h"

struct lua_State;
class UAzureObjectComponent;
class UCameraComponent;
class AAzureEnvironmentManager;

class AzureUtility
{
public:

	static constexpr float UE_SERVER_YAW_DIFF = 90.f;

	static constexpr float FloatError = 0.001f;
	static constexpr float INVALID_POS = 9000000;

	// Minimum acceptable distance for Character capsule to float above floor when walking
	static constexpr float MIN_FLOOR_DIST = 0.02f * UE_METRE_TRANS; // 抬起一点，避免精度问题导致的penetration

	static constexpr ECollisionChannel TRACE_CHN_TERRAIN = ECollisionChannel::ECC_GameTraceChannel1;
	static constexpr ECollisionChannel TRACE_CHN_BUILDING = ECollisionChannel::ECC_GameTraceChannel2;
	static constexpr ECollisionChannel TRACE_CHN_TERRAIN_BUILDING = ECollisionChannel::ECC_GameTraceChannel3;
	static constexpr ECollisionChannel TRACE_CHN_AZUREOBJECT = ECollisionChannel::ECC_GameTraceChannel4;
	static constexpr ECollisionChannel TRACE_CHN_AZUREOBJECT_TERRAIN_BUILDING = ECollisionChannel::ECC_GameTraceChannel5;
	static constexpr ECollisionChannel TRACE_CHN_BLOCKMOVE = ECollisionChannel::ECC_GameTraceChannel6;
	static constexpr ECollisionChannel TRACE_CHN_BLOCKSKILL = ECollisionChannel::ECC_GameTraceChannel7;
	static constexpr ECollisionChannel TRACE_CHN_AZUREHOSTPLAYER = ECollisionChannel::ECC_GameTraceChannel8;
	static constexpr ECollisionChannel TRACE_CHN_BLOCKCAEMRA = ECollisionChannel::ECC_GameTraceChannel9;
	static constexpr ECollisionChannel TRACE_CHN_WATERSUFACE = ECollisionChannel::ECC_GameTraceChannel10;
	static constexpr ECollisionChannel TRACE_CHN_WEAPON_ATTACK = ECollisionChannel::ECC_GameTraceChannel12;
	static constexpr ECollisionChannel TRACE_CHN_MONSTERBLOCKMOVE = ECollisionChannel::ECC_GameTraceChannel13;
	static constexpr ECollisionChannel TRACE_CHN_SHELTER = ECollisionChannel::ECC_GameTraceChannel16;
	static constexpr ECollisionChannel TRACE_CHN_HEIGHTMAP = ECollisionChannel::ECC_GameTraceChannel17;

	static bool isTraceAzureObjectChannel(const ECollisionChannel Channel)
	{
		return Channel == AzureUtility::TRACE_CHN_AZUREOBJECT
			|| Channel == AzureUtility::TRACE_CHN_AZUREOBJECT_TERRAIN_BUILDING
			|| Channel == AzureUtility::TRACE_CHN_WEAPON_ATTACK
			|| Channel == AzureUtility::TRACE_CHN_MONSTERBLOCKMOVE
			|| Channel == AzureUtility::TRACE_CHN_BLOCKSKILL;
	}

	static UAzureObjectComponent* FindActorAzureObjComp(AActor* pActor);

	static int pushFHitResult2Lua(lua_State * L, const FHitResult& result, bool bCheckAzureObj);
	static FHitResult getFHitResult2Lua(lua_State * L, int ParamIndex);

	static void CallLuaSetCameraToTargetPos(const FVector &pos, bool ignore_lag);
	static float AngleRad(const FVector& UnitVec1, const FVector& UnitVec2)
	{
		float dot = FVector::DotProduct(UnitVec1.GetSafeNormal(), UnitVec2.GetSafeNormal());
		float angle = FMath::Acos(dot);
		return angle;
	}

	//角度绝对值
	static float Angle(const FVector& UnitVec1, const FVector& UnitVec2)
	{
		if (UnitVec1.Size() == 0.0f)
			return 0.0f;

		if (UnitVec2.Size() == 0.0f)
			return 0.0f;

		float dot = FVector::DotProduct(UnitVec1.GetSafeNormal(), UnitVec2.GetSafeNormal());
		float angle = FMath::Acos(dot);
		return FMath::RadiansToDegrees(angle);
	}

	//角度带符号
	static float Angle2(const FVector& Vec1, const FVector& Vec2)
	{
		FVector v1 = Vec1.GetSafeNormal();
		FVector v2 = Vec2.GetSafeNormal();

		if (v1 == FVector::ZeroVector || v2 == FVector::ZeroVector)
			return 0.0f;

		float dot = FVector::DotProduct(v1,v2);
		float angle = FMath::Acos(dot);
		angle = FMath::RadiansToDegrees(angle);

		FVector cross_value = FVector::CrossProduct(v1,v2);
		if (cross_value.Z < 0.0f)
			angle = -angle;

		return angle;
	}

	static FVector DecompressDir(uint16 dir0, uint16 dir1)
	{
		float fRad = FMath::DegreesToRadians(dir0 * 360.0f / 65536.0f);
		float fHei = FMath::DegreesToRadians(dir0 * dir1 * 360.0f / 65536.0f);

		FVector v;
		float p = FMath::Sin(fHei);
		VEC_RIGHT(v) = p * FMath::Cos(fRad);
		VEC_FORWARD(v) = p * FMath::Sin(fRad);
		VEC_UP(v) = FMath::Cos(fHei);
		return v;
	}

	static uint8 CompressDirH(float r, float f)
	{
		if (FMath::Abs(r) < 0.00001f)
			return (f > 0) ? (uint8)64 : (uint8)192;
		else
			return (uint8)(FMath::RadiansToDegrees(FMath::Atan2(f, r)) * 256.0f / 360.0f);
	}

	static FVector DecompressDirH(uint8 byDir)
	{
		const float fInter = 360.0f / 256.0f;

		float fRad = FMath::DegreesToRadians(byDir * fInter);
		return FVector(FMath::Cos(fRad), 0.0f, FMath::Sin(fRad));
	}

	static uint16 CompressDirH2(float r, float f, float* pfYaw = NULL)
	{
		if (FMath::Abs(r) < 0.00001f)
		{
			if (pfYaw)
				*pfYaw = (f > 0) ? 90.f : 270.f;
			return (f > 0) ? (uint16)16384 : (uint16)49152;
		}
		else
		{
			float fYaw = FMath::RadiansToDegrees(FMath::Atan2(f, r));
			if (pfYaw)
				*pfYaw = fYaw;
			return (uint16)(short)(fYaw * 65536.0f / 360.0f);
		}
	}
	static uint16 CompressDirH2_Yaw(float fYawDeg)
	{
		return (uint16)(short)(fYawDeg * 65536.0f / 360.0f);
	}

	static FVector DecompressDirH2(uint16 nDir)
	{
		float fRad = FMath::DegreesToRadians(nDir * 360.0f / 65536.0f);
		FVector vDir;
		VEC_RIGHT(vDir) = FMath::Cos(fRad);
		VEC_FORWARD(vDir) = FMath::Sin(fRad);
		VEC_UP(vDir) = 0.0f;
		return vDir;
	}

	static float DecompressDirH2_Yaw(uint16 fYawDeg)
	{
		return (float)(fYawDeg*360.0f / 65536.0f);
	}

	static float ClipYawDegree(float fYawDeg)
	{
		while (fYawDeg < -180.0f)
			fYawDeg += 360.0f;

		while (fYawDeg > 180.0f)
			fYawDeg -= 360.0f;

		return fYawDeg;
	}

	static float ClipDegreeToNormalRange(float fYawDeg)
	{
		const float deg_limit = 1e6;

		if (!FMath::IsFinite(fYawDeg) || fYawDeg > deg_limit || fYawDeg < -deg_limit)
			return 0.0f;

		float Mul = fYawDeg / 360.f;
		fYawDeg -= floorf(Mul) * 360.f;

		while (fYawDeg < -180.0f)
			fYawDeg += 360.0f;

		while (fYawDeg > 180.0f)
			fYawDeg -= 360.0f;

		return fYawDeg;
	}

	static short FLOATTOFIX8(float x)
	{
		return ((short)((x) * 256.0f + 0.5f));
	}

	static float FIX8TOFLOAT(short x)
	{
		return x / 256.0f;
	}

	static FVector DistH(const FVector& vFrom, const FVector& vTo)
	{
		FVector vDistH = vTo - vFrom;
		VEC_UP(vDistH) = 0;
		return vDistH;
	}

	static FVector DirH(const FVector& vFrom, const FVector& vTo)
	{
		FVector vDistH = vTo - vFrom;
		VEC_UP(vDistH) = 0;
		if (vDistH.Normalize())
			return vDistH;
		else
			return FVector::ForwardVector;
	}

	static FVector DirH(const FVector& vFrom, const FVector& vTo, const FVector& vDef)
	{
		FVector vDistH = vTo - vFrom;
		VEC_UP(vDistH) = 0;
		if (vDistH.Normalize())
			return vDistH;
		else
			return vDef;
	}

	static bool GetCurrentJoyStickDir(FVector& vDir, bool bDir3D, bool bIncludeZeroStickValue,
		FVector2D* pvJoyStickValue = NULL, FVector* pvCameraRight = NULL, FVector* pvCameraUp = NULL, FVector* pvCameraForward = NULL);

	//	Interpolate float
	//	Return: true-Reach, false-NotReach
	static bool InterpFloat(float& fCurVal, float fDestVal, float fRatio, float fDeltaTime, float fMinSpeedThresh);

	//	Interpolate float with const speed
	//	Return: true-Reach, false-NotReach
	static bool InterpFloatConstSpeed(float& fCurVal, float fDestVal, float fDeltaTime,
		float fSpeed, const float* pfDeltaDist = NULL);

	static bool JudgeIsInsideTerrBuilding(const FVector& vPos, float fJudgeRadius, float fTestUpHei, float fYawDeg, int nCollisionSides, float fTestSidesLen);
	
	static float GetPreciseSupportHeiByPos(const FVector& curPos, float ext, float fAboveH1, float fAboveH2, float fAboveFinal);

	static float GetDestPosHeightFromCurPos(const FVector& vDestPos, const FVector& vCurPos, float fSplitDistH, float ext = 0, float fAboveH1 = 1.8f * UE_METRE_TRANS, float fAboveH2 = 3.8f * UE_METRE_TRANS, float fAboveFinal = 50.0f * UE_METRE_TRANS);

	enum class JumpPhase
	{
		JP_UPWARD = 1,
		JP_DOWNWARD = 2,
	};

	static FVector GetDestJumpPos(const FVector& vStart, const FVector& vSpeedH, float total_time, float upward_time, float up_height, float down_height, float fSplitTime,
		float& retUpHei, float& retUpTime, float& retTotalTime);

	static float FlashMoveOnDir(FVector& vDestPos, const FVector& vOrigStart,
		bool bForceDestOnGround, bool bCheckReachableOrMovable,
		const FVector& vDir, float fDist, bool bDist3D,
		float fStepDistH/*step dist horizontal*/,
		float fStepRaiseHei/*step raise height, < 0 means use default*/,
		float fMaxTotalRaiseHei/* Max total raise height*/,
		float fTraceDownDist/*Abs hight that trace down*/,
		float fStepFallHeight/*Abs step fall height*/);

	static bool GetHitPosInWorld(const FVector& vStart, const FVector& vEnd, ECollisionChannel Channel, FHitResult& hitInfo, float fRadius, float fHalfHeight, bool bBlockMoveIgnoreCapsuleOverlap = true, const FQuat& Rot = FQuat::Identity, FName traceTag = NAME_None, TArray<AActor*>* ignoreActors = nullptr);
	static bool GetHitPosInWorld_ByShape(const FVector& vStart, const FVector& vEnd, ECollisionChannel Channel, FHitResult& hitInfo, const FCollisionShape& CollisionShape, bool bBlockMoveIgnoreCapsuleOverlap = true, const FQuat& Rot = FQuat::Identity, FName traceTag = NAME_None, TArray<AActor*>* ignoreActors = nullptr);
	static bool GetSupportPlaneHeight(float& ret_height, const FVector& vPos, float fRadius, float fTraceDownDist = -1.f, FHitResult* pHitInfo = NULL, bool bStartPenetratingAsCollision = false);
	
	static bool IsHitMoveBlock(const FVector& vStart, const FVector& vEnd, float fRadius, float fHalfHeight, const TArray<AActor*>& InIgnoreActors);
	
	static bool CapsuleTraceSingle(UWorld* pWorld, const FVector& Start, const FVector& End, const FQuat& quat, float Radius, float HalfHeight, ECollisionChannel Channel, bool bTraceComplex, const TArray<AActor*>& ActorsToIgnore, EDrawDebugTrace::Type DrawDebugType, FHitResult& OutHit, bool bIgnoreSelf, FLinearColor TraceColor = FLinearColor::Red, FLinearColor TraceHitColor = FLinearColor::Green, float DrawTime = 5.0f);
	static bool CapsuleTraceMulti(UWorld* pWorld, const FVector& Start, const FVector& End, const FQuat& quat, float Radius, float HalfHeight, ECollisionChannel Channel, bool bTraceComplex, const TArray<AActor*>& ActorsToIgnore, EDrawDebugTrace::Type DrawDebugType, TArray<FHitResult>& OutHits, bool bIgnoreSelf, FLinearColor TraceColor = FLinearColor::Red, FLinearColor TraceHitColor = FLinearColor::Green, float DrawTime = 5.0f);

	static bool GetPosReachable(const FVector& pos);
	static bool GetPosMovable(const FVector& pos);
	static bool CheckLinePointAvailable(bool bRealReachable, // true: reachmap, false: movemap
		const FVector& vStart, const FVector& vEnd, FVector& stoppoint);
	static bool CheckArcPointAvailable(FVector vStart, FVector vEnd, FVector vAxis, FVector &outFirstInvalidePos);
	static bool IsPosInCliffArea(const FVector& pos);

	static bool IsVectorInvalid(float x, float y, float z)
	{
		return !FMath::IsFinite(x) || !FMath::IsFinite(y) || !FMath::IsFinite(z);
	}

	static bool IsVectorInvalid(const FVector& v)
	{
		return IsVectorInvalid(v.X, v.Y, v.Z);
	}

	//	判断点q是否在以(p1, p2)为中心，r为半径的圆柱之内
	static bool IsPointInCylinder(const FVector& q, const FVector& p1, const FVector& p2, float r);

	static TArray<char> UncompressDataToArray(const void* data, int compressedDataSize, int uncompressedDataSize);

	//激活一个场景的DirectionalLight
	static void EnableLightOfLevel(ULevel *level, bool bEnable);
	//调一个函数，用于触发蓝图事件
	static void RaiseEventForUObject(UObject *pObject, FName FuncName, void* Parameters = nullptr);

	static bool AddActorSceneComponent(AActor* Obj, USceneComponent* SceneComp, bool bMustHaveRoot = false);
	static bool AddActorComponent(AActor* Obj, UActorComponent* ActorComp);
	static bool RemoveActorComponent(AActor* Obj, UActorComponent* ActorComp);

	static bool GetActorBonePose(FTransform& out, bool bWorldOrLocal, AActor* Obj, FString boneName);

	static void SetDepthOfField(bool bEnable, float fFocalRegion, float fScale, bool bEnableHighQuality, float fFarBlurSize, float fSpecifiedDofValue = -1.0f);
	static void SetShadowDistance(float dist);
	static float GetShadowDistance();
	static void SetShadowCascadesNum(int num);

	static void SetShadowBias(float bias);
	static void SetShadowBiasForEnvManager(AAzureEnvironmentManager * envManager, float bias);

	static int32 AddPostProcessBlendableToCamera(UMaterialInterface* Material, UCameraComponent* Camera, float Weight);
	static void RemovePostProcessBlendableFromCamera(UMaterialInterface* Material, UCameraComponent* Camera);
	static void SetPostProcessBlendWeight(UCameraComponent* Camera, int32 Index, float Weight);

	static void AddPostProcessMaterial(UMaterialInterface *Material, float fWeight);
	static void RemovePostProcessMaterial(UMaterialInterface *Material);

	static void AddPostProcessColorLUTTexture(UMaterialInterface* pParentMat, UTexture *pTexture, float fWeight);
	static void RemovePostProcessColorLUTTexture();

	static void SetScreenTint(bool bEnable, FLinearColor &lc, float saturation ,float contrast, float vignette, UMaterialInterface *Material);
	static void SetScreenFringeIntensity(float fringeIntensity);

	static float GetCurWorldVignetteIntensity();

	static void SetPostProcessFilmSaturation(float saturation);
	static void SetPostProcessColorSaturation(const FVector4& saturation);
	static float GetCurWorldPostProcessFilmSaturation();
	static FVector4 GetCurWorldPostProcessColorSaturation();

	// Model related
	static void RemoveSkinOrStaticMeshComponent(USceneComponent* pInComp, bool bDestroyComp);
	static UObject* GetModelSkin(const UMeshComponent* pMasterPoseComponent, const FName& Name);
	static UObject* GetModelSkinComponent(const UMeshComponent* pMasterPoseComponent, const FName& Name);
	static bool RemoveModelSkin(UMeshComponent* pMasterPoseComponent, const FName& Name, bool bDestroyComponent = false);
	static bool AddModelSkin(UMeshComponent* pMasterPoseComponent, UMeshComponent* pSlavePoseComponent, const FName &SocketName, bool bSlave);
	static bool UpdateAllSlaveBoneMap(USkinnedMeshComponent* pMasterSkinComp);
	static bool SetSlaveSkinComponent(UMeshComponent* pMasterComp, UMeshComponent* pSlaveComp);
	static TArray<class UMaterialInterface*> CreateDynamicMaterialForMeshComponent(UMeshComponent *pCom, UMaterialInterface *pSorceMaterial);
	//static void SkinnedMeshToRawMeshes(USkinnedMeshComponent* InSkinnedMeshComponent, int32 InOverallMaxLODs, const FMatrix& InComponentToWorld, TArray<FRawMesh>& OutRawMeshes);
	static void CopySkinMeshComponent(USkeletalMeshComponent *src, USkeletalMeshComponent *des);

	//蓝图
	template<typename FiledType>
	static FiledType* FindBluepintStructFiledByName(const UStruct* obj, FString fieldName)
	{
		if (!obj) return nullptr;

		for (TFieldIterator<FiledType>It(obj); It; ++It)
		{
			FString strName = It->GetName();
			int iCut = strName.Find(TEXT("_"));
			if (iCut != INDEX_NONE)
			{
				strName = strName.Left(iCut);
			}
			if (strName == fieldName)
			{
				return *It;
			}
		}

		return nullptr;
	}
	
	static void CalRelativePosInfo(const FVector & abs_pos, const FRotator & abs_rot, const FVector & carrier_pos, const FRotator & carrier_rot, FVector & rel_pos, FVector & rel_dir);
	static void CalAbsPosInfo(const FVector & rel_pos,const FRotator & rel_rot,const FVector & carrier_pos,const FRotator & carrier_rot,FVector & abs_pos,FVector & abs_dir);
	static void CalcWorldTransformByRelative(const FVector& rel_pos, const FVector& rel_rot, const FVector& rel_scale, const FVector& parent_pos, const FVector& parent_rot, const FVector& parent_scale,
		FVector& out_pos, FVector& out_rot, FVector& out_scale);
	static void CalcRelativeTransform(const FVector& abs_pos, const FVector& abs_rot, const FVector& abs_scale, const FVector& parent_pos, const FVector& parent_rot, const FVector& parent_scale,
		FVector& rel_pos, FVector& rel_rot, FVector& rel_scale);
	static void CutWound(ACharacter* Attacker, ACharacter* Attackee, FName AttackSocket, FName HitBone, float Roll, UTexture* Scar, UDataTable* Table, FVector Scale, float Duration, bool FixedSize, bool debug);
	static void CutWoundTree(AActor* Attackee, FVector Position, FVector Dir, float Roll, FVector Scale, UTexture* Scar, float Duration);
	static void ApplyCutWound(UMeshComponent* Skeletal, const FTransform& Transform, UTexture* Scar, int Mask, FVector Scale, float Duration);
	static FName GetNearestBone(USkinnedMeshComponent* SkeletalMesh, FVector Location);
	static FName GetNearestBoneInCollider(USkinnedMeshComponent* SkeletalMesh, FVector Location, UPrimitiveComponent* ColliderComponent, FName ParentBoneName);
	// 取得离骨骼点最近的配置了物理节点的骨骼点名字
	static FName GetNearestPhysicBodyName(USkeletalMeshComponent* SkeletalMesh, FVector Location);
	static FName GetNearestPhysicBodyName(USkeletalMeshComponent* SkeletalMesh, FName boneName);
	static void CutPersistentWound(ACharacter* Attacker, ACharacter* Attackee, UMaterialInterface* Painter , FName AttackSocket, FName HitBone, float Roll, UTexture* Scar, FVector Scale, float DepthFadeRange, float Opacity ,bool FixedSize, bool debug);
	static void ApplyCutPersistentWound(USkeletalMeshComponent* Skeletal, UMaterialInterface* Painter , const FTransform& Transform, UTexture* Scar, float DepthFadeRange, FVector Scale, float Opacity);
	static void ClearCutPersistentWound(USkeletalMeshComponent* Skeletal);

	static bool CheckIsInWater(const FVector & testPos);
	static bool CheckIsInWaterMap(const FVector & V);
	static bool CheckIsInWater_Swim(const FVector& pos);
	static bool CheckIsInWater_Swim(const FVector& pos, FHitResult& hitInfo);

	static void DebugUObject(class AActor * p);

	//绕着固定轴旋转
	static void RotateAround(FTransform &inOutTrans, FVector point, FVector axis, float angle);
	static FVector RotateAround(FVector pos, FVector point, FVector axis, float angle);
	// return  [0, 180)
	static float AngleBetweenTwoDir(FVector dir1, FVector dir2);

};

//////////////////////////////////////////////////////////////////////////
// Inlines

FORCEINLINE_DEBUGGABLE bool AzureUtility::CheckIsInWater_Swim(const FVector& pos)
{
	FHitResult hitInfo(1.f);
	return CheckIsInWater_Swim(pos, hitInfo);
}
