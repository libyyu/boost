#pragma once

//������platformConfig ���� lua ��ȡ�Ա�ɸ�����ش���
#if 0

#include "CoreMinimal.h"
#include "XmlParser.h"

class AzurePlatformConfig
{
public:

	static AzurePlatformConfig& Get();

	void Init();
	void Release();

	FXmlFile* GetPlatformConfig();
	FXmlFile* GetAllPlatformConfig();
	FXmlNode* GetAllConfig();
	FXmlNode* GetConfig(const TCHAR *configName);

	const TCHAR* GetPlatform();
	const TCHAR* GetSpecialRegion();

private:
	void InitPlatformString();
	void InitSpecialRegion();
	void InitAllConfigNode();

private:
	FXmlFile PlatformConfig;
	FXmlFile AllPlatformConfig;

	FXmlNode *m_allConfig = nullptr;
	FString m_platformString;
	FString m_specialRegion;
};

#endif
