#pragma once

#include "CoreMinimal.h"
#include "UE4Related.h"
#include "utf8.h"
#include "utf16string.h"
#include "vector.h"
#include "ABaseDef.h"
#include "help_funcs.h"

inline FString a_UTF8ArrayToFString(const char* utf8str, int len)
{
	FString ret;
	int StringLength = FUTF8ToTCHAR_Convert::ConvertedLength(utf8str, len);
	auto& StrData = ret.GetCharArray();
	StrData.AddUninitialized(StringLength + 1);
	FUTF8ToTCHAR_Convert::Convert(StrData.GetData(), StringLength, utf8str, len);
	StrData[StringLength] = 0;
	return ret;
}

inline void a_UTF16ArrayToUTF8String(const utf16_char* utf16str, int buf_len, astring& utf8Str)
{
	int char_len = buf_len / sizeof(utf16_char);
	AzureHelpFuncs::safe_utf16to8(utf16str, utf16str + char_len, std::back_inserter(utf8Str));
}

inline void a_UTF8ArrayToUTF16String(const char* utf8str, int buf_len, utf16string& utf16Str)
{
	utf8::unchecked::utf8to16(utf8str, utf8str + buf_len, std::back_inserter(utf16Str));
}

inline bool a_StrPrintf(TCHAR* Buffer, int BufferSize, const TCHAR* Fmt, ...)
{
	int32		Result = -1;

	GET_VARARGS_RESULT(Buffer, BufferSize, BufferSize - 1, Fmt, Fmt, Result);

	// If that fails
	if (Result == -1)
	{
		Buffer[0] = 0;
		return false;
	}
	else
	{
		Buffer[Result] = 0;
		return true;
	}
}
