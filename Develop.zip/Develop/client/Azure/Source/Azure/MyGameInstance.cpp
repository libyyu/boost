// Fill out your copyright notice in the Description page of Project Settings.

#include "MyGameInstance.h"
#include "Ticker.h"
#include "PlatformFilemanager.h"

#pragma warning(push)
#pragma warning(disable:4706)
#include "AzureGameSession.h"
#pragma warning(pop)

#include "FileSystem/IPlatformAFileWrapper.h"
#include "ResourceLoader/AzureResourceLoader.h"

static FDelegateHandle tickHandle;
void UMyGameInstance::Init()
{
	Super::Init();

	// Create AFilePackage here
	if (!GIsEditor)
	{
		IPlatformFile& CurPlatformFile = FPlatformFileManager::Get().GetPlatformFile();
		//if (CurPlatformFile.GetName() != FString(TEXT("SandboxFile")))
		{
			static TUniquePtr<IPlatformFile> AutoDestroySingleton(new FPlatformAFileWrapper());
			IPlatformFile* WrapperFile = AutoDestroySingleton.Get();

			if (WrapperFile != nullptr && WrapperFile->ShouldBeUsed(&CurPlatformFile, TEXT("")))
			{
				if (WrapperFile->Initialize(&CurPlatformFile, TEXT("")))
				{
					FPlatformFileManager::Get().SetPlatformFile(*WrapperFile);
				}
			}
		}

		/*
		int aa = 100;

		UObject* curRes = ResourceLoader::Get().LoadGameRes(TEXT("Activity_LY"));
		if (curRes != nullptr && curRes->IsA<UTexture>())
		{
			GEngine->AddOnScreenDebugMessage(-1, 15, FColor::Green, FString::Printf(TEXT("load succ")));
		}

		ResourceLoader::Get().LoadGameResAsync(TEXT("Activity_LY"), [aa](UObject* res) {
			if (res != nullptr && res->IsA<UTexture>())
			{
				GEngine->AddOnScreenDebugMessage(-1, 15, FColor::Green, FString::Printf(TEXT("aa is :%d"), aa));
			}
		});
		*/
	}

	//AzureGameSession& gs = AzureGameSession::Instance();
	//gs.ConnectToServer("10.236.100.112", 9226, "zl522", "123456");
	
}

void UMyGameInstance::Shutdown()
{ 
	if (tickHandle.IsValid())
		FTicker::GetCoreTicker().RemoveTicker(tickHandle);
	AzureGameSession::Instance().Close();
	Super::Shutdown();
}

