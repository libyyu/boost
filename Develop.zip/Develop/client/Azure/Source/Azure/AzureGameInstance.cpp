// Fill out your copyright notice in the Description page of Project Settings.

#include "AzureGameInstance.h"

void UAzureGameInstance::Init()
{
	Super::Init();
}

void UAzureGameInstance::Shutdown()
{
	Super::Shutdown();
}
