// Fill out your copyright notice in the Description page of Project Settings.

#include "AzurePlayer.h"
#include "AzureEntryPoint.h"
#include "Runtime/Engine/Classes/Animation/AnimSequence.h"
#include "Runtime/Engine/Classes/Animation/BlendSpace1D.h"
#include "Runtime/Engine/Classes/Animation/AnimSingleNodeInstance.h"
#include "GameFramework/SpringArmComponent.h"
#include "Engine.h"

//test
#include "AzureEntryPoint.h"

// Sets default values
AAzurePlayer::AAzurePlayer()
{
 	// Set this actor to call Tick() every frame.  You can turn this off to improve performance if you don't need it.
	PrimaryActorTick.bCanEverTick = true;

	if (!RootComponent)
	{
		USceneComponent* SceneComponent = CreateDefaultSubobject<USceneComponent>(TEXT("AzurePlayerRootComponent"));
		SetRootComponent(SceneComponent);
	}
}

static void InitializeAzurePlayerInputBindings()
{
	UPlayerInput::AddEngineDefinedAxisMapping(FInputAxisKeyMapping("AzurePlayer_MoveForward", EKeys::W, 1.f));
	UPlayerInput::AddEngineDefinedAxisMapping(FInputAxisKeyMapping("AzurePlayer_MoveForward", EKeys::S, -1.f));
	UPlayerInput::AddEngineDefinedAxisMapping(FInputAxisKeyMapping("AzurePlayer_MoveRight", EKeys::A, -1.f));
	UPlayerInput::AddEngineDefinedAxisMapping(FInputAxisKeyMapping("AzurePlayer_MoveRight", EKeys::D, 1.f));

	UPlayerInput::AddEngineDefinedAxisMapping(FInputAxisKeyMapping("AzurePlayer_YawCamera", EKeys::Left, -1.f));
	UPlayerInput::AddEngineDefinedAxisMapping(FInputAxisKeyMapping("AzurePlayer_YawCamera", EKeys::Right, 1.f));
	UPlayerInput::AddEngineDefinedAxisMapping(FInputAxisKeyMapping("AzurePlayer_PitchCamera", EKeys::Up, 1.f));
	UPlayerInput::AddEngineDefinedAxisMapping(FInputAxisKeyMapping("AzurePlayer_PitchCamera", EKeys::Down, -1.f));

	UPlayerInput::AddEngineDefinedActionMapping(FInputActionKeyMapping("AzurePlayer_ZoomInOut", EKeys::TouchKeys[0]));
	UPlayerInput::AddEngineDefinedActionMapping(FInputActionKeyMapping("AzurePlayer_Move", EKeys::TouchKeys[0]));

	UPlayerInput::AddEngineDefinedActionMapping(FInputActionKeyMapping("AzurePlayer_1", EKeys::One));
	UPlayerInput::AddEngineDefinedActionMapping(FInputActionKeyMapping("AzurePlayer_2", EKeys::Two));
	UPlayerInput::AddEngineDefinedActionMapping(FInputActionKeyMapping("AzurePlayer_3", EKeys::Three));
	UPlayerInput::AddEngineDefinedActionMapping(FInputActionKeyMapping("AzurePlayer_4", EKeys::Four));
	UPlayerInput::AddEngineDefinedActionMapping(FInputActionKeyMapping("AzurePlayer_5", EKeys::Five));
}

// Called when the game starts or when spawned
void AAzurePlayer::BeginPlay()
{
	Super::BeginPlay();
	
}

// Called every frame
void AAzurePlayer::Tick( float DeltaTime )
{
	Super::Tick( DeltaTime );

	if (doLoadMap)
	{
		doLoadMap = false;
	}
	else if (doLoadPlayer)
	{
		doLoadPlayer = false;
		LoadPlayer();
	}
	else
	{
		Pawn = Pawns[currentIdx];
		SpringArm = SpringArms[currentIdx];
		if (Pawn && SpringArm && !SpringArm->IsValidLowLevel())
		{
			SpringArm = Pawn->FindComponentByClass<USpringArmComponent>();
			if (!SpringArm->IsValidLowLevel())
				SpringArm = 0;
			SpringArms[currentIdx] = SpringArm;
		}
	}

	if (SpringArm)
	{
		if (bZoomingIn)
		{
			ZoomFactor += DeltaTime / 0.5f;
		}
		else
		{
			ZoomFactor -= DeltaTime / 0.25f;
		}
		ZoomFactor = FMath::Clamp<float>(ZoomFactor, 0.0f, 1.0f);
		//OurCamera->FieldOfView = FMath::Lerp<float>(90.0f, 60.0f, ZoomFactor);
		SpringArm->TargetArmLength = FMath::Lerp<float>(400.0f, 300.0f, ZoomFactor);
	}

	if (Pawn)
	{
		FRotator NewRotation = Pawn->GetActorRotation();
		NewRotation.Yaw += CameraInput.X;
		Pawn->SetActorRotation(NewRotation);
	}

	if (SpringArm)
	{
		FRotator NewRotation = SpringArm->GetComponentRotation();
		NewRotation.Pitch = FMath::Clamp(NewRotation.Pitch + CameraInput.Y, -80.0f, -15.0f);
		SpringArm->SetWorldRotation(NewRotation);
	}

	if (Pawn)
	{
		if (!MovementInput.IsZero())
		{
			MovementInput = MovementInput.GetSafeNormal() * 150.0f;
			FVector NewLocation = Pawn->GetActorLocation();
			NewLocation += Pawn->GetActorForwardVector() * MovementInput.X * DeltaTime;
			NewLocation += Pawn->GetActorRightVector() * MovementInput.Y * DeltaTime;
			Pawn->SetActorLocation(NewLocation);
		}
	}
}
void AAzurePlayer::MoveForward(float AxisValue)
{
	MovementInput.X = FMath::Clamp<float>(AxisValue, -1.0f, 1.0f);
}

void AAzurePlayer::MoveRight(float AxisValue)
{
	MovementInput.Y = FMath::Clamp<float>(AxisValue, -1.0f, 1.0f);
}

void AAzurePlayer::PitchCamera(float AxisValue)
{
	CameraInput.Y = -AxisValue;
}

void AAzurePlayer::YawCamera(float AxisValue)
{
	CameraInput.X = AxisValue;
}

void AAzurePlayer::ZoomIn()
{
	bZoomingIn = true;
}

void AAzurePlayer::ZoomOut()
{
	bZoomingIn = false;
}
void AAzurePlayer::Key1()
{
	currentIdx = 0;
	OnKey(currentIdx);
}
void AAzurePlayer::Key2()
{
	currentIdx = 1;
	OnKey(currentIdx);
}
void AAzurePlayer::Key3()
{
	currentIdx = 2;
	OnKey(currentIdx);
}
void AAzurePlayer::Key4()
{
	currentIdx = 3;
	OnKey(currentIdx);
}
void AAzurePlayer::Key5()
{
	currentIdx = 4;
	OnKey(currentIdx);
}
void AAzurePlayer::OnKey(int idx)
{
	if (idx < 0 || idx > MAX_PAWN)
		return;

	APlayerController *PlayerController = UGameplayStatics::GetPlayerController(this, 0);
	if (PlayerController && Pawns[currentIdx])
	{
		//PlayerController->Possess(Pawns[currentIdx]);
		FViewTargetTransitionParams TransitionParams;
		TransitionParams.BlendTime = BlendTimes[currentIdx];
		PlayerController->SetViewTarget(Pawns[currentIdx], TransitionParams);
	}
}

void AAzurePlayer::TouchMove()
{
}

void AAzurePlayer::LoadPlayer()
{
	// blueprint Actor with USpringArmComponent
	UClass *BP_Player_C = LoadObject<UClass>(0, TEXT("/Game/Arts/Blueprints/BP_Player.BP_Player_C"));
	if (BP_Player_C) for (int i = 0; i < 2; ++i)
	{
		Pawns[i] = GetWorld()->SpawnActor<APawn>(BP_Player_C, FVector(0, -100 * i - 100, 0), FRotator::ZeroRotator);
		if (Pawns[i])
			SpringArms[i] = Pawns[i]->FindComponentByClass<USpringArmComponent>();
	}

	// normal Actor with UCameraComponent
	UCameraComponent *CameraComponent = NewObject<UCameraComponent>();
	CameraComponent->SetupAttachment(RootComponent);
	CameraComponent->RegisterComponentWithWorld(GetWorld());
	Pawns[2] = this;
	SpringArms[2] = 0;
	this->SetActorLocation(FVector(-100, -100, 100));

	// ACameraActor
	Pawns[3] = GetWorld()->SpawnActor<ACameraActor>(ACameraActor::StaticClass(), FVector(0, 0, 100), FRotator::ZeroRotator);
	SpringArms[3] = 0;

	BlendTimes[0] = 0;
	BlendTimes[1] = 3;
	BlendTimes[2] = 2;
	BlendTimes[3] = 2;
	BlendTimes[4] = 2;

	// blueprint Actor with USpringArmComponent
	UClass *Mixamo_Maria_C = LoadObject<UClass>(0, TEXT("Blueprint'/Game/Arts/Blueprints/Mixamo_Maria.Mixamo_Maria_C'"));
	if (Mixamo_Maria_C)
	{
		FActorSpawnParameters ActorSpawnParameters;
		ActorSpawnParameters.Name = TEXT("ActorMaria");
		/*ActorSpawnParameters.OverrideLevel = GetWorld()->PersistentLevel;*/ // the same as Owner and OverrideLevel are null
		Pawns[4] = GetWorld()->SpawnActor<APawn>(Mixamo_Maria_C, FVector(350, -350, 0), FRotator::ZeroRotator, ActorSpawnParameters);
		if (Pawns[4])
		{
			SpringArms[4] = Pawns[4]->FindComponentByClass<USpringArmComponent>();

			USkeletalMeshComponent *SkeletalMeshComponent  = Pawns[4]->FindComponentByClass<USkeletalMeshComponent>();
			if (SkeletalMeshComponent)
			{
				float speed = 300;

#if 1 // EAnimationMode::AnimationBlueprint
				UClass *MixamoAnimBP_Maria_C = LoadObject<UClass>(0, TEXT("AnimBlueprint'/Game/Arts/Blueprints/MixamoAnimBP_Maria.MixamoAnimBP_Maria_C'"));
				if (MixamoAnimBP_Maria_C)
				{
					SkeletalMeshComponent->SetAnimationMode(EAnimationMode::AnimationBlueprint);
					SkeletalMeshComponent->SetAnimInstanceClass(MixamoAnimBP_Maria_C);
					UAnimInstance *AnimInstance = SkeletalMeshComponent->GetAnimInstance();
					if (AnimInstance)
					{
						UFloatProperty *SpeedProperty = FindField<UFloatProperty>(AnimInstance->GetClass(), TEXT("Speed"));
						if (SpeedProperty)
						{
							SpeedProperty->SetPropertyValue_InContainer(AnimInstance, speed);
						}
					}
				}
#else // EAnimationMode::AnimationSingleNode
				// play AnimSequence
				//UAnimSequence *AnimSequence = LoadObject<UAnimSequence>(0, TEXT("AnimSequence'/Game/Arts/Animations/Maria_J_J_Ong_Run.Maria_J_J_Ong_Run'"));
				//SkeletalMeshComponent->PlayAnimation(AnimSequence, true);

				// play BlendSpace1D
				UBlendSpace1D *BlendSpace1D = LoadObject<UBlendSpace1D>(0, TEXT("BlendSpace1D'/Game/Arts/Animations/MixamoBlend_Maria_1D.MixamoBlend_Maria_1D'"));
				if (BlendSpace1D)
				{
					SkeletalMeshComponent->PlayAnimation(BlendSpace1D, true);
					UAnimSingleNodeInstance *AnimSingleNodeInstance = SkeletalMeshComponent->GetSingleNodeInstance();
					if (AnimSingleNodeInstance)
					{
						AnimSingleNodeInstance->SetBlendSpaceInput(FVector(speed, 0, 0));
					}
				}
#endif
			}
		}
	}

	currentIdx = 4;

	APlayerController* PlayerController = UGameplayStatics::GetPlayerController(this, 0);
	if (PlayerController)
	{
		InitializeAzurePlayerInputBindings();
		EnableInput(PlayerController);
		if (InputComponent)
		{
			InputComponent->BindAction("AzurePlayer_ZoomInOut", IE_Pressed, this, &AAzurePlayer::ZoomIn);
			InputComponent->BindAction("AzurePlayer_ZoomInOut", IE_Released, this, &AAzurePlayer::ZoomOut);
			InputComponent->BindAction("AzurePlayer_ZoomInOut", IE_Repeat, this, &AAzurePlayer::TouchMove);
			InputComponent->BindAxis("AzurePlayer_MoveForward", this, &AAzurePlayer::MoveForward);
			InputComponent->BindAxis("AzurePlayer_MoveRight", this, &AAzurePlayer::MoveRight);
			InputComponent->BindAxis("AzurePlayer_YawCamera", this, &AAzurePlayer::YawCamera);
			InputComponent->BindAxis("AzurePlayer_PitchCamera", this, &AAzurePlayer::PitchCamera);

			InputComponent->BindAction("AzurePlayer_1", IE_Released, this, &AAzurePlayer::Key1);
			InputComponent->BindAction("AzurePlayer_2", IE_Released, this, &AAzurePlayer::Key2);
			InputComponent->BindAction("AzurePlayer_3", IE_Released, this, &AAzurePlayer::Key3);
			InputComponent->BindAction("AzurePlayer_4", IE_Released, this, &AAzurePlayer::Key4);
			InputComponent->BindAction("AzurePlayer_5", IE_Released, this, &AAzurePlayer::Key5);
		}

		if (Pawns[currentIdx])
			PlayerController->SetViewTarget(Pawns[currentIdx]);

		// show mouse
		PlayerController->bShowMouseCursor = 1;
		FInputModeGameAndUI InputMode;
		InputMode.SetHideCursorDuringCapture(false);
		InputMode.SetLockMouseToViewportBehavior(EMouseLockMode::DoNotLock);
		PlayerController->SetInputMode(InputMode);
	}
}

void AAzurePlayer::OnClicked()
{
	if (GEngine)
		GEngine->AddOnScreenDebugMessage(-1, 5, FColor::Green, FString::Printf(TEXT("OnClicked")));
}