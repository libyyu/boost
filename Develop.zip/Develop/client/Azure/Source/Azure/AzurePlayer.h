// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "AzurePlayer.generated.h"

class USpringArmComponent;

UCLASS()
class AZURE_API AAzurePlayer : public AActor
{
	GENERATED_BODY()
	
public:	
	// Sets default values for this actor's properties
	AAzurePlayer();

	// Called when the game starts or when spawned
	virtual void BeginPlay() override;
	
	// Called every frame
	virtual void Tick( float DeltaSeconds ) override;

	static const int MAX_PAWN = 5;
	AActor *Pawns[MAX_PAWN];
	USpringArmComponent* SpringArms[MAX_PAWN];
	float BlendTimes[MAX_PAWN];
	int currentIdx = -1;

	AActor *Pawn = nullptr;
	USpringArmComponent* SpringArm = nullptr;

	FVector2D MovementInput;
	FVector2D CameraInput;
	float ZoomFactor;
	bool bZoomingIn;

	bool doLoadMap = true;
	bool doLoadPlayer = false;

	void MoveForward(float AxisValue);
	void MoveRight(float AxisValue);
	void PitchCamera(float AxisValue);
	void YawCamera(float AxisValue);
	void ZoomIn();
	void ZoomOut();

	void Key1();
	void Key2();
	void Key3();
	void Key4();
	void Key5();

	void OnKey(int idx);
	void LoadPlayer();
	void TouchMove();

	UFUNCTION(BlueprintCallable, Category = "Default")
	void OnClicked();
};
