#pragma once

#include "CoreMinimal.h"

constexpr float UE_METRE_TRANS = 100.f;

#define VEC_FORWARD(v) ((v).X)
#define VEC_RIGHT(v) ((v).Y)
#define VEC_UP(v) ((v).Z)

inline FVector POS_TO_SERVER(const FVector& v)
{
	return FVector(VEC_RIGHT(v) / UE_METRE_TRANS, VEC_UP(v) / UE_METRE_TRANS, VEC_FORWARD(v) / UE_METRE_TRANS);
}

inline FVector DIR_TO_SERVER(const FVector& v)
{
	return FVector(VEC_RIGHT(v), VEC_UP(v), VEC_FORWARD(v));
}

inline FVector POS_FROM_SERVER(const FVector& v)
{
	return FVector(v.Z * UE_METRE_TRANS, v.X * UE_METRE_TRANS, v.Y * UE_METRE_TRANS);
}

inline FVector DIR_FROM_SERVER(const FVector& v)
{
	return FVector(v.Z, v.X, v.Y);
}

inline FVector RELATIVE_POS_TO_SERVER(const FVector& v)//�������;������겻ͬ��ע��ע��
{
	return FVector(VEC_FORWARD(v) / UE_METRE_TRANS, VEC_UP(v) / UE_METRE_TRANS, -VEC_RIGHT(v) / UE_METRE_TRANS);
}

inline FVector RELATIVE_POS_FROM_SERVER(const FVector& v)//�������;������겻ͬ��ע��ע��
{
	return FVector(VEC_FORWARD(v) * UE_METRE_TRANS, -VEC_UP(v) * UE_METRE_TRANS, VEC_RIGHT(v) * UE_METRE_TRANS);
}

inline FVector RELATIVE_DIR_TO_SERVER(const FVector& v)
{
	return FVector(VEC_FORWARD(v), VEC_UP(v), -VEC_RIGHT(v));
}

inline FVector RELATIVE_DIR_FROM_SERVER(const FVector& v)
{
	return FVector(VEC_FORWARD(v), -VEC_UP(v), VEC_RIGHT(v));
}