#include "Azure.h"
#include "LuaInterface.h"

namespace LuaVersionFlags
{
	static int lua_ReturnTrue(lua_State *L)
	{
		lua_pushboolean(L, 1);
		return 1;
	}

	static luaL_Reg Lib_VersionFlags_Funcs[] =
	{
		{ "FxCache_AsyncCheckingFixed", lua_ReturnTrue },
		{ "AzureDepthFadeFixed", lua_ReturnTrue },
		{ NULL, NULL }
	};

	void Register(lua_State* L)
	{
		luaL_register(L, "VersionFlags", Lib_VersionFlags_Funcs);
		lua_pop(L, 1);
	}
}
