#pragma once

namespace wLua
{
	struct lua_registry_handle;
}

class LuaRegistryRefWrapper
{
public:
	LuaRegistryRefWrapper();
	~LuaRegistryRefWrapper();
	void PushToStack();

	wLua::lua_registry_handle refID;
};