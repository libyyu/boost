/*
	供 Lua 调用的 Windows 函数 (主要为调试或开发用)
*/

#if PLATFORM_WINDOWS

#include "LuaInterface.h"
#include "AzureLuaIntegration.h"
#include "Windows/WindowsHWrapper.h"
#include "MallocProfilerExWinHook.h"
#include <shellapi.h>
#include <psapi.h>
#include <winternl.h>
//#include <processenv.h>
//#include "Windows/AllowWindowsPlatformTypes.h"
//#include <Ole2.h>
//#include <oleidl.h>
//#include "Windows/HideWindowsPlatformTypes.h"

#if USE_MALLOC_PROFILER_WIN_HOOK
	extern HANDLE FMallocProfilerExWinHook_PrivateHeap;
#endif

extern "C" {
	typedef NTSTATUS(WINAPI *t_NtQueryInformationProcess)(HANDLE, PROCESSINFOCLASS, PVOID, ULONG, PULONG);
}

namespace wLua
{
	namespace GameLuaInterface
	{
		static int lua_GetWindowText(lua_State * L)
		{
			uint32 processId = FPlatformProcess::GetCurrentProcessId();
			auto hWnd = FPlatformMisc::GetTopLevelWindowHandle(processId);
			if (hWnd != nullptr)
			{
				TCHAR szTitle[10240] = { 0 };
				int len = GetWindowText(hWnd, szTitle, 10240);
				lua_pushstring(L, TCHAR_TO_UTF8(szTitle));
				return 1;
			}
			return 0;
		}

		static int lua_SetWindowText(lua_State * L)
		{
			size_t size;
			const char* data = luaL_checklstring(L, 1, &size);
			if (data != nullptr)
			{
				uint32 processId = FPlatformProcess::GetCurrentProcessId();
				auto hWnd = FPlatformMisc::GetTopLevelWindowHandle(processId);
				if (hWnd != nullptr)
				{
					SetWindowText(hWnd, UTF8_TO_TCHAR(data));
				}
			}
			return 0;
		}

		static int lua_GetTopLevelWindowHandle(lua_State * L)
		{
			uint32 processId = FPlatformProcess::GetCurrentProcessId();
			auto hWnd = FPlatformMisc::GetTopLevelWindowHandle(processId);
			lua_pushlstring(L, (const char*)&hWnd, sizeof(hWnd));
			return 1;
		}

		static int lua_SetWindowTextByHandle(lua_State * L)
		{
			Windows::HWND hWnd;
			size_t handleSize;
			char const* pHandle = luaL_checklstring(L, 1, &handleSize);
			if (handleSize != sizeof(hWnd))
			{
				luaL_argerror(L, 1, "invalid window handle");
				return 0;
			}

			memcpy(&hWnd, pHandle, sizeof(hWnd));
			const char* data = luaL_checkstring(L, 2);
			if (hWnd != nullptr)
			{
				SetWindowText(hWnd, UTF8_TO_TCHAR(data));
			}
			return 0;
		}

		static int lua_ShowWindow(lua_State * L)
		{
			bool show = lua_toboolean(L, 1);
			uint32 processId = FPlatformProcess::GetCurrentProcessId();
			auto hWnd = FPlatformMisc::GetTopLevelWindowHandle(processId);
			if (hWnd != nullptr)
			{
				ShowWindow(hWnd, show ? 5 : 0);
			}
			return 0;
		}

		static int lua_GetAsyncKeyState(lua_State * L)
		{
			lua_pushboolean(L, GetAsyncKeyState(lua_tointeger(L, 1)));
			return 1;
		}

		extern "C" __declspec(dllimport) bool InternetGetConnectedState(DWORD*, DWORD);
		static int lua_InternetGetConnectedState(lua_State *L)
		{
			DWORD flags;
			bool bOnline = true;
			bOnline = InternetGetConnectedState(&flags, 0);
			if (bOnline)//在线  
			{
				lua_pushboolean(L, 1);
				lua_pushnumber(L, flags);
				return 2;
			}
			else
			{
				lua_pushboolean(L, 0);
				return 1;
			}
		}

		static int lua_GetProcessHeap(lua_State* L)
		{
			HANDLE hHeap = GetProcessHeap();
			lua_pushlightuserdata(L, (void*)hHeap);
			return 1;
		}

		static int lua_GetProcessHeaps(lua_State* L)
		{
			DWORD numHeaps = GetProcessHeaps(0, nullptr);
			TArray<HANDLE> results;
			results.AddUninitialized(numHeaps);
			DWORD trueNumHeaps = GetProcessHeaps(numHeaps, results.GetData());
			lua_createtable(L, numHeaps, 0);
			for (int i=0; i<numHeaps; ++i)
			{
				lua_pushlightuserdata(L, (void*)results[i]);
				lua_rawseti(L, -2, i+1);
			}
			return 1;
		}

		static int lua_GetHeapSizeInfo(lua_State* L)
		{
			luaL_checktype(L, 1, LUA_TLIGHTUSERDATA);
			HANDLE hHeap = (HANDLE)lua_touserdata(L, 1);
			PROCESS_HEAP_ENTRY heapEntry;
			heapEntry.lpData = nullptr;
			uint64 entryUsedSize = 0;
			uint64 entryOverhead = 0;
			uint64 regionReservedSize = 0;
			uint64 regionCommitedSize = 0;
			uint64 regionUncommitedSize = 0;
			uint64 regionOverhead = 0;
			HeapLock(hHeap);
			while (HeapWalk(hHeap, &heapEntry))
			{
				if ((heapEntry.wFlags & PROCESS_HEAP_ENTRY_BUSY) != 0)
				{
					entryUsedSize += heapEntry.cbData;
					entryOverhead += heapEntry.cbOverhead;
				}
				if ((heapEntry.wFlags & PROCESS_HEAP_REGION) != 0)
				{
					regionReservedSize += heapEntry.cbData;
					regionCommitedSize += heapEntry.Region.dwCommittedSize;
					regionUncommitedSize += heapEntry.Region.dwUnCommittedSize;
					regionOverhead += heapEntry.cbOverhead;
				}
			}
			HeapUnlock(hHeap);
			lua_newtable(L);
			lua_pushnumber(L, (double)entryUsedSize);
			lua_setfield(L, -2, "entryUsedSize");
			lua_pushnumber(L, (double)entryOverhead);
			lua_setfield(L, -2, "entryOverhead");
			lua_pushnumber(L, (double)regionReservedSize);
			lua_setfield(L, -2, "regionReservedSize");
			lua_pushnumber(L, (double)regionCommitedSize);
			lua_setfield(L, -2, "regionCommitedSize");
			lua_pushnumber(L, (double)regionUncommitedSize);
			lua_setfield(L, -2, "regionUncommitedSize");
			lua_pushnumber(L, (double)regionOverhead);
			lua_setfield(L, -2, "regionOverhead");

			return 1;
		}

		static int lua_GetMallocProfilerPrivateHeap(lua_State* L)
		{
#if USE_MALLOC_PROFILER_WIN_HOOK
			if (FMallocProfilerExWinHook_PrivateHeap == nullptr)
				lua_pushnil(L);
			else
				lua_pushlightuserdata(L, FMallocProfilerExWinHook_PrivateHeap);
			return 1;
#else
			lua_pushnil(L);
			return 1;
#endif
		}

		void DoFlashWindow(int count, int freq)
		{
			uint32 processId = FPlatformProcess::GetCurrentProcessId();
			auto hWnd = FPlatformMisc::GetTopLevelWindowHandle(processId);
			FLASHWINFO info;
			info.cbSize = sizeof(info);
			info.hwnd = hWnd;
			info.dwFlags = FLASHW_ALL;
			info.uCount = count;
			info.dwTimeout = freq;
			FlashWindowEx(&info);
		}

		static int lua_SetGameIsFakingTouchEvents(lua_State* L)
		{
			bool bFaking = lua_toboolean(L, 1);
			FSlateApplication::Get().SetGameIsFakingTouchEvents(bFaking);
			return 0;
		}

		static int lua_FlashWindow(lua_State* L)
		{
			int nCount = luaL_checkinteger(L, 1);
			int nTimeout = luaL_checkinteger(L, 2);
			DoFlashWindow(nCount, nTimeout);
			return 0;
		}

		static int lua_ReStartApp(lua_State* L)
		{
			static t_NtQueryInformationProcess NtQueryInformationProcess = nullptr;
			if (!NtQueryInformationProcess)
			{
				NtQueryInformationProcess = (t_NtQueryInformationProcess)GetProcAddress(GetModuleHandle(TEXT("ntdll.dll")), "NtQueryInformationProcess");
			}
			if (!NtQueryInformationProcess)
			{
				UE_LOG(LogTemp, Error, TEXT("Failed GetProcAddress NtQueryInformationProcess"));
				lua_pushboolean(L, 0);
				return 1;
			}

			FString cmdLine = FCommandLine::Get();
			uint32 processId = FPlatformProcess::GetCurrentProcessId();
			auto hWnd = FPlatformMisc::GetTopLevelWindowHandle(processId);

			auto Process = FPlatformProcess::OpenProcess(processId);
			if (!Process.Get())
			{
				UE_LOG(LogTemp, Error, TEXT("Failed OpenProcess %d"), processId);
				lua_pushboolean(L, 0);
				return 1;
			}

			DWORD dwParentProcessId = 0;
			LONG status;
			PROCESS_BASIC_INFORMATION pbi;
			status = NtQueryInformationProcess(Process.Get(), ProcessBasicInformation, &pbi, sizeof(PROCESS_BASIC_INFORMATION), NULL);

			if (NT_SUCCESS(status))
			{
				dwParentProcessId = reinterpret_cast<DWORD_PTR>(pbi.Reserved3);
			}
			else
			{
				UE_LOG(LogTemp, Warning, TEXT("Failed NtQueryInformationProcess %d"), processId);
			}

			FString exeFileName = FPlatformProcess::GetApplicationName(dwParentProcessId != 0 ? dwParentProcessId : processId);

			UE_LOG(LogTemp, Warning, TEXT("Will Restart Process: %d, ParentProcess:%d, bin:%s"), processId, dwParentProcessId, *exeFileName);

			if (exeFileName.IsEmpty())
			{
				UE_LOG(LogTemp, Error, TEXT("Failed GetApplicationName %d"), processId);
				lua_pushboolean(L, 0);
				return 1;
			}

			::PostMessage(hWnd, WM_SYSCOMMAND, SC_CLOSE, NULL);
			::Sleep(500);

			PROCESS_INFORMATION procInfo;
			ZeroMemory(&procInfo, sizeof(PROCESS_INFORMATION));

			STARTUPINFO startInfo;
			ZeroMemory(&startInfo, sizeof(startInfo));
			startInfo.cb = sizeof(startInfo);
			bool v = CreateProcess(*exeFileName, cmdLine.GetCharArray().GetData(), NULL, NULL, FALSE, NORMAL_PRIORITY_CLASS, NULL, NULL, &startInfo, &procInfo);					
			lua_pushboolean(L, v ? 1 : 0);

			return 1;
		}

		extern const luaL_Reg Lib_WindowsUtil_Funcs[] =
		{
			{ "GetWindowText", lua_GetWindowText },
			{ "SetWindowText", lua_SetWindowText },
			{ "GetTopLevelWindowHandle", lua_GetTopLevelWindowHandle },
			{ "SetWindowTextByHandle", lua_SetWindowTextByHandle },
			{ "ShowWindow", lua_ShowWindow },
			{ "GetAsyncKeyState", lua_GetAsyncKeyState },
			{ "InternetGetConnectedState", lua_InternetGetConnectedState },
			{ "GetProcessHeap", lua_GetProcessHeap, },
			{ "GetProcessHeaps", lua_GetProcessHeaps, },
			{ "GetHeapSizeInfo", lua_GetHeapSizeInfo, },
			{ "GetMallocProfilerPrivateHeap", lua_GetMallocProfilerPrivateHeap, },
			{ "SetGameIsFakingTouchEvents", lua_SetGameIsFakingTouchEvents },
			{ "FlashWindow", lua_FlashWindow },
			{ "ReStartApp", lua_ReStartApp },
			
			{ NULL, NULL }
		};
	}
}

#endif	//end #if PLATFORM_WINDOWS
