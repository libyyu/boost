#include "Azure.h"
#include "Utility/help_funcs.h"
#include "wLua/UObjectHeaders.h"
#include "Components/SizeBoxSlot.h"
#include "AzureLuaIntegration.h"

namespace LuaSizeBoxSlot
{
int32 SetVerticalAlignment(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SizeBoxSlot",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SizeBoxSlot must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		TEnumAsByte<EVerticalAlignment> InVerticalAlignment;
	} Params;
	Params.InVerticalAlignment = (TEnumAsByte<EVerticalAlignment>)(luaL_checkint(InScriptContext, 2));
#if UE_GAME
	USizeBoxSlot * This = (USizeBoxSlot *)Obj;
	This->SetVerticalAlignment(Params.InVerticalAlignment);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetVerticalAlignment"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(TEnumAsByte<EVerticalAlignment>*)(params.GetStructMemory() + 0) = Params.InVerticalAlignment;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.InVerticalAlignment = *(TEnumAsByte<EVerticalAlignment>*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetHorizontalAlignment(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SizeBoxSlot",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SizeBoxSlot must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		TEnumAsByte<EHorizontalAlignment> InHorizontalAlignment;
	} Params;
	Params.InHorizontalAlignment = (TEnumAsByte<EHorizontalAlignment>)(luaL_checkint(InScriptContext, 2));
#if UE_GAME
	USizeBoxSlot * This = (USizeBoxSlot *)Obj;
	This->SetHorizontalAlignment(Params.InHorizontalAlignment);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetHorizontalAlignment"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(TEnumAsByte<EHorizontalAlignment>*)(params.GetStructMemory() + 0) = Params.InHorizontalAlignment;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.InHorizontalAlignment = *(TEnumAsByte<EHorizontalAlignment>*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 Get_HorizontalAlignment(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SizeBoxSlot",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SizeBoxSlot must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USizeBoxSlot::StaticClass(), TEXT("HorizontalAlignment"));
	if(!Property) { check(false); return 0;}
	TEnumAsByte<EHorizontalAlignment> PropertyValue = TEnumAsByte<EHorizontalAlignment>();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushinteger(InScriptContext, (int)PropertyValue);
	return 1;
}

int32 Get_VerticalAlignment(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SizeBoxSlot",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SizeBoxSlot must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USizeBoxSlot::StaticClass(), TEXT("VerticalAlignment"));
	if(!Property) { check(false); return 0;}
	TEnumAsByte<EVerticalAlignment> PropertyValue = TEnumAsByte<EVerticalAlignment>();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushinteger(InScriptContext, (int)PropertyValue);
	return 1;
}

int32 New(lua_State* InScriptContext)
{
	UObject* Outer = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Object");
	FName Name = FName(luaL_checkstring(InScriptContext, 2));
	UObject* Obj = NewObject<USizeBoxSlot>(Outer, Name);
	wLua::FLuaUtils::ReturnUObject(InScriptContext,Obj);
	return 1;
}

int32 Destroy(lua_State* InScriptContext)
{
	return 0;
}

int32 Class(lua_State* InScriptContext)
{
	UClass* Class = USizeBoxSlot::StaticClass();
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Class);
	return 1;
}

const luaL_Reg Lib_Funcs[] =
{
	{ "New", New },
	{ "Destroy", Destroy },
	{ "Class", Class },
	{ "SetVerticalAlignment", SetVerticalAlignment },
	{ "SetHorizontalAlignment", SetHorizontalAlignment },
	{ "Get_HorizontalAlignment", Get_HorizontalAlignment },
	{ "Get_VerticalAlignment", Get_VerticalAlignment },
	{ "is_nil", wLua::LuaStatic::isnil },
	{ "__gc", wLua::LuaStatic::removeUClassFrameCache },
	{ NULL, NULL }
};

void Register(lua_State *InScriptContext)
{
	lua_newtable(InScriptContext);
	luaL_register(InScriptContext, NULL, Lib_Funcs);
	AzureHelpFuncs::AuxRegister(InScriptContext, "SizeBoxSlot");
}
void SetMtLink(lua_State *InScriptContext)
{
	AzureHelpFuncs::AuxSetMtLink(InScriptContext, "SizeBoxSlot", "PanelSlot",USERDATATYPE_UOBJECT);
}

}