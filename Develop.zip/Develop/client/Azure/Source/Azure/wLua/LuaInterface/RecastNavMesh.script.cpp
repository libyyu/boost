#include "Azure.h"
#include "Utility/help_funcs.h"
#include "wLua/UObjectHeaders.h"
#include "NavMesh/RecastNavMesh.h"
#include "AzureLuaIntegration.h"

namespace LuaRecastNavMesh
{
int32 RebuildNavMesh(lua_State*);

int32 Get_bDrawTriangleEdges(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"RecastNavMesh",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"RecastNavMesh must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(ARecastNavMesh::StaticClass(), TEXT("bDrawTriangleEdges"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bDrawTriangleEdges(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"RecastNavMesh",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"RecastNavMesh must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(ARecastNavMesh::StaticClass(), TEXT("bDrawTriangleEdges"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bDrawPolyEdges(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"RecastNavMesh",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"RecastNavMesh must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(ARecastNavMesh::StaticClass(), TEXT("bDrawPolyEdges"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bDrawPolyEdges(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"RecastNavMesh",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"RecastNavMesh must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(ARecastNavMesh::StaticClass(), TEXT("bDrawPolyEdges"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bDrawFilledPolys(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"RecastNavMesh",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"RecastNavMesh must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(ARecastNavMesh::StaticClass(), TEXT("bDrawFilledPolys"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bDrawFilledPolys(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"RecastNavMesh",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"RecastNavMesh must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(ARecastNavMesh::StaticClass(), TEXT("bDrawFilledPolys"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bDrawNavMeshEdges(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"RecastNavMesh",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"RecastNavMesh must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(ARecastNavMesh::StaticClass(), TEXT("bDrawNavMeshEdges"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bDrawNavMeshEdges(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"RecastNavMesh",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"RecastNavMesh must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(ARecastNavMesh::StaticClass(), TEXT("bDrawNavMeshEdges"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bDrawTileBounds(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"RecastNavMesh",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"RecastNavMesh must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(ARecastNavMesh::StaticClass(), TEXT("bDrawTileBounds"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bDrawTileBounds(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"RecastNavMesh",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"RecastNavMesh must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(ARecastNavMesh::StaticClass(), TEXT("bDrawTileBounds"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bDrawPathCollidingGeometry(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"RecastNavMesh",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"RecastNavMesh must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(ARecastNavMesh::StaticClass(), TEXT("bDrawPathCollidingGeometry"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bDrawPathCollidingGeometry(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"RecastNavMesh",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"RecastNavMesh must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(ARecastNavMesh::StaticClass(), TEXT("bDrawPathCollidingGeometry"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bDrawTileLabels(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"RecastNavMesh",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"RecastNavMesh must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(ARecastNavMesh::StaticClass(), TEXT("bDrawTileLabels"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bDrawTileLabels(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"RecastNavMesh",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"RecastNavMesh must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(ARecastNavMesh::StaticClass(), TEXT("bDrawTileLabels"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bDrawPolygonLabels(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"RecastNavMesh",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"RecastNavMesh must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(ARecastNavMesh::StaticClass(), TEXT("bDrawPolygonLabels"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bDrawPolygonLabels(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"RecastNavMesh",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"RecastNavMesh must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(ARecastNavMesh::StaticClass(), TEXT("bDrawPolygonLabels"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bDrawDefaultPolygonCost(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"RecastNavMesh",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"RecastNavMesh must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(ARecastNavMesh::StaticClass(), TEXT("bDrawDefaultPolygonCost"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bDrawDefaultPolygonCost(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"RecastNavMesh",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"RecastNavMesh must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(ARecastNavMesh::StaticClass(), TEXT("bDrawDefaultPolygonCost"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bDrawLabelsOnPathNodes(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"RecastNavMesh",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"RecastNavMesh must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(ARecastNavMesh::StaticClass(), TEXT("bDrawLabelsOnPathNodes"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bDrawLabelsOnPathNodes(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"RecastNavMesh",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"RecastNavMesh must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(ARecastNavMesh::StaticClass(), TEXT("bDrawLabelsOnPathNodes"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bDrawNavLinks(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"RecastNavMesh",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"RecastNavMesh must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(ARecastNavMesh::StaticClass(), TEXT("bDrawNavLinks"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bDrawNavLinks(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"RecastNavMesh",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"RecastNavMesh must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(ARecastNavMesh::StaticClass(), TEXT("bDrawNavLinks"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bDrawFailedNavLinks(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"RecastNavMesh",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"RecastNavMesh must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(ARecastNavMesh::StaticClass(), TEXT("bDrawFailedNavLinks"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bDrawFailedNavLinks(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"RecastNavMesh",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"RecastNavMesh must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(ARecastNavMesh::StaticClass(), TEXT("bDrawFailedNavLinks"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bDrawClusters(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"RecastNavMesh",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"RecastNavMesh must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(ARecastNavMesh::StaticClass(), TEXT("bDrawClusters"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bDrawClusters(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"RecastNavMesh",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"RecastNavMesh must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(ARecastNavMesh::StaticClass(), TEXT("bDrawClusters"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bDrawOctree(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"RecastNavMesh",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"RecastNavMesh must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(ARecastNavMesh::StaticClass(), TEXT("bDrawOctree"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bDrawOctree(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"RecastNavMesh",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"RecastNavMesh must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(ARecastNavMesh::StaticClass(), TEXT("bDrawOctree"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bDrawOctreeDetails(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"RecastNavMesh",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"RecastNavMesh must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(ARecastNavMesh::StaticClass(), TEXT("bDrawOctreeDetails"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bDrawOctreeDetails(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"RecastNavMesh",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"RecastNavMesh must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(ARecastNavMesh::StaticClass(), TEXT("bDrawOctreeDetails"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bDrawNavMesh(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"RecastNavMesh",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"RecastNavMesh must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(ARecastNavMesh::StaticClass(), TEXT("bDrawNavMesh"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bDrawNavMesh(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"RecastNavMesh",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"RecastNavMesh must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(ARecastNavMesh::StaticClass(), TEXT("bDrawNavMesh"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_DrawOffset(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"RecastNavMesh",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"RecastNavMesh must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(ARecastNavMesh::StaticClass(), TEXT("DrawOffset"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_DrawOffset(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"RecastNavMesh",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"RecastNavMesh must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(ARecastNavMesh::StaticClass(), TEXT("DrawOffset"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bFixedTilePoolSize(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"RecastNavMesh",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"RecastNavMesh must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(ARecastNavMesh::StaticClass(), TEXT("bFixedTilePoolSize"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bFixedTilePoolSize(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"RecastNavMesh",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"RecastNavMesh must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(ARecastNavMesh::StaticClass(), TEXT("bFixedTilePoolSize"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_TilePoolSize(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"RecastNavMesh",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"RecastNavMesh must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(ARecastNavMesh::StaticClass(), TEXT("TilePoolSize"));
	if(!Property) { check(false); return 0;}
	int32 PropertyValue = int32();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushinteger(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_TilePoolSize(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"RecastNavMesh",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"RecastNavMesh must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(ARecastNavMesh::StaticClass(), TEXT("TilePoolSize"));
	if(!Property) { check(false); return 0;}
	int32 PropertyValue = (luaL_checkint(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_TileSizeUU(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"RecastNavMesh",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"RecastNavMesh must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(ARecastNavMesh::StaticClass(), TEXT("TileSizeUU"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_TileSizeUU(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"RecastNavMesh",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"RecastNavMesh must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(ARecastNavMesh::StaticClass(), TEXT("TileSizeUU"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_CellSize(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"RecastNavMesh",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"RecastNavMesh must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(ARecastNavMesh::StaticClass(), TEXT("CellSize"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_CellSize(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"RecastNavMesh",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"RecastNavMesh must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(ARecastNavMesh::StaticClass(), TEXT("CellSize"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_CellHeight(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"RecastNavMesh",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"RecastNavMesh must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(ARecastNavMesh::StaticClass(), TEXT("CellHeight"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_CellHeight(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"RecastNavMesh",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"RecastNavMesh must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(ARecastNavMesh::StaticClass(), TEXT("CellHeight"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_AgentRadius(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"RecastNavMesh",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"RecastNavMesh must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(ARecastNavMesh::StaticClass(), TEXT("AgentRadius"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_AgentRadius(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"RecastNavMesh",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"RecastNavMesh must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(ARecastNavMesh::StaticClass(), TEXT("AgentRadius"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_AgentHeight(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"RecastNavMesh",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"RecastNavMesh must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(ARecastNavMesh::StaticClass(), TEXT("AgentHeight"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_AgentHeight(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"RecastNavMesh",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"RecastNavMesh must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(ARecastNavMesh::StaticClass(), TEXT("AgentHeight"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_AgentMaxHeight(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"RecastNavMesh",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"RecastNavMesh must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(ARecastNavMesh::StaticClass(), TEXT("AgentMaxHeight"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_AgentMaxHeight(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"RecastNavMesh",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"RecastNavMesh must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(ARecastNavMesh::StaticClass(), TEXT("AgentMaxHeight"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_AgentMaxSlope(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"RecastNavMesh",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"RecastNavMesh must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(ARecastNavMesh::StaticClass(), TEXT("AgentMaxSlope"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_AgentMaxSlope(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"RecastNavMesh",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"RecastNavMesh must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(ARecastNavMesh::StaticClass(), TEXT("AgentMaxSlope"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_AgentMaxStepHeight(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"RecastNavMesh",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"RecastNavMesh must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(ARecastNavMesh::StaticClass(), TEXT("AgentMaxStepHeight"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_AgentMaxStepHeight(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"RecastNavMesh",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"RecastNavMesh must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(ARecastNavMesh::StaticClass(), TEXT("AgentMaxStepHeight"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_MinRegionArea(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"RecastNavMesh",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"RecastNavMesh must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(ARecastNavMesh::StaticClass(), TEXT("MinRegionArea"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_MinRegionArea(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"RecastNavMesh",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"RecastNavMesh must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(ARecastNavMesh::StaticClass(), TEXT("MinRegionArea"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_MergeRegionSize(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"RecastNavMesh",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"RecastNavMesh must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(ARecastNavMesh::StaticClass(), TEXT("MergeRegionSize"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_MergeRegionSize(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"RecastNavMesh",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"RecastNavMesh must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(ARecastNavMesh::StaticClass(), TEXT("MergeRegionSize"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_MaxSimplificationError(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"RecastNavMesh",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"RecastNavMesh must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(ARecastNavMesh::StaticClass(), TEXT("MaxSimplificationError"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_MaxSimplificationError(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"RecastNavMesh",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"RecastNavMesh must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(ARecastNavMesh::StaticClass(), TEXT("MaxSimplificationError"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_MaxSimultaneousTileGenerationJobsCount(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"RecastNavMesh",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"RecastNavMesh must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(ARecastNavMesh::StaticClass(), TEXT("MaxSimultaneousTileGenerationJobsCount"));
	if(!Property) { check(false); return 0;}
	int32 PropertyValue = int32();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushinteger(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_MaxSimultaneousTileGenerationJobsCount(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"RecastNavMesh",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"RecastNavMesh must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(ARecastNavMesh::StaticClass(), TEXT("MaxSimultaneousTileGenerationJobsCount"));
	if(!Property) { check(false); return 0;}
	int32 PropertyValue = (luaL_checkint(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_TileNumberHardLimit(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"RecastNavMesh",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"RecastNavMesh must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(ARecastNavMesh::StaticClass(), TEXT("TileNumberHardLimit"));
	if(!Property) { check(false); return 0;}
	int32 PropertyValue = int32();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushinteger(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_TileNumberHardLimit(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"RecastNavMesh",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"RecastNavMesh must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(ARecastNavMesh::StaticClass(), TEXT("TileNumberHardLimit"));
	if(!Property) { check(false); return 0;}
	int32 PropertyValue = (luaL_checkint(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_PolyRefTileBits(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"RecastNavMesh",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"RecastNavMesh must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(ARecastNavMesh::StaticClass(), TEXT("PolyRefTileBits"));
	if(!Property) { check(false); return 0;}
	int32 PropertyValue = int32();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushinteger(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_PolyRefTileBits(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"RecastNavMesh",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"RecastNavMesh must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(ARecastNavMesh::StaticClass(), TEXT("PolyRefTileBits"));
	if(!Property) { check(false); return 0;}
	int32 PropertyValue = (luaL_checkint(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_PolyRefNavPolyBits(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"RecastNavMesh",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"RecastNavMesh must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(ARecastNavMesh::StaticClass(), TEXT("PolyRefNavPolyBits"));
	if(!Property) { check(false); return 0;}
	int32 PropertyValue = int32();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushinteger(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_PolyRefNavPolyBits(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"RecastNavMesh",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"RecastNavMesh must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(ARecastNavMesh::StaticClass(), TEXT("PolyRefNavPolyBits"));
	if(!Property) { check(false); return 0;}
	int32 PropertyValue = (luaL_checkint(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_PolyRefSaltBits(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"RecastNavMesh",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"RecastNavMesh must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(ARecastNavMesh::StaticClass(), TEXT("PolyRefSaltBits"));
	if(!Property) { check(false); return 0;}
	int32 PropertyValue = int32();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushinteger(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_PolyRefSaltBits(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"RecastNavMesh",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"RecastNavMesh must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(ARecastNavMesh::StaticClass(), TEXT("PolyRefSaltBits"));
	if(!Property) { check(false); return 0;}
	int32 PropertyValue = (luaL_checkint(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_NavMeshOriginOffset(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"RecastNavMesh",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"RecastNavMesh must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(ARecastNavMesh::StaticClass(), TEXT("NavMeshOriginOffset"));
	if(!Property) { check(false); return 0;}
	FVector PropertyValue = FVector();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaVector::Return(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_NavMeshOriginOffset(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"RecastNavMesh",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"RecastNavMesh must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(ARecastNavMesh::StaticClass(), TEXT("NavMeshOriginOffset"));
	if(!Property) { check(false); return 0;}
	FVector PropertyValue = (wLua::FLuaVector::Get(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_RegionPartitioning(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"RecastNavMesh",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"RecastNavMesh must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(ARecastNavMesh::StaticClass(), TEXT("RegionPartitioning"));
	if(!Property) { check(false); return 0;}
	TEnumAsByte<ERecastPartitioning::Type> PropertyValue = TEnumAsByte<ERecastPartitioning::Type>();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushinteger(InScriptContext, (int)PropertyValue);
	return 1;
}

int32 Set_RegionPartitioning(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"RecastNavMesh",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"RecastNavMesh must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(ARecastNavMesh::StaticClass(), TEXT("RegionPartitioning"));
	if(!Property) { check(false); return 0;}
	TEnumAsByte<ERecastPartitioning::Type> PropertyValue = (TEnumAsByte<ERecastPartitioning::Type>)(luaL_checkint(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_LayerPartitioning(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"RecastNavMesh",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"RecastNavMesh must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(ARecastNavMesh::StaticClass(), TEXT("LayerPartitioning"));
	if(!Property) { check(false); return 0;}
	TEnumAsByte<ERecastPartitioning::Type> PropertyValue = TEnumAsByte<ERecastPartitioning::Type>();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushinteger(InScriptContext, (int)PropertyValue);
	return 1;
}

int32 Set_LayerPartitioning(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"RecastNavMesh",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"RecastNavMesh must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(ARecastNavMesh::StaticClass(), TEXT("LayerPartitioning"));
	if(!Property) { check(false); return 0;}
	TEnumAsByte<ERecastPartitioning::Type> PropertyValue = (TEnumAsByte<ERecastPartitioning::Type>)(luaL_checkint(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_RegionChunkSplits(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"RecastNavMesh",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"RecastNavMesh must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(ARecastNavMesh::StaticClass(), TEXT("RegionChunkSplits"));
	if(!Property) { check(false); return 0;}
	int32 PropertyValue = int32();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushinteger(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_RegionChunkSplits(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"RecastNavMesh",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"RecastNavMesh must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(ARecastNavMesh::StaticClass(), TEXT("RegionChunkSplits"));
	if(!Property) { check(false); return 0;}
	int32 PropertyValue = (luaL_checkint(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_LayerChunkSplits(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"RecastNavMesh",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"RecastNavMesh must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(ARecastNavMesh::StaticClass(), TEXT("LayerChunkSplits"));
	if(!Property) { check(false); return 0;}
	int32 PropertyValue = int32();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushinteger(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_LayerChunkSplits(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"RecastNavMesh",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"RecastNavMesh must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(ARecastNavMesh::StaticClass(), TEXT("LayerChunkSplits"));
	if(!Property) { check(false); return 0;}
	int32 PropertyValue = (luaL_checkint(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bSortNavigationAreasByCost(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"RecastNavMesh",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"RecastNavMesh must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(ARecastNavMesh::StaticClass(), TEXT("bSortNavigationAreasByCost"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bSortNavigationAreasByCost(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"RecastNavMesh",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"RecastNavMesh must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(ARecastNavMesh::StaticClass(), TEXT("bSortNavigationAreasByCost"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bPerformVoxelFiltering(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"RecastNavMesh",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"RecastNavMesh must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(ARecastNavMesh::StaticClass(), TEXT("bPerformVoxelFiltering"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bPerformVoxelFiltering(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"RecastNavMesh",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"RecastNavMesh must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(ARecastNavMesh::StaticClass(), TEXT("bPerformVoxelFiltering"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bMarkLowHeightAreas(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"RecastNavMesh",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"RecastNavMesh must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(ARecastNavMesh::StaticClass(), TEXT("bMarkLowHeightAreas"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bMarkLowHeightAreas(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"RecastNavMesh",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"RecastNavMesh must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(ARecastNavMesh::StaticClass(), TEXT("bMarkLowHeightAreas"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bFilterLowSpanSequences(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"RecastNavMesh",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"RecastNavMesh must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(ARecastNavMesh::StaticClass(), TEXT("bFilterLowSpanSequences"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bFilterLowSpanSequences(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"RecastNavMesh",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"RecastNavMesh must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(ARecastNavMesh::StaticClass(), TEXT("bFilterLowSpanSequences"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bFilterLowSpanFromTileCache(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"RecastNavMesh",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"RecastNavMesh must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(ARecastNavMesh::StaticClass(), TEXT("bFilterLowSpanFromTileCache"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bFilterLowSpanFromTileCache(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"RecastNavMesh",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"RecastNavMesh must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(ARecastNavMesh::StaticClass(), TEXT("bFilterLowSpanFromTileCache"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bDoFullyAsyncNavDataGathering(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"RecastNavMesh",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"RecastNavMesh must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(ARecastNavMesh::StaticClass(), TEXT("bDoFullyAsyncNavDataGathering"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bDoFullyAsyncNavDataGathering(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"RecastNavMesh",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"RecastNavMesh must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(ARecastNavMesh::StaticClass(), TEXT("bDoFullyAsyncNavDataGathering"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_HeuristicScale(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"RecastNavMesh",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"RecastNavMesh must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(ARecastNavMesh::StaticClass(), TEXT("HeuristicScale"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_HeuristicScale(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"RecastNavMesh",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"RecastNavMesh must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(ARecastNavMesh::StaticClass(), TEXT("HeuristicScale"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_VerticalDeviationFromGroundCompensation(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"RecastNavMesh",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"RecastNavMesh must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(ARecastNavMesh::StaticClass(), TEXT("VerticalDeviationFromGroundCompensation"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_VerticalDeviationFromGroundCompensation(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"RecastNavMesh",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"RecastNavMesh must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(ARecastNavMesh::StaticClass(), TEXT("VerticalDeviationFromGroundCompensation"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 New(lua_State* InScriptContext)
{
	UObject* Outer = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Object");
	FName Name = FName(luaL_checkstring(InScriptContext, 2));
	UObject* Obj = NewObject<ARecastNavMesh>(Outer, Name);
	wLua::FLuaUtils::ReturnUObject(InScriptContext,Obj);
	return 1;
}

int32 Destroy(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"RecastNavMesh",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"RecastNavMesh must be non-null"); lua_error(InScriptContext);  return 0;}
		AActor * actor = Cast<AActor>(Obj);
		actor->Destroy();
		userdata->flag |= wLua::LuaObjectFlag::DESTROYED;
		wLua::FLuaUtils::RemoveObjectReference(Obj, userdata->stamp, InScriptContext);
#ifdef AZURE_BUILD_WLUACHECK
		UE_LOG(LogAzure, Warning, TEXT("Destroy RecastNavMesh: %x userdata:%x   stamp:%x"),Obj,userdata,userdata->stamp);
#endif
	return 0;
}

int32 Class(lua_State* InScriptContext)
{
	UClass* Class = ARecastNavMesh::StaticClass();
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Class);
	return 1;
}

const luaL_Reg Lib_Funcs[] =
{
	{ "New", New },
	{ "Destroy", Destroy },
	{ "Class", Class },
	{ "Get_bDrawTriangleEdges", Get_bDrawTriangleEdges },
	{ "Set_bDrawTriangleEdges", Set_bDrawTriangleEdges },
	{ "Get_bDrawPolyEdges", Get_bDrawPolyEdges },
	{ "Set_bDrawPolyEdges", Set_bDrawPolyEdges },
	{ "Get_bDrawFilledPolys", Get_bDrawFilledPolys },
	{ "Set_bDrawFilledPolys", Set_bDrawFilledPolys },
	{ "Get_bDrawNavMeshEdges", Get_bDrawNavMeshEdges },
	{ "Set_bDrawNavMeshEdges", Set_bDrawNavMeshEdges },
	{ "Get_bDrawTileBounds", Get_bDrawTileBounds },
	{ "Set_bDrawTileBounds", Set_bDrawTileBounds },
	{ "Get_bDrawPathCollidingGeometry", Get_bDrawPathCollidingGeometry },
	{ "Set_bDrawPathCollidingGeometry", Set_bDrawPathCollidingGeometry },
	{ "Get_bDrawTileLabels", Get_bDrawTileLabels },
	{ "Set_bDrawTileLabels", Set_bDrawTileLabels },
	{ "Get_bDrawPolygonLabels", Get_bDrawPolygonLabels },
	{ "Set_bDrawPolygonLabels", Set_bDrawPolygonLabels },
	{ "Get_bDrawDefaultPolygonCost", Get_bDrawDefaultPolygonCost },
	{ "Set_bDrawDefaultPolygonCost", Set_bDrawDefaultPolygonCost },
	{ "Get_bDrawLabelsOnPathNodes", Get_bDrawLabelsOnPathNodes },
	{ "Set_bDrawLabelsOnPathNodes", Set_bDrawLabelsOnPathNodes },
	{ "Get_bDrawNavLinks", Get_bDrawNavLinks },
	{ "Set_bDrawNavLinks", Set_bDrawNavLinks },
	{ "Get_bDrawFailedNavLinks", Get_bDrawFailedNavLinks },
	{ "Set_bDrawFailedNavLinks", Set_bDrawFailedNavLinks },
	{ "Get_bDrawClusters", Get_bDrawClusters },
	{ "Set_bDrawClusters", Set_bDrawClusters },
	{ "Get_bDrawOctree", Get_bDrawOctree },
	{ "Set_bDrawOctree", Set_bDrawOctree },
	{ "Get_bDrawOctreeDetails", Get_bDrawOctreeDetails },
	{ "Set_bDrawOctreeDetails", Set_bDrawOctreeDetails },
	{ "Get_bDrawNavMesh", Get_bDrawNavMesh },
	{ "Set_bDrawNavMesh", Set_bDrawNavMesh },
	{ "Get_DrawOffset", Get_DrawOffset },
	{ "Set_DrawOffset", Set_DrawOffset },
	{ "Get_bFixedTilePoolSize", Get_bFixedTilePoolSize },
	{ "Set_bFixedTilePoolSize", Set_bFixedTilePoolSize },
	{ "Get_TilePoolSize", Get_TilePoolSize },
	{ "Set_TilePoolSize", Set_TilePoolSize },
	{ "Get_TileSizeUU", Get_TileSizeUU },
	{ "Set_TileSizeUU", Set_TileSizeUU },
	{ "Get_CellSize", Get_CellSize },
	{ "Set_CellSize", Set_CellSize },
	{ "Get_CellHeight", Get_CellHeight },
	{ "Set_CellHeight", Set_CellHeight },
	{ "Get_AgentRadius", Get_AgentRadius },
	{ "Set_AgentRadius", Set_AgentRadius },
	{ "Get_AgentHeight", Get_AgentHeight },
	{ "Set_AgentHeight", Set_AgentHeight },
	{ "Get_AgentMaxHeight", Get_AgentMaxHeight },
	{ "Set_AgentMaxHeight", Set_AgentMaxHeight },
	{ "Get_AgentMaxSlope", Get_AgentMaxSlope },
	{ "Set_AgentMaxSlope", Set_AgentMaxSlope },
	{ "Get_AgentMaxStepHeight", Get_AgentMaxStepHeight },
	{ "Set_AgentMaxStepHeight", Set_AgentMaxStepHeight },
	{ "Get_MinRegionArea", Get_MinRegionArea },
	{ "Set_MinRegionArea", Set_MinRegionArea },
	{ "Get_MergeRegionSize", Get_MergeRegionSize },
	{ "Set_MergeRegionSize", Set_MergeRegionSize },
	{ "Get_MaxSimplificationError", Get_MaxSimplificationError },
	{ "Set_MaxSimplificationError", Set_MaxSimplificationError },
	{ "Get_MaxSimultaneousTileGenerationJobsCount", Get_MaxSimultaneousTileGenerationJobsCount },
	{ "Set_MaxSimultaneousTileGenerationJobsCount", Set_MaxSimultaneousTileGenerationJobsCount },
	{ "Get_TileNumberHardLimit", Get_TileNumberHardLimit },
	{ "Set_TileNumberHardLimit", Set_TileNumberHardLimit },
	{ "Get_PolyRefTileBits", Get_PolyRefTileBits },
	{ "Set_PolyRefTileBits", Set_PolyRefTileBits },
	{ "Get_PolyRefNavPolyBits", Get_PolyRefNavPolyBits },
	{ "Set_PolyRefNavPolyBits", Set_PolyRefNavPolyBits },
	{ "Get_PolyRefSaltBits", Get_PolyRefSaltBits },
	{ "Set_PolyRefSaltBits", Set_PolyRefSaltBits },
	{ "Get_NavMeshOriginOffset", Get_NavMeshOriginOffset },
	{ "Set_NavMeshOriginOffset", Set_NavMeshOriginOffset },
	{ "Get_RegionPartitioning", Get_RegionPartitioning },
	{ "Set_RegionPartitioning", Set_RegionPartitioning },
	{ "Get_LayerPartitioning", Get_LayerPartitioning },
	{ "Set_LayerPartitioning", Set_LayerPartitioning },
	{ "Get_RegionChunkSplits", Get_RegionChunkSplits },
	{ "Set_RegionChunkSplits", Set_RegionChunkSplits },
	{ "Get_LayerChunkSplits", Get_LayerChunkSplits },
	{ "Set_LayerChunkSplits", Set_LayerChunkSplits },
	{ "Get_bSortNavigationAreasByCost", Get_bSortNavigationAreasByCost },
	{ "Set_bSortNavigationAreasByCost", Set_bSortNavigationAreasByCost },
	{ "Get_bPerformVoxelFiltering", Get_bPerformVoxelFiltering },
	{ "Set_bPerformVoxelFiltering", Set_bPerformVoxelFiltering },
	{ "Get_bMarkLowHeightAreas", Get_bMarkLowHeightAreas },
	{ "Set_bMarkLowHeightAreas", Set_bMarkLowHeightAreas },
	{ "Get_bFilterLowSpanSequences", Get_bFilterLowSpanSequences },
	{ "Set_bFilterLowSpanSequences", Set_bFilterLowSpanSequences },
	{ "Get_bFilterLowSpanFromTileCache", Get_bFilterLowSpanFromTileCache },
	{ "Set_bFilterLowSpanFromTileCache", Set_bFilterLowSpanFromTileCache },
	{ "Get_bDoFullyAsyncNavDataGathering", Get_bDoFullyAsyncNavDataGathering },
	{ "Set_bDoFullyAsyncNavDataGathering", Set_bDoFullyAsyncNavDataGathering },
	{ "Get_HeuristicScale", Get_HeuristicScale },
	{ "Set_HeuristicScale", Set_HeuristicScale },
	{ "Get_VerticalDeviationFromGroundCompensation", Get_VerticalDeviationFromGroundCompensation },
	{ "Set_VerticalDeviationFromGroundCompensation", Set_VerticalDeviationFromGroundCompensation },
	{ "RebuildNavMesh", RebuildNavMesh },
	{ "is_nil", wLua::LuaStatic::isnil },
	{ "__gc", wLua::LuaStatic::removeUClassFrameCache },
	{ NULL, NULL }
};

void Register(lua_State *InScriptContext)
{
	lua_newtable(InScriptContext);
	luaL_register(InScriptContext, NULL, Lib_Funcs);
	AzureHelpFuncs::AuxRegister(InScriptContext, "RecastNavMesh");
}
void SetMtLink(lua_State *InScriptContext)
{
	AzureHelpFuncs::AuxSetMtLink(InScriptContext, "RecastNavMesh", "NavigationData",USERDATATYPE_UOBJECT);
}

}