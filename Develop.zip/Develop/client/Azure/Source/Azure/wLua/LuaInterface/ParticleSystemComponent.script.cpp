#include "Azure.h"
#include "Utility/help_funcs.h"
#include "wLua/UObjectHeaders.h"
#include "Particles/ParticleSystemComponent.h"
#include "AzureLuaIntegration.h"

namespace LuaParticleSystemComponent
{
int32 GetEmitterNames(lua_State*);
int32 ResetParticles(lua_State*);
int32 ActivateSystem(lua_State*);
int32 DeactivateSystem(lua_State*);

int32 SetVectorParameter(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ParticleSystemComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ParticleSystemComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FName ParameterName;
		FVector Param;
	} Params;
	Params.ParameterName = FName(UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 2)));
	Params.Param = (wLua::FLuaVector::Get(InScriptContext, 3));
#if UE_GAME
	UParticleSystemComponent * This = (UParticleSystemComponent *)Obj;
	This->SetVectorParameter(Params.ParameterName,Params.Param);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetVectorParameter"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FName*)(params.GetStructMemory() + 0) = Params.ParameterName;
		*(FVector*)(params.GetStructMemory() + 12) = Params.Param;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ParameterName = *(FName*)(params.GetStructMemory() + 0);
		Params.Param = *(FVector*)(params.GetStructMemory() + 12);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetTrailSourceData(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ParticleSystemComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ParticleSystemComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FName InFirstSocketName;
		FName InSecondSocketName;
		TEnumAsByte<ETrailWidthMode> InWidthMode;
		float InWidth;
	} Params;
	Params.InFirstSocketName = FName(UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 2)));
	Params.InSecondSocketName = FName(UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 3)));
	Params.InWidthMode = (TEnumAsByte<ETrailWidthMode>)(luaL_checkint(InScriptContext, 4));
	Params.InWidth = (float)(luaL_checknumber(InScriptContext, 5));
#if UE_GAME
	UParticleSystemComponent * This = (UParticleSystemComponent *)Obj;
	This->SetTrailSourceData(Params.InFirstSocketName,Params.InSecondSocketName,Params.InWidthMode,Params.InWidth);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetTrailSourceData"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FName*)(params.GetStructMemory() + 0) = Params.InFirstSocketName;
		*(FName*)(params.GetStructMemory() + 12) = Params.InSecondSocketName;
		*(TEnumAsByte<ETrailWidthMode>*)(params.GetStructMemory() + 24) = Params.InWidthMode;
		*(float*)(params.GetStructMemory() + 28) = Params.InWidth;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.InFirstSocketName = *(FName*)(params.GetStructMemory() + 0);
		Params.InSecondSocketName = *(FName*)(params.GetStructMemory() + 12);
		Params.InWidthMode = *(TEnumAsByte<ETrailWidthMode>*)(params.GetStructMemory() + 24);
		Params.InWidth = *(float*)(params.GetStructMemory() + 28);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetTemplate(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ParticleSystemComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ParticleSystemComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		UParticleSystem* NewTemplate = nullptr;
	} Params;
	Params.NewTemplate = (UParticleSystem*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"ParticleSystem");;
#if UE_GAME
	UParticleSystemComponent * This = (UParticleSystemComponent *)Obj;
	This->SetTemplate(Params.NewTemplate);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetTemplate"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(UParticleSystem**)(params.GetStructMemory() + 0) = Params.NewTemplate;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.NewTemplate = *(UParticleSystem**)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetMaterialParameter(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ParticleSystemComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ParticleSystemComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FName ParameterName;
		UMaterialInterface* Param = nullptr;
	} Params;
	Params.ParameterName = FName(UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 2)));
	Params.Param = (UMaterialInterface*)wLua::FLuaUtils::GetUObject(InScriptContext,3,"MaterialInterface");;
#if UE_GAME
	UParticleSystemComponent * This = (UParticleSystemComponent *)Obj;
	This->SetMaterialParameter(Params.ParameterName,Params.Param);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetMaterialParameter"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FName*)(params.GetStructMemory() + 0) = Params.ParameterName;
		*(UMaterialInterface**)(params.GetStructMemory() + 16) = Params.Param;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ParameterName = *(FName*)(params.GetStructMemory() + 0);
		Params.Param = *(UMaterialInterface**)(params.GetStructMemory() + 16);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetFloatParameter(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ParticleSystemComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ParticleSystemComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FName ParameterName;
		float Param;
	} Params;
	Params.ParameterName = FName(UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 2)));
	Params.Param = (float)(luaL_checknumber(InScriptContext, 3));
#if UE_GAME
	UParticleSystemComponent * This = (UParticleSystemComponent *)Obj;
	This->SetFloatParameter(Params.ParameterName,Params.Param);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetFloatParameter"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FName*)(params.GetStructMemory() + 0) = Params.ParameterName;
		*(float*)(params.GetStructMemory() + 12) = Params.Param;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ParameterName = *(FName*)(params.GetStructMemory() + 0);
		Params.Param = *(float*)(params.GetStructMemory() + 12);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetEmitterEnable(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ParticleSystemComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ParticleSystemComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FName EmitterName;
		bool bNewEnableState;
	} Params;
	Params.EmitterName = FName(UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 2)));
	Params.bNewEnableState = !!(lua_toboolean(InScriptContext, 3));
#if UE_GAME
	UParticleSystemComponent * This = (UParticleSystemComponent *)Obj;
	This->SetEmitterEnable(Params.EmitterName,Params.bNewEnableState);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetEmitterEnable"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FName*)(params.GetStructMemory() + 0) = Params.EmitterName;
		*(bool*)(params.GetStructMemory() + 12) = Params.bNewEnableState;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.EmitterName = *(FName*)(params.GetStructMemory() + 0);
		Params.bNewEnableState = *(bool*)(params.GetStructMemory() + 12);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetColorParameter(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ParticleSystemComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ParticleSystemComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FName ParameterName;
		FLinearColor Param;
	} Params;
	Params.ParameterName = FName(UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 2)));
	Params.Param = (wLua::FLuaLinearColor::Get(InScriptContext, 3));
#if UE_GAME
	UParticleSystemComponent * This = (UParticleSystemComponent *)Obj;
	This->SetColorParameter(Params.ParameterName,Params.Param);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetColorParameter"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FName*)(params.GetStructMemory() + 0) = Params.ParameterName;
		*(FLinearColor*)(params.GetStructMemory() + 12) = Params.Param;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ParameterName = *(FName*)(params.GetStructMemory() + 0);
		Params.Param = *(FLinearColor*)(params.GetStructMemory() + 12);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetBeamTargetTangent(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ParticleSystemComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ParticleSystemComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		int32 EmitterIndex;
		FVector NewTangentPoint;
		int32 TargetIndex;
	} Params;
	Params.EmitterIndex = (luaL_checkint(InScriptContext, 2));
	Params.NewTangentPoint = (wLua::FLuaVector::Get(InScriptContext, 3));
	Params.TargetIndex = (luaL_checkint(InScriptContext, 4));
#if UE_GAME
	UParticleSystemComponent * This = (UParticleSystemComponent *)Obj;
	This->SetBeamTargetTangent(Params.EmitterIndex,Params.NewTangentPoint,Params.TargetIndex);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetBeamTargetTangent"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(int32*)(params.GetStructMemory() + 0) = Params.EmitterIndex;
		*(FVector*)(params.GetStructMemory() + 4) = Params.NewTangentPoint;
		*(int32*)(params.GetStructMemory() + 16) = Params.TargetIndex;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.EmitterIndex = *(int32*)(params.GetStructMemory() + 0);
		Params.NewTangentPoint = *(FVector*)(params.GetStructMemory() + 4);
		Params.TargetIndex = *(int32*)(params.GetStructMemory() + 16);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetBeamTargetStrength(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ParticleSystemComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ParticleSystemComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		int32 EmitterIndex;
		float NewTargetStrength;
		int32 TargetIndex;
	} Params;
	Params.EmitterIndex = (luaL_checkint(InScriptContext, 2));
	Params.NewTargetStrength = (float)(luaL_checknumber(InScriptContext, 3));
	Params.TargetIndex = (luaL_checkint(InScriptContext, 4));
#if UE_GAME
	UParticleSystemComponent * This = (UParticleSystemComponent *)Obj;
	This->SetBeamTargetStrength(Params.EmitterIndex,Params.NewTargetStrength,Params.TargetIndex);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetBeamTargetStrength"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(int32*)(params.GetStructMemory() + 0) = Params.EmitterIndex;
		*(float*)(params.GetStructMemory() + 4) = Params.NewTargetStrength;
		*(int32*)(params.GetStructMemory() + 8) = Params.TargetIndex;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.EmitterIndex = *(int32*)(params.GetStructMemory() + 0);
		Params.NewTargetStrength = *(float*)(params.GetStructMemory() + 4);
		Params.TargetIndex = *(int32*)(params.GetStructMemory() + 8);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetBeamTargetPoint(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ParticleSystemComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ParticleSystemComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		int32 EmitterIndex;
		FVector NewTargetPoint;
		int32 TargetIndex;
	} Params;
	Params.EmitterIndex = (luaL_checkint(InScriptContext, 2));
	Params.NewTargetPoint = (wLua::FLuaVector::Get(InScriptContext, 3));
	Params.TargetIndex = (luaL_checkint(InScriptContext, 4));
#if UE_GAME
	UParticleSystemComponent * This = (UParticleSystemComponent *)Obj;
	This->SetBeamTargetPoint(Params.EmitterIndex,Params.NewTargetPoint,Params.TargetIndex);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetBeamTargetPoint"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(int32*)(params.GetStructMemory() + 0) = Params.EmitterIndex;
		*(FVector*)(params.GetStructMemory() + 4) = Params.NewTargetPoint;
		*(int32*)(params.GetStructMemory() + 16) = Params.TargetIndex;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.EmitterIndex = *(int32*)(params.GetStructMemory() + 0);
		Params.NewTargetPoint = *(FVector*)(params.GetStructMemory() + 4);
		Params.TargetIndex = *(int32*)(params.GetStructMemory() + 16);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetBeamSourceTangent(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ParticleSystemComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ParticleSystemComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		int32 EmitterIndex;
		FVector NewTangentPoint;
		int32 SourceIndex;
	} Params;
	Params.EmitterIndex = (luaL_checkint(InScriptContext, 2));
	Params.NewTangentPoint = (wLua::FLuaVector::Get(InScriptContext, 3));
	Params.SourceIndex = (luaL_checkint(InScriptContext, 4));
#if UE_GAME
	UParticleSystemComponent * This = (UParticleSystemComponent *)Obj;
	This->SetBeamSourceTangent(Params.EmitterIndex,Params.NewTangentPoint,Params.SourceIndex);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetBeamSourceTangent"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(int32*)(params.GetStructMemory() + 0) = Params.EmitterIndex;
		*(FVector*)(params.GetStructMemory() + 4) = Params.NewTangentPoint;
		*(int32*)(params.GetStructMemory() + 16) = Params.SourceIndex;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.EmitterIndex = *(int32*)(params.GetStructMemory() + 0);
		Params.NewTangentPoint = *(FVector*)(params.GetStructMemory() + 4);
		Params.SourceIndex = *(int32*)(params.GetStructMemory() + 16);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetBeamSourceStrength(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ParticleSystemComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ParticleSystemComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		int32 EmitterIndex;
		float NewSourceStrength;
		int32 SourceIndex;
	} Params;
	Params.EmitterIndex = (luaL_checkint(InScriptContext, 2));
	Params.NewSourceStrength = (float)(luaL_checknumber(InScriptContext, 3));
	Params.SourceIndex = (luaL_checkint(InScriptContext, 4));
#if UE_GAME
	UParticleSystemComponent * This = (UParticleSystemComponent *)Obj;
	This->SetBeamSourceStrength(Params.EmitterIndex,Params.NewSourceStrength,Params.SourceIndex);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetBeamSourceStrength"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(int32*)(params.GetStructMemory() + 0) = Params.EmitterIndex;
		*(float*)(params.GetStructMemory() + 4) = Params.NewSourceStrength;
		*(int32*)(params.GetStructMemory() + 8) = Params.SourceIndex;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.EmitterIndex = *(int32*)(params.GetStructMemory() + 0);
		Params.NewSourceStrength = *(float*)(params.GetStructMemory() + 4);
		Params.SourceIndex = *(int32*)(params.GetStructMemory() + 8);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetBeamSourcePoint(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ParticleSystemComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ParticleSystemComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		int32 EmitterIndex;
		FVector NewSourcePoint;
		int32 SourceIndex;
	} Params;
	Params.EmitterIndex = (luaL_checkint(InScriptContext, 2));
	Params.NewSourcePoint = (wLua::FLuaVector::Get(InScriptContext, 3));
	Params.SourceIndex = (luaL_checkint(InScriptContext, 4));
#if UE_GAME
	UParticleSystemComponent * This = (UParticleSystemComponent *)Obj;
	This->SetBeamSourcePoint(Params.EmitterIndex,Params.NewSourcePoint,Params.SourceIndex);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetBeamSourcePoint"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(int32*)(params.GetStructMemory() + 0) = Params.EmitterIndex;
		*(FVector*)(params.GetStructMemory() + 4) = Params.NewSourcePoint;
		*(int32*)(params.GetStructMemory() + 16) = Params.SourceIndex;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.EmitterIndex = *(int32*)(params.GetStructMemory() + 0);
		Params.NewSourcePoint = *(FVector*)(params.GetStructMemory() + 4);
		Params.SourceIndex = *(int32*)(params.GetStructMemory() + 16);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetBeamMethod_Target(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ParticleSystemComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ParticleSystemComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		int32 EmitterIndex;
		TEnumAsByte<Beam2SourceTargetMethod> method;
	} Params;
	Params.EmitterIndex = (luaL_checkint(InScriptContext, 2));
	Params.method = (TEnumAsByte<Beam2SourceTargetMethod>)(luaL_checkint(InScriptContext, 3));
#if UE_GAME
	UParticleSystemComponent * This = (UParticleSystemComponent *)Obj;
	This->SetBeamMethod_Target(Params.EmitterIndex,Params.method);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetBeamMethod_Target"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(int32*)(params.GetStructMemory() + 0) = Params.EmitterIndex;
		*(TEnumAsByte<Beam2SourceTargetMethod>*)(params.GetStructMemory() + 4) = Params.method;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.EmitterIndex = *(int32*)(params.GetStructMemory() + 0);
		Params.method = *(TEnumAsByte<Beam2SourceTargetMethod>*)(params.GetStructMemory() + 4);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetBeamMethod_Source(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ParticleSystemComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ParticleSystemComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		int32 EmitterIndex;
		TEnumAsByte<Beam2SourceTargetMethod> method;
	} Params;
	Params.EmitterIndex = (luaL_checkint(InScriptContext, 2));
	Params.method = (TEnumAsByte<Beam2SourceTargetMethod>)(luaL_checkint(InScriptContext, 3));
#if UE_GAME
	UParticleSystemComponent * This = (UParticleSystemComponent *)Obj;
	This->SetBeamMethod_Source(Params.EmitterIndex,Params.method);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetBeamMethod_Source"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(int32*)(params.GetStructMemory() + 0) = Params.EmitterIndex;
		*(TEnumAsByte<Beam2SourceTargetMethod>*)(params.GetStructMemory() + 4) = Params.method;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.EmitterIndex = *(int32*)(params.GetStructMemory() + 0);
		Params.method = *(TEnumAsByte<Beam2SourceTargetMethod>*)(params.GetStructMemory() + 4);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetBeamEndPoint(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ParticleSystemComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ParticleSystemComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		int32 EmitterIndex;
		FVector NewEndPoint;
	} Params;
	Params.EmitterIndex = (luaL_checkint(InScriptContext, 2));
	Params.NewEndPoint = (wLua::FLuaVector::Get(InScriptContext, 3));
#if UE_GAME
	UParticleSystemComponent * This = (UParticleSystemComponent *)Obj;
	This->SetBeamEndPoint(Params.EmitterIndex,Params.NewEndPoint);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetBeamEndPoint"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(int32*)(params.GetStructMemory() + 0) = Params.EmitterIndex;
		*(FVector*)(params.GetStructMemory() + 4) = Params.NewEndPoint;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.EmitterIndex = *(int32*)(params.GetStructMemory() + 0);
		Params.NewEndPoint = *(FVector*)(params.GetStructMemory() + 4);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetAutoAttachmentParameters(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ParticleSystemComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ParticleSystemComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		USceneComponent* Parent = nullptr;
		FName SocketName;
		EAttachmentRule LocationRule;
		EAttachmentRule RotationRule;
		EAttachmentRule ScaleRule;
	} Params;
	Params.Parent = (USceneComponent*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"SceneComponent");;
	Params.SocketName = FName(UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 3)));
	Params.LocationRule = (EAttachmentRule)(luaL_checkint(InScriptContext, 4));
	Params.RotationRule = (EAttachmentRule)(luaL_checkint(InScriptContext, 5));
	Params.ScaleRule = (EAttachmentRule)(luaL_checkint(InScriptContext, 6));
#if UE_GAME
	UParticleSystemComponent * This = (UParticleSystemComponent *)Obj;
	This->SetAutoAttachmentParameters(Params.Parent,Params.SocketName,Params.LocationRule,Params.RotationRule,Params.ScaleRule);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetAutoAttachmentParameters"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(USceneComponent**)(params.GetStructMemory() + 0) = Params.Parent;
		*(FName*)(params.GetStructMemory() + 8) = Params.SocketName;
		*(EAttachmentRule*)(params.GetStructMemory() + 20) = Params.LocationRule;
		*(EAttachmentRule*)(params.GetStructMemory() + 21) = Params.RotationRule;
		*(EAttachmentRule*)(params.GetStructMemory() + 22) = Params.ScaleRule;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.Parent = *(USceneComponent**)(params.GetStructMemory() + 0);
		Params.SocketName = *(FName*)(params.GetStructMemory() + 8);
		Params.LocationRule = *(EAttachmentRule*)(params.GetStructMemory() + 20);
		Params.RotationRule = *(EAttachmentRule*)(params.GetStructMemory() + 21);
		Params.ScaleRule = *(EAttachmentRule*)(params.GetStructMemory() + 22);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetActorParameter(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ParticleSystemComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ParticleSystemComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FName ParameterName;
		AActor* Param = nullptr;
	} Params;
	Params.ParameterName = FName(UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 2)));
	Params.Param = (AActor*)wLua::FLuaUtils::GetUObject(InScriptContext,3,"Actor");;
#if UE_GAME
	UParticleSystemComponent * This = (UParticleSystemComponent *)Obj;
	This->SetActorParameter(Params.ParameterName,Params.Param);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetActorParameter"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FName*)(params.GetStructMemory() + 0) = Params.ParameterName;
		*(AActor**)(params.GetStructMemory() + 16) = Params.Param;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ParameterName = *(FName*)(params.GetStructMemory() + 0);
		Params.Param = *(AActor**)(params.GetStructMemory() + 16);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 ReleaseToPool(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ParticleSystemComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ParticleSystemComponent must be non-null"); lua_error(InScriptContext);  return 0;}
#if UE_GAME
	UParticleSystemComponent * This = (UParticleSystemComponent *)Obj;
	This->ReleaseToPool();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("ReleaseToPool"));
	if(!Function) { check(false); return 0;}
	Obj->ProcessEvent(Function, NULL);
#endif
	return 0;
}

int32 GetNumActiveParticles(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ParticleSystemComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ParticleSystemComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		int32 ReturnValue;
	} Params;
#if UE_GAME
	UParticleSystemComponent * This = (UParticleSystemComponent *)Obj;
	Params.ReturnValue = This->GetNumActiveParticles();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetNumActiveParticles"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(int32*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushinteger(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetNamedMaterial(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ParticleSystemComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ParticleSystemComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FName InName;
		UMaterialInterface* ReturnValue = nullptr;
	} Params;
	Params.InName = FName(UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 2)));
#if UE_GAME
	UParticleSystemComponent * This = (UParticleSystemComponent *)Obj;
	Params.ReturnValue = This->GetNamedMaterial(Params.InName);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetNamedMaterial"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FName*)(params.GetStructMemory() + 0) = Params.InName;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.InName = *(FName*)(params.GetStructMemory() + 0);
		Params.ReturnValue = *(UMaterialInterface**)(params.GetStructMemory() + 16);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetBeamTargetTangent(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ParticleSystemComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ParticleSystemComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		int32 EmitterIndex;
		int32 TargetIndex;
		FVector OutTangentPoint;
		bool ReturnValue;
	} Params;
	Params.EmitterIndex = (luaL_checkint(InScriptContext, 2));
	Params.TargetIndex = (luaL_checkint(InScriptContext, 3));
#if UE_GAME
	UParticleSystemComponent * This = (UParticleSystemComponent *)Obj;
	Params.ReturnValue = This->GetBeamTargetTangent(Params.EmitterIndex,Params.TargetIndex,Params.OutTangentPoint);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetBeamTargetTangent"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(int32*)(params.GetStructMemory() + 0) = Params.EmitterIndex;
		*(int32*)(params.GetStructMemory() + 4) = Params.TargetIndex;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.EmitterIndex = *(int32*)(params.GetStructMemory() + 0);
		Params.TargetIndex = *(int32*)(params.GetStructMemory() + 4);
		Params.OutTangentPoint = *(FVector*)(params.GetStructMemory() + 8);
		Params.ReturnValue = *(bool*)(params.GetStructMemory() + 20);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushboolean(InScriptContext, Params.ReturnValue);
	wLua::FLuaVector::Return(InScriptContext, Params.OutTangentPoint);
	return 2;
}

int32 GetBeamTargetStrength(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ParticleSystemComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ParticleSystemComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		int32 EmitterIndex;
		int32 TargetIndex;
		float OutTargetStrength;
		bool ReturnValue;
	} Params;
	Params.EmitterIndex = (luaL_checkint(InScriptContext, 2));
	Params.TargetIndex = (luaL_checkint(InScriptContext, 3));
#if UE_GAME
	UParticleSystemComponent * This = (UParticleSystemComponent *)Obj;
	Params.ReturnValue = This->GetBeamTargetStrength(Params.EmitterIndex,Params.TargetIndex,Params.OutTargetStrength);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetBeamTargetStrength"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(int32*)(params.GetStructMemory() + 0) = Params.EmitterIndex;
		*(int32*)(params.GetStructMemory() + 4) = Params.TargetIndex;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.EmitterIndex = *(int32*)(params.GetStructMemory() + 0);
		Params.TargetIndex = *(int32*)(params.GetStructMemory() + 4);
		Params.OutTargetStrength = *(float*)(params.GetStructMemory() + 8);
		Params.ReturnValue = *(bool*)(params.GetStructMemory() + 12);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushboolean(InScriptContext, Params.ReturnValue);
	lua_pushnumber(InScriptContext, Params.OutTargetStrength);
	return 2;
}

int32 GetBeamTargetPoint(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ParticleSystemComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ParticleSystemComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		int32 EmitterIndex;
		int32 TargetIndex;
		FVector OutTargetPoint;
		bool ReturnValue;
	} Params;
	Params.EmitterIndex = (luaL_checkint(InScriptContext, 2));
	Params.TargetIndex = (luaL_checkint(InScriptContext, 3));
#if UE_GAME
	UParticleSystemComponent * This = (UParticleSystemComponent *)Obj;
	Params.ReturnValue = This->GetBeamTargetPoint(Params.EmitterIndex,Params.TargetIndex,Params.OutTargetPoint);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetBeamTargetPoint"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(int32*)(params.GetStructMemory() + 0) = Params.EmitterIndex;
		*(int32*)(params.GetStructMemory() + 4) = Params.TargetIndex;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.EmitterIndex = *(int32*)(params.GetStructMemory() + 0);
		Params.TargetIndex = *(int32*)(params.GetStructMemory() + 4);
		Params.OutTargetPoint = *(FVector*)(params.GetStructMemory() + 8);
		Params.ReturnValue = *(bool*)(params.GetStructMemory() + 20);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushboolean(InScriptContext, Params.ReturnValue);
	wLua::FLuaVector::Return(InScriptContext, Params.OutTargetPoint);
	return 2;
}

int32 GetBeamSourceTangent(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ParticleSystemComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ParticleSystemComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		int32 EmitterIndex;
		int32 SourceIndex;
		FVector OutTangentPoint;
		bool ReturnValue;
	} Params;
	Params.EmitterIndex = (luaL_checkint(InScriptContext, 2));
	Params.SourceIndex = (luaL_checkint(InScriptContext, 3));
#if UE_GAME
	UParticleSystemComponent * This = (UParticleSystemComponent *)Obj;
	Params.ReturnValue = This->GetBeamSourceTangent(Params.EmitterIndex,Params.SourceIndex,Params.OutTangentPoint);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetBeamSourceTangent"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(int32*)(params.GetStructMemory() + 0) = Params.EmitterIndex;
		*(int32*)(params.GetStructMemory() + 4) = Params.SourceIndex;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.EmitterIndex = *(int32*)(params.GetStructMemory() + 0);
		Params.SourceIndex = *(int32*)(params.GetStructMemory() + 4);
		Params.OutTangentPoint = *(FVector*)(params.GetStructMemory() + 8);
		Params.ReturnValue = *(bool*)(params.GetStructMemory() + 20);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushboolean(InScriptContext, Params.ReturnValue);
	wLua::FLuaVector::Return(InScriptContext, Params.OutTangentPoint);
	return 2;
}

int32 GetBeamSourceStrength(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ParticleSystemComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ParticleSystemComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		int32 EmitterIndex;
		int32 SourceIndex;
		float OutSourceStrength;
		bool ReturnValue;
	} Params;
	Params.EmitterIndex = (luaL_checkint(InScriptContext, 2));
	Params.SourceIndex = (luaL_checkint(InScriptContext, 3));
#if UE_GAME
	UParticleSystemComponent * This = (UParticleSystemComponent *)Obj;
	Params.ReturnValue = This->GetBeamSourceStrength(Params.EmitterIndex,Params.SourceIndex,Params.OutSourceStrength);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetBeamSourceStrength"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(int32*)(params.GetStructMemory() + 0) = Params.EmitterIndex;
		*(int32*)(params.GetStructMemory() + 4) = Params.SourceIndex;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.EmitterIndex = *(int32*)(params.GetStructMemory() + 0);
		Params.SourceIndex = *(int32*)(params.GetStructMemory() + 4);
		Params.OutSourceStrength = *(float*)(params.GetStructMemory() + 8);
		Params.ReturnValue = *(bool*)(params.GetStructMemory() + 12);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushboolean(InScriptContext, Params.ReturnValue);
	lua_pushnumber(InScriptContext, Params.OutSourceStrength);
	return 2;
}

int32 GetBeamSourcePoint(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ParticleSystemComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ParticleSystemComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		int32 EmitterIndex;
		int32 SourceIndex;
		FVector OutSourcePoint;
		bool ReturnValue;
	} Params;
	Params.EmitterIndex = (luaL_checkint(InScriptContext, 2));
	Params.SourceIndex = (luaL_checkint(InScriptContext, 3));
#if UE_GAME
	UParticleSystemComponent * This = (UParticleSystemComponent *)Obj;
	Params.ReturnValue = This->GetBeamSourcePoint(Params.EmitterIndex,Params.SourceIndex,Params.OutSourcePoint);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetBeamSourcePoint"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(int32*)(params.GetStructMemory() + 0) = Params.EmitterIndex;
		*(int32*)(params.GetStructMemory() + 4) = Params.SourceIndex;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.EmitterIndex = *(int32*)(params.GetStructMemory() + 0);
		Params.SourceIndex = *(int32*)(params.GetStructMemory() + 4);
		Params.OutSourcePoint = *(FVector*)(params.GetStructMemory() + 8);
		Params.ReturnValue = *(bool*)(params.GetStructMemory() + 20);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushboolean(InScriptContext, Params.ReturnValue);
	wLua::FLuaVector::Return(InScriptContext, Params.OutSourcePoint);
	return 2;
}

int32 GetBeamMethod_Target(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ParticleSystemComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ParticleSystemComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		int32 EmitterIndex;
		TEnumAsByte<Beam2SourceTargetMethod> ReturnValue;
	} Params;
	Params.EmitterIndex = (luaL_checkint(InScriptContext, 2));
#if UE_GAME
	UParticleSystemComponent * This = (UParticleSystemComponent *)Obj;
	Params.ReturnValue = This->GetBeamMethod_Target(Params.EmitterIndex);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetBeamMethod_Target"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(int32*)(params.GetStructMemory() + 0) = Params.EmitterIndex;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.EmitterIndex = *(int32*)(params.GetStructMemory() + 0);
		Params.ReturnValue = *(TEnumAsByte<Beam2SourceTargetMethod>*)(params.GetStructMemory() + 4);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushinteger(InScriptContext, (int)Params.ReturnValue);
	return 1;
}

int32 GetBeamMethod_Source(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ParticleSystemComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ParticleSystemComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		int32 EmitterIndex;
		TEnumAsByte<Beam2SourceTargetMethod> ReturnValue;
	} Params;
	Params.EmitterIndex = (luaL_checkint(InScriptContext, 2));
#if UE_GAME
	UParticleSystemComponent * This = (UParticleSystemComponent *)Obj;
	Params.ReturnValue = This->GetBeamMethod_Source(Params.EmitterIndex);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetBeamMethod_Source"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(int32*)(params.GetStructMemory() + 0) = Params.EmitterIndex;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.EmitterIndex = *(int32*)(params.GetStructMemory() + 0);
		Params.ReturnValue = *(TEnumAsByte<Beam2SourceTargetMethod>*)(params.GetStructMemory() + 4);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushinteger(InScriptContext, (int)Params.ReturnValue);
	return 1;
}

int32 GetBeamEndPoint(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ParticleSystemComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ParticleSystemComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		int32 EmitterIndex;
		FVector OutEndPoint;
		bool ReturnValue;
	} Params;
	Params.EmitterIndex = (luaL_checkint(InScriptContext, 2));
#if UE_GAME
	UParticleSystemComponent * This = (UParticleSystemComponent *)Obj;
	Params.ReturnValue = This->GetBeamEndPoint(Params.EmitterIndex,Params.OutEndPoint);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetBeamEndPoint"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(int32*)(params.GetStructMemory() + 0) = Params.EmitterIndex;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.EmitterIndex = *(int32*)(params.GetStructMemory() + 0);
		Params.OutEndPoint = *(FVector*)(params.GetStructMemory() + 4);
		Params.ReturnValue = *(bool*)(params.GetStructMemory() + 16);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushboolean(InScriptContext, Params.ReturnValue);
	wLua::FLuaVector::Return(InScriptContext, Params.OutEndPoint);
	return 2;
}

int32 GenerateParticleEvent(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ParticleSystemComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ParticleSystemComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FName InEventName;
		float InEmitterTime;
		FVector InLocation;
		FVector InDirection;
		FVector InVelocity;
	} Params;
	Params.InEventName = FName(UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 2)));
	Params.InEmitterTime = (float)(luaL_checknumber(InScriptContext, 3));
	Params.InLocation = (wLua::FLuaVector::Get(InScriptContext, 4));
	Params.InDirection = (wLua::FLuaVector::Get(InScriptContext, 5));
	Params.InVelocity = (wLua::FLuaVector::Get(InScriptContext, 6));
#if UE_GAME
	UParticleSystemComponent * This = (UParticleSystemComponent *)Obj;
	This->GenerateParticleEvent(Params.InEventName,Params.InEmitterTime,Params.InLocation,Params.InDirection,Params.InVelocity);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GenerateParticleEvent"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FName*)(params.GetStructMemory() + 0) = Params.InEventName;
		*(float*)(params.GetStructMemory() + 12) = Params.InEmitterTime;
		*(FVector*)(params.GetStructMemory() + 16) = Params.InLocation;
		*(FVector*)(params.GetStructMemory() + 28) = Params.InDirection;
		*(FVector*)(params.GetStructMemory() + 40) = Params.InVelocity;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.InEventName = *(FName*)(params.GetStructMemory() + 0);
		Params.InEmitterTime = *(float*)(params.GetStructMemory() + 12);
		Params.InLocation = *(FVector*)(params.GetStructMemory() + 16);
		Params.InDirection = *(FVector*)(params.GetStructMemory() + 28);
		Params.InVelocity = *(FVector*)(params.GetStructMemory() + 40);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 EndTrails(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ParticleSystemComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ParticleSystemComponent must be non-null"); lua_error(InScriptContext);  return 0;}
#if UE_GAME
	UParticleSystemComponent * This = (UParticleSystemComponent *)Obj;
	This->EndTrails();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("EndTrails"));
	if(!Function) { check(false); return 0;}
	Obj->ProcessEvent(Function, NULL);
#endif
	return 0;
}

int32 CreateNamedDynamicMaterialInstance(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ParticleSystemComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ParticleSystemComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FName InName;
		UMaterialInterface* SourceMaterial = nullptr;
		UMaterialInstanceDynamic* ReturnValue = nullptr;
	} Params;
	Params.InName = FName(UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 2)));
	Params.SourceMaterial = lua_isnoneornil(InScriptContext,3) ? nullptr : (UMaterialInterface*)wLua::FLuaUtils::GetUObject(InScriptContext,3,"MaterialInterface");;
#if UE_GAME
	UParticleSystemComponent * This = (UParticleSystemComponent *)Obj;
	Params.ReturnValue = This->CreateNamedDynamicMaterialInstance(Params.InName,Params.SourceMaterial);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("CreateNamedDynamicMaterialInstance"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FName*)(params.GetStructMemory() + 0) = Params.InName;
		*(UMaterialInterface**)(params.GetStructMemory() + 16) = Params.SourceMaterial;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.InName = *(FName*)(params.GetStructMemory() + 0);
		Params.SourceMaterial = *(UMaterialInterface**)(params.GetStructMemory() + 16);
		Params.ReturnValue = *(UMaterialInstanceDynamic**)(params.GetStructMemory() + 24);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 BeginTrails(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ParticleSystemComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ParticleSystemComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FName InFirstSocketName;
		FName InSecondSocketName;
		TEnumAsByte<ETrailWidthMode> InWidthMode;
		float InWidth;
	} Params;
	Params.InFirstSocketName = FName(UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 2)));
	Params.InSecondSocketName = FName(UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 3)));
	Params.InWidthMode = (TEnumAsByte<ETrailWidthMode>)(luaL_checkint(InScriptContext, 4));
	Params.InWidth = (float)(luaL_checknumber(InScriptContext, 5));
#if UE_GAME
	UParticleSystemComponent * This = (UParticleSystemComponent *)Obj;
	This->BeginTrails(Params.InFirstSocketName,Params.InSecondSocketName,Params.InWidthMode,Params.InWidth);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("BeginTrails"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FName*)(params.GetStructMemory() + 0) = Params.InFirstSocketName;
		*(FName*)(params.GetStructMemory() + 12) = Params.InSecondSocketName;
		*(TEnumAsByte<ETrailWidthMode>*)(params.GetStructMemory() + 24) = Params.InWidthMode;
		*(float*)(params.GetStructMemory() + 28) = Params.InWidth;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.InFirstSocketName = *(FName*)(params.GetStructMemory() + 0);
		Params.InSecondSocketName = *(FName*)(params.GetStructMemory() + 12);
		Params.InWidthMode = *(TEnumAsByte<ETrailWidthMode>*)(params.GetStructMemory() + 24);
		Params.InWidth = *(float*)(params.GetStructMemory() + 28);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 AzureSetLODLevelBP(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ParticleSystemComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ParticleSystemComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		int32 InLODLevel;
	} Params;
	Params.InLODLevel = (luaL_checkint(InScriptContext, 2));
#if UE_GAME
	UParticleSystemComponent * This = (UParticleSystemComponent *)Obj;
	This->AzureSetLODLevelBP(Params.InLODLevel);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("AzureSetLODLevelBP"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(int32*)(params.GetStructMemory() + 0) = Params.InLODLevel;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.InLODLevel = *(int32*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 AzureGetLODCountsBP(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ParticleSystemComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ParticleSystemComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		int32 ReturnValue;
	} Params;
#if UE_GAME
	UParticleSystemComponent * This = (UParticleSystemComponent *)Obj;
	Params.ReturnValue = This->AzureGetLODCountsBP();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("AzureGetLODCountsBP"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(int32*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushinteger(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 Get_Template(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ParticleSystemComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ParticleSystemComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UParticleSystemComponent::StaticClass(), TEXT("Template"));
	if(!Property) { check(false); return 0;}
	UParticleSystem* PropertyValue;
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaUtils::ReturnUObject(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_bResetOnDetach(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ParticleSystemComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ParticleSystemComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UParticleSystemComponent::StaticClass(), TEXT("bResetOnDetach"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bResetOnDetach(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ParticleSystemComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ParticleSystemComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UParticleSystemComponent::StaticClass(), TEXT("bResetOnDetach"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bAllowRecycling(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ParticleSystemComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ParticleSystemComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UParticleSystemComponent::StaticClass(), TEXT("bAllowRecycling"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bAllowRecycling(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ParticleSystemComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ParticleSystemComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UParticleSystemComponent::StaticClass(), TEXT("bAllowRecycling"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bAutoManageAttachment(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ParticleSystemComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ParticleSystemComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UParticleSystemComponent::StaticClass(), TEXT("bAutoManageAttachment"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_bOverrideLODMethod(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ParticleSystemComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ParticleSystemComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UParticleSystemComponent::StaticClass(), TEXT("bOverrideLODMethod"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bOverrideLODMethod(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ParticleSystemComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ParticleSystemComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UParticleSystemComponent::StaticClass(), TEXT("bOverrideLODMethod"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_LODMethod(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ParticleSystemComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ParticleSystemComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UParticleSystemComponent::StaticClass(), TEXT("LODMethod"));
	if(!Property) { check(false); return 0;}
	TEnumAsByte<ParticleSystemLODMethod> PropertyValue = TEnumAsByte<ParticleSystemLODMethod>();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushinteger(InScriptContext, (int)PropertyValue);
	return 1;
}

int32 Set_LODMethod(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ParticleSystemComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ParticleSystemComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UParticleSystemComponent::StaticClass(), TEXT("LODMethod"));
	if(!Property) { check(false); return 0;}
	TEnumAsByte<ParticleSystemLODMethod> PropertyValue = (TEnumAsByte<ParticleSystemLODMethod>)(luaL_checkint(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Call_OnParticleSpawn(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ParticleSystemComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ParticleSystemComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FName EventName;
		float EmitterTime;
		FVector Location;
		FVector Velocity;
	} Params;
	Params.EventName = FName(UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 2)));
	Params.EmitterTime = (float)(luaL_checknumber(InScriptContext, 3));
	Params.Location = (wLua::FLuaVector::Get(InScriptContext, 4));
	Params.Velocity = (wLua::FLuaVector::Get(InScriptContext, 5));
	UParticleSystemComponent * This = (UParticleSystemComponent *)Obj;
	This->OnParticleSpawn.Broadcast(Params.EventName,Params.EmitterTime,Params.Location,Params.Velocity);
	return 0;
}

int32 Call_OnParticleBurst(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ParticleSystemComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ParticleSystemComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FName EventName;
		float EmitterTime;
		int32 ParticleCount;
	} Params;
	Params.EventName = FName(UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 2)));
	Params.EmitterTime = (float)(luaL_checknumber(InScriptContext, 3));
	Params.ParticleCount = (luaL_checkint(InScriptContext, 4));
	UParticleSystemComponent * This = (UParticleSystemComponent *)Obj;
	This->OnParticleBurst.Broadcast(Params.EventName,Params.EmitterTime,Params.ParticleCount);
	return 0;
}

int32 Call_OnParticleDeath(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ParticleSystemComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ParticleSystemComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FName EventName;
		float EmitterTime;
		int32 ParticleTime;
		FVector Location;
		FVector Velocity;
		FVector Direction;
	} Params;
	Params.EventName = FName(UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 2)));
	Params.EmitterTime = (float)(luaL_checknumber(InScriptContext, 3));
	Params.ParticleTime = (luaL_checkint(InScriptContext, 4));
	Params.Location = (wLua::FLuaVector::Get(InScriptContext, 5));
	Params.Velocity = (wLua::FLuaVector::Get(InScriptContext, 6));
	Params.Direction = (wLua::FLuaVector::Get(InScriptContext, 7));
	UParticleSystemComponent * This = (UParticleSystemComponent *)Obj;
	This->OnParticleDeath.Broadcast(Params.EventName,Params.EmitterTime,Params.ParticleTime,Params.Location,Params.Velocity,Params.Direction);
	return 0;
}

int32 Call_OnParticleCollide(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ParticleSystemComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ParticleSystemComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FName EventName;
		float EmitterTime;
		int32 ParticleTime;
		FVector Location;
		FVector Velocity;
		FVector Direction;
		FVector Normal;
		FName BoneName;
		UPhysicalMaterial* PhysMat = nullptr;
	} Params;
	Params.EventName = FName(UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 2)));
	Params.EmitterTime = (float)(luaL_checknumber(InScriptContext, 3));
	Params.ParticleTime = (luaL_checkint(InScriptContext, 4));
	Params.Location = (wLua::FLuaVector::Get(InScriptContext, 5));
	Params.Velocity = (wLua::FLuaVector::Get(InScriptContext, 6));
	Params.Direction = (wLua::FLuaVector::Get(InScriptContext, 7));
	Params.Normal = (wLua::FLuaVector::Get(InScriptContext, 8));
	Params.BoneName = FName(UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 9)));
	Params.PhysMat = (UPhysicalMaterial*)wLua::FLuaUtils::GetUObject(InScriptContext,10,"PhysicalMaterial");;
	UParticleSystemComponent * This = (UParticleSystemComponent *)Obj;
	This->OnParticleCollide.Broadcast(Params.EventName,Params.EmitterTime,Params.ParticleTime,Params.Location,Params.Velocity,Params.Direction,Params.Normal,Params.BoneName,Params.PhysMat);
	return 0;
}

int32 Get_SecondsBeforeInactive(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ParticleSystemComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ParticleSystemComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UParticleSystemComponent::StaticClass(), TEXT("SecondsBeforeInactive"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_SecondsBeforeInactive(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ParticleSystemComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ParticleSystemComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UParticleSystemComponent::StaticClass(), TEXT("SecondsBeforeInactive"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_CustomTimeDilation(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ParticleSystemComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ParticleSystemComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UParticleSystemComponent::StaticClass(), TEXT("CustomTimeDilation"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_CustomTimeDilation(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ParticleSystemComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ParticleSystemComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UParticleSystemComponent::StaticClass(), TEXT("CustomTimeDilation"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_AutoAttachSocketName(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ParticleSystemComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ParticleSystemComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UParticleSystemComponent::StaticClass(), TEXT("AutoAttachSocketName"));
	if(!Property) { check(false); return 0;}
	FName PropertyValue = FName();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushstring(InScriptContext, TCHAR_TO_UTF8(*PropertyValue.ToString()));
	return 1;
}

int32 Set_AutoAttachSocketName(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ParticleSystemComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ParticleSystemComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UParticleSystemComponent::StaticClass(), TEXT("AutoAttachSocketName"));
	if(!Property) { check(false); return 0;}
	FName PropertyValue = FName(UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 2)));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_AutoAttachLocationRule(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ParticleSystemComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ParticleSystemComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UParticleSystemComponent::StaticClass(), TEXT("AutoAttachLocationRule"));
	if(!Property) { check(false); return 0;}
	EAttachmentRule PropertyValue = EAttachmentRule();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushinteger(InScriptContext, (int)PropertyValue);
	return 1;
}

int32 Set_AutoAttachLocationRule(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ParticleSystemComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ParticleSystemComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UParticleSystemComponent::StaticClass(), TEXT("AutoAttachLocationRule"));
	if(!Property) { check(false); return 0;}
	EAttachmentRule PropertyValue = (EAttachmentRule)(luaL_checkint(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_AutoAttachRotationRule(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ParticleSystemComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ParticleSystemComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UParticleSystemComponent::StaticClass(), TEXT("AutoAttachRotationRule"));
	if(!Property) { check(false); return 0;}
	EAttachmentRule PropertyValue = EAttachmentRule();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushinteger(InScriptContext, (int)PropertyValue);
	return 1;
}

int32 Set_AutoAttachRotationRule(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ParticleSystemComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ParticleSystemComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UParticleSystemComponent::StaticClass(), TEXT("AutoAttachRotationRule"));
	if(!Property) { check(false); return 0;}
	EAttachmentRule PropertyValue = (EAttachmentRule)(luaL_checkint(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_AutoAttachScaleRule(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ParticleSystemComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ParticleSystemComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UParticleSystemComponent::StaticClass(), TEXT("AutoAttachScaleRule"));
	if(!Property) { check(false); return 0;}
	EAttachmentRule PropertyValue = EAttachmentRule();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushinteger(InScriptContext, (int)PropertyValue);
	return 1;
}

int32 Set_AutoAttachScaleRule(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ParticleSystemComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ParticleSystemComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UParticleSystemComponent::StaticClass(), TEXT("AutoAttachScaleRule"));
	if(!Property) { check(false); return 0;}
	EAttachmentRule PropertyValue = (EAttachmentRule)(luaL_checkint(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Call_OnSystemFinished(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ParticleSystemComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ParticleSystemComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		UParticleSystemComponent* PSystem = nullptr;
	} Params;
	Params.PSystem = (UParticleSystemComponent*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"ParticleSystemComponent");;
	UParticleSystemComponent * This = (UParticleSystemComponent *)Obj;
	This->OnSystemFinished.Broadcast(Params.PSystem);
	return 0;
}

int32 New(lua_State* InScriptContext)
{
	UObject* Outer = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Object");
	FName Name = FName(luaL_checkstring(InScriptContext, 2));
	UObject* Obj = NewObject<UParticleSystemComponent>(Outer, Name);
	wLua::FLuaUtils::ReturnUObject(InScriptContext,Obj);
	return 1;
}

int32 Destroy(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ParticleSystemComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ParticleSystemComponent must be non-null"); lua_error(InScriptContext);  return 0;}
		UActorComponent * com = Cast<UActorComponent>(Obj);
		if(lua_isnoneornil(InScriptContext,2))
			com->DestroyComponent();
		else
			com->DestroyComponent(!!lua_toboolean(InScriptContext,2));
		userdata->flag |= wLua::LuaObjectFlag::DESTROYED;
		wLua::FLuaUtils::RemoveObjectReference(Obj, userdata->stamp, InScriptContext);
#ifdef AZURE_BUILD_WLUACHECK
		UE_LOG(LogAzure, Warning, TEXT("Destroy ParticleSystemComponent: %x userdata:%x   stamp:%x"),Obj,userdata,userdata->stamp);
#endif
	return 0;
}

int32 Class(lua_State* InScriptContext)
{
	UClass* Class = UParticleSystemComponent::StaticClass();
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Class);
	return 1;
}

const luaL_Reg Lib_Funcs[] =
{
	{ "New", New },
	{ "Destroy", Destroy },
	{ "Class", Class },
	{ "SetVectorParameter", SetVectorParameter },
	{ "SetTrailSourceData", SetTrailSourceData },
	{ "SetTemplate", SetTemplate },
	{ "SetMaterialParameter", SetMaterialParameter },
	{ "SetFloatParameter", SetFloatParameter },
	{ "SetEmitterEnable", SetEmitterEnable },
	{ "SetColorParameter", SetColorParameter },
	{ "SetBeamTargetTangent", SetBeamTargetTangent },
	{ "SetBeamTargetStrength", SetBeamTargetStrength },
	{ "SetBeamTargetPoint", SetBeamTargetPoint },
	{ "SetBeamSourceTangent", SetBeamSourceTangent },
	{ "SetBeamSourceStrength", SetBeamSourceStrength },
	{ "SetBeamSourcePoint", SetBeamSourcePoint },
	{ "SetBeamMethod_Target", SetBeamMethod_Target },
	{ "SetBeamMethod_Source", SetBeamMethod_Source },
	{ "SetBeamEndPoint", SetBeamEndPoint },
	{ "SetAutoAttachmentParameters", SetAutoAttachmentParameters },
	{ "SetActorParameter", SetActorParameter },
	{ "ReleaseToPool", ReleaseToPool },
	{ "GetNumActiveParticles", GetNumActiveParticles },
	{ "GetNamedMaterial", GetNamedMaterial },
	{ "GetBeamTargetTangent", GetBeamTargetTangent },
	{ "GetBeamTargetStrength", GetBeamTargetStrength },
	{ "GetBeamTargetPoint", GetBeamTargetPoint },
	{ "GetBeamSourceTangent", GetBeamSourceTangent },
	{ "GetBeamSourceStrength", GetBeamSourceStrength },
	{ "GetBeamSourcePoint", GetBeamSourcePoint },
	{ "GetBeamMethod_Target", GetBeamMethod_Target },
	{ "GetBeamMethod_Source", GetBeamMethod_Source },
	{ "GetBeamEndPoint", GetBeamEndPoint },
	{ "GenerateParticleEvent", GenerateParticleEvent },
	{ "EndTrails", EndTrails },
	{ "CreateNamedDynamicMaterialInstance", CreateNamedDynamicMaterialInstance },
	{ "BeginTrails", BeginTrails },
	{ "AzureSetLODLevelBP", AzureSetLODLevelBP },
	{ "AzureGetLODCountsBP", AzureGetLODCountsBP },
	{ "Get_Template", Get_Template },
	{ "Get_bResetOnDetach", Get_bResetOnDetach },
	{ "Set_bResetOnDetach", Set_bResetOnDetach },
	{ "Get_bAllowRecycling", Get_bAllowRecycling },
	{ "Set_bAllowRecycling", Set_bAllowRecycling },
	{ "Get_bAutoManageAttachment", Get_bAutoManageAttachment },
	{ "Get_bOverrideLODMethod", Get_bOverrideLODMethod },
	{ "Set_bOverrideLODMethod", Set_bOverrideLODMethod },
	{ "Get_LODMethod", Get_LODMethod },
	{ "Set_LODMethod", Set_LODMethod },
	{ "Call_OnParticleSpawn", Call_OnParticleSpawn },
	{ "Call_OnParticleBurst", Call_OnParticleBurst },
	{ "Call_OnParticleDeath", Call_OnParticleDeath },
	{ "Call_OnParticleCollide", Call_OnParticleCollide },
	{ "Get_SecondsBeforeInactive", Get_SecondsBeforeInactive },
	{ "Set_SecondsBeforeInactive", Set_SecondsBeforeInactive },
	{ "Get_CustomTimeDilation", Get_CustomTimeDilation },
	{ "Set_CustomTimeDilation", Set_CustomTimeDilation },
	{ "Get_AutoAttachSocketName", Get_AutoAttachSocketName },
	{ "Set_AutoAttachSocketName", Set_AutoAttachSocketName },
	{ "Get_AutoAttachLocationRule", Get_AutoAttachLocationRule },
	{ "Set_AutoAttachLocationRule", Set_AutoAttachLocationRule },
	{ "Get_AutoAttachRotationRule", Get_AutoAttachRotationRule },
	{ "Set_AutoAttachRotationRule", Set_AutoAttachRotationRule },
	{ "Get_AutoAttachScaleRule", Get_AutoAttachScaleRule },
	{ "Set_AutoAttachScaleRule", Set_AutoAttachScaleRule },
	{ "Call_OnSystemFinished", Call_OnSystemFinished },
	{ "GetEmitterNames", GetEmitterNames },
	{ "ResetParticles", ResetParticles },
	{ "ActivateSystem", ActivateSystem },
	{ "DeactivateSystem", DeactivateSystem },
	{ "is_nil", wLua::LuaStatic::isnil },
	{ "__gc", wLua::LuaStatic::removeUClassFrameCache },
	{ NULL, NULL }
};

void Register(lua_State *InScriptContext)
{
	lua_newtable(InScriptContext);
	luaL_register(InScriptContext, NULL, Lib_Funcs);
	AzureHelpFuncs::AuxRegister(InScriptContext, "ParticleSystemComponent");
}
void SetMtLink(lua_State *InScriptContext)
{
	AzureHelpFuncs::AuxSetMtLink(InScriptContext, "ParticleSystemComponent", "PrimitiveComponent",USERDATATYPE_UOBJECT);
}

}