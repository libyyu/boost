#include "Azure.h"
#include "Utility/help_funcs.h"
#include "wLua/UObjectHeaders.h"
#include "GameLogic/Weapon/SkillRopeComponent.h"
#include "AzureLuaIntegration.h"

namespace LuaSkillRopeComponent
{
int32 SetUseScaleTime(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SkillRopeComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SkillRopeComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool bUse;
	} Params;
	Params.bUse = !!(lua_toboolean(InScriptContext, 2));
#if UE_GAME
	USkillRopeComponent * This = (USkillRopeComponent *)Obj;
	This->SetUseScaleTime(Params.bUse);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetUseScaleTime"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(bool*)(params.GetStructMemory() + 0) = Params.bUse;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.bUse = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetEnabled(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SkillRopeComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SkillRopeComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool bEnabled;
	} Params;
	Params.bEnabled = !!(lua_toboolean(InScriptContext, 2));
#if UE_GAME
	USkillRopeComponent * This = (USkillRopeComponent *)Obj;
	This->SetEnabled(Params.bEnabled);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetEnabled"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(bool*)(params.GetStructMemory() + 0) = Params.bEnabled;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.bEnabled = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetCableLength(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SkillRopeComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SkillRopeComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float Length;
	} Params;
	Params.Length = (float)(luaL_checknumber(InScriptContext, 2));
#if UE_GAME
	USkillRopeComponent * This = (USkillRopeComponent *)Obj;
	This->SetCableLength(Params.Length);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetCableLength"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(float*)(params.GetStructMemory() + 0) = Params.Length;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.Length = *(float*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetAttachEndTo(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SkillRopeComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SkillRopeComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		AActor* Actor = nullptr;
		FName ComponentProperty;
		FName SocketName;
	} Params;
	Params.Actor = (AActor*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"Actor");;
	Params.ComponentProperty = FName(UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 3)));
	Params.SocketName = FName(UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 4)));
#if UE_GAME
	USkillRopeComponent * This = (USkillRopeComponent *)Obj;
	This->SetAttachEndTo(Params.Actor,Params.ComponentProperty,Params.SocketName);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetAttachEndTo"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(AActor**)(params.GetStructMemory() + 0) = Params.Actor;
		*(FName*)(params.GetStructMemory() + 8) = Params.ComponentProperty;
		*(FName*)(params.GetStructMemory() + 20) = Params.SocketName;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.Actor = *(AActor**)(params.GetStructMemory() + 0);
		Params.ComponentProperty = *(FName*)(params.GetStructMemory() + 8);
		Params.SocketName = *(FName*)(params.GetStructMemory() + 20);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 Reset(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SkillRopeComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SkillRopeComponent must be non-null"); lua_error(InScriptContext);  return 0;}
#if UE_GAME
	USkillRopeComponent * This = (USkillRopeComponent *)Obj;
	This->Reset();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("Reset"));
	if(!Function) { check(false); return 0;}
	Obj->ProcessEvent(Function, NULL);
#endif
	return 0;
}

int32 Play(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SkillRopeComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SkillRopeComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FVector _destPos;
		float _speed;
		float _backSpeed;
		float _lockTime;
	} Params;
	Params._destPos = (wLua::FLuaVector::Get(InScriptContext, 2));
	Params._speed = (float)(luaL_checknumber(InScriptContext, 3));
	Params._backSpeed = (float)(luaL_checknumber(InScriptContext, 4));
	Params._lockTime = (float)(luaL_checknumber(InScriptContext, 5));
#if UE_GAME
	USkillRopeComponent * This = (USkillRopeComponent *)Obj;
	This->Play(Params._destPos,Params._speed,Params._backSpeed,Params._lockTime);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("Play"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FVector*)(params.GetStructMemory() + 0) = Params._destPos;
		*(float*)(params.GetStructMemory() + 12) = Params._speed;
		*(float*)(params.GetStructMemory() + 16) = Params._backSpeed;
		*(float*)(params.GetStructMemory() + 20) = Params._lockTime;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params._destPos = *(FVector*)(params.GetStructMemory() + 0);
		Params._speed = *(float*)(params.GetStructMemory() + 12);
		Params._backSpeed = *(float*)(params.GetStructMemory() + 16);
		Params._lockTime = *(float*)(params.GetStructMemory() + 20);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 InitCable(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SkillRopeComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SkillRopeComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		AAttachableCable* cable = nullptr;
	} Params;
	Params.cable = (AAttachableCable*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"AttachableCable");;
#if UE_GAME
	USkillRopeComponent * This = (USkillRopeComponent *)Obj;
	This->InitCable(Params.cable);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("InitCable"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(AAttachableCable**)(params.GetStructMemory() + 0) = Params.cable;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.cable = *(AAttachableCable**)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 DetachEnd(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SkillRopeComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SkillRopeComponent must be non-null"); lua_error(InScriptContext);  return 0;}
#if UE_GAME
	USkillRopeComponent * This = (USkillRopeComponent *)Obj;
	This->DetachEnd();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("DetachEnd"));
	if(!Function) { check(false); return 0;}
	Obj->ProcessEvent(Function, NULL);
#endif
	return 0;
}

int32 Get_destPos(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SkillRopeComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SkillRopeComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USkillRopeComponent::StaticClass(), TEXT("destPos"));
	if(!Property) { check(false); return 0;}
	FVector PropertyValue = FVector();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaVector::Return(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_destPos(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SkillRopeComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SkillRopeComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USkillRopeComponent::StaticClass(), TEXT("destPos"));
	if(!Property) { check(false); return 0;}
	FVector PropertyValue = (wLua::FLuaVector::Get(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_speed(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SkillRopeComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SkillRopeComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USkillRopeComponent::StaticClass(), TEXT("speed"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_speed(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SkillRopeComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SkillRopeComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USkillRopeComponent::StaticClass(), TEXT("speed"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_backSpeed(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SkillRopeComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SkillRopeComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USkillRopeComponent::StaticClass(), TEXT("backSpeed"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_backSpeed(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SkillRopeComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SkillRopeComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USkillRopeComponent::StaticClass(), TEXT("backSpeed"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_LockTime(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SkillRopeComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SkillRopeComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USkillRopeComponent::StaticClass(), TEXT("LockTime"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_LockTime(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SkillRopeComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SkillRopeComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USkillRopeComponent::StaticClass(), TEXT("LockTime"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_dir(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SkillRopeComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SkillRopeComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USkillRopeComponent::StaticClass(), TEXT("dir"));
	if(!Property) { check(false); return 0;}
	FVector PropertyValue = FVector();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaVector::Return(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_dir(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SkillRopeComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SkillRopeComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USkillRopeComponent::StaticClass(), TEXT("dir"));
	if(!Property) { check(false); return 0;}
	FVector PropertyValue = (wLua::FLuaVector::Get(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 New(lua_State* InScriptContext)
{
	UObject* Outer = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Object");
	FName Name = FName(luaL_checkstring(InScriptContext, 2));
	UObject* Obj = NewObject<USkillRopeComponent>(Outer, Name);
	wLua::FLuaUtils::ReturnUObject(InScriptContext,Obj);
	return 1;
}

int32 Destroy(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SkillRopeComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SkillRopeComponent must be non-null"); lua_error(InScriptContext);  return 0;}
		UActorComponent * com = Cast<UActorComponent>(Obj);
		if(lua_isnoneornil(InScriptContext,2))
			com->DestroyComponent();
		else
			com->DestroyComponent(!!lua_toboolean(InScriptContext,2));
		userdata->flag |= wLua::LuaObjectFlag::DESTROYED;
		wLua::FLuaUtils::RemoveObjectReference(Obj, userdata->stamp, InScriptContext);
#ifdef AZURE_BUILD_WLUACHECK
		UE_LOG(LogAzure, Warning, TEXT("Destroy SkillRopeComponent: %x userdata:%x   stamp:%x"),Obj,userdata,userdata->stamp);
#endif
	return 0;
}

int32 Class(lua_State* InScriptContext)
{
	UClass* Class = USkillRopeComponent::StaticClass();
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Class);
	return 1;
}

const luaL_Reg Lib_Funcs[] =
{
	{ "New", New },
	{ "Destroy", Destroy },
	{ "Class", Class },
	{ "SetUseScaleTime", SetUseScaleTime },
	{ "SetEnabled", SetEnabled },
	{ "SetCableLength", SetCableLength },
	{ "SetAttachEndTo", SetAttachEndTo },
	{ "Reset", Reset },
	{ "Play", Play },
	{ "InitCable", InitCable },
	{ "DetachEnd", DetachEnd },
	{ "Get_destPos", Get_destPos },
	{ "Set_destPos", Set_destPos },
	{ "Get_speed", Get_speed },
	{ "Set_speed", Set_speed },
	{ "Get_backSpeed", Get_backSpeed },
	{ "Set_backSpeed", Set_backSpeed },
	{ "Get_LockTime", Get_LockTime },
	{ "Set_LockTime", Set_LockTime },
	{ "Get_dir", Get_dir },
	{ "Set_dir", Set_dir },
	{ "is_nil", wLua::LuaStatic::isnil },
	{ "__gc", wLua::LuaStatic::removeUClassFrameCache },
	{ NULL, NULL }
};

void Register(lua_State *InScriptContext)
{
	lua_newtable(InScriptContext);
	luaL_register(InScriptContext, NULL, Lib_Funcs);
	AzureHelpFuncs::AuxRegister(InScriptContext, "SkillRopeComponent");
}
void SetMtLink(lua_State *InScriptContext)
{
	AzureHelpFuncs::AuxSetMtLink(InScriptContext, "SkillRopeComponent", "SceneComponent",USERDATATYPE_UOBJECT);
}

}