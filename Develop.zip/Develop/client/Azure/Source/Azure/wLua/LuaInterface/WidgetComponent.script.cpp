#include "Azure.h"
#include "Utility/help_funcs.h"
#include "wLua/UObjectHeaders.h"
#include "Components/WidgetComponent.h"
#include "AzureLuaIntegration.h"

namespace LuaWidgetComponent
{
int32 SetBlendMode(lua_State*);

int32 SetWidget(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"WidgetComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"WidgetComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		UUserWidget* Widget = nullptr;
	} Params;
	Params.Widget = (UUserWidget*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"UserWidget");;
#if UE_GAME
	UWidgetComponent * This = (UWidgetComponent *)Obj;
	This->SetWidget(Params.Widget);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetWidget"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(UUserWidget**)(params.GetStructMemory() + 0) = Params.Widget;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.Widget = *(UUserWidget**)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetTintColorAndOpacity(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"WidgetComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"WidgetComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FLinearColor NewTintColorAndOpacity;
	} Params;
	Params.NewTintColorAndOpacity = (wLua::FLuaLinearColor::Get(InScriptContext, 2));
#if UE_GAME
	UWidgetComponent * This = (UWidgetComponent *)Obj;
	This->SetTintColorAndOpacity(Params.NewTintColorAndOpacity);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetTintColorAndOpacity"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FLinearColor*)(params.GetStructMemory() + 0) = Params.NewTintColorAndOpacity;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.NewTintColorAndOpacity = *(FLinearColor*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetOwnerPlayer(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"WidgetComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"WidgetComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		ULocalPlayer* LocalPlayer = nullptr;
	} Params;
	Params.LocalPlayer = (ULocalPlayer*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"LocalPlayer");;
#if UE_GAME
	UWidgetComponent * This = (UWidgetComponent *)Obj;
	This->SetOwnerPlayer(Params.LocalPlayer);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetOwnerPlayer"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(ULocalPlayer**)(params.GetStructMemory() + 0) = Params.LocalPlayer;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.LocalPlayer = *(ULocalPlayer**)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetManuallyRedraw(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"WidgetComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"WidgetComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool bUseManualRedraw;
	} Params;
	Params.bUseManualRedraw = !!(lua_toboolean(InScriptContext, 2));
#if UE_GAME
	UWidgetComponent * This = (UWidgetComponent *)Obj;
	This->SetManuallyRedraw(Params.bUseManualRedraw);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetManuallyRedraw"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(bool*)(params.GetStructMemory() + 0) = Params.bUseManualRedraw;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.bUseManualRedraw = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetDrawSize(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"WidgetComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"WidgetComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FVector2D Size;
	} Params;
	Params.Size = (wLua::FLuaVector2D::Get(InScriptContext, 2));
#if UE_GAME
	UWidgetComponent * This = (UWidgetComponent *)Obj;
	This->SetDrawSize(Params.Size);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetDrawSize"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FVector2D*)(params.GetStructMemory() + 0) = Params.Size;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.Size = *(FVector2D*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetBackgroundColor(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"WidgetComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"WidgetComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FLinearColor NewBackgroundColor;
	} Params;
	Params.NewBackgroundColor = (wLua::FLuaLinearColor::Get(InScriptContext, 2));
#if UE_GAME
	UWidgetComponent * This = (UWidgetComponent *)Obj;
	This->SetBackgroundColor(Params.NewBackgroundColor);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetBackgroundColor"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FLinearColor*)(params.GetStructMemory() + 0) = Params.NewBackgroundColor;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.NewBackgroundColor = *(FLinearColor*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 RequestRedraw(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"WidgetComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"WidgetComponent must be non-null"); lua_error(InScriptContext);  return 0;}
#if UE_GAME
	UWidgetComponent * This = (UWidgetComponent *)Obj;
	This->RequestRedraw();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("RequestRedraw"));
	if(!Function) { check(false); return 0;}
	Obj->ProcessEvent(Function, NULL);
#endif
	return 0;
}

int32 GetUserWidgetObject(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"WidgetComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"WidgetComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		UUserWidget* ReturnValue = nullptr;
	} Params;
#if UE_GAME
	UWidgetComponent * This = (UWidgetComponent *)Obj;
	Params.ReturnValue = This->GetUserWidgetObject();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetUserWidgetObject"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(UUserWidget**)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetRenderTarget(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"WidgetComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"WidgetComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		UTextureRenderTarget2D* ReturnValue = nullptr;
	} Params;
#if UE_GAME
	UWidgetComponent * This = (UWidgetComponent *)Obj;
	Params.ReturnValue = This->GetRenderTarget();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetRenderTarget"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(UTextureRenderTarget2D**)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetOwnerPlayer(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"WidgetComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"WidgetComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		ULocalPlayer* ReturnValue = nullptr;
	} Params;
#if UE_GAME
	UWidgetComponent * This = (UWidgetComponent *)Obj;
	Params.ReturnValue = This->GetOwnerPlayer();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetOwnerPlayer"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(ULocalPlayer**)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetMaterialInstance(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"WidgetComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"WidgetComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		UMaterialInstanceDynamic* ReturnValue = nullptr;
	} Params;
#if UE_GAME
	UWidgetComponent * This = (UWidgetComponent *)Obj;
	Params.ReturnValue = This->GetMaterialInstance();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetMaterialInstance"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(UMaterialInstanceDynamic**)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetDrawSize(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"WidgetComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"WidgetComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FVector2D ReturnValue;
	} Params;
#if UE_GAME
	UWidgetComponent * This = (UWidgetComponent *)Obj;
	Params.ReturnValue = This->GetDrawSize();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetDrawSize"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(FVector2D*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaVector2D::Return(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 Get_Space(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"WidgetComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"WidgetComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UWidgetComponent::StaticClass(), TEXT("Space"));
	if(!Property) { check(false); return 0;}
	EWidgetSpace PropertyValue = EWidgetSpace();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushinteger(InScriptContext, (int)PropertyValue);
	return 1;
}

int32 Set_Space(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"WidgetComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"WidgetComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UWidgetComponent::StaticClass(), TEXT("Space"));
	if(!Property) { check(false); return 0;}
	EWidgetSpace PropertyValue = (EWidgetSpace)(luaL_checkint(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_TimingPolicy(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"WidgetComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"WidgetComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UWidgetComponent::StaticClass(), TEXT("TimingPolicy"));
	if(!Property) { check(false); return 0;}
	EWidgetTimingPolicy PropertyValue = EWidgetTimingPolicy();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushinteger(InScriptContext, (int)PropertyValue);
	return 1;
}

int32 Set_TimingPolicy(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"WidgetComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"WidgetComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UWidgetComponent::StaticClass(), TEXT("TimingPolicy"));
	if(!Property) { check(false); return 0;}
	EWidgetTimingPolicy PropertyValue = (EWidgetTimingPolicy)(luaL_checkint(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_WidgetClass(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"WidgetComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"WidgetComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UWidgetComponent::StaticClass(), TEXT("WidgetClass"));
	if(!Property) { check(false); return 0;}
	TSubclassOf<UUserWidget>  PropertyValue = TSubclassOf<UUserWidget> ();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaUtils::ReturnUObject(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_WidgetClass(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"WidgetComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"WidgetComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UWidgetComponent::StaticClass(), TEXT("WidgetClass"));
	if(!Property) { check(false); return 0;}
	TSubclassOf<UUserWidget>  PropertyValue = (UClass*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"Class");;
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bManuallyRedraw(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"WidgetComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"WidgetComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UWidgetComponent::StaticClass(), TEXT("bManuallyRedraw"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = bool();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bManuallyRedraw(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"WidgetComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"WidgetComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UWidgetComponent::StaticClass(), TEXT("bManuallyRedraw"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_RedrawTime(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"WidgetComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"WidgetComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UWidgetComponent::StaticClass(), TEXT("RedrawTime"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_RedrawTime(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"WidgetComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"WidgetComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UWidgetComponent::StaticClass(), TEXT("RedrawTime"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bDrawAtDesiredSize(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"WidgetComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"WidgetComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UWidgetComponent::StaticClass(), TEXT("bDrawAtDesiredSize"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = bool();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bDrawAtDesiredSize(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"WidgetComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"WidgetComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UWidgetComponent::StaticClass(), TEXT("bDrawAtDesiredSize"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_Pivot(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"WidgetComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"WidgetComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UWidgetComponent::StaticClass(), TEXT("Pivot"));
	if(!Property) { check(false); return 0;}
	FVector2D PropertyValue = FVector2D();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaVector2D::Return(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_Pivot(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"WidgetComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"WidgetComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UWidgetComponent::StaticClass(), TEXT("Pivot"));
	if(!Property) { check(false); return 0;}
	FVector2D PropertyValue = (wLua::FLuaVector2D::Get(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bReceiveHardwareInput(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"WidgetComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"WidgetComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UWidgetComponent::StaticClass(), TEXT("bReceiveHardwareInput"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = bool();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bReceiveHardwareInput(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"WidgetComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"WidgetComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UWidgetComponent::StaticClass(), TEXT("bReceiveHardwareInput"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bWindowFocusable(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"WidgetComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"WidgetComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UWidgetComponent::StaticClass(), TEXT("bWindowFocusable"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = bool();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bWindowFocusable(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"WidgetComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"WidgetComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UWidgetComponent::StaticClass(), TEXT("bWindowFocusable"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bApplyGammaCorrection(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"WidgetComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"WidgetComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UWidgetComponent::StaticClass(), TEXT("bApplyGammaCorrection"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = bool();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bApplyGammaCorrection(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"WidgetComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"WidgetComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UWidgetComponent::StaticClass(), TEXT("bApplyGammaCorrection"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_BackgroundColor(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"WidgetComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"WidgetComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UWidgetComponent::StaticClass(), TEXT("BackgroundColor"));
	if(!Property) { check(false); return 0;}
	FLinearColor PropertyValue = FLinearColor();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaLinearColor::Return(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_BackgroundColor(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"WidgetComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"WidgetComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UWidgetComponent::StaticClass(), TEXT("BackgroundColor"));
	if(!Property) { check(false); return 0;}
	FLinearColor PropertyValue = (wLua::FLuaLinearColor::Get(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_TintColorAndOpacity(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"WidgetComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"WidgetComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UWidgetComponent::StaticClass(), TEXT("TintColorAndOpacity"));
	if(!Property) { check(false); return 0;}
	FLinearColor PropertyValue = FLinearColor();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaLinearColor::Return(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_TintColorAndOpacity(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"WidgetComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"WidgetComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UWidgetComponent::StaticClass(), TEXT("TintColorAndOpacity"));
	if(!Property) { check(false); return 0;}
	FLinearColor PropertyValue = (wLua::FLuaLinearColor::Get(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_OpacityFromTexture(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"WidgetComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"WidgetComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UWidgetComponent::StaticClass(), TEXT("OpacityFromTexture"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_OpacityFromTexture(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"WidgetComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"WidgetComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UWidgetComponent::StaticClass(), TEXT("OpacityFromTexture"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_BlendMode(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"WidgetComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"WidgetComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UWidgetComponent::StaticClass(), TEXT("BlendMode"));
	if(!Property) { check(false); return 0;}
	EWidgetBlendMode PropertyValue = EWidgetBlendMode();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushinteger(InScriptContext, (int)PropertyValue);
	return 1;
}

int32 Set_BlendMode(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"WidgetComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"WidgetComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UWidgetComponent::StaticClass(), TEXT("BlendMode"));
	if(!Property) { check(false); return 0;}
	EWidgetBlendMode PropertyValue = (EWidgetBlendMode)(luaL_checkint(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bIsTwoSided(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"WidgetComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"WidgetComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UWidgetComponent::StaticClass(), TEXT("bIsTwoSided"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = bool();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bIsTwoSided(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"WidgetComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"WidgetComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UWidgetComponent::StaticClass(), TEXT("bIsTwoSided"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_TickWhenOffscreen(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"WidgetComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"WidgetComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UWidgetComponent::StaticClass(), TEXT("TickWhenOffscreen"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = bool();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_TickWhenOffscreen(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"WidgetComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"WidgetComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UWidgetComponent::StaticClass(), TEXT("TickWhenOffscreen"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_SharedLayerName(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"WidgetComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"WidgetComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UWidgetComponent::StaticClass(), TEXT("SharedLayerName"));
	if(!Property) { check(false); return 0;}
	FName PropertyValue = FName();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushstring(InScriptContext, TCHAR_TO_UTF8(*PropertyValue.ToString()));
	return 1;
}

int32 Set_SharedLayerName(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"WidgetComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"WidgetComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UWidgetComponent::StaticClass(), TEXT("SharedLayerName"));
	if(!Property) { check(false); return 0;}
	FName PropertyValue = FName(UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 2)));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_LayerZOrder(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"WidgetComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"WidgetComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UWidgetComponent::StaticClass(), TEXT("LayerZOrder"));
	if(!Property) { check(false); return 0;}
	int32 PropertyValue = int32();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushinteger(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_LayerZOrder(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"WidgetComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"WidgetComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UWidgetComponent::StaticClass(), TEXT("LayerZOrder"));
	if(!Property) { check(false); return 0;}
	int32 PropertyValue = (luaL_checkint(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_GeometryMode(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"WidgetComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"WidgetComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UWidgetComponent::StaticClass(), TEXT("GeometryMode"));
	if(!Property) { check(false); return 0;}
	EWidgetGeometryMode PropertyValue = EWidgetGeometryMode();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushinteger(InScriptContext, (int)PropertyValue);
	return 1;
}

int32 Set_GeometryMode(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"WidgetComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"WidgetComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UWidgetComponent::StaticClass(), TEXT("GeometryMode"));
	if(!Property) { check(false); return 0;}
	EWidgetGeometryMode PropertyValue = (EWidgetGeometryMode)(luaL_checkint(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_CylinderArcAngle(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"WidgetComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"WidgetComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UWidgetComponent::StaticClass(), TEXT("CylinderArcAngle"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_CylinderArcAngle(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"WidgetComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"WidgetComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UWidgetComponent::StaticClass(), TEXT("CylinderArcAngle"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 New(lua_State* InScriptContext)
{
	UObject* Outer = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Object");
	FName Name = FName(luaL_checkstring(InScriptContext, 2));
	UObject* Obj = NewObject<UWidgetComponent>(Outer, Name);
	wLua::FLuaUtils::ReturnUObject(InScriptContext,Obj);
	return 1;
}

int32 Destroy(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"WidgetComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"WidgetComponent must be non-null"); lua_error(InScriptContext);  return 0;}
		UActorComponent * com = Cast<UActorComponent>(Obj);
		if(lua_isnoneornil(InScriptContext,2))
			com->DestroyComponent();
		else
			com->DestroyComponent(!!lua_toboolean(InScriptContext,2));
		userdata->flag |= wLua::LuaObjectFlag::DESTROYED;
		wLua::FLuaUtils::RemoveObjectReference(Obj, userdata->stamp, InScriptContext);
#ifdef AZURE_BUILD_WLUACHECK
		UE_LOG(LogAzure, Warning, TEXT("Destroy WidgetComponent: %x userdata:%x   stamp:%x"),Obj,userdata,userdata->stamp);
#endif
	return 0;
}

int32 Class(lua_State* InScriptContext)
{
	UClass* Class = UWidgetComponent::StaticClass();
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Class);
	return 1;
}

const luaL_Reg Lib_Funcs[] =
{
	{ "New", New },
	{ "Destroy", Destroy },
	{ "Class", Class },
	{ "SetWidget", SetWidget },
	{ "SetTintColorAndOpacity", SetTintColorAndOpacity },
	{ "SetOwnerPlayer", SetOwnerPlayer },
	{ "SetManuallyRedraw", SetManuallyRedraw },
	{ "SetDrawSize", SetDrawSize },
	{ "SetBackgroundColor", SetBackgroundColor },
	{ "RequestRedraw", RequestRedraw },
	{ "GetUserWidgetObject", GetUserWidgetObject },
	{ "GetRenderTarget", GetRenderTarget },
	{ "GetOwnerPlayer", GetOwnerPlayer },
	{ "GetMaterialInstance", GetMaterialInstance },
	{ "GetDrawSize", GetDrawSize },
	{ "Get_Space", Get_Space },
	{ "Set_Space", Set_Space },
	{ "Get_TimingPolicy", Get_TimingPolicy },
	{ "Set_TimingPolicy", Set_TimingPolicy },
	{ "Get_WidgetClass", Get_WidgetClass },
	{ "Set_WidgetClass", Set_WidgetClass },
	{ "Get_bManuallyRedraw", Get_bManuallyRedraw },
	{ "Set_bManuallyRedraw", Set_bManuallyRedraw },
	{ "Get_RedrawTime", Get_RedrawTime },
	{ "Set_RedrawTime", Set_RedrawTime },
	{ "Get_bDrawAtDesiredSize", Get_bDrawAtDesiredSize },
	{ "Set_bDrawAtDesiredSize", Set_bDrawAtDesiredSize },
	{ "Get_Pivot", Get_Pivot },
	{ "Set_Pivot", Set_Pivot },
	{ "Get_bReceiveHardwareInput", Get_bReceiveHardwareInput },
	{ "Set_bReceiveHardwareInput", Set_bReceiveHardwareInput },
	{ "Get_bWindowFocusable", Get_bWindowFocusable },
	{ "Set_bWindowFocusable", Set_bWindowFocusable },
	{ "Get_bApplyGammaCorrection", Get_bApplyGammaCorrection },
	{ "Set_bApplyGammaCorrection", Set_bApplyGammaCorrection },
	{ "Get_BackgroundColor", Get_BackgroundColor },
	{ "Set_BackgroundColor", Set_BackgroundColor },
	{ "Get_TintColorAndOpacity", Get_TintColorAndOpacity },
	{ "Set_TintColorAndOpacity", Set_TintColorAndOpacity },
	{ "Get_OpacityFromTexture", Get_OpacityFromTexture },
	{ "Set_OpacityFromTexture", Set_OpacityFromTexture },
	{ "Get_BlendMode", Get_BlendMode },
	{ "Set_BlendMode", Set_BlendMode },
	{ "Get_bIsTwoSided", Get_bIsTwoSided },
	{ "Set_bIsTwoSided", Set_bIsTwoSided },
	{ "Get_TickWhenOffscreen", Get_TickWhenOffscreen },
	{ "Set_TickWhenOffscreen", Set_TickWhenOffscreen },
	{ "Get_SharedLayerName", Get_SharedLayerName },
	{ "Set_SharedLayerName", Set_SharedLayerName },
	{ "Get_LayerZOrder", Get_LayerZOrder },
	{ "Set_LayerZOrder", Set_LayerZOrder },
	{ "Get_GeometryMode", Get_GeometryMode },
	{ "Set_GeometryMode", Set_GeometryMode },
	{ "Get_CylinderArcAngle", Get_CylinderArcAngle },
	{ "Set_CylinderArcAngle", Set_CylinderArcAngle },
	{ "SetBlendMode", SetBlendMode },
	{ "is_nil", wLua::LuaStatic::isnil },
	{ "__gc", wLua::LuaStatic::removeUClassFrameCache },
	{ NULL, NULL }
};

void Register(lua_State *InScriptContext)
{
	lua_newtable(InScriptContext);
	luaL_register(InScriptContext, NULL, Lib_Funcs);
	AzureHelpFuncs::AuxRegister(InScriptContext, "WidgetComponent");
}
void SetMtLink(lua_State *InScriptContext)
{
	AzureHelpFuncs::AuxSetMtLink(InScriptContext, "WidgetComponent", "MeshComponent",USERDATATYPE_UOBJECT);
}

}