#include "Azure.h"
#include "Utility/help_funcs.h"
#include "wLua/UObjectHeaders.h"
#include "Engine/World.h"
#include "AzureLuaIntegration.h"

namespace LuaWorld
{
int32 LineTraceSingleByObjectType(lua_State*);
int32 LineTraceSingleByChannel(lua_State*);
int32 LineTraceMultiByObjectType(lua_State*);
int32 LineTraceMultiByChannel(lua_State*);
int32 SweepSingleByChannel(lua_State*);
int32 SweepMultiByChannel(lua_State*);
int32 LineTraceOnSkeletalMesh(lua_State*);
int32 GetFirstPlayerController(lua_State*);
int32 SpawnActor(lua_State*);
int32 DestroyActor(lua_State*);
int32 RemoveActor(lua_State*);
int32 GetPersistentLevel(lua_State*);
int32 SetActiveLightingScenario(lua_State*);
int32 GetActiveLightingScenario(lua_State*);
int32 GetDefaultGravityZ(lua_State*);
int32 GetNonDefaultPhysicsVolumeCount(lua_State*);
int32 GetNonDefaultPhysicsVolumeList(lua_State*);
int32 SelectPhysicsVolume(lua_State*);
int32 OverlapAnyTestByChannel(lua_State*);
int32 SpawnActorByTemplate(lua_State*);

int32 HandleTimelineScrubbed(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"World",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"World must be non-null"); lua_error(InScriptContext);  return 0;}
#if UE_GAME
	UWorld * This = (UWorld *)Obj;
	This->HandleTimelineScrubbed();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("HandleTimelineScrubbed"));
	if(!Function) { check(false); return 0;}
	Obj->ProcessEvent(Function, NULL);
#endif
	return 0;
}

int32 Get_ThumbnailInfo(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"World",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"World must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UWorld::StaticClass(), TEXT("ThumbnailInfo"));
	if(!Property) { check(false); return 0;}
	UThumbnailInfo* PropertyValue;
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaUtils::ReturnUObject(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_ThumbnailInfo(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"World",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"World must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UWorld::StaticClass(), TEXT("ThumbnailInfo"));
	if(!Property) { check(false); return 0;}
	UThumbnailInfo* PropertyValue = (UThumbnailInfo*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"ThumbnailInfo");;
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 New(lua_State* InScriptContext)
{
	UObject* Outer = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Object");
	FName Name = FName(luaL_checkstring(InScriptContext, 2));
	UObject* Obj = NewObject<UWorld>(Outer, Name);
	wLua::FLuaUtils::ReturnUObject(InScriptContext,Obj);
	return 1;
}

int32 Destroy(lua_State* InScriptContext)
{
	return 0;
}

int32 Class(lua_State* InScriptContext)
{
	UClass* Class = UWorld::StaticClass();
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Class);
	return 1;
}

const luaL_Reg Lib_Funcs[] =
{
	{ "New", New },
	{ "Destroy", Destroy },
	{ "Class", Class },
	{ "HandleTimelineScrubbed", HandleTimelineScrubbed },
	{ "Get_ThumbnailInfo", Get_ThumbnailInfo },
	{ "Set_ThumbnailInfo", Set_ThumbnailInfo },
	{ "LineTraceSingleByObjectType", LineTraceSingleByObjectType },
	{ "LineTraceSingleByChannel", LineTraceSingleByChannel },
	{ "LineTraceMultiByObjectType", LineTraceMultiByObjectType },
	{ "LineTraceMultiByChannel", LineTraceMultiByChannel },
	{ "SweepSingleByChannel", SweepSingleByChannel },
	{ "SweepMultiByChannel", SweepMultiByChannel },
	{ "LineTraceOnSkeletalMesh", LineTraceOnSkeletalMesh },
	{ "GetFirstPlayerController", GetFirstPlayerController },
	{ "SpawnActor", SpawnActor },
	{ "DestroyActor", DestroyActor },
	{ "RemoveActor", RemoveActor },
	{ "GetPersistentLevel", GetPersistentLevel },
	{ "SetActiveLightingScenario", SetActiveLightingScenario },
	{ "GetActiveLightingScenario", GetActiveLightingScenario },
	{ "GetDefaultGravityZ", GetDefaultGravityZ },
	{ "GetNonDefaultPhysicsVolumeCount", GetNonDefaultPhysicsVolumeCount },
	{ "GetNonDefaultPhysicsVolumeList", GetNonDefaultPhysicsVolumeList },
	{ "SelectPhysicsVolume", SelectPhysicsVolume },
	{ "OverlapAnyTestByChannel", OverlapAnyTestByChannel },
	{ "SpawnActorByTemplate", SpawnActorByTemplate },
	{ "is_nil", wLua::LuaStatic::isnil },
	{ "__gc", wLua::LuaStatic::removeUClassFrameCache },
	{ NULL, NULL }
};

void Register(lua_State *InScriptContext)
{
	lua_newtable(InScriptContext);
	luaL_register(InScriptContext, NULL, Lib_Funcs);
	AzureHelpFuncs::AuxRegister(InScriptContext, "World");
}
void SetMtLink(lua_State *InScriptContext)
{
	AzureHelpFuncs::AuxSetMtLink(InScriptContext, "World", "Object",USERDATATYPE_UOBJECT);
}

}