#include "Azure.h"
#include "Utility/help_funcs.h"
#include "wLua/UObjectHeaders.h"
#include "Components/EditableTextBox.h"
#include "AzureLuaIntegration.h"

namespace LuaEditableTextBox
{
int32 SetText(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"EditableTextBox",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"EditableTextBox must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FText InText;
	} Params;
	Params.InText = FText::FromString(UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 2)));
#if UE_GAME
	UEditableTextBox * This = (UEditableTextBox *)Obj;
	This->SetText(Params.InText);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetText"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FText*)(params.GetStructMemory() + 0) = Params.InText;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.InText = *(FText*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetIsReadOnly(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"EditableTextBox",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"EditableTextBox must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool bReadOnly;
	} Params;
	Params.bReadOnly = !!(lua_toboolean(InScriptContext, 2));
#if UE_GAME
	UEditableTextBox * This = (UEditableTextBox *)Obj;
	This->SetIsReadOnly(Params.bReadOnly);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetIsReadOnly"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(bool*)(params.GetStructMemory() + 0) = Params.bReadOnly;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.bReadOnly = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetIsPassword(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"EditableTextBox",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"EditableTextBox must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool bIsPassword;
	} Params;
	Params.bIsPassword = !!(lua_toboolean(InScriptContext, 2));
#if UE_GAME
	UEditableTextBox * This = (UEditableTextBox *)Obj;
	This->SetIsPassword(Params.bIsPassword);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetIsPassword"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(bool*)(params.GetStructMemory() + 0) = Params.bIsPassword;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.bIsPassword = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetHintText(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"EditableTextBox",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"EditableTextBox must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FText InText;
	} Params;
	Params.InText = FText::FromString(UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 2)));
#if UE_GAME
	UEditableTextBox * This = (UEditableTextBox *)Obj;
	This->SetHintText(Params.InText);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetHintText"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FText*)(params.GetStructMemory() + 0) = Params.InText;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.InText = *(FText*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetError(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"EditableTextBox",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"EditableTextBox must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FText InError;
	} Params;
	Params.InError = FText::FromString(UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 2)));
#if UE_GAME
	UEditableTextBox * This = (UEditableTextBox *)Obj;
	This->SetError(Params.InError);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetError"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FText*)(params.GetStructMemory() + 0) = Params.InError;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.InError = *(FText*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 HaveInvalidChars(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"EditableTextBox",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"EditableTextBox must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool ReturnValue;
	} Params;
#if UE_GAME
	UEditableTextBox * This = (UEditableTextBox *)Obj;
	Params.ReturnValue = This->HaveInvalidChars();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("HaveInvalidChars"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushboolean(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 HasError(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"EditableTextBox",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"EditableTextBox must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool ReturnValue;
	} Params;
#if UE_GAME
	UEditableTextBox * This = (UEditableTextBox *)Obj;
	Params.ReturnValue = This->HasError();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("HasError"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushboolean(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetText(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"EditableTextBox",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"EditableTextBox must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FText ReturnValue;
	} Params;
#if UE_GAME
	UEditableTextBox * This = (UEditableTextBox *)Obj;
	Params.ReturnValue = This->GetText();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetText"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(FText*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushstring(InScriptContext, TCHAR_TO_UTF8(*Params.ReturnValue.ToString()));
	return 1;
}

int32 ClearError(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"EditableTextBox",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"EditableTextBox must be non-null"); lua_error(InScriptContext);  return 0;}
#if UE_GAME
	UEditableTextBox * This = (UEditableTextBox *)Obj;
	This->ClearError();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("ClearError"));
	if(!Function) { check(false); return 0;}
	Obj->ProcessEvent(Function, NULL);
#endif
	return 0;
}

int32 Get_Text(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"EditableTextBox",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"EditableTextBox must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UEditableTextBox::StaticClass(), TEXT("Text"));
	if(!Property) { check(false); return 0;}
	FText PropertyValue;
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushstring(InScriptContext, TCHAR_TO_UTF8(*PropertyValue.ToString()));
	return 1;
}

int32 Set_Text(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"EditableTextBox",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"EditableTextBox must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UEditableTextBox::StaticClass(), TEXT("Text"));
	if(!Property) { check(false); return 0;}
	FText PropertyValue = FText::FromString(UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 2)));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_HintText(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"EditableTextBox",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"EditableTextBox must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UEditableTextBox::StaticClass(), TEXT("HintText"));
	if(!Property) { check(false); return 0;}
	FText PropertyValue;
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushstring(InScriptContext, TCHAR_TO_UTF8(*PropertyValue.ToString()));
	return 1;
}

int32 Get_IsReadOnly(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"EditableTextBox",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"EditableTextBox must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UEditableTextBox::StaticClass(), TEXT("IsReadOnly"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = bool();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_IsPassword(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"EditableTextBox",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"EditableTextBox must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UEditableTextBox::StaticClass(), TEXT("IsPassword"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = bool();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_MinimumDesiredWidth(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"EditableTextBox",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"EditableTextBox must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UEditableTextBox::StaticClass(), TEXT("MinimumDesiredWidth"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_IsCaretMovedWhenGainFocus(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"EditableTextBox",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"EditableTextBox must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UEditableTextBox::StaticClass(), TEXT("IsCaretMovedWhenGainFocus"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = bool();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_SelectAllTextWhenFocused(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"EditableTextBox",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"EditableTextBox must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UEditableTextBox::StaticClass(), TEXT("SelectAllTextWhenFocused"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = bool();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_RevertTextOnEscape(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"EditableTextBox",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"EditableTextBox must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UEditableTextBox::StaticClass(), TEXT("RevertTextOnEscape"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = bool();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_ClearKeyboardFocusOnCommit(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"EditableTextBox",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"EditableTextBox must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UEditableTextBox::StaticClass(), TEXT("ClearKeyboardFocusOnCommit"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = bool();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_SelectAllTextOnCommit(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"EditableTextBox",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"EditableTextBox must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UEditableTextBox::StaticClass(), TEXT("SelectAllTextOnCommit"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = bool();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_AllowContextMenu(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"EditableTextBox",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"EditableTextBox must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UEditableTextBox::StaticClass(), TEXT("AllowContextMenu"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = bool();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_AllowContextMenu(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"EditableTextBox",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"EditableTextBox must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UEditableTextBox::StaticClass(), TEXT("AllowContextMenu"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_KeyboardType(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"EditableTextBox",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"EditableTextBox must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UEditableTextBox::StaticClass(), TEXT("KeyboardType"));
	if(!Property) { check(false); return 0;}
	TEnumAsByte<EVirtualKeyboardType::Type> PropertyValue = TEnumAsByte<EVirtualKeyboardType::Type>();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushinteger(InScriptContext, (int)PropertyValue);
	return 1;
}

int32 Set_KeyboardType(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"EditableTextBox",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"EditableTextBox must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UEditableTextBox::StaticClass(), TEXT("KeyboardType"));
	if(!Property) { check(false); return 0;}
	TEnumAsByte<EVirtualKeyboardType::Type> PropertyValue = (TEnumAsByte<EVirtualKeyboardType::Type>)(luaL_checkint(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_VirtualKeyboardDismissAction(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"EditableTextBox",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"EditableTextBox must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UEditableTextBox::StaticClass(), TEXT("VirtualKeyboardDismissAction"));
	if(!Property) { check(false); return 0;}
	EVirtualKeyboardDismissAction PropertyValue = EVirtualKeyboardDismissAction();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushinteger(InScriptContext, (int)PropertyValue);
	return 1;
}

int32 Set_VirtualKeyboardDismissAction(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"EditableTextBox",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"EditableTextBox must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UEditableTextBox::StaticClass(), TEXT("VirtualKeyboardDismissAction"));
	if(!Property) { check(false); return 0;}
	EVirtualKeyboardDismissAction PropertyValue = (EVirtualKeyboardDismissAction)(luaL_checkint(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_Justification(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"EditableTextBox",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"EditableTextBox must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UEditableTextBox::StaticClass(), TEXT("Justification"));
	if(!Property) { check(false); return 0;}
	TEnumAsByte<ETextJustify::Type> PropertyValue = TEnumAsByte<ETextJustify::Type>();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushinteger(InScriptContext, (int)PropertyValue);
	return 1;
}

int32 Set_Justification(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"EditableTextBox",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"EditableTextBox must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UEditableTextBox::StaticClass(), TEXT("Justification"));
	if(!Property) { check(false); return 0;}
	TEnumAsByte<ETextJustify::Type> PropertyValue = (TEnumAsByte<ETextJustify::Type>)(luaL_checkint(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Call_OnTextChanged(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"EditableTextBox",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"EditableTextBox must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FText Text;
	} Params;
	Params.Text = FText::FromString(UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 2)));
	UEditableTextBox * This = (UEditableTextBox *)Obj;
	This->OnTextChanged.Broadcast(Params.Text);
	return 0;
}

int32 Call_OnTextCommitted(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"EditableTextBox",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"EditableTextBox must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FText Text;
		TEnumAsByte<ETextCommit::Type> CommitMethod;
	} Params;
	Params.Text = FText::FromString(UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 2)));
	Params.CommitMethod = (TEnumAsByte<ETextCommit::Type>)(luaL_checkint(InScriptContext, 3));
	UEditableTextBox * This = (UEditableTextBox *)Obj;
	This->OnTextCommitted.Broadcast(Params.Text,Params.CommitMethod);
	return 0;
}

int32 New(lua_State* InScriptContext)
{
	UObject* Outer = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Object");
	FName Name = FName(luaL_checkstring(InScriptContext, 2));
	UObject* Obj = NewObject<UEditableTextBox>(Outer, Name);
	wLua::FLuaUtils::ReturnUObject(InScriptContext,Obj);
	return 1;
}

int32 Destroy(lua_State* InScriptContext)
{
	return 0;
}

int32 Class(lua_State* InScriptContext)
{
	UClass* Class = UEditableTextBox::StaticClass();
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Class);
	return 1;
}

const luaL_Reg Lib_Funcs[] =
{
	{ "New", New },
	{ "Destroy", Destroy },
	{ "Class", Class },
	{ "SetText", SetText },
	{ "SetIsReadOnly", SetIsReadOnly },
	{ "SetIsPassword", SetIsPassword },
	{ "SetHintText", SetHintText },
	{ "SetError", SetError },
	{ "HaveInvalidChars", HaveInvalidChars },
	{ "HasError", HasError },
	{ "GetText", GetText },
	{ "ClearError", ClearError },
	{ "Get_Text", Get_Text },
	{ "Set_Text", Set_Text },
	{ "Get_HintText", Get_HintText },
	{ "Get_IsReadOnly", Get_IsReadOnly },
	{ "Get_IsPassword", Get_IsPassword },
	{ "Get_MinimumDesiredWidth", Get_MinimumDesiredWidth },
	{ "Get_IsCaretMovedWhenGainFocus", Get_IsCaretMovedWhenGainFocus },
	{ "Get_SelectAllTextWhenFocused", Get_SelectAllTextWhenFocused },
	{ "Get_RevertTextOnEscape", Get_RevertTextOnEscape },
	{ "Get_ClearKeyboardFocusOnCommit", Get_ClearKeyboardFocusOnCommit },
	{ "Get_SelectAllTextOnCommit", Get_SelectAllTextOnCommit },
	{ "Get_AllowContextMenu", Get_AllowContextMenu },
	{ "Set_AllowContextMenu", Set_AllowContextMenu },
	{ "Get_KeyboardType", Get_KeyboardType },
	{ "Set_KeyboardType", Set_KeyboardType },
	{ "Get_VirtualKeyboardDismissAction", Get_VirtualKeyboardDismissAction },
	{ "Set_VirtualKeyboardDismissAction", Set_VirtualKeyboardDismissAction },
	{ "Get_Justification", Get_Justification },
	{ "Set_Justification", Set_Justification },
	{ "Call_OnTextChanged", Call_OnTextChanged },
	{ "Call_OnTextCommitted", Call_OnTextCommitted },
	{ "is_nil", wLua::LuaStatic::isnil },
	{ "__gc", wLua::LuaStatic::removeUClassFrameCache },
	{ NULL, NULL }
};

void Register(lua_State *InScriptContext)
{
	lua_newtable(InScriptContext);
	luaL_register(InScriptContext, NULL, Lib_Funcs);
	AzureHelpFuncs::AuxRegister(InScriptContext, "EditableTextBox");
}
void SetMtLink(lua_State *InScriptContext)
{
	AzureHelpFuncs::AuxSetMtLink(InScriptContext, "EditableTextBox", "Widget",USERDATATYPE_UOBJECT);
}

}