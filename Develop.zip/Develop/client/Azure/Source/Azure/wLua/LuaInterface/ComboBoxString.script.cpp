#include "Azure.h"
#include "Utility/help_funcs.h"
#include "wLua/UObjectHeaders.h"
#include "Components/ComboBoxString.h"
#include "AzureLuaIntegration.h"

namespace LuaComboBoxString
{
int32 SetSelectedOption(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ComboBoxString",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ComboBoxString must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FString Option;
	} Params;
	Params.Option = UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 2));
#if UE_GAME
	UComboBoxString * This = (UComboBoxString *)Obj;
	This->SetSelectedOption(Params.Option);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetSelectedOption"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FString*)(params.GetStructMemory() + 0) = Params.Option;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.Option = *(FString*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 RemoveOption(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ComboBoxString",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ComboBoxString must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FString Option;
		bool ReturnValue;
	} Params;
	Params.Option = UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 2));
#if UE_GAME
	UComboBoxString * This = (UComboBoxString *)Obj;
	Params.ReturnValue = This->RemoveOption(Params.Option);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("RemoveOption"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FString*)(params.GetStructMemory() + 0) = Params.Option;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.Option = *(FString*)(params.GetStructMemory() + 0);
		Params.ReturnValue = *(bool*)(params.GetStructMemory() + 16);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushboolean(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 RefreshOptions(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ComboBoxString",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ComboBoxString must be non-null"); lua_error(InScriptContext);  return 0;}
#if UE_GAME
	UComboBoxString * This = (UComboBoxString *)Obj;
	This->RefreshOptions();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("RefreshOptions"));
	if(!Function) { check(false); return 0;}
	Obj->ProcessEvent(Function, NULL);
#endif
	return 0;
}

int32 GetSelectedOption(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ComboBoxString",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ComboBoxString must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FString ReturnValue;
	} Params;
#if UE_GAME
	UComboBoxString * This = (UComboBoxString *)Obj;
	Params.ReturnValue = This->GetSelectedOption();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetSelectedOption"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(FString*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushstring(InScriptContext, TCHAR_TO_UTF8(*Params.ReturnValue));
	return 1;
}

int32 GetOptionCount(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ComboBoxString",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ComboBoxString must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		int32 ReturnValue;
	} Params;
#if UE_GAME
	UComboBoxString * This = (UComboBoxString *)Obj;
	Params.ReturnValue = This->GetOptionCount();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetOptionCount"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(int32*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushinteger(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetOptionAtIndex(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ComboBoxString",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ComboBoxString must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		int32 Index;
		FString ReturnValue;
	} Params;
	Params.Index = (luaL_checkint(InScriptContext, 2));
#if UE_GAME
	UComboBoxString * This = (UComboBoxString *)Obj;
	Params.ReturnValue = This->GetOptionAtIndex(Params.Index);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetOptionAtIndex"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(int32*)(params.GetStructMemory() + 0) = Params.Index;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.Index = *(int32*)(params.GetStructMemory() + 0);
		Params.ReturnValue = *(FString*)(params.GetStructMemory() + 8);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushstring(InScriptContext, TCHAR_TO_UTF8(*Params.ReturnValue));
	return 1;
}

int32 FindOptionIndex(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ComboBoxString",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ComboBoxString must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FString Option;
		int32 ReturnValue;
	} Params;
	Params.Option = UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 2));
#if UE_GAME
	UComboBoxString * This = (UComboBoxString *)Obj;
	Params.ReturnValue = This->FindOptionIndex(Params.Option);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("FindOptionIndex"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FString*)(params.GetStructMemory() + 0) = Params.Option;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.Option = *(FString*)(params.GetStructMemory() + 0);
		Params.ReturnValue = *(int32*)(params.GetStructMemory() + 16);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushinteger(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 ClearSelection(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ComboBoxString",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ComboBoxString must be non-null"); lua_error(InScriptContext);  return 0;}
#if UE_GAME
	UComboBoxString * This = (UComboBoxString *)Obj;
	This->ClearSelection();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("ClearSelection"));
	if(!Function) { check(false); return 0;}
	Obj->ProcessEvent(Function, NULL);
#endif
	return 0;
}

int32 ClearOptions(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ComboBoxString",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ComboBoxString must be non-null"); lua_error(InScriptContext);  return 0;}
#if UE_GAME
	UComboBoxString * This = (UComboBoxString *)Obj;
	This->ClearOptions();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("ClearOptions"));
	if(!Function) { check(false); return 0;}
	Obj->ProcessEvent(Function, NULL);
#endif
	return 0;
}

int32 AddOption(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ComboBoxString",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ComboBoxString must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FString Option;
	} Params;
	Params.Option = UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 2));
#if UE_GAME
	UComboBoxString * This = (UComboBoxString *)Obj;
	This->AddOption(Params.Option);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("AddOption"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FString*)(params.GetStructMemory() + 0) = Params.Option;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.Option = *(FString*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 Get_DefaultOptions(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ComboBoxString",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ComboBoxString must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UComboBoxString::StaticClass(), TEXT("DefaultOptions"));
	if(!Property) { check(false); return 0;}
	TArray<FString> PropertyValue;
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	{lua_newtable(InScriptContext); int i = 1; for(auto It = PropertyValue.CreateConstIterator(); It; ++It,++i) {  lua_pushstring(InScriptContext, TCHAR_TO_UTF8(*(*It))); lua_rawseti(InScriptContext,-2,i);     }  }
	return 1;
}

int32 Set_DefaultOptions(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ComboBoxString",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ComboBoxString must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UComboBoxString::StaticClass(), TEXT("DefaultOptions"));
	if(!Property) { check(false); return 0;}
	TArray<FString> PropertyValue = [](lua_State * _InScriptContext){ TArray<FString> ret; lua_pushnil(_InScriptContext); while(lua_next(_InScriptContext,2)!=0){ FString item = UTF8_TO_TCHAR(luaL_checkstring(_InScriptContext, -1)); ret.Add(item); lua_pop(_InScriptContext,1);  } return ret; }(InScriptContext);;
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_SelectedOption(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ComboBoxString",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ComboBoxString must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UComboBoxString::StaticClass(), TEXT("SelectedOption"));
	if(!Property) { check(false); return 0;}
	FString PropertyValue;
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushstring(InScriptContext, TCHAR_TO_UTF8(*PropertyValue));
	return 1;
}

int32 Set_SelectedOption(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ComboBoxString",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ComboBoxString must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UComboBoxString::StaticClass(), TEXT("SelectedOption"));
	if(!Property) { check(false); return 0;}
	FString PropertyValue = UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_MaxListHeight(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ComboBoxString",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ComboBoxString must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UComboBoxString::StaticClass(), TEXT("MaxListHeight"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_HasDownArrow(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ComboBoxString",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ComboBoxString must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UComboBoxString::StaticClass(), TEXT("HasDownArrow"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = bool();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_EnableGamepadNavigationMode(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ComboBoxString",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ComboBoxString must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UComboBoxString::StaticClass(), TEXT("EnableGamepadNavigationMode"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = bool();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_bIsFocusable(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ComboBoxString",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ComboBoxString must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UComboBoxString::StaticClass(), TEXT("bIsFocusable"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = bool();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Call_OnSelectionChanged(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ComboBoxString",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ComboBoxString must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FString SelectedItem;
		TEnumAsByte<ESelectInfo::Type> SelectionType;
	} Params;
	Params.SelectedItem = UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 2));
	Params.SelectionType = (TEnumAsByte<ESelectInfo::Type>)(luaL_checkint(InScriptContext, 3));
	UComboBoxString * This = (UComboBoxString *)Obj;
	This->OnSelectionChanged.Broadcast(Params.SelectedItem,Params.SelectionType);
	return 0;
}

int32 Call_OnOpening(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ComboBoxString",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ComboBoxString must be non-null"); lua_error(InScriptContext);  return 0;}
	UComboBoxString * This = (UComboBoxString *)Obj;
	This->OnOpening.Broadcast();
	return 0;
}

int32 New(lua_State* InScriptContext)
{
	UObject* Outer = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Object");
	FName Name = FName(luaL_checkstring(InScriptContext, 2));
	UObject* Obj = NewObject<UComboBoxString>(Outer, Name);
	wLua::FLuaUtils::ReturnUObject(InScriptContext,Obj);
	return 1;
}

int32 Destroy(lua_State* InScriptContext)
{
	return 0;
}

int32 Class(lua_State* InScriptContext)
{
	UClass* Class = UComboBoxString::StaticClass();
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Class);
	return 1;
}

const luaL_Reg Lib_Funcs[] =
{
	{ "New", New },
	{ "Destroy", Destroy },
	{ "Class", Class },
	{ "SetSelectedOption", SetSelectedOption },
	{ "RemoveOption", RemoveOption },
	{ "RefreshOptions", RefreshOptions },
	{ "GetSelectedOption", GetSelectedOption },
	{ "GetOptionCount", GetOptionCount },
	{ "GetOptionAtIndex", GetOptionAtIndex },
	{ "FindOptionIndex", FindOptionIndex },
	{ "ClearSelection", ClearSelection },
	{ "ClearOptions", ClearOptions },
	{ "AddOption", AddOption },
	{ "Get_DefaultOptions", Get_DefaultOptions },
	{ "Set_DefaultOptions", Set_DefaultOptions },
	{ "Get_SelectedOption", Get_SelectedOption },
	{ "Set_SelectedOption", Set_SelectedOption },
	{ "Get_MaxListHeight", Get_MaxListHeight },
	{ "Get_HasDownArrow", Get_HasDownArrow },
	{ "Get_EnableGamepadNavigationMode", Get_EnableGamepadNavigationMode },
	{ "Get_bIsFocusable", Get_bIsFocusable },
	{ "Call_OnSelectionChanged", Call_OnSelectionChanged },
	{ "Call_OnOpening", Call_OnOpening },
	{ "is_nil", wLua::LuaStatic::isnil },
	{ "__gc", wLua::LuaStatic::removeUClassFrameCache },
	{ NULL, NULL }
};

void Register(lua_State *InScriptContext)
{
	lua_newtable(InScriptContext);
	luaL_register(InScriptContext, NULL, Lib_Funcs);
	AzureHelpFuncs::AuxRegister(InScriptContext, "ComboBoxString");
}
void SetMtLink(lua_State *InScriptContext)
{
	AzureHelpFuncs::AuxSetMtLink(InScriptContext, "ComboBoxString", "Widget",USERDATATYPE_UOBJECT);
}

}