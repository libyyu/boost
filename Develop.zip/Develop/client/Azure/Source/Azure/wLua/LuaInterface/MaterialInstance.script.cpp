#include "Azure.h"
#include "Utility/help_funcs.h"
#include "wLua/UObjectHeaders.h"
#include "AzureLuaIntegration.h"

namespace LuaMaterialInstance
{
int32 Get_PhysMaterial(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MaterialInstance",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MaterialInstance must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UMaterialInstance::StaticClass(), TEXT("PhysMaterial"));
	if(!Property) { check(false); return 0;}
	UPhysicalMaterial* PropertyValue;
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaUtils::ReturnUObject(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_PhysMaterial(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MaterialInstance",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MaterialInstance must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UMaterialInstance::StaticClass(), TEXT("PhysMaterial"));
	if(!Property) { check(false); return 0;}
	UPhysicalMaterial* PropertyValue = (UPhysicalMaterial*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"PhysicalMaterial");;
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_Parent(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MaterialInstance",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MaterialInstance must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UMaterialInstance::StaticClass(), TEXT("Parent"));
	if(!Property) { check(false); return 0;}
	UMaterialInterface* PropertyValue;
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaUtils::ReturnUObject(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_bOverrideSubsurfaceProfile(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MaterialInstance",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MaterialInstance must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UMaterialInstance::StaticClass(), TEXT("bOverrideSubsurfaceProfile"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_bOverrideAzureExportWeatherQualityLevels(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MaterialInstance",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MaterialInstance must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UMaterialInstance::StaticClass(), TEXT("bOverrideAzureExportWeatherQualityLevels"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bOverrideAzureExportWeatherQualityLevels(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MaterialInstance",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MaterialInstance must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UMaterialInstance::StaticClass(), TEXT("bOverrideAzureExportWeatherQualityLevels"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_AzureExportWeatherQualityLevels(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MaterialInstance",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MaterialInstance must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UMaterialInstance::StaticClass(), TEXT("AzureExportWeatherQualityLevels"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_AzureExportWeatherQualityLevels(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MaterialInstance",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MaterialInstance must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UMaterialInstance::StaticClass(), TEXT("AzureExportWeatherQualityLevels"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Class(lua_State* InScriptContext)
{
	UClass* Class = UMaterialInstance::StaticClass();
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Class);
	return 1;
}

const luaL_Reg Lib_Funcs[] =
{
	{ "Class", Class },
	{ "Get_PhysMaterial", Get_PhysMaterial },
	{ "Set_PhysMaterial", Set_PhysMaterial },
	{ "Get_Parent", Get_Parent },
	{ "Get_bOverrideSubsurfaceProfile", Get_bOverrideSubsurfaceProfile },
	{ "Get_bOverrideAzureExportWeatherQualityLevels", Get_bOverrideAzureExportWeatherQualityLevels },
	{ "Set_bOverrideAzureExportWeatherQualityLevels", Set_bOverrideAzureExportWeatherQualityLevels },
	{ "Get_AzureExportWeatherQualityLevels", Get_AzureExportWeatherQualityLevels },
	{ "Set_AzureExportWeatherQualityLevels", Set_AzureExportWeatherQualityLevels },
	{ "is_nil", wLua::LuaStatic::isnil },
	{ "__gc", wLua::LuaStatic::removeUClassFrameCache },
	{ NULL, NULL }
};

void Register(lua_State *InScriptContext)
{
	lua_newtable(InScriptContext);
	luaL_register(InScriptContext, NULL, Lib_Funcs);
	AzureHelpFuncs::AuxRegister(InScriptContext, "MaterialInstance");
}
void SetMtLink(lua_State *InScriptContext)
{
	AzureHelpFuncs::AuxSetMtLink(InScriptContext, "MaterialInstance", "MaterialInterface",USERDATATYPE_UOBJECT);
}

}