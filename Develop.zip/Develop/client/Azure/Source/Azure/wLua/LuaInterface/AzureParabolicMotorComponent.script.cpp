#include "Azure.h"
#include "Utility/help_funcs.h"
#include "wLua/UObjectHeaders.h"
#include "AzureParabolicMotorComponent.h"
#include "AzureLuaIntegration.h"

namespace LuaAzureParabolicMotorComponent
{
int32 StartMove(lua_State*);

int32 SetExtraParam(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureParabolicMotorComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureParabolicMotorComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float _fVertSpeed;
		float _fVertAcc;
	} Params;
	Params._fVertSpeed = (float)(luaL_checknumber(InScriptContext, 2));
	Params._fVertAcc = (float)(luaL_checknumber(InScriptContext, 3));
#if UE_GAME
	UAzureParabolicMotorComponent * This = (UAzureParabolicMotorComponent *)Obj;
	This->SetExtraParam(Params._fVertSpeed,Params._fVertAcc);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetExtraParam"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(float*)(params.GetStructMemory() + 0) = Params._fVertSpeed;
		*(float*)(params.GetStructMemory() + 4) = Params._fVertAcc;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params._fVertSpeed = *(float*)(params.GetStructMemory() + 0);
		Params._fVertAcc = *(float*)(params.GetStructMemory() + 4);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 New(lua_State* InScriptContext)
{
	UObject* Outer = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Object");
	FName Name = FName(luaL_checkstring(InScriptContext, 2));
	UObject* Obj = NewObject<UAzureParabolicMotorComponent>(Outer, Name);
	wLua::FLuaUtils::ReturnUObject(InScriptContext,Obj);
	return 1;
}

int32 Destroy(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureParabolicMotorComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureParabolicMotorComponent must be non-null"); lua_error(InScriptContext);  return 0;}
		UActorComponent * com = Cast<UActorComponent>(Obj);
		if(lua_isnoneornil(InScriptContext,2))
			com->DestroyComponent();
		else
			com->DestroyComponent(!!lua_toboolean(InScriptContext,2));
		userdata->flag |= wLua::LuaObjectFlag::DESTROYED;
		wLua::FLuaUtils::RemoveObjectReference(Obj, userdata->stamp, InScriptContext);
#ifdef AZURE_BUILD_WLUACHECK
		UE_LOG(LogAzure, Warning, TEXT("Destroy AzureParabolicMotorComponent: %x userdata:%x   stamp:%x"),Obj,userdata,userdata->stamp);
#endif
	return 0;
}

int32 Class(lua_State* InScriptContext)
{
	UClass* Class = UAzureParabolicMotorComponent::StaticClass();
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Class);
	return 1;
}

const luaL_Reg Lib_Funcs[] =
{
	{ "New", New },
	{ "Destroy", Destroy },
	{ "Class", Class },
	{ "SetExtraParam", SetExtraParam },
	{ "StartMove", StartMove },
	{ "is_nil", wLua::LuaStatic::isnil },
	{ "__gc", wLua::LuaStatic::removeUClassFrameCache },
	{ NULL, NULL }
};

void Register(lua_State *InScriptContext)
{
	lua_newtable(InScriptContext);
	luaL_register(InScriptContext, NULL, Lib_Funcs);
	AzureHelpFuncs::AuxRegister(InScriptContext, "AzureParabolicMotorComponent");
}
void SetMtLink(lua_State *InScriptContext)
{
	AzureHelpFuncs::AuxSetMtLink(InScriptContext, "AzureParabolicMotorComponent", "AzureMotorComponent",USERDATATYPE_UOBJECT);
}

}