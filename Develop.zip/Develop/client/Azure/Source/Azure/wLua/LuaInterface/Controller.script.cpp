#include "Azure.h"
#include "Utility/help_funcs.h"
#include "wLua/UObjectHeaders.h"
#include "GameFramework/Controller.h"
#include "AzureLuaIntegration.h"

namespace LuaController
{
int32 UnPossess(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Controller",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Controller must be non-null"); lua_error(InScriptContext);  return 0;}
#if UE_GAME
	AController * This = (AController *)Obj;
	This->UnPossess();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("UnPossess"));
	if(!Function) { check(false); return 0;}
	Obj->ProcessEvent(Function, NULL);
#endif
	return 0;
}

int32 StopMovement(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Controller",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Controller must be non-null"); lua_error(InScriptContext);  return 0;}
#if UE_GAME
	AController * This = (AController *)Obj;
	This->StopMovement();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("StopMovement"));
	if(!Function) { check(false); return 0;}
	Obj->ProcessEvent(Function, NULL);
#endif
	return 0;
}

int32 SetInitialLocationAndRotation(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Controller",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Controller must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FVector NewLocation;
		FRotator NewRotation;
	} Params;
	Params.NewLocation = (wLua::FLuaVector::Get(InScriptContext, 2));
	Params.NewRotation = (wLua::FLuaRotator::Get(InScriptContext, 3));
#if UE_GAME
	AController * This = (AController *)Obj;
	This->SetInitialLocationAndRotation(Params.NewLocation,Params.NewRotation);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetInitialLocationAndRotation"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FVector*)(params.GetStructMemory() + 0) = Params.NewLocation;
		*(FRotator*)(params.GetStructMemory() + 12) = Params.NewRotation;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.NewLocation = *(FVector*)(params.GetStructMemory() + 0);
		Params.NewRotation = *(FRotator*)(params.GetStructMemory() + 12);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetIgnoreMoveInput(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Controller",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Controller must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool bNewMoveInput;
	} Params;
	Params.bNewMoveInput = !!(lua_toboolean(InScriptContext, 2));
#if UE_GAME
	AController * This = (AController *)Obj;
	This->SetIgnoreMoveInput(Params.bNewMoveInput);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetIgnoreMoveInput"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(bool*)(params.GetStructMemory() + 0) = Params.bNewMoveInput;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.bNewMoveInput = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetIgnoreLookInput(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Controller",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Controller must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool bNewLookInput;
	} Params;
	Params.bNewLookInput = !!(lua_toboolean(InScriptContext, 2));
#if UE_GAME
	AController * This = (AController *)Obj;
	This->SetIgnoreLookInput(Params.bNewLookInput);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetIgnoreLookInput"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(bool*)(params.GetStructMemory() + 0) = Params.bNewLookInput;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.bNewLookInput = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetControlRotation(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Controller",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Controller must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FRotator NewRotation;
	} Params;
	Params.NewRotation = (wLua::FLuaRotator::Get(InScriptContext, 2));
#if UE_GAME
	AController * This = (AController *)Obj;
	This->SetControlRotation(Params.NewRotation);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetControlRotation"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FRotator*)(params.GetStructMemory() + 0) = Params.NewRotation;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.NewRotation = *(FRotator*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 ResetIgnoreMoveInput(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Controller",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Controller must be non-null"); lua_error(InScriptContext);  return 0;}
#if UE_GAME
	AController * This = (AController *)Obj;
	This->ResetIgnoreMoveInput();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("ResetIgnoreMoveInput"));
	if(!Function) { check(false); return 0;}
	Obj->ProcessEvent(Function, NULL);
#endif
	return 0;
}

int32 ResetIgnoreLookInput(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Controller",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Controller must be non-null"); lua_error(InScriptContext);  return 0;}
#if UE_GAME
	AController * This = (AController *)Obj;
	This->ResetIgnoreLookInput();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("ResetIgnoreLookInput"));
	if(!Function) { check(false); return 0;}
	Obj->ProcessEvent(Function, NULL);
#endif
	return 0;
}

int32 ResetIgnoreInputFlags(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Controller",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Controller must be non-null"); lua_error(InScriptContext);  return 0;}
#if UE_GAME
	AController * This = (AController *)Obj;
	This->ResetIgnoreInputFlags();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("ResetIgnoreInputFlags"));
	if(!Function) { check(false); return 0;}
	Obj->ProcessEvent(Function, NULL);
#endif
	return 0;
}

int32 ReceiveInstigatedAnyDamage(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Controller",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Controller must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float Damage;
		UDamageType* DamageType = nullptr;
		AActor* DamagedActor = nullptr;
		AActor* DamageCauser = nullptr;
	} Params;
	Params.Damage = (float)(luaL_checknumber(InScriptContext, 2));
	Params.DamageType = (UDamageType*)wLua::FLuaUtils::GetUObject(InScriptContext,3,"DamageType");;
	Params.DamagedActor = (AActor*)wLua::FLuaUtils::GetUObject(InScriptContext,4,"Actor");;
	Params.DamageCauser = (AActor*)wLua::FLuaUtils::GetUObject(InScriptContext,5,"Actor");;
	UFunction* Function = Obj->FindFunctionChecked(TEXT("ReceiveInstigatedAnyDamage"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(float*)(params.GetStructMemory() + 0) = Params.Damage;
		*(UDamageType**)(params.GetStructMemory() + 8) = Params.DamageType;
		*(AActor**)(params.GetStructMemory() + 16) = Params.DamagedActor;
		*(AActor**)(params.GetStructMemory() + 24) = Params.DamageCauser;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.Damage = *(float*)(params.GetStructMemory() + 0);
		Params.DamageType = *(UDamageType**)(params.GetStructMemory() + 8);
		Params.DamagedActor = *(AActor**)(params.GetStructMemory() + 16);
		Params.DamageCauser = *(AActor**)(params.GetStructMemory() + 24);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
	return 0;
}

int32 Possess(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Controller",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Controller must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		APawn* InPawn = nullptr;
	} Params;
	Params.InPawn = (APawn*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"Pawn");;
#if UE_GAME
	AController * This = (AController *)Obj;
	This->Possess(Params.InPawn);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("Possess"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(APawn**)(params.GetStructMemory() + 0) = Params.InPawn;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.InPawn = *(APawn**)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 OnRep_PlayerState(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Controller",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Controller must be non-null"); lua_error(InScriptContext);  return 0;}
#if UE_GAME
	AController * This = (AController *)Obj;
	This->OnRep_PlayerState();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("OnRep_PlayerState"));
	if(!Function) { check(false); return 0;}
	Obj->ProcessEvent(Function, NULL);
#endif
	return 0;
}

int32 OnRep_Pawn(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Controller",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Controller must be non-null"); lua_error(InScriptContext);  return 0;}
#if UE_GAME
	AController * This = (AController *)Obj;
	This->OnRep_Pawn();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("OnRep_Pawn"));
	if(!Function) { check(false); return 0;}
	Obj->ProcessEvent(Function, NULL);
#endif
	return 0;
}

int32 LineOfSightTo(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Controller",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Controller must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		AActor* Other = nullptr;
		FVector ViewPoint;
		bool bAlternateChecks;
		bool ReturnValue;
	} Params;
	Params.Other = (AActor*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"Actor");;
	Params.ViewPoint = lua_isnoneornil(InScriptContext,3) ? FVector(0.f) : (wLua::FLuaVector::Get(InScriptContext, 3));
	Params.bAlternateChecks = lua_isnoneornil(InScriptContext,4) ? bool(false) : !!(lua_toboolean(InScriptContext, 4));
#if UE_GAME
	AController * This = (AController *)Obj;
	Params.ReturnValue = This->LineOfSightTo(Params.Other,Params.ViewPoint,Params.bAlternateChecks);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("LineOfSightTo"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(AActor**)(params.GetStructMemory() + 0) = Params.Other;
		*(FVector*)(params.GetStructMemory() + 8) = Params.ViewPoint;
		*(bool*)(params.GetStructMemory() + 20) = Params.bAlternateChecks;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.Other = *(AActor**)(params.GetStructMemory() + 0);
		Params.ViewPoint = *(FVector*)(params.GetStructMemory() + 8);
		Params.bAlternateChecks = *(bool*)(params.GetStructMemory() + 20);
		Params.ReturnValue = *(bool*)(params.GetStructMemory() + 21);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushboolean(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 K2_GetPawn(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Controller",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Controller must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		APawn* ReturnValue = nullptr;
	} Params;
#if UE_GAME
	AController * This = (AController *)Obj;
	Params.ReturnValue = This->K2_GetPawn();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("K2_GetPawn"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(APawn**)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 IsPlayerController(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Controller",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Controller must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool ReturnValue;
	} Params;
#if UE_GAME
	AController * This = (AController *)Obj;
	Params.ReturnValue = This->IsPlayerController();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("IsPlayerController"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushboolean(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 IsMoveInputIgnored(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Controller",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Controller must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool ReturnValue;
	} Params;
#if UE_GAME
	AController * This = (AController *)Obj;
	Params.ReturnValue = This->IsMoveInputIgnored();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("IsMoveInputIgnored"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushboolean(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 IsLookInputIgnored(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Controller",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Controller must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool ReturnValue;
	} Params;
#if UE_GAME
	AController * This = (AController *)Obj;
	Params.ReturnValue = This->IsLookInputIgnored();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("IsLookInputIgnored"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushboolean(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 IsLocalPlayerController(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Controller",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Controller must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool ReturnValue;
	} Params;
#if UE_GAME
	AController * This = (AController *)Obj;
	Params.ReturnValue = This->IsLocalPlayerController();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("IsLocalPlayerController"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushboolean(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 IsLocalController(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Controller",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Controller must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool ReturnValue;
	} Params;
#if UE_GAME
	AController * This = (AController *)Obj;
	Params.ReturnValue = This->IsLocalController();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("IsLocalController"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushboolean(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetViewTarget(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Controller",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Controller must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		AActor* ReturnValue = nullptr;
	} Params;
#if UE_GAME
	AController * This = (AController *)Obj;
	Params.ReturnValue = This->GetViewTarget();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetViewTarget"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(AActor**)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetDesiredRotation(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Controller",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Controller must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FRotator ReturnValue;
	} Params;
#if UE_GAME
	AController * This = (AController *)Obj;
	Params.ReturnValue = This->GetDesiredRotation();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetDesiredRotation"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(FRotator*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaRotator::Return(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetControlRotation(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Controller",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Controller must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FRotator ReturnValue;
	} Params;
#if UE_GAME
	AController * This = (AController *)Obj;
	Params.ReturnValue = This->GetControlRotation();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetControlRotation"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(FRotator*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaRotator::Return(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 ClientSetRotation(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Controller",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Controller must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FRotator NewRotation;
		bool bResetCamera;
	} Params;
	Params.NewRotation = (wLua::FLuaRotator::Get(InScriptContext, 2));
	Params.bResetCamera = !!(lua_toboolean(InScriptContext, 3));
#if UE_GAME
	AController * This = (AController *)Obj;
	This->ClientSetRotation(Params.NewRotation,Params.bResetCamera);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("ClientSetRotation"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FRotator*)(params.GetStructMemory() + 0) = Params.NewRotation;
		*(bool*)(params.GetStructMemory() + 12) = Params.bResetCamera;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.NewRotation = *(FRotator*)(params.GetStructMemory() + 0);
		Params.bResetCamera = *(bool*)(params.GetStructMemory() + 12);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 ClientSetLocation(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Controller",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Controller must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FVector NewLocation;
		FRotator NewRotation;
	} Params;
	Params.NewLocation = (wLua::FLuaVector::Get(InScriptContext, 2));
	Params.NewRotation = (wLua::FLuaRotator::Get(InScriptContext, 3));
#if UE_GAME
	AController * This = (AController *)Obj;
	This->ClientSetLocation(Params.NewLocation,Params.NewRotation);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("ClientSetLocation"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FVector*)(params.GetStructMemory() + 0) = Params.NewLocation;
		*(FRotator*)(params.GetStructMemory() + 12) = Params.NewRotation;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.NewLocation = *(FVector*)(params.GetStructMemory() + 0);
		Params.NewRotation = *(FRotator*)(params.GetStructMemory() + 12);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 Get_PlayerState(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Controller",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Controller must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AController::StaticClass(), TEXT("PlayerState"));
	if(!Property) { check(false); return 0;}
	APlayerState* PropertyValue;
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaUtils::ReturnUObject(InScriptContext, PropertyValue);
	return 1;
}

int32 Call_OnInstigatedAnyDamage(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Controller",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Controller must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float Damage;
		UDamageType* DamageType = nullptr;
		AActor* DamagedActor = nullptr;
		AActor* DamageCauser = nullptr;
	} Params;
	Params.Damage = (float)(luaL_checknumber(InScriptContext, 2));
	Params.DamageType = (UDamageType*)wLua::FLuaUtils::GetUObject(InScriptContext,3,"DamageType");;
	Params.DamagedActor = (AActor*)wLua::FLuaUtils::GetUObject(InScriptContext,4,"Actor");;
	Params.DamageCauser = (AActor*)wLua::FLuaUtils::GetUObject(InScriptContext,5,"Actor");;
	AController * This = (AController *)Obj;
	This->OnInstigatedAnyDamage.Broadcast(Params.Damage,Params.DamageType,Params.DamagedActor,Params.DamageCauser);
	return 0;
}

int32 Get_bAttachToPawn(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Controller",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Controller must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AController::StaticClass(), TEXT("bAttachToPawn"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bAttachToPawn(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Controller",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Controller must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AController::StaticClass(), TEXT("bAttachToPawn"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Class(lua_State* InScriptContext)
{
	UClass* Class = AController::StaticClass();
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Class);
	return 1;
}

const luaL_Reg Lib_Funcs[] =
{
	{ "Class", Class },
	{ "UnPossess", UnPossess },
	{ "StopMovement", StopMovement },
	{ "SetInitialLocationAndRotation", SetInitialLocationAndRotation },
	{ "SetIgnoreMoveInput", SetIgnoreMoveInput },
	{ "SetIgnoreLookInput", SetIgnoreLookInput },
	{ "SetControlRotation", SetControlRotation },
	{ "ResetIgnoreMoveInput", ResetIgnoreMoveInput },
	{ "ResetIgnoreLookInput", ResetIgnoreLookInput },
	{ "ResetIgnoreInputFlags", ResetIgnoreInputFlags },
	{ "ReceiveInstigatedAnyDamage", ReceiveInstigatedAnyDamage },
	{ "Possess", Possess },
	{ "OnRep_PlayerState", OnRep_PlayerState },
	{ "OnRep_Pawn", OnRep_Pawn },
	{ "LineOfSightTo", LineOfSightTo },
	{ "GetPawn", K2_GetPawn },
	{ "IsPlayerController", IsPlayerController },
	{ "IsMoveInputIgnored", IsMoveInputIgnored },
	{ "IsLookInputIgnored", IsLookInputIgnored },
	{ "IsLocalPlayerController", IsLocalPlayerController },
	{ "IsLocalController", IsLocalController },
	{ "GetViewTarget", GetViewTarget },
	{ "GetDesiredRotation", GetDesiredRotation },
	{ "GetControlRotation", GetControlRotation },
	{ "ClientSetRotation", ClientSetRotation },
	{ "ClientSetLocation", ClientSetLocation },
	{ "Get_PlayerState", Get_PlayerState },
	{ "Call_OnInstigatedAnyDamage", Call_OnInstigatedAnyDamage },
	{ "Get_bAttachToPawn", Get_bAttachToPawn },
	{ "Set_bAttachToPawn", Set_bAttachToPawn },
	{ "is_nil", wLua::LuaStatic::isnil },
	{ "__gc", wLua::LuaStatic::removeUClassFrameCache },
	{ NULL, NULL }
};

void Register(lua_State *InScriptContext)
{
	lua_newtable(InScriptContext);
	luaL_register(InScriptContext, NULL, Lib_Funcs);
	AzureHelpFuncs::AuxRegister(InScriptContext, "Controller");
}
void SetMtLink(lua_State *InScriptContext)
{
	AzureHelpFuncs::AuxSetMtLink(InScriptContext, "Controller", "Actor",USERDATATYPE_UOBJECT);
}

}