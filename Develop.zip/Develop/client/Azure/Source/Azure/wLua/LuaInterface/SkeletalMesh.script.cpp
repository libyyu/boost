#include "Azure.h"
#include "Utility/help_funcs.h"
#include "wLua/UObjectHeaders.h"
#include "Engine/SkeletalMesh.h"
#include "AzureLuaIntegration.h"

namespace LuaSkeletalMesh
{
int32 GetBoundsExtends(lua_State*);

int32 SetLODSettings(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SkeletalMesh",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SkeletalMesh must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		USkeletalMeshLODSettings* InLODSettings = nullptr;
	} Params;
	Params.InLODSettings = (USkeletalMeshLODSettings*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"SkeletalMeshLODSettings");;
#if UE_GAME
	USkeletalMesh * This = (USkeletalMesh *)Obj;
	This->SetLODSettings(Params.InLODSettings);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetLODSettings"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(USkeletalMeshLODSettings**)(params.GetStructMemory() + 0) = Params.InLODSettings;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.InLODSettings = *(USkeletalMeshLODSettings**)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 NumSockets(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SkeletalMesh",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SkeletalMesh must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		int32 ReturnValue;
	} Params;
#if UE_GAME
	USkeletalMesh * This = (USkeletalMesh *)Obj;
	Params.ReturnValue = This->NumSockets();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("NumSockets"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(int32*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushinteger(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 IsSectionUsingCloth(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SkeletalMesh",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SkeletalMesh must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		int32 InSectionIndex;
		bool bCheckCorrespondingSections;
		bool ReturnValue;
	} Params;
	Params.InSectionIndex = (luaL_checkint(InScriptContext, 2));
	Params.bCheckCorrespondingSections = lua_isnoneornil(InScriptContext,3) ? bool(true) : !!(lua_toboolean(InScriptContext, 3));
#if UE_GAME
	USkeletalMesh * This = (USkeletalMesh *)Obj;
	Params.ReturnValue = This->IsSectionUsingCloth(Params.InSectionIndex,Params.bCheckCorrespondingSections);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("IsSectionUsingCloth"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(int32*)(params.GetStructMemory() + 0) = Params.InSectionIndex;
		*(bool*)(params.GetStructMemory() + 4) = Params.bCheckCorrespondingSections;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.InSectionIndex = *(int32*)(params.GetStructMemory() + 0);
		Params.bCheckCorrespondingSections = *(bool*)(params.GetStructMemory() + 4);
		Params.ReturnValue = *(bool*)(params.GetStructMemory() + 5);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushboolean(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetSocketByIndex(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SkeletalMesh",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SkeletalMesh must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		int32 Index;
		USkeletalMeshSocket* ReturnValue = nullptr;
	} Params;
	Params.Index = (luaL_checkint(InScriptContext, 2));
#if UE_GAME
	USkeletalMesh * This = (USkeletalMesh *)Obj;
	Params.ReturnValue = This->GetSocketByIndex(Params.Index);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetSocketByIndex"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(int32*)(params.GetStructMemory() + 0) = Params.Index;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.Index = *(int32*)(params.GetStructMemory() + 0);
		Params.ReturnValue = *(USkeletalMeshSocket**)(params.GetStructMemory() + 8);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetNodeMappingContainer(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SkeletalMesh",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SkeletalMesh must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		UBlueprint* SourceAsset = nullptr;
		UNodeMappingContainer* ReturnValue = nullptr;
	} Params;
	Params.SourceAsset = (UBlueprint*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"Blueprint");;
#if UE_GAME
	USkeletalMesh * This = (USkeletalMesh *)Obj;
	Params.ReturnValue = This->GetNodeMappingContainer(Params.SourceAsset);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetNodeMappingContainer"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(UBlueprint**)(params.GetStructMemory() + 0) = Params.SourceAsset;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.SourceAsset = *(UBlueprint**)(params.GetStructMemory() + 0);
		Params.ReturnValue = *(UNodeMappingContainer**)(params.GetStructMemory() + 8);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 FindSocketAndIndex(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SkeletalMesh",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SkeletalMesh must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FName InSocketName;
		int32 OutIndex;
		USkeletalMeshSocket* ReturnValue = nullptr;
	} Params;
	Params.InSocketName = FName(UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 2)));
#if UE_GAME
	USkeletalMesh * This = (USkeletalMesh *)Obj;
	Params.ReturnValue = This->FindSocketAndIndex(Params.InSocketName,Params.OutIndex);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("FindSocketAndIndex"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FName*)(params.GetStructMemory() + 0) = Params.InSocketName;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.InSocketName = *(FName*)(params.GetStructMemory() + 0);
		Params.OutIndex = *(int32*)(params.GetStructMemory() + 12);
		Params.ReturnValue = *(USkeletalMeshSocket**)(params.GetStructMemory() + 16);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Params.ReturnValue);
	lua_pushinteger(InScriptContext, Params.OutIndex);
	return 2;
}

int32 FindSocket(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SkeletalMesh",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SkeletalMesh must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FName InSocketName;
		USkeletalMeshSocket* ReturnValue = nullptr;
	} Params;
	Params.InSocketName = FName(UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 2)));
#if UE_GAME
	USkeletalMesh * This = (USkeletalMesh *)Obj;
	Params.ReturnValue = This->FindSocket(Params.InSocketName);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("FindSocket"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FName*)(params.GetStructMemory() + 0) = Params.InSocketName;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.InSocketName = *(FName*)(params.GetStructMemory() + 0);
		Params.ReturnValue = *(USkeletalMeshSocket**)(params.GetStructMemory() + 16);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 Get_Skeleton(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SkeletalMesh",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SkeletalMesh must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USkeletalMesh::StaticClass(), TEXT("Skeleton"));
	if(!Property) { check(false); return 0;}
	USkeleton* PropertyValue;
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaUtils::ReturnUObject(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_PositiveBoundsExtension(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SkeletalMesh",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SkeletalMesh must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USkeletalMesh::StaticClass(), TEXT("PositiveBoundsExtension"));
	if(!Property) { check(false); return 0;}
	FVector PropertyValue = FVector();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaVector::Return(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_NegativeBoundsExtension(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SkeletalMesh",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SkeletalMesh must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USkeletalMesh::StaticClass(), TEXT("NegativeBoundsExtension"));
	if(!Property) { check(false); return 0;}
	FVector PropertyValue = FVector();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaVector::Return(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_LODSettings(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SkeletalMesh",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SkeletalMesh must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USkeletalMesh::StaticClass(), TEXT("LODSettings"));
	if(!Property) { check(false); return 0;}
	USkeletalMeshLODSettings* PropertyValue;
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaUtils::ReturnUObject(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_LODSettings(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SkeletalMesh",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SkeletalMesh must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USkeletalMesh::StaticClass(), TEXT("LODSettings"));
	if(!Property) { check(false); return 0;}
	USkeletalMeshLODSettings* PropertyValue = (USkeletalMeshLODSettings*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"SkeletalMeshLODSettings");;
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_SkelMirrorAxis(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SkeletalMesh",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SkeletalMesh must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USkeletalMesh::StaticClass(), TEXT("SkelMirrorAxis"));
	if(!Property) { check(false); return 0;}
	TEnumAsByte<EAxis::Type> PropertyValue = TEnumAsByte<EAxis::Type>();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushinteger(InScriptContext, (int)PropertyValue);
	return 1;
}

int32 Set_SkelMirrorAxis(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SkeletalMesh",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SkeletalMesh must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USkeletalMesh::StaticClass(), TEXT("SkelMirrorAxis"));
	if(!Property) { check(false); return 0;}
	TEnumAsByte<EAxis::Type> PropertyValue = (TEnumAsByte<EAxis::Type>)(luaL_checkint(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_SkelMirrorFlipAxis(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SkeletalMesh",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SkeletalMesh must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USkeletalMesh::StaticClass(), TEXT("SkelMirrorFlipAxis"));
	if(!Property) { check(false); return 0;}
	TEnumAsByte<EAxis::Type> PropertyValue = TEnumAsByte<EAxis::Type>();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushinteger(InScriptContext, (int)PropertyValue);
	return 1;
}

int32 Set_SkelMirrorFlipAxis(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SkeletalMesh",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SkeletalMesh must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USkeletalMesh::StaticClass(), TEXT("SkelMirrorFlipAxis"));
	if(!Property) { check(false); return 0;}
	TEnumAsByte<EAxis::Type> PropertyValue = (TEnumAsByte<EAxis::Type>)(luaL_checkint(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bUseFullPrecisionUVs(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SkeletalMesh",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SkeletalMesh must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USkeletalMesh::StaticClass(), TEXT("bUseFullPrecisionUVs"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bUseFullPrecisionUVs(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SkeletalMesh",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SkeletalMesh must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USkeletalMesh::StaticClass(), TEXT("bUseFullPrecisionUVs"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bAzureNeedsCPUAccess(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SkeletalMesh",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SkeletalMesh must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USkeletalMesh::StaticClass(), TEXT("bAzureNeedsCPUAccess"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bAzureNeedsCPUAccess(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SkeletalMesh",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SkeletalMesh must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USkeletalMesh::StaticClass(), TEXT("bAzureNeedsCPUAccess"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bUseHighPrecisionTangentBasis(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SkeletalMesh",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SkeletalMesh must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USkeletalMesh::StaticClass(), TEXT("bUseHighPrecisionTangentBasis"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bUseHighPrecisionTangentBasis(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SkeletalMesh",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SkeletalMesh must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USkeletalMesh::StaticClass(), TEXT("bUseHighPrecisionTangentBasis"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bEnablePerPolyCollision(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SkeletalMesh",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SkeletalMesh must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USkeletalMesh::StaticClass(), TEXT("bEnablePerPolyCollision"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bEnablePerPolyCollision(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SkeletalMesh",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SkeletalMesh must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USkeletalMesh::StaticClass(), TEXT("bEnablePerPolyCollision"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_PhysicsAsset(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SkeletalMesh",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SkeletalMesh must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USkeletalMesh::StaticClass(), TEXT("PhysicsAsset"));
	if(!Property) { check(false); return 0;}
	UPhysicsAsset* PropertyValue;
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaUtils::ReturnUObject(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_ShadowPhysicsAsset(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SkeletalMesh",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SkeletalMesh must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USkeletalMesh::StaticClass(), TEXT("ShadowPhysicsAsset"));
	if(!Property) { check(false); return 0;}
	UPhysicsAsset* PropertyValue;
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaUtils::ReturnUObject(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_NodeMappingData(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SkeletalMesh",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SkeletalMesh must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USkeletalMesh::StaticClass(), TEXT("NodeMappingData"));
	if(!Property) { check(false); return 0;}
	TArray<UNodeMappingContainer*> PropertyValue;
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	{lua_newtable(InScriptContext); int i = 1; for(auto It = PropertyValue.CreateConstIterator(); It; ++It,++i) {  wLua::FLuaUtils::ReturnUObject(InScriptContext, (*It)); lua_rawseti(InScriptContext,-2,i);     }  }
	return 1;
}

int32 Get_AssetImportData(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SkeletalMesh",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SkeletalMesh must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USkeletalMesh::StaticClass(), TEXT("AssetImportData"));
	if(!Property) { check(false); return 0;}
	UAssetImportData* PropertyValue;
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaUtils::ReturnUObject(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_AssetImportData(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SkeletalMesh",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SkeletalMesh must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USkeletalMesh::StaticClass(), TEXT("AssetImportData"));
	if(!Property) { check(false); return 0;}
	UAssetImportData* PropertyValue = (UAssetImportData*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"AssetImportData");;
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_ThumbnailInfo(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SkeletalMesh",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SkeletalMesh must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USkeletalMesh::StaticClass(), TEXT("ThumbnailInfo"));
	if(!Property) { check(false); return 0;}
	UThumbnailInfo* PropertyValue;
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaUtils::ReturnUObject(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_ThumbnailInfo(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SkeletalMesh",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SkeletalMesh must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USkeletalMesh::StaticClass(), TEXT("ThumbnailInfo"));
	if(!Property) { check(false); return 0;}
	UThumbnailInfo* PropertyValue = (UThumbnailInfo*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"ThumbnailInfo");;
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_MorphTargets(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SkeletalMesh",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SkeletalMesh must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USkeletalMesh::StaticClass(), TEXT("MorphTargets"));
	if(!Property) { check(false); return 0;}
	TArray<UMorphTarget*> PropertyValue;
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	{lua_newtable(InScriptContext); int i = 1; for(auto It = PropertyValue.CreateConstIterator(); It; ++It,++i) {  wLua::FLuaUtils::ReturnUObject(InScriptContext, (*It)); lua_rawseti(InScriptContext,-2,i);     }  }
	return 1;
}

int32 Set_MorphTargets(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SkeletalMesh",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SkeletalMesh must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USkeletalMesh::StaticClass(), TEXT("MorphTargets"));
	if(!Property) { check(false); return 0;}
	TArray<UMorphTarget*> PropertyValue = [](lua_State * _InScriptContext){ TArray<UMorphTarget*> ret; lua_pushnil(_InScriptContext); while(lua_next(_InScriptContext,2)!=0){ UMorphTarget* item = (UMorphTarget*)wLua::FLuaUtils::GetUObject(_InScriptContext,-1,"MorphTarget");; ret.Add(item); lua_pop(_InScriptContext,1);  } return ret; }(InScriptContext);;
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_PostProcessAnimBlueprint(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SkeletalMesh",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SkeletalMesh must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USkeletalMesh::StaticClass(), TEXT("PostProcessAnimBlueprint"));
	if(!Property) { check(false); return 0;}
	TSubclassOf<UAnimInstance>  PropertyValue = TSubclassOf<UAnimInstance> ();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaUtils::ReturnUObject(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_MeshClothingAssets(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SkeletalMesh",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SkeletalMesh must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USkeletalMesh::StaticClass(), TEXT("MeshClothingAssets"));
	if(!Property) { check(false); return 0;}
	TArray<UClothingAssetBase*> PropertyValue;
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	{lua_newtable(InScriptContext); int i = 1; for(auto It = PropertyValue.CreateConstIterator(); It; ++It,++i) {  wLua::FLuaUtils::ReturnUObject(InScriptContext, (*It)); lua_rawseti(InScriptContext,-2,i);     }  }
	return 1;
}

int32 Get_AssetUserData(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SkeletalMesh",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SkeletalMesh must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USkeletalMesh::StaticClass(), TEXT("AssetUserData"));
	if(!Property) { check(false); return 0;}
	TArray<UAssetUserData*> PropertyValue;
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	{lua_newtable(InScriptContext); int i = 1; for(auto It = PropertyValue.CreateConstIterator(); It; ++It,++i) {  wLua::FLuaUtils::ReturnUObject(InScriptContext, (*It)); lua_rawseti(InScriptContext,-2,i);     }  }
	return 1;
}

int32 Set_AssetUserData(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SkeletalMesh",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SkeletalMesh must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USkeletalMesh::StaticClass(), TEXT("AssetUserData"));
	if(!Property) { check(false); return 0;}
	TArray<UAssetUserData*> PropertyValue = [](lua_State * _InScriptContext){ TArray<UAssetUserData*> ret; lua_pushnil(_InScriptContext); while(lua_next(_InScriptContext,2)!=0){ UAssetUserData* item = (UAssetUserData*)wLua::FLuaUtils::GetUObject(_InScriptContext,-1,"AssetUserData");; ret.Add(item); lua_pop(_InScriptContext,1);  } return ret; }(InScriptContext);;
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 New(lua_State* InScriptContext)
{
	UObject* Outer = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Object");
	FName Name = FName(luaL_checkstring(InScriptContext, 2));
	UObject* Obj = NewObject<USkeletalMesh>(Outer, Name);
	wLua::FLuaUtils::ReturnUObject(InScriptContext,Obj);
	return 1;
}

int32 Destroy(lua_State* InScriptContext)
{
	return 0;
}

int32 Class(lua_State* InScriptContext)
{
	UClass* Class = USkeletalMesh::StaticClass();
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Class);
	return 1;
}

const luaL_Reg Lib_Funcs[] =
{
	{ "New", New },
	{ "Destroy", Destroy },
	{ "Class", Class },
	{ "SetLODSettings", SetLODSettings },
	{ "NumSockets", NumSockets },
	{ "IsSectionUsingCloth", IsSectionUsingCloth },
	{ "GetSocketByIndex", GetSocketByIndex },
	{ "GetNodeMappingContainer", GetNodeMappingContainer },
	{ "FindSocketAndIndex", FindSocketAndIndex },
	{ "FindSocket", FindSocket },
	{ "Get_Skeleton", Get_Skeleton },
	{ "Get_PositiveBoundsExtension", Get_PositiveBoundsExtension },
	{ "Get_NegativeBoundsExtension", Get_NegativeBoundsExtension },
	{ "Get_LODSettings", Get_LODSettings },
	{ "Set_LODSettings", Set_LODSettings },
	{ "Get_SkelMirrorAxis", Get_SkelMirrorAxis },
	{ "Set_SkelMirrorAxis", Set_SkelMirrorAxis },
	{ "Get_SkelMirrorFlipAxis", Get_SkelMirrorFlipAxis },
	{ "Set_SkelMirrorFlipAxis", Set_SkelMirrorFlipAxis },
	{ "Get_bUseFullPrecisionUVs", Get_bUseFullPrecisionUVs },
	{ "Set_bUseFullPrecisionUVs", Set_bUseFullPrecisionUVs },
	{ "Get_bAzureNeedsCPUAccess", Get_bAzureNeedsCPUAccess },
	{ "Set_bAzureNeedsCPUAccess", Set_bAzureNeedsCPUAccess },
	{ "Get_bUseHighPrecisionTangentBasis", Get_bUseHighPrecisionTangentBasis },
	{ "Set_bUseHighPrecisionTangentBasis", Set_bUseHighPrecisionTangentBasis },
	{ "Get_bEnablePerPolyCollision", Get_bEnablePerPolyCollision },
	{ "Set_bEnablePerPolyCollision", Set_bEnablePerPolyCollision },
	{ "Get_PhysicsAsset", Get_PhysicsAsset },
	{ "Get_ShadowPhysicsAsset", Get_ShadowPhysicsAsset },
	{ "Get_NodeMappingData", Get_NodeMappingData },
	{ "Get_AssetImportData", Get_AssetImportData },
	{ "Set_AssetImportData", Set_AssetImportData },
	{ "Get_ThumbnailInfo", Get_ThumbnailInfo },
	{ "Set_ThumbnailInfo", Set_ThumbnailInfo },
	{ "Get_MorphTargets", Get_MorphTargets },
	{ "Set_MorphTargets", Set_MorphTargets },
	{ "Get_PostProcessAnimBlueprint", Get_PostProcessAnimBlueprint },
	{ "Get_MeshClothingAssets", Get_MeshClothingAssets },
	{ "Get_AssetUserData", Get_AssetUserData },
	{ "Set_AssetUserData", Set_AssetUserData },
	{ "GetBoundsExtends", GetBoundsExtends },
	{ "is_nil", wLua::LuaStatic::isnil },
	{ "__gc", wLua::LuaStatic::removeUClassFrameCache },
	{ NULL, NULL }
};

void Register(lua_State *InScriptContext)
{
	lua_newtable(InScriptContext);
	luaL_register(InScriptContext, NULL, Lib_Funcs);
	AzureHelpFuncs::AuxRegister(InScriptContext, "SkeletalMesh");
}
void SetMtLink(lua_State *InScriptContext)
{
	AzureHelpFuncs::AuxSetMtLink(InScriptContext, "SkeletalMesh", "Object",USERDATATYPE_UOBJECT);
}

}