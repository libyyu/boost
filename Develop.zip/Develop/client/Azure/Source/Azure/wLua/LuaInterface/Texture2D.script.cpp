#include "Azure.h"
#include "Utility/help_funcs.h"
#include "wLua/UObjectHeaders.h"
#include "Engine/Texture2D.h"
#include "AzureLuaIntegration.h"

namespace LuaTexture2D
{
int32 Blueprint_GetSizeY(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Texture2D",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Texture2D must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		int32 ReturnValue;
	} Params;
#if UE_GAME
	UTexture2D * This = (UTexture2D *)Obj;
	Params.ReturnValue = This->Blueprint_GetSizeY();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("Blueprint_GetSizeY"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(int32*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushinteger(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 Blueprint_GetSizeX(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Texture2D",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Texture2D must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		int32 ReturnValue;
	} Params;
#if UE_GAME
	UTexture2D * This = (UTexture2D *)Obj;
	Params.ReturnValue = This->Blueprint_GetSizeX();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("Blueprint_GetSizeX"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(int32*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushinteger(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 Get_bGlobalForceMipLevelsToBeResident(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Texture2D",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Texture2D must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UTexture2D::StaticClass(), TEXT("bGlobalForceMipLevelsToBeResident"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_AddressX(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Texture2D",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Texture2D must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UTexture2D::StaticClass(), TEXT("AddressX"));
	if(!Property) { check(false); return 0;}
	TEnumAsByte<TextureAddress> PropertyValue = TEnumAsByte<TextureAddress>();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushinteger(InScriptContext, (int)PropertyValue);
	return 1;
}

int32 Set_AddressX(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Texture2D",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Texture2D must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UTexture2D::StaticClass(), TEXT("AddressX"));
	if(!Property) { check(false); return 0;}
	TEnumAsByte<TextureAddress> PropertyValue = (TEnumAsByte<TextureAddress>)(luaL_checkint(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_AddressY(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Texture2D",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Texture2D must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UTexture2D::StaticClass(), TEXT("AddressY"));
	if(!Property) { check(false); return 0;}
	TEnumAsByte<TextureAddress> PropertyValue = TEnumAsByte<TextureAddress>();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushinteger(InScriptContext, (int)PropertyValue);
	return 1;
}

int32 Set_AddressY(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Texture2D",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Texture2D must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UTexture2D::StaticClass(), TEXT("AddressY"));
	if(!Property) { check(false); return 0;}
	TEnumAsByte<TextureAddress> PropertyValue = (TEnumAsByte<TextureAddress>)(luaL_checkint(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 New(lua_State* InScriptContext)
{
	UObject* Outer = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Object");
	FName Name = FName(luaL_checkstring(InScriptContext, 2));
	UObject* Obj = NewObject<UTexture2D>(Outer, Name);
	wLua::FLuaUtils::ReturnUObject(InScriptContext,Obj);
	return 1;
}

int32 Destroy(lua_State* InScriptContext)
{
	return 0;
}

int32 Class(lua_State* InScriptContext)
{
	UClass* Class = UTexture2D::StaticClass();
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Class);
	return 1;
}

const luaL_Reg Lib_Funcs[] =
{
	{ "New", New },
	{ "Destroy", Destroy },
	{ "Class", Class },
	{ "Blueprint_GetSizeY", Blueprint_GetSizeY },
	{ "Blueprint_GetSizeX", Blueprint_GetSizeX },
	{ "Get_bGlobalForceMipLevelsToBeResident", Get_bGlobalForceMipLevelsToBeResident },
	{ "Get_AddressX", Get_AddressX },
	{ "Set_AddressX", Set_AddressX },
	{ "Get_AddressY", Get_AddressY },
	{ "Set_AddressY", Set_AddressY },
	{ "is_nil", wLua::LuaStatic::isnil },
	{ "__gc", wLua::LuaStatic::removeUClassFrameCache },
	{ NULL, NULL }
};

void Register(lua_State *InScriptContext)
{
	lua_newtable(InScriptContext);
	luaL_register(InScriptContext, NULL, Lib_Funcs);
	AzureHelpFuncs::AuxRegister(InScriptContext, "Texture2D");
}
void SetMtLink(lua_State *InScriptContext)
{
	AzureHelpFuncs::AuxSetMtLink(InScriptContext, "Texture2D", "Texture",USERDATATYPE_UOBJECT);
}

}