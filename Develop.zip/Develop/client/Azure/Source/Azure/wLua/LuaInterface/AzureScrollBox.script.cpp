#include "Azure.h"
#include "Utility/help_funcs.h"
#include "wLua/UObjectHeaders.h"
#include "AzureScrollBox.h"
#include "AzureLuaIntegration.h"

namespace LuaAzureScrollBox
{
int32 SetScrollOffset(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureScrollBox",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureScrollBox must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float NewScrollOffset;
	} Params;
	Params.NewScrollOffset = (float)(luaL_checknumber(InScriptContext, 2));
#if UE_GAME
	UAzureScrollBox * This = (UAzureScrollBox *)Obj;
	This->SetScrollOffset(Params.NewScrollOffset);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetScrollOffset"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(float*)(params.GetStructMemory() + 0) = Params.NewScrollOffset;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.NewScrollOffset = *(float*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 ScrollWidgetIntoView(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureScrollBox",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureScrollBox must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		UWidget* WidgetToFind = nullptr;
		bool AnimateScroll;
		EDescendantScrollDestination ScrollDestination;
	} Params;
	Params.WidgetToFind = (UWidget*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"Widget");;
	Params.AnimateScroll = lua_isnoneornil(InScriptContext,3) ? bool(true) : !!(lua_toboolean(InScriptContext, 3));
	Params.ScrollDestination = lua_isnoneornil(InScriptContext,4) ? EDescendantScrollDestination(EDescendantScrollDestination::IntoView) : (EDescendantScrollDestination)(luaL_checkint(InScriptContext, 4));
#if UE_GAME
	UAzureScrollBox * This = (UAzureScrollBox *)Obj;
	This->ScrollWidgetIntoView(Params.WidgetToFind,Params.AnimateScroll,Params.ScrollDestination);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("ScrollWidgetIntoView"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(UWidget**)(params.GetStructMemory() + 0) = Params.WidgetToFind;
		*(bool*)(params.GetStructMemory() + 8) = Params.AnimateScroll;
		*(EDescendantScrollDestination*)(params.GetStructMemory() + 9) = Params.ScrollDestination;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.WidgetToFind = *(UWidget**)(params.GetStructMemory() + 0);
		Params.AnimateScroll = *(bool*)(params.GetStructMemory() + 8);
		Params.ScrollDestination = *(EDescendantScrollDestination*)(params.GetStructMemory() + 9);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 ScrollToStart(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureScrollBox",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureScrollBox must be non-null"); lua_error(InScriptContext);  return 0;}
#if UE_GAME
	UAzureScrollBox * This = (UAzureScrollBox *)Obj;
	This->ScrollToStart();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("ScrollToStart"));
	if(!Function) { check(false); return 0;}
	Obj->ProcessEvent(Function, NULL);
#endif
	return 0;
}

int32 ScrollToEnd(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureScrollBox",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureScrollBox must be non-null"); lua_error(InScriptContext);  return 0;}
#if UE_GAME
	UAzureScrollBox * This = (UAzureScrollBox *)Obj;
	This->ScrollToEnd();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("ScrollToEnd"));
	if(!Function) { check(false); return 0;}
	Obj->ProcessEvent(Function, NULL);
#endif
	return 0;
}

int32 GetScrollOffset(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureScrollBox",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureScrollBox must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float ReturnValue;
	} Params;
#if UE_GAME
	UAzureScrollBox * This = (UAzureScrollBox *)Obj;
	Params.ReturnValue = This->GetScrollOffset();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetScrollOffset"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(float*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushnumber(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 Get_Orientation(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureScrollBox",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureScrollBox must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzureScrollBox::StaticClass(), TEXT("Orientation"));
	if(!Property) { check(false); return 0;}
	TEnumAsByte<EOrientation> PropertyValue = TEnumAsByte<EOrientation>();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushinteger(InScriptContext, (int)PropertyValue);
	return 1;
}

int32 Get_ScrollBarVisibility(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureScrollBox",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureScrollBox must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzureScrollBox::StaticClass(), TEXT("ScrollBarVisibility"));
	if(!Property) { check(false); return 0;}
	ESlateVisibility PropertyValue = ESlateVisibility();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushinteger(InScriptContext, (int)PropertyValue);
	return 1;
}

int32 Get_ConsumeMouseWheel(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureScrollBox",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureScrollBox must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzureScrollBox::StaticClass(), TEXT("ConsumeMouseWheel"));
	if(!Property) { check(false); return 0;}
	EConsumeMouseWheel PropertyValue = EConsumeMouseWheel();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushinteger(InScriptContext, (int)PropertyValue);
	return 1;
}

int32 Get_ScrollbarThickness(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureScrollBox",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureScrollBox must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzureScrollBox::StaticClass(), TEXT("ScrollbarThickness"));
	if(!Property) { check(false); return 0;}
	FVector2D PropertyValue = FVector2D();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaVector2D::Return(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_AlwaysShowScrollbar(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureScrollBox",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureScrollBox must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzureScrollBox::StaticClass(), TEXT("AlwaysShowScrollbar"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = bool();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_AllowOverscroll(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureScrollBox",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureScrollBox must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzureScrollBox::StaticClass(), TEXT("AllowOverscroll"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = bool();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_UsePhysicalOverscroll(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureScrollBox",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureScrollBox must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzureScrollBox::StaticClass(), TEXT("UsePhysicalOverscroll"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = bool();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_Looseness(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureScrollBox",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureScrollBox must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzureScrollBox::StaticClass(), TEXT("Looseness"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_OvershootLooseMax(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureScrollBox",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureScrollBox must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzureScrollBox::StaticClass(), TEXT("OvershootLooseMax"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_OvershootBounceRate(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureScrollBox",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureScrollBox must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzureScrollBox::StaticClass(), TEXT("OvershootBounceRate"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_bScrollEvent(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureScrollBox",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureScrollBox must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzureScrollBox::StaticClass(), TEXT("bScrollEvent"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = bool();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_bPageView(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureScrollBox",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureScrollBox must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzureScrollBox::StaticClass(), TEXT("bPageView"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = bool();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_PageSize(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureScrollBox",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureScrollBox must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzureScrollBox::StaticClass(), TEXT("PageSize"));
	if(!Property) { check(false); return 0;}
	int32 PropertyValue = int32();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushinteger(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_PageViewMinimumVelocity(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureScrollBox",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureScrollBox must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzureScrollBox::StaticClass(), TEXT("PageViewMinimumVelocity"));
	if(!Property) { check(false); return 0;}
	int32 PropertyValue = int32();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushinteger(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_MinimumInertialVelocity(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureScrollBox",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureScrollBox must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzureScrollBox::StaticClass(), TEXT("MinimumInertialVelocity"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_MinimumInertialVelocity(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureScrollBox",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureScrollBox must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzureScrollBox::StaticClass(), TEXT("MinimumInertialVelocity"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_AnimateScrollVelocity(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureScrollBox",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureScrollBox must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzureScrollBox::StaticClass(), TEXT("AnimateScrollVelocity"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_AnimateScrollVelocity(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureScrollBox",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureScrollBox must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzureScrollBox::StaticClass(), TEXT("AnimateScrollVelocity"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bIsNeedCaptureMovementAxisAligned(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureScrollBox",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureScrollBox must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzureScrollBox::StaticClass(), TEXT("bIsNeedCaptureMovementAxisAligned"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = bool();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_ScrollDragTriggerDistance(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureScrollBox",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureScrollBox must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzureScrollBox::StaticClass(), TEXT("ScrollDragTriggerDistance"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_ScrollDragTriggerDistance(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureScrollBox",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureScrollBox must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzureScrollBox::StaticClass(), TEXT("ScrollDragTriggerDistance"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 New(lua_State* InScriptContext)
{
	UObject* Outer = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Object");
	FName Name = FName(luaL_checkstring(InScriptContext, 2));
	UObject* Obj = NewObject<UAzureScrollBox>(Outer, Name);
	wLua::FLuaUtils::ReturnUObject(InScriptContext,Obj);
	return 1;
}

int32 Destroy(lua_State* InScriptContext)
{
	return 0;
}

int32 Class(lua_State* InScriptContext)
{
	UClass* Class = UAzureScrollBox::StaticClass();
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Class);
	return 1;
}

const luaL_Reg Lib_Funcs[] =
{
	{ "New", New },
	{ "Destroy", Destroy },
	{ "Class", Class },
	{ "SetScrollOffset", SetScrollOffset },
	{ "ScrollWidgetIntoView", ScrollWidgetIntoView },
	{ "ScrollToStart", ScrollToStart },
	{ "ScrollToEnd", ScrollToEnd },
	{ "GetScrollOffset", GetScrollOffset },
	{ "Get_Orientation", Get_Orientation },
	{ "Get_ScrollBarVisibility", Get_ScrollBarVisibility },
	{ "Get_ConsumeMouseWheel", Get_ConsumeMouseWheel },
	{ "Get_ScrollbarThickness", Get_ScrollbarThickness },
	{ "Get_AlwaysShowScrollbar", Get_AlwaysShowScrollbar },
	{ "Get_AllowOverscroll", Get_AllowOverscroll },
	{ "Get_UsePhysicalOverscroll", Get_UsePhysicalOverscroll },
	{ "Get_Looseness", Get_Looseness },
	{ "Get_OvershootLooseMax", Get_OvershootLooseMax },
	{ "Get_OvershootBounceRate", Get_OvershootBounceRate },
	{ "Get_bScrollEvent", Get_bScrollEvent },
	{ "Get_bPageView", Get_bPageView },
	{ "Get_PageSize", Get_PageSize },
	{ "Get_PageViewMinimumVelocity", Get_PageViewMinimumVelocity },
	{ "Get_MinimumInertialVelocity", Get_MinimumInertialVelocity },
	{ "Set_MinimumInertialVelocity", Set_MinimumInertialVelocity },
	{ "Get_AnimateScrollVelocity", Get_AnimateScrollVelocity },
	{ "Set_AnimateScrollVelocity", Set_AnimateScrollVelocity },
	{ "Get_bIsNeedCaptureMovementAxisAligned", Get_bIsNeedCaptureMovementAxisAligned },
	{ "Get_ScrollDragTriggerDistance", Get_ScrollDragTriggerDistance },
	{ "Set_ScrollDragTriggerDistance", Set_ScrollDragTriggerDistance },
	{ "is_nil", wLua::LuaStatic::isnil },
	{ "__gc", wLua::LuaStatic::removeUClassFrameCache },
	{ NULL, NULL }
};

void Register(lua_State *InScriptContext)
{
	lua_newtable(InScriptContext);
	luaL_register(InScriptContext, NULL, Lib_Funcs);
	AzureHelpFuncs::AuxRegister(InScriptContext, "AzureScrollBox");
}
void SetMtLink(lua_State *InScriptContext)
{
	AzureHelpFuncs::AuxSetMtLink(InScriptContext, "AzureScrollBox", "PanelWidget",USERDATATYPE_UOBJECT);
}

}