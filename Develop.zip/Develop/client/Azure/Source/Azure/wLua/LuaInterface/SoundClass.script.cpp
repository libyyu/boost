#include "Azure.h"
#include "Utility/help_funcs.h"
#include "wLua/UObjectHeaders.h"
#include "Sound/SoundClass.h"
#include "AzureLuaIntegration.h"

namespace LuaSoundClass
{
int32 Get_ChildClasses(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SoundClass",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SoundClass must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USoundClass::StaticClass(), TEXT("ChildClasses"));
	if(!Property) { check(false); return 0;}
	TArray<USoundClass*> PropertyValue;
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	{lua_newtable(InScriptContext); int i = 1; for(auto It = PropertyValue.CreateConstIterator(); It; ++It,++i) {  wLua::FLuaUtils::ReturnUObject(InScriptContext, (*It)); lua_rawseti(InScriptContext,-2,i);     }  }
	return 1;
}

int32 New(lua_State* InScriptContext)
{
	UObject* Outer = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Object");
	FName Name = FName(luaL_checkstring(InScriptContext, 2));
	UObject* Obj = NewObject<USoundClass>(Outer, Name);
	wLua::FLuaUtils::ReturnUObject(InScriptContext,Obj);
	return 1;
}

int32 Destroy(lua_State* InScriptContext)
{
	return 0;
}

int32 Class(lua_State* InScriptContext)
{
	UClass* Class = USoundClass::StaticClass();
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Class);
	return 1;
}

const luaL_Reg Lib_Funcs[] =
{
	{ "New", New },
	{ "Destroy", Destroy },
	{ "Class", Class },
	{ "Get_ChildClasses", Get_ChildClasses },
	{ "is_nil", wLua::LuaStatic::isnil },
	{ "__gc", wLua::LuaStatic::removeUClassFrameCache },
	{ NULL, NULL }
};

void Register(lua_State *InScriptContext)
{
	lua_newtable(InScriptContext);
	luaL_register(InScriptContext, NULL, Lib_Funcs);
	AzureHelpFuncs::AuxRegister(InScriptContext, "SoundClass");
}
void SetMtLink(lua_State *InScriptContext)
{
	AzureHelpFuncs::AuxSetMtLink(InScriptContext, "SoundClass", "Object",USERDATATYPE_UOBJECT);
}

}