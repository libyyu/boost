#include "Azure.h"
#include "Utility/help_funcs.h"
#include "wLua/UObjectHeaders.h"
#include "GameFramework/PlayerController.h"
#include "AzureLuaIntegration.h"

namespace LuaPlayerController
{
int32 DeprojectMousePositionToWorld2(lua_State*);
int32 DeprojectScreenPositionToWorld2(lua_State*);
int32 GetPlayerViewPoint(lua_State*);
int32 IsInputKeyDown(lua_State*);
int32 LoadTouchInterface(lua_State*);

int32 ToggleSpeaking(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PlayerController",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PlayerController must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool bInSpeaking;
	} Params;
	Params.bInSpeaking = !!(lua_toboolean(InScriptContext, 2));
#if UE_GAME
	APlayerController * This = (APlayerController *)Obj;
	This->ToggleSpeaking(Params.bInSpeaking);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("ToggleSpeaking"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(bool*)(params.GetStructMemory() + 0) = Params.bInSpeaking;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.bInSpeaking = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SwitchLevel(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PlayerController",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PlayerController must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FString URL;
	} Params;
	Params.URL = UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 2));
#if UE_GAME
	APlayerController * This = (APlayerController *)Obj;
	This->SwitchLevel(Params.URL);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SwitchLevel"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FString*)(params.GetStructMemory() + 0) = Params.URL;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.URL = *(FString*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 StopHapticEffect(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PlayerController",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PlayerController must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		EControllerHand Hand;
	} Params;
	Params.Hand = (EControllerHand)(luaL_checkint(InScriptContext, 2));
#if UE_GAME
	APlayerController * This = (APlayerController *)Obj;
	This->StopHapticEffect(Params.Hand);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("StopHapticEffect"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(EControllerHand*)(params.GetStructMemory() + 0) = Params.Hand;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.Hand = *(EControllerHand*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 StartFire(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PlayerController",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PlayerController must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		uint8 FireModeNum;
	} Params;
	Params.FireModeNum = lua_isnoneornil(InScriptContext,2) ? uint8(0) : (uint8)(luaL_checkint(InScriptContext, 2));
#if UE_GAME
	APlayerController * This = (APlayerController *)Obj;
	This->StartFire(Params.FireModeNum);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("StartFire"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(uint8*)(params.GetStructMemory() + 0) = Params.FireModeNum;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.FireModeNum = *(uint8*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetVirtualJoystickVisibility(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PlayerController",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PlayerController must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool bVisible;
	} Params;
	Params.bVisible = !!(lua_toboolean(InScriptContext, 2));
#if UE_GAME
	APlayerController * This = (APlayerController *)Obj;
	This->SetVirtualJoystickVisibility(Params.bVisible);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetVirtualJoystickVisibility"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(bool*)(params.GetStructMemory() + 0) = Params.bVisible;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.bVisible = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetVirtualJoystickPreventReCenter(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PlayerController",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PlayerController must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool bPreventReCenter;
	} Params;
	Params.bPreventReCenter = !!(lua_toboolean(InScriptContext, 2));
#if UE_GAME
	APlayerController * This = (APlayerController *)Obj;
	This->SetVirtualJoystickPreventReCenter(Params.bPreventReCenter);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetVirtualJoystickPreventReCenter"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(bool*)(params.GetStructMemory() + 0) = Params.bPreventReCenter;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.bPreventReCenter = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetViewTargetWithBlend(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PlayerController",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PlayerController must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		AActor* NewViewTarget = nullptr;
		float BlendTime;
		TEnumAsByte<EViewTargetBlendFunction> BlendFunc;
		float BlendExp;
		bool bLockOutgoing;
	} Params;
	Params.NewViewTarget = (AActor*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"Actor");;
	Params.BlendTime = lua_isnoneornil(InScriptContext,3) ? float(0.000000) : (float)(luaL_checknumber(InScriptContext, 3));
	Params.BlendFunc = lua_isnoneornil(InScriptContext,4) ? TEnumAsByte<EViewTargetBlendFunction>(EViewTargetBlendFunction::VTBlend_Linear) : (TEnumAsByte<EViewTargetBlendFunction>)(luaL_checkint(InScriptContext, 4));
	Params.BlendExp = lua_isnoneornil(InScriptContext,5) ? float(0.000000) : (float)(luaL_checknumber(InScriptContext, 5));
	Params.bLockOutgoing = lua_isnoneornil(InScriptContext,6) ? bool(false) : !!(lua_toboolean(InScriptContext, 6));
#if UE_GAME
	APlayerController * This = (APlayerController *)Obj;
	This->SetViewTargetWithBlend(Params.NewViewTarget,Params.BlendTime,Params.BlendFunc,Params.BlendExp,Params.bLockOutgoing);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetViewTargetWithBlend"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(AActor**)(params.GetStructMemory() + 0) = Params.NewViewTarget;
		*(float*)(params.GetStructMemory() + 8) = Params.BlendTime;
		*(TEnumAsByte<EViewTargetBlendFunction>*)(params.GetStructMemory() + 12) = Params.BlendFunc;
		*(float*)(params.GetStructMemory() + 16) = Params.BlendExp;
		*(bool*)(params.GetStructMemory() + 20) = Params.bLockOutgoing;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.NewViewTarget = *(AActor**)(params.GetStructMemory() + 0);
		Params.BlendTime = *(float*)(params.GetStructMemory() + 8);
		Params.BlendFunc = *(TEnumAsByte<EViewTargetBlendFunction>*)(params.GetStructMemory() + 12);
		Params.BlendExp = *(float*)(params.GetStructMemory() + 16);
		Params.bLockOutgoing = *(bool*)(params.GetStructMemory() + 20);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetName(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PlayerController",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PlayerController must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FString S;
	} Params;
	Params.S = UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 2));
#if UE_GAME
	APlayerController * This = (APlayerController *)Obj;
	This->SetName(Params.S);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetName"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FString*)(params.GetStructMemory() + 0) = Params.S;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.S = *(FString*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetMouseLocation(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PlayerController",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PlayerController must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		int32 X;
		int32 Y;
	} Params;
	Params.X = (luaL_checkint(InScriptContext, 2));
	Params.Y = (luaL_checkint(InScriptContext, 3));
#if UE_GAME
	APlayerController * This = (APlayerController *)Obj;
	This->SetMouseLocation(Params.X,Params.Y);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetMouseLocation"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(int32*)(params.GetStructMemory() + 0) = Params.X;
		*(int32*)(params.GetStructMemory() + 4) = Params.Y;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.X = *(int32*)(params.GetStructMemory() + 0);
		Params.Y = *(int32*)(params.GetStructMemory() + 4);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetMouseCursorWidget(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PlayerController",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PlayerController must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		TEnumAsByte<EMouseCursor::Type> Cursor;
		UUserWidget* CursorWidget = nullptr;
	} Params;
	Params.Cursor = (TEnumAsByte<EMouseCursor::Type>)(luaL_checkint(InScriptContext, 2));
	Params.CursorWidget = (UUserWidget*)wLua::FLuaUtils::GetUObject(InScriptContext,3,"UserWidget");;
#if UE_GAME
	APlayerController * This = (APlayerController *)Obj;
	This->SetMouseCursorWidget(Params.Cursor,Params.CursorWidget);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetMouseCursorWidget"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(TEnumAsByte<EMouseCursor::Type>*)(params.GetStructMemory() + 0) = Params.Cursor;
		*(UUserWidget**)(params.GetStructMemory() + 8) = Params.CursorWidget;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.Cursor = *(TEnumAsByte<EMouseCursor::Type>*)(params.GetStructMemory() + 0);
		Params.CursorWidget = *(UUserWidget**)(params.GetStructMemory() + 8);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetHapticsByValue(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PlayerController",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PlayerController must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float Frequency;
		float Amplitude;
		EControllerHand Hand;
	} Params;
	Params.Frequency = (float)(luaL_checknumber(InScriptContext, 2));
	Params.Amplitude = (float)(luaL_checknumber(InScriptContext, 3));
	Params.Hand = (EControllerHand)(luaL_checkint(InScriptContext, 4));
#if UE_GAME
	APlayerController * This = (APlayerController *)Obj;
	This->SetHapticsByValue(Params.Frequency,Params.Amplitude,Params.Hand);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetHapticsByValue"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(float*)(params.GetStructMemory() + 0) = Params.Frequency;
		*(float*)(params.GetStructMemory() + 4) = Params.Amplitude;
		*(EControllerHand*)(params.GetStructMemory() + 8) = Params.Hand;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.Frequency = *(float*)(params.GetStructMemory() + 0);
		Params.Amplitude = *(float*)(params.GetStructMemory() + 4);
		Params.Hand = *(EControllerHand*)(params.GetStructMemory() + 8);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetDisableHaptics(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PlayerController",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PlayerController must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool bNewDisabled;
	} Params;
	Params.bNewDisabled = !!(lua_toboolean(InScriptContext, 2));
#if UE_GAME
	APlayerController * This = (APlayerController *)Obj;
	This->SetDisableHaptics(Params.bNewDisabled);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetDisableHaptics"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(bool*)(params.GetStructMemory() + 0) = Params.bNewDisabled;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.bNewDisabled = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetControllerLightColor(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PlayerController",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PlayerController must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FColor Color;
	} Params;
	Params.Color = (wLua::FLuaLinearColor::GetColor(InScriptContext, 2));
#if UE_GAME
	APlayerController * This = (APlayerController *)Obj;
	This->SetControllerLightColor(Params.Color);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetControllerLightColor"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FColor*)(params.GetStructMemory() + 0) = Params.Color;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.Color = *(FColor*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetCinematicMode(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PlayerController",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PlayerController must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool bInCinematicMode;
		bool bHidePlayer;
		bool bAffectsHUD;
		bool bAffectsMovement;
		bool bAffectsTurning;
	} Params;
	Params.bInCinematicMode = !!(lua_toboolean(InScriptContext, 2));
	Params.bHidePlayer = !!(lua_toboolean(InScriptContext, 3));
	Params.bAffectsHUD = !!(lua_toboolean(InScriptContext, 4));
	Params.bAffectsMovement = !!(lua_toboolean(InScriptContext, 5));
	Params.bAffectsTurning = !!(lua_toboolean(InScriptContext, 6));
#if UE_GAME
	APlayerController * This = (APlayerController *)Obj;
	This->SetCinematicMode(Params.bInCinematicMode,Params.bHidePlayer,Params.bAffectsHUD,Params.bAffectsMovement,Params.bAffectsTurning);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetCinematicMode"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(bool*)(params.GetStructMemory() + 0) = Params.bInCinematicMode;
		*(bool*)(params.GetStructMemory() + 1) = Params.bHidePlayer;
		*(bool*)(params.GetStructMemory() + 2) = Params.bAffectsHUD;
		*(bool*)(params.GetStructMemory() + 3) = Params.bAffectsMovement;
		*(bool*)(params.GetStructMemory() + 4) = Params.bAffectsTurning;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.bInCinematicMode = *(bool*)(params.GetStructMemory() + 0);
		Params.bHidePlayer = *(bool*)(params.GetStructMemory() + 1);
		Params.bAffectsHUD = *(bool*)(params.GetStructMemory() + 2);
		Params.bAffectsMovement = *(bool*)(params.GetStructMemory() + 3);
		Params.bAffectsTurning = *(bool*)(params.GetStructMemory() + 4);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetAudioListenerOverride(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PlayerController",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PlayerController must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		USceneComponent* AttachToComponent = nullptr;
		FVector Location;
		FRotator Rotation;
	} Params;
	Params.AttachToComponent = (USceneComponent*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"SceneComponent");;
	Params.Location = (wLua::FLuaVector::Get(InScriptContext, 3));
	Params.Rotation = (wLua::FLuaRotator::Get(InScriptContext, 4));
#if UE_GAME
	APlayerController * This = (APlayerController *)Obj;
	This->SetAudioListenerOverride(Params.AttachToComponent,Params.Location,Params.Rotation);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetAudioListenerOverride"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(USceneComponent**)(params.GetStructMemory() + 0) = Params.AttachToComponent;
		*(FVector*)(params.GetStructMemory() + 8) = Params.Location;
		*(FRotator*)(params.GetStructMemory() + 20) = Params.Rotation;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.AttachToComponent = *(USceneComponent**)(params.GetStructMemory() + 0);
		Params.Location = *(FVector*)(params.GetStructMemory() + 8);
		Params.Rotation = *(FRotator*)(params.GetStructMemory() + 20);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetAudioListenerAttenuationOverride(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PlayerController",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PlayerController must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		USceneComponent* AttachToComponent = nullptr;
		FVector AttenuationLocationOVerride;
	} Params;
	Params.AttachToComponent = (USceneComponent*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"SceneComponent");;
	Params.AttenuationLocationOVerride = (wLua::FLuaVector::Get(InScriptContext, 3));
#if UE_GAME
	APlayerController * This = (APlayerController *)Obj;
	This->SetAudioListenerAttenuationOverride(Params.AttachToComponent,Params.AttenuationLocationOVerride);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetAudioListenerAttenuationOverride"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(USceneComponent**)(params.GetStructMemory() + 0) = Params.AttachToComponent;
		*(FVector*)(params.GetStructMemory() + 8) = Params.AttenuationLocationOVerride;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.AttachToComponent = *(USceneComponent**)(params.GetStructMemory() + 0);
		Params.AttenuationLocationOVerride = *(FVector*)(params.GetStructMemory() + 8);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 ServerViewPrevPlayer(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PlayerController",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PlayerController must be non-null"); lua_error(InScriptContext);  return 0;}
#if UE_GAME
	APlayerController * This = (APlayerController *)Obj;
	This->ServerViewPrevPlayer();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("ServerViewPrevPlayer"));
	if(!Function) { check(false); return 0;}
	Obj->ProcessEvent(Function, NULL);
#endif
	return 0;
}

int32 ServerViewNextPlayer(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PlayerController",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PlayerController must be non-null"); lua_error(InScriptContext);  return 0;}
#if UE_GAME
	APlayerController * This = (APlayerController *)Obj;
	This->ServerViewNextPlayer();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("ServerViewNextPlayer"));
	if(!Function) { check(false); return 0;}
	Obj->ProcessEvent(Function, NULL);
#endif
	return 0;
}

int32 ServerVerifyViewTarget(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PlayerController",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PlayerController must be non-null"); lua_error(InScriptContext);  return 0;}
#if UE_GAME
	APlayerController * This = (APlayerController *)Obj;
	This->ServerVerifyViewTarget();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("ServerVerifyViewTarget"));
	if(!Function) { check(false); return 0;}
	Obj->ProcessEvent(Function, NULL);
#endif
	return 0;
}

int32 ServerUpdateLevelVisibility(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PlayerController",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PlayerController must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FName PackageName;
		bool bIsVisible;
	} Params;
	Params.PackageName = FName(UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 2)));
	Params.bIsVisible = !!(lua_toboolean(InScriptContext, 3));
#if UE_GAME
	APlayerController * This = (APlayerController *)Obj;
	This->ServerUpdateLevelVisibility(Params.PackageName,Params.bIsVisible);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("ServerUpdateLevelVisibility"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FName*)(params.GetStructMemory() + 0) = Params.PackageName;
		*(bool*)(params.GetStructMemory() + 12) = Params.bIsVisible;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.PackageName = *(FName*)(params.GetStructMemory() + 0);
		Params.bIsVisible = *(bool*)(params.GetStructMemory() + 12);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 ServerToggleAILogging(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PlayerController",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PlayerController must be non-null"); lua_error(InScriptContext);  return 0;}
#if UE_GAME
	APlayerController * This = (APlayerController *)Obj;
	This->ServerToggleAILogging();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("ServerToggleAILogging"));
	if(!Function) { check(false); return 0;}
	Obj->ProcessEvent(Function, NULL);
#endif
	return 0;
}

int32 ServerShortTimeout(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PlayerController",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PlayerController must be non-null"); lua_error(InScriptContext);  return 0;}
#if UE_GAME
	APlayerController * This = (APlayerController *)Obj;
	This->ServerShortTimeout();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("ServerShortTimeout"));
	if(!Function) { check(false); return 0;}
	Obj->ProcessEvent(Function, NULL);
#endif
	return 0;
}

int32 ServerSetSpectatorWaiting(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PlayerController",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PlayerController must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool bWaiting;
	} Params;
	Params.bWaiting = !!(lua_toboolean(InScriptContext, 2));
#if UE_GAME
	APlayerController * This = (APlayerController *)Obj;
	This->ServerSetSpectatorWaiting(Params.bWaiting);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("ServerSetSpectatorWaiting"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(bool*)(params.GetStructMemory() + 0) = Params.bWaiting;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.bWaiting = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 ServerSetSpectatorLocation(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PlayerController",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PlayerController must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FVector NewLoc;
		FRotator NewRot;
	} Params;
	Params.NewLoc = (wLua::FLuaVector::Get(InScriptContext, 2));
	Params.NewRot = (wLua::FLuaRotator::Get(InScriptContext, 3));
#if UE_GAME
	APlayerController * This = (APlayerController *)Obj;
	This->ServerSetSpectatorLocation(Params.NewLoc,Params.NewRot);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("ServerSetSpectatorLocation"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FVector*)(params.GetStructMemory() + 0) = Params.NewLoc;
		*(FRotator*)(params.GetStructMemory() + 12) = Params.NewRot;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.NewLoc = *(FVector*)(params.GetStructMemory() + 0);
		Params.NewRot = *(FRotator*)(params.GetStructMemory() + 12);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 ServerRestartPlayer(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PlayerController",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PlayerController must be non-null"); lua_error(InScriptContext);  return 0;}
#if UE_GAME
	APlayerController * This = (APlayerController *)Obj;
	This->ServerRestartPlayer();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("ServerRestartPlayer"));
	if(!Function) { check(false); return 0;}
	Obj->ProcessEvent(Function, NULL);
#endif
	return 0;
}

int32 ServerPause(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PlayerController",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PlayerController must be non-null"); lua_error(InScriptContext);  return 0;}
#if UE_GAME
	APlayerController * This = (APlayerController *)Obj;
	This->ServerPause();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("ServerPause"));
	if(!Function) { check(false); return 0;}
	Obj->ProcessEvent(Function, NULL);
#endif
	return 0;
}

int32 ServerNotifyLoadedWorld(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PlayerController",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PlayerController must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FName WorldPackageName;
	} Params;
	Params.WorldPackageName = FName(UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 2)));
#if UE_GAME
	APlayerController * This = (APlayerController *)Obj;
	This->ServerNotifyLoadedWorld(Params.WorldPackageName);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("ServerNotifyLoadedWorld"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FName*)(params.GetStructMemory() + 0) = Params.WorldPackageName;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.WorldPackageName = *(FName*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 ServerCheckClientPossessionReliable(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PlayerController",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PlayerController must be non-null"); lua_error(InScriptContext);  return 0;}
#if UE_GAME
	APlayerController * This = (APlayerController *)Obj;
	This->ServerCheckClientPossessionReliable();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("ServerCheckClientPossessionReliable"));
	if(!Function) { check(false); return 0;}
	Obj->ProcessEvent(Function, NULL);
#endif
	return 0;
}

int32 ServerCheckClientPossession(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PlayerController",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PlayerController must be non-null"); lua_error(InScriptContext);  return 0;}
#if UE_GAME
	APlayerController * This = (APlayerController *)Obj;
	This->ServerCheckClientPossession();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("ServerCheckClientPossession"));
	if(!Function) { check(false); return 0;}
	Obj->ProcessEvent(Function, NULL);
#endif
	return 0;
}

int32 ServerChangeName(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PlayerController",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PlayerController must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FString S;
	} Params;
	Params.S = UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 2));
#if UE_GAME
	APlayerController * This = (APlayerController *)Obj;
	This->ServerChangeName(Params.S);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("ServerChangeName"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FString*)(params.GetStructMemory() + 0) = Params.S;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.S = *(FString*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 ServerCamera(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PlayerController",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PlayerController must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FName NewMode;
	} Params;
	Params.NewMode = FName(UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 2)));
#if UE_GAME
	APlayerController * This = (APlayerController *)Obj;
	This->ServerCamera(Params.NewMode);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("ServerCamera"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FName*)(params.GetStructMemory() + 0) = Params.NewMode;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.NewMode = *(FName*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 ServerAcknowledgePossession(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PlayerController",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PlayerController must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		APawn* P = nullptr;
	} Params;
	Params.P = (APawn*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"Pawn");;
#if UE_GAME
	APlayerController * This = (APlayerController *)Obj;
	This->ServerAcknowledgePossession(Params.P);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("ServerAcknowledgePossession"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(APawn**)(params.GetStructMemory() + 0) = Params.P;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.P = *(APawn**)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SendToConsole(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PlayerController",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PlayerController must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FString Command;
	} Params;
	Params.Command = UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 2));
#if UE_GAME
	APlayerController * This = (APlayerController *)Obj;
	This->SendToConsole(Params.Command);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SendToConsole"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FString*)(params.GetStructMemory() + 0) = Params.Command;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.Command = *(FString*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 RestartLevel(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PlayerController",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PlayerController must be non-null"); lua_error(InScriptContext);  return 0;}
#if UE_GAME
	APlayerController * This = (APlayerController *)Obj;
	This->RestartLevel();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("RestartLevel"));
	if(!Function) { check(false); return 0;}
	Obj->ProcessEvent(Function, NULL);
#endif
	return 0;
}

int32 RemoveHiddenComponent(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PlayerController",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PlayerController must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		UPrimitiveComponent* InComponent = nullptr;
	} Params;
	Params.InComponent = (UPrimitiveComponent*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"PrimitiveComponent");;
#if UE_GAME
	APlayerController * This = (APlayerController *)Obj;
	This->RemoveHiddenComponent(Params.InComponent);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("RemoveHiddenComponent"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(UPrimitiveComponent**)(params.GetStructMemory() + 0) = Params.InComponent;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.InComponent = *(UPrimitiveComponent**)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 ProjectWorldLocationToScreen(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PlayerController",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PlayerController must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FVector WorldLocation;
		FVector2D ScreenLocation;
		bool bPlayerViewportRelative;
		bool ReturnValue;
	} Params;
	Params.WorldLocation = (wLua::FLuaVector::Get(InScriptContext, 2));
	Params.bPlayerViewportRelative = lua_isnoneornil(InScriptContext,4) ? bool(false) : !!(lua_toboolean(InScriptContext, 4));
#if UE_GAME
	APlayerController * This = (APlayerController *)Obj;
	Params.ReturnValue = This->ProjectWorldLocationToScreen(Params.WorldLocation,Params.ScreenLocation,Params.bPlayerViewportRelative);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("ProjectWorldLocationToScreen"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FVector*)(params.GetStructMemory() + 0) = Params.WorldLocation;
		*(bool*)(params.GetStructMemory() + 20) = Params.bPlayerViewportRelative;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.WorldLocation = *(FVector*)(params.GetStructMemory() + 0);
		Params.ScreenLocation = *(FVector2D*)(params.GetStructMemory() + 12);
		Params.bPlayerViewportRelative = *(bool*)(params.GetStructMemory() + 20);
		Params.ReturnValue = *(bool*)(params.GetStructMemory() + 21);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushboolean(InScriptContext, Params.ReturnValue);
	wLua::FLuaVector2D::Return(InScriptContext, Params.ScreenLocation);
	return 2;
}

int32 PlayHapticEffect(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PlayerController",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PlayerController must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		UHapticFeedbackEffect_Base* HapticEffect = nullptr;
		EControllerHand Hand;
		float Scale;
		bool bLoop;
	} Params;
	Params.HapticEffect = (UHapticFeedbackEffect_Base*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"HapticFeedbackEffect_Base");;
	Params.Hand = (EControllerHand)(luaL_checkint(InScriptContext, 3));
	Params.Scale = lua_isnoneornil(InScriptContext,4) ? float(1.000000) : (float)(luaL_checknumber(InScriptContext, 4));
	Params.bLoop = lua_isnoneornil(InScriptContext,5) ? bool(false) : !!(lua_toboolean(InScriptContext, 5));
#if UE_GAME
	APlayerController * This = (APlayerController *)Obj;
	This->PlayHapticEffect(Params.HapticEffect,Params.Hand,Params.Scale,Params.bLoop);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("PlayHapticEffect"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(UHapticFeedbackEffect_Base**)(params.GetStructMemory() + 0) = Params.HapticEffect;
		*(EControllerHand*)(params.GetStructMemory() + 8) = Params.Hand;
		*(float*)(params.GetStructMemory() + 12) = Params.Scale;
		*(bool*)(params.GetStructMemory() + 16) = Params.bLoop;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.HapticEffect = *(UHapticFeedbackEffect_Base**)(params.GetStructMemory() + 0);
		Params.Hand = *(EControllerHand*)(params.GetStructMemory() + 8);
		Params.Scale = *(float*)(params.GetStructMemory() + 12);
		Params.bLoop = *(bool*)(params.GetStructMemory() + 16);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 Pause(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PlayerController",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PlayerController must be non-null"); lua_error(InScriptContext);  return 0;}
#if UE_GAME
	APlayerController * This = (APlayerController *)Obj;
	This->Pause();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("Pause"));
	if(!Function) { check(false); return 0;}
	Obj->ProcessEvent(Function, NULL);
#endif
	return 0;
}

int32 OnServerStartedVisualLogger(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PlayerController",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PlayerController must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool bIsLogging;
	} Params;
	Params.bIsLogging = !!(lua_toboolean(InScriptContext, 2));
#if UE_GAME
	APlayerController * This = (APlayerController *)Obj;
	This->OnServerStartedVisualLogger(Params.bIsLogging);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("OnServerStartedVisualLogger"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(bool*)(params.GetStructMemory() + 0) = Params.bIsLogging;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.bIsLogging = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 LocalTravel(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PlayerController",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PlayerController must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FString URL;
	} Params;
	Params.URL = UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 2));
#if UE_GAME
	APlayerController * This = (APlayerController *)Obj;
	This->LocalTravel(Params.URL);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("LocalTravel"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FString*)(params.GetStructMemory() + 0) = Params.URL;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.URL = *(FString*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 HiddenComponent(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PlayerController",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PlayerController must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		UPrimitiveComponent* InComponent = nullptr;
	} Params;
	Params.InComponent = (UPrimitiveComponent*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"PrimitiveComponent");;
#if UE_GAME
	APlayerController * This = (APlayerController *)Obj;
	This->HiddenComponent(Params.InComponent);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("HiddenComponent"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(UPrimitiveComponent**)(params.GetStructMemory() + 0) = Params.InComponent;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.InComponent = *(UPrimitiveComponent**)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 GetVirtualJoystickCurrentCenterPos(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PlayerController",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PlayerController must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		int32 InControlIdx;
		FVector2D OutCenterPos;
		FVector2D OutPressDownCenterPos;
		FVector2D OutLastTouchScreenPosition;
	} Params;
	Params.InControlIdx = (luaL_checkint(InScriptContext, 2));
#if UE_GAME
	APlayerController * This = (APlayerController *)Obj;
	This->GetVirtualJoystickCurrentCenterPos(Params.InControlIdx,Params.OutCenterPos,Params.OutPressDownCenterPos,Params.OutLastTouchScreenPosition);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetVirtualJoystickCurrentCenterPos"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(int32*)(params.GetStructMemory() + 0) = Params.InControlIdx;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.InControlIdx = *(int32*)(params.GetStructMemory() + 0);
		Params.OutCenterPos = *(FVector2D*)(params.GetStructMemory() + 4);
		Params.OutPressDownCenterPos = *(FVector2D*)(params.GetStructMemory() + 12);
		Params.OutLastTouchScreenPosition = *(FVector2D*)(params.GetStructMemory() + 20);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaVector2D::Return(InScriptContext, Params.OutCenterPos);
	wLua::FLuaVector2D::Return(InScriptContext, Params.OutPressDownCenterPos);
	wLua::FLuaVector2D::Return(InScriptContext, Params.OutLastTouchScreenPosition);
	return 3;
}

int32 GetViewportSize(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PlayerController",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PlayerController must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		int32 SizeX;
		int32 SizeY;
	} Params;
#if UE_GAME
	APlayerController * This = (APlayerController *)Obj;
	This->GetViewportSize(Params.SizeX,Params.SizeY);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetViewportSize"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.SizeX = *(int32*)(params.GetStructMemory() + 0);
		Params.SizeY = *(int32*)(params.GetStructMemory() + 4);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushinteger(InScriptContext, Params.SizeX);
	lua_pushinteger(InScriptContext, Params.SizeY);
	return 2;
}

int32 GetSpectatorPawn(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PlayerController",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PlayerController must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		ASpectatorPawn* ReturnValue = nullptr;
	} Params;
#if UE_GAME
	APlayerController * This = (APlayerController *)Obj;
	Params.ReturnValue = This->GetSpectatorPawn();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetSpectatorPawn"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(ASpectatorPawn**)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetMousePosition(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PlayerController",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PlayerController must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float LocationX;
		float LocationY;
		bool ReturnValue;
	} Params;
#if UE_GAME
	APlayerController * This = (APlayerController *)Obj;
	Params.ReturnValue = This->GetMousePosition(Params.LocationX,Params.LocationY);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetMousePosition"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.LocationX = *(float*)(params.GetStructMemory() + 0);
		Params.LocationY = *(float*)(params.GetStructMemory() + 4);
		Params.ReturnValue = *(bool*)(params.GetStructMemory() + 8);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushboolean(InScriptContext, Params.ReturnValue);
	lua_pushnumber(InScriptContext, Params.LocationX);
	lua_pushnumber(InScriptContext, Params.LocationY);
	return 3;
}

int32 GetInputTouchState(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PlayerController",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PlayerController must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		TEnumAsByte<ETouchIndex::Type> FingerIndex;
		float LocationX;
		float LocationY;
		bool bIsCurrentlyPressed;
	} Params;
	Params.FingerIndex = (TEnumAsByte<ETouchIndex::Type>)(luaL_checkint(InScriptContext, 2));
#if UE_GAME
	APlayerController * This = (APlayerController *)Obj;
	This->GetInputTouchState(Params.FingerIndex,Params.LocationX,Params.LocationY,Params.bIsCurrentlyPressed);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetInputTouchState"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(TEnumAsByte<ETouchIndex::Type>*)(params.GetStructMemory() + 0) = Params.FingerIndex;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.FingerIndex = *(TEnumAsByte<ETouchIndex::Type>*)(params.GetStructMemory() + 0);
		Params.LocationX = *(float*)(params.GetStructMemory() + 4);
		Params.LocationY = *(float*)(params.GetStructMemory() + 8);
		Params.bIsCurrentlyPressed = *(bool*)(params.GetStructMemory() + 12);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushnumber(InScriptContext, Params.LocationX);
	lua_pushnumber(InScriptContext, Params.LocationY);
	lua_pushboolean(InScriptContext, Params.bIsCurrentlyPressed);
	return 3;
}

int32 GetInputMouseDelta(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PlayerController",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PlayerController must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float DeltaX;
		float DeltaY;
	} Params;
#if UE_GAME
	APlayerController * This = (APlayerController *)Obj;
	This->GetInputMouseDelta(Params.DeltaX,Params.DeltaY);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetInputMouseDelta"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.DeltaX = *(float*)(params.GetStructMemory() + 0);
		Params.DeltaY = *(float*)(params.GetStructMemory() + 4);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushnumber(InScriptContext, Params.DeltaX);
	lua_pushnumber(InScriptContext, Params.DeltaY);
	return 2;
}

int32 GetInputMotionState(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PlayerController",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PlayerController must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FVector Tilt;
		FVector RotationRate;
		FVector Gravity;
		FVector Acceleration;
	} Params;
#if UE_GAME
	APlayerController * This = (APlayerController *)Obj;
	This->GetInputMotionState(Params.Tilt,Params.RotationRate,Params.Gravity,Params.Acceleration);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetInputMotionState"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.Tilt = *(FVector*)(params.GetStructMemory() + 0);
		Params.RotationRate = *(FVector*)(params.GetStructMemory() + 12);
		Params.Gravity = *(FVector*)(params.GetStructMemory() + 24);
		Params.Acceleration = *(FVector*)(params.GetStructMemory() + 36);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaVector::Return(InScriptContext, Params.Tilt);
	wLua::FLuaVector::Return(InScriptContext, Params.RotationRate);
	wLua::FLuaVector::Return(InScriptContext, Params.Gravity);
	wLua::FLuaVector::Return(InScriptContext, Params.Acceleration);
	return 4;
}

int32 GetInputAnalogStickState(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PlayerController",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PlayerController must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		TEnumAsByte<EControllerAnalogStick::Type> WhichStick;
		float StickX;
		float StickY;
	} Params;
	Params.WhichStick = (TEnumAsByte<EControllerAnalogStick::Type>)(luaL_checkint(InScriptContext, 2));
#if UE_GAME
	APlayerController * This = (APlayerController *)Obj;
	This->GetInputAnalogStickState(Params.WhichStick,Params.StickX,Params.StickY);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetInputAnalogStickState"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(TEnumAsByte<EControllerAnalogStick::Type>*)(params.GetStructMemory() + 0) = Params.WhichStick;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.WhichStick = *(TEnumAsByte<EControllerAnalogStick::Type>*)(params.GetStructMemory() + 0);
		Params.StickX = *(float*)(params.GetStructMemory() + 4);
		Params.StickY = *(float*)(params.GetStructMemory() + 8);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushnumber(InScriptContext, Params.StickX);
	lua_pushnumber(InScriptContext, Params.StickY);
	return 2;
}

int32 GetHUD(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PlayerController",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PlayerController must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		AHUD* ReturnValue = nullptr;
	} Params;
#if UE_GAME
	APlayerController * This = (APlayerController *)Obj;
	Params.ReturnValue = This->GetHUD();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetHUD"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(AHUD**)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetFocalLocation(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PlayerController",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PlayerController must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FVector ReturnValue;
	} Params;
#if UE_GAME
	APlayerController * This = (APlayerController *)Obj;
	Params.ReturnValue = This->GetFocalLocation();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetFocalLocation"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(FVector*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaVector::Return(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetCurrentTouchInterface(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PlayerController",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PlayerController must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		UTouchInterface* ReturnValue = nullptr;
	} Params;
#if UE_GAME
	APlayerController * This = (APlayerController *)Obj;
	Params.ReturnValue = This->GetCurrentTouchInterface();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetCurrentTouchInterface"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(UTouchInterface**)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 FOV(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PlayerController",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PlayerController must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float NewFOV;
	} Params;
	Params.NewFOV = (float)(luaL_checknumber(InScriptContext, 2));
#if UE_GAME
	APlayerController * This = (APlayerController *)Obj;
	This->FOV(Params.NewFOV);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("FOV"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(float*)(params.GetStructMemory() + 0) = Params.NewFOV;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.NewFOV = *(float*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 EnableCheats(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PlayerController",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PlayerController must be non-null"); lua_error(InScriptContext);  return 0;}
#if UE_GAME
	APlayerController * This = (APlayerController *)Obj;
	This->EnableCheats();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("EnableCheats"));
	if(!Function) { check(false); return 0;}
	Obj->ProcessEvent(Function, NULL);
#endif
	return 0;
}

int32 DeprojectScreenPositionToWorld(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PlayerController",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PlayerController must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float ScreenX;
		float ScreenY;
		FVector WorldLocation;
		FVector WorldDirection;
		bool ReturnValue;
	} Params;
	Params.ScreenX = (float)(luaL_checknumber(InScriptContext, 2));
	Params.ScreenY = (float)(luaL_checknumber(InScriptContext, 3));
#if UE_GAME
	APlayerController * This = (APlayerController *)Obj;
	Params.ReturnValue = This->DeprojectScreenPositionToWorld(Params.ScreenX,Params.ScreenY,Params.WorldLocation,Params.WorldDirection);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("DeprojectScreenPositionToWorld"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(float*)(params.GetStructMemory() + 0) = Params.ScreenX;
		*(float*)(params.GetStructMemory() + 4) = Params.ScreenY;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ScreenX = *(float*)(params.GetStructMemory() + 0);
		Params.ScreenY = *(float*)(params.GetStructMemory() + 4);
		Params.WorldLocation = *(FVector*)(params.GetStructMemory() + 8);
		Params.WorldDirection = *(FVector*)(params.GetStructMemory() + 20);
		Params.ReturnValue = *(bool*)(params.GetStructMemory() + 32);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushboolean(InScriptContext, Params.ReturnValue);
	wLua::FLuaVector::Return(InScriptContext, Params.WorldLocation);
	wLua::FLuaVector::Return(InScriptContext, Params.WorldDirection);
	return 3;
}

int32 DeprojectMousePositionToWorld(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PlayerController",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PlayerController must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FVector WorldLocation;
		FVector WorldDirection;
		bool ReturnValue;
	} Params;
#if UE_GAME
	APlayerController * This = (APlayerController *)Obj;
	Params.ReturnValue = This->DeprojectMousePositionToWorld(Params.WorldLocation,Params.WorldDirection);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("DeprojectMousePositionToWorld"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.WorldLocation = *(FVector*)(params.GetStructMemory() + 0);
		Params.WorldDirection = *(FVector*)(params.GetStructMemory() + 12);
		Params.ReturnValue = *(bool*)(params.GetStructMemory() + 24);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushboolean(InScriptContext, Params.ReturnValue);
	wLua::FLuaVector::Return(InScriptContext, Params.WorldLocation);
	wLua::FLuaVector::Return(InScriptContext, Params.WorldDirection);
	return 3;
}

int32 ClientWasKicked(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PlayerController",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PlayerController must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FText KickReason;
	} Params;
	Params.KickReason = FText::FromString(UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 2)));
#if UE_GAME
	APlayerController * This = (APlayerController *)Obj;
	This->ClientWasKicked(Params.KickReason);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("ClientWasKicked"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FText*)(params.GetStructMemory() + 0) = Params.KickReason;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.KickReason = *(FText*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 ClientVoiceHandshakeComplete(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PlayerController",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PlayerController must be non-null"); lua_error(InScriptContext);  return 0;}
#if UE_GAME
	APlayerController * This = (APlayerController *)Obj;
	This->ClientVoiceHandshakeComplete();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("ClientVoiceHandshakeComplete"));
	if(!Function) { check(false); return 0;}
	Obj->ProcessEvent(Function, NULL);
#endif
	return 0;
}

int32 ClientUpdateLevelStreamingStatus(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PlayerController",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PlayerController must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FName PackageName;
		bool bNewShouldBeLoaded;
		bool bNewShouldBeVisible;
		bool bNewShouldBlockOnLoad;
		int32 LODIndex;
	} Params;
	Params.PackageName = FName(UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 2)));
	Params.bNewShouldBeLoaded = !!(lua_toboolean(InScriptContext, 3));
	Params.bNewShouldBeVisible = !!(lua_toboolean(InScriptContext, 4));
	Params.bNewShouldBlockOnLoad = !!(lua_toboolean(InScriptContext, 5));
	Params.LODIndex = (luaL_checkint(InScriptContext, 6));
#if UE_GAME
	APlayerController * This = (APlayerController *)Obj;
	This->ClientUpdateLevelStreamingStatus(Params.PackageName,Params.bNewShouldBeLoaded,Params.bNewShouldBeVisible,Params.bNewShouldBlockOnLoad,Params.LODIndex);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("ClientUpdateLevelStreamingStatus"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FName*)(params.GetStructMemory() + 0) = Params.PackageName;
		*(bool*)(params.GetStructMemory() + 12) = Params.bNewShouldBeLoaded;
		*(bool*)(params.GetStructMemory() + 13) = Params.bNewShouldBeVisible;
		*(bool*)(params.GetStructMemory() + 14) = Params.bNewShouldBlockOnLoad;
		*(int32*)(params.GetStructMemory() + 16) = Params.LODIndex;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.PackageName = *(FName*)(params.GetStructMemory() + 0);
		Params.bNewShouldBeLoaded = *(bool*)(params.GetStructMemory() + 12);
		Params.bNewShouldBeVisible = *(bool*)(params.GetStructMemory() + 13);
		Params.bNewShouldBlockOnLoad = *(bool*)(params.GetStructMemory() + 14);
		Params.LODIndex = *(int32*)(params.GetStructMemory() + 16);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 ClientTeamMessage(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PlayerController",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PlayerController must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		APlayerState* SenderPlayerState = nullptr;
		FString S;
		FName Type;
		float MsgLifeTime;
	} Params;
	Params.SenderPlayerState = (APlayerState*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"PlayerState");;
	Params.S = UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 3));
	Params.Type = FName(UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 4)));
	Params.MsgLifeTime = (float)(luaL_checknumber(InScriptContext, 5));
#if UE_GAME
	APlayerController * This = (APlayerController *)Obj;
	This->ClientTeamMessage(Params.SenderPlayerState,Params.S,Params.Type,Params.MsgLifeTime);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("ClientTeamMessage"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(APlayerState**)(params.GetStructMemory() + 0) = Params.SenderPlayerState;
		*(FString*)(params.GetStructMemory() + 8) = Params.S;
		*(FName*)(params.GetStructMemory() + 24) = Params.Type;
		*(float*)(params.GetStructMemory() + 36) = Params.MsgLifeTime;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.SenderPlayerState = *(APlayerState**)(params.GetStructMemory() + 0);
		Params.S = *(FString*)(params.GetStructMemory() + 8);
		Params.Type = *(FName*)(params.GetStructMemory() + 24);
		Params.MsgLifeTime = *(float*)(params.GetStructMemory() + 36);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 ClientStopForceFeedback(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PlayerController",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PlayerController must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		UForceFeedbackEffect* ForceFeedbackEffect = nullptr;
		FName Tag;
	} Params;
	Params.ForceFeedbackEffect = (UForceFeedbackEffect*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"ForceFeedbackEffect");;
	Params.Tag = FName(UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 3)));
#if UE_GAME
	APlayerController * This = (APlayerController *)Obj;
	This->ClientStopForceFeedback(Params.ForceFeedbackEffect,Params.Tag);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("ClientStopForceFeedback"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(UForceFeedbackEffect**)(params.GetStructMemory() + 0) = Params.ForceFeedbackEffect;
		*(FName*)(params.GetStructMemory() + 8) = Params.Tag;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ForceFeedbackEffect = *(UForceFeedbackEffect**)(params.GetStructMemory() + 0);
		Params.Tag = *(FName*)(params.GetStructMemory() + 8);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 ClientStopCameraShake(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PlayerController",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PlayerController must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		TSubclassOf<UCameraShake>  Shake;
		bool bImmediately;
	} Params;
	Params.Shake = (UClass*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"Class");;
	Params.bImmediately = lua_isnoneornil(InScriptContext,3) ? bool(true) : !!(lua_toboolean(InScriptContext, 3));
#if UE_GAME
	APlayerController * This = (APlayerController *)Obj;
	This->ClientStopCameraShake(Params.Shake,Params.bImmediately);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("ClientStopCameraShake"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(TSubclassOf<UCameraShake> *)(params.GetStructMemory() + 0) = Params.Shake;
		*(bool*)(params.GetStructMemory() + 8) = Params.bImmediately;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.Shake = *(TSubclassOf<UCameraShake> *)(params.GetStructMemory() + 0);
		Params.bImmediately = *(bool*)(params.GetStructMemory() + 8);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 ClientStopCameraAnim(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PlayerController",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PlayerController must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		UCameraAnim* AnimToStop = nullptr;
	} Params;
	Params.AnimToStop = (UCameraAnim*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"CameraAnim");;
#if UE_GAME
	APlayerController * This = (APlayerController *)Obj;
	This->ClientStopCameraAnim(Params.AnimToStop);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("ClientStopCameraAnim"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(UCameraAnim**)(params.GetStructMemory() + 0) = Params.AnimToStop;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.AnimToStop = *(UCameraAnim**)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 ClientStartOnlineSession(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PlayerController",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PlayerController must be non-null"); lua_error(InScriptContext);  return 0;}
#if UE_GAME
	APlayerController * This = (APlayerController *)Obj;
	This->ClientStartOnlineSession();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("ClientStartOnlineSession"));
	if(!Function) { check(false); return 0;}
	Obj->ProcessEvent(Function, NULL);
#endif
	return 0;
}

int32 ClientSpawnCameraLensEffect(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PlayerController",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PlayerController must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		TSubclassOf<AEmitterCameraLensEffectBase>  LensEffectEmitterClass;
	} Params;
	Params.LensEffectEmitterClass = (UClass*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"Class");;
#if UE_GAME
	APlayerController * This = (APlayerController *)Obj;
	This->ClientSpawnCameraLensEffect(Params.LensEffectEmitterClass);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("ClientSpawnCameraLensEffect"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(TSubclassOf<AEmitterCameraLensEffectBase> *)(params.GetStructMemory() + 0) = Params.LensEffectEmitterClass;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.LensEffectEmitterClass = *(TSubclassOf<AEmitterCameraLensEffectBase> *)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 ClientSetSpectatorWaiting(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PlayerController",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PlayerController must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool bWaiting;
	} Params;
	Params.bWaiting = !!(lua_toboolean(InScriptContext, 2));
#if UE_GAME
	APlayerController * This = (APlayerController *)Obj;
	This->ClientSetSpectatorWaiting(Params.bWaiting);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("ClientSetSpectatorWaiting"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(bool*)(params.GetStructMemory() + 0) = Params.bWaiting;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.bWaiting = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 ClientSetHUD(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PlayerController",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PlayerController must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		TSubclassOf<AHUD>  NewHUDClass;
	} Params;
	Params.NewHUDClass = (UClass*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"Class");;
#if UE_GAME
	APlayerController * This = (APlayerController *)Obj;
	This->ClientSetHUD(Params.NewHUDClass);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("ClientSetHUD"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(TSubclassOf<AHUD> *)(params.GetStructMemory() + 0) = Params.NewHUDClass;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.NewHUDClass = *(TSubclassOf<AHUD> *)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 ClientSetForceMipLevelsToBeResident(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PlayerController",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PlayerController must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		UMaterialInterface* Material = nullptr;
		float ForceDuration;
		int32 CinematicTextureGroups;
	} Params;
	Params.Material = (UMaterialInterface*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"MaterialInterface");;
	Params.ForceDuration = (float)(luaL_checknumber(InScriptContext, 3));
	Params.CinematicTextureGroups = (luaL_checkint(InScriptContext, 4));
#if UE_GAME
	APlayerController * This = (APlayerController *)Obj;
	This->ClientSetForceMipLevelsToBeResident(Params.Material,Params.ForceDuration,Params.CinematicTextureGroups);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("ClientSetForceMipLevelsToBeResident"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(UMaterialInterface**)(params.GetStructMemory() + 0) = Params.Material;
		*(float*)(params.GetStructMemory() + 8) = Params.ForceDuration;
		*(int32*)(params.GetStructMemory() + 12) = Params.CinematicTextureGroups;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.Material = *(UMaterialInterface**)(params.GetStructMemory() + 0);
		Params.ForceDuration = *(float*)(params.GetStructMemory() + 8);
		Params.CinematicTextureGroups = *(int32*)(params.GetStructMemory() + 12);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 ClientSetCinematicMode(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PlayerController",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PlayerController must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool bInCinematicMode;
		bool bAffectsMovement;
		bool bAffectsTurning;
		bool bAffectsHUD;
	} Params;
	Params.bInCinematicMode = !!(lua_toboolean(InScriptContext, 2));
	Params.bAffectsMovement = !!(lua_toboolean(InScriptContext, 3));
	Params.bAffectsTurning = !!(lua_toboolean(InScriptContext, 4));
	Params.bAffectsHUD = !!(lua_toboolean(InScriptContext, 5));
#if UE_GAME
	APlayerController * This = (APlayerController *)Obj;
	This->ClientSetCinematicMode(Params.bInCinematicMode,Params.bAffectsMovement,Params.bAffectsTurning,Params.bAffectsHUD);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("ClientSetCinematicMode"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(bool*)(params.GetStructMemory() + 0) = Params.bInCinematicMode;
		*(bool*)(params.GetStructMemory() + 1) = Params.bAffectsMovement;
		*(bool*)(params.GetStructMemory() + 2) = Params.bAffectsTurning;
		*(bool*)(params.GetStructMemory() + 3) = Params.bAffectsHUD;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.bInCinematicMode = *(bool*)(params.GetStructMemory() + 0);
		Params.bAffectsMovement = *(bool*)(params.GetStructMemory() + 1);
		Params.bAffectsTurning = *(bool*)(params.GetStructMemory() + 2);
		Params.bAffectsHUD = *(bool*)(params.GetStructMemory() + 3);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 ClientSetCameraMode(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PlayerController",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PlayerController must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FName NewCamMode;
	} Params;
	Params.NewCamMode = FName(UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 2)));
#if UE_GAME
	APlayerController * This = (APlayerController *)Obj;
	This->ClientSetCameraMode(Params.NewCamMode);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("ClientSetCameraMode"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FName*)(params.GetStructMemory() + 0) = Params.NewCamMode;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.NewCamMode = *(FName*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 ClientSetCameraFade(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PlayerController",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PlayerController must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool bEnableFading;
		FColor FadeColor;
		FVector2D FadeAlpha;
		float FadeTime;
		bool bFadeAudio;
	} Params;
	Params.bEnableFading = !!(lua_toboolean(InScriptContext, 2));
	Params.FadeColor = (wLua::FLuaLinearColor::GetColor(InScriptContext, 3));
	Params.FadeAlpha = (wLua::FLuaVector2D::Get(InScriptContext, 4));
	Params.FadeTime = (float)(luaL_checknumber(InScriptContext, 5));
	Params.bFadeAudio = !!(lua_toboolean(InScriptContext, 6));
#if UE_GAME
	APlayerController * This = (APlayerController *)Obj;
	This->ClientSetCameraFade(Params.bEnableFading,Params.FadeColor,Params.FadeAlpha,Params.FadeTime,Params.bFadeAudio);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("ClientSetCameraFade"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(bool*)(params.GetStructMemory() + 0) = Params.bEnableFading;
		*(FColor*)(params.GetStructMemory() + 4) = Params.FadeColor;
		*(FVector2D*)(params.GetStructMemory() + 8) = Params.FadeAlpha;
		*(float*)(params.GetStructMemory() + 16) = Params.FadeTime;
		*(bool*)(params.GetStructMemory() + 20) = Params.bFadeAudio;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.bEnableFading = *(bool*)(params.GetStructMemory() + 0);
		Params.FadeColor = *(FColor*)(params.GetStructMemory() + 4);
		Params.FadeAlpha = *(FVector2D*)(params.GetStructMemory() + 8);
		Params.FadeTime = *(float*)(params.GetStructMemory() + 16);
		Params.bFadeAudio = *(bool*)(params.GetStructMemory() + 20);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 ClientSetBlockOnAsyncLoading(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PlayerController",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PlayerController must be non-null"); lua_error(InScriptContext);  return 0;}
#if UE_GAME
	APlayerController * This = (APlayerController *)Obj;
	This->ClientSetBlockOnAsyncLoading();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("ClientSetBlockOnAsyncLoading"));
	if(!Function) { check(false); return 0;}
	Obj->ProcessEvent(Function, NULL);
#endif
	return 0;
}

int32 ClientReturnToMainMenuWithTextReason(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PlayerController",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PlayerController must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FText ReturnReason;
	} Params;
	Params.ReturnReason = FText::FromString(UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 2)));
#if UE_GAME
	APlayerController * This = (APlayerController *)Obj;
	This->ClientReturnToMainMenuWithTextReason(Params.ReturnReason);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("ClientReturnToMainMenuWithTextReason"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FText*)(params.GetStructMemory() + 0) = Params.ReturnReason;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnReason = *(FText*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 ClientReturnToMainMenu(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PlayerController",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PlayerController must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FString ReturnReason;
	} Params;
	Params.ReturnReason = UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 2));
#if UE_GAME
	APlayerController * This = (APlayerController *)Obj;
	This->ClientReturnToMainMenu(Params.ReturnReason);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("ClientReturnToMainMenu"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FString*)(params.GetStructMemory() + 0) = Params.ReturnReason;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnReason = *(FString*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 ClientRetryClientRestart(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PlayerController",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PlayerController must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		APawn* NewPawn = nullptr;
	} Params;
	Params.NewPawn = (APawn*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"Pawn");;
#if UE_GAME
	APlayerController * This = (APlayerController *)Obj;
	This->ClientRetryClientRestart(Params.NewPawn);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("ClientRetryClientRestart"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(APawn**)(params.GetStructMemory() + 0) = Params.NewPawn;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.NewPawn = *(APawn**)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 ClientRestart(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PlayerController",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PlayerController must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		APawn* NewPawn = nullptr;
	} Params;
	Params.NewPawn = (APawn*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"Pawn");;
#if UE_GAME
	APlayerController * This = (APlayerController *)Obj;
	This->ClientRestart(Params.NewPawn);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("ClientRestart"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(APawn**)(params.GetStructMemory() + 0) = Params.NewPawn;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.NewPawn = *(APawn**)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 ClientReset(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PlayerController",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PlayerController must be non-null"); lua_error(InScriptContext);  return 0;}
#if UE_GAME
	APlayerController * This = (APlayerController *)Obj;
	This->ClientReset();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("ClientReset"));
	if(!Function) { check(false); return 0;}
	Obj->ProcessEvent(Function, NULL);
#endif
	return 0;
}

int32 ClientRepObjRef(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PlayerController",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PlayerController must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		UObject* Object = nullptr;
	} Params;
	Params.Object = (UObject*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"Object");;
#if UE_GAME
	APlayerController * This = (APlayerController *)Obj;
	This->ClientRepObjRef(Params.Object);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("ClientRepObjRef"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(UObject**)(params.GetStructMemory() + 0) = Params.Object;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.Object = *(UObject**)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 ClientReceiveLocalizedMessage(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PlayerController",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PlayerController must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		TSubclassOf<ULocalMessage>  Message;
		int32 Switch;
		APlayerState* RelatedPlayerState_1 = nullptr;
		APlayerState* RelatedPlayerState_2 = nullptr;
		UObject* OptionalObject = nullptr;
	} Params;
	Params.Message = (UClass*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"Class");;
	Params.Switch = (luaL_checkint(InScriptContext, 3));
	Params.RelatedPlayerState_1 = (APlayerState*)wLua::FLuaUtils::GetUObject(InScriptContext,4,"PlayerState");;
	Params.RelatedPlayerState_2 = (APlayerState*)wLua::FLuaUtils::GetUObject(InScriptContext,5,"PlayerState");;
	Params.OptionalObject = (UObject*)wLua::FLuaUtils::GetUObject(InScriptContext,6,"Object");;
#if UE_GAME
	APlayerController * This = (APlayerController *)Obj;
	This->ClientReceiveLocalizedMessage(Params.Message,Params.Switch,Params.RelatedPlayerState_1,Params.RelatedPlayerState_2,Params.OptionalObject);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("ClientReceiveLocalizedMessage"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(TSubclassOf<ULocalMessage> *)(params.GetStructMemory() + 0) = Params.Message;
		*(int32*)(params.GetStructMemory() + 8) = Params.Switch;
		*(APlayerState**)(params.GetStructMemory() + 16) = Params.RelatedPlayerState_1;
		*(APlayerState**)(params.GetStructMemory() + 24) = Params.RelatedPlayerState_2;
		*(UObject**)(params.GetStructMemory() + 32) = Params.OptionalObject;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.Message = *(TSubclassOf<ULocalMessage> *)(params.GetStructMemory() + 0);
		Params.Switch = *(int32*)(params.GetStructMemory() + 8);
		Params.RelatedPlayerState_1 = *(APlayerState**)(params.GetStructMemory() + 16);
		Params.RelatedPlayerState_2 = *(APlayerState**)(params.GetStructMemory() + 24);
		Params.OptionalObject = *(UObject**)(params.GetStructMemory() + 32);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 ClientPrestreamTextures(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PlayerController",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PlayerController must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		AActor* ForcedActor = nullptr;
		float ForceDuration;
		bool bEnableStreaming;
		int32 CinematicTextureGroups;
	} Params;
	Params.ForcedActor = (AActor*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"Actor");;
	Params.ForceDuration = (float)(luaL_checknumber(InScriptContext, 3));
	Params.bEnableStreaming = !!(lua_toboolean(InScriptContext, 4));
	Params.CinematicTextureGroups = (luaL_checkint(InScriptContext, 5));
#if UE_GAME
	APlayerController * This = (APlayerController *)Obj;
	This->ClientPrestreamTextures(Params.ForcedActor,Params.ForceDuration,Params.bEnableStreaming,Params.CinematicTextureGroups);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("ClientPrestreamTextures"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(AActor**)(params.GetStructMemory() + 0) = Params.ForcedActor;
		*(float*)(params.GetStructMemory() + 8) = Params.ForceDuration;
		*(bool*)(params.GetStructMemory() + 12) = Params.bEnableStreaming;
		*(int32*)(params.GetStructMemory() + 16) = Params.CinematicTextureGroups;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ForcedActor = *(AActor**)(params.GetStructMemory() + 0);
		Params.ForceDuration = *(float*)(params.GetStructMemory() + 8);
		Params.bEnableStreaming = *(bool*)(params.GetStructMemory() + 12);
		Params.CinematicTextureGroups = *(int32*)(params.GetStructMemory() + 16);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 ClientPrepareMapChange(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PlayerController",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PlayerController must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FName LevelName;
		bool bFirst;
		bool bLast;
	} Params;
	Params.LevelName = FName(UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 2)));
	Params.bFirst = !!(lua_toboolean(InScriptContext, 3));
	Params.bLast = !!(lua_toboolean(InScriptContext, 4));
#if UE_GAME
	APlayerController * This = (APlayerController *)Obj;
	This->ClientPrepareMapChange(Params.LevelName,Params.bFirst,Params.bLast);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("ClientPrepareMapChange"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FName*)(params.GetStructMemory() + 0) = Params.LevelName;
		*(bool*)(params.GetStructMemory() + 12) = Params.bFirst;
		*(bool*)(params.GetStructMemory() + 13) = Params.bLast;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.LevelName = *(FName*)(params.GetStructMemory() + 0);
		Params.bFirst = *(bool*)(params.GetStructMemory() + 12);
		Params.bLast = *(bool*)(params.GetStructMemory() + 13);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 ClientPlaySoundAtLocation(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PlayerController",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PlayerController must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		USoundBase* Sound = nullptr;
		FVector Location;
		float VolumeMultiplier;
		float PitchMultiplier;
	} Params;
	Params.Sound = (USoundBase*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"SoundBase");;
	Params.Location = (wLua::FLuaVector::Get(InScriptContext, 3));
	Params.VolumeMultiplier = (float)(luaL_checknumber(InScriptContext, 4));
	Params.PitchMultiplier = (float)(luaL_checknumber(InScriptContext, 5));
#if UE_GAME
	APlayerController * This = (APlayerController *)Obj;
	This->ClientPlaySoundAtLocation(Params.Sound,Params.Location,Params.VolumeMultiplier,Params.PitchMultiplier);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("ClientPlaySoundAtLocation"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(USoundBase**)(params.GetStructMemory() + 0) = Params.Sound;
		*(FVector*)(params.GetStructMemory() + 8) = Params.Location;
		*(float*)(params.GetStructMemory() + 20) = Params.VolumeMultiplier;
		*(float*)(params.GetStructMemory() + 24) = Params.PitchMultiplier;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.Sound = *(USoundBase**)(params.GetStructMemory() + 0);
		Params.Location = *(FVector*)(params.GetStructMemory() + 8);
		Params.VolumeMultiplier = *(float*)(params.GetStructMemory() + 20);
		Params.PitchMultiplier = *(float*)(params.GetStructMemory() + 24);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 ClientPlaySound(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PlayerController",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PlayerController must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		USoundBase* Sound = nullptr;
		float VolumeMultiplier;
		float PitchMultiplier;
	} Params;
	Params.Sound = (USoundBase*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"SoundBase");;
	Params.VolumeMultiplier = (float)(luaL_checknumber(InScriptContext, 3));
	Params.PitchMultiplier = (float)(luaL_checknumber(InScriptContext, 4));
#if UE_GAME
	APlayerController * This = (APlayerController *)Obj;
	This->ClientPlaySound(Params.Sound,Params.VolumeMultiplier,Params.PitchMultiplier);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("ClientPlaySound"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(USoundBase**)(params.GetStructMemory() + 0) = Params.Sound;
		*(float*)(params.GetStructMemory() + 8) = Params.VolumeMultiplier;
		*(float*)(params.GetStructMemory() + 12) = Params.PitchMultiplier;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.Sound = *(USoundBase**)(params.GetStructMemory() + 0);
		Params.VolumeMultiplier = *(float*)(params.GetStructMemory() + 8);
		Params.PitchMultiplier = *(float*)(params.GetStructMemory() + 12);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 ClientPlayForceFeedback(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PlayerController",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PlayerController must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		UForceFeedbackEffect* ForceFeedbackEffect = nullptr;
		bool bLooping;
		bool bIgnoreTimeDilation;
		FName Tag;
	} Params;
	Params.ForceFeedbackEffect = (UForceFeedbackEffect*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"ForceFeedbackEffect");;
	Params.bLooping = !!(lua_toboolean(InScriptContext, 3));
	Params.bIgnoreTimeDilation = !!(lua_toboolean(InScriptContext, 4));
	Params.Tag = FName(UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 5)));
#if UE_GAME
	APlayerController * This = (APlayerController *)Obj;
	This->ClientPlayForceFeedback(Params.ForceFeedbackEffect,Params.bLooping,Params.bIgnoreTimeDilation,Params.Tag);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("ClientPlayForceFeedback"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(UForceFeedbackEffect**)(params.GetStructMemory() + 0) = Params.ForceFeedbackEffect;
		*(bool*)(params.GetStructMemory() + 8) = Params.bLooping;
		*(bool*)(params.GetStructMemory() + 9) = Params.bIgnoreTimeDilation;
		*(FName*)(params.GetStructMemory() + 12) = Params.Tag;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ForceFeedbackEffect = *(UForceFeedbackEffect**)(params.GetStructMemory() + 0);
		Params.bLooping = *(bool*)(params.GetStructMemory() + 8);
		Params.bIgnoreTimeDilation = *(bool*)(params.GetStructMemory() + 9);
		Params.Tag = *(FName*)(params.GetStructMemory() + 12);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 ClientPlayCameraShake(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PlayerController",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PlayerController must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		TSubclassOf<UCameraShake>  Shake;
		float Scale;
		TEnumAsByte<ECameraAnimPlaySpace::Type> PlaySpace;
		FRotator UserPlaySpaceRot;
	} Params;
	Params.Shake = (UClass*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"Class");;
	Params.Scale = lua_isnoneornil(InScriptContext,3) ? float(1.000000) : (float)(luaL_checknumber(InScriptContext, 3));
	Params.PlaySpace = lua_isnoneornil(InScriptContext,4) ? TEnumAsByte<ECameraAnimPlaySpace::Type>(ECameraAnimPlaySpace::Type::CameraLocal) : (TEnumAsByte<ECameraAnimPlaySpace::Type>)(luaL_checkint(InScriptContext, 4));
	Params.UserPlaySpaceRot = lua_isnoneornil(InScriptContext,5) ? FRotator(0.f) : (wLua::FLuaRotator::Get(InScriptContext, 5));
#if UE_GAME
	APlayerController * This = (APlayerController *)Obj;
	This->ClientPlayCameraShake(Params.Shake,Params.Scale,Params.PlaySpace,Params.UserPlaySpaceRot);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("ClientPlayCameraShake"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(TSubclassOf<UCameraShake> *)(params.GetStructMemory() + 0) = Params.Shake;
		*(float*)(params.GetStructMemory() + 8) = Params.Scale;
		*(TEnumAsByte<ECameraAnimPlaySpace::Type>*)(params.GetStructMemory() + 12) = Params.PlaySpace;
		*(FRotator*)(params.GetStructMemory() + 16) = Params.UserPlaySpaceRot;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.Shake = *(TSubclassOf<UCameraShake> *)(params.GetStructMemory() + 0);
		Params.Scale = *(float*)(params.GetStructMemory() + 8);
		Params.PlaySpace = *(TEnumAsByte<ECameraAnimPlaySpace::Type>*)(params.GetStructMemory() + 12);
		Params.UserPlaySpaceRot = *(FRotator*)(params.GetStructMemory() + 16);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 ClientPlayCameraAnim(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PlayerController",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PlayerController must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		UCameraAnim* AnimToPlay = nullptr;
		float Scale;
		float Rate;
		float BlendInTime;
		float BlendOutTime;
		bool bLoop;
		bool bRandomStartTime;
		TEnumAsByte<ECameraAnimPlaySpace::Type> Space;
		FRotator CustomPlaySpace;
	} Params;
	Params.AnimToPlay = (UCameraAnim*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"CameraAnim");;
	Params.Scale = lua_isnoneornil(InScriptContext,3) ? float(1.000000) : (float)(luaL_checknumber(InScriptContext, 3));
	Params.Rate = lua_isnoneornil(InScriptContext,4) ? float(1.000000) : (float)(luaL_checknumber(InScriptContext, 4));
	Params.BlendInTime = lua_isnoneornil(InScriptContext,5) ? float(0.000000) : (float)(luaL_checknumber(InScriptContext, 5));
	Params.BlendOutTime = lua_isnoneornil(InScriptContext,6) ? float(0.000000) : (float)(luaL_checknumber(InScriptContext, 6));
	Params.bLoop = lua_isnoneornil(InScriptContext,7) ? bool(false) : !!(lua_toboolean(InScriptContext, 7));
	Params.bRandomStartTime = lua_isnoneornil(InScriptContext,8) ? bool(false) : !!(lua_toboolean(InScriptContext, 8));
	Params.Space = lua_isnoneornil(InScriptContext,9) ? TEnumAsByte<ECameraAnimPlaySpace::Type>(ECameraAnimPlaySpace::Type::CameraLocal) : (TEnumAsByte<ECameraAnimPlaySpace::Type>)(luaL_checkint(InScriptContext, 9));
	Params.CustomPlaySpace = lua_isnoneornil(InScriptContext,10) ? FRotator(0.f) : (wLua::FLuaRotator::Get(InScriptContext, 10));
#if UE_GAME
	APlayerController * This = (APlayerController *)Obj;
	This->ClientPlayCameraAnim(Params.AnimToPlay,Params.Scale,Params.Rate,Params.BlendInTime,Params.BlendOutTime,Params.bLoop,Params.bRandomStartTime,Params.Space,Params.CustomPlaySpace);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("ClientPlayCameraAnim"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(UCameraAnim**)(params.GetStructMemory() + 0) = Params.AnimToPlay;
		*(float*)(params.GetStructMemory() + 8) = Params.Scale;
		*(float*)(params.GetStructMemory() + 12) = Params.Rate;
		*(float*)(params.GetStructMemory() + 16) = Params.BlendInTime;
		*(float*)(params.GetStructMemory() + 20) = Params.BlendOutTime;
		*(bool*)(params.GetStructMemory() + 24) = Params.bLoop;
		*(bool*)(params.GetStructMemory() + 25) = Params.bRandomStartTime;
		*(TEnumAsByte<ECameraAnimPlaySpace::Type>*)(params.GetStructMemory() + 26) = Params.Space;
		*(FRotator*)(params.GetStructMemory() + 28) = Params.CustomPlaySpace;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.AnimToPlay = *(UCameraAnim**)(params.GetStructMemory() + 0);
		Params.Scale = *(float*)(params.GetStructMemory() + 8);
		Params.Rate = *(float*)(params.GetStructMemory() + 12);
		Params.BlendInTime = *(float*)(params.GetStructMemory() + 16);
		Params.BlendOutTime = *(float*)(params.GetStructMemory() + 20);
		Params.bLoop = *(bool*)(params.GetStructMemory() + 24);
		Params.bRandomStartTime = *(bool*)(params.GetStructMemory() + 25);
		Params.Space = *(TEnumAsByte<ECameraAnimPlaySpace::Type>*)(params.GetStructMemory() + 26);
		Params.CustomPlaySpace = *(FRotator*)(params.GetStructMemory() + 28);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 ClientMessage(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PlayerController",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PlayerController must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FString S;
		FName Type;
		float MsgLifeTime;
	} Params;
	Params.S = UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 2));
	Params.Type = FName(UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 3)));
	Params.MsgLifeTime = (float)(luaL_checknumber(InScriptContext, 4));
#if UE_GAME
	APlayerController * This = (APlayerController *)Obj;
	This->ClientMessage(Params.S,Params.Type,Params.MsgLifeTime);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("ClientMessage"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FString*)(params.GetStructMemory() + 0) = Params.S;
		*(FName*)(params.GetStructMemory() + 16) = Params.Type;
		*(float*)(params.GetStructMemory() + 28) = Params.MsgLifeTime;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.S = *(FString*)(params.GetStructMemory() + 0);
		Params.Type = *(FName*)(params.GetStructMemory() + 16);
		Params.MsgLifeTime = *(float*)(params.GetStructMemory() + 28);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 ClientIgnoreMoveInput(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PlayerController",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PlayerController must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool bIgnore;
	} Params;
	Params.bIgnore = !!(lua_toboolean(InScriptContext, 2));
#if UE_GAME
	APlayerController * This = (APlayerController *)Obj;
	This->ClientIgnoreMoveInput(Params.bIgnore);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("ClientIgnoreMoveInput"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(bool*)(params.GetStructMemory() + 0) = Params.bIgnore;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.bIgnore = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 ClientIgnoreLookInput(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PlayerController",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PlayerController must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool bIgnore;
	} Params;
	Params.bIgnore = !!(lua_toboolean(InScriptContext, 2));
#if UE_GAME
	APlayerController * This = (APlayerController *)Obj;
	This->ClientIgnoreLookInput(Params.bIgnore);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("ClientIgnoreLookInput"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(bool*)(params.GetStructMemory() + 0) = Params.bIgnore;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.bIgnore = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 ClientGotoState(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PlayerController",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PlayerController must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FName NewState;
	} Params;
	Params.NewState = FName(UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 2)));
#if UE_GAME
	APlayerController * This = (APlayerController *)Obj;
	This->ClientGotoState(Params.NewState);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("ClientGotoState"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FName*)(params.GetStructMemory() + 0) = Params.NewState;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.NewState = *(FName*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 ClientGameEnded(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PlayerController",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PlayerController must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		AActor* EndGameFocus = nullptr;
		bool bIsWinner;
	} Params;
	Params.EndGameFocus = (AActor*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"Actor");;
	Params.bIsWinner = !!(lua_toboolean(InScriptContext, 3));
#if UE_GAME
	APlayerController * This = (APlayerController *)Obj;
	This->ClientGameEnded(Params.EndGameFocus,Params.bIsWinner);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("ClientGameEnded"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(AActor**)(params.GetStructMemory() + 0) = Params.EndGameFocus;
		*(bool*)(params.GetStructMemory() + 8) = Params.bIsWinner;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.EndGameFocus = *(AActor**)(params.GetStructMemory() + 0);
		Params.bIsWinner = *(bool*)(params.GetStructMemory() + 8);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 ClientForceGarbageCollection(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PlayerController",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PlayerController must be non-null"); lua_error(InScriptContext);  return 0;}
#if UE_GAME
	APlayerController * This = (APlayerController *)Obj;
	This->ClientForceGarbageCollection();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("ClientForceGarbageCollection"));
	if(!Function) { check(false); return 0;}
	Obj->ProcessEvent(Function, NULL);
#endif
	return 0;
}

int32 ClientFlushLevelStreaming(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PlayerController",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PlayerController must be non-null"); lua_error(InScriptContext);  return 0;}
#if UE_GAME
	APlayerController * This = (APlayerController *)Obj;
	This->ClientFlushLevelStreaming();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("ClientFlushLevelStreaming"));
	if(!Function) { check(false); return 0;}
	Obj->ProcessEvent(Function, NULL);
#endif
	return 0;
}

int32 ClientEndOnlineSession(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PlayerController",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PlayerController must be non-null"); lua_error(InScriptContext);  return 0;}
#if UE_GAME
	APlayerController * This = (APlayerController *)Obj;
	This->ClientEndOnlineSession();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("ClientEndOnlineSession"));
	if(!Function) { check(false); return 0;}
	Obj->ProcessEvent(Function, NULL);
#endif
	return 0;
}

int32 ClientEnableNetworkVoice(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PlayerController",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PlayerController must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool bEnable;
	} Params;
	Params.bEnable = !!(lua_toboolean(InScriptContext, 2));
#if UE_GAME
	APlayerController * This = (APlayerController *)Obj;
	This->ClientEnableNetworkVoice(Params.bEnable);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("ClientEnableNetworkVoice"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(bool*)(params.GetStructMemory() + 0) = Params.bEnable;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.bEnable = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 ClientCommitMapChange(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PlayerController",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PlayerController must be non-null"); lua_error(InScriptContext);  return 0;}
#if UE_GAME
	APlayerController * This = (APlayerController *)Obj;
	This->ClientCommitMapChange();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("ClientCommitMapChange"));
	if(!Function) { check(false); return 0;}
	Obj->ProcessEvent(Function, NULL);
#endif
	return 0;
}

int32 ClientClearCameraLensEffects(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PlayerController",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PlayerController must be non-null"); lua_error(InScriptContext);  return 0;}
#if UE_GAME
	APlayerController * This = (APlayerController *)Obj;
	This->ClientClearCameraLensEffects();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("ClientClearCameraLensEffects"));
	if(!Function) { check(false); return 0;}
	Obj->ProcessEvent(Function, NULL);
#endif
	return 0;
}

int32 ClientCapBandwidth(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PlayerController",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PlayerController must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		int32 Cap;
	} Params;
	Params.Cap = (luaL_checkint(InScriptContext, 2));
#if UE_GAME
	APlayerController * This = (APlayerController *)Obj;
	This->ClientCapBandwidth(Params.Cap);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("ClientCapBandwidth"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(int32*)(params.GetStructMemory() + 0) = Params.Cap;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.Cap = *(int32*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 ClientCancelPendingMapChange(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PlayerController",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PlayerController must be non-null"); lua_error(InScriptContext);  return 0;}
#if UE_GAME
	APlayerController * This = (APlayerController *)Obj;
	This->ClientCancelPendingMapChange();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("ClientCancelPendingMapChange"));
	if(!Function) { check(false); return 0;}
	Obj->ProcessEvent(Function, NULL);
#endif
	return 0;
}

int32 ClientAddTextureStreamingLoc(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PlayerController",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PlayerController must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FVector InLoc;
		float Duration;
		bool bOverrideLocation;
	} Params;
	Params.InLoc = (wLua::FLuaVector::Get(InScriptContext, 2));
	Params.Duration = (float)(luaL_checknumber(InScriptContext, 3));
	Params.bOverrideLocation = !!(lua_toboolean(InScriptContext, 4));
#if UE_GAME
	APlayerController * This = (APlayerController *)Obj;
	This->ClientAddTextureStreamingLoc(Params.InLoc,Params.Duration,Params.bOverrideLocation);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("ClientAddTextureStreamingLoc"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FVector*)(params.GetStructMemory() + 0) = Params.InLoc;
		*(float*)(params.GetStructMemory() + 12) = Params.Duration;
		*(bool*)(params.GetStructMemory() + 16) = Params.bOverrideLocation;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.InLoc = *(FVector*)(params.GetStructMemory() + 0);
		Params.Duration = *(float*)(params.GetStructMemory() + 12);
		Params.bOverrideLocation = *(bool*)(params.GetStructMemory() + 16);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 ClearAudioListenerOverride(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PlayerController",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PlayerController must be non-null"); lua_error(InScriptContext);  return 0;}
#if UE_GAME
	APlayerController * This = (APlayerController *)Obj;
	This->ClearAudioListenerOverride();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("ClearAudioListenerOverride"));
	if(!Function) { check(false); return 0;}
	Obj->ProcessEvent(Function, NULL);
#endif
	return 0;
}

int32 ClearAudioListenerAttenuationOverride(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PlayerController",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PlayerController must be non-null"); lua_error(InScriptContext);  return 0;}
#if UE_GAME
	APlayerController * This = (APlayerController *)Obj;
	This->ClearAudioListenerAttenuationOverride();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("ClearAudioListenerAttenuationOverride"));
	if(!Function) { check(false); return 0;}
	Obj->ProcessEvent(Function, NULL);
#endif
	return 0;
}

int32 CanRestartPlayer(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PlayerController",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PlayerController must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool ReturnValue;
	} Params;
#if UE_GAME
	APlayerController * This = (APlayerController *)Obj;
	Params.ReturnValue = This->CanRestartPlayer();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("CanRestartPlayer"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushboolean(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 Camera(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PlayerController",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PlayerController must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FName NewMode;
	} Params;
	Params.NewMode = FName(UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 2)));
#if UE_GAME
	APlayerController * This = (APlayerController *)Obj;
	This->Camera(Params.NewMode);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("Camera"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FName*)(params.GetStructMemory() + 0) = Params.NewMode;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.NewMode = *(FName*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 AzureSetBasicControlPositionChanged(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PlayerController",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PlayerController must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float deltaX;
		float deltaY;
	} Params;
	Params.deltaX = (float)(luaL_checknumber(InScriptContext, 2));
	Params.deltaY = (float)(luaL_checknumber(InScriptContext, 3));
#if UE_GAME
	APlayerController * This = (APlayerController *)Obj;
	This->AzureSetBasicControlPositionChanged(Params.deltaX,Params.deltaY);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("AzureSetBasicControlPositionChanged"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(float*)(params.GetStructMemory() + 0) = Params.deltaX;
		*(float*)(params.GetStructMemory() + 4) = Params.deltaY;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.deltaX = *(float*)(params.GetStructMemory() + 0);
		Params.deltaY = *(float*)(params.GetStructMemory() + 4);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 AddYawInput(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PlayerController",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PlayerController must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float Val;
	} Params;
	Params.Val = (float)(luaL_checknumber(InScriptContext, 2));
#if UE_GAME
	APlayerController * This = (APlayerController *)Obj;
	This->AddYawInput(Params.Val);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("AddYawInput"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(float*)(params.GetStructMemory() + 0) = Params.Val;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.Val = *(float*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 AddRollInput(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PlayerController",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PlayerController must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float Val;
	} Params;
	Params.Val = (float)(luaL_checknumber(InScriptContext, 2));
#if UE_GAME
	APlayerController * This = (APlayerController *)Obj;
	This->AddRollInput(Params.Val);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("AddRollInput"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(float*)(params.GetStructMemory() + 0) = Params.Val;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.Val = *(float*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 AddPitchInput(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PlayerController",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PlayerController must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float Val;
	} Params;
	Params.Val = (float)(luaL_checknumber(InScriptContext, 2));
#if UE_GAME
	APlayerController * This = (APlayerController *)Obj;
	This->AddPitchInput(Params.Val);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("AddPitchInput"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(float*)(params.GetStructMemory() + 0) = Params.Val;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.Val = *(float*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 ActivateTouchInterface(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PlayerController",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PlayerController must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		UTouchInterface* NewTouchInterface = nullptr;
	} Params;
	Params.NewTouchInterface = (UTouchInterface*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"TouchInterface");;
#if UE_GAME
	APlayerController * This = (APlayerController *)Obj;
	This->ActivateTouchInterface(Params.NewTouchInterface);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("ActivateTouchInterface"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(UTouchInterface**)(params.GetStructMemory() + 0) = Params.NewTouchInterface;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.NewTouchInterface = *(UTouchInterface**)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 Get_PlayerCameraManager(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PlayerController",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PlayerController must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(APlayerController::StaticClass(), TEXT("PlayerCameraManager"));
	if(!Property) { check(false); return 0;}
	APlayerCameraManager* PropertyValue;
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaUtils::ReturnUObject(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_PlayerCameraManagerClass(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PlayerController",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PlayerController must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(APlayerController::StaticClass(), TEXT("PlayerCameraManagerClass"));
	if(!Property) { check(false); return 0;}
	TSubclassOf<APlayerCameraManager>  PropertyValue = TSubclassOf<APlayerCameraManager> ();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaUtils::ReturnUObject(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_bAutoManageActiveCameraTarget(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PlayerController",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PlayerController must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(APlayerController::StaticClass(), TEXT("bAutoManageActiveCameraTarget"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = bool();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bAutoManageActiveCameraTarget(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PlayerController",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PlayerController must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(APlayerController::StaticClass(), TEXT("bAutoManageActiveCameraTarget"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_SmoothTargetViewRotationSpeed(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PlayerController",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PlayerController must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(APlayerController::StaticClass(), TEXT("SmoothTargetViewRotationSpeed"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_SmoothTargetViewRotationSpeed(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PlayerController",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PlayerController must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(APlayerController::StaticClass(), TEXT("SmoothTargetViewRotationSpeed"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_HiddenActors(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PlayerController",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PlayerController must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(APlayerController::StaticClass(), TEXT("HiddenActors"));
	if(!Property) { check(false); return 0;}
	TArray<AActor*> PropertyValue;
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	{lua_newtable(InScriptContext); int i = 1; for(auto It = PropertyValue.CreateConstIterator(); It; ++It,++i) {  wLua::FLuaUtils::ReturnUObject(InScriptContext, (*It)); lua_rawseti(InScriptContext,-2,i);     }  }
	return 1;
}

int32 Set_HiddenActors(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PlayerController",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PlayerController must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(APlayerController::StaticClass(), TEXT("HiddenActors"));
	if(!Property) { check(false); return 0;}
	TArray<AActor*> PropertyValue = [](lua_State * _InScriptContext){ TArray<AActor*> ret; lua_pushnil(_InScriptContext); while(lua_next(_InScriptContext,2)!=0){ AActor* item = (AActor*)wLua::FLuaUtils::GetUObject(_InScriptContext,-1,"Actor");; ret.Add(item); lua_pop(_InScriptContext,1);  } return ret; }(InScriptContext);;
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_CheatManager(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PlayerController",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PlayerController must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(APlayerController::StaticClass(), TEXT("CheatManager"));
	if(!Property) { check(false); return 0;}
	UCheatManager* PropertyValue;
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaUtils::ReturnUObject(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_CheatClass(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PlayerController",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PlayerController must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(APlayerController::StaticClass(), TEXT("CheatClass"));
	if(!Property) { check(false); return 0;}
	TSubclassOf<UCheatManager>  PropertyValue = TSubclassOf<UCheatManager> ();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaUtils::ReturnUObject(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_bPlayerIsWaiting(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PlayerController",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PlayerController must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(APlayerController::StaticClass(), TEXT("bPlayerIsWaiting"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_InputYawScale(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PlayerController",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PlayerController must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(APlayerController::StaticClass(), TEXT("InputYawScale"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_InputYawScale(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PlayerController",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PlayerController must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(APlayerController::StaticClass(), TEXT("InputYawScale"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_InputPitchScale(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PlayerController",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PlayerController must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(APlayerController::StaticClass(), TEXT("InputPitchScale"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_InputPitchScale(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PlayerController",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PlayerController must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(APlayerController::StaticClass(), TEXT("InputPitchScale"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_InputRollScale(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PlayerController",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PlayerController must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(APlayerController::StaticClass(), TEXT("InputRollScale"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_InputRollScale(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PlayerController",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PlayerController must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(APlayerController::StaticClass(), TEXT("InputRollScale"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bShowMouseCursor(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PlayerController",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PlayerController must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(APlayerController::StaticClass(), TEXT("bShowMouseCursor"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bShowMouseCursor(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PlayerController",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PlayerController must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(APlayerController::StaticClass(), TEXT("bShowMouseCursor"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bEnableClickEvents(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PlayerController",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PlayerController must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(APlayerController::StaticClass(), TEXT("bEnableClickEvents"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bEnableClickEvents(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PlayerController",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PlayerController must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(APlayerController::StaticClass(), TEXT("bEnableClickEvents"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bEnableTouchEvents(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PlayerController",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PlayerController must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(APlayerController::StaticClass(), TEXT("bEnableTouchEvents"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bEnableTouchEvents(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PlayerController",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PlayerController must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(APlayerController::StaticClass(), TEXT("bEnableTouchEvents"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bEnableMouseOverEvents(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PlayerController",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PlayerController must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(APlayerController::StaticClass(), TEXT("bEnableMouseOverEvents"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bEnableMouseOverEvents(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PlayerController",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PlayerController must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(APlayerController::StaticClass(), TEXT("bEnableMouseOverEvents"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bEnableTouchOverEvents(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PlayerController",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PlayerController must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(APlayerController::StaticClass(), TEXT("bEnableTouchOverEvents"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bEnableTouchOverEvents(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PlayerController",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PlayerController must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(APlayerController::StaticClass(), TEXT("bEnableTouchOverEvents"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bForceFeedbackEnabled(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PlayerController",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PlayerController must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(APlayerController::StaticClass(), TEXT("bForceFeedbackEnabled"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bForceFeedbackEnabled(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PlayerController",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PlayerController must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(APlayerController::StaticClass(), TEXT("bForceFeedbackEnabled"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_DefaultMouseCursor(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PlayerController",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PlayerController must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(APlayerController::StaticClass(), TEXT("DefaultMouseCursor"));
	if(!Property) { check(false); return 0;}
	TEnumAsByte<EMouseCursor::Type> PropertyValue = TEnumAsByte<EMouseCursor::Type>();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushinteger(InScriptContext, (int)PropertyValue);
	return 1;
}

int32 Get_CurrentMouseCursor(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PlayerController",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PlayerController must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(APlayerController::StaticClass(), TEXT("CurrentMouseCursor"));
	if(!Property) { check(false); return 0;}
	TEnumAsByte<EMouseCursor::Type> PropertyValue = TEnumAsByte<EMouseCursor::Type>();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushinteger(InScriptContext, (int)PropertyValue);
	return 1;
}

int32 Set_CurrentMouseCursor(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PlayerController",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PlayerController must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(APlayerController::StaticClass(), TEXT("CurrentMouseCursor"));
	if(!Property) { check(false); return 0;}
	TEnumAsByte<EMouseCursor::Type> PropertyValue = (TEnumAsByte<EMouseCursor::Type>)(luaL_checkint(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_DefaultClickTraceChannel(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PlayerController",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PlayerController must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(APlayerController::StaticClass(), TEXT("DefaultClickTraceChannel"));
	if(!Property) { check(false); return 0;}
	TEnumAsByte<ECollisionChannel> PropertyValue = TEnumAsByte<ECollisionChannel>();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushinteger(InScriptContext, (int)PropertyValue);
	return 1;
}

int32 Get_CurrentClickTraceChannel(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PlayerController",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PlayerController must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(APlayerController::StaticClass(), TEXT("CurrentClickTraceChannel"));
	if(!Property) { check(false); return 0;}
	TEnumAsByte<ECollisionChannel> PropertyValue = TEnumAsByte<ECollisionChannel>();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushinteger(InScriptContext, (int)PropertyValue);
	return 1;
}

int32 Set_CurrentClickTraceChannel(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PlayerController",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PlayerController must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(APlayerController::StaticClass(), TEXT("CurrentClickTraceChannel"));
	if(!Property) { check(false); return 0;}
	TEnumAsByte<ECollisionChannel> PropertyValue = (TEnumAsByte<ECollisionChannel>)(luaL_checkint(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_HitResultTraceDistance(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PlayerController",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PlayerController must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(APlayerController::StaticClass(), TEXT("HitResultTraceDistance"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_HitResultTraceDistance(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PlayerController",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PlayerController must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(APlayerController::StaticClass(), TEXT("HitResultTraceDistance"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bShouldPerformFullTickWhenPaused(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PlayerController",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PlayerController must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(APlayerController::StaticClass(), TEXT("bShouldPerformFullTickWhenPaused"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bShouldPerformFullTickWhenPaused(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PlayerController",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PlayerController must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(APlayerController::StaticClass(), TEXT("bShouldPerformFullTickWhenPaused"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 New(lua_State* InScriptContext)
{
	UObject* Outer = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Object");
	FName Name = FName(luaL_checkstring(InScriptContext, 2));
	UObject* Obj = NewObject<APlayerController>(Outer, Name);
	wLua::FLuaUtils::ReturnUObject(InScriptContext,Obj);
	return 1;
}

int32 Destroy(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PlayerController",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PlayerController must be non-null"); lua_error(InScriptContext);  return 0;}
		AActor * actor = Cast<AActor>(Obj);
		actor->Destroy();
		userdata->flag |= wLua::LuaObjectFlag::DESTROYED;
		wLua::FLuaUtils::RemoveObjectReference(Obj, userdata->stamp, InScriptContext);
#ifdef AZURE_BUILD_WLUACHECK
		UE_LOG(LogAzure, Warning, TEXT("Destroy PlayerController: %x userdata:%x   stamp:%x"),Obj,userdata,userdata->stamp);
#endif
	return 0;
}

int32 Class(lua_State* InScriptContext)
{
	UClass* Class = APlayerController::StaticClass();
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Class);
	return 1;
}

const luaL_Reg Lib_Funcs[] =
{
	{ "New", New },
	{ "Destroy", Destroy },
	{ "Class", Class },
	{ "ToggleSpeaking", ToggleSpeaking },
	{ "SwitchLevel", SwitchLevel },
	{ "StopHapticEffect", StopHapticEffect },
	{ "StartFire", StartFire },
	{ "SetVirtualJoystickVisibility", SetVirtualJoystickVisibility },
	{ "SetVirtualJoystickPreventReCenter", SetVirtualJoystickPreventReCenter },
	{ "SetViewTargetWithBlend", SetViewTargetWithBlend },
	{ "SetName", SetName },
	{ "SetMouseLocation", SetMouseLocation },
	{ "SetMouseCursorWidget", SetMouseCursorWidget },
	{ "SetHapticsByValue", SetHapticsByValue },
	{ "SetDisableHaptics", SetDisableHaptics },
	{ "SetControllerLightColor", SetControllerLightColor },
	{ "SetCinematicMode", SetCinematicMode },
	{ "SetAudioListenerOverride", SetAudioListenerOverride },
	{ "SetAudioListenerAttenuationOverride", SetAudioListenerAttenuationOverride },
	{ "ServerViewPrevPlayer", ServerViewPrevPlayer },
	{ "ServerViewNextPlayer", ServerViewNextPlayer },
	{ "ServerVerifyViewTarget", ServerVerifyViewTarget },
	{ "ServerUpdateLevelVisibility", ServerUpdateLevelVisibility },
	{ "ServerToggleAILogging", ServerToggleAILogging },
	{ "ServerShortTimeout", ServerShortTimeout },
	{ "ServerSetSpectatorWaiting", ServerSetSpectatorWaiting },
	{ "ServerSetSpectatorLocation", ServerSetSpectatorLocation },
	{ "ServerRestartPlayer", ServerRestartPlayer },
	{ "ServerPause", ServerPause },
	{ "ServerNotifyLoadedWorld", ServerNotifyLoadedWorld },
	{ "ServerCheckClientPossessionReliable", ServerCheckClientPossessionReliable },
	{ "ServerCheckClientPossession", ServerCheckClientPossession },
	{ "ServerChangeName", ServerChangeName },
	{ "ServerCamera", ServerCamera },
	{ "ServerAcknowledgePossession", ServerAcknowledgePossession },
	{ "SendToConsole", SendToConsole },
	{ "RestartLevel", RestartLevel },
	{ "RemoveHiddenComponent", RemoveHiddenComponent },
	{ "ProjectWorldLocationToScreen", ProjectWorldLocationToScreen },
	{ "PlayHapticEffect", PlayHapticEffect },
	{ "Pause", Pause },
	{ "OnServerStartedVisualLogger", OnServerStartedVisualLogger },
	{ "LocalTravel", LocalTravel },
	{ "HiddenComponent", HiddenComponent },
	{ "GetVirtualJoystickCurrentCenterPos", GetVirtualJoystickCurrentCenterPos },
	{ "GetViewportSize", GetViewportSize },
	{ "GetSpectatorPawn", GetSpectatorPawn },
	{ "GetMousePosition", GetMousePosition },
	{ "GetInputTouchState", GetInputTouchState },
	{ "GetInputMouseDelta", GetInputMouseDelta },
	{ "GetInputMotionState", GetInputMotionState },
	{ "GetInputAnalogStickState", GetInputAnalogStickState },
	{ "GetHUD", GetHUD },
	{ "GetFocalLocation", GetFocalLocation },
	{ "GetCurrentTouchInterface", GetCurrentTouchInterface },
	{ "FOV", FOV },
	{ "EnableCheats", EnableCheats },
	{ "DeprojectScreenPositionToWorld", DeprojectScreenPositionToWorld },
	{ "DeprojectMousePositionToWorld", DeprojectMousePositionToWorld },
	{ "ClientWasKicked", ClientWasKicked },
	{ "ClientVoiceHandshakeComplete", ClientVoiceHandshakeComplete },
	{ "ClientUpdateLevelStreamingStatus", ClientUpdateLevelStreamingStatus },
	{ "ClientTeamMessage", ClientTeamMessage },
	{ "ClientStopForceFeedback", ClientStopForceFeedback },
	{ "ClientStopCameraShake", ClientStopCameraShake },
	{ "ClientStopCameraAnim", ClientStopCameraAnim },
	{ "ClientStartOnlineSession", ClientStartOnlineSession },
	{ "ClientSpawnCameraLensEffect", ClientSpawnCameraLensEffect },
	{ "ClientSetSpectatorWaiting", ClientSetSpectatorWaiting },
	{ "ClientSetHUD", ClientSetHUD },
	{ "ClientSetForceMipLevelsToBeResident", ClientSetForceMipLevelsToBeResident },
	{ "ClientSetCinematicMode", ClientSetCinematicMode },
	{ "ClientSetCameraMode", ClientSetCameraMode },
	{ "ClientSetCameraFade", ClientSetCameraFade },
	{ "ClientSetBlockOnAsyncLoading", ClientSetBlockOnAsyncLoading },
	{ "ClientReturnToMainMenuWithTextReason", ClientReturnToMainMenuWithTextReason },
	{ "ClientReturnToMainMenu", ClientReturnToMainMenu },
	{ "ClientRetryClientRestart", ClientRetryClientRestart },
	{ "ClientRestart", ClientRestart },
	{ "ClientReset", ClientReset },
	{ "ClientRepObjRef", ClientRepObjRef },
	{ "ClientReceiveLocalizedMessage", ClientReceiveLocalizedMessage },
	{ "ClientPrestreamTextures", ClientPrestreamTextures },
	{ "ClientPrepareMapChange", ClientPrepareMapChange },
	{ "ClientPlaySoundAtLocation", ClientPlaySoundAtLocation },
	{ "ClientPlaySound", ClientPlaySound },
	{ "ClientPlayForceFeedback", ClientPlayForceFeedback },
	{ "ClientPlayCameraShake", ClientPlayCameraShake },
	{ "ClientPlayCameraAnim", ClientPlayCameraAnim },
	{ "ClientMessage", ClientMessage },
	{ "ClientIgnoreMoveInput", ClientIgnoreMoveInput },
	{ "ClientIgnoreLookInput", ClientIgnoreLookInput },
	{ "ClientGotoState", ClientGotoState },
	{ "ClientGameEnded", ClientGameEnded },
	{ "ClientForceGarbageCollection", ClientForceGarbageCollection },
	{ "ClientFlushLevelStreaming", ClientFlushLevelStreaming },
	{ "ClientEndOnlineSession", ClientEndOnlineSession },
	{ "ClientEnableNetworkVoice", ClientEnableNetworkVoice },
	{ "ClientCommitMapChange", ClientCommitMapChange },
	{ "ClientClearCameraLensEffects", ClientClearCameraLensEffects },
	{ "ClientCapBandwidth", ClientCapBandwidth },
	{ "ClientCancelPendingMapChange", ClientCancelPendingMapChange },
	{ "ClientAddTextureStreamingLoc", ClientAddTextureStreamingLoc },
	{ "ClearAudioListenerOverride", ClearAudioListenerOverride },
	{ "ClearAudioListenerAttenuationOverride", ClearAudioListenerAttenuationOverride },
	{ "CanRestartPlayer", CanRestartPlayer },
	{ "Camera", Camera },
	{ "AzureSetBasicControlPositionChanged", AzureSetBasicControlPositionChanged },
	{ "AddYawInput", AddYawInput },
	{ "AddRollInput", AddRollInput },
	{ "AddPitchInput", AddPitchInput },
	{ "ActivateTouchInterface", ActivateTouchInterface },
	{ "Get_PlayerCameraManager", Get_PlayerCameraManager },
	{ "Get_PlayerCameraManagerClass", Get_PlayerCameraManagerClass },
	{ "Get_bAutoManageActiveCameraTarget", Get_bAutoManageActiveCameraTarget },
	{ "Set_bAutoManageActiveCameraTarget", Set_bAutoManageActiveCameraTarget },
	{ "Get_SmoothTargetViewRotationSpeed", Get_SmoothTargetViewRotationSpeed },
	{ "Set_SmoothTargetViewRotationSpeed", Set_SmoothTargetViewRotationSpeed },
	{ "Get_HiddenActors", Get_HiddenActors },
	{ "Set_HiddenActors", Set_HiddenActors },
	{ "Get_CheatManager", Get_CheatManager },
	{ "Get_CheatClass", Get_CheatClass },
	{ "Get_bPlayerIsWaiting", Get_bPlayerIsWaiting },
	{ "Get_InputYawScale", Get_InputYawScale },
	{ "Set_InputYawScale", Set_InputYawScale },
	{ "Get_InputPitchScale", Get_InputPitchScale },
	{ "Set_InputPitchScale", Set_InputPitchScale },
	{ "Get_InputRollScale", Get_InputRollScale },
	{ "Set_InputRollScale", Set_InputRollScale },
	{ "Get_bShowMouseCursor", Get_bShowMouseCursor },
	{ "Set_bShowMouseCursor", Set_bShowMouseCursor },
	{ "Get_bEnableClickEvents", Get_bEnableClickEvents },
	{ "Set_bEnableClickEvents", Set_bEnableClickEvents },
	{ "Get_bEnableTouchEvents", Get_bEnableTouchEvents },
	{ "Set_bEnableTouchEvents", Set_bEnableTouchEvents },
	{ "Get_bEnableMouseOverEvents", Get_bEnableMouseOverEvents },
	{ "Set_bEnableMouseOverEvents", Set_bEnableMouseOverEvents },
	{ "Get_bEnableTouchOverEvents", Get_bEnableTouchOverEvents },
	{ "Set_bEnableTouchOverEvents", Set_bEnableTouchOverEvents },
	{ "Get_bForceFeedbackEnabled", Get_bForceFeedbackEnabled },
	{ "Set_bForceFeedbackEnabled", Set_bForceFeedbackEnabled },
	{ "Get_DefaultMouseCursor", Get_DefaultMouseCursor },
	{ "Get_CurrentMouseCursor", Get_CurrentMouseCursor },
	{ "Set_CurrentMouseCursor", Set_CurrentMouseCursor },
	{ "Get_DefaultClickTraceChannel", Get_DefaultClickTraceChannel },
	{ "Get_CurrentClickTraceChannel", Get_CurrentClickTraceChannel },
	{ "Set_CurrentClickTraceChannel", Set_CurrentClickTraceChannel },
	{ "Get_HitResultTraceDistance", Get_HitResultTraceDistance },
	{ "Set_HitResultTraceDistance", Set_HitResultTraceDistance },
	{ "Get_bShouldPerformFullTickWhenPaused", Get_bShouldPerformFullTickWhenPaused },
	{ "Set_bShouldPerformFullTickWhenPaused", Set_bShouldPerformFullTickWhenPaused },
	{ "DeprojectMousePositionToWorld", DeprojectMousePositionToWorld2 },
	{ "DeprojectScreenPositionToWorld", DeprojectScreenPositionToWorld2 },
	{ "GetPlayerViewPoint", GetPlayerViewPoint },
	{ "IsInputKeyDown", IsInputKeyDown },
	{ "LoadTouchInterface", LoadTouchInterface },
	{ "is_nil", wLua::LuaStatic::isnil },
	{ "__gc", wLua::LuaStatic::removeUClassFrameCache },
	{ NULL, NULL }
};

void Register(lua_State *InScriptContext)
{
	lua_newtable(InScriptContext);
	luaL_register(InScriptContext, NULL, Lib_Funcs);
	AzureHelpFuncs::AuxRegister(InScriptContext, "PlayerController");
}
void SetMtLink(lua_State *InScriptContext)
{
	AzureHelpFuncs::AuxSetMtLink(InScriptContext, "PlayerController", "Controller",USERDATATYPE_UOBJECT);
}

}