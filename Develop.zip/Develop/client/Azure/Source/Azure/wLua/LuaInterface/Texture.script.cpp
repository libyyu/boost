#include "Azure.h"
#include "Utility/help_funcs.h"
#include "wLua/UObjectHeaders.h"
#include "AzureLuaIntegration.h"

namespace LuaTexture
{
int32 Get_AssetImportData(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Texture",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Texture must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UTexture::StaticClass(), TEXT("AssetImportData"));
	if(!Property) { check(false); return 0;}
	UAssetImportData* PropertyValue;
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaUtils::ReturnUObject(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_AssetImportData(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Texture",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Texture must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UTexture::StaticClass(), TEXT("AssetImportData"));
	if(!Property) { check(false); return 0;}
	UAssetImportData* PropertyValue = (UAssetImportData*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"AssetImportData");;
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_AdjustBrightness(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Texture",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Texture must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UTexture::StaticClass(), TEXT("AdjustBrightness"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_AdjustBrightness(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Texture",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Texture must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UTexture::StaticClass(), TEXT("AdjustBrightness"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_AdjustBrightnessCurve(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Texture",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Texture must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UTexture::StaticClass(), TEXT("AdjustBrightnessCurve"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_AdjustBrightnessCurve(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Texture",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Texture must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UTexture::StaticClass(), TEXT("AdjustBrightnessCurve"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_AdjustVibrance(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Texture",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Texture must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UTexture::StaticClass(), TEXT("AdjustVibrance"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_AdjustVibrance(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Texture",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Texture must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UTexture::StaticClass(), TEXT("AdjustVibrance"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_AdjustSaturation(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Texture",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Texture must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UTexture::StaticClass(), TEXT("AdjustSaturation"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_AdjustSaturation(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Texture",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Texture must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UTexture::StaticClass(), TEXT("AdjustSaturation"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_AdjustRGBCurve(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Texture",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Texture must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UTexture::StaticClass(), TEXT("AdjustRGBCurve"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_AdjustRGBCurve(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Texture",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Texture must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UTexture::StaticClass(), TEXT("AdjustRGBCurve"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_AdjustHue(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Texture",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Texture must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UTexture::StaticClass(), TEXT("AdjustHue"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_AdjustHue(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Texture",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Texture must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UTexture::StaticClass(), TEXT("AdjustHue"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_AdjustMinAlpha(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Texture",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Texture must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UTexture::StaticClass(), TEXT("AdjustMinAlpha"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_AdjustMinAlpha(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Texture",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Texture must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UTexture::StaticClass(), TEXT("AdjustMinAlpha"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_AdjustMaxAlpha(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Texture",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Texture must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UTexture::StaticClass(), TEXT("AdjustMaxAlpha"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_AdjustMaxAlpha(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Texture",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Texture must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UTexture::StaticClass(), TEXT("AdjustMaxAlpha"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_CompressionNoAlpha(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Texture",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Texture must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UTexture::StaticClass(), TEXT("CompressionNoAlpha"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_CompressionNoAlpha(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Texture",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Texture must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UTexture::StaticClass(), TEXT("CompressionNoAlpha"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_DeferCompression(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Texture",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Texture must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UTexture::StaticClass(), TEXT("DeferCompression"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_DeferCompression(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Texture",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Texture must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UTexture::StaticClass(), TEXT("DeferCompression"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_MaxTextureSize(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Texture",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Texture must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UTexture::StaticClass(), TEXT("MaxTextureSize"));
	if(!Property) { check(false); return 0;}
	int32 PropertyValue = int32();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushinteger(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_CompressionQuality(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Texture",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Texture must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UTexture::StaticClass(), TEXT("CompressionQuality"));
	if(!Property) { check(false); return 0;}
	TEnumAsByte<ETextureCompressionQuality> PropertyValue = TEnumAsByte<ETextureCompressionQuality>();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushinteger(InScriptContext, (int)PropertyValue);
	return 1;
}

int32 Set_CompressionQuality(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Texture",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Texture must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UTexture::StaticClass(), TEXT("CompressionQuality"));
	if(!Property) { check(false); return 0;}
	TEnumAsByte<ETextureCompressionQuality> PropertyValue = (TEnumAsByte<ETextureCompressionQuality>)(luaL_checkint(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bDitherMipMapAlpha(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Texture",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Texture must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UTexture::StaticClass(), TEXT("bDitherMipMapAlpha"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bDitherMipMapAlpha(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Texture",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Texture must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UTexture::StaticClass(), TEXT("bDitherMipMapAlpha"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_AlphaCoverageThresholds(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Texture",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Texture must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UTexture::StaticClass(), TEXT("AlphaCoverageThresholds"));
	if(!Property) { check(false); return 0;}
	FVector4 PropertyValue = FVector4();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaVector4::Return(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_AlphaCoverageThresholds(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Texture",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Texture must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UTexture::StaticClass(), TEXT("AlphaCoverageThresholds"));
	if(!Property) { check(false); return 0;}
	FVector4 PropertyValue = (wLua::FLuaVector4::Get(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bPreserveBorder(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Texture",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Texture must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UTexture::StaticClass(), TEXT("bPreserveBorder"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bPreserveBorder(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Texture",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Texture must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UTexture::StaticClass(), TEXT("bPreserveBorder"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bFlipGreenChannel(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Texture",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Texture must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UTexture::StaticClass(), TEXT("bFlipGreenChannel"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bFlipGreenChannel(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Texture",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Texture must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UTexture::StaticClass(), TEXT("bFlipGreenChannel"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_PowerOfTwoMode(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Texture",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Texture must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UTexture::StaticClass(), TEXT("PowerOfTwoMode"));
	if(!Property) { check(false); return 0;}
	TEnumAsByte<ETexturePowerOfTwoSetting::Type> PropertyValue = TEnumAsByte<ETexturePowerOfTwoSetting::Type>();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushinteger(InScriptContext, (int)PropertyValue);
	return 1;
}

int32 Set_PowerOfTwoMode(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Texture",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Texture must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UTexture::StaticClass(), TEXT("PowerOfTwoMode"));
	if(!Property) { check(false); return 0;}
	TEnumAsByte<ETexturePowerOfTwoSetting::Type> PropertyValue = (TEnumAsByte<ETexturePowerOfTwoSetting::Type>)(luaL_checkint(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_PaddingColor(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Texture",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Texture must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UTexture::StaticClass(), TEXT("PaddingColor"));
	if(!Property) { check(false); return 0;}
	FColor PropertyValue = FColor();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaLinearColor::Return(InScriptContext, FLinearColor(PropertyValue));
	return 1;
}

int32 Set_PaddingColor(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Texture",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Texture must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UTexture::StaticClass(), TEXT("PaddingColor"));
	if(!Property) { check(false); return 0;}
	FColor PropertyValue = (wLua::FLuaLinearColor::GetColor(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bChromaKeyTexture(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Texture",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Texture must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UTexture::StaticClass(), TEXT("bChromaKeyTexture"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = bool();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bChromaKeyTexture(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Texture",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Texture must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UTexture::StaticClass(), TEXT("bChromaKeyTexture"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_ChromaKeyThreshold(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Texture",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Texture must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UTexture::StaticClass(), TEXT("ChromaKeyThreshold"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_ChromaKeyThreshold(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Texture",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Texture must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UTexture::StaticClass(), TEXT("ChromaKeyThreshold"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_ChromaKeyColor(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Texture",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Texture must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UTexture::StaticClass(), TEXT("ChromaKeyColor"));
	if(!Property) { check(false); return 0;}
	FColor PropertyValue = FColor();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaLinearColor::Return(InScriptContext, FLinearColor(PropertyValue));
	return 1;
}

int32 Set_ChromaKeyColor(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Texture",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Texture must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UTexture::StaticClass(), TEXT("ChromaKeyColor"));
	if(!Property) { check(false); return 0;}
	FColor PropertyValue = (wLua::FLuaLinearColor::GetColor(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_MipGenSettings(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Texture",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Texture must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UTexture::StaticClass(), TEXT("MipGenSettings"));
	if(!Property) { check(false); return 0;}
	TEnumAsByte<TextureMipGenSettings> PropertyValue = TEnumAsByte<TextureMipGenSettings>();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushinteger(InScriptContext, (int)PropertyValue);
	return 1;
}

int32 Set_MipGenSettings(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Texture",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Texture must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UTexture::StaticClass(), TEXT("MipGenSettings"));
	if(!Property) { check(false); return 0;}
	TEnumAsByte<TextureMipGenSettings> PropertyValue = (TEnumAsByte<TextureMipGenSettings>)(luaL_checkint(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_CompositeTexture(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Texture",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Texture must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UTexture::StaticClass(), TEXT("CompositeTexture"));
	if(!Property) { check(false); return 0;}
	UTexture* PropertyValue;
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaUtils::ReturnUObject(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_CompositeTexture(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Texture",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Texture must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UTexture::StaticClass(), TEXT("CompositeTexture"));
	if(!Property) { check(false); return 0;}
	UTexture* PropertyValue = (UTexture*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"Texture");;
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_CompositeTextureMode(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Texture",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Texture must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UTexture::StaticClass(), TEXT("CompositeTextureMode"));
	if(!Property) { check(false); return 0;}
	TEnumAsByte<ECompositeTextureMode> PropertyValue = TEnumAsByte<ECompositeTextureMode>();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushinteger(InScriptContext, (int)PropertyValue);
	return 1;
}

int32 Set_CompositeTextureMode(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Texture",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Texture must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UTexture::StaticClass(), TEXT("CompositeTextureMode"));
	if(!Property) { check(false); return 0;}
	TEnumAsByte<ECompositeTextureMode> PropertyValue = (TEnumAsByte<ECompositeTextureMode>)(luaL_checkint(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_CompositePower(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Texture",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Texture must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UTexture::StaticClass(), TEXT("CompositePower"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_CompositePower(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Texture",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Texture must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UTexture::StaticClass(), TEXT("CompositePower"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_LODBias(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Texture",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Texture must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UTexture::StaticClass(), TEXT("LODBias"));
	if(!Property) { check(false); return 0;}
	int32 PropertyValue = int32();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushinteger(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_LODBias(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Texture",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Texture must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UTexture::StaticClass(), TEXT("LODBias"));
	if(!Property) { check(false); return 0;}
	int32 PropertyValue = (luaL_checkint(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_NumCinematicMipLevels(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Texture",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Texture must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UTexture::StaticClass(), TEXT("NumCinematicMipLevels"));
	if(!Property) { check(false); return 0;}
	int32 PropertyValue = int32();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushinteger(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_NumCinematicMipLevels(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Texture",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Texture must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UTexture::StaticClass(), TEXT("NumCinematicMipLevels"));
	if(!Property) { check(false); return 0;}
	int32 PropertyValue = (luaL_checkint(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_CompressionSettings(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Texture",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Texture must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UTexture::StaticClass(), TEXT("CompressionSettings"));
	if(!Property) { check(false); return 0;}
	TEnumAsByte<TextureCompressionSettings> PropertyValue = TEnumAsByte<TextureCompressionSettings>();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushinteger(InScriptContext, (int)PropertyValue);
	return 1;
}

int32 Set_CompressionSettings(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Texture",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Texture must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UTexture::StaticClass(), TEXT("CompressionSettings"));
	if(!Property) { check(false); return 0;}
	TEnumAsByte<TextureCompressionSettings> PropertyValue = (TEnumAsByte<TextureCompressionSettings>)(luaL_checkint(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_Filter(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Texture",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Texture must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UTexture::StaticClass(), TEXT("Filter"));
	if(!Property) { check(false); return 0;}
	TEnumAsByte<TextureFilter> PropertyValue = TEnumAsByte<TextureFilter>();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushinteger(InScriptContext, (int)PropertyValue);
	return 1;
}

int32 Set_Filter(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Texture",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Texture must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UTexture::StaticClass(), TEXT("Filter"));
	if(!Property) { check(false); return 0;}
	TEnumAsByte<TextureFilter> PropertyValue = (TEnumAsByte<TextureFilter>)(luaL_checkint(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_LODGroup(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Texture",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Texture must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UTexture::StaticClass(), TEXT("LODGroup"));
	if(!Property) { check(false); return 0;}
	TEnumAsByte<TextureGroup> PropertyValue = TEnumAsByte<TextureGroup>();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushinteger(InScriptContext, (int)PropertyValue);
	return 1;
}

int32 Set_LODGroup(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Texture",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Texture must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UTexture::StaticClass(), TEXT("LODGroup"));
	if(!Property) { check(false); return 0;}
	TEnumAsByte<TextureGroup> PropertyValue = (TEnumAsByte<TextureGroup>)(luaL_checkint(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_SRGB(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Texture",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Texture must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UTexture::StaticClass(), TEXT("SRGB"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_SRGB(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Texture",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Texture must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UTexture::StaticClass(), TEXT("SRGB"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bUseLegacyGamma(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Texture",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Texture must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UTexture::StaticClass(), TEXT("bUseLegacyGamma"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bUseLegacyGamma(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Texture",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Texture must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UTexture::StaticClass(), TEXT("bUseLegacyGamma"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_NeverStream(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Texture",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Texture must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UTexture::StaticClass(), TEXT("NeverStream"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_NeverStream(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Texture",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Texture must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UTexture::StaticClass(), TEXT("NeverStream"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_AssetUserData(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Texture",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Texture must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UTexture::StaticClass(), TEXT("AssetUserData"));
	if(!Property) { check(false); return 0;}
	TArray<UAssetUserData*> PropertyValue;
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	{lua_newtable(InScriptContext); int i = 1; for(auto It = PropertyValue.CreateConstIterator(); It; ++It,++i) {  wLua::FLuaUtils::ReturnUObject(InScriptContext, (*It)); lua_rawseti(InScriptContext,-2,i);     }  }
	return 1;
}

int32 Set_AssetUserData(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Texture",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Texture must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UTexture::StaticClass(), TEXT("AssetUserData"));
	if(!Property) { check(false); return 0;}
	TArray<UAssetUserData*> PropertyValue = [](lua_State * _InScriptContext){ TArray<UAssetUserData*> ret; lua_pushnil(_InScriptContext); while(lua_next(_InScriptContext,2)!=0){ UAssetUserData* item = (UAssetUserData*)wLua::FLuaUtils::GetUObject(_InScriptContext,-1,"AssetUserData");; ret.Add(item); lua_pop(_InScriptContext,1);  } return ret; }(InScriptContext);;
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Class(lua_State* InScriptContext)
{
	UClass* Class = UTexture::StaticClass();
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Class);
	return 1;
}

const luaL_Reg Lib_Funcs[] =
{
	{ "Class", Class },
	{ "Get_AssetImportData", Get_AssetImportData },
	{ "Set_AssetImportData", Set_AssetImportData },
	{ "Get_AdjustBrightness", Get_AdjustBrightness },
	{ "Set_AdjustBrightness", Set_AdjustBrightness },
	{ "Get_AdjustBrightnessCurve", Get_AdjustBrightnessCurve },
	{ "Set_AdjustBrightnessCurve", Set_AdjustBrightnessCurve },
	{ "Get_AdjustVibrance", Get_AdjustVibrance },
	{ "Set_AdjustVibrance", Set_AdjustVibrance },
	{ "Get_AdjustSaturation", Get_AdjustSaturation },
	{ "Set_AdjustSaturation", Set_AdjustSaturation },
	{ "Get_AdjustRGBCurve", Get_AdjustRGBCurve },
	{ "Set_AdjustRGBCurve", Set_AdjustRGBCurve },
	{ "Get_AdjustHue", Get_AdjustHue },
	{ "Set_AdjustHue", Set_AdjustHue },
	{ "Get_AdjustMinAlpha", Get_AdjustMinAlpha },
	{ "Set_AdjustMinAlpha", Set_AdjustMinAlpha },
	{ "Get_AdjustMaxAlpha", Get_AdjustMaxAlpha },
	{ "Set_AdjustMaxAlpha", Set_AdjustMaxAlpha },
	{ "Get_CompressionNoAlpha", Get_CompressionNoAlpha },
	{ "Set_CompressionNoAlpha", Set_CompressionNoAlpha },
	{ "Get_DeferCompression", Get_DeferCompression },
	{ "Set_DeferCompression", Set_DeferCompression },
	{ "Get_MaxTextureSize", Get_MaxTextureSize },
	{ "Get_CompressionQuality", Get_CompressionQuality },
	{ "Set_CompressionQuality", Set_CompressionQuality },
	{ "Get_bDitherMipMapAlpha", Get_bDitherMipMapAlpha },
	{ "Set_bDitherMipMapAlpha", Set_bDitherMipMapAlpha },
	{ "Get_AlphaCoverageThresholds", Get_AlphaCoverageThresholds },
	{ "Set_AlphaCoverageThresholds", Set_AlphaCoverageThresholds },
	{ "Get_bPreserveBorder", Get_bPreserveBorder },
	{ "Set_bPreserveBorder", Set_bPreserveBorder },
	{ "Get_bFlipGreenChannel", Get_bFlipGreenChannel },
	{ "Set_bFlipGreenChannel", Set_bFlipGreenChannel },
	{ "Get_PowerOfTwoMode", Get_PowerOfTwoMode },
	{ "Set_PowerOfTwoMode", Set_PowerOfTwoMode },
	{ "Get_PaddingColor", Get_PaddingColor },
	{ "Set_PaddingColor", Set_PaddingColor },
	{ "Get_bChromaKeyTexture", Get_bChromaKeyTexture },
	{ "Set_bChromaKeyTexture", Set_bChromaKeyTexture },
	{ "Get_ChromaKeyThreshold", Get_ChromaKeyThreshold },
	{ "Set_ChromaKeyThreshold", Set_ChromaKeyThreshold },
	{ "Get_ChromaKeyColor", Get_ChromaKeyColor },
	{ "Set_ChromaKeyColor", Set_ChromaKeyColor },
	{ "Get_MipGenSettings", Get_MipGenSettings },
	{ "Set_MipGenSettings", Set_MipGenSettings },
	{ "Get_CompositeTexture", Get_CompositeTexture },
	{ "Set_CompositeTexture", Set_CompositeTexture },
	{ "Get_CompositeTextureMode", Get_CompositeTextureMode },
	{ "Set_CompositeTextureMode", Set_CompositeTextureMode },
	{ "Get_CompositePower", Get_CompositePower },
	{ "Set_CompositePower", Set_CompositePower },
	{ "Get_LODBias", Get_LODBias },
	{ "Set_LODBias", Set_LODBias },
	{ "Get_NumCinematicMipLevels", Get_NumCinematicMipLevels },
	{ "Set_NumCinematicMipLevels", Set_NumCinematicMipLevels },
	{ "Get_CompressionSettings", Get_CompressionSettings },
	{ "Set_CompressionSettings", Set_CompressionSettings },
	{ "Get_Filter", Get_Filter },
	{ "Set_Filter", Set_Filter },
	{ "Get_LODGroup", Get_LODGroup },
	{ "Set_LODGroup", Set_LODGroup },
	{ "Get_SRGB", Get_SRGB },
	{ "Set_SRGB", Set_SRGB },
	{ "Get_bUseLegacyGamma", Get_bUseLegacyGamma },
	{ "Set_bUseLegacyGamma", Set_bUseLegacyGamma },
	{ "Get_NeverStream", Get_NeverStream },
	{ "Set_NeverStream", Set_NeverStream },
	{ "Get_AssetUserData", Get_AssetUserData },
	{ "Set_AssetUserData", Set_AssetUserData },
	{ "is_nil", wLua::LuaStatic::isnil },
	{ "__gc", wLua::LuaStatic::removeUClassFrameCache },
	{ NULL, NULL }
};

void Register(lua_State *InScriptContext)
{
	lua_newtable(InScriptContext);
	luaL_register(InScriptContext, NULL, Lib_Funcs);
	AzureHelpFuncs::AuxRegister(InScriptContext, "Texture");
}
void SetMtLink(lua_State *InScriptContext)
{
	AzureHelpFuncs::AuxSetMtLink(InScriptContext, "Texture", "Object",USERDATATYPE_UOBJECT);
}

}