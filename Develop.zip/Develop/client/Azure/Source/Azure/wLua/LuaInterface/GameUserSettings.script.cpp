#include "Azure.h"
#include "Utility/help_funcs.h"
#include "wLua/UObjectHeaders.h"
#include "GameFramework/GameUserSettings.h"
#include "AzureLuaIntegration.h"

namespace LuaGameUserSettings
{
int32 ValidateSettings(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"GameUserSettings",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"GameUserSettings must be non-null"); lua_error(InScriptContext);  return 0;}
#if UE_GAME
	UGameUserSettings * This = (UGameUserSettings *)Obj;
	This->ValidateSettings();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("ValidateSettings"));
	if(!Function) { check(false); return 0;}
	Obj->ProcessEvent(Function, NULL);
#endif
	return 0;
}

int32 SupportsHDRDisplayOutput(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"GameUserSettings",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"GameUserSettings must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool ReturnValue;
	} Params;
#if UE_GAME
	UGameUserSettings * This = (UGameUserSettings *)Obj;
	Params.ReturnValue = This->SupportsHDRDisplayOutput();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SupportsHDRDisplayOutput"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushboolean(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 SetVSyncEnabled(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"GameUserSettings",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"GameUserSettings must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool bEnable;
	} Params;
	Params.bEnable = !!(lua_toboolean(InScriptContext, 2));
#if UE_GAME
	UGameUserSettings * This = (UGameUserSettings *)Obj;
	This->SetVSyncEnabled(Params.bEnable);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetVSyncEnabled"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(bool*)(params.GetStructMemory() + 0) = Params.bEnable;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.bEnable = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetVisualEffectQuality(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"GameUserSettings",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"GameUserSettings must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		int32 Value;
	} Params;
	Params.Value = (luaL_checkint(InScriptContext, 2));
#if UE_GAME
	UGameUserSettings * This = (UGameUserSettings *)Obj;
	This->SetVisualEffectQuality(Params.Value);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetVisualEffectQuality"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(int32*)(params.GetStructMemory() + 0) = Params.Value;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.Value = *(int32*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetViewDistanceQuality(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"GameUserSettings",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"GameUserSettings must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		int32 Value;
	} Params;
	Params.Value = (luaL_checkint(InScriptContext, 2));
#if UE_GAME
	UGameUserSettings * This = (UGameUserSettings *)Obj;
	This->SetViewDistanceQuality(Params.Value);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetViewDistanceQuality"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(int32*)(params.GetStructMemory() + 0) = Params.Value;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.Value = *(int32*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetToDefaults(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"GameUserSettings",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"GameUserSettings must be non-null"); lua_error(InScriptContext);  return 0;}
#if UE_GAME
	UGameUserSettings * This = (UGameUserSettings *)Obj;
	This->SetToDefaults();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetToDefaults"));
	if(!Function) { check(false); return 0;}
	Obj->ProcessEvent(Function, NULL);
#endif
	return 0;
}

int32 SetTextureQuality(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"GameUserSettings",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"GameUserSettings must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		int32 Value;
	} Params;
	Params.Value = (luaL_checkint(InScriptContext, 2));
#if UE_GAME
	UGameUserSettings * This = (UGameUserSettings *)Obj;
	This->SetTextureQuality(Params.Value);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetTextureQuality"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(int32*)(params.GetStructMemory() + 0) = Params.Value;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.Value = *(int32*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetShadowQuality(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"GameUserSettings",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"GameUserSettings must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		int32 Value;
	} Params;
	Params.Value = (luaL_checkint(InScriptContext, 2));
#if UE_GAME
	UGameUserSettings * This = (UGameUserSettings *)Obj;
	This->SetShadowQuality(Params.Value);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetShadowQuality"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(int32*)(params.GetStructMemory() + 0) = Params.Value;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.Value = *(int32*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetResolutionScaleValueEx(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"GameUserSettings",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"GameUserSettings must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float NewScaleValue;
	} Params;
	Params.NewScaleValue = (float)(luaL_checknumber(InScriptContext, 2));
#if UE_GAME
	UGameUserSettings * This = (UGameUserSettings *)Obj;
	This->SetResolutionScaleValueEx(Params.NewScaleValue);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetResolutionScaleValueEx"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(float*)(params.GetStructMemory() + 0) = Params.NewScaleValue;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.NewScaleValue = *(float*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetResolutionScaleNormalized(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"GameUserSettings",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"GameUserSettings must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float NewScaleNormalized;
	} Params;
	Params.NewScaleNormalized = (float)(luaL_checknumber(InScriptContext, 2));
#if UE_GAME
	UGameUserSettings * This = (UGameUserSettings *)Obj;
	This->SetResolutionScaleNormalized(Params.NewScaleNormalized);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetResolutionScaleNormalized"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(float*)(params.GetStructMemory() + 0) = Params.NewScaleNormalized;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.NewScaleNormalized = *(float*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetPostProcessingQuality(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"GameUserSettings",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"GameUserSettings must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		int32 Value;
	} Params;
	Params.Value = (luaL_checkint(InScriptContext, 2));
#if UE_GAME
	UGameUserSettings * This = (UGameUserSettings *)Obj;
	This->SetPostProcessingQuality(Params.Value);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetPostProcessingQuality"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(int32*)(params.GetStructMemory() + 0) = Params.Value;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.Value = *(int32*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetOverallScalabilityLevel(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"GameUserSettings",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"GameUserSettings must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		int32 Value;
	} Params;
	Params.Value = (luaL_checkint(InScriptContext, 2));
#if UE_GAME
	UGameUserSettings * This = (UGameUserSettings *)Obj;
	This->SetOverallScalabilityLevel(Params.Value);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetOverallScalabilityLevel"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(int32*)(params.GetStructMemory() + 0) = Params.Value;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.Value = *(int32*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetFullscreenMode(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"GameUserSettings",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"GameUserSettings must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		TEnumAsByte<EWindowMode::Type> InFullscreenMode;
	} Params;
	Params.InFullscreenMode = (TEnumAsByte<EWindowMode::Type>)(luaL_checkint(InScriptContext, 2));
#if UE_GAME
	UGameUserSettings * This = (UGameUserSettings *)Obj;
	This->SetFullscreenMode(Params.InFullscreenMode);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetFullscreenMode"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(TEnumAsByte<EWindowMode::Type>*)(params.GetStructMemory() + 0) = Params.InFullscreenMode;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.InFullscreenMode = *(TEnumAsByte<EWindowMode::Type>*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetFrameRateLimit(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"GameUserSettings",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"GameUserSettings must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float NewLimit;
	} Params;
	Params.NewLimit = (float)(luaL_checknumber(InScriptContext, 2));
#if UE_GAME
	UGameUserSettings * This = (UGameUserSettings *)Obj;
	This->SetFrameRateLimit(Params.NewLimit);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetFrameRateLimit"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(float*)(params.GetStructMemory() + 0) = Params.NewLimit;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.NewLimit = *(float*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetFoliageQuality(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"GameUserSettings",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"GameUserSettings must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		int32 Value;
	} Params;
	Params.Value = (luaL_checkint(InScriptContext, 2));
#if UE_GAME
	UGameUserSettings * This = (UGameUserSettings *)Obj;
	This->SetFoliageQuality(Params.Value);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetFoliageQuality"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(int32*)(params.GetStructMemory() + 0) = Params.Value;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.Value = *(int32*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetDynamicResolutionEnabled(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"GameUserSettings",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"GameUserSettings must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool bEnable;
	} Params;
	Params.bEnable = !!(lua_toboolean(InScriptContext, 2));
#if UE_GAME
	UGameUserSettings * This = (UGameUserSettings *)Obj;
	This->SetDynamicResolutionEnabled(Params.bEnable);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetDynamicResolutionEnabled"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(bool*)(params.GetStructMemory() + 0) = Params.bEnable;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.bEnable = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetBenchmarkFallbackValues(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"GameUserSettings",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"GameUserSettings must be non-null"); lua_error(InScriptContext);  return 0;}
#if UE_GAME
	UGameUserSettings * This = (UGameUserSettings *)Obj;
	This->SetBenchmarkFallbackValues();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetBenchmarkFallbackValues"));
	if(!Function) { check(false); return 0;}
	Obj->ProcessEvent(Function, NULL);
#endif
	return 0;
}

int32 SetAudioQualityLevel(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"GameUserSettings",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"GameUserSettings must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		int32 QualityLevel;
	} Params;
	Params.QualityLevel = (luaL_checkint(InScriptContext, 2));
#if UE_GAME
	UGameUserSettings * This = (UGameUserSettings *)Obj;
	This->SetAudioQualityLevel(Params.QualityLevel);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetAudioQualityLevel"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(int32*)(params.GetStructMemory() + 0) = Params.QualityLevel;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.QualityLevel = *(int32*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetAntiAliasingQuality(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"GameUserSettings",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"GameUserSettings must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		int32 Value;
	} Params;
	Params.Value = (luaL_checkint(InScriptContext, 2));
#if UE_GAME
	UGameUserSettings * This = (UGameUserSettings *)Obj;
	This->SetAntiAliasingQuality(Params.Value);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetAntiAliasingQuality"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(int32*)(params.GetStructMemory() + 0) = Params.Value;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.Value = *(int32*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SaveSettings(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"GameUserSettings",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"GameUserSettings must be non-null"); lua_error(InScriptContext);  return 0;}
#if UE_GAME
	UGameUserSettings * This = (UGameUserSettings *)Obj;
	This->SaveSettings();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SaveSettings"));
	if(!Function) { check(false); return 0;}
	Obj->ProcessEvent(Function, NULL);
#endif
	return 0;
}

int32 RunHardwareBenchmark(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"GameUserSettings",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"GameUserSettings must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		int32 WorkScale;
		float CPUMultiplier;
		float GPUMultiplier;
	} Params;
	Params.WorkScale = lua_isnoneornil(InScriptContext,2) ? int32(10) : (luaL_checkint(InScriptContext, 2));
	Params.CPUMultiplier = lua_isnoneornil(InScriptContext,3) ? float(1.000000) : (float)(luaL_checknumber(InScriptContext, 3));
	Params.GPUMultiplier = lua_isnoneornil(InScriptContext,4) ? float(1.000000) : (float)(luaL_checknumber(InScriptContext, 4));
#if UE_GAME
	UGameUserSettings * This = (UGameUserSettings *)Obj;
	This->RunHardwareBenchmark(Params.WorkScale,Params.CPUMultiplier,Params.GPUMultiplier);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("RunHardwareBenchmark"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(int32*)(params.GetStructMemory() + 0) = Params.WorkScale;
		*(float*)(params.GetStructMemory() + 4) = Params.CPUMultiplier;
		*(float*)(params.GetStructMemory() + 8) = Params.GPUMultiplier;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.WorkScale = *(int32*)(params.GetStructMemory() + 0);
		Params.CPUMultiplier = *(float*)(params.GetStructMemory() + 4);
		Params.GPUMultiplier = *(float*)(params.GetStructMemory() + 8);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 RevertVideoMode(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"GameUserSettings",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"GameUserSettings must be non-null"); lua_error(InScriptContext);  return 0;}
#if UE_GAME
	UGameUserSettings * This = (UGameUserSettings *)Obj;
	This->RevertVideoMode();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("RevertVideoMode"));
	if(!Function) { check(false); return 0;}
	Obj->ProcessEvent(Function, NULL);
#endif
	return 0;
}

int32 ResetToCurrentSettings(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"GameUserSettings",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"GameUserSettings must be non-null"); lua_error(InScriptContext);  return 0;}
#if UE_GAME
	UGameUserSettings * This = (UGameUserSettings *)Obj;
	This->ResetToCurrentSettings();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("ResetToCurrentSettings"));
	if(!Function) { check(false); return 0;}
	Obj->ProcessEvent(Function, NULL);
#endif
	return 0;
}

int32 LoadSettings(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"GameUserSettings",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"GameUserSettings must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool bForceReload;
	} Params;
	Params.bForceReload = lua_isnoneornil(InScriptContext,2) ? bool(false) : !!(lua_toboolean(InScriptContext, 2));
#if UE_GAME
	UGameUserSettings * This = (UGameUserSettings *)Obj;
	This->LoadSettings(Params.bForceReload);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("LoadSettings"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(bool*)(params.GetStructMemory() + 0) = Params.bForceReload;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.bForceReload = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 IsVSyncEnabled(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"GameUserSettings",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"GameUserSettings must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool ReturnValue;
	} Params;
#if UE_GAME
	UGameUserSettings * This = (UGameUserSettings *)Obj;
	Params.ReturnValue = This->IsVSyncEnabled();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("IsVSyncEnabled"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushboolean(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 IsVSyncDirty(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"GameUserSettings",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"GameUserSettings must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool ReturnValue;
	} Params;
#if UE_GAME
	UGameUserSettings * This = (UGameUserSettings *)Obj;
	Params.ReturnValue = This->IsVSyncDirty();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("IsVSyncDirty"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushboolean(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 IsScreenResolutionDirty(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"GameUserSettings",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"GameUserSettings must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool ReturnValue;
	} Params;
#if UE_GAME
	UGameUserSettings * This = (UGameUserSettings *)Obj;
	Params.ReturnValue = This->IsScreenResolutionDirty();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("IsScreenResolutionDirty"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushboolean(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 IsHDREnabled(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"GameUserSettings",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"GameUserSettings must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool ReturnValue;
	} Params;
#if UE_GAME
	UGameUserSettings * This = (UGameUserSettings *)Obj;
	Params.ReturnValue = This->IsHDREnabled();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("IsHDREnabled"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushboolean(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 IsFullscreenModeDirty(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"GameUserSettings",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"GameUserSettings must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool ReturnValue;
	} Params;
#if UE_GAME
	UGameUserSettings * This = (UGameUserSettings *)Obj;
	Params.ReturnValue = This->IsFullscreenModeDirty();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("IsFullscreenModeDirty"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushboolean(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 IsDynamicResolutionEnabled(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"GameUserSettings",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"GameUserSettings must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool ReturnValue;
	} Params;
#if UE_GAME
	UGameUserSettings * This = (UGameUserSettings *)Obj;
	Params.ReturnValue = This->IsDynamicResolutionEnabled();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("IsDynamicResolutionEnabled"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushboolean(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 IsDynamicResolutionDirty(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"GameUserSettings",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"GameUserSettings must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool ReturnValue;
	} Params;
#if UE_GAME
	UGameUserSettings * This = (UGameUserSettings *)Obj;
	Params.ReturnValue = This->IsDynamicResolutionDirty();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("IsDynamicResolutionDirty"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushboolean(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 IsDirty(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"GameUserSettings",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"GameUserSettings must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool ReturnValue;
	} Params;
#if UE_GAME
	UGameUserSettings * This = (UGameUserSettings *)Obj;
	Params.ReturnValue = This->IsDirty();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("IsDirty"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushboolean(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetVisualEffectQuality(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"GameUserSettings",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"GameUserSettings must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		int32 ReturnValue;
	} Params;
#if UE_GAME
	UGameUserSettings * This = (UGameUserSettings *)Obj;
	Params.ReturnValue = This->GetVisualEffectQuality();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetVisualEffectQuality"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(int32*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushinteger(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetViewDistanceQuality(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"GameUserSettings",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"GameUserSettings must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		int32 ReturnValue;
	} Params;
#if UE_GAME
	UGameUserSettings * This = (UGameUserSettings *)Obj;
	Params.ReturnValue = This->GetViewDistanceQuality();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetViewDistanceQuality"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(int32*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushinteger(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetTextureQuality(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"GameUserSettings",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"GameUserSettings must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		int32 ReturnValue;
	} Params;
#if UE_GAME
	UGameUserSettings * This = (UGameUserSettings *)Obj;
	Params.ReturnValue = This->GetTextureQuality();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetTextureQuality"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(int32*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushinteger(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetShadowQuality(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"GameUserSettings",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"GameUserSettings must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		int32 ReturnValue;
	} Params;
#if UE_GAME
	UGameUserSettings * This = (UGameUserSettings *)Obj;
	Params.ReturnValue = This->GetShadowQuality();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetShadowQuality"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(int32*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushinteger(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetResolutionScaleInformationEx(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"GameUserSettings",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"GameUserSettings must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float CurrentScaleNormalized;
		float CurrentScaleValue;
		float MinScaleValue;
		float MaxScaleValue;
	} Params;
#if UE_GAME
	UGameUserSettings * This = (UGameUserSettings *)Obj;
	This->GetResolutionScaleInformationEx(Params.CurrentScaleNormalized,Params.CurrentScaleValue,Params.MinScaleValue,Params.MaxScaleValue);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetResolutionScaleInformationEx"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.CurrentScaleNormalized = *(float*)(params.GetStructMemory() + 0);
		Params.CurrentScaleValue = *(float*)(params.GetStructMemory() + 4);
		Params.MinScaleValue = *(float*)(params.GetStructMemory() + 8);
		Params.MaxScaleValue = *(float*)(params.GetStructMemory() + 12);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushnumber(InScriptContext, Params.CurrentScaleNormalized);
	lua_pushnumber(InScriptContext, Params.CurrentScaleValue);
	lua_pushnumber(InScriptContext, Params.MinScaleValue);
	lua_pushnumber(InScriptContext, Params.MaxScaleValue);
	return 4;
}

int32 GetRecommendedResolutionScale(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"GameUserSettings",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"GameUserSettings must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float ReturnValue;
	} Params;
#if UE_GAME
	UGameUserSettings * This = (UGameUserSettings *)Obj;
	Params.ReturnValue = This->GetRecommendedResolutionScale();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetRecommendedResolutionScale"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(float*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushnumber(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetPreferredFullscreenMode(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"GameUserSettings",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"GameUserSettings must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		TEnumAsByte<EWindowMode::Type> ReturnValue;
	} Params;
#if UE_GAME
	UGameUserSettings * This = (UGameUserSettings *)Obj;
	Params.ReturnValue = This->GetPreferredFullscreenMode();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetPreferredFullscreenMode"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(TEnumAsByte<EWindowMode::Type>*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushinteger(InScriptContext, (int)Params.ReturnValue);
	return 1;
}

int32 GetPostProcessingQuality(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"GameUserSettings",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"GameUserSettings must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		int32 ReturnValue;
	} Params;
#if UE_GAME
	UGameUserSettings * This = (UGameUserSettings *)Obj;
	Params.ReturnValue = This->GetPostProcessingQuality();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetPostProcessingQuality"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(int32*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushinteger(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetOverallScalabilityLevel(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"GameUserSettings",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"GameUserSettings must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		int32 ReturnValue;
	} Params;
#if UE_GAME
	UGameUserSettings * This = (UGameUserSettings *)Obj;
	Params.ReturnValue = This->GetOverallScalabilityLevel();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetOverallScalabilityLevel"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(int32*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushinteger(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetLastConfirmedFullscreenMode(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"GameUserSettings",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"GameUserSettings must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		TEnumAsByte<EWindowMode::Type> ReturnValue;
	} Params;
#if UE_GAME
	UGameUserSettings * This = (UGameUserSettings *)Obj;
	Params.ReturnValue = This->GetLastConfirmedFullscreenMode();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetLastConfirmedFullscreenMode"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(TEnumAsByte<EWindowMode::Type>*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushinteger(InScriptContext, (int)Params.ReturnValue);
	return 1;
}

int32 GetGameUserSettings(lua_State* InScriptContext)
{
	UClass * Obj = UGameUserSettings::StaticClass(); 
	struct FDispatchParams
	{
		UGameUserSettings* ReturnValue = nullptr;
	} Params;
#if UE_GAME
	Params.ReturnValue = UGameUserSettings::GetGameUserSettings();
#else
	UFunction* Function = Obj->FindFunctionByName(TEXT("GetGameUserSettings"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(UGameUserSettings**)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetFullscreenMode(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"GameUserSettings",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"GameUserSettings must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		TEnumAsByte<EWindowMode::Type> ReturnValue;
	} Params;
#if UE_GAME
	UGameUserSettings * This = (UGameUserSettings *)Obj;
	Params.ReturnValue = This->GetFullscreenMode();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetFullscreenMode"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(TEnumAsByte<EWindowMode::Type>*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushinteger(InScriptContext, (int)Params.ReturnValue);
	return 1;
}

int32 GetFrameRateLimit(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"GameUserSettings",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"GameUserSettings must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float ReturnValue;
	} Params;
#if UE_GAME
	UGameUserSettings * This = (UGameUserSettings *)Obj;
	Params.ReturnValue = This->GetFrameRateLimit();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetFrameRateLimit"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(float*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushnumber(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetFoliageQuality(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"GameUserSettings",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"GameUserSettings must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		int32 ReturnValue;
	} Params;
#if UE_GAME
	UGameUserSettings * This = (UGameUserSettings *)Obj;
	Params.ReturnValue = This->GetFoliageQuality();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetFoliageQuality"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(int32*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushinteger(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetDefaultWindowMode(lua_State* InScriptContext)
{
	UClass * Obj = UGameUserSettings::StaticClass(); 
	struct FDispatchParams
	{
		TEnumAsByte<EWindowMode::Type> ReturnValue;
	} Params;
#if UE_GAME
	Params.ReturnValue = UGameUserSettings::GetDefaultWindowMode();
#else
	UFunction* Function = Obj->FindFunctionByName(TEXT("GetDefaultWindowMode"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(TEnumAsByte<EWindowMode::Type>*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushinteger(InScriptContext, (int)Params.ReturnValue);
	return 1;
}

int32 GetDefaultResolutionScale(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"GameUserSettings",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"GameUserSettings must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float ReturnValue;
	} Params;
#if UE_GAME
	UGameUserSettings * This = (UGameUserSettings *)Obj;
	Params.ReturnValue = This->GetDefaultResolutionScale();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetDefaultResolutionScale"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(float*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushnumber(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetCurrentHDRDisplayNits(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"GameUserSettings",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"GameUserSettings must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		int32 ReturnValue;
	} Params;
#if UE_GAME
	UGameUserSettings * This = (UGameUserSettings *)Obj;
	Params.ReturnValue = This->GetCurrentHDRDisplayNits();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetCurrentHDRDisplayNits"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(int32*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushinteger(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetAudioQualityLevel(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"GameUserSettings",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"GameUserSettings must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		int32 ReturnValue;
	} Params;
#if UE_GAME
	UGameUserSettings * This = (UGameUserSettings *)Obj;
	Params.ReturnValue = This->GetAudioQualityLevel();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetAudioQualityLevel"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(int32*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushinteger(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetAntiAliasingQuality(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"GameUserSettings",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"GameUserSettings must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		int32 ReturnValue;
	} Params;
#if UE_GAME
	UGameUserSettings * This = (UGameUserSettings *)Obj;
	Params.ReturnValue = This->GetAntiAliasingQuality();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetAntiAliasingQuality"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(int32*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushinteger(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 EnableHDRDisplayOutput(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"GameUserSettings",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"GameUserSettings must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool bEnable;
		int32 DisplayNits;
	} Params;
	Params.bEnable = !!(lua_toboolean(InScriptContext, 2));
	Params.DisplayNits = lua_isnoneornil(InScriptContext,3) ? int32(1000) : (luaL_checkint(InScriptContext, 3));
#if UE_GAME
	UGameUserSettings * This = (UGameUserSettings *)Obj;
	This->EnableHDRDisplayOutput(Params.bEnable,Params.DisplayNits);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("EnableHDRDisplayOutput"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(bool*)(params.GetStructMemory() + 0) = Params.bEnable;
		*(int32*)(params.GetStructMemory() + 4) = Params.DisplayNits;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.bEnable = *(bool*)(params.GetStructMemory() + 0);
		Params.DisplayNits = *(int32*)(params.GetStructMemory() + 4);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 ConfirmVideoMode(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"GameUserSettings",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"GameUserSettings must be non-null"); lua_error(InScriptContext);  return 0;}
#if UE_GAME
	UGameUserSettings * This = (UGameUserSettings *)Obj;
	This->ConfirmVideoMode();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("ConfirmVideoMode"));
	if(!Function) { check(false); return 0;}
	Obj->ProcessEvent(Function, NULL);
#endif
	return 0;
}

int32 ApplySettings(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"GameUserSettings",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"GameUserSettings must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool bCheckForCommandLineOverrides;
	} Params;
	Params.bCheckForCommandLineOverrides = !!(lua_toboolean(InScriptContext, 2));
#if UE_GAME
	UGameUserSettings * This = (UGameUserSettings *)Obj;
	This->ApplySettings(Params.bCheckForCommandLineOverrides);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("ApplySettings"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(bool*)(params.GetStructMemory() + 0) = Params.bCheckForCommandLineOverrides;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.bCheckForCommandLineOverrides = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 ApplyResolutionSettings(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"GameUserSettings",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"GameUserSettings must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool bCheckForCommandLineOverrides;
	} Params;
	Params.bCheckForCommandLineOverrides = !!(lua_toboolean(InScriptContext, 2));
#if UE_GAME
	UGameUserSettings * This = (UGameUserSettings *)Obj;
	This->ApplyResolutionSettings(Params.bCheckForCommandLineOverrides);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("ApplyResolutionSettings"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(bool*)(params.GetStructMemory() + 0) = Params.bCheckForCommandLineOverrides;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.bCheckForCommandLineOverrides = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 ApplyNonResolutionSettings(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"GameUserSettings",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"GameUserSettings must be non-null"); lua_error(InScriptContext);  return 0;}
#if UE_GAME
	UGameUserSettings * This = (UGameUserSettings *)Obj;
	This->ApplyNonResolutionSettings();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("ApplyNonResolutionSettings"));
	if(!Function) { check(false); return 0;}
	Obj->ProcessEvent(Function, NULL);
#endif
	return 0;
}

int32 ApplyHardwareBenchmarkResults(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"GameUserSettings",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"GameUserSettings must be non-null"); lua_error(InScriptContext);  return 0;}
#if UE_GAME
	UGameUserSettings * This = (UGameUserSettings *)Obj;
	This->ApplyHardwareBenchmarkResults();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("ApplyHardwareBenchmarkResults"));
	if(!Function) { check(false); return 0;}
	Obj->ProcessEvent(Function, NULL);
#endif
	return 0;
}

int32 New(lua_State* InScriptContext)
{
	UObject* Outer = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Object");
	FName Name = FName(luaL_checkstring(InScriptContext, 2));
	UObject* Obj = NewObject<UGameUserSettings>(Outer, Name);
	wLua::FLuaUtils::ReturnUObject(InScriptContext,Obj);
	return 1;
}

int32 Destroy(lua_State* InScriptContext)
{
	return 0;
}

int32 Class(lua_State* InScriptContext)
{
	UClass* Class = UGameUserSettings::StaticClass();
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Class);
	return 1;
}

const luaL_Reg Lib_Funcs[] =
{
	{ "New", New },
	{ "Destroy", Destroy },
	{ "Class", Class },
	{ "ValidateSettings", ValidateSettings },
	{ "SupportsHDRDisplayOutput", SupportsHDRDisplayOutput },
	{ "SetVSyncEnabled", SetVSyncEnabled },
	{ "SetVisualEffectQuality", SetVisualEffectQuality },
	{ "SetViewDistanceQuality", SetViewDistanceQuality },
	{ "SetToDefaults", SetToDefaults },
	{ "SetTextureQuality", SetTextureQuality },
	{ "SetShadowQuality", SetShadowQuality },
	{ "SetResolutionScaleValueEx", SetResolutionScaleValueEx },
	{ "SetResolutionScaleNormalized", SetResolutionScaleNormalized },
	{ "SetPostProcessingQuality", SetPostProcessingQuality },
	{ "SetOverallScalabilityLevel", SetOverallScalabilityLevel },
	{ "SetFullscreenMode", SetFullscreenMode },
	{ "SetFrameRateLimit", SetFrameRateLimit },
	{ "SetFoliageQuality", SetFoliageQuality },
	{ "SetDynamicResolutionEnabled", SetDynamicResolutionEnabled },
	{ "SetBenchmarkFallbackValues", SetBenchmarkFallbackValues },
	{ "SetAudioQualityLevel", SetAudioQualityLevel },
	{ "SetAntiAliasingQuality", SetAntiAliasingQuality },
	{ "SaveSettings", SaveSettings },
	{ "RunHardwareBenchmark", RunHardwareBenchmark },
	{ "RevertVideoMode", RevertVideoMode },
	{ "ResetToCurrentSettings", ResetToCurrentSettings },
	{ "LoadSettings", LoadSettings },
	{ "IsVSyncEnabled", IsVSyncEnabled },
	{ "IsVSyncDirty", IsVSyncDirty },
	{ "IsScreenResolutionDirty", IsScreenResolutionDirty },
	{ "IsHDREnabled", IsHDREnabled },
	{ "IsFullscreenModeDirty", IsFullscreenModeDirty },
	{ "IsDynamicResolutionEnabled", IsDynamicResolutionEnabled },
	{ "IsDynamicResolutionDirty", IsDynamicResolutionDirty },
	{ "IsDirty", IsDirty },
	{ "GetVisualEffectQuality", GetVisualEffectQuality },
	{ "GetViewDistanceQuality", GetViewDistanceQuality },
	{ "GetTextureQuality", GetTextureQuality },
	{ "GetShadowQuality", GetShadowQuality },
	{ "GetResolutionScaleInformationEx", GetResolutionScaleInformationEx },
	{ "GetRecommendedResolutionScale", GetRecommendedResolutionScale },
	{ "GetPreferredFullscreenMode", GetPreferredFullscreenMode },
	{ "GetPostProcessingQuality", GetPostProcessingQuality },
	{ "GetOverallScalabilityLevel", GetOverallScalabilityLevel },
	{ "GetLastConfirmedFullscreenMode", GetLastConfirmedFullscreenMode },
	{ "GetGameUserSettings", GetGameUserSettings },
	{ "GetFullscreenMode", GetFullscreenMode },
	{ "GetFrameRateLimit", GetFrameRateLimit },
	{ "GetFoliageQuality", GetFoliageQuality },
	{ "GetDefaultWindowMode", GetDefaultWindowMode },
	{ "GetDefaultResolutionScale", GetDefaultResolutionScale },
	{ "GetCurrentHDRDisplayNits", GetCurrentHDRDisplayNits },
	{ "GetAudioQualityLevel", GetAudioQualityLevel },
	{ "GetAntiAliasingQuality", GetAntiAliasingQuality },
	{ "EnableHDRDisplayOutput", EnableHDRDisplayOutput },
	{ "ConfirmVideoMode", ConfirmVideoMode },
	{ "ApplySettings", ApplySettings },
	{ "ApplyResolutionSettings", ApplyResolutionSettings },
	{ "ApplyNonResolutionSettings", ApplyNonResolutionSettings },
	{ "ApplyHardwareBenchmarkResults", ApplyHardwareBenchmarkResults },
	{ "is_nil", wLua::LuaStatic::isnil },
	{ "__gc", wLua::LuaStatic::removeUClassFrameCache },
	{ NULL, NULL }
};

void Register(lua_State *InScriptContext)
{
	lua_newtable(InScriptContext);
	luaL_register(InScriptContext, NULL, Lib_Funcs);
	AzureHelpFuncs::AuxRegister(InScriptContext, "GameUserSettings");
}
void SetMtLink(lua_State *InScriptContext)
{
	AzureHelpFuncs::AuxSetMtLink(InScriptContext, "GameUserSettings", "Object",USERDATATYPE_UOBJECT);
}

}