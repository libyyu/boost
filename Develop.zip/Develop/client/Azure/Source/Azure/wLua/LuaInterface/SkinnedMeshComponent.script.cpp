#include "Azure.h"
#include "Utility/help_funcs.h"
#include "wLua/UObjectHeaders.h"
#include "Components/SkinnedMeshComponent.h"
#include "AzureLuaIntegration.h"

namespace LuaSkinnedMeshComponent
{
int32 GetBoneLocationByName(lua_State*);
int32 GetSkeletalMesh(lua_State*);
int32 SetReceivesDecals(lua_State*);
int32 GetPredictedLODLevel(lua_State*);
int32 GetNearestBone(lua_State*);
int32 GetNearestBoneInCollider(lua_State*);
int32 SetOverrideMinLod(lua_State*);
int32 GetMaxDistanceFactor(lua_State*);
int32 SetAnimUpdateRateParams(lua_State*);
int32 Get_bRecentlyRendered(lua_State*);

int32 UnHideBoneByName(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SkinnedMeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SkinnedMeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FName BoneName;
	} Params;
	Params.BoneName = FName(UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 2)));
#if UE_GAME
	USkinnedMeshComponent * This = (USkinnedMeshComponent *)Obj;
	This->UnHideBoneByName(Params.BoneName);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("UnHideBoneByName"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FName*)(params.GetStructMemory() + 0) = Params.BoneName;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.BoneName = *(FName*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 TransformToBoneSpace(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SkinnedMeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SkinnedMeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FName BoneName;
		FVector InPosition;
		FRotator InRotation;
		FVector OutPosition;
		FRotator OutRotation;
	} Params;
	Params.BoneName = FName(UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 2)));
	Params.InPosition = (wLua::FLuaVector::Get(InScriptContext, 3));
	Params.InRotation = (wLua::FLuaRotator::Get(InScriptContext, 4));
#if UE_GAME
	USkinnedMeshComponent * This = (USkinnedMeshComponent *)Obj;
	This->TransformToBoneSpace(Params.BoneName,Params.InPosition,Params.InRotation,Params.OutPosition,Params.OutRotation);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("TransformToBoneSpace"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FName*)(params.GetStructMemory() + 0) = Params.BoneName;
		*(FVector*)(params.GetStructMemory() + 12) = Params.InPosition;
		*(FRotator*)(params.GetStructMemory() + 24) = Params.InRotation;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.BoneName = *(FName*)(params.GetStructMemory() + 0);
		Params.InPosition = *(FVector*)(params.GetStructMemory() + 12);
		Params.InRotation = *(FRotator*)(params.GetStructMemory() + 24);
		Params.OutPosition = *(FVector*)(params.GetStructMemory() + 36);
		Params.OutRotation = *(FRotator*)(params.GetStructMemory() + 48);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaVector::Return(InScriptContext, Params.OutPosition);
	wLua::FLuaRotator::Return(InScriptContext, Params.OutRotation);
	return 2;
}

int32 TransformFromBoneSpace(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SkinnedMeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SkinnedMeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FName BoneName;
		FVector InPosition;
		FRotator InRotation;
		FVector OutPosition;
		FRotator OutRotation;
	} Params;
	Params.BoneName = FName(UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 2)));
	Params.InPosition = (wLua::FLuaVector::Get(InScriptContext, 3));
	Params.InRotation = (wLua::FLuaRotator::Get(InScriptContext, 4));
#if UE_GAME
	USkinnedMeshComponent * This = (USkinnedMeshComponent *)Obj;
	This->TransformFromBoneSpace(Params.BoneName,Params.InPosition,Params.InRotation,Params.OutPosition,Params.OutRotation);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("TransformFromBoneSpace"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FName*)(params.GetStructMemory() + 0) = Params.BoneName;
		*(FVector*)(params.GetStructMemory() + 12) = Params.InPosition;
		*(FRotator*)(params.GetStructMemory() + 24) = Params.InRotation;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.BoneName = *(FName*)(params.GetStructMemory() + 0);
		Params.InPosition = *(FVector*)(params.GetStructMemory() + 12);
		Params.InRotation = *(FRotator*)(params.GetStructMemory() + 24);
		Params.OutPosition = *(FVector*)(params.GetStructMemory() + 36);
		Params.OutRotation = *(FRotator*)(params.GetStructMemory() + 48);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaVector::Return(InScriptContext, Params.OutPosition);
	wLua::FLuaRotator::Return(InScriptContext, Params.OutRotation);
	return 2;
}

int32 ShowMaterialSection(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SkinnedMeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SkinnedMeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		int32 MaterialID;
		bool bShow;
		int32 LODIndex;
	} Params;
	Params.MaterialID = (luaL_checkint(InScriptContext, 2));
	Params.bShow = !!(lua_toboolean(InScriptContext, 3));
	Params.LODIndex = (luaL_checkint(InScriptContext, 4));
#if UE_GAME
	USkinnedMeshComponent * This = (USkinnedMeshComponent *)Obj;
	This->ShowMaterialSection(Params.MaterialID,Params.bShow,Params.LODIndex);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("ShowMaterialSection"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(int32*)(params.GetStructMemory() + 0) = Params.MaterialID;
		*(bool*)(params.GetStructMemory() + 4) = Params.bShow;
		*(int32*)(params.GetStructMemory() + 8) = Params.LODIndex;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.MaterialID = *(int32*)(params.GetStructMemory() + 0);
		Params.bShow = *(bool*)(params.GetStructMemory() + 4);
		Params.LODIndex = *(int32*)(params.GetStructMemory() + 8);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 ShowAllMaterialSections(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SkinnedMeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SkinnedMeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		int32 LODIndex;
	} Params;
	Params.LODIndex = (luaL_checkint(InScriptContext, 2));
#if UE_GAME
	USkinnedMeshComponent * This = (USkinnedMeshComponent *)Obj;
	This->ShowAllMaterialSections(Params.LODIndex);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("ShowAllMaterialSections"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(int32*)(params.GetStructMemory() + 0) = Params.LODIndex;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.LODIndex = *(int32*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetVertexColorOverride_LinearColor(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SkinnedMeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SkinnedMeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		int32 LODIndex;
		TArray<FLinearColor> VertexColors;
	} Params;
	Params.LODIndex = (luaL_checkint(InScriptContext, 2));
	Params.VertexColors = [](lua_State * _InScriptContext){ TArray<FLinearColor> ret; lua_pushnil(_InScriptContext); while(lua_next(_InScriptContext,3)!=0){ FLinearColor item = (wLua::FLuaLinearColor::Get(_InScriptContext, -1)); ret.Add(item); lua_pop(_InScriptContext,1);  } return ret; }(InScriptContext);;
#if UE_GAME
	USkinnedMeshComponent * This = (USkinnedMeshComponent *)Obj;
	This->SetVertexColorOverride_LinearColor(Params.LODIndex,Params.VertexColors);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetVertexColorOverride_LinearColor"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(int32*)(params.GetStructMemory() + 0) = Params.LODIndex;
		*(TArray<FLinearColor>*)(params.GetStructMemory() + 8) = Params.VertexColors;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.LODIndex = *(int32*)(params.GetStructMemory() + 0);
		Params.VertexColors = *(TArray<FLinearColor>*)(params.GetStructMemory() + 8);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetSkeletalMesh(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SkinnedMeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SkinnedMeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		USkeletalMesh* NewMesh = nullptr;
		bool bReinitPose;
	} Params;
	Params.NewMesh = (USkeletalMesh*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"SkeletalMesh");;
	Params.bReinitPose = lua_isnoneornil(InScriptContext,3) ? bool(true) : !!(lua_toboolean(InScriptContext, 3));
#if UE_GAME
	USkinnedMeshComponent * This = (USkinnedMeshComponent *)Obj;
	This->SetSkeletalMesh(Params.NewMesh,Params.bReinitPose);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetSkeletalMesh"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(USkeletalMesh**)(params.GetStructMemory() + 0) = Params.NewMesh;
		*(bool*)(params.GetStructMemory() + 8) = Params.bReinitPose;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.NewMesh = *(USkeletalMesh**)(params.GetStructMemory() + 0);
		Params.bReinitPose = *(bool*)(params.GetStructMemory() + 8);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetRenderStatic(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SkinnedMeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SkinnedMeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool bNewValue;
	} Params;
	Params.bNewValue = !!(lua_toboolean(InScriptContext, 2));
#if UE_GAME
	USkinnedMeshComponent * This = (USkinnedMeshComponent *)Obj;
	This->SetRenderStatic(Params.bNewValue);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetRenderStatic"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(bool*)(params.GetStructMemory() + 0) = Params.bNewValue;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.bNewValue = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetPhysicsAsset(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SkinnedMeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SkinnedMeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		UPhysicsAsset* NewPhysicsAsset = nullptr;
		bool bForceReInit;
	} Params;
	Params.NewPhysicsAsset = (UPhysicsAsset*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"PhysicsAsset");;
	Params.bForceReInit = lua_isnoneornil(InScriptContext,3) ? bool(false) : !!(lua_toboolean(InScriptContext, 3));
#if UE_GAME
	USkinnedMeshComponent * This = (USkinnedMeshComponent *)Obj;
	This->SetPhysicsAsset(Params.NewPhysicsAsset,Params.bForceReInit);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetPhysicsAsset"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(UPhysicsAsset**)(params.GetStructMemory() + 0) = Params.NewPhysicsAsset;
		*(bool*)(params.GetStructMemory() + 8) = Params.bForceReInit;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.NewPhysicsAsset = *(UPhysicsAsset**)(params.GetStructMemory() + 0);
		Params.bForceReInit = *(bool*)(params.GetStructMemory() + 8);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetMinLOD(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SkinnedMeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SkinnedMeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		int32 InNewMinLOD;
	} Params;
	Params.InNewMinLOD = (luaL_checkint(InScriptContext, 2));
#if UE_GAME
	USkinnedMeshComponent * This = (USkinnedMeshComponent *)Obj;
	This->SetMinLOD(Params.InNewMinLOD);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetMinLOD"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(int32*)(params.GetStructMemory() + 0) = Params.InNewMinLOD;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.InNewMinLOD = *(int32*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetMasterPoseComponent(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SkinnedMeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SkinnedMeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		USkinnedMeshComponent* NewMasterBoneComponent = nullptr;
		bool bForceUpdate;
	} Params;
	Params.NewMasterBoneComponent = (USkinnedMeshComponent*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"SkinnedMeshComponent");;
	Params.bForceUpdate = lua_isnoneornil(InScriptContext,3) ? bool(false) : !!(lua_toboolean(InScriptContext, 3));
#if UE_GAME
	USkinnedMeshComponent * This = (USkinnedMeshComponent *)Obj;
	This->SetMasterPoseComponent(Params.NewMasterBoneComponent,Params.bForceUpdate);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetMasterPoseComponent"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(USkinnedMeshComponent**)(params.GetStructMemory() + 0) = Params.NewMasterBoneComponent;
		*(bool*)(params.GetStructMemory() + 8) = Params.bForceUpdate;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.NewMasterBoneComponent = *(USkinnedMeshComponent**)(params.GetStructMemory() + 0);
		Params.bForceUpdate = *(bool*)(params.GetStructMemory() + 8);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetForcedLOD(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SkinnedMeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SkinnedMeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		int32 InNewForcedLOD;
	} Params;
	Params.InNewForcedLOD = (luaL_checkint(InScriptContext, 2));
#if UE_GAME
	USkinnedMeshComponent * This = (USkinnedMeshComponent *)Obj;
	This->SetForcedLOD(Params.InNewForcedLOD);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetForcedLOD"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(int32*)(params.GetStructMemory() + 0) = Params.InNewForcedLOD;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.InNewForcedLOD = *(int32*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetCastCapsuleIndirectShadow(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SkinnedMeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SkinnedMeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool bNewValue;
	} Params;
	Params.bNewValue = !!(lua_toboolean(InScriptContext, 2));
#if UE_GAME
	USkinnedMeshComponent * This = (USkinnedMeshComponent *)Obj;
	This->SetCastCapsuleIndirectShadow(Params.bNewValue);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetCastCapsuleIndirectShadow"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(bool*)(params.GetStructMemory() + 0) = Params.bNewValue;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.bNewValue = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetCastCapsuleDirectShadow(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SkinnedMeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SkinnedMeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool bNewValue;
	} Params;
	Params.bNewValue = !!(lua_toboolean(InScriptContext, 2));
#if UE_GAME
	USkinnedMeshComponent * This = (USkinnedMeshComponent *)Obj;
	This->SetCastCapsuleDirectShadow(Params.bNewValue);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetCastCapsuleDirectShadow"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(bool*)(params.GetStructMemory() + 0) = Params.bNewValue;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.bNewValue = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetCapsuleIndirectShadowMinVisibility(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SkinnedMeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SkinnedMeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float NewValue;
	} Params;
	Params.NewValue = (float)(luaL_checknumber(InScriptContext, 2));
#if UE_GAME
	USkinnedMeshComponent * This = (USkinnedMeshComponent *)Obj;
	This->SetCapsuleIndirectShadowMinVisibility(Params.NewValue);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetCapsuleIndirectShadowMinVisibility"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(float*)(params.GetStructMemory() + 0) = Params.NewValue;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.NewValue = *(float*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 IsMaterialSectionShown(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SkinnedMeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SkinnedMeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		int32 MaterialID;
		int32 LODIndex;
		bool ReturnValue;
	} Params;
	Params.MaterialID = (luaL_checkint(InScriptContext, 2));
	Params.LODIndex = (luaL_checkint(InScriptContext, 3));
#if UE_GAME
	USkinnedMeshComponent * This = (USkinnedMeshComponent *)Obj;
	Params.ReturnValue = This->IsMaterialSectionShown(Params.MaterialID,Params.LODIndex);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("IsMaterialSectionShown"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(int32*)(params.GetStructMemory() + 0) = Params.MaterialID;
		*(int32*)(params.GetStructMemory() + 4) = Params.LODIndex;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.MaterialID = *(int32*)(params.GetStructMemory() + 0);
		Params.LODIndex = *(int32*)(params.GetStructMemory() + 4);
		Params.ReturnValue = *(bool*)(params.GetStructMemory() + 8);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushboolean(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 IsBoneHiddenByName(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SkinnedMeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SkinnedMeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FName BoneName;
		bool ReturnValue;
	} Params;
	Params.BoneName = FName(UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 2)));
#if UE_GAME
	USkinnedMeshComponent * This = (USkinnedMeshComponent *)Obj;
	Params.ReturnValue = This->IsBoneHiddenByName(Params.BoneName);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("IsBoneHiddenByName"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FName*)(params.GetStructMemory() + 0) = Params.BoneName;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.BoneName = *(FName*)(params.GetStructMemory() + 0);
		Params.ReturnValue = *(bool*)(params.GetStructMemory() + 12);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushboolean(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 HideBoneByName(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SkinnedMeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SkinnedMeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FName BoneName;
		TEnumAsByte<EPhysBodyOp> PhysBodyOption;
	} Params;
	Params.BoneName = FName(UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 2)));
	Params.PhysBodyOption = (TEnumAsByte<EPhysBodyOp>)(luaL_checkint(InScriptContext, 3));
#if UE_GAME
	USkinnedMeshComponent * This = (USkinnedMeshComponent *)Obj;
	This->HideBoneByName(Params.BoneName,Params.PhysBodyOption);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("HideBoneByName"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FName*)(params.GetStructMemory() + 0) = Params.BoneName;
		*(TEnumAsByte<EPhysBodyOp>*)(params.GetStructMemory() + 12) = Params.PhysBodyOption;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.BoneName = *(FName*)(params.GetStructMemory() + 0);
		Params.PhysBodyOption = *(TEnumAsByte<EPhysBodyOp>*)(params.GetStructMemory() + 12);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 GetSocketBoneName(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SkinnedMeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SkinnedMeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FName InSocketName;
		FName ReturnValue;
	} Params;
	Params.InSocketName = FName(UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 2)));
#if UE_GAME
	USkinnedMeshComponent * This = (USkinnedMeshComponent *)Obj;
	Params.ReturnValue = This->GetSocketBoneName(Params.InSocketName);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetSocketBoneName"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FName*)(params.GetStructMemory() + 0) = Params.InSocketName;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.InSocketName = *(FName*)(params.GetStructMemory() + 0);
		Params.ReturnValue = *(FName*)(params.GetStructMemory() + 12);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushstring(InScriptContext, TCHAR_TO_UTF8(*Params.ReturnValue.ToString()));
	return 1;
}

int32 GetRefPosePosition(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SkinnedMeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SkinnedMeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		int32 BoneIndex;
		FVector ReturnValue;
	} Params;
	Params.BoneIndex = (luaL_checkint(InScriptContext, 2));
#if UE_GAME
	USkinnedMeshComponent * This = (USkinnedMeshComponent *)Obj;
	Params.ReturnValue = This->GetRefPosePosition(Params.BoneIndex);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetRefPosePosition"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(int32*)(params.GetStructMemory() + 0) = Params.BoneIndex;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.BoneIndex = *(int32*)(params.GetStructMemory() + 0);
		Params.ReturnValue = *(FVector*)(params.GetStructMemory() + 4);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaVector::Return(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetParentBone(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SkinnedMeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SkinnedMeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FName BoneName;
		FName ReturnValue;
	} Params;
	Params.BoneName = FName(UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 2)));
#if UE_GAME
	USkinnedMeshComponent * This = (USkinnedMeshComponent *)Obj;
	Params.ReturnValue = This->GetParentBone(Params.BoneName);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetParentBone"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FName*)(params.GetStructMemory() + 0) = Params.BoneName;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.BoneName = *(FName*)(params.GetStructMemory() + 0);
		Params.ReturnValue = *(FName*)(params.GetStructMemory() + 12);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushstring(InScriptContext, TCHAR_TO_UTF8(*Params.ReturnValue.ToString()));
	return 1;
}

int32 GetNumLODs(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SkinnedMeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SkinnedMeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		int32 ReturnValue;
	} Params;
#if UE_GAME
	USkinnedMeshComponent * This = (USkinnedMeshComponent *)Obj;
	Params.ReturnValue = This->GetNumLODs();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetNumLODs"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(int32*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushinteger(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetNumBones(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SkinnedMeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SkinnedMeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		int32 ReturnValue;
	} Params;
#if UE_GAME
	USkinnedMeshComponent * This = (USkinnedMeshComponent *)Obj;
	Params.ReturnValue = This->GetNumBones();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetNumBones"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(int32*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushinteger(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetDeltaTransformFromRefPose(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SkinnedMeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SkinnedMeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FName BoneName;
		FName BaseName;
		FTransform ReturnValue;
	} Params;
	Params.BoneName = FName(UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 2)));
	Params.BaseName = lua_isnoneornil(InScriptContext,3) ? FName(TEXT("")) : FName(UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 3)));
#if UE_GAME
	USkinnedMeshComponent * This = (USkinnedMeshComponent *)Obj;
	Params.ReturnValue = This->GetDeltaTransformFromRefPose(Params.BoneName,Params.BaseName);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetDeltaTransformFromRefPose"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FName*)(params.GetStructMemory() + 0) = Params.BoneName;
		*(FName*)(params.GetStructMemory() + 12) = Params.BaseName;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.BoneName = *(FName*)(params.GetStructMemory() + 0);
		Params.BaseName = *(FName*)(params.GetStructMemory() + 12);
		Params.ReturnValue = *(FTransform*)(params.GetStructMemory() + 32);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaTransform::Return(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetBoneName(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SkinnedMeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SkinnedMeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		int32 BoneIndex;
		FName ReturnValue;
	} Params;
	Params.BoneIndex = (luaL_checkint(InScriptContext, 2));
#if UE_GAME
	USkinnedMeshComponent * This = (USkinnedMeshComponent *)Obj;
	Params.ReturnValue = This->GetBoneName(Params.BoneIndex);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetBoneName"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(int32*)(params.GetStructMemory() + 0) = Params.BoneIndex;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.BoneIndex = *(int32*)(params.GetStructMemory() + 0);
		Params.ReturnValue = *(FName*)(params.GetStructMemory() + 4);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushstring(InScriptContext, TCHAR_TO_UTF8(*Params.ReturnValue.ToString()));
	return 1;
}

int32 GetBoneIndex(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SkinnedMeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SkinnedMeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FName BoneName;
		int32 ReturnValue;
	} Params;
	Params.BoneName = FName(UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 2)));
#if UE_GAME
	USkinnedMeshComponent * This = (USkinnedMeshComponent *)Obj;
	Params.ReturnValue = This->GetBoneIndex(Params.BoneName);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetBoneIndex"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FName*)(params.GetStructMemory() + 0) = Params.BoneName;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.BoneName = *(FName*)(params.GetStructMemory() + 0);
		Params.ReturnValue = *(int32*)(params.GetStructMemory() + 12);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushinteger(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 FindClosestBone_K2(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SkinnedMeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SkinnedMeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FVector TestLocation;
		FVector BoneLocation;
		float IgnoreScale;
		bool bRequirePhysicsAsset;
		FName ReturnValue;
	} Params;
	Params.TestLocation = (wLua::FLuaVector::Get(InScriptContext, 2));
	Params.IgnoreScale = lua_isnoneornil(InScriptContext,4) ? float(0.000000) : (float)(luaL_checknumber(InScriptContext, 4));
	Params.bRequirePhysicsAsset = lua_isnoneornil(InScriptContext,5) ? bool(false) : !!(lua_toboolean(InScriptContext, 5));
#if UE_GAME
	USkinnedMeshComponent * This = (USkinnedMeshComponent *)Obj;
	Params.ReturnValue = This->FindClosestBone_K2(Params.TestLocation,Params.BoneLocation,Params.IgnoreScale,Params.bRequirePhysicsAsset);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("FindClosestBone_K2"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FVector*)(params.GetStructMemory() + 0) = Params.TestLocation;
		*(float*)(params.GetStructMemory() + 24) = Params.IgnoreScale;
		*(bool*)(params.GetStructMemory() + 28) = Params.bRequirePhysicsAsset;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.TestLocation = *(FVector*)(params.GetStructMemory() + 0);
		Params.BoneLocation = *(FVector*)(params.GetStructMemory() + 12);
		Params.IgnoreScale = *(float*)(params.GetStructMemory() + 24);
		Params.bRequirePhysicsAsset = *(bool*)(params.GetStructMemory() + 28);
		Params.ReturnValue = *(FName*)(params.GetStructMemory() + 32);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushstring(InScriptContext, TCHAR_TO_UTF8(*Params.ReturnValue.ToString()));
	wLua::FLuaVector::Return(InScriptContext, Params.BoneLocation);
	return 2;
}

int32 ClearVertexColorOverride(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SkinnedMeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SkinnedMeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		int32 LODIndex;
	} Params;
	Params.LODIndex = (luaL_checkint(InScriptContext, 2));
#if UE_GAME
	USkinnedMeshComponent * This = (USkinnedMeshComponent *)Obj;
	This->ClearVertexColorOverride(Params.LODIndex);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("ClearVertexColorOverride"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(int32*)(params.GetStructMemory() + 0) = Params.LODIndex;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.LODIndex = *(int32*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 ClearSkinWeightOverride(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SkinnedMeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SkinnedMeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		int32 LODIndex;
	} Params;
	Params.LODIndex = (luaL_checkint(InScriptContext, 2));
#if UE_GAME
	USkinnedMeshComponent * This = (USkinnedMeshComponent *)Obj;
	This->ClearSkinWeightOverride(Params.LODIndex);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("ClearSkinWeightOverride"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(int32*)(params.GetStructMemory() + 0) = Params.LODIndex;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.LODIndex = *(int32*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 BoneIsChildOf(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SkinnedMeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SkinnedMeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FName BoneName;
		FName ParentBoneName;
		bool ReturnValue;
	} Params;
	Params.BoneName = FName(UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 2)));
	Params.ParentBoneName = FName(UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 3)));
#if UE_GAME
	USkinnedMeshComponent * This = (USkinnedMeshComponent *)Obj;
	Params.ReturnValue = This->BoneIsChildOf(Params.BoneName,Params.ParentBoneName);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("BoneIsChildOf"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FName*)(params.GetStructMemory() + 0) = Params.BoneName;
		*(FName*)(params.GetStructMemory() + 12) = Params.ParentBoneName;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.BoneName = *(FName*)(params.GetStructMemory() + 0);
		Params.ParentBoneName = *(FName*)(params.GetStructMemory() + 12);
		Params.ReturnValue = *(bool*)(params.GetStructMemory() + 24);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushboolean(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 Get_SkeletalMesh(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SkinnedMeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SkinnedMeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USkinnedMeshComponent::StaticClass(), TEXT("SkeletalMesh"));
	if(!Property) { check(false); return 0;}
	USkeletalMesh* PropertyValue;
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaUtils::ReturnUObject(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_significanceManagerLevel(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SkinnedMeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SkinnedMeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USkinnedMeshComponent::StaticClass(), TEXT("significanceManagerLevel"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_significanceManagerLevel(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SkinnedMeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SkinnedMeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USkinnedMeshComponent::StaticClass(), TEXT("significanceManagerLevel"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_PhysicsAssetOverride(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SkinnedMeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SkinnedMeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USkinnedMeshComponent::StaticClass(), TEXT("PhysicsAssetOverride"));
	if(!Property) { check(false); return 0;}
	UPhysicsAsset* PropertyValue;
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaUtils::ReturnUObject(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_ForcedLodModel(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SkinnedMeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SkinnedMeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USkinnedMeshComponent::StaticClass(), TEXT("ForcedLodModel"));
	if(!Property) { check(false); return 0;}
	int32 PropertyValue = int32();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushinteger(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_MinLodModel(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SkinnedMeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SkinnedMeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USkinnedMeshComponent::StaticClass(), TEXT("MinLodModel"));
	if(!Property) { check(false); return 0;}
	int32 PropertyValue = int32();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushinteger(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_ForcedShadowLod(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SkinnedMeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SkinnedMeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USkinnedMeshComponent::StaticClass(), TEXT("ForcedShadowLod"));
	if(!Property) { check(false); return 0;}
	int32 PropertyValue = int32();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushinteger(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_ShadowLODBias(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SkinnedMeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SkinnedMeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USkinnedMeshComponent::StaticClass(), TEXT("ShadowLODBias"));
	if(!Property) { check(false); return 0;}
	int32 PropertyValue = int32();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushinteger(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_StreamingDistanceMultiplier(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SkinnedMeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SkinnedMeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USkinnedMeshComponent::StaticClass(), TEXT("StreamingDistanceMultiplier"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_StreamingDistanceMultiplier(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SkinnedMeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SkinnedMeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USkinnedMeshComponent::StaticClass(), TEXT("StreamingDistanceMultiplier"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_VisibilityBasedAnimTickOption(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SkinnedMeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SkinnedMeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USkinnedMeshComponent::StaticClass(), TEXT("VisibilityBasedAnimTickOption"));
	if(!Property) { check(false); return 0;}
	EVisibilityBasedAnimTickOption PropertyValue = EVisibilityBasedAnimTickOption();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushinteger(InScriptContext, (int)PropertyValue);
	return 1;
}

int32 Set_VisibilityBasedAnimTickOption(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SkinnedMeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SkinnedMeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USkinnedMeshComponent::StaticClass(), TEXT("VisibilityBasedAnimTickOption"));
	if(!Property) { check(false); return 0;}
	EVisibilityBasedAnimTickOption PropertyValue = (EVisibilityBasedAnimTickOption)(luaL_checkint(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bOverrideMinLod(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SkinnedMeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SkinnedMeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USkinnedMeshComponent::StaticClass(), TEXT("bOverrideMinLod"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_bUseBoundsFromMasterPoseComponent(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SkinnedMeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SkinnedMeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USkinnedMeshComponent::StaticClass(), TEXT("bUseBoundsFromMasterPoseComponent"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bUseBoundsFromMasterPoseComponent(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SkinnedMeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SkinnedMeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USkinnedMeshComponent::StaticClass(), TEXT("bUseBoundsFromMasterPoseComponent"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bDisableMorphTarget(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SkinnedMeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SkinnedMeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USkinnedMeshComponent::StaticClass(), TEXT("bDisableMorphTarget"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bDisableMorphTarget(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SkinnedMeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SkinnedMeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USkinnedMeshComponent::StaticClass(), TEXT("bDisableMorphTarget"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bPerBoneMotionBlur(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SkinnedMeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SkinnedMeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USkinnedMeshComponent::StaticClass(), TEXT("bPerBoneMotionBlur"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_bComponentUseFixedSkelBounds(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SkinnedMeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SkinnedMeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USkinnedMeshComponent::StaticClass(), TEXT("bComponentUseFixedSkelBounds"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bComponentUseFixedSkelBounds(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SkinnedMeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SkinnedMeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USkinnedMeshComponent::StaticClass(), TEXT("bComponentUseFixedSkelBounds"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bConsiderAllBodiesForBounds(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SkinnedMeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SkinnedMeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USkinnedMeshComponent::StaticClass(), TEXT("bConsiderAllBodiesForBounds"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bConsiderAllBodiesForBounds(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SkinnedMeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SkinnedMeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USkinnedMeshComponent::StaticClass(), TEXT("bConsiderAllBodiesForBounds"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bSyncAttachParentLOD(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SkinnedMeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SkinnedMeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USkinnedMeshComponent::StaticClass(), TEXT("bSyncAttachParentLOD"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bSyncAttachParentLOD(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SkinnedMeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SkinnedMeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USkinnedMeshComponent::StaticClass(), TEXT("bSyncAttachParentLOD"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bCastCapsuleDirectShadow(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SkinnedMeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SkinnedMeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USkinnedMeshComponent::StaticClass(), TEXT("bCastCapsuleDirectShadow"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_bCastCapsuleIndirectShadow(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SkinnedMeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SkinnedMeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USkinnedMeshComponent::StaticClass(), TEXT("bCastCapsuleIndirectShadow"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_bEnableUpdateRateOptimizations(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SkinnedMeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SkinnedMeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USkinnedMeshComponent::StaticClass(), TEXT("bEnableUpdateRateOptimizations"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bEnableUpdateRateOptimizations(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SkinnedMeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SkinnedMeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USkinnedMeshComponent::StaticClass(), TEXT("bEnableUpdateRateOptimizations"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bDisplayDebugUpdateRateOptimizations(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SkinnedMeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SkinnedMeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USkinnedMeshComponent::StaticClass(), TEXT("bDisplayDebugUpdateRateOptimizations"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bDisplayDebugUpdateRateOptimizations(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SkinnedMeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SkinnedMeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USkinnedMeshComponent::StaticClass(), TEXT("bDisplayDebugUpdateRateOptimizations"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bRenderStatic(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SkinnedMeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SkinnedMeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USkinnedMeshComponent::StaticClass(), TEXT("bRenderStatic"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_CapsuleIndirectShadowMinVisibility(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SkinnedMeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SkinnedMeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USkinnedMeshComponent::StaticClass(), TEXT("CapsuleIndirectShadowMinVisibility"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Class(lua_State* InScriptContext)
{
	UClass* Class = USkinnedMeshComponent::StaticClass();
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Class);
	return 1;
}

const luaL_Reg Lib_Funcs[] =
{
	{ "Class", Class },
	{ "UnHideBoneByName", UnHideBoneByName },
	{ "TransformToBoneSpace", TransformToBoneSpace },
	{ "TransformFromBoneSpace", TransformFromBoneSpace },
	{ "ShowMaterialSection", ShowMaterialSection },
	{ "ShowAllMaterialSections", ShowAllMaterialSections },
	{ "SetVertexColorOverride_LinearColor", SetVertexColorOverride_LinearColor },
	{ "SetSkeletalMesh", SetSkeletalMesh },
	{ "SetRenderStatic", SetRenderStatic },
	{ "SetPhysicsAsset", SetPhysicsAsset },
	{ "SetMinLOD", SetMinLOD },
	{ "SetMasterPoseComponent", SetMasterPoseComponent },
	{ "SetForcedLOD", SetForcedLOD },
	{ "SetCastCapsuleIndirectShadow", SetCastCapsuleIndirectShadow },
	{ "SetCastCapsuleDirectShadow", SetCastCapsuleDirectShadow },
	{ "SetCapsuleIndirectShadowMinVisibility", SetCapsuleIndirectShadowMinVisibility },
	{ "IsMaterialSectionShown", IsMaterialSectionShown },
	{ "IsBoneHiddenByName", IsBoneHiddenByName },
	{ "HideBoneByName", HideBoneByName },
	{ "GetSocketBoneName", GetSocketBoneName },
	{ "GetRefPosePosition", GetRefPosePosition },
	{ "GetParentBone", GetParentBone },
	{ "GetNumLODs", GetNumLODs },
	{ "GetNumBones", GetNumBones },
	{ "GetDeltaTransformFromRefPose", GetDeltaTransformFromRefPose },
	{ "GetBoneName", GetBoneName },
	{ "GetBoneIndex", GetBoneIndex },
	{ "FindClosestBone_K2", FindClosestBone_K2 },
	{ "ClearVertexColorOverride", ClearVertexColorOverride },
	{ "ClearSkinWeightOverride", ClearSkinWeightOverride },
	{ "BoneIsChildOf", BoneIsChildOf },
	{ "Get_SkeletalMesh", Get_SkeletalMesh },
	{ "Get_significanceManagerLevel", Get_significanceManagerLevel },
	{ "Set_significanceManagerLevel", Set_significanceManagerLevel },
	{ "Get_PhysicsAssetOverride", Get_PhysicsAssetOverride },
	{ "Get_ForcedLodModel", Get_ForcedLodModel },
	{ "Get_MinLodModel", Get_MinLodModel },
	{ "Get_ForcedShadowLod", Get_ForcedShadowLod },
	{ "Get_ShadowLODBias", Get_ShadowLODBias },
	{ "Get_StreamingDistanceMultiplier", Get_StreamingDistanceMultiplier },
	{ "Set_StreamingDistanceMultiplier", Set_StreamingDistanceMultiplier },
	{ "Get_VisibilityBasedAnimTickOption", Get_VisibilityBasedAnimTickOption },
	{ "Set_VisibilityBasedAnimTickOption", Set_VisibilityBasedAnimTickOption },
	{ "Get_bOverrideMinLod", Get_bOverrideMinLod },
	{ "Get_bUseBoundsFromMasterPoseComponent", Get_bUseBoundsFromMasterPoseComponent },
	{ "Set_bUseBoundsFromMasterPoseComponent", Set_bUseBoundsFromMasterPoseComponent },
	{ "Get_bDisableMorphTarget", Get_bDisableMorphTarget },
	{ "Set_bDisableMorphTarget", Set_bDisableMorphTarget },
	{ "Get_bPerBoneMotionBlur", Get_bPerBoneMotionBlur },
	{ "Get_bComponentUseFixedSkelBounds", Get_bComponentUseFixedSkelBounds },
	{ "Set_bComponentUseFixedSkelBounds", Set_bComponentUseFixedSkelBounds },
	{ "Get_bConsiderAllBodiesForBounds", Get_bConsiderAllBodiesForBounds },
	{ "Set_bConsiderAllBodiesForBounds", Set_bConsiderAllBodiesForBounds },
	{ "Get_bSyncAttachParentLOD", Get_bSyncAttachParentLOD },
	{ "Set_bSyncAttachParentLOD", Set_bSyncAttachParentLOD },
	{ "Get_bCastCapsuleDirectShadow", Get_bCastCapsuleDirectShadow },
	{ "Get_bCastCapsuleIndirectShadow", Get_bCastCapsuleIndirectShadow },
	{ "Get_bEnableUpdateRateOptimizations", Get_bEnableUpdateRateOptimizations },
	{ "Set_bEnableUpdateRateOptimizations", Set_bEnableUpdateRateOptimizations },
	{ "Get_bDisplayDebugUpdateRateOptimizations", Get_bDisplayDebugUpdateRateOptimizations },
	{ "Set_bDisplayDebugUpdateRateOptimizations", Set_bDisplayDebugUpdateRateOptimizations },
	{ "Get_bRenderStatic", Get_bRenderStatic },
	{ "Get_CapsuleIndirectShadowMinVisibility", Get_CapsuleIndirectShadowMinVisibility },
	{ "GetBoneLocationByName", GetBoneLocationByName },
	{ "GetSkeletalMesh", GetSkeletalMesh },
	{ "SetReceivesDecals", SetReceivesDecals },
	{ "GetPredictedLODLevel", GetPredictedLODLevel },
	{ "GetNearestBone", GetNearestBone },
	{ "GetNearestBoneInCollider", GetNearestBoneInCollider },
	{ "SetOverrideMinLod", SetOverrideMinLod },
	{ "GetMaxDistanceFactor", GetMaxDistanceFactor },
	{ "SetAnimUpdateRateParams", SetAnimUpdateRateParams },
	{ "Get_bRecentlyRendered", Get_bRecentlyRendered },
	{ "is_nil", wLua::LuaStatic::isnil },
	{ "__gc", wLua::LuaStatic::removeUClassFrameCache },
	{ NULL, NULL }
};

void Register(lua_State *InScriptContext)
{
	lua_newtable(InScriptContext);
	luaL_register(InScriptContext, NULL, Lib_Funcs);
	AzureHelpFuncs::AuxRegister(InScriptContext, "SkinnedMeshComponent");
}
void SetMtLink(lua_State *InScriptContext)
{
	AzureHelpFuncs::AuxSetMtLink(InScriptContext, "SkinnedMeshComponent", "MeshComponent",USERDATATYPE_UOBJECT);
}

}