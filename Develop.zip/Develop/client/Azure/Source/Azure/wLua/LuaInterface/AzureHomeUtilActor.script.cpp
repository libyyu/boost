#include "Azure.h"
#include "Utility/help_funcs.h"
#include "wLua/UObjectHeaders.h"
#include "GameLogic/Home/AzureHomeUtilActor.h"
#include "AzureLuaIntegration.h"

namespace LuaAzureHomeUtilActor
{
int32 SetMask(lua_State*);
int32 GetMask(lua_State*);
int32 RotatorToFQuat(lua_State*);

int32 ZeroMask(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureHomeUtilActor",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureHomeUtilActor must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		int32 size;
	} Params;
	Params.size = (luaL_checkint(InScriptContext, 2));
#if UE_GAME
	AAzureHomeUtilActor * This = (AAzureHomeUtilActor *)Obj;
	This->ZeroMask(Params.size);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("ZeroMask"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(int32*)(params.GetStructMemory() + 0) = Params.size;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.size = *(int32*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 ReleaseMaskCache(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureHomeUtilActor",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureHomeUtilActor must be non-null"); lua_error(InScriptContext);  return 0;}
#if UE_GAME
	AAzureHomeUtilActor * This = (AAzureHomeUtilActor *)Obj;
	This->ReleaseMaskCache();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("ReleaseMaskCache"));
	if(!Function) { check(false); return 0;}
	Obj->ProcessEvent(Function, NULL);
#endif
	return 0;
}

int32 InitMaskCache(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureHomeUtilActor",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureHomeUtilActor must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		int32 size;
	} Params;
	Params.size = (luaL_checkint(InScriptContext, 2));
#if UE_GAME
	AAzureHomeUtilActor * This = (AAzureHomeUtilActor *)Obj;
	This->InitMaskCache(Params.size);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("InitMaskCache"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(int32*)(params.GetStructMemory() + 0) = Params.size;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.size = *(int32*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 CreateDynamicMaterialInstance(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureHomeUtilActor",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureHomeUtilActor must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		UMaterialInterface* Parent = nullptr;
		UMaterialInstanceDynamic* ReturnValue = nullptr;
	} Params;
	Params.Parent = (UMaterialInterface*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"MaterialInterface");;
#if UE_GAME
	AAzureHomeUtilActor * This = (AAzureHomeUtilActor *)Obj;
	Params.ReturnValue = This->CreateDynamicMaterialInstance(Params.Parent);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("CreateDynamicMaterialInstance"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(UMaterialInterface**)(params.GetStructMemory() + 0) = Params.Parent;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.Parent = *(UMaterialInterface**)(params.GetStructMemory() + 0);
		Params.ReturnValue = *(UMaterialInstanceDynamic**)(params.GetStructMemory() + 8);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 CopyTexture2D(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureHomeUtilActor",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureHomeUtilActor must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		UMaterialInstanceDynamic* pWallDynamic = nullptr;
		UMaterialInstanceDynamic* pItemDynamic = nullptr;
	} Params;
	Params.pWallDynamic = (UMaterialInstanceDynamic*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"MaterialInstanceDynamic");;
	Params.pItemDynamic = (UMaterialInstanceDynamic*)wLua::FLuaUtils::GetUObject(InScriptContext,3,"MaterialInstanceDynamic");;
#if UE_GAME
	AAzureHomeUtilActor * This = (AAzureHomeUtilActor *)Obj;
	This->CopyTexture2D(Params.pWallDynamic,Params.pItemDynamic);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("CopyTexture2D"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(UMaterialInstanceDynamic**)(params.GetStructMemory() + 0) = Params.pWallDynamic;
		*(UMaterialInstanceDynamic**)(params.GetStructMemory() + 8) = Params.pItemDynamic;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.pWallDynamic = *(UMaterialInstanceDynamic**)(params.GetStructMemory() + 0);
		Params.pItemDynamic = *(UMaterialInstanceDynamic**)(params.GetStructMemory() + 8);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 New(lua_State* InScriptContext)
{
	UObject* Outer = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Object");
	FName Name = FName(luaL_checkstring(InScriptContext, 2));
	UObject* Obj = NewObject<AAzureHomeUtilActor>(Outer, Name);
	wLua::FLuaUtils::ReturnUObject(InScriptContext,Obj);
	return 1;
}

int32 Destroy(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureHomeUtilActor",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureHomeUtilActor must be non-null"); lua_error(InScriptContext);  return 0;}
		AActor * actor = Cast<AActor>(Obj);
		actor->Destroy();
		userdata->flag |= wLua::LuaObjectFlag::DESTROYED;
		wLua::FLuaUtils::RemoveObjectReference(Obj, userdata->stamp, InScriptContext);
#ifdef AZURE_BUILD_WLUACHECK
		UE_LOG(LogAzure, Warning, TEXT("Destroy AzureHomeUtilActor: %x userdata:%x   stamp:%x"),Obj,userdata,userdata->stamp);
#endif
	return 0;
}

int32 Class(lua_State* InScriptContext)
{
	UClass* Class = AAzureHomeUtilActor::StaticClass();
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Class);
	return 1;
}

const luaL_Reg Lib_Funcs[] =
{
	{ "New", New },
	{ "Destroy", Destroy },
	{ "Class", Class },
	{ "ZeroMask", ZeroMask },
	{ "ReleaseMaskCache", ReleaseMaskCache },
	{ "InitMaskCache", InitMaskCache },
	{ "CreateDynamicMaterialInstance", CreateDynamicMaterialInstance },
	{ "CopyTexture2D", CopyTexture2D },
	{ "SetMask", SetMask },
	{ "GetMask", GetMask },
	{ "RotatorToFQuat", RotatorToFQuat },
	{ "is_nil", wLua::LuaStatic::isnil },
	{ "__gc", wLua::LuaStatic::removeUClassFrameCache },
	{ NULL, NULL }
};

void Register(lua_State *InScriptContext)
{
	lua_newtable(InScriptContext);
	luaL_register(InScriptContext, NULL, Lib_Funcs);
	AzureHelpFuncs::AuxRegister(InScriptContext, "AzureHomeUtilActor");
}
void SetMtLink(lua_State *InScriptContext)
{
	AzureHelpFuncs::AuxSetMtLink(InScriptContext, "AzureHomeUtilActor", "Actor",USERDATATYPE_UOBJECT);
}

}