#include "Azure.h"
#include "Utility/help_funcs.h"
#include "wLua/UObjectHeaders.h"
#include "NavigationData.h"
#include "AzureLuaIntegration.h"

namespace LuaNavigationData
{
int32 Get_bEnableDrawing(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"NavigationData",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"NavigationData must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(ANavigationData::StaticClass(), TEXT("bEnableDrawing"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bEnableDrawing(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"NavigationData",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"NavigationData must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(ANavigationData::StaticClass(), TEXT("bEnableDrawing"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bForceRebuildOnLoad(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"NavigationData",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"NavigationData must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(ANavigationData::StaticClass(), TEXT("bForceRebuildOnLoad"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bForceRebuildOnLoad(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"NavigationData",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"NavigationData must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(ANavigationData::StaticClass(), TEXT("bForceRebuildOnLoad"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bCanBeMainNavData(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"NavigationData",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"NavigationData must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(ANavigationData::StaticClass(), TEXT("bCanBeMainNavData"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bCanBeMainNavData(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"NavigationData",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"NavigationData must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(ANavigationData::StaticClass(), TEXT("bCanBeMainNavData"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bCanSpawnOnRebuild(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"NavigationData",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"NavigationData must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(ANavigationData::StaticClass(), TEXT("bCanSpawnOnRebuild"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bCanSpawnOnRebuild(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"NavigationData",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"NavigationData must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(ANavigationData::StaticClass(), TEXT("bCanSpawnOnRebuild"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_RuntimeGeneration(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"NavigationData",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"NavigationData must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(ANavigationData::StaticClass(), TEXT("RuntimeGeneration"));
	if(!Property) { check(false); return 0;}
	ERuntimeGenerationType PropertyValue = ERuntimeGenerationType();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushinteger(InScriptContext, (int)PropertyValue);
	return 1;
}

int32 Set_RuntimeGeneration(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"NavigationData",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"NavigationData must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(ANavigationData::StaticClass(), TEXT("RuntimeGeneration"));
	if(!Property) { check(false); return 0;}
	ERuntimeGenerationType PropertyValue = (ERuntimeGenerationType)(luaL_checkint(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_ObservedPathsTickInterval(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"NavigationData",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"NavigationData must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(ANavigationData::StaticClass(), TEXT("ObservedPathsTickInterval"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_ObservedPathsTickInterval(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"NavigationData",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"NavigationData must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(ANavigationData::StaticClass(), TEXT("ObservedPathsTickInterval"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Class(lua_State* InScriptContext)
{
	UClass* Class = ANavigationData::StaticClass();
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Class);
	return 1;
}

const luaL_Reg Lib_Funcs[] =
{
	{ "Class", Class },
	{ "Get_bEnableDrawing", Get_bEnableDrawing },
	{ "Set_bEnableDrawing", Set_bEnableDrawing },
	{ "Get_bForceRebuildOnLoad", Get_bForceRebuildOnLoad },
	{ "Set_bForceRebuildOnLoad", Set_bForceRebuildOnLoad },
	{ "Get_bCanBeMainNavData", Get_bCanBeMainNavData },
	{ "Set_bCanBeMainNavData", Set_bCanBeMainNavData },
	{ "Get_bCanSpawnOnRebuild", Get_bCanSpawnOnRebuild },
	{ "Set_bCanSpawnOnRebuild", Set_bCanSpawnOnRebuild },
	{ "Get_RuntimeGeneration", Get_RuntimeGeneration },
	{ "Set_RuntimeGeneration", Set_RuntimeGeneration },
	{ "Get_ObservedPathsTickInterval", Get_ObservedPathsTickInterval },
	{ "Set_ObservedPathsTickInterval", Set_ObservedPathsTickInterval },
	{ "is_nil", wLua::LuaStatic::isnil },
	{ "__gc", wLua::LuaStatic::removeUClassFrameCache },
	{ NULL, NULL }
};

void Register(lua_State *InScriptContext)
{
	lua_newtable(InScriptContext);
	luaL_register(InScriptContext, NULL, Lib_Funcs);
	AzureHelpFuncs::AuxRegister(InScriptContext, "NavigationData");
}
void SetMtLink(lua_State *InScriptContext)
{
	AzureHelpFuncs::AuxSetMtLink(InScriptContext, "NavigationData", "Actor",USERDATATYPE_UOBJECT);
}

}