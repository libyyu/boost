#include "Azure.h"
#include "Utility/help_funcs.h"
#include "wLua/UObjectHeaders.h"
#include "GameFramework/TouchInterface.h"
#include "AzureLuaIntegration.h"

namespace LuaTouchInterface
{
int32 Get_ActiveOpacity(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"TouchInterface",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"TouchInterface must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UTouchInterface::StaticClass(), TEXT("ActiveOpacity"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_ActiveOpacity(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"TouchInterface",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"TouchInterface must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UTouchInterface::StaticClass(), TEXT("ActiveOpacity"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_InactiveOpacity(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"TouchInterface",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"TouchInterface must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UTouchInterface::StaticClass(), TEXT("InactiveOpacity"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_InactiveOpacity(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"TouchInterface",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"TouchInterface must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UTouchInterface::StaticClass(), TEXT("InactiveOpacity"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_ActiveOpacity_Image2(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"TouchInterface",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"TouchInterface must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UTouchInterface::StaticClass(), TEXT("ActiveOpacity_Image2"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_ActiveOpacity_Image2(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"TouchInterface",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"TouchInterface must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UTouchInterface::StaticClass(), TEXT("ActiveOpacity_Image2"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_InActiveOpacity_Image2(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"TouchInterface",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"TouchInterface must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UTouchInterface::StaticClass(), TEXT("InActiveOpacity_Image2"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_InActiveOpacity_Image2(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"TouchInterface",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"TouchInterface must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UTouchInterface::StaticClass(), TEXT("InActiveOpacity_Image2"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_ActiveOpacity_Image3(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"TouchInterface",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"TouchInterface must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UTouchInterface::StaticClass(), TEXT("ActiveOpacity_Image3"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_ActiveOpacity_Image3(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"TouchInterface",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"TouchInterface must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UTouchInterface::StaticClass(), TEXT("ActiveOpacity_Image3"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_InActiveOpacity_Image3(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"TouchInterface",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"TouchInterface must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UTouchInterface::StaticClass(), TEXT("InActiveOpacity_Image3"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_InActiveOpacity_Image3(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"TouchInterface",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"TouchInterface must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UTouchInterface::StaticClass(), TEXT("InActiveOpacity_Image3"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_TimeUntilDeactive(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"TouchInterface",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"TouchInterface must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UTouchInterface::StaticClass(), TEXT("TimeUntilDeactive"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_TimeUntilDeactive(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"TouchInterface",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"TouchInterface must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UTouchInterface::StaticClass(), TEXT("TimeUntilDeactive"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_TimeUntilReset(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"TouchInterface",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"TouchInterface must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UTouchInterface::StaticClass(), TEXT("TimeUntilReset"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_TimeUntilReset(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"TouchInterface",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"TouchInterface must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UTouchInterface::StaticClass(), TEXT("TimeUntilReset"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_ActivationDelay(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"TouchInterface",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"TouchInterface must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UTouchInterface::StaticClass(), TEXT("ActivationDelay"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_ActivationDelay(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"TouchInterface",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"TouchInterface must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UTouchInterface::StaticClass(), TEXT("ActivationDelay"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bPreventRecenter(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"TouchInterface",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"TouchInterface must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UTouchInterface::StaticClass(), TEXT("bPreventRecenter"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = bool();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bPreventRecenter(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"TouchInterface",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"TouchInterface must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UTouchInterface::StaticClass(), TEXT("bPreventRecenter"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_StartupDelay(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"TouchInterface",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"TouchInterface must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UTouchInterface::StaticClass(), TEXT("StartupDelay"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_StartupDelay(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"TouchInterface",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"TouchInterface must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UTouchInterface::StaticClass(), TEXT("StartupDelay"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bUseDrag(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"TouchInterface",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"TouchInterface must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UTouchInterface::StaticClass(), TEXT("bUseDrag"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = bool();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bUseDrag(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"TouchInterface",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"TouchInterface must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UTouchInterface::StaticClass(), TEXT("bUseDrag"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 New(lua_State* InScriptContext)
{
	UObject* Outer = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Object");
	FName Name = FName(luaL_checkstring(InScriptContext, 2));
	UObject* Obj = NewObject<UTouchInterface>(Outer, Name);
	wLua::FLuaUtils::ReturnUObject(InScriptContext,Obj);
	return 1;
}

int32 Destroy(lua_State* InScriptContext)
{
	return 0;
}

int32 Class(lua_State* InScriptContext)
{
	UClass* Class = UTouchInterface::StaticClass();
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Class);
	return 1;
}

const luaL_Reg Lib_Funcs[] =
{
	{ "New", New },
	{ "Destroy", Destroy },
	{ "Class", Class },
	{ "Get_ActiveOpacity", Get_ActiveOpacity },
	{ "Set_ActiveOpacity", Set_ActiveOpacity },
	{ "Get_InactiveOpacity", Get_InactiveOpacity },
	{ "Set_InactiveOpacity", Set_InactiveOpacity },
	{ "Get_ActiveOpacity_Image2", Get_ActiveOpacity_Image2 },
	{ "Set_ActiveOpacity_Image2", Set_ActiveOpacity_Image2 },
	{ "Get_InActiveOpacity_Image2", Get_InActiveOpacity_Image2 },
	{ "Set_InActiveOpacity_Image2", Set_InActiveOpacity_Image2 },
	{ "Get_ActiveOpacity_Image3", Get_ActiveOpacity_Image3 },
	{ "Set_ActiveOpacity_Image3", Set_ActiveOpacity_Image3 },
	{ "Get_InActiveOpacity_Image3", Get_InActiveOpacity_Image3 },
	{ "Set_InActiveOpacity_Image3", Set_InActiveOpacity_Image3 },
	{ "Get_TimeUntilDeactive", Get_TimeUntilDeactive },
	{ "Set_TimeUntilDeactive", Set_TimeUntilDeactive },
	{ "Get_TimeUntilReset", Get_TimeUntilReset },
	{ "Set_TimeUntilReset", Set_TimeUntilReset },
	{ "Get_ActivationDelay", Get_ActivationDelay },
	{ "Set_ActivationDelay", Set_ActivationDelay },
	{ "Get_bPreventRecenter", Get_bPreventRecenter },
	{ "Set_bPreventRecenter", Set_bPreventRecenter },
	{ "Get_StartupDelay", Get_StartupDelay },
	{ "Set_StartupDelay", Set_StartupDelay },
	{ "Get_bUseDrag", Get_bUseDrag },
	{ "Set_bUseDrag", Set_bUseDrag },
	{ "is_nil", wLua::LuaStatic::isnil },
	{ "__gc", wLua::LuaStatic::removeUClassFrameCache },
	{ NULL, NULL }
};

void Register(lua_State *InScriptContext)
{
	lua_newtable(InScriptContext);
	luaL_register(InScriptContext, NULL, Lib_Funcs);
	AzureHelpFuncs::AuxRegister(InScriptContext, "TouchInterface");
}
void SetMtLink(lua_State *InScriptContext)
{
	AzureHelpFuncs::AuxSetMtLink(InScriptContext, "TouchInterface", "Object",USERDATATYPE_UOBJECT);
}

}