#include "Azure.h"
#include "Utility/help_funcs.h"
#include "wLua/UObjectHeaders.h"
#include "Kismet/KismetRenderingLibrary.h"
#include "AzureLuaIntegration.h"

namespace LuaKismetRenderingLibrary
{
int32 RenderTargetCreateStaticTexture2DEditorOnly(lua_State* InScriptContext)
{
	UClass * Obj = UKismetRenderingLibrary::StaticClass(); 
	struct FDispatchParams
	{
		UTextureRenderTarget2D* RenderTarget = nullptr;
		FString Name;
		TEnumAsByte<TextureCompressionSettings> CompressionSettings;
		TEnumAsByte<TextureMipGenSettings> MipSettings;
		UTexture2D* ReturnValue = nullptr;
	} Params;
	Params.RenderTarget = (UTextureRenderTarget2D*)wLua::FLuaUtils::GetUObject(InScriptContext,1,"TextureRenderTarget2D");;
	Params.Name = lua_isnoneornil(InScriptContext,2) ? FString(TEXT("Texture")) : UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 2));
	Params.CompressionSettings = lua_isnoneornil(InScriptContext,3) ? TEnumAsByte<TextureCompressionSettings>(TextureCompressionSettings::TC_Default) : (TEnumAsByte<TextureCompressionSettings>)(luaL_checkint(InScriptContext, 3));
	Params.MipSettings = lua_isnoneornil(InScriptContext,4) ? TEnumAsByte<TextureMipGenSettings>(TextureMipGenSettings::TMGS_FromTextureGroup) : (TEnumAsByte<TextureMipGenSettings>)(luaL_checkint(InScriptContext, 4));
	Params.ReturnValue = UKismetRenderingLibrary::RenderTargetCreateStaticTexture2DEditorOnly(Params.RenderTarget,Params.Name,Params.CompressionSettings,Params.MipSettings);
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 ReleaseRenderTarget2D(lua_State* InScriptContext)
{
	UClass * Obj = UKismetRenderingLibrary::StaticClass(); 
	struct FDispatchParams
	{
		UTextureRenderTarget2D* TextureRenderTarget = nullptr;
	} Params;
	Params.TextureRenderTarget = (UTextureRenderTarget2D*)wLua::FLuaUtils::GetUObject(InScriptContext,1,"TextureRenderTarget2D");;
	UKismetRenderingLibrary::ReleaseRenderTarget2D(Params.TextureRenderTarget);
	return 0;
}

int32 ReadRenderTargetUV(lua_State* InScriptContext)
{
	UClass * Obj = UKismetRenderingLibrary::StaticClass(); 
	struct FDispatchParams
	{
		UObject* WorldContextObject = nullptr;
		UTextureRenderTarget2D* TextureRenderTarget = nullptr;
		float U;
		float V;
		FColor ReturnValue;
	} Params;
	Params.WorldContextObject = (UObject*)wLua::FLuaUtils::GetUObject(InScriptContext,1,"Object");;
	Params.TextureRenderTarget = (UTextureRenderTarget2D*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"TextureRenderTarget2D");;
	Params.U = (float)(luaL_checknumber(InScriptContext, 3));
	Params.V = (float)(luaL_checknumber(InScriptContext, 4));
	Params.ReturnValue = UKismetRenderingLibrary::ReadRenderTargetUV(Params.WorldContextObject,Params.TextureRenderTarget,Params.U,Params.V);
	wLua::FLuaLinearColor::Return(InScriptContext, FLinearColor(Params.ReturnValue));
	return 1;
}

int32 ReadRenderTargetRawUV(lua_State* InScriptContext)
{
	UClass * Obj = UKismetRenderingLibrary::StaticClass(); 
	struct FDispatchParams
	{
		UObject* WorldContextObject = nullptr;
		UTextureRenderTarget2D* TextureRenderTarget = nullptr;
		float U;
		float V;
		FLinearColor ReturnValue;
	} Params;
	Params.WorldContextObject = (UObject*)wLua::FLuaUtils::GetUObject(InScriptContext,1,"Object");;
	Params.TextureRenderTarget = (UTextureRenderTarget2D*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"TextureRenderTarget2D");;
	Params.U = (float)(luaL_checknumber(InScriptContext, 3));
	Params.V = (float)(luaL_checknumber(InScriptContext, 4));
	Params.ReturnValue = UKismetRenderingLibrary::ReadRenderTargetRawUV(Params.WorldContextObject,Params.TextureRenderTarget,Params.U,Params.V);
	wLua::FLuaLinearColor::Return(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 ReadRenderTargetRawPixel(lua_State* InScriptContext)
{
	UClass * Obj = UKismetRenderingLibrary::StaticClass(); 
	struct FDispatchParams
	{
		UObject* WorldContextObject = nullptr;
		UTextureRenderTarget2D* TextureRenderTarget = nullptr;
		int32 X;
		int32 Y;
		FLinearColor ReturnValue;
	} Params;
	Params.WorldContextObject = (UObject*)wLua::FLuaUtils::GetUObject(InScriptContext,1,"Object");;
	Params.TextureRenderTarget = (UTextureRenderTarget2D*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"TextureRenderTarget2D");;
	Params.X = (luaL_checkint(InScriptContext, 3));
	Params.Y = (luaL_checkint(InScriptContext, 4));
	Params.ReturnValue = UKismetRenderingLibrary::ReadRenderTargetRawPixel(Params.WorldContextObject,Params.TextureRenderTarget,Params.X,Params.Y);
	wLua::FLuaLinearColor::Return(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 ReadRenderTargetPixelFloat16Value(lua_State* InScriptContext)
{
	UClass * Obj = UKismetRenderingLibrary::StaticClass(); 
	struct FDispatchParams
	{
		UObject* WorldContextObject = nullptr;
		UTextureRenderTarget2D* TextureRenderTarget = nullptr;
		TArray<FVector4> OutData;
	} Params;
	Params.WorldContextObject = (UObject*)wLua::FLuaUtils::GetUObject(InScriptContext,1,"Object");;
	Params.TextureRenderTarget = (UTextureRenderTarget2D*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"TextureRenderTarget2D");;
	UKismetRenderingLibrary::ReadRenderTargetPixelFloat16Value(Params.WorldContextObject,Params.TextureRenderTarget,Params.OutData);
	{lua_newtable(InScriptContext); int i = 1; for(auto It = Params.OutData.CreateConstIterator(); It; ++It,++i) {  wLua::FLuaVector4::Return(InScriptContext, (*It)); lua_rawseti(InScriptContext,-2,i);     }  }
	return 1;
}

int32 ReadRenderTargetPixel(lua_State* InScriptContext)
{
	UClass * Obj = UKismetRenderingLibrary::StaticClass(); 
	struct FDispatchParams
	{
		UObject* WorldContextObject = nullptr;
		UTextureRenderTarget2D* TextureRenderTarget = nullptr;
		int32 X;
		int32 Y;
		FColor ReturnValue;
	} Params;
	Params.WorldContextObject = (UObject*)wLua::FLuaUtils::GetUObject(InScriptContext,1,"Object");;
	Params.TextureRenderTarget = (UTextureRenderTarget2D*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"TextureRenderTarget2D");;
	Params.X = (luaL_checkint(InScriptContext, 3));
	Params.Y = (luaL_checkint(InScriptContext, 4));
	Params.ReturnValue = UKismetRenderingLibrary::ReadRenderTargetPixel(Params.WorldContextObject,Params.TextureRenderTarget,Params.X,Params.Y);
	wLua::FLuaLinearColor::Return(InScriptContext, FLinearColor(Params.ReturnValue));
	return 1;
}

int32 ReadRenderTargetAllRawPixel(lua_State* InScriptContext)
{
	UClass * Obj = UKismetRenderingLibrary::StaticClass(); 
	struct FDispatchParams
	{
		UObject* WorldContextObject = nullptr;
		UTextureRenderTarget2D* TextureRenderTarget = nullptr;
		TArray<FVector4> OutData;
	} Params;
	Params.WorldContextObject = (UObject*)wLua::FLuaUtils::GetUObject(InScriptContext,1,"Object");;
	Params.TextureRenderTarget = (UTextureRenderTarget2D*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"TextureRenderTarget2D");;
	UKismetRenderingLibrary::ReadRenderTargetAllRawPixel(Params.WorldContextObject,Params.TextureRenderTarget,Params.OutData);
	{lua_newtable(InScriptContext); int i = 1; for(auto It = Params.OutData.CreateConstIterator(); It; ++It,++i) {  wLua::FLuaVector4::Return(InScriptContext, (*It)); lua_rawseti(InScriptContext,-2,i);     }  }
	return 1;
}

int32 ImportFileAsTexture2D(lua_State* InScriptContext)
{
	UClass * Obj = UKismetRenderingLibrary::StaticClass(); 
	struct FDispatchParams
	{
		UObject* WorldContextObject = nullptr;
		FString Filename;
		UTexture2D* ReturnValue = nullptr;
	} Params;
	Params.WorldContextObject = (UObject*)wLua::FLuaUtils::GetUObject(InScriptContext,1,"Object");;
	Params.Filename = UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 2));
	Params.ReturnValue = UKismetRenderingLibrary::ImportFileAsTexture2D(Params.WorldContextObject,Params.Filename);
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 ImportBufferAsTexture2D(lua_State* InScriptContext)
{
	UClass * Obj = UKismetRenderingLibrary::StaticClass(); 
	struct FDispatchParams
	{
		UObject* WorldContextObject = nullptr;
		TArray<uint8> Buffer;
		UTexture2D* ReturnValue = nullptr;
	} Params;
	Params.WorldContextObject = (UObject*)wLua::FLuaUtils::GetUObject(InScriptContext,1,"Object");;
	Params.Buffer = [](lua_State * _InScriptContext){ TArray<uint8> ret; lua_pushnil(_InScriptContext); while(lua_next(_InScriptContext,2)!=0){ uint8 item = (uint8)(luaL_checkint(_InScriptContext, -1)); ret.Add(item); lua_pop(_InScriptContext,1);  } return ret; }(InScriptContext);;
	Params.ReturnValue = UKismetRenderingLibrary::ImportBufferAsTexture2D(Params.WorldContextObject,Params.Buffer);
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 ExportTexture2D(lua_State* InScriptContext)
{
	UClass * Obj = UKismetRenderingLibrary::StaticClass(); 
	struct FDispatchParams
	{
		UObject* WorldContextObject = nullptr;
		UTexture2D* Texture = nullptr;
		FString FilePath;
		FString FileName;
	} Params;
	Params.WorldContextObject = (UObject*)wLua::FLuaUtils::GetUObject(InScriptContext,1,"Object");;
	Params.Texture = (UTexture2D*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"Texture2D");;
	Params.FilePath = UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 3));
	Params.FileName = UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 4));
	UKismetRenderingLibrary::ExportTexture2D(Params.WorldContextObject,Params.Texture,Params.FilePath,Params.FileName);
	return 0;
}

int32 ExportRenderTarget(lua_State* InScriptContext)
{
	UClass * Obj = UKismetRenderingLibrary::StaticClass(); 
	struct FDispatchParams
	{
		UObject* WorldContextObject = nullptr;
		UTextureRenderTarget2D* TextureRenderTarget = nullptr;
		FString FilePath;
		FString FileName;
	} Params;
	Params.WorldContextObject = (UObject*)wLua::FLuaUtils::GetUObject(InScriptContext,1,"Object");;
	Params.TextureRenderTarget = (UTextureRenderTarget2D*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"TextureRenderTarget2D");;
	Params.FilePath = UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 3));
	Params.FileName = UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 4));
	UKismetRenderingLibrary::ExportRenderTarget(Params.WorldContextObject,Params.TextureRenderTarget,Params.FilePath,Params.FileName);
	return 0;
}

int32 DrawMaterialToRenderTarget(lua_State* InScriptContext)
{
	UClass * Obj = UKismetRenderingLibrary::StaticClass(); 
	struct FDispatchParams
	{
		UObject* WorldContextObject = nullptr;
		UTextureRenderTarget2D* TextureRenderTarget = nullptr;
		UMaterialInterface* Material = nullptr;
		bool NeedFlush;
	} Params;
	Params.WorldContextObject = (UObject*)wLua::FLuaUtils::GetUObject(InScriptContext,1,"Object");;
	Params.TextureRenderTarget = (UTextureRenderTarget2D*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"TextureRenderTarget2D");;
	Params.Material = (UMaterialInterface*)wLua::FLuaUtils::GetUObject(InScriptContext,3,"MaterialInterface");;
	Params.NeedFlush = lua_isnoneornil(InScriptContext,4) ? bool(true) : !!(lua_toboolean(InScriptContext, 4));
	UKismetRenderingLibrary::DrawMaterialToRenderTarget(Params.WorldContextObject,Params.TextureRenderTarget,Params.Material,Params.NeedFlush);
	return 0;
}

int32 CreateRenderTarget2D(lua_State* InScriptContext)
{
	UClass * Obj = UKismetRenderingLibrary::StaticClass(); 
	struct FDispatchParams
	{
		UObject* WorldContextObject = nullptr;
		int32 Width;
		int32 Height;
		TEnumAsByte<ETextureRenderTargetFormat> Format;
		UTextureRenderTarget2D* ReturnValue = nullptr;
	} Params;
	Params.WorldContextObject = (UObject*)wLua::FLuaUtils::GetUObject(InScriptContext,1,"Object");;
	Params.Width = lua_isnoneornil(InScriptContext,2) ? int32(256) : (luaL_checkint(InScriptContext, 2));
	Params.Height = lua_isnoneornil(InScriptContext,3) ? int32(256) : (luaL_checkint(InScriptContext, 3));
	Params.Format = lua_isnoneornil(InScriptContext,4) ? TEnumAsByte<ETextureRenderTargetFormat>(ETextureRenderTargetFormat::RTF_RGBA16f) : (TEnumAsByte<ETextureRenderTargetFormat>)(luaL_checkint(InScriptContext, 4));
	Params.ReturnValue = UKismetRenderingLibrary::CreateRenderTarget2D(Params.WorldContextObject,Params.Width,Params.Height,Params.Format);
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 ConvertRenderTargetToTexture2DEditorOnly(lua_State* InScriptContext)
{
	UClass * Obj = UKismetRenderingLibrary::StaticClass(); 
	struct FDispatchParams
	{
		UObject* WorldContextObject = nullptr;
		UTextureRenderTarget2D* RenderTarget = nullptr;
		UTexture2D* Texture = nullptr;
	} Params;
	Params.WorldContextObject = (UObject*)wLua::FLuaUtils::GetUObject(InScriptContext,1,"Object");;
	Params.RenderTarget = (UTextureRenderTarget2D*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"TextureRenderTarget2D");;
	Params.Texture = (UTexture2D*)wLua::FLuaUtils::GetUObject(InScriptContext,3,"Texture2D");;
	UKismetRenderingLibrary::ConvertRenderTargetToTexture2DEditorOnly(Params.WorldContextObject,Params.RenderTarget,Params.Texture);
	return 0;
}

int32 ClearRenderTarget2D(lua_State* InScriptContext)
{
	UClass * Obj = UKismetRenderingLibrary::StaticClass(); 
	struct FDispatchParams
	{
		UObject* WorldContextObject = nullptr;
		UTextureRenderTarget2D* TextureRenderTarget = nullptr;
		FLinearColor ClearColor;
	} Params;
	Params.WorldContextObject = (UObject*)wLua::FLuaUtils::GetUObject(InScriptContext,1,"Object");;
	Params.TextureRenderTarget = (UTextureRenderTarget2D*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"TextureRenderTarget2D");;
	if(lua_isnoneornil(InScriptContext,3))
	{
		Params.ClearColor.R=0.000000;
		Params.ClearColor.G=0.000000;
		Params.ClearColor.B=0.000000;
		Params.ClearColor.A=1.000000;
	}
	else
		Params.ClearColor = (wLua::FLuaLinearColor::Get(InScriptContext, 3));
	UKismetRenderingLibrary::ClearRenderTarget2D(Params.WorldContextObject,Params.TextureRenderTarget,Params.ClearColor);
	return 0;
}

int32 New(lua_State* InScriptContext)
{
	UObject* Outer = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Object");
	FName Name = FName(luaL_checkstring(InScriptContext, 2));
	UObject* Obj = NewObject<UKismetRenderingLibrary>(Outer, Name);
	wLua::FLuaUtils::ReturnUObject(InScriptContext,Obj);
	return 1;
}

int32 Destroy(lua_State* InScriptContext)
{
	return 0;
}

int32 Class(lua_State* InScriptContext)
{
	UClass* Class = UKismetRenderingLibrary::StaticClass();
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Class);
	return 1;
}

const luaL_Reg Lib_Funcs[] =
{
	{ "New", New },
	{ "Destroy", Destroy },
	{ "Class", Class },
	{ "RenderTargetCreateStaticTexture2DEditorOnly", RenderTargetCreateStaticTexture2DEditorOnly },
	{ "ReleaseRenderTarget2D", ReleaseRenderTarget2D },
	{ "ReadRenderTargetUV", ReadRenderTargetUV },
	{ "ReadRenderTargetRawUV", ReadRenderTargetRawUV },
	{ "ReadRenderTargetRawPixel", ReadRenderTargetRawPixel },
	{ "ReadRenderTargetPixelFloat16Value", ReadRenderTargetPixelFloat16Value },
	{ "ReadRenderTargetPixel", ReadRenderTargetPixel },
	{ "ReadRenderTargetAllRawPixel", ReadRenderTargetAllRawPixel },
	{ "ImportFileAsTexture2D", ImportFileAsTexture2D },
	{ "ImportBufferAsTexture2D", ImportBufferAsTexture2D },
	{ "ExportTexture2D", ExportTexture2D },
	{ "ExportRenderTarget", ExportRenderTarget },
	{ "DrawMaterialToRenderTarget", DrawMaterialToRenderTarget },
	{ "CreateRenderTarget2D", CreateRenderTarget2D },
	{ "ConvertRenderTargetToTexture2DEditorOnly", ConvertRenderTargetToTexture2DEditorOnly },
	{ "ClearRenderTarget2D", ClearRenderTarget2D },
	{ "is_nil", wLua::LuaStatic::isnil },
	{ "__gc", wLua::LuaStatic::removeUClassFrameCache },
	{ NULL, NULL }
};

void Register(lua_State *InScriptContext)
{
	lua_newtable(InScriptContext);
	luaL_register(InScriptContext, NULL, Lib_Funcs);
	AzureHelpFuncs::AuxRegister(InScriptContext, "KismetRenderingLibrary");
}
void SetMtLink(lua_State *InScriptContext)
{
	AzureHelpFuncs::AuxSetMtLink(InScriptContext, "KismetRenderingLibrary", "Object",USERDATATYPE_UOBJECT);
}

}