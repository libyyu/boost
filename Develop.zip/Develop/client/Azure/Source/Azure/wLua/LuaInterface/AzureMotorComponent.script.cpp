#include "Azure.h"
#include "Utility/help_funcs.h"
#include "wLua/UObjectHeaders.h"
#include "AzureMotorComponent.h"
#include "AzureLuaIntegration.h"

namespace LuaAzureMotorComponent
{
int32 StartMove(lua_State*);

int32 SetParams(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureMotorComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureMotorComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float _duration;
		bool _bChangeRotWhenMove;
		bool _bChangeRotWhenStart;
		float _Speed;
		float _Acc;
		FVector _RandRotRange;
		bool _bTargetSelf;
		float _fTarselfOutwardTimeProportion;
		FRotator _tarselfOutwardDirRotator;
		FVector _emitterDir;
		float fHitContinueFly_ForwardTime;
		ACharacter* pCarrier = nullptr;
	} Params;
	Params._duration = (float)(luaL_checknumber(InScriptContext, 2));
	Params._bChangeRotWhenMove = !!(lua_toboolean(InScriptContext, 3));
	Params._bChangeRotWhenStart = !!(lua_toboolean(InScriptContext, 4));
	Params._Speed = (float)(luaL_checknumber(InScriptContext, 5));
	Params._Acc = (float)(luaL_checknumber(InScriptContext, 6));
	Params._RandRotRange = (wLua::FLuaVector::Get(InScriptContext, 7));
	Params._bTargetSelf = !!(lua_toboolean(InScriptContext, 8));
	Params._fTarselfOutwardTimeProportion = (float)(luaL_checknumber(InScriptContext, 9));
	Params._tarselfOutwardDirRotator = (wLua::FLuaRotator::Get(InScriptContext, 10));
	Params._emitterDir = (wLua::FLuaVector::Get(InScriptContext, 11));
	Params.fHitContinueFly_ForwardTime = lua_isnoneornil(InScriptContext,12) ? float(0.000000) : (float)(luaL_checknumber(InScriptContext, 12));
	Params.pCarrier = lua_isnoneornil(InScriptContext,13) ? nullptr : (ACharacter*)wLua::FLuaUtils::GetUObject(InScriptContext,13,"Character");;
#if UE_GAME
	UAzureMotorComponent * This = (UAzureMotorComponent *)Obj;
	This->SetParams(Params._duration,Params._bChangeRotWhenMove,Params._bChangeRotWhenStart,Params._Speed,Params._Acc,Params._RandRotRange,Params._bTargetSelf,Params._fTarselfOutwardTimeProportion,Params._tarselfOutwardDirRotator,Params._emitterDir,Params.fHitContinueFly_ForwardTime,Params.pCarrier);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetParams"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(float*)(params.GetStructMemory() + 0) = Params._duration;
		*(bool*)(params.GetStructMemory() + 4) = Params._bChangeRotWhenMove;
		*(bool*)(params.GetStructMemory() + 5) = Params._bChangeRotWhenStart;
		*(float*)(params.GetStructMemory() + 8) = Params._Speed;
		*(float*)(params.GetStructMemory() + 12) = Params._Acc;
		*(FVector*)(params.GetStructMemory() + 16) = Params._RandRotRange;
		*(bool*)(params.GetStructMemory() + 28) = Params._bTargetSelf;
		*(float*)(params.GetStructMemory() + 32) = Params._fTarselfOutwardTimeProportion;
		*(FRotator*)(params.GetStructMemory() + 36) = Params._tarselfOutwardDirRotator;
		*(FVector*)(params.GetStructMemory() + 48) = Params._emitterDir;
		*(float*)(params.GetStructMemory() + 60) = Params.fHitContinueFly_ForwardTime;
		*(ACharacter**)(params.GetStructMemory() + 64) = Params.pCarrier;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params._duration = *(float*)(params.GetStructMemory() + 0);
		Params._bChangeRotWhenMove = *(bool*)(params.GetStructMemory() + 4);
		Params._bChangeRotWhenStart = *(bool*)(params.GetStructMemory() + 5);
		Params._Speed = *(float*)(params.GetStructMemory() + 8);
		Params._Acc = *(float*)(params.GetStructMemory() + 12);
		Params._RandRotRange = *(FVector*)(params.GetStructMemory() + 16);
		Params._bTargetSelf = *(bool*)(params.GetStructMemory() + 28);
		Params._fTarselfOutwardTimeProportion = *(float*)(params.GetStructMemory() + 32);
		Params._tarselfOutwardDirRotator = *(FRotator*)(params.GetStructMemory() + 36);
		Params._emitterDir = *(FVector*)(params.GetStructMemory() + 48);
		Params.fHitContinueFly_ForwardTime = *(float*)(params.GetStructMemory() + 60);
		Params.pCarrier = *(ACharacter**)(params.GetStructMemory() + 64);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetDestPos(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureMotorComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureMotorComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FVector vDestPos;
		float _distTolerance;
	} Params;
	Params.vDestPos = (wLua::FLuaVector::Get(InScriptContext, 2));
	Params._distTolerance = (float)(luaL_checknumber(InScriptContext, 3));
#if UE_GAME
	UAzureMotorComponent * This = (UAzureMotorComponent *)Obj;
	This->SetDestPos(Params.vDestPos,Params._distTolerance);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetDestPos"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FVector*)(params.GetStructMemory() + 0) = Params.vDestPos;
		*(float*)(params.GetStructMemory() + 12) = Params._distTolerance;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.vDestPos = *(FVector*)(params.GetStructMemory() + 0);
		Params._distTolerance = *(float*)(params.GetStructMemory() + 12);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetDestLockPoint(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureMotorComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureMotorComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		USceneComponent* _pDestLockPoint = nullptr;
	} Params;
	Params._pDestLockPoint = (USceneComponent*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"SceneComponent");;
#if UE_GAME
	UAzureMotorComponent * This = (UAzureMotorComponent *)Obj;
	This->SetDestLockPoint(Params._pDestLockPoint);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetDestLockPoint"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(USceneComponent**)(params.GetStructMemory() + 0) = Params._pDestLockPoint;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params._pDestLockPoint = *(USceneComponent**)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetDestActor(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureMotorComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureMotorComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		AActor* _pDestActor = nullptr;
		FVector vDestActor_PosOff;
		float _distTolerance;
	} Params;
	Params._pDestActor = (AActor*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"Actor");;
	Params.vDestActor_PosOff = (wLua::FLuaVector::Get(InScriptContext, 3));
	Params._distTolerance = (float)(luaL_checknumber(InScriptContext, 4));
#if UE_GAME
	UAzureMotorComponent * This = (UAzureMotorComponent *)Obj;
	This->SetDestActor(Params._pDestActor,Params.vDestActor_PosOff,Params._distTolerance);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetDestActor"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(AActor**)(params.GetStructMemory() + 0) = Params._pDestActor;
		*(FVector*)(params.GetStructMemory() + 8) = Params.vDestActor_PosOff;
		*(float*)(params.GetStructMemory() + 20) = Params._distTolerance;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params._pDestActor = *(AActor**)(params.GetStructMemory() + 0);
		Params.vDestActor_PosOff = *(FVector*)(params.GetStructMemory() + 8);
		Params._distTolerance = *(float*)(params.GetStructMemory() + 20);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 New(lua_State* InScriptContext)
{
	UObject* Outer = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Object");
	FName Name = FName(luaL_checkstring(InScriptContext, 2));
	UObject* Obj = NewObject<UAzureMotorComponent>(Outer, Name);
	wLua::FLuaUtils::ReturnUObject(InScriptContext,Obj);
	return 1;
}

int32 Destroy(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureMotorComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureMotorComponent must be non-null"); lua_error(InScriptContext);  return 0;}
		UActorComponent * com = Cast<UActorComponent>(Obj);
		if(lua_isnoneornil(InScriptContext,2))
			com->DestroyComponent();
		else
			com->DestroyComponent(!!lua_toboolean(InScriptContext,2));
		userdata->flag |= wLua::LuaObjectFlag::DESTROYED;
		wLua::FLuaUtils::RemoveObjectReference(Obj, userdata->stamp, InScriptContext);
#ifdef AZURE_BUILD_WLUACHECK
		UE_LOG(LogAzure, Warning, TEXT("Destroy AzureMotorComponent: %x userdata:%x   stamp:%x"),Obj,userdata,userdata->stamp);
#endif
	return 0;
}

int32 Class(lua_State* InScriptContext)
{
	UClass* Class = UAzureMotorComponent::StaticClass();
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Class);
	return 1;
}

const luaL_Reg Lib_Funcs[] =
{
	{ "New", New },
	{ "Destroy", Destroy },
	{ "Class", Class },
	{ "SetParams", SetParams },
	{ "SetDestPos", SetDestPos },
	{ "SetDestLockPoint", SetDestLockPoint },
	{ "SetDestActor", SetDestActor },
	{ "StartMove", StartMove },
	{ "is_nil", wLua::LuaStatic::isnil },
	{ "__gc", wLua::LuaStatic::removeUClassFrameCache },
	{ NULL, NULL }
};

void Register(lua_State *InScriptContext)
{
	lua_newtable(InScriptContext);
	luaL_register(InScriptContext, NULL, Lib_Funcs);
	AzureHelpFuncs::AuxRegister(InScriptContext, "AzureMotorComponent");
}
void SetMtLink(lua_State *InScriptContext)
{
	AzureHelpFuncs::AuxSetMtLink(InScriptContext, "AzureMotorComponent", "ActorComponent",USERDATATYPE_UOBJECT);
}

}