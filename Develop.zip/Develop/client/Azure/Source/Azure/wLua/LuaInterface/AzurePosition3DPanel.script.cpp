#include "Azure.h"
#include "Utility/help_funcs.h"
#include "wLua/UObjectHeaders.h"
#include "Azure3DPanel.h"
#include "AzureLuaIntegration.h"

namespace LuaAzurePosition3DPanel
{
int32 SetZoomFactor(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzurePosition3DPanel",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzurePosition3DPanel must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float InValue;
	} Params;
	Params.InValue = (float)(luaL_checknumber(InScriptContext, 2));
#if UE_GAME
	UAzurePosition3DPanel * This = (UAzurePosition3DPanel *)Obj;
	This->SetZoomFactor(Params.InValue);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetZoomFactor"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(float*)(params.GetStructMemory() + 0) = Params.InValue;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.InValue = *(float*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetViewOffset(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzurePosition3DPanel",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzurePosition3DPanel must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FVector2D InValue;
	} Params;
	Params.InValue = (wLua::FLuaVector2D::Get(InScriptContext, 2));
#if UE_GAME
	UAzurePosition3DPanel * This = (UAzurePosition3DPanel *)Obj;
	This->SetViewOffset(Params.InValue);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetViewOffset"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FVector2D*)(params.GetStructMemory() + 0) = Params.InValue;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.InValue = *(FVector2D*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetPivot3D(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzurePosition3DPanel",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzurePosition3DPanel must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FVector2D InValue;
	} Params;
	Params.InValue = (wLua::FLuaVector2D::Get(InScriptContext, 2));
#if UE_GAME
	UAzurePosition3DPanel * This = (UAzurePosition3DPanel *)Obj;
	This->SetPivot3D(Params.InValue);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetPivot3D"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FVector2D*)(params.GetStructMemory() + 0) = Params.InValue;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.InValue = *(FVector2D*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetOffset(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzurePosition3DPanel",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzurePosition3DPanel must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FVector InValue;
	} Params;
	Params.InValue = (wLua::FLuaVector::Get(InScriptContext, 2));
#if UE_GAME
	UAzurePosition3DPanel * This = (UAzurePosition3DPanel *)Obj;
	This->SetOffset(Params.InValue);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetOffset"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FVector*)(params.GetStructMemory() + 0) = Params.InValue;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.InValue = *(FVector*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetInheritParentView(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzurePosition3DPanel",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzurePosition3DPanel must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool InValue;
	} Params;
	Params.InValue = !!(lua_toboolean(InScriptContext, 2));
#if UE_GAME
	UAzurePosition3DPanel * This = (UAzurePosition3DPanel *)Obj;
	This->SetInheritParentView(Params.InValue);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetInheritParentView"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(bool*)(params.GetStructMemory() + 0) = Params.InValue;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.InValue = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetAngle3D(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzurePosition3DPanel",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzurePosition3DPanel must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FVector2D InValue;
	} Params;
	Params.InValue = (wLua::FLuaVector2D::Get(InScriptContext, 2));
#if UE_GAME
	UAzurePosition3DPanel * This = (UAzurePosition3DPanel *)Obj;
	This->SetAngle3D(Params.InValue);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetAngle3D"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FVector2D*)(params.GetStructMemory() + 0) = Params.InValue;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.InValue = *(FVector2D*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 GetZoomFactor(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzurePosition3DPanel",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzurePosition3DPanel must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float ReturnValue;
	} Params;
#if UE_GAME
	UAzurePosition3DPanel * This = (UAzurePosition3DPanel *)Obj;
	Params.ReturnValue = This->GetZoomFactor();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetZoomFactor"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(float*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushnumber(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetViewOffset(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzurePosition3DPanel",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzurePosition3DPanel must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FVector2D ReturnValue;
	} Params;
#if UE_GAME
	UAzurePosition3DPanel * This = (UAzurePosition3DPanel *)Obj;
	Params.ReturnValue = This->GetViewOffset();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetViewOffset"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(FVector2D*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaVector2D::Return(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetPivot3D(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzurePosition3DPanel",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzurePosition3DPanel must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FVector2D ReturnValue;
	} Params;
#if UE_GAME
	UAzurePosition3DPanel * This = (UAzurePosition3DPanel *)Obj;
	Params.ReturnValue = This->GetPivot3D();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetPivot3D"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(FVector2D*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaVector2D::Return(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetOffset(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzurePosition3DPanel",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzurePosition3DPanel must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FVector ReturnValue;
	} Params;
#if UE_GAME
	UAzurePosition3DPanel * This = (UAzurePosition3DPanel *)Obj;
	Params.ReturnValue = This->GetOffset();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetOffset"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(FVector*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaVector::Return(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetInheritParentView(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzurePosition3DPanel",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzurePosition3DPanel must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool ReturnValue;
	} Params;
#if UE_GAME
	UAzurePosition3DPanel * This = (UAzurePosition3DPanel *)Obj;
	Params.ReturnValue = This->GetInheritParentView();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetInheritParentView"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushboolean(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetAngle3D(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzurePosition3DPanel",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzurePosition3DPanel must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FVector2D ReturnValue;
	} Params;
#if UE_GAME
	UAzurePosition3DPanel * This = (UAzurePosition3DPanel *)Obj;
	Params.ReturnValue = This->GetAngle3D();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetAngle3D"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(FVector2D*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaVector2D::Return(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 Get_Angle3D(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzurePosition3DPanel",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzurePosition3DPanel must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzurePosition3DPanel::StaticClass(), TEXT("Angle3D"));
	if(!Property) { check(false); return 0;}
	FVector2D PropertyValue = FVector2D();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaVector2D::Return(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_Offset(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzurePosition3DPanel",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzurePosition3DPanel must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzurePosition3DPanel::StaticClass(), TEXT("Offset"));
	if(!Property) { check(false); return 0;}
	FVector PropertyValue = FVector();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaVector::Return(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_Pivot3D(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzurePosition3DPanel",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzurePosition3DPanel must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzurePosition3DPanel::StaticClass(), TEXT("Pivot3D"));
	if(!Property) { check(false); return 0;}
	FVector2D PropertyValue = FVector2D();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaVector2D::Return(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_InheritParentView(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzurePosition3DPanel",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzurePosition3DPanel must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzurePosition3DPanel::StaticClass(), TEXT("InheritParentView"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = bool();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_ViewOffset(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzurePosition3DPanel",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzurePosition3DPanel must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzurePosition3DPanel::StaticClass(), TEXT("ViewOffset"));
	if(!Property) { check(false); return 0;}
	FVector2D PropertyValue = FVector2D();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaVector2D::Return(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_ZoomFactor(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzurePosition3DPanel",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzurePosition3DPanel must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzurePosition3DPanel::StaticClass(), TEXT("ZoomFactor"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_FeatherAmount(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzurePosition3DPanel",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzurePosition3DPanel must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzurePosition3DPanel::StaticClass(), TEXT("FeatherAmount"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 New(lua_State* InScriptContext)
{
	UObject* Outer = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Object");
	FName Name = FName(luaL_checkstring(InScriptContext, 2));
	UObject* Obj = NewObject<UAzurePosition3DPanel>(Outer, Name);
	wLua::FLuaUtils::ReturnUObject(InScriptContext,Obj);
	return 1;
}

int32 Destroy(lua_State* InScriptContext)
{
	return 0;
}

int32 Class(lua_State* InScriptContext)
{
	UClass* Class = UAzurePosition3DPanel::StaticClass();
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Class);
	return 1;
}

const luaL_Reg Lib_Funcs[] =
{
	{ "New", New },
	{ "Destroy", Destroy },
	{ "Class", Class },
	{ "SetZoomFactor", SetZoomFactor },
	{ "SetViewOffset", SetViewOffset },
	{ "SetPivot3D", SetPivot3D },
	{ "SetOffset", SetOffset },
	{ "SetInheritParentView", SetInheritParentView },
	{ "SetAngle3D", SetAngle3D },
	{ "GetZoomFactor", GetZoomFactor },
	{ "GetViewOffset", GetViewOffset },
	{ "GetPivot3D", GetPivot3D },
	{ "GetOffset", GetOffset },
	{ "GetInheritParentView", GetInheritParentView },
	{ "GetAngle3D", GetAngle3D },
	{ "Get_Angle3D", Get_Angle3D },
	{ "Get_Offset", Get_Offset },
	{ "Get_Pivot3D", Get_Pivot3D },
	{ "Get_InheritParentView", Get_InheritParentView },
	{ "Get_ViewOffset", Get_ViewOffset },
	{ "Get_ZoomFactor", Get_ZoomFactor },
	{ "Get_FeatherAmount", Get_FeatherAmount },
	{ "is_nil", wLua::LuaStatic::isnil },
	{ "__gc", wLua::LuaStatic::removeUClassFrameCache },
	{ NULL, NULL }
};

void Register(lua_State *InScriptContext)
{
	lua_newtable(InScriptContext);
	luaL_register(InScriptContext, NULL, Lib_Funcs);
	AzureHelpFuncs::AuxRegister(InScriptContext, "AzurePosition3DPanel");
}
void SetMtLink(lua_State *InScriptContext)
{
	AzureHelpFuncs::AuxSetMtLink(InScriptContext, "AzurePosition3DPanel", "ContentWidget",USERDATATYPE_UOBJECT);
}

}