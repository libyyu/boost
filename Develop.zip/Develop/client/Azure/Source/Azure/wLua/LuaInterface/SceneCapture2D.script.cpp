#include "Azure.h"
#include "Utility/help_funcs.h"
#include "wLua/UObjectHeaders.h"
#include "Engine/SceneCapture2D.h"
#include "AzureLuaIntegration.h"

namespace LuaSceneCapture2D
{
int32 OnInterpToggle(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SceneCapture2D",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SceneCapture2D must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool bEnable;
	} Params;
	Params.bEnable = !!(lua_toboolean(InScriptContext, 2));
#if UE_GAME
	ASceneCapture2D * This = (ASceneCapture2D *)Obj;
	This->OnInterpToggle(Params.bEnable);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("OnInterpToggle"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(bool*)(params.GetStructMemory() + 0) = Params.bEnable;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.bEnable = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 Get_CaptureComponent2D(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SceneCapture2D",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SceneCapture2D must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(ASceneCapture2D::StaticClass(), TEXT("CaptureComponent2D"));
	if(!Property) { check(false); return 0;}
	USceneCaptureComponent2D* PropertyValue;
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaUtils::ReturnUObject(InScriptContext, PropertyValue);
	return 1;
}

int32 New(lua_State* InScriptContext)
{
	UObject* Outer = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Object");
	FName Name = FName(luaL_checkstring(InScriptContext, 2));
	UObject* Obj = NewObject<ASceneCapture2D>(Outer, Name);
	wLua::FLuaUtils::ReturnUObject(InScriptContext,Obj);
	return 1;
}

int32 Destroy(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SceneCapture2D",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SceneCapture2D must be non-null"); lua_error(InScriptContext);  return 0;}
		AActor * actor = Cast<AActor>(Obj);
		actor->Destroy();
		userdata->flag |= wLua::LuaObjectFlag::DESTROYED;
		wLua::FLuaUtils::RemoveObjectReference(Obj, userdata->stamp, InScriptContext);
#ifdef AZURE_BUILD_WLUACHECK
		UE_LOG(LogAzure, Warning, TEXT("Destroy SceneCapture2D: %x userdata:%x   stamp:%x"),Obj,userdata,userdata->stamp);
#endif
	return 0;
}

int32 Class(lua_State* InScriptContext)
{
	UClass* Class = ASceneCapture2D::StaticClass();
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Class);
	return 1;
}

const luaL_Reg Lib_Funcs[] =
{
	{ "New", New },
	{ "Destroy", Destroy },
	{ "Class", Class },
	{ "OnInterpToggle", OnInterpToggle },
	{ "Get_CaptureComponent2D", Get_CaptureComponent2D },
	{ "is_nil", wLua::LuaStatic::isnil },
	{ "__gc", wLua::LuaStatic::removeUClassFrameCache },
	{ NULL, NULL }
};

void Register(lua_State *InScriptContext)
{
	lua_newtable(InScriptContext);
	luaL_register(InScriptContext, NULL, Lib_Funcs);
	AzureHelpFuncs::AuxRegister(InScriptContext, "SceneCapture2D");
}
void SetMtLink(lua_State *InScriptContext)
{
	AzureHelpFuncs::AuxSetMtLink(InScriptContext, "SceneCapture2D", "Actor",USERDATATYPE_UOBJECT);
}

}