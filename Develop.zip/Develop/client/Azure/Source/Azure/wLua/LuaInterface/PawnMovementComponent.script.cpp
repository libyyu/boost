#include "Azure.h"
#include "Utility/help_funcs.h"
#include "wLua/UObjectHeaders.h"
#include "GameFramework/PawnMovementComponent.h"
#include "AzureLuaIntegration.h"

namespace LuaPawnMovementComponent
{
int32 IsMoveInputIgnored(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PawnMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PawnMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool ReturnValue;
	} Params;
#if UE_GAME
	UPawnMovementComponent * This = (UPawnMovementComponent *)Obj;
	Params.ReturnValue = This->IsMoveInputIgnored();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("IsMoveInputIgnored"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushboolean(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetPendingInputVector(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PawnMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PawnMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FVector ReturnValue;
	} Params;
#if UE_GAME
	UPawnMovementComponent * This = (UPawnMovementComponent *)Obj;
	Params.ReturnValue = This->GetPendingInputVector();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetPendingInputVector"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(FVector*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaVector::Return(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetPawnOwner(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PawnMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PawnMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		APawn* ReturnValue = nullptr;
	} Params;
#if UE_GAME
	UPawnMovementComponent * This = (UPawnMovementComponent *)Obj;
	Params.ReturnValue = This->GetPawnOwner();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetPawnOwner"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(APawn**)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetLastInputVector(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PawnMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PawnMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FVector ReturnValue;
	} Params;
#if UE_GAME
	UPawnMovementComponent * This = (UPawnMovementComponent *)Obj;
	Params.ReturnValue = This->GetLastInputVector();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetLastInputVector"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(FVector*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaVector::Return(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 ConsumeInputVector(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PawnMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PawnMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FVector ReturnValue;
	} Params;
#if UE_GAME
	UPawnMovementComponent * This = (UPawnMovementComponent *)Obj;
	Params.ReturnValue = This->ConsumeInputVector();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("ConsumeInputVector"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(FVector*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaVector::Return(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 AddInputVector(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PawnMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PawnMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FVector WorldVector;
		bool bForce;
	} Params;
	Params.WorldVector = (wLua::FLuaVector::Get(InScriptContext, 2));
	Params.bForce = lua_isnoneornil(InScriptContext,3) ? bool(false) : !!(lua_toboolean(InScriptContext, 3));
#if UE_GAME
	UPawnMovementComponent * This = (UPawnMovementComponent *)Obj;
	This->AddInputVector(Params.WorldVector,Params.bForce);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("AddInputVector"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FVector*)(params.GetStructMemory() + 0) = Params.WorldVector;
		*(bool*)(params.GetStructMemory() + 12) = Params.bForce;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.WorldVector = *(FVector*)(params.GetStructMemory() + 0);
		Params.bForce = *(bool*)(params.GetStructMemory() + 12);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 Class(lua_State* InScriptContext)
{
	UClass* Class = UPawnMovementComponent::StaticClass();
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Class);
	return 1;
}

const luaL_Reg Lib_Funcs[] =
{
	{ "Class", Class },
	{ "IsMoveInputIgnored", IsMoveInputIgnored },
	{ "GetPendingInputVector", GetPendingInputVector },
	{ "GetPawnOwner", GetPawnOwner },
	{ "GetLastInputVector", GetLastInputVector },
	{ "ConsumeInputVector", ConsumeInputVector },
	{ "AddInputVector", AddInputVector },
	{ "is_nil", wLua::LuaStatic::isnil },
	{ "__gc", wLua::LuaStatic::removeUClassFrameCache },
	{ NULL, NULL }
};

void Register(lua_State *InScriptContext)
{
	lua_newtable(InScriptContext);
	luaL_register(InScriptContext, NULL, Lib_Funcs);
	AzureHelpFuncs::AuxRegister(InScriptContext, "PawnMovementComponent");
}
void SetMtLink(lua_State *InScriptContext)
{
	AzureHelpFuncs::AuxSetMtLink(InScriptContext, "PawnMovementComponent", "NavMovementComponent",USERDATATYPE_UOBJECT);
}

}