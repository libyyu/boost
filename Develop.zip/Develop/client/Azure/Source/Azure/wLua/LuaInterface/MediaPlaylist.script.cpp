#include "Azure.h"
#include "Utility/help_funcs.h"
#include "wLua/UObjectHeaders.h"
#include "MediaPlaylist.h"
#include "MediaSource.h"
#include "AzureLuaIntegration.h"

namespace LuaMediaPlaylist
{
int32 Replace(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MediaPlaylist",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MediaPlaylist must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		int32 Index;
		UMediaSource* Replacement = nullptr;
		bool ReturnValue;
	} Params;
	Params.Index = (luaL_checkint(InScriptContext, 2));
	Params.Replacement = (UMediaSource*)wLua::FLuaUtils::GetUObject(InScriptContext,3,"MediaSource");;
#if UE_GAME
	UMediaPlaylist * This = (UMediaPlaylist *)Obj;
	Params.ReturnValue = This->Replace(Params.Index,Params.Replacement);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("Replace"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(int32*)(params.GetStructMemory() + 0) = Params.Index;
		*(UMediaSource**)(params.GetStructMemory() + 8) = Params.Replacement;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.Index = *(int32*)(params.GetStructMemory() + 0);
		Params.Replacement = *(UMediaSource**)(params.GetStructMemory() + 8);
		Params.ReturnValue = *(bool*)(params.GetStructMemory() + 16);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushboolean(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 RemoveAt(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MediaPlaylist",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MediaPlaylist must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		int32 Index;
		bool ReturnValue;
	} Params;
	Params.Index = (luaL_checkint(InScriptContext, 2));
#if UE_GAME
	UMediaPlaylist * This = (UMediaPlaylist *)Obj;
	Params.ReturnValue = This->RemoveAt(Params.Index);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("RemoveAt"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(int32*)(params.GetStructMemory() + 0) = Params.Index;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.Index = *(int32*)(params.GetStructMemory() + 0);
		Params.ReturnValue = *(bool*)(params.GetStructMemory() + 4);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushboolean(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 Remove(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MediaPlaylist",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MediaPlaylist must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		UMediaSource* MediaSource = nullptr;
		bool ReturnValue;
	} Params;
	Params.MediaSource = (UMediaSource*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"MediaSource");;
#if UE_GAME
	UMediaPlaylist * This = (UMediaPlaylist *)Obj;
	Params.ReturnValue = This->Remove(Params.MediaSource);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("Remove"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(UMediaSource**)(params.GetStructMemory() + 0) = Params.MediaSource;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.MediaSource = *(UMediaSource**)(params.GetStructMemory() + 0);
		Params.ReturnValue = *(bool*)(params.GetStructMemory() + 8);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushboolean(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 Num(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MediaPlaylist",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MediaPlaylist must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		int32 ReturnValue;
	} Params;
#if UE_GAME
	UMediaPlaylist * This = (UMediaPlaylist *)Obj;
	Params.ReturnValue = This->Num();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("Num"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(int32*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushinteger(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 Insert(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MediaPlaylist",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MediaPlaylist must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		UMediaSource* MediaSource = nullptr;
		int32 Index;
	} Params;
	Params.MediaSource = (UMediaSource*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"MediaSource");;
	Params.Index = (luaL_checkint(InScriptContext, 3));
#if UE_GAME
	UMediaPlaylist * This = (UMediaPlaylist *)Obj;
	This->Insert(Params.MediaSource,Params.Index);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("Insert"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(UMediaSource**)(params.GetStructMemory() + 0) = Params.MediaSource;
		*(int32*)(params.GetStructMemory() + 8) = Params.Index;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.MediaSource = *(UMediaSource**)(params.GetStructMemory() + 0);
		Params.Index = *(int32*)(params.GetStructMemory() + 8);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 GetRandom(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MediaPlaylist",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MediaPlaylist must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		int32 OutIndex;
		UMediaSource* ReturnValue = nullptr;
	} Params;
#if UE_GAME
	UMediaPlaylist * This = (UMediaPlaylist *)Obj;
	Params.ReturnValue = This->GetRandom(Params.OutIndex);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetRandom"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.OutIndex = *(int32*)(params.GetStructMemory() + 0);
		Params.ReturnValue = *(UMediaSource**)(params.GetStructMemory() + 8);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Params.ReturnValue);
	lua_pushinteger(InScriptContext, Params.OutIndex);
	return 2;
}

int32 GetPrevious(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MediaPlaylist",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MediaPlaylist must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		int32 InOutIndex;
		UMediaSource* ReturnValue = nullptr;
	} Params;
#if UE_GAME
	UMediaPlaylist * This = (UMediaPlaylist *)Obj;
	Params.ReturnValue = This->GetPrevious(Params.InOutIndex);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetPrevious"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.InOutIndex = *(int32*)(params.GetStructMemory() + 0);
		Params.ReturnValue = *(UMediaSource**)(params.GetStructMemory() + 8);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Params.ReturnValue);
	lua_pushinteger(InScriptContext, Params.InOutIndex);
	return 2;
}

int32 GetNext(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MediaPlaylist",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MediaPlaylist must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		int32 InOutIndex;
		UMediaSource* ReturnValue = nullptr;
	} Params;
#if UE_GAME
	UMediaPlaylist * This = (UMediaPlaylist *)Obj;
	Params.ReturnValue = This->GetNext(Params.InOutIndex);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetNext"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.InOutIndex = *(int32*)(params.GetStructMemory() + 0);
		Params.ReturnValue = *(UMediaSource**)(params.GetStructMemory() + 8);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Params.ReturnValue);
	lua_pushinteger(InScriptContext, Params.InOutIndex);
	return 2;
}

int32 Get(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MediaPlaylist",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MediaPlaylist must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		int32 Index;
		UMediaSource* ReturnValue = nullptr;
	} Params;
	Params.Index = (luaL_checkint(InScriptContext, 2));
#if UE_GAME
	UMediaPlaylist * This = (UMediaPlaylist *)Obj;
	Params.ReturnValue = This->Get(Params.Index);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("Get"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(int32*)(params.GetStructMemory() + 0) = Params.Index;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.Index = *(int32*)(params.GetStructMemory() + 0);
		Params.ReturnValue = *(UMediaSource**)(params.GetStructMemory() + 8);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 AddUrl(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MediaPlaylist",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MediaPlaylist must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FString Url;
		bool ReturnValue;
	} Params;
	Params.Url = UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 2));
#if UE_GAME
	UMediaPlaylist * This = (UMediaPlaylist *)Obj;
	Params.ReturnValue = This->AddUrl(Params.Url);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("AddUrl"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FString*)(params.GetStructMemory() + 0) = Params.Url;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.Url = *(FString*)(params.GetStructMemory() + 0);
		Params.ReturnValue = *(bool*)(params.GetStructMemory() + 16);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushboolean(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 AddFile(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MediaPlaylist",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MediaPlaylist must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FString FilePath;
		bool ReturnValue;
	} Params;
	Params.FilePath = UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 2));
#if UE_GAME
	UMediaPlaylist * This = (UMediaPlaylist *)Obj;
	Params.ReturnValue = This->AddFile(Params.FilePath);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("AddFile"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FString*)(params.GetStructMemory() + 0) = Params.FilePath;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.FilePath = *(FString*)(params.GetStructMemory() + 0);
		Params.ReturnValue = *(bool*)(params.GetStructMemory() + 16);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushboolean(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 Add(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MediaPlaylist",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MediaPlaylist must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		UMediaSource* MediaSource = nullptr;
		bool ReturnValue;
	} Params;
	Params.MediaSource = (UMediaSource*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"MediaSource");;
#if UE_GAME
	UMediaPlaylist * This = (UMediaPlaylist *)Obj;
	Params.ReturnValue = This->Add(Params.MediaSource);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("Add"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(UMediaSource**)(params.GetStructMemory() + 0) = Params.MediaSource;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.MediaSource = *(UMediaSource**)(params.GetStructMemory() + 0);
		Params.ReturnValue = *(bool*)(params.GetStructMemory() + 8);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushboolean(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 Get_Items(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MediaPlaylist",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MediaPlaylist must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UMediaPlaylist::StaticClass(), TEXT("Items"));
	if(!Property) { check(false); return 0;}
	TArray<UMediaSource*> PropertyValue;
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	{lua_newtable(InScriptContext); int i = 1; for(auto It = PropertyValue.CreateConstIterator(); It; ++It,++i) {  wLua::FLuaUtils::ReturnUObject(InScriptContext, (*It)); lua_rawseti(InScriptContext,-2,i);     }  }
	return 1;
}

int32 Set_Items(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MediaPlaylist",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MediaPlaylist must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UMediaPlaylist::StaticClass(), TEXT("Items"));
	if(!Property) { check(false); return 0;}
	TArray<UMediaSource*> PropertyValue = [](lua_State * _InScriptContext){ TArray<UMediaSource*> ret; lua_pushnil(_InScriptContext); while(lua_next(_InScriptContext,2)!=0){ UMediaSource* item = (UMediaSource*)wLua::FLuaUtils::GetUObject(_InScriptContext,-1,"MediaSource");; ret.Add(item); lua_pop(_InScriptContext,1);  } return ret; }(InScriptContext);;
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 New(lua_State* InScriptContext)
{
	UObject* Outer = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Object");
	FName Name = FName(luaL_checkstring(InScriptContext, 2));
	UObject* Obj = NewObject<UMediaPlaylist>(Outer, Name);
	wLua::FLuaUtils::ReturnUObject(InScriptContext,Obj);
	return 1;
}

int32 Destroy(lua_State* InScriptContext)
{
	return 0;
}

int32 Class(lua_State* InScriptContext)
{
	UClass* Class = UMediaPlaylist::StaticClass();
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Class);
	return 1;
}

const luaL_Reg Lib_Funcs[] =
{
	{ "New", New },
	{ "Destroy", Destroy },
	{ "Class", Class },
	{ "Replace", Replace },
	{ "RemoveAt", RemoveAt },
	{ "Remove", Remove },
	{ "Num", Num },
	{ "Insert", Insert },
	{ "GetRandom", GetRandom },
	{ "GetPrevious", GetPrevious },
	{ "GetNext", GetNext },
	{ "Get", Get },
	{ "AddUrl", AddUrl },
	{ "AddFile", AddFile },
	{ "Add", Add },
	{ "Get_Items", Get_Items },
	{ "Set_Items", Set_Items },
	{ "is_nil", wLua::LuaStatic::isnil },
	{ "__gc", wLua::LuaStatic::removeUClassFrameCache },
	{ NULL, NULL }
};

void Register(lua_State *InScriptContext)
{
	lua_newtable(InScriptContext);
	luaL_register(InScriptContext, NULL, Lib_Funcs);
	AzureHelpFuncs::AuxRegister(InScriptContext, "MediaPlaylist");
}
void SetMtLink(lua_State *InScriptContext)
{
	AzureHelpFuncs::AuxSetMtLink(InScriptContext, "MediaPlaylist", "Object",USERDATATYPE_UOBJECT);
}

}