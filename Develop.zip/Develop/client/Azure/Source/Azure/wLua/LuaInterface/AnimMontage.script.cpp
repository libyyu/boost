#include "Azure.h"
#include "Utility/help_funcs.h"
#include "wLua/UObjectHeaders.h"
#include "Animation/AnimMontage.h"
#include "AzureLuaIntegration.h"

namespace LuaAnimMontage
{
int32 HasRootMotion(lua_State*);
int32 GetPlayLength(lua_State*);
int32 GetNotifies(lua_State*);
int32 GetNotifyTimePoint(lua_State*);
int32 ExtractRootMotionFromTrackRange(lua_State*);
int32 GetSectionIndex(lua_State*);
int32 GetSectionLength(lua_State*);
int32 GetNumberOfFrames(lua_State*);
int32 GetSequenceLength(lua_State*);
int32 GetFrameRate(lua_State*);
int32 GetFrameAtTime(lua_State*);
int32 GetTimeAtFrame(lua_State*);
int32 GetSectionStartAndEndTime(lua_State*);
int32 ShouldDisableEvalRateOptimize(lua_State*);

int32 GetDefaultBlendOutTime(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AnimMontage",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AnimMontage must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float ReturnValue;
	} Params;
#if UE_GAME
	UAnimMontage * This = (UAnimMontage *)Obj;
	Params.ReturnValue = This->GetDefaultBlendOutTime();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetDefaultBlendOutTime"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(float*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushnumber(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 Get_BlendOutTriggerTime(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AnimMontage",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AnimMontage must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAnimMontage::StaticClass(), TEXT("BlendOutTriggerTime"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_BlendOutTriggerTime(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AnimMontage",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AnimMontage must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAnimMontage::StaticClass(), TEXT("BlendOutTriggerTime"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_SyncGroup(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AnimMontage",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AnimMontage must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAnimMontage::StaticClass(), TEXT("SyncGroup"));
	if(!Property) { check(false); return 0;}
	FName PropertyValue = FName();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushstring(InScriptContext, TCHAR_TO_UTF8(*PropertyValue.ToString()));
	return 1;
}

int32 Set_SyncGroup(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AnimMontage",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AnimMontage must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAnimMontage::StaticClass(), TEXT("SyncGroup"));
	if(!Property) { check(false); return 0;}
	FName PropertyValue = FName(UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 2)));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_SyncSlotIndex(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AnimMontage",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AnimMontage must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAnimMontage::StaticClass(), TEXT("SyncSlotIndex"));
	if(!Property) { check(false); return 0;}
	int32 PropertyValue = int32();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushinteger(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_SyncSlotIndex(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AnimMontage",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AnimMontage must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAnimMontage::StaticClass(), TEXT("SyncSlotIndex"));
	if(!Property) { check(false); return 0;}
	int32 PropertyValue = (luaL_checkint(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bEnableAutoBlendOut(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AnimMontage",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AnimMontage must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAnimMontage::StaticClass(), TEXT("bEnableAutoBlendOut"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = bool();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bEnableAutoBlendOut(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AnimMontage",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AnimMontage must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAnimMontage::StaticClass(), TEXT("bEnableAutoBlendOut"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_PreviewBasePose(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AnimMontage",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AnimMontage must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAnimMontage::StaticClass(), TEXT("PreviewBasePose"));
	if(!Property) { check(false); return 0;}
	UAnimSequence* PropertyValue;
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaUtils::ReturnUObject(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_PreviewBasePose(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AnimMontage",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AnimMontage must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAnimMontage::StaticClass(), TEXT("PreviewBasePose"));
	if(!Property) { check(false); return 0;}
	UAnimSequence* PropertyValue = (UAnimSequence*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"AnimSequence");;
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_TimeStretchCurveName(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AnimMontage",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AnimMontage must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAnimMontage::StaticClass(), TEXT("TimeStretchCurveName"));
	if(!Property) { check(false); return 0;}
	FName PropertyValue = FName();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushstring(InScriptContext, TCHAR_TO_UTF8(*PropertyValue.ToString()));
	return 1;
}

int32 Set_TimeStretchCurveName(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AnimMontage",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AnimMontage must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAnimMontage::StaticClass(), TEXT("TimeStretchCurveName"));
	if(!Property) { check(false); return 0;}
	FName PropertyValue = FName(UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 2)));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 New(lua_State* InScriptContext)
{
	UObject* Outer = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Object");
	FName Name = FName(luaL_checkstring(InScriptContext, 2));
	UObject* Obj = NewObject<UAnimMontage>(Outer, Name);
	wLua::FLuaUtils::ReturnUObject(InScriptContext,Obj);
	return 1;
}

int32 Destroy(lua_State* InScriptContext)
{
	return 0;
}

int32 Class(lua_State* InScriptContext)
{
	UClass* Class = UAnimMontage::StaticClass();
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Class);
	return 1;
}

const luaL_Reg Lib_Funcs[] =
{
	{ "New", New },
	{ "Destroy", Destroy },
	{ "Class", Class },
	{ "GetDefaultBlendOutTime", GetDefaultBlendOutTime },
	{ "Get_BlendOutTriggerTime", Get_BlendOutTriggerTime },
	{ "Set_BlendOutTriggerTime", Set_BlendOutTriggerTime },
	{ "Get_SyncGroup", Get_SyncGroup },
	{ "Set_SyncGroup", Set_SyncGroup },
	{ "Get_SyncSlotIndex", Get_SyncSlotIndex },
	{ "Set_SyncSlotIndex", Set_SyncSlotIndex },
	{ "Get_bEnableAutoBlendOut", Get_bEnableAutoBlendOut },
	{ "Set_bEnableAutoBlendOut", Set_bEnableAutoBlendOut },
	{ "Get_PreviewBasePose", Get_PreviewBasePose },
	{ "Set_PreviewBasePose", Set_PreviewBasePose },
	{ "Get_TimeStretchCurveName", Get_TimeStretchCurveName },
	{ "Set_TimeStretchCurveName", Set_TimeStretchCurveName },
	{ "HasRootMotion", HasRootMotion },
	{ "GetPlayLength", GetPlayLength },
	{ "GetNotifies", GetNotifies },
	{ "GetNotifyTimePoint", GetNotifyTimePoint },
	{ "ExtractRootMotionFromTrackRange", ExtractRootMotionFromTrackRange },
	{ "GetSectionIndex", GetSectionIndex },
	{ "GetSectionLength", GetSectionLength },
	{ "GetNumberOfFrames", GetNumberOfFrames },
	{ "GetSequenceLength", GetSequenceLength },
	{ "GetFrameRate", GetFrameRate },
	{ "GetFrameAtTime", GetFrameAtTime },
	{ "GetTimeAtFrame", GetTimeAtFrame },
	{ "GetSectionStartAndEndTime", GetSectionStartAndEndTime },
	{ "ShouldDisableEvalRateOptimize", ShouldDisableEvalRateOptimize },
	{ "is_nil", wLua::LuaStatic::isnil },
	{ "__gc", wLua::LuaStatic::removeUClassFrameCache },
	{ NULL, NULL }
};

void Register(lua_State *InScriptContext)
{
	lua_newtable(InScriptContext);
	luaL_register(InScriptContext, NULL, Lib_Funcs);
	AzureHelpFuncs::AuxRegister(InScriptContext, "AnimMontage");
}
void SetMtLink(lua_State *InScriptContext)
{
	AzureHelpFuncs::AuxSetMtLink(InScriptContext, "AnimMontage", "AnimSequenceBase",USERDATATYPE_UOBJECT);
}

}