#include "Azure.h"
#include "Utility/help_funcs.h"
#include "wLua/UObjectHeaders.h"
#include "Components/CapsuleComponent.h"
#include "AzureLuaIntegration.h"

namespace LuaCapsuleComponent
{
int32 SetCapsuleSize(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CapsuleComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CapsuleComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float InRadius;
		float InHalfHeight;
		bool bUpdateOverlaps;
	} Params;
	Params.InRadius = (float)(luaL_checknumber(InScriptContext, 2));
	Params.InHalfHeight = (float)(luaL_checknumber(InScriptContext, 3));
	Params.bUpdateOverlaps = lua_isnoneornil(InScriptContext,4) ? bool(true) : !!(lua_toboolean(InScriptContext, 4));
#if UE_GAME
	UCapsuleComponent * This = (UCapsuleComponent *)Obj;
	This->SetCapsuleSize(Params.InRadius,Params.InHalfHeight,Params.bUpdateOverlaps);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetCapsuleSize"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(float*)(params.GetStructMemory() + 0) = Params.InRadius;
		*(float*)(params.GetStructMemory() + 4) = Params.InHalfHeight;
		*(bool*)(params.GetStructMemory() + 8) = Params.bUpdateOverlaps;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.InRadius = *(float*)(params.GetStructMemory() + 0);
		Params.InHalfHeight = *(float*)(params.GetStructMemory() + 4);
		Params.bUpdateOverlaps = *(bool*)(params.GetStructMemory() + 8);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetCapsuleRadius(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CapsuleComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CapsuleComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float Radius;
		bool bUpdateOverlaps;
	} Params;
	Params.Radius = (float)(luaL_checknumber(InScriptContext, 2));
	Params.bUpdateOverlaps = lua_isnoneornil(InScriptContext,3) ? bool(true) : !!(lua_toboolean(InScriptContext, 3));
#if UE_GAME
	UCapsuleComponent * This = (UCapsuleComponent *)Obj;
	This->SetCapsuleRadius(Params.Radius,Params.bUpdateOverlaps);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetCapsuleRadius"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(float*)(params.GetStructMemory() + 0) = Params.Radius;
		*(bool*)(params.GetStructMemory() + 4) = Params.bUpdateOverlaps;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.Radius = *(float*)(params.GetStructMemory() + 0);
		Params.bUpdateOverlaps = *(bool*)(params.GetStructMemory() + 4);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetCapsuleHalfHeight(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CapsuleComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CapsuleComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float HalfHeight;
		bool bUpdateOverlaps;
	} Params;
	Params.HalfHeight = (float)(luaL_checknumber(InScriptContext, 2));
	Params.bUpdateOverlaps = lua_isnoneornil(InScriptContext,3) ? bool(true) : !!(lua_toboolean(InScriptContext, 3));
#if UE_GAME
	UCapsuleComponent * This = (UCapsuleComponent *)Obj;
	This->SetCapsuleHalfHeight(Params.HalfHeight,Params.bUpdateOverlaps);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetCapsuleHalfHeight"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(float*)(params.GetStructMemory() + 0) = Params.HalfHeight;
		*(bool*)(params.GetStructMemory() + 4) = Params.bUpdateOverlaps;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.HalfHeight = *(float*)(params.GetStructMemory() + 0);
		Params.bUpdateOverlaps = *(bool*)(params.GetStructMemory() + 4);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 GetUnscaledCapsuleSize_WithoutHemisphere(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CapsuleComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CapsuleComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float OutRadius;
		float OutHalfHeightWithoutHemisphere;
	} Params;
#if UE_GAME
	UCapsuleComponent * This = (UCapsuleComponent *)Obj;
	This->GetUnscaledCapsuleSize_WithoutHemisphere(Params.OutRadius,Params.OutHalfHeightWithoutHemisphere);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetUnscaledCapsuleSize_WithoutHemisphere"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.OutRadius = *(float*)(params.GetStructMemory() + 0);
		Params.OutHalfHeightWithoutHemisphere = *(float*)(params.GetStructMemory() + 4);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushnumber(InScriptContext, Params.OutRadius);
	lua_pushnumber(InScriptContext, Params.OutHalfHeightWithoutHemisphere);
	return 2;
}

int32 GetUnscaledCapsuleSize(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CapsuleComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CapsuleComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float OutRadius;
		float OutHalfHeight;
	} Params;
#if UE_GAME
	UCapsuleComponent * This = (UCapsuleComponent *)Obj;
	This->GetUnscaledCapsuleSize(Params.OutRadius,Params.OutHalfHeight);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetUnscaledCapsuleSize"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.OutRadius = *(float*)(params.GetStructMemory() + 0);
		Params.OutHalfHeight = *(float*)(params.GetStructMemory() + 4);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushnumber(InScriptContext, Params.OutRadius);
	lua_pushnumber(InScriptContext, Params.OutHalfHeight);
	return 2;
}

int32 GetUnscaledCapsuleRadius(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CapsuleComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CapsuleComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float ReturnValue;
	} Params;
#if UE_GAME
	UCapsuleComponent * This = (UCapsuleComponent *)Obj;
	Params.ReturnValue = This->GetUnscaledCapsuleRadius();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetUnscaledCapsuleRadius"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(float*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushnumber(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetUnscaledCapsuleHalfHeight_WithoutHemisphere(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CapsuleComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CapsuleComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float ReturnValue;
	} Params;
#if UE_GAME
	UCapsuleComponent * This = (UCapsuleComponent *)Obj;
	Params.ReturnValue = This->GetUnscaledCapsuleHalfHeight_WithoutHemisphere();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetUnscaledCapsuleHalfHeight_WithoutHemisphere"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(float*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushnumber(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetUnscaledCapsuleHalfHeight(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CapsuleComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CapsuleComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float ReturnValue;
	} Params;
#if UE_GAME
	UCapsuleComponent * This = (UCapsuleComponent *)Obj;
	Params.ReturnValue = This->GetUnscaledCapsuleHalfHeight();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetUnscaledCapsuleHalfHeight"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(float*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushnumber(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetShapeScale(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CapsuleComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CapsuleComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float ReturnValue;
	} Params;
#if UE_GAME
	UCapsuleComponent * This = (UCapsuleComponent *)Obj;
	Params.ReturnValue = This->GetShapeScale();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetShapeScale"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(float*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushnumber(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetScaledCapsuleSize_WithoutHemisphere(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CapsuleComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CapsuleComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float OutRadius;
		float OutHalfHeightWithoutHemisphere;
	} Params;
#if UE_GAME
	UCapsuleComponent * This = (UCapsuleComponent *)Obj;
	This->GetScaledCapsuleSize_WithoutHemisphere(Params.OutRadius,Params.OutHalfHeightWithoutHemisphere);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetScaledCapsuleSize_WithoutHemisphere"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.OutRadius = *(float*)(params.GetStructMemory() + 0);
		Params.OutHalfHeightWithoutHemisphere = *(float*)(params.GetStructMemory() + 4);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushnumber(InScriptContext, Params.OutRadius);
	lua_pushnumber(InScriptContext, Params.OutHalfHeightWithoutHemisphere);
	return 2;
}

int32 GetScaledCapsuleSize(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CapsuleComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CapsuleComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float OutRadius;
		float OutHalfHeight;
	} Params;
#if UE_GAME
	UCapsuleComponent * This = (UCapsuleComponent *)Obj;
	This->GetScaledCapsuleSize(Params.OutRadius,Params.OutHalfHeight);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetScaledCapsuleSize"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.OutRadius = *(float*)(params.GetStructMemory() + 0);
		Params.OutHalfHeight = *(float*)(params.GetStructMemory() + 4);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushnumber(InScriptContext, Params.OutRadius);
	lua_pushnumber(InScriptContext, Params.OutHalfHeight);
	return 2;
}

int32 GetScaledCapsuleRadius(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CapsuleComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CapsuleComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float ReturnValue;
	} Params;
#if UE_GAME
	UCapsuleComponent * This = (UCapsuleComponent *)Obj;
	Params.ReturnValue = This->GetScaledCapsuleRadius();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetScaledCapsuleRadius"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(float*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushnumber(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetScaledCapsuleHalfHeight_WithoutHemisphere(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CapsuleComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CapsuleComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float ReturnValue;
	} Params;
#if UE_GAME
	UCapsuleComponent * This = (UCapsuleComponent *)Obj;
	Params.ReturnValue = This->GetScaledCapsuleHalfHeight_WithoutHemisphere();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetScaledCapsuleHalfHeight_WithoutHemisphere"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(float*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushnumber(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetScaledCapsuleHalfHeight(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CapsuleComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CapsuleComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float ReturnValue;
	} Params;
#if UE_GAME
	UCapsuleComponent * This = (UCapsuleComponent *)Obj;
	Params.ReturnValue = This->GetScaledCapsuleHalfHeight();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetScaledCapsuleHalfHeight"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(float*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushnumber(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 Get_CapsuleHalfHeight(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CapsuleComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CapsuleComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UCapsuleComponent::StaticClass(), TEXT("CapsuleHalfHeight"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_CapsuleRadius(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CapsuleComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CapsuleComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UCapsuleComponent::StaticClass(), TEXT("CapsuleRadius"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 New(lua_State* InScriptContext)
{
	UObject* Outer = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Object");
	FName Name = FName(luaL_checkstring(InScriptContext, 2));
	UObject* Obj = NewObject<UCapsuleComponent>(Outer, Name);
	wLua::FLuaUtils::ReturnUObject(InScriptContext,Obj);
	return 1;
}

int32 Destroy(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CapsuleComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CapsuleComponent must be non-null"); lua_error(InScriptContext);  return 0;}
		UActorComponent * com = Cast<UActorComponent>(Obj);
		if(lua_isnoneornil(InScriptContext,2))
			com->DestroyComponent();
		else
			com->DestroyComponent(!!lua_toboolean(InScriptContext,2));
		userdata->flag |= wLua::LuaObjectFlag::DESTROYED;
		wLua::FLuaUtils::RemoveObjectReference(Obj, userdata->stamp, InScriptContext);
#ifdef AZURE_BUILD_WLUACHECK
		UE_LOG(LogAzure, Warning, TEXT("Destroy CapsuleComponent: %x userdata:%x   stamp:%x"),Obj,userdata,userdata->stamp);
#endif
	return 0;
}

int32 Class(lua_State* InScriptContext)
{
	UClass* Class = UCapsuleComponent::StaticClass();
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Class);
	return 1;
}

const luaL_Reg Lib_Funcs[] =
{
	{ "New", New },
	{ "Destroy", Destroy },
	{ "Class", Class },
	{ "SetCapsuleSize", SetCapsuleSize },
	{ "SetCapsuleRadius", SetCapsuleRadius },
	{ "SetCapsuleHalfHeight", SetCapsuleHalfHeight },
	{ "GetUnscaledCapsuleSize_WithoutHemisphere", GetUnscaledCapsuleSize_WithoutHemisphere },
	{ "GetUnscaledCapsuleSize", GetUnscaledCapsuleSize },
	{ "GetUnscaledCapsuleRadius", GetUnscaledCapsuleRadius },
	{ "GetUnscaledCapsuleHalfHeight_WithoutHemisphere", GetUnscaledCapsuleHalfHeight_WithoutHemisphere },
	{ "GetUnscaledCapsuleHalfHeight", GetUnscaledCapsuleHalfHeight },
	{ "GetShapeScale", GetShapeScale },
	{ "GetScaledCapsuleSize_WithoutHemisphere", GetScaledCapsuleSize_WithoutHemisphere },
	{ "GetScaledCapsuleSize", GetScaledCapsuleSize },
	{ "GetScaledCapsuleRadius", GetScaledCapsuleRadius },
	{ "GetScaledCapsuleHalfHeight_WithoutHemisphere", GetScaledCapsuleHalfHeight_WithoutHemisphere },
	{ "GetScaledCapsuleHalfHeight", GetScaledCapsuleHalfHeight },
	{ "Get_CapsuleHalfHeight", Get_CapsuleHalfHeight },
	{ "Get_CapsuleRadius", Get_CapsuleRadius },
	{ "is_nil", wLua::LuaStatic::isnil },
	{ "__gc", wLua::LuaStatic::removeUClassFrameCache },
	{ NULL, NULL }
};

void Register(lua_State *InScriptContext)
{
	lua_newtable(InScriptContext);
	luaL_register(InScriptContext, NULL, Lib_Funcs);
	AzureHelpFuncs::AuxRegister(InScriptContext, "CapsuleComponent");
}
void SetMtLink(lua_State *InScriptContext)
{
	AzureHelpFuncs::AuxSetMtLink(InScriptContext, "CapsuleComponent", "ShapeComponent",USERDATATYPE_UOBJECT);
}

}