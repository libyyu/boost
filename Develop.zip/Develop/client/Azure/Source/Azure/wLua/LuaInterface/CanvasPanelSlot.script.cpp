#include "Azure.h"
#include "Utility/help_funcs.h"
#include "wLua/UObjectHeaders.h"
#include "Components/CanvasPanelSlot.h"
#include "AzureLuaIntegration.h"

namespace LuaCanvasPanelSlot
{
int32 SetZOrder(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CanvasPanelSlot",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CanvasPanelSlot must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		int32 InZOrder;
	} Params;
	Params.InZOrder = (luaL_checkint(InScriptContext, 2));
#if UE_GAME
	UCanvasPanelSlot * This = (UCanvasPanelSlot *)Obj;
	This->SetZOrder(Params.InZOrder);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetZOrder"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(int32*)(params.GetStructMemory() + 0) = Params.InZOrder;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.InZOrder = *(int32*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetSize(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CanvasPanelSlot",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CanvasPanelSlot must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FVector2D InSize;
	} Params;
	Params.InSize = (wLua::FLuaVector2D::Get(InScriptContext, 2));
#if UE_GAME
	UCanvasPanelSlot * This = (UCanvasPanelSlot *)Obj;
	This->SetSize(Params.InSize);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetSize"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FVector2D*)(params.GetStructMemory() + 0) = Params.InSize;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.InSize = *(FVector2D*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetPosition(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CanvasPanelSlot",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CanvasPanelSlot must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FVector2D InPosition;
	} Params;
	Params.InPosition = (wLua::FLuaVector2D::Get(InScriptContext, 2));
#if UE_GAME
	UCanvasPanelSlot * This = (UCanvasPanelSlot *)Obj;
	This->SetPosition(Params.InPosition);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetPosition"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FVector2D*)(params.GetStructMemory() + 0) = Params.InPosition;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.InPosition = *(FVector2D*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetMinimum(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CanvasPanelSlot",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CanvasPanelSlot must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FVector2D InMinimumAnchors;
	} Params;
	Params.InMinimumAnchors = (wLua::FLuaVector2D::Get(InScriptContext, 2));
#if UE_GAME
	UCanvasPanelSlot * This = (UCanvasPanelSlot *)Obj;
	This->SetMinimum(Params.InMinimumAnchors);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetMinimum"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FVector2D*)(params.GetStructMemory() + 0) = Params.InMinimumAnchors;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.InMinimumAnchors = *(FVector2D*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetMaximum(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CanvasPanelSlot",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CanvasPanelSlot must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FVector2D InMaximumAnchors;
	} Params;
	Params.InMaximumAnchors = (wLua::FLuaVector2D::Get(InScriptContext, 2));
#if UE_GAME
	UCanvasPanelSlot * This = (UCanvasPanelSlot *)Obj;
	This->SetMaximum(Params.InMaximumAnchors);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetMaximum"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FVector2D*)(params.GetStructMemory() + 0) = Params.InMaximumAnchors;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.InMaximumAnchors = *(FVector2D*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetAutoSize(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CanvasPanelSlot",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CanvasPanelSlot must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool InbAutoSize;
	} Params;
	Params.InbAutoSize = !!(lua_toboolean(InScriptContext, 2));
#if UE_GAME
	UCanvasPanelSlot * This = (UCanvasPanelSlot *)Obj;
	This->SetAutoSize(Params.InbAutoSize);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetAutoSize"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(bool*)(params.GetStructMemory() + 0) = Params.InbAutoSize;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.InbAutoSize = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetAnchors(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CanvasPanelSlot",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CanvasPanelSlot must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FAnchors InAnchors;
	} Params;
	Params.InAnchors = (wLua::FLuaAnchors::Get(InScriptContext, 2));
#if UE_GAME
	UCanvasPanelSlot * This = (UCanvasPanelSlot *)Obj;
	This->SetAnchors(Params.InAnchors);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetAnchors"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FAnchors*)(params.GetStructMemory() + 0) = Params.InAnchors;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.InAnchors = *(FAnchors*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetAlignment(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CanvasPanelSlot",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CanvasPanelSlot must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FVector2D InAlignment;
	} Params;
	Params.InAlignment = (wLua::FLuaVector2D::Get(InScriptContext, 2));
#if UE_GAME
	UCanvasPanelSlot * This = (UCanvasPanelSlot *)Obj;
	This->SetAlignment(Params.InAlignment);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetAlignment"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FVector2D*)(params.GetStructMemory() + 0) = Params.InAlignment;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.InAlignment = *(FVector2D*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 GetZOrder(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CanvasPanelSlot",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CanvasPanelSlot must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		int32 ReturnValue;
	} Params;
#if UE_GAME
	UCanvasPanelSlot * This = (UCanvasPanelSlot *)Obj;
	Params.ReturnValue = This->GetZOrder();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetZOrder"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(int32*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushinteger(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetSize(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CanvasPanelSlot",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CanvasPanelSlot must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FVector2D ReturnValue;
	} Params;
#if UE_GAME
	UCanvasPanelSlot * This = (UCanvasPanelSlot *)Obj;
	Params.ReturnValue = This->GetSize();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetSize"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(FVector2D*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaVector2D::Return(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetPosition(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CanvasPanelSlot",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CanvasPanelSlot must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FVector2D ReturnValue;
	} Params;
#if UE_GAME
	UCanvasPanelSlot * This = (UCanvasPanelSlot *)Obj;
	Params.ReturnValue = This->GetPosition();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetPosition"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(FVector2D*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaVector2D::Return(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetAutoSize(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CanvasPanelSlot",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CanvasPanelSlot must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool ReturnValue;
	} Params;
#if UE_GAME
	UCanvasPanelSlot * This = (UCanvasPanelSlot *)Obj;
	Params.ReturnValue = This->GetAutoSize();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetAutoSize"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushboolean(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetAnchors(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CanvasPanelSlot",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CanvasPanelSlot must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FAnchors ReturnValue;
	} Params;
#if UE_GAME
	UCanvasPanelSlot * This = (UCanvasPanelSlot *)Obj;
	Params.ReturnValue = This->GetAnchors();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetAnchors"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(FAnchors*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaAnchors::Return(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetAlignment(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CanvasPanelSlot",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CanvasPanelSlot must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FVector2D ReturnValue;
	} Params;
#if UE_GAME
	UCanvasPanelSlot * This = (UCanvasPanelSlot *)Obj;
	Params.ReturnValue = This->GetAlignment();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetAlignment"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(FVector2D*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaVector2D::Return(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 Get_bAutoSize(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CanvasPanelSlot",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CanvasPanelSlot must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UCanvasPanelSlot::StaticClass(), TEXT("bAutoSize"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = bool();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_ZOrder(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CanvasPanelSlot",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CanvasPanelSlot must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UCanvasPanelSlot::StaticClass(), TEXT("ZOrder"));
	if(!Property) { check(false); return 0;}
	int32 PropertyValue = int32();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushinteger(InScriptContext, PropertyValue);
	return 1;
}

int32 New(lua_State* InScriptContext)
{
	UObject* Outer = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Object");
	FName Name = FName(luaL_checkstring(InScriptContext, 2));
	UObject* Obj = NewObject<UCanvasPanelSlot>(Outer, Name);
	wLua::FLuaUtils::ReturnUObject(InScriptContext,Obj);
	return 1;
}

int32 Destroy(lua_State* InScriptContext)
{
	return 0;
}

int32 Class(lua_State* InScriptContext)
{
	UClass* Class = UCanvasPanelSlot::StaticClass();
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Class);
	return 1;
}

const luaL_Reg Lib_Funcs[] =
{
	{ "New", New },
	{ "Destroy", Destroy },
	{ "Class", Class },
	{ "SetZOrder", SetZOrder },
	{ "SetSize", SetSize },
	{ "SetPosition", SetPosition },
	{ "SetMinimum", SetMinimum },
	{ "SetMaximum", SetMaximum },
	{ "SetAutoSize", SetAutoSize },
	{ "SetAnchors", SetAnchors },
	{ "SetAlignment", SetAlignment },
	{ "GetZOrder", GetZOrder },
	{ "GetSize", GetSize },
	{ "GetPosition", GetPosition },
	{ "GetAutoSize", GetAutoSize },
	{ "GetAnchors", GetAnchors },
	{ "GetAlignment", GetAlignment },
	{ "Get_bAutoSize", Get_bAutoSize },
	{ "Get_ZOrder", Get_ZOrder },
	{ "is_nil", wLua::LuaStatic::isnil },
	{ "__gc", wLua::LuaStatic::removeUClassFrameCache },
	{ NULL, NULL }
};

void Register(lua_State *InScriptContext)
{
	lua_newtable(InScriptContext);
	luaL_register(InScriptContext, NULL, Lib_Funcs);
	AzureHelpFuncs::AuxRegister(InScriptContext, "CanvasPanelSlot");
}
void SetMtLink(lua_State *InScriptContext)
{
	AzureHelpFuncs::AuxSetMtLink(InScriptContext, "CanvasPanelSlot", "PanelSlot",USERDATATYPE_UOBJECT);
}

}