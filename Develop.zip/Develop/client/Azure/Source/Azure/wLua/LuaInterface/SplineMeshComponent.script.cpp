#include "Azure.h"
#include "Utility/help_funcs.h"
#include "wLua/UObjectHeaders.h"
#include "Components/SplineMeshComponent.h"
#include "AzureLuaIntegration.h"

namespace LuaSplineMeshComponent
{
int32 UpdateMesh(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SplineMeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SplineMeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
#if UE_GAME
	USplineMeshComponent * This = (USplineMeshComponent *)Obj;
	This->UpdateMesh();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("UpdateMesh"));
	if(!Function) { check(false); return 0;}
	Obj->ProcessEvent(Function, NULL);
#endif
	return 0;
}

int32 SetStartTangent(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SplineMeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SplineMeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FVector StartTangent;
		bool bUpdateMesh;
	} Params;
	Params.StartTangent = (wLua::FLuaVector::Get(InScriptContext, 2));
	Params.bUpdateMesh = lua_isnoneornil(InScriptContext,3) ? bool(true) : !!(lua_toboolean(InScriptContext, 3));
#if UE_GAME
	USplineMeshComponent * This = (USplineMeshComponent *)Obj;
	This->SetStartTangent(Params.StartTangent,Params.bUpdateMesh);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetStartTangent"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FVector*)(params.GetStructMemory() + 0) = Params.StartTangent;
		*(bool*)(params.GetStructMemory() + 12) = Params.bUpdateMesh;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.StartTangent = *(FVector*)(params.GetStructMemory() + 0);
		Params.bUpdateMesh = *(bool*)(params.GetStructMemory() + 12);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetStartScale(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SplineMeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SplineMeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FVector2D StartScale;
		bool bUpdateMesh;
	} Params;
	if(lua_isnoneornil(InScriptContext,2))
	{
		Params.StartScale.X=1.000;
		Params.StartScale.Y=1.000;
	}
	else
		Params.StartScale = (wLua::FLuaVector2D::Get(InScriptContext, 2));
	Params.bUpdateMesh = lua_isnoneornil(InScriptContext,3) ? bool(true) : !!(lua_toboolean(InScriptContext, 3));
#if UE_GAME
	USplineMeshComponent * This = (USplineMeshComponent *)Obj;
	This->SetStartScale(Params.StartScale,Params.bUpdateMesh);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetStartScale"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FVector2D*)(params.GetStructMemory() + 0) = Params.StartScale;
		*(bool*)(params.GetStructMemory() + 8) = Params.bUpdateMesh;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.StartScale = *(FVector2D*)(params.GetStructMemory() + 0);
		Params.bUpdateMesh = *(bool*)(params.GetStructMemory() + 8);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetStartRoll(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SplineMeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SplineMeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float StartRoll;
		bool bUpdateMesh;
	} Params;
	Params.StartRoll = (float)(luaL_checknumber(InScriptContext, 2));
	Params.bUpdateMesh = lua_isnoneornil(InScriptContext,3) ? bool(true) : !!(lua_toboolean(InScriptContext, 3));
#if UE_GAME
	USplineMeshComponent * This = (USplineMeshComponent *)Obj;
	This->SetStartRoll(Params.StartRoll,Params.bUpdateMesh);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetStartRoll"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(float*)(params.GetStructMemory() + 0) = Params.StartRoll;
		*(bool*)(params.GetStructMemory() + 4) = Params.bUpdateMesh;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.StartRoll = *(float*)(params.GetStructMemory() + 0);
		Params.bUpdateMesh = *(bool*)(params.GetStructMemory() + 4);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetStartPosition(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SplineMeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SplineMeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FVector StartPos;
		bool bUpdateMesh;
	} Params;
	Params.StartPos = (wLua::FLuaVector::Get(InScriptContext, 2));
	Params.bUpdateMesh = lua_isnoneornil(InScriptContext,3) ? bool(true) : !!(lua_toboolean(InScriptContext, 3));
#if UE_GAME
	USplineMeshComponent * This = (USplineMeshComponent *)Obj;
	This->SetStartPosition(Params.StartPos,Params.bUpdateMesh);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetStartPosition"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FVector*)(params.GetStructMemory() + 0) = Params.StartPos;
		*(bool*)(params.GetStructMemory() + 12) = Params.bUpdateMesh;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.StartPos = *(FVector*)(params.GetStructMemory() + 0);
		Params.bUpdateMesh = *(bool*)(params.GetStructMemory() + 12);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetStartOffset(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SplineMeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SplineMeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FVector2D StartOffset;
		bool bUpdateMesh;
	} Params;
	Params.StartOffset = (wLua::FLuaVector2D::Get(InScriptContext, 2));
	Params.bUpdateMesh = lua_isnoneornil(InScriptContext,3) ? bool(true) : !!(lua_toboolean(InScriptContext, 3));
#if UE_GAME
	USplineMeshComponent * This = (USplineMeshComponent *)Obj;
	This->SetStartOffset(Params.StartOffset,Params.bUpdateMesh);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetStartOffset"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FVector2D*)(params.GetStructMemory() + 0) = Params.StartOffset;
		*(bool*)(params.GetStructMemory() + 8) = Params.bUpdateMesh;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.StartOffset = *(FVector2D*)(params.GetStructMemory() + 0);
		Params.bUpdateMesh = *(bool*)(params.GetStructMemory() + 8);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetStartAndEnd(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SplineMeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SplineMeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FVector StartPos;
		FVector StartTangent;
		FVector EndPos;
		FVector EndTangent;
		bool bUpdateMesh;
	} Params;
	Params.StartPos = (wLua::FLuaVector::Get(InScriptContext, 2));
	Params.StartTangent = (wLua::FLuaVector::Get(InScriptContext, 3));
	Params.EndPos = (wLua::FLuaVector::Get(InScriptContext, 4));
	Params.EndTangent = (wLua::FLuaVector::Get(InScriptContext, 5));
	Params.bUpdateMesh = lua_isnoneornil(InScriptContext,6) ? bool(true) : !!(lua_toboolean(InScriptContext, 6));
#if UE_GAME
	USplineMeshComponent * This = (USplineMeshComponent *)Obj;
	This->SetStartAndEnd(Params.StartPos,Params.StartTangent,Params.EndPos,Params.EndTangent,Params.bUpdateMesh);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetStartAndEnd"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FVector*)(params.GetStructMemory() + 0) = Params.StartPos;
		*(FVector*)(params.GetStructMemory() + 12) = Params.StartTangent;
		*(FVector*)(params.GetStructMemory() + 24) = Params.EndPos;
		*(FVector*)(params.GetStructMemory() + 36) = Params.EndTangent;
		*(bool*)(params.GetStructMemory() + 48) = Params.bUpdateMesh;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.StartPos = *(FVector*)(params.GetStructMemory() + 0);
		Params.StartTangent = *(FVector*)(params.GetStructMemory() + 12);
		Params.EndPos = *(FVector*)(params.GetStructMemory() + 24);
		Params.EndTangent = *(FVector*)(params.GetStructMemory() + 36);
		Params.bUpdateMesh = *(bool*)(params.GetStructMemory() + 48);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetSplineUpDir(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SplineMeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SplineMeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FVector InSplineUpDir;
		bool bUpdateMesh;
	} Params;
	Params.InSplineUpDir = (wLua::FLuaVector::Get(InScriptContext, 2));
	Params.bUpdateMesh = lua_isnoneornil(InScriptContext,3) ? bool(true) : !!(lua_toboolean(InScriptContext, 3));
#if UE_GAME
	USplineMeshComponent * This = (USplineMeshComponent *)Obj;
	This->SetSplineUpDir(Params.InSplineUpDir,Params.bUpdateMesh);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetSplineUpDir"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FVector*)(params.GetStructMemory() + 0) = Params.InSplineUpDir;
		*(bool*)(params.GetStructMemory() + 12) = Params.bUpdateMesh;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.InSplineUpDir = *(FVector*)(params.GetStructMemory() + 0);
		Params.bUpdateMesh = *(bool*)(params.GetStructMemory() + 12);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetForwardAxis(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SplineMeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SplineMeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		TEnumAsByte<ESplineMeshAxis::Type> InForwardAxis;
		bool bUpdateMesh;
	} Params;
	Params.InForwardAxis = (TEnumAsByte<ESplineMeshAxis::Type>)(luaL_checkint(InScriptContext, 2));
	Params.bUpdateMesh = lua_isnoneornil(InScriptContext,3) ? bool(true) : !!(lua_toboolean(InScriptContext, 3));
#if UE_GAME
	USplineMeshComponent * This = (USplineMeshComponent *)Obj;
	This->SetForwardAxis(Params.InForwardAxis,Params.bUpdateMesh);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetForwardAxis"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(TEnumAsByte<ESplineMeshAxis::Type>*)(params.GetStructMemory() + 0) = Params.InForwardAxis;
		*(bool*)(params.GetStructMemory() + 1) = Params.bUpdateMesh;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.InForwardAxis = *(TEnumAsByte<ESplineMeshAxis::Type>*)(params.GetStructMemory() + 0);
		Params.bUpdateMesh = *(bool*)(params.GetStructMemory() + 1);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetEndTangent(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SplineMeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SplineMeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FVector EndTangent;
		bool bUpdateMesh;
	} Params;
	Params.EndTangent = (wLua::FLuaVector::Get(InScriptContext, 2));
	Params.bUpdateMesh = lua_isnoneornil(InScriptContext,3) ? bool(true) : !!(lua_toboolean(InScriptContext, 3));
#if UE_GAME
	USplineMeshComponent * This = (USplineMeshComponent *)Obj;
	This->SetEndTangent(Params.EndTangent,Params.bUpdateMesh);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetEndTangent"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FVector*)(params.GetStructMemory() + 0) = Params.EndTangent;
		*(bool*)(params.GetStructMemory() + 12) = Params.bUpdateMesh;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.EndTangent = *(FVector*)(params.GetStructMemory() + 0);
		Params.bUpdateMesh = *(bool*)(params.GetStructMemory() + 12);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetEndScale(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SplineMeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SplineMeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FVector2D EndScale;
		bool bUpdateMesh;
	} Params;
	if(lua_isnoneornil(InScriptContext,2))
	{
		Params.EndScale.X=1.000;
		Params.EndScale.Y=1.000;
	}
	else
		Params.EndScale = (wLua::FLuaVector2D::Get(InScriptContext, 2));
	Params.bUpdateMesh = lua_isnoneornil(InScriptContext,3) ? bool(true) : !!(lua_toboolean(InScriptContext, 3));
#if UE_GAME
	USplineMeshComponent * This = (USplineMeshComponent *)Obj;
	This->SetEndScale(Params.EndScale,Params.bUpdateMesh);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetEndScale"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FVector2D*)(params.GetStructMemory() + 0) = Params.EndScale;
		*(bool*)(params.GetStructMemory() + 8) = Params.bUpdateMesh;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.EndScale = *(FVector2D*)(params.GetStructMemory() + 0);
		Params.bUpdateMesh = *(bool*)(params.GetStructMemory() + 8);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetEndRoll(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SplineMeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SplineMeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float EndRoll;
		bool bUpdateMesh;
	} Params;
	Params.EndRoll = (float)(luaL_checknumber(InScriptContext, 2));
	Params.bUpdateMesh = lua_isnoneornil(InScriptContext,3) ? bool(true) : !!(lua_toboolean(InScriptContext, 3));
#if UE_GAME
	USplineMeshComponent * This = (USplineMeshComponent *)Obj;
	This->SetEndRoll(Params.EndRoll,Params.bUpdateMesh);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetEndRoll"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(float*)(params.GetStructMemory() + 0) = Params.EndRoll;
		*(bool*)(params.GetStructMemory() + 4) = Params.bUpdateMesh;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.EndRoll = *(float*)(params.GetStructMemory() + 0);
		Params.bUpdateMesh = *(bool*)(params.GetStructMemory() + 4);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetEndPosition(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SplineMeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SplineMeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FVector EndPos;
		bool bUpdateMesh;
	} Params;
	Params.EndPos = (wLua::FLuaVector::Get(InScriptContext, 2));
	Params.bUpdateMesh = lua_isnoneornil(InScriptContext,3) ? bool(true) : !!(lua_toboolean(InScriptContext, 3));
#if UE_GAME
	USplineMeshComponent * This = (USplineMeshComponent *)Obj;
	This->SetEndPosition(Params.EndPos,Params.bUpdateMesh);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetEndPosition"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FVector*)(params.GetStructMemory() + 0) = Params.EndPos;
		*(bool*)(params.GetStructMemory() + 12) = Params.bUpdateMesh;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.EndPos = *(FVector*)(params.GetStructMemory() + 0);
		Params.bUpdateMesh = *(bool*)(params.GetStructMemory() + 12);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetEndOffset(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SplineMeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SplineMeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FVector2D EndOffset;
		bool bUpdateMesh;
	} Params;
	Params.EndOffset = (wLua::FLuaVector2D::Get(InScriptContext, 2));
	Params.bUpdateMesh = lua_isnoneornil(InScriptContext,3) ? bool(true) : !!(lua_toboolean(InScriptContext, 3));
#if UE_GAME
	USplineMeshComponent * This = (USplineMeshComponent *)Obj;
	This->SetEndOffset(Params.EndOffset,Params.bUpdateMesh);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetEndOffset"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FVector2D*)(params.GetStructMemory() + 0) = Params.EndOffset;
		*(bool*)(params.GetStructMemory() + 8) = Params.bUpdateMesh;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.EndOffset = *(FVector2D*)(params.GetStructMemory() + 0);
		Params.bUpdateMesh = *(bool*)(params.GetStructMemory() + 8);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetBoundaryMin(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SplineMeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SplineMeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float InBoundaryMin;
		bool bUpdateMesh;
	} Params;
	Params.InBoundaryMin = (float)(luaL_checknumber(InScriptContext, 2));
	Params.bUpdateMesh = lua_isnoneornil(InScriptContext,3) ? bool(true) : !!(lua_toboolean(InScriptContext, 3));
#if UE_GAME
	USplineMeshComponent * This = (USplineMeshComponent *)Obj;
	This->SetBoundaryMin(Params.InBoundaryMin,Params.bUpdateMesh);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetBoundaryMin"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(float*)(params.GetStructMemory() + 0) = Params.InBoundaryMin;
		*(bool*)(params.GetStructMemory() + 4) = Params.bUpdateMesh;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.InBoundaryMin = *(float*)(params.GetStructMemory() + 0);
		Params.bUpdateMesh = *(bool*)(params.GetStructMemory() + 4);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetBoundaryMax(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SplineMeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SplineMeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float InBoundaryMax;
		bool bUpdateMesh;
	} Params;
	Params.InBoundaryMax = (float)(luaL_checknumber(InScriptContext, 2));
	Params.bUpdateMesh = lua_isnoneornil(InScriptContext,3) ? bool(true) : !!(lua_toboolean(InScriptContext, 3));
#if UE_GAME
	USplineMeshComponent * This = (USplineMeshComponent *)Obj;
	This->SetBoundaryMax(Params.InBoundaryMax,Params.bUpdateMesh);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetBoundaryMax"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(float*)(params.GetStructMemory() + 0) = Params.InBoundaryMax;
		*(bool*)(params.GetStructMemory() + 4) = Params.bUpdateMesh;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.InBoundaryMax = *(float*)(params.GetStructMemory() + 0);
		Params.bUpdateMesh = *(bool*)(params.GetStructMemory() + 4);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 GetStartTangent(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SplineMeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SplineMeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FVector ReturnValue;
	} Params;
#if UE_GAME
	USplineMeshComponent * This = (USplineMeshComponent *)Obj;
	Params.ReturnValue = This->GetStartTangent();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetStartTangent"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(FVector*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaVector::Return(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetStartScale(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SplineMeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SplineMeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FVector2D ReturnValue;
	} Params;
#if UE_GAME
	USplineMeshComponent * This = (USplineMeshComponent *)Obj;
	Params.ReturnValue = This->GetStartScale();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetStartScale"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(FVector2D*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaVector2D::Return(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetStartRoll(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SplineMeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SplineMeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float ReturnValue;
	} Params;
#if UE_GAME
	USplineMeshComponent * This = (USplineMeshComponent *)Obj;
	Params.ReturnValue = This->GetStartRoll();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetStartRoll"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(float*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushnumber(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetStartPosition(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SplineMeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SplineMeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FVector ReturnValue;
	} Params;
#if UE_GAME
	USplineMeshComponent * This = (USplineMeshComponent *)Obj;
	Params.ReturnValue = This->GetStartPosition();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetStartPosition"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(FVector*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaVector::Return(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetStartOffset(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SplineMeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SplineMeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FVector2D ReturnValue;
	} Params;
#if UE_GAME
	USplineMeshComponent * This = (USplineMeshComponent *)Obj;
	Params.ReturnValue = This->GetStartOffset();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetStartOffset"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(FVector2D*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaVector2D::Return(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetSplineUpDir(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SplineMeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SplineMeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FVector ReturnValue;
	} Params;
#if UE_GAME
	USplineMeshComponent * This = (USplineMeshComponent *)Obj;
	Params.ReturnValue = This->GetSplineUpDir();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetSplineUpDir"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(FVector*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaVector::Return(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetForwardAxis(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SplineMeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SplineMeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		TEnumAsByte<ESplineMeshAxis::Type> ReturnValue;
	} Params;
#if UE_GAME
	USplineMeshComponent * This = (USplineMeshComponent *)Obj;
	Params.ReturnValue = This->GetForwardAxis();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetForwardAxis"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(TEnumAsByte<ESplineMeshAxis::Type>*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushinteger(InScriptContext, (int)Params.ReturnValue);
	return 1;
}

int32 GetEndTangent(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SplineMeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SplineMeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FVector ReturnValue;
	} Params;
#if UE_GAME
	USplineMeshComponent * This = (USplineMeshComponent *)Obj;
	Params.ReturnValue = This->GetEndTangent();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetEndTangent"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(FVector*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaVector::Return(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetEndScale(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SplineMeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SplineMeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FVector2D ReturnValue;
	} Params;
#if UE_GAME
	USplineMeshComponent * This = (USplineMeshComponent *)Obj;
	Params.ReturnValue = This->GetEndScale();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetEndScale"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(FVector2D*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaVector2D::Return(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetEndRoll(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SplineMeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SplineMeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float ReturnValue;
	} Params;
#if UE_GAME
	USplineMeshComponent * This = (USplineMeshComponent *)Obj;
	Params.ReturnValue = This->GetEndRoll();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetEndRoll"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(float*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushnumber(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetEndPosition(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SplineMeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SplineMeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FVector ReturnValue;
	} Params;
#if UE_GAME
	USplineMeshComponent * This = (USplineMeshComponent *)Obj;
	Params.ReturnValue = This->GetEndPosition();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetEndPosition"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(FVector*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaVector::Return(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetEndOffset(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SplineMeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SplineMeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FVector2D ReturnValue;
	} Params;
#if UE_GAME
	USplineMeshComponent * This = (USplineMeshComponent *)Obj;
	Params.ReturnValue = This->GetEndOffset();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetEndOffset"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(FVector2D*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaVector2D::Return(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetBoundaryMin(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SplineMeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SplineMeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float ReturnValue;
	} Params;
#if UE_GAME
	USplineMeshComponent * This = (USplineMeshComponent *)Obj;
	Params.ReturnValue = This->GetBoundaryMin();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetBoundaryMin"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(float*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushnumber(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetBoundaryMax(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SplineMeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SplineMeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float ReturnValue;
	} Params;
#if UE_GAME
	USplineMeshComponent * This = (USplineMeshComponent *)Obj;
	Params.ReturnValue = This->GetBoundaryMax();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetBoundaryMax"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(float*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushnumber(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 Get_SplineUpDir(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SplineMeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SplineMeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USplineMeshComponent::StaticClass(), TEXT("SplineUpDir"));
	if(!Property) { check(false); return 0;}
	FVector PropertyValue = FVector();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaVector::Return(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_SplineUpDir(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SplineMeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SplineMeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USplineMeshComponent::StaticClass(), TEXT("SplineUpDir"));
	if(!Property) { check(false); return 0;}
	FVector PropertyValue = (wLua::FLuaVector::Get(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bAllowSplineEditingPerInstance(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SplineMeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SplineMeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USplineMeshComponent::StaticClass(), TEXT("bAllowSplineEditingPerInstance"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bAllowSplineEditingPerInstance(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SplineMeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SplineMeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USplineMeshComponent::StaticClass(), TEXT("bAllowSplineEditingPerInstance"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bSmoothInterpRollScale(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SplineMeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SplineMeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USplineMeshComponent::StaticClass(), TEXT("bSmoothInterpRollScale"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bSmoothInterpRollScale(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SplineMeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SplineMeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USplineMeshComponent::StaticClass(), TEXT("bSmoothInterpRollScale"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_ForwardAxis(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SplineMeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SplineMeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USplineMeshComponent::StaticClass(), TEXT("ForwardAxis"));
	if(!Property) { check(false); return 0;}
	TEnumAsByte<ESplineMeshAxis::Type> PropertyValue = TEnumAsByte<ESplineMeshAxis::Type>();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushinteger(InScriptContext, (int)PropertyValue);
	return 1;
}

int32 Set_ForwardAxis(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SplineMeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SplineMeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USplineMeshComponent::StaticClass(), TEXT("ForwardAxis"));
	if(!Property) { check(false); return 0;}
	TEnumAsByte<ESplineMeshAxis::Type> PropertyValue = (TEnumAsByte<ESplineMeshAxis::Type>)(luaL_checkint(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_SplineBoundaryMin(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SplineMeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SplineMeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USplineMeshComponent::StaticClass(), TEXT("SplineBoundaryMin"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_SplineBoundaryMin(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SplineMeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SplineMeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USplineMeshComponent::StaticClass(), TEXT("SplineBoundaryMin"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_SplineBoundaryMax(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SplineMeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SplineMeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USplineMeshComponent::StaticClass(), TEXT("SplineBoundaryMax"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_SplineBoundaryMax(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SplineMeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SplineMeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USplineMeshComponent::StaticClass(), TEXT("SplineBoundaryMax"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 New(lua_State* InScriptContext)
{
	UObject* Outer = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Object");
	FName Name = FName(luaL_checkstring(InScriptContext, 2));
	UObject* Obj = NewObject<USplineMeshComponent>(Outer, Name);
	wLua::FLuaUtils::ReturnUObject(InScriptContext,Obj);
	return 1;
}

int32 Destroy(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SplineMeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SplineMeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
		UActorComponent * com = Cast<UActorComponent>(Obj);
		if(lua_isnoneornil(InScriptContext,2))
			com->DestroyComponent();
		else
			com->DestroyComponent(!!lua_toboolean(InScriptContext,2));
		userdata->flag |= wLua::LuaObjectFlag::DESTROYED;
		wLua::FLuaUtils::RemoveObjectReference(Obj, userdata->stamp, InScriptContext);
#ifdef AZURE_BUILD_WLUACHECK
		UE_LOG(LogAzure, Warning, TEXT("Destroy SplineMeshComponent: %x userdata:%x   stamp:%x"),Obj,userdata,userdata->stamp);
#endif
	return 0;
}

int32 Class(lua_State* InScriptContext)
{
	UClass* Class = USplineMeshComponent::StaticClass();
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Class);
	return 1;
}

const luaL_Reg Lib_Funcs[] =
{
	{ "New", New },
	{ "Destroy", Destroy },
	{ "Class", Class },
	{ "UpdateMesh", UpdateMesh },
	{ "SetStartTangent", SetStartTangent },
	{ "SetStartScale", SetStartScale },
	{ "SetStartRoll", SetStartRoll },
	{ "SetStartPosition", SetStartPosition },
	{ "SetStartOffset", SetStartOffset },
	{ "SetStartAndEnd", SetStartAndEnd },
	{ "SetSplineUpDir", SetSplineUpDir },
	{ "SetForwardAxis", SetForwardAxis },
	{ "SetEndTangent", SetEndTangent },
	{ "SetEndScale", SetEndScale },
	{ "SetEndRoll", SetEndRoll },
	{ "SetEndPosition", SetEndPosition },
	{ "SetEndOffset", SetEndOffset },
	{ "SetBoundaryMin", SetBoundaryMin },
	{ "SetBoundaryMax", SetBoundaryMax },
	{ "GetStartTangent", GetStartTangent },
	{ "GetStartScale", GetStartScale },
	{ "GetStartRoll", GetStartRoll },
	{ "GetStartPosition", GetStartPosition },
	{ "GetStartOffset", GetStartOffset },
	{ "GetSplineUpDir", GetSplineUpDir },
	{ "GetForwardAxis", GetForwardAxis },
	{ "GetEndTangent", GetEndTangent },
	{ "GetEndScale", GetEndScale },
	{ "GetEndRoll", GetEndRoll },
	{ "GetEndPosition", GetEndPosition },
	{ "GetEndOffset", GetEndOffset },
	{ "GetBoundaryMin", GetBoundaryMin },
	{ "GetBoundaryMax", GetBoundaryMax },
	{ "Get_SplineUpDir", Get_SplineUpDir },
	{ "Set_SplineUpDir", Set_SplineUpDir },
	{ "Get_bAllowSplineEditingPerInstance", Get_bAllowSplineEditingPerInstance },
	{ "Set_bAllowSplineEditingPerInstance", Set_bAllowSplineEditingPerInstance },
	{ "Get_bSmoothInterpRollScale", Get_bSmoothInterpRollScale },
	{ "Set_bSmoothInterpRollScale", Set_bSmoothInterpRollScale },
	{ "Get_ForwardAxis", Get_ForwardAxis },
	{ "Set_ForwardAxis", Set_ForwardAxis },
	{ "Get_SplineBoundaryMin", Get_SplineBoundaryMin },
	{ "Set_SplineBoundaryMin", Set_SplineBoundaryMin },
	{ "Get_SplineBoundaryMax", Get_SplineBoundaryMax },
	{ "Set_SplineBoundaryMax", Set_SplineBoundaryMax },
	{ "is_nil", wLua::LuaStatic::isnil },
	{ "__gc", wLua::LuaStatic::removeUClassFrameCache },
	{ NULL, NULL }
};

void Register(lua_State *InScriptContext)
{
	lua_newtable(InScriptContext);
	luaL_register(InScriptContext, NULL, Lib_Funcs);
	AzureHelpFuncs::AuxRegister(InScriptContext, "SplineMeshComponent");
}
void SetMtLink(lua_State *InScriptContext)
{
	AzureHelpFuncs::AuxSetMtLink(InScriptContext, "SplineMeshComponent", "StaticMeshComponent",USERDATATYPE_UOBJECT);
}

}