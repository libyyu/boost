#include "Azure.h"
#include "Utility/help_funcs.h"
#include "wLua/UObjectHeaders.h"
#include "AzureFixedList.h"
#include "AzureLuaIntegration.h"

namespace LuaAzureFixedList
{
int32 getItem(lua_State*);
int32 setCount(lua_State*);
int32 getCount(lua_State*);
int32 clear(lua_State*);

int32 SetReuseChildWidgets(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureFixedList",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureFixedList must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool bReuse;
	} Params;
	Params.bReuse = !!(lua_toboolean(InScriptContext, 2));
#if UE_GAME
	UAzureFixedList * This = (UAzureFixedList *)Obj;
	This->SetReuseChildWidgets(Params.bReuse);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetReuseChildWidgets"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(bool*)(params.GetStructMemory() + 0) = Params.bReuse;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.bReuse = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetCount(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureFixedList",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureFixedList must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		int32 count;
	} Params;
	Params.count = (luaL_checkint(InScriptContext, 2));
#if UE_GAME
	UAzureFixedList * This = (UAzureFixedList *)Obj;
	This->SetCount(Params.count);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetCount"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(int32*)(params.GetStructMemory() + 0) = Params.count;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.count = *(int32*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 ManuallyRelease(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureFixedList",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureFixedList must be non-null"); lua_error(InScriptContext);  return 0;}
#if UE_GAME
	UAzureFixedList * This = (UAzureFixedList *)Obj;
	This->ManuallyRelease();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("ManuallyRelease"));
	if(!Function) { check(false); return 0;}
	Obj->ProcessEvent(Function, NULL);
#endif
	return 0;
}

int32 GetItemByWidget(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureFixedList",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureFixedList must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		UWidget* Widget = nullptr;
		int32 Index;
		UUserWidget* ReturnValue = nullptr;
	} Params;
	Params.Widget = (UWidget*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"Widget");;
#if UE_GAME
	UAzureFixedList * This = (UAzureFixedList *)Obj;
	Params.ReturnValue = This->GetItemByWidget(Params.Widget,Params.Index);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetItemByWidget"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(UWidget**)(params.GetStructMemory() + 0) = Params.Widget;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.Widget = *(UWidget**)(params.GetStructMemory() + 0);
		Params.Index = *(int32*)(params.GetStructMemory() + 8);
		Params.ReturnValue = *(UUserWidget**)(params.GetStructMemory() + 16);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Params.ReturnValue);
	lua_pushinteger(InScriptContext, Params.Index);
	return 2;
}

int32 GetItemByIndex(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureFixedList",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureFixedList must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		int32 index;
		UUserWidget* ReturnValue = nullptr;
	} Params;
	Params.index = (luaL_checkint(InScriptContext, 2));
#if UE_GAME
	UAzureFixedList * This = (UAzureFixedList *)Obj;
	Params.ReturnValue = This->GetItemByIndex(Params.index);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetItemByIndex"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(int32*)(params.GetStructMemory() + 0) = Params.index;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.index = *(int32*)(params.GetStructMemory() + 0);
		Params.ReturnValue = *(UUserWidget**)(params.GetStructMemory() + 8);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetIndexByItem(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureFixedList",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureFixedList must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		UUserWidget* Item = nullptr;
		int32 ReturnValue;
	} Params;
	Params.Item = (UUserWidget*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"UserWidget");;
#if UE_GAME
	UAzureFixedList * This = (UAzureFixedList *)Obj;
	Params.ReturnValue = This->GetIndexByItem(Params.Item);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetIndexByItem"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(UUserWidget**)(params.GetStructMemory() + 0) = Params.Item;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.Item = *(UUserWidget**)(params.GetStructMemory() + 0);
		Params.ReturnValue = *(int32*)(params.GetStructMemory() + 8);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushinteger(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetCount(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureFixedList",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureFixedList must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		int32 ReturnValue;
	} Params;
#if UE_GAME
	UAzureFixedList * This = (UAzureFixedList *)Obj;
	Params.ReturnValue = This->GetCount();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetCount"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(int32*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushinteger(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 Clear(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureFixedList",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureFixedList must be non-null"); lua_error(InScriptContext);  return 0;}
#if UE_GAME
	UAzureFixedList * This = (UAzureFixedList *)Obj;
	This->Clear();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("Clear"));
	if(!Function) { check(false); return 0;}
	Obj->ProcessEvent(Function, NULL);
#endif
	return 0;
}

int32 Get_TemplateClass(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureFixedList",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureFixedList must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzureFixedList::StaticClass(), TEXT("TemplateClass"));
	if(!Property) { check(false); return 0;}
	TSubclassOf<UUserWidget>  PropertyValue = TSubclassOf<UUserWidget> ();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaUtils::ReturnUObject(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_ItemWidth(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureFixedList",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureFixedList must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzureFixedList::StaticClass(), TEXT("ItemWidth"));
	if(!Property) { check(false); return 0;}
	int32 PropertyValue = int32();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushinteger(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_ItemHeight(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureFixedList",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureFixedList must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzureFixedList::StaticClass(), TEXT("ItemHeight"));
	if(!Property) { check(false); return 0;}
	int32 PropertyValue = int32();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushinteger(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_RowCount(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureFixedList",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureFixedList must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzureFixedList::StaticClass(), TEXT("RowCount"));
	if(!Property) { check(false); return 0;}
	int32 PropertyValue = int32();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushinteger(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_ColCount(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureFixedList",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureFixedList must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzureFixedList::StaticClass(), TEXT("ColCount"));
	if(!Property) { check(false); return 0;}
	int32 PropertyValue = int32();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushinteger(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_RowGap(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureFixedList",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureFixedList must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzureFixedList::StaticClass(), TEXT("RowGap"));
	if(!Property) { check(false); return 0;}
	int32 PropertyValue = int32();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushinteger(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_ColGap(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureFixedList",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureFixedList must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzureFixedList::StaticClass(), TEXT("ColGap"));
	if(!Property) { check(false); return 0;}
	int32 PropertyValue = int32();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushinteger(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_bAutoSizeItem(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureFixedList",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureFixedList must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzureFixedList::StaticClass(), TEXT("bAutoSizeItem"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = bool();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_Orientation(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureFixedList",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureFixedList must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzureFixedList::StaticClass(), TEXT("Orientation"));
	if(!Property) { check(false); return 0;}
	TEnumAsByte<EOrientation> PropertyValue = TEnumAsByte<EOrientation>();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushinteger(InScriptContext, (int)PropertyValue);
	return 1;
}

int32 Get_bReverseOrientationX(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureFixedList",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureFixedList must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzureFixedList::StaticClass(), TEXT("bReverseOrientationX"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = bool();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_bReverseOrientationY(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureFixedList",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureFixedList must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzureFixedList::StaticClass(), TEXT("bReverseOrientationY"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = bool();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_ListWidth(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureFixedList",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureFixedList must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzureFixedList::StaticClass(), TEXT("ListWidth"));
	if(!Property) { check(false); return 0;}
	int32 PropertyValue = int32();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushinteger(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_ListHeight(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureFixedList",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureFixedList must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzureFixedList::StaticClass(), TEXT("ListHeight"));
	if(!Property) { check(false); return 0;}
	int32 PropertyValue = int32();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushinteger(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_ItemSize(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureFixedList",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureFixedList must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzureFixedList::StaticClass(), TEXT("ItemSize"));
	if(!Property) { check(false); return 0;}
	FVector2D PropertyValue = FVector2D();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaVector2D::Return(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_bReuseChildWidgets(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureFixedList",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureFixedList must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzureFixedList::StaticClass(), TEXT("bReuseChildWidgets"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = bool();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 New(lua_State* InScriptContext)
{
	UObject* Outer = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Object");
	FName Name = FName(luaL_checkstring(InScriptContext, 2));
	UObject* Obj = NewObject<UAzureFixedList>(Outer, Name);
	wLua::FLuaUtils::ReturnUObject(InScriptContext,Obj);
	return 1;
}

int32 Destroy(lua_State* InScriptContext)
{
	return 0;
}

int32 Class(lua_State* InScriptContext)
{
	UClass* Class = UAzureFixedList::StaticClass();
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Class);
	return 1;
}

const luaL_Reg Lib_Funcs[] =
{
	{ "New", New },
	{ "Destroy", Destroy },
	{ "Class", Class },
	{ "SetReuseChildWidgets", SetReuseChildWidgets },
	{ "SetCount", SetCount },
	{ "ManuallyRelease", ManuallyRelease },
	{ "GetItemByWidget", GetItemByWidget },
	{ "GetItemByIndex", GetItemByIndex },
	{ "GetIndexByItem", GetIndexByItem },
	{ "GetCount", GetCount },
	{ "Clear", Clear },
	{ "Get_TemplateClass", Get_TemplateClass },
	{ "Get_ItemWidth", Get_ItemWidth },
	{ "Get_ItemHeight", Get_ItemHeight },
	{ "Get_RowCount", Get_RowCount },
	{ "Get_ColCount", Get_ColCount },
	{ "Get_RowGap", Get_RowGap },
	{ "Get_ColGap", Get_ColGap },
	{ "Get_bAutoSizeItem", Get_bAutoSizeItem },
	{ "Get_Orientation", Get_Orientation },
	{ "Get_bReverseOrientationX", Get_bReverseOrientationX },
	{ "Get_bReverseOrientationY", Get_bReverseOrientationY },
	{ "Get_ListWidth", Get_ListWidth },
	{ "Get_ListHeight", Get_ListHeight },
	{ "Get_ItemSize", Get_ItemSize },
	{ "Get_bReuseChildWidgets", Get_bReuseChildWidgets },
	{ "getItem", getItem },
	{ "setCount", setCount },
	{ "getCount", getCount },
	{ "clear", clear },
	{ "is_nil", wLua::LuaStatic::isnil },
	{ "__gc", wLua::LuaStatic::removeUClassFrameCache },
	{ NULL, NULL }
};

void Register(lua_State *InScriptContext)
{
	lua_newtable(InScriptContext);
	luaL_register(InScriptContext, NULL, Lib_Funcs);
	AzureHelpFuncs::AuxRegister(InScriptContext, "AzureFixedList");
}
void SetMtLink(lua_State *InScriptContext)
{
	AzureHelpFuncs::AuxSetMtLink(InScriptContext, "AzureFixedList", "Widget",USERDATATYPE_UOBJECT);
}

}