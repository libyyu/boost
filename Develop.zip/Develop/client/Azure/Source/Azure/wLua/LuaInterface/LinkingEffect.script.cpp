#include "Azure.h"
#include "Utility/help_funcs.h"
#include "wLua/UObjectHeaders.h"
#include "GameLogic/Weapon/LinkingEffect.h"
#include "AzureLuaIntegration.h"

namespace LuaLinkingEffect
{
int32 SetVectorProperty(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"LinkingEffect",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"LinkingEffect must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FName PropertyName;
		FVector4 Value;
	} Params;
	Params.PropertyName = FName(UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 2)));
	Params.Value = (wLua::FLuaVector4::Get(InScriptContext, 3));
#if UE_GAME
	ALinkingEffect * This = (ALinkingEffect *)Obj;
	This->SetVectorProperty(Params.PropertyName,Params.Value);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetVectorProperty"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FName*)(params.GetStructMemory() + 0) = Params.PropertyName;
		*(FVector4*)(params.GetStructMemory() + 16) = Params.Value;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.PropertyName = *(FName*)(params.GetStructMemory() + 0);
		Params.Value = *(FVector4*)(params.GetStructMemory() + 16);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetScalarProperty(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"LinkingEffect",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"LinkingEffect must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FName PropertyName;
		float Value;
	} Params;
	Params.PropertyName = FName(UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 2)));
	Params.Value = (float)(luaL_checknumber(InScriptContext, 3));
#if UE_GAME
	ALinkingEffect * This = (ALinkingEffect *)Obj;
	This->SetScalarProperty(Params.PropertyName,Params.Value);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetScalarProperty"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FName*)(params.GetStructMemory() + 0) = Params.PropertyName;
		*(float*)(params.GetStructMemory() + 12) = Params.Value;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.PropertyName = *(FName*)(params.GetStructMemory() + 0);
		Params.Value = *(float*)(params.GetStructMemory() + 12);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 Detach(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"LinkingEffect",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"LinkingEffect must be non-null"); lua_error(InScriptContext);  return 0;}
#if UE_GAME
	ALinkingEffect * This = (ALinkingEffect *)Obj;
	This->Detach();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("Detach"));
	if(!Function) { check(false); return 0;}
	Obj->ProcessEvent(Function, NULL);
#endif
	return 0;
}

int32 AttachToWorld(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"LinkingEffect",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"LinkingEffect must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FVector WorldLocation;
	} Params;
	Params.WorldLocation = (wLua::FLuaVector::Get(InScriptContext, 2));
#if UE_GAME
	ALinkingEffect * This = (ALinkingEffect *)Obj;
	This->AttachToWorld(Params.WorldLocation);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("AttachToWorld"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FVector*)(params.GetStructMemory() + 0) = Params.WorldLocation;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.WorldLocation = *(FVector*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 AttachTo(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"LinkingEffect",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"LinkingEffect must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		USceneComponent* Component = nullptr;
		FName SocketName;
		FVector RelativeLocation;
	} Params;
	Params.Component = (USceneComponent*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"SceneComponent");;
	Params.SocketName = FName(UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 3)));
	Params.RelativeLocation = (wLua::FLuaVector::Get(InScriptContext, 4));
#if UE_GAME
	ALinkingEffect * This = (ALinkingEffect *)Obj;
	This->AttachTo(Params.Component,Params.SocketName,Params.RelativeLocation);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("AttachTo"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(USceneComponent**)(params.GetStructMemory() + 0) = Params.Component;
		*(FName*)(params.GetStructMemory() + 8) = Params.SocketName;
		*(FVector*)(params.GetStructMemory() + 20) = Params.RelativeLocation;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.Component = *(USceneComponent**)(params.GetStructMemory() + 0);
		Params.SocketName = *(FName*)(params.GetStructMemory() + 8);
		Params.RelativeLocation = *(FVector*)(params.GetStructMemory() + 20);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 New(lua_State* InScriptContext)
{
	UObject* Outer = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Object");
	FName Name = FName(luaL_checkstring(InScriptContext, 2));
	UObject* Obj = NewObject<ALinkingEffect>(Outer, Name);
	wLua::FLuaUtils::ReturnUObject(InScriptContext,Obj);
	return 1;
}

int32 Destroy(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"LinkingEffect",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"LinkingEffect must be non-null"); lua_error(InScriptContext);  return 0;}
		AActor * actor = Cast<AActor>(Obj);
		actor->Destroy();
		userdata->flag |= wLua::LuaObjectFlag::DESTROYED;
		wLua::FLuaUtils::RemoveObjectReference(Obj, userdata->stamp, InScriptContext);
#ifdef AZURE_BUILD_WLUACHECK
		UE_LOG(LogAzure, Warning, TEXT("Destroy LinkingEffect: %x userdata:%x   stamp:%x"),Obj,userdata,userdata->stamp);
#endif
	return 0;
}

int32 Class(lua_State* InScriptContext)
{
	UClass* Class = ALinkingEffect::StaticClass();
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Class);
	return 1;
}

const luaL_Reg Lib_Funcs[] =
{
	{ "New", New },
	{ "Destroy", Destroy },
	{ "Class", Class },
	{ "SetVectorProperty", SetVectorProperty },
	{ "SetScalarProperty", SetScalarProperty },
	{ "Detach", Detach },
	{ "AttachToWorld", AttachToWorld },
	{ "AttachTo", AttachTo },
	{ "is_nil", wLua::LuaStatic::isnil },
	{ "__gc", wLua::LuaStatic::removeUClassFrameCache },
	{ NULL, NULL }
};

void Register(lua_State *InScriptContext)
{
	lua_newtable(InScriptContext);
	luaL_register(InScriptContext, NULL, Lib_Funcs);
	AzureHelpFuncs::AuxRegister(InScriptContext, "LinkingEffect");
}
void SetMtLink(lua_State *InScriptContext)
{
	AzureHelpFuncs::AuxSetMtLink(InScriptContext, "LinkingEffect", "Actor",USERDATATYPE_UOBJECT);
}

}