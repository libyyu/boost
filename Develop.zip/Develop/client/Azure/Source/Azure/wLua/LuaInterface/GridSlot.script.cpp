#include "Azure.h"
#include "Utility/help_funcs.h"
#include "wLua/UObjectHeaders.h"
#include "Components/GridSlot.h"
#include "AzureLuaIntegration.h"

namespace LuaGridSlot
{
int32 SetVerticalAlignment(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"GridSlot",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"GridSlot must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		TEnumAsByte<EVerticalAlignment> InVerticalAlignment;
	} Params;
	Params.InVerticalAlignment = (TEnumAsByte<EVerticalAlignment>)(luaL_checkint(InScriptContext, 2));
#if UE_GAME
	UGridSlot * This = (UGridSlot *)Obj;
	This->SetVerticalAlignment(Params.InVerticalAlignment);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetVerticalAlignment"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(TEnumAsByte<EVerticalAlignment>*)(params.GetStructMemory() + 0) = Params.InVerticalAlignment;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.InVerticalAlignment = *(TEnumAsByte<EVerticalAlignment>*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetRowSpan(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"GridSlot",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"GridSlot must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		int32 InRowSpan;
	} Params;
	Params.InRowSpan = (luaL_checkint(InScriptContext, 2));
#if UE_GAME
	UGridSlot * This = (UGridSlot *)Obj;
	This->SetRowSpan(Params.InRowSpan);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetRowSpan"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(int32*)(params.GetStructMemory() + 0) = Params.InRowSpan;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.InRowSpan = *(int32*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetRow(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"GridSlot",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"GridSlot must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		int32 InRow;
	} Params;
	Params.InRow = (luaL_checkint(InScriptContext, 2));
#if UE_GAME
	UGridSlot * This = (UGridSlot *)Obj;
	This->SetRow(Params.InRow);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetRow"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(int32*)(params.GetStructMemory() + 0) = Params.InRow;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.InRow = *(int32*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetLayer(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"GridSlot",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"GridSlot must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		int32 InLayer;
	} Params;
	Params.InLayer = (luaL_checkint(InScriptContext, 2));
#if UE_GAME
	UGridSlot * This = (UGridSlot *)Obj;
	This->SetLayer(Params.InLayer);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetLayer"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(int32*)(params.GetStructMemory() + 0) = Params.InLayer;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.InLayer = *(int32*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetHorizontalAlignment(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"GridSlot",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"GridSlot must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		TEnumAsByte<EHorizontalAlignment> InHorizontalAlignment;
	} Params;
	Params.InHorizontalAlignment = (TEnumAsByte<EHorizontalAlignment>)(luaL_checkint(InScriptContext, 2));
#if UE_GAME
	UGridSlot * This = (UGridSlot *)Obj;
	This->SetHorizontalAlignment(Params.InHorizontalAlignment);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetHorizontalAlignment"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(TEnumAsByte<EHorizontalAlignment>*)(params.GetStructMemory() + 0) = Params.InHorizontalAlignment;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.InHorizontalAlignment = *(TEnumAsByte<EHorizontalAlignment>*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetColumnSpan(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"GridSlot",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"GridSlot must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		int32 InColumnSpan;
	} Params;
	Params.InColumnSpan = (luaL_checkint(InScriptContext, 2));
#if UE_GAME
	UGridSlot * This = (UGridSlot *)Obj;
	This->SetColumnSpan(Params.InColumnSpan);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetColumnSpan"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(int32*)(params.GetStructMemory() + 0) = Params.InColumnSpan;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.InColumnSpan = *(int32*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetColumn(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"GridSlot",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"GridSlot must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		int32 InColumn;
	} Params;
	Params.InColumn = (luaL_checkint(InScriptContext, 2));
#if UE_GAME
	UGridSlot * This = (UGridSlot *)Obj;
	This->SetColumn(Params.InColumn);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetColumn"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(int32*)(params.GetStructMemory() + 0) = Params.InColumn;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.InColumn = *(int32*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 Get_HorizontalAlignment(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"GridSlot",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"GridSlot must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UGridSlot::StaticClass(), TEXT("HorizontalAlignment"));
	if(!Property) { check(false); return 0;}
	TEnumAsByte<EHorizontalAlignment> PropertyValue = TEnumAsByte<EHorizontalAlignment>();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushinteger(InScriptContext, (int)PropertyValue);
	return 1;
}

int32 Get_VerticalAlignment(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"GridSlot",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"GridSlot must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UGridSlot::StaticClass(), TEXT("VerticalAlignment"));
	if(!Property) { check(false); return 0;}
	TEnumAsByte<EVerticalAlignment> PropertyValue = TEnumAsByte<EVerticalAlignment>();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushinteger(InScriptContext, (int)PropertyValue);
	return 1;
}

int32 Get_Row(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"GridSlot",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"GridSlot must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UGridSlot::StaticClass(), TEXT("Row"));
	if(!Property) { check(false); return 0;}
	int32 PropertyValue = int32();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushinteger(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_RowSpan(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"GridSlot",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"GridSlot must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UGridSlot::StaticClass(), TEXT("RowSpan"));
	if(!Property) { check(false); return 0;}
	int32 PropertyValue = int32();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushinteger(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_Column(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"GridSlot",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"GridSlot must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UGridSlot::StaticClass(), TEXT("Column"));
	if(!Property) { check(false); return 0;}
	int32 PropertyValue = int32();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushinteger(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_ColumnSpan(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"GridSlot",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"GridSlot must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UGridSlot::StaticClass(), TEXT("ColumnSpan"));
	if(!Property) { check(false); return 0;}
	int32 PropertyValue = int32();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushinteger(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_Layer(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"GridSlot",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"GridSlot must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UGridSlot::StaticClass(), TEXT("Layer"));
	if(!Property) { check(false); return 0;}
	int32 PropertyValue = int32();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushinteger(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_Nudge(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"GridSlot",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"GridSlot must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UGridSlot::StaticClass(), TEXT("Nudge"));
	if(!Property) { check(false); return 0;}
	FVector2D PropertyValue = FVector2D();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaVector2D::Return(InScriptContext, PropertyValue);
	return 1;
}

int32 New(lua_State* InScriptContext)
{
	UObject* Outer = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Object");
	FName Name = FName(luaL_checkstring(InScriptContext, 2));
	UObject* Obj = NewObject<UGridSlot>(Outer, Name);
	wLua::FLuaUtils::ReturnUObject(InScriptContext,Obj);
	return 1;
}

int32 Destroy(lua_State* InScriptContext)
{
	return 0;
}

int32 Class(lua_State* InScriptContext)
{
	UClass* Class = UGridSlot::StaticClass();
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Class);
	return 1;
}

const luaL_Reg Lib_Funcs[] =
{
	{ "New", New },
	{ "Destroy", Destroy },
	{ "Class", Class },
	{ "SetVerticalAlignment", SetVerticalAlignment },
	{ "SetRowSpan", SetRowSpan },
	{ "SetRow", SetRow },
	{ "SetLayer", SetLayer },
	{ "SetHorizontalAlignment", SetHorizontalAlignment },
	{ "SetColumnSpan", SetColumnSpan },
	{ "SetColumn", SetColumn },
	{ "Get_HorizontalAlignment", Get_HorizontalAlignment },
	{ "Get_VerticalAlignment", Get_VerticalAlignment },
	{ "Get_Row", Get_Row },
	{ "Get_RowSpan", Get_RowSpan },
	{ "Get_Column", Get_Column },
	{ "Get_ColumnSpan", Get_ColumnSpan },
	{ "Get_Layer", Get_Layer },
	{ "Get_Nudge", Get_Nudge },
	{ "is_nil", wLua::LuaStatic::isnil },
	{ "__gc", wLua::LuaStatic::removeUClassFrameCache },
	{ NULL, NULL }
};

void Register(lua_State *InScriptContext)
{
	lua_newtable(InScriptContext);
	luaL_register(InScriptContext, NULL, Lib_Funcs);
	AzureHelpFuncs::AuxRegister(InScriptContext, "GridSlot");
}
void SetMtLink(lua_State *InScriptContext)
{
	AzureHelpFuncs::AuxSetMtLink(InScriptContext, "GridSlot", "PanelSlot",USERDATATYPE_UOBJECT);
}

}