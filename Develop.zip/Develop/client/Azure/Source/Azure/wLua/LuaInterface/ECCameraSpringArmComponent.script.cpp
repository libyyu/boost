#include "Azure.h"
#include "Utility/help_funcs.h"
#include "wLua/UObjectHeaders.h"
#include "GameLogic/Player/ECCameraSpringArmComponent.h"
#include "../UClassHeaders.h"
#include "AzureLuaIntegration.h"

namespace LuaECCameraSpringArmComponent
{
int32 TransitRotation(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ECCameraSpringArmComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ECCameraSpringArmComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FRotator dest;
		float duration;
		bool bLerp;
	} Params;
	Params.dest = (wLua::FLuaRotator::Get(InScriptContext, 2));
	Params.duration = (float)(luaL_checknumber(InScriptContext, 3));
	Params.bLerp = lua_isnoneornil(InScriptContext,4) ? bool(false) : !!(lua_toboolean(InScriptContext, 4));
#if UE_GAME
	UECCameraSpringArmComponent * This = (UECCameraSpringArmComponent *)Obj;
	This->TransitRotation(Params.dest,Params.duration,Params.bLerp);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("TransitRotation"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FRotator*)(params.GetStructMemory() + 0) = Params.dest;
		*(float*)(params.GetStructMemory() + 12) = Params.duration;
		*(bool*)(params.GetStructMemory() + 16) = Params.bLerp;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.dest = *(FRotator*)(params.GetStructMemory() + 0);
		Params.duration = *(float*)(params.GetStructMemory() + 12);
		Params.bLerp = *(bool*)(params.GetStructMemory() + 16);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetSpecificFollowSceneComponent(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ECCameraSpringArmComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ECCameraSpringArmComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		USceneComponent* targetFloow = nullptr;
		FName socketName;
	} Params;
	Params.targetFloow = (USceneComponent*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"SceneComponent");;
	Params.socketName = FName(UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 3)));
#if UE_GAME
	UECCameraSpringArmComponent * This = (UECCameraSpringArmComponent *)Obj;
	This->SetSpecificFollowSceneComponent(Params.targetFloow,Params.socketName);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetSpecificFollowSceneComponent"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(USceneComponent**)(params.GetStructMemory() + 0) = Params.targetFloow;
		*(FName*)(params.GetStructMemory() + 8) = Params.socketName;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.targetFloow = *(USceneComponent**)(params.GetStructMemory() + 0);
		Params.socketName = *(FName*)(params.GetStructMemory() + 8);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetMinMaxDist(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ECCameraSpringArmComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ECCameraSpringArmComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float fMinDist;
		float fMaxDist;
	} Params;
	Params.fMinDist = (float)(luaL_checknumber(InScriptContext, 2));
	Params.fMaxDist = (float)(luaL_checknumber(InScriptContext, 3));
#if UE_GAME
	UECCameraSpringArmComponent * This = (UECCameraSpringArmComponent *)Obj;
	This->SetMinMaxDist(Params.fMinDist,Params.fMaxDist);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetMinMaxDist"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(float*)(params.GetStructMemory() + 0) = Params.fMinDist;
		*(float*)(params.GetStructMemory() + 4) = Params.fMaxDist;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.fMinDist = *(float*)(params.GetStructMemory() + 0);
		Params.fMaxDist = *(float*)(params.GetStructMemory() + 4);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetLockTargetComponent(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ECCameraSpringArmComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ECCameraSpringArmComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		USceneComponent* _lockTarget = nullptr;
	} Params;
	Params._lockTarget = (USceneComponent*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"SceneComponent");;
#if UE_GAME
	UECCameraSpringArmComponent * This = (UECCameraSpringArmComponent *)Obj;
	This->SetLockTargetComponent(Params._lockTarget);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetLockTargetComponent"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(USceneComponent**)(params.GetStructMemory() + 0) = Params._lockTarget;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params._lockTarget = *(USceneComponent**)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetDefaultTargetArmLength(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ECCameraSpringArmComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ECCameraSpringArmComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float len;
	} Params;
	Params.len = (float)(luaL_checknumber(InScriptContext, 2));
#if UE_GAME
	UECCameraSpringArmComponent * This = (UECCameraSpringArmComponent *)Obj;
	This->SetDefaultTargetArmLength(Params.len);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetDefaultTargetArmLength"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(float*)(params.GetStructMemory() + 0) = Params.len;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.len = *(float*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetContrlMode(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ECCameraSpringArmComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ECCameraSpringArmComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		ECameraContrlMode mode;
		bool smoothTransition;
	} Params;
	Params.mode = (ECameraContrlMode)(luaL_checkint(InScriptContext, 2));
	Params.smoothTransition = !!(lua_toboolean(InScriptContext, 3));
#if UE_GAME
	UECCameraSpringArmComponent * This = (UECCameraSpringArmComponent *)Obj;
	This->SetContrlMode(Params.mode,Params.smoothTransition);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetContrlMode"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(ECameraContrlMode*)(params.GetStructMemory() + 0) = Params.mode;
		*(bool*)(params.GetStructMemory() + 1) = Params.smoothTransition;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.mode = *(ECameraContrlMode*)(params.GetStructMemory() + 0);
		Params.smoothTransition = *(bool*)(params.GetStructMemory() + 1);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetCanAdjustCameraRelativeTargetInAutoMove(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ECCameraSpringArmComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ECCameraSpringArmComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool bCan;
	} Params;
	Params.bCan = !!(lua_toboolean(InScriptContext, 2));
#if UE_GAME
	UECCameraSpringArmComponent * This = (UECCameraSpringArmComponent *)Obj;
	This->SetCanAdjustCameraRelativeTargetInAutoMove(Params.bCan);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetCanAdjustCameraRelativeTargetInAutoMove"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(bool*)(params.GetStructMemory() + 0) = Params.bCan;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.bCan = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetCameraLagMaxDistance(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ECCameraSpringArmComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ECCameraSpringArmComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float max_dist;
	} Params;
	Params.max_dist = (float)(luaL_checknumber(InScriptContext, 2));
#if UE_GAME
	UECCameraSpringArmComponent * This = (UECCameraSpringArmComponent *)Obj;
	This->SetCameraLagMaxDistance(Params.max_dist);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetCameraLagMaxDistance"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(float*)(params.GetStructMemory() + 0) = Params.max_dist;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.max_dist = *(float*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetCameraLagCloseSpeed(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ECCameraSpringArmComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ECCameraSpringArmComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float speed;
	} Params;
	Params.speed = (float)(luaL_checknumber(InScriptContext, 2));
#if UE_GAME
	UECCameraSpringArmComponent * This = (UECCameraSpringArmComponent *)Obj;
	This->SetCameraLagCloseSpeed(Params.speed);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetCameraLagCloseSpeed"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(float*)(params.GetStructMemory() + 0) = Params.speed;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.speed = *(float*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetCameraLagCloseMidDistance(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ECCameraSpringArmComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ECCameraSpringArmComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float close_dist;
		float mid_dist;
	} Params;
	Params.close_dist = (float)(luaL_checknumber(InScriptContext, 2));
	Params.mid_dist = (float)(luaL_checknumber(InScriptContext, 3));
#if UE_GAME
	UECCameraSpringArmComponent * This = (UECCameraSpringArmComponent *)Obj;
	This->SetCameraLagCloseMidDistance(Params.close_dist,Params.mid_dist);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetCameraLagCloseMidDistance"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(float*)(params.GetStructMemory() + 0) = Params.close_dist;
		*(float*)(params.GetStructMemory() + 4) = Params.mid_dist;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.close_dist = *(float*)(params.GetStructMemory() + 0);
		Params.mid_dist = *(float*)(params.GetStructMemory() + 4);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 ManualUpdateDesiredArmLocation(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ECCameraSpringArmComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ECCameraSpringArmComponent must be non-null"); lua_error(InScriptContext);  return 0;}
#if UE_GAME
	UECCameraSpringArmComponent * This = (UECCameraSpringArmComponent *)Obj;
	This->ManualUpdateDesiredArmLocation();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("ManualUpdateDesiredArmLocation"));
	if(!Function) { check(false); return 0;}
	Obj->ProcessEvent(Function, NULL);
#endif
	return 0;
}

int32 IsTransiting(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ECCameraSpringArmComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ECCameraSpringArmComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool ReturnValue;
	} Params;
#if UE_GAME
	UECCameraSpringArmComponent * This = (UECCameraSpringArmComponent *)Obj;
	Params.ReturnValue = This->IsTransiting();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("IsTransiting"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushboolean(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetTransitingRotator(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ECCameraSpringArmComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ECCameraSpringArmComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FRotator ReturnValue;
	} Params;
#if UE_GAME
	UECCameraSpringArmComponent * This = (UECCameraSpringArmComponent *)Obj;
	Params.ReturnValue = This->GetTransitingRotator();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetTransitingRotator"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(FRotator*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaRotator::Return(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetTargetOriginLocation(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ECCameraSpringArmComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ECCameraSpringArmComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FVector ReturnValue;
	} Params;
#if UE_GAME
	UECCameraSpringArmComponent * This = (UECCameraSpringArmComponent *)Obj;
	Params.ReturnValue = This->GetTargetOriginLocation();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetTargetOriginLocation"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(FVector*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaVector::Return(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetMinMaxDist(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ECCameraSpringArmComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ECCameraSpringArmComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float fMinDist;
		float fMaxDist;
	} Params;
#if UE_GAME
	UECCameraSpringArmComponent * This = (UECCameraSpringArmComponent *)Obj;
	This->GetMinMaxDist(Params.fMinDist,Params.fMaxDist);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetMinMaxDist"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.fMinDist = *(float*)(params.GetStructMemory() + 0);
		Params.fMaxDist = *(float*)(params.GetStructMemory() + 4);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushnumber(InScriptContext, Params.fMinDist);
	lua_pushnumber(InScriptContext, Params.fMaxDist);
	return 2;
}

int32 GetCameraLagSpeed(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ECCameraSpringArmComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ECCameraSpringArmComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float close_speed;
		float far_speed;
	} Params;
#if UE_GAME
	UECCameraSpringArmComponent * This = (UECCameraSpringArmComponent *)Obj;
	This->GetCameraLagSpeed(Params.close_speed,Params.far_speed);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetCameraLagSpeed"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.close_speed = *(float*)(params.GetStructMemory() + 0);
		Params.far_speed = *(float*)(params.GetStructMemory() + 4);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushnumber(InScriptContext, Params.close_speed);
	lua_pushnumber(InScriptContext, Params.far_speed);
	return 2;
}

int32 GetCameraLagDistance(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ECCameraSpringArmComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ECCameraSpringArmComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float close_dist;
		float mid_dist;
		float max_dist;
	} Params;
#if UE_GAME
	UECCameraSpringArmComponent * This = (UECCameraSpringArmComponent *)Obj;
	This->GetCameraLagDistance(Params.close_dist,Params.mid_dist,Params.max_dist);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetCameraLagDistance"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.close_dist = *(float*)(params.GetStructMemory() + 0);
		Params.mid_dist = *(float*)(params.GetStructMemory() + 4);
		Params.max_dist = *(float*)(params.GetStructMemory() + 8);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushnumber(InScriptContext, Params.close_dist);
	lua_pushnumber(InScriptContext, Params.mid_dist);
	lua_pushnumber(InScriptContext, Params.max_dist);
	return 3;
}

int32 AdjustArmLengthDelta(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ECCameraSpringArmComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ECCameraSpringArmComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float fDistDeltaRatio;
	} Params;
	Params.fDistDeltaRatio = (float)(luaL_checknumber(InScriptContext, 2));
#if UE_GAME
	UECCameraSpringArmComponent * This = (UECCameraSpringArmComponent *)Obj;
	This->AdjustArmLengthDelta(Params.fDistDeltaRatio);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("AdjustArmLengthDelta"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(float*)(params.GetStructMemory() + 0) = Params.fDistDeltaRatio;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.fDistDeltaRatio = *(float*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 Get_lockNearDeviationAngle(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ECCameraSpringArmComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ECCameraSpringArmComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UECCameraSpringArmComponent::StaticClass(), TEXT("lockNearDeviationAngle"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_lockNearDeviationAngle(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ECCameraSpringArmComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ECCameraSpringArmComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UECCameraSpringArmComponent::StaticClass(), TEXT("lockNearDeviationAngle"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_lockFarDeviationAngle(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ECCameraSpringArmComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ECCameraSpringArmComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UECCameraSpringArmComponent::StaticClass(), TEXT("lockFarDeviationAngle"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_lockFarDeviationAngle(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ECCameraSpringArmComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ECCameraSpringArmComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UECCameraSpringArmComponent::StaticClass(), TEXT("lockFarDeviationAngle"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_lockNearDistance(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ECCameraSpringArmComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ECCameraSpringArmComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UECCameraSpringArmComponent::StaticClass(), TEXT("lockNearDistance"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_lockNearDistance(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ECCameraSpringArmComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ECCameraSpringArmComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UECCameraSpringArmComponent::StaticClass(), TEXT("lockNearDistance"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_lockFarDistance(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ECCameraSpringArmComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ECCameraSpringArmComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UECCameraSpringArmComponent::StaticClass(), TEXT("lockFarDistance"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_lockFarDistance(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ECCameraSpringArmComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ECCameraSpringArmComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UECCameraSpringArmComponent::StaticClass(), TEXT("lockFarDistance"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_LockSmoothTransitionAccelerator(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ECCameraSpringArmComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ECCameraSpringArmComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UECCameraSpringArmComponent::StaticClass(), TEXT("LockSmoothTransitionAccelerator"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_LockSmoothTransitionAccelerator(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ECCameraSpringArmComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ECCameraSpringArmComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UECCameraSpringArmComponent::StaticClass(), TEXT("LockSmoothTransitionAccelerator"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_LockSmoothTransitionMaxSpeed(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ECCameraSpringArmComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ECCameraSpringArmComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UECCameraSpringArmComponent::StaticClass(), TEXT("LockSmoothTransitionMaxSpeed"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_LockSmoothTransitionMaxSpeed(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ECCameraSpringArmComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ECCameraSpringArmComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UECCameraSpringArmComponent::StaticClass(), TEXT("LockSmoothTransitionMaxSpeed"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_lockRecommendMaxPitch(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ECCameraSpringArmComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ECCameraSpringArmComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UECCameraSpringArmComponent::StaticClass(), TEXT("lockRecommendMaxPitch"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_lockRecommendMaxPitch(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ECCameraSpringArmComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ECCameraSpringArmComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UECCameraSpringArmComponent::StaticClass(), TEXT("lockRecommendMaxPitch"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_lockRecommendMinPitch(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ECCameraSpringArmComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ECCameraSpringArmComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UECCameraSpringArmComponent::StaticClass(), TEXT("lockRecommendMinPitch"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_lockRecommendMinPitch(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ECCameraSpringArmComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ECCameraSpringArmComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UECCameraSpringArmComponent::StaticClass(), TEXT("lockRecommendMinPitch"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_AutoSmoothTransitionAccelerator(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ECCameraSpringArmComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ECCameraSpringArmComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UECCameraSpringArmComponent::StaticClass(), TEXT("AutoSmoothTransitionAccelerator"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_AutoSmoothTransitionAccelerator(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ECCameraSpringArmComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ECCameraSpringArmComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UECCameraSpringArmComponent::StaticClass(), TEXT("AutoSmoothTransitionAccelerator"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_AutoSmoothTransitionMaxSpeed(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ECCameraSpringArmComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ECCameraSpringArmComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UECCameraSpringArmComponent::StaticClass(), TEXT("AutoSmoothTransitionMaxSpeed"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_AutoSmoothTransitionMaxSpeed(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ECCameraSpringArmComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ECCameraSpringArmComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UECCameraSpringArmComponent::StaticClass(), TEXT("AutoSmoothTransitionMaxSpeed"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_AutoFixedPitch(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ECCameraSpringArmComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ECCameraSpringArmComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UECCameraSpringArmComponent::StaticClass(), TEXT("AutoFixedPitch"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_AutoFixedPitch(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ECCameraSpringArmComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ECCameraSpringArmComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UECCameraSpringArmComponent::StaticClass(), TEXT("AutoFixedPitch"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_enableAutoFixedPitch(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ECCameraSpringArmComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ECCameraSpringArmComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UECCameraSpringArmComponent::StaticClass(), TEXT("enableAutoFixedPitch"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = bool();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_enableAutoFixedPitch(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ECCameraSpringArmComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ECCameraSpringArmComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UECCameraSpringArmComponent::StaticClass(), TEXT("enableAutoFixedPitch"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bDoTerrainCollisionTest(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ECCameraSpringArmComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ECCameraSpringArmComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UECCameraSpringArmComponent::StaticClass(), TEXT("bDoTerrainCollisionTest"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bDoTerrainCollisionTest(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ECCameraSpringArmComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ECCameraSpringArmComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UECCameraSpringArmComponent::StaticClass(), TEXT("bDoTerrainCollisionTest"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_TerrainProbeSize(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ECCameraSpringArmComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ECCameraSpringArmComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UECCameraSpringArmComponent::StaticClass(), TEXT("TerrainProbeSize"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_TerrainProbeSize(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ECCameraSpringArmComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ECCameraSpringArmComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UECCameraSpringArmComponent::StaticClass(), TEXT("TerrainProbeSize"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bEnableXRayVision(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ECCameraSpringArmComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ECCameraSpringArmComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UECCameraSpringArmComponent::StaticClass(), TEXT("bEnableXRayVision"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bEnableXRayVision(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ECCameraSpringArmComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ECCameraSpringArmComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UECCameraSpringArmComponent::StaticClass(), TEXT("bEnableXRayVision"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_XRayProbeSize(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ECCameraSpringArmComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ECCameraSpringArmComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UECCameraSpringArmComponent::StaticClass(), TEXT("XRayProbeSize"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_XRayProbeSize(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ECCameraSpringArmComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ECCameraSpringArmComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UECCameraSpringArmComponent::StaticClass(), TEXT("XRayProbeSize"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_XRayMaterial(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ECCameraSpringArmComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ECCameraSpringArmComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UECCameraSpringArmComponent::StaticClass(), TEXT("XRayMaterial"));
	if(!Property) { check(false); return 0;}
	UMaterialInterface* PropertyValue;
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaUtils::ReturnUObject(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_XRayMaterial(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ECCameraSpringArmComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ECCameraSpringArmComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UECCameraSpringArmComponent::StaticClass(), TEXT("XRayMaterial"));
	if(!Property) { check(false); return 0;}
	UMaterialInterface* PropertyValue = (UMaterialInterface*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"MaterialInterface");;
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bXRayTransition(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ECCameraSpringArmComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ECCameraSpringArmComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UECCameraSpringArmComponent::StaticClass(), TEXT("bXRayTransition"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bXRayTransition(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ECCameraSpringArmComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ECCameraSpringArmComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UECCameraSpringArmComponent::StaticClass(), TEXT("bXRayTransition"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_XRayTransitionPropName(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ECCameraSpringArmComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ECCameraSpringArmComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UECCameraSpringArmComponent::StaticClass(), TEXT("XRayTransitionPropName"));
	if(!Property) { check(false); return 0;}
	FName PropertyValue = FName();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushstring(InScriptContext, TCHAR_TO_UTF8(*PropertyValue.ToString()));
	return 1;
}

int32 Set_XRayTransitionPropName(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ECCameraSpringArmComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ECCameraSpringArmComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UECCameraSpringArmComponent::StaticClass(), TEXT("XRayTransitionPropName"));
	if(!Property) { check(false); return 0;}
	FName PropertyValue = FName(UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 2)));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_XRayTransitionBeginValue(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ECCameraSpringArmComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ECCameraSpringArmComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UECCameraSpringArmComponent::StaticClass(), TEXT("XRayTransitionBeginValue"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_XRayTransitionBeginValue(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ECCameraSpringArmComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ECCameraSpringArmComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UECCameraSpringArmComponent::StaticClass(), TEXT("XRayTransitionBeginValue"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_XRayTransitionEndValue(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ECCameraSpringArmComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ECCameraSpringArmComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UECCameraSpringArmComponent::StaticClass(), TEXT("XRayTransitionEndValue"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_XRayTransitionEndValue(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ECCameraSpringArmComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ECCameraSpringArmComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UECCameraSpringArmComponent::StaticClass(), TEXT("XRayTransitionEndValue"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_XRayTransitionTime(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ECCameraSpringArmComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ECCameraSpringArmComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UECCameraSpringArmComponent::StaticClass(), TEXT("XRayTransitionTime"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_XRayTransitionTime(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ECCameraSpringArmComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ECCameraSpringArmComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UECCameraSpringArmComponent::StaticClass(), TEXT("XRayTransitionTime"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bEnableArmLengthLag(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ECCameraSpringArmComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ECCameraSpringArmComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UECCameraSpringArmComponent::StaticClass(), TEXT("bEnableArmLengthLag"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = bool();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bEnableArmLengthLag(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ECCameraSpringArmComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ECCameraSpringArmComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UECCameraSpringArmComponent::StaticClass(), TEXT("bEnableArmLengthLag"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bArmLengthLag_Constant(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ECCameraSpringArmComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ECCameraSpringArmComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UECCameraSpringArmComponent::StaticClass(), TEXT("bArmLengthLag_Constant"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = bool();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bArmLengthLag_Constant(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ECCameraSpringArmComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ECCameraSpringArmComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UECCameraSpringArmComponent::StaticClass(), TEXT("bArmLengthLag_Constant"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_CameraArmLengthLagSpeed(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ECCameraSpringArmComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ECCameraSpringArmComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UECCameraSpringArmComponent::StaticClass(), TEXT("CameraArmLengthLagSpeed"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_CameraArmLengthLagSpeed(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ECCameraSpringArmComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ECCameraSpringArmComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UECCameraSpringArmComponent::StaticClass(), TEXT("CameraArmLengthLagSpeed"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bEnableSocketOffsetLag(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ECCameraSpringArmComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ECCameraSpringArmComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UECCameraSpringArmComponent::StaticClass(), TEXT("bEnableSocketOffsetLag"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = bool();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bEnableSocketOffsetLag(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ECCameraSpringArmComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ECCameraSpringArmComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UECCameraSpringArmComponent::StaticClass(), TEXT("bEnableSocketOffsetLag"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bSocketOffsetLag_Constant(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ECCameraSpringArmComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ECCameraSpringArmComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UECCameraSpringArmComponent::StaticClass(), TEXT("bSocketOffsetLag_Constant"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = bool();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bSocketOffsetLag_Constant(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ECCameraSpringArmComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ECCameraSpringArmComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UECCameraSpringArmComponent::StaticClass(), TEXT("bSocketOffsetLag_Constant"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_SocketOffsetLagSpeed(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ECCameraSpringArmComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ECCameraSpringArmComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UECCameraSpringArmComponent::StaticClass(), TEXT("SocketOffsetLagSpeed"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_SocketOffsetLagSpeed(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ECCameraSpringArmComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ECCameraSpringArmComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UECCameraSpringArmComponent::StaticClass(), TEXT("SocketOffsetLagSpeed"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_BreakLagArmLengthThreshold(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ECCameraSpringArmComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ECCameraSpringArmComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UECCameraSpringArmComponent::StaticClass(), TEXT("BreakLagArmLengthThreshold"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_BreakLagArmLengthThreshold(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ECCameraSpringArmComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ECCameraSpringArmComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UECCameraSpringArmComponent::StaticClass(), TEXT("BreakLagArmLengthThreshold"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_suspend(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ECCameraSpringArmComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ECCameraSpringArmComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UECCameraSpringArmComponent::StaticClass(), TEXT("suspend"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = bool();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_suspend(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ECCameraSpringArmComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ECCameraSpringArmComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UECCameraSpringArmComponent::StaticClass(), TEXT("suspend"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bEnableLagSmooth(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ECCameraSpringArmComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ECCameraSpringArmComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UECCameraSpringArmComponent::StaticClass(), TEXT("bEnableLagSmooth"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = bool();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bEnableLagSmooth(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ECCameraSpringArmComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ECCameraSpringArmComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UECCameraSpringArmComponent::StaticClass(), TEXT("bEnableLagSmooth"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_LagLocationSmoothSpeed(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ECCameraSpringArmComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ECCameraSpringArmComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UECCameraSpringArmComponent::StaticClass(), TEXT("LagLocationSmoothSpeed"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_LagLocationSmoothSpeed(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ECCameraSpringArmComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ECCameraSpringArmComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UECCameraSpringArmComponent::StaticClass(), TEXT("LagLocationSmoothSpeed"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bEnableTraceLocLag(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ECCameraSpringArmComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ECCameraSpringArmComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UECCameraSpringArmComponent::StaticClass(), TEXT("bEnableTraceLocLag"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = bool();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bEnableTraceLocLag(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ECCameraSpringArmComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ECCameraSpringArmComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UECCameraSpringArmComponent::StaticClass(), TEXT("bEnableTraceLocLag"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_LagTraceDisThreshold(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ECCameraSpringArmComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ECCameraSpringArmComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UECCameraSpringArmComponent::StaticClass(), TEXT("LagTraceDisThreshold"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_LagTraceDisThreshold(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ECCameraSpringArmComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ECCameraSpringArmComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UECCameraSpringArmComponent::StaticClass(), TEXT("LagTraceDisThreshold"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 New(lua_State* InScriptContext)
{
	UObject* Outer = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Object");
	FName Name = FName(luaL_checkstring(InScriptContext, 2));
	UObject* Obj = NewObject<UECCameraSpringArmComponent>(Outer, Name);
	wLua::FLuaUtils::ReturnUObject(InScriptContext,Obj);
	return 1;
}

int32 Destroy(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ECCameraSpringArmComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ECCameraSpringArmComponent must be non-null"); lua_error(InScriptContext);  return 0;}
		UActorComponent * com = Cast<UActorComponent>(Obj);
		if(lua_isnoneornil(InScriptContext,2))
			com->DestroyComponent();
		else
			com->DestroyComponent(!!lua_toboolean(InScriptContext,2));
		userdata->flag |= wLua::LuaObjectFlag::DESTROYED;
		wLua::FLuaUtils::RemoveObjectReference(Obj, userdata->stamp, InScriptContext);
#ifdef AZURE_BUILD_WLUACHECK
		UE_LOG(LogAzure, Warning, TEXT("Destroy ECCameraSpringArmComponent: %x userdata:%x   stamp:%x"),Obj,userdata,userdata->stamp);
#endif
	return 0;
}

int32 Class(lua_State* InScriptContext)
{
	UClass* Class = UECCameraSpringArmComponent::StaticClass();
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Class);
	return 1;
}

const luaL_Reg Lib_Funcs[] =
{
	{ "New", New },
	{ "Destroy", Destroy },
	{ "Class", Class },
	{ "TransitRotation", TransitRotation },
	{ "SetSpecificFollowSceneComponent", SetSpecificFollowSceneComponent },
	{ "SetMinMaxDist", SetMinMaxDist },
	{ "SetLockTargetComponent", SetLockTargetComponent },
	{ "SetDefaultTargetArmLength", SetDefaultTargetArmLength },
	{ "SetContrlMode", SetContrlMode },
	{ "SetCanAdjustCameraRelativeTargetInAutoMove", SetCanAdjustCameraRelativeTargetInAutoMove },
	{ "SetCameraLagMaxDistance", SetCameraLagMaxDistance },
	{ "SetCameraLagCloseSpeed", SetCameraLagCloseSpeed },
	{ "SetCameraLagCloseMidDistance", SetCameraLagCloseMidDistance },
	{ "ManualUpdateDesiredArmLocation", ManualUpdateDesiredArmLocation },
	{ "IsTransiting", IsTransiting },
	{ "GetTransitingRotator", GetTransitingRotator },
	{ "GetTargetOriginLocation", GetTargetOriginLocation },
	{ "GetMinMaxDist", GetMinMaxDist },
	{ "GetCameraLagSpeed", GetCameraLagSpeed },
	{ "GetCameraLagDistance", GetCameraLagDistance },
	{ "AdjustArmLengthDelta", AdjustArmLengthDelta },
	{ "Get_lockNearDeviationAngle", Get_lockNearDeviationAngle },
	{ "Set_lockNearDeviationAngle", Set_lockNearDeviationAngle },
	{ "Get_lockFarDeviationAngle", Get_lockFarDeviationAngle },
	{ "Set_lockFarDeviationAngle", Set_lockFarDeviationAngle },
	{ "Get_lockNearDistance", Get_lockNearDistance },
	{ "Set_lockNearDistance", Set_lockNearDistance },
	{ "Get_lockFarDistance", Get_lockFarDistance },
	{ "Set_lockFarDistance", Set_lockFarDistance },
	{ "Get_LockSmoothTransitionAccelerator", Get_LockSmoothTransitionAccelerator },
	{ "Set_LockSmoothTransitionAccelerator", Set_LockSmoothTransitionAccelerator },
	{ "Get_LockSmoothTransitionMaxSpeed", Get_LockSmoothTransitionMaxSpeed },
	{ "Set_LockSmoothTransitionMaxSpeed", Set_LockSmoothTransitionMaxSpeed },
	{ "Get_lockRecommendMaxPitch", Get_lockRecommendMaxPitch },
	{ "Set_lockRecommendMaxPitch", Set_lockRecommendMaxPitch },
	{ "Get_lockRecommendMinPitch", Get_lockRecommendMinPitch },
	{ "Set_lockRecommendMinPitch", Set_lockRecommendMinPitch },
	{ "Get_AutoSmoothTransitionAccelerator", Get_AutoSmoothTransitionAccelerator },
	{ "Set_AutoSmoothTransitionAccelerator", Set_AutoSmoothTransitionAccelerator },
	{ "Get_AutoSmoothTransitionMaxSpeed", Get_AutoSmoothTransitionMaxSpeed },
	{ "Set_AutoSmoothTransitionMaxSpeed", Set_AutoSmoothTransitionMaxSpeed },
	{ "Get_AutoFixedPitch", Get_AutoFixedPitch },
	{ "Set_AutoFixedPitch", Set_AutoFixedPitch },
	{ "Get_enableAutoFixedPitch", Get_enableAutoFixedPitch },
	{ "Set_enableAutoFixedPitch", Set_enableAutoFixedPitch },
	{ "Get_bDoTerrainCollisionTest", Get_bDoTerrainCollisionTest },
	{ "Set_bDoTerrainCollisionTest", Set_bDoTerrainCollisionTest },
	{ "Get_TerrainProbeSize", Get_TerrainProbeSize },
	{ "Set_TerrainProbeSize", Set_TerrainProbeSize },
	{ "Get_bEnableXRayVision", Get_bEnableXRayVision },
	{ "Set_bEnableXRayVision", Set_bEnableXRayVision },
	{ "Get_XRayProbeSize", Get_XRayProbeSize },
	{ "Set_XRayProbeSize", Set_XRayProbeSize },
	{ "Get_XRayMaterial", Get_XRayMaterial },
	{ "Set_XRayMaterial", Set_XRayMaterial },
	{ "Get_bXRayTransition", Get_bXRayTransition },
	{ "Set_bXRayTransition", Set_bXRayTransition },
	{ "Get_XRayTransitionPropName", Get_XRayTransitionPropName },
	{ "Set_XRayTransitionPropName", Set_XRayTransitionPropName },
	{ "Get_XRayTransitionBeginValue", Get_XRayTransitionBeginValue },
	{ "Set_XRayTransitionBeginValue", Set_XRayTransitionBeginValue },
	{ "Get_XRayTransitionEndValue", Get_XRayTransitionEndValue },
	{ "Set_XRayTransitionEndValue", Set_XRayTransitionEndValue },
	{ "Get_XRayTransitionTime", Get_XRayTransitionTime },
	{ "Set_XRayTransitionTime", Set_XRayTransitionTime },
	{ "Get_bEnableArmLengthLag", Get_bEnableArmLengthLag },
	{ "Set_bEnableArmLengthLag", Set_bEnableArmLengthLag },
	{ "Get_bArmLengthLag_Constant", Get_bArmLengthLag_Constant },
	{ "Set_bArmLengthLag_Constant", Set_bArmLengthLag_Constant },
	{ "Get_CameraArmLengthLagSpeed", Get_CameraArmLengthLagSpeed },
	{ "Set_CameraArmLengthLagSpeed", Set_CameraArmLengthLagSpeed },
	{ "Get_bEnableSocketOffsetLag", Get_bEnableSocketOffsetLag },
	{ "Set_bEnableSocketOffsetLag", Set_bEnableSocketOffsetLag },
	{ "Get_bSocketOffsetLag_Constant", Get_bSocketOffsetLag_Constant },
	{ "Set_bSocketOffsetLag_Constant", Set_bSocketOffsetLag_Constant },
	{ "Get_SocketOffsetLagSpeed", Get_SocketOffsetLagSpeed },
	{ "Set_SocketOffsetLagSpeed", Set_SocketOffsetLagSpeed },
	{ "Get_BreakLagArmLengthThreshold", Get_BreakLagArmLengthThreshold },
	{ "Set_BreakLagArmLengthThreshold", Set_BreakLagArmLengthThreshold },
	{ "Get_suspend", Get_suspend },
	{ "Set_suspend", Set_suspend },
	{ "Get_bEnableLagSmooth", Get_bEnableLagSmooth },
	{ "Set_bEnableLagSmooth", Set_bEnableLagSmooth },
	{ "Get_LagLocationSmoothSpeed", Get_LagLocationSmoothSpeed },
	{ "Set_LagLocationSmoothSpeed", Set_LagLocationSmoothSpeed },
	{ "Get_bEnableTraceLocLag", Get_bEnableTraceLocLag },
	{ "Set_bEnableTraceLocLag", Set_bEnableTraceLocLag },
	{ "Get_LagTraceDisThreshold", Get_LagTraceDisThreshold },
	{ "Set_LagTraceDisThreshold", Set_LagTraceDisThreshold },
	{ "is_nil", wLua::LuaStatic::isnil },
	{ "__gc", wLua::LuaStatic::removeUClassFrameCache },
	{ NULL, NULL }
};

void Register(lua_State *InScriptContext)
{
	lua_newtable(InScriptContext);
	luaL_register(InScriptContext, NULL, Lib_Funcs);
	AzureHelpFuncs::AuxRegister(InScriptContext, "ECCameraSpringArmComponent");
}
void SetMtLink(lua_State *InScriptContext)
{
	AzureHelpFuncs::AuxSetMtLink(InScriptContext, "ECCameraSpringArmComponent", "SpringArmComponent",USERDATATYPE_UOBJECT);
}

}