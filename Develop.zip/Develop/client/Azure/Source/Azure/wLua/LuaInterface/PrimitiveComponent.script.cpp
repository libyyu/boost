#include "Azure.h"
#include "Utility/help_funcs.h"
#include "wLua/UObjectHeaders.h"
#include "Components/PrimitiveComponent.h"
#include "AzureLuaIntegration.h"

namespace LuaPrimitiveComponent
{
int32 GetSquaredDistanceToCollision(lua_State*);
int32 GetCollisionShape(lua_State*);
int32 PutAllRigidBodiesToSleep(lua_State*);
int32 LineTraceComponent(lua_State*);

int32 WakeRigidBody(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PrimitiveComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PrimitiveComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FName BoneName;
	} Params;
	Params.BoneName = lua_isnoneornil(InScriptContext,2) ? FName(TEXT("")) : FName(UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 2)));
#if UE_GAME
	UPrimitiveComponent * This = (UPrimitiveComponent *)Obj;
	This->WakeRigidBody(Params.BoneName);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("WakeRigidBody"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FName*)(params.GetStructMemory() + 0) = Params.BoneName;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.BoneName = *(FName*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 WakeAllRigidBodies(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PrimitiveComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PrimitiveComponent must be non-null"); lua_error(InScriptContext);  return 0;}
#if UE_GAME
	UPrimitiveComponent * This = (UPrimitiveComponent *)Obj;
	This->WakeAllRigidBodies();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("WakeAllRigidBodies"));
	if(!Function) { check(false); return 0;}
	Obj->ProcessEvent(Function, NULL);
#endif
	return 0;
}

int32 SetUseCCD(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PrimitiveComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PrimitiveComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool InUseCCD;
		FName BoneName;
	} Params;
	Params.InUseCCD = !!(lua_toboolean(InScriptContext, 2));
	Params.BoneName = lua_isnoneornil(InScriptContext,3) ? FName(TEXT("")) : FName(UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 3)));
#if UE_GAME
	UPrimitiveComponent * This = (UPrimitiveComponent *)Obj;
	This->SetUseCCD(Params.InUseCCD,Params.BoneName);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetUseCCD"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(bool*)(params.GetStructMemory() + 0) = Params.InUseCCD;
		*(FName*)(params.GetStructMemory() + 4) = Params.BoneName;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.InUseCCD = *(bool*)(params.GetStructMemory() + 0);
		Params.BoneName = *(FName*)(params.GetStructMemory() + 4);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetTranslucentSortPriority(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PrimitiveComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PrimitiveComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		int32 NewTranslucentSortPriority;
	} Params;
	Params.NewTranslucentSortPriority = (luaL_checkint(InScriptContext, 2));
#if UE_GAME
	UPrimitiveComponent * This = (UPrimitiveComponent *)Obj;
	This->SetTranslucentSortPriority(Params.NewTranslucentSortPriority);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetTranslucentSortPriority"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(int32*)(params.GetStructMemory() + 0) = Params.NewTranslucentSortPriority;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.NewTranslucentSortPriority = *(int32*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetSingleSampleShadowFromStationaryLights(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PrimitiveComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PrimitiveComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool bNewSingleSampleShadowFromStationaryLights;
	} Params;
	Params.bNewSingleSampleShadowFromStationaryLights = !!(lua_toboolean(InScriptContext, 2));
#if UE_GAME
	UPrimitiveComponent * This = (UPrimitiveComponent *)Obj;
	This->SetSingleSampleShadowFromStationaryLights(Params.bNewSingleSampleShadowFromStationaryLights);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetSingleSampleShadowFromStationaryLights"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(bool*)(params.GetStructMemory() + 0) = Params.bNewSingleSampleShadowFromStationaryLights;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.bNewSingleSampleShadowFromStationaryLights = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetSimulatePhysics(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PrimitiveComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PrimitiveComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool bSimulate;
	} Params;
	Params.bSimulate = !!(lua_toboolean(InScriptContext, 2));
#if UE_GAME
	UPrimitiveComponent * This = (UPrimitiveComponent *)Obj;
	This->SetSimulatePhysics(Params.bSimulate);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetSimulatePhysics"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(bool*)(params.GetStructMemory() + 0) = Params.bSimulate;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.bSimulate = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetRenderInMono(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PrimitiveComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PrimitiveComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool bValue;
	} Params;
	Params.bValue = !!(lua_toboolean(InScriptContext, 2));
#if UE_GAME
	UPrimitiveComponent * This = (UPrimitiveComponent *)Obj;
	This->SetRenderInMono(Params.bValue);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetRenderInMono"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(bool*)(params.GetStructMemory() + 0) = Params.bValue;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.bValue = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetRenderInMainPass(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PrimitiveComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PrimitiveComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool bValue;
	} Params;
	Params.bValue = !!(lua_toboolean(InScriptContext, 2));
#if UE_GAME
	UPrimitiveComponent * This = (UPrimitiveComponent *)Obj;
	This->SetRenderInMainPass(Params.bValue);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetRenderInMainPass"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(bool*)(params.GetStructMemory() + 0) = Params.bValue;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.bValue = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetRenderCustomDepth(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PrimitiveComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PrimitiveComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool bValue;
	} Params;
	Params.bValue = !!(lua_toboolean(InScriptContext, 2));
#if UE_GAME
	UPrimitiveComponent * This = (UPrimitiveComponent *)Obj;
	This->SetRenderCustomDepth(Params.bValue);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetRenderCustomDepth"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(bool*)(params.GetStructMemory() + 0) = Params.bValue;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.bValue = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetRenderAzureDistortion(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PrimitiveComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PrimitiveComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool bValue;
	} Params;
	Params.bValue = !!(lua_toboolean(InScriptContext, 2));
#if UE_GAME
	UPrimitiveComponent * This = (UPrimitiveComponent *)Obj;
	This->SetRenderAzureDistortion(Params.bValue);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetRenderAzureDistortion"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(bool*)(params.GetStructMemory() + 0) = Params.bValue;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.bValue = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetReceivesDecals(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PrimitiveComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PrimitiveComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool bNewReceivesDecals;
	} Params;
	Params.bNewReceivesDecals = !!(lua_toboolean(InScriptContext, 2));
#if UE_GAME
	UPrimitiveComponent * This = (UPrimitiveComponent *)Obj;
	This->SetReceivesDecals(Params.bNewReceivesDecals);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetReceivesDecals"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(bool*)(params.GetStructMemory() + 0) = Params.bNewReceivesDecals;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.bNewReceivesDecals = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetReceiveCSMShadows(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PrimitiveComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PrimitiveComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool bValue;
	} Params;
	Params.bValue = !!(lua_toboolean(InScriptContext, 2));
#if UE_GAME
	UPrimitiveComponent * This = (UPrimitiveComponent *)Obj;
	This->SetReceiveCSMShadows(Params.bValue);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetReceiveCSMShadows"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(bool*)(params.GetStructMemory() + 0) = Params.bValue;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.bValue = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetPhysMaterialOverride(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PrimitiveComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PrimitiveComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		UPhysicalMaterial* NewPhysMaterial = nullptr;
	} Params;
	Params.NewPhysMaterial = (UPhysicalMaterial*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"PhysicalMaterial");;
#if UE_GAME
	UPrimitiveComponent * This = (UPrimitiveComponent *)Obj;
	This->SetPhysMaterialOverride(Params.NewPhysMaterial);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetPhysMaterialOverride"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(UPhysicalMaterial**)(params.GetStructMemory() + 0) = Params.NewPhysMaterial;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.NewPhysMaterial = *(UPhysicalMaterial**)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetPhysicsMaxAngularVelocityInRadians(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PrimitiveComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PrimitiveComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float NewMaxAngVel;
		bool bAddToCurrent;
		FName BoneName;
	} Params;
	Params.NewMaxAngVel = (float)(luaL_checknumber(InScriptContext, 2));
	Params.bAddToCurrent = lua_isnoneornil(InScriptContext,3) ? bool(false) : !!(lua_toboolean(InScriptContext, 3));
	Params.BoneName = lua_isnoneornil(InScriptContext,4) ? FName(TEXT("")) : FName(UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 4)));
#if UE_GAME
	UPrimitiveComponent * This = (UPrimitiveComponent *)Obj;
	This->SetPhysicsMaxAngularVelocityInRadians(Params.NewMaxAngVel,Params.bAddToCurrent,Params.BoneName);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetPhysicsMaxAngularVelocityInRadians"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(float*)(params.GetStructMemory() + 0) = Params.NewMaxAngVel;
		*(bool*)(params.GetStructMemory() + 4) = Params.bAddToCurrent;
		*(FName*)(params.GetStructMemory() + 8) = Params.BoneName;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.NewMaxAngVel = *(float*)(params.GetStructMemory() + 0);
		Params.bAddToCurrent = *(bool*)(params.GetStructMemory() + 4);
		Params.BoneName = *(FName*)(params.GetStructMemory() + 8);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetPhysicsMaxAngularVelocityInDegrees(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PrimitiveComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PrimitiveComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float NewMaxAngVel;
		bool bAddToCurrent;
		FName BoneName;
	} Params;
	Params.NewMaxAngVel = (float)(luaL_checknumber(InScriptContext, 2));
	Params.bAddToCurrent = lua_isnoneornil(InScriptContext,3) ? bool(false) : !!(lua_toboolean(InScriptContext, 3));
	Params.BoneName = lua_isnoneornil(InScriptContext,4) ? FName(TEXT("")) : FName(UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 4)));
#if UE_GAME
	UPrimitiveComponent * This = (UPrimitiveComponent *)Obj;
	This->SetPhysicsMaxAngularVelocityInDegrees(Params.NewMaxAngVel,Params.bAddToCurrent,Params.BoneName);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetPhysicsMaxAngularVelocityInDegrees"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(float*)(params.GetStructMemory() + 0) = Params.NewMaxAngVel;
		*(bool*)(params.GetStructMemory() + 4) = Params.bAddToCurrent;
		*(FName*)(params.GetStructMemory() + 8) = Params.BoneName;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.NewMaxAngVel = *(float*)(params.GetStructMemory() + 0);
		Params.bAddToCurrent = *(bool*)(params.GetStructMemory() + 4);
		Params.BoneName = *(FName*)(params.GetStructMemory() + 8);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetPhysicsLinearVelocity(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PrimitiveComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PrimitiveComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FVector NewVel;
		bool bAddToCurrent;
		FName BoneName;
	} Params;
	Params.NewVel = (wLua::FLuaVector::Get(InScriptContext, 2));
	Params.bAddToCurrent = lua_isnoneornil(InScriptContext,3) ? bool(false) : !!(lua_toboolean(InScriptContext, 3));
	Params.BoneName = lua_isnoneornil(InScriptContext,4) ? FName(TEXT("")) : FName(UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 4)));
#if UE_GAME
	UPrimitiveComponent * This = (UPrimitiveComponent *)Obj;
	This->SetPhysicsLinearVelocity(Params.NewVel,Params.bAddToCurrent,Params.BoneName);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetPhysicsLinearVelocity"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FVector*)(params.GetStructMemory() + 0) = Params.NewVel;
		*(bool*)(params.GetStructMemory() + 12) = Params.bAddToCurrent;
		*(FName*)(params.GetStructMemory() + 16) = Params.BoneName;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.NewVel = *(FVector*)(params.GetStructMemory() + 0);
		Params.bAddToCurrent = *(bool*)(params.GetStructMemory() + 12);
		Params.BoneName = *(FName*)(params.GetStructMemory() + 16);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetPhysicsAngularVelocityInRadians(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PrimitiveComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PrimitiveComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FVector NewAngVel;
		bool bAddToCurrent;
		FName BoneName;
	} Params;
	Params.NewAngVel = (wLua::FLuaVector::Get(InScriptContext, 2));
	Params.bAddToCurrent = lua_isnoneornil(InScriptContext,3) ? bool(false) : !!(lua_toboolean(InScriptContext, 3));
	Params.BoneName = lua_isnoneornil(InScriptContext,4) ? FName(TEXT("")) : FName(UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 4)));
#if UE_GAME
	UPrimitiveComponent * This = (UPrimitiveComponent *)Obj;
	This->SetPhysicsAngularVelocityInRadians(Params.NewAngVel,Params.bAddToCurrent,Params.BoneName);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetPhysicsAngularVelocityInRadians"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FVector*)(params.GetStructMemory() + 0) = Params.NewAngVel;
		*(bool*)(params.GetStructMemory() + 12) = Params.bAddToCurrent;
		*(FName*)(params.GetStructMemory() + 16) = Params.BoneName;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.NewAngVel = *(FVector*)(params.GetStructMemory() + 0);
		Params.bAddToCurrent = *(bool*)(params.GetStructMemory() + 12);
		Params.BoneName = *(FName*)(params.GetStructMemory() + 16);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetPhysicsAngularVelocityInDegrees(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PrimitiveComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PrimitiveComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FVector NewAngVel;
		bool bAddToCurrent;
		FName BoneName;
	} Params;
	Params.NewAngVel = (wLua::FLuaVector::Get(InScriptContext, 2));
	Params.bAddToCurrent = lua_isnoneornil(InScriptContext,3) ? bool(false) : !!(lua_toboolean(InScriptContext, 3));
	Params.BoneName = lua_isnoneornil(InScriptContext,4) ? FName(TEXT("")) : FName(UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 4)));
#if UE_GAME
	UPrimitiveComponent * This = (UPrimitiveComponent *)Obj;
	This->SetPhysicsAngularVelocityInDegrees(Params.NewAngVel,Params.bAddToCurrent,Params.BoneName);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetPhysicsAngularVelocityInDegrees"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FVector*)(params.GetStructMemory() + 0) = Params.NewAngVel;
		*(bool*)(params.GetStructMemory() + 12) = Params.bAddToCurrent;
		*(FName*)(params.GetStructMemory() + 16) = Params.BoneName;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.NewAngVel = *(FVector*)(params.GetStructMemory() + 0);
		Params.bAddToCurrent = *(bool*)(params.GetStructMemory() + 12);
		Params.BoneName = *(FName*)(params.GetStructMemory() + 16);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetOwnerNoSee(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PrimitiveComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PrimitiveComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool bNewOwnerNoSee;
	} Params;
	Params.bNewOwnerNoSee = !!(lua_toboolean(InScriptContext, 2));
#if UE_GAME
	UPrimitiveComponent * This = (UPrimitiveComponent *)Obj;
	This->SetOwnerNoSee(Params.bNewOwnerNoSee);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetOwnerNoSee"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(bool*)(params.GetStructMemory() + 0) = Params.bNewOwnerNoSee;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.bNewOwnerNoSee = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetOnlyOwnerSee(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PrimitiveComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PrimitiveComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool bNewOnlyOwnerSee;
	} Params;
	Params.bNewOnlyOwnerSee = !!(lua_toboolean(InScriptContext, 2));
#if UE_GAME
	UPrimitiveComponent * This = (UPrimitiveComponent *)Obj;
	This->SetOnlyOwnerSee(Params.bNewOnlyOwnerSee);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetOnlyOwnerSee"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(bool*)(params.GetStructMemory() + 0) = Params.bNewOnlyOwnerSee;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.bNewOnlyOwnerSee = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetNotifyRigidBodyCollision(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PrimitiveComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PrimitiveComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool bNewNotifyRigidBodyCollision;
	} Params;
	Params.bNewNotifyRigidBodyCollision = !!(lua_toboolean(InScriptContext, 2));
#if UE_GAME
	UPrimitiveComponent * This = (UPrimitiveComponent *)Obj;
	This->SetNotifyRigidBodyCollision(Params.bNewNotifyRigidBodyCollision);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetNotifyRigidBodyCollision"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(bool*)(params.GetStructMemory() + 0) = Params.bNewNotifyRigidBodyCollision;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.bNewNotifyRigidBodyCollision = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetMaterialQualityLevel(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PrimitiveComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PrimitiveComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		TEnumAsByte<EMaterialQualityLevel::Type> QualityLevel;
		bool bForce;
		bool bNoRemap;
		bool ReturnValue;
	} Params;
	Params.QualityLevel = (TEnumAsByte<EMaterialQualityLevel::Type>)(luaL_checkint(InScriptContext, 2));
	Params.bForce = lua_isnoneornil(InScriptContext,3) ? bool(false) : !!(lua_toboolean(InScriptContext, 3));
	Params.bNoRemap = lua_isnoneornil(InScriptContext,4) ? bool(false) : !!(lua_toboolean(InScriptContext, 4));
#if UE_GAME
	UPrimitiveComponent * This = (UPrimitiveComponent *)Obj;
	Params.ReturnValue = This->SetMaterialQualityLevel(Params.QualityLevel,Params.bForce,Params.bNoRemap);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetMaterialQualityLevel"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(TEnumAsByte<EMaterialQualityLevel::Type>*)(params.GetStructMemory() + 0) = Params.QualityLevel;
		*(bool*)(params.GetStructMemory() + 1) = Params.bForce;
		*(bool*)(params.GetStructMemory() + 2) = Params.bNoRemap;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.QualityLevel = *(TEnumAsByte<EMaterialQualityLevel::Type>*)(params.GetStructMemory() + 0);
		Params.bForce = *(bool*)(params.GetStructMemory() + 1);
		Params.bNoRemap = *(bool*)(params.GetStructMemory() + 2);
		Params.ReturnValue = *(bool*)(params.GetStructMemory() + 3);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushboolean(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 SetMaterialByName(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PrimitiveComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PrimitiveComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FName MaterialSlotName;
		UMaterialInterface* Material = nullptr;
	} Params;
	Params.MaterialSlotName = FName(UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 2)));
	Params.Material = (UMaterialInterface*)wLua::FLuaUtils::GetUObject(InScriptContext,3,"MaterialInterface");;
#if UE_GAME
	UPrimitiveComponent * This = (UPrimitiveComponent *)Obj;
	This->SetMaterialByName(Params.MaterialSlotName,Params.Material);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetMaterialByName"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FName*)(params.GetStructMemory() + 0) = Params.MaterialSlotName;
		*(UMaterialInterface**)(params.GetStructMemory() + 16) = Params.Material;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.MaterialSlotName = *(FName*)(params.GetStructMemory() + 0);
		Params.Material = *(UMaterialInterface**)(params.GetStructMemory() + 16);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetMaterial(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PrimitiveComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PrimitiveComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		int32 ElementIndex;
		UMaterialInterface* Material = nullptr;
	} Params;
	Params.ElementIndex = (luaL_checkint(InScriptContext, 2));
	Params.Material = (UMaterialInterface*)wLua::FLuaUtils::GetUObject(InScriptContext,3,"MaterialInterface");;
#if UE_GAME
	UPrimitiveComponent * This = (UPrimitiveComponent *)Obj;
	This->SetMaterial(Params.ElementIndex,Params.Material);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetMaterial"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(int32*)(params.GetStructMemory() + 0) = Params.ElementIndex;
		*(UMaterialInterface**)(params.GetStructMemory() + 8) = Params.Material;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ElementIndex = *(int32*)(params.GetStructMemory() + 0);
		Params.Material = *(UMaterialInterface**)(params.GetStructMemory() + 8);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetMassScale(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PrimitiveComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PrimitiveComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FName BoneName;
		float InMassScale;
	} Params;
	Params.BoneName = lua_isnoneornil(InScriptContext,2) ? FName(TEXT("")) : FName(UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 2)));
	Params.InMassScale = lua_isnoneornil(InScriptContext,3) ? float(1.000000) : (float)(luaL_checknumber(InScriptContext, 3));
#if UE_GAME
	UPrimitiveComponent * This = (UPrimitiveComponent *)Obj;
	This->SetMassScale(Params.BoneName,Params.InMassScale);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetMassScale"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FName*)(params.GetStructMemory() + 0) = Params.BoneName;
		*(float*)(params.GetStructMemory() + 12) = Params.InMassScale;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.BoneName = *(FName*)(params.GetStructMemory() + 0);
		Params.InMassScale = *(float*)(params.GetStructMemory() + 12);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetMassOverrideInKg(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PrimitiveComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PrimitiveComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FName BoneName;
		float MassInKg;
		bool bOverrideMass;
	} Params;
	Params.BoneName = lua_isnoneornil(InScriptContext,2) ? FName(TEXT("")) : FName(UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 2)));
	Params.MassInKg = lua_isnoneornil(InScriptContext,3) ? float(1.000000) : (float)(luaL_checknumber(InScriptContext, 3));
	Params.bOverrideMass = lua_isnoneornil(InScriptContext,4) ? bool(true) : !!(lua_toboolean(InScriptContext, 4));
#if UE_GAME
	UPrimitiveComponent * This = (UPrimitiveComponent *)Obj;
	This->SetMassOverrideInKg(Params.BoneName,Params.MassInKg,Params.bOverrideMass);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetMassOverrideInKg"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FName*)(params.GetStructMemory() + 0) = Params.BoneName;
		*(float*)(params.GetStructMemory() + 12) = Params.MassInKg;
		*(bool*)(params.GetStructMemory() + 16) = Params.bOverrideMass;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.BoneName = *(FName*)(params.GetStructMemory() + 0);
		Params.MassInKg = *(float*)(params.GetStructMemory() + 12);
		Params.bOverrideMass = *(bool*)(params.GetStructMemory() + 16);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetLinearDamping(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PrimitiveComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PrimitiveComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float InDamping;
	} Params;
	Params.InDamping = (float)(luaL_checknumber(InScriptContext, 2));
#if UE_GAME
	UPrimitiveComponent * This = (UPrimitiveComponent *)Obj;
	This->SetLinearDamping(Params.InDamping);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetLinearDamping"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(float*)(params.GetStructMemory() + 0) = Params.InDamping;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.InDamping = *(float*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetGenerateOverlapEvents(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PrimitiveComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PrimitiveComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool bInGenerateOverlapEvents;
	} Params;
	Params.bInGenerateOverlapEvents = !!(lua_toboolean(InScriptContext, 2));
#if UE_GAME
	UPrimitiveComponent * This = (UPrimitiveComponent *)Obj;
	This->SetGenerateOverlapEvents(Params.bInGenerateOverlapEvents);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetGenerateOverlapEvents"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(bool*)(params.GetStructMemory() + 0) = Params.bInGenerateOverlapEvents;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.bInGenerateOverlapEvents = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetEnableGravity(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PrimitiveComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PrimitiveComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool bGravityEnabled;
	} Params;
	Params.bGravityEnabled = !!(lua_toboolean(InScriptContext, 2));
#if UE_GAME
	UPrimitiveComponent * This = (UPrimitiveComponent *)Obj;
	This->SetEnableGravity(Params.bGravityEnabled);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetEnableGravity"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(bool*)(params.GetStructMemory() + 0) = Params.bGravityEnabled;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.bGravityEnabled = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetCustomDepthStencilWriteMask(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PrimitiveComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PrimitiveComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		ERendererStencilMask WriteMaskBit;
	} Params;
	Params.WriteMaskBit = (ERendererStencilMask)(luaL_checkint(InScriptContext, 2));
#if UE_GAME
	UPrimitiveComponent * This = (UPrimitiveComponent *)Obj;
	This->SetCustomDepthStencilWriteMask(Params.WriteMaskBit);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetCustomDepthStencilWriteMask"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(ERendererStencilMask*)(params.GetStructMemory() + 0) = Params.WriteMaskBit;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.WriteMaskBit = *(ERendererStencilMask*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetCustomDepthStencilValue(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PrimitiveComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PrimitiveComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		int32 Value;
	} Params;
	Params.Value = (luaL_checkint(InScriptContext, 2));
#if UE_GAME
	UPrimitiveComponent * This = (UPrimitiveComponent *)Obj;
	This->SetCustomDepthStencilValue(Params.Value);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetCustomDepthStencilValue"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(int32*)(params.GetStructMemory() + 0) = Params.Value;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.Value = *(int32*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetCullDistance(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PrimitiveComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PrimitiveComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float NewCullDistance;
	} Params;
	Params.NewCullDistance = (float)(luaL_checknumber(InScriptContext, 2));
#if UE_GAME
	UPrimitiveComponent * This = (UPrimitiveComponent *)Obj;
	This->SetCullDistance(Params.NewCullDistance);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetCullDistance"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(float*)(params.GetStructMemory() + 0) = Params.NewCullDistance;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.NewCullDistance = *(float*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetConstraintMode(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PrimitiveComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PrimitiveComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		TEnumAsByte<EDOFMode::Type> ConstraintMode;
	} Params;
	Params.ConstraintMode = (TEnumAsByte<EDOFMode::Type>)(luaL_checkint(InScriptContext, 2));
#if UE_GAME
	UPrimitiveComponent * This = (UPrimitiveComponent *)Obj;
	This->SetConstraintMode(Params.ConstraintMode);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetConstraintMode"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(TEnumAsByte<EDOFMode::Type>*)(params.GetStructMemory() + 0) = Params.ConstraintMode;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ConstraintMode = *(TEnumAsByte<EDOFMode::Type>*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetCollisionResponseToChannel(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PrimitiveComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PrimitiveComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		TEnumAsByte<ECollisionChannel> Channel;
		TEnumAsByte<ECollisionResponse> NewResponse;
	} Params;
	Params.Channel = (TEnumAsByte<ECollisionChannel>)(luaL_checkint(InScriptContext, 2));
	Params.NewResponse = (TEnumAsByte<ECollisionResponse>)(luaL_checkint(InScriptContext, 3));
#if UE_GAME
	UPrimitiveComponent * This = (UPrimitiveComponent *)Obj;
	This->SetCollisionResponseToChannel(Params.Channel,Params.NewResponse);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetCollisionResponseToChannel"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(TEnumAsByte<ECollisionChannel>*)(params.GetStructMemory() + 0) = Params.Channel;
		*(TEnumAsByte<ECollisionResponse>*)(params.GetStructMemory() + 1) = Params.NewResponse;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.Channel = *(TEnumAsByte<ECollisionChannel>*)(params.GetStructMemory() + 0);
		Params.NewResponse = *(TEnumAsByte<ECollisionResponse>*)(params.GetStructMemory() + 1);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetCollisionResponseToAllChannels(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PrimitiveComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PrimitiveComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		TEnumAsByte<ECollisionResponse> NewResponse;
	} Params;
	Params.NewResponse = (TEnumAsByte<ECollisionResponse>)(luaL_checkint(InScriptContext, 2));
#if UE_GAME
	UPrimitiveComponent * This = (UPrimitiveComponent *)Obj;
	This->SetCollisionResponseToAllChannels(Params.NewResponse);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetCollisionResponseToAllChannels"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(TEnumAsByte<ECollisionResponse>*)(params.GetStructMemory() + 0) = Params.NewResponse;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.NewResponse = *(TEnumAsByte<ECollisionResponse>*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetCollisionProfileName(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PrimitiveComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PrimitiveComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FName InCollisionProfileName;
	} Params;
	Params.InCollisionProfileName = FName(UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 2)));
#if UE_GAME
	UPrimitiveComponent * This = (UPrimitiveComponent *)Obj;
	This->SetCollisionProfileName(Params.InCollisionProfileName);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetCollisionProfileName"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FName*)(params.GetStructMemory() + 0) = Params.InCollisionProfileName;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.InCollisionProfileName = *(FName*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetCollisionObjectType(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PrimitiveComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PrimitiveComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		TEnumAsByte<ECollisionChannel> Channel;
	} Params;
	Params.Channel = (TEnumAsByte<ECollisionChannel>)(luaL_checkint(InScriptContext, 2));
#if UE_GAME
	UPrimitiveComponent * This = (UPrimitiveComponent *)Obj;
	This->SetCollisionObjectType(Params.Channel);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetCollisionObjectType"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(TEnumAsByte<ECollisionChannel>*)(params.GetStructMemory() + 0) = Params.Channel;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.Channel = *(TEnumAsByte<ECollisionChannel>*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetCollisionEnabled(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PrimitiveComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PrimitiveComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		TEnumAsByte<ECollisionEnabled::Type> NewType;
	} Params;
	Params.NewType = (TEnumAsByte<ECollisionEnabled::Type>)(luaL_checkint(InScriptContext, 2));
#if UE_GAME
	UPrimitiveComponent * This = (UPrimitiveComponent *)Obj;
	This->SetCollisionEnabled(Params.NewType);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetCollisionEnabled"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(TEnumAsByte<ECollisionEnabled::Type>*)(params.GetStructMemory() + 0) = Params.NewType;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.NewType = *(TEnumAsByte<ECollisionEnabled::Type>*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetCenterOfMass(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PrimitiveComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PrimitiveComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FVector CenterOfMassOffset;
		FName BoneName;
	} Params;
	Params.CenterOfMassOffset = (wLua::FLuaVector::Get(InScriptContext, 2));
	Params.BoneName = lua_isnoneornil(InScriptContext,3) ? FName(TEXT("")) : FName(UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 3)));
#if UE_GAME
	UPrimitiveComponent * This = (UPrimitiveComponent *)Obj;
	This->SetCenterOfMass(Params.CenterOfMassOffset,Params.BoneName);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetCenterOfMass"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FVector*)(params.GetStructMemory() + 0) = Params.CenterOfMassOffset;
		*(FName*)(params.GetStructMemory() + 12) = Params.BoneName;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.CenterOfMassOffset = *(FVector*)(params.GetStructMemory() + 0);
		Params.BoneName = *(FName*)(params.GetStructMemory() + 12);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetCastShadow(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PrimitiveComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PrimitiveComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool NewCastShadow;
	} Params;
	Params.NewCastShadow = !!(lua_toboolean(InScriptContext, 2));
#if UE_GAME
	UPrimitiveComponent * This = (UPrimitiveComponent *)Obj;
	This->SetCastShadow(Params.NewCastShadow);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetCastShadow"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(bool*)(params.GetStructMemory() + 0) = Params.NewCastShadow;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.NewCastShadow = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetBoundsScale(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PrimitiveComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PrimitiveComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float NewBoundsScale;
	} Params;
	Params.NewBoundsScale = lua_isnoneornil(InScriptContext,2) ? float(1.000000) : (float)(luaL_checknumber(InScriptContext, 2));
#if UE_GAME
	UPrimitiveComponent * This = (UPrimitiveComponent *)Obj;
	This->SetBoundsScale(Params.NewBoundsScale);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetBoundsScale"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(float*)(params.GetStructMemory() + 0) = Params.NewBoundsScale;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.NewBoundsScale = *(float*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetAngularDamping(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PrimitiveComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PrimitiveComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float InDamping;
	} Params;
	Params.InDamping = (float)(luaL_checknumber(InScriptContext, 2));
#if UE_GAME
	UPrimitiveComponent * This = (UPrimitiveComponent *)Obj;
	This->SetAngularDamping(Params.InDamping);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetAngularDamping"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(float*)(params.GetStructMemory() + 0) = Params.InDamping;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.InDamping = *(float*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetAllUseCCD(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PrimitiveComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PrimitiveComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool InUseCCD;
	} Params;
	Params.InUseCCD = !!(lua_toboolean(InScriptContext, 2));
#if UE_GAME
	UPrimitiveComponent * This = (UPrimitiveComponent *)Obj;
	This->SetAllUseCCD(Params.InUseCCD);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetAllUseCCD"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(bool*)(params.GetStructMemory() + 0) = Params.InUseCCD;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.InUseCCD = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetAllPhysicsLinearVelocity(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PrimitiveComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PrimitiveComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FVector NewVel;
		bool bAddToCurrent;
	} Params;
	Params.NewVel = (wLua::FLuaVector::Get(InScriptContext, 2));
	Params.bAddToCurrent = lua_isnoneornil(InScriptContext,3) ? bool(false) : !!(lua_toboolean(InScriptContext, 3));
#if UE_GAME
	UPrimitiveComponent * This = (UPrimitiveComponent *)Obj;
	This->SetAllPhysicsLinearVelocity(Params.NewVel,Params.bAddToCurrent);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetAllPhysicsLinearVelocity"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FVector*)(params.GetStructMemory() + 0) = Params.NewVel;
		*(bool*)(params.GetStructMemory() + 12) = Params.bAddToCurrent;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.NewVel = *(FVector*)(params.GetStructMemory() + 0);
		Params.bAddToCurrent = *(bool*)(params.GetStructMemory() + 12);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetAllPhysicsAngularVelocityInRadians(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PrimitiveComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PrimitiveComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FVector NewAngVel;
		bool bAddToCurrent;
	} Params;
	Params.NewAngVel = (wLua::FLuaVector::Get(InScriptContext, 2));
	Params.bAddToCurrent = lua_isnoneornil(InScriptContext,3) ? bool(false) : !!(lua_toboolean(InScriptContext, 3));
#if UE_GAME
	UPrimitiveComponent * This = (UPrimitiveComponent *)Obj;
	This->SetAllPhysicsAngularVelocityInRadians(Params.NewAngVel,Params.bAddToCurrent);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetAllPhysicsAngularVelocityInRadians"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FVector*)(params.GetStructMemory() + 0) = Params.NewAngVel;
		*(bool*)(params.GetStructMemory() + 12) = Params.bAddToCurrent;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.NewAngVel = *(FVector*)(params.GetStructMemory() + 0);
		Params.bAddToCurrent = *(bool*)(params.GetStructMemory() + 12);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetAllPhysicsAngularVelocityInDegrees(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PrimitiveComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PrimitiveComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FVector NewAngVel;
		bool bAddToCurrent;
	} Params;
	Params.NewAngVel = (wLua::FLuaVector::Get(InScriptContext, 2));
	Params.bAddToCurrent = lua_isnoneornil(InScriptContext,3) ? bool(false) : !!(lua_toboolean(InScriptContext, 3));
#if UE_GAME
	UPrimitiveComponent * This = (UPrimitiveComponent *)Obj;
	This->SetAllPhysicsAngularVelocityInDegrees(Params.NewAngVel,Params.bAddToCurrent);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetAllPhysicsAngularVelocityInDegrees"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FVector*)(params.GetStructMemory() + 0) = Params.NewAngVel;
		*(bool*)(params.GetStructMemory() + 12) = Params.bAddToCurrent;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.NewAngVel = *(FVector*)(params.GetStructMemory() + 0);
		Params.bAddToCurrent = *(bool*)(params.GetStructMemory() + 12);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetAllMassScale(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PrimitiveComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PrimitiveComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float InMassScale;
	} Params;
	Params.InMassScale = lua_isnoneornil(InScriptContext,2) ? float(1.000000) : (float)(luaL_checknumber(InScriptContext, 2));
#if UE_GAME
	UPrimitiveComponent * This = (UPrimitiveComponent *)Obj;
	This->SetAllMassScale(Params.InMassScale);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetAllMassScale"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(float*)(params.GetStructMemory() + 0) = Params.InMassScale;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.InMassScale = *(float*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 ScaleByMomentOfInertia(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PrimitiveComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PrimitiveComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FVector InputVector;
		FName BoneName;
		FVector ReturnValue;
	} Params;
	Params.InputVector = (wLua::FLuaVector::Get(InScriptContext, 2));
	Params.BoneName = lua_isnoneornil(InScriptContext,3) ? FName(TEXT("")) : FName(UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 3)));
#if UE_GAME
	UPrimitiveComponent * This = (UPrimitiveComponent *)Obj;
	Params.ReturnValue = This->ScaleByMomentOfInertia(Params.InputVector,Params.BoneName);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("ScaleByMomentOfInertia"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FVector*)(params.GetStructMemory() + 0) = Params.InputVector;
		*(FName*)(params.GetStructMemory() + 12) = Params.BoneName;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.InputVector = *(FVector*)(params.GetStructMemory() + 0);
		Params.BoneName = *(FName*)(params.GetStructMemory() + 12);
		Params.ReturnValue = *(FVector*)(params.GetStructMemory() + 24);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaVector::Return(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 PutRigidBodyToSleep(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PrimitiveComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PrimitiveComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FName BoneName;
	} Params;
	Params.BoneName = lua_isnoneornil(InScriptContext,2) ? FName(TEXT("")) : FName(UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 2)));
#if UE_GAME
	UPrimitiveComponent * This = (UPrimitiveComponent *)Obj;
	This->PutRigidBodyToSleep(Params.BoneName);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("PutRigidBodyToSleep"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FName*)(params.GetStructMemory() + 0) = Params.BoneName;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.BoneName = *(FName*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 K2_IsQueryCollisionEnabled(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PrimitiveComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PrimitiveComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool ReturnValue;
	} Params;
#if UE_GAME
	UPrimitiveComponent * This = (UPrimitiveComponent *)Obj;
	Params.ReturnValue = This->K2_IsQueryCollisionEnabled();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("K2_IsQueryCollisionEnabled"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushboolean(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 K2_IsPhysicsCollisionEnabled(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PrimitiveComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PrimitiveComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool ReturnValue;
	} Params;
#if UE_GAME
	UPrimitiveComponent * This = (UPrimitiveComponent *)Obj;
	Params.ReturnValue = This->K2_IsPhysicsCollisionEnabled();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("K2_IsPhysicsCollisionEnabled"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushboolean(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 K2_IsCollisionEnabled(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PrimitiveComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PrimitiveComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool ReturnValue;
	} Params;
#if UE_GAME
	UPrimitiveComponent * This = (UPrimitiveComponent *)Obj;
	Params.ReturnValue = This->K2_IsCollisionEnabled();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("K2_IsCollisionEnabled"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushboolean(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 JudgeShouldChangeMaterialQualityLevel(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PrimitiveComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PrimitiveComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		TEnumAsByte<EMaterialQualityLevel::Type> QualityLevel;
		bool ReturnValue;
	} Params;
	Params.QualityLevel = (TEnumAsByte<EMaterialQualityLevel::Type>)(luaL_checkint(InScriptContext, 2));
#if UE_GAME
	UPrimitiveComponent * This = (UPrimitiveComponent *)Obj;
	Params.ReturnValue = This->JudgeShouldChangeMaterialQualityLevel(Params.QualityLevel);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("JudgeShouldChangeMaterialQualityLevel"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(TEnumAsByte<EMaterialQualityLevel::Type>*)(params.GetStructMemory() + 0) = Params.QualityLevel;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.QualityLevel = *(TEnumAsByte<EMaterialQualityLevel::Type>*)(params.GetStructMemory() + 0);
		Params.ReturnValue = *(bool*)(params.GetStructMemory() + 1);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushboolean(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 IsOverlappingComponent(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PrimitiveComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PrimitiveComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		UPrimitiveComponent* OtherComp = nullptr;
		bool ReturnValue;
	} Params;
	Params.OtherComp = (UPrimitiveComponent*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"PrimitiveComponent");;
#if UE_GAME
	UPrimitiveComponent * This = (UPrimitiveComponent *)Obj;
	Params.ReturnValue = This->IsOverlappingComponent(Params.OtherComp);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("IsOverlappingComponent"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(UPrimitiveComponent**)(params.GetStructMemory() + 0) = Params.OtherComp;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.OtherComp = *(UPrimitiveComponent**)(params.GetStructMemory() + 0);
		Params.ReturnValue = *(bool*)(params.GetStructMemory() + 8);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushboolean(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 IsOverlappingActor(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PrimitiveComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PrimitiveComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		AActor* Other = nullptr;
		bool ReturnValue;
	} Params;
	Params.Other = (AActor*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"Actor");;
#if UE_GAME
	UPrimitiveComponent * This = (UPrimitiveComponent *)Obj;
	Params.ReturnValue = This->IsOverlappingActor(Params.Other);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("IsOverlappingActor"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(AActor**)(params.GetStructMemory() + 0) = Params.Other;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.Other = *(AActor**)(params.GetStructMemory() + 0);
		Params.ReturnValue = *(bool*)(params.GetStructMemory() + 8);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushboolean(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 IsGravityEnabled(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PrimitiveComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PrimitiveComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool ReturnValue;
	} Params;
#if UE_GAME
	UPrimitiveComponent * This = (UPrimitiveComponent *)Obj;
	Params.ReturnValue = This->IsGravityEnabled();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("IsGravityEnabled"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushboolean(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 IsAzureForeground(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PrimitiveComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PrimitiveComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool ReturnValue;
	} Params;
#if UE_GAME
	UPrimitiveComponent * This = (UPrimitiveComponent *)Obj;
	Params.ReturnValue = This->IsAzureForeground();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("IsAzureForeground"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushboolean(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 IsAnyRigidBodyAwake(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PrimitiveComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PrimitiveComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool ReturnValue;
	} Params;
#if UE_GAME
	UPrimitiveComponent * This = (UPrimitiveComponent *)Obj;
	Params.ReturnValue = This->IsAnyRigidBodyAwake();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("IsAnyRigidBodyAwake"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushboolean(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 IgnoreComponentWhenMoving(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PrimitiveComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PrimitiveComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		UPrimitiveComponent* Component = nullptr;
		bool bShouldIgnore;
	} Params;
	Params.Component = (UPrimitiveComponent*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"PrimitiveComponent");;
	Params.bShouldIgnore = !!(lua_toboolean(InScriptContext, 3));
#if UE_GAME
	UPrimitiveComponent * This = (UPrimitiveComponent *)Obj;
	This->IgnoreComponentWhenMoving(Params.Component,Params.bShouldIgnore);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("IgnoreComponentWhenMoving"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(UPrimitiveComponent**)(params.GetStructMemory() + 0) = Params.Component;
		*(bool*)(params.GetStructMemory() + 8) = Params.bShouldIgnore;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.Component = *(UPrimitiveComponent**)(params.GetStructMemory() + 0);
		Params.bShouldIgnore = *(bool*)(params.GetStructMemory() + 8);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 IgnoreActorWhenMoving(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PrimitiveComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PrimitiveComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		AActor* Actor = nullptr;
		bool bShouldIgnore;
	} Params;
	Params.Actor = (AActor*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"Actor");;
	Params.bShouldIgnore = !!(lua_toboolean(InScriptContext, 3));
#if UE_GAME
	UPrimitiveComponent * This = (UPrimitiveComponent *)Obj;
	This->IgnoreActorWhenMoving(Params.Actor,Params.bShouldIgnore);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("IgnoreActorWhenMoving"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(AActor**)(params.GetStructMemory() + 0) = Params.Actor;
		*(bool*)(params.GetStructMemory() + 8) = Params.bShouldIgnore;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.Actor = *(AActor**)(params.GetStructMemory() + 0);
		Params.bShouldIgnore = *(bool*)(params.GetStructMemory() + 8);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 GetPhysicsLinearVelocityAtPoint(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PrimitiveComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PrimitiveComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FVector Point;
		FName BoneName;
		FVector ReturnValue;
	} Params;
	Params.Point = (wLua::FLuaVector::Get(InScriptContext, 2));
	Params.BoneName = lua_isnoneornil(InScriptContext,3) ? FName(TEXT("")) : FName(UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 3)));
#if UE_GAME
	UPrimitiveComponent * This = (UPrimitiveComponent *)Obj;
	Params.ReturnValue = This->GetPhysicsLinearVelocityAtPoint(Params.Point,Params.BoneName);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetPhysicsLinearVelocityAtPoint"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FVector*)(params.GetStructMemory() + 0) = Params.Point;
		*(FName*)(params.GetStructMemory() + 12) = Params.BoneName;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.Point = *(FVector*)(params.GetStructMemory() + 0);
		Params.BoneName = *(FName*)(params.GetStructMemory() + 12);
		Params.ReturnValue = *(FVector*)(params.GetStructMemory() + 24);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaVector::Return(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetPhysicsLinearVelocity(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PrimitiveComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PrimitiveComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FName BoneName;
		FVector ReturnValue;
	} Params;
	Params.BoneName = lua_isnoneornil(InScriptContext,2) ? FName(TEXT("")) : FName(UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 2)));
#if UE_GAME
	UPrimitiveComponent * This = (UPrimitiveComponent *)Obj;
	Params.ReturnValue = This->GetPhysicsLinearVelocity(Params.BoneName);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetPhysicsLinearVelocity"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FName*)(params.GetStructMemory() + 0) = Params.BoneName;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.BoneName = *(FName*)(params.GetStructMemory() + 0);
		Params.ReturnValue = *(FVector*)(params.GetStructMemory() + 12);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaVector::Return(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetPhysicsAngularVelocityInRadians(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PrimitiveComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PrimitiveComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FName BoneName;
		FVector ReturnValue;
	} Params;
	Params.BoneName = lua_isnoneornil(InScriptContext,2) ? FName(TEXT("")) : FName(UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 2)));
#if UE_GAME
	UPrimitiveComponent * This = (UPrimitiveComponent *)Obj;
	Params.ReturnValue = This->GetPhysicsAngularVelocityInRadians(Params.BoneName);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetPhysicsAngularVelocityInRadians"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FName*)(params.GetStructMemory() + 0) = Params.BoneName;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.BoneName = *(FName*)(params.GetStructMemory() + 0);
		Params.ReturnValue = *(FVector*)(params.GetStructMemory() + 12);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaVector::Return(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetPhysicsAngularVelocityInDegrees(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PrimitiveComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PrimitiveComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FName BoneName;
		FVector ReturnValue;
	} Params;
	Params.BoneName = lua_isnoneornil(InScriptContext,2) ? FName(TEXT("")) : FName(UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 2)));
#if UE_GAME
	UPrimitiveComponent * This = (UPrimitiveComponent *)Obj;
	Params.ReturnValue = This->GetPhysicsAngularVelocityInDegrees(Params.BoneName);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetPhysicsAngularVelocityInDegrees"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FName*)(params.GetStructMemory() + 0) = Params.BoneName;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.BoneName = *(FName*)(params.GetStructMemory() + 0);
		Params.ReturnValue = *(FVector*)(params.GetStructMemory() + 12);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaVector::Return(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetOverlappingComponents(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PrimitiveComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PrimitiveComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		TArray<UPrimitiveComponent*> OutOverlappingComponents;
	} Params;
#if UE_GAME
	UPrimitiveComponent * This = (UPrimitiveComponent *)Obj;
	This->GetOverlappingComponents(Params.OutOverlappingComponents);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetOverlappingComponents"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.OutOverlappingComponents = *(TArray<UPrimitiveComponent*>*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	{lua_newtable(InScriptContext); int i = 1; for(auto It = Params.OutOverlappingComponents.CreateConstIterator(); It; ++It,++i) {  wLua::FLuaUtils::ReturnUObject(InScriptContext, (*It)); lua_rawseti(InScriptContext,-2,i);     }  }
	return 1;
}

int32 GetOverlappingActors(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PrimitiveComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PrimitiveComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		TArray<AActor*> OverlappingActors;
		TSubclassOf<AActor>  ClassFilter;
	} Params;
	Params.ClassFilter = lua_isnoneornil(InScriptContext,3) ? (UClass*)TSubclassOf<AActor> (nullptr) : (UClass*)wLua::FLuaUtils::GetUObject(InScriptContext,3,"Class");;
#if UE_GAME
	UPrimitiveComponent * This = (UPrimitiveComponent *)Obj;
	This->GetOverlappingActors(Params.OverlappingActors,Params.ClassFilter);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetOverlappingActors"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(TSubclassOf<AActor> *)(params.GetStructMemory() + 16) = Params.ClassFilter;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.OverlappingActors = *(TArray<AActor*>*)(params.GetStructMemory() + 0);
		Params.ClassFilter = *(TSubclassOf<AActor> *)(params.GetStructMemory() + 16);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	{lua_newtable(InScriptContext); int i = 1; for(auto It = Params.OverlappingActors.CreateConstIterator(); It; ++It,++i) {  wLua::FLuaUtils::ReturnUObject(InScriptContext, (*It)); lua_rawseti(InScriptContext,-2,i);     }  }
	return 1;
}

int32 GetNumMaterials(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PrimitiveComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PrimitiveComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		int32 ReturnValue;
	} Params;
#if UE_GAME
	UPrimitiveComponent * This = (UPrimitiveComponent *)Obj;
	Params.ReturnValue = This->GetNumMaterials();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetNumMaterials"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(int32*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushinteger(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetMaterialQualityLevelBias(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PrimitiveComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PrimitiveComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		int32 Index;
		int32 ReturnValue;
	} Params;
	Params.Index = (luaL_checkint(InScriptContext, 2));
#if UE_GAME
	UPrimitiveComponent * This = (UPrimitiveComponent *)Obj;
	Params.ReturnValue = This->GetMaterialQualityLevelBias(Params.Index);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetMaterialQualityLevelBias"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(int32*)(params.GetStructMemory() + 0) = Params.Index;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.Index = *(int32*)(params.GetStructMemory() + 0);
		Params.ReturnValue = *(int32*)(params.GetStructMemory() + 4);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushinteger(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetMaterialQualityLevel(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PrimitiveComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PrimitiveComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		TEnumAsByte<EMaterialQualityLevel::Type> ReturnValue;
	} Params;
#if UE_GAME
	UPrimitiveComponent * This = (UPrimitiveComponent *)Obj;
	Params.ReturnValue = This->GetMaterialQualityLevel();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetMaterialQualityLevel"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(TEnumAsByte<EMaterialQualityLevel::Type>*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushinteger(InScriptContext, (int)Params.ReturnValue);
	return 1;
}

int32 GetMaterialFromCollisionFaceIndex(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PrimitiveComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PrimitiveComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		int32 FaceIndex;
		int32 SectionIndex;
		UMaterialInterface* ReturnValue = nullptr;
	} Params;
	Params.FaceIndex = (luaL_checkint(InScriptContext, 2));
#if UE_GAME
	UPrimitiveComponent * This = (UPrimitiveComponent *)Obj;
	Params.ReturnValue = This->GetMaterialFromCollisionFaceIndex(Params.FaceIndex,Params.SectionIndex);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetMaterialFromCollisionFaceIndex"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(int32*)(params.GetStructMemory() + 0) = Params.FaceIndex;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.FaceIndex = *(int32*)(params.GetStructMemory() + 0);
		Params.SectionIndex = *(int32*)(params.GetStructMemory() + 4);
		Params.ReturnValue = *(UMaterialInterface**)(params.GetStructMemory() + 8);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Params.ReturnValue);
	lua_pushinteger(InScriptContext, Params.SectionIndex);
	return 2;
}

int32 GetMaterial(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PrimitiveComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PrimitiveComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		int32 ElementIndex;
		UMaterialInterface* ReturnValue = nullptr;
	} Params;
	Params.ElementIndex = (luaL_checkint(InScriptContext, 2));
#if UE_GAME
	UPrimitiveComponent * This = (UPrimitiveComponent *)Obj;
	Params.ReturnValue = This->GetMaterial(Params.ElementIndex);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetMaterial"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(int32*)(params.GetStructMemory() + 0) = Params.ElementIndex;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ElementIndex = *(int32*)(params.GetStructMemory() + 0);
		Params.ReturnValue = *(UMaterialInterface**)(params.GetStructMemory() + 8);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetMassScale(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PrimitiveComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PrimitiveComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FName BoneName;
		float ReturnValue;
	} Params;
	Params.BoneName = lua_isnoneornil(InScriptContext,2) ? FName(TEXT("")) : FName(UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 2)));
#if UE_GAME
	UPrimitiveComponent * This = (UPrimitiveComponent *)Obj;
	Params.ReturnValue = This->GetMassScale(Params.BoneName);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetMassScale"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FName*)(params.GetStructMemory() + 0) = Params.BoneName;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.BoneName = *(FName*)(params.GetStructMemory() + 0);
		Params.ReturnValue = *(float*)(params.GetStructMemory() + 12);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushnumber(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetMass(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PrimitiveComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PrimitiveComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float ReturnValue;
	} Params;
#if UE_GAME
	UPrimitiveComponent * This = (UPrimitiveComponent *)Obj;
	Params.ReturnValue = This->GetMass();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetMass"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(float*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushnumber(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetLinearDamping(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PrimitiveComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PrimitiveComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float ReturnValue;
	} Params;
#if UE_GAME
	UPrimitiveComponent * This = (UPrimitiveComponent *)Obj;
	Params.ReturnValue = This->GetLinearDamping();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetLinearDamping"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(float*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushnumber(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetInertiaTensor(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PrimitiveComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PrimitiveComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FName BoneName;
		FVector ReturnValue;
	} Params;
	Params.BoneName = lua_isnoneornil(InScriptContext,2) ? FName(TEXT("")) : FName(UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 2)));
#if UE_GAME
	UPrimitiveComponent * This = (UPrimitiveComponent *)Obj;
	Params.ReturnValue = This->GetInertiaTensor(Params.BoneName);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetInertiaTensor"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FName*)(params.GetStructMemory() + 0) = Params.BoneName;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.BoneName = *(FName*)(params.GetStructMemory() + 0);
		Params.ReturnValue = *(FVector*)(params.GetStructMemory() + 12);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaVector::Return(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetGenerateOverlapEvents(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PrimitiveComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PrimitiveComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool ReturnValue;
	} Params;
#if UE_GAME
	UPrimitiveComponent * This = (UPrimitiveComponent *)Obj;
	Params.ReturnValue = This->GetGenerateOverlapEvents();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetGenerateOverlapEvents"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushboolean(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetCollisionResponseToChannel(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PrimitiveComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PrimitiveComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		TEnumAsByte<ECollisionChannel> Channel;
		TEnumAsByte<ECollisionResponse> ReturnValue;
	} Params;
	Params.Channel = (TEnumAsByte<ECollisionChannel>)(luaL_checkint(InScriptContext, 2));
#if UE_GAME
	UPrimitiveComponent * This = (UPrimitiveComponent *)Obj;
	Params.ReturnValue = This->GetCollisionResponseToChannel(Params.Channel);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetCollisionResponseToChannel"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(TEnumAsByte<ECollisionChannel>*)(params.GetStructMemory() + 0) = Params.Channel;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.Channel = *(TEnumAsByte<ECollisionChannel>*)(params.GetStructMemory() + 0);
		Params.ReturnValue = *(TEnumAsByte<ECollisionResponse>*)(params.GetStructMemory() + 1);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushinteger(InScriptContext, (int)Params.ReturnValue);
	return 1;
}

int32 GetCollisionProfileName(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PrimitiveComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PrimitiveComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FName ReturnValue;
	} Params;
#if UE_GAME
	UPrimitiveComponent * This = (UPrimitiveComponent *)Obj;
	Params.ReturnValue = This->GetCollisionProfileName();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetCollisionProfileName"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(FName*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushstring(InScriptContext, TCHAR_TO_UTF8(*Params.ReturnValue.ToString()));
	return 1;
}

int32 GetCollisionObjectType(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PrimitiveComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PrimitiveComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		TEnumAsByte<ECollisionChannel> ReturnValue;
	} Params;
#if UE_GAME
	UPrimitiveComponent * This = (UPrimitiveComponent *)Obj;
	Params.ReturnValue = This->GetCollisionObjectType();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetCollisionObjectType"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(TEnumAsByte<ECollisionChannel>*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushinteger(InScriptContext, (int)Params.ReturnValue);
	return 1;
}

int32 GetCollisionEnabled(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PrimitiveComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PrimitiveComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		TEnumAsByte<ECollisionEnabled::Type> ReturnValue;
	} Params;
#if UE_GAME
	UPrimitiveComponent * This = (UPrimitiveComponent *)Obj;
	Params.ReturnValue = This->GetCollisionEnabled();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetCollisionEnabled"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(TEnumAsByte<ECollisionEnabled::Type>*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushinteger(InScriptContext, (int)Params.ReturnValue);
	return 1;
}

int32 GetClosestPointOnCollision(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PrimitiveComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PrimitiveComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FVector Point;
		FVector OutPointOnBody;
		FName BoneName;
		float ReturnValue;
	} Params;
	Params.Point = (wLua::FLuaVector::Get(InScriptContext, 2));
	Params.BoneName = lua_isnoneornil(InScriptContext,4) ? FName(TEXT("")) : FName(UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 4)));
#if UE_GAME
	UPrimitiveComponent * This = (UPrimitiveComponent *)Obj;
	Params.ReturnValue = This->GetClosestPointOnCollision(Params.Point,Params.OutPointOnBody,Params.BoneName);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetClosestPointOnCollision"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FVector*)(params.GetStructMemory() + 0) = Params.Point;
		*(FName*)(params.GetStructMemory() + 24) = Params.BoneName;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.Point = *(FVector*)(params.GetStructMemory() + 0);
		Params.OutPointOnBody = *(FVector*)(params.GetStructMemory() + 12);
		Params.BoneName = *(FName*)(params.GetStructMemory() + 24);
		Params.ReturnValue = *(float*)(params.GetStructMemory() + 36);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushnumber(InScriptContext, Params.ReturnValue);
	wLua::FLuaVector::Return(InScriptContext, Params.OutPointOnBody);
	return 2;
}

int32 GetCenterOfMass(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PrimitiveComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PrimitiveComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FName BoneName;
		FVector ReturnValue;
	} Params;
	Params.BoneName = lua_isnoneornil(InScriptContext,2) ? FName(TEXT("")) : FName(UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 2)));
#if UE_GAME
	UPrimitiveComponent * This = (UPrimitiveComponent *)Obj;
	Params.ReturnValue = This->GetCenterOfMass(Params.BoneName);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetCenterOfMass"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FName*)(params.GetStructMemory() + 0) = Params.BoneName;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.BoneName = *(FName*)(params.GetStructMemory() + 0);
		Params.ReturnValue = *(FVector*)(params.GetStructMemory() + 12);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaVector::Return(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetAzureDirectLightShadowScale(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PrimitiveComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PrimitiveComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		uint8 ReturnValue;
	} Params;
#if UE_GAME
	UPrimitiveComponent * This = (UPrimitiveComponent *)Obj;
	Params.ReturnValue = This->GetAzureDirectLightShadowScale();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetAzureDirectLightShadowScale"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(uint8*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushinteger(InScriptContext, (int)Params.ReturnValue);
	return 1;
}

int32 GetAngularDamping(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PrimitiveComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PrimitiveComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float ReturnValue;
	} Params;
#if UE_GAME
	UPrimitiveComponent * This = (UPrimitiveComponent *)Obj;
	Params.ReturnValue = This->GetAngularDamping();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetAngularDamping"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(float*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushnumber(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 CreateDynamicMaterialInstance(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PrimitiveComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PrimitiveComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		int32 ElementIndex;
		UMaterialInterface* SourceMaterial = nullptr;
		FName OptionalName;
		UMaterialInstanceDynamic* ReturnValue = nullptr;
	} Params;
	Params.ElementIndex = (luaL_checkint(InScriptContext, 2));
	Params.SourceMaterial = lua_isnoneornil(InScriptContext,3) ? nullptr : (UMaterialInterface*)wLua::FLuaUtils::GetUObject(InScriptContext,3,"MaterialInterface");;
	Params.OptionalName = lua_isnoneornil(InScriptContext,4) ? FName(TEXT("")) : FName(UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 4)));
#if UE_GAME
	UPrimitiveComponent * This = (UPrimitiveComponent *)Obj;
	Params.ReturnValue = This->CreateDynamicMaterialInstance(Params.ElementIndex,Params.SourceMaterial,Params.OptionalName);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("CreateDynamicMaterialInstance"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(int32*)(params.GetStructMemory() + 0) = Params.ElementIndex;
		*(UMaterialInterface**)(params.GetStructMemory() + 8) = Params.SourceMaterial;
		*(FName*)(params.GetStructMemory() + 16) = Params.OptionalName;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ElementIndex = *(int32*)(params.GetStructMemory() + 0);
		Params.SourceMaterial = *(UMaterialInterface**)(params.GetStructMemory() + 8);
		Params.OptionalName = *(FName*)(params.GetStructMemory() + 16);
		Params.ReturnValue = *(UMaterialInstanceDynamic**)(params.GetStructMemory() + 32);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 CopyArrayOfMoveIgnoreComponents(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PrimitiveComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PrimitiveComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		TArray<UPrimitiveComponent*> ReturnValue;
	} Params;
#if UE_GAME
	UPrimitiveComponent * This = (UPrimitiveComponent *)Obj;
	Params.ReturnValue = This->CopyArrayOfMoveIgnoreComponents();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("CopyArrayOfMoveIgnoreComponents"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(TArray<UPrimitiveComponent*>*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	{lua_newtable(InScriptContext); int i = 1; for(auto It = Params.ReturnValue.CreateConstIterator(); It; ++It,++i) {  wLua::FLuaUtils::ReturnUObject(InScriptContext, (*It)); lua_rawseti(InScriptContext,-2,i);     }  }
	return 1;
}

int32 CopyArrayOfMoveIgnoreActors(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PrimitiveComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PrimitiveComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		TArray<AActor*> ReturnValue;
	} Params;
#if UE_GAME
	UPrimitiveComponent * This = (UPrimitiveComponent *)Obj;
	Params.ReturnValue = This->CopyArrayOfMoveIgnoreActors();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("CopyArrayOfMoveIgnoreActors"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(TArray<AActor*>*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	{lua_newtable(InScriptContext); int i = 1; for(auto It = Params.ReturnValue.CreateConstIterator(); It; ++It,++i) {  wLua::FLuaUtils::ReturnUObject(InScriptContext, (*It)); lua_rawseti(InScriptContext,-2,i);     }  }
	return 1;
}

int32 ClearMoveIgnoreComponents(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PrimitiveComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PrimitiveComponent must be non-null"); lua_error(InScriptContext);  return 0;}
#if UE_GAME
	UPrimitiveComponent * This = (UPrimitiveComponent *)Obj;
	This->ClearMoveIgnoreComponents();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("ClearMoveIgnoreComponents"));
	if(!Function) { check(false); return 0;}
	Obj->ProcessEvent(Function, NULL);
#endif
	return 0;
}

int32 ClearMoveIgnoreActors(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PrimitiveComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PrimitiveComponent must be non-null"); lua_error(InScriptContext);  return 0;}
#if UE_GAME
	UPrimitiveComponent * This = (UPrimitiveComponent *)Obj;
	This->ClearMoveIgnoreActors();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("ClearMoveIgnoreActors"));
	if(!Function) { check(false); return 0;}
	Obj->ProcessEvent(Function, NULL);
#endif
	return 0;
}

int32 CanCharacterStepUp(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PrimitiveComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PrimitiveComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		APawn* Pawn = nullptr;
		bool ReturnValue;
	} Params;
	Params.Pawn = (APawn*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"Pawn");;
#if UE_GAME
	UPrimitiveComponent * This = (UPrimitiveComponent *)Obj;
	Params.ReturnValue = This->CanCharacterStepUp(Params.Pawn);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("CanCharacterStepUp"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(APawn**)(params.GetStructMemory() + 0) = Params.Pawn;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.Pawn = *(APawn**)(params.GetStructMemory() + 0);
		Params.ReturnValue = *(bool*)(params.GetStructMemory() + 8);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushboolean(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 AzureUpdatePrimitiveLightingAttachmentRoot(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PrimitiveComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PrimitiveComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		USceneComponent* pParent = nullptr;
	} Params;
	Params.pParent = (USceneComponent*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"SceneComponent");;
#if UE_GAME
	UPrimitiveComponent * This = (UPrimitiveComponent *)Obj;
	This->AzureUpdatePrimitiveLightingAttachmentRoot(Params.pParent);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("AzureUpdatePrimitiveLightingAttachmentRoot"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(USceneComponent**)(params.GetStructMemory() + 0) = Params.pParent;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.pParent = *(USceneComponent**)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 AzureShouldUseGlobalSHIndirectLighting(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PrimitiveComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PrimitiveComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool ReturnValue;
	} Params;
#if UE_GAME
	UPrimitiveComponent * This = (UPrimitiveComponent *)Obj;
	Params.ReturnValue = This->AzureShouldUseGlobalSHIndirectLighting();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("AzureShouldUseGlobalSHIndirectLighting"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushboolean(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 AzureSetUseGlobalSHIndirectLighting(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PrimitiveComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PrimitiveComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool bInUse;
	} Params;
	Params.bInUse = !!(lua_toboolean(InScriptContext, 2));
#if UE_GAME
	UPrimitiveComponent * This = (UPrimitiveComponent *)Obj;
	This->AzureSetUseGlobalSHIndirectLighting(Params.bInUse);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("AzureSetUseGlobalSHIndirectLighting"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(bool*)(params.GetStructMemory() + 0) = Params.bInUse;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.bInUse = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 AzureSetLightParent(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PrimitiveComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PrimitiveComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		USceneComponent* pLightParent = nullptr;
	} Params;
	Params.pLightParent = (USceneComponent*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"SceneComponent");;
#if UE_GAME
	UPrimitiveComponent * This = (UPrimitiveComponent *)Obj;
	This->AzureSetLightParent(Params.pLightParent);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("AzureSetLightParent"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(USceneComponent**)(params.GetStructMemory() + 0) = Params.pLightParent;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.pLightParent = *(USceneComponent**)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 AzureResetUseGlobalSHIndirectLighting(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PrimitiveComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PrimitiveComponent must be non-null"); lua_error(InScriptContext);  return 0;}
#if UE_GAME
	UPrimitiveComponent * This = (UPrimitiveComponent *)Obj;
	This->AzureResetUseGlobalSHIndirectLighting();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("AzureResetUseGlobalSHIndirectLighting"));
	if(!Function) { check(false); return 0;}
	Obj->ProcessEvent(Function, NULL);
#endif
	return 0;
}

int32 AzureResetILCData(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PrimitiveComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PrimitiveComponent must be non-null"); lua_error(InScriptContext);  return 0;}
#if UE_GAME
	UPrimitiveComponent * This = (UPrimitiveComponent *)Obj;
	This->AzureResetILCData();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("AzureResetILCData"));
	if(!Function) { check(false); return 0;}
	Obj->ProcessEvent(Function, NULL);
#endif
	return 0;
}

int32 AddTorqueInRadians(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PrimitiveComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PrimitiveComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FVector Torque;
		FName BoneName;
		bool bAccelChange;
	} Params;
	Params.Torque = (wLua::FLuaVector::Get(InScriptContext, 2));
	Params.BoneName = lua_isnoneornil(InScriptContext,3) ? FName(TEXT("")) : FName(UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 3)));
	Params.bAccelChange = lua_isnoneornil(InScriptContext,4) ? bool(false) : !!(lua_toboolean(InScriptContext, 4));
#if UE_GAME
	UPrimitiveComponent * This = (UPrimitiveComponent *)Obj;
	This->AddTorqueInRadians(Params.Torque,Params.BoneName,Params.bAccelChange);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("AddTorqueInRadians"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FVector*)(params.GetStructMemory() + 0) = Params.Torque;
		*(FName*)(params.GetStructMemory() + 12) = Params.BoneName;
		*(bool*)(params.GetStructMemory() + 24) = Params.bAccelChange;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.Torque = *(FVector*)(params.GetStructMemory() + 0);
		Params.BoneName = *(FName*)(params.GetStructMemory() + 12);
		Params.bAccelChange = *(bool*)(params.GetStructMemory() + 24);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 AddTorqueInDegrees(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PrimitiveComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PrimitiveComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FVector Torque;
		FName BoneName;
		bool bAccelChange;
	} Params;
	Params.Torque = (wLua::FLuaVector::Get(InScriptContext, 2));
	Params.BoneName = lua_isnoneornil(InScriptContext,3) ? FName(TEXT("")) : FName(UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 3)));
	Params.bAccelChange = lua_isnoneornil(InScriptContext,4) ? bool(false) : !!(lua_toboolean(InScriptContext, 4));
#if UE_GAME
	UPrimitiveComponent * This = (UPrimitiveComponent *)Obj;
	This->AddTorqueInDegrees(Params.Torque,Params.BoneName,Params.bAccelChange);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("AddTorqueInDegrees"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FVector*)(params.GetStructMemory() + 0) = Params.Torque;
		*(FName*)(params.GetStructMemory() + 12) = Params.BoneName;
		*(bool*)(params.GetStructMemory() + 24) = Params.bAccelChange;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.Torque = *(FVector*)(params.GetStructMemory() + 0);
		Params.BoneName = *(FName*)(params.GetStructMemory() + 12);
		Params.bAccelChange = *(bool*)(params.GetStructMemory() + 24);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 AddRadialImpulse(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PrimitiveComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PrimitiveComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FVector Origin;
		float Radius;
		float Strength;
		TEnumAsByte<ERadialImpulseFalloff> Falloff;
		bool bVelChange;
	} Params;
	Params.Origin = (wLua::FLuaVector::Get(InScriptContext, 2));
	Params.Radius = (float)(luaL_checknumber(InScriptContext, 3));
	Params.Strength = (float)(luaL_checknumber(InScriptContext, 4));
	Params.Falloff = (TEnumAsByte<ERadialImpulseFalloff>)(luaL_checkint(InScriptContext, 5));
	Params.bVelChange = lua_isnoneornil(InScriptContext,6) ? bool(false) : !!(lua_toboolean(InScriptContext, 6));
#if UE_GAME
	UPrimitiveComponent * This = (UPrimitiveComponent *)Obj;
	This->AddRadialImpulse(Params.Origin,Params.Radius,Params.Strength,Params.Falloff,Params.bVelChange);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("AddRadialImpulse"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FVector*)(params.GetStructMemory() + 0) = Params.Origin;
		*(float*)(params.GetStructMemory() + 12) = Params.Radius;
		*(float*)(params.GetStructMemory() + 16) = Params.Strength;
		*(TEnumAsByte<ERadialImpulseFalloff>*)(params.GetStructMemory() + 20) = Params.Falloff;
		*(bool*)(params.GetStructMemory() + 21) = Params.bVelChange;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.Origin = *(FVector*)(params.GetStructMemory() + 0);
		Params.Radius = *(float*)(params.GetStructMemory() + 12);
		Params.Strength = *(float*)(params.GetStructMemory() + 16);
		Params.Falloff = *(TEnumAsByte<ERadialImpulseFalloff>*)(params.GetStructMemory() + 20);
		Params.bVelChange = *(bool*)(params.GetStructMemory() + 21);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 AddRadialForce(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PrimitiveComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PrimitiveComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FVector Origin;
		float Radius;
		float Strength;
		TEnumAsByte<ERadialImpulseFalloff> Falloff;
		bool bAccelChange;
	} Params;
	Params.Origin = (wLua::FLuaVector::Get(InScriptContext, 2));
	Params.Radius = (float)(luaL_checknumber(InScriptContext, 3));
	Params.Strength = (float)(luaL_checknumber(InScriptContext, 4));
	Params.Falloff = (TEnumAsByte<ERadialImpulseFalloff>)(luaL_checkint(InScriptContext, 5));
	Params.bAccelChange = lua_isnoneornil(InScriptContext,6) ? bool(false) : !!(lua_toboolean(InScriptContext, 6));
#if UE_GAME
	UPrimitiveComponent * This = (UPrimitiveComponent *)Obj;
	This->AddRadialForce(Params.Origin,Params.Radius,Params.Strength,Params.Falloff,Params.bAccelChange);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("AddRadialForce"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FVector*)(params.GetStructMemory() + 0) = Params.Origin;
		*(float*)(params.GetStructMemory() + 12) = Params.Radius;
		*(float*)(params.GetStructMemory() + 16) = Params.Strength;
		*(TEnumAsByte<ERadialImpulseFalloff>*)(params.GetStructMemory() + 20) = Params.Falloff;
		*(bool*)(params.GetStructMemory() + 21) = Params.bAccelChange;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.Origin = *(FVector*)(params.GetStructMemory() + 0);
		Params.Radius = *(float*)(params.GetStructMemory() + 12);
		Params.Strength = *(float*)(params.GetStructMemory() + 16);
		Params.Falloff = *(TEnumAsByte<ERadialImpulseFalloff>*)(params.GetStructMemory() + 20);
		Params.bAccelChange = *(bool*)(params.GetStructMemory() + 21);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 AddImpulseAtLocation(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PrimitiveComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PrimitiveComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FVector Impulse;
		FVector Location;
		FName BoneName;
	} Params;
	Params.Impulse = (wLua::FLuaVector::Get(InScriptContext, 2));
	Params.Location = (wLua::FLuaVector::Get(InScriptContext, 3));
	Params.BoneName = lua_isnoneornil(InScriptContext,4) ? FName(TEXT("")) : FName(UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 4)));
#if UE_GAME
	UPrimitiveComponent * This = (UPrimitiveComponent *)Obj;
	This->AddImpulseAtLocation(Params.Impulse,Params.Location,Params.BoneName);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("AddImpulseAtLocation"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FVector*)(params.GetStructMemory() + 0) = Params.Impulse;
		*(FVector*)(params.GetStructMemory() + 12) = Params.Location;
		*(FName*)(params.GetStructMemory() + 24) = Params.BoneName;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.Impulse = *(FVector*)(params.GetStructMemory() + 0);
		Params.Location = *(FVector*)(params.GetStructMemory() + 12);
		Params.BoneName = *(FName*)(params.GetStructMemory() + 24);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 AddImpulse(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PrimitiveComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PrimitiveComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FVector Impulse;
		FName BoneName;
		bool bVelChange;
	} Params;
	Params.Impulse = (wLua::FLuaVector::Get(InScriptContext, 2));
	Params.BoneName = lua_isnoneornil(InScriptContext,3) ? FName(TEXT("")) : FName(UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 3)));
	Params.bVelChange = lua_isnoneornil(InScriptContext,4) ? bool(false) : !!(lua_toboolean(InScriptContext, 4));
#if UE_GAME
	UPrimitiveComponent * This = (UPrimitiveComponent *)Obj;
	This->AddImpulse(Params.Impulse,Params.BoneName,Params.bVelChange);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("AddImpulse"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FVector*)(params.GetStructMemory() + 0) = Params.Impulse;
		*(FName*)(params.GetStructMemory() + 12) = Params.BoneName;
		*(bool*)(params.GetStructMemory() + 24) = Params.bVelChange;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.Impulse = *(FVector*)(params.GetStructMemory() + 0);
		Params.BoneName = *(FName*)(params.GetStructMemory() + 12);
		Params.bVelChange = *(bool*)(params.GetStructMemory() + 24);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 AddForceAtLocationLocal(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PrimitiveComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PrimitiveComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FVector Force;
		FVector Location;
		FName BoneName;
	} Params;
	Params.Force = (wLua::FLuaVector::Get(InScriptContext, 2));
	Params.Location = (wLua::FLuaVector::Get(InScriptContext, 3));
	Params.BoneName = lua_isnoneornil(InScriptContext,4) ? FName(TEXT("")) : FName(UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 4)));
#if UE_GAME
	UPrimitiveComponent * This = (UPrimitiveComponent *)Obj;
	This->AddForceAtLocationLocal(Params.Force,Params.Location,Params.BoneName);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("AddForceAtLocationLocal"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FVector*)(params.GetStructMemory() + 0) = Params.Force;
		*(FVector*)(params.GetStructMemory() + 12) = Params.Location;
		*(FName*)(params.GetStructMemory() + 24) = Params.BoneName;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.Force = *(FVector*)(params.GetStructMemory() + 0);
		Params.Location = *(FVector*)(params.GetStructMemory() + 12);
		Params.BoneName = *(FName*)(params.GetStructMemory() + 24);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 AddForceAtLocation(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PrimitiveComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PrimitiveComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FVector Force;
		FVector Location;
		FName BoneName;
	} Params;
	Params.Force = (wLua::FLuaVector::Get(InScriptContext, 2));
	Params.Location = (wLua::FLuaVector::Get(InScriptContext, 3));
	Params.BoneName = lua_isnoneornil(InScriptContext,4) ? FName(TEXT("")) : FName(UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 4)));
#if UE_GAME
	UPrimitiveComponent * This = (UPrimitiveComponent *)Obj;
	This->AddForceAtLocation(Params.Force,Params.Location,Params.BoneName);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("AddForceAtLocation"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FVector*)(params.GetStructMemory() + 0) = Params.Force;
		*(FVector*)(params.GetStructMemory() + 12) = Params.Location;
		*(FName*)(params.GetStructMemory() + 24) = Params.BoneName;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.Force = *(FVector*)(params.GetStructMemory() + 0);
		Params.Location = *(FVector*)(params.GetStructMemory() + 12);
		Params.BoneName = *(FName*)(params.GetStructMemory() + 24);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 AddForce(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PrimitiveComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PrimitiveComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FVector Force;
		FName BoneName;
		bool bAccelChange;
	} Params;
	Params.Force = (wLua::FLuaVector::Get(InScriptContext, 2));
	Params.BoneName = lua_isnoneornil(InScriptContext,3) ? FName(TEXT("")) : FName(UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 3)));
	Params.bAccelChange = lua_isnoneornil(InScriptContext,4) ? bool(false) : !!(lua_toboolean(InScriptContext, 4));
#if UE_GAME
	UPrimitiveComponent * This = (UPrimitiveComponent *)Obj;
	This->AddForce(Params.Force,Params.BoneName,Params.bAccelChange);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("AddForce"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FVector*)(params.GetStructMemory() + 0) = Params.Force;
		*(FName*)(params.GetStructMemory() + 12) = Params.BoneName;
		*(bool*)(params.GetStructMemory() + 24) = Params.bAccelChange;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.Force = *(FVector*)(params.GetStructMemory() + 0);
		Params.BoneName = *(FName*)(params.GetStructMemory() + 12);
		Params.bAccelChange = *(bool*)(params.GetStructMemory() + 24);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 AddAngularImpulseInRadians(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PrimitiveComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PrimitiveComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FVector Impulse;
		FName BoneName;
		bool bVelChange;
	} Params;
	Params.Impulse = (wLua::FLuaVector::Get(InScriptContext, 2));
	Params.BoneName = lua_isnoneornil(InScriptContext,3) ? FName(TEXT("")) : FName(UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 3)));
	Params.bVelChange = lua_isnoneornil(InScriptContext,4) ? bool(false) : !!(lua_toboolean(InScriptContext, 4));
#if UE_GAME
	UPrimitiveComponent * This = (UPrimitiveComponent *)Obj;
	This->AddAngularImpulseInRadians(Params.Impulse,Params.BoneName,Params.bVelChange);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("AddAngularImpulseInRadians"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FVector*)(params.GetStructMemory() + 0) = Params.Impulse;
		*(FName*)(params.GetStructMemory() + 12) = Params.BoneName;
		*(bool*)(params.GetStructMemory() + 24) = Params.bVelChange;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.Impulse = *(FVector*)(params.GetStructMemory() + 0);
		Params.BoneName = *(FName*)(params.GetStructMemory() + 12);
		Params.bVelChange = *(bool*)(params.GetStructMemory() + 24);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 AddAngularImpulseInDegrees(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PrimitiveComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PrimitiveComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FVector Impulse;
		FName BoneName;
		bool bVelChange;
	} Params;
	Params.Impulse = (wLua::FLuaVector::Get(InScriptContext, 2));
	Params.BoneName = lua_isnoneornil(InScriptContext,3) ? FName(TEXT("")) : FName(UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 3)));
	Params.bVelChange = lua_isnoneornil(InScriptContext,4) ? bool(false) : !!(lua_toboolean(InScriptContext, 4));
#if UE_GAME
	UPrimitiveComponent * This = (UPrimitiveComponent *)Obj;
	This->AddAngularImpulseInDegrees(Params.Impulse,Params.BoneName,Params.bVelChange);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("AddAngularImpulseInDegrees"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FVector*)(params.GetStructMemory() + 0) = Params.Impulse;
		*(FName*)(params.GetStructMemory() + 12) = Params.BoneName;
		*(bool*)(params.GetStructMemory() + 24) = Params.bVelChange;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.Impulse = *(FVector*)(params.GetStructMemory() + 0);
		Params.BoneName = *(FName*)(params.GetStructMemory() + 12);
		Params.bVelChange = *(bool*)(params.GetStructMemory() + 24);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 Get_MinDrawDistance(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PrimitiveComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PrimitiveComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UPrimitiveComponent::StaticClass(), TEXT("MinDrawDistance"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_LDMaxDrawDistance(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PrimitiveComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PrimitiveComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UPrimitiveComponent::StaticClass(), TEXT("LDMaxDrawDistance"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_CachedMaxDrawDistance(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PrimitiveComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PrimitiveComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UPrimitiveComponent::StaticClass(), TEXT("CachedMaxDrawDistance"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_IndirectLightingCacheQuality(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PrimitiveComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PrimitiveComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UPrimitiveComponent::StaticClass(), TEXT("IndirectLightingCacheQuality"));
	if(!Property) { check(false); return 0;}
	TEnumAsByte<EIndirectLightingCacheQuality> PropertyValue = TEnumAsByte<EIndirectLightingCacheQuality>();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushinteger(InScriptContext, (int)PropertyValue);
	return 1;
}

int32 Get_LightmapType(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PrimitiveComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PrimitiveComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UPrimitiveComponent::StaticClass(), TEXT("LightmapType"));
	if(!Property) { check(false); return 0;}
	ELightmapType PropertyValue = ELightmapType();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushinteger(InScriptContext, (int)PropertyValue);
	return 1;
}

int32 Get_bEnableAutoLODGeneration(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PrimitiveComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PrimitiveComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UPrimitiveComponent::StaticClass(), TEXT("bEnableAutoLODGeneration"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bEnableAutoLODGeneration(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PrimitiveComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PrimitiveComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UPrimitiveComponent::StaticClass(), TEXT("bEnableAutoLODGeneration"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bUseMaxLODAsImposter(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PrimitiveComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PrimitiveComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UPrimitiveComponent::StaticClass(), TEXT("bUseMaxLODAsImposter"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bUseMaxLODAsImposter(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PrimitiveComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PrimitiveComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UPrimitiveComponent::StaticClass(), TEXT("bUseMaxLODAsImposter"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_ExcludeForSpecificHLODLevels(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PrimitiveComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PrimitiveComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UPrimitiveComponent::StaticClass(), TEXT("ExcludeForSpecificHLODLevels"));
	if(!Property) { check(false); return 0;}
	TArray<int32> PropertyValue;
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	{lua_newtable(InScriptContext); int i = 1; for(auto It = PropertyValue.CreateConstIterator(); It; ++It,++i) {  lua_pushinteger(InScriptContext, (*It)); lua_rawseti(InScriptContext,-2,i);     }  }
	return 1;
}

int32 Set_ExcludeForSpecificHLODLevels(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PrimitiveComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PrimitiveComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UPrimitiveComponent::StaticClass(), TEXT("ExcludeForSpecificHLODLevels"));
	if(!Property) { check(false); return 0;}
	TArray<int32> PropertyValue = [](lua_State * _InScriptContext){ TArray<int32> ret; lua_pushnil(_InScriptContext); while(lua_next(_InScriptContext,2)!=0){ int32 item = (luaL_checkint(_InScriptContext, -1)); ret.Add(item); lua_pop(_InScriptContext,1);  } return ret; }(InScriptContext);;
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bNeverDistanceCull(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PrimitiveComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PrimitiveComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UPrimitiveComponent::StaticClass(), TEXT("bNeverDistanceCull"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_bAlwaysCreatePhysicsState(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PrimitiveComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PrimitiveComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UPrimitiveComponent::StaticClass(), TEXT("bAlwaysCreatePhysicsState"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_bGenerateOverlapEvents(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PrimitiveComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PrimitiveComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UPrimitiveComponent::StaticClass(), TEXT("bGenerateOverlapEvents"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bGenerateOverlapEvents(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PrimitiveComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PrimitiveComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UPrimitiveComponent::StaticClass(), TEXT("bGenerateOverlapEvents"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bMultiBodyOverlap(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PrimitiveComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PrimitiveComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UPrimitiveComponent::StaticClass(), TEXT("bMultiBodyOverlap"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bMultiBodyOverlap(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PrimitiveComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PrimitiveComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UPrimitiveComponent::StaticClass(), TEXT("bMultiBodyOverlap"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bCheckAsyncSceneOnMove(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PrimitiveComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PrimitiveComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UPrimitiveComponent::StaticClass(), TEXT("bCheckAsyncSceneOnMove"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bCheckAsyncSceneOnMove(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PrimitiveComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PrimitiveComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UPrimitiveComponent::StaticClass(), TEXT("bCheckAsyncSceneOnMove"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bTraceComplexOnMove(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PrimitiveComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PrimitiveComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UPrimitiveComponent::StaticClass(), TEXT("bTraceComplexOnMove"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bTraceComplexOnMove(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PrimitiveComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PrimitiveComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UPrimitiveComponent::StaticClass(), TEXT("bTraceComplexOnMove"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bReturnMaterialOnMove(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PrimitiveComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PrimitiveComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UPrimitiveComponent::StaticClass(), TEXT("bReturnMaterialOnMove"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bReturnMaterialOnMove(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PrimitiveComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PrimitiveComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UPrimitiveComponent::StaticClass(), TEXT("bReturnMaterialOnMove"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bAllowCullDistanceVolume(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PrimitiveComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PrimitiveComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UPrimitiveComponent::StaticClass(), TEXT("bAllowCullDistanceVolume"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_bVisibleInReflectionCaptures(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PrimitiveComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PrimitiveComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UPrimitiveComponent::StaticClass(), TEXT("bVisibleInReflectionCaptures"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_bRenderInMainPass(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PrimitiveComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PrimitiveComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UPrimitiveComponent::StaticClass(), TEXT("bRenderInMainPass"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_bRenderInPlanarReflectionPass(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PrimitiveComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PrimitiveComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UPrimitiveComponent::StaticClass(), TEXT("bRenderInPlanarReflectionPass"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_bRenderInMono(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PrimitiveComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PrimitiveComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UPrimitiveComponent::StaticClass(), TEXT("bRenderInMono"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_bReceivesDecals(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PrimitiveComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PrimitiveComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UPrimitiveComponent::StaticClass(), TEXT("bReceivesDecals"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_bOwnerNoSee(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PrimitiveComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PrimitiveComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UPrimitiveComponent::StaticClass(), TEXT("bOwnerNoSee"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_bOnlyOwnerSee(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PrimitiveComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PrimitiveComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UPrimitiveComponent::StaticClass(), TEXT("bOnlyOwnerSee"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_bTreatAsBackgroundForOcclusion(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PrimitiveComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PrimitiveComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UPrimitiveComponent::StaticClass(), TEXT("bTreatAsBackgroundForOcclusion"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_bUseAsOccluder(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PrimitiveComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PrimitiveComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UPrimitiveComponent::StaticClass(), TEXT("bUseAsOccluder"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_bForceMipStreaming(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PrimitiveComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PrimitiveComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UPrimitiveComponent::StaticClass(), TEXT("bForceMipStreaming"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_CastShadow(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PrimitiveComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PrimitiveComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UPrimitiveComponent::StaticClass(), TEXT("CastShadow"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_bAffectDynamicIndirectLighting(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PrimitiveComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PrimitiveComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UPrimitiveComponent::StaticClass(), TEXT("bAffectDynamicIndirectLighting"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_bAffectDistanceFieldLighting(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PrimitiveComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PrimitiveComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UPrimitiveComponent::StaticClass(), TEXT("bAffectDistanceFieldLighting"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_bCastDynamicShadow(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PrimitiveComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PrimitiveComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UPrimitiveComponent::StaticClass(), TEXT("bCastDynamicShadow"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_bCastStaticShadow(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PrimitiveComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PrimitiveComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UPrimitiveComponent::StaticClass(), TEXT("bCastStaticShadow"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_bCastVolumetricTranslucentShadow(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PrimitiveComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PrimitiveComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UPrimitiveComponent::StaticClass(), TEXT("bCastVolumetricTranslucentShadow"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_bSelfShadowOnly(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PrimitiveComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PrimitiveComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UPrimitiveComponent::StaticClass(), TEXT("bSelfShadowOnly"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_bCastFarShadow(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PrimitiveComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PrimitiveComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UPrimitiveComponent::StaticClass(), TEXT("bCastFarShadow"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_bCastInsetShadow(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PrimitiveComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PrimitiveComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UPrimitiveComponent::StaticClass(), TEXT("bCastInsetShadow"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_bCastCinematicShadow(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PrimitiveComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PrimitiveComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UPrimitiveComponent::StaticClass(), TEXT("bCastCinematicShadow"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_bCastHiddenShadow(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PrimitiveComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PrimitiveComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UPrimitiveComponent::StaticClass(), TEXT("bCastHiddenShadow"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_bCastShadowAsTwoSided(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PrimitiveComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PrimitiveComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UPrimitiveComponent::StaticClass(), TEXT("bCastShadowAsTwoSided"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_bLightAttachmentsAsGroup(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PrimitiveComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PrimitiveComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UPrimitiveComponent::StaticClass(), TEXT("bLightAttachmentsAsGroup"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_bReceiveMobileCSMShadows(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PrimitiveComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PrimitiveComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UPrimitiveComponent::StaticClass(), TEXT("bReceiveMobileCSMShadows"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_bAzureTranslucentReceiveMobileCSMShadows(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PrimitiveComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PrimitiveComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UPrimitiveComponent::StaticClass(), TEXT("bAzureTranslucentReceiveMobileCSMShadows"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_bAzureIndoorReceiveCSMShadow(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PrimitiveComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PrimitiveComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UPrimitiveComponent::StaticClass(), TEXT("bAzureIndoorReceiveCSMShadow"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_bAzureDisableSelfStaticShadow(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PrimitiveComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PrimitiveComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UPrimitiveComponent::StaticClass(), TEXT("bAzureDisableSelfStaticShadow"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_bSingleSampleShadowFromStationaryLights(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PrimitiveComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PrimitiveComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UPrimitiveComponent::StaticClass(), TEXT("bSingleSampleShadowFromStationaryLights"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_bIgnoreRadialImpulse(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PrimitiveComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PrimitiveComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UPrimitiveComponent::StaticClass(), TEXT("bIgnoreRadialImpulse"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bIgnoreRadialImpulse(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PrimitiveComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PrimitiveComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UPrimitiveComponent::StaticClass(), TEXT("bIgnoreRadialImpulse"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bIgnoreRadialForce(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PrimitiveComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PrimitiveComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UPrimitiveComponent::StaticClass(), TEXT("bIgnoreRadialForce"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bIgnoreRadialForce(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PrimitiveComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PrimitiveComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UPrimitiveComponent::StaticClass(), TEXT("bIgnoreRadialForce"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bApplyImpulseOnDamage(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PrimitiveComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PrimitiveComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UPrimitiveComponent::StaticClass(), TEXT("bApplyImpulseOnDamage"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bApplyImpulseOnDamage(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PrimitiveComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PrimitiveComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UPrimitiveComponent::StaticClass(), TEXT("bApplyImpulseOnDamage"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bReplicatePhysicsToAutonomousProxy(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PrimitiveComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PrimitiveComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UPrimitiveComponent::StaticClass(), TEXT("bReplicatePhysicsToAutonomousProxy"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bReplicatePhysicsToAutonomousProxy(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PrimitiveComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PrimitiveComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UPrimitiveComponent::StaticClass(), TEXT("bReplicatePhysicsToAutonomousProxy"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bRenderCustomDepth(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PrimitiveComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PrimitiveComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UPrimitiveComponent::StaticClass(), TEXT("bRenderCustomDepth"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_bAzureUseDistortion(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PrimitiveComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PrimitiveComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UPrimitiveComponent::StaticClass(), TEXT("bAzureUseDistortion"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_CanCharacterStepUpOn(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PrimitiveComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PrimitiveComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UPrimitiveComponent::StaticClass(), TEXT("CanCharacterStepUpOn"));
	if(!Property) { check(false); return 0;}
	TEnumAsByte<ECanBeCharacterBase> PropertyValue = TEnumAsByte<ECanBeCharacterBase>();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushinteger(InScriptContext, (int)PropertyValue);
	return 1;
}

int32 Set_CanCharacterStepUpOn(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PrimitiveComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PrimitiveComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UPrimitiveComponent::StaticClass(), TEXT("CanCharacterStepUpOn"));
	if(!Property) { check(false); return 0;}
	TEnumAsByte<ECanBeCharacterBase> PropertyValue = (TEnumAsByte<ECanBeCharacterBase>)(luaL_checkint(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_CustomDepthStencilWriteMask(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PrimitiveComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PrimitiveComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UPrimitiveComponent::StaticClass(), TEXT("CustomDepthStencilWriteMask"));
	if(!Property) { check(false); return 0;}
	ERendererStencilMask PropertyValue = ERendererStencilMask();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushinteger(InScriptContext, (int)PropertyValue);
	return 1;
}

int32 Get_CustomDepthStencilValue(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PrimitiveComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PrimitiveComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UPrimitiveComponent::StaticClass(), TEXT("CustomDepthStencilValue"));
	if(!Property) { check(false); return 0;}
	int32 PropertyValue = int32();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushinteger(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_TranslucencySortPriority(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PrimitiveComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PrimitiveComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UPrimitiveComponent::StaticClass(), TEXT("TranslucencySortPriority"));
	if(!Property) { check(false); return 0;}
	int32 PropertyValue = int32();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushinteger(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_LpvBiasMultiplier(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PrimitiveComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PrimitiveComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UPrimitiveComponent::StaticClass(), TEXT("LpvBiasMultiplier"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_BoundsScale(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PrimitiveComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PrimitiveComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UPrimitiveComponent::StaticClass(), TEXT("BoundsScale"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_BoundsScale(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PrimitiveComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PrimitiveComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UPrimitiveComponent::StaticClass(), TEXT("BoundsScale"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Call_OnComponentEndOverlap(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PrimitiveComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PrimitiveComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		UPrimitiveComponent* OverlappedComponent = nullptr;
		AActor* OtherActor = nullptr;
		UPrimitiveComponent* OtherComp = nullptr;
		int32 OtherBodyIndex;
	} Params;
	Params.OverlappedComponent = (UPrimitiveComponent*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"PrimitiveComponent");;
	Params.OtherActor = (AActor*)wLua::FLuaUtils::GetUObject(InScriptContext,3,"Actor");;
	Params.OtherComp = (UPrimitiveComponent*)wLua::FLuaUtils::GetUObject(InScriptContext,4,"PrimitiveComponent");;
	Params.OtherBodyIndex = (luaL_checkint(InScriptContext, 5));
	UPrimitiveComponent * This = (UPrimitiveComponent *)Obj;
	This->OnComponentEndOverlap.Broadcast(Params.OverlappedComponent,Params.OtherActor,Params.OtherComp,Params.OtherBodyIndex);
	return 0;
}

int32 Call_OnComponentWake(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PrimitiveComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PrimitiveComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		UPrimitiveComponent* WakingComponent = nullptr;
		FName BoneName;
	} Params;
	Params.WakingComponent = (UPrimitiveComponent*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"PrimitiveComponent");;
	Params.BoneName = FName(UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 3)));
	UPrimitiveComponent * This = (UPrimitiveComponent *)Obj;
	This->OnComponentWake.Broadcast(Params.WakingComponent,Params.BoneName);
	return 0;
}

int32 Call_OnComponentSleep(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PrimitiveComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PrimitiveComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		UPrimitiveComponent* SleepingComponent = nullptr;
		FName BoneName;
	} Params;
	Params.SleepingComponent = (UPrimitiveComponent*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"PrimitiveComponent");;
	Params.BoneName = FName(UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 3)));
	UPrimitiveComponent * This = (UPrimitiveComponent *)Obj;
	This->OnComponentSleep.Broadcast(Params.SleepingComponent,Params.BoneName);
	return 0;
}

int32 Call_OnBeginCursorOver(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PrimitiveComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PrimitiveComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		UPrimitiveComponent* TouchedComponent = nullptr;
	} Params;
	Params.TouchedComponent = (UPrimitiveComponent*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"PrimitiveComponent");;
	UPrimitiveComponent * This = (UPrimitiveComponent *)Obj;
	This->OnBeginCursorOver.Broadcast(Params.TouchedComponent);
	return 0;
}

int32 Call_OnEndCursorOver(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PrimitiveComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PrimitiveComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		UPrimitiveComponent* TouchedComponent = nullptr;
	} Params;
	Params.TouchedComponent = (UPrimitiveComponent*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"PrimitiveComponent");;
	UPrimitiveComponent * This = (UPrimitiveComponent *)Obj;
	This->OnEndCursorOver.Broadcast(Params.TouchedComponent);
	return 0;
}

int32 Call_OnInputTouchBegin(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PrimitiveComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PrimitiveComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		TEnumAsByte<ETouchIndex::Type> FingerIndex;
		UPrimitiveComponent* TouchedComponent = nullptr;
	} Params;
	Params.FingerIndex = (TEnumAsByte<ETouchIndex::Type>)(luaL_checkint(InScriptContext, 2));
	Params.TouchedComponent = (UPrimitiveComponent*)wLua::FLuaUtils::GetUObject(InScriptContext,3,"PrimitiveComponent");;
	UPrimitiveComponent * This = (UPrimitiveComponent *)Obj;
	This->OnInputTouchBegin.Broadcast(Params.FingerIndex,Params.TouchedComponent);
	return 0;
}

int32 Call_OnInputTouchEnd(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PrimitiveComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PrimitiveComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		TEnumAsByte<ETouchIndex::Type> FingerIndex;
		UPrimitiveComponent* TouchedComponent = nullptr;
	} Params;
	Params.FingerIndex = (TEnumAsByte<ETouchIndex::Type>)(luaL_checkint(InScriptContext, 2));
	Params.TouchedComponent = (UPrimitiveComponent*)wLua::FLuaUtils::GetUObject(InScriptContext,3,"PrimitiveComponent");;
	UPrimitiveComponent * This = (UPrimitiveComponent *)Obj;
	This->OnInputTouchEnd.Broadcast(Params.FingerIndex,Params.TouchedComponent);
	return 0;
}

int32 Call_OnInputTouchEnter(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PrimitiveComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PrimitiveComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		TEnumAsByte<ETouchIndex::Type> FingerIndex;
		UPrimitiveComponent* TouchedComponent = nullptr;
	} Params;
	Params.FingerIndex = (TEnumAsByte<ETouchIndex::Type>)(luaL_checkint(InScriptContext, 2));
	Params.TouchedComponent = (UPrimitiveComponent*)wLua::FLuaUtils::GetUObject(InScriptContext,3,"PrimitiveComponent");;
	UPrimitiveComponent * This = (UPrimitiveComponent *)Obj;
	This->OnInputTouchEnter.Broadcast(Params.FingerIndex,Params.TouchedComponent);
	return 0;
}

int32 Call_OnInputTouchLeave(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PrimitiveComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PrimitiveComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		TEnumAsByte<ETouchIndex::Type> FingerIndex;
		UPrimitiveComponent* TouchedComponent = nullptr;
	} Params;
	Params.FingerIndex = (TEnumAsByte<ETouchIndex::Type>)(luaL_checkint(InScriptContext, 2));
	Params.TouchedComponent = (UPrimitiveComponent*)wLua::FLuaUtils::GetUObject(InScriptContext,3,"PrimitiveComponent");;
	UPrimitiveComponent * This = (UPrimitiveComponent *)Obj;
	This->OnInputTouchLeave.Broadcast(Params.FingerIndex,Params.TouchedComponent);
	return 0;
}

int32 Class(lua_State* InScriptContext)
{
	UClass* Class = UPrimitiveComponent::StaticClass();
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Class);
	return 1;
}

const luaL_Reg Lib_Funcs[] =
{
	{ "Class", Class },
	{ "WakeRigidBody", WakeRigidBody },
	{ "WakeAllRigidBodies", WakeAllRigidBodies },
	{ "SetUseCCD", SetUseCCD },
	{ "SetTranslucentSortPriority", SetTranslucentSortPriority },
	{ "SetSingleSampleShadowFromStationaryLights", SetSingleSampleShadowFromStationaryLights },
	{ "SetSimulatePhysics", SetSimulatePhysics },
	{ "SetRenderInMono", SetRenderInMono },
	{ "SetRenderInMainPass", SetRenderInMainPass },
	{ "SetRenderCustomDepth", SetRenderCustomDepth },
	{ "SetRenderAzureDistortion", SetRenderAzureDistortion },
	{ "SetReceivesDecals", SetReceivesDecals },
	{ "SetReceiveCSMShadows", SetReceiveCSMShadows },
	{ "SetPhysMaterialOverride", SetPhysMaterialOverride },
	{ "SetPhysicsMaxAngularVelocityInRadians", SetPhysicsMaxAngularVelocityInRadians },
	{ "SetPhysicsMaxAngularVelocityInDegrees", SetPhysicsMaxAngularVelocityInDegrees },
	{ "SetPhysicsLinearVelocity", SetPhysicsLinearVelocity },
	{ "SetPhysicsAngularVelocityInRadians", SetPhysicsAngularVelocityInRadians },
	{ "SetPhysicsAngularVelocityInDegrees", SetPhysicsAngularVelocityInDegrees },
	{ "SetOwnerNoSee", SetOwnerNoSee },
	{ "SetOnlyOwnerSee", SetOnlyOwnerSee },
	{ "SetNotifyRigidBodyCollision", SetNotifyRigidBodyCollision },
	{ "SetMaterialQualityLevel", SetMaterialQualityLevel },
	{ "SetMaterialByName", SetMaterialByName },
	{ "SetMaterial", SetMaterial },
	{ "SetMassScale", SetMassScale },
	{ "SetMassOverrideInKg", SetMassOverrideInKg },
	{ "SetLinearDamping", SetLinearDamping },
	{ "SetGenerateOverlapEvents", SetGenerateOverlapEvents },
	{ "SetEnableGravity", SetEnableGravity },
	{ "SetCustomDepthStencilWriteMask", SetCustomDepthStencilWriteMask },
	{ "SetCustomDepthStencilValue", SetCustomDepthStencilValue },
	{ "SetCullDistance", SetCullDistance },
	{ "SetConstraintMode", SetConstraintMode },
	{ "SetCollisionResponseToChannel", SetCollisionResponseToChannel },
	{ "SetCollisionResponseToAllChannels", SetCollisionResponseToAllChannels },
	{ "SetCollisionProfileName", SetCollisionProfileName },
	{ "SetCollisionObjectType", SetCollisionObjectType },
	{ "SetCollisionEnabled", SetCollisionEnabled },
	{ "SetCenterOfMass", SetCenterOfMass },
	{ "SetCastShadow", SetCastShadow },
	{ "SetBoundsScale", SetBoundsScale },
	{ "SetAngularDamping", SetAngularDamping },
	{ "SetAllUseCCD", SetAllUseCCD },
	{ "SetAllPhysicsLinearVelocity", SetAllPhysicsLinearVelocity },
	{ "SetAllPhysicsAngularVelocityInRadians", SetAllPhysicsAngularVelocityInRadians },
	{ "SetAllPhysicsAngularVelocityInDegrees", SetAllPhysicsAngularVelocityInDegrees },
	{ "SetAllMassScale", SetAllMassScale },
	{ "ScaleByMomentOfInertia", ScaleByMomentOfInertia },
	{ "PutRigidBodyToSleep", PutRigidBodyToSleep },
	{ "IsQueryCollisionEnabled", K2_IsQueryCollisionEnabled },
	{ "IsPhysicsCollisionEnabled", K2_IsPhysicsCollisionEnabled },
	{ "IsCollisionEnabled", K2_IsCollisionEnabled },
	{ "JudgeShouldChangeMaterialQualityLevel", JudgeShouldChangeMaterialQualityLevel },
	{ "IsOverlappingComponent", IsOverlappingComponent },
	{ "IsOverlappingActor", IsOverlappingActor },
	{ "IsGravityEnabled", IsGravityEnabled },
	{ "IsAzureForeground", IsAzureForeground },
	{ "IsAnyRigidBodyAwake", IsAnyRigidBodyAwake },
	{ "IgnoreComponentWhenMoving", IgnoreComponentWhenMoving },
	{ "IgnoreActorWhenMoving", IgnoreActorWhenMoving },
	{ "GetPhysicsLinearVelocityAtPoint", GetPhysicsLinearVelocityAtPoint },
	{ "GetPhysicsLinearVelocity", GetPhysicsLinearVelocity },
	{ "GetPhysicsAngularVelocityInRadians", GetPhysicsAngularVelocityInRadians },
	{ "GetPhysicsAngularVelocityInDegrees", GetPhysicsAngularVelocityInDegrees },
	{ "GetOverlappingComponents", GetOverlappingComponents },
	{ "GetOverlappingActors", GetOverlappingActors },
	{ "GetNumMaterials", GetNumMaterials },
	{ "GetMaterialQualityLevelBias", GetMaterialQualityLevelBias },
	{ "GetMaterialQualityLevel", GetMaterialQualityLevel },
	{ "GetMaterialFromCollisionFaceIndex", GetMaterialFromCollisionFaceIndex },
	{ "GetMaterial", GetMaterial },
	{ "GetMassScale", GetMassScale },
	{ "GetMass", GetMass },
	{ "GetLinearDamping", GetLinearDamping },
	{ "GetInertiaTensor", GetInertiaTensor },
	{ "GetGenerateOverlapEvents", GetGenerateOverlapEvents },
	{ "GetCollisionResponseToChannel", GetCollisionResponseToChannel },
	{ "GetCollisionProfileName", GetCollisionProfileName },
	{ "GetCollisionObjectType", GetCollisionObjectType },
	{ "GetCollisionEnabled", GetCollisionEnabled },
	{ "GetClosestPointOnCollision", GetClosestPointOnCollision },
	{ "GetCenterOfMass", GetCenterOfMass },
	{ "GetAzureDirectLightShadowScale", GetAzureDirectLightShadowScale },
	{ "GetAngularDamping", GetAngularDamping },
	{ "CreateDynamicMaterialInstance", CreateDynamicMaterialInstance },
	{ "CopyArrayOfMoveIgnoreComponents", CopyArrayOfMoveIgnoreComponents },
	{ "CopyArrayOfMoveIgnoreActors", CopyArrayOfMoveIgnoreActors },
	{ "ClearMoveIgnoreComponents", ClearMoveIgnoreComponents },
	{ "ClearMoveIgnoreActors", ClearMoveIgnoreActors },
	{ "CanCharacterStepUp", CanCharacterStepUp },
	{ "AzureUpdatePrimitiveLightingAttachmentRoot", AzureUpdatePrimitiveLightingAttachmentRoot },
	{ "AzureShouldUseGlobalSHIndirectLighting", AzureShouldUseGlobalSHIndirectLighting },
	{ "AzureSetUseGlobalSHIndirectLighting", AzureSetUseGlobalSHIndirectLighting },
	{ "AzureSetLightParent", AzureSetLightParent },
	{ "AzureResetUseGlobalSHIndirectLighting", AzureResetUseGlobalSHIndirectLighting },
	{ "AzureResetILCData", AzureResetILCData },
	{ "AddTorqueInRadians", AddTorqueInRadians },
	{ "AddTorqueInDegrees", AddTorqueInDegrees },
	{ "AddRadialImpulse", AddRadialImpulse },
	{ "AddRadialForce", AddRadialForce },
	{ "AddImpulseAtLocation", AddImpulseAtLocation },
	{ "AddImpulse", AddImpulse },
	{ "AddForceAtLocationLocal", AddForceAtLocationLocal },
	{ "AddForceAtLocation", AddForceAtLocation },
	{ "AddForce", AddForce },
	{ "AddAngularImpulseInRadians", AddAngularImpulseInRadians },
	{ "AddAngularImpulseInDegrees", AddAngularImpulseInDegrees },
	{ "Get_MinDrawDistance", Get_MinDrawDistance },
	{ "Get_LDMaxDrawDistance", Get_LDMaxDrawDistance },
	{ "Get_CachedMaxDrawDistance", Get_CachedMaxDrawDistance },
	{ "Get_IndirectLightingCacheQuality", Get_IndirectLightingCacheQuality },
	{ "Get_LightmapType", Get_LightmapType },
	{ "Get_bEnableAutoLODGeneration", Get_bEnableAutoLODGeneration },
	{ "Set_bEnableAutoLODGeneration", Set_bEnableAutoLODGeneration },
	{ "Get_bUseMaxLODAsImposter", Get_bUseMaxLODAsImposter },
	{ "Set_bUseMaxLODAsImposter", Set_bUseMaxLODAsImposter },
	{ "Get_ExcludeForSpecificHLODLevels", Get_ExcludeForSpecificHLODLevels },
	{ "Set_ExcludeForSpecificHLODLevels", Set_ExcludeForSpecificHLODLevels },
	{ "Get_bNeverDistanceCull", Get_bNeverDistanceCull },
	{ "Get_bAlwaysCreatePhysicsState", Get_bAlwaysCreatePhysicsState },
	{ "Get_bGenerateOverlapEvents", Get_bGenerateOverlapEvents },
	{ "Set_bGenerateOverlapEvents", Set_bGenerateOverlapEvents },
	{ "Get_bMultiBodyOverlap", Get_bMultiBodyOverlap },
	{ "Set_bMultiBodyOverlap", Set_bMultiBodyOverlap },
	{ "Get_bCheckAsyncSceneOnMove", Get_bCheckAsyncSceneOnMove },
	{ "Set_bCheckAsyncSceneOnMove", Set_bCheckAsyncSceneOnMove },
	{ "Get_bTraceComplexOnMove", Get_bTraceComplexOnMove },
	{ "Set_bTraceComplexOnMove", Set_bTraceComplexOnMove },
	{ "Get_bReturnMaterialOnMove", Get_bReturnMaterialOnMove },
	{ "Set_bReturnMaterialOnMove", Set_bReturnMaterialOnMove },
	{ "Get_bAllowCullDistanceVolume", Get_bAllowCullDistanceVolume },
	{ "Get_bVisibleInReflectionCaptures", Get_bVisibleInReflectionCaptures },
	{ "Get_bRenderInMainPass", Get_bRenderInMainPass },
	{ "Get_bRenderInPlanarReflectionPass", Get_bRenderInPlanarReflectionPass },
	{ "Get_bRenderInMono", Get_bRenderInMono },
	{ "Get_bReceivesDecals", Get_bReceivesDecals },
	{ "Get_bOwnerNoSee", Get_bOwnerNoSee },
	{ "Get_bOnlyOwnerSee", Get_bOnlyOwnerSee },
	{ "Get_bTreatAsBackgroundForOcclusion", Get_bTreatAsBackgroundForOcclusion },
	{ "Get_bUseAsOccluder", Get_bUseAsOccluder },
	{ "Get_bForceMipStreaming", Get_bForceMipStreaming },
	{ "Get_CastShadow", Get_CastShadow },
	{ "Get_bAffectDynamicIndirectLighting", Get_bAffectDynamicIndirectLighting },
	{ "Get_bAffectDistanceFieldLighting", Get_bAffectDistanceFieldLighting },
	{ "Get_bCastDynamicShadow", Get_bCastDynamicShadow },
	{ "Get_bCastStaticShadow", Get_bCastStaticShadow },
	{ "Get_bCastVolumetricTranslucentShadow", Get_bCastVolumetricTranslucentShadow },
	{ "Get_bSelfShadowOnly", Get_bSelfShadowOnly },
	{ "Get_bCastFarShadow", Get_bCastFarShadow },
	{ "Get_bCastInsetShadow", Get_bCastInsetShadow },
	{ "Get_bCastCinematicShadow", Get_bCastCinematicShadow },
	{ "Get_bCastHiddenShadow", Get_bCastHiddenShadow },
	{ "Get_bCastShadowAsTwoSided", Get_bCastShadowAsTwoSided },
	{ "Get_bLightAttachmentsAsGroup", Get_bLightAttachmentsAsGroup },
	{ "Get_bReceiveMobileCSMShadows", Get_bReceiveMobileCSMShadows },
	{ "Get_bAzureTranslucentReceiveMobileCSMShadows", Get_bAzureTranslucentReceiveMobileCSMShadows },
	{ "Get_bAzureIndoorReceiveCSMShadow", Get_bAzureIndoorReceiveCSMShadow },
	{ "Get_bAzureDisableSelfStaticShadow", Get_bAzureDisableSelfStaticShadow },
	{ "Get_bSingleSampleShadowFromStationaryLights", Get_bSingleSampleShadowFromStationaryLights },
	{ "Get_bIgnoreRadialImpulse", Get_bIgnoreRadialImpulse },
	{ "Set_bIgnoreRadialImpulse", Set_bIgnoreRadialImpulse },
	{ "Get_bIgnoreRadialForce", Get_bIgnoreRadialForce },
	{ "Set_bIgnoreRadialForce", Set_bIgnoreRadialForce },
	{ "Get_bApplyImpulseOnDamage", Get_bApplyImpulseOnDamage },
	{ "Set_bApplyImpulseOnDamage", Set_bApplyImpulseOnDamage },
	{ "Get_bReplicatePhysicsToAutonomousProxy", Get_bReplicatePhysicsToAutonomousProxy },
	{ "Set_bReplicatePhysicsToAutonomousProxy", Set_bReplicatePhysicsToAutonomousProxy },
	{ "Get_bRenderCustomDepth", Get_bRenderCustomDepth },
	{ "Get_bAzureUseDistortion", Get_bAzureUseDistortion },
	{ "Get_CanCharacterStepUpOn", Get_CanCharacterStepUpOn },
	{ "Set_CanCharacterStepUpOn", Set_CanCharacterStepUpOn },
	{ "Get_CustomDepthStencilWriteMask", Get_CustomDepthStencilWriteMask },
	{ "Get_CustomDepthStencilValue", Get_CustomDepthStencilValue },
	{ "Get_TranslucencySortPriority", Get_TranslucencySortPriority },
	{ "Get_LpvBiasMultiplier", Get_LpvBiasMultiplier },
	{ "Get_BoundsScale", Get_BoundsScale },
	{ "Set_BoundsScale", Set_BoundsScale },
	{ "Call_OnComponentEndOverlap", Call_OnComponentEndOverlap },
	{ "Call_OnComponentWake", Call_OnComponentWake },
	{ "Call_OnComponentSleep", Call_OnComponentSleep },
	{ "Call_OnBeginCursorOver", Call_OnBeginCursorOver },
	{ "Call_OnEndCursorOver", Call_OnEndCursorOver },
	{ "Call_OnInputTouchBegin", Call_OnInputTouchBegin },
	{ "Call_OnInputTouchEnd", Call_OnInputTouchEnd },
	{ "Call_OnInputTouchEnter", Call_OnInputTouchEnter },
	{ "Call_OnInputTouchLeave", Call_OnInputTouchLeave },
	{ "GetSquaredDistanceToCollision", GetSquaredDistanceToCollision },
	{ "GetCollisionShape", GetCollisionShape },
	{ "PutAllRigidBodiesToSleep", PutAllRigidBodiesToSleep },
	{ "LineTraceComponent", LineTraceComponent },
	{ "is_nil", wLua::LuaStatic::isnil },
	{ "__gc", wLua::LuaStatic::removeUClassFrameCache },
	{ NULL, NULL }
};

void Register(lua_State *InScriptContext)
{
	lua_newtable(InScriptContext);
	luaL_register(InScriptContext, NULL, Lib_Funcs);
	AzureHelpFuncs::AuxRegister(InScriptContext, "PrimitiveComponent");
}
void SetMtLink(lua_State *InScriptContext)
{
	AzureHelpFuncs::AuxSetMtLink(InScriptContext, "PrimitiveComponent", "SceneComponent",USERDATATYPE_UOBJECT);
}

}