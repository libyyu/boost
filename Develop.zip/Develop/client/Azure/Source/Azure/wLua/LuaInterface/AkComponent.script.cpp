#include "Azure.h"
#include "Utility/help_funcs.h"
#include "wLua/UObjectHeaders.h"
#include "AkComponent.h"
#include "AkGameplayStatics.h"
#include "AzureLuaIntegration.h"

namespace LuaAkComponent
{
int32 UseEarlyReflections(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AkComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AkComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		UAkAuxBus* AuxBus = nullptr;
		int32 Order;
		float BusSendGain;
		float MaxPathLength;
		bool SpotReflectors;
		FString AuxBusName;
	} Params;
	Params.AuxBus = UAkGameplayStatics::UObject2UAkAuxBus(wLua::FLuaUtils::GetUObject(InScriptContext,2,"AkAuxBus"));;
	Params.Order = lua_isnoneornil(InScriptContext,3) ? int32(1) : (luaL_checkint(InScriptContext, 3));
	Params.BusSendGain = lua_isnoneornil(InScriptContext,4) ? float(1.000000) : (float)(luaL_checknumber(InScriptContext, 4));
	Params.MaxPathLength = lua_isnoneornil(InScriptContext,5) ? float(100000.000000) : (float)(luaL_checknumber(InScriptContext, 5));
	Params.SpotReflectors = lua_isnoneornil(InScriptContext,6) ? bool(false) : !!(lua_toboolean(InScriptContext, 6));
	Params.AuxBusName = lua_isnoneornil(InScriptContext,7) ? FString(TEXT("")) : UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 7));
#if UE_GAME
	UAkComponent * This = (UAkComponent *)Obj;
	This->UseEarlyReflections(Params.AuxBus,Params.Order,Params.BusSendGain,Params.MaxPathLength,Params.SpotReflectors,Params.AuxBusName);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("UseEarlyReflections"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(UAkAuxBus**)(params.GetStructMemory() + 0) = Params.AuxBus;
		*(int32*)(params.GetStructMemory() + 8) = Params.Order;
		*(float*)(params.GetStructMemory() + 12) = Params.BusSendGain;
		*(float*)(params.GetStructMemory() + 16) = Params.MaxPathLength;
		*(bool*)(params.GetStructMemory() + 20) = Params.SpotReflectors;
		*(FString*)(params.GetStructMemory() + 24) = Params.AuxBusName;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.AuxBus = *(UAkAuxBus**)(params.GetStructMemory() + 0);
		Params.Order = *(int32*)(params.GetStructMemory() + 8);
		Params.BusSendGain = *(float*)(params.GetStructMemory() + 12);
		Params.MaxPathLength = *(float*)(params.GetStructMemory() + 16);
		Params.SpotReflectors = *(bool*)(params.GetStructMemory() + 20);
		Params.AuxBusName = *(FString*)(params.GetStructMemory() + 24);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 Stop(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AkComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AkComponent must be non-null"); lua_error(InScriptContext);  return 0;}
#if UE_GAME
	UAkComponent * This = (UAkComponent *)Obj;
	This->Stop();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("Stop"));
	if(!Function) { check(false); return 0;}
	Obj->ProcessEvent(Function, NULL);
#endif
	return 0;
}

int32 SetUseSpatialAudio(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AkComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AkComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool bNewValue;
	} Params;
	Params.bNewValue = !!(lua_toboolean(InScriptContext, 2));
#if UE_GAME
	UAkComponent * This = (UAkComponent *)Obj;
	This->SetUseSpatialAudio(Params.bNewValue);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetUseSpatialAudio"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(bool*)(params.GetStructMemory() + 0) = Params.bNewValue;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.bNewValue = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetSwitch(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AkComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AkComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FString SwitchGroup;
		FString SwitchState;
	} Params;
	Params.SwitchGroup = UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 2));
	Params.SwitchState = UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 3));
#if UE_GAME
	UAkComponent * This = (UAkComponent *)Obj;
	This->SetSwitch(Params.SwitchGroup,Params.SwitchState);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetSwitch"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FString*)(params.GetStructMemory() + 0) = Params.SwitchGroup;
		*(FString*)(params.GetStructMemory() + 16) = Params.SwitchState;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.SwitchGroup = *(FString*)(params.GetStructMemory() + 0);
		Params.SwitchState = *(FString*)(params.GetStructMemory() + 16);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetStopWhenOwnerDestroyed(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AkComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AkComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool bStopWhenOwnerDestroyed;
	} Params;
	Params.bStopWhenOwnerDestroyed = !!(lua_toboolean(InScriptContext, 2));
#if UE_GAME
	UAkComponent * This = (UAkComponent *)Obj;
	This->SetStopWhenOwnerDestroyed(Params.bStopWhenOwnerDestroyed);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetStopWhenOwnerDestroyed"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(bool*)(params.GetStructMemory() + 0) = Params.bStopWhenOwnerDestroyed;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.bStopWhenOwnerDestroyed = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetRTPCValue(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AkComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AkComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FString RTPC;
		float Value;
		int32 InterpolationTimeMs;
	} Params;
	Params.RTPC = UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 2));
	Params.Value = (float)(luaL_checknumber(InScriptContext, 3));
	Params.InterpolationTimeMs = (luaL_checkint(InScriptContext, 4));
#if UE_GAME
	UAkComponent * This = (UAkComponent *)Obj;
	This->SetRTPCValue(Params.RTPC,Params.Value,Params.InterpolationTimeMs);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetRTPCValue"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FString*)(params.GetStructMemory() + 0) = Params.RTPC;
		*(float*)(params.GetStructMemory() + 16) = Params.Value;
		*(int32*)(params.GetStructMemory() + 20) = Params.InterpolationTimeMs;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.RTPC = *(FString*)(params.GetStructMemory() + 0);
		Params.Value = *(float*)(params.GetStructMemory() + 16);
		Params.InterpolationTimeMs = *(int32*)(params.GetStructMemory() + 20);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetOutputBusVolume(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AkComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AkComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float BusVolume;
	} Params;
	Params.BusVolume = (float)(luaL_checknumber(InScriptContext, 2));
#if UE_GAME
	UAkComponent * This = (UAkComponent *)Obj;
	This->SetOutputBusVolume(Params.BusVolume);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetOutputBusVolume"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(float*)(params.GetStructMemory() + 0) = Params.BusVolume;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.BusVolume = *(float*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetListeners(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AkComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AkComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		TArray<UAkComponent*> Listeners;
	} Params;
	Params.Listeners = [](lua_State * _InScriptContext){ TArray<UAkComponent*> ret; lua_pushnil(_InScriptContext); while(lua_next(_InScriptContext,2)!=0){ UAkComponent* item = UAkGameplayStatics::UObject2UAkComponent(wLua::FLuaUtils::GetUObject(_InScriptContext,-1,"AkComponent"));; ret.Add(item); lua_pop(_InScriptContext,1);  } return ret; }(InScriptContext);;
#if UE_GAME
	UAkComponent * This = (UAkComponent *)Obj;
	This->SetListeners(Params.Listeners);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetListeners"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(TArray<UAkComponent*>*)(params.GetStructMemory() + 0) = Params.Listeners;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.Listeners = *(TArray<UAkComponent*>*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetAttenuationScalingFactor(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AkComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AkComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float Value;
	} Params;
	Params.Value = (float)(luaL_checknumber(InScriptContext, 2));
#if UE_GAME
	UAkComponent * This = (UAkComponent *)Obj;
	This->SetAttenuationScalingFactor(Params.Value);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetAttenuationScalingFactor"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(float*)(params.GetStructMemory() + 0) = Params.Value;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.Value = *(float*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 PostTrigger(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AkComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AkComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FString Trigger;
	} Params;
	Params.Trigger = UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 2));
#if UE_GAME
	UAkComponent * This = (UAkComponent *)Obj;
	This->PostTrigger(Params.Trigger);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("PostTrigger"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FString*)(params.GetStructMemory() + 0) = Params.Trigger;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.Trigger = *(FString*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 GetRTPCValue(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AkComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AkComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FString RTPC;
		int32 PlayingID;
		ERTPCValueType InputValueType;
		float Value;
		ERTPCValueType OutputValueType;
	} Params;
	Params.RTPC = UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 2));
	Params.PlayingID = (luaL_checkint(InScriptContext, 3));
	Params.InputValueType = (ERTPCValueType)(luaL_checkint(InScriptContext, 4));
#if UE_GAME
	UAkComponent * This = (UAkComponent *)Obj;
	This->GetRTPCValue(Params.RTPC,Params.PlayingID,Params.InputValueType,Params.Value,Params.OutputValueType);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetRTPCValue"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FString*)(params.GetStructMemory() + 0) = Params.RTPC;
		*(int32*)(params.GetStructMemory() + 16) = Params.PlayingID;
		*(ERTPCValueType*)(params.GetStructMemory() + 20) = Params.InputValueType;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.RTPC = *(FString*)(params.GetStructMemory() + 0);
		Params.PlayingID = *(int32*)(params.GetStructMemory() + 16);
		Params.InputValueType = *(ERTPCValueType*)(params.GetStructMemory() + 20);
		Params.Value = *(float*)(params.GetStructMemory() + 24);
		Params.OutputValueType = *(ERTPCValueType*)(params.GetStructMemory() + 28);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushnumber(InScriptContext, Params.Value);
	lua_pushinteger(InScriptContext, (int)Params.OutputValueType);
	return 2;
}

int32 GetAttenuationRadius(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AkComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AkComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float ReturnValue;
	} Params;
#if UE_GAME
	UAkComponent * This = (UAkComponent *)Obj;
	Params.ReturnValue = This->GetAttenuationRadius();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetAttenuationRadius"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(float*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushnumber(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 Get_bUseSpatialAudio(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AkComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AkComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAkComponent::StaticClass(), TEXT("bUseSpatialAudio"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = bool();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bUseSpatialAudio(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AkComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AkComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAkComponent::StaticClass(), TEXT("bUseSpatialAudio"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_EarlyReflectionAuxBus(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AkComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AkComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAkComponent::StaticClass(), TEXT("EarlyReflectionAuxBus"));
	if(!Property) { check(false); return 0;}
	UAkAuxBus* PropertyValue;
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaUtils::ReturnUObject(InScriptContext, UAkGameplayStatics::UAkAuxBus2UObject(PropertyValue));
	return 1;
}

int32 Get_EarlyReflectionAuxBusName(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AkComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AkComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAkComponent::StaticClass(), TEXT("EarlyReflectionAuxBusName"));
	if(!Property) { check(false); return 0;}
	FString PropertyValue;
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushstring(InScriptContext, TCHAR_TO_UTF8(*PropertyValue));
	return 1;
}

int32 Get_EarlyReflectionOrder(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AkComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AkComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAkComponent::StaticClass(), TEXT("EarlyReflectionOrder"));
	if(!Property) { check(false); return 0;}
	int32 PropertyValue = int32();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushinteger(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_EarlyReflectionBusSendGain(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AkComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AkComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAkComponent::StaticClass(), TEXT("EarlyReflectionBusSendGain"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_EarlyReflectionMaxPathLength(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AkComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AkComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAkComponent::StaticClass(), TEXT("EarlyReflectionMaxPathLength"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_OcclusionCollisionChannel(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AkComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AkComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAkComponent::StaticClass(), TEXT("OcclusionCollisionChannel"));
	if(!Property) { check(false); return 0;}
	TEnumAsByte<ECollisionChannel> PropertyValue = TEnumAsByte<ECollisionChannel>();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushinteger(InScriptContext, (int)PropertyValue);
	return 1;
}

int32 Set_OcclusionCollisionChannel(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AkComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AkComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAkComponent::StaticClass(), TEXT("OcclusionCollisionChannel"));
	if(!Property) { check(false); return 0;}
	TEnumAsByte<ECollisionChannel> PropertyValue = (TEnumAsByte<ECollisionChannel>)(luaL_checkint(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_EnableSpotReflectors(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AkComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AkComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAkComponent::StaticClass(), TEXT("EnableSpotReflectors"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_roomReverbAuxBusGain(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AkComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AkComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAkComponent::StaticClass(), TEXT("roomReverbAuxBusGain"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_diffractionMaxEdges(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AkComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AkComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAkComponent::StaticClass(), TEXT("diffractionMaxEdges"));
	if(!Property) { check(false); return 0;}
	int32 PropertyValue = int32();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushinteger(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_diffractionMaxPaths(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AkComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AkComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAkComponent::StaticClass(), TEXT("diffractionMaxPaths"));
	if(!Property) { check(false); return 0;}
	int32 PropertyValue = int32();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushinteger(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_diffractionMaxPathLength(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AkComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AkComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAkComponent::StaticClass(), TEXT("diffractionMaxPathLength"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_DrawFirstOrderReflections(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AkComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AkComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAkComponent::StaticClass(), TEXT("DrawFirstOrderReflections"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_DrawFirstOrderReflections(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AkComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AkComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAkComponent::StaticClass(), TEXT("DrawFirstOrderReflections"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_DrawSecondOrderReflections(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AkComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AkComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAkComponent::StaticClass(), TEXT("DrawSecondOrderReflections"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_DrawSecondOrderReflections(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AkComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AkComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAkComponent::StaticClass(), TEXT("DrawSecondOrderReflections"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_DrawHigherOrderReflections(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AkComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AkComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAkComponent::StaticClass(), TEXT("DrawHigherOrderReflections"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_DrawHigherOrderReflections(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AkComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AkComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAkComponent::StaticClass(), TEXT("DrawHigherOrderReflections"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_DrawDiffraction(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AkComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AkComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAkComponent::StaticClass(), TEXT("DrawDiffraction"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_DrawDiffraction(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AkComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AkComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAkComponent::StaticClass(), TEXT("DrawDiffraction"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_AttenuationScalingFactor(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AkComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AkComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAkComponent::StaticClass(), TEXT("AttenuationScalingFactor"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_OcclusionRefreshInterval(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AkComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AkComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAkComponent::StaticClass(), TEXT("OcclusionRefreshInterval"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_OcclusionRefreshInterval(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AkComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AkComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAkComponent::StaticClass(), TEXT("OcclusionRefreshInterval"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bUseReverbVolumes(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AkComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AkComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAkComponent::StaticClass(), TEXT("bUseReverbVolumes"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = bool();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bUseReverbVolumes(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AkComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AkComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAkComponent::StaticClass(), TEXT("bUseReverbVolumes"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_AkAudioEvent(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AkComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AkComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAkComponent::StaticClass(), TEXT("AkAudioEvent"));
	if(!Property) { check(false); return 0;}
	UAkAudioEvent* PropertyValue;
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaUtils::ReturnUObject(InScriptContext, UAkGameplayStatics::UAkAudioEvent2UObject(PropertyValue));
	return 1;
}

int32 Set_AkAudioEvent(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AkComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AkComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAkComponent::StaticClass(), TEXT("AkAudioEvent"));
	if(!Property) { check(false); return 0;}
	UAkAudioEvent* PropertyValue = UAkGameplayStatics::UObject2UAkAudioEvent(wLua::FLuaUtils::GetUObject(InScriptContext,2,"AkAudioEvent"));;
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_EventName(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AkComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AkComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAkComponent::StaticClass(), TEXT("EventName"));
	if(!Property) { check(false); return 0;}
	FString PropertyValue;
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushstring(InScriptContext, TCHAR_TO_UTF8(*PropertyValue));
	return 1;
}

int32 Set_EventName(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AkComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AkComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAkComponent::StaticClass(), TEXT("EventName"));
	if(!Property) { check(false); return 0;}
	FString PropertyValue = UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 New(lua_State* InScriptContext)
{
	UObject* Outer = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Object");
	FName Name = FName(luaL_checkstring(InScriptContext, 2));
	UObject* Obj = NewObject<UAkComponent>(Outer, Name);
	wLua::FLuaUtils::ReturnUObject(InScriptContext,Obj);
	return 1;
}

int32 Destroy(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AkComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AkComponent must be non-null"); lua_error(InScriptContext);  return 0;}
		UActorComponent * com = Cast<UActorComponent>(Obj);
		if(lua_isnoneornil(InScriptContext,2))
			com->DestroyComponent();
		else
			com->DestroyComponent(!!lua_toboolean(InScriptContext,2));
		userdata->flag |= wLua::LuaObjectFlag::DESTROYED;
		wLua::FLuaUtils::RemoveObjectReference(Obj, userdata->stamp, InScriptContext);
#ifdef AZURE_BUILD_WLUACHECK
		UE_LOG(LogAzure, Warning, TEXT("Destroy AkComponent: %x userdata:%x   stamp:%x"),Obj,userdata,userdata->stamp);
#endif
	return 0;
}

int32 Class(lua_State* InScriptContext)
{
	UClass* Class = UAkComponent::StaticClass();
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Class);
	return 1;
}

const luaL_Reg Lib_Funcs[] =
{
	{ "New", New },
	{ "Destroy", Destroy },
	{ "Class", Class },
	{ "UseEarlyReflections", UseEarlyReflections },
	{ "Stop", Stop },
	{ "SetUseSpatialAudio", SetUseSpatialAudio },
	{ "SetSwitch", SetSwitch },
	{ "SetStopWhenOwnerDestroyed", SetStopWhenOwnerDestroyed },
	{ "SetRTPCValue", SetRTPCValue },
	{ "SetOutputBusVolume", SetOutputBusVolume },
	{ "SetListeners", SetListeners },
	{ "SetAttenuationScalingFactor", SetAttenuationScalingFactor },
	{ "PostTrigger", PostTrigger },
	{ "GetRTPCValue", GetRTPCValue },
	{ "GetAttenuationRadius", GetAttenuationRadius },
	{ "Get_bUseSpatialAudio", Get_bUseSpatialAudio },
	{ "Set_bUseSpatialAudio", Set_bUseSpatialAudio },
	{ "Get_EarlyReflectionAuxBus", Get_EarlyReflectionAuxBus },
	{ "Get_EarlyReflectionAuxBusName", Get_EarlyReflectionAuxBusName },
	{ "Get_EarlyReflectionOrder", Get_EarlyReflectionOrder },
	{ "Get_EarlyReflectionBusSendGain", Get_EarlyReflectionBusSendGain },
	{ "Get_EarlyReflectionMaxPathLength", Get_EarlyReflectionMaxPathLength },
	{ "Get_OcclusionCollisionChannel", Get_OcclusionCollisionChannel },
	{ "Set_OcclusionCollisionChannel", Set_OcclusionCollisionChannel },
	{ "Get_EnableSpotReflectors", Get_EnableSpotReflectors },
	{ "Get_roomReverbAuxBusGain", Get_roomReverbAuxBusGain },
	{ "Get_diffractionMaxEdges", Get_diffractionMaxEdges },
	{ "Get_diffractionMaxPaths", Get_diffractionMaxPaths },
	{ "Get_diffractionMaxPathLength", Get_diffractionMaxPathLength },
	{ "Get_DrawFirstOrderReflections", Get_DrawFirstOrderReflections },
	{ "Set_DrawFirstOrderReflections", Set_DrawFirstOrderReflections },
	{ "Get_DrawSecondOrderReflections", Get_DrawSecondOrderReflections },
	{ "Set_DrawSecondOrderReflections", Set_DrawSecondOrderReflections },
	{ "Get_DrawHigherOrderReflections", Get_DrawHigherOrderReflections },
	{ "Set_DrawHigherOrderReflections", Set_DrawHigherOrderReflections },
	{ "Get_DrawDiffraction", Get_DrawDiffraction },
	{ "Set_DrawDiffraction", Set_DrawDiffraction },
	{ "Get_AttenuationScalingFactor", Get_AttenuationScalingFactor },
	{ "Get_OcclusionRefreshInterval", Get_OcclusionRefreshInterval },
	{ "Set_OcclusionRefreshInterval", Set_OcclusionRefreshInterval },
	{ "Get_bUseReverbVolumes", Get_bUseReverbVolumes },
	{ "Set_bUseReverbVolumes", Set_bUseReverbVolumes },
	{ "Get_AkAudioEvent", Get_AkAudioEvent },
	{ "Set_AkAudioEvent", Set_AkAudioEvent },
	{ "Get_EventName", Get_EventName },
	{ "Set_EventName", Set_EventName },
	{ "is_nil", wLua::LuaStatic::isnil },
	{ "__gc", wLua::LuaStatic::removeUClassFrameCache },
	{ NULL, NULL }
};

void Register(lua_State *InScriptContext)
{
	lua_newtable(InScriptContext);
	luaL_register(InScriptContext, NULL, Lib_Funcs);
	AzureHelpFuncs::AuxRegister(InScriptContext, "AkComponent");
}
void SetMtLink(lua_State *InScriptContext)
{
	AzureHelpFuncs::AuxSetMtLink(InScriptContext, "AkComponent", "SceneComponent",USERDATATYPE_UOBJECT);
}

}