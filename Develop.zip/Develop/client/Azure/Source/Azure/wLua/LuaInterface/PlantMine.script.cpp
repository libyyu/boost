#include "Azure.h"
#include "Utility/help_funcs.h"
#include "wLua/UObjectHeaders.h"
#include "GameLogic/PlantMine/PlantMine.h"
#include "AzureLuaIntegration.h"

namespace LuaPlantMine
{
int32 SetHitDown(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PlantMine",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PlantMine must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool bHitDown;
		bool bPlayAnim;
	} Params;
	Params.bHitDown = !!(lua_toboolean(InScriptContext, 2));
	Params.bPlayAnim = !!(lua_toboolean(InScriptContext, 3));
#if UE_GAME
	APlantMine * This = (APlantMine *)Obj;
	This->SetHitDown(Params.bHitDown,Params.bPlayAnim);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetHitDown"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(bool*)(params.GetStructMemory() + 0) = Params.bHitDown;
		*(bool*)(params.GetStructMemory() + 1) = Params.bPlayAnim;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.bHitDown = *(bool*)(params.GetStructMemory() + 0);
		Params.bPlayAnim = *(bool*)(params.GetStructMemory() + 1);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 Get_SlotOnTree(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PlantMine",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PlantMine must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(APlantMine::StaticClass(), TEXT("SlotOnTree"));
	if(!Property) { check(false); return 0;}
	int32 PropertyValue = int32();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushinteger(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_SlotOnTree(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PlantMine",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PlantMine must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(APlantMine::StaticClass(), TEXT("SlotOnTree"));
	if(!Property) { check(false); return 0;}
	int32 PropertyValue = (luaL_checkint(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_UsePhysics(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PlantMine",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PlantMine must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(APlantMine::StaticClass(), TEXT("UsePhysics"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = bool();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_UsePhysics(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PlantMine",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PlantMine must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(APlantMine::StaticClass(), TEXT("UsePhysics"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_PhysicsLastTime(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PlantMine",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PlantMine must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(APlantMine::StaticClass(), TEXT("PhysicsLastTime"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_PhysicsLastTime(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PlantMine",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PlantMine must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(APlantMine::StaticClass(), TEXT("PhysicsLastTime"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 New(lua_State* InScriptContext)
{
	UObject* Outer = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Object");
	FName Name = FName(luaL_checkstring(InScriptContext, 2));
	UObject* Obj = NewObject<APlantMine>(Outer, Name);
	wLua::FLuaUtils::ReturnUObject(InScriptContext,Obj);
	return 1;
}

int32 Destroy(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PlantMine",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PlantMine must be non-null"); lua_error(InScriptContext);  return 0;}
		AActor * actor = Cast<AActor>(Obj);
		actor->Destroy();
		userdata->flag |= wLua::LuaObjectFlag::DESTROYED;
		wLua::FLuaUtils::RemoveObjectReference(Obj, userdata->stamp, InScriptContext);
#ifdef AZURE_BUILD_WLUACHECK
		UE_LOG(LogAzure, Warning, TEXT("Destroy PlantMine: %x userdata:%x   stamp:%x"),Obj,userdata,userdata->stamp);
#endif
	return 0;
}

int32 Class(lua_State* InScriptContext)
{
	UClass* Class = APlantMine::StaticClass();
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Class);
	return 1;
}

const luaL_Reg Lib_Funcs[] =
{
	{ "New", New },
	{ "Destroy", Destroy },
	{ "Class", Class },
	{ "SetHitDown", SetHitDown },
	{ "Get_SlotOnTree", Get_SlotOnTree },
	{ "Set_SlotOnTree", Set_SlotOnTree },
	{ "Get_UsePhysics", Get_UsePhysics },
	{ "Set_UsePhysics", Set_UsePhysics },
	{ "Get_PhysicsLastTime", Get_PhysicsLastTime },
	{ "Set_PhysicsLastTime", Set_PhysicsLastTime },
	{ "is_nil", wLua::LuaStatic::isnil },
	{ "__gc", wLua::LuaStatic::removeUClassFrameCache },
	{ NULL, NULL }
};

void Register(lua_State *InScriptContext)
{
	lua_newtable(InScriptContext);
	luaL_register(InScriptContext, NULL, Lib_Funcs);
	AzureHelpFuncs::AuxRegister(InScriptContext, "PlantMine");
}
void SetMtLink(lua_State *InScriptContext)
{
	AzureHelpFuncs::AuxSetMtLink(InScriptContext, "PlantMine", "Actor",USERDATATYPE_UOBJECT);
}

}