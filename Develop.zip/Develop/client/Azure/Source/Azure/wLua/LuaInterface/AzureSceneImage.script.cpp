#include "Azure.h"
#include "Utility/help_funcs.h"
#include "wLua/UObjectHeaders.h"
#include "AzureSceneImage.h"
#include "AzureLuaIntegration.h"

namespace LuaAzureSceneImage
{
int32 SetWorldRotation(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureSceneImage",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureSceneImage must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float InRoll;
		float InPitch;
		float InYaw;
	} Params;
	Params.InRoll = (float)(luaL_checknumber(InScriptContext, 2));
	Params.InPitch = (float)(luaL_checknumber(InScriptContext, 3));
	Params.InYaw = (float)(luaL_checknumber(InScriptContext, 4));
#if UE_GAME
	UAzureSceneImage * This = (UAzureSceneImage *)Obj;
	This->SetWorldRotation(Params.InRoll,Params.InPitch,Params.InYaw);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetWorldRotation"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(float*)(params.GetStructMemory() + 0) = Params.InRoll;
		*(float*)(params.GetStructMemory() + 4) = Params.InPitch;
		*(float*)(params.GetStructMemory() + 8) = Params.InYaw;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.InRoll = *(float*)(params.GetStructMemory() + 0);
		Params.InPitch = *(float*)(params.GetStructMemory() + 4);
		Params.InYaw = *(float*)(params.GetStructMemory() + 8);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetWorldPosition(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureSceneImage",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureSceneImage must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float x;
		float y;
		float z;
	} Params;
	Params.x = (float)(luaL_checknumber(InScriptContext, 2));
	Params.y = (float)(luaL_checknumber(InScriptContext, 3));
	Params.z = (float)(luaL_checknumber(InScriptContext, 4));
#if UE_GAME
	UAzureSceneImage * This = (UAzureSceneImage *)Obj;
	This->SetWorldPosition(Params.x,Params.y,Params.z);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetWorldPosition"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(float*)(params.GetStructMemory() + 0) = Params.x;
		*(float*)(params.GetStructMemory() + 4) = Params.y;
		*(float*)(params.GetStructMemory() + 8) = Params.z;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.x = *(float*)(params.GetStructMemory() + 0);
		Params.y = *(float*)(params.GetStructMemory() + 4);
		Params.z = *(float*)(params.GetStructMemory() + 8);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetOrthoWidth(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureSceneImage",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureSceneImage must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float OrthoWidth;
	} Params;
	Params.OrthoWidth = (float)(luaL_checknumber(InScriptContext, 2));
#if UE_GAME
	UAzureSceneImage * This = (UAzureSceneImage *)Obj;
	This->SetOrthoWidth(Params.OrthoWidth);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetOrthoWidth"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(float*)(params.GetStructMemory() + 0) = Params.OrthoWidth;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.OrthoWidth = *(float*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetMaterial(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureSceneImage",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureSceneImage must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		UMaterial* InMaterial = nullptr;
	} Params;
	Params.InMaterial = (UMaterial*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"Material");;
#if UE_GAME
	UAzureSceneImage * This = (UAzureSceneImage *)Obj;
	This->SetMaterial(Params.InMaterial);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetMaterial"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(UMaterial**)(params.GetStructMemory() + 0) = Params.InMaterial;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.InMaterial = *(UMaterial**)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetImageSize(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureSceneImage",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureSceneImage must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FVector2D InValue;
	} Params;
	Params.InValue = (wLua::FLuaVector2D::Get(InScriptContext, 2));
#if UE_GAME
	UAzureSceneImage * This = (UAzureSceneImage *)Obj;
	This->SetImageSize(Params.InValue);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetImageSize"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FVector2D*)(params.GetStructMemory() + 0) = Params.InValue;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.InValue = *(FVector2D*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetFieldOfView(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureSceneImage",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureSceneImage must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float InFieldOfView;
	} Params;
	Params.InFieldOfView = (float)(luaL_checknumber(InScriptContext, 2));
#if UE_GAME
	UAzureSceneImage * This = (UAzureSceneImage *)Obj;
	This->SetFieldOfView(Params.InFieldOfView);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetFieldOfView"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(float*)(params.GetStructMemory() + 0) = Params.InFieldOfView;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.InFieldOfView = *(float*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 ReplaceMovableIndirectLighting(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureSceneImage",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureSceneImage must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool bReplace;
		TArray<float> Params;
	} Params;
	Params.bReplace = !!(lua_toboolean(InScriptContext, 2));
	Params.Params = [](lua_State * _InScriptContext){ TArray<float> ret; lua_pushnil(_InScriptContext); while(lua_next(_InScriptContext,3)!=0){ float item = (float)(luaL_checknumber(_InScriptContext, -1)); ret.Add(item); lua_pop(_InScriptContext,1);  } return ret; }(InScriptContext);;
#if UE_GAME
	UAzureSceneImage * This = (UAzureSceneImage *)Obj;
	This->ReplaceMovableIndirectLighting(Params.bReplace,Params.Params);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("ReplaceMovableIndirectLighting"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(bool*)(params.GetStructMemory() + 0) = Params.bReplace;
		*(TArray<float>*)(params.GetStructMemory() + 8) = Params.Params;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.bReplace = *(bool*)(params.GetStructMemory() + 0);
		Params.Params = *(TArray<float>*)(params.GetStructMemory() + 8);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 ReplaceDirectionalLight(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureSceneImage",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureSceneImage must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool bReplace;
		TArray<float> color;
		TArray<float> dir;
	} Params;
	Params.bReplace = !!(lua_toboolean(InScriptContext, 2));
	Params.color = [](lua_State * _InScriptContext){ TArray<float> ret; lua_pushnil(_InScriptContext); while(lua_next(_InScriptContext,3)!=0){ float item = (float)(luaL_checknumber(_InScriptContext, -1)); ret.Add(item); lua_pop(_InScriptContext,1);  } return ret; }(InScriptContext);;
	Params.dir = [](lua_State * _InScriptContext){ TArray<float> ret; lua_pushnil(_InScriptContext); while(lua_next(_InScriptContext,4)!=0){ float item = (float)(luaL_checknumber(_InScriptContext, -1)); ret.Add(item); lua_pop(_InScriptContext,1);  } return ret; }(InScriptContext);;
#if UE_GAME
	UAzureSceneImage * This = (UAzureSceneImage *)Obj;
	This->ReplaceDirectionalLight(Params.bReplace,Params.color,Params.dir);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("ReplaceDirectionalLight"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(bool*)(params.GetStructMemory() + 0) = Params.bReplace;
		*(TArray<float>*)(params.GetStructMemory() + 8) = Params.color;
		*(TArray<float>*)(params.GetStructMemory() + 24) = Params.dir;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.bReplace = *(bool*)(params.GetStructMemory() + 0);
		Params.color = *(TArray<float>*)(params.GetStructMemory() + 8);
		Params.dir = *(TArray<float>*)(params.GetStructMemory() + 24);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 RemoveShowOnlyActor(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureSceneImage",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureSceneImage must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		AActor* Actor = nullptr;
	} Params;
	Params.Actor = (AActor*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"Actor");;
#if UE_GAME
	UAzureSceneImage * This = (UAzureSceneImage *)Obj;
	This->RemoveShowOnlyActor(Params.Actor);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("RemoveShowOnlyActor"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(AActor**)(params.GetStructMemory() + 0) = Params.Actor;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.Actor = *(AActor**)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 GetMaterialInstance(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureSceneImage",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureSceneImage must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		UMaterialInstanceDynamic* ReturnValue = nullptr;
	} Params;
#if UE_GAME
	UAzureSceneImage * This = (UAzureSceneImage *)Obj;
	Params.ReturnValue = This->GetMaterialInstance();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetMaterialInstance"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(UMaterialInstanceDynamic**)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 ClearShowOnlyActor(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureSceneImage",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureSceneImage must be non-null"); lua_error(InScriptContext);  return 0;}
#if UE_GAME
	UAzureSceneImage * This = (UAzureSceneImage *)Obj;
	This->ClearShowOnlyActor();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("ClearShowOnlyActor"));
	if(!Function) { check(false); return 0;}
	Obj->ProcessEvent(Function, NULL);
#endif
	return 0;
}

int32 CaptureEnable(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureSceneImage",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureSceneImage must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool InEnable;
	} Params;
	Params.InEnable = !!(lua_toboolean(InScriptContext, 2));
#if UE_GAME
	UAzureSceneImage * This = (UAzureSceneImage *)Obj;
	This->CaptureEnable(Params.InEnable);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("CaptureEnable"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(bool*)(params.GetStructMemory() + 0) = Params.InEnable;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.InEnable = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 AddShowOnlyActor(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureSceneImage",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureSceneImage must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		AActor* Actor = nullptr;
	} Params;
	Params.Actor = (AActor*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"Actor");;
#if UE_GAME
	UAzureSceneImage * This = (UAzureSceneImage *)Obj;
	This->AddShowOnlyActor(Params.Actor);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("AddShowOnlyActor"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(AActor**)(params.GetStructMemory() + 0) = Params.Actor;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.Actor = *(AActor**)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 Get_bDragEnabled(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureSceneImage",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureSceneImage must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzureSceneImage::StaticClass(), TEXT("bDragEnabled"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = bool();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_bUsePostProcess(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureSceneImage",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureSceneImage must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzureSceneImage::StaticClass(), TEXT("bUsePostProcess"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = bool();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 New(lua_State* InScriptContext)
{
	UObject* Outer = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Object");
	FName Name = FName(luaL_checkstring(InScriptContext, 2));
	UObject* Obj = NewObject<UAzureSceneImage>(Outer, Name);
	wLua::FLuaUtils::ReturnUObject(InScriptContext,Obj);
	return 1;
}

int32 Destroy(lua_State* InScriptContext)
{
	return 0;
}

int32 Class(lua_State* InScriptContext)
{
	UClass* Class = UAzureSceneImage::StaticClass();
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Class);
	return 1;
}

const luaL_Reg Lib_Funcs[] =
{
	{ "New", New },
	{ "Destroy", Destroy },
	{ "Class", Class },
	{ "SetWorldRotation", SetWorldRotation },
	{ "SetWorldPosition", SetWorldPosition },
	{ "SetOrthoWidth", SetOrthoWidth },
	{ "SetMaterial", SetMaterial },
	{ "SetImageSize", SetImageSize },
	{ "SetFieldOfView", SetFieldOfView },
	{ "ReplaceMovableIndirectLighting", ReplaceMovableIndirectLighting },
	{ "ReplaceDirectionalLight", ReplaceDirectionalLight },
	{ "RemoveShowOnlyActor", RemoveShowOnlyActor },
	{ "GetMaterialInstance", GetMaterialInstance },
	{ "ClearShowOnlyActor", ClearShowOnlyActor },
	{ "CaptureEnable", CaptureEnable },
	{ "AddShowOnlyActor", AddShowOnlyActor },
	{ "Get_bDragEnabled", Get_bDragEnabled },
	{ "Get_bUsePostProcess", Get_bUsePostProcess },
	{ "is_nil", wLua::LuaStatic::isnil },
	{ "__gc", wLua::LuaStatic::removeUClassFrameCache },
	{ NULL, NULL }
};

void Register(lua_State *InScriptContext)
{
	lua_newtable(InScriptContext);
	luaL_register(InScriptContext, NULL, Lib_Funcs);
	AzureHelpFuncs::AuxRegister(InScriptContext, "AzureSceneImage");
}
void SetMtLink(lua_State *InScriptContext)
{
	AzureHelpFuncs::AuxSetMtLink(InScriptContext, "AzureSceneImage", "Widget",USERDATATYPE_UOBJECT);
}

}