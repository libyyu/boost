#include "Azure.h"
#include "Utility/help_funcs.h"
#include "wLua/UObjectHeaders.h"
#include "Engine/GameViewportClient.h"
#include "AzureLuaIntegration.h"

namespace LuaGameViewportClient
{
int32 GetMousePosition(lua_State*);
int32 SetIgnoreInput(lua_State*);
int32 IgnoreInput(lua_State*);
int32 SetCaptureMouseOnClick(lua_State*);
int32 CaptureMouseOnClick(lua_State*);
int32 LockDuringCapture(lua_State*);
int32 ShouldAlwaysLockMouse(lua_State*);
int32 SetMouseLockMode(lua_State*);
int32 SetHideCursorDuringCapture(lua_State*);
int32 HideCursorDuringCapture(lua_State*);
int32 IsSimulateInEditorViewport(lua_State*);

int32 SSSwapControllers(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"GameViewportClient",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"GameViewportClient must be non-null"); lua_error(InScriptContext);  return 0;}
#if UE_GAME
	UGameViewportClient * This = (UGameViewportClient *)Obj;
	This->SSSwapControllers();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SSSwapControllers"));
	if(!Function) { check(false); return 0;}
	Obj->ProcessEvent(Function, NULL);
#endif
	return 0;
}

int32 ShowTitleSafeArea(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"GameViewportClient",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"GameViewportClient must be non-null"); lua_error(InScriptContext);  return 0;}
#if UE_GAME
	UGameViewportClient * This = (UGameViewportClient *)Obj;
	This->ShowTitleSafeArea();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("ShowTitleSafeArea"));
	if(!Function) { check(false); return 0;}
	Obj->ProcessEvent(Function, NULL);
#endif
	return 0;
}

int32 SetConsoleTarget(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"GameViewportClient",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"GameViewportClient must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		int32 PlayerIndex;
	} Params;
	Params.PlayerIndex = (luaL_checkint(InScriptContext, 2));
#if UE_GAME
	UGameViewportClient * This = (UGameViewportClient *)Obj;
	This->SetConsoleTarget(Params.PlayerIndex);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetConsoleTarget"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(int32*)(params.GetStructMemory() + 0) = Params.PlayerIndex;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.PlayerIndex = *(int32*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 GetViewportOverlayBatchCountTotal(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"GameViewportClient",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"GameViewportClient must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		int32 ReturnValue;
	} Params;
#if UE_GAME
	UGameViewportClient * This = (UGameViewportClient *)Obj;
	Params.ReturnValue = This->GetViewportOverlayBatchCountTotal();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetViewportOverlayBatchCountTotal"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(int32*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushinteger(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetViewportOverlayBatchCountSelf(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"GameViewportClient",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"GameViewportClient must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		int32 ReturnValue;
	} Params;
#if UE_GAME
	UGameViewportClient * This = (UGameViewportClient *)Obj;
	Params.ReturnValue = This->GetViewportOverlayBatchCountSelf();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetViewportOverlayBatchCountSelf"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(int32*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushinteger(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 New(lua_State* InScriptContext)
{
	UObject* Outer = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Object");
	FName Name = FName(luaL_checkstring(InScriptContext, 2));
	UObject* Obj = NewObject<UGameViewportClient>(Outer, Name);
	wLua::FLuaUtils::ReturnUObject(InScriptContext,Obj);
	return 1;
}

int32 Destroy(lua_State* InScriptContext)
{
	return 0;
}

int32 Class(lua_State* InScriptContext)
{
	UClass* Class = UGameViewportClient::StaticClass();
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Class);
	return 1;
}

const luaL_Reg Lib_Funcs[] =
{
	{ "New", New },
	{ "Destroy", Destroy },
	{ "Class", Class },
	{ "SSSwapControllers", SSSwapControllers },
	{ "ShowTitleSafeArea", ShowTitleSafeArea },
	{ "SetConsoleTarget", SetConsoleTarget },
	{ "GetViewportOverlayBatchCountTotal", GetViewportOverlayBatchCountTotal },
	{ "GetViewportOverlayBatchCountSelf", GetViewportOverlayBatchCountSelf },
	{ "GetMousePosition", GetMousePosition },
	{ "SetIgnoreInput", SetIgnoreInput },
	{ "IgnoreInput", IgnoreInput },
	{ "SetCaptureMouseOnClick", SetCaptureMouseOnClick },
	{ "CaptureMouseOnClick", CaptureMouseOnClick },
	{ "LockDuringCapture", LockDuringCapture },
	{ "ShouldAlwaysLockMouse", ShouldAlwaysLockMouse },
	{ "SetMouseLockMode", SetMouseLockMode },
	{ "SetHideCursorDuringCapture", SetHideCursorDuringCapture },
	{ "HideCursorDuringCapture", HideCursorDuringCapture },
	{ "IsSimulateInEditorViewport", IsSimulateInEditorViewport },
	{ "is_nil", wLua::LuaStatic::isnil },
	{ "__gc", wLua::LuaStatic::removeUClassFrameCache },
	{ NULL, NULL }
};

void Register(lua_State *InScriptContext)
{
	lua_newtable(InScriptContext);
	luaL_register(InScriptContext, NULL, Lib_Funcs);
	AzureHelpFuncs::AuxRegister(InScriptContext, "GameViewportClient");
}
void SetMtLink(lua_State *InScriptContext)
{
	AzureHelpFuncs::AuxSetMtLink(InScriptContext, "GameViewportClient", "Object",USERDATATYPE_UOBJECT);
}

}