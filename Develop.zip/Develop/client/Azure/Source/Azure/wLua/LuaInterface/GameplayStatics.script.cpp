#include "Azure.h"
#include "Utility/help_funcs.h"
#include "wLua/UObjectHeaders.h"
#include "Kismet/GameplayStatics.h"
#include "AzureLuaIntegration.h"

namespace LuaGameplayStatics
{
int32 ProjectWorldToScreenExpand(lua_State*);

int32 SuggestProjectileVelocity_CustomArc(lua_State* InScriptContext)
{
	UClass * Obj = UGameplayStatics::StaticClass(); 
	struct FDispatchParams
	{
		UObject* WorldContextObject = nullptr;
		FVector OutLaunchVelocity;
		FVector StartPos;
		FVector EndPos;
		float OverrideGravityZ;
		float ArcParam;
		bool ReturnValue;
	} Params;
	Params.WorldContextObject = (UObject*)wLua::FLuaUtils::GetUObject(InScriptContext,1,"Object");;
	Params.StartPos = (wLua::FLuaVector::Get(InScriptContext, 3));
	Params.EndPos = (wLua::FLuaVector::Get(InScriptContext, 4));
	Params.OverrideGravityZ = lua_isnoneornil(InScriptContext,5) ? float(0.000000) : (float)(luaL_checknumber(InScriptContext, 5));
	Params.ArcParam = lua_isnoneornil(InScriptContext,6) ? float(0.500000) : (float)(luaL_checknumber(InScriptContext, 6));
#if UE_GAME
	Params.ReturnValue = UGameplayStatics::SuggestProjectileVelocity_CustomArc(Params.WorldContextObject,Params.OutLaunchVelocity,Params.StartPos,Params.EndPos,Params.OverrideGravityZ,Params.ArcParam);
#else
	UFunction* Function = Obj->FindFunctionByName(TEXT("SuggestProjectileVelocity_CustomArc"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(UObject**)(params.GetStructMemory() + 0) = Params.WorldContextObject;
		*(FVector*)(params.GetStructMemory() + 20) = Params.StartPos;
		*(FVector*)(params.GetStructMemory() + 32) = Params.EndPos;
		*(float*)(params.GetStructMemory() + 44) = Params.OverrideGravityZ;
		*(float*)(params.GetStructMemory() + 48) = Params.ArcParam;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.WorldContextObject = *(UObject**)(params.GetStructMemory() + 0);
		Params.OutLaunchVelocity = *(FVector*)(params.GetStructMemory() + 8);
		Params.StartPos = *(FVector*)(params.GetStructMemory() + 20);
		Params.EndPos = *(FVector*)(params.GetStructMemory() + 32);
		Params.OverrideGravityZ = *(float*)(params.GetStructMemory() + 44);
		Params.ArcParam = *(float*)(params.GetStructMemory() + 48);
		Params.ReturnValue = *(bool*)(params.GetStructMemory() + 52);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushboolean(InScriptContext, Params.ReturnValue);
	wLua::FLuaVector::Return(InScriptContext, Params.OutLaunchVelocity);
	return 2;
}

int32 SpawnSoundAttached(lua_State* InScriptContext)
{
	UClass * Obj = UGameplayStatics::StaticClass(); 
	struct FDispatchParams
	{
		USoundBase* Sound = nullptr;
		USceneComponent* AttachToComponent = nullptr;
		FName AttachPointName;
		FVector Location;
		FRotator Rotation;
		TEnumAsByte<EAttachLocation::Type> LocationType;
		bool bStopWhenAttachedToDestroyed;
		float VolumeMultiplier;
		float PitchMultiplier;
		float StartTime;
		USoundAttenuation* AttenuationSettings = nullptr;
		USoundConcurrency* ConcurrencySettings = nullptr;
		bool bAutoDestroy;
		UAudioComponent* ReturnValue = nullptr;
	} Params;
	Params.Sound = (USoundBase*)wLua::FLuaUtils::GetUObject(InScriptContext,1,"SoundBase");;
	Params.AttachToComponent = (USceneComponent*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"SceneComponent");;
	Params.AttachPointName = lua_isnoneornil(InScriptContext,3) ? FName(TEXT("")) : FName(UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 3)));
	Params.Location = lua_isnoneornil(InScriptContext,4) ? FVector(0.f) : (wLua::FLuaVector::Get(InScriptContext, 4));
	Params.Rotation = lua_isnoneornil(InScriptContext,5) ? FRotator(0.f) : (wLua::FLuaRotator::Get(InScriptContext, 5));
	Params.LocationType = lua_isnoneornil(InScriptContext,6) ? TEnumAsByte<EAttachLocation::Type>(EAttachLocation::Type::KeepRelativeOffset) : (TEnumAsByte<EAttachLocation::Type>)(luaL_checkint(InScriptContext, 6));
	Params.bStopWhenAttachedToDestroyed = lua_isnoneornil(InScriptContext,7) ? bool(false) : !!(lua_toboolean(InScriptContext, 7));
	Params.VolumeMultiplier = lua_isnoneornil(InScriptContext,8) ? float(1.000000) : (float)(luaL_checknumber(InScriptContext, 8));
	Params.PitchMultiplier = lua_isnoneornil(InScriptContext,9) ? float(1.000000) : (float)(luaL_checknumber(InScriptContext, 9));
	Params.StartTime = lua_isnoneornil(InScriptContext,10) ? float(0.000000) : (float)(luaL_checknumber(InScriptContext, 10));
	Params.AttenuationSettings = lua_isnoneornil(InScriptContext,11) ? nullptr : (USoundAttenuation*)wLua::FLuaUtils::GetUObject(InScriptContext,11,"SoundAttenuation");;
	Params.ConcurrencySettings = lua_isnoneornil(InScriptContext,12) ? nullptr : (USoundConcurrency*)wLua::FLuaUtils::GetUObject(InScriptContext,12,"SoundConcurrency");;
	Params.bAutoDestroy = lua_isnoneornil(InScriptContext,13) ? bool(true) : !!(lua_toboolean(InScriptContext, 13));
#if UE_GAME
	Params.ReturnValue = UGameplayStatics::SpawnSoundAttached(Params.Sound,Params.AttachToComponent,Params.AttachPointName,Params.Location,Params.Rotation,Params.LocationType,Params.bStopWhenAttachedToDestroyed,Params.VolumeMultiplier,Params.PitchMultiplier,Params.StartTime,Params.AttenuationSettings,Params.ConcurrencySettings,Params.bAutoDestroy);
#else
	UFunction* Function = Obj->FindFunctionByName(TEXT("SpawnSoundAttached"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(USoundBase**)(params.GetStructMemory() + 0) = Params.Sound;
		*(USceneComponent**)(params.GetStructMemory() + 8) = Params.AttachToComponent;
		*(FName*)(params.GetStructMemory() + 16) = Params.AttachPointName;
		*(FVector*)(params.GetStructMemory() + 28) = Params.Location;
		*(FRotator*)(params.GetStructMemory() + 40) = Params.Rotation;
		*(TEnumAsByte<EAttachLocation::Type>*)(params.GetStructMemory() + 52) = Params.LocationType;
		*(bool*)(params.GetStructMemory() + 53) = Params.bStopWhenAttachedToDestroyed;
		*(float*)(params.GetStructMemory() + 56) = Params.VolumeMultiplier;
		*(float*)(params.GetStructMemory() + 60) = Params.PitchMultiplier;
		*(float*)(params.GetStructMemory() + 64) = Params.StartTime;
		*(USoundAttenuation**)(params.GetStructMemory() + 72) = Params.AttenuationSettings;
		*(USoundConcurrency**)(params.GetStructMemory() + 80) = Params.ConcurrencySettings;
		*(bool*)(params.GetStructMemory() + 88) = Params.bAutoDestroy;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.Sound = *(USoundBase**)(params.GetStructMemory() + 0);
		Params.AttachToComponent = *(USceneComponent**)(params.GetStructMemory() + 8);
		Params.AttachPointName = *(FName*)(params.GetStructMemory() + 16);
		Params.Location = *(FVector*)(params.GetStructMemory() + 28);
		Params.Rotation = *(FRotator*)(params.GetStructMemory() + 40);
		Params.LocationType = *(TEnumAsByte<EAttachLocation::Type>*)(params.GetStructMemory() + 52);
		Params.bStopWhenAttachedToDestroyed = *(bool*)(params.GetStructMemory() + 53);
		Params.VolumeMultiplier = *(float*)(params.GetStructMemory() + 56);
		Params.PitchMultiplier = *(float*)(params.GetStructMemory() + 60);
		Params.StartTime = *(float*)(params.GetStructMemory() + 64);
		Params.AttenuationSettings = *(USoundAttenuation**)(params.GetStructMemory() + 72);
		Params.ConcurrencySettings = *(USoundConcurrency**)(params.GetStructMemory() + 80);
		Params.bAutoDestroy = *(bool*)(params.GetStructMemory() + 88);
		Params.ReturnValue = *(UAudioComponent**)(params.GetStructMemory() + 96);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 SpawnSoundAtLocation(lua_State* InScriptContext)
{
	UClass * Obj = UGameplayStatics::StaticClass(); 
	struct FDispatchParams
	{
		UObject* WorldContextObject = nullptr;
		USoundBase* Sound = nullptr;
		FVector Location;
		FRotator Rotation;
		float VolumeMultiplier;
		float PitchMultiplier;
		float StartTime;
		USoundAttenuation* AttenuationSettings = nullptr;
		USoundConcurrency* ConcurrencySettings = nullptr;
		bool bAutoDestroy;
		UAudioComponent* ReturnValue = nullptr;
	} Params;
	Params.WorldContextObject = (UObject*)wLua::FLuaUtils::GetUObject(InScriptContext,1,"Object");;
	Params.Sound = (USoundBase*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"SoundBase");;
	Params.Location = (wLua::FLuaVector::Get(InScriptContext, 3));
	Params.Rotation = lua_isnoneornil(InScriptContext,4) ? FRotator(0.f) : (wLua::FLuaRotator::Get(InScriptContext, 4));
	Params.VolumeMultiplier = lua_isnoneornil(InScriptContext,5) ? float(1.000000) : (float)(luaL_checknumber(InScriptContext, 5));
	Params.PitchMultiplier = lua_isnoneornil(InScriptContext,6) ? float(1.000000) : (float)(luaL_checknumber(InScriptContext, 6));
	Params.StartTime = lua_isnoneornil(InScriptContext,7) ? float(0.000000) : (float)(luaL_checknumber(InScriptContext, 7));
	Params.AttenuationSettings = lua_isnoneornil(InScriptContext,8) ? nullptr : (USoundAttenuation*)wLua::FLuaUtils::GetUObject(InScriptContext,8,"SoundAttenuation");;
	Params.ConcurrencySettings = lua_isnoneornil(InScriptContext,9) ? nullptr : (USoundConcurrency*)wLua::FLuaUtils::GetUObject(InScriptContext,9,"SoundConcurrency");;
	Params.bAutoDestroy = lua_isnoneornil(InScriptContext,10) ? bool(true) : !!(lua_toboolean(InScriptContext, 10));
#if UE_GAME
	Params.ReturnValue = UGameplayStatics::SpawnSoundAtLocation(Params.WorldContextObject,Params.Sound,Params.Location,Params.Rotation,Params.VolumeMultiplier,Params.PitchMultiplier,Params.StartTime,Params.AttenuationSettings,Params.ConcurrencySettings,Params.bAutoDestroy);
#else
	UFunction* Function = Obj->FindFunctionByName(TEXT("SpawnSoundAtLocation"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(UObject**)(params.GetStructMemory() + 0) = Params.WorldContextObject;
		*(USoundBase**)(params.GetStructMemory() + 8) = Params.Sound;
		*(FVector*)(params.GetStructMemory() + 16) = Params.Location;
		*(FRotator*)(params.GetStructMemory() + 28) = Params.Rotation;
		*(float*)(params.GetStructMemory() + 40) = Params.VolumeMultiplier;
		*(float*)(params.GetStructMemory() + 44) = Params.PitchMultiplier;
		*(float*)(params.GetStructMemory() + 48) = Params.StartTime;
		*(USoundAttenuation**)(params.GetStructMemory() + 56) = Params.AttenuationSettings;
		*(USoundConcurrency**)(params.GetStructMemory() + 64) = Params.ConcurrencySettings;
		*(bool*)(params.GetStructMemory() + 72) = Params.bAutoDestroy;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.WorldContextObject = *(UObject**)(params.GetStructMemory() + 0);
		Params.Sound = *(USoundBase**)(params.GetStructMemory() + 8);
		Params.Location = *(FVector*)(params.GetStructMemory() + 16);
		Params.Rotation = *(FRotator*)(params.GetStructMemory() + 28);
		Params.VolumeMultiplier = *(float*)(params.GetStructMemory() + 40);
		Params.PitchMultiplier = *(float*)(params.GetStructMemory() + 44);
		Params.StartTime = *(float*)(params.GetStructMemory() + 48);
		Params.AttenuationSettings = *(USoundAttenuation**)(params.GetStructMemory() + 56);
		Params.ConcurrencySettings = *(USoundConcurrency**)(params.GetStructMemory() + 64);
		Params.bAutoDestroy = *(bool*)(params.GetStructMemory() + 72);
		Params.ReturnValue = *(UAudioComponent**)(params.GetStructMemory() + 80);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 SpawnSound2D(lua_State* InScriptContext)
{
	UClass * Obj = UGameplayStatics::StaticClass(); 
	struct FDispatchParams
	{
		UObject* WorldContextObject = nullptr;
		USoundBase* Sound = nullptr;
		float VolumeMultiplier;
		float PitchMultiplier;
		float StartTime;
		USoundConcurrency* ConcurrencySettings = nullptr;
		bool bPersistAcrossLevelTransition;
		bool bAutoDestroy;
		UAudioComponent* ReturnValue = nullptr;
	} Params;
	Params.WorldContextObject = (UObject*)wLua::FLuaUtils::GetUObject(InScriptContext,1,"Object");;
	Params.Sound = (USoundBase*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"SoundBase");;
	Params.VolumeMultiplier = lua_isnoneornil(InScriptContext,3) ? float(1.000000) : (float)(luaL_checknumber(InScriptContext, 3));
	Params.PitchMultiplier = lua_isnoneornil(InScriptContext,4) ? float(1.000000) : (float)(luaL_checknumber(InScriptContext, 4));
	Params.StartTime = lua_isnoneornil(InScriptContext,5) ? float(0.000000) : (float)(luaL_checknumber(InScriptContext, 5));
	Params.ConcurrencySettings = lua_isnoneornil(InScriptContext,6) ? nullptr : (USoundConcurrency*)wLua::FLuaUtils::GetUObject(InScriptContext,6,"SoundConcurrency");;
	Params.bPersistAcrossLevelTransition = lua_isnoneornil(InScriptContext,7) ? bool(false) : !!(lua_toboolean(InScriptContext, 7));
	Params.bAutoDestroy = lua_isnoneornil(InScriptContext,8) ? bool(true) : !!(lua_toboolean(InScriptContext, 8));
#if UE_GAME
	Params.ReturnValue = UGameplayStatics::SpawnSound2D(Params.WorldContextObject,Params.Sound,Params.VolumeMultiplier,Params.PitchMultiplier,Params.StartTime,Params.ConcurrencySettings,Params.bPersistAcrossLevelTransition,Params.bAutoDestroy);
#else
	UFunction* Function = Obj->FindFunctionByName(TEXT("SpawnSound2D"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(UObject**)(params.GetStructMemory() + 0) = Params.WorldContextObject;
		*(USoundBase**)(params.GetStructMemory() + 8) = Params.Sound;
		*(float*)(params.GetStructMemory() + 16) = Params.VolumeMultiplier;
		*(float*)(params.GetStructMemory() + 20) = Params.PitchMultiplier;
		*(float*)(params.GetStructMemory() + 24) = Params.StartTime;
		*(USoundConcurrency**)(params.GetStructMemory() + 32) = Params.ConcurrencySettings;
		*(bool*)(params.GetStructMemory() + 40) = Params.bPersistAcrossLevelTransition;
		*(bool*)(params.GetStructMemory() + 41) = Params.bAutoDestroy;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.WorldContextObject = *(UObject**)(params.GetStructMemory() + 0);
		Params.Sound = *(USoundBase**)(params.GetStructMemory() + 8);
		Params.VolumeMultiplier = *(float*)(params.GetStructMemory() + 16);
		Params.PitchMultiplier = *(float*)(params.GetStructMemory() + 20);
		Params.StartTime = *(float*)(params.GetStructMemory() + 24);
		Params.ConcurrencySettings = *(USoundConcurrency**)(params.GetStructMemory() + 32);
		Params.bPersistAcrossLevelTransition = *(bool*)(params.GetStructMemory() + 40);
		Params.bAutoDestroy = *(bool*)(params.GetStructMemory() + 41);
		Params.ReturnValue = *(UAudioComponent**)(params.GetStructMemory() + 48);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 SpawnForceFeedbackAttached(lua_State* InScriptContext)
{
	UClass * Obj = UGameplayStatics::StaticClass(); 
	struct FDispatchParams
	{
		UForceFeedbackEffect* ForceFeedbackEffect = nullptr;
		USceneComponent* AttachToComponent = nullptr;
		FName AttachPointName;
		FVector Location;
		FRotator Rotation;
		TEnumAsByte<EAttachLocation::Type> LocationType;
		bool bStopWhenAttachedToDestroyed;
		bool bLooping;
		float IntensityMultiplier;
		float StartTime;
		UForceFeedbackAttenuation* AttenuationSettings = nullptr;
		bool bAutoDestroy;
		UForceFeedbackComponent* ReturnValue = nullptr;
	} Params;
	Params.ForceFeedbackEffect = (UForceFeedbackEffect*)wLua::FLuaUtils::GetUObject(InScriptContext,1,"ForceFeedbackEffect");;
	Params.AttachToComponent = (USceneComponent*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"SceneComponent");;
	Params.AttachPointName = lua_isnoneornil(InScriptContext,3) ? FName(TEXT("")) : FName(UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 3)));
	Params.Location = lua_isnoneornil(InScriptContext,4) ? FVector(0.f) : (wLua::FLuaVector::Get(InScriptContext, 4));
	Params.Rotation = lua_isnoneornil(InScriptContext,5) ? FRotator(0.f) : (wLua::FLuaRotator::Get(InScriptContext, 5));
	Params.LocationType = lua_isnoneornil(InScriptContext,6) ? TEnumAsByte<EAttachLocation::Type>(EAttachLocation::Type::KeepRelativeOffset) : (TEnumAsByte<EAttachLocation::Type>)(luaL_checkint(InScriptContext, 6));
	Params.bStopWhenAttachedToDestroyed = lua_isnoneornil(InScriptContext,7) ? bool(false) : !!(lua_toboolean(InScriptContext, 7));
	Params.bLooping = lua_isnoneornil(InScriptContext,8) ? bool(false) : !!(lua_toboolean(InScriptContext, 8));
	Params.IntensityMultiplier = lua_isnoneornil(InScriptContext,9) ? float(1.000000) : (float)(luaL_checknumber(InScriptContext, 9));
	Params.StartTime = lua_isnoneornil(InScriptContext,10) ? float(0.000000) : (float)(luaL_checknumber(InScriptContext, 10));
	Params.AttenuationSettings = lua_isnoneornil(InScriptContext,11) ? nullptr : (UForceFeedbackAttenuation*)wLua::FLuaUtils::GetUObject(InScriptContext,11,"ForceFeedbackAttenuation");;
	Params.bAutoDestroy = lua_isnoneornil(InScriptContext,12) ? bool(true) : !!(lua_toboolean(InScriptContext, 12));
#if UE_GAME
	Params.ReturnValue = UGameplayStatics::SpawnForceFeedbackAttached(Params.ForceFeedbackEffect,Params.AttachToComponent,Params.AttachPointName,Params.Location,Params.Rotation,Params.LocationType,Params.bStopWhenAttachedToDestroyed,Params.bLooping,Params.IntensityMultiplier,Params.StartTime,Params.AttenuationSettings,Params.bAutoDestroy);
#else
	UFunction* Function = Obj->FindFunctionByName(TEXT("SpawnForceFeedbackAttached"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(UForceFeedbackEffect**)(params.GetStructMemory() + 0) = Params.ForceFeedbackEffect;
		*(USceneComponent**)(params.GetStructMemory() + 8) = Params.AttachToComponent;
		*(FName*)(params.GetStructMemory() + 16) = Params.AttachPointName;
		*(FVector*)(params.GetStructMemory() + 28) = Params.Location;
		*(FRotator*)(params.GetStructMemory() + 40) = Params.Rotation;
		*(TEnumAsByte<EAttachLocation::Type>*)(params.GetStructMemory() + 52) = Params.LocationType;
		*(bool*)(params.GetStructMemory() + 53) = Params.bStopWhenAttachedToDestroyed;
		*(bool*)(params.GetStructMemory() + 54) = Params.bLooping;
		*(float*)(params.GetStructMemory() + 56) = Params.IntensityMultiplier;
		*(float*)(params.GetStructMemory() + 60) = Params.StartTime;
		*(UForceFeedbackAttenuation**)(params.GetStructMemory() + 64) = Params.AttenuationSettings;
		*(bool*)(params.GetStructMemory() + 72) = Params.bAutoDestroy;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ForceFeedbackEffect = *(UForceFeedbackEffect**)(params.GetStructMemory() + 0);
		Params.AttachToComponent = *(USceneComponent**)(params.GetStructMemory() + 8);
		Params.AttachPointName = *(FName*)(params.GetStructMemory() + 16);
		Params.Location = *(FVector*)(params.GetStructMemory() + 28);
		Params.Rotation = *(FRotator*)(params.GetStructMemory() + 40);
		Params.LocationType = *(TEnumAsByte<EAttachLocation::Type>*)(params.GetStructMemory() + 52);
		Params.bStopWhenAttachedToDestroyed = *(bool*)(params.GetStructMemory() + 53);
		Params.bLooping = *(bool*)(params.GetStructMemory() + 54);
		Params.IntensityMultiplier = *(float*)(params.GetStructMemory() + 56);
		Params.StartTime = *(float*)(params.GetStructMemory() + 60);
		Params.AttenuationSettings = *(UForceFeedbackAttenuation**)(params.GetStructMemory() + 64);
		Params.bAutoDestroy = *(bool*)(params.GetStructMemory() + 72);
		Params.ReturnValue = *(UForceFeedbackComponent**)(params.GetStructMemory() + 80);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 SpawnForceFeedbackAtLocation(lua_State* InScriptContext)
{
	UClass * Obj = UGameplayStatics::StaticClass(); 
	struct FDispatchParams
	{
		UObject* WorldContextObject = nullptr;
		UForceFeedbackEffect* ForceFeedbackEffect = nullptr;
		FVector Location;
		FRotator Rotation;
		bool bLooping;
		float IntensityMultiplier;
		float StartTime;
		UForceFeedbackAttenuation* AttenuationSettings = nullptr;
		bool bAutoDestroy;
		UForceFeedbackComponent* ReturnValue = nullptr;
	} Params;
	Params.WorldContextObject = (UObject*)wLua::FLuaUtils::GetUObject(InScriptContext,1,"Object");;
	Params.ForceFeedbackEffect = (UForceFeedbackEffect*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"ForceFeedbackEffect");;
	Params.Location = (wLua::FLuaVector::Get(InScriptContext, 3));
	Params.Rotation = lua_isnoneornil(InScriptContext,4) ? FRotator(0.f) : (wLua::FLuaRotator::Get(InScriptContext, 4));
	Params.bLooping = lua_isnoneornil(InScriptContext,5) ? bool(false) : !!(lua_toboolean(InScriptContext, 5));
	Params.IntensityMultiplier = lua_isnoneornil(InScriptContext,6) ? float(1.000000) : (float)(luaL_checknumber(InScriptContext, 6));
	Params.StartTime = lua_isnoneornil(InScriptContext,7) ? float(0.000000) : (float)(luaL_checknumber(InScriptContext, 7));
	Params.AttenuationSettings = lua_isnoneornil(InScriptContext,8) ? nullptr : (UForceFeedbackAttenuation*)wLua::FLuaUtils::GetUObject(InScriptContext,8,"ForceFeedbackAttenuation");;
	Params.bAutoDestroy = lua_isnoneornil(InScriptContext,9) ? bool(true) : !!(lua_toboolean(InScriptContext, 9));
#if UE_GAME
	Params.ReturnValue = UGameplayStatics::SpawnForceFeedbackAtLocation(Params.WorldContextObject,Params.ForceFeedbackEffect,Params.Location,Params.Rotation,Params.bLooping,Params.IntensityMultiplier,Params.StartTime,Params.AttenuationSettings,Params.bAutoDestroy);
#else
	UFunction* Function = Obj->FindFunctionByName(TEXT("SpawnForceFeedbackAtLocation"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(UObject**)(params.GetStructMemory() + 0) = Params.WorldContextObject;
		*(UForceFeedbackEffect**)(params.GetStructMemory() + 8) = Params.ForceFeedbackEffect;
		*(FVector*)(params.GetStructMemory() + 16) = Params.Location;
		*(FRotator*)(params.GetStructMemory() + 28) = Params.Rotation;
		*(bool*)(params.GetStructMemory() + 40) = Params.bLooping;
		*(float*)(params.GetStructMemory() + 44) = Params.IntensityMultiplier;
		*(float*)(params.GetStructMemory() + 48) = Params.StartTime;
		*(UForceFeedbackAttenuation**)(params.GetStructMemory() + 56) = Params.AttenuationSettings;
		*(bool*)(params.GetStructMemory() + 64) = Params.bAutoDestroy;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.WorldContextObject = *(UObject**)(params.GetStructMemory() + 0);
		Params.ForceFeedbackEffect = *(UForceFeedbackEffect**)(params.GetStructMemory() + 8);
		Params.Location = *(FVector*)(params.GetStructMemory() + 16);
		Params.Rotation = *(FRotator*)(params.GetStructMemory() + 28);
		Params.bLooping = *(bool*)(params.GetStructMemory() + 40);
		Params.IntensityMultiplier = *(float*)(params.GetStructMemory() + 44);
		Params.StartTime = *(float*)(params.GetStructMemory() + 48);
		Params.AttenuationSettings = *(UForceFeedbackAttenuation**)(params.GetStructMemory() + 56);
		Params.bAutoDestroy = *(bool*)(params.GetStructMemory() + 64);
		Params.ReturnValue = *(UForceFeedbackComponent**)(params.GetStructMemory() + 72);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 SpawnEmitterAttached(lua_State* InScriptContext)
{
	UClass * Obj = UGameplayStatics::StaticClass(); 
	struct FDispatchParams
	{
		UParticleSystem* EmitterTemplate = nullptr;
		USceneComponent* AttachToComponent = nullptr;
		FName AttachPointName;
		FVector Location;
		FRotator Rotation;
		FVector Scale;
		TEnumAsByte<EAttachLocation::Type> LocationType;
		bool bAutoDestroy;
		EPSCPoolMethod PoolingMethod;
		UParticleSystemComponent* ReturnValue = nullptr;
	} Params;
	Params.EmitterTemplate = (UParticleSystem*)wLua::FLuaUtils::GetUObject(InScriptContext,1,"ParticleSystem");;
	Params.AttachToComponent = (USceneComponent*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"SceneComponent");;
	Params.AttachPointName = lua_isnoneornil(InScriptContext,3) ? FName(TEXT("")) : FName(UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 3)));
	Params.Location = lua_isnoneornil(InScriptContext,4) ? FVector(0.f) : (wLua::FLuaVector::Get(InScriptContext, 4));
	Params.Rotation = lua_isnoneornil(InScriptContext,5) ? FRotator(0.f) : (wLua::FLuaRotator::Get(InScriptContext, 5));
	Params.Scale = lua_isnoneornil(InScriptContext,6) ? FVector(1.000000,1.000000,1.000000) : (wLua::FLuaVector::Get(InScriptContext, 6));
	Params.LocationType = lua_isnoneornil(InScriptContext,7) ? TEnumAsByte<EAttachLocation::Type>(EAttachLocation::Type::KeepRelativeOffset) : (TEnumAsByte<EAttachLocation::Type>)(luaL_checkint(InScriptContext, 7));
	Params.bAutoDestroy = lua_isnoneornil(InScriptContext,8) ? bool(true) : !!(lua_toboolean(InScriptContext, 8));
	Params.PoolingMethod = lua_isnoneornil(InScriptContext,9) ? EPSCPoolMethod(EPSCPoolMethod::None) : (EPSCPoolMethod)(luaL_checkint(InScriptContext, 9));
#if UE_GAME
	Params.ReturnValue = UGameplayStatics::SpawnEmitterAttached(Params.EmitterTemplate,Params.AttachToComponent,Params.AttachPointName,Params.Location,Params.Rotation,Params.Scale,Params.LocationType,Params.bAutoDestroy,Params.PoolingMethod);
#else
	UFunction* Function = Obj->FindFunctionByName(TEXT("SpawnEmitterAttached"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(UParticleSystem**)(params.GetStructMemory() + 0) = Params.EmitterTemplate;
		*(USceneComponent**)(params.GetStructMemory() + 8) = Params.AttachToComponent;
		*(FName*)(params.GetStructMemory() + 16) = Params.AttachPointName;
		*(FVector*)(params.GetStructMemory() + 28) = Params.Location;
		*(FRotator*)(params.GetStructMemory() + 40) = Params.Rotation;
		*(FVector*)(params.GetStructMemory() + 52) = Params.Scale;
		*(TEnumAsByte<EAttachLocation::Type>*)(params.GetStructMemory() + 64) = Params.LocationType;
		*(bool*)(params.GetStructMemory() + 65) = Params.bAutoDestroy;
		*(EPSCPoolMethod*)(params.GetStructMemory() + 66) = Params.PoolingMethod;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.EmitterTemplate = *(UParticleSystem**)(params.GetStructMemory() + 0);
		Params.AttachToComponent = *(USceneComponent**)(params.GetStructMemory() + 8);
		Params.AttachPointName = *(FName*)(params.GetStructMemory() + 16);
		Params.Location = *(FVector*)(params.GetStructMemory() + 28);
		Params.Rotation = *(FRotator*)(params.GetStructMemory() + 40);
		Params.Scale = *(FVector*)(params.GetStructMemory() + 52);
		Params.LocationType = *(TEnumAsByte<EAttachLocation::Type>*)(params.GetStructMemory() + 64);
		Params.bAutoDestroy = *(bool*)(params.GetStructMemory() + 65);
		Params.PoolingMethod = *(EPSCPoolMethod*)(params.GetStructMemory() + 66);
		Params.ReturnValue = *(UParticleSystemComponent**)(params.GetStructMemory() + 72);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 SpawnEmitterAtLocation(lua_State* InScriptContext)
{
	UClass * Obj = UGameplayStatics::StaticClass(); 
	struct FDispatchParams
	{
		UObject* WorldContextObject = nullptr;
		UParticleSystem* EmitterTemplate = nullptr;
		FVector Location;
		FRotator Rotation;
		FVector Scale;
		bool bAutoDestroy;
		EPSCPoolMethod PoolingMethod;
		UParticleSystemComponent* ReturnValue = nullptr;
	} Params;
	Params.WorldContextObject = (UObject*)wLua::FLuaUtils::GetUObject(InScriptContext,1,"Object");;
	Params.EmitterTemplate = (UParticleSystem*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"ParticleSystem");;
	Params.Location = (wLua::FLuaVector::Get(InScriptContext, 3));
	Params.Rotation = lua_isnoneornil(InScriptContext,4) ? FRotator(0.f) : (wLua::FLuaRotator::Get(InScriptContext, 4));
	Params.Scale = lua_isnoneornil(InScriptContext,5) ? FVector(1.000000,1.000000,1.000000) : (wLua::FLuaVector::Get(InScriptContext, 5));
	Params.bAutoDestroy = lua_isnoneornil(InScriptContext,6) ? bool(true) : !!(lua_toboolean(InScriptContext, 6));
	Params.PoolingMethod = lua_isnoneornil(InScriptContext,7) ? EPSCPoolMethod(EPSCPoolMethod::None) : (EPSCPoolMethod)(luaL_checkint(InScriptContext, 7));
#if UE_GAME
	Params.ReturnValue = UGameplayStatics::SpawnEmitterAtLocation(Params.WorldContextObject,Params.EmitterTemplate,Params.Location,Params.Rotation,Params.Scale,Params.bAutoDestroy,Params.PoolingMethod);
#else
	UFunction* Function = Obj->FindFunctionByName(TEXT("SpawnEmitterAtLocation"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(UObject**)(params.GetStructMemory() + 0) = Params.WorldContextObject;
		*(UParticleSystem**)(params.GetStructMemory() + 8) = Params.EmitterTemplate;
		*(FVector*)(params.GetStructMemory() + 16) = Params.Location;
		*(FRotator*)(params.GetStructMemory() + 28) = Params.Rotation;
		*(FVector*)(params.GetStructMemory() + 40) = Params.Scale;
		*(bool*)(params.GetStructMemory() + 52) = Params.bAutoDestroy;
		*(EPSCPoolMethod*)(params.GetStructMemory() + 53) = Params.PoolingMethod;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.WorldContextObject = *(UObject**)(params.GetStructMemory() + 0);
		Params.EmitterTemplate = *(UParticleSystem**)(params.GetStructMemory() + 8);
		Params.Location = *(FVector*)(params.GetStructMemory() + 16);
		Params.Rotation = *(FRotator*)(params.GetStructMemory() + 28);
		Params.Scale = *(FVector*)(params.GetStructMemory() + 40);
		Params.bAutoDestroy = *(bool*)(params.GetStructMemory() + 52);
		Params.PoolingMethod = *(EPSCPoolMethod*)(params.GetStructMemory() + 53);
		Params.ReturnValue = *(UParticleSystemComponent**)(params.GetStructMemory() + 56);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 SpawnDecalAttached(lua_State* InScriptContext)
{
	UClass * Obj = UGameplayStatics::StaticClass(); 
	struct FDispatchParams
	{
		UMaterialInterface* DecalMaterial = nullptr;
		FVector DecalSize;
		USceneComponent* AttachToComponent = nullptr;
		FName AttachPointName;
		FVector Location;
		FRotator Rotation;
		TEnumAsByte<EAttachLocation::Type> LocationType;
		float LifeSpan;
		UDecalComponent* ReturnValue = nullptr;
	} Params;
	Params.DecalMaterial = (UMaterialInterface*)wLua::FLuaUtils::GetUObject(InScriptContext,1,"MaterialInterface");;
	Params.DecalSize = (wLua::FLuaVector::Get(InScriptContext, 2));
	Params.AttachToComponent = (USceneComponent*)wLua::FLuaUtils::GetUObject(InScriptContext,3,"SceneComponent");;
	Params.AttachPointName = lua_isnoneornil(InScriptContext,4) ? FName(TEXT("")) : FName(UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 4)));
	Params.Location = lua_isnoneornil(InScriptContext,5) ? FVector(0.f) : (wLua::FLuaVector::Get(InScriptContext, 5));
	Params.Rotation = lua_isnoneornil(InScriptContext,6) ? FRotator(0.f) : (wLua::FLuaRotator::Get(InScriptContext, 6));
	Params.LocationType = lua_isnoneornil(InScriptContext,7) ? TEnumAsByte<EAttachLocation::Type>(EAttachLocation::Type::KeepRelativeOffset) : (TEnumAsByte<EAttachLocation::Type>)(luaL_checkint(InScriptContext, 7));
	Params.LifeSpan = lua_isnoneornil(InScriptContext,8) ? float(0.000000) : (float)(luaL_checknumber(InScriptContext, 8));
#if UE_GAME
	Params.ReturnValue = UGameplayStatics::SpawnDecalAttached(Params.DecalMaterial,Params.DecalSize,Params.AttachToComponent,Params.AttachPointName,Params.Location,Params.Rotation,Params.LocationType,Params.LifeSpan);
#else
	UFunction* Function = Obj->FindFunctionByName(TEXT("SpawnDecalAttached"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(UMaterialInterface**)(params.GetStructMemory() + 0) = Params.DecalMaterial;
		*(FVector*)(params.GetStructMemory() + 8) = Params.DecalSize;
		*(USceneComponent**)(params.GetStructMemory() + 24) = Params.AttachToComponent;
		*(FName*)(params.GetStructMemory() + 32) = Params.AttachPointName;
		*(FVector*)(params.GetStructMemory() + 44) = Params.Location;
		*(FRotator*)(params.GetStructMemory() + 56) = Params.Rotation;
		*(TEnumAsByte<EAttachLocation::Type>*)(params.GetStructMemory() + 68) = Params.LocationType;
		*(float*)(params.GetStructMemory() + 72) = Params.LifeSpan;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.DecalMaterial = *(UMaterialInterface**)(params.GetStructMemory() + 0);
		Params.DecalSize = *(FVector*)(params.GetStructMemory() + 8);
		Params.AttachToComponent = *(USceneComponent**)(params.GetStructMemory() + 24);
		Params.AttachPointName = *(FName*)(params.GetStructMemory() + 32);
		Params.Location = *(FVector*)(params.GetStructMemory() + 44);
		Params.Rotation = *(FRotator*)(params.GetStructMemory() + 56);
		Params.LocationType = *(TEnumAsByte<EAttachLocation::Type>*)(params.GetStructMemory() + 68);
		Params.LifeSpan = *(float*)(params.GetStructMemory() + 72);
		Params.ReturnValue = *(UDecalComponent**)(params.GetStructMemory() + 80);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 SpawnDecalAtLocation(lua_State* InScriptContext)
{
	UClass * Obj = UGameplayStatics::StaticClass(); 
	struct FDispatchParams
	{
		UObject* WorldContextObject = nullptr;
		UMaterialInterface* DecalMaterial = nullptr;
		FVector DecalSize;
		FVector Location;
		FRotator Rotation;
		float LifeSpan;
		UDecalComponent* ReturnValue = nullptr;
	} Params;
	Params.WorldContextObject = (UObject*)wLua::FLuaUtils::GetUObject(InScriptContext,1,"Object");;
	Params.DecalMaterial = (UMaterialInterface*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"MaterialInterface");;
	Params.DecalSize = (wLua::FLuaVector::Get(InScriptContext, 3));
	Params.Location = (wLua::FLuaVector::Get(InScriptContext, 4));
	Params.Rotation = lua_isnoneornil(InScriptContext,5) ? FRotator(-90.000000,0.000000,0.000000) : (wLua::FLuaRotator::Get(InScriptContext, 5));
	Params.LifeSpan = lua_isnoneornil(InScriptContext,6) ? float(0.000000) : (float)(luaL_checknumber(InScriptContext, 6));
#if UE_GAME
	Params.ReturnValue = UGameplayStatics::SpawnDecalAtLocation(Params.WorldContextObject,Params.DecalMaterial,Params.DecalSize,Params.Location,Params.Rotation,Params.LifeSpan);
#else
	UFunction* Function = Obj->FindFunctionByName(TEXT("SpawnDecalAtLocation"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(UObject**)(params.GetStructMemory() + 0) = Params.WorldContextObject;
		*(UMaterialInterface**)(params.GetStructMemory() + 8) = Params.DecalMaterial;
		*(FVector*)(params.GetStructMemory() + 16) = Params.DecalSize;
		*(FVector*)(params.GetStructMemory() + 28) = Params.Location;
		*(FRotator*)(params.GetStructMemory() + 40) = Params.Rotation;
		*(float*)(params.GetStructMemory() + 52) = Params.LifeSpan;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.WorldContextObject = *(UObject**)(params.GetStructMemory() + 0);
		Params.DecalMaterial = *(UMaterialInterface**)(params.GetStructMemory() + 8);
		Params.DecalSize = *(FVector*)(params.GetStructMemory() + 16);
		Params.Location = *(FVector*)(params.GetStructMemory() + 28);
		Params.Rotation = *(FRotator*)(params.GetStructMemory() + 40);
		Params.LifeSpan = *(float*)(params.GetStructMemory() + 52);
		Params.ReturnValue = *(UDecalComponent**)(params.GetStructMemory() + 56);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 SetSubtitlesEnabled(lua_State* InScriptContext)
{
	UClass * Obj = UGameplayStatics::StaticClass(); 
	struct FDispatchParams
	{
		bool bEnabled;
	} Params;
	Params.bEnabled = !!(lua_toboolean(InScriptContext, 1));
#if UE_GAME
	UGameplayStatics::SetSubtitlesEnabled(Params.bEnabled);
#else
	UFunction* Function = Obj->FindFunctionByName(TEXT("SetSubtitlesEnabled"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(bool*)(params.GetStructMemory() + 0) = Params.bEnabled;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.bEnabled = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetSoundMixClassOverride(lua_State* InScriptContext)
{
	UClass * Obj = UGameplayStatics::StaticClass(); 
	struct FDispatchParams
	{
		UObject* WorldContextObject = nullptr;
		USoundMix* InSoundMixModifier = nullptr;
		USoundClass* InSoundClass = nullptr;
		float Volume;
		float Pitch;
		float FadeInTime;
		bool bApplyToChildren;
	} Params;
	Params.WorldContextObject = (UObject*)wLua::FLuaUtils::GetUObject(InScriptContext,1,"Object");;
	Params.InSoundMixModifier = (USoundMix*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"SoundMix");;
	Params.InSoundClass = (USoundClass*)wLua::FLuaUtils::GetUObject(InScriptContext,3,"SoundClass");;
	Params.Volume = lua_isnoneornil(InScriptContext,4) ? float(1.000000) : (float)(luaL_checknumber(InScriptContext, 4));
	Params.Pitch = lua_isnoneornil(InScriptContext,5) ? float(1.000000) : (float)(luaL_checknumber(InScriptContext, 5));
	Params.FadeInTime = lua_isnoneornil(InScriptContext,6) ? float(1.000000) : (float)(luaL_checknumber(InScriptContext, 6));
	Params.bApplyToChildren = lua_isnoneornil(InScriptContext,7) ? bool(true) : !!(lua_toboolean(InScriptContext, 7));
#if UE_GAME
	UGameplayStatics::SetSoundMixClassOverride(Params.WorldContextObject,Params.InSoundMixModifier,Params.InSoundClass,Params.Volume,Params.Pitch,Params.FadeInTime,Params.bApplyToChildren);
#else
	UFunction* Function = Obj->FindFunctionByName(TEXT("SetSoundMixClassOverride"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(UObject**)(params.GetStructMemory() + 0) = Params.WorldContextObject;
		*(USoundMix**)(params.GetStructMemory() + 8) = Params.InSoundMixModifier;
		*(USoundClass**)(params.GetStructMemory() + 16) = Params.InSoundClass;
		*(float*)(params.GetStructMemory() + 24) = Params.Volume;
		*(float*)(params.GetStructMemory() + 28) = Params.Pitch;
		*(float*)(params.GetStructMemory() + 32) = Params.FadeInTime;
		*(bool*)(params.GetStructMemory() + 36) = Params.bApplyToChildren;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.WorldContextObject = *(UObject**)(params.GetStructMemory() + 0);
		Params.InSoundMixModifier = *(USoundMix**)(params.GetStructMemory() + 8);
		Params.InSoundClass = *(USoundClass**)(params.GetStructMemory() + 16);
		Params.Volume = *(float*)(params.GetStructMemory() + 24);
		Params.Pitch = *(float*)(params.GetStructMemory() + 28);
		Params.FadeInTime = *(float*)(params.GetStructMemory() + 32);
		Params.bApplyToChildren = *(bool*)(params.GetStructMemory() + 36);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetPlayerControllerID(lua_State* InScriptContext)
{
	UClass * Obj = UGameplayStatics::StaticClass(); 
	struct FDispatchParams
	{
		APlayerController* Player = nullptr;
		int32 ControllerId;
	} Params;
	Params.Player = (APlayerController*)wLua::FLuaUtils::GetUObject(InScriptContext,1,"PlayerController");;
	Params.ControllerId = (luaL_checkint(InScriptContext, 2));
#if UE_GAME
	UGameplayStatics::SetPlayerControllerID(Params.Player,Params.ControllerId);
#else
	UFunction* Function = Obj->FindFunctionByName(TEXT("SetPlayerControllerID"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(APlayerController**)(params.GetStructMemory() + 0) = Params.Player;
		*(int32*)(params.GetStructMemory() + 8) = Params.ControllerId;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.Player = *(APlayerController**)(params.GetStructMemory() + 0);
		Params.ControllerId = *(int32*)(params.GetStructMemory() + 8);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetGlobalTimeDilation(lua_State* InScriptContext)
{
	UClass * Obj = UGameplayStatics::StaticClass(); 
	struct FDispatchParams
	{
		UObject* WorldContextObject = nullptr;
		float TimeDilation;
	} Params;
	Params.WorldContextObject = (UObject*)wLua::FLuaUtils::GetUObject(InScriptContext,1,"Object");;
	Params.TimeDilation = (float)(luaL_checknumber(InScriptContext, 2));
#if UE_GAME
	UGameplayStatics::SetGlobalTimeDilation(Params.WorldContextObject,Params.TimeDilation);
#else
	UFunction* Function = Obj->FindFunctionByName(TEXT("SetGlobalTimeDilation"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(UObject**)(params.GetStructMemory() + 0) = Params.WorldContextObject;
		*(float*)(params.GetStructMemory() + 8) = Params.TimeDilation;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.WorldContextObject = *(UObject**)(params.GetStructMemory() + 0);
		Params.TimeDilation = *(float*)(params.GetStructMemory() + 8);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetGlobalPitchModulation(lua_State* InScriptContext)
{
	UClass * Obj = UGameplayStatics::StaticClass(); 
	struct FDispatchParams
	{
		UObject* WorldContextObject = nullptr;
		float PitchModulation;
		float TimeSec;
	} Params;
	Params.WorldContextObject = (UObject*)wLua::FLuaUtils::GetUObject(InScriptContext,1,"Object");;
	Params.PitchModulation = (float)(luaL_checknumber(InScriptContext, 2));
	Params.TimeSec = (float)(luaL_checknumber(InScriptContext, 3));
#if UE_GAME
	UGameplayStatics::SetGlobalPitchModulation(Params.WorldContextObject,Params.PitchModulation,Params.TimeSec);
#else
	UFunction* Function = Obj->FindFunctionByName(TEXT("SetGlobalPitchModulation"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(UObject**)(params.GetStructMemory() + 0) = Params.WorldContextObject;
		*(float*)(params.GetStructMemory() + 8) = Params.PitchModulation;
		*(float*)(params.GetStructMemory() + 12) = Params.TimeSec;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.WorldContextObject = *(UObject**)(params.GetStructMemory() + 0);
		Params.PitchModulation = *(float*)(params.GetStructMemory() + 8);
		Params.TimeSec = *(float*)(params.GetStructMemory() + 12);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetGlobalListenerFocusParameters(lua_State* InScriptContext)
{
	UClass * Obj = UGameplayStatics::StaticClass(); 
	struct FDispatchParams
	{
		UObject* WorldContextObject = nullptr;
		float FocusAzimuthScale;
		float NonFocusAzimuthScale;
		float FocusDistanceScale;
		float NonFocusDistanceScale;
		float FocusVolumeScale;
		float NonFocusVolumeScale;
		float FocusPriorityScale;
		float NonFocusPriorityScale;
	} Params;
	Params.WorldContextObject = (UObject*)wLua::FLuaUtils::GetUObject(InScriptContext,1,"Object");;
	Params.FocusAzimuthScale = lua_isnoneornil(InScriptContext,2) ? float(1.000000) : (float)(luaL_checknumber(InScriptContext, 2));
	Params.NonFocusAzimuthScale = lua_isnoneornil(InScriptContext,3) ? float(1.000000) : (float)(luaL_checknumber(InScriptContext, 3));
	Params.FocusDistanceScale = lua_isnoneornil(InScriptContext,4) ? float(1.000000) : (float)(luaL_checknumber(InScriptContext, 4));
	Params.NonFocusDistanceScale = lua_isnoneornil(InScriptContext,5) ? float(1.000000) : (float)(luaL_checknumber(InScriptContext, 5));
	Params.FocusVolumeScale = lua_isnoneornil(InScriptContext,6) ? float(1.000000) : (float)(luaL_checknumber(InScriptContext, 6));
	Params.NonFocusVolumeScale = lua_isnoneornil(InScriptContext,7) ? float(1.000000) : (float)(luaL_checknumber(InScriptContext, 7));
	Params.FocusPriorityScale = lua_isnoneornil(InScriptContext,8) ? float(1.000000) : (float)(luaL_checknumber(InScriptContext, 8));
	Params.NonFocusPriorityScale = lua_isnoneornil(InScriptContext,9) ? float(1.000000) : (float)(luaL_checknumber(InScriptContext, 9));
#if UE_GAME
	UGameplayStatics::SetGlobalListenerFocusParameters(Params.WorldContextObject,Params.FocusAzimuthScale,Params.NonFocusAzimuthScale,Params.FocusDistanceScale,Params.NonFocusDistanceScale,Params.FocusVolumeScale,Params.NonFocusVolumeScale,Params.FocusPriorityScale,Params.NonFocusPriorityScale);
#else
	UFunction* Function = Obj->FindFunctionByName(TEXT("SetGlobalListenerFocusParameters"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(UObject**)(params.GetStructMemory() + 0) = Params.WorldContextObject;
		*(float*)(params.GetStructMemory() + 8) = Params.FocusAzimuthScale;
		*(float*)(params.GetStructMemory() + 12) = Params.NonFocusAzimuthScale;
		*(float*)(params.GetStructMemory() + 16) = Params.FocusDistanceScale;
		*(float*)(params.GetStructMemory() + 20) = Params.NonFocusDistanceScale;
		*(float*)(params.GetStructMemory() + 24) = Params.FocusVolumeScale;
		*(float*)(params.GetStructMemory() + 28) = Params.NonFocusVolumeScale;
		*(float*)(params.GetStructMemory() + 32) = Params.FocusPriorityScale;
		*(float*)(params.GetStructMemory() + 36) = Params.NonFocusPriorityScale;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.WorldContextObject = *(UObject**)(params.GetStructMemory() + 0);
		Params.FocusAzimuthScale = *(float*)(params.GetStructMemory() + 8);
		Params.NonFocusAzimuthScale = *(float*)(params.GetStructMemory() + 12);
		Params.FocusDistanceScale = *(float*)(params.GetStructMemory() + 16);
		Params.NonFocusDistanceScale = *(float*)(params.GetStructMemory() + 20);
		Params.FocusVolumeScale = *(float*)(params.GetStructMemory() + 24);
		Params.NonFocusVolumeScale = *(float*)(params.GetStructMemory() + 28);
		Params.FocusPriorityScale = *(float*)(params.GetStructMemory() + 32);
		Params.NonFocusPriorityScale = *(float*)(params.GetStructMemory() + 36);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetGamePaused(lua_State* InScriptContext)
{
	UClass * Obj = UGameplayStatics::StaticClass(); 
	struct FDispatchParams
	{
		UObject* WorldContextObject = nullptr;
		bool bPaused;
		bool ReturnValue;
	} Params;
	Params.WorldContextObject = (UObject*)wLua::FLuaUtils::GetUObject(InScriptContext,1,"Object");;
	Params.bPaused = !!(lua_toboolean(InScriptContext, 2));
#if UE_GAME
	Params.ReturnValue = UGameplayStatics::SetGamePaused(Params.WorldContextObject,Params.bPaused);
#else
	UFunction* Function = Obj->FindFunctionByName(TEXT("SetGamePaused"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(UObject**)(params.GetStructMemory() + 0) = Params.WorldContextObject;
		*(bool*)(params.GetStructMemory() + 8) = Params.bPaused;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.WorldContextObject = *(UObject**)(params.GetStructMemory() + 0);
		Params.bPaused = *(bool*)(params.GetStructMemory() + 8);
		Params.ReturnValue = *(bool*)(params.GetStructMemory() + 9);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushboolean(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 SetEnableWorldRendering(lua_State* InScriptContext)
{
	UClass * Obj = UGameplayStatics::StaticClass(); 
	struct FDispatchParams
	{
		UObject* WorldContextObject = nullptr;
		bool bEnable;
	} Params;
	Params.WorldContextObject = (UObject*)wLua::FLuaUtils::GetUObject(InScriptContext,1,"Object");;
	Params.bEnable = !!(lua_toboolean(InScriptContext, 2));
#if UE_GAME
	UGameplayStatics::SetEnableWorldRendering(Params.WorldContextObject,Params.bEnable);
#else
	UFunction* Function = Obj->FindFunctionByName(TEXT("SetEnableWorldRendering"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(UObject**)(params.GetStructMemory() + 0) = Params.WorldContextObject;
		*(bool*)(params.GetStructMemory() + 8) = Params.bEnable;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.WorldContextObject = *(UObject**)(params.GetStructMemory() + 0);
		Params.bEnable = *(bool*)(params.GetStructMemory() + 8);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetBaseSoundMix(lua_State* InScriptContext)
{
	UClass * Obj = UGameplayStatics::StaticClass(); 
	struct FDispatchParams
	{
		UObject* WorldContextObject = nullptr;
		USoundMix* InSoundMix = nullptr;
	} Params;
	Params.WorldContextObject = (UObject*)wLua::FLuaUtils::GetUObject(InScriptContext,1,"Object");;
	Params.InSoundMix = (USoundMix*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"SoundMix");;
#if UE_GAME
	UGameplayStatics::SetBaseSoundMix(Params.WorldContextObject,Params.InSoundMix);
#else
	UFunction* Function = Obj->FindFunctionByName(TEXT("SetBaseSoundMix"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(UObject**)(params.GetStructMemory() + 0) = Params.WorldContextObject;
		*(USoundMix**)(params.GetStructMemory() + 8) = Params.InSoundMix;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.WorldContextObject = *(UObject**)(params.GetStructMemory() + 0);
		Params.InSoundMix = *(USoundMix**)(params.GetStructMemory() + 8);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SaveGameToSlot(lua_State* InScriptContext)
{
	UClass * Obj = UGameplayStatics::StaticClass(); 
	struct FDispatchParams
	{
		USaveGame* SaveGameObject = nullptr;
		FString SlotName;
		int32 UserIndex;
		bool ReturnValue;
	} Params;
	Params.SaveGameObject = (USaveGame*)wLua::FLuaUtils::GetUObject(InScriptContext,1,"SaveGame");;
	Params.SlotName = UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 2));
	Params.UserIndex = (luaL_checkint(InScriptContext, 3));
#if UE_GAME
	Params.ReturnValue = UGameplayStatics::SaveGameToSlot(Params.SaveGameObject,Params.SlotName,Params.UserIndex);
#else
	UFunction* Function = Obj->FindFunctionByName(TEXT("SaveGameToSlot"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(USaveGame**)(params.GetStructMemory() + 0) = Params.SaveGameObject;
		*(FString*)(params.GetStructMemory() + 8) = Params.SlotName;
		*(int32*)(params.GetStructMemory() + 24) = Params.UserIndex;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.SaveGameObject = *(USaveGame**)(params.GetStructMemory() + 0);
		Params.SlotName = *(FString*)(params.GetStructMemory() + 8);
		Params.UserIndex = *(int32*)(params.GetStructMemory() + 24);
		Params.ReturnValue = *(bool*)(params.GetStructMemory() + 28);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushboolean(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 RemovePlayer(lua_State* InScriptContext)
{
	UClass * Obj = UGameplayStatics::StaticClass(); 
	struct FDispatchParams
	{
		APlayerController* Player = nullptr;
		bool bDestroyPawn;
	} Params;
	Params.Player = (APlayerController*)wLua::FLuaUtils::GetUObject(InScriptContext,1,"PlayerController");;
	Params.bDestroyPawn = !!(lua_toboolean(InScriptContext, 2));
#if UE_GAME
	UGameplayStatics::RemovePlayer(Params.Player,Params.bDestroyPawn);
#else
	UFunction* Function = Obj->FindFunctionByName(TEXT("RemovePlayer"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(APlayerController**)(params.GetStructMemory() + 0) = Params.Player;
		*(bool*)(params.GetStructMemory() + 8) = Params.bDestroyPawn;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.Player = *(APlayerController**)(params.GetStructMemory() + 0);
		Params.bDestroyPawn = *(bool*)(params.GetStructMemory() + 8);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 RebaseZeroOriginOntoLocal(lua_State* InScriptContext)
{
	UClass * Obj = UGameplayStatics::StaticClass(); 
	struct FDispatchParams
	{
		UObject* WorldContextObject = nullptr;
		FVector WorldLocation;
		FVector ReturnValue;
	} Params;
	Params.WorldContextObject = (UObject*)wLua::FLuaUtils::GetUObject(InScriptContext,1,"Object");;
	Params.WorldLocation = (wLua::FLuaVector::Get(InScriptContext, 2));
#if UE_GAME
	Params.ReturnValue = UGameplayStatics::RebaseZeroOriginOntoLocal(Params.WorldContextObject,Params.WorldLocation);
#else
	UFunction* Function = Obj->FindFunctionByName(TEXT("RebaseZeroOriginOntoLocal"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(UObject**)(params.GetStructMemory() + 0) = Params.WorldContextObject;
		*(FVector*)(params.GetStructMemory() + 8) = Params.WorldLocation;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.WorldContextObject = *(UObject**)(params.GetStructMemory() + 0);
		Params.WorldLocation = *(FVector*)(params.GetStructMemory() + 8);
		Params.ReturnValue = *(FVector*)(params.GetStructMemory() + 20);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaVector::Return(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 RebaseLocalOriginOntoZero(lua_State* InScriptContext)
{
	UClass * Obj = UGameplayStatics::StaticClass(); 
	struct FDispatchParams
	{
		UObject* WorldContextObject = nullptr;
		FVector WorldLocation;
		FVector ReturnValue;
	} Params;
	Params.WorldContextObject = (UObject*)wLua::FLuaUtils::GetUObject(InScriptContext,1,"Object");;
	Params.WorldLocation = (wLua::FLuaVector::Get(InScriptContext, 2));
#if UE_GAME
	Params.ReturnValue = UGameplayStatics::RebaseLocalOriginOntoZero(Params.WorldContextObject,Params.WorldLocation);
#else
	UFunction* Function = Obj->FindFunctionByName(TEXT("RebaseLocalOriginOntoZero"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(UObject**)(params.GetStructMemory() + 0) = Params.WorldContextObject;
		*(FVector*)(params.GetStructMemory() + 8) = Params.WorldLocation;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.WorldContextObject = *(UObject**)(params.GetStructMemory() + 0);
		Params.WorldLocation = *(FVector*)(params.GetStructMemory() + 8);
		Params.ReturnValue = *(FVector*)(params.GetStructMemory() + 20);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaVector::Return(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 PushSoundMixModifier(lua_State* InScriptContext)
{
	UClass * Obj = UGameplayStatics::StaticClass(); 
	struct FDispatchParams
	{
		UObject* WorldContextObject = nullptr;
		USoundMix* InSoundMixModifier = nullptr;
	} Params;
	Params.WorldContextObject = (UObject*)wLua::FLuaUtils::GetUObject(InScriptContext,1,"Object");;
	Params.InSoundMixModifier = (USoundMix*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"SoundMix");;
#if UE_GAME
	UGameplayStatics::PushSoundMixModifier(Params.WorldContextObject,Params.InSoundMixModifier);
#else
	UFunction* Function = Obj->FindFunctionByName(TEXT("PushSoundMixModifier"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(UObject**)(params.GetStructMemory() + 0) = Params.WorldContextObject;
		*(USoundMix**)(params.GetStructMemory() + 8) = Params.InSoundMixModifier;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.WorldContextObject = *(UObject**)(params.GetStructMemory() + 0);
		Params.InSoundMixModifier = *(USoundMix**)(params.GetStructMemory() + 8);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 ProjectWorldToScreen(lua_State* InScriptContext)
{
	UClass * Obj = UGameplayStatics::StaticClass(); 
	struct FDispatchParams
	{
		APlayerController* Player = nullptr;
		FVector WorldPosition;
		FVector2D ScreenPosition;
		bool bPlayerViewportRelative;
		bool ReturnValue;
	} Params;
	Params.Player = (APlayerController*)wLua::FLuaUtils::GetUObject(InScriptContext,1,"PlayerController");;
	Params.WorldPosition = (wLua::FLuaVector::Get(InScriptContext, 2));
	Params.bPlayerViewportRelative = lua_isnoneornil(InScriptContext,4) ? bool(false) : !!(lua_toboolean(InScriptContext, 4));
#if UE_GAME
	Params.ReturnValue = UGameplayStatics::ProjectWorldToScreen(Params.Player,Params.WorldPosition,Params.ScreenPosition,Params.bPlayerViewportRelative);
#else
	UFunction* Function = Obj->FindFunctionByName(TEXT("ProjectWorldToScreen"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(APlayerController**)(params.GetStructMemory() + 0) = Params.Player;
		*(FVector*)(params.GetStructMemory() + 8) = Params.WorldPosition;
		*(bool*)(params.GetStructMemory() + 28) = Params.bPlayerViewportRelative;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.Player = *(APlayerController**)(params.GetStructMemory() + 0);
		Params.WorldPosition = *(FVector*)(params.GetStructMemory() + 8);
		Params.ScreenPosition = *(FVector2D*)(params.GetStructMemory() + 20);
		Params.bPlayerViewportRelative = *(bool*)(params.GetStructMemory() + 28);
		Params.ReturnValue = *(bool*)(params.GetStructMemory() + 29);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushboolean(InScriptContext, Params.ReturnValue);
	wLua::FLuaVector2D::Return(InScriptContext, Params.ScreenPosition);
	return 2;
}

int32 PopSoundMixModifier(lua_State* InScriptContext)
{
	UClass * Obj = UGameplayStatics::StaticClass(); 
	struct FDispatchParams
	{
		UObject* WorldContextObject = nullptr;
		USoundMix* InSoundMixModifier = nullptr;
	} Params;
	Params.WorldContextObject = (UObject*)wLua::FLuaUtils::GetUObject(InScriptContext,1,"Object");;
	Params.InSoundMixModifier = (USoundMix*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"SoundMix");;
#if UE_GAME
	UGameplayStatics::PopSoundMixModifier(Params.WorldContextObject,Params.InSoundMixModifier);
#else
	UFunction* Function = Obj->FindFunctionByName(TEXT("PopSoundMixModifier"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(UObject**)(params.GetStructMemory() + 0) = Params.WorldContextObject;
		*(USoundMix**)(params.GetStructMemory() + 8) = Params.InSoundMixModifier;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.WorldContextObject = *(UObject**)(params.GetStructMemory() + 0);
		Params.InSoundMixModifier = *(USoundMix**)(params.GetStructMemory() + 8);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 PlayWorldCameraShake(lua_State* InScriptContext)
{
	UClass * Obj = UGameplayStatics::StaticClass(); 
	struct FDispatchParams
	{
		UObject* WorldContextObject = nullptr;
		TSubclassOf<UCameraShake>  Shake;
		FVector Epicenter;
		float InnerRadius;
		float OuterRadius;
		float Falloff;
		bool bOrientShakeTowardsEpicenter;
	} Params;
	Params.WorldContextObject = (UObject*)wLua::FLuaUtils::GetUObject(InScriptContext,1,"Object");;
	Params.Shake = (UClass*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"Class");;
	Params.Epicenter = (wLua::FLuaVector::Get(InScriptContext, 3));
	Params.InnerRadius = (float)(luaL_checknumber(InScriptContext, 4));
	Params.OuterRadius = (float)(luaL_checknumber(InScriptContext, 5));
	Params.Falloff = lua_isnoneornil(InScriptContext,6) ? float(1.000000) : (float)(luaL_checknumber(InScriptContext, 6));
	Params.bOrientShakeTowardsEpicenter = lua_isnoneornil(InScriptContext,7) ? bool(false) : !!(lua_toboolean(InScriptContext, 7));
#if UE_GAME
	UGameplayStatics::PlayWorldCameraShake(Params.WorldContextObject,Params.Shake,Params.Epicenter,Params.InnerRadius,Params.OuterRadius,Params.Falloff,Params.bOrientShakeTowardsEpicenter);
#else
	UFunction* Function = Obj->FindFunctionByName(TEXT("PlayWorldCameraShake"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(UObject**)(params.GetStructMemory() + 0) = Params.WorldContextObject;
		*(TSubclassOf<UCameraShake> *)(params.GetStructMemory() + 8) = Params.Shake;
		*(FVector*)(params.GetStructMemory() + 16) = Params.Epicenter;
		*(float*)(params.GetStructMemory() + 28) = Params.InnerRadius;
		*(float*)(params.GetStructMemory() + 32) = Params.OuterRadius;
		*(float*)(params.GetStructMemory() + 36) = Params.Falloff;
		*(bool*)(params.GetStructMemory() + 40) = Params.bOrientShakeTowardsEpicenter;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.WorldContextObject = *(UObject**)(params.GetStructMemory() + 0);
		Params.Shake = *(TSubclassOf<UCameraShake> *)(params.GetStructMemory() + 8);
		Params.Epicenter = *(FVector*)(params.GetStructMemory() + 16);
		Params.InnerRadius = *(float*)(params.GetStructMemory() + 28);
		Params.OuterRadius = *(float*)(params.GetStructMemory() + 32);
		Params.Falloff = *(float*)(params.GetStructMemory() + 36);
		Params.bOrientShakeTowardsEpicenter = *(bool*)(params.GetStructMemory() + 40);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 PlaySoundAtLocation(lua_State* InScriptContext)
{
	UClass * Obj = UGameplayStatics::StaticClass(); 
	struct FDispatchParams
	{
		UObject* WorldContextObject = nullptr;
		USoundBase* Sound = nullptr;
		FVector Location;
		FRotator Rotation;
		float VolumeMultiplier;
		float PitchMultiplier;
		float StartTime;
		USoundAttenuation* AttenuationSettings = nullptr;
		USoundConcurrency* ConcurrencySettings = nullptr;
		AActor* OwningActor = nullptr;
	} Params;
	Params.WorldContextObject = (UObject*)wLua::FLuaUtils::GetUObject(InScriptContext,1,"Object");;
	Params.Sound = (USoundBase*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"SoundBase");;
	Params.Location = (wLua::FLuaVector::Get(InScriptContext, 3));
	Params.Rotation = (wLua::FLuaRotator::Get(InScriptContext, 4));
	Params.VolumeMultiplier = lua_isnoneornil(InScriptContext,5) ? float(1.000000) : (float)(luaL_checknumber(InScriptContext, 5));
	Params.PitchMultiplier = lua_isnoneornil(InScriptContext,6) ? float(1.000000) : (float)(luaL_checknumber(InScriptContext, 6));
	Params.StartTime = lua_isnoneornil(InScriptContext,7) ? float(0.000000) : (float)(luaL_checknumber(InScriptContext, 7));
	Params.AttenuationSettings = lua_isnoneornil(InScriptContext,8) ? nullptr : (USoundAttenuation*)wLua::FLuaUtils::GetUObject(InScriptContext,8,"SoundAttenuation");;
	Params.ConcurrencySettings = lua_isnoneornil(InScriptContext,9) ? nullptr : (USoundConcurrency*)wLua::FLuaUtils::GetUObject(InScriptContext,9,"SoundConcurrency");;
	Params.OwningActor = lua_isnoneornil(InScriptContext,10) ? nullptr : (AActor*)wLua::FLuaUtils::GetUObject(InScriptContext,10,"Actor");;
#if UE_GAME
	UGameplayStatics::PlaySoundAtLocation(Params.WorldContextObject,Params.Sound,Params.Location,Params.Rotation,Params.VolumeMultiplier,Params.PitchMultiplier,Params.StartTime,Params.AttenuationSettings,Params.ConcurrencySettings,Params.OwningActor);
#else
	UFunction* Function = Obj->FindFunctionByName(TEXT("PlaySoundAtLocation"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(UObject**)(params.GetStructMemory() + 0) = Params.WorldContextObject;
		*(USoundBase**)(params.GetStructMemory() + 8) = Params.Sound;
		*(FVector*)(params.GetStructMemory() + 16) = Params.Location;
		*(FRotator*)(params.GetStructMemory() + 28) = Params.Rotation;
		*(float*)(params.GetStructMemory() + 40) = Params.VolumeMultiplier;
		*(float*)(params.GetStructMemory() + 44) = Params.PitchMultiplier;
		*(float*)(params.GetStructMemory() + 48) = Params.StartTime;
		*(USoundAttenuation**)(params.GetStructMemory() + 56) = Params.AttenuationSettings;
		*(USoundConcurrency**)(params.GetStructMemory() + 64) = Params.ConcurrencySettings;
		*(AActor**)(params.GetStructMemory() + 72) = Params.OwningActor;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.WorldContextObject = *(UObject**)(params.GetStructMemory() + 0);
		Params.Sound = *(USoundBase**)(params.GetStructMemory() + 8);
		Params.Location = *(FVector*)(params.GetStructMemory() + 16);
		Params.Rotation = *(FRotator*)(params.GetStructMemory() + 28);
		Params.VolumeMultiplier = *(float*)(params.GetStructMemory() + 40);
		Params.PitchMultiplier = *(float*)(params.GetStructMemory() + 44);
		Params.StartTime = *(float*)(params.GetStructMemory() + 48);
		Params.AttenuationSettings = *(USoundAttenuation**)(params.GetStructMemory() + 56);
		Params.ConcurrencySettings = *(USoundConcurrency**)(params.GetStructMemory() + 64);
		Params.OwningActor = *(AActor**)(params.GetStructMemory() + 72);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 PlaySound2D(lua_State* InScriptContext)
{
	UClass * Obj = UGameplayStatics::StaticClass(); 
	struct FDispatchParams
	{
		UObject* WorldContextObject = nullptr;
		USoundBase* Sound = nullptr;
		float VolumeMultiplier;
		float PitchMultiplier;
		float StartTime;
		USoundConcurrency* ConcurrencySettings = nullptr;
		AActor* OwningActor = nullptr;
	} Params;
	Params.WorldContextObject = (UObject*)wLua::FLuaUtils::GetUObject(InScriptContext,1,"Object");;
	Params.Sound = (USoundBase*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"SoundBase");;
	Params.VolumeMultiplier = lua_isnoneornil(InScriptContext,3) ? float(1.000000) : (float)(luaL_checknumber(InScriptContext, 3));
	Params.PitchMultiplier = lua_isnoneornil(InScriptContext,4) ? float(1.000000) : (float)(luaL_checknumber(InScriptContext, 4));
	Params.StartTime = lua_isnoneornil(InScriptContext,5) ? float(0.000000) : (float)(luaL_checknumber(InScriptContext, 5));
	Params.ConcurrencySettings = lua_isnoneornil(InScriptContext,6) ? nullptr : (USoundConcurrency*)wLua::FLuaUtils::GetUObject(InScriptContext,6,"SoundConcurrency");;
	Params.OwningActor = lua_isnoneornil(InScriptContext,7) ? nullptr : (AActor*)wLua::FLuaUtils::GetUObject(InScriptContext,7,"Actor");;
#if UE_GAME
	UGameplayStatics::PlaySound2D(Params.WorldContextObject,Params.Sound,Params.VolumeMultiplier,Params.PitchMultiplier,Params.StartTime,Params.ConcurrencySettings,Params.OwningActor);
#else
	UFunction* Function = Obj->FindFunctionByName(TEXT("PlaySound2D"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(UObject**)(params.GetStructMemory() + 0) = Params.WorldContextObject;
		*(USoundBase**)(params.GetStructMemory() + 8) = Params.Sound;
		*(float*)(params.GetStructMemory() + 16) = Params.VolumeMultiplier;
		*(float*)(params.GetStructMemory() + 20) = Params.PitchMultiplier;
		*(float*)(params.GetStructMemory() + 24) = Params.StartTime;
		*(USoundConcurrency**)(params.GetStructMemory() + 32) = Params.ConcurrencySettings;
		*(AActor**)(params.GetStructMemory() + 40) = Params.OwningActor;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.WorldContextObject = *(UObject**)(params.GetStructMemory() + 0);
		Params.Sound = *(USoundBase**)(params.GetStructMemory() + 8);
		Params.VolumeMultiplier = *(float*)(params.GetStructMemory() + 16);
		Params.PitchMultiplier = *(float*)(params.GetStructMemory() + 20);
		Params.StartTime = *(float*)(params.GetStructMemory() + 24);
		Params.ConcurrencySettings = *(USoundConcurrency**)(params.GetStructMemory() + 32);
		Params.OwningActor = *(AActor**)(params.GetStructMemory() + 40);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 ParseOption(lua_State* InScriptContext)
{
	UClass * Obj = UGameplayStatics::StaticClass(); 
	struct FDispatchParams
	{
		FString Options;
		FString Key;
		FString ReturnValue;
	} Params;
	Params.Options = UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 1));
	Params.Key = UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 2));
#if UE_GAME
	Params.ReturnValue = UGameplayStatics::ParseOption(Params.Options,Params.Key);
#else
	UFunction* Function = Obj->FindFunctionByName(TEXT("ParseOption"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FString*)(params.GetStructMemory() + 0) = Params.Options;
		*(FString*)(params.GetStructMemory() + 16) = Params.Key;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.Options = *(FString*)(params.GetStructMemory() + 0);
		Params.Key = *(FString*)(params.GetStructMemory() + 16);
		Params.ReturnValue = *(FString*)(params.GetStructMemory() + 32);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushstring(InScriptContext, TCHAR_TO_UTF8(*Params.ReturnValue));
	return 1;
}

int32 OpenLevel(lua_State* InScriptContext)
{
	UClass * Obj = UGameplayStatics::StaticClass(); 
	struct FDispatchParams
	{
		UObject* WorldContextObject = nullptr;
		FName LevelName;
		bool bAbsolute;
		FString Options;
	} Params;
	Params.WorldContextObject = (UObject*)wLua::FLuaUtils::GetUObject(InScriptContext,1,"Object");;
	Params.LevelName = FName(UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 2)));
	Params.bAbsolute = lua_isnoneornil(InScriptContext,3) ? bool(true) : !!(lua_toboolean(InScriptContext, 3));
	Params.Options = lua_isnoneornil(InScriptContext,4) ? FString(TEXT("")) : UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 4));
#if UE_GAME
	UGameplayStatics::OpenLevel(Params.WorldContextObject,Params.LevelName,Params.bAbsolute,Params.Options);
#else
	UFunction* Function = Obj->FindFunctionByName(TEXT("OpenLevel"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(UObject**)(params.GetStructMemory() + 0) = Params.WorldContextObject;
		*(FName*)(params.GetStructMemory() + 8) = Params.LevelName;
		*(bool*)(params.GetStructMemory() + 20) = Params.bAbsolute;
		*(FString*)(params.GetStructMemory() + 24) = Params.Options;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.WorldContextObject = *(UObject**)(params.GetStructMemory() + 0);
		Params.LevelName = *(FName*)(params.GetStructMemory() + 8);
		Params.bAbsolute = *(bool*)(params.GetStructMemory() + 20);
		Params.Options = *(FString*)(params.GetStructMemory() + 24);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 LoadGameFromSlot(lua_State* InScriptContext)
{
	UClass * Obj = UGameplayStatics::StaticClass(); 
	struct FDispatchParams
	{
		FString SlotName;
		int32 UserIndex;
		USaveGame* ReturnValue = nullptr;
	} Params;
	Params.SlotName = UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 1));
	Params.UserIndex = (luaL_checkint(InScriptContext, 2));
#if UE_GAME
	Params.ReturnValue = UGameplayStatics::LoadGameFromSlot(Params.SlotName,Params.UserIndex);
#else
	UFunction* Function = Obj->FindFunctionByName(TEXT("LoadGameFromSlot"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FString*)(params.GetStructMemory() + 0) = Params.SlotName;
		*(int32*)(params.GetStructMemory() + 16) = Params.UserIndex;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.SlotName = *(FString*)(params.GetStructMemory() + 0);
		Params.UserIndex = *(int32*)(params.GetStructMemory() + 16);
		Params.ReturnValue = *(USaveGame**)(params.GetStructMemory() + 24);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 IsGamePaused(lua_State* InScriptContext)
{
	UClass * Obj = UGameplayStatics::StaticClass(); 
	struct FDispatchParams
	{
		UObject* WorldContextObject = nullptr;
		bool ReturnValue;
	} Params;
	Params.WorldContextObject = (UObject*)wLua::FLuaUtils::GetUObject(InScriptContext,1,"Object");;
#if UE_GAME
	Params.ReturnValue = UGameplayStatics::IsGamePaused(Params.WorldContextObject);
#else
	UFunction* Function = Obj->FindFunctionByName(TEXT("IsGamePaused"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(UObject**)(params.GetStructMemory() + 0) = Params.WorldContextObject;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.WorldContextObject = *(UObject**)(params.GetStructMemory() + 0);
		Params.ReturnValue = *(bool*)(params.GetStructMemory() + 8);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushboolean(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 HasOption(lua_State* InScriptContext)
{
	UClass * Obj = UGameplayStatics::StaticClass(); 
	struct FDispatchParams
	{
		FString Options;
		FString InKey;
		bool ReturnValue;
	} Params;
	Params.Options = UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 1));
	Params.InKey = UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 2));
#if UE_GAME
	Params.ReturnValue = UGameplayStatics::HasOption(Params.Options,Params.InKey);
#else
	UFunction* Function = Obj->FindFunctionByName(TEXT("HasOption"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FString*)(params.GetStructMemory() + 0) = Params.Options;
		*(FString*)(params.GetStructMemory() + 16) = Params.InKey;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.Options = *(FString*)(params.GetStructMemory() + 0);
		Params.InKey = *(FString*)(params.GetStructMemory() + 16);
		Params.ReturnValue = *(bool*)(params.GetStructMemory() + 32);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushboolean(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 HasLaunchOption(lua_State* InScriptContext)
{
	UClass * Obj = UGameplayStatics::StaticClass(); 
	struct FDispatchParams
	{
		FString OptionToCheck;
		bool ReturnValue;
	} Params;
	Params.OptionToCheck = UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 1));
#if UE_GAME
	Params.ReturnValue = UGameplayStatics::HasLaunchOption(Params.OptionToCheck);
#else
	UFunction* Function = Obj->FindFunctionByName(TEXT("HasLaunchOption"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FString*)(params.GetStructMemory() + 0) = Params.OptionToCheck;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.OptionToCheck = *(FString*)(params.GetStructMemory() + 0);
		Params.ReturnValue = *(bool*)(params.GetStructMemory() + 16);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushboolean(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GrassOverlappingSphereCount(lua_State* InScriptContext)
{
	UClass * Obj = UGameplayStatics::StaticClass(); 
	struct FDispatchParams
	{
		UObject* WorldContextObject = nullptr;
		UStaticMesh* StaticMesh = nullptr;
		FVector CenterPosition;
		float Radius;
		int32 ReturnValue;
	} Params;
	Params.WorldContextObject = (UObject*)wLua::FLuaUtils::GetUObject(InScriptContext,1,"Object");;
	Params.StaticMesh = (UStaticMesh*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"StaticMesh");;
	Params.CenterPosition = (wLua::FLuaVector::Get(InScriptContext, 3));
	Params.Radius = (float)(luaL_checknumber(InScriptContext, 4));
#if UE_GAME
	Params.ReturnValue = UGameplayStatics::GrassOverlappingSphereCount(Params.WorldContextObject,Params.StaticMesh,Params.CenterPosition,Params.Radius);
#else
	UFunction* Function = Obj->FindFunctionByName(TEXT("GrassOverlappingSphereCount"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(UObject**)(params.GetStructMemory() + 0) = Params.WorldContextObject;
		*(UStaticMesh**)(params.GetStructMemory() + 8) = Params.StaticMesh;
		*(FVector*)(params.GetStructMemory() + 16) = Params.CenterPosition;
		*(float*)(params.GetStructMemory() + 28) = Params.Radius;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.WorldContextObject = *(UObject**)(params.GetStructMemory() + 0);
		Params.StaticMesh = *(UStaticMesh**)(params.GetStructMemory() + 8);
		Params.CenterPosition = *(FVector*)(params.GetStructMemory() + 16);
		Params.Radius = *(float*)(params.GetStructMemory() + 28);
		Params.ReturnValue = *(int32*)(params.GetStructMemory() + 32);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushinteger(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetWorldDeltaSeconds(lua_State* InScriptContext)
{
	UClass * Obj = UGameplayStatics::StaticClass(); 
	struct FDispatchParams
	{
		UObject* WorldContextObject = nullptr;
		float ReturnValue;
	} Params;
	Params.WorldContextObject = (UObject*)wLua::FLuaUtils::GetUObject(InScriptContext,1,"Object");;
#if UE_GAME
	Params.ReturnValue = UGameplayStatics::GetWorldDeltaSeconds(Params.WorldContextObject);
#else
	UFunction* Function = Obj->FindFunctionByName(TEXT("GetWorldDeltaSeconds"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(UObject**)(params.GetStructMemory() + 0) = Params.WorldContextObject;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.WorldContextObject = *(UObject**)(params.GetStructMemory() + 0);
		Params.ReturnValue = *(float*)(params.GetStructMemory() + 8);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushnumber(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetUnpausedTimeSeconds(lua_State* InScriptContext)
{
	UClass * Obj = UGameplayStatics::StaticClass(); 
	struct FDispatchParams
	{
		UObject* WorldContextObject = nullptr;
		float ReturnValue;
	} Params;
	Params.WorldContextObject = (UObject*)wLua::FLuaUtils::GetUObject(InScriptContext,1,"Object");;
#if UE_GAME
	Params.ReturnValue = UGameplayStatics::GetUnpausedTimeSeconds(Params.WorldContextObject);
#else
	UFunction* Function = Obj->FindFunctionByName(TEXT("GetUnpausedTimeSeconds"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(UObject**)(params.GetStructMemory() + 0) = Params.WorldContextObject;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.WorldContextObject = *(UObject**)(params.GetStructMemory() + 0);
		Params.ReturnValue = *(float*)(params.GetStructMemory() + 8);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushnumber(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetTimeSeconds(lua_State* InScriptContext)
{
	UClass * Obj = UGameplayStatics::StaticClass(); 
	struct FDispatchParams
	{
		UObject* WorldContextObject = nullptr;
		float ReturnValue;
	} Params;
	Params.WorldContextObject = (UObject*)wLua::FLuaUtils::GetUObject(InScriptContext,1,"Object");;
#if UE_GAME
	Params.ReturnValue = UGameplayStatics::GetTimeSeconds(Params.WorldContextObject);
#else
	UFunction* Function = Obj->FindFunctionByName(TEXT("GetTimeSeconds"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(UObject**)(params.GetStructMemory() + 0) = Params.WorldContextObject;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.WorldContextObject = *(UObject**)(params.GetStructMemory() + 0);
		Params.ReturnValue = *(float*)(params.GetStructMemory() + 8);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushnumber(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetStreamingLevel(lua_State* InScriptContext)
{
	UClass * Obj = UGameplayStatics::StaticClass(); 
	struct FDispatchParams
	{
		UObject* WorldContextObject = nullptr;
		FName PackageName;
		ULevelStreaming* ReturnValue = nullptr;
	} Params;
	Params.WorldContextObject = (UObject*)wLua::FLuaUtils::GetUObject(InScriptContext,1,"Object");;
	Params.PackageName = FName(UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 2)));
#if UE_GAME
	Params.ReturnValue = UGameplayStatics::GetStreamingLevel(Params.WorldContextObject,Params.PackageName);
#else
	UFunction* Function = Obj->FindFunctionByName(TEXT("GetStreamingLevel"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(UObject**)(params.GetStructMemory() + 0) = Params.WorldContextObject;
		*(FName*)(params.GetStructMemory() + 8) = Params.PackageName;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.WorldContextObject = *(UObject**)(params.GetStructMemory() + 0);
		Params.PackageName = *(FName*)(params.GetStructMemory() + 8);
		Params.ReturnValue = *(ULevelStreaming**)(params.GetStructMemory() + 24);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetRealTimeSeconds(lua_State* InScriptContext)
{
	UClass * Obj = UGameplayStatics::StaticClass(); 
	struct FDispatchParams
	{
		UObject* WorldContextObject = nullptr;
		float ReturnValue;
	} Params;
	Params.WorldContextObject = (UObject*)wLua::FLuaUtils::GetUObject(InScriptContext,1,"Object");;
#if UE_GAME
	Params.ReturnValue = UGameplayStatics::GetRealTimeSeconds(Params.WorldContextObject);
#else
	UFunction* Function = Obj->FindFunctionByName(TEXT("GetRealTimeSeconds"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(UObject**)(params.GetStructMemory() + 0) = Params.WorldContextObject;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.WorldContextObject = *(UObject**)(params.GetStructMemory() + 0);
		Params.ReturnValue = *(float*)(params.GetStructMemory() + 8);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushnumber(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetPlayerPawn(lua_State* InScriptContext)
{
	UClass * Obj = UGameplayStatics::StaticClass(); 
	struct FDispatchParams
	{
		UObject* WorldContextObject = nullptr;
		int32 PlayerIndex;
		APawn* ReturnValue = nullptr;
	} Params;
	Params.WorldContextObject = (UObject*)wLua::FLuaUtils::GetUObject(InScriptContext,1,"Object");;
	Params.PlayerIndex = (luaL_checkint(InScriptContext, 2));
#if UE_GAME
	Params.ReturnValue = UGameplayStatics::GetPlayerPawn(Params.WorldContextObject,Params.PlayerIndex);
#else
	UFunction* Function = Obj->FindFunctionByName(TEXT("GetPlayerPawn"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(UObject**)(params.GetStructMemory() + 0) = Params.WorldContextObject;
		*(int32*)(params.GetStructMemory() + 8) = Params.PlayerIndex;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.WorldContextObject = *(UObject**)(params.GetStructMemory() + 0);
		Params.PlayerIndex = *(int32*)(params.GetStructMemory() + 8);
		Params.ReturnValue = *(APawn**)(params.GetStructMemory() + 16);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetPlayerControllerID(lua_State* InScriptContext)
{
	UClass * Obj = UGameplayStatics::StaticClass(); 
	struct FDispatchParams
	{
		APlayerController* Player = nullptr;
		int32 ReturnValue;
	} Params;
	Params.Player = (APlayerController*)wLua::FLuaUtils::GetUObject(InScriptContext,1,"PlayerController");;
#if UE_GAME
	Params.ReturnValue = UGameplayStatics::GetPlayerControllerID(Params.Player);
#else
	UFunction* Function = Obj->FindFunctionByName(TEXT("GetPlayerControllerID"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(APlayerController**)(params.GetStructMemory() + 0) = Params.Player;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.Player = *(APlayerController**)(params.GetStructMemory() + 0);
		Params.ReturnValue = *(int32*)(params.GetStructMemory() + 8);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushinteger(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetPlayerController(lua_State* InScriptContext)
{
	UClass * Obj = UGameplayStatics::StaticClass(); 
	struct FDispatchParams
	{
		UObject* WorldContextObject = nullptr;
		int32 PlayerIndex;
		APlayerController* ReturnValue = nullptr;
	} Params;
	Params.WorldContextObject = (UObject*)wLua::FLuaUtils::GetUObject(InScriptContext,1,"Object");;
	Params.PlayerIndex = (luaL_checkint(InScriptContext, 2));
#if UE_GAME
	Params.ReturnValue = UGameplayStatics::GetPlayerController(Params.WorldContextObject,Params.PlayerIndex);
#else
	UFunction* Function = Obj->FindFunctionByName(TEXT("GetPlayerController"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(UObject**)(params.GetStructMemory() + 0) = Params.WorldContextObject;
		*(int32*)(params.GetStructMemory() + 8) = Params.PlayerIndex;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.WorldContextObject = *(UObject**)(params.GetStructMemory() + 0);
		Params.PlayerIndex = *(int32*)(params.GetStructMemory() + 8);
		Params.ReturnValue = *(APlayerController**)(params.GetStructMemory() + 16);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetPlayerCharacter(lua_State* InScriptContext)
{
	UClass * Obj = UGameplayStatics::StaticClass(); 
	struct FDispatchParams
	{
		UObject* WorldContextObject = nullptr;
		int32 PlayerIndex;
		ACharacter* ReturnValue = nullptr;
	} Params;
	Params.WorldContextObject = (UObject*)wLua::FLuaUtils::GetUObject(InScriptContext,1,"Object");;
	Params.PlayerIndex = (luaL_checkint(InScriptContext, 2));
#if UE_GAME
	Params.ReturnValue = UGameplayStatics::GetPlayerCharacter(Params.WorldContextObject,Params.PlayerIndex);
#else
	UFunction* Function = Obj->FindFunctionByName(TEXT("GetPlayerCharacter"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(UObject**)(params.GetStructMemory() + 0) = Params.WorldContextObject;
		*(int32*)(params.GetStructMemory() + 8) = Params.PlayerIndex;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.WorldContextObject = *(UObject**)(params.GetStructMemory() + 0);
		Params.PlayerIndex = *(int32*)(params.GetStructMemory() + 8);
		Params.ReturnValue = *(ACharacter**)(params.GetStructMemory() + 16);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetPlayerCameraManager(lua_State* InScriptContext)
{
	UClass * Obj = UGameplayStatics::StaticClass(); 
	struct FDispatchParams
	{
		UObject* WorldContextObject = nullptr;
		int32 PlayerIndex;
		APlayerCameraManager* ReturnValue = nullptr;
	} Params;
	Params.WorldContextObject = (UObject*)wLua::FLuaUtils::GetUObject(InScriptContext,1,"Object");;
	Params.PlayerIndex = (luaL_checkint(InScriptContext, 2));
#if UE_GAME
	Params.ReturnValue = UGameplayStatics::GetPlayerCameraManager(Params.WorldContextObject,Params.PlayerIndex);
#else
	UFunction* Function = Obj->FindFunctionByName(TEXT("GetPlayerCameraManager"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(UObject**)(params.GetStructMemory() + 0) = Params.WorldContextObject;
		*(int32*)(params.GetStructMemory() + 8) = Params.PlayerIndex;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.WorldContextObject = *(UObject**)(params.GetStructMemory() + 0);
		Params.PlayerIndex = *(int32*)(params.GetStructMemory() + 8);
		Params.ReturnValue = *(APlayerCameraManager**)(params.GetStructMemory() + 16);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetPlatformName(lua_State* InScriptContext)
{
	UClass * Obj = UGameplayStatics::StaticClass(); 
	struct FDispatchParams
	{
		FString ReturnValue;
	} Params;
#if UE_GAME
	Params.ReturnValue = UGameplayStatics::GetPlatformName();
#else
	UFunction* Function = Obj->FindFunctionByName(TEXT("GetPlatformName"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(FString*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushstring(InScriptContext, TCHAR_TO_UTF8(*Params.ReturnValue));
	return 1;
}

int32 GetObjectClass(lua_State* InScriptContext)
{
	UClass * Obj = UGameplayStatics::StaticClass(); 
	struct FDispatchParams
	{
		UObject* Object = nullptr;
		UClass* ReturnValue = nullptr;
	} Params;
	Params.Object = (UObject*)wLua::FLuaUtils::GetUObject(InScriptContext,1,"Object");;
#if UE_GAME
	Params.ReturnValue = UGameplayStatics::GetObjectClass(Params.Object);
#else
	UFunction* Function = Obj->FindFunctionByName(TEXT("GetObjectClass"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(UObject**)(params.GetStructMemory() + 0) = Params.Object;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.Object = *(UObject**)(params.GetStructMemory() + 0);
		Params.ReturnValue = *(UClass**)(params.GetStructMemory() + 8);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetKeyValue(lua_State* InScriptContext)
{
	UClass * Obj = UGameplayStatics::StaticClass(); 
	struct FDispatchParams
	{
		FString Pair;
		FString Key;
		FString Value;
	} Params;
	Params.Pair = UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 1));
#if UE_GAME
	UGameplayStatics::GetKeyValue(Params.Pair,Params.Key,Params.Value);
#else
	UFunction* Function = Obj->FindFunctionByName(TEXT("GetKeyValue"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FString*)(params.GetStructMemory() + 0) = Params.Pair;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.Pair = *(FString*)(params.GetStructMemory() + 0);
		Params.Key = *(FString*)(params.GetStructMemory() + 16);
		Params.Value = *(FString*)(params.GetStructMemory() + 32);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushstring(InScriptContext, TCHAR_TO_UTF8(*Params.Key));
	lua_pushstring(InScriptContext, TCHAR_TO_UTF8(*Params.Value));
	return 2;
}

int32 GetIntOption(lua_State* InScriptContext)
{
	UClass * Obj = UGameplayStatics::StaticClass(); 
	struct FDispatchParams
	{
		FString Options;
		FString Key;
		int32 DefaultValue;
		int32 ReturnValue;
	} Params;
	Params.Options = UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 1));
	Params.Key = UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 2));
	Params.DefaultValue = (luaL_checkint(InScriptContext, 3));
#if UE_GAME
	Params.ReturnValue = UGameplayStatics::GetIntOption(Params.Options,Params.Key,Params.DefaultValue);
#else
	UFunction* Function = Obj->FindFunctionByName(TEXT("GetIntOption"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FString*)(params.GetStructMemory() + 0) = Params.Options;
		*(FString*)(params.GetStructMemory() + 16) = Params.Key;
		*(int32*)(params.GetStructMemory() + 32) = Params.DefaultValue;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.Options = *(FString*)(params.GetStructMemory() + 0);
		Params.Key = *(FString*)(params.GetStructMemory() + 16);
		Params.DefaultValue = *(int32*)(params.GetStructMemory() + 32);
		Params.ReturnValue = *(int32*)(params.GetStructMemory() + 36);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushinteger(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetGlobalTimeDilation(lua_State* InScriptContext)
{
	UClass * Obj = UGameplayStatics::StaticClass(); 
	struct FDispatchParams
	{
		UObject* WorldContextObject = nullptr;
		float ReturnValue;
	} Params;
	Params.WorldContextObject = (UObject*)wLua::FLuaUtils::GetUObject(InScriptContext,1,"Object");;
#if UE_GAME
	Params.ReturnValue = UGameplayStatics::GetGlobalTimeDilation(Params.WorldContextObject);
#else
	UFunction* Function = Obj->FindFunctionByName(TEXT("GetGlobalTimeDilation"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(UObject**)(params.GetStructMemory() + 0) = Params.WorldContextObject;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.WorldContextObject = *(UObject**)(params.GetStructMemory() + 0);
		Params.ReturnValue = *(float*)(params.GetStructMemory() + 8);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushnumber(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetGameState(lua_State* InScriptContext)
{
	UClass * Obj = UGameplayStatics::StaticClass(); 
	struct FDispatchParams
	{
		UObject* WorldContextObject = nullptr;
		AGameStateBase* ReturnValue = nullptr;
	} Params;
	Params.WorldContextObject = (UObject*)wLua::FLuaUtils::GetUObject(InScriptContext,1,"Object");;
#if UE_GAME
	Params.ReturnValue = UGameplayStatics::GetGameState(Params.WorldContextObject);
#else
	UFunction* Function = Obj->FindFunctionByName(TEXT("GetGameState"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(UObject**)(params.GetStructMemory() + 0) = Params.WorldContextObject;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.WorldContextObject = *(UObject**)(params.GetStructMemory() + 0);
		Params.ReturnValue = *(AGameStateBase**)(params.GetStructMemory() + 8);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetGameMode(lua_State* InScriptContext)
{
	UClass * Obj = UGameplayStatics::StaticClass(); 
	struct FDispatchParams
	{
		UObject* WorldContextObject = nullptr;
		AGameModeBase* ReturnValue = nullptr;
	} Params;
	Params.WorldContextObject = (UObject*)wLua::FLuaUtils::GetUObject(InScriptContext,1,"Object");;
#if UE_GAME
	Params.ReturnValue = UGameplayStatics::GetGameMode(Params.WorldContextObject);
#else
	UFunction* Function = Obj->FindFunctionByName(TEXT("GetGameMode"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(UObject**)(params.GetStructMemory() + 0) = Params.WorldContextObject;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.WorldContextObject = *(UObject**)(params.GetStructMemory() + 0);
		Params.ReturnValue = *(AGameModeBase**)(params.GetStructMemory() + 8);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetGameInstance(lua_State* InScriptContext)
{
	UClass * Obj = UGameplayStatics::StaticClass(); 
	struct FDispatchParams
	{
		UObject* WorldContextObject = nullptr;
		UGameInstance* ReturnValue = nullptr;
	} Params;
	Params.WorldContextObject = (UObject*)wLua::FLuaUtils::GetUObject(InScriptContext,1,"Object");;
#if UE_GAME
	Params.ReturnValue = UGameplayStatics::GetGameInstance(Params.WorldContextObject);
#else
	UFunction* Function = Obj->FindFunctionByName(TEXT("GetGameInstance"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(UObject**)(params.GetStructMemory() + 0) = Params.WorldContextObject;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.WorldContextObject = *(UObject**)(params.GetStructMemory() + 0);
		Params.ReturnValue = *(UGameInstance**)(params.GetStructMemory() + 8);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetEnableWorldRendering(lua_State* InScriptContext)
{
	UClass * Obj = UGameplayStatics::StaticClass(); 
	struct FDispatchParams
	{
		UObject* WorldContextObject = nullptr;
		bool ReturnValue;
	} Params;
	Params.WorldContextObject = (UObject*)wLua::FLuaUtils::GetUObject(InScriptContext,1,"Object");;
#if UE_GAME
	Params.ReturnValue = UGameplayStatics::GetEnableWorldRendering(Params.WorldContextObject);
#else
	UFunction* Function = Obj->FindFunctionByName(TEXT("GetEnableWorldRendering"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(UObject**)(params.GetStructMemory() + 0) = Params.WorldContextObject;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.WorldContextObject = *(UObject**)(params.GetStructMemory() + 0);
		Params.ReturnValue = *(bool*)(params.GetStructMemory() + 8);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushboolean(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetCurrentReverbEffect(lua_State* InScriptContext)
{
	UClass * Obj = UGameplayStatics::StaticClass(); 
	struct FDispatchParams
	{
		UObject* WorldContextObject = nullptr;
		UReverbEffect* ReturnValue = nullptr;
	} Params;
	Params.WorldContextObject = (UObject*)wLua::FLuaUtils::GetUObject(InScriptContext,1,"Object");;
#if UE_GAME
	Params.ReturnValue = UGameplayStatics::GetCurrentReverbEffect(Params.WorldContextObject);
#else
	UFunction* Function = Obj->FindFunctionByName(TEXT("GetCurrentReverbEffect"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(UObject**)(params.GetStructMemory() + 0) = Params.WorldContextObject;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.WorldContextObject = *(UObject**)(params.GetStructMemory() + 0);
		Params.ReturnValue = *(UReverbEffect**)(params.GetStructMemory() + 8);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetCurrentLevelName(lua_State* InScriptContext)
{
	UClass * Obj = UGameplayStatics::StaticClass(); 
	struct FDispatchParams
	{
		UObject* WorldContextObject = nullptr;
		bool bRemovePrefixString;
		FString ReturnValue;
	} Params;
	Params.WorldContextObject = (UObject*)wLua::FLuaUtils::GetUObject(InScriptContext,1,"Object");;
	Params.bRemovePrefixString = lua_isnoneornil(InScriptContext,2) ? bool(true) : !!(lua_toboolean(InScriptContext, 2));
#if UE_GAME
	Params.ReturnValue = UGameplayStatics::GetCurrentLevelName(Params.WorldContextObject,Params.bRemovePrefixString);
#else
	UFunction* Function = Obj->FindFunctionByName(TEXT("GetCurrentLevelName"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(UObject**)(params.GetStructMemory() + 0) = Params.WorldContextObject;
		*(bool*)(params.GetStructMemory() + 8) = Params.bRemovePrefixString;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.WorldContextObject = *(UObject**)(params.GetStructMemory() + 0);
		Params.bRemovePrefixString = *(bool*)(params.GetStructMemory() + 8);
		Params.ReturnValue = *(FString*)(params.GetStructMemory() + 16);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushstring(InScriptContext, TCHAR_TO_UTF8(*Params.ReturnValue));
	return 1;
}

int32 GetAudioTimeSeconds(lua_State* InScriptContext)
{
	UClass * Obj = UGameplayStatics::StaticClass(); 
	struct FDispatchParams
	{
		UObject* WorldContextObject = nullptr;
		float ReturnValue;
	} Params;
	Params.WorldContextObject = (UObject*)wLua::FLuaUtils::GetUObject(InScriptContext,1,"Object");;
#if UE_GAME
	Params.ReturnValue = UGameplayStatics::GetAudioTimeSeconds(Params.WorldContextObject);
#else
	UFunction* Function = Obj->FindFunctionByName(TEXT("GetAudioTimeSeconds"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(UObject**)(params.GetStructMemory() + 0) = Params.WorldContextObject;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.WorldContextObject = *(UObject**)(params.GetStructMemory() + 0);
		Params.ReturnValue = *(float*)(params.GetStructMemory() + 8);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushnumber(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetAllActorsWithTag(lua_State* InScriptContext)
{
	UClass * Obj = UGameplayStatics::StaticClass(); 
	struct FDispatchParams
	{
		UObject* WorldContextObject = nullptr;
		FName Tag;
		TArray<AActor*> OutActors;
	} Params;
	Params.WorldContextObject = (UObject*)wLua::FLuaUtils::GetUObject(InScriptContext,1,"Object");;
	Params.Tag = FName(UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 2)));
#if UE_GAME
	UGameplayStatics::GetAllActorsWithTag(Params.WorldContextObject,Params.Tag,Params.OutActors);
#else
	UFunction* Function = Obj->FindFunctionByName(TEXT("GetAllActorsWithTag"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(UObject**)(params.GetStructMemory() + 0) = Params.WorldContextObject;
		*(FName*)(params.GetStructMemory() + 8) = Params.Tag;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.WorldContextObject = *(UObject**)(params.GetStructMemory() + 0);
		Params.Tag = *(FName*)(params.GetStructMemory() + 8);
		Params.OutActors = *(TArray<AActor*>*)(params.GetStructMemory() + 24);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	{lua_newtable(InScriptContext); int i = 1; for(auto It = Params.OutActors.CreateConstIterator(); It; ++It,++i) {  wLua::FLuaUtils::ReturnUObject(InScriptContext, (*It)); lua_rawseti(InScriptContext,-2,i);     }  }
	return 1;
}

int32 GetAllActorsWithInterface(lua_State* InScriptContext)
{
	UClass * Obj = UGameplayStatics::StaticClass(); 
	struct FDispatchParams
	{
		UObject* WorldContextObject = nullptr;
		TSubclassOf<UInterface>  Interface;
		TArray<AActor*> OutActors;
	} Params;
	Params.WorldContextObject = (UObject*)wLua::FLuaUtils::GetUObject(InScriptContext,1,"Object");;
	Params.Interface = (UClass*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"Class");;
#if UE_GAME
	UGameplayStatics::GetAllActorsWithInterface(Params.WorldContextObject,Params.Interface,Params.OutActors);
#else
	UFunction* Function = Obj->FindFunctionByName(TEXT("GetAllActorsWithInterface"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(UObject**)(params.GetStructMemory() + 0) = Params.WorldContextObject;
		*(TSubclassOf<UInterface> *)(params.GetStructMemory() + 8) = Params.Interface;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.WorldContextObject = *(UObject**)(params.GetStructMemory() + 0);
		Params.Interface = *(TSubclassOf<UInterface> *)(params.GetStructMemory() + 8);
		Params.OutActors = *(TArray<AActor*>*)(params.GetStructMemory() + 16);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	{lua_newtable(InScriptContext); int i = 1; for(auto It = Params.OutActors.CreateConstIterator(); It; ++It,++i) {  wLua::FLuaUtils::ReturnUObject(InScriptContext, (*It)); lua_rawseti(InScriptContext,-2,i);     }  }
	return 1;
}

int32 GetAllActorsOfClass(lua_State* InScriptContext)
{
	UClass * Obj = UGameplayStatics::StaticClass(); 
	struct FDispatchParams
	{
		UObject* WorldContextObject = nullptr;
		TSubclassOf<AActor>  ActorClass;
		TArray<AActor*> OutActors;
	} Params;
	Params.WorldContextObject = (UObject*)wLua::FLuaUtils::GetUObject(InScriptContext,1,"Object");;
	Params.ActorClass = (UClass*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"Class");;
#if UE_GAME
	UGameplayStatics::GetAllActorsOfClass(Params.WorldContextObject,Params.ActorClass,Params.OutActors);
#else
	UFunction* Function = Obj->FindFunctionByName(TEXT("GetAllActorsOfClass"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(UObject**)(params.GetStructMemory() + 0) = Params.WorldContextObject;
		*(TSubclassOf<AActor> *)(params.GetStructMemory() + 8) = Params.ActorClass;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.WorldContextObject = *(UObject**)(params.GetStructMemory() + 0);
		Params.ActorClass = *(TSubclassOf<AActor> *)(params.GetStructMemory() + 8);
		Params.OutActors = *(TArray<AActor*>*)(params.GetStructMemory() + 16);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	{lua_newtable(InScriptContext); int i = 1; for(auto It = Params.OutActors.CreateConstIterator(); It; ++It,++i) {  wLua::FLuaUtils::ReturnUObject(InScriptContext, (*It)); lua_rawseti(InScriptContext,-2,i);     }  }
	return 1;
}

int32 GetActorArrayBounds(lua_State* InScriptContext)
{
	UClass * Obj = UGameplayStatics::StaticClass(); 
	struct FDispatchParams
	{
		TArray<AActor*> Actors;
		bool bOnlyCollidingComponents;
		FVector Center;
		FVector BoxExtent;
	} Params;
	Params.Actors = [](lua_State * _InScriptContext){ TArray<AActor*> ret; lua_pushnil(_InScriptContext); while(lua_next(_InScriptContext,1)!=0){ AActor* item = (AActor*)wLua::FLuaUtils::GetUObject(_InScriptContext,-1,"Actor");; ret.Add(item); lua_pop(_InScriptContext,1);  } return ret; }(InScriptContext);;
	Params.bOnlyCollidingComponents = !!(lua_toboolean(InScriptContext, 2));
#if UE_GAME
	UGameplayStatics::GetActorArrayBounds(Params.Actors,Params.bOnlyCollidingComponents,Params.Center,Params.BoxExtent);
#else
	UFunction* Function = Obj->FindFunctionByName(TEXT("GetActorArrayBounds"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(TArray<AActor*>*)(params.GetStructMemory() + 0) = Params.Actors;
		*(bool*)(params.GetStructMemory() + 16) = Params.bOnlyCollidingComponents;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.Actors = *(TArray<AActor*>*)(params.GetStructMemory() + 0);
		Params.bOnlyCollidingComponents = *(bool*)(params.GetStructMemory() + 16);
		Params.Center = *(FVector*)(params.GetStructMemory() + 20);
		Params.BoxExtent = *(FVector*)(params.GetStructMemory() + 32);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaVector::Return(InScriptContext, Params.Center);
	wLua::FLuaVector::Return(InScriptContext, Params.BoxExtent);
	return 2;
}

int32 GetActorArrayAverageLocation(lua_State* InScriptContext)
{
	UClass * Obj = UGameplayStatics::StaticClass(); 
	struct FDispatchParams
	{
		TArray<AActor*> Actors;
		FVector ReturnValue;
	} Params;
	Params.Actors = [](lua_State * _InScriptContext){ TArray<AActor*> ret; lua_pushnil(_InScriptContext); while(lua_next(_InScriptContext,1)!=0){ AActor* item = (AActor*)wLua::FLuaUtils::GetUObject(_InScriptContext,-1,"Actor");; ret.Add(item); lua_pop(_InScriptContext,1);  } return ret; }(InScriptContext);;
#if UE_GAME
	Params.ReturnValue = UGameplayStatics::GetActorArrayAverageLocation(Params.Actors);
#else
	UFunction* Function = Obj->FindFunctionByName(TEXT("GetActorArrayAverageLocation"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(TArray<AActor*>*)(params.GetStructMemory() + 0) = Params.Actors;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.Actors = *(TArray<AActor*>*)(params.GetStructMemory() + 0);
		Params.ReturnValue = *(FVector*)(params.GetStructMemory() + 16);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaVector::Return(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetAccurateRealTime(lua_State* InScriptContext)
{
	UClass * Obj = UGameplayStatics::StaticClass(); 
	struct FDispatchParams
	{
		UObject* WorldContextObject = nullptr;
		int32 Seconds;
		float PartialSeconds;
	} Params;
	Params.WorldContextObject = (UObject*)wLua::FLuaUtils::GetUObject(InScriptContext,1,"Object");;
#if UE_GAME
	UGameplayStatics::GetAccurateRealTime(Params.WorldContextObject,Params.Seconds,Params.PartialSeconds);
#else
	UFunction* Function = Obj->FindFunctionByName(TEXT("GetAccurateRealTime"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(UObject**)(params.GetStructMemory() + 0) = Params.WorldContextObject;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.WorldContextObject = *(UObject**)(params.GetStructMemory() + 0);
		Params.Seconds = *(int32*)(params.GetStructMemory() + 8);
		Params.PartialSeconds = *(float*)(params.GetStructMemory() + 12);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushinteger(InScriptContext, Params.Seconds);
	lua_pushnumber(InScriptContext, Params.PartialSeconds);
	return 2;
}

int32 FlushLevelStreaming(lua_State* InScriptContext)
{
	UClass * Obj = UGameplayStatics::StaticClass(); 
	struct FDispatchParams
	{
		UObject* WorldContextObject = nullptr;
	} Params;
	Params.WorldContextObject = (UObject*)wLua::FLuaUtils::GetUObject(InScriptContext,1,"Object");;
#if UE_GAME
	UGameplayStatics::FlushLevelStreaming(Params.WorldContextObject);
#else
	UFunction* Function = Obj->FindFunctionByName(TEXT("FlushLevelStreaming"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(UObject**)(params.GetStructMemory() + 0) = Params.WorldContextObject;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.WorldContextObject = *(UObject**)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 EnableLiveStreaming(lua_State* InScriptContext)
{
	UClass * Obj = UGameplayStatics::StaticClass(); 
	struct FDispatchParams
	{
		bool Enable;
	} Params;
	Params.Enable = !!(lua_toboolean(InScriptContext, 1));
#if UE_GAME
	UGameplayStatics::EnableLiveStreaming(Params.Enable);
#else
	UFunction* Function = Obj->FindFunctionByName(TEXT("EnableLiveStreaming"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(bool*)(params.GetStructMemory() + 0) = Params.Enable;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.Enable = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 DoesSaveGameExist(lua_State* InScriptContext)
{
	UClass * Obj = UGameplayStatics::StaticClass(); 
	struct FDispatchParams
	{
		FString SlotName;
		int32 UserIndex;
		bool ReturnValue;
	} Params;
	Params.SlotName = UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 1));
	Params.UserIndex = (luaL_checkint(InScriptContext, 2));
#if UE_GAME
	Params.ReturnValue = UGameplayStatics::DoesSaveGameExist(Params.SlotName,Params.UserIndex);
#else
	UFunction* Function = Obj->FindFunctionByName(TEXT("DoesSaveGameExist"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FString*)(params.GetStructMemory() + 0) = Params.SlotName;
		*(int32*)(params.GetStructMemory() + 16) = Params.UserIndex;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.SlotName = *(FString*)(params.GetStructMemory() + 0);
		Params.UserIndex = *(int32*)(params.GetStructMemory() + 16);
		Params.ReturnValue = *(bool*)(params.GetStructMemory() + 20);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushboolean(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 DeprojectScreenToWorld(lua_State* InScriptContext)
{
	UClass * Obj = UGameplayStatics::StaticClass(); 
	struct FDispatchParams
	{
		APlayerController* Player = nullptr;
		FVector2D ScreenPosition;
		FVector WorldPosition;
		FVector WorldDirection;
		bool ReturnValue;
	} Params;
	Params.Player = (APlayerController*)wLua::FLuaUtils::GetUObject(InScriptContext,1,"PlayerController");;
	Params.ScreenPosition = (wLua::FLuaVector2D::Get(InScriptContext, 2));
#if UE_GAME
	Params.ReturnValue = UGameplayStatics::DeprojectScreenToWorld(Params.Player,Params.ScreenPosition,Params.WorldPosition,Params.WorldDirection);
#else
	UFunction* Function = Obj->FindFunctionByName(TEXT("DeprojectScreenToWorld"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(APlayerController**)(params.GetStructMemory() + 0) = Params.Player;
		*(FVector2D*)(params.GetStructMemory() + 8) = Params.ScreenPosition;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.Player = *(APlayerController**)(params.GetStructMemory() + 0);
		Params.ScreenPosition = *(FVector2D*)(params.GetStructMemory() + 8);
		Params.WorldPosition = *(FVector*)(params.GetStructMemory() + 16);
		Params.WorldDirection = *(FVector*)(params.GetStructMemory() + 28);
		Params.ReturnValue = *(bool*)(params.GetStructMemory() + 40);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushboolean(InScriptContext, Params.ReturnValue);
	wLua::FLuaVector::Return(InScriptContext, Params.WorldPosition);
	wLua::FLuaVector::Return(InScriptContext, Params.WorldDirection);
	return 3;
}

int32 DeleteGameInSlot(lua_State* InScriptContext)
{
	UClass * Obj = UGameplayStatics::StaticClass(); 
	struct FDispatchParams
	{
		FString SlotName;
		int32 UserIndex;
		bool ReturnValue;
	} Params;
	Params.SlotName = UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 1));
	Params.UserIndex = (luaL_checkint(InScriptContext, 2));
#if UE_GAME
	Params.ReturnValue = UGameplayStatics::DeleteGameInSlot(Params.SlotName,Params.UserIndex);
#else
	UFunction* Function = Obj->FindFunctionByName(TEXT("DeleteGameInSlot"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FString*)(params.GetStructMemory() + 0) = Params.SlotName;
		*(int32*)(params.GetStructMemory() + 16) = Params.UserIndex;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.SlotName = *(FString*)(params.GetStructMemory() + 0);
		Params.UserIndex = *(int32*)(params.GetStructMemory() + 16);
		Params.ReturnValue = *(bool*)(params.GetStructMemory() + 20);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushboolean(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 DeactivateReverbEffect(lua_State* InScriptContext)
{
	UClass * Obj = UGameplayStatics::StaticClass(); 
	struct FDispatchParams
	{
		UObject* WorldContextObject = nullptr;
		FName TagName;
	} Params;
	Params.WorldContextObject = (UObject*)wLua::FLuaUtils::GetUObject(InScriptContext,1,"Object");;
	Params.TagName = FName(UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 2)));
#if UE_GAME
	UGameplayStatics::DeactivateReverbEffect(Params.WorldContextObject,Params.TagName);
#else
	UFunction* Function = Obj->FindFunctionByName(TEXT("DeactivateReverbEffect"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(UObject**)(params.GetStructMemory() + 0) = Params.WorldContextObject;
		*(FName*)(params.GetStructMemory() + 8) = Params.TagName;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.WorldContextObject = *(UObject**)(params.GetStructMemory() + 0);
		Params.TagName = *(FName*)(params.GetStructMemory() + 8);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 CreateSound2D(lua_State* InScriptContext)
{
	UClass * Obj = UGameplayStatics::StaticClass(); 
	struct FDispatchParams
	{
		UObject* WorldContextObject = nullptr;
		USoundBase* Sound = nullptr;
		float VolumeMultiplier;
		float PitchMultiplier;
		float StartTime;
		USoundConcurrency* ConcurrencySettings = nullptr;
		bool bPersistAcrossLevelTransition;
		bool bAutoDestroy;
		UAudioComponent* ReturnValue = nullptr;
	} Params;
	Params.WorldContextObject = (UObject*)wLua::FLuaUtils::GetUObject(InScriptContext,1,"Object");;
	Params.Sound = (USoundBase*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"SoundBase");;
	Params.VolumeMultiplier = lua_isnoneornil(InScriptContext,3) ? float(1.000000) : (float)(luaL_checknumber(InScriptContext, 3));
	Params.PitchMultiplier = lua_isnoneornil(InScriptContext,4) ? float(1.000000) : (float)(luaL_checknumber(InScriptContext, 4));
	Params.StartTime = lua_isnoneornil(InScriptContext,5) ? float(0.000000) : (float)(luaL_checknumber(InScriptContext, 5));
	Params.ConcurrencySettings = lua_isnoneornil(InScriptContext,6) ? nullptr : (USoundConcurrency*)wLua::FLuaUtils::GetUObject(InScriptContext,6,"SoundConcurrency");;
	Params.bPersistAcrossLevelTransition = lua_isnoneornil(InScriptContext,7) ? bool(false) : !!(lua_toboolean(InScriptContext, 7));
	Params.bAutoDestroy = lua_isnoneornil(InScriptContext,8) ? bool(true) : !!(lua_toboolean(InScriptContext, 8));
#if UE_GAME
	Params.ReturnValue = UGameplayStatics::CreateSound2D(Params.WorldContextObject,Params.Sound,Params.VolumeMultiplier,Params.PitchMultiplier,Params.StartTime,Params.ConcurrencySettings,Params.bPersistAcrossLevelTransition,Params.bAutoDestroy);
#else
	UFunction* Function = Obj->FindFunctionByName(TEXT("CreateSound2D"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(UObject**)(params.GetStructMemory() + 0) = Params.WorldContextObject;
		*(USoundBase**)(params.GetStructMemory() + 8) = Params.Sound;
		*(float*)(params.GetStructMemory() + 16) = Params.VolumeMultiplier;
		*(float*)(params.GetStructMemory() + 20) = Params.PitchMultiplier;
		*(float*)(params.GetStructMemory() + 24) = Params.StartTime;
		*(USoundConcurrency**)(params.GetStructMemory() + 32) = Params.ConcurrencySettings;
		*(bool*)(params.GetStructMemory() + 40) = Params.bPersistAcrossLevelTransition;
		*(bool*)(params.GetStructMemory() + 41) = Params.bAutoDestroy;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.WorldContextObject = *(UObject**)(params.GetStructMemory() + 0);
		Params.Sound = *(USoundBase**)(params.GetStructMemory() + 8);
		Params.VolumeMultiplier = *(float*)(params.GetStructMemory() + 16);
		Params.PitchMultiplier = *(float*)(params.GetStructMemory() + 20);
		Params.StartTime = *(float*)(params.GetStructMemory() + 24);
		Params.ConcurrencySettings = *(USoundConcurrency**)(params.GetStructMemory() + 32);
		Params.bPersistAcrossLevelTransition = *(bool*)(params.GetStructMemory() + 40);
		Params.bAutoDestroy = *(bool*)(params.GetStructMemory() + 41);
		Params.ReturnValue = *(UAudioComponent**)(params.GetStructMemory() + 48);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 CreateSaveGameObject(lua_State* InScriptContext)
{
	UClass * Obj = UGameplayStatics::StaticClass(); 
	struct FDispatchParams
	{
		TSubclassOf<USaveGame>  SaveGameClass;
		USaveGame* ReturnValue = nullptr;
	} Params;
	Params.SaveGameClass = (UClass*)wLua::FLuaUtils::GetUObject(InScriptContext,1,"Class");;
#if UE_GAME
	Params.ReturnValue = UGameplayStatics::CreateSaveGameObject(Params.SaveGameClass);
#else
	UFunction* Function = Obj->FindFunctionByName(TEXT("CreateSaveGameObject"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(TSubclassOf<USaveGame> *)(params.GetStructMemory() + 0) = Params.SaveGameClass;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.SaveGameClass = *(TSubclassOf<USaveGame> *)(params.GetStructMemory() + 0);
		Params.ReturnValue = *(USaveGame**)(params.GetStructMemory() + 8);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 CreatePlayer(lua_State* InScriptContext)
{
	UClass * Obj = UGameplayStatics::StaticClass(); 
	struct FDispatchParams
	{
		UObject* WorldContextObject = nullptr;
		int32 ControllerId;
		bool bSpawnPawn;
		APlayerController* ReturnValue = nullptr;
	} Params;
	Params.WorldContextObject = (UObject*)wLua::FLuaUtils::GetUObject(InScriptContext,1,"Object");;
	Params.ControllerId = lua_isnoneornil(InScriptContext,2) ? int32(-1) : (luaL_checkint(InScriptContext, 2));
	Params.bSpawnPawn = lua_isnoneornil(InScriptContext,3) ? bool(true) : !!(lua_toboolean(InScriptContext, 3));
#if UE_GAME
	Params.ReturnValue = UGameplayStatics::CreatePlayer(Params.WorldContextObject,Params.ControllerId,Params.bSpawnPawn);
#else
	UFunction* Function = Obj->FindFunctionByName(TEXT("CreatePlayer"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(UObject**)(params.GetStructMemory() + 0) = Params.WorldContextObject;
		*(int32*)(params.GetStructMemory() + 8) = Params.ControllerId;
		*(bool*)(params.GetStructMemory() + 12) = Params.bSpawnPawn;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.WorldContextObject = *(UObject**)(params.GetStructMemory() + 0);
		Params.ControllerId = *(int32*)(params.GetStructMemory() + 8);
		Params.bSpawnPawn = *(bool*)(params.GetStructMemory() + 12);
		Params.ReturnValue = *(APlayerController**)(params.GetStructMemory() + 16);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 ClearSoundMixModifiers(lua_State* InScriptContext)
{
	UClass * Obj = UGameplayStatics::StaticClass(); 
	struct FDispatchParams
	{
		UObject* WorldContextObject = nullptr;
	} Params;
	Params.WorldContextObject = (UObject*)wLua::FLuaUtils::GetUObject(InScriptContext,1,"Object");;
#if UE_GAME
	UGameplayStatics::ClearSoundMixModifiers(Params.WorldContextObject);
#else
	UFunction* Function = Obj->FindFunctionByName(TEXT("ClearSoundMixModifiers"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(UObject**)(params.GetStructMemory() + 0) = Params.WorldContextObject;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.WorldContextObject = *(UObject**)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 ClearSoundMixClassOverride(lua_State* InScriptContext)
{
	UClass * Obj = UGameplayStatics::StaticClass(); 
	struct FDispatchParams
	{
		UObject* WorldContextObject = nullptr;
		USoundMix* InSoundMixModifier = nullptr;
		USoundClass* InSoundClass = nullptr;
		float FadeOutTime;
	} Params;
	Params.WorldContextObject = (UObject*)wLua::FLuaUtils::GetUObject(InScriptContext,1,"Object");;
	Params.InSoundMixModifier = (USoundMix*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"SoundMix");;
	Params.InSoundClass = (USoundClass*)wLua::FLuaUtils::GetUObject(InScriptContext,3,"SoundClass");;
	Params.FadeOutTime = lua_isnoneornil(InScriptContext,4) ? float(1.000000) : (float)(luaL_checknumber(InScriptContext, 4));
#if UE_GAME
	UGameplayStatics::ClearSoundMixClassOverride(Params.WorldContextObject,Params.InSoundMixModifier,Params.InSoundClass,Params.FadeOutTime);
#else
	UFunction* Function = Obj->FindFunctionByName(TEXT("ClearSoundMixClassOverride"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(UObject**)(params.GetStructMemory() + 0) = Params.WorldContextObject;
		*(USoundMix**)(params.GetStructMemory() + 8) = Params.InSoundMixModifier;
		*(USoundClass**)(params.GetStructMemory() + 16) = Params.InSoundClass;
		*(float*)(params.GetStructMemory() + 24) = Params.FadeOutTime;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.WorldContextObject = *(UObject**)(params.GetStructMemory() + 0);
		Params.InSoundMixModifier = *(USoundMix**)(params.GetStructMemory() + 8);
		Params.InSoundClass = *(USoundClass**)(params.GetStructMemory() + 16);
		Params.FadeOutTime = *(float*)(params.GetStructMemory() + 24);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 CancelAsyncLoading(lua_State* InScriptContext)
{
	UClass * Obj = UGameplayStatics::StaticClass(); 
#if UE_GAME
	UGameplayStatics::CancelAsyncLoading();
#else
	UFunction* Function = Obj->FindFunctionByName(TEXT("CancelAsyncLoading"));
	if(!Function) { check(false); return 0;}
	Obj->ProcessEvent(Function, NULL);
#endif
	return 0;
}

int32 BlueprintSuggestProjectileVelocity(lua_State* InScriptContext)
{
	UClass * Obj = UGameplayStatics::StaticClass(); 
	struct FDispatchParams
	{
		UObject* WorldContextObject = nullptr;
		FVector TossVelocity;
		FVector StartLocation;
		FVector EndLocation;
		float LaunchSpeed;
		float OverrideGravityZ;
		TEnumAsByte<ESuggestProjVelocityTraceOption::Type> TraceOption;
		float CollisionRadius;
		bool bFavorHighArc;
		bool bDrawDebug;
		bool ReturnValue;
	} Params;
	Params.WorldContextObject = (UObject*)wLua::FLuaUtils::GetUObject(InScriptContext,1,"Object");;
	Params.StartLocation = (wLua::FLuaVector::Get(InScriptContext, 3));
	Params.EndLocation = (wLua::FLuaVector::Get(InScriptContext, 4));
	Params.LaunchSpeed = (float)(luaL_checknumber(InScriptContext, 5));
	Params.OverrideGravityZ = (float)(luaL_checknumber(InScriptContext, 6));
	Params.TraceOption = (TEnumAsByte<ESuggestProjVelocityTraceOption::Type>)(luaL_checkint(InScriptContext, 7));
	Params.CollisionRadius = (float)(luaL_checknumber(InScriptContext, 8));
	Params.bFavorHighArc = !!(lua_toboolean(InScriptContext, 9));
	Params.bDrawDebug = !!(lua_toboolean(InScriptContext, 10));
#if UE_GAME
	Params.ReturnValue = UGameplayStatics::BlueprintSuggestProjectileVelocity(Params.WorldContextObject,Params.TossVelocity,Params.StartLocation,Params.EndLocation,Params.LaunchSpeed,Params.OverrideGravityZ,Params.TraceOption,Params.CollisionRadius,Params.bFavorHighArc,Params.bDrawDebug);
#else
	UFunction* Function = Obj->FindFunctionByName(TEXT("BlueprintSuggestProjectileVelocity"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(UObject**)(params.GetStructMemory() + 0) = Params.WorldContextObject;
		*(FVector*)(params.GetStructMemory() + 20) = Params.StartLocation;
		*(FVector*)(params.GetStructMemory() + 32) = Params.EndLocation;
		*(float*)(params.GetStructMemory() + 44) = Params.LaunchSpeed;
		*(float*)(params.GetStructMemory() + 48) = Params.OverrideGravityZ;
		*(TEnumAsByte<ESuggestProjVelocityTraceOption::Type>*)(params.GetStructMemory() + 52) = Params.TraceOption;
		*(float*)(params.GetStructMemory() + 56) = Params.CollisionRadius;
		*(bool*)(params.GetStructMemory() + 60) = Params.bFavorHighArc;
		*(bool*)(params.GetStructMemory() + 61) = Params.bDrawDebug;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.WorldContextObject = *(UObject**)(params.GetStructMemory() + 0);
		Params.TossVelocity = *(FVector*)(params.GetStructMemory() + 8);
		Params.StartLocation = *(FVector*)(params.GetStructMemory() + 20);
		Params.EndLocation = *(FVector*)(params.GetStructMemory() + 32);
		Params.LaunchSpeed = *(float*)(params.GetStructMemory() + 44);
		Params.OverrideGravityZ = *(float*)(params.GetStructMemory() + 48);
		Params.TraceOption = *(TEnumAsByte<ESuggestProjVelocityTraceOption::Type>*)(params.GetStructMemory() + 52);
		Params.CollisionRadius = *(float*)(params.GetStructMemory() + 56);
		Params.bFavorHighArc = *(bool*)(params.GetStructMemory() + 60);
		Params.bDrawDebug = *(bool*)(params.GetStructMemory() + 61);
		Params.ReturnValue = *(bool*)(params.GetStructMemory() + 62);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushboolean(InScriptContext, Params.ReturnValue);
	wLua::FLuaVector::Return(InScriptContext, Params.TossVelocity);
	return 2;
}

int32 AreSubtitlesEnabled(lua_State* InScriptContext)
{
	UClass * Obj = UGameplayStatics::StaticClass(); 
	struct FDispatchParams
	{
		bool ReturnValue;
	} Params;
#if UE_GAME
	Params.ReturnValue = UGameplayStatics::AreSubtitlesEnabled();
#else
	UFunction* Function = Obj->FindFunctionByName(TEXT("AreSubtitlesEnabled"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushboolean(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 AreAnyListenersWithinRange(lua_State* InScriptContext)
{
	UClass * Obj = UGameplayStatics::StaticClass(); 
	struct FDispatchParams
	{
		UObject* WorldContextObject = nullptr;
		FVector Location;
		float MaximumRange;
		bool ReturnValue;
	} Params;
	Params.WorldContextObject = (UObject*)wLua::FLuaUtils::GetUObject(InScriptContext,1,"Object");;
	Params.Location = (wLua::FLuaVector::Get(InScriptContext, 2));
	Params.MaximumRange = (float)(luaL_checknumber(InScriptContext, 3));
#if UE_GAME
	Params.ReturnValue = UGameplayStatics::AreAnyListenersWithinRange(Params.WorldContextObject,Params.Location,Params.MaximumRange);
#else
	UFunction* Function = Obj->FindFunctionByName(TEXT("AreAnyListenersWithinRange"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(UObject**)(params.GetStructMemory() + 0) = Params.WorldContextObject;
		*(FVector*)(params.GetStructMemory() + 8) = Params.Location;
		*(float*)(params.GetStructMemory() + 20) = Params.MaximumRange;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.WorldContextObject = *(UObject**)(params.GetStructMemory() + 0);
		Params.Location = *(FVector*)(params.GetStructMemory() + 8);
		Params.MaximumRange = *(float*)(params.GetStructMemory() + 20);
		Params.ReturnValue = *(bool*)(params.GetStructMemory() + 24);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushboolean(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 ApplyRadialDamageWithFalloff(lua_State* InScriptContext)
{
	UClass * Obj = UGameplayStatics::StaticClass(); 
	struct FDispatchParams
	{
		UObject* WorldContextObject = nullptr;
		float BaseDamage;
		float MinimumDamage;
		FVector Origin;
		float DamageInnerRadius;
		float DamageOuterRadius;
		float DamageFalloff;
		TSubclassOf<UDamageType>  DamageTypeClass;
		TArray<AActor*> IgnoreActors;
		AActor* DamageCauser = nullptr;
		AController* InstigatedByController = nullptr;
		TEnumAsByte<ECollisionChannel> DamagePreventionChannel;
		bool ReturnValue;
	} Params;
	Params.WorldContextObject = (UObject*)wLua::FLuaUtils::GetUObject(InScriptContext,1,"Object");;
	Params.BaseDamage = (float)(luaL_checknumber(InScriptContext, 2));
	Params.MinimumDamage = (float)(luaL_checknumber(InScriptContext, 3));
	Params.Origin = (wLua::FLuaVector::Get(InScriptContext, 4));
	Params.DamageInnerRadius = (float)(luaL_checknumber(InScriptContext, 5));
	Params.DamageOuterRadius = (float)(luaL_checknumber(InScriptContext, 6));
	Params.DamageFalloff = (float)(luaL_checknumber(InScriptContext, 7));
	Params.DamageTypeClass = (UClass*)wLua::FLuaUtils::GetUObject(InScriptContext,8,"Class");;
	Params.IgnoreActors = [](lua_State * _InScriptContext){ TArray<AActor*> ret; lua_pushnil(_InScriptContext); while(lua_next(_InScriptContext,9)!=0){ AActor* item = (AActor*)wLua::FLuaUtils::GetUObject(_InScriptContext,-1,"Actor");; ret.Add(item); lua_pop(_InScriptContext,1);  } return ret; }(InScriptContext);;
	Params.DamageCauser = lua_isnoneornil(InScriptContext,10) ? nullptr : (AActor*)wLua::FLuaUtils::GetUObject(InScriptContext,10,"Actor");;
	Params.InstigatedByController = lua_isnoneornil(InScriptContext,11) ? nullptr : (AController*)wLua::FLuaUtils::GetUObject(InScriptContext,11,"Controller");;
	Params.DamagePreventionChannel = lua_isnoneornil(InScriptContext,12) ? TEnumAsByte<ECollisionChannel>(ECollisionChannel::ECC_Visibility) : (TEnumAsByte<ECollisionChannel>)(luaL_checkint(InScriptContext, 12));
#if UE_GAME
	Params.ReturnValue = UGameplayStatics::ApplyRadialDamageWithFalloff(Params.WorldContextObject,Params.BaseDamage,Params.MinimumDamage,Params.Origin,Params.DamageInnerRadius,Params.DamageOuterRadius,Params.DamageFalloff,Params.DamageTypeClass,Params.IgnoreActors,Params.DamageCauser,Params.InstigatedByController,Params.DamagePreventionChannel);
#else
	UFunction* Function = Obj->FindFunctionByName(TEXT("ApplyRadialDamageWithFalloff"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(UObject**)(params.GetStructMemory() + 0) = Params.WorldContextObject;
		*(float*)(params.GetStructMemory() + 8) = Params.BaseDamage;
		*(float*)(params.GetStructMemory() + 12) = Params.MinimumDamage;
		*(FVector*)(params.GetStructMemory() + 16) = Params.Origin;
		*(float*)(params.GetStructMemory() + 28) = Params.DamageInnerRadius;
		*(float*)(params.GetStructMemory() + 32) = Params.DamageOuterRadius;
		*(float*)(params.GetStructMemory() + 36) = Params.DamageFalloff;
		*(TSubclassOf<UDamageType> *)(params.GetStructMemory() + 40) = Params.DamageTypeClass;
		*(TArray<AActor*>*)(params.GetStructMemory() + 48) = Params.IgnoreActors;
		*(AActor**)(params.GetStructMemory() + 64) = Params.DamageCauser;
		*(AController**)(params.GetStructMemory() + 72) = Params.InstigatedByController;
		*(TEnumAsByte<ECollisionChannel>*)(params.GetStructMemory() + 80) = Params.DamagePreventionChannel;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.WorldContextObject = *(UObject**)(params.GetStructMemory() + 0);
		Params.BaseDamage = *(float*)(params.GetStructMemory() + 8);
		Params.MinimumDamage = *(float*)(params.GetStructMemory() + 12);
		Params.Origin = *(FVector*)(params.GetStructMemory() + 16);
		Params.DamageInnerRadius = *(float*)(params.GetStructMemory() + 28);
		Params.DamageOuterRadius = *(float*)(params.GetStructMemory() + 32);
		Params.DamageFalloff = *(float*)(params.GetStructMemory() + 36);
		Params.DamageTypeClass = *(TSubclassOf<UDamageType> *)(params.GetStructMemory() + 40);
		Params.IgnoreActors = *(TArray<AActor*>*)(params.GetStructMemory() + 48);
		Params.DamageCauser = *(AActor**)(params.GetStructMemory() + 64);
		Params.InstigatedByController = *(AController**)(params.GetStructMemory() + 72);
		Params.DamagePreventionChannel = *(TEnumAsByte<ECollisionChannel>*)(params.GetStructMemory() + 80);
		Params.ReturnValue = *(bool*)(params.GetStructMemory() + 81);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushboolean(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 ApplyRadialDamage(lua_State* InScriptContext)
{
	UClass * Obj = UGameplayStatics::StaticClass(); 
	struct FDispatchParams
	{
		UObject* WorldContextObject = nullptr;
		float BaseDamage;
		FVector Origin;
		float DamageRadius;
		TSubclassOf<UDamageType>  DamageTypeClass;
		TArray<AActor*> IgnoreActors;
		AActor* DamageCauser = nullptr;
		AController* InstigatedByController = nullptr;
		bool bDoFullDamage;
		TEnumAsByte<ECollisionChannel> DamagePreventionChannel;
		bool ReturnValue;
	} Params;
	Params.WorldContextObject = (UObject*)wLua::FLuaUtils::GetUObject(InScriptContext,1,"Object");;
	Params.BaseDamage = (float)(luaL_checknumber(InScriptContext, 2));
	Params.Origin = (wLua::FLuaVector::Get(InScriptContext, 3));
	Params.DamageRadius = (float)(luaL_checknumber(InScriptContext, 4));
	Params.DamageTypeClass = (UClass*)wLua::FLuaUtils::GetUObject(InScriptContext,5,"Class");;
	Params.IgnoreActors = [](lua_State * _InScriptContext){ TArray<AActor*> ret; lua_pushnil(_InScriptContext); while(lua_next(_InScriptContext,6)!=0){ AActor* item = (AActor*)wLua::FLuaUtils::GetUObject(_InScriptContext,-1,"Actor");; ret.Add(item); lua_pop(_InScriptContext,1);  } return ret; }(InScriptContext);;
	Params.DamageCauser = lua_isnoneornil(InScriptContext,7) ? nullptr : (AActor*)wLua::FLuaUtils::GetUObject(InScriptContext,7,"Actor");;
	Params.InstigatedByController = lua_isnoneornil(InScriptContext,8) ? nullptr : (AController*)wLua::FLuaUtils::GetUObject(InScriptContext,8,"Controller");;
	Params.bDoFullDamage = lua_isnoneornil(InScriptContext,9) ? bool(false) : !!(lua_toboolean(InScriptContext, 9));
	Params.DamagePreventionChannel = lua_isnoneornil(InScriptContext,10) ? TEnumAsByte<ECollisionChannel>(ECollisionChannel::ECC_Visibility) : (TEnumAsByte<ECollisionChannel>)(luaL_checkint(InScriptContext, 10));
#if UE_GAME
	Params.ReturnValue = UGameplayStatics::ApplyRadialDamage(Params.WorldContextObject,Params.BaseDamage,Params.Origin,Params.DamageRadius,Params.DamageTypeClass,Params.IgnoreActors,Params.DamageCauser,Params.InstigatedByController,Params.bDoFullDamage,Params.DamagePreventionChannel);
#else
	UFunction* Function = Obj->FindFunctionByName(TEXT("ApplyRadialDamage"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(UObject**)(params.GetStructMemory() + 0) = Params.WorldContextObject;
		*(float*)(params.GetStructMemory() + 8) = Params.BaseDamage;
		*(FVector*)(params.GetStructMemory() + 12) = Params.Origin;
		*(float*)(params.GetStructMemory() + 24) = Params.DamageRadius;
		*(TSubclassOf<UDamageType> *)(params.GetStructMemory() + 32) = Params.DamageTypeClass;
		*(TArray<AActor*>*)(params.GetStructMemory() + 40) = Params.IgnoreActors;
		*(AActor**)(params.GetStructMemory() + 56) = Params.DamageCauser;
		*(AController**)(params.GetStructMemory() + 64) = Params.InstigatedByController;
		*(bool*)(params.GetStructMemory() + 72) = Params.bDoFullDamage;
		*(TEnumAsByte<ECollisionChannel>*)(params.GetStructMemory() + 73) = Params.DamagePreventionChannel;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.WorldContextObject = *(UObject**)(params.GetStructMemory() + 0);
		Params.BaseDamage = *(float*)(params.GetStructMemory() + 8);
		Params.Origin = *(FVector*)(params.GetStructMemory() + 12);
		Params.DamageRadius = *(float*)(params.GetStructMemory() + 24);
		Params.DamageTypeClass = *(TSubclassOf<UDamageType> *)(params.GetStructMemory() + 32);
		Params.IgnoreActors = *(TArray<AActor*>*)(params.GetStructMemory() + 40);
		Params.DamageCauser = *(AActor**)(params.GetStructMemory() + 56);
		Params.InstigatedByController = *(AController**)(params.GetStructMemory() + 64);
		Params.bDoFullDamage = *(bool*)(params.GetStructMemory() + 72);
		Params.DamagePreventionChannel = *(TEnumAsByte<ECollisionChannel>*)(params.GetStructMemory() + 73);
		Params.ReturnValue = *(bool*)(params.GetStructMemory() + 74);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushboolean(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 ApplyDamage(lua_State* InScriptContext)
{
	UClass * Obj = UGameplayStatics::StaticClass(); 
	struct FDispatchParams
	{
		AActor* DamagedActor = nullptr;
		float BaseDamage;
		AController* EventInstigator = nullptr;
		AActor* DamageCauser = nullptr;
		TSubclassOf<UDamageType>  DamageTypeClass;
		float ReturnValue;
	} Params;
	Params.DamagedActor = (AActor*)wLua::FLuaUtils::GetUObject(InScriptContext,1,"Actor");;
	Params.BaseDamage = (float)(luaL_checknumber(InScriptContext, 2));
	Params.EventInstigator = (AController*)wLua::FLuaUtils::GetUObject(InScriptContext,3,"Controller");;
	Params.DamageCauser = (AActor*)wLua::FLuaUtils::GetUObject(InScriptContext,4,"Actor");;
	Params.DamageTypeClass = (UClass*)wLua::FLuaUtils::GetUObject(InScriptContext,5,"Class");;
#if UE_GAME
	Params.ReturnValue = UGameplayStatics::ApplyDamage(Params.DamagedActor,Params.BaseDamage,Params.EventInstigator,Params.DamageCauser,Params.DamageTypeClass);
#else
	UFunction* Function = Obj->FindFunctionByName(TEXT("ApplyDamage"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(AActor**)(params.GetStructMemory() + 0) = Params.DamagedActor;
		*(float*)(params.GetStructMemory() + 8) = Params.BaseDamage;
		*(AController**)(params.GetStructMemory() + 16) = Params.EventInstigator;
		*(AActor**)(params.GetStructMemory() + 24) = Params.DamageCauser;
		*(TSubclassOf<UDamageType> *)(params.GetStructMemory() + 32) = Params.DamageTypeClass;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.DamagedActor = *(AActor**)(params.GetStructMemory() + 0);
		Params.BaseDamage = *(float*)(params.GetStructMemory() + 8);
		Params.EventInstigator = *(AController**)(params.GetStructMemory() + 16);
		Params.DamageCauser = *(AActor**)(params.GetStructMemory() + 24);
		Params.DamageTypeClass = *(TSubclassOf<UDamageType> *)(params.GetStructMemory() + 32);
		Params.ReturnValue = *(float*)(params.GetStructMemory() + 40);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushnumber(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 ActivateReverbEffect(lua_State* InScriptContext)
{
	UClass * Obj = UGameplayStatics::StaticClass(); 
	struct FDispatchParams
	{
		UObject* WorldContextObject = nullptr;
		UReverbEffect* ReverbEffect = nullptr;
		FName TagName;
		float Priority;
		float Volume;
		float FadeTime;
	} Params;
	Params.WorldContextObject = (UObject*)wLua::FLuaUtils::GetUObject(InScriptContext,1,"Object");;
	Params.ReverbEffect = (UReverbEffect*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"ReverbEffect");;
	Params.TagName = FName(UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 3)));
	Params.Priority = lua_isnoneornil(InScriptContext,4) ? float(0.000000) : (float)(luaL_checknumber(InScriptContext, 4));
	Params.Volume = lua_isnoneornil(InScriptContext,5) ? float(0.500000) : (float)(luaL_checknumber(InScriptContext, 5));
	Params.FadeTime = lua_isnoneornil(InScriptContext,6) ? float(2.000000) : (float)(luaL_checknumber(InScriptContext, 6));
#if UE_GAME
	UGameplayStatics::ActivateReverbEffect(Params.WorldContextObject,Params.ReverbEffect,Params.TagName,Params.Priority,Params.Volume,Params.FadeTime);
#else
	UFunction* Function = Obj->FindFunctionByName(TEXT("ActivateReverbEffect"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(UObject**)(params.GetStructMemory() + 0) = Params.WorldContextObject;
		*(UReverbEffect**)(params.GetStructMemory() + 8) = Params.ReverbEffect;
		*(FName*)(params.GetStructMemory() + 16) = Params.TagName;
		*(float*)(params.GetStructMemory() + 28) = Params.Priority;
		*(float*)(params.GetStructMemory() + 32) = Params.Volume;
		*(float*)(params.GetStructMemory() + 36) = Params.FadeTime;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.WorldContextObject = *(UObject**)(params.GetStructMemory() + 0);
		Params.ReverbEffect = *(UReverbEffect**)(params.GetStructMemory() + 8);
		Params.TagName = *(FName*)(params.GetStructMemory() + 16);
		Params.Priority = *(float*)(params.GetStructMemory() + 28);
		Params.Volume = *(float*)(params.GetStructMemory() + 32);
		Params.FadeTime = *(float*)(params.GetStructMemory() + 36);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 New(lua_State* InScriptContext)
{
	UObject* Outer = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Object");
	FName Name = FName(luaL_checkstring(InScriptContext, 2));
	UObject* Obj = NewObject<UGameplayStatics>(Outer, Name);
	wLua::FLuaUtils::ReturnUObject(InScriptContext,Obj);
	return 1;
}

int32 Destroy(lua_State* InScriptContext)
{
	return 0;
}

int32 Class(lua_State* InScriptContext)
{
	UClass* Class = UGameplayStatics::StaticClass();
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Class);
	return 1;
}

const luaL_Reg Lib_Funcs[] =
{
	{ "New", New },
	{ "Destroy", Destroy },
	{ "Class", Class },
	{ "SuggestProjectileVelocity_CustomArc", SuggestProjectileVelocity_CustomArc },
	{ "SpawnSoundAttached", SpawnSoundAttached },
	{ "SpawnSoundAtLocation", SpawnSoundAtLocation },
	{ "SpawnSound2D", SpawnSound2D },
	{ "SpawnForceFeedbackAttached", SpawnForceFeedbackAttached },
	{ "SpawnForceFeedbackAtLocation", SpawnForceFeedbackAtLocation },
	{ "SpawnEmitterAttached", SpawnEmitterAttached },
	{ "SpawnEmitterAtLocation", SpawnEmitterAtLocation },
	{ "SpawnDecalAttached", SpawnDecalAttached },
	{ "SpawnDecalAtLocation", SpawnDecalAtLocation },
	{ "SetSubtitlesEnabled", SetSubtitlesEnabled },
	{ "SetSoundMixClassOverride", SetSoundMixClassOverride },
	{ "SetPlayerControllerID", SetPlayerControllerID },
	{ "SetGlobalTimeDilation", SetGlobalTimeDilation },
	{ "SetGlobalPitchModulation", SetGlobalPitchModulation },
	{ "SetGlobalListenerFocusParameters", SetGlobalListenerFocusParameters },
	{ "SetGamePaused", SetGamePaused },
	{ "SetEnableWorldRendering", SetEnableWorldRendering },
	{ "SetBaseSoundMix", SetBaseSoundMix },
	{ "SaveGameToSlot", SaveGameToSlot },
	{ "RemovePlayer", RemovePlayer },
	{ "RebaseZeroOriginOntoLocal", RebaseZeroOriginOntoLocal },
	{ "RebaseLocalOriginOntoZero", RebaseLocalOriginOntoZero },
	{ "PushSoundMixModifier", PushSoundMixModifier },
	{ "ProjectWorldToScreen", ProjectWorldToScreen },
	{ "PopSoundMixModifier", PopSoundMixModifier },
	{ "PlayWorldCameraShake", PlayWorldCameraShake },
	{ "PlaySoundAtLocation", PlaySoundAtLocation },
	{ "PlaySound2D", PlaySound2D },
	{ "ParseOption", ParseOption },
	{ "OpenLevel", OpenLevel },
	{ "LoadGameFromSlot", LoadGameFromSlot },
	{ "IsGamePaused", IsGamePaused },
	{ "HasOption", HasOption },
	{ "HasLaunchOption", HasLaunchOption },
	{ "GrassOverlappingSphereCount", GrassOverlappingSphereCount },
	{ "GetWorldDeltaSeconds", GetWorldDeltaSeconds },
	{ "GetUnpausedTimeSeconds", GetUnpausedTimeSeconds },
	{ "GetTimeSeconds", GetTimeSeconds },
	{ "GetStreamingLevel", GetStreamingLevel },
	{ "GetRealTimeSeconds", GetRealTimeSeconds },
	{ "GetPlayerPawn", GetPlayerPawn },
	{ "GetPlayerControllerID", GetPlayerControllerID },
	{ "GetPlayerController", GetPlayerController },
	{ "GetPlayerCharacter", GetPlayerCharacter },
	{ "GetPlayerCameraManager", GetPlayerCameraManager },
	{ "GetPlatformName", GetPlatformName },
	{ "GetObjectClass", GetObjectClass },
	{ "GetKeyValue", GetKeyValue },
	{ "GetIntOption", GetIntOption },
	{ "GetGlobalTimeDilation", GetGlobalTimeDilation },
	{ "GetGameState", GetGameState },
	{ "GetGameMode", GetGameMode },
	{ "GetGameInstance", GetGameInstance },
	{ "GetEnableWorldRendering", GetEnableWorldRendering },
	{ "GetCurrentReverbEffect", GetCurrentReverbEffect },
	{ "GetCurrentLevelName", GetCurrentLevelName },
	{ "GetAudioTimeSeconds", GetAudioTimeSeconds },
	{ "GetAllActorsWithTag", GetAllActorsWithTag },
	{ "GetAllActorsWithInterface", GetAllActorsWithInterface },
	{ "GetAllActorsOfClass", GetAllActorsOfClass },
	{ "GetActorArrayBounds", GetActorArrayBounds },
	{ "GetActorArrayAverageLocation", GetActorArrayAverageLocation },
	{ "GetAccurateRealTime", GetAccurateRealTime },
	{ "FlushLevelStreaming", FlushLevelStreaming },
	{ "EnableLiveStreaming", EnableLiveStreaming },
	{ "DoesSaveGameExist", DoesSaveGameExist },
	{ "DeprojectScreenToWorld", DeprojectScreenToWorld },
	{ "DeleteGameInSlot", DeleteGameInSlot },
	{ "DeactivateReverbEffect", DeactivateReverbEffect },
	{ "CreateSound2D", CreateSound2D },
	{ "CreateSaveGameObject", CreateSaveGameObject },
	{ "CreatePlayer", CreatePlayer },
	{ "ClearSoundMixModifiers", ClearSoundMixModifiers },
	{ "ClearSoundMixClassOverride", ClearSoundMixClassOverride },
	{ "CancelAsyncLoading", CancelAsyncLoading },
	{ "BlueprintSuggestProjectileVelocity", BlueprintSuggestProjectileVelocity },
	{ "AreSubtitlesEnabled", AreSubtitlesEnabled },
	{ "AreAnyListenersWithinRange", AreAnyListenersWithinRange },
	{ "ApplyRadialDamageWithFalloff", ApplyRadialDamageWithFalloff },
	{ "ApplyRadialDamage", ApplyRadialDamage },
	{ "ApplyDamage", ApplyDamage },
	{ "ActivateReverbEffect", ActivateReverbEffect },
	{ "ProjectWorldToScreenExpand", ProjectWorldToScreenExpand },
	{ "is_nil", wLua::LuaStatic::isnil },
	{ "__gc", wLua::LuaStatic::removeUClassFrameCache },
	{ NULL, NULL }
};

void Register(lua_State *InScriptContext)
{
	lua_newtable(InScriptContext);
	luaL_register(InScriptContext, NULL, Lib_Funcs);
	AzureHelpFuncs::AuxRegister(InScriptContext, "GameplayStatics");
}
void SetMtLink(lua_State *InScriptContext)
{
	AzureHelpFuncs::AuxSetMtLink(InScriptContext, "GameplayStatics", "Object",USERDATATYPE_UOBJECT);
}

}