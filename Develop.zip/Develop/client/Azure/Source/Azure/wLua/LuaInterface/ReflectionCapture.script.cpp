#include "Azure.h"
#include "Utility/help_funcs.h"
#include "wLua/UObjectHeaders.h"
#include "Engine/ReflectionCapture.h"
#include "AzureLuaIntegration.h"

namespace LuaReflectionCapture
{
int32 DestroyEncodedHDRCubemapTexture(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ReflectionCapture",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ReflectionCapture must be non-null"); lua_error(InScriptContext);  return 0;}
#if UE_GAME
	AReflectionCapture * This = (AReflectionCapture *)Obj;
	This->DestroyEncodedHDRCubemapTexture();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("DestroyEncodedHDRCubemapTexture"));
	if(!Function) { check(false); return 0;}
	Obj->ProcessEvent(Function, NULL);
#endif
	return 0;
}

int32 Get_CaptureComponent(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ReflectionCapture",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ReflectionCapture must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AReflectionCapture::StaticClass(), TEXT("CaptureComponent"));
	if(!Property) { check(false); return 0;}
	UReflectionCaptureComponent* PropertyValue;
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaUtils::ReturnUObject(InScriptContext, PropertyValue);
	return 1;
}

int32 Class(lua_State* InScriptContext)
{
	UClass* Class = AReflectionCapture::StaticClass();
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Class);
	return 1;
}

const luaL_Reg Lib_Funcs[] =
{
	{ "Class", Class },
	{ "DestroyEncodedHDRCubemapTexture", DestroyEncodedHDRCubemapTexture },
	{ "Get_CaptureComponent", Get_CaptureComponent },
	{ "is_nil", wLua::LuaStatic::isnil },
	{ "__gc", wLua::LuaStatic::removeUClassFrameCache },
	{ NULL, NULL }
};

void Register(lua_State *InScriptContext)
{
	lua_newtable(InScriptContext);
	luaL_register(InScriptContext, NULL, Lib_Funcs);
	AzureHelpFuncs::AuxRegister(InScriptContext, "ReflectionCapture");
}
void SetMtLink(lua_State *InScriptContext)
{
	AzureHelpFuncs::AuxSetMtLink(InScriptContext, "ReflectionCapture", "Actor",USERDATATYPE_UOBJECT);
}

}