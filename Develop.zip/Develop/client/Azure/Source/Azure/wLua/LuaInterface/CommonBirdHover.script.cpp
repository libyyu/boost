#include "Azure.h"
#include "Utility/help_funcs.h"
#include "wLua/UObjectHeaders.h"
#include "GameLogic/BiologicalMine/CommonBirdHover.h"
#include "AzureLuaIntegration.h"

namespace LuaCommonBirdHover
{
int32 Start(lua_State*);

int32 Stop(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CommonBirdHover",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CommonBirdHover must be non-null"); lua_error(InScriptContext);  return 0;}
#if UE_GAME
	UCommonBirdHover * This = (UCommonBirdHover *)Obj;
	This->Stop();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("Stop"));
	if(!Function) { check(false); return 0;}
	Obj->ProcessEvent(Function, NULL);
#endif
	return 0;
}

int32 GetCurveCount(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CommonBirdHover",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CommonBirdHover must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		int32 ReturnValue;
	} Params;
#if UE_GAME
	UCommonBirdHover * This = (UCommonBirdHover *)Obj;
	Params.ReturnValue = This->GetCurveCount();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetCurveCount"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(int32*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushinteger(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 Get_splineComponentList(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CommonBirdHover",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CommonBirdHover must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UCommonBirdHover::StaticClass(), TEXT("splineComponentList"));
	if(!Property) { check(false); return 0;}
	TArray<USplineComponent*> PropertyValue;
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	{lua_newtable(InScriptContext); int i = 1; for(auto It = PropertyValue.CreateConstIterator(); It; ++It,++i) {  wLua::FLuaUtils::ReturnUObject(InScriptContext, (*It)); lua_rawseti(InScriptContext,-2,i);     }  }
	return 1;
}

int32 Set_splineComponentList(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CommonBirdHover",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CommonBirdHover must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UCommonBirdHover::StaticClass(), TEXT("splineComponentList"));
	if(!Property) { check(false); return 0;}
	TArray<USplineComponent*> PropertyValue = [](lua_State * _InScriptContext){ TArray<USplineComponent*> ret; lua_pushnil(_InScriptContext); while(lua_next(_InScriptContext,2)!=0){ USplineComponent* item = (USplineComponent*)wLua::FLuaUtils::GetUObject(_InScriptContext,-1,"SplineComponent");; ret.Add(item); lua_pop(_InScriptContext,1);  } return ret; }(InScriptContext);;
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 New(lua_State* InScriptContext)
{
	UObject* Outer = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Object");
	FName Name = FName(luaL_checkstring(InScriptContext, 2));
	UObject* Obj = NewObject<UCommonBirdHover>(Outer, Name);
	wLua::FLuaUtils::ReturnUObject(InScriptContext,Obj);
	return 1;
}

int32 Destroy(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CommonBirdHover",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CommonBirdHover must be non-null"); lua_error(InScriptContext);  return 0;}
		UActorComponent * com = Cast<UActorComponent>(Obj);
		if(lua_isnoneornil(InScriptContext,2))
			com->DestroyComponent();
		else
			com->DestroyComponent(!!lua_toboolean(InScriptContext,2));
		userdata->flag |= wLua::LuaObjectFlag::DESTROYED;
		wLua::FLuaUtils::RemoveObjectReference(Obj, userdata->stamp, InScriptContext);
#ifdef AZURE_BUILD_WLUACHECK
		UE_LOG(LogAzure, Warning, TEXT("Destroy CommonBirdHover: %x userdata:%x   stamp:%x"),Obj,userdata,userdata->stamp);
#endif
	return 0;
}

int32 Class(lua_State* InScriptContext)
{
	UClass* Class = UCommonBirdHover::StaticClass();
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Class);
	return 1;
}

const luaL_Reg Lib_Funcs[] =
{
	{ "New", New },
	{ "Destroy", Destroy },
	{ "Class", Class },
	{ "Stop", Stop },
	{ "GetCurveCount", GetCurveCount },
	{ "Get_splineComponentList", Get_splineComponentList },
	{ "Set_splineComponentList", Set_splineComponentList },
	{ "Start", Start },
	{ "is_nil", wLua::LuaStatic::isnil },
	{ "__gc", wLua::LuaStatic::removeUClassFrameCache },
	{ NULL, NULL }
};

void Register(lua_State *InScriptContext)
{
	lua_newtable(InScriptContext);
	luaL_register(InScriptContext, NULL, Lib_Funcs);
	AzureHelpFuncs::AuxRegister(InScriptContext, "CommonBirdHover");
}
void SetMtLink(lua_State *InScriptContext)
{
	AzureHelpFuncs::AuxSetMtLink(InScriptContext, "CommonBirdHover", "ActorComponent",USERDATATYPE_UOBJECT);
}

}