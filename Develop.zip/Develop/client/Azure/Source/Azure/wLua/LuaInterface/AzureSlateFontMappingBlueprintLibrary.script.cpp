#include "Azure.h"
#include "Utility/help_funcs.h"
#include "wLua/UObjectHeaders.h"
#include "AzureSlateFontMappingBlueprintLibrary.h"
#include "AzureLuaIntegration.h"

namespace LuaAzureSlateFontMappingBlueprintLibrary
{
int32 SlateFontMappingReloadLayoutsInPresetFolder(lua_State* InScriptContext)
{
	UClass * Obj = UAzureSlateFontMappingBlueprintLibrary::StaticClass(); 
#if UE_GAME
	UAzureSlateFontMappingBlueprintLibrary::SlateFontMappingReloadLayoutsInPresetFolder();
#else
	UFunction* Function = Obj->FindFunctionByName(TEXT("SlateFontMappingReloadLayoutsInPresetFolder"));
	if(!Function) { check(false); return 0;}
	Obj->ProcessEvent(Function, NULL);
#endif
	return 0;
}

int32 SlateFontMappingLoadPackage(lua_State* InScriptContext)
{
	UClass * Obj = UAzureSlateFontMappingBlueprintLibrary::StaticClass(); 
	struct FDispatchParams
	{
		FString PackagePath;
		UPackage* Outer = nullptr;
		UClass* ReturnValue = nullptr;
	} Params;
	Params.PackagePath = UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 1));
	Params.Outer = (UPackage*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"Package");;
#if UE_GAME
	Params.ReturnValue = UAzureSlateFontMappingBlueprintLibrary::SlateFontMappingLoadPackage(Params.PackagePath,Params.Outer);
#else
	UFunction* Function = Obj->FindFunctionByName(TEXT("SlateFontMappingLoadPackage"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FString*)(params.GetStructMemory() + 0) = Params.PackagePath;
		*(UPackage**)(params.GetStructMemory() + 16) = Params.Outer;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.PackagePath = *(FString*)(params.GetStructMemory() + 0);
		Params.Outer = *(UPackage**)(params.GetStructMemory() + 16);
		Params.ReturnValue = *(UClass**)(params.GetStructMemory() + 24);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 SlateFontMappingLoadLayoutFromXmlString(lua_State* InScriptContext)
{
	UClass * Obj = UAzureSlateFontMappingBlueprintLibrary::StaticClass(); 
	struct FDispatchParams
	{
		FString ConfigName;
		FString XmlString;
	} Params;
	Params.ConfigName = UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 1));
	Params.XmlString = UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 2));
#if UE_GAME
	UAzureSlateFontMappingBlueprintLibrary::SlateFontMappingLoadLayoutFromXmlString(Params.ConfigName,Params.XmlString);
#else
	UFunction* Function = Obj->FindFunctionByName(TEXT("SlateFontMappingLoadLayoutFromXmlString"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FString*)(params.GetStructMemory() + 0) = Params.ConfigName;
		*(FString*)(params.GetStructMemory() + 16) = Params.XmlString;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ConfigName = *(FString*)(params.GetStructMemory() + 0);
		Params.XmlString = *(FString*)(params.GetStructMemory() + 16);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SlateFontMappingLoadLayoutFromXmlFilePath(lua_State* InScriptContext)
{
	UClass * Obj = UAzureSlateFontMappingBlueprintLibrary::StaticClass(); 
	struct FDispatchParams
	{
		FString ConfigName;
		FString XmlFilePath;
	} Params;
	Params.ConfigName = UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 1));
	Params.XmlFilePath = UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 2));
#if UE_GAME
	UAzureSlateFontMappingBlueprintLibrary::SlateFontMappingLoadLayoutFromXmlFilePath(Params.ConfigName,Params.XmlFilePath);
#else
	UFunction* Function = Obj->FindFunctionByName(TEXT("SlateFontMappingLoadLayoutFromXmlFilePath"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FString*)(params.GetStructMemory() + 0) = Params.ConfigName;
		*(FString*)(params.GetStructMemory() + 16) = Params.XmlFilePath;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ConfigName = *(FString*)(params.GetStructMemory() + 0);
		Params.XmlFilePath = *(FString*)(params.GetStructMemory() + 16);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SlateFontMappingGetAllLayouts(lua_State* InScriptContext)
{
	UClass * Obj = UAzureSlateFontMappingBlueprintLibrary::StaticClass(); 
	struct FDispatchParams
	{
		TArray<FString> ReturnValue;
	} Params;
#if UE_GAME
	Params.ReturnValue = UAzureSlateFontMappingBlueprintLibrary::SlateFontMappingGetAllLayouts();
#else
	UFunction* Function = Obj->FindFunctionByName(TEXT("SlateFontMappingGetAllLayouts"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(TArray<FString>*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	{lua_newtable(InScriptContext); int i = 1; for(auto It = Params.ReturnValue.CreateConstIterator(); It; ++It,++i) {  lua_pushstring(InScriptContext, TCHAR_TO_UTF8(*(*It))); lua_rawseti(InScriptContext,-2,i);     }  }
	return 1;
}

int32 SlateFontMappingEnableLayout(lua_State* InScriptContext)
{
	UClass * Obj = UAzureSlateFontMappingBlueprintLibrary::StaticClass(); 
	struct FDispatchParams
	{
		FString InLayoutMode;
	} Params;
	Params.InLayoutMode = UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 1));
#if UE_GAME
	UAzureSlateFontMappingBlueprintLibrary::SlateFontMappingEnableLayout(Params.InLayoutMode);
#else
	UFunction* Function = Obj->FindFunctionByName(TEXT("SlateFontMappingEnableLayout"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FString*)(params.GetStructMemory() + 0) = Params.InLayoutMode;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.InLayoutMode = *(FString*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SlateFontMappingDisableLayout(lua_State* InScriptContext)
{
	UClass * Obj = UAzureSlateFontMappingBlueprintLibrary::StaticClass(); 
#if UE_GAME
	UAzureSlateFontMappingBlueprintLibrary::SlateFontMappingDisableLayout();
#else
	UFunction* Function = Obj->FindFunctionByName(TEXT("SlateFontMappingDisableLayout"));
	if(!Function) { check(false); return 0;}
	Obj->ProcessEvent(Function, NULL);
#endif
	return 0;
}

int32 New(lua_State* InScriptContext)
{
	UObject* Outer = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Object");
	FName Name = FName(luaL_checkstring(InScriptContext, 2));
	UObject* Obj = NewObject<UAzureSlateFontMappingBlueprintLibrary>(Outer, Name);
	wLua::FLuaUtils::ReturnUObject(InScriptContext,Obj);
	return 1;
}

int32 Destroy(lua_State* InScriptContext)
{
	return 0;
}

int32 Class(lua_State* InScriptContext)
{
	UClass* Class = UAzureSlateFontMappingBlueprintLibrary::StaticClass();
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Class);
	return 1;
}

const luaL_Reg Lib_Funcs[] =
{
	{ "New", New },
	{ "Destroy", Destroy },
	{ "Class", Class },
	{ "SlateFontMappingReloadLayoutsInPresetFolder", SlateFontMappingReloadLayoutsInPresetFolder },
	{ "SlateFontMappingLoadPackage", SlateFontMappingLoadPackage },
	{ "SlateFontMappingLoadLayoutFromXmlString", SlateFontMappingLoadLayoutFromXmlString },
	{ "SlateFontMappingLoadLayoutFromXmlFilePath", SlateFontMappingLoadLayoutFromXmlFilePath },
	{ "SlateFontMappingGetAllLayouts", SlateFontMappingGetAllLayouts },
	{ "SlateFontMappingEnableLayout", SlateFontMappingEnableLayout },
	{ "SlateFontMappingDisableLayout", SlateFontMappingDisableLayout },
	{ "is_nil", wLua::LuaStatic::isnil },
	{ "__gc", wLua::LuaStatic::removeUClassFrameCache },
	{ NULL, NULL }
};

void Register(lua_State *InScriptContext)
{
	lua_newtable(InScriptContext);
	luaL_register(InScriptContext, NULL, Lib_Funcs);
	AzureHelpFuncs::AuxRegister(InScriptContext, "AzureSlateFontMappingBlueprintLibrary");
}
void SetMtLink(lua_State *InScriptContext)
{
	AzureHelpFuncs::AuxSetMtLink(InScriptContext, "AzureSlateFontMappingBlueprintLibrary", "Object",USERDATATYPE_UOBJECT);
}

}