#include "Azure.h"
#include "Utility/help_funcs.h"
#include "wLua/UObjectHeaders.h"
#include "Camera/CameraShake.h"
#include "AzureLuaIntegration.h"

namespace LuaCameraShake
{
int32 ReceiveStopShake(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CameraShake",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CameraShake must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool bImmediately;
	} Params;
	Params.bImmediately = !!(lua_toboolean(InScriptContext, 2));
#if UE_GAME
	UCameraShake * This = (UCameraShake *)Obj;
	This->ReceiveStopShake(Params.bImmediately);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("ReceiveStopShake"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(bool*)(params.GetStructMemory() + 0) = Params.bImmediately;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.bImmediately = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 ReceivePlayShake(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CameraShake",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CameraShake must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float Scale;
	} Params;
	Params.Scale = (float)(luaL_checknumber(InScriptContext, 2));
#if UE_GAME
	UCameraShake * This = (UCameraShake *)Obj;
	This->ReceivePlayShake(Params.Scale);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("ReceivePlayShake"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(float*)(params.GetStructMemory() + 0) = Params.Scale;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.Scale = *(float*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 ReceiveIsFinished(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CameraShake",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CameraShake must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool ReturnValue;
	} Params;
#if UE_GAME
	UCameraShake * This = (UCameraShake *)Obj;
	Params.ReturnValue = This->ReceiveIsFinished();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("ReceiveIsFinished"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushboolean(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 Get_bSingleInstance(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CameraShake",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CameraShake must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UCameraShake::StaticClass(), TEXT("bSingleInstance"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bSingleInstance(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CameraShake",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CameraShake must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UCameraShake::StaticClass(), TEXT("bSingleInstance"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_OscillationDuration(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CameraShake",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CameraShake must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UCameraShake::StaticClass(), TEXT("OscillationDuration"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_OscillationDuration(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CameraShake",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CameraShake must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UCameraShake::StaticClass(), TEXT("OscillationDuration"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_OscillationBlendInTime(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CameraShake",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CameraShake must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UCameraShake::StaticClass(), TEXT("OscillationBlendInTime"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_OscillationBlendInTime(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CameraShake",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CameraShake must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UCameraShake::StaticClass(), TEXT("OscillationBlendInTime"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_OscillationBlendOutTime(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CameraShake",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CameraShake must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UCameraShake::StaticClass(), TEXT("OscillationBlendOutTime"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_OscillationBlendOutTime(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CameraShake",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CameraShake must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UCameraShake::StaticClass(), TEXT("OscillationBlendOutTime"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_AnimPlayRate(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CameraShake",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CameraShake must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UCameraShake::StaticClass(), TEXT("AnimPlayRate"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_AnimPlayRate(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CameraShake",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CameraShake must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UCameraShake::StaticClass(), TEXT("AnimPlayRate"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_AnimScale(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CameraShake",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CameraShake must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UCameraShake::StaticClass(), TEXT("AnimScale"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_AnimScale(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CameraShake",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CameraShake must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UCameraShake::StaticClass(), TEXT("AnimScale"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_AnimBlendInTime(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CameraShake",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CameraShake must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UCameraShake::StaticClass(), TEXT("AnimBlendInTime"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_AnimBlendInTime(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CameraShake",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CameraShake must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UCameraShake::StaticClass(), TEXT("AnimBlendInTime"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_AnimBlendOutTime(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CameraShake",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CameraShake must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UCameraShake::StaticClass(), TEXT("AnimBlendOutTime"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_AnimBlendOutTime(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CameraShake",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CameraShake must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UCameraShake::StaticClass(), TEXT("AnimBlendOutTime"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_RandomAnimSegmentDuration(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CameraShake",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CameraShake must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UCameraShake::StaticClass(), TEXT("RandomAnimSegmentDuration"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_RandomAnimSegmentDuration(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CameraShake",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CameraShake must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UCameraShake::StaticClass(), TEXT("RandomAnimSegmentDuration"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_Anim(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CameraShake",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CameraShake must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UCameraShake::StaticClass(), TEXT("Anim"));
	if(!Property) { check(false); return 0;}
	UCameraAnim* PropertyValue;
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaUtils::ReturnUObject(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_Anim(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CameraShake",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CameraShake must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UCameraShake::StaticClass(), TEXT("Anim"));
	if(!Property) { check(false); return 0;}
	UCameraAnim* PropertyValue = (UCameraAnim*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"CameraAnim");;
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bRandomAnimSegment(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CameraShake",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CameraShake must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UCameraShake::StaticClass(), TEXT("bRandomAnimSegment"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bRandomAnimSegment(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CameraShake",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CameraShake must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UCameraShake::StaticClass(), TEXT("bRandomAnimSegment"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_CameraOwner(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CameraShake",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CameraShake must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UCameraShake::StaticClass(), TEXT("CameraOwner"));
	if(!Property) { check(false); return 0;}
	APlayerCameraManager* PropertyValue;
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaUtils::ReturnUObject(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_ShakeScale(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CameraShake",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CameraShake must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UCameraShake::StaticClass(), TEXT("ShakeScale"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_ShakeScale(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CameraShake",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CameraShake must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UCameraShake::StaticClass(), TEXT("ShakeScale"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_OscillatorTimeRemaining(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CameraShake",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CameraShake must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UCameraShake::StaticClass(), TEXT("OscillatorTimeRemaining"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_AnimInst(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CameraShake",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CameraShake must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UCameraShake::StaticClass(), TEXT("AnimInst"));
	if(!Property) { check(false); return 0;}
	UCameraAnimInst* PropertyValue;
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaUtils::ReturnUObject(InScriptContext, PropertyValue);
	return 1;
}

int32 New(lua_State* InScriptContext)
{
	UObject* Outer = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Object");
	FName Name = FName(luaL_checkstring(InScriptContext, 2));
	UObject* Obj = NewObject<UCameraShake>(Outer, Name);
	wLua::FLuaUtils::ReturnUObject(InScriptContext,Obj);
	return 1;
}

int32 Destroy(lua_State* InScriptContext)
{
	return 0;
}

int32 Class(lua_State* InScriptContext)
{
	UClass* Class = UCameraShake::StaticClass();
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Class);
	return 1;
}

const luaL_Reg Lib_Funcs[] =
{
	{ "New", New },
	{ "Destroy", Destroy },
	{ "Class", Class },
	{ "ReceiveStopShake", ReceiveStopShake },
	{ "ReceivePlayShake", ReceivePlayShake },
	{ "ReceiveIsFinished", ReceiveIsFinished },
	{ "Get_bSingleInstance", Get_bSingleInstance },
	{ "Set_bSingleInstance", Set_bSingleInstance },
	{ "Get_OscillationDuration", Get_OscillationDuration },
	{ "Set_OscillationDuration", Set_OscillationDuration },
	{ "Get_OscillationBlendInTime", Get_OscillationBlendInTime },
	{ "Set_OscillationBlendInTime", Set_OscillationBlendInTime },
	{ "Get_OscillationBlendOutTime", Get_OscillationBlendOutTime },
	{ "Set_OscillationBlendOutTime", Set_OscillationBlendOutTime },
	{ "Get_AnimPlayRate", Get_AnimPlayRate },
	{ "Set_AnimPlayRate", Set_AnimPlayRate },
	{ "Get_AnimScale", Get_AnimScale },
	{ "Set_AnimScale", Set_AnimScale },
	{ "Get_AnimBlendInTime", Get_AnimBlendInTime },
	{ "Set_AnimBlendInTime", Set_AnimBlendInTime },
	{ "Get_AnimBlendOutTime", Get_AnimBlendOutTime },
	{ "Set_AnimBlendOutTime", Set_AnimBlendOutTime },
	{ "Get_RandomAnimSegmentDuration", Get_RandomAnimSegmentDuration },
	{ "Set_RandomAnimSegmentDuration", Set_RandomAnimSegmentDuration },
	{ "Get_Anim", Get_Anim },
	{ "Set_Anim", Set_Anim },
	{ "Get_bRandomAnimSegment", Get_bRandomAnimSegment },
	{ "Set_bRandomAnimSegment", Set_bRandomAnimSegment },
	{ "Get_CameraOwner", Get_CameraOwner },
	{ "Get_ShakeScale", Get_ShakeScale },
	{ "Set_ShakeScale", Set_ShakeScale },
	{ "Get_OscillatorTimeRemaining", Get_OscillatorTimeRemaining },
	{ "Get_AnimInst", Get_AnimInst },
	{ "is_nil", wLua::LuaStatic::isnil },
	{ "__gc", wLua::LuaStatic::removeUClassFrameCache },
	{ NULL, NULL }
};

void Register(lua_State *InScriptContext)
{
	lua_newtable(InScriptContext);
	luaL_register(InScriptContext, NULL, Lib_Funcs);
	AzureHelpFuncs::AuxRegister(InScriptContext, "CameraShake");
}
void SetMtLink(lua_State *InScriptContext)
{
	AzureHelpFuncs::AuxSetMtLink(InScriptContext, "CameraShake", "Object",USERDATATYPE_UOBJECT);
}

}