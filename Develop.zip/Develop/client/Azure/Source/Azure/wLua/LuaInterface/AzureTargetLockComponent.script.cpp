#include "Azure.h"
#include "Utility/help_funcs.h"
#include "wLua/UObjectHeaders.h"
#include "AzureTargetLockComponent.h"
#include "AzureLuaIntegration.h"

namespace LuaAzureTargetLockComponent
{
int32 SetParentComponent(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureTargetLockComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureTargetLockComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		USceneComponent* parentComponent = nullptr;
	} Params;
	Params.parentComponent = (USceneComponent*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"SceneComponent");;
#if UE_GAME
	UAzureTargetLockComponent * This = (UAzureTargetLockComponent *)Obj;
	This->SetParentComponent(Params.parentComponent);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetParentComponent"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(USceneComponent**)(params.GetStructMemory() + 0) = Params.parentComponent;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.parentComponent = *(USceneComponent**)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 RemoveLockWidget(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureTargetLockComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureTargetLockComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		UUserWidget* userWidget = nullptr;
	} Params;
	Params.userWidget = (UUserWidget*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"UserWidget");;
#if UE_GAME
	UAzureTargetLockComponent * This = (UAzureTargetLockComponent *)Obj;
	This->RemoveLockWidget(Params.userWidget);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("RemoveLockWidget"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(UUserWidget**)(params.GetStructMemory() + 0) = Params.userWidget;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.userWidget = *(UUserWidget**)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 AddLockWidget(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureTargetLockComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureTargetLockComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		UUserWidget* userWidget = nullptr;
	} Params;
	Params.userWidget = (UUserWidget*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"UserWidget");;
#if UE_GAME
	UAzureTargetLockComponent * This = (UAzureTargetLockComponent *)Obj;
	This->AddLockWidget(Params.userWidget);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("AddLockWidget"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(UUserWidget**)(params.GetStructMemory() + 0) = Params.userWidget;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.userWidget = *(UUserWidget**)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 Get_WorldOffset(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureTargetLockComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureTargetLockComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzureTargetLockComponent::StaticClass(), TEXT("WorldOffset"));
	if(!Property) { check(false); return 0;}
	FVector PropertyValue = FVector();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaVector::Return(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_WorldOffset(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureTargetLockComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureTargetLockComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzureTargetLockComponent::StaticClass(), TEXT("WorldOffset"));
	if(!Property) { check(false); return 0;}
	FVector PropertyValue = (wLua::FLuaVector::Get(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_ScreenOffset(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureTargetLockComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureTargetLockComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzureTargetLockComponent::StaticClass(), TEXT("ScreenOffset"));
	if(!Property) { check(false); return 0;}
	FVector2D PropertyValue = FVector2D();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaVector2D::Return(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_ScreenOffset(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureTargetLockComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureTargetLockComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzureTargetLockComponent::StaticClass(), TEXT("ScreenOffset"));
	if(!Property) { check(false); return 0;}
	FVector2D PropertyValue = (wLua::FLuaVector2D::Get(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 New(lua_State* InScriptContext)
{
	UObject* Outer = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Object");
	FName Name = FName(luaL_checkstring(InScriptContext, 2));
	UObject* Obj = NewObject<UAzureTargetLockComponent>(Outer, Name);
	wLua::FLuaUtils::ReturnUObject(InScriptContext,Obj);
	return 1;
}

int32 Destroy(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureTargetLockComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureTargetLockComponent must be non-null"); lua_error(InScriptContext);  return 0;}
		UActorComponent * com = Cast<UActorComponent>(Obj);
		if(lua_isnoneornil(InScriptContext,2))
			com->DestroyComponent();
		else
			com->DestroyComponent(!!lua_toboolean(InScriptContext,2));
		userdata->flag |= wLua::LuaObjectFlag::DESTROYED;
		wLua::FLuaUtils::RemoveObjectReference(Obj, userdata->stamp, InScriptContext);
#ifdef AZURE_BUILD_WLUACHECK
		UE_LOG(LogAzure, Warning, TEXT("Destroy AzureTargetLockComponent: %x userdata:%x   stamp:%x"),Obj,userdata,userdata->stamp);
#endif
	return 0;
}

int32 Class(lua_State* InScriptContext)
{
	UClass* Class = UAzureTargetLockComponent::StaticClass();
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Class);
	return 1;
}

const luaL_Reg Lib_Funcs[] =
{
	{ "New", New },
	{ "Destroy", Destroy },
	{ "Class", Class },
	{ "SetParentComponent", SetParentComponent },
	{ "RemoveLockWidget", RemoveLockWidget },
	{ "AddLockWidget", AddLockWidget },
	{ "Get_WorldOffset", Get_WorldOffset },
	{ "Set_WorldOffset", Set_WorldOffset },
	{ "Get_ScreenOffset", Get_ScreenOffset },
	{ "Set_ScreenOffset", Set_ScreenOffset },
	{ "is_nil", wLua::LuaStatic::isnil },
	{ "__gc", wLua::LuaStatic::removeUClassFrameCache },
	{ NULL, NULL }
};

void Register(lua_State *InScriptContext)
{
	lua_newtable(InScriptContext);
	luaL_register(InScriptContext, NULL, Lib_Funcs);
	AzureHelpFuncs::AuxRegister(InScriptContext, "AzureTargetLockComponent");
}
void SetMtLink(lua_State *InScriptContext)
{
	AzureHelpFuncs::AuxSetMtLink(InScriptContext, "AzureTargetLockComponent", "ActorComponent",USERDATATYPE_UOBJECT);
}

}