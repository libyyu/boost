#include "Azure.h"
#include "Utility/help_funcs.h"
#include "wLua/UObjectHeaders.h"
#include "Camera/PlayerCameraManager.h"
#include "AzureLuaIntegration.h"

namespace LuaPlayerCameraManager
{
int32 StopCameraShake(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PlayerCameraManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PlayerCameraManager must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		UCameraShake* ShakeInstance = nullptr;
		bool bImmediately;
	} Params;
	Params.ShakeInstance = (UCameraShake*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"CameraShake");;
	Params.bImmediately = lua_isnoneornil(InScriptContext,3) ? bool(true) : !!(lua_toboolean(InScriptContext, 3));
#if UE_GAME
	APlayerCameraManager * This = (APlayerCameraManager *)Obj;
	This->StopCameraShake(Params.ShakeInstance,Params.bImmediately);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("StopCameraShake"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(UCameraShake**)(params.GetStructMemory() + 0) = Params.ShakeInstance;
		*(bool*)(params.GetStructMemory() + 8) = Params.bImmediately;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ShakeInstance = *(UCameraShake**)(params.GetStructMemory() + 0);
		Params.bImmediately = *(bool*)(params.GetStructMemory() + 8);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 StopCameraFade(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PlayerCameraManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PlayerCameraManager must be non-null"); lua_error(InScriptContext);  return 0;}
#if UE_GAME
	APlayerCameraManager * This = (APlayerCameraManager *)Obj;
	This->StopCameraFade();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("StopCameraFade"));
	if(!Function) { check(false); return 0;}
	Obj->ProcessEvent(Function, NULL);
#endif
	return 0;
}

int32 StopCameraAnimInst(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PlayerCameraManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PlayerCameraManager must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		UCameraAnimInst* AnimInst = nullptr;
		bool bImmediate;
	} Params;
	Params.AnimInst = (UCameraAnimInst*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"CameraAnimInst");;
	Params.bImmediate = lua_isnoneornil(InScriptContext,3) ? bool(false) : !!(lua_toboolean(InScriptContext, 3));
#if UE_GAME
	APlayerCameraManager * This = (APlayerCameraManager *)Obj;
	This->StopCameraAnimInst(Params.AnimInst,Params.bImmediate);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("StopCameraAnimInst"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(UCameraAnimInst**)(params.GetStructMemory() + 0) = Params.AnimInst;
		*(bool*)(params.GetStructMemory() + 8) = Params.bImmediate;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.AnimInst = *(UCameraAnimInst**)(params.GetStructMemory() + 0);
		Params.bImmediate = *(bool*)(params.GetStructMemory() + 8);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 StopAllInstancesOfCameraShake(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PlayerCameraManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PlayerCameraManager must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		TSubclassOf<UCameraShake>  Shake;
		bool bImmediately;
	} Params;
	Params.Shake = (UClass*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"Class");;
	Params.bImmediately = lua_isnoneornil(InScriptContext,3) ? bool(true) : !!(lua_toboolean(InScriptContext, 3));
#if UE_GAME
	APlayerCameraManager * This = (APlayerCameraManager *)Obj;
	This->StopAllInstancesOfCameraShake(Params.Shake,Params.bImmediately);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("StopAllInstancesOfCameraShake"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(TSubclassOf<UCameraShake> *)(params.GetStructMemory() + 0) = Params.Shake;
		*(bool*)(params.GetStructMemory() + 8) = Params.bImmediately;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.Shake = *(TSubclassOf<UCameraShake> *)(params.GetStructMemory() + 0);
		Params.bImmediately = *(bool*)(params.GetStructMemory() + 8);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 StopAllInstancesOfCameraAnim(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PlayerCameraManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PlayerCameraManager must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		UCameraAnim* Anim = nullptr;
		bool bImmediate;
	} Params;
	Params.Anim = (UCameraAnim*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"CameraAnim");;
	Params.bImmediate = lua_isnoneornil(InScriptContext,3) ? bool(false) : !!(lua_toboolean(InScriptContext, 3));
#if UE_GAME
	APlayerCameraManager * This = (APlayerCameraManager *)Obj;
	This->StopAllInstancesOfCameraAnim(Params.Anim,Params.bImmediate);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("StopAllInstancesOfCameraAnim"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(UCameraAnim**)(params.GetStructMemory() + 0) = Params.Anim;
		*(bool*)(params.GetStructMemory() + 8) = Params.bImmediate;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.Anim = *(UCameraAnim**)(params.GetStructMemory() + 0);
		Params.bImmediate = *(bool*)(params.GetStructMemory() + 8);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 StopAllCameraShakes(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PlayerCameraManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PlayerCameraManager must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool bImmediately;
	} Params;
	Params.bImmediately = lua_isnoneornil(InScriptContext,2) ? bool(true) : !!(lua_toboolean(InScriptContext, 2));
#if UE_GAME
	APlayerCameraManager * This = (APlayerCameraManager *)Obj;
	This->StopAllCameraShakes(Params.bImmediately);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("StopAllCameraShakes"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(bool*)(params.GetStructMemory() + 0) = Params.bImmediately;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.bImmediately = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 StopAllCameraAnims(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PlayerCameraManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PlayerCameraManager must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool bImmediate;
	} Params;
	Params.bImmediate = lua_isnoneornil(InScriptContext,2) ? bool(false) : !!(lua_toboolean(InScriptContext, 2));
#if UE_GAME
	APlayerCameraManager * This = (APlayerCameraManager *)Obj;
	This->StopAllCameraAnims(Params.bImmediate);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("StopAllCameraAnims"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(bool*)(params.GetStructMemory() + 0) = Params.bImmediate;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.bImmediate = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 StartCameraFade(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PlayerCameraManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PlayerCameraManager must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float FromAlpha;
		float ToAlpha;
		float Duration;
		FLinearColor Color;
		bool bShouldFadeAudio;
		bool bHoldWhenFinished;
	} Params;
	Params.FromAlpha = (float)(luaL_checknumber(InScriptContext, 2));
	Params.ToAlpha = (float)(luaL_checknumber(InScriptContext, 3));
	Params.Duration = (float)(luaL_checknumber(InScriptContext, 4));
	Params.Color = (wLua::FLuaLinearColor::Get(InScriptContext, 5));
	Params.bShouldFadeAudio = lua_isnoneornil(InScriptContext,6) ? bool(false) : !!(lua_toboolean(InScriptContext, 6));
	Params.bHoldWhenFinished = lua_isnoneornil(InScriptContext,7) ? bool(false) : !!(lua_toboolean(InScriptContext, 7));
#if UE_GAME
	APlayerCameraManager * This = (APlayerCameraManager *)Obj;
	This->StartCameraFade(Params.FromAlpha,Params.ToAlpha,Params.Duration,Params.Color,Params.bShouldFadeAudio,Params.bHoldWhenFinished);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("StartCameraFade"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(float*)(params.GetStructMemory() + 0) = Params.FromAlpha;
		*(float*)(params.GetStructMemory() + 4) = Params.ToAlpha;
		*(float*)(params.GetStructMemory() + 8) = Params.Duration;
		*(FLinearColor*)(params.GetStructMemory() + 12) = Params.Color;
		*(bool*)(params.GetStructMemory() + 28) = Params.bShouldFadeAudio;
		*(bool*)(params.GetStructMemory() + 29) = Params.bHoldWhenFinished;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.FromAlpha = *(float*)(params.GetStructMemory() + 0);
		Params.ToAlpha = *(float*)(params.GetStructMemory() + 4);
		Params.Duration = *(float*)(params.GetStructMemory() + 8);
		Params.Color = *(FLinearColor*)(params.GetStructMemory() + 12);
		Params.bShouldFadeAudio = *(bool*)(params.GetStructMemory() + 28);
		Params.bHoldWhenFinished = *(bool*)(params.GetStructMemory() + 29);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetManualCameraFade(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PlayerCameraManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PlayerCameraManager must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float InFadeAmount;
		FLinearColor Color;
		bool bInFadeAudio;
	} Params;
	Params.InFadeAmount = (float)(luaL_checknumber(InScriptContext, 2));
	Params.Color = (wLua::FLuaLinearColor::Get(InScriptContext, 3));
	Params.bInFadeAudio = !!(lua_toboolean(InScriptContext, 4));
#if UE_GAME
	APlayerCameraManager * This = (APlayerCameraManager *)Obj;
	This->SetManualCameraFade(Params.InFadeAmount,Params.Color,Params.bInFadeAudio);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetManualCameraFade"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(float*)(params.GetStructMemory() + 0) = Params.InFadeAmount;
		*(FLinearColor*)(params.GetStructMemory() + 4) = Params.Color;
		*(bool*)(params.GetStructMemory() + 20) = Params.bInFadeAudio;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.InFadeAmount = *(float*)(params.GetStructMemory() + 0);
		Params.Color = *(FLinearColor*)(params.GetStructMemory() + 4);
		Params.bInFadeAudio = *(bool*)(params.GetStructMemory() + 20);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 RemoveCameraModifier(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PlayerCameraManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PlayerCameraManager must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		UCameraModifier* ModifierToRemove = nullptr;
		bool ReturnValue;
	} Params;
	Params.ModifierToRemove = (UCameraModifier*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"CameraModifier");;
#if UE_GAME
	APlayerCameraManager * This = (APlayerCameraManager *)Obj;
	Params.ReturnValue = This->RemoveCameraModifier(Params.ModifierToRemove);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("RemoveCameraModifier"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(UCameraModifier**)(params.GetStructMemory() + 0) = Params.ModifierToRemove;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ModifierToRemove = *(UCameraModifier**)(params.GetStructMemory() + 0);
		Params.ReturnValue = *(bool*)(params.GetStructMemory() + 8);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushboolean(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 RemoveCameraLensEffect(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PlayerCameraManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PlayerCameraManager must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		AEmitterCameraLensEffectBase* Emitter = nullptr;
	} Params;
	Params.Emitter = (AEmitterCameraLensEffectBase*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"EmitterCameraLensEffectBase");;
#if UE_GAME
	APlayerCameraManager * This = (APlayerCameraManager *)Obj;
	This->RemoveCameraLensEffect(Params.Emitter);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("RemoveCameraLensEffect"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(AEmitterCameraLensEffectBase**)(params.GetStructMemory() + 0) = Params.Emitter;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.Emitter = *(AEmitterCameraLensEffectBase**)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 PlayCameraShake(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PlayerCameraManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PlayerCameraManager must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		TSubclassOf<UCameraShake>  ShakeClass;
		float Scale;
		TEnumAsByte<ECameraAnimPlaySpace::Type> PlaySpace;
		FRotator UserPlaySpaceRot;
		UCameraShake* ReturnValue = nullptr;
	} Params;
	Params.ShakeClass = (UClass*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"Class");;
	Params.Scale = lua_isnoneornil(InScriptContext,3) ? float(1.000000) : (float)(luaL_checknumber(InScriptContext, 3));
	Params.PlaySpace = lua_isnoneornil(InScriptContext,4) ? TEnumAsByte<ECameraAnimPlaySpace::Type>(ECameraAnimPlaySpace::Type::CameraLocal) : (TEnumAsByte<ECameraAnimPlaySpace::Type>)(luaL_checkint(InScriptContext, 4));
	Params.UserPlaySpaceRot = lua_isnoneornil(InScriptContext,5) ? FRotator(0.f) : (wLua::FLuaRotator::Get(InScriptContext, 5));
#if UE_GAME
	APlayerCameraManager * This = (APlayerCameraManager *)Obj;
	Params.ReturnValue = This->PlayCameraShake(Params.ShakeClass,Params.Scale,Params.PlaySpace,Params.UserPlaySpaceRot);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("PlayCameraShake"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(TSubclassOf<UCameraShake> *)(params.GetStructMemory() + 0) = Params.ShakeClass;
		*(float*)(params.GetStructMemory() + 8) = Params.Scale;
		*(TEnumAsByte<ECameraAnimPlaySpace::Type>*)(params.GetStructMemory() + 12) = Params.PlaySpace;
		*(FRotator*)(params.GetStructMemory() + 16) = Params.UserPlaySpaceRot;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ShakeClass = *(TSubclassOf<UCameraShake> *)(params.GetStructMemory() + 0);
		Params.Scale = *(float*)(params.GetStructMemory() + 8);
		Params.PlaySpace = *(TEnumAsByte<ECameraAnimPlaySpace::Type>*)(params.GetStructMemory() + 12);
		Params.UserPlaySpaceRot = *(FRotator*)(params.GetStructMemory() + 16);
		Params.ReturnValue = *(UCameraShake**)(params.GetStructMemory() + 32);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 PlayCameraAnim(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PlayerCameraManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PlayerCameraManager must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		UCameraAnim* Anim = nullptr;
		float Rate;
		float Scale;
		float BlendInTime;
		float BlendOutTime;
		bool bLoop;
		bool bRandomStartTime;
		float Duration;
		TEnumAsByte<ECameraAnimPlaySpace::Type> PlaySpace;
		FRotator UserPlaySpaceRot;
		UCameraAnimInst* ReturnValue = nullptr;
	} Params;
	Params.Anim = (UCameraAnim*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"CameraAnim");;
	Params.Rate = lua_isnoneornil(InScriptContext,3) ? float(1.000000) : (float)(luaL_checknumber(InScriptContext, 3));
	Params.Scale = lua_isnoneornil(InScriptContext,4) ? float(1.000000) : (float)(luaL_checknumber(InScriptContext, 4));
	Params.BlendInTime = lua_isnoneornil(InScriptContext,5) ? float(0.000000) : (float)(luaL_checknumber(InScriptContext, 5));
	Params.BlendOutTime = lua_isnoneornil(InScriptContext,6) ? float(0.000000) : (float)(luaL_checknumber(InScriptContext, 6));
	Params.bLoop = lua_isnoneornil(InScriptContext,7) ? bool(false) : !!(lua_toboolean(InScriptContext, 7));
	Params.bRandomStartTime = lua_isnoneornil(InScriptContext,8) ? bool(false) : !!(lua_toboolean(InScriptContext, 8));
	Params.Duration = lua_isnoneornil(InScriptContext,9) ? float(0.000000) : (float)(luaL_checknumber(InScriptContext, 9));
	Params.PlaySpace = lua_isnoneornil(InScriptContext,10) ? TEnumAsByte<ECameraAnimPlaySpace::Type>(ECameraAnimPlaySpace::Type::CameraLocal) : (TEnumAsByte<ECameraAnimPlaySpace::Type>)(luaL_checkint(InScriptContext, 10));
	Params.UserPlaySpaceRot = lua_isnoneornil(InScriptContext,11) ? FRotator(0.f) : (wLua::FLuaRotator::Get(InScriptContext, 11));
#if UE_GAME
	APlayerCameraManager * This = (APlayerCameraManager *)Obj;
	Params.ReturnValue = This->PlayCameraAnim(Params.Anim,Params.Rate,Params.Scale,Params.BlendInTime,Params.BlendOutTime,Params.bLoop,Params.bRandomStartTime,Params.Duration,Params.PlaySpace,Params.UserPlaySpaceRot);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("PlayCameraAnim"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(UCameraAnim**)(params.GetStructMemory() + 0) = Params.Anim;
		*(float*)(params.GetStructMemory() + 8) = Params.Rate;
		*(float*)(params.GetStructMemory() + 12) = Params.Scale;
		*(float*)(params.GetStructMemory() + 16) = Params.BlendInTime;
		*(float*)(params.GetStructMemory() + 20) = Params.BlendOutTime;
		*(bool*)(params.GetStructMemory() + 24) = Params.bLoop;
		*(bool*)(params.GetStructMemory() + 25) = Params.bRandomStartTime;
		*(float*)(params.GetStructMemory() + 28) = Params.Duration;
		*(TEnumAsByte<ECameraAnimPlaySpace::Type>*)(params.GetStructMemory() + 32) = Params.PlaySpace;
		*(FRotator*)(params.GetStructMemory() + 36) = Params.UserPlaySpaceRot;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.Anim = *(UCameraAnim**)(params.GetStructMemory() + 0);
		Params.Rate = *(float*)(params.GetStructMemory() + 8);
		Params.Scale = *(float*)(params.GetStructMemory() + 12);
		Params.BlendInTime = *(float*)(params.GetStructMemory() + 16);
		Params.BlendOutTime = *(float*)(params.GetStructMemory() + 20);
		Params.bLoop = *(bool*)(params.GetStructMemory() + 24);
		Params.bRandomStartTime = *(bool*)(params.GetStructMemory() + 25);
		Params.Duration = *(float*)(params.GetStructMemory() + 28);
		Params.PlaySpace = *(TEnumAsByte<ECameraAnimPlaySpace::Type>*)(params.GetStructMemory() + 32);
		Params.UserPlaySpaceRot = *(FRotator*)(params.GetStructMemory() + 36);
		Params.ReturnValue = *(UCameraAnimInst**)(params.GetStructMemory() + 48);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 PhotographyCameraModify(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PlayerCameraManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PlayerCameraManager must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FVector NewCameraLocation;
		FVector PreviousCameraLocation;
		FVector OriginalCameraLocation;
		FVector ResultCameraLocation;
	} Params;
	Params.NewCameraLocation = (wLua::FLuaVector::Get(InScriptContext, 2));
	Params.PreviousCameraLocation = (wLua::FLuaVector::Get(InScriptContext, 3));
	Params.OriginalCameraLocation = (wLua::FLuaVector::Get(InScriptContext, 4));
#if UE_GAME
	APlayerCameraManager * This = (APlayerCameraManager *)Obj;
	This->PhotographyCameraModify(Params.NewCameraLocation,Params.PreviousCameraLocation,Params.OriginalCameraLocation,Params.ResultCameraLocation);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("PhotographyCameraModify"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FVector*)(params.GetStructMemory() + 0) = Params.NewCameraLocation;
		*(FVector*)(params.GetStructMemory() + 12) = Params.PreviousCameraLocation;
		*(FVector*)(params.GetStructMemory() + 24) = Params.OriginalCameraLocation;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.NewCameraLocation = *(FVector*)(params.GetStructMemory() + 0);
		Params.PreviousCameraLocation = *(FVector*)(params.GetStructMemory() + 12);
		Params.OriginalCameraLocation = *(FVector*)(params.GetStructMemory() + 24);
		Params.ResultCameraLocation = *(FVector*)(params.GetStructMemory() + 36);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaVector::Return(InScriptContext, Params.ResultCameraLocation);
	return 1;
}

int32 OnPhotographySessionStart(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PlayerCameraManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PlayerCameraManager must be non-null"); lua_error(InScriptContext);  return 0;}
#if UE_GAME
	APlayerCameraManager * This = (APlayerCameraManager *)Obj;
	This->OnPhotographySessionStart();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("OnPhotographySessionStart"));
	if(!Function) { check(false); return 0;}
	Obj->ProcessEvent(Function, NULL);
#endif
	return 0;
}

int32 OnPhotographySessionEnd(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PlayerCameraManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PlayerCameraManager must be non-null"); lua_error(InScriptContext);  return 0;}
#if UE_GAME
	APlayerCameraManager * This = (APlayerCameraManager *)Obj;
	This->OnPhotographySessionEnd();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("OnPhotographySessionEnd"));
	if(!Function) { check(false); return 0;}
	Obj->ProcessEvent(Function, NULL);
#endif
	return 0;
}

int32 OnPhotographyMultiPartCaptureStart(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PlayerCameraManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PlayerCameraManager must be non-null"); lua_error(InScriptContext);  return 0;}
#if UE_GAME
	APlayerCameraManager * This = (APlayerCameraManager *)Obj;
	This->OnPhotographyMultiPartCaptureStart();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("OnPhotographyMultiPartCaptureStart"));
	if(!Function) { check(false); return 0;}
	Obj->ProcessEvent(Function, NULL);
#endif
	return 0;
}

int32 OnPhotographyMultiPartCaptureEnd(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PlayerCameraManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PlayerCameraManager must be non-null"); lua_error(InScriptContext);  return 0;}
#if UE_GAME
	APlayerCameraManager * This = (APlayerCameraManager *)Obj;
	This->OnPhotographyMultiPartCaptureEnd();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("OnPhotographyMultiPartCaptureEnd"));
	if(!Function) { check(false); return 0;}
	Obj->ProcessEvent(Function, NULL);
#endif
	return 0;
}

int32 GetOwningPlayerController(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PlayerCameraManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PlayerCameraManager must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		APlayerController* ReturnValue = nullptr;
	} Params;
#if UE_GAME
	APlayerCameraManager * This = (APlayerCameraManager *)Obj;
	Params.ReturnValue = This->GetOwningPlayerController();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetOwningPlayerController"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(APlayerController**)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetFOVAngle(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PlayerCameraManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PlayerCameraManager must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float ReturnValue;
	} Params;
#if UE_GAME
	APlayerCameraManager * This = (APlayerCameraManager *)Obj;
	Params.ReturnValue = This->GetFOVAngle();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetFOVAngle"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(float*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushnumber(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetCameraRotation(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PlayerCameraManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PlayerCameraManager must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FRotator ReturnValue;
	} Params;
#if UE_GAME
	APlayerCameraManager * This = (APlayerCameraManager *)Obj;
	Params.ReturnValue = This->GetCameraRotation();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetCameraRotation"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(FRotator*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaRotator::Return(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetCameraLocation(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PlayerCameraManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PlayerCameraManager must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FVector ReturnValue;
	} Params;
#if UE_GAME
	APlayerCameraManager * This = (APlayerCameraManager *)Obj;
	Params.ReturnValue = This->GetCameraLocation();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetCameraLocation"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(FVector*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaVector::Return(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 FindCameraModifierByClass(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PlayerCameraManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PlayerCameraManager must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		TSubclassOf<UCameraModifier>  ModifierClass;
		UCameraModifier* ReturnValue = nullptr;
	} Params;
	Params.ModifierClass = (UClass*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"Class");;
#if UE_GAME
	APlayerCameraManager * This = (APlayerCameraManager *)Obj;
	Params.ReturnValue = This->FindCameraModifierByClass(Params.ModifierClass);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("FindCameraModifierByClass"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(TSubclassOf<UCameraModifier> *)(params.GetStructMemory() + 0) = Params.ModifierClass;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ModifierClass = *(TSubclassOf<UCameraModifier> *)(params.GetStructMemory() + 0);
		Params.ReturnValue = *(UCameraModifier**)(params.GetStructMemory() + 8);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 ClearCameraLensEffects(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PlayerCameraManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PlayerCameraManager must be non-null"); lua_error(InScriptContext);  return 0;}
#if UE_GAME
	APlayerCameraManager * This = (APlayerCameraManager *)Obj;
	This->ClearCameraLensEffects();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("ClearCameraLensEffects"));
	if(!Function) { check(false); return 0;}
	Obj->ProcessEvent(Function, NULL);
#endif
	return 0;
}

int32 BlueprintUpdateCamera(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PlayerCameraManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PlayerCameraManager must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		AActor* CameraTarget = nullptr;
		FVector NewCameraLocation;
		FRotator NewCameraRotation;
		float NewCameraFOV;
		bool ReturnValue;
	} Params;
	Params.CameraTarget = (AActor*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"Actor");;
#if UE_GAME
	APlayerCameraManager * This = (APlayerCameraManager *)Obj;
	Params.ReturnValue = This->BlueprintUpdateCamera(Params.CameraTarget,Params.NewCameraLocation,Params.NewCameraRotation,Params.NewCameraFOV);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("BlueprintUpdateCamera"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(AActor**)(params.GetStructMemory() + 0) = Params.CameraTarget;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.CameraTarget = *(AActor**)(params.GetStructMemory() + 0);
		Params.NewCameraLocation = *(FVector*)(params.GetStructMemory() + 8);
		Params.NewCameraRotation = *(FRotator*)(params.GetStructMemory() + 20);
		Params.NewCameraFOV = *(float*)(params.GetStructMemory() + 32);
		Params.ReturnValue = *(bool*)(params.GetStructMemory() + 36);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushboolean(InScriptContext, Params.ReturnValue);
	wLua::FLuaVector::Return(InScriptContext, Params.NewCameraLocation);
	wLua::FLuaRotator::Return(InScriptContext, Params.NewCameraRotation);
	lua_pushnumber(InScriptContext, Params.NewCameraFOV);
	return 4;
}

int32 AddNewCameraModifier(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PlayerCameraManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PlayerCameraManager must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		TSubclassOf<UCameraModifier>  ModifierClass;
		UCameraModifier* ReturnValue = nullptr;
	} Params;
	Params.ModifierClass = (UClass*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"Class");;
#if UE_GAME
	APlayerCameraManager * This = (APlayerCameraManager *)Obj;
	Params.ReturnValue = This->AddNewCameraModifier(Params.ModifierClass);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("AddNewCameraModifier"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(TSubclassOf<UCameraModifier> *)(params.GetStructMemory() + 0) = Params.ModifierClass;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ModifierClass = *(TSubclassOf<UCameraModifier> *)(params.GetStructMemory() + 0);
		Params.ReturnValue = *(UCameraModifier**)(params.GetStructMemory() + 8);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 Get_TransformComponent(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PlayerCameraManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PlayerCameraManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(APlayerCameraManager::StaticClass(), TEXT("TransformComponent"));
	if(!Property) { check(false); return 0;}
	USceneComponent* PropertyValue;
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaUtils::ReturnUObject(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_DefaultFOV(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PlayerCameraManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PlayerCameraManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(APlayerCameraManager::StaticClass(), TEXT("DefaultFOV"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_DefaultFOV(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PlayerCameraManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PlayerCameraManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(APlayerCameraManager::StaticClass(), TEXT("DefaultFOV"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_DefaultOrthoWidth(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PlayerCameraManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PlayerCameraManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(APlayerCameraManager::StaticClass(), TEXT("DefaultOrthoWidth"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_DefaultOrthoWidth(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PlayerCameraManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PlayerCameraManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(APlayerCameraManager::StaticClass(), TEXT("DefaultOrthoWidth"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_DefaultAspectRatio(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PlayerCameraManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PlayerCameraManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(APlayerCameraManager::StaticClass(), TEXT("DefaultAspectRatio"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_DefaultAspectRatio(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PlayerCameraManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PlayerCameraManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(APlayerCameraManager::StaticClass(), TEXT("DefaultAspectRatio"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_DefaultModifiers(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PlayerCameraManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PlayerCameraManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(APlayerCameraManager::StaticClass(), TEXT("DefaultModifiers"));
	if(!Property) { check(false); return 0;}
	TArray<TSubclassOf<UCameraModifier> > PropertyValue;
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	{lua_newtable(InScriptContext); int i = 1; for(auto It = PropertyValue.CreateConstIterator(); It; ++It,++i) {  wLua::FLuaUtils::ReturnUObject(InScriptContext, (*It)); lua_rawseti(InScriptContext,-2,i);     }  }
	return 1;
}

int32 Get_FreeCamDistance(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PlayerCameraManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PlayerCameraManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(APlayerCameraManager::StaticClass(), TEXT("FreeCamDistance"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_FreeCamDistance(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PlayerCameraManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PlayerCameraManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(APlayerCameraManager::StaticClass(), TEXT("FreeCamDistance"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_FreeCamOffset(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PlayerCameraManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PlayerCameraManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(APlayerCameraManager::StaticClass(), TEXT("FreeCamOffset"));
	if(!Property) { check(false); return 0;}
	FVector PropertyValue = FVector();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaVector::Return(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_FreeCamOffset(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PlayerCameraManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PlayerCameraManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(APlayerCameraManager::StaticClass(), TEXT("FreeCamOffset"));
	if(!Property) { check(false); return 0;}
	FVector PropertyValue = (wLua::FLuaVector::Get(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_ViewTargetOffset(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PlayerCameraManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PlayerCameraManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(APlayerCameraManager::StaticClass(), TEXT("ViewTargetOffset"));
	if(!Property) { check(false); return 0;}
	FVector PropertyValue = FVector();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaVector::Return(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_ViewTargetOffset(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PlayerCameraManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PlayerCameraManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(APlayerCameraManager::StaticClass(), TEXT("ViewTargetOffset"));
	if(!Property) { check(false); return 0;}
	FVector PropertyValue = (wLua::FLuaVector::Get(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bIsOrthographic(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PlayerCameraManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PlayerCameraManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(APlayerCameraManager::StaticClass(), TEXT("bIsOrthographic"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bIsOrthographic(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PlayerCameraManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PlayerCameraManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(APlayerCameraManager::StaticClass(), TEXT("bIsOrthographic"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bDefaultConstrainAspectRatio(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PlayerCameraManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PlayerCameraManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(APlayerCameraManager::StaticClass(), TEXT("bDefaultConstrainAspectRatio"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bDefaultConstrainAspectRatio(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PlayerCameraManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PlayerCameraManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(APlayerCameraManager::StaticClass(), TEXT("bDefaultConstrainAspectRatio"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bClientSimulatingViewTarget(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PlayerCameraManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PlayerCameraManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(APlayerCameraManager::StaticClass(), TEXT("bClientSimulatingViewTarget"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bClientSimulatingViewTarget(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PlayerCameraManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PlayerCameraManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(APlayerCameraManager::StaticClass(), TEXT("bClientSimulatingViewTarget"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bUseClientSideCameraUpdates(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PlayerCameraManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PlayerCameraManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(APlayerCameraManager::StaticClass(), TEXT("bUseClientSideCameraUpdates"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_bGameCameraCutThisFrame(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PlayerCameraManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PlayerCameraManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(APlayerCameraManager::StaticClass(), TEXT("bGameCameraCutThisFrame"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_ViewPitchMin(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PlayerCameraManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PlayerCameraManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(APlayerCameraManager::StaticClass(), TEXT("ViewPitchMin"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_ViewPitchMin(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PlayerCameraManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PlayerCameraManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(APlayerCameraManager::StaticClass(), TEXT("ViewPitchMin"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_ViewPitchMax(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PlayerCameraManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PlayerCameraManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(APlayerCameraManager::StaticClass(), TEXT("ViewPitchMax"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_ViewPitchMax(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PlayerCameraManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PlayerCameraManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(APlayerCameraManager::StaticClass(), TEXT("ViewPitchMax"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_ViewYawMin(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PlayerCameraManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PlayerCameraManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(APlayerCameraManager::StaticClass(), TEXT("ViewYawMin"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_ViewYawMin(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PlayerCameraManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PlayerCameraManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(APlayerCameraManager::StaticClass(), TEXT("ViewYawMin"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_ViewYawMax(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PlayerCameraManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PlayerCameraManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(APlayerCameraManager::StaticClass(), TEXT("ViewYawMax"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_ViewYawMax(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PlayerCameraManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PlayerCameraManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(APlayerCameraManager::StaticClass(), TEXT("ViewYawMax"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_ViewRollMin(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PlayerCameraManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PlayerCameraManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(APlayerCameraManager::StaticClass(), TEXT("ViewRollMin"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_ViewRollMin(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PlayerCameraManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PlayerCameraManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(APlayerCameraManager::StaticClass(), TEXT("ViewRollMin"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_ViewRollMax(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PlayerCameraManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PlayerCameraManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(APlayerCameraManager::StaticClass(), TEXT("ViewRollMax"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_ViewRollMax(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PlayerCameraManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PlayerCameraManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(APlayerCameraManager::StaticClass(), TEXT("ViewRollMax"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 New(lua_State* InScriptContext)
{
	UObject* Outer = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Object");
	FName Name = FName(luaL_checkstring(InScriptContext, 2));
	UObject* Obj = NewObject<APlayerCameraManager>(Outer, Name);
	wLua::FLuaUtils::ReturnUObject(InScriptContext,Obj);
	return 1;
}

int32 Destroy(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PlayerCameraManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PlayerCameraManager must be non-null"); lua_error(InScriptContext);  return 0;}
		AActor * actor = Cast<AActor>(Obj);
		actor->Destroy();
		userdata->flag |= wLua::LuaObjectFlag::DESTROYED;
		wLua::FLuaUtils::RemoveObjectReference(Obj, userdata->stamp, InScriptContext);
#ifdef AZURE_BUILD_WLUACHECK
		UE_LOG(LogAzure, Warning, TEXT("Destroy PlayerCameraManager: %x userdata:%x   stamp:%x"),Obj,userdata,userdata->stamp);
#endif
	return 0;
}

int32 Class(lua_State* InScriptContext)
{
	UClass* Class = APlayerCameraManager::StaticClass();
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Class);
	return 1;
}

const luaL_Reg Lib_Funcs[] =
{
	{ "New", New },
	{ "Destroy", Destroy },
	{ "Class", Class },
	{ "StopCameraShake", StopCameraShake },
	{ "StopCameraFade", StopCameraFade },
	{ "StopCameraAnimInst", StopCameraAnimInst },
	{ "StopAllInstancesOfCameraShake", StopAllInstancesOfCameraShake },
	{ "StopAllInstancesOfCameraAnim", StopAllInstancesOfCameraAnim },
	{ "StopAllCameraShakes", StopAllCameraShakes },
	{ "StopAllCameraAnims", StopAllCameraAnims },
	{ "StartCameraFade", StartCameraFade },
	{ "SetManualCameraFade", SetManualCameraFade },
	{ "RemoveCameraModifier", RemoveCameraModifier },
	{ "RemoveCameraLensEffect", RemoveCameraLensEffect },
	{ "PlayCameraShake", PlayCameraShake },
	{ "PlayCameraAnim", PlayCameraAnim },
	{ "PhotographyCameraModify", PhotographyCameraModify },
	{ "OnPhotographySessionStart", OnPhotographySessionStart },
	{ "OnPhotographySessionEnd", OnPhotographySessionEnd },
	{ "OnPhotographyMultiPartCaptureStart", OnPhotographyMultiPartCaptureStart },
	{ "OnPhotographyMultiPartCaptureEnd", OnPhotographyMultiPartCaptureEnd },
	{ "GetOwningPlayerController", GetOwningPlayerController },
	{ "GetFOVAngle", GetFOVAngle },
	{ "GetCameraRotation", GetCameraRotation },
	{ "GetCameraLocation", GetCameraLocation },
	{ "FindCameraModifierByClass", FindCameraModifierByClass },
	{ "ClearCameraLensEffects", ClearCameraLensEffects },
	{ "BlueprintUpdateCamera", BlueprintUpdateCamera },
	{ "AddNewCameraModifier", AddNewCameraModifier },
	{ "Get_TransformComponent", Get_TransformComponent },
	{ "Get_DefaultFOV", Get_DefaultFOV },
	{ "Set_DefaultFOV", Set_DefaultFOV },
	{ "Get_DefaultOrthoWidth", Get_DefaultOrthoWidth },
	{ "Set_DefaultOrthoWidth", Set_DefaultOrthoWidth },
	{ "Get_DefaultAspectRatio", Get_DefaultAspectRatio },
	{ "Set_DefaultAspectRatio", Set_DefaultAspectRatio },
	{ "Get_DefaultModifiers", Get_DefaultModifiers },
	{ "Get_FreeCamDistance", Get_FreeCamDistance },
	{ "Set_FreeCamDistance", Set_FreeCamDistance },
	{ "Get_FreeCamOffset", Get_FreeCamOffset },
	{ "Set_FreeCamOffset", Set_FreeCamOffset },
	{ "Get_ViewTargetOffset", Get_ViewTargetOffset },
	{ "Set_ViewTargetOffset", Set_ViewTargetOffset },
	{ "Get_bIsOrthographic", Get_bIsOrthographic },
	{ "Set_bIsOrthographic", Set_bIsOrthographic },
	{ "Get_bDefaultConstrainAspectRatio", Get_bDefaultConstrainAspectRatio },
	{ "Set_bDefaultConstrainAspectRatio", Set_bDefaultConstrainAspectRatio },
	{ "Get_bClientSimulatingViewTarget", Get_bClientSimulatingViewTarget },
	{ "Set_bClientSimulatingViewTarget", Set_bClientSimulatingViewTarget },
	{ "Get_bUseClientSideCameraUpdates", Get_bUseClientSideCameraUpdates },
	{ "Get_bGameCameraCutThisFrame", Get_bGameCameraCutThisFrame },
	{ "Get_ViewPitchMin", Get_ViewPitchMin },
	{ "Set_ViewPitchMin", Set_ViewPitchMin },
	{ "Get_ViewPitchMax", Get_ViewPitchMax },
	{ "Set_ViewPitchMax", Set_ViewPitchMax },
	{ "Get_ViewYawMin", Get_ViewYawMin },
	{ "Set_ViewYawMin", Set_ViewYawMin },
	{ "Get_ViewYawMax", Get_ViewYawMax },
	{ "Set_ViewYawMax", Set_ViewYawMax },
	{ "Get_ViewRollMin", Get_ViewRollMin },
	{ "Set_ViewRollMin", Set_ViewRollMin },
	{ "Get_ViewRollMax", Get_ViewRollMax },
	{ "Set_ViewRollMax", Set_ViewRollMax },
	{ "is_nil", wLua::LuaStatic::isnil },
	{ "__gc", wLua::LuaStatic::removeUClassFrameCache },
	{ NULL, NULL }
};

void Register(lua_State *InScriptContext)
{
	lua_newtable(InScriptContext);
	luaL_register(InScriptContext, NULL, Lib_Funcs);
	AzureHelpFuncs::AuxRegister(InScriptContext, "PlayerCameraManager");
}
void SetMtLink(lua_State *InScriptContext)
{
	AzureHelpFuncs::AuxSetMtLink(InScriptContext, "PlayerCameraManager", "Actor",USERDATATYPE_UOBJECT);
}

}