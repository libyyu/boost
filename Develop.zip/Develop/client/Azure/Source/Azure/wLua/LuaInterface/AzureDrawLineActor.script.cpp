#include "Azure.h"
#include "Utility/help_funcs.h"
#include "wLua/UObjectHeaders.h"
#include "GameLogic/Home/AzureDrawLineActor.h"
#include "AzureLuaIntegration.h"

namespace LuaAzureDrawLineActor
{
int32 RemoveAllLines(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureDrawLineActor",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureDrawLineActor must be non-null"); lua_error(InScriptContext);  return 0;}
#if UE_GAME
	AAzureDrawLineActor * This = (AAzureDrawLineActor *)Obj;
	This->RemoveAllLines();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("RemoveAllLines"));
	if(!Function) { check(false); return 0;}
	Obj->ProcessEvent(Function, NULL);
#endif
	return 0;
}

int32 AddLine(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureDrawLineActor",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureDrawLineActor must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FVector Start;
		FVector End;
		FLinearColor Color;
		int32 DepthPriorityGroup;
		float Thickness;
	} Params;
	Params.Start = (wLua::FLuaVector::Get(InScriptContext, 2));
	Params.End = (wLua::FLuaVector::Get(InScriptContext, 3));
	Params.Color = (wLua::FLuaLinearColor::Get(InScriptContext, 4));
	Params.DepthPriorityGroup = (luaL_checkint(InScriptContext, 5));
	Params.Thickness = (float)(luaL_checknumber(InScriptContext, 6));
#if UE_GAME
	AAzureDrawLineActor * This = (AAzureDrawLineActor *)Obj;
	This->AddLine(Params.Start,Params.End,Params.Color,Params.DepthPriorityGroup,Params.Thickness);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("AddLine"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FVector*)(params.GetStructMemory() + 0) = Params.Start;
		*(FVector*)(params.GetStructMemory() + 12) = Params.End;
		*(FLinearColor*)(params.GetStructMemory() + 24) = Params.Color;
		*(int32*)(params.GetStructMemory() + 40) = Params.DepthPriorityGroup;
		*(float*)(params.GetStructMemory() + 44) = Params.Thickness;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.Start = *(FVector*)(params.GetStructMemory() + 0);
		Params.End = *(FVector*)(params.GetStructMemory() + 12);
		Params.Color = *(FLinearColor*)(params.GetStructMemory() + 24);
		Params.DepthPriorityGroup = *(int32*)(params.GetStructMemory() + 40);
		Params.Thickness = *(float*)(params.GetStructMemory() + 44);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 New(lua_State* InScriptContext)
{
	UObject* Outer = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Object");
	FName Name = FName(luaL_checkstring(InScriptContext, 2));
	UObject* Obj = NewObject<AAzureDrawLineActor>(Outer, Name);
	wLua::FLuaUtils::ReturnUObject(InScriptContext,Obj);
	return 1;
}

int32 Destroy(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureDrawLineActor",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureDrawLineActor must be non-null"); lua_error(InScriptContext);  return 0;}
		AActor * actor = Cast<AActor>(Obj);
		actor->Destroy();
		userdata->flag |= wLua::LuaObjectFlag::DESTROYED;
		wLua::FLuaUtils::RemoveObjectReference(Obj, userdata->stamp, InScriptContext);
#ifdef AZURE_BUILD_WLUACHECK
		UE_LOG(LogAzure, Warning, TEXT("Destroy AzureDrawLineActor: %x userdata:%x   stamp:%x"),Obj,userdata,userdata->stamp);
#endif
	return 0;
}

int32 Class(lua_State* InScriptContext)
{
	UClass* Class = AAzureDrawLineActor::StaticClass();
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Class);
	return 1;
}

const luaL_Reg Lib_Funcs[] =
{
	{ "New", New },
	{ "Destroy", Destroy },
	{ "Class", Class },
	{ "RemoveAllLines", RemoveAllLines },
	{ "AddLine", AddLine },
	{ "is_nil", wLua::LuaStatic::isnil },
	{ "__gc", wLua::LuaStatic::removeUClassFrameCache },
	{ NULL, NULL }
};

void Register(lua_State *InScriptContext)
{
	lua_newtable(InScriptContext);
	luaL_register(InScriptContext, NULL, Lib_Funcs);
	AzureHelpFuncs::AuxRegister(InScriptContext, "AzureDrawLineActor");
}
void SetMtLink(lua_State *InScriptContext)
{
	AzureHelpFuncs::AuxSetMtLink(InScriptContext, "AzureDrawLineActor", "Actor",USERDATATYPE_UOBJECT);
}

}