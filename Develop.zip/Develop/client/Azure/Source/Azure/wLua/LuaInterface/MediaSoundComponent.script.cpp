#include "Azure.h"
#include "Utility/help_funcs.h"
#include "wLua/UObjectHeaders.h"
#include "MediaSoundComponent.h"
#include "MediaPlayer.h"
#include "AzureLuaIntegration.h"

namespace LuaMediaSoundComponent
{
int32 SetMediaPlayer(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MediaSoundComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MediaSoundComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		UMediaPlayer* NewMediaPlayer = nullptr;
	} Params;
	Params.NewMediaPlayer = (UMediaPlayer*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"MediaPlayer");;
#if UE_GAME
	UMediaSoundComponent * This = (UMediaSoundComponent *)Obj;
	This->SetMediaPlayer(Params.NewMediaPlayer);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetMediaPlayer"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(UMediaPlayer**)(params.GetStructMemory() + 0) = Params.NewMediaPlayer;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.NewMediaPlayer = *(UMediaPlayer**)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 GetMediaPlayer(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MediaSoundComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MediaSoundComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		UMediaPlayer* ReturnValue = nullptr;
	} Params;
#if UE_GAME
	UMediaSoundComponent * This = (UMediaSoundComponent *)Obj;
	Params.ReturnValue = This->GetMediaPlayer();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetMediaPlayer"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(UMediaPlayer**)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 Get_Channels(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MediaSoundComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MediaSoundComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UMediaSoundComponent::StaticClass(), TEXT("Channels"));
	if(!Property) { check(false); return 0;}
	EMediaSoundChannels PropertyValue = EMediaSoundChannels();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushinteger(InScriptContext, (int)PropertyValue);
	return 1;
}

int32 Set_Channels(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MediaSoundComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MediaSoundComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UMediaSoundComponent::StaticClass(), TEXT("Channels"));
	if(!Property) { check(false); return 0;}
	EMediaSoundChannels PropertyValue = (EMediaSoundChannels)(luaL_checkint(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_DynamicRateAdjustment(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MediaSoundComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MediaSoundComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UMediaSoundComponent::StaticClass(), TEXT("DynamicRateAdjustment"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = bool();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_DynamicRateAdjustment(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MediaSoundComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MediaSoundComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UMediaSoundComponent::StaticClass(), TEXT("DynamicRateAdjustment"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_RateAdjustmentFactor(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MediaSoundComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MediaSoundComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UMediaSoundComponent::StaticClass(), TEXT("RateAdjustmentFactor"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_RateAdjustmentFactor(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MediaSoundComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MediaSoundComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UMediaSoundComponent::StaticClass(), TEXT("RateAdjustmentFactor"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_MediaPlayer(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MediaSoundComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MediaSoundComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UMediaSoundComponent::StaticClass(), TEXT("MediaPlayer"));
	if(!Property) { check(false); return 0;}
	UMediaPlayer* PropertyValue;
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaUtils::ReturnUObject(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_MediaPlayer(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MediaSoundComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MediaSoundComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UMediaSoundComponent::StaticClass(), TEXT("MediaPlayer"));
	if(!Property) { check(false); return 0;}
	UMediaPlayer* PropertyValue = (UMediaPlayer*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"MediaPlayer");;
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 New(lua_State* InScriptContext)
{
	UObject* Outer = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Object");
	FName Name = FName(luaL_checkstring(InScriptContext, 2));
	UObject* Obj = NewObject<UMediaSoundComponent>(Outer, Name);
	wLua::FLuaUtils::ReturnUObject(InScriptContext,Obj);
	return 1;
}

int32 Destroy(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MediaSoundComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MediaSoundComponent must be non-null"); lua_error(InScriptContext);  return 0;}
		UActorComponent * com = Cast<UActorComponent>(Obj);
		if(lua_isnoneornil(InScriptContext,2))
			com->DestroyComponent();
		else
			com->DestroyComponent(!!lua_toboolean(InScriptContext,2));
		userdata->flag |= wLua::LuaObjectFlag::DESTROYED;
		wLua::FLuaUtils::RemoveObjectReference(Obj, userdata->stamp, InScriptContext);
#ifdef AZURE_BUILD_WLUACHECK
		UE_LOG(LogAzure, Warning, TEXT("Destroy MediaSoundComponent: %x userdata:%x   stamp:%x"),Obj,userdata,userdata->stamp);
#endif
	return 0;
}

int32 Class(lua_State* InScriptContext)
{
	UClass* Class = UMediaSoundComponent::StaticClass();
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Class);
	return 1;
}

const luaL_Reg Lib_Funcs[] =
{
	{ "New", New },
	{ "Destroy", Destroy },
	{ "Class", Class },
	{ "SetMediaPlayer", SetMediaPlayer },
	{ "GetMediaPlayer", GetMediaPlayer },
	{ "Get_Channels", Get_Channels },
	{ "Set_Channels", Set_Channels },
	{ "Get_DynamicRateAdjustment", Get_DynamicRateAdjustment },
	{ "Set_DynamicRateAdjustment", Set_DynamicRateAdjustment },
	{ "Get_RateAdjustmentFactor", Get_RateAdjustmentFactor },
	{ "Set_RateAdjustmentFactor", Set_RateAdjustmentFactor },
	{ "Get_MediaPlayer", Get_MediaPlayer },
	{ "Set_MediaPlayer", Set_MediaPlayer },
	{ "is_nil", wLua::LuaStatic::isnil },
	{ "__gc", wLua::LuaStatic::removeUClassFrameCache },
	{ NULL, NULL }
};

void Register(lua_State *InScriptContext)
{
	lua_newtable(InScriptContext);
	luaL_register(InScriptContext, NULL, Lib_Funcs);
	AzureHelpFuncs::AuxRegister(InScriptContext, "MediaSoundComponent");
}
void SetMtLink(lua_State *InScriptContext)
{
	AzureHelpFuncs::AuxSetMtLink(InScriptContext, "MediaSoundComponent", "SceneComponent",USERDATATYPE_UOBJECT);
}

}