#include "Azure.h"
#include "Utility/help_funcs.h"
#include "wLua/UObjectHeaders.h"
#include "Widget/UIParticleEmitter.h"
#include "AzureLuaIntegration.h"

namespace LuaUIParticleEmitter
{
int32 StopEmit(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"UIParticleEmitter",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"UIParticleEmitter must be non-null"); lua_error(InScriptContext);  return 0;}
#if UE_GAME
	UUIParticleEmitter * This = (UUIParticleEmitter *)Obj;
	This->StopEmit();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("StopEmit"));
	if(!Function) { check(false); return 0;}
	Obj->ProcessEvent(Function, NULL);
#endif
	return 0;
}

int32 Stop(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"UIParticleEmitter",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"UIParticleEmitter must be non-null"); lua_error(InScriptContext);  return 0;}
#if UE_GAME
	UUIParticleEmitter * This = (UUIParticleEmitter *)Obj;
	This->Stop();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("Stop"));
	if(!Function) { check(false); return 0;}
	Obj->ProcessEvent(Function, NULL);
#endif
	return 0;
}

int32 Play(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"UIParticleEmitter",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"UIParticleEmitter must be non-null"); lua_error(InScriptContext);  return 0;}
#if UE_GAME
	UUIParticleEmitter * This = (UUIParticleEmitter *)Obj;
	This->Play();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("Play"));
	if(!Function) { check(false); return 0;}
	Obj->ProcessEvent(Function, NULL);
#endif
	return 0;
}

int32 Get_Asset(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"UIParticleEmitter",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"UIParticleEmitter must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UUIParticleEmitter::StaticClass(), TEXT("Asset"));
	if(!Property) { check(false); return 0;}
	UUIParticleEmitterAsset* PropertyValue;
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaUtils::ReturnUObject(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_Asset(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"UIParticleEmitter",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"UIParticleEmitter must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UUIParticleEmitter::StaticClass(), TEXT("Asset"));
	if(!Property) { check(false); return 0;}
	UUIParticleEmitterAsset* PropertyValue = (UUIParticleEmitterAsset*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"UIParticleEmitterAsset");;
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Call_EventOnEnd(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"UIParticleEmitter",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"UIParticleEmitter must be non-null"); lua_error(InScriptContext);  return 0;}
	UUIParticleEmitter * This = (UUIParticleEmitter *)Obj;
	This->EventOnEnd.Broadcast();
	return 0;
}

int32 Get_IsPlaying(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"UIParticleEmitter",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"UIParticleEmitter must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UUIParticleEmitter::StaticClass(), TEXT("IsPlaying"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = bool();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 New(lua_State* InScriptContext)
{
	UObject* Outer = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Object");
	FName Name = FName(luaL_checkstring(InScriptContext, 2));
	UObject* Obj = NewObject<UUIParticleEmitter>(Outer, Name);
	wLua::FLuaUtils::ReturnUObject(InScriptContext,Obj);
	return 1;
}

int32 Destroy(lua_State* InScriptContext)
{
	return 0;
}

int32 Class(lua_State* InScriptContext)
{
	UClass* Class = UUIParticleEmitter::StaticClass();
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Class);
	return 1;
}

const luaL_Reg Lib_Funcs[] =
{
	{ "New", New },
	{ "Destroy", Destroy },
	{ "Class", Class },
	{ "StopEmit", StopEmit },
	{ "Stop", Stop },
	{ "Play", Play },
	{ "Get_Asset", Get_Asset },
	{ "Set_Asset", Set_Asset },
	{ "Call_EventOnEnd", Call_EventOnEnd },
	{ "Get_IsPlaying", Get_IsPlaying },
	{ "is_nil", wLua::LuaStatic::isnil },
	{ "__gc", wLua::LuaStatic::removeUClassFrameCache },
	{ NULL, NULL }
};

void Register(lua_State *InScriptContext)
{
	lua_newtable(InScriptContext);
	luaL_register(InScriptContext, NULL, Lib_Funcs);
	AzureHelpFuncs::AuxRegister(InScriptContext, "UIParticleEmitter");
}
void SetMtLink(lua_State *InScriptContext)
{
	AzureHelpFuncs::AuxSetMtLink(InScriptContext, "UIParticleEmitter", "Widget",USERDATATYPE_UOBJECT);
}

}