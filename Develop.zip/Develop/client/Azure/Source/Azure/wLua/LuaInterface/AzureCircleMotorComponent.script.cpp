#include "Azure.h"
#include "Utility/help_funcs.h"
#include "wLua/UObjectHeaders.h"
#include "AzureCircleMotorComponent.h"
#include "AzureLuaIntegration.h"

namespace LuaAzureCircleMotorComponent
{
int32 StartMove(lua_State*);

int32 SetExtraParam(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureCircleMotorComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureCircleMotorComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FVector centerPos;
		FVector emitDir;
		float _RadiusShrinkSpeed;
		float _AngleSpeed;
	} Params;
	Params.centerPos = (wLua::FLuaVector::Get(InScriptContext, 2));
	Params.emitDir = (wLua::FLuaVector::Get(InScriptContext, 3));
	Params._RadiusShrinkSpeed = (float)(luaL_checknumber(InScriptContext, 4));
	Params._AngleSpeed = (float)(luaL_checknumber(InScriptContext, 5));
#if UE_GAME
	UAzureCircleMotorComponent * This = (UAzureCircleMotorComponent *)Obj;
	This->SetExtraParam(Params.centerPos,Params.emitDir,Params._RadiusShrinkSpeed,Params._AngleSpeed);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetExtraParam"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FVector*)(params.GetStructMemory() + 0) = Params.centerPos;
		*(FVector*)(params.GetStructMemory() + 12) = Params.emitDir;
		*(float*)(params.GetStructMemory() + 24) = Params._RadiusShrinkSpeed;
		*(float*)(params.GetStructMemory() + 28) = Params._AngleSpeed;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.centerPos = *(FVector*)(params.GetStructMemory() + 0);
		Params.emitDir = *(FVector*)(params.GetStructMemory() + 12);
		Params._RadiusShrinkSpeed = *(float*)(params.GetStructMemory() + 24);
		Params._AngleSpeed = *(float*)(params.GetStructMemory() + 28);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 New(lua_State* InScriptContext)
{
	UObject* Outer = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Object");
	FName Name = FName(luaL_checkstring(InScriptContext, 2));
	UObject* Obj = NewObject<UAzureCircleMotorComponent>(Outer, Name);
	wLua::FLuaUtils::ReturnUObject(InScriptContext,Obj);
	return 1;
}

int32 Destroy(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureCircleMotorComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureCircleMotorComponent must be non-null"); lua_error(InScriptContext);  return 0;}
		UActorComponent * com = Cast<UActorComponent>(Obj);
		if(lua_isnoneornil(InScriptContext,2))
			com->DestroyComponent();
		else
			com->DestroyComponent(!!lua_toboolean(InScriptContext,2));
		userdata->flag |= wLua::LuaObjectFlag::DESTROYED;
		wLua::FLuaUtils::RemoveObjectReference(Obj, userdata->stamp, InScriptContext);
#ifdef AZURE_BUILD_WLUACHECK
		UE_LOG(LogAzure, Warning, TEXT("Destroy AzureCircleMotorComponent: %x userdata:%x   stamp:%x"),Obj,userdata,userdata->stamp);
#endif
	return 0;
}

int32 Class(lua_State* InScriptContext)
{
	UClass* Class = UAzureCircleMotorComponent::StaticClass();
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Class);
	return 1;
}

const luaL_Reg Lib_Funcs[] =
{
	{ "New", New },
	{ "Destroy", Destroy },
	{ "Class", Class },
	{ "SetExtraParam", SetExtraParam },
	{ "StartMove", StartMove },
	{ "is_nil", wLua::LuaStatic::isnil },
	{ "__gc", wLua::LuaStatic::removeUClassFrameCache },
	{ NULL, NULL }
};

void Register(lua_State *InScriptContext)
{
	lua_newtable(InScriptContext);
	luaL_register(InScriptContext, NULL, Lib_Funcs);
	AzureHelpFuncs::AuxRegister(InScriptContext, "AzureCircleMotorComponent");
}
void SetMtLink(lua_State *InScriptContext)
{
	AzureHelpFuncs::AuxSetMtLink(InScriptContext, "AzureCircleMotorComponent", "AzureMotorComponent",USERDATATYPE_UOBJECT);
}

}