#include "Azure.h"
#include "Utility/help_funcs.h"
#include "wLua/UObjectHeaders.h"
#include "Kismet/BlueprintPlatformLibrary.h"
#include "AzureLuaIntegration.h"

namespace LuaBlueprintPlatformLibrary
{
int32 ScheduleLocalNotificationFromNow(lua_State* InScriptContext)
{
	UClass * Obj = UBlueprintPlatformLibrary::StaticClass(); 
	struct FDispatchParams
	{
		int32 inSecondsFromNow;
		FText Title;
		FText Body;
		FText Action;
		FString ActivationEvent;
	} Params;
	Params.inSecondsFromNow = (luaL_checkint(InScriptContext, 1));
	Params.Title = FText::FromString(UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 2)));
	Params.Body = FText::FromString(UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 3)));
	Params.Action = FText::FromString(UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 4)));
	Params.ActivationEvent = UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 5));
#if UE_GAME
	UBlueprintPlatformLibrary::ScheduleLocalNotificationFromNow(Params.inSecondsFromNow,Params.Title,Params.Body,Params.Action,Params.ActivationEvent);
#else
	UFunction* Function = Obj->FindFunctionByName(TEXT("ScheduleLocalNotificationFromNow"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(int32*)(params.GetStructMemory() + 0) = Params.inSecondsFromNow;
		*(FText*)(params.GetStructMemory() + 8) = Params.Title;
		*(FText*)(params.GetStructMemory() + 32) = Params.Body;
		*(FText*)(params.GetStructMemory() + 56) = Params.Action;
		*(FString*)(params.GetStructMemory() + 80) = Params.ActivationEvent;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.inSecondsFromNow = *(int32*)(params.GetStructMemory() + 0);
		Params.Title = *(FText*)(params.GetStructMemory() + 8);
		Params.Body = *(FText*)(params.GetStructMemory() + 32);
		Params.Action = *(FText*)(params.GetStructMemory() + 56);
		Params.ActivationEvent = *(FString*)(params.GetStructMemory() + 80);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 ScheduleLocalNotificationBadgeFromNow(lua_State* InScriptContext)
{
	UClass * Obj = UBlueprintPlatformLibrary::StaticClass(); 
	struct FDispatchParams
	{
		int32 inSecondsFromNow;
		FString ActivationEvent;
	} Params;
	Params.inSecondsFromNow = (luaL_checkint(InScriptContext, 1));
	Params.ActivationEvent = UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 2));
#if UE_GAME
	UBlueprintPlatformLibrary::ScheduleLocalNotificationBadgeFromNow(Params.inSecondsFromNow,Params.ActivationEvent);
#else
	UFunction* Function = Obj->FindFunctionByName(TEXT("ScheduleLocalNotificationBadgeFromNow"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(int32*)(params.GetStructMemory() + 0) = Params.inSecondsFromNow;
		*(FString*)(params.GetStructMemory() + 8) = Params.ActivationEvent;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.inSecondsFromNow = *(int32*)(params.GetStructMemory() + 0);
		Params.ActivationEvent = *(FString*)(params.GetStructMemory() + 8);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 GetLaunchNotification(lua_State* InScriptContext)
{
	UClass * Obj = UBlueprintPlatformLibrary::StaticClass(); 
	struct FDispatchParams
	{
		bool NotificationLaunchedApp;
		FString ActivationEvent;
		int32 FireDate;
	} Params;
#if UE_GAME
	UBlueprintPlatformLibrary::GetLaunchNotification(Params.NotificationLaunchedApp,Params.ActivationEvent,Params.FireDate);
#else
	UFunction* Function = Obj->FindFunctionByName(TEXT("GetLaunchNotification"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.NotificationLaunchedApp = *(bool*)(params.GetStructMemory() + 0);
		Params.ActivationEvent = *(FString*)(params.GetStructMemory() + 8);
		Params.FireDate = *(int32*)(params.GetStructMemory() + 24);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushboolean(InScriptContext, Params.NotificationLaunchedApp);
	lua_pushstring(InScriptContext, TCHAR_TO_UTF8(*Params.ActivationEvent));
	lua_pushinteger(InScriptContext, Params.FireDate);
	return 3;
}

int32 GetDeviceOrientation(lua_State* InScriptContext)
{
	UClass * Obj = UBlueprintPlatformLibrary::StaticClass(); 
	struct FDispatchParams
	{
		TEnumAsByte<EScreenOrientation::Type> ReturnValue;
	} Params;
#if UE_GAME
	Params.ReturnValue = UBlueprintPlatformLibrary::GetDeviceOrientation();
#else
	UFunction* Function = Obj->FindFunctionByName(TEXT("GetDeviceOrientation"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(TEnumAsByte<EScreenOrientation::Type>*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushinteger(InScriptContext, (int)Params.ReturnValue);
	return 1;
}

int32 ClearAllLocalNotifications(lua_State* InScriptContext)
{
	UClass * Obj = UBlueprintPlatformLibrary::StaticClass(); 
#if UE_GAME
	UBlueprintPlatformLibrary::ClearAllLocalNotifications();
#else
	UFunction* Function = Obj->FindFunctionByName(TEXT("ClearAllLocalNotifications"));
	if(!Function) { check(false); return 0;}
	Obj->ProcessEvent(Function, NULL);
#endif
	return 0;
}

int32 CancelLocalNotification(lua_State* InScriptContext)
{
	UClass * Obj = UBlueprintPlatformLibrary::StaticClass(); 
	struct FDispatchParams
	{
		FString ActivationEvent;
	} Params;
	Params.ActivationEvent = UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 1));
#if UE_GAME
	UBlueprintPlatformLibrary::CancelLocalNotification(Params.ActivationEvent);
#else
	UFunction* Function = Obj->FindFunctionByName(TEXT("CancelLocalNotification"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FString*)(params.GetStructMemory() + 0) = Params.ActivationEvent;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ActivationEvent = *(FString*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 New(lua_State* InScriptContext)
{
	UObject* Outer = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Object");
	FName Name = FName(luaL_checkstring(InScriptContext, 2));
	UObject* Obj = NewObject<UBlueprintPlatformLibrary>(Outer, Name);
	wLua::FLuaUtils::ReturnUObject(InScriptContext,Obj);
	return 1;
}

int32 Destroy(lua_State* InScriptContext)
{
	return 0;
}

int32 Class(lua_State* InScriptContext)
{
	UClass* Class = UBlueprintPlatformLibrary::StaticClass();
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Class);
	return 1;
}

const luaL_Reg Lib_Funcs[] =
{
	{ "New", New },
	{ "Destroy", Destroy },
	{ "Class", Class },
	{ "ScheduleLocalNotificationFromNow", ScheduleLocalNotificationFromNow },
	{ "ScheduleLocalNotificationBadgeFromNow", ScheduleLocalNotificationBadgeFromNow },
	{ "GetLaunchNotification", GetLaunchNotification },
	{ "GetDeviceOrientation", GetDeviceOrientation },
	{ "ClearAllLocalNotifications", ClearAllLocalNotifications },
	{ "CancelLocalNotification", CancelLocalNotification },
	{ "is_nil", wLua::LuaStatic::isnil },
	{ "__gc", wLua::LuaStatic::removeUClassFrameCache },
	{ NULL, NULL }
};

void Register(lua_State *InScriptContext)
{
	lua_newtable(InScriptContext);
	luaL_register(InScriptContext, NULL, Lib_Funcs);
	AzureHelpFuncs::AuxRegister(InScriptContext, "BlueprintPlatformLibrary");
}
void SetMtLink(lua_State *InScriptContext)
{
	AzureHelpFuncs::AuxSetMtLink(InScriptContext, "BlueprintPlatformLibrary", "Object",USERDATATYPE_UOBJECT);
}

}