#include "Azure.h"
#include "Utility/help_funcs.h"
#include "wLua/UObjectHeaders.h"
#include "GameFramework/SpringArmComponent.h"
#include "AzureLuaIntegration.h"

namespace LuaSpringArmComponent
{
int32 IsCollisionFixApplied(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SpringArmComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SpringArmComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool ReturnValue;
	} Params;
#if UE_GAME
	USpringArmComponent * This = (USpringArmComponent *)Obj;
	Params.ReturnValue = This->IsCollisionFixApplied();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("IsCollisionFixApplied"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushboolean(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetUnfixedCameraPosition(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SpringArmComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SpringArmComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FVector ReturnValue;
	} Params;
#if UE_GAME
	USpringArmComponent * This = (USpringArmComponent *)Obj;
	Params.ReturnValue = This->GetUnfixedCameraPosition();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetUnfixedCameraPosition"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(FVector*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaVector::Return(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetTargetRotation(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SpringArmComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SpringArmComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FRotator ReturnValue;
	} Params;
#if UE_GAME
	USpringArmComponent * This = (USpringArmComponent *)Obj;
	Params.ReturnValue = This->GetTargetRotation();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetTargetRotation"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(FRotator*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaRotator::Return(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 Get_TargetArmLength(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SpringArmComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SpringArmComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USpringArmComponent::StaticClass(), TEXT("TargetArmLength"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_TargetArmLength(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SpringArmComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SpringArmComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USpringArmComponent::StaticClass(), TEXT("TargetArmLength"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_SocketOffset(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SpringArmComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SpringArmComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USpringArmComponent::StaticClass(), TEXT("SocketOffset"));
	if(!Property) { check(false); return 0;}
	FVector PropertyValue = FVector();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaVector::Return(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_SocketOffset(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SpringArmComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SpringArmComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USpringArmComponent::StaticClass(), TEXT("SocketOffset"));
	if(!Property) { check(false); return 0;}
	FVector PropertyValue = (wLua::FLuaVector::Get(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_TargetOffset(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SpringArmComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SpringArmComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USpringArmComponent::StaticClass(), TEXT("TargetOffset"));
	if(!Property) { check(false); return 0;}
	FVector PropertyValue = FVector();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaVector::Return(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_TargetOffset(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SpringArmComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SpringArmComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USpringArmComponent::StaticClass(), TEXT("TargetOffset"));
	if(!Property) { check(false); return 0;}
	FVector PropertyValue = (wLua::FLuaVector::Get(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_ProbeSize(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SpringArmComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SpringArmComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USpringArmComponent::StaticClass(), TEXT("ProbeSize"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_ProbeSize(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SpringArmComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SpringArmComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USpringArmComponent::StaticClass(), TEXT("ProbeSize"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_ProbeChannel(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SpringArmComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SpringArmComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USpringArmComponent::StaticClass(), TEXT("ProbeChannel"));
	if(!Property) { check(false); return 0;}
	TEnumAsByte<ECollisionChannel> PropertyValue = TEnumAsByte<ECollisionChannel>();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushinteger(InScriptContext, (int)PropertyValue);
	return 1;
}

int32 Set_ProbeChannel(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SpringArmComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SpringArmComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USpringArmComponent::StaticClass(), TEXT("ProbeChannel"));
	if(!Property) { check(false); return 0;}
	TEnumAsByte<ECollisionChannel> PropertyValue = (TEnumAsByte<ECollisionChannel>)(luaL_checkint(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bDoCollisionTest(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SpringArmComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SpringArmComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USpringArmComponent::StaticClass(), TEXT("bDoCollisionTest"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bDoCollisionTest(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SpringArmComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SpringArmComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USpringArmComponent::StaticClass(), TEXT("bDoCollisionTest"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bUsePawnControlRotation(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SpringArmComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SpringArmComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USpringArmComponent::StaticClass(), TEXT("bUsePawnControlRotation"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bUsePawnControlRotation(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SpringArmComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SpringArmComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USpringArmComponent::StaticClass(), TEXT("bUsePawnControlRotation"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bInheritPitch(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SpringArmComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SpringArmComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USpringArmComponent::StaticClass(), TEXT("bInheritPitch"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bInheritPitch(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SpringArmComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SpringArmComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USpringArmComponent::StaticClass(), TEXT("bInheritPitch"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bInheritYaw(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SpringArmComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SpringArmComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USpringArmComponent::StaticClass(), TEXT("bInheritYaw"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bInheritYaw(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SpringArmComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SpringArmComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USpringArmComponent::StaticClass(), TEXT("bInheritYaw"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bInheritRoll(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SpringArmComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SpringArmComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USpringArmComponent::StaticClass(), TEXT("bInheritRoll"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bInheritRoll(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SpringArmComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SpringArmComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USpringArmComponent::StaticClass(), TEXT("bInheritRoll"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bEnableCameraLag(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SpringArmComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SpringArmComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USpringArmComponent::StaticClass(), TEXT("bEnableCameraLag"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bEnableCameraLag(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SpringArmComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SpringArmComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USpringArmComponent::StaticClass(), TEXT("bEnableCameraLag"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bEnableCameraRotationLag(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SpringArmComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SpringArmComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USpringArmComponent::StaticClass(), TEXT("bEnableCameraRotationLag"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bEnableCameraRotationLag(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SpringArmComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SpringArmComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USpringArmComponent::StaticClass(), TEXT("bEnableCameraRotationLag"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bUseCameraLagSubstepping(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SpringArmComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SpringArmComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USpringArmComponent::StaticClass(), TEXT("bUseCameraLagSubstepping"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bUseCameraLagSubstepping(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SpringArmComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SpringArmComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USpringArmComponent::StaticClass(), TEXT("bUseCameraLagSubstepping"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bDrawDebugLagMarkers(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SpringArmComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SpringArmComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USpringArmComponent::StaticClass(), TEXT("bDrawDebugLagMarkers"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bDrawDebugLagMarkers(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SpringArmComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SpringArmComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USpringArmComponent::StaticClass(), TEXT("bDrawDebugLagMarkers"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_CameraLagSpeed(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SpringArmComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SpringArmComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USpringArmComponent::StaticClass(), TEXT("CameraLagSpeed"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_CameraLagSpeed(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SpringArmComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SpringArmComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USpringArmComponent::StaticClass(), TEXT("CameraLagSpeed"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_CameraRotationLagSpeed(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SpringArmComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SpringArmComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USpringArmComponent::StaticClass(), TEXT("CameraRotationLagSpeed"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_CameraRotationLagSpeed(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SpringArmComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SpringArmComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USpringArmComponent::StaticClass(), TEXT("CameraRotationLagSpeed"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_CameraLagMaxTimeStep(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SpringArmComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SpringArmComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USpringArmComponent::StaticClass(), TEXT("CameraLagMaxTimeStep"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_CameraLagMaxTimeStep(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SpringArmComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SpringArmComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USpringArmComponent::StaticClass(), TEXT("CameraLagMaxTimeStep"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_CameraLagMaxDistance(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SpringArmComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SpringArmComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USpringArmComponent::StaticClass(), TEXT("CameraLagMaxDistance"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_CameraLagMaxDistance(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SpringArmComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SpringArmComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USpringArmComponent::StaticClass(), TEXT("CameraLagMaxDistance"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 New(lua_State* InScriptContext)
{
	UObject* Outer = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Object");
	FName Name = FName(luaL_checkstring(InScriptContext, 2));
	UObject* Obj = NewObject<USpringArmComponent>(Outer, Name);
	wLua::FLuaUtils::ReturnUObject(InScriptContext,Obj);
	return 1;
}

int32 Destroy(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SpringArmComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SpringArmComponent must be non-null"); lua_error(InScriptContext);  return 0;}
		UActorComponent * com = Cast<UActorComponent>(Obj);
		if(lua_isnoneornil(InScriptContext,2))
			com->DestroyComponent();
		else
			com->DestroyComponent(!!lua_toboolean(InScriptContext,2));
		userdata->flag |= wLua::LuaObjectFlag::DESTROYED;
		wLua::FLuaUtils::RemoveObjectReference(Obj, userdata->stamp, InScriptContext);
#ifdef AZURE_BUILD_WLUACHECK
		UE_LOG(LogAzure, Warning, TEXT("Destroy SpringArmComponent: %x userdata:%x   stamp:%x"),Obj,userdata,userdata->stamp);
#endif
	return 0;
}

int32 Class(lua_State* InScriptContext)
{
	UClass* Class = USpringArmComponent::StaticClass();
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Class);
	return 1;
}

const luaL_Reg Lib_Funcs[] =
{
	{ "New", New },
	{ "Destroy", Destroy },
	{ "Class", Class },
	{ "IsCollisionFixApplied", IsCollisionFixApplied },
	{ "GetUnfixedCameraPosition", GetUnfixedCameraPosition },
	{ "GetTargetRotation", GetTargetRotation },
	{ "Get_TargetArmLength", Get_TargetArmLength },
	{ "Set_TargetArmLength", Set_TargetArmLength },
	{ "Get_SocketOffset", Get_SocketOffset },
	{ "Set_SocketOffset", Set_SocketOffset },
	{ "Get_TargetOffset", Get_TargetOffset },
	{ "Set_TargetOffset", Set_TargetOffset },
	{ "Get_ProbeSize", Get_ProbeSize },
	{ "Set_ProbeSize", Set_ProbeSize },
	{ "Get_ProbeChannel", Get_ProbeChannel },
	{ "Set_ProbeChannel", Set_ProbeChannel },
	{ "Get_bDoCollisionTest", Get_bDoCollisionTest },
	{ "Set_bDoCollisionTest", Set_bDoCollisionTest },
	{ "Get_bUsePawnControlRotation", Get_bUsePawnControlRotation },
	{ "Set_bUsePawnControlRotation", Set_bUsePawnControlRotation },
	{ "Get_bInheritPitch", Get_bInheritPitch },
	{ "Set_bInheritPitch", Set_bInheritPitch },
	{ "Get_bInheritYaw", Get_bInheritYaw },
	{ "Set_bInheritYaw", Set_bInheritYaw },
	{ "Get_bInheritRoll", Get_bInheritRoll },
	{ "Set_bInheritRoll", Set_bInheritRoll },
	{ "Get_bEnableCameraLag", Get_bEnableCameraLag },
	{ "Set_bEnableCameraLag", Set_bEnableCameraLag },
	{ "Get_bEnableCameraRotationLag", Get_bEnableCameraRotationLag },
	{ "Set_bEnableCameraRotationLag", Set_bEnableCameraRotationLag },
	{ "Get_bUseCameraLagSubstepping", Get_bUseCameraLagSubstepping },
	{ "Set_bUseCameraLagSubstepping", Set_bUseCameraLagSubstepping },
	{ "Get_bDrawDebugLagMarkers", Get_bDrawDebugLagMarkers },
	{ "Set_bDrawDebugLagMarkers", Set_bDrawDebugLagMarkers },
	{ "Get_CameraLagSpeed", Get_CameraLagSpeed },
	{ "Set_CameraLagSpeed", Set_CameraLagSpeed },
	{ "Get_CameraRotationLagSpeed", Get_CameraRotationLagSpeed },
	{ "Set_CameraRotationLagSpeed", Set_CameraRotationLagSpeed },
	{ "Get_CameraLagMaxTimeStep", Get_CameraLagMaxTimeStep },
	{ "Set_CameraLagMaxTimeStep", Set_CameraLagMaxTimeStep },
	{ "Get_CameraLagMaxDistance", Get_CameraLagMaxDistance },
	{ "Set_CameraLagMaxDistance", Set_CameraLagMaxDistance },
	{ "is_nil", wLua::LuaStatic::isnil },
	{ "__gc", wLua::LuaStatic::removeUClassFrameCache },
	{ NULL, NULL }
};

void Register(lua_State *InScriptContext)
{
	lua_newtable(InScriptContext);
	luaL_register(InScriptContext, NULL, Lib_Funcs);
	AzureHelpFuncs::AuxRegister(InScriptContext, "SpringArmComponent");
}
void SetMtLink(lua_State *InScriptContext)
{
	AzureHelpFuncs::AuxSetMtLink(InScriptContext, "SpringArmComponent", "SceneComponent",USERDATATYPE_UOBJECT);
}

}