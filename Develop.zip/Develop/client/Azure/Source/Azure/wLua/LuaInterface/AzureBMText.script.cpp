#include "Azure.h"
#include "Utility/help_funcs.h"
#include "wLua/UObjectHeaders.h"
#include "AzureBMText.h"
#include "AzureLuaIntegration.h"

namespace LuaAzureBMText
{
int32 StopRolling(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureBMText",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureBMText must be non-null"); lua_error(InScriptContext);  return 0;}
#if UE_GAME
	UAzureBMText * This = (UAzureBMText *)Obj;
	This->StopRolling();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("StopRolling"));
	if(!Function) { check(false); return 0;}
	Obj->ProcessEvent(Function, NULL);
#endif
	return 0;
}

int32 SetText(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureBMText",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureBMText must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FString InText;
	} Params;
	Params.InText = UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 2));
#if UE_GAME
	UAzureBMText * This = (UAzureBMText *)Obj;
	This->SetText(Params.InText);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetText"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FString*)(params.GetStructMemory() + 0) = Params.InText;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.InText = *(FString*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetOpacity(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureBMText",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureBMText must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float InOpacity;
	} Params;
	Params.InOpacity = (float)(luaL_checknumber(InScriptContext, 2));
#if UE_GAME
	UAzureBMText * This = (UAzureBMText *)Obj;
	This->SetOpacity(Params.InOpacity);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetOpacity"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(float*)(params.GetStructMemory() + 0) = Params.InOpacity;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.InOpacity = *(float*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetLineOffset(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureBMText",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureBMText must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FVector2D InLineOffset;
	} Params;
	Params.InLineOffset = (wLua::FLuaVector2D::Get(InScriptContext, 2));
#if UE_GAME
	UAzureBMText * This = (UAzureBMText *)Obj;
	This->SetLineOffset(Params.InLineOffset);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetLineOffset"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FVector2D*)(params.GetStructMemory() + 0) = Params.InLineOffset;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.InLineOffset = *(FVector2D*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetFontSize(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureBMText",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureBMText must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		int32 InSize;
	} Params;
	Params.InSize = (luaL_checkint(InScriptContext, 2));
#if UE_GAME
	UAzureBMText * This = (UAzureBMText *)Obj;
	This->SetFontSize(Params.InSize);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetFontSize"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(int32*)(params.GetStructMemory() + 0) = Params.InSize;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.InSize = *(int32*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetColorAndOpacity(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureBMText",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureBMText must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FLinearColor InColorAndOpacity;
	} Params;
	Params.InColorAndOpacity = (wLua::FLuaLinearColor::Get(InScriptContext, 2));
#if UE_GAME
	UAzureBMText * This = (UAzureBMText *)Obj;
	This->SetColorAndOpacity(Params.InColorAndOpacity);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetColorAndOpacity"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FLinearColor*)(params.GetStructMemory() + 0) = Params.InColorAndOpacity;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.InColorAndOpacity = *(FLinearColor*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetBMFont(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureBMText",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureBMText must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		UAzureBMFont* InBMFont = nullptr;
	} Params;
	Params.InBMFont = (UAzureBMFont*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"AzureBMFont");;
#if UE_GAME
	UAzureBMText * This = (UAzureBMText *)Obj;
	This->SetBMFont(Params.InBMFont);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetBMFont"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(UAzureBMFont**)(params.GetStructMemory() + 0) = Params.InBMFont;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.InBMFont = *(UAzureBMFont**)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 PlayRolling(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureBMText",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureBMText must be non-null"); lua_error(InScriptContext);  return 0;}
#if UE_GAME
	UAzureBMText * This = (UAzureBMText *)Obj;
	This->PlayRolling();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("PlayRolling"));
	if(!Function) { check(false); return 0;}
	Obj->ProcessEvent(Function, NULL);
#endif
	return 0;
}

int32 IsRolling(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureBMText",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureBMText must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool ReturnValue;
	} Params;
#if UE_GAME
	UAzureBMText * This = (UAzureBMText *)Obj;
	Params.ReturnValue = This->IsRolling();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("IsRolling"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushboolean(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 Get_Text(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureBMText",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureBMText must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzureBMText::StaticClass(), TEXT("Text"));
	if(!Property) { check(false); return 0;}
	FString PropertyValue;
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushstring(InScriptContext, TCHAR_TO_UTF8(*PropertyValue));
	return 1;
}

int32 Get_BMFont(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureBMText",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureBMText must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzureBMText::StaticClass(), TEXT("BMFont"));
	if(!Property) { check(false); return 0;}
	UAzureBMFont* PropertyValue;
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaUtils::ReturnUObject(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_FontSize(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureBMText",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureBMText must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzureBMText::StaticClass(), TEXT("FontSize"));
	if(!Property) { check(false); return 0;}
	int32 PropertyValue = int32();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushinteger(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_LineOffset(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureBMText",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureBMText must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzureBMText::StaticClass(), TEXT("LineOffset"));
	if(!Property) { check(false); return 0;}
	FVector2D PropertyValue = FVector2D();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaVector2D::Return(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_ColorAndOpacity(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureBMText",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureBMText must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzureBMText::StaticClass(), TEXT("ColorAndOpacity"));
	if(!Property) { check(false); return 0;}
	FLinearColor PropertyValue = FLinearColor();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaLinearColor::Return(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_bUseRolling(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureBMText",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureBMText must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzureBMText::StaticClass(), TEXT("bUseRolling"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = bool();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_bAutoRolling(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureBMText",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureBMText must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzureBMText::StaticClass(), TEXT("bAutoRolling"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = bool();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 New(lua_State* InScriptContext)
{
	UObject* Outer = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Object");
	FName Name = FName(luaL_checkstring(InScriptContext, 2));
	UObject* Obj = NewObject<UAzureBMText>(Outer, Name);
	wLua::FLuaUtils::ReturnUObject(InScriptContext,Obj);
	return 1;
}

int32 Destroy(lua_State* InScriptContext)
{
	return 0;
}

int32 Class(lua_State* InScriptContext)
{
	UClass* Class = UAzureBMText::StaticClass();
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Class);
	return 1;
}

const luaL_Reg Lib_Funcs[] =
{
	{ "New", New },
	{ "Destroy", Destroy },
	{ "Class", Class },
	{ "StopRolling", StopRolling },
	{ "SetText", SetText },
	{ "SetOpacity", SetOpacity },
	{ "SetLineOffset", SetLineOffset },
	{ "SetFontSize", SetFontSize },
	{ "SetColorAndOpacity", SetColorAndOpacity },
	{ "SetBMFont", SetBMFont },
	{ "PlayRolling", PlayRolling },
	{ "IsRolling", IsRolling },
	{ "Get_Text", Get_Text },
	{ "Get_BMFont", Get_BMFont },
	{ "Get_FontSize", Get_FontSize },
	{ "Get_LineOffset", Get_LineOffset },
	{ "Get_ColorAndOpacity", Get_ColorAndOpacity },
	{ "Get_bUseRolling", Get_bUseRolling },
	{ "Get_bAutoRolling", Get_bAutoRolling },
	{ "is_nil", wLua::LuaStatic::isnil },
	{ "__gc", wLua::LuaStatic::removeUClassFrameCache },
	{ NULL, NULL }
};

void Register(lua_State *InScriptContext)
{
	lua_newtable(InScriptContext);
	luaL_register(InScriptContext, NULL, Lib_Funcs);
	AzureHelpFuncs::AuxRegister(InScriptContext, "AzureBMText");
}
void SetMtLink(lua_State *InScriptContext)
{
	AzureHelpFuncs::AuxSetMtLink(InScriptContext, "AzureBMText", "Widget",USERDATATYPE_UOBJECT);
}

}