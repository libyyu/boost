#include "Azure.h"
#include "Utility/help_funcs.h"
#include "wLua/UObjectHeaders.h"
#include "Engine/ExponentialHeightFog.h"
#include "AzureLuaIntegration.h"

namespace LuaExponentialHeightFog
{
int32 OnRep_bEnabled(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ExponentialHeightFog",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ExponentialHeightFog must be non-null"); lua_error(InScriptContext);  return 0;}
#if UE_GAME
	AExponentialHeightFog * This = (AExponentialHeightFog *)Obj;
	This->OnRep_bEnabled();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("OnRep_bEnabled"));
	if(!Function) { check(false); return 0;}
	Obj->ProcessEvent(Function, NULL);
#endif
	return 0;
}

int32 Get_Component(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ExponentialHeightFog",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ExponentialHeightFog must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AExponentialHeightFog::StaticClass(), TEXT("Component"));
	if(!Property) { check(false); return 0;}
	UExponentialHeightFogComponent* PropertyValue;
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaUtils::ReturnUObject(InScriptContext, PropertyValue);
	return 1;
}

int32 New(lua_State* InScriptContext)
{
	UObject* Outer = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Object");
	FName Name = FName(luaL_checkstring(InScriptContext, 2));
	UObject* Obj = NewObject<AExponentialHeightFog>(Outer, Name);
	wLua::FLuaUtils::ReturnUObject(InScriptContext,Obj);
	return 1;
}

int32 Destroy(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ExponentialHeightFog",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ExponentialHeightFog must be non-null"); lua_error(InScriptContext);  return 0;}
		AActor * actor = Cast<AActor>(Obj);
		actor->Destroy();
		userdata->flag |= wLua::LuaObjectFlag::DESTROYED;
		wLua::FLuaUtils::RemoveObjectReference(Obj, userdata->stamp, InScriptContext);
#ifdef AZURE_BUILD_WLUACHECK
		UE_LOG(LogAzure, Warning, TEXT("Destroy ExponentialHeightFog: %x userdata:%x   stamp:%x"),Obj,userdata,userdata->stamp);
#endif
	return 0;
}

int32 Class(lua_State* InScriptContext)
{
	UClass* Class = AExponentialHeightFog::StaticClass();
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Class);
	return 1;
}

const luaL_Reg Lib_Funcs[] =
{
	{ "New", New },
	{ "Destroy", Destroy },
	{ "Class", Class },
	{ "OnRep_bEnabled", OnRep_bEnabled },
	{ "Get_Component", Get_Component },
	{ "is_nil", wLua::LuaStatic::isnil },
	{ "__gc", wLua::LuaStatic::removeUClassFrameCache },
	{ NULL, NULL }
};

void Register(lua_State *InScriptContext)
{
	lua_newtable(InScriptContext);
	luaL_register(InScriptContext, NULL, Lib_Funcs);
	AzureHelpFuncs::AuxRegister(InScriptContext, "ExponentialHeightFog");
}
void SetMtLink(lua_State *InScriptContext)
{
	AzureHelpFuncs::AuxSetMtLink(InScriptContext, "ExponentialHeightFog", "Actor",USERDATATYPE_UOBJECT);
}

}