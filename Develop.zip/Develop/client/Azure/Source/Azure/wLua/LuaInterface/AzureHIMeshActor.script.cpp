#include "Azure.h"
#include "Utility/help_funcs.h"
#include "wLua/UObjectHeaders.h"
#include "GameLogic/Home/AzureHIMeshActor.h"
#include "AzureLuaIntegration.h"

namespace LuaAzureHIMeshActor
{
int32 UpdateInstance(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureHIMeshActor",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureHIMeshActor must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		int32 InstanceIndex;
		FTransform NewInstanceTransform;
	} Params;
	Params.InstanceIndex = (luaL_checkint(InScriptContext, 2));
	Params.NewInstanceTransform = (wLua::FLuaTransform::Get(InScriptContext, 3));
#if UE_GAME
	AAzureHIMeshActor * This = (AAzureHIMeshActor *)Obj;
	This->UpdateInstance(Params.InstanceIndex,Params.NewInstanceTransform);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("UpdateInstance"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(int32*)(params.GetStructMemory() + 0) = Params.InstanceIndex;
		*(FTransform*)(params.GetStructMemory() + 16) = Params.NewInstanceTransform;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.InstanceIndex = *(int32*)(params.GetStructMemory() + 0);
		Params.NewInstanceTransform = *(FTransform*)(params.GetStructMemory() + 16);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetStaticMesh(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureHIMeshActor",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureHIMeshActor must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		UStaticMesh* NewMesh = nullptr;
		bool ReturnValue;
	} Params;
	Params.NewMesh = (UStaticMesh*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"StaticMesh");;
#if UE_GAME
	AAzureHIMeshActor * This = (AAzureHIMeshActor *)Obj;
	Params.ReturnValue = This->SetStaticMesh(Params.NewMesh);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetStaticMesh"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(UStaticMesh**)(params.GetStructMemory() + 0) = Params.NewMesh;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.NewMesh = *(UStaticMesh**)(params.GetStructMemory() + 0);
		Params.ReturnValue = *(bool*)(params.GetStructMemory() + 8);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushboolean(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 SetCollisionProfileName(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureHIMeshActor",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureHIMeshActor must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FString ProfileName;
	} Params;
	Params.ProfileName = UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 2));
#if UE_GAME
	AAzureHIMeshActor * This = (AAzureHIMeshActor *)Obj;
	This->SetCollisionProfileName(Params.ProfileName);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetCollisionProfileName"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FString*)(params.GetStructMemory() + 0) = Params.ProfileName;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ProfileName = *(FString*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 RemoveInstance(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureHIMeshActor",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureHIMeshActor must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		int32 InstanceIndex;
	} Params;
	Params.InstanceIndex = (luaL_checkint(InScriptContext, 2));
#if UE_GAME
	AAzureHIMeshActor * This = (AAzureHIMeshActor *)Obj;
	This->RemoveInstance(Params.InstanceIndex);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("RemoveInstance"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(int32*)(params.GetStructMemory() + 0) = Params.InstanceIndex;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.InstanceIndex = *(int32*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 GetStaticMesh(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureHIMeshActor",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureHIMeshActor must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		UStaticMesh* ReturnValue = nullptr;
	} Params;
#if UE_GAME
	AAzureHIMeshActor * This = (AAzureHIMeshActor *)Obj;
	Params.ReturnValue = This->GetStaticMesh();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetStaticMesh"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(UStaticMesh**)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetHIMComponent(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureHIMeshActor",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureHIMeshActor must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		UHierarchicalInstancedStaticMeshComponent* ReturnValue = nullptr;
	} Params;
#if UE_GAME
	AAzureHIMeshActor * This = (AAzureHIMeshActor *)Obj;
	Params.ReturnValue = This->GetHIMComponent();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetHIMComponent"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(UHierarchicalInstancedStaticMeshComponent**)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 ClearInstances(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureHIMeshActor",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureHIMeshActor must be non-null"); lua_error(InScriptContext);  return 0;}
#if UE_GAME
	AAzureHIMeshActor * This = (AAzureHIMeshActor *)Obj;
	This->ClearInstances();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("ClearInstances"));
	if(!Function) { check(false); return 0;}
	Obj->ProcessEvent(Function, NULL);
#endif
	return 0;
}

int32 AddInstance(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureHIMeshActor",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureHIMeshActor must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FTransform InstanceTransform;
		int32 ReturnValue;
	} Params;
	Params.InstanceTransform = (wLua::FLuaTransform::Get(InScriptContext, 2));
#if UE_GAME
	AAzureHIMeshActor * This = (AAzureHIMeshActor *)Obj;
	Params.ReturnValue = This->AddInstance(Params.InstanceTransform);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("AddInstance"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FTransform*)(params.GetStructMemory() + 0) = Params.InstanceTransform;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.InstanceTransform = *(FTransform*)(params.GetStructMemory() + 0);
		Params.ReturnValue = *(int32*)(params.GetStructMemory() + 48);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushinteger(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 New(lua_State* InScriptContext)
{
	UObject* Outer = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Object");
	FName Name = FName(luaL_checkstring(InScriptContext, 2));
	UObject* Obj = NewObject<AAzureHIMeshActor>(Outer, Name);
	wLua::FLuaUtils::ReturnUObject(InScriptContext,Obj);
	return 1;
}

int32 Destroy(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureHIMeshActor",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureHIMeshActor must be non-null"); lua_error(InScriptContext);  return 0;}
		AActor * actor = Cast<AActor>(Obj);
		actor->Destroy();
		userdata->flag |= wLua::LuaObjectFlag::DESTROYED;
		wLua::FLuaUtils::RemoveObjectReference(Obj, userdata->stamp, InScriptContext);
#ifdef AZURE_BUILD_WLUACHECK
		UE_LOG(LogAzure, Warning, TEXT("Destroy AzureHIMeshActor: %x userdata:%x   stamp:%x"),Obj,userdata,userdata->stamp);
#endif
	return 0;
}

int32 Class(lua_State* InScriptContext)
{
	UClass* Class = AAzureHIMeshActor::StaticClass();
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Class);
	return 1;
}

const luaL_Reg Lib_Funcs[] =
{
	{ "New", New },
	{ "Destroy", Destroy },
	{ "Class", Class },
	{ "UpdateInstance", UpdateInstance },
	{ "SetStaticMesh", SetStaticMesh },
	{ "SetCollisionProfileName", SetCollisionProfileName },
	{ "RemoveInstance", RemoveInstance },
	{ "GetStaticMesh", GetStaticMesh },
	{ "GetHIMComponent", GetHIMComponent },
	{ "ClearInstances", ClearInstances },
	{ "AddInstance", AddInstance },
	{ "is_nil", wLua::LuaStatic::isnil },
	{ "__gc", wLua::LuaStatic::removeUClassFrameCache },
	{ NULL, NULL }
};

void Register(lua_State *InScriptContext)
{
	lua_newtable(InScriptContext);
	luaL_register(InScriptContext, NULL, Lib_Funcs);
	AzureHelpFuncs::AuxRegister(InScriptContext, "AzureHIMeshActor");
}
void SetMtLink(lua_State *InScriptContext)
{
	AzureHelpFuncs::AuxSetMtLink(InScriptContext, "AzureHIMeshActor", "Actor",USERDATATYPE_UOBJECT);
}

}