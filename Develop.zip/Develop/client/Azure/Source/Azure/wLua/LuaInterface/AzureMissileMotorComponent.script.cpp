#include "Azure.h"
#include "Utility/help_funcs.h"
#include "wLua/UObjectHeaders.h"
#include "AzureMissileMotorComponent.h"
#include "AzureLuaIntegration.h"

namespace LuaAzureMissileMotorComponent
{
int32 StartMove(lua_State*);

int32 SetExtraParam(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureMissileMotorComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureMissileMotorComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float _fRotSpeed;
		float _fAngleSpeedDown;
		float _fAngleToTarget;
		float _fDistToTarget;
	} Params;
	Params._fRotSpeed = (float)(luaL_checknumber(InScriptContext, 2));
	Params._fAngleSpeedDown = (float)(luaL_checknumber(InScriptContext, 3));
	Params._fAngleToTarget = (float)(luaL_checknumber(InScriptContext, 4));
	Params._fDistToTarget = (float)(luaL_checknumber(InScriptContext, 5));
#if UE_GAME
	UAzureMissileMotorComponent * This = (UAzureMissileMotorComponent *)Obj;
	This->SetExtraParam(Params._fRotSpeed,Params._fAngleSpeedDown,Params._fAngleToTarget,Params._fDistToTarget);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetExtraParam"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(float*)(params.GetStructMemory() + 0) = Params._fRotSpeed;
		*(float*)(params.GetStructMemory() + 4) = Params._fAngleSpeedDown;
		*(float*)(params.GetStructMemory() + 8) = Params._fAngleToTarget;
		*(float*)(params.GetStructMemory() + 12) = Params._fDistToTarget;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params._fRotSpeed = *(float*)(params.GetStructMemory() + 0);
		Params._fAngleSpeedDown = *(float*)(params.GetStructMemory() + 4);
		Params._fAngleToTarget = *(float*)(params.GetStructMemory() + 8);
		Params._fDistToTarget = *(float*)(params.GetStructMemory() + 12);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 New(lua_State* InScriptContext)
{
	UObject* Outer = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Object");
	FName Name = FName(luaL_checkstring(InScriptContext, 2));
	UObject* Obj = NewObject<UAzureMissileMotorComponent>(Outer, Name);
	wLua::FLuaUtils::ReturnUObject(InScriptContext,Obj);
	return 1;
}

int32 Destroy(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureMissileMotorComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureMissileMotorComponent must be non-null"); lua_error(InScriptContext);  return 0;}
		UActorComponent * com = Cast<UActorComponent>(Obj);
		if(lua_isnoneornil(InScriptContext,2))
			com->DestroyComponent();
		else
			com->DestroyComponent(!!lua_toboolean(InScriptContext,2));
		userdata->flag |= wLua::LuaObjectFlag::DESTROYED;
		wLua::FLuaUtils::RemoveObjectReference(Obj, userdata->stamp, InScriptContext);
#ifdef AZURE_BUILD_WLUACHECK
		UE_LOG(LogAzure, Warning, TEXT("Destroy AzureMissileMotorComponent: %x userdata:%x   stamp:%x"),Obj,userdata,userdata->stamp);
#endif
	return 0;
}

int32 Class(lua_State* InScriptContext)
{
	UClass* Class = UAzureMissileMotorComponent::StaticClass();
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Class);
	return 1;
}

const luaL_Reg Lib_Funcs[] =
{
	{ "New", New },
	{ "Destroy", Destroy },
	{ "Class", Class },
	{ "SetExtraParam", SetExtraParam },
	{ "StartMove", StartMove },
	{ "is_nil", wLua::LuaStatic::isnil },
	{ "__gc", wLua::LuaStatic::removeUClassFrameCache },
	{ NULL, NULL }
};

void Register(lua_State *InScriptContext)
{
	lua_newtable(InScriptContext);
	luaL_register(InScriptContext, NULL, Lib_Funcs);
	AzureHelpFuncs::AuxRegister(InScriptContext, "AzureMissileMotorComponent");
}
void SetMtLink(lua_State *InScriptContext)
{
	AzureHelpFuncs::AuxSetMtLink(InScriptContext, "AzureMissileMotorComponent", "AzureMotorComponent",USERDATATYPE_UOBJECT);
}

}