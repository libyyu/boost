#include "Azure.h"
#include "Utility/help_funcs.h"
#include "wLua/UObjectHeaders.h"
#include "GameLogic/Player/MotorVehicleCharacter.h"
#include "../UClassHeaders.h"
#include "AzureLuaIntegration.h"

namespace LuaMotorVehicleCharacter
{
int32 SetMovePhaseParamsEx(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MotorVehicleCharacter",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MotorVehicleCharacter must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		int32 phaseIndex;
		float maxSpeed;
		float acceleration;
		float turnMaxSpeed;
		float turnAcceleration;
		float turnMaxAngle;
	} Params;
	Params.phaseIndex = (luaL_checkint(InScriptContext, 2));
	Params.maxSpeed = (float)(luaL_checknumber(InScriptContext, 3));
	Params.acceleration = (float)(luaL_checknumber(InScriptContext, 4));
	Params.turnMaxSpeed = (float)(luaL_checknumber(InScriptContext, 5));
	Params.turnAcceleration = (float)(luaL_checknumber(InScriptContext, 6));
	Params.turnMaxAngle = (float)(luaL_checknumber(InScriptContext, 7));
#if UE_GAME
	AMotorVehicleCharacter * This = (AMotorVehicleCharacter *)Obj;
	This->SetMovePhaseParamsEx(Params.phaseIndex,Params.maxSpeed,Params.acceleration,Params.turnMaxSpeed,Params.turnAcceleration,Params.turnMaxAngle);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetMovePhaseParamsEx"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(int32*)(params.GetStructMemory() + 0) = Params.phaseIndex;
		*(float*)(params.GetStructMemory() + 4) = Params.maxSpeed;
		*(float*)(params.GetStructMemory() + 8) = Params.acceleration;
		*(float*)(params.GetStructMemory() + 12) = Params.turnMaxSpeed;
		*(float*)(params.GetStructMemory() + 16) = Params.turnAcceleration;
		*(float*)(params.GetStructMemory() + 20) = Params.turnMaxAngle;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.phaseIndex = *(int32*)(params.GetStructMemory() + 0);
		Params.maxSpeed = *(float*)(params.GetStructMemory() + 4);
		Params.acceleration = *(float*)(params.GetStructMemory() + 8);
		Params.turnMaxSpeed = *(float*)(params.GetStructMemory() + 12);
		Params.turnAcceleration = *(float*)(params.GetStructMemory() + 16);
		Params.turnMaxAngle = *(float*)(params.GetStructMemory() + 20);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetAcceleratorOpenState(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MotorVehicleCharacter",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MotorVehicleCharacter must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool open;
	} Params;
	Params.open = !!(lua_toboolean(InScriptContext, 2));
#if UE_GAME
	AMotorVehicleCharacter * This = (AMotorVehicleCharacter *)Obj;
	This->SetAcceleratorOpenState(Params.open);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetAcceleratorOpenState"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(bool*)(params.GetStructMemory() + 0) = Params.open;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.open = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 GetJoystickControlState(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MotorVehicleCharacter",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MotorVehicleCharacter must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		int32 ReturnValue;
	} Params;
#if UE_GAME
	AMotorVehicleCharacter * This = (AMotorVehicleCharacter *)Obj;
	Params.ReturnValue = This->GetJoystickControlState();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetJoystickControlState"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(int32*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushinteger(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 EnableBrake(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MotorVehicleCharacter",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MotorVehicleCharacter must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool enable;
	} Params;
	Params.enable = !!(lua_toboolean(InScriptContext, 2));
#if UE_GAME
	AMotorVehicleCharacter * This = (AMotorVehicleCharacter *)Obj;
	This->EnableBrake(Params.enable);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("EnableBrake"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(bool*)(params.GetStructMemory() + 0) = Params.enable;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.enable = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 Get_turnBackToForwardAcceleration(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MotorVehicleCharacter",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MotorVehicleCharacter must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AMotorVehicleCharacter::StaticClass(), TEXT("turnBackToForwardAcceleration"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_turnBackToForwardAcceleration(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MotorVehicleCharacter",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MotorVehicleCharacter must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AMotorVehicleCharacter::StaticClass(), TEXT("turnBackToForwardAcceleration"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_moveExtraAddAngle(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MotorVehicleCharacter",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MotorVehicleCharacter must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AMotorVehicleCharacter::StaticClass(), TEXT("moveExtraAddAngle"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_moveExtraAddAngle(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MotorVehicleCharacter",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MotorVehicleCharacter must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AMotorVehicleCharacter::StaticClass(), TEXT("moveExtraAddAngle"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_separateTurnMoveMode(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MotorVehicleCharacter",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MotorVehicleCharacter must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AMotorVehicleCharacter::StaticClass(), TEXT("separateTurnMoveMode"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = bool();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_separateTurnMoveMode(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MotorVehicleCharacter",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MotorVehicleCharacter must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AMotorVehicleCharacter::StaticClass(), TEXT("separateTurnMoveMode"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_canBackwardsMove(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MotorVehicleCharacter",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MotorVehicleCharacter must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AMotorVehicleCharacter::StaticClass(), TEXT("canBackwardsMove"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = bool();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_canBackwardsMove(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MotorVehicleCharacter",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MotorVehicleCharacter must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AMotorVehicleCharacter::StaticClass(), TEXT("canBackwardsMove"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_moveSpeed2TurnSpeedRate(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MotorVehicleCharacter",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MotorVehicleCharacter must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AMotorVehicleCharacter::StaticClass(), TEXT("moveSpeed2TurnSpeedRate"));
	if(!Property) { check(false); return 0;}
	UCurveFloat* PropertyValue;
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaUtils::ReturnUObject(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_moveSpeed2TurnSpeedRate(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MotorVehicleCharacter",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MotorVehicleCharacter must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AMotorVehicleCharacter::StaticClass(), TEXT("moveSpeed2TurnSpeedRate"));
	if(!Property) { check(false); return 0;}
	UCurveFloat* PropertyValue = (UCurveFloat*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"CurveFloat");;
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_triggerTurnJoystickAngleRange(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MotorVehicleCharacter",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MotorVehicleCharacter must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AMotorVehicleCharacter::StaticClass(), TEXT("triggerTurnJoystickAngleRange"));
	if(!Property) { check(false); return 0;}
	FVector2D PropertyValue = FVector2D();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaVector2D::Return(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_triggerTurnJoystickAngleRange(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MotorVehicleCharacter",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MotorVehicleCharacter must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AMotorVehicleCharacter::StaticClass(), TEXT("triggerTurnJoystickAngleRange"));
	if(!Property) { check(false); return 0;}
	FVector2D PropertyValue = (wLua::FLuaVector2D::Get(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_triggerMoveJoystickAngleRange(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MotorVehicleCharacter",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MotorVehicleCharacter must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AMotorVehicleCharacter::StaticClass(), TEXT("triggerMoveJoystickAngleRange"));
	if(!Property) { check(false); return 0;}
	FVector2D PropertyValue = FVector2D();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaVector2D::Return(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_triggerMoveJoystickAngleRange(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MotorVehicleCharacter",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MotorVehicleCharacter must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AMotorVehicleCharacter::StaticClass(), TEXT("triggerMoveJoystickAngleRange"));
	if(!Property) { check(false); return 0;}
	FVector2D PropertyValue = (wLua::FLuaVector2D::Get(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 New(lua_State* InScriptContext)
{
	UObject* Outer = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Object");
	FName Name = FName(luaL_checkstring(InScriptContext, 2));
	UObject* Obj = NewObject<AMotorVehicleCharacter>(Outer, Name);
	wLua::FLuaUtils::ReturnUObject(InScriptContext,Obj);
	return 1;
}

int32 Destroy(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MotorVehicleCharacter",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MotorVehicleCharacter must be non-null"); lua_error(InScriptContext);  return 0;}
		AActor * actor = Cast<AActor>(Obj);
		actor->Destroy();
		userdata->flag |= wLua::LuaObjectFlag::DESTROYED;
		wLua::FLuaUtils::RemoveObjectReference(Obj, userdata->stamp, InScriptContext);
#ifdef AZURE_BUILD_WLUACHECK
		UE_LOG(LogAzure, Warning, TEXT("Destroy MotorVehicleCharacter: %x userdata:%x   stamp:%x"),Obj,userdata,userdata->stamp);
#endif
	return 0;
}

int32 Class(lua_State* InScriptContext)
{
	UClass* Class = AMotorVehicleCharacter::StaticClass();
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Class);
	return 1;
}

const luaL_Reg Lib_Funcs[] =
{
	{ "New", New },
	{ "Destroy", Destroy },
	{ "Class", Class },
	{ "SetMovePhaseParamsEx", SetMovePhaseParamsEx },
	{ "SetAcceleratorOpenState", SetAcceleratorOpenState },
	{ "GetJoystickControlState", GetJoystickControlState },
	{ "EnableBrake", EnableBrake },
	{ "Get_turnBackToForwardAcceleration", Get_turnBackToForwardAcceleration },
	{ "Set_turnBackToForwardAcceleration", Set_turnBackToForwardAcceleration },
	{ "Get_moveExtraAddAngle", Get_moveExtraAddAngle },
	{ "Set_moveExtraAddAngle", Set_moveExtraAddAngle },
	{ "Get_separateTurnMoveMode", Get_separateTurnMoveMode },
	{ "Set_separateTurnMoveMode", Set_separateTurnMoveMode },
	{ "Get_canBackwardsMove", Get_canBackwardsMove },
	{ "Set_canBackwardsMove", Set_canBackwardsMove },
	{ "Get_moveSpeed2TurnSpeedRate", Get_moveSpeed2TurnSpeedRate },
	{ "Set_moveSpeed2TurnSpeedRate", Set_moveSpeed2TurnSpeedRate },
	{ "Get_triggerTurnJoystickAngleRange", Get_triggerTurnJoystickAngleRange },
	{ "Set_triggerTurnJoystickAngleRange", Set_triggerTurnJoystickAngleRange },
	{ "Get_triggerMoveJoystickAngleRange", Get_triggerMoveJoystickAngleRange },
	{ "Set_triggerMoveJoystickAngleRange", Set_triggerMoveJoystickAngleRange },
	{ "is_nil", wLua::LuaStatic::isnil },
	{ "__gc", wLua::LuaStatic::removeUClassFrameCache },
	{ NULL, NULL }
};

void Register(lua_State *InScriptContext)
{
	lua_newtable(InScriptContext);
	luaL_register(InScriptContext, NULL, Lib_Funcs);
	AzureHelpFuncs::AuxRegister(InScriptContext, "MotorVehicleCharacter");
}
void SetMtLink(lua_State *InScriptContext)
{
	AzureHelpFuncs::AuxSetMtLink(InScriptContext, "MotorVehicleCharacter", "VehicleCharacter",USERDATATYPE_UOBJECT);
}

}