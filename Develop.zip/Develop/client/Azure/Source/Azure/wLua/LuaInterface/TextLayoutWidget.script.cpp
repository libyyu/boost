#include "Azure.h"
#include "Utility/help_funcs.h"
#include "wLua/UObjectHeaders.h"
#include "AzureLuaIntegration.h"

namespace LuaTextLayoutWidget
{
int32 Get_Justification(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"TextLayoutWidget",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"TextLayoutWidget must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UTextLayoutWidget::StaticClass(), TEXT("Justification"));
	if(!Property) { check(false); return 0;}
	TEnumAsByte<ETextJustify::Type> PropertyValue = TEnumAsByte<ETextJustify::Type>();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushinteger(InScriptContext, (int)PropertyValue);
	return 1;
}

int32 Set_Justification(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"TextLayoutWidget",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"TextLayoutWidget must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UTextLayoutWidget::StaticClass(), TEXT("Justification"));
	if(!Property) { check(false); return 0;}
	TEnumAsByte<ETextJustify::Type> PropertyValue = (TEnumAsByte<ETextJustify::Type>)(luaL_checkint(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_WrappingPolicy(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"TextLayoutWidget",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"TextLayoutWidget must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UTextLayoutWidget::StaticClass(), TEXT("WrappingPolicy"));
	if(!Property) { check(false); return 0;}
	ETextWrappingPolicy PropertyValue = ETextWrappingPolicy();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushinteger(InScriptContext, (int)PropertyValue);
	return 1;
}

int32 Get_AutoWrapText(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"TextLayoutWidget",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"TextLayoutWidget must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UTextLayoutWidget::StaticClass(), TEXT("AutoWrapText"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_WrapTextAt(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"TextLayoutWidget",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"TextLayoutWidget must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UTextLayoutWidget::StaticClass(), TEXT("WrapTextAt"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_LineHeightPercentage(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"TextLayoutWidget",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"TextLayoutWidget must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UTextLayoutWidget::StaticClass(), TEXT("LineHeightPercentage"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_LineHeightGap(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"TextLayoutWidget",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"TextLayoutWidget must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UTextLayoutWidget::StaticClass(), TEXT("LineHeightGap"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_bSkipLastLineGap(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"TextLayoutWidget",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"TextLayoutWidget must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UTextLayoutWidget::StaticClass(), TEXT("bSkipLastLineGap"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = bool();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_CharMargin(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"TextLayoutWidget",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"TextLayoutWidget must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UTextLayoutWidget::StaticClass(), TEXT("CharMargin"));
	if(!Property) { check(false); return 0;}
	int32 PropertyValue = int32();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushinteger(InScriptContext, PropertyValue);
	return 1;
}

int32 Class(lua_State* InScriptContext)
{
	UClass* Class = UTextLayoutWidget::StaticClass();
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Class);
	return 1;
}

const luaL_Reg Lib_Funcs[] =
{
	{ "Class", Class },
	{ "Get_Justification", Get_Justification },
	{ "Set_Justification", Set_Justification },
	{ "Get_WrappingPolicy", Get_WrappingPolicy },
	{ "Get_AutoWrapText", Get_AutoWrapText },
	{ "Get_WrapTextAt", Get_WrapTextAt },
	{ "Get_LineHeightPercentage", Get_LineHeightPercentage },
	{ "Get_LineHeightGap", Get_LineHeightGap },
	{ "Get_bSkipLastLineGap", Get_bSkipLastLineGap },
	{ "Get_CharMargin", Get_CharMargin },
	{ "is_nil", wLua::LuaStatic::isnil },
	{ "__gc", wLua::LuaStatic::removeUClassFrameCache },
	{ NULL, NULL }
};

void Register(lua_State *InScriptContext)
{
	lua_newtable(InScriptContext);
	luaL_register(InScriptContext, NULL, Lib_Funcs);
	AzureHelpFuncs::AuxRegister(InScriptContext, "TextLayoutWidget");
}
void SetMtLink(lua_State *InScriptContext)
{
	AzureHelpFuncs::AuxSetMtLink(InScriptContext, "TextLayoutWidget", "Widget",USERDATATYPE_UOBJECT);
}

}