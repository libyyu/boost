#include "Azure.h"
#include "Utility/help_funcs.h"
#include "wLua/UObjectHeaders.h"
#include "Components/Border.h"
#include "AzureLuaIntegration.h"

namespace LuaBorder
{
int32 SetVerticalAlignment(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Border",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Border must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		TEnumAsByte<EVerticalAlignment> InVerticalAlignment;
	} Params;
	Params.InVerticalAlignment = (TEnumAsByte<EVerticalAlignment>)(luaL_checkint(InScriptContext, 2));
#if UE_GAME
	UBorder * This = (UBorder *)Obj;
	This->SetVerticalAlignment(Params.InVerticalAlignment);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetVerticalAlignment"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(TEnumAsByte<EVerticalAlignment>*)(params.GetStructMemory() + 0) = Params.InVerticalAlignment;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.InVerticalAlignment = *(TEnumAsByte<EVerticalAlignment>*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetHorizontalAlignment(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Border",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Border must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		TEnumAsByte<EHorizontalAlignment> InHorizontalAlignment;
	} Params;
	Params.InHorizontalAlignment = (TEnumAsByte<EHorizontalAlignment>)(luaL_checkint(InScriptContext, 2));
#if UE_GAME
	UBorder * This = (UBorder *)Obj;
	This->SetHorizontalAlignment(Params.InHorizontalAlignment);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetHorizontalAlignment"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(TEnumAsByte<EHorizontalAlignment>*)(params.GetStructMemory() + 0) = Params.InHorizontalAlignment;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.InHorizontalAlignment = *(TEnumAsByte<EHorizontalAlignment>*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetDesiredSizeScale(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Border",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Border must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FVector2D InScale;
	} Params;
	Params.InScale = (wLua::FLuaVector2D::Get(InScriptContext, 2));
#if UE_GAME
	UBorder * This = (UBorder *)Obj;
	This->SetDesiredSizeScale(Params.InScale);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetDesiredSizeScale"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FVector2D*)(params.GetStructMemory() + 0) = Params.InScale;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.InScale = *(FVector2D*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetContentColorAndOpacity(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Border",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Border must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FLinearColor InContentColorAndOpacity;
	} Params;
	Params.InContentColorAndOpacity = (wLua::FLuaLinearColor::Get(InScriptContext, 2));
#if UE_GAME
	UBorder * This = (UBorder *)Obj;
	This->SetContentColorAndOpacity(Params.InContentColorAndOpacity);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetContentColorAndOpacity"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FLinearColor*)(params.GetStructMemory() + 0) = Params.InContentColorAndOpacity;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.InContentColorAndOpacity = *(FLinearColor*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetBrushFromTexture(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Border",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Border must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		UTexture2D* Texture = nullptr;
	} Params;
	Params.Texture = (UTexture2D*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"Texture2D");;
#if UE_GAME
	UBorder * This = (UBorder *)Obj;
	This->SetBrushFromTexture(Params.Texture);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetBrushFromTexture"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(UTexture2D**)(params.GetStructMemory() + 0) = Params.Texture;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.Texture = *(UTexture2D**)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetBrushFromMaterial(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Border",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Border must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		UMaterialInterface* Material = nullptr;
	} Params;
	Params.Material = (UMaterialInterface*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"MaterialInterface");;
#if UE_GAME
	UBorder * This = (UBorder *)Obj;
	This->SetBrushFromMaterial(Params.Material);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetBrushFromMaterial"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(UMaterialInterface**)(params.GetStructMemory() + 0) = Params.Material;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.Material = *(UMaterialInterface**)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetBrushFromAsset(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Border",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Border must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		USlateBrushAsset* Asset = nullptr;
	} Params;
	Params.Asset = (USlateBrushAsset*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"SlateBrushAsset");;
#if UE_GAME
	UBorder * This = (UBorder *)Obj;
	This->SetBrushFromAsset(Params.Asset);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetBrushFromAsset"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(USlateBrushAsset**)(params.GetStructMemory() + 0) = Params.Asset;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.Asset = *(USlateBrushAsset**)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetBrushColor(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Border",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Border must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FLinearColor InBrushColor;
	} Params;
	Params.InBrushColor = (wLua::FLuaLinearColor::Get(InScriptContext, 2));
#if UE_GAME
	UBorder * This = (UBorder *)Obj;
	This->SetBrushColor(Params.InBrushColor);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetBrushColor"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FLinearColor*)(params.GetStructMemory() + 0) = Params.InBrushColor;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.InBrushColor = *(FLinearColor*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 GetDynamicMaterial(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Border",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Border must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		UMaterialInstanceDynamic* ReturnValue = nullptr;
	} Params;
#if UE_GAME
	UBorder * This = (UBorder *)Obj;
	Params.ReturnValue = This->GetDynamicMaterial();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetDynamicMaterial"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(UMaterialInstanceDynamic**)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 Get_HorizontalAlignment(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Border",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Border must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UBorder::StaticClass(), TEXT("HorizontalAlignment"));
	if(!Property) { check(false); return 0;}
	TEnumAsByte<EHorizontalAlignment> PropertyValue = TEnumAsByte<EHorizontalAlignment>();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushinteger(InScriptContext, (int)PropertyValue);
	return 1;
}

int32 Get_VerticalAlignment(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Border",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Border must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UBorder::StaticClass(), TEXT("VerticalAlignment"));
	if(!Property) { check(false); return 0;}
	TEnumAsByte<EVerticalAlignment> PropertyValue = TEnumAsByte<EVerticalAlignment>();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushinteger(InScriptContext, (int)PropertyValue);
	return 1;
}

int32 Get_bShowEffectWhenDisabled(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Border",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Border must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UBorder::StaticClass(), TEXT("bShowEffectWhenDisabled"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_ContentColorAndOpacity(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Border",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Border must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UBorder::StaticClass(), TEXT("ContentColorAndOpacity"));
	if(!Property) { check(false); return 0;}
	FLinearColor PropertyValue = FLinearColor();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaLinearColor::Return(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_BrushColor(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Border",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Border must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UBorder::StaticClass(), TEXT("BrushColor"));
	if(!Property) { check(false); return 0;}
	FLinearColor PropertyValue = FLinearColor();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaLinearColor::Return(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_DesiredSizeScale(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Border",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Border must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UBorder::StaticClass(), TEXT("DesiredSizeScale"));
	if(!Property) { check(false); return 0;}
	FVector2D PropertyValue = FVector2D();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaVector2D::Return(InScriptContext, PropertyValue);
	return 1;
}

int32 New(lua_State* InScriptContext)
{
	UObject* Outer = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Object");
	FName Name = FName(luaL_checkstring(InScriptContext, 2));
	UObject* Obj = NewObject<UBorder>(Outer, Name);
	wLua::FLuaUtils::ReturnUObject(InScriptContext,Obj);
	return 1;
}

int32 Destroy(lua_State* InScriptContext)
{
	return 0;
}

int32 Class(lua_State* InScriptContext)
{
	UClass* Class = UBorder::StaticClass();
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Class);
	return 1;
}

const luaL_Reg Lib_Funcs[] =
{
	{ "New", New },
	{ "Destroy", Destroy },
	{ "Class", Class },
	{ "SetVerticalAlignment", SetVerticalAlignment },
	{ "SetHorizontalAlignment", SetHorizontalAlignment },
	{ "SetDesiredSizeScale", SetDesiredSizeScale },
	{ "SetContentColorAndOpacity", SetContentColorAndOpacity },
	{ "SetBrushFromTexture", SetBrushFromTexture },
	{ "SetBrushFromMaterial", SetBrushFromMaterial },
	{ "SetBrushFromAsset", SetBrushFromAsset },
	{ "SetBrushColor", SetBrushColor },
	{ "GetDynamicMaterial", GetDynamicMaterial },
	{ "Get_HorizontalAlignment", Get_HorizontalAlignment },
	{ "Get_VerticalAlignment", Get_VerticalAlignment },
	{ "Get_bShowEffectWhenDisabled", Get_bShowEffectWhenDisabled },
	{ "Get_ContentColorAndOpacity", Get_ContentColorAndOpacity },
	{ "Get_BrushColor", Get_BrushColor },
	{ "Get_DesiredSizeScale", Get_DesiredSizeScale },
	{ "is_nil", wLua::LuaStatic::isnil },
	{ "__gc", wLua::LuaStatic::removeUClassFrameCache },
	{ NULL, NULL }
};

void Register(lua_State *InScriptContext)
{
	lua_newtable(InScriptContext);
	luaL_register(InScriptContext, NULL, Lib_Funcs);
	AzureHelpFuncs::AuxRegister(InScriptContext, "Border");
}
void SetMtLink(lua_State *InScriptContext)
{
	AzureHelpFuncs::AuxSetMtLink(InScriptContext, "Border", "ContentWidget",USERDATATYPE_UOBJECT);
}

}