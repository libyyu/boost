#include "Azure.h"
#include "Utility/help_funcs.h"
#include "wLua/UObjectHeaders.h"
#include "AzureLogTextBox.h"
#include "AzureLuaIntegration.h"

namespace LuaAzureLogTextBox
{
int32 ScrollToEnd(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureLogTextBox",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureLogTextBox must be non-null"); lua_error(InScriptContext);  return 0;}
#if UE_GAME
	UAzureLogTextBox * This = (UAzureLogTextBox *)Obj;
	This->ScrollToEnd();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("ScrollToEnd"));
	if(!Function) { check(false); return 0;}
	Obj->ProcessEvent(Function, NULL);
#endif
	return 0;
}

int32 Clear(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureLogTextBox",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureLogTextBox must be non-null"); lua_error(InScriptContext);  return 0;}
#if UE_GAME
	UAzureLogTextBox * This = (UAzureLogTextBox *)Obj;
	This->Clear();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("Clear"));
	if(!Function) { check(false); return 0;}
	Obj->ProcessEvent(Function, NULL);
#endif
	return 0;
}

int32 AppendText(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureLogTextBox",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureLogTextBox must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FString InText;
	} Params;
	Params.InText = UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 2));
#if UE_GAME
	UAzureLogTextBox * This = (UAzureLogTextBox *)Obj;
	This->AppendText(Params.InText);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("AppendText"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FString*)(params.GetStructMemory() + 0) = Params.InText;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.InText = *(FString*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 Get_AutoScroll(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureLogTextBox",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureLogTextBox must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzureLogTextBox::StaticClass(), TEXT("AutoScroll"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = bool();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_AutoScroll(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureLogTextBox",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureLogTextBox must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzureLogTextBox::StaticClass(), TEXT("AutoScroll"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_HyperlinkDotted(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureLogTextBox",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureLogTextBox must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzureLogTextBox::StaticClass(), TEXT("HyperlinkDotted"));
	if(!Property) { check(false); return 0;}
	UTexture* PropertyValue;
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaUtils::ReturnUObject(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_HyperlinkUnderline(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureLogTextBox",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureLogTextBox must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzureLogTextBox::StaticClass(), TEXT("HyperlinkUnderline"));
	if(!Property) { check(false); return 0;}
	UTexture* PropertyValue;
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaUtils::ReturnUObject(InScriptContext, PropertyValue);
	return 1;
}

int32 New(lua_State* InScriptContext)
{
	UObject* Outer = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Object");
	FName Name = FName(luaL_checkstring(InScriptContext, 2));
	UObject* Obj = NewObject<UAzureLogTextBox>(Outer, Name);
	wLua::FLuaUtils::ReturnUObject(InScriptContext,Obj);
	return 1;
}

int32 Destroy(lua_State* InScriptContext)
{
	return 0;
}

int32 Class(lua_State* InScriptContext)
{
	UClass* Class = UAzureLogTextBox::StaticClass();
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Class);
	return 1;
}

const luaL_Reg Lib_Funcs[] =
{
	{ "New", New },
	{ "Destroy", Destroy },
	{ "Class", Class },
	{ "ScrollToEnd", ScrollToEnd },
	{ "Clear", Clear },
	{ "AppendText", AppendText },
	{ "Get_AutoScroll", Get_AutoScroll },
	{ "Set_AutoScroll", Set_AutoScroll },
	{ "Get_HyperlinkDotted", Get_HyperlinkDotted },
	{ "Get_HyperlinkUnderline", Get_HyperlinkUnderline },
	{ "is_nil", wLua::LuaStatic::isnil },
	{ "__gc", wLua::LuaStatic::removeUClassFrameCache },
	{ NULL, NULL }
};

void Register(lua_State *InScriptContext)
{
	lua_newtable(InScriptContext);
	luaL_register(InScriptContext, NULL, Lib_Funcs);
	AzureHelpFuncs::AuxRegister(InScriptContext, "AzureLogTextBox");
}
void SetMtLink(lua_State *InScriptContext)
{
	AzureHelpFuncs::AuxSetMtLink(InScriptContext, "AzureLogTextBox", "TextLayoutWidget",USERDATATYPE_UOBJECT);
}

}