#include "Azure.h"
#include "Utility/help_funcs.h"
#include "wLua/UObjectHeaders.h"
#include "Components/Slider.h"
#include "AzureLuaIntegration.h"

namespace LuaSlider
{
int32 IsMouseCaptureBegin(lua_State*);
int32 IsMouseCaptureEnd(lua_State*);

int32 SetValue(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Slider",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Slider must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float InValue;
	} Params;
	Params.InValue = (float)(luaL_checknumber(InScriptContext, 2));
#if UE_GAME
	USlider * This = (USlider *)Obj;
	This->SetValue(Params.InValue);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetValue"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(float*)(params.GetStructMemory() + 0) = Params.InValue;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.InValue = *(float*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetStepSize(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Slider",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Slider must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float InValue;
	} Params;
	Params.InValue = (float)(luaL_checknumber(InScriptContext, 2));
#if UE_GAME
	USlider * This = (USlider *)Obj;
	This->SetStepSize(Params.InValue);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetStepSize"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(float*)(params.GetStructMemory() + 0) = Params.InValue;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.InValue = *(float*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetSliderHandleColor(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Slider",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Slider must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FLinearColor InValue;
	} Params;
	Params.InValue = (wLua::FLuaLinearColor::Get(InScriptContext, 2));
#if UE_GAME
	USlider * This = (USlider *)Obj;
	This->SetSliderHandleColor(Params.InValue);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetSliderHandleColor"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FLinearColor*)(params.GetStructMemory() + 0) = Params.InValue;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.InValue = *(FLinearColor*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetSliderBarColor(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Slider",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Slider must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FLinearColor InValue;
	} Params;
	Params.InValue = (wLua::FLuaLinearColor::Get(InScriptContext, 2));
#if UE_GAME
	USlider * This = (USlider *)Obj;
	This->SetSliderBarColor(Params.InValue);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetSliderBarColor"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FLinearColor*)(params.GetStructMemory() + 0) = Params.InValue;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.InValue = *(FLinearColor*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetLocked(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Slider",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Slider must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool InValue;
	} Params;
	Params.InValue = !!(lua_toboolean(InScriptContext, 2));
#if UE_GAME
	USlider * This = (USlider *)Obj;
	This->SetLocked(Params.InValue);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetLocked"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(bool*)(params.GetStructMemory() + 0) = Params.InValue;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.InValue = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetIndentHandle(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Slider",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Slider must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool InValue;
	} Params;
	Params.InValue = !!(lua_toboolean(InScriptContext, 2));
#if UE_GAME
	USlider * This = (USlider *)Obj;
	This->SetIndentHandle(Params.InValue);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetIndentHandle"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(bool*)(params.GetStructMemory() + 0) = Params.InValue;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.InValue = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 GetValue(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Slider",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Slider must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float ReturnValue;
	} Params;
#if UE_GAME
	USlider * This = (USlider *)Obj;
	Params.ReturnValue = This->GetValue();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetValue"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(float*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushnumber(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 Get_Value(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Slider",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Slider must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USlider::StaticClass(), TEXT("Value"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_Value(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Slider",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Slider must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USlider::StaticClass(), TEXT("Value"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_Orientation(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Slider",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Slider must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USlider::StaticClass(), TEXT("Orientation"));
	if(!Property) { check(false); return 0;}
	TEnumAsByte<EOrientation> PropertyValue = TEnumAsByte<EOrientation>();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushinteger(InScriptContext, (int)PropertyValue);
	return 1;
}

int32 Get_SliderBarColor(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Slider",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Slider must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USlider::StaticClass(), TEXT("SliderBarColor"));
	if(!Property) { check(false); return 0;}
	FLinearColor PropertyValue = FLinearColor();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaLinearColor::Return(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_SliderHandleColor(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Slider",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Slider must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USlider::StaticClass(), TEXT("SliderHandleColor"));
	if(!Property) { check(false); return 0;}
	FLinearColor PropertyValue = FLinearColor();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaLinearColor::Return(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_IndentHandle(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Slider",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Slider must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USlider::StaticClass(), TEXT("IndentHandle"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = bool();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_Locked(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Slider",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Slider must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USlider::StaticClass(), TEXT("Locked"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = bool();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_MouseUsesStep(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Slider",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Slider must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USlider::StaticClass(), TEXT("MouseUsesStep"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = bool();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_RequiresControllerLock(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Slider",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Slider must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USlider::StaticClass(), TEXT("RequiresControllerLock"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = bool();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_StepSize(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Slider",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Slider must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USlider::StaticClass(), TEXT("StepSize"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_IsFocusable(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Slider",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Slider must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USlider::StaticClass(), TEXT("IsFocusable"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = bool();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_bPrecise(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Slider",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Slider must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USlider::StaticClass(), TEXT("bPrecise"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = bool();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Call_OnMouseCaptureBegin(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Slider",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Slider must be non-null"); lua_error(InScriptContext);  return 0;}
	USlider * This = (USlider *)Obj;
	This->OnMouseCaptureBegin.Broadcast();
	return 0;
}

int32 Call_OnMouseCaptureEnd(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Slider",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Slider must be non-null"); lua_error(InScriptContext);  return 0;}
	USlider * This = (USlider *)Obj;
	This->OnMouseCaptureEnd.Broadcast();
	return 0;
}

int32 Call_OnControllerCaptureBegin(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Slider",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Slider must be non-null"); lua_error(InScriptContext);  return 0;}
	USlider * This = (USlider *)Obj;
	This->OnControllerCaptureBegin.Broadcast();
	return 0;
}

int32 Call_OnControllerCaptureEnd(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Slider",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Slider must be non-null"); lua_error(InScriptContext);  return 0;}
	USlider * This = (USlider *)Obj;
	This->OnControllerCaptureEnd.Broadcast();
	return 0;
}

int32 Call_OnValueChanged(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Slider",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Slider must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float Value;
	} Params;
	Params.Value = (float)(luaL_checknumber(InScriptContext, 2));
	USlider * This = (USlider *)Obj;
	This->OnValueChanged.Broadcast(Params.Value);
	return 0;
}

int32 New(lua_State* InScriptContext)
{
	UObject* Outer = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Object");
	FName Name = FName(luaL_checkstring(InScriptContext, 2));
	UObject* Obj = NewObject<USlider>(Outer, Name);
	wLua::FLuaUtils::ReturnUObject(InScriptContext,Obj);
	return 1;
}

int32 Destroy(lua_State* InScriptContext)
{
	return 0;
}

int32 Class(lua_State* InScriptContext)
{
	UClass* Class = USlider::StaticClass();
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Class);
	return 1;
}

const luaL_Reg Lib_Funcs[] =
{
	{ "New", New },
	{ "Destroy", Destroy },
	{ "Class", Class },
	{ "SetValue", SetValue },
	{ "SetStepSize", SetStepSize },
	{ "SetSliderHandleColor", SetSliderHandleColor },
	{ "SetSliderBarColor", SetSliderBarColor },
	{ "SetLocked", SetLocked },
	{ "SetIndentHandle", SetIndentHandle },
	{ "GetValue", GetValue },
	{ "Get_Value", Get_Value },
	{ "Set_Value", Set_Value },
	{ "Get_Orientation", Get_Orientation },
	{ "Get_SliderBarColor", Get_SliderBarColor },
	{ "Get_SliderHandleColor", Get_SliderHandleColor },
	{ "Get_IndentHandle", Get_IndentHandle },
	{ "Get_Locked", Get_Locked },
	{ "Get_MouseUsesStep", Get_MouseUsesStep },
	{ "Get_RequiresControllerLock", Get_RequiresControllerLock },
	{ "Get_StepSize", Get_StepSize },
	{ "Get_IsFocusable", Get_IsFocusable },
	{ "Get_bPrecise", Get_bPrecise },
	{ "Call_OnMouseCaptureBegin", Call_OnMouseCaptureBegin },
	{ "Call_OnMouseCaptureEnd", Call_OnMouseCaptureEnd },
	{ "Call_OnControllerCaptureBegin", Call_OnControllerCaptureBegin },
	{ "Call_OnControllerCaptureEnd", Call_OnControllerCaptureEnd },
	{ "Call_OnValueChanged", Call_OnValueChanged },
	{ "IsMouseCaptureBegin", IsMouseCaptureBegin },
	{ "IsMouseCaptureEnd", IsMouseCaptureEnd },
	{ "is_nil", wLua::LuaStatic::isnil },
	{ "__gc", wLua::LuaStatic::removeUClassFrameCache },
	{ NULL, NULL }
};

void Register(lua_State *InScriptContext)
{
	lua_newtable(InScriptContext);
	luaL_register(InScriptContext, NULL, Lib_Funcs);
	AzureHelpFuncs::AuxRegister(InScriptContext, "Slider");
}
void SetMtLink(lua_State *InScriptContext)
{
	AzureHelpFuncs::AuxSetMtLink(InScriptContext, "Slider", "Widget",USERDATATYPE_UOBJECT);
}

}