#include "Azure.h"
#include "Utility/help_funcs.h"
#include "wLua/UObjectHeaders.h"
#include "Animation/AnimInstance.h"
#include "AzureLuaIntegration.h"

namespace LuaAnimInstance
{
int32 GetBool(lua_State*);
int32 SetBool(lua_State*);
int32 GetInt(lua_State*);
int32 SetInt(lua_State*);
int32 GetFloat(lua_State*);
int32 SetFloat(lua_State*);
int32 GetVector(lua_State*);
int32 SetVector(lua_State*);
int32 GetRotator(lua_State*);
int32 SetRotator(lua_State*);
int32 GetActiveInstInfoForMontage(lua_State*);
int32 SetPositionForMontage(lua_State*);
int32 SetPlayRateForMontage(lua_State*);
int32 MontageAdvance(lua_State*);
int32 Advance(lua_State*);
int32 StopAllMontages(lua_State*);

int32 TryGetPawnOwner(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AnimInstance",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AnimInstance must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		APawn* ReturnValue = nullptr;
	} Params;
#if UE_GAME
	UAnimInstance * This = (UAnimInstance *)Obj;
	Params.ReturnValue = This->TryGetPawnOwner();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("TryGetPawnOwner"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(APawn**)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 StopSlotAnimation(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AnimInstance",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AnimInstance must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float InBlendOutTime;
		FName SlotNodeName;
	} Params;
	Params.InBlendOutTime = lua_isnoneornil(InScriptContext,2) ? float(0.250000) : (float)(luaL_checknumber(InScriptContext, 2));
	Params.SlotNodeName = lua_isnoneornil(InScriptContext,3) ? FName(TEXT("")) : FName(UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 3)));
#if UE_GAME
	UAnimInstance * This = (UAnimInstance *)Obj;
	This->StopSlotAnimation(Params.InBlendOutTime,Params.SlotNodeName);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("StopSlotAnimation"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(float*)(params.GetStructMemory() + 0) = Params.InBlendOutTime;
		*(FName*)(params.GetStructMemory() + 4) = Params.SlotNodeName;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.InBlendOutTime = *(float*)(params.GetStructMemory() + 0);
		Params.SlotNodeName = *(FName*)(params.GetStructMemory() + 4);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetRootMotionMode(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AnimInstance",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AnimInstance must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		TEnumAsByte<ERootMotionMode::Type> Value;
	} Params;
	Params.Value = (TEnumAsByte<ERootMotionMode::Type>)(luaL_checkint(InScriptContext, 2));
#if UE_GAME
	UAnimInstance * This = (UAnimInstance *)Obj;
	This->SetRootMotionMode(Params.Value);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetRootMotionMode"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(TEnumAsByte<ERootMotionMode::Type>*)(params.GetStructMemory() + 0) = Params.Value;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.Value = *(TEnumAsByte<ERootMotionMode::Type>*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetMorphTarget(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AnimInstance",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AnimInstance must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FName MorphTargetName;
		float Value;
	} Params;
	Params.MorphTargetName = FName(UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 2)));
	Params.Value = (float)(luaL_checknumber(InScriptContext, 3));
#if UE_GAME
	UAnimInstance * This = (UAnimInstance *)Obj;
	This->SetMorphTarget(Params.MorphTargetName,Params.Value);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetMorphTarget"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FName*)(params.GetStructMemory() + 0) = Params.MorphTargetName;
		*(float*)(params.GetStructMemory() + 12) = Params.Value;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.MorphTargetName = *(FName*)(params.GetStructMemory() + 0);
		Params.Value = *(float*)(params.GetStructMemory() + 12);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SavePoseSnapshot(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AnimInstance",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AnimInstance must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FName SnapshotName;
	} Params;
	Params.SnapshotName = FName(UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 2)));
#if UE_GAME
	UAnimInstance * This = (UAnimInstance *)Obj;
	This->SavePoseSnapshot(Params.SnapshotName);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SavePoseSnapshot"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FName*)(params.GetStructMemory() + 0) = Params.SnapshotName;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.SnapshotName = *(FName*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 ResetDynamics(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AnimInstance",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AnimInstance must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		ETeleportType InTeleportType;
	} Params;
	Params.InTeleportType = (ETeleportType)(luaL_checkint(InScriptContext, 2));
#if UE_GAME
	UAnimInstance * This = (UAnimInstance *)Obj;
	This->ResetDynamics(Params.InTeleportType);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("ResetDynamics"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(ETeleportType*)(params.GetStructMemory() + 0) = Params.InTeleportType;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.InTeleportType = *(ETeleportType*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 PlaySlotAnimationAsDynamicMontage(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AnimInstance",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AnimInstance must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		UAnimSequenceBase* Asset = nullptr;
		FName SlotNodeName;
		float BlendInTime;
		float BlendOutTime;
		float InPlayRate;
		int32 LoopCount;
		float BlendOutTriggerTime;
		float InTimeToStartMontageAt;
		UAnimMontage* ReturnValue = nullptr;
	} Params;
	Params.Asset = (UAnimSequenceBase*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"AnimSequenceBase");;
	Params.SlotNodeName = FName(UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 3)));
	Params.BlendInTime = lua_isnoneornil(InScriptContext,4) ? float(0.250000) : (float)(luaL_checknumber(InScriptContext, 4));
	Params.BlendOutTime = lua_isnoneornil(InScriptContext,5) ? float(0.250000) : (float)(luaL_checknumber(InScriptContext, 5));
	Params.InPlayRate = lua_isnoneornil(InScriptContext,6) ? float(1.000000) : (float)(luaL_checknumber(InScriptContext, 6));
	Params.LoopCount = lua_isnoneornil(InScriptContext,7) ? int32(1) : (luaL_checkint(InScriptContext, 7));
	Params.BlendOutTriggerTime = lua_isnoneornil(InScriptContext,8) ? float(-1.000000) : (float)(luaL_checknumber(InScriptContext, 8));
	Params.InTimeToStartMontageAt = lua_isnoneornil(InScriptContext,9) ? float(0.000000) : (float)(luaL_checknumber(InScriptContext, 9));
#if UE_GAME
	UAnimInstance * This = (UAnimInstance *)Obj;
	Params.ReturnValue = This->PlaySlotAnimationAsDynamicMontage(Params.Asset,Params.SlotNodeName,Params.BlendInTime,Params.BlendOutTime,Params.InPlayRate,Params.LoopCount,Params.BlendOutTriggerTime,Params.InTimeToStartMontageAt);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("PlaySlotAnimationAsDynamicMontage"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(UAnimSequenceBase**)(params.GetStructMemory() + 0) = Params.Asset;
		*(FName*)(params.GetStructMemory() + 8) = Params.SlotNodeName;
		*(float*)(params.GetStructMemory() + 20) = Params.BlendInTime;
		*(float*)(params.GetStructMemory() + 24) = Params.BlendOutTime;
		*(float*)(params.GetStructMemory() + 28) = Params.InPlayRate;
		*(int32*)(params.GetStructMemory() + 32) = Params.LoopCount;
		*(float*)(params.GetStructMemory() + 36) = Params.BlendOutTriggerTime;
		*(float*)(params.GetStructMemory() + 40) = Params.InTimeToStartMontageAt;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.Asset = *(UAnimSequenceBase**)(params.GetStructMemory() + 0);
		Params.SlotNodeName = *(FName*)(params.GetStructMemory() + 8);
		Params.BlendInTime = *(float*)(params.GetStructMemory() + 20);
		Params.BlendOutTime = *(float*)(params.GetStructMemory() + 24);
		Params.InPlayRate = *(float*)(params.GetStructMemory() + 28);
		Params.LoopCount = *(int32*)(params.GetStructMemory() + 32);
		Params.BlendOutTriggerTime = *(float*)(params.GetStructMemory() + 36);
		Params.InTimeToStartMontageAt = *(float*)(params.GetStructMemory() + 40);
		Params.ReturnValue = *(UAnimMontage**)(params.GetStructMemory() + 48);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 PlaySlotAnimation(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AnimInstance",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AnimInstance must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		UAnimSequenceBase* Asset = nullptr;
		FName SlotNodeName;
		float BlendInTime;
		float BlendOutTime;
		float InPlayRate;
		int32 LoopCount;
		float ReturnValue;
	} Params;
	Params.Asset = (UAnimSequenceBase*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"AnimSequenceBase");;
	Params.SlotNodeName = FName(UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 3)));
	Params.BlendInTime = lua_isnoneornil(InScriptContext,4) ? float(0.250000) : (float)(luaL_checknumber(InScriptContext, 4));
	Params.BlendOutTime = lua_isnoneornil(InScriptContext,5) ? float(0.250000) : (float)(luaL_checknumber(InScriptContext, 5));
	Params.InPlayRate = lua_isnoneornil(InScriptContext,6) ? float(1.000000) : (float)(luaL_checknumber(InScriptContext, 6));
	Params.LoopCount = lua_isnoneornil(InScriptContext,7) ? int32(1) : (luaL_checkint(InScriptContext, 7));
#if UE_GAME
	UAnimInstance * This = (UAnimInstance *)Obj;
	Params.ReturnValue = This->PlaySlotAnimation(Params.Asset,Params.SlotNodeName,Params.BlendInTime,Params.BlendOutTime,Params.InPlayRate,Params.LoopCount);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("PlaySlotAnimation"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(UAnimSequenceBase**)(params.GetStructMemory() + 0) = Params.Asset;
		*(FName*)(params.GetStructMemory() + 8) = Params.SlotNodeName;
		*(float*)(params.GetStructMemory() + 20) = Params.BlendInTime;
		*(float*)(params.GetStructMemory() + 24) = Params.BlendOutTime;
		*(float*)(params.GetStructMemory() + 28) = Params.InPlayRate;
		*(int32*)(params.GetStructMemory() + 32) = Params.LoopCount;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.Asset = *(UAnimSequenceBase**)(params.GetStructMemory() + 0);
		Params.SlotNodeName = *(FName*)(params.GetStructMemory() + 8);
		Params.BlendInTime = *(float*)(params.GetStructMemory() + 20);
		Params.BlendOutTime = *(float*)(params.GetStructMemory() + 24);
		Params.InPlayRate = *(float*)(params.GetStructMemory() + 28);
		Params.LoopCount = *(int32*)(params.GetStructMemory() + 32);
		Params.ReturnValue = *(float*)(params.GetStructMemory() + 36);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushnumber(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 Montage_Stop(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AnimInstance",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AnimInstance must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float InBlendOutTime;
		UAnimMontage* Montage = nullptr;
	} Params;
	Params.InBlendOutTime = (float)(luaL_checknumber(InScriptContext, 2));
	Params.Montage = lua_isnoneornil(InScriptContext,3) ? nullptr : (UAnimMontage*)wLua::FLuaUtils::GetUObject(InScriptContext,3,"AnimMontage");;
#if UE_GAME
	UAnimInstance * This = (UAnimInstance *)Obj;
	This->Montage_Stop(Params.InBlendOutTime,Params.Montage);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("Montage_Stop"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(float*)(params.GetStructMemory() + 0) = Params.InBlendOutTime;
		*(UAnimMontage**)(params.GetStructMemory() + 8) = Params.Montage;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.InBlendOutTime = *(float*)(params.GetStructMemory() + 0);
		Params.Montage = *(UAnimMontage**)(params.GetStructMemory() + 8);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 Montage_SetPosition(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AnimInstance",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AnimInstance must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		UAnimMontage* Montage = nullptr;
		float NewPosition;
	} Params;
	Params.Montage = (UAnimMontage*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"AnimMontage");;
	Params.NewPosition = (float)(luaL_checknumber(InScriptContext, 3));
#if UE_GAME
	UAnimInstance * This = (UAnimInstance *)Obj;
	This->Montage_SetPosition(Params.Montage,Params.NewPosition);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("Montage_SetPosition"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(UAnimMontage**)(params.GetStructMemory() + 0) = Params.Montage;
		*(float*)(params.GetStructMemory() + 8) = Params.NewPosition;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.Montage = *(UAnimMontage**)(params.GetStructMemory() + 0);
		Params.NewPosition = *(float*)(params.GetStructMemory() + 8);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 Montage_SetPlayRate(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AnimInstance",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AnimInstance must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		UAnimMontage* Montage = nullptr;
		float NewPlayRate;
	} Params;
	Params.Montage = (UAnimMontage*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"AnimMontage");;
	Params.NewPlayRate = lua_isnoneornil(InScriptContext,3) ? float(1.000000) : (float)(luaL_checknumber(InScriptContext, 3));
#if UE_GAME
	UAnimInstance * This = (UAnimInstance *)Obj;
	This->Montage_SetPlayRate(Params.Montage,Params.NewPlayRate);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("Montage_SetPlayRate"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(UAnimMontage**)(params.GetStructMemory() + 0) = Params.Montage;
		*(float*)(params.GetStructMemory() + 8) = Params.NewPlayRate;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.Montage = *(UAnimMontage**)(params.GetStructMemory() + 0);
		Params.NewPlayRate = *(float*)(params.GetStructMemory() + 8);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 Montage_SetNextSection(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AnimInstance",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AnimInstance must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FName SectionNameToChange;
		FName NextSection;
		UAnimMontage* Montage = nullptr;
	} Params;
	Params.SectionNameToChange = FName(UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 2)));
	Params.NextSection = FName(UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 3)));
	Params.Montage = lua_isnoneornil(InScriptContext,4) ? nullptr : (UAnimMontage*)wLua::FLuaUtils::GetUObject(InScriptContext,4,"AnimMontage");;
#if UE_GAME
	UAnimInstance * This = (UAnimInstance *)Obj;
	This->Montage_SetNextSection(Params.SectionNameToChange,Params.NextSection,Params.Montage);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("Montage_SetNextSection"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FName*)(params.GetStructMemory() + 0) = Params.SectionNameToChange;
		*(FName*)(params.GetStructMemory() + 12) = Params.NextSection;
		*(UAnimMontage**)(params.GetStructMemory() + 24) = Params.Montage;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.SectionNameToChange = *(FName*)(params.GetStructMemory() + 0);
		Params.NextSection = *(FName*)(params.GetStructMemory() + 12);
		Params.Montage = *(UAnimMontage**)(params.GetStructMemory() + 24);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 Montage_Resume(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AnimInstance",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AnimInstance must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		UAnimMontage* Montage = nullptr;
	} Params;
	Params.Montage = (UAnimMontage*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"AnimMontage");;
#if UE_GAME
	UAnimInstance * This = (UAnimInstance *)Obj;
	This->Montage_Resume(Params.Montage);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("Montage_Resume"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(UAnimMontage**)(params.GetStructMemory() + 0) = Params.Montage;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.Montage = *(UAnimMontage**)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 Montage_Play(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AnimInstance",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AnimInstance must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		UAnimMontage* MontageToPlay = nullptr;
		float InPlayRate;
		EMontagePlayReturnType ReturnValueType;
		float InTimeToStartMontageAt;
		bool bStopAllMontages;
		float ReturnValue;
	} Params;
	Params.MontageToPlay = (UAnimMontage*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"AnimMontage");;
	Params.InPlayRate = lua_isnoneornil(InScriptContext,3) ? float(1.000000) : (float)(luaL_checknumber(InScriptContext, 3));
	Params.ReturnValueType = lua_isnoneornil(InScriptContext,4) ? EMontagePlayReturnType(EMontagePlayReturnType::MontageLength) : (EMontagePlayReturnType)(luaL_checkint(InScriptContext, 4));
	Params.InTimeToStartMontageAt = lua_isnoneornil(InScriptContext,5) ? float(0.000000) : (float)(luaL_checknumber(InScriptContext, 5));
	Params.bStopAllMontages = lua_isnoneornil(InScriptContext,6) ? bool(true) : !!(lua_toboolean(InScriptContext, 6));
#if UE_GAME
	UAnimInstance * This = (UAnimInstance *)Obj;
	Params.ReturnValue = This->Montage_Play(Params.MontageToPlay,Params.InPlayRate,Params.ReturnValueType,Params.InTimeToStartMontageAt,Params.bStopAllMontages);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("Montage_Play"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(UAnimMontage**)(params.GetStructMemory() + 0) = Params.MontageToPlay;
		*(float*)(params.GetStructMemory() + 8) = Params.InPlayRate;
		*(EMontagePlayReturnType*)(params.GetStructMemory() + 12) = Params.ReturnValueType;
		*(float*)(params.GetStructMemory() + 16) = Params.InTimeToStartMontageAt;
		*(bool*)(params.GetStructMemory() + 20) = Params.bStopAllMontages;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.MontageToPlay = *(UAnimMontage**)(params.GetStructMemory() + 0);
		Params.InPlayRate = *(float*)(params.GetStructMemory() + 8);
		Params.ReturnValueType = *(EMontagePlayReturnType*)(params.GetStructMemory() + 12);
		Params.InTimeToStartMontageAt = *(float*)(params.GetStructMemory() + 16);
		Params.bStopAllMontages = *(bool*)(params.GetStructMemory() + 20);
		Params.ReturnValue = *(float*)(params.GetStructMemory() + 24);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushnumber(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 Montage_Pause(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AnimInstance",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AnimInstance must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		UAnimMontage* Montage = nullptr;
	} Params;
	Params.Montage = lua_isnoneornil(InScriptContext,2) ? nullptr : (UAnimMontage*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"AnimMontage");;
#if UE_GAME
	UAnimInstance * This = (UAnimInstance *)Obj;
	This->Montage_Pause(Params.Montage);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("Montage_Pause"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(UAnimMontage**)(params.GetStructMemory() + 0) = Params.Montage;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.Montage = *(UAnimMontage**)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 Montage_JumpToSectionsEnd(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AnimInstance",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AnimInstance must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FName SectionName;
		UAnimMontage* Montage = nullptr;
	} Params;
	Params.SectionName = FName(UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 2)));
	Params.Montage = lua_isnoneornil(InScriptContext,3) ? nullptr : (UAnimMontage*)wLua::FLuaUtils::GetUObject(InScriptContext,3,"AnimMontage");;
#if UE_GAME
	UAnimInstance * This = (UAnimInstance *)Obj;
	This->Montage_JumpToSectionsEnd(Params.SectionName,Params.Montage);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("Montage_JumpToSectionsEnd"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FName*)(params.GetStructMemory() + 0) = Params.SectionName;
		*(UAnimMontage**)(params.GetStructMemory() + 16) = Params.Montage;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.SectionName = *(FName*)(params.GetStructMemory() + 0);
		Params.Montage = *(UAnimMontage**)(params.GetStructMemory() + 16);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 Montage_JumpToSection(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AnimInstance",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AnimInstance must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FName SectionName;
		UAnimMontage* Montage = nullptr;
	} Params;
	Params.SectionName = FName(UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 2)));
	Params.Montage = lua_isnoneornil(InScriptContext,3) ? nullptr : (UAnimMontage*)wLua::FLuaUtils::GetUObject(InScriptContext,3,"AnimMontage");;
#if UE_GAME
	UAnimInstance * This = (UAnimInstance *)Obj;
	This->Montage_JumpToSection(Params.SectionName,Params.Montage);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("Montage_JumpToSection"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FName*)(params.GetStructMemory() + 0) = Params.SectionName;
		*(UAnimMontage**)(params.GetStructMemory() + 16) = Params.Montage;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.SectionName = *(FName*)(params.GetStructMemory() + 0);
		Params.Montage = *(UAnimMontage**)(params.GetStructMemory() + 16);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 Montage_IsPlaying(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AnimInstance",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AnimInstance must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		UAnimMontage* Montage = nullptr;
		bool ReturnValue;
	} Params;
	Params.Montage = (UAnimMontage*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"AnimMontage");;
#if UE_GAME
	UAnimInstance * This = (UAnimInstance *)Obj;
	Params.ReturnValue = This->Montage_IsPlaying(Params.Montage);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("Montage_IsPlaying"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(UAnimMontage**)(params.GetStructMemory() + 0) = Params.Montage;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.Montage = *(UAnimMontage**)(params.GetStructMemory() + 0);
		Params.ReturnValue = *(bool*)(params.GetStructMemory() + 8);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushboolean(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 Montage_IsActive(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AnimInstance",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AnimInstance must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		UAnimMontage* Montage = nullptr;
		bool ReturnValue;
	} Params;
	Params.Montage = (UAnimMontage*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"AnimMontage");;
#if UE_GAME
	UAnimInstance * This = (UAnimInstance *)Obj;
	Params.ReturnValue = This->Montage_IsActive(Params.Montage);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("Montage_IsActive"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(UAnimMontage**)(params.GetStructMemory() + 0) = Params.Montage;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.Montage = *(UAnimMontage**)(params.GetStructMemory() + 0);
		Params.ReturnValue = *(bool*)(params.GetStructMemory() + 8);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushboolean(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 Montage_GetPosition(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AnimInstance",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AnimInstance must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		UAnimMontage* Montage = nullptr;
		float ReturnValue;
	} Params;
	Params.Montage = (UAnimMontage*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"AnimMontage");;
#if UE_GAME
	UAnimInstance * This = (UAnimInstance *)Obj;
	Params.ReturnValue = This->Montage_GetPosition(Params.Montage);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("Montage_GetPosition"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(UAnimMontage**)(params.GetStructMemory() + 0) = Params.Montage;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.Montage = *(UAnimMontage**)(params.GetStructMemory() + 0);
		Params.ReturnValue = *(float*)(params.GetStructMemory() + 8);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushnumber(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 Montage_GetPlayRate(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AnimInstance",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AnimInstance must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		UAnimMontage* Montage = nullptr;
		float ReturnValue;
	} Params;
	Params.Montage = (UAnimMontage*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"AnimMontage");;
#if UE_GAME
	UAnimInstance * This = (UAnimInstance *)Obj;
	Params.ReturnValue = This->Montage_GetPlayRate(Params.Montage);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("Montage_GetPlayRate"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(UAnimMontage**)(params.GetStructMemory() + 0) = Params.Montage;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.Montage = *(UAnimMontage**)(params.GetStructMemory() + 0);
		Params.ReturnValue = *(float*)(params.GetStructMemory() + 8);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushnumber(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 Montage_GetIsStopped(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AnimInstance",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AnimInstance must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		UAnimMontage* Montage = nullptr;
		bool ReturnValue;
	} Params;
	Params.Montage = (UAnimMontage*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"AnimMontage");;
#if UE_GAME
	UAnimInstance * This = (UAnimInstance *)Obj;
	Params.ReturnValue = This->Montage_GetIsStopped(Params.Montage);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("Montage_GetIsStopped"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(UAnimMontage**)(params.GetStructMemory() + 0) = Params.Montage;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.Montage = *(UAnimMontage**)(params.GetStructMemory() + 0);
		Params.ReturnValue = *(bool*)(params.GetStructMemory() + 8);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushboolean(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 Montage_GetCurrentSection(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AnimInstance",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AnimInstance must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		UAnimMontage* Montage = nullptr;
		FName ReturnValue;
	} Params;
	Params.Montage = lua_isnoneornil(InScriptContext,2) ? nullptr : (UAnimMontage*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"AnimMontage");;
#if UE_GAME
	UAnimInstance * This = (UAnimInstance *)Obj;
	Params.ReturnValue = This->Montage_GetCurrentSection(Params.Montage);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("Montage_GetCurrentSection"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(UAnimMontage**)(params.GetStructMemory() + 0) = Params.Montage;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.Montage = *(UAnimMontage**)(params.GetStructMemory() + 0);
		Params.ReturnValue = *(FName*)(params.GetStructMemory() + 8);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushstring(InScriptContext, TCHAR_TO_UTF8(*Params.ReturnValue.ToString()));
	return 1;
}

int32 Montage_GetBlendTime(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AnimInstance",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AnimInstance must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		UAnimMontage* Montage = nullptr;
		float ReturnValue;
	} Params;
	Params.Montage = (UAnimMontage*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"AnimMontage");;
#if UE_GAME
	UAnimInstance * This = (UAnimInstance *)Obj;
	Params.ReturnValue = This->Montage_GetBlendTime(Params.Montage);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("Montage_GetBlendTime"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(UAnimMontage**)(params.GetStructMemory() + 0) = Params.Montage;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.Montage = *(UAnimMontage**)(params.GetStructMemory() + 0);
		Params.ReturnValue = *(float*)(params.GetStructMemory() + 8);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushnumber(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 IsSyncGroupBetweenMarkers(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AnimInstance",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AnimInstance must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FName InSyncGroupName;
		FName PreviousMarker;
		FName NextMarker;
		bool bRespectMarkerOrder;
		bool ReturnValue;
	} Params;
	Params.InSyncGroupName = FName(UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 2)));
	Params.PreviousMarker = FName(UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 3)));
	Params.NextMarker = FName(UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 4)));
	Params.bRespectMarkerOrder = lua_isnoneornil(InScriptContext,5) ? bool(true) : !!(lua_toboolean(InScriptContext, 5));
#if UE_GAME
	UAnimInstance * This = (UAnimInstance *)Obj;
	Params.ReturnValue = This->IsSyncGroupBetweenMarkers(Params.InSyncGroupName,Params.PreviousMarker,Params.NextMarker,Params.bRespectMarkerOrder);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("IsSyncGroupBetweenMarkers"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FName*)(params.GetStructMemory() + 0) = Params.InSyncGroupName;
		*(FName*)(params.GetStructMemory() + 12) = Params.PreviousMarker;
		*(FName*)(params.GetStructMemory() + 24) = Params.NextMarker;
		*(bool*)(params.GetStructMemory() + 36) = Params.bRespectMarkerOrder;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.InSyncGroupName = *(FName*)(params.GetStructMemory() + 0);
		Params.PreviousMarker = *(FName*)(params.GetStructMemory() + 12);
		Params.NextMarker = *(FName*)(params.GetStructMemory() + 24);
		Params.bRespectMarkerOrder = *(bool*)(params.GetStructMemory() + 36);
		Params.ReturnValue = *(bool*)(params.GetStructMemory() + 37);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushboolean(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 IsPlayingSlotAnimation(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AnimInstance",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AnimInstance must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		UAnimSequenceBase* Asset = nullptr;
		FName SlotNodeName;
		bool ReturnValue;
	} Params;
	Params.Asset = (UAnimSequenceBase*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"AnimSequenceBase");;
	Params.SlotNodeName = FName(UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 3)));
#if UE_GAME
	UAnimInstance * This = (UAnimInstance *)Obj;
	Params.ReturnValue = This->IsPlayingSlotAnimation(Params.Asset,Params.SlotNodeName);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("IsPlayingSlotAnimation"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(UAnimSequenceBase**)(params.GetStructMemory() + 0) = Params.Asset;
		*(FName*)(params.GetStructMemory() + 8) = Params.SlotNodeName;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.Asset = *(UAnimSequenceBase**)(params.GetStructMemory() + 0);
		Params.SlotNodeName = *(FName*)(params.GetStructMemory() + 8);
		Params.ReturnValue = *(bool*)(params.GetStructMemory() + 20);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushboolean(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 IsAnyMontagePlaying(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AnimInstance",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AnimInstance must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool ReturnValue;
	} Params;
#if UE_GAME
	UAnimInstance * This = (UAnimInstance *)Obj;
	Params.ReturnValue = This->IsAnyMontagePlaying();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("IsAnyMontagePlaying"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushboolean(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 HasMarkerBeenHitThisFrame(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AnimInstance",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AnimInstance must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FName SyncGroup;
		FName MarkerName;
		bool ReturnValue;
	} Params;
	Params.SyncGroup = FName(UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 2)));
	Params.MarkerName = FName(UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 3)));
#if UE_GAME
	UAnimInstance * This = (UAnimInstance *)Obj;
	Params.ReturnValue = This->HasMarkerBeenHitThisFrame(Params.SyncGroup,Params.MarkerName);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("HasMarkerBeenHitThisFrame"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FName*)(params.GetStructMemory() + 0) = Params.SyncGroup;
		*(FName*)(params.GetStructMemory() + 12) = Params.MarkerName;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.SyncGroup = *(FName*)(params.GetStructMemory() + 0);
		Params.MarkerName = *(FName*)(params.GetStructMemory() + 12);
		Params.ReturnValue = *(bool*)(params.GetStructMemory() + 24);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushboolean(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetTimeToClosestMarker(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AnimInstance",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AnimInstance must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FName SyncGroup;
		FName MarkerName;
		float OutMarkerTime;
		bool ReturnValue;
	} Params;
	Params.SyncGroup = FName(UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 2)));
	Params.MarkerName = FName(UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 3)));
#if UE_GAME
	UAnimInstance * This = (UAnimInstance *)Obj;
	Params.ReturnValue = This->GetTimeToClosestMarker(Params.SyncGroup,Params.MarkerName,Params.OutMarkerTime);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetTimeToClosestMarker"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FName*)(params.GetStructMemory() + 0) = Params.SyncGroup;
		*(FName*)(params.GetStructMemory() + 12) = Params.MarkerName;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.SyncGroup = *(FName*)(params.GetStructMemory() + 0);
		Params.MarkerName = *(FName*)(params.GetStructMemory() + 12);
		Params.OutMarkerTime = *(float*)(params.GetStructMemory() + 24);
		Params.ReturnValue = *(bool*)(params.GetStructMemory() + 28);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushboolean(InScriptContext, Params.ReturnValue);
	lua_pushnumber(InScriptContext, Params.OutMarkerTime);
	return 2;
}

int32 GetOwningComponent(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AnimInstance",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AnimInstance must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		USkeletalMeshComponent* ReturnValue = nullptr;
	} Params;
#if UE_GAME
	UAnimInstance * This = (UAnimInstance *)Obj;
	Params.ReturnValue = This->GetOwningComponent();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetOwningComponent"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(USkeletalMeshComponent**)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetOwningActor(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AnimInstance",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AnimInstance must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		AActor* ReturnValue = nullptr;
	} Params;
#if UE_GAME
	UAnimInstance * This = (UAnimInstance *)Obj;
	Params.ReturnValue = This->GetOwningActor();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetOwningActor"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(AActor**)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetCurveValueWithDefault(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AnimInstance",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AnimInstance must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FName CurveName;
		float defaultValue;
		float ReturnValue;
	} Params;
	Params.CurveName = FName(UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 2)));
	Params.defaultValue = lua_isnoneornil(InScriptContext,3) ? float(1.000000) : (float)(luaL_checknumber(InScriptContext, 3));
#if UE_GAME
	UAnimInstance * This = (UAnimInstance *)Obj;
	Params.ReturnValue = This->GetCurveValueWithDefault(Params.CurveName,Params.defaultValue);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetCurveValueWithDefault"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FName*)(params.GetStructMemory() + 0) = Params.CurveName;
		*(float*)(params.GetStructMemory() + 12) = Params.defaultValue;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.CurveName = *(FName*)(params.GetStructMemory() + 0);
		Params.defaultValue = *(float*)(params.GetStructMemory() + 12);
		Params.ReturnValue = *(float*)(params.GetStructMemory() + 16);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushnumber(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetCurveValue(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AnimInstance",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AnimInstance must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FName CurveName;
		float ReturnValue;
	} Params;
	Params.CurveName = FName(UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 2)));
#if UE_GAME
	UAnimInstance * This = (UAnimInstance *)Obj;
	Params.ReturnValue = This->GetCurveValue(Params.CurveName);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetCurveValue"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FName*)(params.GetStructMemory() + 0) = Params.CurveName;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.CurveName = *(FName*)(params.GetStructMemory() + 0);
		Params.ReturnValue = *(float*)(params.GetStructMemory() + 12);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushnumber(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetCurrentActiveMontage(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AnimInstance",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AnimInstance must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		UAnimMontage* ReturnValue = nullptr;
	} Params;
#if UE_GAME
	UAnimInstance * This = (UAnimInstance *)Obj;
	Params.ReturnValue = This->GetCurrentActiveMontage();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetCurrentActiveMontage"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(UAnimMontage**)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetAllCurveNames(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AnimInstance",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AnimInstance must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		TArray<FName> OutNames;
	} Params;
#if UE_GAME
	UAnimInstance * This = (UAnimInstance *)Obj;
	This->GetAllCurveNames(Params.OutNames);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetAllCurveNames"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.OutNames = *(TArray<FName>*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	{lua_newtable(InScriptContext); int i = 1; for(auto It = Params.OutNames.CreateConstIterator(); It; ++It,++i) {  lua_pushstring(InScriptContext, TCHAR_TO_UTF8(*(*It).ToString())); lua_rawseti(InScriptContext,-2,i);     }  }
	return 1;
}

int32 GetActiveCurveNames(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AnimInstance",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AnimInstance must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		EAnimCurveType CurveType;
		TArray<FName> OutNames;
	} Params;
	Params.CurveType = (EAnimCurveType)(luaL_checkint(InScriptContext, 2));
#if UE_GAME
	UAnimInstance * This = (UAnimInstance *)Obj;
	This->GetActiveCurveNames(Params.CurveType,Params.OutNames);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetActiveCurveNames"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(EAnimCurveType*)(params.GetStructMemory() + 0) = Params.CurveType;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.CurveType = *(EAnimCurveType*)(params.GetStructMemory() + 0);
		Params.OutNames = *(TArray<FName>*)(params.GetStructMemory() + 8);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	{lua_newtable(InScriptContext); int i = 1; for(auto It = Params.OutNames.CreateConstIterator(); It; ++It,++i) {  lua_pushstring(InScriptContext, TCHAR_TO_UTF8(*(*It).ToString())); lua_rawseti(InScriptContext,-2,i);     }  }
	return 1;
}

int32 ClearMorphTargets(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AnimInstance",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AnimInstance must be non-null"); lua_error(InScriptContext);  return 0;}
#if UE_GAME
	UAnimInstance * This = (UAnimInstance *)Obj;
	This->ClearMorphTargets();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("ClearMorphTargets"));
	if(!Function) { check(false); return 0;}
	Obj->ProcessEvent(Function, NULL);
#endif
	return 0;
}

int32 CalculateDirection(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AnimInstance",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AnimInstance must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FVector Velocity;
		FRotator BaseRotation;
		float ReturnValue;
	} Params;
	Params.Velocity = (wLua::FLuaVector::Get(InScriptContext, 2));
	Params.BaseRotation = (wLua::FLuaRotator::Get(InScriptContext, 3));
#if UE_GAME
	UAnimInstance * This = (UAnimInstance *)Obj;
	Params.ReturnValue = This->CalculateDirection(Params.Velocity,Params.BaseRotation);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("CalculateDirection"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FVector*)(params.GetStructMemory() + 0) = Params.Velocity;
		*(FRotator*)(params.GetStructMemory() + 12) = Params.BaseRotation;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.Velocity = *(FVector*)(params.GetStructMemory() + 0);
		Params.BaseRotation = *(FRotator*)(params.GetStructMemory() + 12);
		Params.ReturnValue = *(float*)(params.GetStructMemory() + 24);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushnumber(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 BlueprintUpdateAnimation(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AnimInstance",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AnimInstance must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float DeltaTimeX;
	} Params;
	Params.DeltaTimeX = (float)(luaL_checknumber(InScriptContext, 2));
#if UE_GAME
	UAnimInstance * This = (UAnimInstance *)Obj;
	This->BlueprintUpdateAnimation(Params.DeltaTimeX);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("BlueprintUpdateAnimation"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(float*)(params.GetStructMemory() + 0) = Params.DeltaTimeX;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.DeltaTimeX = *(float*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 BlueprintPostEvaluateAnimation(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AnimInstance",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AnimInstance must be non-null"); lua_error(InScriptContext);  return 0;}
#if UE_GAME
	UAnimInstance * This = (UAnimInstance *)Obj;
	This->BlueprintPostEvaluateAnimation();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("BlueprintPostEvaluateAnimation"));
	if(!Function) { check(false); return 0;}
	Obj->ProcessEvent(Function, NULL);
#endif
	return 0;
}

int32 BlueprintInitializeAnimation(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AnimInstance",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AnimInstance must be non-null"); lua_error(InScriptContext);  return 0;}
#if UE_GAME
	UAnimInstance * This = (UAnimInstance *)Obj;
	This->BlueprintInitializeAnimation();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("BlueprintInitializeAnimation"));
	if(!Function) { check(false); return 0;}
	Obj->ProcessEvent(Function, NULL);
#endif
	return 0;
}

int32 BlueprintBeginPlay(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AnimInstance",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AnimInstance must be non-null"); lua_error(InScriptContext);  return 0;}
#if UE_GAME
	UAnimInstance * This = (UAnimInstance *)Obj;
	This->BlueprintBeginPlay();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("BlueprintBeginPlay"));
	if(!Function) { check(false); return 0;}
	Obj->ProcessEvent(Function, NULL);
#endif
	return 0;
}

int32 Get_RootMotionMode(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AnimInstance",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AnimInstance must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAnimInstance::StaticClass(), TEXT("RootMotionMode"));
	if(!Property) { check(false); return 0;}
	TEnumAsByte<ERootMotionMode::Type> PropertyValue = TEnumAsByte<ERootMotionMode::Type>();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushinteger(InScriptContext, (int)PropertyValue);
	return 1;
}

int32 Set_RootMotionMode(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AnimInstance",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AnimInstance must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAnimInstance::StaticClass(), TEXT("RootMotionMode"));
	if(!Property) { check(false); return 0;}
	TEnumAsByte<ERootMotionMode::Type> PropertyValue = (TEnumAsByte<ERootMotionMode::Type>)(luaL_checkint(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Call_OnMontageBlendingOut(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AnimInstance",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AnimInstance must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		UAnimMontage* Montage = nullptr;
		bool bInterrupted;
	} Params;
	Params.Montage = (UAnimMontage*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"AnimMontage");;
	Params.bInterrupted = !!(lua_toboolean(InScriptContext, 3));
	UAnimInstance * This = (UAnimInstance *)Obj;
	This->OnMontageBlendingOut.Broadcast(Params.Montage,Params.bInterrupted);
	return 0;
}

int32 Call_OnMontageStarted(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AnimInstance",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AnimInstance must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		UAnimMontage* Montage = nullptr;
	} Params;
	Params.Montage = (UAnimMontage*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"AnimMontage");;
	UAnimInstance * This = (UAnimInstance *)Obj;
	This->OnMontageStarted.Broadcast(Params.Montage);
	return 0;
}

int32 Call_OnMontageEnded(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AnimInstance",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AnimInstance must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		UAnimMontage* Montage = nullptr;
		bool bInterrupted;
	} Params;
	Params.Montage = (UAnimMontage*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"AnimMontage");;
	Params.bInterrupted = !!(lua_toboolean(InScriptContext, 3));
	UAnimInstance * This = (UAnimInstance *)Obj;
	This->OnMontageEnded.Broadcast(Params.Montage,Params.bInterrupted);
	return 0;
}

int32 Call_OnAllMontageInstancesEnded(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AnimInstance",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AnimInstance must be non-null"); lua_error(InScriptContext);  return 0;}
	UAnimInstance * This = (UAnimInstance *)Obj;
	This->OnAllMontageInstancesEnded.Broadcast();
	return 0;
}

int32 New(lua_State* InScriptContext)
{
	UObject* Outer = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Object");
	FName Name = FName(luaL_checkstring(InScriptContext, 2));
	UObject* Obj = NewObject<UAnimInstance>(Outer, Name);
	wLua::FLuaUtils::ReturnUObject(InScriptContext,Obj);
	return 1;
}

int32 Destroy(lua_State* InScriptContext)
{
	return 0;
}

int32 Class(lua_State* InScriptContext)
{
	UClass* Class = UAnimInstance::StaticClass();
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Class);
	return 1;
}

const luaL_Reg Lib_Funcs[] =
{
	{ "New", New },
	{ "Destroy", Destroy },
	{ "Class", Class },
	{ "TryGetPawnOwner", TryGetPawnOwner },
	{ "StopSlotAnimation", StopSlotAnimation },
	{ "SetRootMotionMode", SetRootMotionMode },
	{ "SetMorphTarget", SetMorphTarget },
	{ "SavePoseSnapshot", SavePoseSnapshot },
	{ "ResetDynamics", ResetDynamics },
	{ "PlaySlotAnimationAsDynamicMontage", PlaySlotAnimationAsDynamicMontage },
	{ "PlaySlotAnimation", PlaySlotAnimation },
	{ "Montage_Stop", Montage_Stop },
	{ "Montage_SetPosition", Montage_SetPosition },
	{ "Montage_SetPlayRate", Montage_SetPlayRate },
	{ "Montage_SetNextSection", Montage_SetNextSection },
	{ "Montage_Resume", Montage_Resume },
	{ "Montage_Play", Montage_Play },
	{ "Montage_Pause", Montage_Pause },
	{ "Montage_JumpToSectionsEnd", Montage_JumpToSectionsEnd },
	{ "Montage_JumpToSection", Montage_JumpToSection },
	{ "Montage_IsPlaying", Montage_IsPlaying },
	{ "Montage_IsActive", Montage_IsActive },
	{ "Montage_GetPosition", Montage_GetPosition },
	{ "Montage_GetPlayRate", Montage_GetPlayRate },
	{ "Montage_GetIsStopped", Montage_GetIsStopped },
	{ "Montage_GetCurrentSection", Montage_GetCurrentSection },
	{ "Montage_GetBlendTime", Montage_GetBlendTime },
	{ "IsSyncGroupBetweenMarkers", IsSyncGroupBetweenMarkers },
	{ "IsPlayingSlotAnimation", IsPlayingSlotAnimation },
	{ "IsAnyMontagePlaying", IsAnyMontagePlaying },
	{ "HasMarkerBeenHitThisFrame", HasMarkerBeenHitThisFrame },
	{ "GetTimeToClosestMarker", GetTimeToClosestMarker },
	{ "GetOwningComponent", GetOwningComponent },
	{ "GetOwningActor", GetOwningActor },
	{ "GetCurveValueWithDefault", GetCurveValueWithDefault },
	{ "GetCurveValue", GetCurveValue },
	{ "GetCurrentActiveMontage", GetCurrentActiveMontage },
	{ "GetAllCurveNames", GetAllCurveNames },
	{ "GetActiveCurveNames", GetActiveCurveNames },
	{ "ClearMorphTargets", ClearMorphTargets },
	{ "CalculateDirection", CalculateDirection },
	{ "BlueprintUpdateAnimation", BlueprintUpdateAnimation },
	{ "BlueprintPostEvaluateAnimation", BlueprintPostEvaluateAnimation },
	{ "BlueprintInitializeAnimation", BlueprintInitializeAnimation },
	{ "BlueprintBeginPlay", BlueprintBeginPlay },
	{ "Get_RootMotionMode", Get_RootMotionMode },
	{ "Set_RootMotionMode", Set_RootMotionMode },
	{ "Call_OnMontageBlendingOut", Call_OnMontageBlendingOut },
	{ "Call_OnMontageStarted", Call_OnMontageStarted },
	{ "Call_OnMontageEnded", Call_OnMontageEnded },
	{ "Call_OnAllMontageInstancesEnded", Call_OnAllMontageInstancesEnded },
	{ "GetBool", GetBool },
	{ "SetBool", SetBool },
	{ "GetInt", GetInt },
	{ "SetInt", SetInt },
	{ "GetFloat", GetFloat },
	{ "SetFloat", SetFloat },
	{ "GetVector", GetVector },
	{ "SetVector", SetVector },
	{ "GetRotator", GetRotator },
	{ "SetRotator", SetRotator },
	{ "GetActiveInstInfoForMontage", GetActiveInstInfoForMontage },
	{ "SetPositionForMontage", SetPositionForMontage },
	{ "SetPlayRateForMontage", SetPlayRateForMontage },
	{ "MontageAdvance", MontageAdvance },
	{ "Advance", Advance },
	{ "StopAllMontages", StopAllMontages },
	{ "is_nil", wLua::LuaStatic::isnil },
	{ "__gc", wLua::LuaStatic::removeUClassFrameCache },
	{ NULL, NULL }
};

void Register(lua_State *InScriptContext)
{
	lua_newtable(InScriptContext);
	luaL_register(InScriptContext, NULL, Lib_Funcs);
	AzureHelpFuncs::AuxRegister(InScriptContext, "AnimInstance");
}
void SetMtLink(lua_State *InScriptContext)
{
	AzureHelpFuncs::AuxSetMtLink(InScriptContext, "AnimInstance", "Object",USERDATATYPE_UOBJECT);
}

}