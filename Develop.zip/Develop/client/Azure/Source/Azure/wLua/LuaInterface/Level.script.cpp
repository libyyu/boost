#include "Azure.h"
#include "Utility/help_funcs.h"
#include "wLua/UObjectHeaders.h"
#include "Engine/Level.h"
#include "AzureLuaIntegration.h"

namespace LuaLevel
{
int32 FindActorByName(lua_State*);
int32 FindActorsByClass(lua_State*);
int32 FindActorsByTag(lua_State*);
int32 FindComponentsByClassAndTag(lua_State*);
int32 FindComponentsByClass(lua_State*);
int32 ChangeLightingChannelMask(lua_State*);
int32 GetLevelScriptActor(lua_State*);

int32 Get_LightmapTotalSize(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Level",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Level must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(ULevel::StaticClass(), TEXT("LightmapTotalSize"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_LightmapTotalSize(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Level",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Level must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(ULevel::StaticClass(), TEXT("LightmapTotalSize"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_ShadowmapTotalSize(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Level",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Level must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(ULevel::StaticClass(), TEXT("ShadowmapTotalSize"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_ShadowmapTotalSize(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Level",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Level must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(ULevel::StaticClass(), TEXT("ShadowmapTotalSize"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_AzureWorldOffset(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Level",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Level must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(ULevel::StaticClass(), TEXT("AzureWorldOffset"));
	if(!Property) { check(false); return 0;}
	FVector PropertyValue = FVector();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaVector::Return(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_AzureWorldOffset(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Level",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Level must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(ULevel::StaticClass(), TEXT("AzureWorldOffset"));
	if(!Property) { check(false); return 0;}
	FVector PropertyValue = (wLua::FLuaVector::Get(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 New(lua_State* InScriptContext)
{
	UObject* Outer = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Object");
	FName Name = FName(luaL_checkstring(InScriptContext, 2));
	UObject* Obj = NewObject<ULevel>(Outer, Name);
	wLua::FLuaUtils::ReturnUObject(InScriptContext,Obj);
	return 1;
}

int32 Destroy(lua_State* InScriptContext)
{
	return 0;
}

int32 Class(lua_State* InScriptContext)
{
	UClass* Class = ULevel::StaticClass();
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Class);
	return 1;
}

const luaL_Reg Lib_Funcs[] =
{
	{ "New", New },
	{ "Destroy", Destroy },
	{ "Class", Class },
	{ "Get_LightmapTotalSize", Get_LightmapTotalSize },
	{ "Set_LightmapTotalSize", Set_LightmapTotalSize },
	{ "Get_ShadowmapTotalSize", Get_ShadowmapTotalSize },
	{ "Set_ShadowmapTotalSize", Set_ShadowmapTotalSize },
	{ "Get_AzureWorldOffset", Get_AzureWorldOffset },
	{ "Set_AzureWorldOffset", Set_AzureWorldOffset },
	{ "FindActorByName", FindActorByName },
	{ "FindActorsByClass", FindActorsByClass },
	{ "FindActorsByTag", FindActorsByTag },
	{ "FindComponentsByClassAndTag", FindComponentsByClassAndTag },
	{ "FindComponentsByClass", FindComponentsByClass },
	{ "ChangeLightingChannelMask", ChangeLightingChannelMask },
	{ "GetLevelScriptActor", GetLevelScriptActor },
	{ "is_nil", wLua::LuaStatic::isnil },
	{ "__gc", wLua::LuaStatic::removeUClassFrameCache },
	{ NULL, NULL }
};

void Register(lua_State *InScriptContext)
{
	lua_newtable(InScriptContext);
	luaL_register(InScriptContext, NULL, Lib_Funcs);
	AzureHelpFuncs::AuxRegister(InScriptContext, "Level");
}
void SetMtLink(lua_State *InScriptContext)
{
	AzureHelpFuncs::AuxSetMtLink(InScriptContext, "Level", "Object",USERDATATYPE_UOBJECT);
}

}