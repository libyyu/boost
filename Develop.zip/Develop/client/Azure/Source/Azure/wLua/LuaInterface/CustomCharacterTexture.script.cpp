#include "Azure.h"
#include "Utility/help_funcs.h"
#include "wLua/UObjectHeaders.h"
#include "Utilities/CustomCharacterTexture.h"
#include "AzureLuaIntegration.h"

namespace LuaCustomCharacterTexture
{
int32 DrawCustomTexture(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CustomCharacterTexture",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CustomCharacterTexture must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		UTextureRenderTarget2D* renderTarget = nullptr;
		bool needClear;
	} Params;
	Params.renderTarget = (UTextureRenderTarget2D*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"TextureRenderTarget2D");;
	Params.needClear = !!(lua_toboolean(InScriptContext, 3));
#if UE_GAME
	ACustomCharacterTexture * This = (ACustomCharacterTexture *)Obj;
	This->DrawCustomTexture(Params.renderTarget,Params.needClear);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("DrawCustomTexture"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(UTextureRenderTarget2D**)(params.GetStructMemory() + 0) = Params.renderTarget;
		*(bool*)(params.GetStructMemory() + 8) = Params.needClear;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.renderTarget = *(UTextureRenderTarget2D**)(params.GetStructMemory() + 0);
		Params.needClear = *(bool*)(params.GetStructMemory() + 8);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 CreateCustomRenderTarget(lua_State* InScriptContext)
{
	UClass * Obj = ACustomCharacterTexture::StaticClass(); 
	struct FDispatchParams
	{
		bool bAutoGenerateMips;
		bool bHDR;
		int32 Resolution;
		bool bForceLinearGamma;
		UObject* InOuter = nullptr;
		UTextureRenderTarget2D* ReturnValue = nullptr;
	} Params;
	Params.bAutoGenerateMips = !!(lua_toboolean(InScriptContext, 1));
	Params.bHDR = !!(lua_toboolean(InScriptContext, 2));
	Params.Resolution = (luaL_checkint(InScriptContext, 3));
	Params.bForceLinearGamma = !!(lua_toboolean(InScriptContext, 4));
	Params.InOuter = (UObject*)wLua::FLuaUtils::GetUObject(InScriptContext,5,"Object");;
#if UE_GAME
	Params.ReturnValue = ACustomCharacterTexture::CreateCustomRenderTarget(Params.bAutoGenerateMips,Params.bHDR,Params.Resolution,Params.bForceLinearGamma,Params.InOuter);
#else
	UFunction* Function = Obj->FindFunctionByName(TEXT("CreateCustomRenderTarget"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(bool*)(params.GetStructMemory() + 0) = Params.bAutoGenerateMips;
		*(bool*)(params.GetStructMemory() + 1) = Params.bHDR;
		*(int32*)(params.GetStructMemory() + 4) = Params.Resolution;
		*(bool*)(params.GetStructMemory() + 8) = Params.bForceLinearGamma;
		*(UObject**)(params.GetStructMemory() + 16) = Params.InOuter;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.bAutoGenerateMips = *(bool*)(params.GetStructMemory() + 0);
		Params.bHDR = *(bool*)(params.GetStructMemory() + 1);
		Params.Resolution = *(int32*)(params.GetStructMemory() + 4);
		Params.bForceLinearGamma = *(bool*)(params.GetStructMemory() + 8);
		Params.InOuter = *(UObject**)(params.GetStructMemory() + 16);
		Params.ReturnValue = *(UTextureRenderTarget2D**)(params.GetStructMemory() + 24);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 Get_Material(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CustomCharacterTexture",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CustomCharacterTexture must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(ACustomCharacterTexture::StaticClass(), TEXT("Material"));
	if(!Property) { check(false); return 0;}
	UMaterialInterface* PropertyValue;
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaUtils::ReturnUObject(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_Material(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CustomCharacterTexture",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CustomCharacterTexture must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(ACustomCharacterTexture::StaticClass(), TEXT("Material"));
	if(!Property) { check(false); return 0;}
	UMaterialInterface* PropertyValue = (UMaterialInterface*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"MaterialInterface");;
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 New(lua_State* InScriptContext)
{
	UObject* Outer = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Object");
	FName Name = FName(luaL_checkstring(InScriptContext, 2));
	UObject* Obj = NewObject<ACustomCharacterTexture>(Outer, Name);
	wLua::FLuaUtils::ReturnUObject(InScriptContext,Obj);
	return 1;
}

int32 Destroy(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CustomCharacterTexture",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CustomCharacterTexture must be non-null"); lua_error(InScriptContext);  return 0;}
		AActor * actor = Cast<AActor>(Obj);
		actor->Destroy();
		userdata->flag |= wLua::LuaObjectFlag::DESTROYED;
		wLua::FLuaUtils::RemoveObjectReference(Obj, userdata->stamp, InScriptContext);
#ifdef AZURE_BUILD_WLUACHECK
		UE_LOG(LogAzure, Warning, TEXT("Destroy CustomCharacterTexture: %x userdata:%x   stamp:%x"),Obj,userdata,userdata->stamp);
#endif
	return 0;
}

int32 Class(lua_State* InScriptContext)
{
	UClass* Class = ACustomCharacterTexture::StaticClass();
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Class);
	return 1;
}

const luaL_Reg Lib_Funcs[] =
{
	{ "New", New },
	{ "Destroy", Destroy },
	{ "Class", Class },
	{ "DrawCustomTexture", DrawCustomTexture },
	{ "CreateCustomRenderTarget", CreateCustomRenderTarget },
	{ "Get_Material", Get_Material },
	{ "Set_Material", Set_Material },
	{ "is_nil", wLua::LuaStatic::isnil },
	{ "__gc", wLua::LuaStatic::removeUClassFrameCache },
	{ NULL, NULL }
};

void Register(lua_State *InScriptContext)
{
	lua_newtable(InScriptContext);
	luaL_register(InScriptContext, NULL, Lib_Funcs);
	AzureHelpFuncs::AuxRegister(InScriptContext, "CustomCharacterTexture");
}
void SetMtLink(lua_State *InScriptContext)
{
	AzureHelpFuncs::AuxSetMtLink(InScriptContext, "CustomCharacterTexture", "Actor",USERDATATYPE_UOBJECT);
}

}