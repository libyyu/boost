#include "Azure.h"
#include "Utility/help_funcs.h"
#include "wLua/UObjectHeaders.h"
#include "Components/DecalComponent.h"
#include "AzureLuaIntegration.h"

namespace LuaDecalComponent
{
int32 Set_DecalSize(lua_State*);

int32 SetSortOrder(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"DecalComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"DecalComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		int32 Value;
	} Params;
	Params.Value = (luaL_checkint(InScriptContext, 2));
#if UE_GAME
	UDecalComponent * This = (UDecalComponent *)Obj;
	This->SetSortOrder(Params.Value);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetSortOrder"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(int32*)(params.GetStructMemory() + 0) = Params.Value;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.Value = *(int32*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetFadeScreenSize(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"DecalComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"DecalComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float NewFadeScreenSize;
	} Params;
	Params.NewFadeScreenSize = (float)(luaL_checknumber(InScriptContext, 2));
#if UE_GAME
	UDecalComponent * This = (UDecalComponent *)Obj;
	This->SetFadeScreenSize(Params.NewFadeScreenSize);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetFadeScreenSize"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(float*)(params.GetStructMemory() + 0) = Params.NewFadeScreenSize;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.NewFadeScreenSize = *(float*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetFadeOut(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"DecalComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"DecalComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float StartDelay;
		float Duration;
		bool DestroyOwnerAfterFade;
	} Params;
	Params.StartDelay = (float)(luaL_checknumber(InScriptContext, 2));
	Params.Duration = (float)(luaL_checknumber(InScriptContext, 3));
	Params.DestroyOwnerAfterFade = lua_isnoneornil(InScriptContext,4) ? bool(true) : !!(lua_toboolean(InScriptContext, 4));
#if UE_GAME
	UDecalComponent * This = (UDecalComponent *)Obj;
	This->SetFadeOut(Params.StartDelay,Params.Duration,Params.DestroyOwnerAfterFade);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetFadeOut"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(float*)(params.GetStructMemory() + 0) = Params.StartDelay;
		*(float*)(params.GetStructMemory() + 4) = Params.Duration;
		*(bool*)(params.GetStructMemory() + 8) = Params.DestroyOwnerAfterFade;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.StartDelay = *(float*)(params.GetStructMemory() + 0);
		Params.Duration = *(float*)(params.GetStructMemory() + 4);
		Params.DestroyOwnerAfterFade = *(bool*)(params.GetStructMemory() + 8);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetFadeIn(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"DecalComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"DecalComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float StartDelay;
		float Duaration;
	} Params;
	Params.StartDelay = (float)(luaL_checknumber(InScriptContext, 2));
	Params.Duaration = (float)(luaL_checknumber(InScriptContext, 3));
#if UE_GAME
	UDecalComponent * This = (UDecalComponent *)Obj;
	This->SetFadeIn(Params.StartDelay,Params.Duaration);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetFadeIn"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(float*)(params.GetStructMemory() + 0) = Params.StartDelay;
		*(float*)(params.GetStructMemory() + 4) = Params.Duaration;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.StartDelay = *(float*)(params.GetStructMemory() + 0);
		Params.Duaration = *(float*)(params.GetStructMemory() + 4);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetDecalMaterial(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"DecalComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"DecalComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		UMaterialInterface* NewDecalMaterial = nullptr;
	} Params;
	Params.NewDecalMaterial = (UMaterialInterface*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"MaterialInterface");;
#if UE_GAME
	UDecalComponent * This = (UDecalComponent *)Obj;
	This->SetDecalMaterial(Params.NewDecalMaterial);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetDecalMaterial"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(UMaterialInterface**)(params.GetStructMemory() + 0) = Params.NewDecalMaterial;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.NewDecalMaterial = *(UMaterialInterface**)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 GetFadeStartDelay(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"DecalComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"DecalComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float ReturnValue;
	} Params;
#if UE_GAME
	UDecalComponent * This = (UDecalComponent *)Obj;
	Params.ReturnValue = This->GetFadeStartDelay();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetFadeStartDelay"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(float*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushnumber(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetFadeInStartDelay(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"DecalComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"DecalComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float ReturnValue;
	} Params;
#if UE_GAME
	UDecalComponent * This = (UDecalComponent *)Obj;
	Params.ReturnValue = This->GetFadeInStartDelay();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetFadeInStartDelay"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(float*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushnumber(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetFadeInDuration(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"DecalComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"DecalComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float ReturnValue;
	} Params;
#if UE_GAME
	UDecalComponent * This = (UDecalComponent *)Obj;
	Params.ReturnValue = This->GetFadeInDuration();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetFadeInDuration"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(float*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushnumber(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetFadeDuration(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"DecalComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"DecalComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float ReturnValue;
	} Params;
#if UE_GAME
	UDecalComponent * This = (UDecalComponent *)Obj;
	Params.ReturnValue = This->GetFadeDuration();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetFadeDuration"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(float*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushnumber(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetDecalMaterial(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"DecalComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"DecalComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		UMaterialInterface* ReturnValue = nullptr;
	} Params;
#if UE_GAME
	UDecalComponent * This = (UDecalComponent *)Obj;
	Params.ReturnValue = This->GetDecalMaterial();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetDecalMaterial"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(UMaterialInterface**)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 CreateDynamicMaterialInstance(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"DecalComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"DecalComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		UMaterialInstanceDynamic* ReturnValue = nullptr;
	} Params;
#if UE_GAME
	UDecalComponent * This = (UDecalComponent *)Obj;
	Params.ReturnValue = This->CreateDynamicMaterialInstance();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("CreateDynamicMaterialInstance"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(UMaterialInstanceDynamic**)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 Get_DecalMaterial(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"DecalComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"DecalComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UDecalComponent::StaticClass(), TEXT("DecalMaterial"));
	if(!Property) { check(false); return 0;}
	UMaterialInterface* PropertyValue;
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaUtils::ReturnUObject(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_SortOrder(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"DecalComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"DecalComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UDecalComponent::StaticClass(), TEXT("SortOrder"));
	if(!Property) { check(false); return 0;}
	int32 PropertyValue = int32();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushinteger(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_FadeScreenSize(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"DecalComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"DecalComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UDecalComponent::StaticClass(), TEXT("FadeScreenSize"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_FadeStartDelay(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"DecalComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"DecalComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UDecalComponent::StaticClass(), TEXT("FadeStartDelay"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_FadeDuration(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"DecalComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"DecalComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UDecalComponent::StaticClass(), TEXT("FadeDuration"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_FadeInDuration(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"DecalComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"DecalComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UDecalComponent::StaticClass(), TEXT("FadeInDuration"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_FadeInStartDelay(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"DecalComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"DecalComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UDecalComponent::StaticClass(), TEXT("FadeInStartDelay"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_bDestroyOwnerAfterFade(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"DecalComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"DecalComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UDecalComponent::StaticClass(), TEXT("bDestroyOwnerAfterFade"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_DecalSize(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"DecalComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"DecalComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UDecalComponent::StaticClass(), TEXT("DecalSize"));
	if(!Property) { check(false); return 0;}
	FVector PropertyValue = FVector();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaVector::Return(InScriptContext, PropertyValue);
	return 1;
}

int32 New(lua_State* InScriptContext)
{
	UObject* Outer = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Object");
	FName Name = FName(luaL_checkstring(InScriptContext, 2));
	UObject* Obj = NewObject<UDecalComponent>(Outer, Name);
	wLua::FLuaUtils::ReturnUObject(InScriptContext,Obj);
	return 1;
}

int32 Destroy(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"DecalComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"DecalComponent must be non-null"); lua_error(InScriptContext);  return 0;}
		UActorComponent * com = Cast<UActorComponent>(Obj);
		if(lua_isnoneornil(InScriptContext,2))
			com->DestroyComponent();
		else
			com->DestroyComponent(!!lua_toboolean(InScriptContext,2));
		userdata->flag |= wLua::LuaObjectFlag::DESTROYED;
		wLua::FLuaUtils::RemoveObjectReference(Obj, userdata->stamp, InScriptContext);
#ifdef AZURE_BUILD_WLUACHECK
		UE_LOG(LogAzure, Warning, TEXT("Destroy DecalComponent: %x userdata:%x   stamp:%x"),Obj,userdata,userdata->stamp);
#endif
	return 0;
}

int32 Class(lua_State* InScriptContext)
{
	UClass* Class = UDecalComponent::StaticClass();
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Class);
	return 1;
}

const luaL_Reg Lib_Funcs[] =
{
	{ "New", New },
	{ "Destroy", Destroy },
	{ "Class", Class },
	{ "SetSortOrder", SetSortOrder },
	{ "SetFadeScreenSize", SetFadeScreenSize },
	{ "SetFadeOut", SetFadeOut },
	{ "SetFadeIn", SetFadeIn },
	{ "SetDecalMaterial", SetDecalMaterial },
	{ "GetFadeStartDelay", GetFadeStartDelay },
	{ "GetFadeInStartDelay", GetFadeInStartDelay },
	{ "GetFadeInDuration", GetFadeInDuration },
	{ "GetFadeDuration", GetFadeDuration },
	{ "GetDecalMaterial", GetDecalMaterial },
	{ "CreateDynamicMaterialInstance", CreateDynamicMaterialInstance },
	{ "Get_DecalMaterial", Get_DecalMaterial },
	{ "Get_SortOrder", Get_SortOrder },
	{ "Get_FadeScreenSize", Get_FadeScreenSize },
	{ "Get_FadeStartDelay", Get_FadeStartDelay },
	{ "Get_FadeDuration", Get_FadeDuration },
	{ "Get_FadeInDuration", Get_FadeInDuration },
	{ "Get_FadeInStartDelay", Get_FadeInStartDelay },
	{ "Get_bDestroyOwnerAfterFade", Get_bDestroyOwnerAfterFade },
	{ "Get_DecalSize", Get_DecalSize },
	{ "Set_DecalSize", Set_DecalSize },
	{ "is_nil", wLua::LuaStatic::isnil },
	{ "__gc", wLua::LuaStatic::removeUClassFrameCache },
	{ NULL, NULL }
};

void Register(lua_State *InScriptContext)
{
	lua_newtable(InScriptContext);
	luaL_register(InScriptContext, NULL, Lib_Funcs);
	AzureHelpFuncs::AuxRegister(InScriptContext, "DecalComponent");
}
void SetMtLink(lua_State *InScriptContext)
{
	AzureHelpFuncs::AuxSetMtLink(InScriptContext, "DecalComponent", "SceneComponent",USERDATATYPE_UOBJECT);
}

}