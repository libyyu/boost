#include "Azure.h"
#include "Utility/help_funcs.h"
#include "wLua/UObjectHeaders.h"
#include "DefaultLevelSequenceInstanceData.h"
#include "AzureLuaIntegration.h"

namespace LuaDefaultLevelSequenceInstanceData
{
int32 Get_TransformOriginActor(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"DefaultLevelSequenceInstanceData",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"DefaultLevelSequenceInstanceData must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UDefaultLevelSequenceInstanceData::StaticClass(), TEXT("TransformOriginActor"));
	if(!Property) { check(false); return 0;}
	AActor* PropertyValue;
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaUtils::ReturnUObject(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_TransformOriginActor(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"DefaultLevelSequenceInstanceData",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"DefaultLevelSequenceInstanceData must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UDefaultLevelSequenceInstanceData::StaticClass(), TEXT("TransformOriginActor"));
	if(!Property) { check(false); return 0;}
	AActor* PropertyValue = (AActor*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"Actor");;
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_TransformOrigin(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"DefaultLevelSequenceInstanceData",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"DefaultLevelSequenceInstanceData must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UDefaultLevelSequenceInstanceData::StaticClass(), TEXT("TransformOrigin"));
	if(!Property) { check(false); return 0;}
	FTransform PropertyValue = FTransform();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaTransform::Return(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_TransformOrigin(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"DefaultLevelSequenceInstanceData",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"DefaultLevelSequenceInstanceData must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UDefaultLevelSequenceInstanceData::StaticClass(), TEXT("TransformOrigin"));
	if(!Property) { check(false); return 0;}
	FTransform PropertyValue = (wLua::FLuaTransform::Get(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 New(lua_State* InScriptContext)
{
	UObject* Outer = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Object");
	FName Name = FName(luaL_checkstring(InScriptContext, 2));
	UObject* Obj = NewObject<UDefaultLevelSequenceInstanceData>(Outer, Name);
	wLua::FLuaUtils::ReturnUObject(InScriptContext,Obj);
	return 1;
}

int32 Destroy(lua_State* InScriptContext)
{
	return 0;
}

int32 Class(lua_State* InScriptContext)
{
	UClass* Class = UDefaultLevelSequenceInstanceData::StaticClass();
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Class);
	return 1;
}

const luaL_Reg Lib_Funcs[] =
{
	{ "New", New },
	{ "Destroy", Destroy },
	{ "Class", Class },
	{ "Get_TransformOriginActor", Get_TransformOriginActor },
	{ "Set_TransformOriginActor", Set_TransformOriginActor },
	{ "Get_TransformOrigin", Get_TransformOrigin },
	{ "Set_TransformOrigin", Set_TransformOrigin },
	{ "is_nil", wLua::LuaStatic::isnil },
	{ "__gc", wLua::LuaStatic::removeUClassFrameCache },
	{ NULL, NULL }
};

void Register(lua_State *InScriptContext)
{
	lua_newtable(InScriptContext);
	luaL_register(InScriptContext, NULL, Lib_Funcs);
	AzureHelpFuncs::AuxRegister(InScriptContext, "DefaultLevelSequenceInstanceData");
}
void SetMtLink(lua_State *InScriptContext)
{
	AzureHelpFuncs::AuxSetMtLink(InScriptContext, "DefaultLevelSequenceInstanceData", "Object",USERDATATYPE_UOBJECT);
}

}