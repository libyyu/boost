#include "Azure.h"
#include "Utility/help_funcs.h"
#include "wLua/UObjectHeaders.h"
#include "AzureLuaIntegration.h"

namespace LuaPhysicsAsset
{
int32 Get_PhysicalAnimationProfiles(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PhysicsAsset",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PhysicsAsset must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UPhysicsAsset::StaticClass(), TEXT("PhysicalAnimationProfiles"));
	if(!Property) { check(false); return 0;}
	TArray<FName> PropertyValue;
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	{lua_newtable(InScriptContext); int i = 1; for(auto It = PropertyValue.CreateConstIterator(); It; ++It,++i) {  lua_pushstring(InScriptContext, TCHAR_TO_UTF8(*(*It).ToString())); lua_rawseti(InScriptContext,-2,i);     }  }
	return 1;
}

int32 Set_PhysicalAnimationProfiles(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PhysicsAsset",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PhysicsAsset must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UPhysicsAsset::StaticClass(), TEXT("PhysicalAnimationProfiles"));
	if(!Property) { check(false); return 0;}
	TArray<FName> PropertyValue = [](lua_State * _InScriptContext){ TArray<FName> ret; lua_pushnil(_InScriptContext); while(lua_next(_InScriptContext,2)!=0){ FName item = FName(UTF8_TO_TCHAR(luaL_checkstring(_InScriptContext, -1))); ret.Add(item); lua_pop(_InScriptContext,1);  } return ret; }(InScriptContext);;
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_ConstraintProfiles(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PhysicsAsset",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PhysicsAsset must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UPhysicsAsset::StaticClass(), TEXT("ConstraintProfiles"));
	if(!Property) { check(false); return 0;}
	TArray<FName> PropertyValue;
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	{lua_newtable(InScriptContext); int i = 1; for(auto It = PropertyValue.CreateConstIterator(); It; ++It,++i) {  lua_pushstring(InScriptContext, TCHAR_TO_UTF8(*(*It).ToString())); lua_rawseti(InScriptContext,-2,i);     }  }
	return 1;
}

int32 Set_ConstraintProfiles(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PhysicsAsset",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PhysicsAsset must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UPhysicsAsset::StaticClass(), TEXT("ConstraintProfiles"));
	if(!Property) { check(false); return 0;}
	TArray<FName> PropertyValue = [](lua_State * _InScriptContext){ TArray<FName> ret; lua_pushnil(_InScriptContext); while(lua_next(_InScriptContext,2)!=0){ FName item = FName(UTF8_TO_TCHAR(luaL_checkstring(_InScriptContext, -1))); ret.Add(item); lua_pop(_InScriptContext,1);  } return ret; }(InScriptContext);;
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bUseAsyncScene(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PhysicsAsset",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PhysicsAsset must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UPhysicsAsset::StaticClass(), TEXT("bUseAsyncScene"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bUseAsyncScene(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PhysicsAsset",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PhysicsAsset must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UPhysicsAsset::StaticClass(), TEXT("bUseAsyncScene"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bNotForDedicatedServer(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PhysicsAsset",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PhysicsAsset must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UPhysicsAsset::StaticClass(), TEXT("bNotForDedicatedServer"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bNotForDedicatedServer(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PhysicsAsset",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PhysicsAsset must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UPhysicsAsset::StaticClass(), TEXT("bNotForDedicatedServer"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_ThumbnailInfo(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PhysicsAsset",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PhysicsAsset must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UPhysicsAsset::StaticClass(), TEXT("ThumbnailInfo"));
	if(!Property) { check(false); return 0;}
	UThumbnailInfo* PropertyValue;
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaUtils::ReturnUObject(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_ThumbnailInfo(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PhysicsAsset",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PhysicsAsset must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UPhysicsAsset::StaticClass(), TEXT("ThumbnailInfo"));
	if(!Property) { check(false); return 0;}
	UThumbnailInfo* PropertyValue = (UThumbnailInfo*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"ThumbnailInfo");;
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 New(lua_State* InScriptContext)
{
	UObject* Outer = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Actor");
	FName Name = FName(luaL_checkstring(InScriptContext, 2));
	UObject* Obj = NewObject<UPhysicsAsset>(Outer, Name);
	wLua::FLuaUtils::ReturnUObject(InScriptContext,Obj);
	return 1;
}

int32 Destroy(lua_State* InScriptContext)
{
	return 0;
}

int32 Class(lua_State* InScriptContext)
{
	UClass* Class = UPhysicsAsset::StaticClass();
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Class);
	return 1;
}

const luaL_Reg Lib_Funcs[] =
{
	{ "New", New },
	{ "Destroy", Destroy },
	{ "Class", Class },
	{ "Get_PhysicalAnimationProfiles", Get_PhysicalAnimationProfiles },
	{ "Set_PhysicalAnimationProfiles", Set_PhysicalAnimationProfiles },
	{ "Get_ConstraintProfiles", Get_ConstraintProfiles },
	{ "Set_ConstraintProfiles", Set_ConstraintProfiles },
	{ "Get_bUseAsyncScene", Get_bUseAsyncScene },
	{ "Set_bUseAsyncScene", Set_bUseAsyncScene },
	{ "Get_bNotForDedicatedServer", Get_bNotForDedicatedServer },
	{ "Set_bNotForDedicatedServer", Set_bNotForDedicatedServer },
	{ "Get_ThumbnailInfo", Get_ThumbnailInfo },
	{ "Set_ThumbnailInfo", Set_ThumbnailInfo },
	{ "is_nil", wLua::LuaStatic::isnil },
	{ "__gc", wLua::LuaStatic::removeUClassFrameCache },
	{ NULL, NULL }
};

void Register(lua_State *InScriptContext)
{
	lua_newtable(InScriptContext);
	luaL_register(InScriptContext, NULL, Lib_Funcs);
	AzureHelpFuncs::AuxRegister(InScriptContext, "PhysicsAsset");
}
void SetMtLink(lua_State *InScriptContext)
{
	AzureHelpFuncs::AuxSetMtLink(InScriptContext, "PhysicsAsset","Object",USERDATATYPE_UOBJECT);
}

}