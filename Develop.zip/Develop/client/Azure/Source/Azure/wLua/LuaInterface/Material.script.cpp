#include "Azure.h"
#include "Utility/help_funcs.h"
#include "wLua/UObjectHeaders.h"
#include "Materials/Material.h"
#include "AzureLuaIntegration.h"

namespace LuaMaterial
{
int32 Get_PhysMaterial(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Material",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Material must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UMaterial::StaticClass(), TEXT("PhysMaterial"));
	if(!Property) { check(false); return 0;}
	UPhysicalMaterial* PropertyValue;
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaUtils::ReturnUObject(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_PhysMaterial(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Material",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Material must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UMaterial::StaticClass(), TEXT("PhysMaterial"));
	if(!Property) { check(false); return 0;}
	UPhysicalMaterial* PropertyValue = (UPhysicalMaterial*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"PhysicalMaterial");;
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_MaterialDomain(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Material",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Material must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UMaterial::StaticClass(), TEXT("MaterialDomain"));
	if(!Property) { check(false); return 0;}
	TEnumAsByte<EMaterialDomain> PropertyValue = TEnumAsByte<EMaterialDomain>();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushinteger(InScriptContext, (int)PropertyValue);
	return 1;
}

int32 Get_BlendMode(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Material",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Material must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UMaterial::StaticClass(), TEXT("BlendMode"));
	if(!Property) { check(false); return 0;}
	TEnumAsByte<EBlendMode> PropertyValue = TEnumAsByte<EBlendMode>();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushinteger(InScriptContext, (int)PropertyValue);
	return 1;
}

int32 Get_DecalBlendMode(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Material",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Material must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UMaterial::StaticClass(), TEXT("DecalBlendMode"));
	if(!Property) { check(false); return 0;}
	TEnumAsByte<EDecalBlendMode> PropertyValue = TEnumAsByte<EDecalBlendMode>();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushinteger(InScriptContext, (int)PropertyValue);
	return 1;
}

int32 Set_DecalBlendMode(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Material",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Material must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UMaterial::StaticClass(), TEXT("DecalBlendMode"));
	if(!Property) { check(false); return 0;}
	TEnumAsByte<EDecalBlendMode> PropertyValue = (TEnumAsByte<EDecalBlendMode>)(luaL_checkint(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_MaterialDecalResponse(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Material",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Material must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UMaterial::StaticClass(), TEXT("MaterialDecalResponse"));
	if(!Property) { check(false); return 0;}
	TEnumAsByte<EMaterialDecalResponse> PropertyValue = TEnumAsByte<EMaterialDecalResponse>();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushinteger(InScriptContext, (int)PropertyValue);
	return 1;
}

int32 Get_ShadingModel(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Material",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Material must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UMaterial::StaticClass(), TEXT("ShadingModel"));
	if(!Property) { check(false); return 0;}
	TEnumAsByte<EMaterialShadingModel> PropertyValue = TEnumAsByte<EMaterialShadingModel>();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushinteger(InScriptContext, (int)PropertyValue);
	return 1;
}

int32 Set_ShadingModel(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Material",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Material must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UMaterial::StaticClass(), TEXT("ShadingModel"));
	if(!Property) { check(false); return 0;}
	TEnumAsByte<EMaterialShadingModel> PropertyValue = (TEnumAsByte<EMaterialShadingModel>)(luaL_checkint(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_OpacityMaskClipValue(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Material",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Material must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UMaterial::StaticClass(), TEXT("OpacityMaskClipValue"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_OpacityMaskClipValue(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Material",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Material must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UMaterial::StaticClass(), TEXT("OpacityMaskClipValue"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bCastDynamicShadowAsMasked(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Material",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Material must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UMaterial::StaticClass(), TEXT("bCastDynamicShadowAsMasked"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bCastDynamicShadowAsMasked(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Material",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Material must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UMaterial::StaticClass(), TEXT("bCastDynamicShadowAsMasked"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bEnableSeparateTranslucency(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Material",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Material must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UMaterial::StaticClass(), TEXT("bEnableSeparateTranslucency"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bEnableSeparateTranslucency(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Material",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Material must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UMaterial::StaticClass(), TEXT("bEnableSeparateTranslucency"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bEnableMobileSeparateTranslucency(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Material",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Material must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UMaterial::StaticClass(), TEXT("bEnableMobileSeparateTranslucency"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bEnableMobileSeparateTranslucency(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Material",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Material must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UMaterial::StaticClass(), TEXT("bEnableMobileSeparateTranslucency"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bAzureEnableBasePassTranslucent(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Material",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Material must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UMaterial::StaticClass(), TEXT("bAzureEnableBasePassTranslucent"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bAzureEnableBasePassTranslucent(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Material",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Material must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UMaterial::StaticClass(), TEXT("bAzureEnableBasePassTranslucent"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bAzureEnableMobileSoftMasked(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Material",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Material must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UMaterial::StaticClass(), TEXT("bAzureEnableMobileSoftMasked"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bAzureEnableMobileSoftMasked(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Material",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Material must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UMaterial::StaticClass(), TEXT("bAzureEnableMobileSoftMasked"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bEnableResponsiveAA(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Material",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Material must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UMaterial::StaticClass(), TEXT("bEnableResponsiveAA"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bEnableResponsiveAA(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Material",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Material must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UMaterial::StaticClass(), TEXT("bEnableResponsiveAA"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bScreenSpaceReflections(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Material",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Material must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UMaterial::StaticClass(), TEXT("bScreenSpaceReflections"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bScreenSpaceReflections(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Material",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Material must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UMaterial::StaticClass(), TEXT("bScreenSpaceReflections"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bContactShadows(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Material",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Material must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UMaterial::StaticClass(), TEXT("bContactShadows"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bContactShadows(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Material",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Material must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UMaterial::StaticClass(), TEXT("bContactShadows"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_TwoSided(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Material",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Material must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UMaterial::StaticClass(), TEXT("TwoSided"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_TwoSided(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Material",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Material must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UMaterial::StaticClass(), TEXT("TwoSided"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_DitheredLODTransition(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Material",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Material must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UMaterial::StaticClass(), TEXT("DitheredLODTransition"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_DitheredLODTransition(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Material",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Material must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UMaterial::StaticClass(), TEXT("DitheredLODTransition"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bAzureDisableLODAutoDither(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Material",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Material must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UMaterial::StaticClass(), TEXT("bAzureDisableLODAutoDither"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bAzureDisableLODAutoDither(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Material",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Material must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UMaterial::StaticClass(), TEXT("bAzureDisableLODAutoDither"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_DitherOpacityMask(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Material",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Material must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UMaterial::StaticClass(), TEXT("DitherOpacityMask"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_DitherOpacityMask(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Material",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Material must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UMaterial::StaticClass(), TEXT("DitherOpacityMask"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bAllowNegativeEmissiveColor(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Material",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Material must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UMaterial::StaticClass(), TEXT("bAllowNegativeEmissiveColor"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bAllowNegativeEmissiveColor(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Material",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Material must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UMaterial::StaticClass(), TEXT("bAllowNegativeEmissiveColor"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_ExportAllQualityLevels(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Material",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Material must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UMaterial::StaticClass(), TEXT("ExportAllQualityLevels"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_ExportAllQualityLevels(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Material",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Material must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UMaterial::StaticClass(), TEXT("ExportAllQualityLevels"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_AzureExportWeatherQualityLevels(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Material",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Material must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UMaterial::StaticClass(), TEXT("AzureExportWeatherQualityLevels"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_AzureExportWeatherQualityLevels(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Material",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Material must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UMaterial::StaticClass(), TEXT("AzureExportWeatherQualityLevels"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_NumCustomizedUVs(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Material",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Material must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UMaterial::StaticClass(), TEXT("NumCustomizedUVs"));
	if(!Property) { check(false); return 0;}
	int32 PropertyValue = int32();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushinteger(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_NumCustomizedUVs(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Material",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Material must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UMaterial::StaticClass(), TEXT("NumCustomizedUVs"));
	if(!Property) { check(false); return 0;}
	int32 PropertyValue = (luaL_checkint(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_TranslucencyLightingMode(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Material",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Material must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UMaterial::StaticClass(), TEXT("TranslucencyLightingMode"));
	if(!Property) { check(false); return 0;}
	TEnumAsByte<ETranslucencyLightingMode> PropertyValue = TEnumAsByte<ETranslucencyLightingMode>();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushinteger(InScriptContext, (int)PropertyValue);
	return 1;
}

int32 Set_TranslucencyLightingMode(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Material",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Material must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UMaterial::StaticClass(), TEXT("TranslucencyLightingMode"));
	if(!Property) { check(false); return 0;}
	TEnumAsByte<ETranslucencyLightingMode> PropertyValue = (TEnumAsByte<ETranslucencyLightingMode>)(luaL_checkint(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_TranslucencyDirectionalLightingIntensity(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Material",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Material must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UMaterial::StaticClass(), TEXT("TranslucencyDirectionalLightingIntensity"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_TranslucencyDirectionalLightingIntensity(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Material",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Material must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UMaterial::StaticClass(), TEXT("TranslucencyDirectionalLightingIntensity"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_AllowTranslucentCustomDepthWrites(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Material",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Material must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UMaterial::StaticClass(), TEXT("AllowTranslucentCustomDepthWrites"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_AllowTranslucentCustomDepthWrites(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Material",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Material must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UMaterial::StaticClass(), TEXT("AllowTranslucentCustomDepthWrites"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_TranslucentShadowDensityScale(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Material",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Material must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UMaterial::StaticClass(), TEXT("TranslucentShadowDensityScale"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_TranslucentShadowDensityScale(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Material",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Material must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UMaterial::StaticClass(), TEXT("TranslucentShadowDensityScale"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_TranslucentSelfShadowDensityScale(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Material",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Material must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UMaterial::StaticClass(), TEXT("TranslucentSelfShadowDensityScale"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_TranslucentSelfShadowDensityScale(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Material",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Material must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UMaterial::StaticClass(), TEXT("TranslucentSelfShadowDensityScale"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_TranslucentSelfShadowSecondDensityScale(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Material",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Material must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UMaterial::StaticClass(), TEXT("TranslucentSelfShadowSecondDensityScale"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_TranslucentSelfShadowSecondDensityScale(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Material",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Material must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UMaterial::StaticClass(), TEXT("TranslucentSelfShadowSecondDensityScale"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_TranslucentSelfShadowSecondOpacity(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Material",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Material must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UMaterial::StaticClass(), TEXT("TranslucentSelfShadowSecondOpacity"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_TranslucentSelfShadowSecondOpacity(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Material",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Material must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UMaterial::StaticClass(), TEXT("TranslucentSelfShadowSecondOpacity"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_TranslucentBackscatteringExponent(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Material",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Material must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UMaterial::StaticClass(), TEXT("TranslucentBackscatteringExponent"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_TranslucentBackscatteringExponent(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Material",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Material must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UMaterial::StaticClass(), TEXT("TranslucentBackscatteringExponent"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_TranslucentMultipleScatteringExtinction(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Material",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Material must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UMaterial::StaticClass(), TEXT("TranslucentMultipleScatteringExtinction"));
	if(!Property) { check(false); return 0;}
	FLinearColor PropertyValue = FLinearColor();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaLinearColor::Return(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_TranslucentMultipleScatteringExtinction(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Material",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Material must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UMaterial::StaticClass(), TEXT("TranslucentMultipleScatteringExtinction"));
	if(!Property) { check(false); return 0;}
	FLinearColor PropertyValue = (wLua::FLuaLinearColor::Get(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_TranslucentShadowStartOffset(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Material",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Material must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UMaterial::StaticClass(), TEXT("TranslucentShadowStartOffset"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_TranslucentShadowStartOffset(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Material",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Material must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UMaterial::StaticClass(), TEXT("TranslucentShadowStartOffset"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_AzureDepthFadeDistance(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Material",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Material must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UMaterial::StaticClass(), TEXT("AzureDepthFadeDistance"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_AzureDepthFadeDistance(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Material",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Material must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UMaterial::StaticClass(), TEXT("AzureDepthFadeDistance"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bDisableDepthTest(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Material",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Material must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UMaterial::StaticClass(), TEXT("bDisableDepthTest"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bDisableDepthTest(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Material",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Material must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UMaterial::StaticClass(), TEXT("bDisableDepthTest"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bWriteOnlyAlpha(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Material",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Material must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UMaterial::StaticClass(), TEXT("bWriteOnlyAlpha"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bWriteOnlyAlpha(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Material",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Material must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UMaterial::StaticClass(), TEXT("bWriteOnlyAlpha"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bColorBlendOpMax(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Material",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Material must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UMaterial::StaticClass(), TEXT("bColorBlendOpMax"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bColorBlendOpMax(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Material",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Material must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UMaterial::StaticClass(), TEXT("bColorBlendOpMax"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bColorBlendOpMin(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Material",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Material must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UMaterial::StaticClass(), TEXT("bColorBlendOpMin"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bColorBlendOpMin(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Material",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Material must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UMaterial::StaticClass(), TEXT("bColorBlendOpMin"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bGenerateSphericalParticleNormals(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Material",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Material must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UMaterial::StaticClass(), TEXT("bGenerateSphericalParticleNormals"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bGenerateSphericalParticleNormals(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Material",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Material must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UMaterial::StaticClass(), TEXT("bGenerateSphericalParticleNormals"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bTangentSpaceNormal(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Material",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Material must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UMaterial::StaticClass(), TEXT("bTangentSpaceNormal"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bTangentSpaceNormal(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Material",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Material must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UMaterial::StaticClass(), TEXT("bTangentSpaceNormal"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bUseEmissiveForDynamicAreaLighting(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Material",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Material must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UMaterial::StaticClass(), TEXT("bUseEmissiveForDynamicAreaLighting"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bUseEmissiveForDynamicAreaLighting(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Material",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Material must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UMaterial::StaticClass(), TEXT("bUseEmissiveForDynamicAreaLighting"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bBlockGI(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Material",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Material must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UMaterial::StaticClass(), TEXT("bBlockGI"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bBlockGI(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Material",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Material must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UMaterial::StaticClass(), TEXT("bBlockGI"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bUsedWithSkeletalMesh(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Material",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Material must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UMaterial::StaticClass(), TEXT("bUsedWithSkeletalMesh"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_bUsedWithEditorCompositing(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Material",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Material must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UMaterial::StaticClass(), TEXT("bUsedWithEditorCompositing"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_bUsedWithParticleSprites(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Material",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Material must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UMaterial::StaticClass(), TEXT("bUsedWithParticleSprites"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_bUsedWithBeamTrails(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Material",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Material must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UMaterial::StaticClass(), TEXT("bUsedWithBeamTrails"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_bUsedWithMeshParticles(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Material",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Material must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UMaterial::StaticClass(), TEXT("bUsedWithMeshParticles"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_bUsedWithNiagaraSprites(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Material",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Material must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UMaterial::StaticClass(), TEXT("bUsedWithNiagaraSprites"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_bUsedWithNiagaraRibbons(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Material",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Material must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UMaterial::StaticClass(), TEXT("bUsedWithNiagaraRibbons"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_bUsedWithNiagaraMeshParticles(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Material",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Material must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UMaterial::StaticClass(), TEXT("bUsedWithNiagaraMeshParticles"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_bUsedWithGeometryCache(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Material",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Material must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UMaterial::StaticClass(), TEXT("bUsedWithGeometryCache"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_bUsedWithStaticLighting(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Material",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Material must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UMaterial::StaticClass(), TEXT("bUsedWithStaticLighting"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_bUsedWithMorphTargets(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Material",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Material must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UMaterial::StaticClass(), TEXT("bUsedWithMorphTargets"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_bUsedWithSplineMeshes(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Material",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Material must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UMaterial::StaticClass(), TEXT("bUsedWithSplineMeshes"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_bUsedWithInstancedStaticMeshes(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Material",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Material must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UMaterial::StaticClass(), TEXT("bUsedWithInstancedStaticMeshes"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_bUsedWithCustomLocalPosition(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Material",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Material must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UMaterial::StaticClass(), TEXT("bUsedWithCustomLocalPosition"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_bUsedWithClothing(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Material",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Material must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UMaterial::StaticClass(), TEXT("bUsedWithClothing"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_bAutomaticallySetUsageInEditor(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Material",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Material must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UMaterial::StaticClass(), TEXT("bAutomaticallySetUsageInEditor"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_bEnableAzureDepthFade(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Material",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Material must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UMaterial::StaticClass(), TEXT("bEnableAzureDepthFade"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bEnableAzureDepthFade(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Material",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Material must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UMaterial::StaticClass(), TEXT("bEnableAzureDepthFade"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bFullyRough(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Material",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Material must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UMaterial::StaticClass(), TEXT("bFullyRough"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_bUseFullPrecision(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Material",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Material must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UMaterial::StaticClass(), TEXT("bUseFullPrecision"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_bUseLightmapDirectionality(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Material",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Material must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UMaterial::StaticClass(), TEXT("bUseLightmapDirectionality"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_bAzureUseGlobalIndirectLighting(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Material",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Material must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UMaterial::StaticClass(), TEXT("bAzureUseGlobalIndirectLighting"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_bAzureMobileForceDepthTextureReads(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Material",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Material must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UMaterial::StaticClass(), TEXT("bAzureMobileForceDepthTextureReads"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_bUseHQForwardReflections(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Material",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Material must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UMaterial::StaticClass(), TEXT("bUseHQForwardReflections"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_bUsePlanarForwardReflections(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Material",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Material must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UMaterial::StaticClass(), TEXT("bUsePlanarForwardReflections"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_bNormalCurvatureToRoughness(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Material",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Material must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UMaterial::StaticClass(), TEXT("bNormalCurvatureToRoughness"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_D3D11TessellationMode(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Material",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Material must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UMaterial::StaticClass(), TEXT("D3D11TessellationMode"));
	if(!Property) { check(false); return 0;}
	TEnumAsByte<EMaterialTessellationMode> PropertyValue = TEnumAsByte<EMaterialTessellationMode>();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushinteger(InScriptContext, (int)PropertyValue);
	return 1;
}

int32 Get_bEnableCrackFreeDisplacement(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Material",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Material must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UMaterial::StaticClass(), TEXT("bEnableCrackFreeDisplacement"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_bEnableAdaptiveTessellation(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Material",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Material must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UMaterial::StaticClass(), TEXT("bEnableAdaptiveTessellation"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_MaxDisplacement(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Material",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Material must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UMaterial::StaticClass(), TEXT("MaxDisplacement"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_MaxDisplacement(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Material",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Material must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UMaterial::StaticClass(), TEXT("MaxDisplacement"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_Wireframe(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Material",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Material must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UMaterial::StaticClass(), TEXT("Wireframe"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_Wireframe(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Material",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Material must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UMaterial::StaticClass(), TEXT("Wireframe"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bOutputVelocityOnBasePass(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Material",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Material must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UMaterial::StaticClass(), TEXT("bOutputVelocityOnBasePass"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bOutputVelocityOnBasePass(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Material",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Material must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UMaterial::StaticClass(), TEXT("bOutputVelocityOnBasePass"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bUseMaterialAttributes(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Material",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Material must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UMaterial::StaticClass(), TEXT("bUseMaterialAttributes"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bUseMaterialAttributes(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Material",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Material must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UMaterial::StaticClass(), TEXT("bUseMaterialAttributes"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bUseTranslucencyVertexFog(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Material",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Material must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UMaterial::StaticClass(), TEXT("bUseTranslucencyVertexFog"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bUseTranslucencyVertexFog(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Material",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Material must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UMaterial::StaticClass(), TEXT("bUseTranslucencyVertexFog"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bComputeFogPerPixel(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Material",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Material must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UMaterial::StaticClass(), TEXT("bComputeFogPerPixel"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bComputeFogPerPixel(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Material",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Material must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UMaterial::StaticClass(), TEXT("bComputeFogPerPixel"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_BlendableLocation(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Material",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Material must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UMaterial::StaticClass(), TEXT("BlendableLocation"));
	if(!Property) { check(false); return 0;}
	TEnumAsByte<EBlendableLocation> PropertyValue = TEnumAsByte<EBlendableLocation>();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushinteger(InScriptContext, (int)PropertyValue);
	return 1;
}

int32 Set_BlendableLocation(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Material",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Material must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UMaterial::StaticClass(), TEXT("BlendableLocation"));
	if(!Property) { check(false); return 0;}
	TEnumAsByte<EBlendableLocation> PropertyValue = (TEnumAsByte<EBlendableLocation>)(luaL_checkint(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_BlendablePriority(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Material",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Material must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UMaterial::StaticClass(), TEXT("BlendablePriority"));
	if(!Property) { check(false); return 0;}
	int32 PropertyValue = int32();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushinteger(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_BlendablePriority(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Material",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Material must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UMaterial::StaticClass(), TEXT("BlendablePriority"));
	if(!Property) { check(false); return 0;}
	int32 PropertyValue = (luaL_checkint(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_BlendableOutputAlpha(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Material",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Material must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UMaterial::StaticClass(), TEXT("BlendableOutputAlpha"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = bool();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_BlendableOutputAlpha(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Material",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Material must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UMaterial::StaticClass(), TEXT("BlendableOutputAlpha"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_RefractionMode(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Material",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Material must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UMaterial::StaticClass(), TEXT("RefractionMode"));
	if(!Property) { check(false); return 0;}
	TEnumAsByte<ERefractionMode> PropertyValue = TEnumAsByte<ERefractionMode>();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushinteger(InScriptContext, (int)PropertyValue);
	return 1;
}

int32 Set_RefractionMode(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Material",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Material must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UMaterial::StaticClass(), TEXT("RefractionMode"));
	if(!Property) { check(false); return 0;}
	TEnumAsByte<ERefractionMode> PropertyValue = (TEnumAsByte<ERefractionMode>)(luaL_checkint(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_RefractionDepthBias(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Material",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Material must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UMaterial::StaticClass(), TEXT("RefractionDepthBias"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_RefractionDepthBias(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Material",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Material must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UMaterial::StaticClass(), TEXT("RefractionDepthBias"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 New(lua_State* InScriptContext)
{
	UObject* Outer = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Object");
	FName Name = FName(luaL_checkstring(InScriptContext, 2));
	UObject* Obj = NewObject<UMaterial>(Outer, Name);
	wLua::FLuaUtils::ReturnUObject(InScriptContext,Obj);
	return 1;
}

int32 Destroy(lua_State* InScriptContext)
{
	return 0;
}

int32 Class(lua_State* InScriptContext)
{
	UClass* Class = UMaterial::StaticClass();
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Class);
	return 1;
}

const luaL_Reg Lib_Funcs[] =
{
	{ "New", New },
	{ "Destroy", Destroy },
	{ "Class", Class },
	{ "Get_PhysMaterial", Get_PhysMaterial },
	{ "Set_PhysMaterial", Set_PhysMaterial },
	{ "Get_MaterialDomain", Get_MaterialDomain },
	{ "Get_BlendMode", Get_BlendMode },
	{ "Get_DecalBlendMode", Get_DecalBlendMode },
	{ "Set_DecalBlendMode", Set_DecalBlendMode },
	{ "Get_MaterialDecalResponse", Get_MaterialDecalResponse },
	{ "Get_ShadingModel", Get_ShadingModel },
	{ "Set_ShadingModel", Set_ShadingModel },
	{ "Get_OpacityMaskClipValue", Get_OpacityMaskClipValue },
	{ "Set_OpacityMaskClipValue", Set_OpacityMaskClipValue },
	{ "Get_bCastDynamicShadowAsMasked", Get_bCastDynamicShadowAsMasked },
	{ "Set_bCastDynamicShadowAsMasked", Set_bCastDynamicShadowAsMasked },
	{ "Get_bEnableSeparateTranslucency", Get_bEnableSeparateTranslucency },
	{ "Set_bEnableSeparateTranslucency", Set_bEnableSeparateTranslucency },
	{ "Get_bEnableMobileSeparateTranslucency", Get_bEnableMobileSeparateTranslucency },
	{ "Set_bEnableMobileSeparateTranslucency", Set_bEnableMobileSeparateTranslucency },
	{ "Get_bAzureEnableBasePassTranslucent", Get_bAzureEnableBasePassTranslucent },
	{ "Set_bAzureEnableBasePassTranslucent", Set_bAzureEnableBasePassTranslucent },
	{ "Get_bAzureEnableMobileSoftMasked", Get_bAzureEnableMobileSoftMasked },
	{ "Set_bAzureEnableMobileSoftMasked", Set_bAzureEnableMobileSoftMasked },
	{ "Get_bEnableResponsiveAA", Get_bEnableResponsiveAA },
	{ "Set_bEnableResponsiveAA", Set_bEnableResponsiveAA },
	{ "Get_bScreenSpaceReflections", Get_bScreenSpaceReflections },
	{ "Set_bScreenSpaceReflections", Set_bScreenSpaceReflections },
	{ "Get_bContactShadows", Get_bContactShadows },
	{ "Set_bContactShadows", Set_bContactShadows },
	{ "Get_TwoSided", Get_TwoSided },
	{ "Set_TwoSided", Set_TwoSided },
	{ "Get_DitheredLODTransition", Get_DitheredLODTransition },
	{ "Set_DitheredLODTransition", Set_DitheredLODTransition },
	{ "Get_bAzureDisableLODAutoDither", Get_bAzureDisableLODAutoDither },
	{ "Set_bAzureDisableLODAutoDither", Set_bAzureDisableLODAutoDither },
	{ "Get_DitherOpacityMask", Get_DitherOpacityMask },
	{ "Set_DitherOpacityMask", Set_DitherOpacityMask },
	{ "Get_bAllowNegativeEmissiveColor", Get_bAllowNegativeEmissiveColor },
	{ "Set_bAllowNegativeEmissiveColor", Set_bAllowNegativeEmissiveColor },
	{ "Get_ExportAllQualityLevels", Get_ExportAllQualityLevels },
	{ "Set_ExportAllQualityLevels", Set_ExportAllQualityLevels },
	{ "Get_AzureExportWeatherQualityLevels", Get_AzureExportWeatherQualityLevels },
	{ "Set_AzureExportWeatherQualityLevels", Set_AzureExportWeatherQualityLevels },
	{ "Get_NumCustomizedUVs", Get_NumCustomizedUVs },
	{ "Set_NumCustomizedUVs", Set_NumCustomizedUVs },
	{ "Get_TranslucencyLightingMode", Get_TranslucencyLightingMode },
	{ "Set_TranslucencyLightingMode", Set_TranslucencyLightingMode },
	{ "Get_TranslucencyDirectionalLightingIntensity", Get_TranslucencyDirectionalLightingIntensity },
	{ "Set_TranslucencyDirectionalLightingIntensity", Set_TranslucencyDirectionalLightingIntensity },
	{ "Get_AllowTranslucentCustomDepthWrites", Get_AllowTranslucentCustomDepthWrites },
	{ "Set_AllowTranslucentCustomDepthWrites", Set_AllowTranslucentCustomDepthWrites },
	{ "Get_TranslucentShadowDensityScale", Get_TranslucentShadowDensityScale },
	{ "Set_TranslucentShadowDensityScale", Set_TranslucentShadowDensityScale },
	{ "Get_TranslucentSelfShadowDensityScale", Get_TranslucentSelfShadowDensityScale },
	{ "Set_TranslucentSelfShadowDensityScale", Set_TranslucentSelfShadowDensityScale },
	{ "Get_TranslucentSelfShadowSecondDensityScale", Get_TranslucentSelfShadowSecondDensityScale },
	{ "Set_TranslucentSelfShadowSecondDensityScale", Set_TranslucentSelfShadowSecondDensityScale },
	{ "Get_TranslucentSelfShadowSecondOpacity", Get_TranslucentSelfShadowSecondOpacity },
	{ "Set_TranslucentSelfShadowSecondOpacity", Set_TranslucentSelfShadowSecondOpacity },
	{ "Get_TranslucentBackscatteringExponent", Get_TranslucentBackscatteringExponent },
	{ "Set_TranslucentBackscatteringExponent", Set_TranslucentBackscatteringExponent },
	{ "Get_TranslucentMultipleScatteringExtinction", Get_TranslucentMultipleScatteringExtinction },
	{ "Set_TranslucentMultipleScatteringExtinction", Set_TranslucentMultipleScatteringExtinction },
	{ "Get_TranslucentShadowStartOffset", Get_TranslucentShadowStartOffset },
	{ "Set_TranslucentShadowStartOffset", Set_TranslucentShadowStartOffset },
	{ "Get_AzureDepthFadeDistance", Get_AzureDepthFadeDistance },
	{ "Set_AzureDepthFadeDistance", Set_AzureDepthFadeDistance },
	{ "Get_bDisableDepthTest", Get_bDisableDepthTest },
	{ "Set_bDisableDepthTest", Set_bDisableDepthTest },
	{ "Get_bWriteOnlyAlpha", Get_bWriteOnlyAlpha },
	{ "Set_bWriteOnlyAlpha", Set_bWriteOnlyAlpha },
	{ "Get_bColorBlendOpMax", Get_bColorBlendOpMax },
	{ "Set_bColorBlendOpMax", Set_bColorBlendOpMax },
	{ "Get_bColorBlendOpMin", Get_bColorBlendOpMin },
	{ "Set_bColorBlendOpMin", Set_bColorBlendOpMin },
	{ "Get_bGenerateSphericalParticleNormals", Get_bGenerateSphericalParticleNormals },
	{ "Set_bGenerateSphericalParticleNormals", Set_bGenerateSphericalParticleNormals },
	{ "Get_bTangentSpaceNormal", Get_bTangentSpaceNormal },
	{ "Set_bTangentSpaceNormal", Set_bTangentSpaceNormal },
	{ "Get_bUseEmissiveForDynamicAreaLighting", Get_bUseEmissiveForDynamicAreaLighting },
	{ "Set_bUseEmissiveForDynamicAreaLighting", Set_bUseEmissiveForDynamicAreaLighting },
	{ "Get_bBlockGI", Get_bBlockGI },
	{ "Set_bBlockGI", Set_bBlockGI },
	{ "Get_bUsedWithSkeletalMesh", Get_bUsedWithSkeletalMesh },
	{ "Get_bUsedWithEditorCompositing", Get_bUsedWithEditorCompositing },
	{ "Get_bUsedWithParticleSprites", Get_bUsedWithParticleSprites },
	{ "Get_bUsedWithBeamTrails", Get_bUsedWithBeamTrails },
	{ "Get_bUsedWithMeshParticles", Get_bUsedWithMeshParticles },
	{ "Get_bUsedWithNiagaraSprites", Get_bUsedWithNiagaraSprites },
	{ "Get_bUsedWithNiagaraRibbons", Get_bUsedWithNiagaraRibbons },
	{ "Get_bUsedWithNiagaraMeshParticles", Get_bUsedWithNiagaraMeshParticles },
	{ "Get_bUsedWithGeometryCache", Get_bUsedWithGeometryCache },
	{ "Get_bUsedWithStaticLighting", Get_bUsedWithStaticLighting },
	{ "Get_bUsedWithMorphTargets", Get_bUsedWithMorphTargets },
	{ "Get_bUsedWithSplineMeshes", Get_bUsedWithSplineMeshes },
	{ "Get_bUsedWithInstancedStaticMeshes", Get_bUsedWithInstancedStaticMeshes },
	{ "Get_bUsedWithCustomLocalPosition", Get_bUsedWithCustomLocalPosition },
	{ "Get_bUsedWithClothing", Get_bUsedWithClothing },
	{ "Get_bAutomaticallySetUsageInEditor", Get_bAutomaticallySetUsageInEditor },
	{ "Get_bEnableAzureDepthFade", Get_bEnableAzureDepthFade },
	{ "Set_bEnableAzureDepthFade", Set_bEnableAzureDepthFade },
	{ "Get_bFullyRough", Get_bFullyRough },
	{ "Get_bUseFullPrecision", Get_bUseFullPrecision },
	{ "Get_bUseLightmapDirectionality", Get_bUseLightmapDirectionality },
	{ "Get_bAzureUseGlobalIndirectLighting", Get_bAzureUseGlobalIndirectLighting },
	{ "Get_bAzureMobileForceDepthTextureReads", Get_bAzureMobileForceDepthTextureReads },
	{ "Get_bUseHQForwardReflections", Get_bUseHQForwardReflections },
	{ "Get_bUsePlanarForwardReflections", Get_bUsePlanarForwardReflections },
	{ "Get_bNormalCurvatureToRoughness", Get_bNormalCurvatureToRoughness },
	{ "Get_D3D11TessellationMode", Get_D3D11TessellationMode },
	{ "Get_bEnableCrackFreeDisplacement", Get_bEnableCrackFreeDisplacement },
	{ "Get_bEnableAdaptiveTessellation", Get_bEnableAdaptiveTessellation },
	{ "Get_MaxDisplacement", Get_MaxDisplacement },
	{ "Set_MaxDisplacement", Set_MaxDisplacement },
	{ "Get_Wireframe", Get_Wireframe },
	{ "Set_Wireframe", Set_Wireframe },
	{ "Get_bOutputVelocityOnBasePass", Get_bOutputVelocityOnBasePass },
	{ "Set_bOutputVelocityOnBasePass", Set_bOutputVelocityOnBasePass },
	{ "Get_bUseMaterialAttributes", Get_bUseMaterialAttributes },
	{ "Set_bUseMaterialAttributes", Set_bUseMaterialAttributes },
	{ "Get_bUseTranslucencyVertexFog", Get_bUseTranslucencyVertexFog },
	{ "Set_bUseTranslucencyVertexFog", Set_bUseTranslucencyVertexFog },
	{ "Get_bComputeFogPerPixel", Get_bComputeFogPerPixel },
	{ "Set_bComputeFogPerPixel", Set_bComputeFogPerPixel },
	{ "Get_BlendableLocation", Get_BlendableLocation },
	{ "Set_BlendableLocation", Set_BlendableLocation },
	{ "Get_BlendablePriority", Get_BlendablePriority },
	{ "Set_BlendablePriority", Set_BlendablePriority },
	{ "Get_BlendableOutputAlpha", Get_BlendableOutputAlpha },
	{ "Set_BlendableOutputAlpha", Set_BlendableOutputAlpha },
	{ "Get_RefractionMode", Get_RefractionMode },
	{ "Set_RefractionMode", Set_RefractionMode },
	{ "Get_RefractionDepthBias", Get_RefractionDepthBias },
	{ "Set_RefractionDepthBias", Set_RefractionDepthBias },
	{ "is_nil", wLua::LuaStatic::isnil },
	{ "__gc", wLua::LuaStatic::removeUClassFrameCache },
	{ NULL, NULL }
};

void Register(lua_State *InScriptContext)
{
	lua_newtable(InScriptContext);
	luaL_register(InScriptContext, NULL, Lib_Funcs);
	AzureHelpFuncs::AuxRegister(InScriptContext, "Material");
}
void SetMtLink(lua_State *InScriptContext)
{
	AzureHelpFuncs::AuxSetMtLink(InScriptContext, "Material", "MaterialInterface",USERDATATYPE_UOBJECT);
}

}