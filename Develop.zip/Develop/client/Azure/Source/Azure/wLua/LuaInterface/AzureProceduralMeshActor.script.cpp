#include "Azure.h"
#include "Utility/help_funcs.h"
#include "wLua/UObjectHeaders.h"
#include "GameLogic/Home/AzureProceduralMeshActor.h"
#include "AzureLuaIntegration.h"

namespace LuaAzureProceduralMeshActor
{
int32 CreateMeshSection(lua_State*);
int32 UpdateMeshSection(lua_State*);

int32 SetRelativeLocationAndRotationAndScale(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureProceduralMeshActor",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureProceduralMeshActor must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FVector NewLocation;
		FRotator NewRotation;
		FVector NewScale3D;
	} Params;
	Params.NewLocation = (wLua::FLuaVector::Get(InScriptContext, 2));
	Params.NewRotation = (wLua::FLuaRotator::Get(InScriptContext, 3));
	Params.NewScale3D = (wLua::FLuaVector::Get(InScriptContext, 4));
#if UE_GAME
	AAzureProceduralMeshActor * This = (AAzureProceduralMeshActor *)Obj;
	This->SetRelativeLocationAndRotationAndScale(Params.NewLocation,Params.NewRotation,Params.NewScale3D);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetRelativeLocationAndRotationAndScale"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FVector*)(params.GetStructMemory() + 0) = Params.NewLocation;
		*(FRotator*)(params.GetStructMemory() + 12) = Params.NewRotation;
		*(FVector*)(params.GetStructMemory() + 24) = Params.NewScale3D;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.NewLocation = *(FVector*)(params.GetStructMemory() + 0);
		Params.NewRotation = *(FRotator*)(params.GetStructMemory() + 12);
		Params.NewScale3D = *(FVector*)(params.GetStructMemory() + 24);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetRelativeLocationAndRotation(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureProceduralMeshActor",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureProceduralMeshActor must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FVector NewLocation;
		FRotator NewRotation;
	} Params;
	Params.NewLocation = (wLua::FLuaVector::Get(InScriptContext, 2));
	Params.NewRotation = (wLua::FLuaRotator::Get(InScriptContext, 3));
#if UE_GAME
	AAzureProceduralMeshActor * This = (AAzureProceduralMeshActor *)Obj;
	This->SetRelativeLocationAndRotation(Params.NewLocation,Params.NewRotation);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetRelativeLocationAndRotation"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FVector*)(params.GetStructMemory() + 0) = Params.NewLocation;
		*(FRotator*)(params.GetStructMemory() + 12) = Params.NewRotation;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.NewLocation = *(FVector*)(params.GetStructMemory() + 0);
		Params.NewRotation = *(FRotator*)(params.GetStructMemory() + 12);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetMeshSectionVisible(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureProceduralMeshActor",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureProceduralMeshActor must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		int32 SectionIndex;
		bool bNewVisibility;
	} Params;
	Params.SectionIndex = (luaL_checkint(InScriptContext, 2));
	Params.bNewVisibility = !!(lua_toboolean(InScriptContext, 3));
#if UE_GAME
	AAzureProceduralMeshActor * This = (AAzureProceduralMeshActor *)Obj;
	This->SetMeshSectionVisible(Params.SectionIndex,Params.bNewVisibility);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetMeshSectionVisible"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(int32*)(params.GetStructMemory() + 0) = Params.SectionIndex;
		*(bool*)(params.GetStructMemory() + 4) = Params.bNewVisibility;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.SectionIndex = *(int32*)(params.GetStructMemory() + 0);
		Params.bNewVisibility = *(bool*)(params.GetStructMemory() + 4);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetMaterial(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureProceduralMeshActor",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureProceduralMeshActor must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		int32 section_id;
		UMaterialInterface* Material = nullptr;
	} Params;
	Params.section_id = (luaL_checkint(InScriptContext, 2));
	Params.Material = (UMaterialInterface*)wLua::FLuaUtils::GetUObject(InScriptContext,3,"MaterialInterface");;
#if UE_GAME
	AAzureProceduralMeshActor * This = (AAzureProceduralMeshActor *)Obj;
	This->SetMaterial(Params.section_id,Params.Material);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetMaterial"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(int32*)(params.GetStructMemory() + 0) = Params.section_id;
		*(UMaterialInterface**)(params.GetStructMemory() + 8) = Params.Material;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.section_id = *(int32*)(params.GetStructMemory() + 0);
		Params.Material = *(UMaterialInterface**)(params.GetStructMemory() + 8);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetCollisionProfileName(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureProceduralMeshActor",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureProceduralMeshActor must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FString ProfileName;
	} Params;
	Params.ProfileName = UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 2));
#if UE_GAME
	AAzureProceduralMeshActor * This = (AAzureProceduralMeshActor *)Obj;
	This->SetCollisionProfileName(Params.ProfileName);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetCollisionProfileName"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FString*)(params.GetStructMemory() + 0) = Params.ProfileName;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ProfileName = *(FString*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 ReleaseSectionMesh(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureProceduralMeshActor",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureProceduralMeshActor must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		int32 section_id;
		bool ReturnValue;
	} Params;
	Params.section_id = (luaL_checkint(InScriptContext, 2));
#if UE_GAME
	AAzureProceduralMeshActor * This = (AAzureProceduralMeshActor *)Obj;
	Params.ReturnValue = This->ReleaseSectionMesh(Params.section_id);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("ReleaseSectionMesh"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(int32*)(params.GetStructMemory() + 0) = Params.section_id;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.section_id = *(int32*)(params.GetStructMemory() + 0);
		Params.ReturnValue = *(bool*)(params.GetStructMemory() + 4);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushboolean(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 IsMeshSectionVisible(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureProceduralMeshActor",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureProceduralMeshActor must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		int32 SectionIndex;
		bool ReturnValue;
	} Params;
	Params.SectionIndex = (luaL_checkint(InScriptContext, 2));
#if UE_GAME
	AAzureProceduralMeshActor * This = (AAzureProceduralMeshActor *)Obj;
	Params.ReturnValue = This->IsMeshSectionVisible(Params.SectionIndex);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("IsMeshSectionVisible"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(int32*)(params.GetStructMemory() + 0) = Params.SectionIndex;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.SectionIndex = *(int32*)(params.GetStructMemory() + 0);
		Params.ReturnValue = *(bool*)(params.GetStructMemory() + 4);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushboolean(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetSectionVerticesNum(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureProceduralMeshActor",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureProceduralMeshActor must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		int32 section_id;
		int32 ReturnValue;
	} Params;
	Params.section_id = (luaL_checkint(InScriptContext, 2));
#if UE_GAME
	AAzureProceduralMeshActor * This = (AAzureProceduralMeshActor *)Obj;
	Params.ReturnValue = This->GetSectionVerticesNum(Params.section_id);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetSectionVerticesNum"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(int32*)(params.GetStructMemory() + 0) = Params.section_id;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.section_id = *(int32*)(params.GetStructMemory() + 0);
		Params.ReturnValue = *(int32*)(params.GetStructMemory() + 4);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushinteger(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetSectionMaterialInst(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureProceduralMeshActor",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureProceduralMeshActor must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		int32 section_id;
		UMaterialInterface* ReturnValue = nullptr;
	} Params;
	Params.section_id = (luaL_checkint(InScriptContext, 2));
#if UE_GAME
	AAzureProceduralMeshActor * This = (AAzureProceduralMeshActor *)Obj;
	Params.ReturnValue = This->GetSectionMaterialInst(Params.section_id);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetSectionMaterialInst"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(int32*)(params.GetStructMemory() + 0) = Params.section_id;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.section_id = *(int32*)(params.GetStructMemory() + 0);
		Params.ReturnValue = *(UMaterialInterface**)(params.GetStructMemory() + 8);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetNumSections(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureProceduralMeshActor",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureProceduralMeshActor must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		int32 ReturnValue;
	} Params;
#if UE_GAME
	AAzureProceduralMeshActor * This = (AAzureProceduralMeshActor *)Obj;
	Params.ReturnValue = This->GetNumSections();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetNumSections"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(int32*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushinteger(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetNumMaterials(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureProceduralMeshActor",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureProceduralMeshActor must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		int32 ReturnValue;
	} Params;
#if UE_GAME
	AAzureProceduralMeshActor * This = (AAzureProceduralMeshActor *)Obj;
	Params.ReturnValue = This->GetNumMaterials();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetNumMaterials"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(int32*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushinteger(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 ClearAllMeshSections(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureProceduralMeshActor",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureProceduralMeshActor must be non-null"); lua_error(InScriptContext);  return 0;}
#if UE_GAME
	AAzureProceduralMeshActor * This = (AAzureProceduralMeshActor *)Obj;
	This->ClearAllMeshSections();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("ClearAllMeshSections"));
	if(!Function) { check(false); return 0;}
	Obj->ProcessEvent(Function, NULL);
#endif
	return 0;
}

int32 Get_ProceduralMeshComponent(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureProceduralMeshActor",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureProceduralMeshActor must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureProceduralMeshActor::StaticClass(), TEXT("ProceduralMeshComponent"));
	if(!Property) { check(false); return 0;}
	UProceduralMeshComponent* PropertyValue;
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaUtils::ReturnUObject(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_ProceduralMeshComponent(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureProceduralMeshActor",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureProceduralMeshActor must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureProceduralMeshActor::StaticClass(), TEXT("ProceduralMeshComponent"));
	if(!Property) { check(false); return 0;}
	UProceduralMeshComponent* PropertyValue = (UProceduralMeshComponent*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"ProceduralMeshComponent");;
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 New(lua_State* InScriptContext)
{
	UObject* Outer = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Object");
	FName Name = FName(luaL_checkstring(InScriptContext, 2));
	UObject* Obj = NewObject<AAzureProceduralMeshActor>(Outer, Name);
	wLua::FLuaUtils::ReturnUObject(InScriptContext,Obj);
	return 1;
}

int32 Destroy(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureProceduralMeshActor",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureProceduralMeshActor must be non-null"); lua_error(InScriptContext);  return 0;}
		AActor * actor = Cast<AActor>(Obj);
		actor->Destroy();
		userdata->flag |= wLua::LuaObjectFlag::DESTROYED;
		wLua::FLuaUtils::RemoveObjectReference(Obj, userdata->stamp, InScriptContext);
#ifdef AZURE_BUILD_WLUACHECK
		UE_LOG(LogAzure, Warning, TEXT("Destroy AzureProceduralMeshActor: %x userdata:%x   stamp:%x"),Obj,userdata,userdata->stamp);
#endif
	return 0;
}

int32 Class(lua_State* InScriptContext)
{
	UClass* Class = AAzureProceduralMeshActor::StaticClass();
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Class);
	return 1;
}

const luaL_Reg Lib_Funcs[] =
{
	{ "New", New },
	{ "Destroy", Destroy },
	{ "Class", Class },
	{ "SetRelativeLocationAndRotationAndScale", SetRelativeLocationAndRotationAndScale },
	{ "SetRelativeLocationAndRotation", SetRelativeLocationAndRotation },
	{ "SetMeshSectionVisible", SetMeshSectionVisible },
	{ "SetMaterial", SetMaterial },
	{ "SetCollisionProfileName", SetCollisionProfileName },
	{ "ReleaseSectionMesh", ReleaseSectionMesh },
	{ "IsMeshSectionVisible", IsMeshSectionVisible },
	{ "GetSectionVerticesNum", GetSectionVerticesNum },
	{ "GetSectionMaterialInst", GetSectionMaterialInst },
	{ "GetNumSections", GetNumSections },
	{ "GetNumMaterials", GetNumMaterials },
	{ "ClearAllMeshSections", ClearAllMeshSections },
	{ "Get_ProceduralMeshComponent", Get_ProceduralMeshComponent },
	{ "Set_ProceduralMeshComponent", Set_ProceduralMeshComponent },
	{ "CreateMeshSection", CreateMeshSection },
	{ "UpdateMeshSection", UpdateMeshSection },
	{ "is_nil", wLua::LuaStatic::isnil },
	{ "__gc", wLua::LuaStatic::removeUClassFrameCache },
	{ NULL, NULL }
};

void Register(lua_State *InScriptContext)
{
	lua_newtable(InScriptContext);
	luaL_register(InScriptContext, NULL, Lib_Funcs);
	AzureHelpFuncs::AuxRegister(InScriptContext, "AzureProceduralMeshActor");
}
void SetMtLink(lua_State *InScriptContext)
{
	AzureHelpFuncs::AuxSetMtLink(InScriptContext, "AzureProceduralMeshActor", "Actor",USERDATATYPE_UOBJECT);
}

}