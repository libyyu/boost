#include "Azure.h"
#include "Utility/help_funcs.h"
#include "wLua/UObjectHeaders.h"
#include "GameFramework/Actor.h"
#include "AzureLuaIntegration.h"

namespace LuaActor
{
int32 AddComponent2(lua_State*);
int32 SetActive2(lua_State*);
int32 SetLogicActive(lua_State*);
int32 SetActorLocation2(lua_State*);
int32 GetActorLocation2(lua_State*);
int32 SetActorRotation2(lua_State*);
int32 GetActorRotation2(lua_State*);
int32 GetActorForwardVector2(lua_State*);
int32 SetActorScale2(lua_State*);
int32 GetActorScale2(lua_State*);
int32 SetActorTransform2(lua_State*);
int32 SetActorLocationAndRotation2(lua_State*);
int32 SetParent2(lua_State*);
int32 GetWorld2(lua_State*);
int32 SetOrGetActorRelativeLocation(lua_State*);
int32 SetOrGetActorRelativeLocation(lua_State*);
int32 SetOrGetActorRelativeRotation(lua_State*);
int32 SetOrGetActorRelativeRotation(lua_State*);
int32 SetOrGetActorRelativeScale(lua_State*);
int32 SetOrGetActorRelativeScale(lua_State*);
int32 ResumeActorLocalTransform(lua_State*);
int32 GetChildrenCount(lua_State*);
int32 GetChild(lua_State*);
int32 FindChildDirect(lua_State*);
int32 FindChild(lua_State*);
int32 FindAttachChildActor(lua_State*);
int32 TransformPoint(lua_State*);
int32 TransformRotator(lua_State*);
int32 GetComponentByVariableName(lua_State*);
int32 SetLightingChannelMask(lua_State*);
int32 SetIndirectLightingCacheQuality(lua_State*);
int32 GetComponentByName(lua_State*);
int32 SetActorLabel(lua_State*);
int32 SetFolderPath(lua_State*);
int32 GetFolderPath(lua_State*);
int32 SetUseGlobalSHIndirectLighting(lua_State*);
int32 ResetUseGlobalSHIndirectLighting(lua_State*);
int32 GetLevel(lua_State*);

int32 WasRecentlyRendered(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Actor",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Actor must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float Tolerance;
		bool ReturnValue;
	} Params;
	Params.Tolerance = lua_isnoneornil(InScriptContext,2) ? float(0.200000) : (float)(luaL_checknumber(InScriptContext, 2));
#if UE_GAME
	AActor * This = (AActor *)Obj;
	Params.ReturnValue = This->WasRecentlyRendered(Params.Tolerance);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("WasRecentlyRendered"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(float*)(params.GetStructMemory() + 0) = Params.Tolerance;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.Tolerance = *(float*)(params.GetStructMemory() + 0);
		Params.ReturnValue = *(bool*)(params.GetStructMemory() + 4);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushboolean(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 TearOff(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Actor",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Actor must be non-null"); lua_error(InScriptContext);  return 0;}
#if UE_GAME
	AActor * This = (AActor *)Obj;
	This->TearOff();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("TearOff"));
	if(!Function) { check(false); return 0;}
	Obj->ProcessEvent(Function, NULL);
#endif
	return 0;
}

int32 SetTickGroup(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Actor",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Actor must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		TEnumAsByte<ETickingGroup> NewTickGroup;
	} Params;
	Params.NewTickGroup = (TEnumAsByte<ETickingGroup>)(luaL_checkint(InScriptContext, 2));
#if UE_GAME
	AActor * This = (AActor *)Obj;
	This->SetTickGroup(Params.NewTickGroup);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetTickGroup"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(TEnumAsByte<ETickingGroup>*)(params.GetStructMemory() + 0) = Params.NewTickGroup;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.NewTickGroup = *(TEnumAsByte<ETickingGroup>*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetTickableWhenPaused(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Actor",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Actor must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool bTickableWhenPaused;
	} Params;
	Params.bTickableWhenPaused = !!(lua_toboolean(InScriptContext, 2));
#if UE_GAME
	AActor * This = (AActor *)Obj;
	This->SetTickableWhenPaused(Params.bTickableWhenPaused);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetTickableWhenPaused"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(bool*)(params.GetStructMemory() + 0) = Params.bTickableWhenPaused;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.bTickableWhenPaused = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetReplicates(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Actor",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Actor must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool bInReplicates;
	} Params;
	Params.bInReplicates = !!(lua_toboolean(InScriptContext, 2));
#if UE_GAME
	AActor * This = (AActor *)Obj;
	This->SetReplicates(Params.bInReplicates);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetReplicates"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(bool*)(params.GetStructMemory() + 0) = Params.bInReplicates;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.bInReplicates = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetReplicateMovement(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Actor",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Actor must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool bInReplicateMovement;
	} Params;
	Params.bInReplicateMovement = !!(lua_toboolean(InScriptContext, 2));
#if UE_GAME
	AActor * This = (AActor *)Obj;
	This->SetReplicateMovement(Params.bInReplicateMovement);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetReplicateMovement"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(bool*)(params.GetStructMemory() + 0) = Params.bInReplicateMovement;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.bInReplicateMovement = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetOwner(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Actor",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Actor must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		AActor* NewOwner = nullptr;
	} Params;
	Params.NewOwner = (AActor*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"Actor");;
#if UE_GAME
	AActor * This = (AActor *)Obj;
	This->SetOwner(Params.NewOwner);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetOwner"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(AActor**)(params.GetStructMemory() + 0) = Params.NewOwner;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.NewOwner = *(AActor**)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetNetDormancy(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Actor",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Actor must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		TEnumAsByte<ENetDormancy> NewDormancy;
	} Params;
	Params.NewDormancy = (TEnumAsByte<ENetDormancy>)(luaL_checkint(InScriptContext, 2));
#if UE_GAME
	AActor * This = (AActor *)Obj;
	This->SetNetDormancy(Params.NewDormancy);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetNetDormancy"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(TEnumAsByte<ENetDormancy>*)(params.GetStructMemory() + 0) = Params.NewDormancy;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.NewDormancy = *(TEnumAsByte<ENetDormancy>*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetLifeSpan(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Actor",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Actor must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float InLifespan;
	} Params;
	Params.InLifespan = (float)(luaL_checknumber(InScriptContext, 2));
#if UE_GAME
	AActor * This = (AActor *)Obj;
	This->SetLifeSpan(Params.InLifespan);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetLifeSpan"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(float*)(params.GetStructMemory() + 0) = Params.InLifespan;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.InLifespan = *(float*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetActorTickInterval(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Actor",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Actor must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float TickInterval;
	} Params;
	Params.TickInterval = (float)(luaL_checknumber(InScriptContext, 2));
#if UE_GAME
	AActor * This = (AActor *)Obj;
	This->SetActorTickInterval(Params.TickInterval);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetActorTickInterval"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(float*)(params.GetStructMemory() + 0) = Params.TickInterval;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.TickInterval = *(float*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetActorTickEnabled(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Actor",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Actor must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool bEnabled;
	} Params;
	Params.bEnabled = !!(lua_toboolean(InScriptContext, 2));
#if UE_GAME
	AActor * This = (AActor *)Obj;
	This->SetActorTickEnabled(Params.bEnabled);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetActorTickEnabled"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(bool*)(params.GetStructMemory() + 0) = Params.bEnabled;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.bEnabled = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetActorScale3D(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Actor",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Actor must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FVector NewScale3D;
	} Params;
	Params.NewScale3D = (wLua::FLuaVector::Get(InScriptContext, 2));
#if UE_GAME
	AActor * This = (AActor *)Obj;
	This->SetActorScale3D(Params.NewScale3D);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetActorScale3D"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FVector*)(params.GetStructMemory() + 0) = Params.NewScale3D;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.NewScale3D = *(FVector*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetActorRelativeScale3D(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Actor",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Actor must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FVector NewRelativeScale;
	} Params;
	Params.NewRelativeScale = (wLua::FLuaVector::Get(InScriptContext, 2));
#if UE_GAME
	AActor * This = (AActor *)Obj;
	This->SetActorRelativeScale3D(Params.NewRelativeScale);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetActorRelativeScale3D"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FVector*)(params.GetStructMemory() + 0) = Params.NewRelativeScale;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.NewRelativeScale = *(FVector*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetActorHiddenInGame(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Actor",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Actor must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool bNewHidden;
	} Params;
	Params.bNewHidden = !!(lua_toboolean(InScriptContext, 2));
#if UE_GAME
	AActor * This = (AActor *)Obj;
	This->SetActorHiddenInGame(Params.bNewHidden);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetActorHiddenInGame"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(bool*)(params.GetStructMemory() + 0) = Params.bNewHidden;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.bNewHidden = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetActorEnableCollision(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Actor",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Actor must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool bNewActorEnableCollision;
	} Params;
	Params.bNewActorEnableCollision = !!(lua_toboolean(InScriptContext, 2));
#if UE_GAME
	AActor * This = (AActor *)Obj;
	This->SetActorEnableCollision(Params.bNewActorEnableCollision);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetActorEnableCollision"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(bool*)(params.GetStructMemory() + 0) = Params.bNewActorEnableCollision;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.bNewActorEnableCollision = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 RemoveTickPrerequisiteComponent(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Actor",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Actor must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		UActorComponent* PrerequisiteComponent = nullptr;
	} Params;
	Params.PrerequisiteComponent = (UActorComponent*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"ActorComponent");;
#if UE_GAME
	AActor * This = (AActor *)Obj;
	This->RemoveTickPrerequisiteComponent(Params.PrerequisiteComponent);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("RemoveTickPrerequisiteComponent"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(UActorComponent**)(params.GetStructMemory() + 0) = Params.PrerequisiteComponent;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.PrerequisiteComponent = *(UActorComponent**)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 RemoveTickPrerequisiteActor(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Actor",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Actor must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		AActor* PrerequisiteActor = nullptr;
	} Params;
	Params.PrerequisiteActor = (AActor*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"Actor");;
#if UE_GAME
	AActor * This = (AActor *)Obj;
	This->RemoveTickPrerequisiteActor(Params.PrerequisiteActor);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("RemoveTickPrerequisiteActor"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(AActor**)(params.GetStructMemory() + 0) = Params.PrerequisiteActor;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.PrerequisiteActor = *(AActor**)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 ReceiveTick(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Actor",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Actor must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float DeltaSeconds;
	} Params;
	Params.DeltaSeconds = (float)(luaL_checknumber(InScriptContext, 2));
#if UE_GAME
	AActor * This = (AActor *)Obj;
	This->ReceiveTick(Params.DeltaSeconds);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("ReceiveTick"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(float*)(params.GetStructMemory() + 0) = Params.DeltaSeconds;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.DeltaSeconds = *(float*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 ReceiveEndPlay(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Actor",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Actor must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		TEnumAsByte<EEndPlayReason::Type> EndPlayReason;
	} Params;
	Params.EndPlayReason = (TEnumAsByte<EEndPlayReason::Type>)(luaL_checkint(InScriptContext, 2));
#if UE_GAME
	AActor * This = (AActor *)Obj;
	This->ReceiveEndPlay(Params.EndPlayReason);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("ReceiveEndPlay"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(TEnumAsByte<EEndPlayReason::Type>*)(params.GetStructMemory() + 0) = Params.EndPlayReason;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.EndPlayReason = *(TEnumAsByte<EEndPlayReason::Type>*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 ReceiveDestroyed(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Actor",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Actor must be non-null"); lua_error(InScriptContext);  return 0;}
#if UE_GAME
	AActor * This = (AActor *)Obj;
	This->ReceiveDestroyed();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("ReceiveDestroyed"));
	if(!Function) { check(false); return 0;}
	Obj->ProcessEvent(Function, NULL);
#endif
	return 0;
}

int32 ReceiveBeginPlay(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Actor",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Actor must be non-null"); lua_error(InScriptContext);  return 0;}
	UFunction* Function = Obj->FindFunctionChecked(TEXT("ReceiveBeginPlay"));
	if(!Function) { check(false); return 0;}
	Obj->ProcessEvent(Function, NULL);
	return 0;
}

int32 ReceiveAnyDamage(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Actor",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Actor must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float Damage;
		UDamageType* DamageType = nullptr;
		AController* InstigatedBy = nullptr;
		AActor* DamageCauser = nullptr;
	} Params;
	Params.Damage = (float)(luaL_checknumber(InScriptContext, 2));
	Params.DamageType = (UDamageType*)wLua::FLuaUtils::GetUObject(InScriptContext,3,"DamageType");;
	Params.InstigatedBy = (AController*)wLua::FLuaUtils::GetUObject(InScriptContext,4,"Controller");;
	Params.DamageCauser = (AActor*)wLua::FLuaUtils::GetUObject(InScriptContext,5,"Actor");;
#if UE_GAME
	AActor * This = (AActor *)Obj;
	This->ReceiveAnyDamage(Params.Damage,Params.DamageType,Params.InstigatedBy,Params.DamageCauser);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("ReceiveAnyDamage"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(float*)(params.GetStructMemory() + 0) = Params.Damage;
		*(UDamageType**)(params.GetStructMemory() + 8) = Params.DamageType;
		*(AController**)(params.GetStructMemory() + 16) = Params.InstigatedBy;
		*(AActor**)(params.GetStructMemory() + 24) = Params.DamageCauser;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.Damage = *(float*)(params.GetStructMemory() + 0);
		Params.DamageType = *(UDamageType**)(params.GetStructMemory() + 8);
		Params.InstigatedBy = *(AController**)(params.GetStructMemory() + 16);
		Params.DamageCauser = *(AActor**)(params.GetStructMemory() + 24);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 ReceiveActorOnInputTouchLeave(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Actor",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Actor must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		TEnumAsByte<ETouchIndex::Type> FingerIndex;
	} Params;
	Params.FingerIndex = (TEnumAsByte<ETouchIndex::Type>)(luaL_checkint(InScriptContext, 2));
#if UE_GAME
	AActor * This = (AActor *)Obj;
	This->ReceiveActorOnInputTouchLeave(Params.FingerIndex);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("ReceiveActorOnInputTouchLeave"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(TEnumAsByte<ETouchIndex::Type>*)(params.GetStructMemory() + 0) = Params.FingerIndex;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.FingerIndex = *(TEnumAsByte<ETouchIndex::Type>*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 ReceiveActorOnInputTouchEnter(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Actor",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Actor must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		TEnumAsByte<ETouchIndex::Type> FingerIndex;
	} Params;
	Params.FingerIndex = (TEnumAsByte<ETouchIndex::Type>)(luaL_checkint(InScriptContext, 2));
#if UE_GAME
	AActor * This = (AActor *)Obj;
	This->ReceiveActorOnInputTouchEnter(Params.FingerIndex);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("ReceiveActorOnInputTouchEnter"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(TEnumAsByte<ETouchIndex::Type>*)(params.GetStructMemory() + 0) = Params.FingerIndex;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.FingerIndex = *(TEnumAsByte<ETouchIndex::Type>*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 ReceiveActorOnInputTouchEnd(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Actor",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Actor must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		TEnumAsByte<ETouchIndex::Type> FingerIndex;
	} Params;
	Params.FingerIndex = (TEnumAsByte<ETouchIndex::Type>)(luaL_checkint(InScriptContext, 2));
#if UE_GAME
	AActor * This = (AActor *)Obj;
	This->ReceiveActorOnInputTouchEnd(Params.FingerIndex);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("ReceiveActorOnInputTouchEnd"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(TEnumAsByte<ETouchIndex::Type>*)(params.GetStructMemory() + 0) = Params.FingerIndex;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.FingerIndex = *(TEnumAsByte<ETouchIndex::Type>*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 ReceiveActorOnInputTouchBegin(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Actor",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Actor must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		TEnumAsByte<ETouchIndex::Type> FingerIndex;
	} Params;
	Params.FingerIndex = (TEnumAsByte<ETouchIndex::Type>)(luaL_checkint(InScriptContext, 2));
#if UE_GAME
	AActor * This = (AActor *)Obj;
	This->ReceiveActorOnInputTouchBegin(Params.FingerIndex);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("ReceiveActorOnInputTouchBegin"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(TEnumAsByte<ETouchIndex::Type>*)(params.GetStructMemory() + 0) = Params.FingerIndex;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.FingerIndex = *(TEnumAsByte<ETouchIndex::Type>*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 ReceiveActorEndOverlap(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Actor",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Actor must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		AActor* OtherActor = nullptr;
	} Params;
	Params.OtherActor = (AActor*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"Actor");;
#if UE_GAME
	AActor * This = (AActor *)Obj;
	This->ReceiveActorEndOverlap(Params.OtherActor);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("ReceiveActorEndOverlap"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(AActor**)(params.GetStructMemory() + 0) = Params.OtherActor;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.OtherActor = *(AActor**)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 ReceiveActorEndCursorOver(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Actor",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Actor must be non-null"); lua_error(InScriptContext);  return 0;}
#if UE_GAME
	AActor * This = (AActor *)Obj;
	This->ReceiveActorEndCursorOver();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("ReceiveActorEndCursorOver"));
	if(!Function) { check(false); return 0;}
	Obj->ProcessEvent(Function, NULL);
#endif
	return 0;
}

int32 ReceiveActorBeginOverlap(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Actor",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Actor must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		AActor* OtherActor = nullptr;
	} Params;
	Params.OtherActor = (AActor*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"Actor");;
#if UE_GAME
	AActor * This = (AActor *)Obj;
	This->ReceiveActorBeginOverlap(Params.OtherActor);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("ReceiveActorBeginOverlap"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(AActor**)(params.GetStructMemory() + 0) = Params.OtherActor;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.OtherActor = *(AActor**)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 ReceiveActorBeginCursorOver(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Actor",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Actor must be non-null"); lua_error(InScriptContext);  return 0;}
#if UE_GAME
	AActor * This = (AActor *)Obj;
	This->ReceiveActorBeginCursorOver();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("ReceiveActorBeginCursorOver"));
	if(!Function) { check(false); return 0;}
	Obj->ProcessEvent(Function, NULL);
#endif
	return 0;
}

int32 PrestreamTextures(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Actor",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Actor must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float Seconds;
		bool bEnableStreaming;
		int32 CinematicTextureGroups;
	} Params;
	Params.Seconds = (float)(luaL_checknumber(InScriptContext, 2));
	Params.bEnableStreaming = !!(lua_toboolean(InScriptContext, 3));
	Params.CinematicTextureGroups = lua_isnoneornil(InScriptContext,4) ? int32(0) : (luaL_checkint(InScriptContext, 4));
#if UE_GAME
	AActor * This = (AActor *)Obj;
	This->PrestreamTextures(Params.Seconds,Params.bEnableStreaming,Params.CinematicTextureGroups);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("PrestreamTextures"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(float*)(params.GetStructMemory() + 0) = Params.Seconds;
		*(bool*)(params.GetStructMemory() + 4) = Params.bEnableStreaming;
		*(int32*)(params.GetStructMemory() + 8) = Params.CinematicTextureGroups;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.Seconds = *(float*)(params.GetStructMemory() + 0);
		Params.bEnableStreaming = *(bool*)(params.GetStructMemory() + 4);
		Params.CinematicTextureGroups = *(int32*)(params.GetStructMemory() + 8);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 OnRep_ReplicateMovement(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Actor",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Actor must be non-null"); lua_error(InScriptContext);  return 0;}
#if UE_GAME
	AActor * This = (AActor *)Obj;
	This->OnRep_ReplicateMovement();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("OnRep_ReplicateMovement"));
	if(!Function) { check(false); return 0;}
	Obj->ProcessEvent(Function, NULL);
#endif
	return 0;
}

int32 OnRep_ReplicatedMovement(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Actor",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Actor must be non-null"); lua_error(InScriptContext);  return 0;}
#if UE_GAME
	AActor * This = (AActor *)Obj;
	This->OnRep_ReplicatedMovement();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("OnRep_ReplicatedMovement"));
	if(!Function) { check(false); return 0;}
	Obj->ProcessEvent(Function, NULL);
#endif
	return 0;
}

int32 OnRep_Owner(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Actor",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Actor must be non-null"); lua_error(InScriptContext);  return 0;}
	UFunction* Function = Obj->FindFunctionChecked(TEXT("OnRep_Owner"));
	if(!Function) { check(false); return 0;}
	Obj->ProcessEvent(Function, NULL);
	return 0;
}

int32 OnRep_Instigator(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Actor",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Actor must be non-null"); lua_error(InScriptContext);  return 0;}
#if UE_GAME
	AActor * This = (AActor *)Obj;
	This->OnRep_Instigator();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("OnRep_Instigator"));
	if(!Function) { check(false); return 0;}
	Obj->ProcessEvent(Function, NULL);
#endif
	return 0;
}

int32 OnRep_AttachmentReplication(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Actor",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Actor must be non-null"); lua_error(InScriptContext);  return 0;}
#if UE_GAME
	AActor * This = (AActor *)Obj;
	This->OnRep_AttachmentReplication();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("OnRep_AttachmentReplication"));
	if(!Function) { check(false); return 0;}
	Obj->ProcessEvent(Function, NULL);
#endif
	return 0;
}

int32 MakeNoise(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Actor",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Actor must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float Loudness;
		APawn* NoiseInstigator = nullptr;
		FVector NoiseLocation;
		float MaxRange;
		FName Tag;
	} Params;
	Params.Loudness = lua_isnoneornil(InScriptContext,2) ? float(1.000000) : (float)(luaL_checknumber(InScriptContext, 2));
	Params.NoiseInstigator = lua_isnoneornil(InScriptContext,3) ? nullptr : (APawn*)wLua::FLuaUtils::GetUObject(InScriptContext,3,"Pawn");;
	Params.NoiseLocation = lua_isnoneornil(InScriptContext,4) ? FVector(0.f) : (wLua::FLuaVector::Get(InScriptContext, 4));
	Params.MaxRange = lua_isnoneornil(InScriptContext,5) ? float(0.000000) : (float)(luaL_checknumber(InScriptContext, 5));
	Params.Tag = lua_isnoneornil(InScriptContext,6) ? FName(TEXT("")) : FName(UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 6)));
#if UE_GAME
	AActor * This = (AActor *)Obj;
	This->MakeNoise(Params.Loudness,Params.NoiseInstigator,Params.NoiseLocation,Params.MaxRange,Params.Tag);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("MakeNoise"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(float*)(params.GetStructMemory() + 0) = Params.Loudness;
		*(APawn**)(params.GetStructMemory() + 8) = Params.NoiseInstigator;
		*(FVector*)(params.GetStructMemory() + 16) = Params.NoiseLocation;
		*(float*)(params.GetStructMemory() + 28) = Params.MaxRange;
		*(FName*)(params.GetStructMemory() + 32) = Params.Tag;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.Loudness = *(float*)(params.GetStructMemory() + 0);
		Params.NoiseInstigator = *(APawn**)(params.GetStructMemory() + 8);
		Params.NoiseLocation = *(FVector*)(params.GetStructMemory() + 16);
		Params.MaxRange = *(float*)(params.GetStructMemory() + 28);
		Params.Tag = *(FName*)(params.GetStructMemory() + 32);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 K2_TeleportTo(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Actor",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Actor must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FVector DestLocation;
		FRotator DestRotation;
		bool ReturnValue;
	} Params;
	Params.DestLocation = (wLua::FLuaVector::Get(InScriptContext, 2));
	Params.DestRotation = (wLua::FLuaRotator::Get(InScriptContext, 3));
#if UE_GAME
	AActor * This = (AActor *)Obj;
	Params.ReturnValue = This->K2_TeleportTo(Params.DestLocation,Params.DestRotation);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("K2_TeleportTo"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FVector*)(params.GetStructMemory() + 0) = Params.DestLocation;
		*(FRotator*)(params.GetStructMemory() + 12) = Params.DestRotation;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.DestLocation = *(FVector*)(params.GetStructMemory() + 0);
		Params.DestRotation = *(FRotator*)(params.GetStructMemory() + 12);
		Params.ReturnValue = *(bool*)(params.GetStructMemory() + 24);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushboolean(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 K2_OnReset(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Actor",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Actor must be non-null"); lua_error(InScriptContext);  return 0;}
#if UE_GAME
	AActor * This = (AActor *)Obj;
	This->K2_OnReset();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("K2_OnReset"));
	if(!Function) { check(false); return 0;}
	Obj->ProcessEvent(Function, NULL);
#endif
	return 0;
}

int32 K2_OnEndViewTarget(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Actor",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Actor must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		APlayerController* PC = nullptr;
	} Params;
	Params.PC = (APlayerController*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"PlayerController");;
#if UE_GAME
	AActor * This = (AActor *)Obj;
	This->K2_OnEndViewTarget(Params.PC);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("K2_OnEndViewTarget"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(APlayerController**)(params.GetStructMemory() + 0) = Params.PC;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.PC = *(APlayerController**)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 K2_OnBecomeViewTarget(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Actor",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Actor must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		APlayerController* PC = nullptr;
	} Params;
	Params.PC = (APlayerController*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"PlayerController");;
#if UE_GAME
	AActor * This = (AActor *)Obj;
	This->K2_OnBecomeViewTarget(Params.PC);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("K2_OnBecomeViewTarget"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(APlayerController**)(params.GetStructMemory() + 0) = Params.PC;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.PC = *(APlayerController**)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 K2_GetRootComponent(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Actor",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Actor must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		USceneComponent* ReturnValue = nullptr;
	} Params;
#if UE_GAME
	AActor * This = (AActor *)Obj;
	Params.ReturnValue = This->K2_GetRootComponent();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("K2_GetRootComponent"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(USceneComponent**)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 K2_GetActorRotation(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Actor",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Actor must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FRotator ReturnValue;
	} Params;
#if UE_GAME
	AActor * This = (AActor *)Obj;
	Params.ReturnValue = This->K2_GetActorRotation();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("K2_GetActorRotation"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(FRotator*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaRotator::Return(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 K2_GetActorLocation(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Actor",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Actor must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FVector ReturnValue;
	} Params;
#if UE_GAME
	AActor * This = (AActor *)Obj;
	Params.ReturnValue = This->K2_GetActorLocation();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("K2_GetActorLocation"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(FVector*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaVector::Return(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 K2_DetachFromActor(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Actor",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Actor must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		EDetachmentRule LocationRule;
		EDetachmentRule RotationRule;
		EDetachmentRule ScaleRule;
	} Params;
	Params.LocationRule = lua_isnoneornil(InScriptContext,2) ? EDetachmentRule(EDetachmentRule::KeepRelative) : (EDetachmentRule)(luaL_checkint(InScriptContext, 2));
	Params.RotationRule = lua_isnoneornil(InScriptContext,3) ? EDetachmentRule(EDetachmentRule::KeepRelative) : (EDetachmentRule)(luaL_checkint(InScriptContext, 3));
	Params.ScaleRule = lua_isnoneornil(InScriptContext,4) ? EDetachmentRule(EDetachmentRule::KeepRelative) : (EDetachmentRule)(luaL_checkint(InScriptContext, 4));
#if UE_GAME
	AActor * This = (AActor *)Obj;
	This->K2_DetachFromActor(Params.LocationRule,Params.RotationRule,Params.ScaleRule);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("K2_DetachFromActor"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(EDetachmentRule*)(params.GetStructMemory() + 0) = Params.LocationRule;
		*(EDetachmentRule*)(params.GetStructMemory() + 1) = Params.RotationRule;
		*(EDetachmentRule*)(params.GetStructMemory() + 2) = Params.ScaleRule;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.LocationRule = *(EDetachmentRule*)(params.GetStructMemory() + 0);
		Params.RotationRule = *(EDetachmentRule*)(params.GetStructMemory() + 1);
		Params.ScaleRule = *(EDetachmentRule*)(params.GetStructMemory() + 2);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 K2_DestroyActor(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Actor",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Actor must be non-null"); lua_error(InScriptContext);  return 0;}
#if UE_GAME
	AActor * This = (AActor *)Obj;
	This->K2_DestroyActor();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("K2_DestroyActor"));
	if(!Function) { check(false); return 0;}
	Obj->ProcessEvent(Function, NULL);
#endif
	return 0;
}

int32 K2_AttachToComponent(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Actor",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Actor must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		USceneComponent* Parent = nullptr;
		FName SocketName;
		EAttachmentRule LocationRule;
		EAttachmentRule RotationRule;
		EAttachmentRule ScaleRule;
		bool bWeldSimulatedBodies;
	} Params;
	Params.Parent = (USceneComponent*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"SceneComponent");;
	Params.SocketName = FName(UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 3)));
	Params.LocationRule = (EAttachmentRule)(luaL_checkint(InScriptContext, 4));
	Params.RotationRule = (EAttachmentRule)(luaL_checkint(InScriptContext, 5));
	Params.ScaleRule = (EAttachmentRule)(luaL_checkint(InScriptContext, 6));
	Params.bWeldSimulatedBodies = !!(lua_toboolean(InScriptContext, 7));
#if UE_GAME
	AActor * This = (AActor *)Obj;
	This->K2_AttachToComponent(Params.Parent,Params.SocketName,Params.LocationRule,Params.RotationRule,Params.ScaleRule,Params.bWeldSimulatedBodies);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("K2_AttachToComponent"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(USceneComponent**)(params.GetStructMemory() + 0) = Params.Parent;
		*(FName*)(params.GetStructMemory() + 8) = Params.SocketName;
		*(EAttachmentRule*)(params.GetStructMemory() + 20) = Params.LocationRule;
		*(EAttachmentRule*)(params.GetStructMemory() + 21) = Params.RotationRule;
		*(EAttachmentRule*)(params.GetStructMemory() + 22) = Params.ScaleRule;
		*(bool*)(params.GetStructMemory() + 23) = Params.bWeldSimulatedBodies;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.Parent = *(USceneComponent**)(params.GetStructMemory() + 0);
		Params.SocketName = *(FName*)(params.GetStructMemory() + 8);
		Params.LocationRule = *(EAttachmentRule*)(params.GetStructMemory() + 20);
		Params.RotationRule = *(EAttachmentRule*)(params.GetStructMemory() + 21);
		Params.ScaleRule = *(EAttachmentRule*)(params.GetStructMemory() + 22);
		Params.bWeldSimulatedBodies = *(bool*)(params.GetStructMemory() + 23);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 K2_AttachToActor(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Actor",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Actor must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		AActor* ParentActor = nullptr;
		FName SocketName;
		EAttachmentRule LocationRule;
		EAttachmentRule RotationRule;
		EAttachmentRule ScaleRule;
		bool bWeldSimulatedBodies;
	} Params;
	Params.ParentActor = (AActor*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"Actor");;
	Params.SocketName = FName(UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 3)));
	Params.LocationRule = (EAttachmentRule)(luaL_checkint(InScriptContext, 4));
	Params.RotationRule = (EAttachmentRule)(luaL_checkint(InScriptContext, 5));
	Params.ScaleRule = (EAttachmentRule)(luaL_checkint(InScriptContext, 6));
	Params.bWeldSimulatedBodies = !!(lua_toboolean(InScriptContext, 7));
#if UE_GAME
	AActor * This = (AActor *)Obj;
	This->K2_AttachToActor(Params.ParentActor,Params.SocketName,Params.LocationRule,Params.RotationRule,Params.ScaleRule,Params.bWeldSimulatedBodies);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("K2_AttachToActor"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(AActor**)(params.GetStructMemory() + 0) = Params.ParentActor;
		*(FName*)(params.GetStructMemory() + 8) = Params.SocketName;
		*(EAttachmentRule*)(params.GetStructMemory() + 20) = Params.LocationRule;
		*(EAttachmentRule*)(params.GetStructMemory() + 21) = Params.RotationRule;
		*(EAttachmentRule*)(params.GetStructMemory() + 22) = Params.ScaleRule;
		*(bool*)(params.GetStructMemory() + 23) = Params.bWeldSimulatedBodies;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ParentActor = *(AActor**)(params.GetStructMemory() + 0);
		Params.SocketName = *(FName*)(params.GetStructMemory() + 8);
		Params.LocationRule = *(EAttachmentRule*)(params.GetStructMemory() + 20);
		Params.RotationRule = *(EAttachmentRule*)(params.GetStructMemory() + 21);
		Params.ScaleRule = *(EAttachmentRule*)(params.GetStructMemory() + 22);
		Params.bWeldSimulatedBodies = *(bool*)(params.GetStructMemory() + 23);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 K2_AttachRootComponentToActor(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Actor",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Actor must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		AActor* InParentActor = nullptr;
		FName InSocketName;
		TEnumAsByte<EAttachLocation::Type> AttachLocationType;
		bool bWeldSimulatedBodies;
	} Params;
	Params.InParentActor = (AActor*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"Actor");;
	Params.InSocketName = lua_isnoneornil(InScriptContext,3) ? FName(TEXT("")) : FName(UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 3)));
	Params.AttachLocationType = lua_isnoneornil(InScriptContext,4) ? TEnumAsByte<EAttachLocation::Type>(EAttachLocation::Type::KeepRelativeOffset) : (TEnumAsByte<EAttachLocation::Type>)(luaL_checkint(InScriptContext, 4));
	Params.bWeldSimulatedBodies = lua_isnoneornil(InScriptContext,5) ? bool(true) : !!(lua_toboolean(InScriptContext, 5));
#if UE_GAME
	AActor * This = (AActor *)Obj;
	This->K2_AttachRootComponentToActor(Params.InParentActor,Params.InSocketName,Params.AttachLocationType,Params.bWeldSimulatedBodies);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("K2_AttachRootComponentToActor"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(AActor**)(params.GetStructMemory() + 0) = Params.InParentActor;
		*(FName*)(params.GetStructMemory() + 8) = Params.InSocketName;
		*(TEnumAsByte<EAttachLocation::Type>*)(params.GetStructMemory() + 20) = Params.AttachLocationType;
		*(bool*)(params.GetStructMemory() + 21) = Params.bWeldSimulatedBodies;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.InParentActor = *(AActor**)(params.GetStructMemory() + 0);
		Params.InSocketName = *(FName*)(params.GetStructMemory() + 8);
		Params.AttachLocationType = *(TEnumAsByte<EAttachLocation::Type>*)(params.GetStructMemory() + 20);
		Params.bWeldSimulatedBodies = *(bool*)(params.GetStructMemory() + 21);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 K2_AttachRootComponentTo(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Actor",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Actor must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		USceneComponent* InParent = nullptr;
		FName InSocketName;
		TEnumAsByte<EAttachLocation::Type> AttachLocationType;
		bool bWeldSimulatedBodies;
	} Params;
	Params.InParent = (USceneComponent*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"SceneComponent");;
	Params.InSocketName = lua_isnoneornil(InScriptContext,3) ? FName(TEXT("")) : FName(UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 3)));
	Params.AttachLocationType = lua_isnoneornil(InScriptContext,4) ? TEnumAsByte<EAttachLocation::Type>(EAttachLocation::Type::KeepRelativeOffset) : (TEnumAsByte<EAttachLocation::Type>)(luaL_checkint(InScriptContext, 4));
	Params.bWeldSimulatedBodies = lua_isnoneornil(InScriptContext,5) ? bool(true) : !!(lua_toboolean(InScriptContext, 5));
#if UE_GAME
	AActor * This = (AActor *)Obj;
	This->K2_AttachRootComponentTo(Params.InParent,Params.InSocketName,Params.AttachLocationType,Params.bWeldSimulatedBodies);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("K2_AttachRootComponentTo"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(USceneComponent**)(params.GetStructMemory() + 0) = Params.InParent;
		*(FName*)(params.GetStructMemory() + 8) = Params.InSocketName;
		*(TEnumAsByte<EAttachLocation::Type>*)(params.GetStructMemory() + 20) = Params.AttachLocationType;
		*(bool*)(params.GetStructMemory() + 21) = Params.bWeldSimulatedBodies;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.InParent = *(USceneComponent**)(params.GetStructMemory() + 0);
		Params.InSocketName = *(FName*)(params.GetStructMemory() + 8);
		Params.AttachLocationType = *(TEnumAsByte<EAttachLocation::Type>*)(params.GetStructMemory() + 20);
		Params.bWeldSimulatedBodies = *(bool*)(params.GetStructMemory() + 21);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 IsOverlappingActor(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Actor",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Actor must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		AActor* Other = nullptr;
		bool ReturnValue;
	} Params;
	Params.Other = (AActor*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"Actor");;
#if UE_GAME
	AActor * This = (AActor *)Obj;
	Params.ReturnValue = This->IsOverlappingActor(Params.Other);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("IsOverlappingActor"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(AActor**)(params.GetStructMemory() + 0) = Params.Other;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.Other = *(AActor**)(params.GetStructMemory() + 0);
		Params.ReturnValue = *(bool*)(params.GetStructMemory() + 8);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushboolean(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 IsChildActor(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Actor",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Actor must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool ReturnValue;
	} Params;
#if UE_GAME
	AActor * This = (AActor *)Obj;
	Params.ReturnValue = This->IsChildActor();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("IsChildActor"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushboolean(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 IsActorTickEnabled(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Actor",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Actor must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool ReturnValue;
	} Params;
#if UE_GAME
	AActor * This = (AActor *)Obj;
	Params.ReturnValue = This->IsActorTickEnabled();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("IsActorTickEnabled"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushboolean(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 IsActorBeingDestroyed(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Actor",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Actor must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool ReturnValue;
	} Params;
#if UE_GAME
	AActor * This = (AActor *)Obj;
	Params.ReturnValue = This->IsActorBeingDestroyed();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("IsActorBeingDestroyed"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushboolean(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 HasAuthority(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Actor",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Actor must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool ReturnValue;
	} Params;
#if UE_GAME
	AActor * This = (AActor *)Obj;
	Params.ReturnValue = This->HasAuthority();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("HasAuthority"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushboolean(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetVerticalDistanceTo(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Actor",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Actor must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		AActor* OtherActor = nullptr;
		float ReturnValue;
	} Params;
	Params.OtherActor = (AActor*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"Actor");;
#if UE_GAME
	AActor * This = (AActor *)Obj;
	Params.ReturnValue = This->GetVerticalDistanceTo(Params.OtherActor);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetVerticalDistanceTo"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(AActor**)(params.GetStructMemory() + 0) = Params.OtherActor;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.OtherActor = *(AActor**)(params.GetStructMemory() + 0);
		Params.ReturnValue = *(float*)(params.GetStructMemory() + 8);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushnumber(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetVelocity(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Actor",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Actor must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FVector ReturnValue;
	} Params;
#if UE_GAME
	AActor * This = (AActor *)Obj;
	Params.ReturnValue = This->GetVelocity();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetVelocity"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(FVector*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaVector::Return(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetTransform(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Actor",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Actor must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FTransform ReturnValue;
	} Params;
#if UE_GAME
	AActor * This = (AActor *)Obj;
	Params.ReturnValue = This->GetTransform();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetTransform"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(FTransform*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaTransform::Return(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetTickableWhenPaused(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Actor",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Actor must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool ReturnValue;
	} Params;
#if UE_GAME
	AActor * This = (AActor *)Obj;
	Params.ReturnValue = This->GetTickableWhenPaused();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetTickableWhenPaused"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushboolean(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetSquaredDistanceTo(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Actor",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Actor must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		AActor* OtherActor = nullptr;
		float ReturnValue;
	} Params;
	Params.OtherActor = (AActor*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"Actor");;
#if UE_GAME
	AActor * This = (AActor *)Obj;
	Params.ReturnValue = This->GetSquaredDistanceTo(Params.OtherActor);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetSquaredDistanceTo"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(AActor**)(params.GetStructMemory() + 0) = Params.OtherActor;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.OtherActor = *(AActor**)(params.GetStructMemory() + 0);
		Params.ReturnValue = *(float*)(params.GetStructMemory() + 8);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushnumber(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetRemoteRole(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Actor",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Actor must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		TEnumAsByte<ENetRole> ReturnValue;
	} Params;
#if UE_GAME
	AActor * This = (AActor *)Obj;
	Params.ReturnValue = This->GetRemoteRole();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetRemoteRole"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(TEnumAsByte<ENetRole>*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushinteger(InScriptContext, (int)Params.ReturnValue);
	return 1;
}

int32 GetParentComponent(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Actor",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Actor must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		UChildActorComponent* ReturnValue = nullptr;
	} Params;
#if UE_GAME
	AActor * This = (AActor *)Obj;
	Params.ReturnValue = This->GetParentComponent();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetParentComponent"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(UChildActorComponent**)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetParentActor(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Actor",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Actor must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		AActor* ReturnValue = nullptr;
	} Params;
#if UE_GAME
	AActor * This = (AActor *)Obj;
	Params.ReturnValue = This->GetParentActor();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetParentActor"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(AActor**)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetOwner(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Actor",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Actor must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		AActor* ReturnValue = nullptr;
	} Params;
#if UE_GAME
	AActor * This = (AActor *)Obj;
	Params.ReturnValue = This->GetOwner();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetOwner"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(AActor**)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetOverlappingComponents(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Actor",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Actor must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		TArray<UPrimitiveComponent*> OverlappingComponents;
	} Params;
#if UE_GAME
	AActor * This = (AActor *)Obj;
	This->GetOverlappingComponents(Params.OverlappingComponents);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetOverlappingComponents"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.OverlappingComponents = *(TArray<UPrimitiveComponent*>*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	{lua_newtable(InScriptContext); int i = 1; for(auto It = Params.OverlappingComponents.CreateConstIterator(); It; ++It,++i) {  wLua::FLuaUtils::ReturnUObject(InScriptContext, (*It)); lua_rawseti(InScriptContext,-2,i);     }  }
	return 1;
}

int32 GetOverlappingActors(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Actor",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Actor must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		TArray<AActor*> OverlappingActors;
		TSubclassOf<AActor>  ClassFilter;
	} Params;
	Params.ClassFilter = lua_isnoneornil(InScriptContext,3) ? (UClass*)TSubclassOf<AActor> (nullptr) : (UClass*)wLua::FLuaUtils::GetUObject(InScriptContext,3,"Class");;
#if UE_GAME
	AActor * This = (AActor *)Obj;
	This->GetOverlappingActors(Params.OverlappingActors,Params.ClassFilter);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetOverlappingActors"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(TSubclassOf<AActor> *)(params.GetStructMemory() + 16) = Params.ClassFilter;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.OverlappingActors = *(TArray<AActor*>*)(params.GetStructMemory() + 0);
		Params.ClassFilter = *(TSubclassOf<AActor> *)(params.GetStructMemory() + 16);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	{lua_newtable(InScriptContext); int i = 1; for(auto It = Params.OverlappingActors.CreateConstIterator(); It; ++It,++i) {  wLua::FLuaUtils::ReturnUObject(InScriptContext, (*It)); lua_rawseti(InScriptContext,-2,i);     }  }
	return 1;
}

int32 GetLocalRole(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Actor",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Actor must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		TEnumAsByte<ENetRole> ReturnValue;
	} Params;
#if UE_GAME
	AActor * This = (AActor *)Obj;
	Params.ReturnValue = This->GetLocalRole();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetLocalRole"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(TEnumAsByte<ENetRole>*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushinteger(InScriptContext, (int)Params.ReturnValue);
	return 1;
}

int32 GetLifeSpan(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Actor",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Actor must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float ReturnValue;
	} Params;
#if UE_GAME
	AActor * This = (AActor *)Obj;
	Params.ReturnValue = This->GetLifeSpan();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetLifeSpan"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(float*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushnumber(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetInstigatorController(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Actor",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Actor must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		AController* ReturnValue = nullptr;
	} Params;
#if UE_GAME
	AActor * This = (AActor *)Obj;
	Params.ReturnValue = This->GetInstigatorController();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetInstigatorController"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(AController**)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetInstigator(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Actor",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Actor must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		APawn* ReturnValue = nullptr;
	} Params;
#if UE_GAME
	AActor * This = (AActor *)Obj;
	Params.ReturnValue = This->GetInstigator();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetInstigator"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(APawn**)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetHorizontalDotProductTo(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Actor",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Actor must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		AActor* OtherActor = nullptr;
		float ReturnValue;
	} Params;
	Params.OtherActor = (AActor*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"Actor");;
#if UE_GAME
	AActor * This = (AActor *)Obj;
	Params.ReturnValue = This->GetHorizontalDotProductTo(Params.OtherActor);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetHorizontalDotProductTo"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(AActor**)(params.GetStructMemory() + 0) = Params.OtherActor;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.OtherActor = *(AActor**)(params.GetStructMemory() + 0);
		Params.ReturnValue = *(float*)(params.GetStructMemory() + 8);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushnumber(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetHorizontalDistanceTo(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Actor",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Actor must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		AActor* OtherActor = nullptr;
		float ReturnValue;
	} Params;
	Params.OtherActor = (AActor*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"Actor");;
#if UE_GAME
	AActor * This = (AActor *)Obj;
	Params.ReturnValue = This->GetHorizontalDistanceTo(Params.OtherActor);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetHorizontalDistanceTo"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(AActor**)(params.GetStructMemory() + 0) = Params.OtherActor;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.OtherActor = *(AActor**)(params.GetStructMemory() + 0);
		Params.ReturnValue = *(float*)(params.GetStructMemory() + 8);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushnumber(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetGameTimeSinceCreation(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Actor",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Actor must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float ReturnValue;
	} Params;
#if UE_GAME
	AActor * This = (AActor *)Obj;
	Params.ReturnValue = This->GetGameTimeSinceCreation();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetGameTimeSinceCreation"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(float*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushnumber(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetDotProductTo(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Actor",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Actor must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		AActor* OtherActor = nullptr;
		float ReturnValue;
	} Params;
	Params.OtherActor = (AActor*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"Actor");;
#if UE_GAME
	AActor * This = (AActor *)Obj;
	Params.ReturnValue = This->GetDotProductTo(Params.OtherActor);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetDotProductTo"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(AActor**)(params.GetStructMemory() + 0) = Params.OtherActor;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.OtherActor = *(AActor**)(params.GetStructMemory() + 0);
		Params.ReturnValue = *(float*)(params.GetStructMemory() + 8);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushnumber(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetDistanceTo(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Actor",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Actor must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		AActor* OtherActor = nullptr;
		float ReturnValue;
	} Params;
	Params.OtherActor = (AActor*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"Actor");;
#if UE_GAME
	AActor * This = (AActor *)Obj;
	Params.ReturnValue = This->GetDistanceTo(Params.OtherActor);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetDistanceTo"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(AActor**)(params.GetStructMemory() + 0) = Params.OtherActor;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.OtherActor = *(AActor**)(params.GetStructMemory() + 0);
		Params.ReturnValue = *(float*)(params.GetStructMemory() + 8);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushnumber(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetComponentsInChildren(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Actor",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Actor must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FString className;
		TArray<UActorComponent*> ReturnValue;
	} Params;
	Params.className = UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 2));
#if UE_GAME
	AActor * This = (AActor *)Obj;
	Params.ReturnValue = This->GetComponentsInChildren(Params.className);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetComponentsInChildren"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FString*)(params.GetStructMemory() + 0) = Params.className;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.className = *(FString*)(params.GetStructMemory() + 0);
		Params.ReturnValue = *(TArray<UActorComponent*>*)(params.GetStructMemory() + 16);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	{lua_newtable(InScriptContext); int i = 1; for(auto It = Params.ReturnValue.CreateConstIterator(); It; ++It,++i) {  wLua::FLuaUtils::ReturnUObject(InScriptContext, (*It)); lua_rawseti(InScriptContext,-2,i);     }  }
	return 1;
}

int32 GetComponentsByTag(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Actor",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Actor must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		TSubclassOf<UActorComponent>  ComponentClass;
		FName Tag;
		TArray<UActorComponent*> ReturnValue;
	} Params;
	Params.ComponentClass = (UClass*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"Class");;
	Params.Tag = FName(UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 3)));
#if UE_GAME
	AActor * This = (AActor *)Obj;
	Params.ReturnValue = This->GetComponentsByTag(Params.ComponentClass,Params.Tag);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetComponentsByTag"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(TSubclassOf<UActorComponent> *)(params.GetStructMemory() + 0) = Params.ComponentClass;
		*(FName*)(params.GetStructMemory() + 8) = Params.Tag;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ComponentClass = *(TSubclassOf<UActorComponent> *)(params.GetStructMemory() + 0);
		Params.Tag = *(FName*)(params.GetStructMemory() + 8);
		Params.ReturnValue = *(TArray<UActorComponent*>*)(params.GetStructMemory() + 24);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	{lua_newtable(InScriptContext); int i = 1; for(auto It = Params.ReturnValue.CreateConstIterator(); It; ++It,++i) {  wLua::FLuaUtils::ReturnUObject(InScriptContext, (*It)); lua_rawseti(InScriptContext,-2,i);     }  }
	return 1;
}

int32 GetComponentsByClass(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Actor",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Actor must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		TSubclassOf<UActorComponent>  ComponentClass;
		TArray<UActorComponent*> ReturnValue;
	} Params;
	Params.ComponentClass = (UClass*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"Class");;
#if UE_GAME
	AActor * This = (AActor *)Obj;
	Params.ReturnValue = This->GetComponentsByClass(Params.ComponentClass);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetComponentsByClass"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(TSubclassOf<UActorComponent> *)(params.GetStructMemory() + 0) = Params.ComponentClass;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ComponentClass = *(TSubclassOf<UActorComponent> *)(params.GetStructMemory() + 0);
		Params.ReturnValue = *(TArray<UActorComponent*>*)(params.GetStructMemory() + 8);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	{lua_newtable(InScriptContext); int i = 1; for(auto It = Params.ReturnValue.CreateConstIterator(); It; ++It,++i) {  wLua::FLuaUtils::ReturnUObject(InScriptContext, (*It)); lua_rawseti(InScriptContext,-2,i);     }  }
	return 1;
}

int32 GetComponentInChildren(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Actor",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Actor must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FString className;
		UActorComponent* ReturnValue = nullptr;
	} Params;
	Params.className = UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 2));
#if UE_GAME
	AActor * This = (AActor *)Obj;
	Params.ReturnValue = This->GetComponentInChildren(Params.className);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetComponentInChildren"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FString*)(params.GetStructMemory() + 0) = Params.className;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.className = *(FString*)(params.GetStructMemory() + 0);
		Params.ReturnValue = *(UActorComponent**)(params.GetStructMemory() + 16);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetComponentByClass(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Actor",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Actor must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		TSubclassOf<UActorComponent>  ComponentClass;
		UActorComponent* ReturnValue = nullptr;
	} Params;
	Params.ComponentClass = (UClass*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"Class");;
#if UE_GAME
	AActor * This = (AActor *)Obj;
	Params.ReturnValue = This->GetComponentByClass(Params.ComponentClass);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetComponentByClass"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(TSubclassOf<UActorComponent> *)(params.GetStructMemory() + 0) = Params.ComponentClass;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ComponentClass = *(TSubclassOf<UActorComponent> *)(params.GetStructMemory() + 0);
		Params.ReturnValue = *(UActorComponent**)(params.GetStructMemory() + 8);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetAttachParentSocketName(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Actor",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Actor must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FName ReturnValue;
	} Params;
#if UE_GAME
	AActor * This = (AActor *)Obj;
	Params.ReturnValue = This->GetAttachParentSocketName();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetAttachParentSocketName"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(FName*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushstring(InScriptContext, TCHAR_TO_UTF8(*Params.ReturnValue.ToString()));
	return 1;
}

int32 GetAttachParentActor(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Actor",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Actor must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		AActor* ReturnValue = nullptr;
	} Params;
#if UE_GAME
	AActor * This = (AActor *)Obj;
	Params.ReturnValue = This->GetAttachParentActor();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetAttachParentActor"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(AActor**)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetAttachedActors(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Actor",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Actor must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		TArray<AActor*> OutActors;
	} Params;
#if UE_GAME
	AActor * This = (AActor *)Obj;
	This->GetAttachedActors(Params.OutActors);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetAttachedActors"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.OutActors = *(TArray<AActor*>*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	{lua_newtable(InScriptContext); int i = 1; for(auto It = Params.OutActors.CreateConstIterator(); It; ++It,++i) {  wLua::FLuaUtils::ReturnUObject(InScriptContext, (*It)); lua_rawseti(InScriptContext,-2,i);     }  }
	return 1;
}

int32 GetAllChildActors(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Actor",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Actor must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		TArray<AActor*> ChildActors;
		bool bIncludeDescendants;
	} Params;
	Params.bIncludeDescendants = lua_isnoneornil(InScriptContext,3) ? bool(true) : !!(lua_toboolean(InScriptContext, 3));
#if UE_GAME
	AActor * This = (AActor *)Obj;
	This->GetAllChildActors(Params.ChildActors,Params.bIncludeDescendants);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetAllChildActors"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(bool*)(params.GetStructMemory() + 16) = Params.bIncludeDescendants;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ChildActors = *(TArray<AActor*>*)(params.GetStructMemory() + 0);
		Params.bIncludeDescendants = *(bool*)(params.GetStructMemory() + 16);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	{lua_newtable(InScriptContext); int i = 1; for(auto It = Params.ChildActors.CreateConstIterator(); It; ++It,++i) {  wLua::FLuaUtils::ReturnUObject(InScriptContext, (*It)); lua_rawseti(InScriptContext,-2,i);     }  }
	return 1;
}

int32 GetActorUpVector(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Actor",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Actor must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FVector ReturnValue;
	} Params;
#if UE_GAME
	AActor * This = (AActor *)Obj;
	Params.ReturnValue = This->GetActorUpVector();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetActorUpVector"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(FVector*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaVector::Return(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetActorTimeDilation(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Actor",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Actor must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float ReturnValue;
	} Params;
#if UE_GAME
	AActor * This = (AActor *)Obj;
	Params.ReturnValue = This->GetActorTimeDilation();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetActorTimeDilation"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(float*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushnumber(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetActorTickInterval(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Actor",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Actor must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float ReturnValue;
	} Params;
#if UE_GAME
	AActor * This = (AActor *)Obj;
	Params.ReturnValue = This->GetActorTickInterval();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetActorTickInterval"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(float*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushnumber(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetActorScale3D(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Actor",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Actor must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FVector ReturnValue;
	} Params;
#if UE_GAME
	AActor * This = (AActor *)Obj;
	Params.ReturnValue = This->GetActorScale3D();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetActorScale3D"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(FVector*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaVector::Return(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetActorRightVector(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Actor",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Actor must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FVector ReturnValue;
	} Params;
#if UE_GAME
	AActor * This = (AActor *)Obj;
	Params.ReturnValue = This->GetActorRightVector();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetActorRightVector"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(FVector*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaVector::Return(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetActorRelativeScale3D(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Actor",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Actor must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FVector ReturnValue;
	} Params;
#if UE_GAME
	AActor * This = (AActor *)Obj;
	Params.ReturnValue = This->GetActorRelativeScale3D();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetActorRelativeScale3D"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(FVector*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaVector::Return(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetActorEyesViewPoint(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Actor",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Actor must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FVector OutLocation;
		FRotator OutRotation;
	} Params;
#if UE_GAME
	AActor * This = (AActor *)Obj;
	This->GetActorEyesViewPoint(Params.OutLocation,Params.OutRotation);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetActorEyesViewPoint"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.OutLocation = *(FVector*)(params.GetStructMemory() + 0);
		Params.OutRotation = *(FRotator*)(params.GetStructMemory() + 12);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaVector::Return(InScriptContext, Params.OutLocation);
	wLua::FLuaRotator::Return(InScriptContext, Params.OutRotation);
	return 2;
}

int32 GetActorEnableCollision(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Actor",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Actor must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool ReturnValue;
	} Params;
#if UE_GAME
	AActor * This = (AActor *)Obj;
	Params.ReturnValue = This->GetActorEnableCollision();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetActorEnableCollision"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushboolean(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetActorBounds(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Actor",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Actor must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool bOnlyCollidingComponents;
		FVector Origin;
		FVector BoxExtent;
	} Params;
	Params.bOnlyCollidingComponents = !!(lua_toboolean(InScriptContext, 2));
#if UE_GAME
	AActor * This = (AActor *)Obj;
	This->GetActorBounds(Params.bOnlyCollidingComponents,Params.Origin,Params.BoxExtent);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetActorBounds"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(bool*)(params.GetStructMemory() + 0) = Params.bOnlyCollidingComponents;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.bOnlyCollidingComponents = *(bool*)(params.GetStructMemory() + 0);
		Params.Origin = *(FVector*)(params.GetStructMemory() + 4);
		Params.BoxExtent = *(FVector*)(params.GetStructMemory() + 16);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaVector::Return(InScriptContext, Params.Origin);
	wLua::FLuaVector::Return(InScriptContext, Params.BoxExtent);
	return 2;
}

int32 ForceNetUpdate(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Actor",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Actor must be non-null"); lua_error(InScriptContext);  return 0;}
#if UE_GAME
	AActor * This = (AActor *)Obj;
	This->ForceNetUpdate();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("ForceNetUpdate"));
	if(!Function) { check(false); return 0;}
	Obj->ProcessEvent(Function, NULL);
#endif
	return 0;
}

int32 FlushNetDormancy(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Actor",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Actor must be non-null"); lua_error(InScriptContext);  return 0;}
#if UE_GAME
	AActor * This = (AActor *)Obj;
	This->FlushNetDormancy();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("FlushNetDormancy"));
	if(!Function) { check(false); return 0;}
	Obj->ProcessEvent(Function, NULL);
#endif
	return 0;
}

int32 EnableInput(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Actor",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Actor must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		APlayerController* PlayerController = nullptr;
	} Params;
	Params.PlayerController = (APlayerController*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"PlayerController");;
#if UE_GAME
	AActor * This = (AActor *)Obj;
	This->EnableInput(Params.PlayerController);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("EnableInput"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(APlayerController**)(params.GetStructMemory() + 0) = Params.PlayerController;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.PlayerController = *(APlayerController**)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 DisableInput(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Actor",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Actor must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		APlayerController* PlayerController = nullptr;
	} Params;
	Params.PlayerController = (APlayerController*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"PlayerController");;
#if UE_GAME
	AActor * This = (AActor *)Obj;
	This->DisableInput(Params.PlayerController);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("DisableInput"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(APlayerController**)(params.GetStructMemory() + 0) = Params.PlayerController;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.PlayerController = *(APlayerController**)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 DetachRootComponentFromParent(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Actor",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Actor must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool bMaintainWorldPosition;
	} Params;
	Params.bMaintainWorldPosition = lua_isnoneornil(InScriptContext,2) ? bool(true) : !!(lua_toboolean(InScriptContext, 2));
#if UE_GAME
	AActor * This = (AActor *)Obj;
	This->DetachRootComponentFromParent(Params.bMaintainWorldPosition);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("DetachRootComponentFromParent"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(bool*)(params.GetStructMemory() + 0) = Params.bMaintainWorldPosition;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.bMaintainWorldPosition = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 AddTickPrerequisiteComponent(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Actor",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Actor must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		UActorComponent* PrerequisiteComponent = nullptr;
	} Params;
	Params.PrerequisiteComponent = (UActorComponent*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"ActorComponent");;
#if UE_GAME
	AActor * This = (AActor *)Obj;
	This->AddTickPrerequisiteComponent(Params.PrerequisiteComponent);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("AddTickPrerequisiteComponent"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(UActorComponent**)(params.GetStructMemory() + 0) = Params.PrerequisiteComponent;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.PrerequisiteComponent = *(UActorComponent**)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 AddTickPrerequisiteActor(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Actor",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Actor must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		AActor* PrerequisiteActor = nullptr;
	} Params;
	Params.PrerequisiteActor = (AActor*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"Actor");;
#if UE_GAME
	AActor * This = (AActor *)Obj;
	This->AddTickPrerequisiteActor(Params.PrerequisiteActor);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("AddTickPrerequisiteActor"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(AActor**)(params.GetStructMemory() + 0) = Params.PrerequisiteActor;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.PrerequisiteActor = *(AActor**)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 ActorHasTag(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Actor",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Actor must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FName Tag;
		bool ReturnValue;
	} Params;
	Params.Tag = FName(UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 2)));
#if UE_GAME
	AActor * This = (AActor *)Obj;
	Params.ReturnValue = This->ActorHasTag(Params.Tag);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("ActorHasTag"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FName*)(params.GetStructMemory() + 0) = Params.Tag;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.Tag = *(FName*)(params.GetStructMemory() + 0);
		Params.ReturnValue = *(bool*)(params.GetStructMemory() + 12);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushboolean(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 Get_bHidden(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Actor",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Actor must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AActor::StaticClass(), TEXT("bHidden"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_bOnlyRelevantToOwner(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Actor",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Actor must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AActor::StaticClass(), TEXT("bOnlyRelevantToOwner"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_bAlwaysRelevant(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Actor",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Actor must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AActor::StaticClass(), TEXT("bAlwaysRelevant"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bAlwaysRelevant(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Actor",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Actor must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AActor::StaticClass(), TEXT("bAlwaysRelevant"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bReplicateMovement(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Actor",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Actor must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AActor::StaticClass(), TEXT("bReplicateMovement"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bReplicateMovement(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Actor",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Actor must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AActor::StaticClass(), TEXT("bReplicateMovement"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bNetLoadOnClient(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Actor",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Actor must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AActor::StaticClass(), TEXT("bNetLoadOnClient"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bNetLoadOnClient(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Actor",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Actor must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AActor::StaticClass(), TEXT("bNetLoadOnClient"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bNetUseOwnerRelevancy(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Actor",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Actor must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AActor::StaticClass(), TEXT("bNetUseOwnerRelevancy"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bNetUseOwnerRelevancy(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Actor",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Actor must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AActor::StaticClass(), TEXT("bNetUseOwnerRelevancy"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bAllowTickBeforeBeginPlay(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Actor",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Actor must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AActor::StaticClass(), TEXT("bAllowTickBeforeBeginPlay"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bAllowTickBeforeBeginPlay(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Actor",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Actor must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AActor::StaticClass(), TEXT("bAllowTickBeforeBeginPlay"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bAutoDestroyWhenFinished(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Actor",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Actor must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AActor::StaticClass(), TEXT("bAutoDestroyWhenFinished"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bAutoDestroyWhenFinished(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Actor",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Actor must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AActor::StaticClass(), TEXT("bAutoDestroyWhenFinished"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bBlockInput(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Actor",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Actor must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AActor::StaticClass(), TEXT("bBlockInput"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bBlockInput(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Actor",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Actor must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AActor::StaticClass(), TEXT("bBlockInput"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bCanBeDamaged(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Actor",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Actor must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AActor::StaticClass(), TEXT("bCanBeDamaged"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bCanBeDamaged(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Actor",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Actor must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AActor::StaticClass(), TEXT("bCanBeDamaged"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bFindCameraComponentWhenViewTarget(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Actor",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Actor must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AActor::StaticClass(), TEXT("bFindCameraComponentWhenViewTarget"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bFindCameraComponentWhenViewTarget(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Actor",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Actor must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AActor::StaticClass(), TEXT("bFindCameraComponentWhenViewTarget"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bGenerateOverlapEventsDuringLevelStreaming(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Actor",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Actor must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AActor::StaticClass(), TEXT("bGenerateOverlapEventsDuringLevelStreaming"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bGenerateOverlapEventsDuringLevelStreaming(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Actor",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Actor must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AActor::StaticClass(), TEXT("bGenerateOverlapEventsDuringLevelStreaming"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bIgnoresOriginShifting(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Actor",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Actor must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AActor::StaticClass(), TEXT("bIgnoresOriginShifting"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bIgnoresOriginShifting(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Actor",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Actor must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AActor::StaticClass(), TEXT("bIgnoresOriginShifting"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bEnableAutoLODGeneration(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Actor",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Actor must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AActor::StaticClass(), TEXT("bEnableAutoLODGeneration"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bEnableAutoLODGeneration(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Actor",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Actor must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AActor::StaticClass(), TEXT("bEnableAutoLODGeneration"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bIsEditorOnlyActor(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Actor",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Actor must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AActor::StaticClass(), TEXT("bIsEditorOnlyActor"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bIsEditorOnlyActor(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Actor",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Actor must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AActor::StaticClass(), TEXT("bIsEditorOnlyActor"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bReplicates(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Actor",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Actor must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AActor::StaticClass(), TEXT("bReplicates"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_bCanBeInCluster(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Actor",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Actor must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AActor::StaticClass(), TEXT("bCanBeInCluster"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bCanBeInCluster(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Actor",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Actor must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AActor::StaticClass(), TEXT("bCanBeInCluster"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_InitialLifeSpan(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Actor",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Actor must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AActor::StaticClass(), TEXT("InitialLifeSpan"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_CustomTimeDilation(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Actor",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Actor must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AActor::StaticClass(), TEXT("CustomTimeDilation"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_CustomTimeDilation(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Actor",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Actor must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AActor::StaticClass(), TEXT("CustomTimeDilation"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_NetDormancy(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Actor",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Actor must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AActor::StaticClass(), TEXT("NetDormancy"));
	if(!Property) { check(false); return 0;}
	TEnumAsByte<ENetDormancy> PropertyValue = TEnumAsByte<ENetDormancy>();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushinteger(InScriptContext, (int)PropertyValue);
	return 1;
}

int32 Get_SpawnCollisionHandlingMethod(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Actor",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Actor must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AActor::StaticClass(), TEXT("SpawnCollisionHandlingMethod"));
	if(!Property) { check(false); return 0;}
	ESpawnActorCollisionHandlingMethod PropertyValue = ESpawnActorCollisionHandlingMethod();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushinteger(InScriptContext, (int)PropertyValue);
	return 1;
}

int32 Set_SpawnCollisionHandlingMethod(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Actor",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Actor must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AActor::StaticClass(), TEXT("SpawnCollisionHandlingMethod"));
	if(!Property) { check(false); return 0;}
	ESpawnActorCollisionHandlingMethod PropertyValue = (ESpawnActorCollisionHandlingMethod)(luaL_checkint(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_AutoReceiveInput(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Actor",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Actor must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AActor::StaticClass(), TEXT("AutoReceiveInput"));
	if(!Property) { check(false); return 0;}
	TEnumAsByte<EAutoReceiveInput::Type> PropertyValue = TEnumAsByte<EAutoReceiveInput::Type>();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushinteger(InScriptContext, (int)PropertyValue);
	return 1;
}

int32 Set_AutoReceiveInput(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Actor",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Actor must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AActor::StaticClass(), TEXT("AutoReceiveInput"));
	if(!Property) { check(false); return 0;}
	TEnumAsByte<EAutoReceiveInput::Type> PropertyValue = (TEnumAsByte<EAutoReceiveInput::Type>)(luaL_checkint(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_InputPriority(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Actor",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Actor must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AActor::StaticClass(), TEXT("InputPriority"));
	if(!Property) { check(false); return 0;}
	int32 PropertyValue = int32();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushinteger(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_InputPriority(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Actor",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Actor must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AActor::StaticClass(), TEXT("InputPriority"));
	if(!Property) { check(false); return 0;}
	int32 PropertyValue = (luaL_checkint(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_NetCullDistanceSquared(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Actor",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Actor must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AActor::StaticClass(), TEXT("NetCullDistanceSquared"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_NetUpdateFrequency(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Actor",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Actor must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AActor::StaticClass(), TEXT("NetUpdateFrequency"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_NetUpdateFrequency(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Actor",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Actor must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AActor::StaticClass(), TEXT("NetUpdateFrequency"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_MinNetUpdateFrequency(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Actor",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Actor must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AActor::StaticClass(), TEXT("MinNetUpdateFrequency"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_MinNetUpdateFrequency(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Actor",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Actor must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AActor::StaticClass(), TEXT("MinNetUpdateFrequency"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_NetPriority(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Actor",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Actor must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AActor::StaticClass(), TEXT("NetPriority"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_NetPriority(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Actor",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Actor must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AActor::StaticClass(), TEXT("NetPriority"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_Instigator(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Actor",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Actor must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AActor::StaticClass(), TEXT("Instigator"));
	if(!Property) { check(false); return 0;}
	APawn* PropertyValue;
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaUtils::ReturnUObject(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_Instigator(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Actor",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Actor must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AActor::StaticClass(), TEXT("Instigator"));
	if(!Property) { check(false); return 0;}
	APawn* PropertyValue = (APawn*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"Pawn");;
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_RootComponent(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Actor",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Actor must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AActor::StaticClass(), TEXT("RootComponent"));
	if(!Property) { check(false); return 0;}
	USceneComponent* PropertyValue;
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaUtils::ReturnUObject(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_PivotOffset(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Actor",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Actor must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AActor::StaticClass(), TEXT("PivotOffset"));
	if(!Property) { check(false); return 0;}
	FVector PropertyValue = FVector();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaVector::Return(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_SpriteScale(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Actor",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Actor must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AActor::StaticClass(), TEXT("SpriteScale"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_SpriteScale(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Actor",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Actor must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AActor::StaticClass(), TEXT("SpriteScale"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_AzurePostColorScaleType(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Actor",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Actor must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AActor::StaticClass(), TEXT("AzurePostColorScaleType"));
	if(!Property) { check(false); return 0;}
	TEnumAsByte<EAzurePostColorScaleType> PropertyValue = TEnumAsByte<EAzurePostColorScaleType>();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushinteger(InScriptContext, (int)PropertyValue);
	return 1;
}

int32 Set_AzurePostColorScaleType(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Actor",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Actor must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AActor::StaticClass(), TEXT("AzurePostColorScaleType"));
	if(!Property) { check(false); return 0;}
	TEnumAsByte<EAzurePostColorScaleType> PropertyValue = (TEnumAsByte<EAzurePostColorScaleType>)(luaL_checkint(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_AzureDirectLightShadowScale(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Actor",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Actor must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AActor::StaticClass(), TEXT("AzureDirectLightShadowScale"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushinteger(InScriptContext, (int)PropertyValue);
	return 1;
}

int32 Set_AzureDirectLightShadowScale(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Actor",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Actor must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AActor::StaticClass(), TEXT("AzureDirectLightShadowScale"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = (uint8)(luaL_checkint(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_Tags(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Actor",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Actor must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AActor::StaticClass(), TEXT("Tags"));
	if(!Property) { check(false); return 0;}
	TArray<FName> PropertyValue;
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	{lua_newtable(InScriptContext); int i = 1; for(auto It = PropertyValue.CreateConstIterator(); It; ++It,++i) {  lua_pushstring(InScriptContext, TCHAR_TO_UTF8(*(*It).ToString())); lua_rawseti(InScriptContext,-2,i);     }  }
	return 1;
}

int32 Set_Tags(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Actor",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Actor must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AActor::StaticClass(), TEXT("Tags"));
	if(!Property) { check(false); return 0;}
	TArray<FName> PropertyValue = [](lua_State * _InScriptContext){ TArray<FName> ret; lua_pushnil(_InScriptContext); while(lua_next(_InScriptContext,2)!=0){ FName item = FName(UTF8_TO_TCHAR(luaL_checkstring(_InScriptContext, -1))); ret.Add(item); lua_pop(_InScriptContext,1);  } return ret; }(InScriptContext);;
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Call_OnTakeAnyDamage(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Actor",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Actor must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		AActor* DamagedActor = nullptr;
		float Damage;
		UDamageType* DamageType = nullptr;
		AController* InstigatedBy = nullptr;
		AActor* DamageCauser = nullptr;
	} Params;
	Params.DamagedActor = (AActor*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"Actor");;
	Params.Damage = (float)(luaL_checknumber(InScriptContext, 3));
	Params.DamageType = (UDamageType*)wLua::FLuaUtils::GetUObject(InScriptContext,4,"DamageType");;
	Params.InstigatedBy = (AController*)wLua::FLuaUtils::GetUObject(InScriptContext,5,"Controller");;
	Params.DamageCauser = (AActor*)wLua::FLuaUtils::GetUObject(InScriptContext,6,"Actor");;
	AActor * This = (AActor *)Obj;
	This->OnTakeAnyDamage.Broadcast(Params.DamagedActor,Params.Damage,Params.DamageType,Params.InstigatedBy,Params.DamageCauser);
	return 0;
}

int32 Call_OnTakePointDamage(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Actor",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Actor must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		AActor* DamagedActor = nullptr;
		float Damage;
		AController* InstigatedBy = nullptr;
		FVector HitLocation;
		UPrimitiveComponent* FHitComponent = nullptr;
		FName BoneName;
		FVector ShotFromDirection;
		UDamageType* DamageType = nullptr;
		AActor* DamageCauser = nullptr;
	} Params;
	Params.DamagedActor = (AActor*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"Actor");;
	Params.Damage = (float)(luaL_checknumber(InScriptContext, 3));
	Params.InstigatedBy = (AController*)wLua::FLuaUtils::GetUObject(InScriptContext,4,"Controller");;
	Params.HitLocation = (wLua::FLuaVector::Get(InScriptContext, 5));
	Params.FHitComponent = (UPrimitiveComponent*)wLua::FLuaUtils::GetUObject(InScriptContext,6,"PrimitiveComponent");;
	Params.BoneName = FName(UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 7)));
	Params.ShotFromDirection = (wLua::FLuaVector::Get(InScriptContext, 8));
	Params.DamageType = (UDamageType*)wLua::FLuaUtils::GetUObject(InScriptContext,9,"DamageType");;
	Params.DamageCauser = (AActor*)wLua::FLuaUtils::GetUObject(InScriptContext,10,"Actor");;
	AActor * This = (AActor *)Obj;
	This->OnTakePointDamage.Broadcast(Params.DamagedActor,Params.Damage,Params.InstigatedBy,Params.HitLocation,Params.FHitComponent,Params.BoneName,Params.ShotFromDirection,Params.DamageType,Params.DamageCauser);
	return 0;
}

int32 Call_OnActorBeginOverlap(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Actor",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Actor must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		AActor* OverlappedActor = nullptr;
		AActor* OtherActor = nullptr;
	} Params;
	Params.OverlappedActor = (AActor*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"Actor");;
	Params.OtherActor = (AActor*)wLua::FLuaUtils::GetUObject(InScriptContext,3,"Actor");;
	AActor * This = (AActor *)Obj;
	This->OnActorBeginOverlap.Broadcast(Params.OverlappedActor,Params.OtherActor);
	return 0;
}

int32 Call_OnActorEndOverlap(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Actor",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Actor must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		AActor* OverlappedActor = nullptr;
		AActor* OtherActor = nullptr;
	} Params;
	Params.OverlappedActor = (AActor*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"Actor");;
	Params.OtherActor = (AActor*)wLua::FLuaUtils::GetUObject(InScriptContext,3,"Actor");;
	AActor * This = (AActor *)Obj;
	This->OnActorEndOverlap.Broadcast(Params.OverlappedActor,Params.OtherActor);
	return 0;
}

int32 Call_OnBeginCursorOver(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Actor",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Actor must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		AActor* TouchedActor = nullptr;
	} Params;
	Params.TouchedActor = (AActor*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"Actor");;
	AActor * This = (AActor *)Obj;
	This->OnBeginCursorOver.Broadcast(Params.TouchedActor);
	return 0;
}

int32 Call_OnEndCursorOver(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Actor",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Actor must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		AActor* TouchedActor = nullptr;
	} Params;
	Params.TouchedActor = (AActor*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"Actor");;
	AActor * This = (AActor *)Obj;
	This->OnEndCursorOver.Broadcast(Params.TouchedActor);
	return 0;
}

int32 Call_OnInputTouchBegin(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Actor",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Actor must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		TEnumAsByte<ETouchIndex::Type> FingerIndex;
		AActor* TouchedActor = nullptr;
	} Params;
	Params.FingerIndex = (TEnumAsByte<ETouchIndex::Type>)(luaL_checkint(InScriptContext, 2));
	Params.TouchedActor = (AActor*)wLua::FLuaUtils::GetUObject(InScriptContext,3,"Actor");;
	AActor * This = (AActor *)Obj;
	This->OnInputTouchBegin.Broadcast(Params.FingerIndex,Params.TouchedActor);
	return 0;
}

int32 Call_OnInputTouchEnd(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Actor",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Actor must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		TEnumAsByte<ETouchIndex::Type> FingerIndex;
		AActor* TouchedActor = nullptr;
	} Params;
	Params.FingerIndex = (TEnumAsByte<ETouchIndex::Type>)(luaL_checkint(InScriptContext, 2));
	Params.TouchedActor = (AActor*)wLua::FLuaUtils::GetUObject(InScriptContext,3,"Actor");;
	AActor * This = (AActor *)Obj;
	This->OnInputTouchEnd.Broadcast(Params.FingerIndex,Params.TouchedActor);
	return 0;
}

int32 Call_OnInputTouchEnter(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Actor",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Actor must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		TEnumAsByte<ETouchIndex::Type> FingerIndex;
		AActor* TouchedActor = nullptr;
	} Params;
	Params.FingerIndex = (TEnumAsByte<ETouchIndex::Type>)(luaL_checkint(InScriptContext, 2));
	Params.TouchedActor = (AActor*)wLua::FLuaUtils::GetUObject(InScriptContext,3,"Actor");;
	AActor * This = (AActor *)Obj;
	This->OnInputTouchEnter.Broadcast(Params.FingerIndex,Params.TouchedActor);
	return 0;
}

int32 Call_OnInputTouchLeave(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Actor",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Actor must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		TEnumAsByte<ETouchIndex::Type> FingerIndex;
		AActor* TouchedActor = nullptr;
	} Params;
	Params.FingerIndex = (TEnumAsByte<ETouchIndex::Type>)(luaL_checkint(InScriptContext, 2));
	Params.TouchedActor = (AActor*)wLua::FLuaUtils::GetUObject(InScriptContext,3,"Actor");;
	AActor * This = (AActor *)Obj;
	This->OnInputTouchLeave.Broadcast(Params.FingerIndex,Params.TouchedActor);
	return 0;
}

int32 Call_OnDestroyed(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Actor",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Actor must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		AActor* DestroyedActor = nullptr;
	} Params;
	Params.DestroyedActor = (AActor*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"Actor");;
	AActor * This = (AActor *)Obj;
	This->OnDestroyed.Broadcast(Params.DestroyedActor);
	return 0;
}

int32 Call_OnEndPlay(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Actor",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Actor must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		AActor* Actor = nullptr;
		TEnumAsByte<EEndPlayReason::Type> EndPlayReason;
	} Params;
	Params.Actor = (AActor*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"Actor");;
	Params.EndPlayReason = (TEnumAsByte<EEndPlayReason::Type>)(luaL_checkint(InScriptContext, 3));
	AActor * This = (AActor *)Obj;
	This->OnEndPlay.Broadcast(Params.Actor,Params.EndPlayReason);
	return 0;
}

int32 New(lua_State* InScriptContext)
{
	UObject* Outer = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Object");
	FName Name = FName(luaL_checkstring(InScriptContext, 2));
	UObject* Obj = NewObject<AActor>(Outer, Name);
	wLua::FLuaUtils::ReturnUObject(InScriptContext,Obj);
	return 1;
}

int32 Destroy(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Actor",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Actor must be non-null"); lua_error(InScriptContext);  return 0;}
		AActor * actor = Cast<AActor>(Obj);
		actor->Destroy();
		userdata->flag |= wLua::LuaObjectFlag::DESTROYED;
		wLua::FLuaUtils::RemoveObjectReference(Obj, userdata->stamp, InScriptContext);
#ifdef AZURE_BUILD_WLUACHECK
		UE_LOG(LogAzure, Warning, TEXT("Destroy Actor: %x userdata:%x   stamp:%x"),Obj,userdata,userdata->stamp);
#endif
	return 0;
}

int32 Class(lua_State* InScriptContext)
{
	UClass* Class = AActor::StaticClass();
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Class);
	return 1;
}

const luaL_Reg Lib_Funcs[] =
{
	{ "New", New },
	{ "Destroy", Destroy },
	{ "Class", Class },
	{ "WasRecentlyRendered", WasRecentlyRendered },
	{ "TearOff", TearOff },
	{ "SetTickGroup", SetTickGroup },
	{ "SetTickableWhenPaused", SetTickableWhenPaused },
	{ "SetReplicates", SetReplicates },
	{ "SetReplicateMovement", SetReplicateMovement },
	{ "SetOwner", SetOwner },
	{ "SetNetDormancy", SetNetDormancy },
	{ "SetLifeSpan", SetLifeSpan },
	{ "SetActorTickInterval", SetActorTickInterval },
	{ "SetActorTickEnabled", SetActorTickEnabled },
	{ "SetActorScale3D", SetActorScale3D },
	{ "SetActorRelativeScale3D", SetActorRelativeScale3D },
	{ "SetActorHiddenInGame", SetActorHiddenInGame },
	{ "SetActorEnableCollision", SetActorEnableCollision },
	{ "RemoveTickPrerequisiteComponent", RemoveTickPrerequisiteComponent },
	{ "RemoveTickPrerequisiteActor", RemoveTickPrerequisiteActor },
	{ "ReceiveTick", ReceiveTick },
	{ "ReceiveEndPlay", ReceiveEndPlay },
	{ "ReceiveDestroyed", ReceiveDestroyed },
	{ "ReceiveBeginPlay", ReceiveBeginPlay },
	{ "ReceiveAnyDamage", ReceiveAnyDamage },
	{ "ReceiveActorOnInputTouchLeave", ReceiveActorOnInputTouchLeave },
	{ "ReceiveActorOnInputTouchEnter", ReceiveActorOnInputTouchEnter },
	{ "ReceiveActorOnInputTouchEnd", ReceiveActorOnInputTouchEnd },
	{ "ReceiveActorOnInputTouchBegin", ReceiveActorOnInputTouchBegin },
	{ "ReceiveActorEndOverlap", ReceiveActorEndOverlap },
	{ "ReceiveActorEndCursorOver", ReceiveActorEndCursorOver },
	{ "ReceiveActorBeginOverlap", ReceiveActorBeginOverlap },
	{ "ReceiveActorBeginCursorOver", ReceiveActorBeginCursorOver },
	{ "PrestreamTextures", PrestreamTextures },
	{ "OnRep_ReplicateMovement", OnRep_ReplicateMovement },
	{ "OnRep_ReplicatedMovement", OnRep_ReplicatedMovement },
	{ "OnRep_Owner", OnRep_Owner },
	{ "OnRep_Instigator", OnRep_Instigator },
	{ "OnRep_AttachmentReplication", OnRep_AttachmentReplication },
	{ "MakeNoise", MakeNoise },
	{ "TeleportTo", K2_TeleportTo },
	{ "OnReset", K2_OnReset },
	{ "OnEndViewTarget", K2_OnEndViewTarget },
	{ "OnBecomeViewTarget", K2_OnBecomeViewTarget },
	{ "GetRootComponent", K2_GetRootComponent },
	{ "GetActorRotation", K2_GetActorRotation },
	{ "GetActorLocation", K2_GetActorLocation },
	{ "DetachFromActor", K2_DetachFromActor },
	{ "DestroyActor", K2_DestroyActor },
	{ "AttachToComponent", K2_AttachToComponent },
	{ "AttachToActor", K2_AttachToActor },
	{ "AttachRootComponentToActor", K2_AttachRootComponentToActor },
	{ "AttachRootComponentTo", K2_AttachRootComponentTo },
	{ "IsOverlappingActor", IsOverlappingActor },
	{ "IsChildActor", IsChildActor },
	{ "IsActorTickEnabled", IsActorTickEnabled },
	{ "IsActorBeingDestroyed", IsActorBeingDestroyed },
	{ "HasAuthority", HasAuthority },
	{ "GetVerticalDistanceTo", GetVerticalDistanceTo },
	{ "GetVelocity", GetVelocity },
	{ "GetTransform", GetTransform },
	{ "GetTickableWhenPaused", GetTickableWhenPaused },
	{ "GetSquaredDistanceTo", GetSquaredDistanceTo },
	{ "GetRemoteRole", GetRemoteRole },
	{ "GetParentComponent", GetParentComponent },
	{ "GetParentActor", GetParentActor },
	{ "GetOwner", GetOwner },
	{ "GetOverlappingComponents", GetOverlappingComponents },
	{ "GetOverlappingActors", GetOverlappingActors },
	{ "GetLocalRole", GetLocalRole },
	{ "GetLifeSpan", GetLifeSpan },
	{ "GetInstigatorController", GetInstigatorController },
	{ "GetInstigator", GetInstigator },
	{ "GetHorizontalDotProductTo", GetHorizontalDotProductTo },
	{ "GetHorizontalDistanceTo", GetHorizontalDistanceTo },
	{ "GetGameTimeSinceCreation", GetGameTimeSinceCreation },
	{ "GetDotProductTo", GetDotProductTo },
	{ "GetDistanceTo", GetDistanceTo },
	{ "GetComponentsInChildren", GetComponentsInChildren },
	{ "GetComponentsByTag", GetComponentsByTag },
	{ "GetComponentsByClass", GetComponentsByClass },
	{ "GetComponentInChildren", GetComponentInChildren },
	{ "GetComponentByClass", GetComponentByClass },
	{ "GetAttachParentSocketName", GetAttachParentSocketName },
	{ "GetAttachParentActor", GetAttachParentActor },
	{ "GetAttachedActors", GetAttachedActors },
	{ "GetAllChildActors", GetAllChildActors },
	{ "GetActorUpVector", GetActorUpVector },
	{ "GetActorTimeDilation", GetActorTimeDilation },
	{ "GetActorTickInterval", GetActorTickInterval },
	{ "GetActorScale3D", GetActorScale3D },
	{ "GetActorRightVector", GetActorRightVector },
	{ "GetActorRelativeScale3D", GetActorRelativeScale3D },
	{ "GetActorEyesViewPoint", GetActorEyesViewPoint },
	{ "GetActorEnableCollision", GetActorEnableCollision },
	{ "GetActorBounds", GetActorBounds },
	{ "ForceNetUpdate", ForceNetUpdate },
	{ "FlushNetDormancy", FlushNetDormancy },
	{ "EnableInput", EnableInput },
	{ "DisableInput", DisableInput },
	{ "DetachRootComponentFromParent", DetachRootComponentFromParent },
	{ "AddTickPrerequisiteComponent", AddTickPrerequisiteComponent },
	{ "AddTickPrerequisiteActor", AddTickPrerequisiteActor },
	{ "ActorHasTag", ActorHasTag },
	{ "Get_bHidden", Get_bHidden },
	{ "Get_bOnlyRelevantToOwner", Get_bOnlyRelevantToOwner },
	{ "Get_bAlwaysRelevant", Get_bAlwaysRelevant },
	{ "Set_bAlwaysRelevant", Set_bAlwaysRelevant },
	{ "Get_bReplicateMovement", Get_bReplicateMovement },
	{ "Set_bReplicateMovement", Set_bReplicateMovement },
	{ "Get_bNetLoadOnClient", Get_bNetLoadOnClient },
	{ "Set_bNetLoadOnClient", Set_bNetLoadOnClient },
	{ "Get_bNetUseOwnerRelevancy", Get_bNetUseOwnerRelevancy },
	{ "Set_bNetUseOwnerRelevancy", Set_bNetUseOwnerRelevancy },
	{ "Get_bAllowTickBeforeBeginPlay", Get_bAllowTickBeforeBeginPlay },
	{ "Set_bAllowTickBeforeBeginPlay", Set_bAllowTickBeforeBeginPlay },
	{ "Get_bAutoDestroyWhenFinished", Get_bAutoDestroyWhenFinished },
	{ "Set_bAutoDestroyWhenFinished", Set_bAutoDestroyWhenFinished },
	{ "Get_bBlockInput", Get_bBlockInput },
	{ "Set_bBlockInput", Set_bBlockInput },
	{ "Get_bCanBeDamaged", Get_bCanBeDamaged },
	{ "Set_bCanBeDamaged", Set_bCanBeDamaged },
	{ "Get_bFindCameraComponentWhenViewTarget", Get_bFindCameraComponentWhenViewTarget },
	{ "Set_bFindCameraComponentWhenViewTarget", Set_bFindCameraComponentWhenViewTarget },
	{ "Get_bGenerateOverlapEventsDuringLevelStreaming", Get_bGenerateOverlapEventsDuringLevelStreaming },
	{ "Set_bGenerateOverlapEventsDuringLevelStreaming", Set_bGenerateOverlapEventsDuringLevelStreaming },
	{ "Get_bIgnoresOriginShifting", Get_bIgnoresOriginShifting },
	{ "Set_bIgnoresOriginShifting", Set_bIgnoresOriginShifting },
	{ "Get_bEnableAutoLODGeneration", Get_bEnableAutoLODGeneration },
	{ "Set_bEnableAutoLODGeneration", Set_bEnableAutoLODGeneration },
	{ "Get_bIsEditorOnlyActor", Get_bIsEditorOnlyActor },
	{ "Set_bIsEditorOnlyActor", Set_bIsEditorOnlyActor },
	{ "Get_bReplicates", Get_bReplicates },
	{ "Get_bCanBeInCluster", Get_bCanBeInCluster },
	{ "Set_bCanBeInCluster", Set_bCanBeInCluster },
	{ "Get_InitialLifeSpan", Get_InitialLifeSpan },
	{ "Get_CustomTimeDilation", Get_CustomTimeDilation },
	{ "Set_CustomTimeDilation", Set_CustomTimeDilation },
	{ "Get_NetDormancy", Get_NetDormancy },
	{ "Get_SpawnCollisionHandlingMethod", Get_SpawnCollisionHandlingMethod },
	{ "Set_SpawnCollisionHandlingMethod", Set_SpawnCollisionHandlingMethod },
	{ "Get_AutoReceiveInput", Get_AutoReceiveInput },
	{ "Set_AutoReceiveInput", Set_AutoReceiveInput },
	{ "Get_InputPriority", Get_InputPriority },
	{ "Set_InputPriority", Set_InputPriority },
	{ "Get_NetCullDistanceSquared", Get_NetCullDistanceSquared },
	{ "Get_NetUpdateFrequency", Get_NetUpdateFrequency },
	{ "Set_NetUpdateFrequency", Set_NetUpdateFrequency },
	{ "Get_MinNetUpdateFrequency", Get_MinNetUpdateFrequency },
	{ "Set_MinNetUpdateFrequency", Set_MinNetUpdateFrequency },
	{ "Get_NetPriority", Get_NetPriority },
	{ "Set_NetPriority", Set_NetPriority },
	{ "Get_Instigator", Get_Instigator },
	{ "Set_Instigator", Set_Instigator },
	{ "Get_RootComponent", Get_RootComponent },
	{ "Get_PivotOffset", Get_PivotOffset },
	{ "Get_SpriteScale", Get_SpriteScale },
	{ "Set_SpriteScale", Set_SpriteScale },
	{ "Get_AzurePostColorScaleType", Get_AzurePostColorScaleType },
	{ "Set_AzurePostColorScaleType", Set_AzurePostColorScaleType },
	{ "Get_AzureDirectLightShadowScale", Get_AzureDirectLightShadowScale },
	{ "Set_AzureDirectLightShadowScale", Set_AzureDirectLightShadowScale },
	{ "Get_Tags", Get_Tags },
	{ "Set_Tags", Set_Tags },
	{ "Call_OnTakeAnyDamage", Call_OnTakeAnyDamage },
	{ "Call_OnTakePointDamage", Call_OnTakePointDamage },
	{ "Call_OnActorBeginOverlap", Call_OnActorBeginOverlap },
	{ "Call_OnActorEndOverlap", Call_OnActorEndOverlap },
	{ "Call_OnBeginCursorOver", Call_OnBeginCursorOver },
	{ "Call_OnEndCursorOver", Call_OnEndCursorOver },
	{ "Call_OnInputTouchBegin", Call_OnInputTouchBegin },
	{ "Call_OnInputTouchEnd", Call_OnInputTouchEnd },
	{ "Call_OnInputTouchEnter", Call_OnInputTouchEnter },
	{ "Call_OnInputTouchLeave", Call_OnInputTouchLeave },
	{ "Call_OnDestroyed", Call_OnDestroyed },
	{ "Call_OnEndPlay", Call_OnEndPlay },
	{ "AddComponent", AddComponent2 },
	{ "SetActive", SetActive2 },
	{ "SetLogicActive", SetLogicActive },
	{ "SetActorLocation", SetActorLocation2 },
	{ "GetActorLocation", GetActorLocation2 },
	{ "SetActorRotation", SetActorRotation2 },
	{ "GetActorRotation", GetActorRotation2 },
	{ "GetActorForwardVector", GetActorForwardVector2 },
	{ "SetActorScale", SetActorScale2 },
	{ "GetActorScale", GetActorScale2 },
	{ "SetActorTransform", SetActorTransform2 },
	{ "SetActorLocationAndRotation", SetActorLocationAndRotation2 },
	{ "SetParent", SetParent2 },
	{ "GetWorld", GetWorld2 },
	{ "SetActorLocalLocation", SetOrGetActorRelativeLocation },
	{ "GetActorLocalLocation", SetOrGetActorRelativeLocation },
	{ "SetActorLocalRotation", SetOrGetActorRelativeRotation },
	{ "GetActorLocalRotation", SetOrGetActorRelativeRotation },
	{ "SetActorLocalScale", SetOrGetActorRelativeScale },
	{ "GetActorLocalScale", SetOrGetActorRelativeScale },
	{ "ResumeActorLocalTransform", ResumeActorLocalTransform },
	{ "GetChildrenCount", GetChildrenCount },
	{ "GetChild", GetChild },
	{ "FindChildDirect", FindChildDirect },
	{ "FindChild", FindChild },
	{ "FindAttachChildActor", FindAttachChildActor },
	{ "TransformPoint", TransformPoint },
	{ "TransformRotator", TransformRotator },
	{ "GetComponentByVariableName", GetComponentByVariableName },
	{ "SetLightingChannelMask", SetLightingChannelMask },
	{ "SetIndirectLightingCacheQuality", SetIndirectLightingCacheQuality },
	{ "GetComponentByName", GetComponentByName },
	{ "SetActorLabel", SetActorLabel },
	{ "SetFolderPath", SetFolderPath },
	{ "GetFolderPath", GetFolderPath },
	{ "SetUseGlobalSHIndirectLighting", SetUseGlobalSHIndirectLighting },
	{ "ResetUseGlobalSHIndirectLighting", ResetUseGlobalSHIndirectLighting },
	{ "GetLevel", GetLevel },
	{ "is_nil", wLua::LuaStatic::isnil },
	{ "__gc", wLua::LuaStatic::removeUClassFrameCache },
	{ NULL, NULL }
};

void Register(lua_State *InScriptContext)
{
	lua_newtable(InScriptContext);
	luaL_register(InScriptContext, NULL, Lib_Funcs);
	AzureHelpFuncs::AuxRegister(InScriptContext, "Actor");
}
void SetMtLink(lua_State *InScriptContext)
{
	AzureHelpFuncs::AuxSetMtLink(InScriptContext, "Actor", "Object",USERDATATYPE_UOBJECT);
}

}