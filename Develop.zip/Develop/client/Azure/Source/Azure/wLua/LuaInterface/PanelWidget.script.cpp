#include "Azure.h"
#include "Utility/help_funcs.h"
#include "wLua/UObjectHeaders.h"
#include "Components/PanelWidget.h"
#include "AzureLuaIntegration.h"

namespace LuaPanelWidget
{
int32 RemoveChild2(lua_State*);
int32 RemoveChildAt2(lua_State*);
int32 AddChildEx(lua_State*);
int32 Class(lua_State*);
int32 GetChildAt2(lua_State*);
int32 GetChildWidgetByName2(lua_State*);

int32 HasChild(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PanelWidget",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PanelWidget must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		UWidget* Content = nullptr;
		bool ReturnValue;
	} Params;
	Params.Content = (UWidget*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"Widget");;
#if UE_GAME
	UPanelWidget * This = (UPanelWidget *)Obj;
	Params.ReturnValue = This->HasChild(Params.Content);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("HasChild"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(UWidget**)(params.GetStructMemory() + 0) = Params.Content;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.Content = *(UWidget**)(params.GetStructMemory() + 0);
		Params.ReturnValue = *(bool*)(params.GetStructMemory() + 8);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushboolean(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 HasAnyChildren(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PanelWidget",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PanelWidget must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool ReturnValue;
	} Params;
#if UE_GAME
	UPanelWidget * This = (UPanelWidget *)Obj;
	Params.ReturnValue = This->HasAnyChildren();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("HasAnyChildren"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushboolean(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetChildrenCount(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PanelWidget",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PanelWidget must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		int32 ReturnValue;
	} Params;
#if UE_GAME
	UPanelWidget * This = (UPanelWidget *)Obj;
	Params.ReturnValue = This->GetChildrenCount();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetChildrenCount"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(int32*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushinteger(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetChildIndex(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PanelWidget",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PanelWidget must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		UWidget* Content = nullptr;
		int32 ReturnValue;
	} Params;
	Params.Content = (UWidget*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"Widget");;
#if UE_GAME
	UPanelWidget * This = (UPanelWidget *)Obj;
	Params.ReturnValue = This->GetChildIndex(Params.Content);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetChildIndex"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(UWidget**)(params.GetStructMemory() + 0) = Params.Content;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.Content = *(UWidget**)(params.GetStructMemory() + 0);
		Params.ReturnValue = *(int32*)(params.GetStructMemory() + 8);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushinteger(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 ClearChildren(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PanelWidget",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PanelWidget must be non-null"); lua_error(InScriptContext);  return 0;}
#if UE_GAME
	UPanelWidget * This = (UPanelWidget *)Obj;
	This->ClearChildren();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("ClearChildren"));
	if(!Function) { check(false); return 0;}
	Obj->ProcessEvent(Function, NULL);
#endif
	return 0;
}

int32 AddChild(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"PanelWidget",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"PanelWidget must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		UWidget* Content = nullptr;
		UPanelSlot* ReturnValue = nullptr;
	} Params;
	Params.Content = (UWidget*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"Widget");;
#if UE_GAME
	UPanelWidget * This = (UPanelWidget *)Obj;
	Params.ReturnValue = This->AddChild(Params.Content);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("AddChild"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(UWidget**)(params.GetStructMemory() + 0) = Params.Content;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.Content = *(UWidget**)(params.GetStructMemory() + 0);
		Params.ReturnValue = *(UPanelSlot**)(params.GetStructMemory() + 8);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 Class(lua_State* InScriptContext)
{
	UClass* Class = UPanelWidget::StaticClass();
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Class);
	return 1;
}

const luaL_Reg Lib_Funcs[] =
{
	{ "Class", Class },
	{ "HasChild", HasChild },
	{ "HasAnyChildren", HasAnyChildren },
	{ "GetChildrenCount", GetChildrenCount },
	{ "GetChildIndex", GetChildIndex },
	{ "ClearChildren", ClearChildren },
	{ "AddChild", AddChild },
	{ "RemoveChild", RemoveChild2 },
	{ "RemoveChildAt", RemoveChildAt2 },
	{ "AddChildEx", AddChildEx },
	{ "Class", Class },
	{ "GetChildAt", GetChildAt2 },
	{ "GetChildWidgetByName", GetChildWidgetByName2 },
	{ "is_nil", wLua::LuaStatic::isnil },
	{ "__gc", wLua::LuaStatic::removeUClassFrameCache },
	{ NULL, NULL }
};

void Register(lua_State *InScriptContext)
{
	lua_newtable(InScriptContext);
	luaL_register(InScriptContext, NULL, Lib_Funcs);
	AzureHelpFuncs::AuxRegister(InScriptContext, "PanelWidget");
}
void SetMtLink(lua_State *InScriptContext)
{
	AzureHelpFuncs::AuxSetMtLink(InScriptContext, "PanelWidget", "Widget",USERDATATYPE_UOBJECT);
}

}