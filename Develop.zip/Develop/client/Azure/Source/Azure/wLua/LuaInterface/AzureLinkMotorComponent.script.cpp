#include "Azure.h"
#include "Utility/help_funcs.h"
#include "wLua/UObjectHeaders.h"
#include "AzureLinkMotorComponent.h"
#include "AzureLuaIntegration.h"

namespace LuaAzureLinkMotorComponent
{
int32 StartMove(lua_State*);

int32 SetExtraParam(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureLinkMotorComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureLinkMotorComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		UParticleSystemComponent* ParticleCom = nullptr;
		AActor* _Source = nullptr;
		AActor* _Target = nullptr;
		USkinnedMeshComponent* _SourceMesh = nullptr;
		USkinnedMeshComponent* _TargetMesh = nullptr;
		FString _socket;
		float _offRight;
		float _offHeightRatio;
		float _offForward;
		float _performerHeight;
		FString _tarSocket;
		float _tarOffRight;
		float _tarOffHeightRatio;
		float _tarOffForward;
		float _targetHeight;
	} Params;
	Params.ParticleCom = (UParticleSystemComponent*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"ParticleSystemComponent");;
	Params._Source = (AActor*)wLua::FLuaUtils::GetUObject(InScriptContext,3,"Actor");;
	Params._Target = (AActor*)wLua::FLuaUtils::GetUObject(InScriptContext,4,"Actor");;
	Params._SourceMesh = (USkinnedMeshComponent*)wLua::FLuaUtils::GetUObject(InScriptContext,5,"SkinnedMeshComponent");;
	Params._TargetMesh = (USkinnedMeshComponent*)wLua::FLuaUtils::GetUObject(InScriptContext,6,"SkinnedMeshComponent");;
	Params._socket = UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 7));
	Params._offRight = (float)(luaL_checknumber(InScriptContext, 8));
	Params._offHeightRatio = (float)(luaL_checknumber(InScriptContext, 9));
	Params._offForward = (float)(luaL_checknumber(InScriptContext, 10));
	Params._performerHeight = (float)(luaL_checknumber(InScriptContext, 11));
	Params._tarSocket = UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 12));
	Params._tarOffRight = (float)(luaL_checknumber(InScriptContext, 13));
	Params._tarOffHeightRatio = (float)(luaL_checknumber(InScriptContext, 14));
	Params._tarOffForward = (float)(luaL_checknumber(InScriptContext, 15));
	Params._targetHeight = (float)(luaL_checknumber(InScriptContext, 16));
#if UE_GAME
	UAzureLinkMotorComponent * This = (UAzureLinkMotorComponent *)Obj;
	This->SetExtraParam(Params.ParticleCom,Params._Source,Params._Target,Params._SourceMesh,Params._TargetMesh,Params._socket,Params._offRight,Params._offHeightRatio,Params._offForward,Params._performerHeight,Params._tarSocket,Params._tarOffRight,Params._tarOffHeightRatio,Params._tarOffForward,Params._targetHeight);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetExtraParam"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(UParticleSystemComponent**)(params.GetStructMemory() + 0) = Params.ParticleCom;
		*(AActor**)(params.GetStructMemory() + 8) = Params._Source;
		*(AActor**)(params.GetStructMemory() + 16) = Params._Target;
		*(USkinnedMeshComponent**)(params.GetStructMemory() + 24) = Params._SourceMesh;
		*(USkinnedMeshComponent**)(params.GetStructMemory() + 32) = Params._TargetMesh;
		*(FString*)(params.GetStructMemory() + 40) = Params._socket;
		*(float*)(params.GetStructMemory() + 56) = Params._offRight;
		*(float*)(params.GetStructMemory() + 60) = Params._offHeightRatio;
		*(float*)(params.GetStructMemory() + 64) = Params._offForward;
		*(float*)(params.GetStructMemory() + 68) = Params._performerHeight;
		*(FString*)(params.GetStructMemory() + 72) = Params._tarSocket;
		*(float*)(params.GetStructMemory() + 88) = Params._tarOffRight;
		*(float*)(params.GetStructMemory() + 92) = Params._tarOffHeightRatio;
		*(float*)(params.GetStructMemory() + 96) = Params._tarOffForward;
		*(float*)(params.GetStructMemory() + 100) = Params._targetHeight;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ParticleCom = *(UParticleSystemComponent**)(params.GetStructMemory() + 0);
		Params._Source = *(AActor**)(params.GetStructMemory() + 8);
		Params._Target = *(AActor**)(params.GetStructMemory() + 16);
		Params._SourceMesh = *(USkinnedMeshComponent**)(params.GetStructMemory() + 24);
		Params._TargetMesh = *(USkinnedMeshComponent**)(params.GetStructMemory() + 32);
		Params._socket = *(FString*)(params.GetStructMemory() + 40);
		Params._offRight = *(float*)(params.GetStructMemory() + 56);
		Params._offHeightRatio = *(float*)(params.GetStructMemory() + 60);
		Params._offForward = *(float*)(params.GetStructMemory() + 64);
		Params._performerHeight = *(float*)(params.GetStructMemory() + 68);
		Params._tarSocket = *(FString*)(params.GetStructMemory() + 72);
		Params._tarOffRight = *(float*)(params.GetStructMemory() + 88);
		Params._tarOffHeightRatio = *(float*)(params.GetStructMemory() + 92);
		Params._tarOffForward = *(float*)(params.GetStructMemory() + 96);
		Params._targetHeight = *(float*)(params.GetStructMemory() + 100);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 New(lua_State* InScriptContext)
{
	UObject* Outer = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Object");
	FName Name = FName(luaL_checkstring(InScriptContext, 2));
	UObject* Obj = NewObject<UAzureLinkMotorComponent>(Outer, Name);
	wLua::FLuaUtils::ReturnUObject(InScriptContext,Obj);
	return 1;
}

int32 Destroy(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureLinkMotorComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureLinkMotorComponent must be non-null"); lua_error(InScriptContext);  return 0;}
		UActorComponent * com = Cast<UActorComponent>(Obj);
		if(lua_isnoneornil(InScriptContext,2))
			com->DestroyComponent();
		else
			com->DestroyComponent(!!lua_toboolean(InScriptContext,2));
		userdata->flag |= wLua::LuaObjectFlag::DESTROYED;
		wLua::FLuaUtils::RemoveObjectReference(Obj, userdata->stamp, InScriptContext);
#ifdef AZURE_BUILD_WLUACHECK
		UE_LOG(LogAzure, Warning, TEXT("Destroy AzureLinkMotorComponent: %x userdata:%x   stamp:%x"),Obj,userdata,userdata->stamp);
#endif
	return 0;
}

int32 Class(lua_State* InScriptContext)
{
	UClass* Class = UAzureLinkMotorComponent::StaticClass();
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Class);
	return 1;
}

const luaL_Reg Lib_Funcs[] =
{
	{ "New", New },
	{ "Destroy", Destroy },
	{ "Class", Class },
	{ "SetExtraParam", SetExtraParam },
	{ "StartMove", StartMove },
	{ "is_nil", wLua::LuaStatic::isnil },
	{ "__gc", wLua::LuaStatic::removeUClassFrameCache },
	{ NULL, NULL }
};

void Register(lua_State *InScriptContext)
{
	lua_newtable(InScriptContext);
	luaL_register(InScriptContext, NULL, Lib_Funcs);
	AzureHelpFuncs::AuxRegister(InScriptContext, "AzureLinkMotorComponent");
}
void SetMtLink(lua_State *InScriptContext)
{
	AzureHelpFuncs::AuxSetMtLink(InScriptContext, "AzureLinkMotorComponent", "AzureMotorComponent",USERDATATYPE_UOBJECT);
}

}