#pragma once
#include "wLua/LuaInterface.h"

namespace LuaObject {
void Register(lua_State *InScriptContext);
void SetMtLink(lua_State *InScriptContext);
};

namespace LuaClass {
void Register(lua_State *InScriptContext);
void SetMtLink(lua_State *InScriptContext);
};

namespace LuaPackage {
void Register(lua_State *InScriptContext);
void SetMtLink(lua_State *InScriptContext);
};

namespace LuaGUIActor {
void Register(lua_State *InScriptContext);
void SetMtLink(lua_State *InScriptContext);
};

namespace LuaMovieSceneSequencePlayer {
void Register(lua_State *InScriptContext);
void SetMtLink(lua_State *InScriptContext);
};

namespace LuaLevelSequencePlayer {
void Register(lua_State *InScriptContext);
void SetMtLink(lua_State *InScriptContext);
};

namespace LuaLevelSequencePlayerEx {
void Register(lua_State *InScriptContext);
void SetMtLink(lua_State *InScriptContext);
};

namespace LuaLevelSequenceActor {
void Register(lua_State *InScriptContext);
void SetMtLink(lua_State *InScriptContext);
};

namespace LuaLevelSequenceActorEx {
void Register(lua_State *InScriptContext);
void SetMtLink(lua_State *InScriptContext);
};

namespace LuaDefaultLevelSequenceInstanceData {
void Register(lua_State *InScriptContext);
void SetMtLink(lua_State *InScriptContext);
};

namespace LuaActor {
void Register(lua_State *InScriptContext);
void SetMtLink(lua_State *InScriptContext);
};

namespace LuaPawn {
void Register(lua_State *InScriptContext);
void SetMtLink(lua_State *InScriptContext);
};

namespace LuaCharacter {
void Register(lua_State *InScriptContext);
void SetMtLink(lua_State *InScriptContext);
};

namespace LuaMyMovementComponent {
void Register(lua_State *InScriptContext);
void SetMtLink(lua_State *InScriptContext);
};

namespace LuaCharacterMovementComponent {
void Register(lua_State *InScriptContext);
void SetMtLink(lua_State *InScriptContext);
};

namespace LuaNavMovementComponent {
void Register(lua_State *InScriptContext);
void SetMtLink(lua_State *InScriptContext);
};

namespace LuaPawnMovementComponent {
void Register(lua_State *InScriptContext);
void SetMtLink(lua_State *InScriptContext);
};

namespace LuaMovementComponent {
void Register(lua_State *InScriptContext);
void SetMtLink(lua_State *InScriptContext);
};

namespace LuaBrush {
void Register(lua_State *InScriptContext);
void SetMtLink(lua_State *InScriptContext);
};

namespace LuaVolume {
void Register(lua_State *InScriptContext);
void SetMtLink(lua_State *InScriptContext);
};

namespace LuaPhysicsVolume {
void Register(lua_State *InScriptContext);
void SetMtLink(lua_State *InScriptContext);
};

namespace LuaPostProcessVolume {
void Register(lua_State *InScriptContext);
void SetMtLink(lua_State *InScriptContext);
};

namespace LuaTexture {
void Register(lua_State *InScriptContext);
void SetMtLink(lua_State *InScriptContext);
};

namespace LuaTextureRenderTarget {
void Register(lua_State *InScriptContext);
void SetMtLink(lua_State *InScriptContext);
};

namespace LuaTextureRenderTarget2D {
void Register(lua_State *InScriptContext);
void SetMtLink(lua_State *InScriptContext);
};

namespace LuaDecalActor {
void Register(lua_State *InScriptContext);
void SetMtLink(lua_State *InScriptContext);
};

namespace LuaStaticMeshActor {
void Register(lua_State *InScriptContext);
void SetMtLink(lua_State *InScriptContext);
};

namespace LuaTexture2D {
void Register(lua_State *InScriptContext);
void SetMtLink(lua_State *InScriptContext);
};

namespace LuaGameplayStatics {
void Register(lua_State *InScriptContext);
void SetMtLink(lua_State *InScriptContext);
};

namespace LuaKismetRenderingLibrary {
void Register(lua_State *InScriptContext);
void SetMtLink(lua_State *InScriptContext);
};

namespace LuaPrimitiveComponent {
void Register(lua_State *InScriptContext);
void SetMtLink(lua_State *InScriptContext);
};

namespace LuaSceneComponent {
void Register(lua_State *InScriptContext);
void SetMtLink(lua_State *InScriptContext);
};

namespace LuaDecalComponent {
void Register(lua_State *InScriptContext);
void SetMtLink(lua_State *InScriptContext);
};

namespace LuaShapeComponent {
void Register(lua_State *InScriptContext);
void SetMtLink(lua_State *InScriptContext);
};

namespace LuaCapsuleComponent {
void Register(lua_State *InScriptContext);
void SetMtLink(lua_State *InScriptContext);
};

namespace LuaBoxComponent {
void Register(lua_State *InScriptContext);
void SetMtLink(lua_State *InScriptContext);
};

namespace LuaMaterial {
void Register(lua_State *InScriptContext);
void SetMtLink(lua_State *InScriptContext);
};

namespace LuaMaterialInstance {
void Register(lua_State *InScriptContext);
void SetMtLink(lua_State *InScriptContext);
};

namespace LuaMaterialInstanceDynamic {
void Register(lua_State *InScriptContext);
void SetMtLink(lua_State *InScriptContext);
};

namespace LuaMaterialInstanceConstant {
void Register(lua_State *InScriptContext);
void SetMtLink(lua_State *InScriptContext);
};

namespace LuaMaterialInterface {
void Register(lua_State *InScriptContext);
void SetMtLink(lua_State *InScriptContext);
};

namespace LuaPanelWidget {
void Register(lua_State *InScriptContext);
void SetMtLink(lua_State *InScriptContext);
};

namespace LuaWidgetComponent {
void Register(lua_State *InScriptContext);
void SetMtLink(lua_State *InScriptContext);
};

namespace LuaWidgetInteractionComponent {
void Register(lua_State *InScriptContext);
void SetMtLink(lua_State *InScriptContext);
};

namespace LuaWidget {
void Register(lua_State *InScriptContext);
void SetMtLink(lua_State *InScriptContext);
};

namespace LuaVisual {
void Register(lua_State *InScriptContext);
void SetMtLink(lua_State *InScriptContext);
};

namespace LuaBorder {
void Register(lua_State *InScriptContext);
void SetMtLink(lua_State *InScriptContext);
};

namespace LuaUserWidget {
void Register(lua_State *InScriptContext);
void SetMtLink(lua_State *InScriptContext);
};

namespace LuaTextBlock {
void Register(lua_State *InScriptContext);
void SetMtLink(lua_State *InScriptContext);
};

namespace LuaTextLayoutWidget {
void Register(lua_State *InScriptContext);
void SetMtLink(lua_State *InScriptContext);
};

namespace LuaProgressBar {
void Register(lua_State *InScriptContext);
void SetMtLink(lua_State *InScriptContext);
};

namespace LuaButton {
void Register(lua_State *InScriptContext);
void SetMtLink(lua_State *InScriptContext);
};

namespace LuaContentWidget {
void Register(lua_State *InScriptContext);
void SetMtLink(lua_State *InScriptContext);
};

namespace LuaCameraActor {
void Register(lua_State *InScriptContext);
void SetMtLink(lua_State *InScriptContext);
};

namespace LuaCineCameraActor {
void Register(lua_State *InScriptContext);
void SetMtLink(lua_State *InScriptContext);
};

namespace LuaCineCameraComponent {
void Register(lua_State *InScriptContext);
void SetMtLink(lua_State *InScriptContext);
};

namespace LuaLevelStreaming {
void Register(lua_State *InScriptContext);
void SetMtLink(lua_State *InScriptContext);
};

namespace LuaCameraComponent {
void Register(lua_State *InScriptContext);
void SetMtLink(lua_State *InScriptContext);
};

namespace LuaPanelSlot {
void Register(lua_State *InScriptContext);
void SetMtLink(lua_State *InScriptContext);
};

namespace LuaCanvasPanel {
void Register(lua_State *InScriptContext);
void SetMtLink(lua_State *InScriptContext);
};

namespace LuaCanvasPanelSlot {
void Register(lua_State *InScriptContext);
void SetMtLink(lua_State *InScriptContext);
};

namespace LuaVerticalBox {
void Register(lua_State *InScriptContext);
void SetMtLink(lua_State *InScriptContext);
};

namespace LuaVerticalBoxSlot {
void Register(lua_State *InScriptContext);
void SetMtLink(lua_State *InScriptContext);
};

namespace LuaHorizontalBox {
void Register(lua_State *InScriptContext);
void SetMtLink(lua_State *InScriptContext);
};

namespace LuaHorizontalBoxSlot {
void Register(lua_State *InScriptContext);
void SetMtLink(lua_State *InScriptContext);
};

namespace LuaCheckBox {
void Register(lua_State *InScriptContext);
void SetMtLink(lua_State *InScriptContext);
};

namespace LuaEditableTextBox {
void Register(lua_State *InScriptContext);
void SetMtLink(lua_State *InScriptContext);
};

namespace LuaAzureEditableTextBox {
void Register(lua_State *InScriptContext);
void SetMtLink(lua_State *InScriptContext);
};

namespace LuaMultiLineEditableTextBox {
void Register(lua_State *InScriptContext);
void SetMtLink(lua_State *InScriptContext);
};

namespace LuaMultiLineEditableText {
void Register(lua_State *InScriptContext);
void SetMtLink(lua_State *InScriptContext);
};

namespace LuaSizeBox {
void Register(lua_State *InScriptContext);
void SetMtLink(lua_State *InScriptContext);
};

namespace LuaSizeBoxSlot {
void Register(lua_State *InScriptContext);
void SetMtLink(lua_State *InScriptContext);
};

namespace LuaImage {
void Register(lua_State *InScriptContext);
void SetMtLink(lua_State *InScriptContext);
};

namespace LuaWidgetSwitcher {
void Register(lua_State *InScriptContext);
void SetMtLink(lua_State *InScriptContext);
};

namespace LuaSkeletalMesh {
void Register(lua_State *InScriptContext);
void SetMtLink(lua_State *InScriptContext);
};

namespace LuaStaticMesh {
void Register(lua_State *InScriptContext);
void SetMtLink(lua_State *InScriptContext);
};

namespace LuaMeshComponent {
void Register(lua_State *InScriptContext);
void SetMtLink(lua_State *InScriptContext);
};

namespace LuaStaticMeshComponent {
void Register(lua_State *InScriptContext);
void SetMtLink(lua_State *InScriptContext);
};

namespace LuaSkinnedMeshComponent {
void Register(lua_State *InScriptContext);
void SetMtLink(lua_State *InScriptContext);
};

namespace LuaSkeletalMeshComponent {
void Register(lua_State *InScriptContext);
void SetMtLink(lua_State *InScriptContext);
};

namespace LuaAnimInstance {
void Register(lua_State *InScriptContext);
void SetMtLink(lua_State *InScriptContext);
};

namespace LuaAnimSequenceBase {
void Register(lua_State *InScriptContext);
void SetMtLink(lua_State *InScriptContext);
};

namespace LuaAnimMontage {
void Register(lua_State *InScriptContext);
void SetMtLink(lua_State *InScriptContext);
};

namespace LuaLevel {
void Register(lua_State *InScriptContext);
void SetMtLink(lua_State *InScriptContext);
};

namespace LuaWorld {
void Register(lua_State *InScriptContext);
void SetMtLink(lua_State *InScriptContext);
};

namespace LuaPlayerController {
void Register(lua_State *InScriptContext);
void SetMtLink(lua_State *InScriptContext);
};

namespace LuaAIController {
void Register(lua_State *InScriptContext);
void SetMtLink(lua_State *InScriptContext);
};

namespace LuaBiologicalMineController {
void Register(lua_State *InScriptContext);
void SetMtLink(lua_State *InScriptContext);
};

namespace LuaActorComponent {
void Register(lua_State *InScriptContext);
void SetMtLink(lua_State *InScriptContext);
};

namespace LuaParticleSystemComponent {
void Register(lua_State *InScriptContext);
void SetMtLink(lua_State *InScriptContext);
};

namespace LuaParticleSystem {
void Register(lua_State *InScriptContext);
void SetMtLink(lua_State *InScriptContext);
};

namespace LuaAudioComponent {
void Register(lua_State *InScriptContext);
void SetMtLink(lua_State *InScriptContext);
};

namespace LuaSoundBase {
void Register(lua_State *InScriptContext);
void SetMtLink(lua_State *InScriptContext);
};

namespace LuaSoundCue {
void Register(lua_State *InScriptContext);
void SetMtLink(lua_State *InScriptContext);
};

namespace LuaSoundWave {
void Register(lua_State *InScriptContext);
void SetMtLink(lua_State *InScriptContext);
};

namespace LuaSoundAttenuation {
void Register(lua_State *InScriptContext);
void SetMtLink(lua_State *InScriptContext);
};

namespace LuaSoundClass {
void Register(lua_State *InScriptContext);
void SetMtLink(lua_State *InScriptContext);
};

namespace LuaSoundMix {
void Register(lua_State *InScriptContext);
void SetMtLink(lua_State *InScriptContext);
};

namespace LuaReverbEffect {
void Register(lua_State *InScriptContext);
void SetMtLink(lua_State *InScriptContext);
};

namespace LuaAzureLogTextBox {
void Register(lua_State *InScriptContext);
void SetMtLink(lua_State *InScriptContext);
};

namespace LuaFxCacheMan {
void Register(lua_State *InScriptContext);
void SetMtLink(lua_State *InScriptContext);
};

namespace LuaFxCache {
void Register(lua_State *InScriptContext);
void SetMtLink(lua_State *InScriptContext);
};

namespace LuaFxOne {
void Register(lua_State *InScriptContext);
void SetMtLink(lua_State *InScriptContext);
};

namespace LuaGamePlayer {
void Register(lua_State *InScriptContext);
void SetMtLink(lua_State *InScriptContext);
};

namespace LuaGameCharacterBase {
void Register(lua_State *InScriptContext);
void SetMtLink(lua_State *InScriptContext);
};

namespace LuaECCameraSpringArmComponent {
void Register(lua_State *InScriptContext);
void SetMtLink(lua_State *InScriptContext);
};

namespace LuaCarrierCharacterBase {
void Register(lua_State *InScriptContext);
void SetMtLink(lua_State *InScriptContext);
};

namespace LuaVehicleCharacter {
void Register(lua_State *InScriptContext);
void SetMtLink(lua_State *InScriptContext);
};

namespace LuaAnimalVehicleCharacter {
void Register(lua_State *InScriptContext);
void SetMtLink(lua_State *InScriptContext);
};

namespace LuaMotorVehicleCharacter {
void Register(lua_State *InScriptContext);
void SetMtLink(lua_State *InScriptContext);
};

namespace LuaAnimMetaOptimizeOption {
void Register(lua_State *InScriptContext);
void SetMtLink(lua_State *InScriptContext);
};

namespace LuaCarrierCharacter {
void Register(lua_State *InScriptContext);
void SetMtLink(lua_State *InScriptContext);
};

namespace LuaBiologicalMine {
void Register(lua_State *InScriptContext);
void SetMtLink(lua_State *InScriptContext);
};

namespace LuaSplineComponent {
void Register(lua_State *InScriptContext);
void SetMtLink(lua_State *InScriptContext);
};

namespace LuaSplineMeshComponent {
void Register(lua_State *InScriptContext);
void SetMtLink(lua_State *InScriptContext);
};

namespace LuaCommonBirdHover {
void Register(lua_State *InScriptContext);
void SetMtLink(lua_State *InScriptContext);
};

namespace LuaAzureEnvironmentManager {
void Register(lua_State *InScriptContext);
void SetMtLink(lua_State *InScriptContext);
};

namespace LuaBaseAnimInstance {
void Register(lua_State *InScriptContext);
void SetMtLink(lua_State *InScriptContext);
};

namespace LuaWeaponAnimInstance {
void Register(lua_State *InScriptContext);
void SetMtLink(lua_State *InScriptContext);
};

namespace LuaSpringArmComponent {
void Register(lua_State *InScriptContext);
void SetMtLink(lua_State *InScriptContext);
};

namespace LuaPlayerCameraManager {
void Register(lua_State *InScriptContext);
void SetMtLink(lua_State *InScriptContext);
};

namespace LuaController {
void Register(lua_State *InScriptContext);
void SetMtLink(lua_State *InScriptContext);
};

namespace LuaAzureRadioBox {
void Register(lua_State *InScriptContext);
void SetMtLink(lua_State *InScriptContext);
};

namespace LuaAzureButton {
void Register(lua_State *InScriptContext);
void SetMtLink(lua_State *InScriptContext);
};

namespace LuaAzureFixedList {
void Register(lua_State *InScriptContext);
void SetMtLink(lua_State *InScriptContext);
};

namespace LuaAzureScrollList {
void Register(lua_State *InScriptContext);
void SetMtLink(lua_State *InScriptContext);
};

namespace LuaAzureCompactScrollList {
void Register(lua_State *InScriptContext);
void SetMtLink(lua_State *InScriptContext);
};

namespace LuaAzureImage {
void Register(lua_State *InScriptContext);
void SetMtLink(lua_State *InScriptContext);
};

namespace LuaAzureTextBlock {
void Register(lua_State *InScriptContext);
void SetMtLink(lua_State *InScriptContext);
};

namespace LuaAzureTextBlock {
void Register(lua_State *InScriptContext);
void SetMtLink(lua_State *InScriptContext);
};

namespace LuaAzureRichTextBlock {
void Register(lua_State *InScriptContext);
void SetMtLink(lua_State *InScriptContext);
};

namespace LuaAzureProgressBar {
void Register(lua_State *InScriptContext);
void SetMtLink(lua_State *InScriptContext);
};

namespace LuaAzurePateComponent {
void Register(lua_State *InScriptContext);
void SetMtLink(lua_State *InScriptContext);
};

namespace LuaAzureMotorComponent {
void Register(lua_State *InScriptContext);
void SetMtLink(lua_State *InScriptContext);
};

namespace LuaAzureLinearMotorComponent {
void Register(lua_State *InScriptContext);
void SetMtLink(lua_State *InScriptContext);
};

namespace LuaAzureParabolicMotorComponent {
void Register(lua_State *InScriptContext);
void SetMtLink(lua_State *InScriptContext);
};

namespace LuaAzureMissileMotorComponent {
void Register(lua_State *InScriptContext);
void SetMtLink(lua_State *InScriptContext);
};

namespace LuaAzureHelixMotorComponent {
void Register(lua_State *InScriptContext);
void SetMtLink(lua_State *InScriptContext);
};

namespace LuaAzureCurvedMotorComponent {
void Register(lua_State *InScriptContext);
void SetMtLink(lua_State *InScriptContext);
};

namespace LuaAzureCircleMotorComponent {
void Register(lua_State *InScriptContext);
void SetMtLink(lua_State *InScriptContext);
};

namespace LuaComboBox {
void Register(lua_State *InScriptContext);
void SetMtLink(lua_State *InScriptContext);
};

namespace LuaScrollBox {
void Register(lua_State *InScriptContext);
void SetMtLink(lua_State *InScriptContext);
};

namespace LuaComboBoxString {
void Register(lua_State *InScriptContext);
void SetMtLink(lua_State *InScriptContext);
};

namespace LuaAzureComboBox {
void Register(lua_State *InScriptContext);
void SetMtLink(lua_State *InScriptContext);
};

namespace LuaAzureHTMLTextBlock {
void Register(lua_State *InScriptContext);
void SetMtLink(lua_State *InScriptContext);
};

namespace LuaAzureSceneImage {
void Register(lua_State *InScriptContext);
void SetMtLink(lua_State *InScriptContext);
};

namespace LuaAzureVerticalBox {
void Register(lua_State *InScriptContext);
void SetMtLink(lua_State *InScriptContext);
};

namespace LuaWidgetAnimation {
void Register(lua_State *InScriptContext);
void SetMtLink(lua_State *InScriptContext);
};

namespace LuaAzureBMText {
void Register(lua_State *InScriptContext);
void SetMtLink(lua_State *InScriptContext);
};

namespace LuaAzureBMFont {
void Register(lua_State *InScriptContext);
void SetMtLink(lua_State *InScriptContext);
};

namespace LuaSlider {
void Register(lua_State *InScriptContext);
void SetMtLink(lua_State *InScriptContext);
};

namespace LuaAzureAtlas {
void Register(lua_State *InScriptContext);
void SetMtLink(lua_State *InScriptContext);
};

namespace LuaAzureAtlasAnimation {
void Register(lua_State *InScriptContext);
void SetMtLink(lua_State *InScriptContext);
};

namespace LuaAzureScrollBox {
void Register(lua_State *InScriptContext);
void SetMtLink(lua_State *InScriptContext);
};

namespace LuaAzureViewport {
void Register(lua_State *InScriptContext);
void SetMtLink(lua_State *InScriptContext);
};

namespace LuaInvalidationBox {
void Register(lua_State *InScriptContext);
void SetMtLink(lua_State *InScriptContext);
};

namespace LuaRetainerBox {
void Register(lua_State *InScriptContext);
void SetMtLink(lua_State *InScriptContext);
};

namespace LuaAzurePolygonImage {
void Register(lua_State *InScriptContext);
void SetMtLink(lua_State *InScriptContext);
};

namespace LuaAzureBarChart {
void Register(lua_State *InScriptContext);
void SetMtLink(lua_State *InScriptContext);
};

namespace LuaGameViewportClient {
void Register(lua_State *InScriptContext);
void SetMtLink(lua_State *InScriptContext);
};

namespace LuaAzureGameViewportClient {
void Register(lua_State *InScriptContext);
void SetMtLink(lua_State *InScriptContext);
};

namespace LuaAzureLinkMotorComponent {
void Register(lua_State *InScriptContext);
void SetMtLink(lua_State *InScriptContext);
};

namespace LuaAzureInfiniteList {
void Register(lua_State *InScriptContext);
void SetMtLink(lua_State *InScriptContext);
};

namespace LuaAzureSplitScrollList {
void Register(lua_State *InScriptContext);
void SetMtLink(lua_State *InScriptContext);
};

namespace LuaGameUserSettings {
void Register(lua_State *InScriptContext);
void SetMtLink(lua_State *InScriptContext);
};

namespace LuaAkGameplayStatics {
void Register(lua_State *InScriptContext);
void SetMtLink(lua_State *InScriptContext);
};

namespace LuaAkComponent {
void Register(lua_State *InScriptContext);
void SetMtLink(lua_State *InScriptContext);
};

namespace LuaWheeledVehicleCharacter {
void Register(lua_State *InScriptContext);
void SetMtLink(lua_State *InScriptContext);
};

namespace LuaWheeledVehicleMovementComponent {
void Register(lua_State *InScriptContext);
void SetMtLink(lua_State *InScriptContext);
};

namespace LuaAzureFreeScrollBox {
void Register(lua_State *InScriptContext);
void SetMtLink(lua_State *InScriptContext);
};

namespace LuaAzurePosition3DPanel {
void Register(lua_State *InScriptContext);
void SetMtLink(lua_State *InScriptContext);
};

namespace LuaLevelScriptActor {
void Register(lua_State *InScriptContext);
void SetMtLink(lua_State *InScriptContext);
};

namespace LuaRefLevelScriptBase {
void Register(lua_State *InScriptContext);
void SetMtLink(lua_State *InScriptContext);
};

namespace LuaMyDMeshActor {
void Register(lua_State *InScriptContext);
void SetMtLink(lua_State *InScriptContext);
};

namespace LuaCurveBase {
void Register(lua_State *InScriptContext);
void SetMtLink(lua_State *InScriptContext);
};

namespace LuaCurveFloat {
void Register(lua_State *InScriptContext);
void SetMtLink(lua_State *InScriptContext);
};

namespace LuaUIParticle {
void Register(lua_State *InScriptContext);
void SetMtLink(lua_State *InScriptContext);
};

namespace LuaUIParticleEmitter {
void Register(lua_State *InScriptContext);
void SetMtLink(lua_State *InScriptContext);
};

namespace LuaUIParticleEmitterAsset {
void Register(lua_State *InScriptContext);
void SetMtLink(lua_State *InScriptContext);
};

namespace LuaMaterialFxPlayerComponent {
void Register(lua_State *InScriptContext);
void SetMtLink(lua_State *InScriptContext);
};

namespace LuaAzureTargetLockComponent {
void Register(lua_State *InScriptContext);
void SetMtLink(lua_State *InScriptContext);
};

namespace LuaGridSlot {
void Register(lua_State *InScriptContext);
void SetMtLink(lua_State *InScriptContext);
};

namespace LuaGridPanel {
void Register(lua_State *InScriptContext);
void SetMtLink(lua_State *InScriptContext);
};

namespace LuaMediaPlayer {
void Register(lua_State *InScriptContext);
void SetMtLink(lua_State *InScriptContext);
};

namespace LuaMediaPlaylist {
void Register(lua_State *InScriptContext);
void SetMtLink(lua_State *InScriptContext);
};

namespace LuaMediaSource {
void Register(lua_State *InScriptContext);
void SetMtLink(lua_State *InScriptContext);
};

namespace LuaMediaTexture {
void Register(lua_State *InScriptContext);
void SetMtLink(lua_State *InScriptContext);
};

namespace LuaMediaSoundComponent {
void Register(lua_State *InScriptContext);
void SetMtLink(lua_State *InScriptContext);
};

namespace LuaOVRLipSyncPlaybackActorComponent {
void Register(lua_State *InScriptContext);
void SetMtLink(lua_State *InScriptContext);
};

namespace LuaAttachableCable {
void Register(lua_State *InScriptContext);
void SetMtLink(lua_State *InScriptContext);
};

namespace LuaSkillRopeComponent {
void Register(lua_State *InScriptContext);
void SetMtLink(lua_State *InScriptContext);
};

namespace LuaAzureGlobalCamera {
void Register(lua_State *InScriptContext);
void SetMtLink(lua_State *InScriptContext);
};

namespace LuaLinkingEffect {
void Register(lua_State *InScriptContext);
void SetMtLink(lua_State *InScriptContext);
};

namespace LuaParabolaEffect {
void Register(lua_State *InScriptContext);
void SetMtLink(lua_State *InScriptContext);
};

namespace LuaGrassMower {
void Register(lua_State *InScriptContext);
void SetMtLink(lua_State *InScriptContext);
};

namespace LuaSkeletalMeshActor {
void Register(lua_State *InScriptContext);
void SetMtLink(lua_State *InScriptContext);
};

namespace LuaTextAsset {
void Register(lua_State *InScriptContext);
void SetMtLink(lua_State *InScriptContext);
};

namespace LuaPlantMine {
void Register(lua_State *InScriptContext);
void SetMtLink(lua_State *InScriptContext);
};

namespace LuaCustomCharacterTexture {
void Register(lua_State *InScriptContext);
void SetMtLink(lua_State *InScriptContext);
};

namespace LuaCableComponent {
void Register(lua_State *InScriptContext);
void SetMtLink(lua_State *InScriptContext);
};

namespace LuaCableActor {
void Register(lua_State *InScriptContext);
void SetMtLink(lua_State *InScriptContext);
};

namespace LuaCameraShake {
void Register(lua_State *InScriptContext);
void SetMtLink(lua_State *InScriptContext);
};

namespace LuaWaterWaveActor {
void Register(lua_State *InScriptContext);
void SetMtLink(lua_State *InScriptContext);
};

namespace LuaAzureHIMeshActor {
void Register(lua_State *InScriptContext);
void SetMtLink(lua_State *InScriptContext);
};

namespace LuaAzureStaticMeshActor {
void Register(lua_State *InScriptContext);
void SetMtLink(lua_State *InScriptContext);
};

namespace LuaAzureHomeUtilActor {
void Register(lua_State *InScriptContext);
void SetMtLink(lua_State *InScriptContext);
};

namespace LuaAzureProceduralMeshActor {
void Register(lua_State *InScriptContext);
void SetMtLink(lua_State *InScriptContext);
};

namespace LuaAzureDrawLineActor {
void Register(lua_State *InScriptContext);
void SetMtLink(lua_State *InScriptContext);
};

namespace LuaAzureHomeWallArrowComponent {
void Register(lua_State *InScriptContext);
void SetMtLink(lua_State *InScriptContext);
};

namespace LuaParticleSystemWidget {
void Register(lua_State *InScriptContext);
void SetMtLink(lua_State *InScriptContext);
};

namespace LuaSceneCaptureComponent {
void Register(lua_State *InScriptContext);
void SetMtLink(lua_State *InScriptContext);
};

namespace LuaSceneCaptureComponent2D {
void Register(lua_State *InScriptContext);
void SetMtLink(lua_State *InScriptContext);
};

namespace LuaSceneCapture2D {
void Register(lua_State *InScriptContext);
void SetMtLink(lua_State *InScriptContext);
};

namespace LuaAzureTextureReadback {
void Register(lua_State *InScriptContext);
void SetMtLink(lua_State *InScriptContext);
};

namespace LuaEmitter {
void Register(lua_State *InScriptContext);
void SetMtLink(lua_State *InScriptContext);
};

namespace LuaCullDistanceVolume {
void Register(lua_State *InScriptContext);
void SetMtLink(lua_State *InScriptContext);
};

namespace LuaExponentialHeightFog {
void Register(lua_State *InScriptContext);
void SetMtLink(lua_State *InScriptContext);
};

namespace LuaReflectionCapture {
void Register(lua_State *InScriptContext);
void SetMtLink(lua_State *InScriptContext);
};

namespace LuaDynamicTextureHelper {
void Register(lua_State *InScriptContext);
void SetMtLink(lua_State *InScriptContext);
};

namespace LuaBlueprintPlatformLibrary {
void Register(lua_State *InScriptContext);
void SetMtLink(lua_State *InScriptContext);
};

namespace LuaKeepCloseToGroundComponent {
void Register(lua_State *InScriptContext);
void SetMtLink(lua_State *InScriptContext);
};

namespace LuaTouchInterface {
void Register(lua_State *InScriptContext);
void SetMtLink(lua_State *InScriptContext);
};

namespace LuaWebBrowser {
void Register(lua_State *InScriptContext);
void SetMtLink(lua_State *InScriptContext);
};

namespace LuaRecastNavMesh {
void Register(lua_State *InScriptContext);
void SetMtLink(lua_State *InScriptContext);
};

namespace LuaNavigationData {
void Register(lua_State *InScriptContext);
void SetMtLink(lua_State *InScriptContext);
};

namespace LuaAzureSlateFontMappingBlueprintLibrary {
void Register(lua_State *InScriptContext);
void SetMtLink(lua_State *InScriptContext);
};

namespace LuaNavigationSystemV1 {
void Register(lua_State *InScriptContext);
void SetMtLink(lua_State *InScriptContext);
};

namespace LuaNavigationPath {
void Register(lua_State *InScriptContext);
void SetMtLink(lua_State *InScriptContext);
};

namespace LuaNavigationPath {
void Register(lua_State *InScriptContext);
void SetMtLink(lua_State *InScriptContext);
};

namespace LuaNavRelevantComponent {
void Register(lua_State *InScriptContext);
void SetMtLink(lua_State *InScriptContext);
};

namespace LuaNavModifierComponent {
void Register(lua_State *InScriptContext);
void SetMtLink(lua_State *InScriptContext);
};
