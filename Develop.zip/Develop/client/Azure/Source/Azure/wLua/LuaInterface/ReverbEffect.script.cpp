#include "Azure.h"
#include "Utility/help_funcs.h"
#include "wLua/UObjectHeaders.h"
#include "Sound/ReverbEffect.h"
#include "AzureLuaIntegration.h"

namespace LuaReverbEffect
{
int32 Get_Density(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ReverbEffect",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ReverbEffect must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UReverbEffect::StaticClass(), TEXT("Density"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_Density(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ReverbEffect",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ReverbEffect must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UReverbEffect::StaticClass(), TEXT("Density"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_Diffusion(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ReverbEffect",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ReverbEffect must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UReverbEffect::StaticClass(), TEXT("Diffusion"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_Diffusion(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ReverbEffect",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ReverbEffect must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UReverbEffect::StaticClass(), TEXT("Diffusion"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_Gain(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ReverbEffect",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ReverbEffect must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UReverbEffect::StaticClass(), TEXT("Gain"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_Gain(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ReverbEffect",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ReverbEffect must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UReverbEffect::StaticClass(), TEXT("Gain"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_GainHF(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ReverbEffect",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ReverbEffect must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UReverbEffect::StaticClass(), TEXT("GainHF"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_GainHF(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ReverbEffect",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ReverbEffect must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UReverbEffect::StaticClass(), TEXT("GainHF"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_DecayTime(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ReverbEffect",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ReverbEffect must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UReverbEffect::StaticClass(), TEXT("DecayTime"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_DecayTime(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ReverbEffect",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ReverbEffect must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UReverbEffect::StaticClass(), TEXT("DecayTime"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_DecayHFRatio(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ReverbEffect",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ReverbEffect must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UReverbEffect::StaticClass(), TEXT("DecayHFRatio"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_DecayHFRatio(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ReverbEffect",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ReverbEffect must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UReverbEffect::StaticClass(), TEXT("DecayHFRatio"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_ReflectionsGain(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ReverbEffect",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ReverbEffect must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UReverbEffect::StaticClass(), TEXT("ReflectionsGain"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_ReflectionsGain(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ReverbEffect",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ReverbEffect must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UReverbEffect::StaticClass(), TEXT("ReflectionsGain"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_ReflectionsDelay(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ReverbEffect",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ReverbEffect must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UReverbEffect::StaticClass(), TEXT("ReflectionsDelay"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_ReflectionsDelay(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ReverbEffect",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ReverbEffect must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UReverbEffect::StaticClass(), TEXT("ReflectionsDelay"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_LateGain(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ReverbEffect",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ReverbEffect must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UReverbEffect::StaticClass(), TEXT("LateGain"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_LateGain(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ReverbEffect",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ReverbEffect must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UReverbEffect::StaticClass(), TEXT("LateGain"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_LateDelay(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ReverbEffect",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ReverbEffect must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UReverbEffect::StaticClass(), TEXT("LateDelay"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_LateDelay(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ReverbEffect",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ReverbEffect must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UReverbEffect::StaticClass(), TEXT("LateDelay"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_AirAbsorptionGainHF(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ReverbEffect",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ReverbEffect must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UReverbEffect::StaticClass(), TEXT("AirAbsorptionGainHF"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_AirAbsorptionGainHF(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ReverbEffect",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ReverbEffect must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UReverbEffect::StaticClass(), TEXT("AirAbsorptionGainHF"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_RoomRolloffFactor(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ReverbEffect",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ReverbEffect must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UReverbEffect::StaticClass(), TEXT("RoomRolloffFactor"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_RoomRolloffFactor(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ReverbEffect",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ReverbEffect must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UReverbEffect::StaticClass(), TEXT("RoomRolloffFactor"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 New(lua_State* InScriptContext)
{
	UObject* Outer = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Object");
	FName Name = FName(luaL_checkstring(InScriptContext, 2));
	UObject* Obj = NewObject<UReverbEffect>(Outer, Name);
	wLua::FLuaUtils::ReturnUObject(InScriptContext,Obj);
	return 1;
}

int32 Destroy(lua_State* InScriptContext)
{
	return 0;
}

int32 Class(lua_State* InScriptContext)
{
	UClass* Class = UReverbEffect::StaticClass();
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Class);
	return 1;
}

const luaL_Reg Lib_Funcs[] =
{
	{ "New", New },
	{ "Destroy", Destroy },
	{ "Class", Class },
	{ "Get_Density", Get_Density },
	{ "Set_Density", Set_Density },
	{ "Get_Diffusion", Get_Diffusion },
	{ "Set_Diffusion", Set_Diffusion },
	{ "Get_Gain", Get_Gain },
	{ "Set_Gain", Set_Gain },
	{ "Get_GainHF", Get_GainHF },
	{ "Set_GainHF", Set_GainHF },
	{ "Get_DecayTime", Get_DecayTime },
	{ "Set_DecayTime", Set_DecayTime },
	{ "Get_DecayHFRatio", Get_DecayHFRatio },
	{ "Set_DecayHFRatio", Set_DecayHFRatio },
	{ "Get_ReflectionsGain", Get_ReflectionsGain },
	{ "Set_ReflectionsGain", Set_ReflectionsGain },
	{ "Get_ReflectionsDelay", Get_ReflectionsDelay },
	{ "Set_ReflectionsDelay", Set_ReflectionsDelay },
	{ "Get_LateGain", Get_LateGain },
	{ "Set_LateGain", Set_LateGain },
	{ "Get_LateDelay", Get_LateDelay },
	{ "Set_LateDelay", Set_LateDelay },
	{ "Get_AirAbsorptionGainHF", Get_AirAbsorptionGainHF },
	{ "Set_AirAbsorptionGainHF", Set_AirAbsorptionGainHF },
	{ "Get_RoomRolloffFactor", Get_RoomRolloffFactor },
	{ "Set_RoomRolloffFactor", Set_RoomRolloffFactor },
	{ "is_nil", wLua::LuaStatic::isnil },
	{ "__gc", wLua::LuaStatic::removeUClassFrameCache },
	{ NULL, NULL }
};

void Register(lua_State *InScriptContext)
{
	lua_newtable(InScriptContext);
	luaL_register(InScriptContext, NULL, Lib_Funcs);
	AzureHelpFuncs::AuxRegister(InScriptContext, "ReverbEffect");
}
void SetMtLink(lua_State *InScriptContext)
{
	AzureHelpFuncs::AuxSetMtLink(InScriptContext, "ReverbEffect", "Object",USERDATATYPE_UOBJECT);
}

}