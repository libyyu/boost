#include "Azure.h"
#include "Utility/help_funcs.h"
#include "wLua/UObjectHeaders.h"
#include "GameLogic/Player/AnimalVehicleCharacter.h"
#include "../UClassHeaders.h"
#include "AzureLuaIntegration.h"

namespace LuaAnimalVehicleCharacter
{
int32 SetMovePhaseMaxSpeed(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AnimalVehicleCharacter",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AnimalVehicleCharacter must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		VehicleMovePhase newPhase;
		float speed;
	} Params;
	Params.newPhase = (VehicleMovePhase)(luaL_checkint(InScriptContext, 2));
	Params.speed = (float)(luaL_checknumber(InScriptContext, 3));
#if UE_GAME
	AAnimalVehicleCharacter * This = (AAnimalVehicleCharacter *)Obj;
	This->SetMovePhaseMaxSpeed(Params.newPhase,Params.speed);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetMovePhaseMaxSpeed"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(VehicleMovePhase*)(params.GetStructMemory() + 0) = Params.newPhase;
		*(float*)(params.GetStructMemory() + 4) = Params.speed;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.newPhase = *(VehicleMovePhase*)(params.GetStructMemory() + 0);
		Params.speed = *(float*)(params.GetStructMemory() + 4);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 Get_rmYawSpeedCurveName(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AnimalVehicleCharacter",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AnimalVehicleCharacter must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAnimalVehicleCharacter::StaticClass(), TEXT("rmYawSpeedCurveName"));
	if(!Property) { check(false); return 0;}
	FName PropertyValue = FName();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushstring(InScriptContext, TCHAR_TO_UTF8(*PropertyValue.ToString()));
	return 1;
}

int32 Set_rmYawSpeedCurveName(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AnimalVehicleCharacter",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AnimalVehicleCharacter must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAnimalVehicleCharacter::StaticClass(), TEXT("rmYawSpeedCurveName"));
	if(!Property) { check(false); return 0;}
	FName PropertyValue = FName(UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 2)));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_rmSpeedCurveName(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AnimalVehicleCharacter",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AnimalVehicleCharacter must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAnimalVehicleCharacter::StaticClass(), TEXT("rmSpeedCurveName"));
	if(!Property) { check(false); return 0;}
	FName PropertyValue = FName();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushstring(InScriptContext, TCHAR_TO_UTF8(*PropertyValue.ToString()));
	return 1;
}

int32 Set_rmSpeedCurveName(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AnimalVehicleCharacter",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AnimalVehicleCharacter must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAnimalVehicleCharacter::StaticClass(), TEXT("rmSpeedCurveName"));
	if(!Property) { check(false); return 0;}
	FName PropertyValue = FName(UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 2)));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_minRotationSpeedThreshold(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AnimalVehicleCharacter",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AnimalVehicleCharacter must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAnimalVehicleCharacter::StaticClass(), TEXT("minRotationSpeedThreshold"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_minRotationSpeedThreshold(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AnimalVehicleCharacter",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AnimalVehicleCharacter must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAnimalVehicleCharacter::StaticClass(), TEXT("minRotationSpeedThreshold"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_defaultRotationSpeed(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AnimalVehicleCharacter",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AnimalVehicleCharacter must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAnimalVehicleCharacter::StaticClass(), TEXT("defaultRotationSpeed"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_defaultRotationSpeed(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AnimalVehicleCharacter",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AnimalVehicleCharacter must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAnimalVehicleCharacter::StaticClass(), TEXT("defaultRotationSpeed"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_fixedRotationSpeed(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AnimalVehicleCharacter",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AnimalVehicleCharacter must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAnimalVehicleCharacter::StaticClass(), TEXT("fixedRotationSpeed"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_fixedRotationSpeed(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AnimalVehicleCharacter",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AnimalVehicleCharacter must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAnimalVehicleCharacter::StaticClass(), TEXT("fixedRotationSpeed"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_noramlizeDiffAngle2RotationSpeedCurve(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AnimalVehicleCharacter",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AnimalVehicleCharacter must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAnimalVehicleCharacter::StaticClass(), TEXT("noramlizeDiffAngle2RotationSpeedCurve"));
	if(!Property) { check(false); return 0;}
	UCurveFloat* PropertyValue;
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaUtils::ReturnUObject(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_noramlizeDiffAngle2RotationSpeedCurve(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AnimalVehicleCharacter",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AnimalVehicleCharacter must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAnimalVehicleCharacter::StaticClass(), TEXT("noramlizeDiffAngle2RotationSpeedCurve"));
	if(!Property) { check(false); return 0;}
	UCurveFloat* PropertyValue = (UCurveFloat*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"CurveFloat");;
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_logicMaxAcceleration(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AnimalVehicleCharacter",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AnimalVehicleCharacter must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAnimalVehicleCharacter::StaticClass(), TEXT("logicMaxAcceleration"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_logicMaxAcceleration(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AnimalVehicleCharacter",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AnimalVehicleCharacter must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAnimalVehicleCharacter::StaticClass(), TEXT("logicMaxAcceleration"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_maxAccelerationInRm(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AnimalVehicleCharacter",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AnimalVehicleCharacter must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAnimalVehicleCharacter::StaticClass(), TEXT("maxAccelerationInRm"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_maxAccelerationInRm(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AnimalVehicleCharacter",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AnimalVehicleCharacter must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAnimalVehicleCharacter::StaticClass(), TEXT("maxAccelerationInRm"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_OnlyTurnSpeedThreshold(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AnimalVehicleCharacter",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AnimalVehicleCharacter must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAnimalVehicleCharacter::StaticClass(), TEXT("OnlyTurnSpeedThreshold"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_OnlyTurnSpeedThreshold(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AnimalVehicleCharacter",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AnimalVehicleCharacter must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAnimalVehicleCharacter::StaticClass(), TEXT("OnlyTurnSpeedThreshold"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_OnlyTurnYawThreshold(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AnimalVehicleCharacter",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AnimalVehicleCharacter must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAnimalVehicleCharacter::StaticClass(), TEXT("OnlyTurnYawThreshold"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_OnlyTurnYawThreshold(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AnimalVehicleCharacter",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AnimalVehicleCharacter must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAnimalVehicleCharacter::StaticClass(), TEXT("OnlyTurnYawThreshold"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_OnlyTurnQuitYawThreshold(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AnimalVehicleCharacter",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AnimalVehicleCharacter must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAnimalVehicleCharacter::StaticClass(), TEXT("OnlyTurnQuitYawThreshold"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_OnlyTurnQuitYawThreshold(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AnimalVehicleCharacter",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AnimalVehicleCharacter must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAnimalVehicleCharacter::StaticClass(), TEXT("OnlyTurnQuitYawThreshold"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 New(lua_State* InScriptContext)
{
	UObject* Outer = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Object");
	FName Name = FName(luaL_checkstring(InScriptContext, 2));
	UObject* Obj = NewObject<AAnimalVehicleCharacter>(Outer, Name);
	wLua::FLuaUtils::ReturnUObject(InScriptContext,Obj);
	return 1;
}

int32 Destroy(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AnimalVehicleCharacter",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AnimalVehicleCharacter must be non-null"); lua_error(InScriptContext);  return 0;}
		AActor * actor = Cast<AActor>(Obj);
		actor->Destroy();
		userdata->flag |= wLua::LuaObjectFlag::DESTROYED;
		wLua::FLuaUtils::RemoveObjectReference(Obj, userdata->stamp, InScriptContext);
#ifdef AZURE_BUILD_WLUACHECK
		UE_LOG(LogAzure, Warning, TEXT("Destroy AnimalVehicleCharacter: %x userdata:%x   stamp:%x"),Obj,userdata,userdata->stamp);
#endif
	return 0;
}

int32 Class(lua_State* InScriptContext)
{
	UClass* Class = AAnimalVehicleCharacter::StaticClass();
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Class);
	return 1;
}

const luaL_Reg Lib_Funcs[] =
{
	{ "New", New },
	{ "Destroy", Destroy },
	{ "Class", Class },
	{ "SetMovePhaseMaxSpeed", SetMovePhaseMaxSpeed },
	{ "Get_rmYawSpeedCurveName", Get_rmYawSpeedCurveName },
	{ "Set_rmYawSpeedCurveName", Set_rmYawSpeedCurveName },
	{ "Get_rmSpeedCurveName", Get_rmSpeedCurveName },
	{ "Set_rmSpeedCurveName", Set_rmSpeedCurveName },
	{ "Get_minRotationSpeedThreshold", Get_minRotationSpeedThreshold },
	{ "Set_minRotationSpeedThreshold", Set_minRotationSpeedThreshold },
	{ "Get_defaultRotationSpeed", Get_defaultRotationSpeed },
	{ "Set_defaultRotationSpeed", Set_defaultRotationSpeed },
	{ "Get_fixedRotationSpeed", Get_fixedRotationSpeed },
	{ "Set_fixedRotationSpeed", Set_fixedRotationSpeed },
	{ "Get_noramlizeDiffAngle2RotationSpeedCurve", Get_noramlizeDiffAngle2RotationSpeedCurve },
	{ "Set_noramlizeDiffAngle2RotationSpeedCurve", Set_noramlizeDiffAngle2RotationSpeedCurve },
	{ "Get_logicMaxAcceleration", Get_logicMaxAcceleration },
	{ "Set_logicMaxAcceleration", Set_logicMaxAcceleration },
	{ "Get_maxAccelerationInRm", Get_maxAccelerationInRm },
	{ "Set_maxAccelerationInRm", Set_maxAccelerationInRm },
	{ "Get_OnlyTurnSpeedThreshold", Get_OnlyTurnSpeedThreshold },
	{ "Set_OnlyTurnSpeedThreshold", Set_OnlyTurnSpeedThreshold },
	{ "Get_OnlyTurnYawThreshold", Get_OnlyTurnYawThreshold },
	{ "Set_OnlyTurnYawThreshold", Set_OnlyTurnYawThreshold },
	{ "Get_OnlyTurnQuitYawThreshold", Get_OnlyTurnQuitYawThreshold },
	{ "Set_OnlyTurnQuitYawThreshold", Set_OnlyTurnQuitYawThreshold },
	{ "is_nil", wLua::LuaStatic::isnil },
	{ "__gc", wLua::LuaStatic::removeUClassFrameCache },
	{ NULL, NULL }
};

void Register(lua_State *InScriptContext)
{
	lua_newtable(InScriptContext);
	luaL_register(InScriptContext, NULL, Lib_Funcs);
	AzureHelpFuncs::AuxRegister(InScriptContext, "AnimalVehicleCharacter");
}
void SetMtLink(lua_State *InScriptContext)
{
	AzureHelpFuncs::AuxSetMtLink(InScriptContext, "AnimalVehicleCharacter", "VehicleCharacter",USERDATATYPE_UOBJECT);
}

}