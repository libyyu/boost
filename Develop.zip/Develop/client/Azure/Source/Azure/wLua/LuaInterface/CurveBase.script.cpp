#include "Azure.h"
#include "Utility/help_funcs.h"
#include "wLua/UObjectHeaders.h"
#include "Curves/CurveBase.h"
#include "AzureLuaIntegration.h"

namespace LuaCurveBase
{
int32 GetValueRange(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CurveBase",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CurveBase must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float MinValue;
		float MaxValue;
	} Params;
#if UE_GAME
	UCurveBase * This = (UCurveBase *)Obj;
	This->GetValueRange(Params.MinValue,Params.MaxValue);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetValueRange"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.MinValue = *(float*)(params.GetStructMemory() + 0);
		Params.MaxValue = *(float*)(params.GetStructMemory() + 4);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushnumber(InScriptContext, Params.MinValue);
	lua_pushnumber(InScriptContext, Params.MaxValue);
	return 2;
}

int32 GetTimeRange(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CurveBase",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CurveBase must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float MinTime;
		float MaxTime;
	} Params;
#if UE_GAME
	UCurveBase * This = (UCurveBase *)Obj;
	This->GetTimeRange(Params.MinTime,Params.MaxTime);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetTimeRange"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.MinTime = *(float*)(params.GetStructMemory() + 0);
		Params.MaxTime = *(float*)(params.GetStructMemory() + 4);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushnumber(InScriptContext, Params.MinTime);
	lua_pushnumber(InScriptContext, Params.MaxTime);
	return 2;
}

int32 Get_AssetImportData(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CurveBase",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CurveBase must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UCurveBase::StaticClass(), TEXT("AssetImportData"));
	if(!Property) { check(false); return 0;}
	UAssetImportData* PropertyValue;
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaUtils::ReturnUObject(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_AssetImportData(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CurveBase",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CurveBase must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UCurveBase::StaticClass(), TEXT("AssetImportData"));
	if(!Property) { check(false); return 0;}
	UAssetImportData* PropertyValue = (UAssetImportData*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"AssetImportData");;
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Class(lua_State* InScriptContext)
{
	UClass* Class = UCurveBase::StaticClass();
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Class);
	return 1;
}

const luaL_Reg Lib_Funcs[] =
{
	{ "Class", Class },
	{ "GetValueRange", GetValueRange },
	{ "GetTimeRange", GetTimeRange },
	{ "Get_AssetImportData", Get_AssetImportData },
	{ "Set_AssetImportData", Set_AssetImportData },
	{ "is_nil", wLua::LuaStatic::isnil },
	{ "__gc", wLua::LuaStatic::removeUClassFrameCache },
	{ NULL, NULL }
};

void Register(lua_State *InScriptContext)
{
	lua_newtable(InScriptContext);
	luaL_register(InScriptContext, NULL, Lib_Funcs);
	AzureHelpFuncs::AuxRegister(InScriptContext, "CurveBase");
}
void SetMtLink(lua_State *InScriptContext)
{
	AzureHelpFuncs::AuxSetMtLink(InScriptContext, "CurveBase", "Object",USERDATATYPE_UOBJECT);
}

}