#include "Azure.h"
#include "Utility/help_funcs.h"
#include "wLua/UObjectHeaders.h"
#include "AzureProgressBar.h"
#include "AzureLuaIntegration.h"

namespace LuaAzureProgressBar
{
int32 AutoProgress(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureProgressBar",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureProgressBar must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool aut0;
		float start;
		float end;
		float time;
	} Params;
	Params.aut0 = !!(lua_toboolean(InScriptContext, 2));
	Params.start = (float)(luaL_checknumber(InScriptContext, 3));
	Params.end = (float)(luaL_checknumber(InScriptContext, 4));
	Params.time = (float)(luaL_checknumber(InScriptContext, 5));
#if UE_GAME
	UAzureProgressBar * This = (UAzureProgressBar *)Obj;
	This->AutoProgress(Params.aut0,Params.start,Params.end,Params.time);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("AutoProgress"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(bool*)(params.GetStructMemory() + 0) = Params.aut0;
		*(float*)(params.GetStructMemory() + 4) = Params.start;
		*(float*)(params.GetStructMemory() + 8) = Params.end;
		*(float*)(params.GetStructMemory() + 12) = Params.time;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.aut0 = *(bool*)(params.GetStructMemory() + 0);
		Params.start = *(float*)(params.GetStructMemory() + 4);
		Params.end = *(float*)(params.GetStructMemory() + 8);
		Params.time = *(float*)(params.GetStructMemory() + 12);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 AutoAdd(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureProgressBar",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureProgressBar must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float addspeed;
	} Params;
	Params.addspeed = (float)(luaL_checknumber(InScriptContext, 2));
#if UE_GAME
	UAzureProgressBar * This = (UAzureProgressBar *)Obj;
	This->AutoAdd(Params.addspeed);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("AutoAdd"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(float*)(params.GetStructMemory() + 0) = Params.addspeed;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.addspeed = *(float*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 Get_ThumbImageAlignment(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureProgressBar",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureProgressBar must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzureProgressBar::StaticClass(), TEXT("ThumbImageAlignment"));
	if(!Property) { check(false); return 0;}
	FVector2D PropertyValue = FVector2D();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaVector2D::Return(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_ThumbImageUnderAlignment(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureProgressBar",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureProgressBar must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzureProgressBar::StaticClass(), TEXT("ThumbImageUnderAlignment"));
	if(!Property) { check(false); return 0;}
	FVector2D PropertyValue = FVector2D();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaVector2D::Return(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_bNotClipped(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureProgressBar",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureProgressBar must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzureProgressBar::StaticClass(), TEXT("bNotClipped"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = bool();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_ThumbWidgetName(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureProgressBar",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureProgressBar must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzureProgressBar::StaticClass(), TEXT("ThumbWidgetName"));
	if(!Property) { check(false); return 0;}
	FName PropertyValue = FName();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushstring(InScriptContext, TCHAR_TO_UTF8(*PropertyValue.ToString()));
	return 1;
}

int32 New(lua_State* InScriptContext)
{
	UObject* Outer = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Object");
	FName Name = FName(luaL_checkstring(InScriptContext, 2));
	UObject* Obj = NewObject<UAzureProgressBar>(Outer, Name);
	wLua::FLuaUtils::ReturnUObject(InScriptContext,Obj);
	return 1;
}

int32 Destroy(lua_State* InScriptContext)
{
	return 0;
}

int32 Class(lua_State* InScriptContext)
{
	UClass* Class = UAzureProgressBar::StaticClass();
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Class);
	return 1;
}

const luaL_Reg Lib_Funcs[] =
{
	{ "New", New },
	{ "Destroy", Destroy },
	{ "Class", Class },
	{ "AutoProgress", AutoProgress },
	{ "AutoAdd", AutoAdd },
	{ "Get_ThumbImageAlignment", Get_ThumbImageAlignment },
	{ "Get_ThumbImageUnderAlignment", Get_ThumbImageUnderAlignment },
	{ "Get_bNotClipped", Get_bNotClipped },
	{ "Get_ThumbWidgetName", Get_ThumbWidgetName },
	{ "is_nil", wLua::LuaStatic::isnil },
	{ "__gc", wLua::LuaStatic::removeUClassFrameCache },
	{ NULL, NULL }
};

void Register(lua_State *InScriptContext)
{
	lua_newtable(InScriptContext);
	luaL_register(InScriptContext, NULL, Lib_Funcs);
	AzureHelpFuncs::AuxRegister(InScriptContext, "AzureProgressBar");
}
void SetMtLink(lua_State *InScriptContext)
{
	AzureHelpFuncs::AuxSetMtLink(InScriptContext, "AzureProgressBar", "ProgressBar",USERDATATYPE_UOBJECT);
}

}