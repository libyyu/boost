#include "Azure.h"
#include "Utility/help_funcs.h"
#include "wLua/UObjectHeaders.h"
#include "Components/SceneCaptureComponent.h"
#include "AzureLuaIntegration.h"

namespace LuaSceneCaptureComponent
{
int32 SetShowFlagSettings(lua_State*);
int32 AddShowFlagSetting(lua_State*);
int32 RemoveShowFlagSetting(lua_State*);
int32 UpdateShowFlags(lua_State*);

int32 ShowOnlyComponent(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SceneCaptureComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SceneCaptureComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		UPrimitiveComponent* InComponent = nullptr;
	} Params;
	Params.InComponent = (UPrimitiveComponent*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"PrimitiveComponent");;
#if UE_GAME
	USceneCaptureComponent * This = (USceneCaptureComponent *)Obj;
	This->ShowOnlyComponent(Params.InComponent);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("ShowOnlyComponent"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(UPrimitiveComponent**)(params.GetStructMemory() + 0) = Params.InComponent;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.InComponent = *(UPrimitiveComponent**)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 ShowOnlyActorComponents(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SceneCaptureComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SceneCaptureComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		AActor* InActor = nullptr;
	} Params;
	Params.InActor = (AActor*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"Actor");;
#if UE_GAME
	USceneCaptureComponent * This = (USceneCaptureComponent *)Obj;
	This->ShowOnlyActorComponents(Params.InActor);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("ShowOnlyActorComponents"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(AActor**)(params.GetStructMemory() + 0) = Params.InActor;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.InActor = *(AActor**)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetCaptureSortPriority(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SceneCaptureComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SceneCaptureComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		int32 NewCaptureSortPriority;
	} Params;
	Params.NewCaptureSortPriority = (luaL_checkint(InScriptContext, 2));
#if UE_GAME
	USceneCaptureComponent * This = (USceneCaptureComponent *)Obj;
	This->SetCaptureSortPriority(Params.NewCaptureSortPriority);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetCaptureSortPriority"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(int32*)(params.GetStructMemory() + 0) = Params.NewCaptureSortPriority;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.NewCaptureSortPriority = *(int32*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 RemoveShowOnlyComponent(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SceneCaptureComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SceneCaptureComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		UPrimitiveComponent* InComponent = nullptr;
	} Params;
	Params.InComponent = (UPrimitiveComponent*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"PrimitiveComponent");;
#if UE_GAME
	USceneCaptureComponent * This = (USceneCaptureComponent *)Obj;
	This->RemoveShowOnlyComponent(Params.InComponent);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("RemoveShowOnlyComponent"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(UPrimitiveComponent**)(params.GetStructMemory() + 0) = Params.InComponent;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.InComponent = *(UPrimitiveComponent**)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 RemoveShowOnlyActorComponents(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SceneCaptureComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SceneCaptureComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		AActor* InActor = nullptr;
	} Params;
	Params.InActor = (AActor*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"Actor");;
#if UE_GAME
	USceneCaptureComponent * This = (USceneCaptureComponent *)Obj;
	This->RemoveShowOnlyActorComponents(Params.InActor);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("RemoveShowOnlyActorComponents"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(AActor**)(params.GetStructMemory() + 0) = Params.InActor;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.InActor = *(AActor**)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 HideComponent(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SceneCaptureComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SceneCaptureComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		UPrimitiveComponent* InComponent = nullptr;
	} Params;
	Params.InComponent = (UPrimitiveComponent*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"PrimitiveComponent");;
#if UE_GAME
	USceneCaptureComponent * This = (USceneCaptureComponent *)Obj;
	This->HideComponent(Params.InComponent);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("HideComponent"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(UPrimitiveComponent**)(params.GetStructMemory() + 0) = Params.InComponent;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.InComponent = *(UPrimitiveComponent**)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 HideActorComponents(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SceneCaptureComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SceneCaptureComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		AActor* InActor = nullptr;
	} Params;
	Params.InActor = (AActor*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"Actor");;
#if UE_GAME
	USceneCaptureComponent * This = (USceneCaptureComponent *)Obj;
	This->HideActorComponents(Params.InActor);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("HideActorComponents"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(AActor**)(params.GetStructMemory() + 0) = Params.InActor;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.InActor = *(AActor**)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 ClearShowOnlyComponents(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SceneCaptureComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SceneCaptureComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		UPrimitiveComponent* InComponent = nullptr;
	} Params;
	Params.InComponent = (UPrimitiveComponent*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"PrimitiveComponent");;
#if UE_GAME
	USceneCaptureComponent * This = (USceneCaptureComponent *)Obj;
	This->ClearShowOnlyComponents(Params.InComponent);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("ClearShowOnlyComponents"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(UPrimitiveComponent**)(params.GetStructMemory() + 0) = Params.InComponent;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.InComponent = *(UPrimitiveComponent**)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 ClearHiddenComponents(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SceneCaptureComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SceneCaptureComponent must be non-null"); lua_error(InScriptContext);  return 0;}
#if UE_GAME
	USceneCaptureComponent * This = (USceneCaptureComponent *)Obj;
	This->ClearHiddenComponents();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("ClearHiddenComponents"));
	if(!Function) { check(false); return 0;}
	Obj->ProcessEvent(Function, NULL);
#endif
	return 0;
}

int32 Get_PrimitiveRenderMode(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SceneCaptureComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SceneCaptureComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USceneCaptureComponent::StaticClass(), TEXT("PrimitiveRenderMode"));
	if(!Property) { check(false); return 0;}
	ESceneCapturePrimitiveRenderMode PropertyValue = ESceneCapturePrimitiveRenderMode();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushinteger(InScriptContext, (int)PropertyValue);
	return 1;
}

int32 Set_PrimitiveRenderMode(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SceneCaptureComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SceneCaptureComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USceneCaptureComponent::StaticClass(), TEXT("PrimitiveRenderMode"));
	if(!Property) { check(false); return 0;}
	ESceneCapturePrimitiveRenderMode PropertyValue = (ESceneCapturePrimitiveRenderMode)(luaL_checkint(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_HiddenActors(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SceneCaptureComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SceneCaptureComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USceneCaptureComponent::StaticClass(), TEXT("HiddenActors"));
	if(!Property) { check(false); return 0;}
	TArray<AActor*> PropertyValue;
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	{lua_newtable(InScriptContext); int i = 1; for(auto It = PropertyValue.CreateConstIterator(); It; ++It,++i) {  wLua::FLuaUtils::ReturnUObject(InScriptContext, (*It)); lua_rawseti(InScriptContext,-2,i);     }  }
	return 1;
}

int32 Set_HiddenActors(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SceneCaptureComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SceneCaptureComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USceneCaptureComponent::StaticClass(), TEXT("HiddenActors"));
	if(!Property) { check(false); return 0;}
	TArray<AActor*> PropertyValue = [](lua_State * _InScriptContext){ TArray<AActor*> ret; lua_pushnil(_InScriptContext); while(lua_next(_InScriptContext,2)!=0){ AActor* item = (AActor*)wLua::FLuaUtils::GetUObject(_InScriptContext,-1,"Actor");; ret.Add(item); lua_pop(_InScriptContext,1);  } return ret; }(InScriptContext);;
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_ShowOnlyActors(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SceneCaptureComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SceneCaptureComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USceneCaptureComponent::StaticClass(), TEXT("ShowOnlyActors"));
	if(!Property) { check(false); return 0;}
	TArray<AActor*> PropertyValue;
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	{lua_newtable(InScriptContext); int i = 1; for(auto It = PropertyValue.CreateConstIterator(); It; ++It,++i) {  wLua::FLuaUtils::ReturnUObject(InScriptContext, (*It)); lua_rawseti(InScriptContext,-2,i);     }  }
	return 1;
}

int32 Set_ShowOnlyActors(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SceneCaptureComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SceneCaptureComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USceneCaptureComponent::StaticClass(), TEXT("ShowOnlyActors"));
	if(!Property) { check(false); return 0;}
	TArray<AActor*> PropertyValue = [](lua_State * _InScriptContext){ TArray<AActor*> ret; lua_pushnil(_InScriptContext); while(lua_next(_InScriptContext,2)!=0){ AActor* item = (AActor*)wLua::FLuaUtils::GetUObject(_InScriptContext,-1,"Actor");; ret.Add(item); lua_pop(_InScriptContext,1);  } return ret; }(InScriptContext);;
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bCaptureEveryFrame(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SceneCaptureComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SceneCaptureComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USceneCaptureComponent::StaticClass(), TEXT("bCaptureEveryFrame"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = bool();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bCaptureEveryFrame(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SceneCaptureComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SceneCaptureComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USceneCaptureComponent::StaticClass(), TEXT("bCaptureEveryFrame"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bCaptureOnMovement(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SceneCaptureComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SceneCaptureComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USceneCaptureComponent::StaticClass(), TEXT("bCaptureOnMovement"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = bool();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bCaptureOnMovement(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SceneCaptureComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SceneCaptureComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USceneCaptureComponent::StaticClass(), TEXT("bCaptureOnMovement"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bAlwaysPersistRenderingState(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SceneCaptureComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SceneCaptureComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USceneCaptureComponent::StaticClass(), TEXT("bAlwaysPersistRenderingState"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = bool();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bAlwaysPersistRenderingState(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SceneCaptureComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SceneCaptureComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USceneCaptureComponent::StaticClass(), TEXT("bAlwaysPersistRenderingState"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_LODDistanceFactor(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SceneCaptureComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SceneCaptureComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USceneCaptureComponent::StaticClass(), TEXT("LODDistanceFactor"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_LODDistanceFactor(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SceneCaptureComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SceneCaptureComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USceneCaptureComponent::StaticClass(), TEXT("LODDistanceFactor"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_MaxViewDistanceOverride(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SceneCaptureComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SceneCaptureComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USceneCaptureComponent::StaticClass(), TEXT("MaxViewDistanceOverride"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_MaxViewDistanceOverride(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SceneCaptureComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SceneCaptureComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USceneCaptureComponent::StaticClass(), TEXT("MaxViewDistanceOverride"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_CaptureSortPriority(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SceneCaptureComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SceneCaptureComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USceneCaptureComponent::StaticClass(), TEXT("CaptureSortPriority"));
	if(!Property) { check(false); return 0;}
	int32 PropertyValue = int32();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushinteger(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_ProfilingEventName(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SceneCaptureComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SceneCaptureComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USceneCaptureComponent::StaticClass(), TEXT("ProfilingEventName"));
	if(!Property) { check(false); return 0;}
	FString PropertyValue;
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushstring(InScriptContext, TCHAR_TO_UTF8(*PropertyValue));
	return 1;
}

int32 Set_ProfilingEventName(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SceneCaptureComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SceneCaptureComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USceneCaptureComponent::StaticClass(), TEXT("ProfilingEventName"));
	if(!Property) { check(false); return 0;}
	FString PropertyValue = UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 New(lua_State* InScriptContext)
{
	UObject* Outer = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Object");
	FName Name = FName(luaL_checkstring(InScriptContext, 2));
	UObject* Obj = NewObject<USceneCaptureComponent>(Outer, Name);
	wLua::FLuaUtils::ReturnUObject(InScriptContext,Obj);
	return 1;
}

int32 Destroy(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SceneCaptureComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SceneCaptureComponent must be non-null"); lua_error(InScriptContext);  return 0;}
		UActorComponent * com = Cast<UActorComponent>(Obj);
		if(lua_isnoneornil(InScriptContext,2))
			com->DestroyComponent();
		else
			com->DestroyComponent(!!lua_toboolean(InScriptContext,2));
		userdata->flag |= wLua::LuaObjectFlag::DESTROYED;
		wLua::FLuaUtils::RemoveObjectReference(Obj, userdata->stamp, InScriptContext);
#ifdef AZURE_BUILD_WLUACHECK
		UE_LOG(LogAzure, Warning, TEXT("Destroy SceneCaptureComponent: %x userdata:%x   stamp:%x"),Obj,userdata,userdata->stamp);
#endif
	return 0;
}

int32 Class(lua_State* InScriptContext)
{
	UClass* Class = USceneCaptureComponent::StaticClass();
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Class);
	return 1;
}

const luaL_Reg Lib_Funcs[] =
{
	{ "New", New },
	{ "Destroy", Destroy },
	{ "Class", Class },
	{ "ShowOnlyComponent", ShowOnlyComponent },
	{ "ShowOnlyActorComponents", ShowOnlyActorComponents },
	{ "SetCaptureSortPriority", SetCaptureSortPriority },
	{ "RemoveShowOnlyComponent", RemoveShowOnlyComponent },
	{ "RemoveShowOnlyActorComponents", RemoveShowOnlyActorComponents },
	{ "HideComponent", HideComponent },
	{ "HideActorComponents", HideActorComponents },
	{ "ClearShowOnlyComponents", ClearShowOnlyComponents },
	{ "ClearHiddenComponents", ClearHiddenComponents },
	{ "Get_PrimitiveRenderMode", Get_PrimitiveRenderMode },
	{ "Set_PrimitiveRenderMode", Set_PrimitiveRenderMode },
	{ "Get_HiddenActors", Get_HiddenActors },
	{ "Set_HiddenActors", Set_HiddenActors },
	{ "Get_ShowOnlyActors", Get_ShowOnlyActors },
	{ "Set_ShowOnlyActors", Set_ShowOnlyActors },
	{ "Get_bCaptureEveryFrame", Get_bCaptureEveryFrame },
	{ "Set_bCaptureEveryFrame", Set_bCaptureEveryFrame },
	{ "Get_bCaptureOnMovement", Get_bCaptureOnMovement },
	{ "Set_bCaptureOnMovement", Set_bCaptureOnMovement },
	{ "Get_bAlwaysPersistRenderingState", Get_bAlwaysPersistRenderingState },
	{ "Set_bAlwaysPersistRenderingState", Set_bAlwaysPersistRenderingState },
	{ "Get_LODDistanceFactor", Get_LODDistanceFactor },
	{ "Set_LODDistanceFactor", Set_LODDistanceFactor },
	{ "Get_MaxViewDistanceOverride", Get_MaxViewDistanceOverride },
	{ "Set_MaxViewDistanceOverride", Set_MaxViewDistanceOverride },
	{ "Get_CaptureSortPriority", Get_CaptureSortPriority },
	{ "Get_ProfilingEventName", Get_ProfilingEventName },
	{ "Set_ProfilingEventName", Set_ProfilingEventName },
	{ "SetShowFlagSettings", SetShowFlagSettings },
	{ "AddShowFlagSetting", AddShowFlagSetting },
	{ "RemoveShowFlagSetting", RemoveShowFlagSetting },
	{ "UpdateShowFlags", UpdateShowFlags },
	{ "is_nil", wLua::LuaStatic::isnil },
	{ "__gc", wLua::LuaStatic::removeUClassFrameCache },
	{ NULL, NULL }
};

void Register(lua_State *InScriptContext)
{
	lua_newtable(InScriptContext);
	luaL_register(InScriptContext, NULL, Lib_Funcs);
	AzureHelpFuncs::AuxRegister(InScriptContext, "SceneCaptureComponent");
}
void SetMtLink(lua_State *InScriptContext)
{
	AzureHelpFuncs::AuxSetMtLink(InScriptContext, "SceneCaptureComponent", "SceneComponent",USERDATATYPE_UOBJECT);
}

}