#include "Azure.h"
#include "Utility/help_funcs.h"
#include "wLua/UObjectHeaders.h"
#include "Components/WidgetInteractionComponent.h"
#include "AzureLuaIntegration.h"

namespace LuaWidgetInteractionComponent
{
int32 SendKeyChar(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"WidgetInteractionComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"WidgetInteractionComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FString Characters;
		bool bRepeat;
		bool ReturnValue;
	} Params;
	Params.Characters = UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 2));
	Params.bRepeat = lua_isnoneornil(InScriptContext,3) ? bool(false) : !!(lua_toboolean(InScriptContext, 3));
#if UE_GAME
	UWidgetInteractionComponent * This = (UWidgetInteractionComponent *)Obj;
	Params.ReturnValue = This->SendKeyChar(Params.Characters,Params.bRepeat);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SendKeyChar"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FString*)(params.GetStructMemory() + 0) = Params.Characters;
		*(bool*)(params.GetStructMemory() + 16) = Params.bRepeat;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.Characters = *(FString*)(params.GetStructMemory() + 0);
		Params.bRepeat = *(bool*)(params.GetStructMemory() + 16);
		Params.ReturnValue = *(bool*)(params.GetStructMemory() + 17);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushboolean(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 ScrollWheel(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"WidgetInteractionComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"WidgetInteractionComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float ScrollDelta;
	} Params;
	Params.ScrollDelta = (float)(luaL_checknumber(InScriptContext, 2));
#if UE_GAME
	UWidgetInteractionComponent * This = (UWidgetInteractionComponent *)Obj;
	This->ScrollWheel(Params.ScrollDelta);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("ScrollWheel"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(float*)(params.GetStructMemory() + 0) = Params.ScrollDelta;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ScrollDelta = *(float*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 IsOverInteractableWidget(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"WidgetInteractionComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"WidgetInteractionComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool ReturnValue;
	} Params;
#if UE_GAME
	UWidgetInteractionComponent * This = (UWidgetInteractionComponent *)Obj;
	Params.ReturnValue = This->IsOverInteractableWidget();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("IsOverInteractableWidget"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushboolean(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 IsOverHitTestVisibleWidget(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"WidgetInteractionComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"WidgetInteractionComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool ReturnValue;
	} Params;
#if UE_GAME
	UWidgetInteractionComponent * This = (UWidgetInteractionComponent *)Obj;
	Params.ReturnValue = This->IsOverHitTestVisibleWidget();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("IsOverHitTestVisibleWidget"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushboolean(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 IsOverFocusableWidget(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"WidgetInteractionComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"WidgetInteractionComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool ReturnValue;
	} Params;
#if UE_GAME
	UWidgetInteractionComponent * This = (UWidgetInteractionComponent *)Obj;
	Params.ReturnValue = This->IsOverFocusableWidget();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("IsOverFocusableWidget"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushboolean(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetHoveredWidgetComponent(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"WidgetInteractionComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"WidgetInteractionComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		UWidgetComponent* ReturnValue = nullptr;
	} Params;
#if UE_GAME
	UWidgetInteractionComponent * This = (UWidgetInteractionComponent *)Obj;
	Params.ReturnValue = This->GetHoveredWidgetComponent();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetHoveredWidgetComponent"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(UWidgetComponent**)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 Get2DHitLocation(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"WidgetInteractionComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"WidgetInteractionComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FVector2D ReturnValue;
	} Params;
#if UE_GAME
	UWidgetInteractionComponent * This = (UWidgetInteractionComponent *)Obj;
	Params.ReturnValue = This->Get2DHitLocation();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("Get2DHitLocation"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(FVector2D*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaVector2D::Return(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 Call_OnHoveredWidgetChanged(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"WidgetInteractionComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"WidgetInteractionComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		UWidgetComponent* WidgetComponent = nullptr;
		UWidgetComponent* PreviousWidgetComponent = nullptr;
	} Params;
	Params.WidgetComponent = (UWidgetComponent*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"WidgetComponent");;
	Params.PreviousWidgetComponent = (UWidgetComponent*)wLua::FLuaUtils::GetUObject(InScriptContext,3,"WidgetComponent");;
	UWidgetInteractionComponent * This = (UWidgetInteractionComponent *)Obj;
	This->OnHoveredWidgetChanged.Broadcast(Params.WidgetComponent,Params.PreviousWidgetComponent);
	return 0;
}

int32 Get_VirtualUserIndex(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"WidgetInteractionComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"WidgetInteractionComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UWidgetInteractionComponent::StaticClass(), TEXT("VirtualUserIndex"));
	if(!Property) { check(false); return 0;}
	int32 PropertyValue = int32();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushinteger(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_VirtualUserIndex(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"WidgetInteractionComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"WidgetInteractionComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UWidgetInteractionComponent::StaticClass(), TEXT("VirtualUserIndex"));
	if(!Property) { check(false); return 0;}
	int32 PropertyValue = (luaL_checkint(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_PointerIndex(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"WidgetInteractionComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"WidgetInteractionComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UWidgetInteractionComponent::StaticClass(), TEXT("PointerIndex"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_PointerIndex(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"WidgetInteractionComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"WidgetInteractionComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UWidgetInteractionComponent::StaticClass(), TEXT("PointerIndex"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_TraceChannel(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"WidgetInteractionComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"WidgetInteractionComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UWidgetInteractionComponent::StaticClass(), TEXT("TraceChannel"));
	if(!Property) { check(false); return 0;}
	TEnumAsByte<ECollisionChannel> PropertyValue = TEnumAsByte<ECollisionChannel>();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushinteger(InScriptContext, (int)PropertyValue);
	return 1;
}

int32 Set_TraceChannel(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"WidgetInteractionComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"WidgetInteractionComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UWidgetInteractionComponent::StaticClass(), TEXT("TraceChannel"));
	if(!Property) { check(false); return 0;}
	TEnumAsByte<ECollisionChannel> PropertyValue = (TEnumAsByte<ECollisionChannel>)(luaL_checkint(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_InteractionDistance(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"WidgetInteractionComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"WidgetInteractionComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UWidgetInteractionComponent::StaticClass(), TEXT("InteractionDistance"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_InteractionDistance(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"WidgetInteractionComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"WidgetInteractionComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UWidgetInteractionComponent::StaticClass(), TEXT("InteractionDistance"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_InteractionSource(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"WidgetInteractionComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"WidgetInteractionComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UWidgetInteractionComponent::StaticClass(), TEXT("InteractionSource"));
	if(!Property) { check(false); return 0;}
	EWidgetInteractionSource PropertyValue = EWidgetInteractionSource();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushinteger(InScriptContext, (int)PropertyValue);
	return 1;
}

int32 Set_InteractionSource(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"WidgetInteractionComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"WidgetInteractionComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UWidgetInteractionComponent::StaticClass(), TEXT("InteractionSource"));
	if(!Property) { check(false); return 0;}
	EWidgetInteractionSource PropertyValue = (EWidgetInteractionSource)(luaL_checkint(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bEnableHitTesting(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"WidgetInteractionComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"WidgetInteractionComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UWidgetInteractionComponent::StaticClass(), TEXT("bEnableHitTesting"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = bool();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bEnableHitTesting(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"WidgetInteractionComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"WidgetInteractionComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UWidgetInteractionComponent::StaticClass(), TEXT("bEnableHitTesting"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bShowDebug(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"WidgetInteractionComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"WidgetInteractionComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UWidgetInteractionComponent::StaticClass(), TEXT("bShowDebug"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = bool();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bShowDebug(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"WidgetInteractionComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"WidgetInteractionComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UWidgetInteractionComponent::StaticClass(), TEXT("bShowDebug"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_DebugColor(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"WidgetInteractionComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"WidgetInteractionComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UWidgetInteractionComponent::StaticClass(), TEXT("DebugColor"));
	if(!Property) { check(false); return 0;}
	FLinearColor PropertyValue = FLinearColor();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaLinearColor::Return(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_DebugColor(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"WidgetInteractionComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"WidgetInteractionComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UWidgetInteractionComponent::StaticClass(), TEXT("DebugColor"));
	if(!Property) { check(false); return 0;}
	FLinearColor PropertyValue = (wLua::FLuaLinearColor::Get(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 New(lua_State* InScriptContext)
{
	UObject* Outer = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Object");
	FName Name = FName(luaL_checkstring(InScriptContext, 2));
	UObject* Obj = NewObject<UWidgetInteractionComponent>(Outer, Name);
	wLua::FLuaUtils::ReturnUObject(InScriptContext,Obj);
	return 1;
}

int32 Destroy(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"WidgetInteractionComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"WidgetInteractionComponent must be non-null"); lua_error(InScriptContext);  return 0;}
		UActorComponent * com = Cast<UActorComponent>(Obj);
		if(lua_isnoneornil(InScriptContext,2))
			com->DestroyComponent();
		else
			com->DestroyComponent(!!lua_toboolean(InScriptContext,2));
		userdata->flag |= wLua::LuaObjectFlag::DESTROYED;
		wLua::FLuaUtils::RemoveObjectReference(Obj, userdata->stamp, InScriptContext);
#ifdef AZURE_BUILD_WLUACHECK
		UE_LOG(LogAzure, Warning, TEXT("Destroy WidgetInteractionComponent: %x userdata:%x   stamp:%x"),Obj,userdata,userdata->stamp);
#endif
	return 0;
}

int32 Class(lua_State* InScriptContext)
{
	UClass* Class = UWidgetInteractionComponent::StaticClass();
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Class);
	return 1;
}

const luaL_Reg Lib_Funcs[] =
{
	{ "New", New },
	{ "Destroy", Destroy },
	{ "Class", Class },
	{ "SendKeyChar", SendKeyChar },
	{ "ScrollWheel", ScrollWheel },
	{ "IsOverInteractableWidget", IsOverInteractableWidget },
	{ "IsOverHitTestVisibleWidget", IsOverHitTestVisibleWidget },
	{ "IsOverFocusableWidget", IsOverFocusableWidget },
	{ "GetHoveredWidgetComponent", GetHoveredWidgetComponent },
	{ "Get2DHitLocation", Get2DHitLocation },
	{ "Call_OnHoveredWidgetChanged", Call_OnHoveredWidgetChanged },
	{ "Get_VirtualUserIndex", Get_VirtualUserIndex },
	{ "Set_VirtualUserIndex", Set_VirtualUserIndex },
	{ "Get_PointerIndex", Get_PointerIndex },
	{ "Set_PointerIndex", Set_PointerIndex },
	{ "Get_TraceChannel", Get_TraceChannel },
	{ "Set_TraceChannel", Set_TraceChannel },
	{ "Get_InteractionDistance", Get_InteractionDistance },
	{ "Set_InteractionDistance", Set_InteractionDistance },
	{ "Get_InteractionSource", Get_InteractionSource },
	{ "Set_InteractionSource", Set_InteractionSource },
	{ "Get_bEnableHitTesting", Get_bEnableHitTesting },
	{ "Set_bEnableHitTesting", Set_bEnableHitTesting },
	{ "Get_bShowDebug", Get_bShowDebug },
	{ "Set_bShowDebug", Set_bShowDebug },
	{ "Get_DebugColor", Get_DebugColor },
	{ "Set_DebugColor", Set_DebugColor },
	{ "is_nil", wLua::LuaStatic::isnil },
	{ "__gc", wLua::LuaStatic::removeUClassFrameCache },
	{ NULL, NULL }
};

void Register(lua_State *InScriptContext)
{
	lua_newtable(InScriptContext);
	luaL_register(InScriptContext, NULL, Lib_Funcs);
	AzureHelpFuncs::AuxRegister(InScriptContext, "WidgetInteractionComponent");
}
void SetMtLink(lua_State *InScriptContext)
{
	AzureHelpFuncs::AuxSetMtLink(InScriptContext, "WidgetInteractionComponent", "SceneComponent",USERDATATYPE_UOBJECT);
}

}