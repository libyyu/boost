#include "Azure.h"
#include "Utility/help_funcs.h"
#include "wLua/UObjectHeaders.h"
#include "Animation/SkeletalMeshActor.h"
#include "AzureLuaIntegration.h"

namespace LuaSkeletalMeshActor
{
int32 OnRep_ReplicatedPhysAsset(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SkeletalMeshActor",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SkeletalMeshActor must be non-null"); lua_error(InScriptContext);  return 0;}
#if UE_GAME
	ASkeletalMeshActor * This = (ASkeletalMeshActor *)Obj;
	This->OnRep_ReplicatedPhysAsset();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("OnRep_ReplicatedPhysAsset"));
	if(!Function) { check(false); return 0;}
	Obj->ProcessEvent(Function, NULL);
#endif
	return 0;
}

int32 OnRep_ReplicatedMesh(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SkeletalMeshActor",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SkeletalMeshActor must be non-null"); lua_error(InScriptContext);  return 0;}
#if UE_GAME
	ASkeletalMeshActor * This = (ASkeletalMeshActor *)Obj;
	This->OnRep_ReplicatedMesh();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("OnRep_ReplicatedMesh"));
	if(!Function) { check(false); return 0;}
	Obj->ProcessEvent(Function, NULL);
#endif
	return 0;
}

int32 OnRep_ReplicatedMaterial1(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SkeletalMeshActor",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SkeletalMeshActor must be non-null"); lua_error(InScriptContext);  return 0;}
#if UE_GAME
	ASkeletalMeshActor * This = (ASkeletalMeshActor *)Obj;
	This->OnRep_ReplicatedMaterial1();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("OnRep_ReplicatedMaterial1"));
	if(!Function) { check(false); return 0;}
	Obj->ProcessEvent(Function, NULL);
#endif
	return 0;
}

int32 OnRep_ReplicatedMaterial0(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SkeletalMeshActor",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SkeletalMeshActor must be non-null"); lua_error(InScriptContext);  return 0;}
#if UE_GAME
	ASkeletalMeshActor * This = (ASkeletalMeshActor *)Obj;
	This->OnRep_ReplicatedMaterial0();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("OnRep_ReplicatedMaterial0"));
	if(!Function) { check(false); return 0;}
	Obj->ProcessEvent(Function, NULL);
#endif
	return 0;
}

int32 Get_bShouldDoAnimNotifies(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SkeletalMeshActor",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SkeletalMeshActor must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(ASkeletalMeshActor::StaticClass(), TEXT("bShouldDoAnimNotifies"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bShouldDoAnimNotifies(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SkeletalMeshActor",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SkeletalMeshActor must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(ASkeletalMeshActor::StaticClass(), TEXT("bShouldDoAnimNotifies"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_SkeletalMeshComponent(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SkeletalMeshActor",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SkeletalMeshActor must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(ASkeletalMeshActor::StaticClass(), TEXT("SkeletalMeshComponent"));
	if(!Property) { check(false); return 0;}
	USkeletalMeshComponent* PropertyValue;
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaUtils::ReturnUObject(InScriptContext, PropertyValue);
	return 1;
}

int32 New(lua_State* InScriptContext)
{
	UObject* Outer = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Object");
	FName Name = FName(luaL_checkstring(InScriptContext, 2));
	UObject* Obj = NewObject<ASkeletalMeshActor>(Outer, Name);
	wLua::FLuaUtils::ReturnUObject(InScriptContext,Obj);
	return 1;
}

int32 Destroy(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SkeletalMeshActor",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SkeletalMeshActor must be non-null"); lua_error(InScriptContext);  return 0;}
		AActor * actor = Cast<AActor>(Obj);
		actor->Destroy();
		userdata->flag |= wLua::LuaObjectFlag::DESTROYED;
		wLua::FLuaUtils::RemoveObjectReference(Obj, userdata->stamp, InScriptContext);
#ifdef AZURE_BUILD_WLUACHECK
		UE_LOG(LogAzure, Warning, TEXT("Destroy SkeletalMeshActor: %x userdata:%x   stamp:%x"),Obj,userdata,userdata->stamp);
#endif
	return 0;
}

int32 Class(lua_State* InScriptContext)
{
	UClass* Class = ASkeletalMeshActor::StaticClass();
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Class);
	return 1;
}

const luaL_Reg Lib_Funcs[] =
{
	{ "New", New },
	{ "Destroy", Destroy },
	{ "Class", Class },
	{ "OnRep_ReplicatedPhysAsset", OnRep_ReplicatedPhysAsset },
	{ "OnRep_ReplicatedMesh", OnRep_ReplicatedMesh },
	{ "OnRep_ReplicatedMaterial1", OnRep_ReplicatedMaterial1 },
	{ "OnRep_ReplicatedMaterial0", OnRep_ReplicatedMaterial0 },
	{ "Get_bShouldDoAnimNotifies", Get_bShouldDoAnimNotifies },
	{ "Set_bShouldDoAnimNotifies", Set_bShouldDoAnimNotifies },
	{ "Get_SkeletalMeshComponent", Get_SkeletalMeshComponent },
	{ "is_nil", wLua::LuaStatic::isnil },
	{ "__gc", wLua::LuaStatic::removeUClassFrameCache },
	{ NULL, NULL }
};

void Register(lua_State *InScriptContext)
{
	lua_newtable(InScriptContext);
	luaL_register(InScriptContext, NULL, Lib_Funcs);
	AzureHelpFuncs::AuxRegister(InScriptContext, "SkeletalMeshActor");
}
void SetMtLink(lua_State *InScriptContext)
{
	AzureHelpFuncs::AuxSetMtLink(InScriptContext, "SkeletalMeshActor", "Actor",USERDATATYPE_UOBJECT);
}

}