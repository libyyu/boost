#include "Azure.h"
#include "Utility/help_funcs.h"
#include "wLua/UObjectHeaders.h"
#include "Curves/CurveFloat.h"
#include "AzureLuaIntegration.h"

namespace LuaCurveFloat
{
int32 GetFloatValue(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CurveFloat",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CurveFloat must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float InTime;
		float ReturnValue;
	} Params;
	Params.InTime = (float)(luaL_checknumber(InScriptContext, 2));
#if UE_GAME
	UCurveFloat * This = (UCurveFloat *)Obj;
	Params.ReturnValue = This->GetFloatValue(Params.InTime);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetFloatValue"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(float*)(params.GetStructMemory() + 0) = Params.InTime;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.InTime = *(float*)(params.GetStructMemory() + 0);
		Params.ReturnValue = *(float*)(params.GetStructMemory() + 4);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushnumber(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetFloatSlopeValue(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CurveFloat",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CurveFloat must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float InTime;
		float ReturnValue;
	} Params;
	Params.InTime = (float)(luaL_checknumber(InScriptContext, 2));
#if UE_GAME
	UCurveFloat * This = (UCurveFloat *)Obj;
	Params.ReturnValue = This->GetFloatSlopeValue(Params.InTime);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetFloatSlopeValue"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(float*)(params.GetStructMemory() + 0) = Params.InTime;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.InTime = *(float*)(params.GetStructMemory() + 0);
		Params.ReturnValue = *(float*)(params.GetStructMemory() + 4);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushnumber(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 New(lua_State* InScriptContext)
{
	UObject* Outer = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Object");
	FName Name = FName(luaL_checkstring(InScriptContext, 2));
	UObject* Obj = NewObject<UCurveFloat>(Outer, Name);
	wLua::FLuaUtils::ReturnUObject(InScriptContext,Obj);
	return 1;
}

int32 Destroy(lua_State* InScriptContext)
{
	return 0;
}

int32 Class(lua_State* InScriptContext)
{
	UClass* Class = UCurveFloat::StaticClass();
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Class);
	return 1;
}

const luaL_Reg Lib_Funcs[] =
{
	{ "New", New },
	{ "Destroy", Destroy },
	{ "Class", Class },
	{ "GetFloatValue", GetFloatValue },
	{ "GetFloatSlopeValue", GetFloatSlopeValue },
	{ "is_nil", wLua::LuaStatic::isnil },
	{ "__gc", wLua::LuaStatic::removeUClassFrameCache },
	{ NULL, NULL }
};

void Register(lua_State *InScriptContext)
{
	lua_newtable(InScriptContext);
	luaL_register(InScriptContext, NULL, Lib_Funcs);
	AzureHelpFuncs::AuxRegister(InScriptContext, "CurveFloat");
}
void SetMtLink(lua_State *InScriptContext)
{
	AzureHelpFuncs::AuxSetMtLink(InScriptContext, "CurveFloat", "CurveBase",USERDATATYPE_UOBJECT);
}

}