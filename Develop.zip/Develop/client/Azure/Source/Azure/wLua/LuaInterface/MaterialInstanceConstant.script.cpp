#include "Azure.h"
#include "Utility/help_funcs.h"
#include "wLua/UObjectHeaders.h"
#include "Materials/MaterialInstanceConstant.h"
#include "AzureLuaIntegration.h"

namespace LuaMaterialInstanceConstant
{
int32 K2_GetVectorParameterValue(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MaterialInstanceConstant",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MaterialInstanceConstant must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FName ParameterName;
		FLinearColor ReturnValue;
	} Params;
	Params.ParameterName = FName(UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 2)));
#if UE_GAME
	UMaterialInstanceConstant * This = (UMaterialInstanceConstant *)Obj;
	Params.ReturnValue = This->K2_GetVectorParameterValue(Params.ParameterName);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("K2_GetVectorParameterValue"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FName*)(params.GetStructMemory() + 0) = Params.ParameterName;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ParameterName = *(FName*)(params.GetStructMemory() + 0);
		Params.ReturnValue = *(FLinearColor*)(params.GetStructMemory() + 12);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaLinearColor::Return(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 K2_GetTextureParameterValue(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MaterialInstanceConstant",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MaterialInstanceConstant must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FName ParameterName;
		UTexture* ReturnValue = nullptr;
	} Params;
	Params.ParameterName = FName(UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 2)));
#if UE_GAME
	UMaterialInstanceConstant * This = (UMaterialInstanceConstant *)Obj;
	Params.ReturnValue = This->K2_GetTextureParameterValue(Params.ParameterName);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("K2_GetTextureParameterValue"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FName*)(params.GetStructMemory() + 0) = Params.ParameterName;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ParameterName = *(FName*)(params.GetStructMemory() + 0);
		Params.ReturnValue = *(UTexture**)(params.GetStructMemory() + 16);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 K2_GetScalarParameterValue(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MaterialInstanceConstant",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MaterialInstanceConstant must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FName ParameterName;
		float ReturnValue;
	} Params;
	Params.ParameterName = FName(UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 2)));
#if UE_GAME
	UMaterialInstanceConstant * This = (UMaterialInstanceConstant *)Obj;
	Params.ReturnValue = This->K2_GetScalarParameterValue(Params.ParameterName);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("K2_GetScalarParameterValue"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FName*)(params.GetStructMemory() + 0) = Params.ParameterName;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ParameterName = *(FName*)(params.GetStructMemory() + 0);
		Params.ReturnValue = *(float*)(params.GetStructMemory() + 12);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushnumber(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 New(lua_State* InScriptContext)
{
	UObject* Outer = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Object");
	FName Name = FName(luaL_checkstring(InScriptContext, 2));
	UObject* Obj = NewObject<UMaterialInstanceConstant>(Outer, Name);
	wLua::FLuaUtils::ReturnUObject(InScriptContext,Obj);
	return 1;
}

int32 Destroy(lua_State* InScriptContext)
{
	return 0;
}

int32 Class(lua_State* InScriptContext)
{
	UClass* Class = UMaterialInstanceConstant::StaticClass();
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Class);
	return 1;
}

const luaL_Reg Lib_Funcs[] =
{
	{ "New", New },
	{ "Destroy", Destroy },
	{ "Class", Class },
	{ "GetVectorParameterValue", K2_GetVectorParameterValue },
	{ "GetTextureParameterValue", K2_GetTextureParameterValue },
	{ "GetScalarParameterValue", K2_GetScalarParameterValue },
	{ "is_nil", wLua::LuaStatic::isnil },
	{ "__gc", wLua::LuaStatic::removeUClassFrameCache },
	{ NULL, NULL }
};

void Register(lua_State *InScriptContext)
{
	lua_newtable(InScriptContext);
	luaL_register(InScriptContext, NULL, Lib_Funcs);
	AzureHelpFuncs::AuxRegister(InScriptContext, "MaterialInstanceConstant");
}
void SetMtLink(lua_State *InScriptContext)
{
	AzureHelpFuncs::AuxSetMtLink(InScriptContext, "MaterialInstanceConstant", "MaterialInstance",USERDATATYPE_UOBJECT);
}

}