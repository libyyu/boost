#include "Azure.h"
#include "Utility/help_funcs.h"
#include "wLua/UObjectHeaders.h"
#include "AzureCompactScrollList.h"
#include "AzureLuaIntegration.h"

namespace LuaAzureCompactScrollList
{
int32 setUpdateFunc(lua_State*);
int32 getItem(lua_State*);
int32 setCount(lua_State*);
int32 forceUpdate(lua_State*);
int32 scrollToBegin(lua_State*);
int32 scrollToEnd(lua_State*);
int32 setFirstIndex(lua_State*);
int32 getFirstIndex(lua_State*);
int32 clear(lua_State*);
int32 GetFirstIndex(lua_State*);
int32 setMiddleItemChangeFunc(lua_State*);

int32 SetFirstIndex(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureCompactScrollList",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureCompactScrollList must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		int32 index;
		bool bAnimate;
		float Offset;
		EDescendantScrollDestination ScrollDestination;
	} Params;
	Params.index = (luaL_checkint(InScriptContext, 2));
	Params.bAnimate = lua_isnoneornil(InScriptContext,3) ? bool(false) : !!(lua_toboolean(InScriptContext, 3));
	Params.Offset = lua_isnoneornil(InScriptContext,4) ? float(0.000000) : (float)(luaL_checknumber(InScriptContext, 4));
	Params.ScrollDestination = lua_isnoneornil(InScriptContext,5) ? EDescendantScrollDestination(EDescendantScrollDestination::TopOrLeft) : (EDescendantScrollDestination)(luaL_checkint(InScriptContext, 5));
#if UE_GAME
	UAzureCompactScrollList * This = (UAzureCompactScrollList *)Obj;
	This->SetFirstIndex(Params.index,Params.bAnimate,Params.Offset,Params.ScrollDestination);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetFirstIndex"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(int32*)(params.GetStructMemory() + 0) = Params.index;
		*(bool*)(params.GetStructMemory() + 4) = Params.bAnimate;
		*(float*)(params.GetStructMemory() + 8) = Params.Offset;
		*(EDescendantScrollDestination*)(params.GetStructMemory() + 12) = Params.ScrollDestination;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.index = *(int32*)(params.GetStructMemory() + 0);
		Params.bAnimate = *(bool*)(params.GetStructMemory() + 4);
		Params.Offset = *(float*)(params.GetStructMemory() + 8);
		Params.ScrollDestination = *(EDescendantScrollDestination*)(params.GetStructMemory() + 12);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 Call_OnBPUpdateItem(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureCompactScrollList",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureCompactScrollList must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		UUserWidget* Item = nullptr;
		int32 Index;
	} Params;
	Params.Item = (UUserWidget*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"UserWidget");;
	Params.Index = (luaL_checkint(InScriptContext, 3));
	UAzureCompactScrollList * This = (UAzureCompactScrollList *)Obj;
	This->OnBPUpdateItem.Broadcast(Params.Item,Params.Index);
	return 0;
}

int32 Call_OnBPHideItem(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureCompactScrollList",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureCompactScrollList must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		UUserWidget* Item = nullptr;
		int32 Index;
	} Params;
	Params.Item = (UUserWidget*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"UserWidget");;
	Params.Index = (luaL_checkint(InScriptContext, 3));
	UAzureCompactScrollList * This = (UAzureCompactScrollList *)Obj;
	This->OnBPHideItem.Broadcast(Params.Item,Params.Index);
	return 0;
}

int32 Get_PaddingCurve(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureCompactScrollList",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureCompactScrollList must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzureCompactScrollList::StaticClass(), TEXT("PaddingCurve"));
	if(!Property) { check(false); return 0;}
	UCurveFloat* PropertyValue;
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaUtils::ReturnUObject(InScriptContext, PropertyValue);
	return 1;
}

int32 New(lua_State* InScriptContext)
{
	UObject* Outer = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Object");
	FName Name = FName(luaL_checkstring(InScriptContext, 2));
	UObject* Obj = NewObject<UAzureCompactScrollList>(Outer, Name);
	wLua::FLuaUtils::ReturnUObject(InScriptContext,Obj);
	return 1;
}

int32 Destroy(lua_State* InScriptContext)
{
	return 0;
}

int32 Class(lua_State* InScriptContext)
{
	UClass* Class = UAzureCompactScrollList::StaticClass();
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Class);
	return 1;
}

const luaL_Reg Lib_Funcs[] =
{
	{ "New", New },
	{ "Destroy", Destroy },
	{ "Class", Class },
	{ "SetFirstIndex", SetFirstIndex },
	{ "Call_OnBPUpdateItem", Call_OnBPUpdateItem },
	{ "Call_OnBPHideItem", Call_OnBPHideItem },
	{ "Get_PaddingCurve", Get_PaddingCurve },
	{ "setUpdateFunc", setUpdateFunc },
	{ "getItem", getItem },
	{ "setCount", setCount },
	{ "forceUpdate", forceUpdate },
	{ "scrollToBegin", scrollToBegin },
	{ "scrollToEnd", scrollToEnd },
	{ "setFirstIndex", setFirstIndex },
	{ "getFirstIndex", getFirstIndex },
	{ "clear", clear },
	{ "GetFirstIndex", GetFirstIndex },
	{ "setMiddleItemChangeFunc", setMiddleItemChangeFunc },
	{ "is_nil", wLua::LuaStatic::isnil },
	{ "__gc", wLua::LuaStatic::removeUClassFrameCache },
	{ NULL, NULL }
};

void Register(lua_State *InScriptContext)
{
	lua_newtable(InScriptContext);
	luaL_register(InScriptContext, NULL, Lib_Funcs);
	AzureHelpFuncs::AuxRegister(InScriptContext, "AzureCompactScrollList");
}
void SetMtLink(lua_State *InScriptContext)
{
	AzureHelpFuncs::AuxSetMtLink(InScriptContext, "AzureCompactScrollList", "AzureSplitScrollList",USERDATATYPE_UOBJECT);
}

}