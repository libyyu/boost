#include "Azure.h"
#include "Utility/help_funcs.h"
#include "wLua/UObjectHeaders.h"
#include "GameLogic/Home/AzureHomeWallArrowComponent.h"
#include "AzureLuaIntegration.h"

namespace LuaAzureHomeWallArrowComponent
{
int32 SetWallInfo(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureHomeWallArrowComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureHomeWallArrowComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		int32 id;
		int32 wall_id;
		ArrowType type;
	} Params;
	Params.id = (luaL_checkint(InScriptContext, 2));
	Params.wall_id = (luaL_checkint(InScriptContext, 3));
	Params.type = (ArrowType)(luaL_checkint(InScriptContext, 4));
#if UE_GAME
	UAzureHomeWallArrowComponent * This = (UAzureHomeWallArrowComponent *)Obj;
	This->SetWallInfo(Params.id,Params.wall_id,Params.type);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetWallInfo"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(int32*)(params.GetStructMemory() + 0) = Params.id;
		*(int32*)(params.GetStructMemory() + 4) = Params.wall_id;
		*(ArrowType*)(params.GetStructMemory() + 8) = Params.type;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.id = *(int32*)(params.GetStructMemory() + 0);
		Params.wall_id = *(int32*)(params.GetStructMemory() + 4);
		Params.type = *(ArrowType*)(params.GetStructMemory() + 8);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 GetWallInfo(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureHomeWallArrowComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureHomeWallArrowComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		int32 id;
		int32 wall_id;
		ArrowType type;
		bool ReturnValue;
	} Params;
#if UE_GAME
	UAzureHomeWallArrowComponent * This = (UAzureHomeWallArrowComponent *)Obj;
	Params.ReturnValue = This->GetWallInfo(Params.id,Params.wall_id,Params.type);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetWallInfo"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.id = *(int32*)(params.GetStructMemory() + 0);
		Params.wall_id = *(int32*)(params.GetStructMemory() + 4);
		Params.type = *(ArrowType*)(params.GetStructMemory() + 8);
		Params.ReturnValue = *(bool*)(params.GetStructMemory() + 9);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushboolean(InScriptContext, Params.ReturnValue);
	lua_pushinteger(InScriptContext, Params.id);
	lua_pushinteger(InScriptContext, Params.wall_id);
	lua_pushinteger(InScriptContext, (int)Params.type);
	return 4;
}

int32 Get_ID(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureHomeWallArrowComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureHomeWallArrowComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzureHomeWallArrowComponent::StaticClass(), TEXT("ID"));
	if(!Property) { check(false); return 0;}
	int32 PropertyValue = int32();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushinteger(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_ID(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureHomeWallArrowComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureHomeWallArrowComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzureHomeWallArrowComponent::StaticClass(), TEXT("ID"));
	if(!Property) { check(false); return 0;}
	int32 PropertyValue = (luaL_checkint(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_WallId(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureHomeWallArrowComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureHomeWallArrowComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzureHomeWallArrowComponent::StaticClass(), TEXT("WallId"));
	if(!Property) { check(false); return 0;}
	int32 PropertyValue = int32();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushinteger(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_WallId(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureHomeWallArrowComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureHomeWallArrowComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzureHomeWallArrowComponent::StaticClass(), TEXT("WallId"));
	if(!Property) { check(false); return 0;}
	int32 PropertyValue = (luaL_checkint(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_Type(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureHomeWallArrowComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureHomeWallArrowComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzureHomeWallArrowComponent::StaticClass(), TEXT("Type"));
	if(!Property) { check(false); return 0;}
	ArrowType PropertyValue = ArrowType();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushinteger(InScriptContext, (int)PropertyValue);
	return 1;
}

int32 Set_Type(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureHomeWallArrowComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureHomeWallArrowComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzureHomeWallArrowComponent::StaticClass(), TEXT("Type"));
	if(!Property) { check(false); return 0;}
	ArrowType PropertyValue = (ArrowType)(luaL_checkint(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 New(lua_State* InScriptContext)
{
	UObject* Outer = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Object");
	FName Name = FName(luaL_checkstring(InScriptContext, 2));
	UObject* Obj = NewObject<UAzureHomeWallArrowComponent>(Outer, Name);
	wLua::FLuaUtils::ReturnUObject(InScriptContext,Obj);
	return 1;
}

int32 Destroy(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureHomeWallArrowComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureHomeWallArrowComponent must be non-null"); lua_error(InScriptContext);  return 0;}
		UActorComponent * com = Cast<UActorComponent>(Obj);
		if(lua_isnoneornil(InScriptContext,2))
			com->DestroyComponent();
		else
			com->DestroyComponent(!!lua_toboolean(InScriptContext,2));
		userdata->flag |= wLua::LuaObjectFlag::DESTROYED;
		wLua::FLuaUtils::RemoveObjectReference(Obj, userdata->stamp, InScriptContext);
#ifdef AZURE_BUILD_WLUACHECK
		UE_LOG(LogAzure, Warning, TEXT("Destroy AzureHomeWallArrowComponent: %x userdata:%x   stamp:%x"),Obj,userdata,userdata->stamp);
#endif
	return 0;
}

int32 Class(lua_State* InScriptContext)
{
	UClass* Class = UAzureHomeWallArrowComponent::StaticClass();
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Class);
	return 1;
}

const luaL_Reg Lib_Funcs[] =
{
	{ "New", New },
	{ "Destroy", Destroy },
	{ "Class", Class },
	{ "SetWallInfo", SetWallInfo },
	{ "GetWallInfo", GetWallInfo },
	{ "Get_ID", Get_ID },
	{ "Set_ID", Set_ID },
	{ "Get_WallId", Get_WallId },
	{ "Set_WallId", Set_WallId },
	{ "Get_Type", Get_Type },
	{ "Set_Type", Set_Type },
	{ "is_nil", wLua::LuaStatic::isnil },
	{ "__gc", wLua::LuaStatic::removeUClassFrameCache },
	{ NULL, NULL }
};

void Register(lua_State *InScriptContext)
{
	lua_newtable(InScriptContext);
	luaL_register(InScriptContext, NULL, Lib_Funcs);
	AzureHelpFuncs::AuxRegister(InScriptContext, "AzureHomeWallArrowComponent");
}
void SetMtLink(lua_State *InScriptContext)
{
	AzureHelpFuncs::AuxSetMtLink(InScriptContext, "AzureHomeWallArrowComponent", "ActorComponent",USERDATATYPE_UOBJECT);
}

}