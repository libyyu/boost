#include "Azure.h"
#include "Utility/help_funcs.h"
#include "wLua/UObjectHeaders.h"
#include "AzureAtlasAnimation.h"
#include "AzureLuaIntegration.h"

namespace LuaAzureAtlasAnimation
{
int32 setOnStopFunc(lua_State*);

int32 SetPrefix(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureAtlasAnimation",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureAtlasAnimation must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FString InPrefix;
	} Params;
	Params.InPrefix = UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 2));
#if UE_GAME
	UAzureAtlasAnimation * This = (UAzureAtlasAnimation *)Obj;
	This->SetPrefix(Params.InPrefix);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetPrefix"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FString*)(params.GetStructMemory() + 0) = Params.InPrefix;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.InPrefix = *(FString*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetLoop(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureAtlasAnimation",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureAtlasAnimation must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		int32 InLoop;
	} Params;
	Params.InLoop = (luaL_checkint(InScriptContext, 2));
#if UE_GAME
	UAzureAtlasAnimation * This = (UAzureAtlasAnimation *)Obj;
	This->SetLoop(Params.InLoop);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetLoop"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(int32*)(params.GetStructMemory() + 0) = Params.InLoop;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.InLoop = *(int32*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetFrameOffset(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureAtlasAnimation",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureAtlasAnimation must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		int32 InOffset;
	} Params;
	Params.InOffset = (luaL_checkint(InScriptContext, 2));
#if UE_GAME
	UAzureAtlasAnimation * This = (UAzureAtlasAnimation *)Obj;
	This->SetFrameOffset(Params.InOffset);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetFrameOffset"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(int32*)(params.GetStructMemory() + 0) = Params.InOffset;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.InOffset = *(int32*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetFPS(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureAtlasAnimation",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureAtlasAnimation must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		int32 InFPS;
	} Params;
	Params.InFPS = (luaL_checkint(InScriptContext, 2));
#if UE_GAME
	UAzureAtlasAnimation * This = (UAzureAtlasAnimation *)Obj;
	This->SetFPS(Params.InFPS);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetFPS"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(int32*)(params.GetStructMemory() + 0) = Params.InFPS;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.InFPS = *(int32*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetAtlas(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureAtlasAnimation",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureAtlasAnimation must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		UAzureAtlas* InAtlas = nullptr;
	} Params;
	Params.InAtlas = (UAzureAtlas*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"AzureAtlas");;
#if UE_GAME
	UAzureAtlasAnimation * This = (UAzureAtlasAnimation *)Obj;
	This->SetAtlas(Params.InAtlas);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetAtlas"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(UAzureAtlas**)(params.GetStructMemory() + 0) = Params.InAtlas;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.InAtlas = *(UAzureAtlas**)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 Play(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureAtlasAnimation",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureAtlasAnimation must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool InPlay;
	} Params;
	Params.InPlay = !!(lua_toboolean(InScriptContext, 2));
#if UE_GAME
	UAzureAtlasAnimation * This = (UAzureAtlasAnimation *)Obj;
	This->Play(Params.InPlay);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("Play"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(bool*)(params.GetStructMemory() + 0) = Params.InPlay;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.InPlay = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 Get_AzureAtlas(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureAtlasAnimation",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureAtlasAnimation must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzureAtlasAnimation::StaticClass(), TEXT("AzureAtlas"));
	if(!Property) { check(false); return 0;}
	UAzureAtlas* PropertyValue;
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaUtils::ReturnUObject(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_AzureAtlas(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureAtlasAnimation",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureAtlasAnimation must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzureAtlasAnimation::StaticClass(), TEXT("AzureAtlas"));
	if(!Property) { check(false); return 0;}
	UAzureAtlas* PropertyValue = (UAzureAtlas*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"AzureAtlas");;
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_Prefix(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureAtlasAnimation",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureAtlasAnimation must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzureAtlasAnimation::StaticClass(), TEXT("Prefix"));
	if(!Property) { check(false); return 0;}
	FString PropertyValue;
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushstring(InScriptContext, TCHAR_TO_UTF8(*PropertyValue));
	return 1;
}

int32 Set_Prefix(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureAtlasAnimation",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureAtlasAnimation must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzureAtlasAnimation::StaticClass(), TEXT("Prefix"));
	if(!Property) { check(false); return 0;}
	FString PropertyValue = UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_FPS(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureAtlasAnimation",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureAtlasAnimation must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzureAtlasAnimation::StaticClass(), TEXT("FPS"));
	if(!Property) { check(false); return 0;}
	int32 PropertyValue = int32();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushinteger(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_FPS(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureAtlasAnimation",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureAtlasAnimation must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzureAtlasAnimation::StaticClass(), TEXT("FPS"));
	if(!Property) { check(false); return 0;}
	int32 PropertyValue = (luaL_checkint(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_Loop(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureAtlasAnimation",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureAtlasAnimation must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzureAtlasAnimation::StaticClass(), TEXT("Loop"));
	if(!Property) { check(false); return 0;}
	int32 PropertyValue = int32();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushinteger(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_Loop(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureAtlasAnimation",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureAtlasAnimation must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzureAtlasAnimation::StaticClass(), TEXT("Loop"));
	if(!Property) { check(false); return 0;}
	int32 PropertyValue = (luaL_checkint(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_FrameOffset(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureAtlasAnimation",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureAtlasAnimation must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzureAtlasAnimation::StaticClass(), TEXT("FrameOffset"));
	if(!Property) { check(false); return 0;}
	int32 PropertyValue = int32();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushinteger(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_FrameOffset(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureAtlasAnimation",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureAtlasAnimation must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzureAtlasAnimation::StaticClass(), TEXT("FrameOffset"));
	if(!Property) { check(false); return 0;}
	int32 PropertyValue = (luaL_checkint(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bAnimationCompatible(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureAtlasAnimation",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureAtlasAnimation must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzureAtlasAnimation::StaticClass(), TEXT("bAnimationCompatible"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = bool();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 New(lua_State* InScriptContext)
{
	UObject* Outer = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Object");
	FName Name = FName(luaL_checkstring(InScriptContext, 2));
	UObject* Obj = NewObject<UAzureAtlasAnimation>(Outer, Name);
	wLua::FLuaUtils::ReturnUObject(InScriptContext,Obj);
	return 1;
}

int32 Destroy(lua_State* InScriptContext)
{
	return 0;
}

int32 Class(lua_State* InScriptContext)
{
	UClass* Class = UAzureAtlasAnimation::StaticClass();
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Class);
	return 1;
}

const luaL_Reg Lib_Funcs[] =
{
	{ "New", New },
	{ "Destroy", Destroy },
	{ "Class", Class },
	{ "SetPrefix", SetPrefix },
	{ "SetLoop", SetLoop },
	{ "SetFrameOffset", SetFrameOffset },
	{ "SetFPS", SetFPS },
	{ "SetAtlas", SetAtlas },
	{ "Play", Play },
	{ "Get_AzureAtlas", Get_AzureAtlas },
	{ "Set_AzureAtlas", Set_AzureAtlas },
	{ "Get_Prefix", Get_Prefix },
	{ "Set_Prefix", Set_Prefix },
	{ "Get_FPS", Get_FPS },
	{ "Set_FPS", Set_FPS },
	{ "Get_Loop", Get_Loop },
	{ "Set_Loop", Set_Loop },
	{ "Get_FrameOffset", Get_FrameOffset },
	{ "Set_FrameOffset", Set_FrameOffset },
	{ "Get_bAnimationCompatible", Get_bAnimationCompatible },
	{ "setOnStopFunc", setOnStopFunc },
	{ "is_nil", wLua::LuaStatic::isnil },
	{ "__gc", wLua::LuaStatic::removeUClassFrameCache },
	{ NULL, NULL }
};

void Register(lua_State *InScriptContext)
{
	lua_newtable(InScriptContext);
	luaL_register(InScriptContext, NULL, Lib_Funcs);
	AzureHelpFuncs::AuxRegister(InScriptContext, "AzureAtlasAnimation");
}
void SetMtLink(lua_State *InScriptContext)
{
	AzureHelpFuncs::AuxSetMtLink(InScriptContext, "AzureAtlasAnimation", "Widget",USERDATATYPE_UOBJECT);
}

}