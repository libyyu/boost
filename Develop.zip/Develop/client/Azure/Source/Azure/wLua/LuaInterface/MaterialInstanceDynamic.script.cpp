#include "Azure.h"
#include "Utility/help_funcs.h"
#include "wLua/UObjectHeaders.h"
#include "Materials/MaterialInstanceDynamic.h"
#include "AzureLuaIntegration.h"

namespace LuaMaterialInstanceDynamic
{
int32 ClearParameterValues(lua_State*);

int32 SetVectorParameterValue(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MaterialInstanceDynamic",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MaterialInstanceDynamic must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FName ParameterName;
		FLinearColor Value;
	} Params;
	Params.ParameterName = FName(UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 2)));
	Params.Value = (wLua::FLuaLinearColor::Get(InScriptContext, 3));
#if UE_GAME
	UMaterialInstanceDynamic * This = (UMaterialInstanceDynamic *)Obj;
	This->SetVectorParameterValue(Params.ParameterName,Params.Value);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetVectorParameterValue"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FName*)(params.GetStructMemory() + 0) = Params.ParameterName;
		*(FLinearColor*)(params.GetStructMemory() + 12) = Params.Value;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ParameterName = *(FName*)(params.GetStructMemory() + 0);
		Params.Value = *(FLinearColor*)(params.GetStructMemory() + 12);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetTextureParameterValue(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MaterialInstanceDynamic",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MaterialInstanceDynamic must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FName ParameterName;
		UTexture* Value = nullptr;
	} Params;
	Params.ParameterName = FName(UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 2)));
	Params.Value = (UTexture*)wLua::FLuaUtils::GetUObject(InScriptContext,3,"Texture");;
#if UE_GAME
	UMaterialInstanceDynamic * This = (UMaterialInstanceDynamic *)Obj;
	This->SetTextureParameterValue(Params.ParameterName,Params.Value);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetTextureParameterValue"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FName*)(params.GetStructMemory() + 0) = Params.ParameterName;
		*(UTexture**)(params.GetStructMemory() + 16) = Params.Value;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ParameterName = *(FName*)(params.GetStructMemory() + 0);
		Params.Value = *(UTexture**)(params.GetStructMemory() + 16);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetScalarParameterValue(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MaterialInstanceDynamic",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MaterialInstanceDynamic must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FName ParameterName;
		float Value;
	} Params;
	Params.ParameterName = FName(UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 2)));
	Params.Value = (float)(luaL_checknumber(InScriptContext, 3));
#if UE_GAME
	UMaterialInstanceDynamic * This = (UMaterialInstanceDynamic *)Obj;
	This->SetScalarParameterValue(Params.ParameterName,Params.Value);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetScalarParameterValue"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FName*)(params.GetStructMemory() + 0) = Params.ParameterName;
		*(float*)(params.GetStructMemory() + 12) = Params.Value;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ParameterName = *(FName*)(params.GetStructMemory() + 0);
		Params.Value = *(float*)(params.GetStructMemory() + 12);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 K2_InterpolateMaterialInstanceParams(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MaterialInstanceDynamic",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MaterialInstanceDynamic must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		UMaterialInstance* SourceA = nullptr;
		UMaterialInstance* SourceB = nullptr;
		float Alpha;
	} Params;
	Params.SourceA = (UMaterialInstance*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"MaterialInstance");;
	Params.SourceB = (UMaterialInstance*)wLua::FLuaUtils::GetUObject(InScriptContext,3,"MaterialInstance");;
	Params.Alpha = (float)(luaL_checknumber(InScriptContext, 4));
#if UE_GAME
	UMaterialInstanceDynamic * This = (UMaterialInstanceDynamic *)Obj;
	This->K2_InterpolateMaterialInstanceParams(Params.SourceA,Params.SourceB,Params.Alpha);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("K2_InterpolateMaterialInstanceParams"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(UMaterialInstance**)(params.GetStructMemory() + 0) = Params.SourceA;
		*(UMaterialInstance**)(params.GetStructMemory() + 8) = Params.SourceB;
		*(float*)(params.GetStructMemory() + 16) = Params.Alpha;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.SourceA = *(UMaterialInstance**)(params.GetStructMemory() + 0);
		Params.SourceB = *(UMaterialInstance**)(params.GetStructMemory() + 8);
		Params.Alpha = *(float*)(params.GetStructMemory() + 16);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 K2_GetVectorParameterValue(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MaterialInstanceDynamic",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MaterialInstanceDynamic must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FName ParameterName;
		FLinearColor ReturnValue;
	} Params;
	Params.ParameterName = FName(UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 2)));
#if UE_GAME
	UMaterialInstanceDynamic * This = (UMaterialInstanceDynamic *)Obj;
	Params.ReturnValue = This->K2_GetVectorParameterValue(Params.ParameterName);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("K2_GetVectorParameterValue"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FName*)(params.GetStructMemory() + 0) = Params.ParameterName;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ParameterName = *(FName*)(params.GetStructMemory() + 0);
		Params.ReturnValue = *(FLinearColor*)(params.GetStructMemory() + 12);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaLinearColor::Return(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 K2_GetTextureParameterValue(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MaterialInstanceDynamic",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MaterialInstanceDynamic must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FName ParameterName;
		UTexture* ReturnValue = nullptr;
	} Params;
	Params.ParameterName = FName(UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 2)));
#if UE_GAME
	UMaterialInstanceDynamic * This = (UMaterialInstanceDynamic *)Obj;
	Params.ReturnValue = This->K2_GetTextureParameterValue(Params.ParameterName);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("K2_GetTextureParameterValue"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FName*)(params.GetStructMemory() + 0) = Params.ParameterName;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ParameterName = *(FName*)(params.GetStructMemory() + 0);
		Params.ReturnValue = *(UTexture**)(params.GetStructMemory() + 16);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 K2_GetScalarParameterValue(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MaterialInstanceDynamic",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MaterialInstanceDynamic must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FName ParameterName;
		float ReturnValue;
	} Params;
	Params.ParameterName = FName(UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 2)));
#if UE_GAME
	UMaterialInstanceDynamic * This = (UMaterialInstanceDynamic *)Obj;
	Params.ReturnValue = This->K2_GetScalarParameterValue(Params.ParameterName);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("K2_GetScalarParameterValue"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FName*)(params.GetStructMemory() + 0) = Params.ParameterName;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ParameterName = *(FName*)(params.GetStructMemory() + 0);
		Params.ReturnValue = *(float*)(params.GetStructMemory() + 12);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushnumber(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 K2_CopyMaterialInstanceParameters(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MaterialInstanceDynamic",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MaterialInstanceDynamic must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		UMaterialInterface* Source = nullptr;
		bool bQuickParametersOnly;
	} Params;
	Params.Source = (UMaterialInterface*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"MaterialInterface");;
	Params.bQuickParametersOnly = lua_isnoneornil(InScriptContext,3) ? bool(false) : !!(lua_toboolean(InScriptContext, 3));
#if UE_GAME
	UMaterialInstanceDynamic * This = (UMaterialInstanceDynamic *)Obj;
	This->K2_CopyMaterialInstanceParameters(Params.Source,Params.bQuickParametersOnly);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("K2_CopyMaterialInstanceParameters"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(UMaterialInterface**)(params.GetStructMemory() + 0) = Params.Source;
		*(bool*)(params.GetStructMemory() + 8) = Params.bQuickParametersOnly;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.Source = *(UMaterialInterface**)(params.GetStructMemory() + 0);
		Params.bQuickParametersOnly = *(bool*)(params.GetStructMemory() + 8);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 CopyParameterOverrides(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MaterialInstanceDynamic",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MaterialInstanceDynamic must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		UMaterialInstance* MaterialInstance = nullptr;
	} Params;
	Params.MaterialInstance = (UMaterialInstance*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"MaterialInstance");;
#if UE_GAME
	UMaterialInstanceDynamic * This = (UMaterialInstanceDynamic *)Obj;
	This->CopyParameterOverrides(Params.MaterialInstance);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("CopyParameterOverrides"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(UMaterialInstance**)(params.GetStructMemory() + 0) = Params.MaterialInstance;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.MaterialInstance = *(UMaterialInstance**)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 CopyInterpParameters(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MaterialInstanceDynamic",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MaterialInstanceDynamic must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		UMaterialInstance* Source = nullptr;
	} Params;
	Params.Source = (UMaterialInstance*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"MaterialInstance");;
#if UE_GAME
	UMaterialInstanceDynamic * This = (UMaterialInstanceDynamic *)Obj;
	This->CopyInterpParameters(Params.Source);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("CopyInterpParameters"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(UMaterialInstance**)(params.GetStructMemory() + 0) = Params.Source;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.Source = *(UMaterialInstance**)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 New(lua_State* InScriptContext)
{
	UObject* Outer = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Object");
	FName Name = FName(luaL_checkstring(InScriptContext, 2));
	UObject* Obj = NewObject<UMaterialInstanceDynamic>(Outer, Name);
	wLua::FLuaUtils::ReturnUObject(InScriptContext,Obj);
	return 1;
}

int32 Destroy(lua_State* InScriptContext)
{
	return 0;
}

int32 Class(lua_State* InScriptContext)
{
	UClass* Class = UMaterialInstanceDynamic::StaticClass();
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Class);
	return 1;
}

const luaL_Reg Lib_Funcs[] =
{
	{ "New", New },
	{ "Destroy", Destroy },
	{ "Class", Class },
	{ "SetVectorParameterValue", SetVectorParameterValue },
	{ "SetTextureParameterValue", SetTextureParameterValue },
	{ "SetScalarParameterValue", SetScalarParameterValue },
	{ "InterpolateMaterialInstanceParams", K2_InterpolateMaterialInstanceParams },
	{ "GetVectorParameterValue", K2_GetVectorParameterValue },
	{ "GetTextureParameterValue", K2_GetTextureParameterValue },
	{ "GetScalarParameterValue", K2_GetScalarParameterValue },
	{ "CopyMaterialInstanceParameters", K2_CopyMaterialInstanceParameters },
	{ "CopyParameterOverrides", CopyParameterOverrides },
	{ "CopyInterpParameters", CopyInterpParameters },
	{ "ClearParameterValues", ClearParameterValues },
	{ "is_nil", wLua::LuaStatic::isnil },
	{ "__gc", wLua::LuaStatic::removeUClassFrameCache },
	{ NULL, NULL }
};

void Register(lua_State *InScriptContext)
{
	lua_newtable(InScriptContext);
	luaL_register(InScriptContext, NULL, Lib_Funcs);
	AzureHelpFuncs::AuxRegister(InScriptContext, "MaterialInstanceDynamic");
}
void SetMtLink(lua_State *InScriptContext)
{
	AzureHelpFuncs::AuxSetMtLink(InScriptContext, "MaterialInstanceDynamic", "MaterialInstance",USERDATATYPE_UOBJECT);
}

}