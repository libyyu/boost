#include "Azure.h"
#include "Utility/help_funcs.h"
#include "wLua/UObjectHeaders.h"
#include "Materials/MaterialInterface.h"
#include "AzureLuaIntegration.h"

namespace LuaMaterialInterface
{
int32 SetForceMipLevelsToBeResident(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MaterialInterface",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MaterialInterface must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool OverrideForceMiplevelsToBeResident;
		bool bForceMiplevelsToBeResidentValue;
		float ForceDuration;
		int32 CinematicTextureGroups;
	} Params;
	Params.OverrideForceMiplevelsToBeResident = !!(lua_toboolean(InScriptContext, 2));
	Params.bForceMiplevelsToBeResidentValue = !!(lua_toboolean(InScriptContext, 3));
	Params.ForceDuration = (float)(luaL_checknumber(InScriptContext, 4));
	Params.CinematicTextureGroups = lua_isnoneornil(InScriptContext,5) ? int32(0) : (luaL_checkint(InScriptContext, 5));
	UMaterialInterface * This = (UMaterialInterface *)Obj;
	This->SetForceMipLevelsToBeResident(Params.OverrideForceMiplevelsToBeResident,Params.bForceMiplevelsToBeResidentValue,Params.ForceDuration,Params.CinematicTextureGroups);
	return 0;
}

int32 GetPhysicalMaterial(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MaterialInterface",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MaterialInterface must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		UPhysicalMaterial* ReturnValue = nullptr;
	} Params;
#if UE_GAME
	UMaterialInterface * This = (UMaterialInterface *)Obj;
	Params.ReturnValue = This->GetPhysicalMaterial();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetPhysicalMaterial"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(UPhysicalMaterial**)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetBaseMaterial(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MaterialInterface",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MaterialInterface must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		UMaterial* ReturnValue = nullptr;
	} Params;
	UMaterialInterface * This = (UMaterialInterface *)Obj;
	Params.ReturnValue = This->GetBaseMaterial();
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 Get_SubsurfaceProfile(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MaterialInterface",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MaterialInterface must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UMaterialInterface::StaticClass(), TEXT("SubsurfaceProfile"));
	if(!Property) { check(false); return 0;}
	USubsurfaceProfile* PropertyValue;
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaUtils::ReturnUObject(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_AssetUserData(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MaterialInterface",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MaterialInterface must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UMaterialInterface::StaticClass(), TEXT("AssetUserData"));
	if(!Property) { check(false); return 0;}
	TArray<UAssetUserData*> PropertyValue;
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	{lua_newtable(InScriptContext); int i = 1; for(auto It = PropertyValue.CreateConstIterator(); It; ++It,++i) {  wLua::FLuaUtils::ReturnUObject(InScriptContext, (*It)); lua_rawseti(InScriptContext,-2,i);     }  }
	return 1;
}

int32 Set_AssetUserData(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MaterialInterface",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MaterialInterface must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UMaterialInterface::StaticClass(), TEXT("AssetUserData"));
	if(!Property) { check(false); return 0;}
	TArray<UAssetUserData*> PropertyValue = [](lua_State * _InScriptContext){ TArray<UAssetUserData*> ret; lua_pushnil(_InScriptContext); while(lua_next(_InScriptContext,2)!=0){ UAssetUserData* item = (UAssetUserData*)wLua::FLuaUtils::GetUObject(_InScriptContext,-1,"AssetUserData");; ret.Add(item); lua_pop(_InScriptContext,1);  } return ret; }(InScriptContext);;
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_ThumbnailInfo(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MaterialInterface",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MaterialInterface must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UMaterialInterface::StaticClass(), TEXT("ThumbnailInfo"));
	if(!Property) { check(false); return 0;}
	UThumbnailInfo* PropertyValue;
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaUtils::ReturnUObject(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_ThumbnailInfo(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MaterialInterface",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MaterialInterface must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UMaterialInterface::StaticClass(), TEXT("ThumbnailInfo"));
	if(!Property) { check(false); return 0;}
	UThumbnailInfo* PropertyValue = (UThumbnailInfo*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"ThumbnailInfo");;
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_AssetImportData(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MaterialInterface",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MaterialInterface must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UMaterialInterface::StaticClass(), TEXT("AssetImportData"));
	if(!Property) { check(false); return 0;}
	UAssetImportData* PropertyValue;
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaUtils::ReturnUObject(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_AssetImportData(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MaterialInterface",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MaterialInterface must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UMaterialInterface::StaticClass(), TEXT("AssetImportData"));
	if(!Property) { check(false); return 0;}
	UAssetImportData* PropertyValue = (UAssetImportData*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"AssetImportData");;
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Class(lua_State* InScriptContext)
{
	UClass* Class = UMaterialInterface::StaticClass();
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Class);
	return 1;
}

const luaL_Reg Lib_Funcs[] =
{
	{ "Class", Class },
	{ "SetForceMipLevelsToBeResident", SetForceMipLevelsToBeResident },
	{ "GetPhysicalMaterial", GetPhysicalMaterial },
	{ "GetBaseMaterial", GetBaseMaterial },
	{ "Get_SubsurfaceProfile", Get_SubsurfaceProfile },
	{ "Get_AssetUserData", Get_AssetUserData },
	{ "Set_AssetUserData", Set_AssetUserData },
	{ "Get_ThumbnailInfo", Get_ThumbnailInfo },
	{ "Set_ThumbnailInfo", Set_ThumbnailInfo },
	{ "Get_AssetImportData", Get_AssetImportData },
	{ "Set_AssetImportData", Set_AssetImportData },
	{ "is_nil", wLua::LuaStatic::isnil },
	{ "__gc", wLua::LuaStatic::removeUClassFrameCache },
	{ NULL, NULL }
};

void Register(lua_State *InScriptContext)
{
	lua_newtable(InScriptContext);
	luaL_register(InScriptContext, NULL, Lib_Funcs);
	AzureHelpFuncs::AuxRegister(InScriptContext, "MaterialInterface");
}
void SetMtLink(lua_State *InScriptContext)
{
	AzureHelpFuncs::AuxSetMtLink(InScriptContext, "MaterialInterface", "Object",USERDATATYPE_UOBJECT);
}

}