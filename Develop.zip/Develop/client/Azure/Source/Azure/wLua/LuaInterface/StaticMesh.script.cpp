#include "Azure.h"
#include "Utility/help_funcs.h"
#include "wLua/UObjectHeaders.h"
#include "Engine/StaticMesh.h"
#include "AzureLuaIntegration.h"

namespace LuaStaticMesh
{
int32 GetNumSections(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"StaticMesh",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"StaticMesh must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		int32 InLOD;
		int32 ReturnValue;
	} Params;
	Params.InLOD = (luaL_checkint(InScriptContext, 2));
	UStaticMesh * This = (UStaticMesh *)Obj;
	Params.ReturnValue = This->GetNumSections(Params.InLOD);
	lua_pushinteger(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetNumLODs(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"StaticMesh",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"StaticMesh must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		int32 ReturnValue;
	} Params;
	UStaticMesh * This = (UStaticMesh *)Obj;
	Params.ReturnValue = This->GetNumLODs();
	lua_pushinteger(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetMaterialIndex(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"StaticMesh",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"StaticMesh must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FName MaterialSlotName;
		int32 ReturnValue;
	} Params;
	Params.MaterialSlotName = FName(UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 2)));
	UStaticMesh * This = (UStaticMesh *)Obj;
	Params.ReturnValue = This->GetMaterialIndex(Params.MaterialSlotName);
	lua_pushinteger(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetMaterial(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"StaticMesh",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"StaticMesh must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		int32 MaterialIndex;
		UMaterialInterface* ReturnValue = nullptr;
	} Params;
	Params.MaterialIndex = (luaL_checkint(InScriptContext, 2));
	UStaticMesh * This = (UStaticMesh *)Obj;
	Params.ReturnValue = This->GetMaterial(Params.MaterialIndex);
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 Get_LODGroup(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"StaticMesh",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"StaticMesh must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UStaticMesh::StaticClass(), TEXT("LODGroup"));
	if(!Property) { check(false); return 0;}
	FName PropertyValue = FName();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushstring(InScriptContext, TCHAR_TO_UTF8(*PropertyValue.ToString()));
	return 1;
}

int32 Set_LODGroup(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"StaticMesh",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"StaticMesh must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UStaticMesh::StaticClass(), TEXT("LODGroup"));
	if(!Property) { check(false); return 0;}
	FName PropertyValue = FName(UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 2)));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bShareLightmap(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"StaticMesh",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"StaticMesh must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UStaticMesh::StaticClass(), TEXT("bShareLightmap"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bShareLightmap(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"StaticMesh",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"StaticMesh must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UStaticMesh::StaticClass(), TEXT("bShareLightmap"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_LpvBiasMultiplier(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"StaticMesh",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"StaticMesh must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UStaticMesh::StaticClass(), TEXT("LpvBiasMultiplier"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_LightMapResolution(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"StaticMesh",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"StaticMesh must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UStaticMesh::StaticClass(), TEXT("LightMapResolution"));
	if(!Property) { check(false); return 0;}
	int32 PropertyValue = int32();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushinteger(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_LightMapResolution(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"StaticMesh",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"StaticMesh must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UStaticMesh::StaticClass(), TEXT("LightMapResolution"));
	if(!Property) { check(false); return 0;}
	int32 PropertyValue = (luaL_checkint(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_LightMapCoordinateIndex(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"StaticMesh",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"StaticMesh must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UStaticMesh::StaticClass(), TEXT("LightMapCoordinateIndex"));
	if(!Property) { check(false); return 0;}
	int32 PropertyValue = int32();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushinteger(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_LightMapCoordinateIndex(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"StaticMesh",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"StaticMesh must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UStaticMesh::StaticClass(), TEXT("LightMapCoordinateIndex"));
	if(!Property) { check(false); return 0;}
	int32 PropertyValue = (luaL_checkint(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_DistanceFieldSelfShadowBias(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"StaticMesh",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"StaticMesh must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UStaticMesh::StaticClass(), TEXT("DistanceFieldSelfShadowBias"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_DistanceFieldSelfShadowBias(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"StaticMesh",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"StaticMesh must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UStaticMesh::StaticClass(), TEXT("DistanceFieldSelfShadowBias"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_BodySetup(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"StaticMesh",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"StaticMesh must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UStaticMesh::StaticClass(), TEXT("BodySetup"));
	if(!Property) { check(false); return 0;}
	UBodySetup* PropertyValue;
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaUtils::ReturnUObject(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_BodySetup(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"StaticMesh",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"StaticMesh must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UStaticMesh::StaticClass(), TEXT("BodySetup"));
	if(!Property) { check(false); return 0;}
	UBodySetup* PropertyValue = (UBodySetup*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"BodySetup");;
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_LODForCollision(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"StaticMesh",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"StaticMesh must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UStaticMesh::StaticClass(), TEXT("LODForCollision"));
	if(!Property) { check(false); return 0;}
	int32 PropertyValue = int32();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushinteger(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_LODForCollision(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"StaticMesh",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"StaticMesh must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UStaticMesh::StaticClass(), TEXT("LODForCollision"));
	if(!Property) { check(false); return 0;}
	int32 PropertyValue = (luaL_checkint(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bGenerateMeshDistanceField(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"StaticMesh",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"StaticMesh must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UStaticMesh::StaticClass(), TEXT("bGenerateMeshDistanceField"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bGenerateMeshDistanceField(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"StaticMesh",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"StaticMesh must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UStaticMesh::StaticClass(), TEXT("bGenerateMeshDistanceField"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bHasNavigationData(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"StaticMesh",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"StaticMesh must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UStaticMesh::StaticClass(), TEXT("bHasNavigationData"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bHasNavigationData(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"StaticMesh",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"StaticMesh must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UStaticMesh::StaticClass(), TEXT("bHasNavigationData"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bSupportUniformlyDistributedSampling(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"StaticMesh",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"StaticMesh must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UStaticMesh::StaticClass(), TEXT("bSupportUniformlyDistributedSampling"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bSupportUniformlyDistributedSampling(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"StaticMesh",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"StaticMesh must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UStaticMesh::StaticClass(), TEXT("bSupportUniformlyDistributedSampling"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bAllowCPUAccess(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"StaticMesh",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"StaticMesh must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UStaticMesh::StaticClass(), TEXT("bAllowCPUAccess"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bAllowCPUAccess(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"StaticMesh",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"StaticMesh must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UStaticMesh::StaticClass(), TEXT("bAllowCPUAccess"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_AssetImportData(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"StaticMesh",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"StaticMesh must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UStaticMesh::StaticClass(), TEXT("AssetImportData"));
	if(!Property) { check(false); return 0;}
	UAssetImportData* PropertyValue;
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaUtils::ReturnUObject(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_AssetImportData(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"StaticMesh",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"StaticMesh must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UStaticMesh::StaticClass(), TEXT("AssetImportData"));
	if(!Property) { check(false); return 0;}
	UAssetImportData* PropertyValue = (UAssetImportData*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"AssetImportData");;
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_ThumbnailInfo(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"StaticMesh",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"StaticMesh must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UStaticMesh::StaticClass(), TEXT("ThumbnailInfo"));
	if(!Property) { check(false); return 0;}
	UThumbnailInfo* PropertyValue;
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaUtils::ReturnUObject(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_ThumbnailInfo(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"StaticMesh",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"StaticMesh must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UStaticMesh::StaticClass(), TEXT("ThumbnailInfo"));
	if(!Property) { check(false); return 0;}
	UThumbnailInfo* PropertyValue = (UThumbnailInfo*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"ThumbnailInfo");;
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bCustomizedCollision(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"StaticMesh",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"StaticMesh must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UStaticMesh::StaticClass(), TEXT("bCustomizedCollision"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = bool();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bCustomizedCollision(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"StaticMesh",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"StaticMesh must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UStaticMesh::StaticClass(), TEXT("bCustomizedCollision"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_LODForOccluderMesh(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"StaticMesh",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"StaticMesh must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UStaticMesh::StaticClass(), TEXT("LODForOccluderMesh"));
	if(!Property) { check(false); return 0;}
	int32 PropertyValue = int32();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushinteger(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_LODForOccluderMesh(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"StaticMesh",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"StaticMesh must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UStaticMesh::StaticClass(), TEXT("LODForOccluderMesh"));
	if(!Property) { check(false); return 0;}
	int32 PropertyValue = (luaL_checkint(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_PositiveBoundsExtension(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"StaticMesh",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"StaticMesh must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UStaticMesh::StaticClass(), TEXT("PositiveBoundsExtension"));
	if(!Property) { check(false); return 0;}
	FVector PropertyValue = FVector();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaVector::Return(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_PositiveBoundsExtension(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"StaticMesh",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"StaticMesh must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UStaticMesh::StaticClass(), TEXT("PositiveBoundsExtension"));
	if(!Property) { check(false); return 0;}
	FVector PropertyValue = (wLua::FLuaVector::Get(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_NegativeBoundsExtension(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"StaticMesh",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"StaticMesh must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UStaticMesh::StaticClass(), TEXT("NegativeBoundsExtension"));
	if(!Property) { check(false); return 0;}
	FVector PropertyValue = FVector();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaVector::Return(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_NegativeBoundsExtension(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"StaticMesh",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"StaticMesh must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UStaticMesh::StaticClass(), TEXT("NegativeBoundsExtension"));
	if(!Property) { check(false); return 0;}
	FVector PropertyValue = (wLua::FLuaVector::Get(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_AssetUserData(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"StaticMesh",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"StaticMesh must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UStaticMesh::StaticClass(), TEXT("AssetUserData"));
	if(!Property) { check(false); return 0;}
	TArray<UAssetUserData*> PropertyValue;
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	{lua_newtable(InScriptContext); int i = 1; for(auto It = PropertyValue.CreateConstIterator(); It; ++It,++i) {  wLua::FLuaUtils::ReturnUObject(InScriptContext, (*It)); lua_rawseti(InScriptContext,-2,i);     }  }
	return 1;
}

int32 Set_AssetUserData(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"StaticMesh",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"StaticMesh must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UStaticMesh::StaticClass(), TEXT("AssetUserData"));
	if(!Property) { check(false); return 0;}
	TArray<UAssetUserData*> PropertyValue = [](lua_State * _InScriptContext){ TArray<UAssetUserData*> ret; lua_pushnil(_InScriptContext); while(lua_next(_InScriptContext,2)!=0){ UAssetUserData* item = (UAssetUserData*)wLua::FLuaUtils::GetUObject(_InScriptContext,-1,"AssetUserData");; ret.Add(item); lua_pop(_InScriptContext,1);  } return ret; }(InScriptContext);;
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_EditableMesh(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"StaticMesh",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"StaticMesh must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UStaticMesh::StaticClass(), TEXT("EditableMesh"));
	if(!Property) { check(false); return 0;}
	UObject* PropertyValue;
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaUtils::ReturnUObject(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_EditableMesh(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"StaticMesh",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"StaticMesh must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UStaticMesh::StaticClass(), TEXT("EditableMesh"));
	if(!Property) { check(false); return 0;}
	UObject* PropertyValue = (UObject*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"Object");;
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 New(lua_State* InScriptContext)
{
	UObject* Outer = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Object");
	FName Name = FName(luaL_checkstring(InScriptContext, 2));
	UObject* Obj = NewObject<UStaticMesh>(Outer, Name);
	wLua::FLuaUtils::ReturnUObject(InScriptContext,Obj);
	return 1;
}

int32 Destroy(lua_State* InScriptContext)
{
	return 0;
}

int32 Class(lua_State* InScriptContext)
{
	UClass* Class = UStaticMesh::StaticClass();
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Class);
	return 1;
}

const luaL_Reg Lib_Funcs[] =
{
	{ "New", New },
	{ "Destroy", Destroy },
	{ "Class", Class },
	{ "GetNumSections", GetNumSections },
	{ "GetNumLODs", GetNumLODs },
	{ "GetMaterialIndex", GetMaterialIndex },
	{ "GetMaterial", GetMaterial },
	{ "Get_LODGroup", Get_LODGroup },
	{ "Set_LODGroup", Set_LODGroup },
	{ "Get_bShareLightmap", Get_bShareLightmap },
	{ "Set_bShareLightmap", Set_bShareLightmap },
	{ "Get_LpvBiasMultiplier", Get_LpvBiasMultiplier },
	{ "Get_LightMapResolution", Get_LightMapResolution },
	{ "Set_LightMapResolution", Set_LightMapResolution },
	{ "Get_LightMapCoordinateIndex", Get_LightMapCoordinateIndex },
	{ "Set_LightMapCoordinateIndex", Set_LightMapCoordinateIndex },
	{ "Get_DistanceFieldSelfShadowBias", Get_DistanceFieldSelfShadowBias },
	{ "Set_DistanceFieldSelfShadowBias", Set_DistanceFieldSelfShadowBias },
	{ "Get_BodySetup", Get_BodySetup },
	{ "Set_BodySetup", Set_BodySetup },
	{ "Get_LODForCollision", Get_LODForCollision },
	{ "Set_LODForCollision", Set_LODForCollision },
	{ "Get_bGenerateMeshDistanceField", Get_bGenerateMeshDistanceField },
	{ "Set_bGenerateMeshDistanceField", Set_bGenerateMeshDistanceField },
	{ "Get_bHasNavigationData", Get_bHasNavigationData },
	{ "Set_bHasNavigationData", Set_bHasNavigationData },
	{ "Get_bSupportUniformlyDistributedSampling", Get_bSupportUniformlyDistributedSampling },
	{ "Set_bSupportUniformlyDistributedSampling", Set_bSupportUniformlyDistributedSampling },
	{ "Get_bAllowCPUAccess", Get_bAllowCPUAccess },
	{ "Set_bAllowCPUAccess", Set_bAllowCPUAccess },
	{ "Get_AssetImportData", Get_AssetImportData },
	{ "Set_AssetImportData", Set_AssetImportData },
	{ "Get_ThumbnailInfo", Get_ThumbnailInfo },
	{ "Set_ThumbnailInfo", Set_ThumbnailInfo },
	{ "Get_bCustomizedCollision", Get_bCustomizedCollision },
	{ "Set_bCustomizedCollision", Set_bCustomizedCollision },
	{ "Get_LODForOccluderMesh", Get_LODForOccluderMesh },
	{ "Set_LODForOccluderMesh", Set_LODForOccluderMesh },
	{ "Get_PositiveBoundsExtension", Get_PositiveBoundsExtension },
	{ "Set_PositiveBoundsExtension", Set_PositiveBoundsExtension },
	{ "Get_NegativeBoundsExtension", Get_NegativeBoundsExtension },
	{ "Set_NegativeBoundsExtension", Set_NegativeBoundsExtension },
	{ "Get_AssetUserData", Get_AssetUserData },
	{ "Set_AssetUserData", Set_AssetUserData },
	{ "Get_EditableMesh", Get_EditableMesh },
	{ "Set_EditableMesh", Set_EditableMesh },
	{ "is_nil", wLua::LuaStatic::isnil },
	{ "__gc", wLua::LuaStatic::removeUClassFrameCache },
	{ NULL, NULL }
};

void Register(lua_State *InScriptContext)
{
	lua_newtable(InScriptContext);
	luaL_register(InScriptContext, NULL, Lib_Funcs);
	AzureHelpFuncs::AuxRegister(InScriptContext, "StaticMesh");
}
void SetMtLink(lua_State *InScriptContext)
{
	AzureHelpFuncs::AuxSetMtLink(InScriptContext, "StaticMesh", "Object",USERDATATYPE_UOBJECT);
}

}