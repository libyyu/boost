#include "Azure.h"
#include "Utility/help_funcs.h"
#include "wLua/UObjectHeaders.h"
#include "AzureSplitScrollList.h"
#include "AzureLuaIntegration.h"

namespace LuaAzureSplitScrollList
{
int32 setUpdateFunc(lua_State*);

int32 SetSuccess(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureSplitScrollList",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureSplitScrollList must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool InValue;
	} Params;
	Params.InValue = !!(lua_toboolean(InScriptContext, 2));
#if UE_GAME
	UAzureSplitScrollList * This = (UAzureSplitScrollList *)Obj;
	This->SetSuccess(Params.InValue);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetSuccess"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(bool*)(params.GetStructMemory() + 0) = Params.InValue;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.InValue = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetFirstIndexByColumeIndex(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureSplitScrollList",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureSplitScrollList must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		TArray<int32> InColumeIndex;
		TArray<float> InOffset;
		bool bAnimate;
		EDescendantScrollDestination ScrollDestination;
		float ForcePhysicalOffset;
	} Params;
	Params.InColumeIndex = [](lua_State * _InScriptContext){ TArray<int32> ret; lua_pushnil(_InScriptContext); while(lua_next(_InScriptContext,2)!=0){ int32 item = (luaL_checkint(_InScriptContext, -1)); ret.Add(item); lua_pop(_InScriptContext,1);  } return ret; }(InScriptContext);;
	Params.InOffset = [](lua_State * _InScriptContext){ TArray<float> ret; lua_pushnil(_InScriptContext); while(lua_next(_InScriptContext,3)!=0){ float item = (float)(luaL_checknumber(_InScriptContext, -1)); ret.Add(item); lua_pop(_InScriptContext,1);  } return ret; }(InScriptContext);;
	Params.bAnimate = lua_isnoneornil(InScriptContext,4) ? bool(false) : !!(lua_toboolean(InScriptContext, 4));
	Params.ScrollDestination = lua_isnoneornil(InScriptContext,5) ? EDescendantScrollDestination(EDescendantScrollDestination::TopOrLeft) : (EDescendantScrollDestination)(luaL_checkint(InScriptContext, 5));
	Params.ForcePhysicalOffset = lua_isnoneornil(InScriptContext,6) ? float(0.000000) : (float)(luaL_checknumber(InScriptContext, 6));
#if UE_GAME
	UAzureSplitScrollList * This = (UAzureSplitScrollList *)Obj;
	This->SetFirstIndexByColumeIndex(Params.InColumeIndex,Params.InOffset,Params.bAnimate,Params.ScrollDestination,Params.ForcePhysicalOffset);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetFirstIndexByColumeIndex"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(TArray<int32>*)(params.GetStructMemory() + 0) = Params.InColumeIndex;
		*(TArray<float>*)(params.GetStructMemory() + 16) = Params.InOffset;
		*(bool*)(params.GetStructMemory() + 32) = Params.bAnimate;
		*(EDescendantScrollDestination*)(params.GetStructMemory() + 33) = Params.ScrollDestination;
		*(float*)(params.GetStructMemory() + 36) = Params.ForcePhysicalOffset;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.InColumeIndex = *(TArray<int32>*)(params.GetStructMemory() + 0);
		Params.InOffset = *(TArray<float>*)(params.GetStructMemory() + 16);
		Params.bAnimate = *(bool*)(params.GetStructMemory() + 32);
		Params.ScrollDestination = *(EDescendantScrollDestination*)(params.GetStructMemory() + 33);
		Params.ForcePhysicalOffset = *(float*)(params.GetStructMemory() + 36);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetCount(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureSplitScrollList",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureSplitScrollList must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		int32 InCount;
	} Params;
	Params.InCount = (luaL_checkint(InScriptContext, 2));
#if UE_GAME
	UAzureSplitScrollList * This = (UAzureSplitScrollList *)Obj;
	This->SetCount(Params.InCount);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetCount"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(int32*)(params.GetStructMemory() + 0) = Params.InCount;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.InCount = *(int32*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 ScrollWidgetIntoView(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureSplitScrollList",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureSplitScrollList must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		UWidget* InWidgetToFind = nullptr;
		bool InAnimateScroll;
		EDescendantScrollDestination InScrollDestination;
	} Params;
	Params.InWidgetToFind = (UWidget*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"Widget");;
	Params.InAnimateScroll = lua_isnoneornil(InScriptContext,3) ? bool(true) : !!(lua_toboolean(InScriptContext, 3));
	Params.InScrollDestination = lua_isnoneornil(InScriptContext,4) ? EDescendantScrollDestination(EDescendantScrollDestination::IntoView) : (EDescendantScrollDestination)(luaL_checkint(InScriptContext, 4));
#if UE_GAME
	UAzureSplitScrollList * This = (UAzureSplitScrollList *)Obj;
	This->ScrollWidgetIntoView(Params.InWidgetToFind,Params.InAnimateScroll,Params.InScrollDestination);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("ScrollWidgetIntoView"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(UWidget**)(params.GetStructMemory() + 0) = Params.InWidgetToFind;
		*(bool*)(params.GetStructMemory() + 8) = Params.InAnimateScroll;
		*(EDescendantScrollDestination*)(params.GetStructMemory() + 9) = Params.InScrollDestination;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.InWidgetToFind = *(UWidget**)(params.GetStructMemory() + 0);
		Params.InAnimateScroll = *(bool*)(params.GetStructMemory() + 8);
		Params.InScrollDestination = *(EDescendantScrollDestination*)(params.GetStructMemory() + 9);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 ScrollToEnd(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureSplitScrollList",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureSplitScrollList must be non-null"); lua_error(InScriptContext);  return 0;}
#if UE_GAME
	UAzureSplitScrollList * This = (UAzureSplitScrollList *)Obj;
	This->ScrollToEnd();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("ScrollToEnd"));
	if(!Function) { check(false); return 0;}
	Obj->ProcessEvent(Function, NULL);
#endif
	return 0;
}

int32 ScrollToBegin(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureSplitScrollList",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureSplitScrollList must be non-null"); lua_error(InScriptContext);  return 0;}
#if UE_GAME
	UAzureSplitScrollList * This = (UAzureSplitScrollList *)Obj;
	This->ScrollToBegin();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("ScrollToBegin"));
	if(!Function) { check(false); return 0;}
	Obj->ProcessEvent(Function, NULL);
#endif
	return 0;
}

int32 IsScrollAtEnd(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureSplitScrollList",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureSplitScrollList must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool ReturnValue;
	} Params;
#if UE_GAME
	UAzureSplitScrollList * This = (UAzureSplitScrollList *)Obj;
	Params.ReturnValue = This->IsScrollAtEnd();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("IsScrollAtEnd"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushboolean(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 IsScrollAtBegin(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureSplitScrollList",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureSplitScrollList must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool ReturnValue;
	} Params;
#if UE_GAME
	UAzureSplitScrollList * This = (UAzureSplitScrollList *)Obj;
	Params.ReturnValue = This->IsScrollAtBegin();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("IsScrollAtBegin"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushboolean(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 IsEmpty(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureSplitScrollList",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureSplitScrollList must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool ReturnValue;
	} Params;
#if UE_GAME
	UAzureSplitScrollList * This = (UAzureSplitScrollList *)Obj;
	Params.ReturnValue = This->IsEmpty();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("IsEmpty"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushboolean(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 IsCanScroll(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureSplitScrollList",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureSplitScrollList must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool ReturnValue;
	} Params;
#if UE_GAME
	UAzureSplitScrollList * This = (UAzureSplitScrollList *)Obj;
	Params.ReturnValue = This->IsCanScroll();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("IsCanScroll"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushboolean(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetTailIndex(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureSplitScrollList",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureSplitScrollList must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		int32 ReturnValue;
	} Params;
#if UE_GAME
	UAzureSplitScrollList * This = (UAzureSplitScrollList *)Obj;
	Params.ReturnValue = This->GetTailIndex();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetTailIndex"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(int32*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushinteger(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetItemByIndex(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureSplitScrollList",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureSplitScrollList must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		int32 InIndex;
		UUserWidget* ReturnValue = nullptr;
	} Params;
	Params.InIndex = (luaL_checkint(InScriptContext, 2));
#if UE_GAME
	UAzureSplitScrollList * This = (UAzureSplitScrollList *)Obj;
	Params.ReturnValue = This->GetItemByIndex(Params.InIndex);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetItemByIndex"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(int32*)(params.GetStructMemory() + 0) = Params.InIndex;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.InIndex = *(int32*)(params.GetStructMemory() + 0);
		Params.ReturnValue = *(UUserWidget**)(params.GetStructMemory() + 8);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetHeadIndex(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureSplitScrollList",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureSplitScrollList must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		int32 ReturnValue;
	} Params;
#if UE_GAME
	UAzureSplitScrollList * This = (UAzureSplitScrollList *)Obj;
	Params.ReturnValue = This->GetHeadIndex();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetHeadIndex"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(int32*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushinteger(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetFirstIndex(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureSplitScrollList",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureSplitScrollList must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		int32 ReturnValue;
	} Params;
#if UE_GAME
	UAzureSplitScrollList * This = (UAzureSplitScrollList *)Obj;
	Params.ReturnValue = This->GetFirstIndex();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetFirstIndex"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(int32*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushinteger(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetCount(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureSplitScrollList",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureSplitScrollList must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		int32 ReturnValue;
	} Params;
#if UE_GAME
	UAzureSplitScrollList * This = (UAzureSplitScrollList *)Obj;
	Params.ReturnValue = This->GetCount();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetCount"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(int32*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushinteger(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 ForceUpdate(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureSplitScrollList",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureSplitScrollList must be non-null"); lua_error(InScriptContext);  return 0;}
#if UE_GAME
	UAzureSplitScrollList * This = (UAzureSplitScrollList *)Obj;
	This->ForceUpdate();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("ForceUpdate"));
	if(!Function) { check(false); return 0;}
	Obj->ProcessEvent(Function, NULL);
#endif
	return 0;
}

int32 ForceStopInertialScroll(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureSplitScrollList",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureSplitScrollList must be non-null"); lua_error(InScriptContext);  return 0;}
#if UE_GAME
	UAzureSplitScrollList * This = (UAzureSplitScrollList *)Obj;
	This->ForceStopInertialScroll();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("ForceStopInertialScroll"));
	if(!Function) { check(false); return 0;}
	Obj->ProcessEvent(Function, NULL);
#endif
	return 0;
}

int32 FindWidgetByIndex(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureSplitScrollList",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureSplitScrollList must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		int32 InIndex;
		UUserWidget* ReturnValue = nullptr;
	} Params;
	Params.InIndex = (luaL_checkint(InScriptContext, 2));
#if UE_GAME
	UAzureSplitScrollList * This = (UAzureSplitScrollList *)Obj;
	Params.ReturnValue = This->FindWidgetByIndex(Params.InIndex);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("FindWidgetByIndex"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(int32*)(params.GetStructMemory() + 0) = Params.InIndex;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.InIndex = *(int32*)(params.GetStructMemory() + 0);
		Params.ReturnValue = *(UUserWidget**)(params.GetStructMemory() + 8);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 FindIndexByWidget(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureSplitScrollList",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureSplitScrollList must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		UWidget* InWidget = nullptr;
		int32 ReturnValue;
	} Params;
	Params.InWidget = (UWidget*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"Widget");;
#if UE_GAME
	UAzureSplitScrollList * This = (UAzureSplitScrollList *)Obj;
	Params.ReturnValue = This->FindIndexByWidget(Params.InWidget);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("FindIndexByWidget"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(UWidget**)(params.GetStructMemory() + 0) = Params.InWidget;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.InWidget = *(UWidget**)(params.GetStructMemory() + 0);
		Params.ReturnValue = *(int32*)(params.GetStructMemory() + 8);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushinteger(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 Clear(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureSplitScrollList",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureSplitScrollList must be non-null"); lua_error(InScriptContext);  return 0;}
#if UE_GAME
	UAzureSplitScrollList * This = (UAzureSplitScrollList *)Obj;
	This->Clear();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("Clear"));
	if(!Function) { check(false); return 0;}
	Obj->ProcessEvent(Function, NULL);
#endif
	return 0;
}

int32 Get_TemplateClass(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureSplitScrollList",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureSplitScrollList must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzureSplitScrollList::StaticClass(), TEXT("TemplateClass"));
	if(!Property) { check(false); return 0;}
	TSubclassOf<UUserWidget>  PropertyValue = TSubclassOf<UUserWidget> ();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaUtils::ReturnUObject(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_TemplateClass(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureSplitScrollList",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureSplitScrollList must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzureSplitScrollList::StaticClass(), TEXT("TemplateClass"));
	if(!Property) { check(false); return 0;}
	TSubclassOf<UUserWidget>  PropertyValue = (UClass*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"Class");;
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_Orientation(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureSplitScrollList",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureSplitScrollList must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzureSplitScrollList::StaticClass(), TEXT("Orientation"));
	if(!Property) { check(false); return 0;}
	TEnumAsByte<EOrientation> PropertyValue = TEnumAsByte<EOrientation>();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushinteger(InScriptContext, (int)PropertyValue);
	return 1;
}

int32 Get_ScrollBarVisibility(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureSplitScrollList",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureSplitScrollList must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzureSplitScrollList::StaticClass(), TEXT("ScrollBarVisibility"));
	if(!Property) { check(false); return 0;}
	ESlateVisibility PropertyValue = ESlateVisibility();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushinteger(InScriptContext, (int)PropertyValue);
	return 1;
}

int32 Get_ConsumeMouseWheel(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureSplitScrollList",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureSplitScrollList must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzureSplitScrollList::StaticClass(), TEXT("ConsumeMouseWheel"));
	if(!Property) { check(false); return 0;}
	EConsumeMouseWheel PropertyValue = EConsumeMouseWheel();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushinteger(InScriptContext, (int)PropertyValue);
	return 1;
}

int32 Get_ScrollbarThickness(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureSplitScrollList",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureSplitScrollList must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzureSplitScrollList::StaticClass(), TEXT("ScrollbarThickness"));
	if(!Property) { check(false); return 0;}
	FVector2D PropertyValue = FVector2D();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaVector2D::Return(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_AlwaysShowScrollbar(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureSplitScrollList",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureSplitScrollList must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzureSplitScrollList::StaticClass(), TEXT("AlwaysShowScrollbar"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = bool();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_AllowOverscroll(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureSplitScrollList",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureSplitScrollList must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzureSplitScrollList::StaticClass(), TEXT("AllowOverscroll"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = bool();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_bUseOverscrollWhenContentIsShot(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureSplitScrollList",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureSplitScrollList must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzureSplitScrollList::StaticClass(), TEXT("bUseOverscrollWhenContentIsShot"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = bool();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_bTriggerBlueprintScrollEvent(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureSplitScrollList",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureSplitScrollList must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzureSplitScrollList::StaticClass(), TEXT("bTriggerBlueprintScrollEvent"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = bool();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_bIsNeedCaptureMovementAxisAligned(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureSplitScrollList",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureSplitScrollList must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzureSplitScrollList::StaticClass(), TEXT("bIsNeedCaptureMovementAxisAligned"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = bool();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_bIsReleaseCaptureWhenScrollToEnd(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureSplitScrollList",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureSplitScrollList must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzureSplitScrollList::StaticClass(), TEXT("bIsReleaseCaptureWhenScrollToEnd"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = bool();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_bScrollEvent(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureSplitScrollList",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureSplitScrollList must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzureSplitScrollList::StaticClass(), TEXT("bScrollEvent"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = bool();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_ColumeSplit(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureSplitScrollList",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureSplitScrollList must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzureSplitScrollList::StaticClass(), TEXT("ColumeSplit"));
	if(!Property) { check(false); return 0;}
	int32 PropertyValue = int32();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushinteger(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_CustomizeEachColume(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureSplitScrollList",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureSplitScrollList must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzureSplitScrollList::StaticClass(), TEXT("CustomizeEachColume"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = bool();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Call_OnBPUpdateSplitItem(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureSplitScrollList",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureSplitScrollList must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		UUserWidget* Item = nullptr;
		int32 Index;
		int32 ColumeId;
		int32 ColumeIndex;
	} Params;
	Params.Item = (UUserWidget*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"UserWidget");;
	Params.Index = (luaL_checkint(InScriptContext, 3));
	Params.ColumeId = (luaL_checkint(InScriptContext, 4));
	Params.ColumeIndex = (luaL_checkint(InScriptContext, 5));
	UAzureSplitScrollList * This = (UAzureSplitScrollList *)Obj;
	This->OnBPUpdateSplitItem.Broadcast(Params.Item,Params.Index,Params.ColumeId,Params.ColumeIndex);
	return 0;
}

int32 Call_OnBPHideSplitItem(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureSplitScrollList",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureSplitScrollList must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		UUserWidget* Item = nullptr;
		int32 Index;
		int32 ColumeId;
		int32 ColumeIndex;
	} Params;
	Params.Item = (UUserWidget*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"UserWidget");;
	Params.Index = (luaL_checkint(InScriptContext, 3));
	Params.ColumeId = (luaL_checkint(InScriptContext, 4));
	Params.ColumeIndex = (luaL_checkint(InScriptContext, 5));
	UAzureSplitScrollList * This = (UAzureSplitScrollList *)Obj;
	This->OnBPHideSplitItem.Broadcast(Params.Item,Params.Index,Params.ColumeId,Params.ColumeIndex);
	return 0;
}

int32 New(lua_State* InScriptContext)
{
	UObject* Outer = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Object");
	FName Name = FName(luaL_checkstring(InScriptContext, 2));
	UObject* Obj = NewObject<UAzureSplitScrollList>(Outer, Name);
	wLua::FLuaUtils::ReturnUObject(InScriptContext,Obj);
	return 1;
}

int32 Destroy(lua_State* InScriptContext)
{
	return 0;
}

int32 Class(lua_State* InScriptContext)
{
	UClass* Class = UAzureSplitScrollList::StaticClass();
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Class);
	return 1;
}

const luaL_Reg Lib_Funcs[] =
{
	{ "New", New },
	{ "Destroy", Destroy },
	{ "Class", Class },
	{ "SetSuccess", SetSuccess },
	{ "SetFirstIndexByColumeIndex", SetFirstIndexByColumeIndex },
	{ "SetCount", SetCount },
	{ "ScrollWidgetIntoView", ScrollWidgetIntoView },
	{ "ScrollToEnd", ScrollToEnd },
	{ "ScrollToBegin", ScrollToBegin },
	{ "IsScrollAtEnd", IsScrollAtEnd },
	{ "IsScrollAtBegin", IsScrollAtBegin },
	{ "IsEmpty", IsEmpty },
	{ "IsCanScroll", IsCanScroll },
	{ "GetTailIndex", GetTailIndex },
	{ "GetItemByIndex", GetItemByIndex },
	{ "GetHeadIndex", GetHeadIndex },
	{ "GetFirstIndex", GetFirstIndex },
	{ "GetCount", GetCount },
	{ "ForceUpdate", ForceUpdate },
	{ "ForceStopInertialScroll", ForceStopInertialScroll },
	{ "FindWidgetByIndex", FindWidgetByIndex },
	{ "FindIndexByWidget", FindIndexByWidget },
	{ "Clear", Clear },
	{ "Get_TemplateClass", Get_TemplateClass },
	{ "Set_TemplateClass", Set_TemplateClass },
	{ "Get_Orientation", Get_Orientation },
	{ "Get_ScrollBarVisibility", Get_ScrollBarVisibility },
	{ "Get_ConsumeMouseWheel", Get_ConsumeMouseWheel },
	{ "Get_ScrollbarThickness", Get_ScrollbarThickness },
	{ "Get_AlwaysShowScrollbar", Get_AlwaysShowScrollbar },
	{ "Get_AllowOverscroll", Get_AllowOverscroll },
	{ "Get_bUseOverscrollWhenContentIsShot", Get_bUseOverscrollWhenContentIsShot },
	{ "Get_bTriggerBlueprintScrollEvent", Get_bTriggerBlueprintScrollEvent },
	{ "Get_bIsNeedCaptureMovementAxisAligned", Get_bIsNeedCaptureMovementAxisAligned },
	{ "Get_bIsReleaseCaptureWhenScrollToEnd", Get_bIsReleaseCaptureWhenScrollToEnd },
	{ "Get_bScrollEvent", Get_bScrollEvent },
	{ "Get_ColumeSplit", Get_ColumeSplit },
	{ "Get_CustomizeEachColume", Get_CustomizeEachColume },
	{ "Call_OnBPUpdateSplitItem", Call_OnBPUpdateSplitItem },
	{ "Call_OnBPHideSplitItem", Call_OnBPHideSplitItem },
	{ "setUpdateFunc", setUpdateFunc },
	{ "is_nil", wLua::LuaStatic::isnil },
	{ "__gc", wLua::LuaStatic::removeUClassFrameCache },
	{ NULL, NULL }
};

void Register(lua_State *InScriptContext)
{
	lua_newtable(InScriptContext);
	luaL_register(InScriptContext, NULL, Lib_Funcs);
	AzureHelpFuncs::AuxRegister(InScriptContext, "AzureSplitScrollList");
}
void SetMtLink(lua_State *InScriptContext)
{
	AzureHelpFuncs::AuxSetMtLink(InScriptContext, "AzureSplitScrollList", "Widget",USERDATATYPE_UOBJECT);
}

}