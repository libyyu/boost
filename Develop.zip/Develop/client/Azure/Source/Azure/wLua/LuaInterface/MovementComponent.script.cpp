#include "Azure.h"
#include "Utility/help_funcs.h"
#include "wLua/UObjectHeaders.h"
#include "GameFramework/MovementComponent.h"
#include "AzureLuaIntegration.h"

namespace LuaMovementComponent
{
int32 StopMovementImmediately(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
#if UE_GAME
	UMovementComponent * This = (UMovementComponent *)Obj;
	This->StopMovementImmediately();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("StopMovementImmediately"));
	if(!Function) { check(false); return 0;}
	Obj->ProcessEvent(Function, NULL);
#endif
	return 0;
}

int32 SnapUpdatedComponentToPlane(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
#if UE_GAME
	UMovementComponent * This = (UMovementComponent *)Obj;
	This->SnapUpdatedComponentToPlane();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SnapUpdatedComponentToPlane"));
	if(!Function) { check(false); return 0;}
	Obj->ProcessEvent(Function, NULL);
#endif
	return 0;
}

int32 SetUpdatedComponent(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		USceneComponent* NewUpdatedComponent = nullptr;
	} Params;
	Params.NewUpdatedComponent = (USceneComponent*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"SceneComponent");;
#if UE_GAME
	UMovementComponent * This = (UMovementComponent *)Obj;
	This->SetUpdatedComponent(Params.NewUpdatedComponent);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetUpdatedComponent"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(USceneComponent**)(params.GetStructMemory() + 0) = Params.NewUpdatedComponent;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.NewUpdatedComponent = *(USceneComponent**)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetPlaneConstraintOrigin(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FVector PlaneOrigin;
	} Params;
	Params.PlaneOrigin = (wLua::FLuaVector::Get(InScriptContext, 2));
#if UE_GAME
	UMovementComponent * This = (UMovementComponent *)Obj;
	This->SetPlaneConstraintOrigin(Params.PlaneOrigin);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetPlaneConstraintOrigin"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FVector*)(params.GetStructMemory() + 0) = Params.PlaneOrigin;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.PlaneOrigin = *(FVector*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetPlaneConstraintNormal(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FVector PlaneNormal;
	} Params;
	Params.PlaneNormal = (wLua::FLuaVector::Get(InScriptContext, 2));
#if UE_GAME
	UMovementComponent * This = (UMovementComponent *)Obj;
	This->SetPlaneConstraintNormal(Params.PlaneNormal);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetPlaneConstraintNormal"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FVector*)(params.GetStructMemory() + 0) = Params.PlaneNormal;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.PlaneNormal = *(FVector*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetPlaneConstraintFromVectors(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FVector Forward;
		FVector Up;
	} Params;
	Params.Forward = (wLua::FLuaVector::Get(InScriptContext, 2));
	Params.Up = (wLua::FLuaVector::Get(InScriptContext, 3));
#if UE_GAME
	UMovementComponent * This = (UMovementComponent *)Obj;
	This->SetPlaneConstraintFromVectors(Params.Forward,Params.Up);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetPlaneConstraintFromVectors"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FVector*)(params.GetStructMemory() + 0) = Params.Forward;
		*(FVector*)(params.GetStructMemory() + 12) = Params.Up;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.Forward = *(FVector*)(params.GetStructMemory() + 0);
		Params.Up = *(FVector*)(params.GetStructMemory() + 12);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetPlaneConstraintEnabled(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool bEnabled;
	} Params;
	Params.bEnabled = !!(lua_toboolean(InScriptContext, 2));
#if UE_GAME
	UMovementComponent * This = (UMovementComponent *)Obj;
	This->SetPlaneConstraintEnabled(Params.bEnabled);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetPlaneConstraintEnabled"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(bool*)(params.GetStructMemory() + 0) = Params.bEnabled;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.bEnabled = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetPlaneConstraintAxisSetting(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		EPlaneConstraintAxisSetting NewAxisSetting;
	} Params;
	Params.NewAxisSetting = (EPlaneConstraintAxisSetting)(luaL_checkint(InScriptContext, 2));
#if UE_GAME
	UMovementComponent * This = (UMovementComponent *)Obj;
	This->SetPlaneConstraintAxisSetting(Params.NewAxisSetting);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetPlaneConstraintAxisSetting"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(EPlaneConstraintAxisSetting*)(params.GetStructMemory() + 0) = Params.NewAxisSetting;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.NewAxisSetting = *(EPlaneConstraintAxisSetting*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 PhysicsVolumeChanged(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		APhysicsVolume* NewVolume = nullptr;
	} Params;
	Params.NewVolume = (APhysicsVolume*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"PhysicsVolume");;
#if UE_GAME
	UMovementComponent * This = (UMovementComponent *)Obj;
	This->PhysicsVolumeChanged(Params.NewVolume);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("PhysicsVolumeChanged"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(APhysicsVolume**)(params.GetStructMemory() + 0) = Params.NewVolume;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.NewVolume = *(APhysicsVolume**)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 K2_GetModifiedMaxSpeed(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float ReturnValue;
	} Params;
#if UE_GAME
	UMovementComponent * This = (UMovementComponent *)Obj;
	Params.ReturnValue = This->K2_GetModifiedMaxSpeed();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("K2_GetModifiedMaxSpeed"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(float*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushnumber(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 IsExceedingMaxSpeed(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float MaxSpeed;
		bool ReturnValue;
	} Params;
	Params.MaxSpeed = (float)(luaL_checknumber(InScriptContext, 2));
#if UE_GAME
	UMovementComponent * This = (UMovementComponent *)Obj;
	Params.ReturnValue = This->IsExceedingMaxSpeed(Params.MaxSpeed);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("IsExceedingMaxSpeed"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(float*)(params.GetStructMemory() + 0) = Params.MaxSpeed;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.MaxSpeed = *(float*)(params.GetStructMemory() + 0);
		Params.ReturnValue = *(bool*)(params.GetStructMemory() + 4);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushboolean(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetPlaneConstraintOrigin(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FVector ReturnValue;
	} Params;
#if UE_GAME
	UMovementComponent * This = (UMovementComponent *)Obj;
	Params.ReturnValue = This->GetPlaneConstraintOrigin();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetPlaneConstraintOrigin"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(FVector*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaVector::Return(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetPlaneConstraintNormal(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FVector ReturnValue;
	} Params;
#if UE_GAME
	UMovementComponent * This = (UMovementComponent *)Obj;
	Params.ReturnValue = This->GetPlaneConstraintNormal();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetPlaneConstraintNormal"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(FVector*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaVector::Return(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetPlaneConstraintAxisSetting(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		EPlaneConstraintAxisSetting ReturnValue;
	} Params;
#if UE_GAME
	UMovementComponent * This = (UMovementComponent *)Obj;
	Params.ReturnValue = This->GetPlaneConstraintAxisSetting();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetPlaneConstraintAxisSetting"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(EPlaneConstraintAxisSetting*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushinteger(InScriptContext, (int)Params.ReturnValue);
	return 1;
}

int32 GetPhysicsVolume(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		APhysicsVolume* ReturnValue = nullptr;
	} Params;
#if UE_GAME
	UMovementComponent * This = (UMovementComponent *)Obj;
	Params.ReturnValue = This->GetPhysicsVolume();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetPhysicsVolume"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(APhysicsVolume**)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetMaxSpeed(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float ReturnValue;
	} Params;
#if UE_GAME
	UMovementComponent * This = (UMovementComponent *)Obj;
	Params.ReturnValue = This->GetMaxSpeed();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetMaxSpeed"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(float*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushnumber(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetGravityZ(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float ReturnValue;
	} Params;
#if UE_GAME
	UMovementComponent * This = (UMovementComponent *)Obj;
	Params.ReturnValue = This->GetGravityZ();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetGravityZ"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(float*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushnumber(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 ConstrainNormalToPlane(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FVector Normal;
		FVector ReturnValue;
	} Params;
	Params.Normal = (wLua::FLuaVector::Get(InScriptContext, 2));
#if UE_GAME
	UMovementComponent * This = (UMovementComponent *)Obj;
	Params.ReturnValue = This->ConstrainNormalToPlane(Params.Normal);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("ConstrainNormalToPlane"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FVector*)(params.GetStructMemory() + 0) = Params.Normal;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.Normal = *(FVector*)(params.GetStructMemory() + 0);
		Params.ReturnValue = *(FVector*)(params.GetStructMemory() + 12);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaVector::Return(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 ConstrainLocationToPlane(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FVector Location;
		FVector ReturnValue;
	} Params;
	Params.Location = (wLua::FLuaVector::Get(InScriptContext, 2));
#if UE_GAME
	UMovementComponent * This = (UMovementComponent *)Obj;
	Params.ReturnValue = This->ConstrainLocationToPlane(Params.Location);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("ConstrainLocationToPlane"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FVector*)(params.GetStructMemory() + 0) = Params.Location;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.Location = *(FVector*)(params.GetStructMemory() + 0);
		Params.ReturnValue = *(FVector*)(params.GetStructMemory() + 12);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaVector::Return(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 ConstrainDirectionToPlane(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FVector Direction;
		FVector ReturnValue;
	} Params;
	Params.Direction = (wLua::FLuaVector::Get(InScriptContext, 2));
#if UE_GAME
	UMovementComponent * This = (UMovementComponent *)Obj;
	Params.ReturnValue = This->ConstrainDirectionToPlane(Params.Direction);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("ConstrainDirectionToPlane"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FVector*)(params.GetStructMemory() + 0) = Params.Direction;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.Direction = *(FVector*)(params.GetStructMemory() + 0);
		Params.ReturnValue = *(FVector*)(params.GetStructMemory() + 12);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaVector::Return(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 Get_UpdatedComponent(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UMovementComponent::StaticClass(), TEXT("UpdatedComponent"));
	if(!Property) { check(false); return 0;}
	USceneComponent* PropertyValue;
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaUtils::ReturnUObject(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_UpdatedPrimitive(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UMovementComponent::StaticClass(), TEXT("UpdatedPrimitive"));
	if(!Property) { check(false); return 0;}
	UPrimitiveComponent* PropertyValue;
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaUtils::ReturnUObject(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_Velocity(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UMovementComponent::StaticClass(), TEXT("Velocity"));
	if(!Property) { check(false); return 0;}
	FVector PropertyValue = FVector();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaVector::Return(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_Velocity(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UMovementComponent::StaticClass(), TEXT("Velocity"));
	if(!Property) { check(false); return 0;}
	FVector PropertyValue = (wLua::FLuaVector::Get(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_PlaneConstraintNormal(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UMovementComponent::StaticClass(), TEXT("PlaneConstraintNormal"));
	if(!Property) { check(false); return 0;}
	FVector PropertyValue = FVector();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaVector::Return(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_PlaneConstraintOrigin(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UMovementComponent::StaticClass(), TEXT("PlaneConstraintOrigin"));
	if(!Property) { check(false); return 0;}
	FVector PropertyValue = FVector();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaVector::Return(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_bUpdateOnlyIfRendered(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UMovementComponent::StaticClass(), TEXT("bUpdateOnlyIfRendered"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bUpdateOnlyIfRendered(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UMovementComponent::StaticClass(), TEXT("bUpdateOnlyIfRendered"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bAutoUpdateTickRegistration(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UMovementComponent::StaticClass(), TEXT("bAutoUpdateTickRegistration"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_bTickBeforeOwner(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UMovementComponent::StaticClass(), TEXT("bTickBeforeOwner"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_bAutoRegisterUpdatedComponent(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UMovementComponent::StaticClass(), TEXT("bAutoRegisterUpdatedComponent"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_bConstrainToPlane(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UMovementComponent::StaticClass(), TEXT("bConstrainToPlane"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_bSnapToPlaneAtStart(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UMovementComponent::StaticClass(), TEXT("bSnapToPlaneAtStart"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_bAutoRegisterPhysicsVolumeUpdates(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UMovementComponent::StaticClass(), TEXT("bAutoRegisterPhysicsVolumeUpdates"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_bComponentShouldUpdatePhysicsVolume(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UMovementComponent::StaticClass(), TEXT("bComponentShouldUpdatePhysicsVolume"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_PlaneConstraintAxisSetting(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UMovementComponent::StaticClass(), TEXT("PlaneConstraintAxisSetting"));
	if(!Property) { check(false); return 0;}
	EPlaneConstraintAxisSetting PropertyValue = EPlaneConstraintAxisSetting();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushinteger(InScriptContext, (int)PropertyValue);
	return 1;
}

int32 Set_PlaneConstraintAxisSetting(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UMovementComponent::StaticClass(), TEXT("PlaneConstraintAxisSetting"));
	if(!Property) { check(false); return 0;}
	EPlaneConstraintAxisSetting PropertyValue = (EPlaneConstraintAxisSetting)(luaL_checkint(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Class(lua_State* InScriptContext)
{
	UClass* Class = UMovementComponent::StaticClass();
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Class);
	return 1;
}

const luaL_Reg Lib_Funcs[] =
{
	{ "Class", Class },
	{ "StopMovementImmediately", StopMovementImmediately },
	{ "SnapUpdatedComponentToPlane", SnapUpdatedComponentToPlane },
	{ "SetUpdatedComponent", SetUpdatedComponent },
	{ "SetPlaneConstraintOrigin", SetPlaneConstraintOrigin },
	{ "SetPlaneConstraintNormal", SetPlaneConstraintNormal },
	{ "SetPlaneConstraintFromVectors", SetPlaneConstraintFromVectors },
	{ "SetPlaneConstraintEnabled", SetPlaneConstraintEnabled },
	{ "SetPlaneConstraintAxisSetting", SetPlaneConstraintAxisSetting },
	{ "PhysicsVolumeChanged", PhysicsVolumeChanged },
	{ "GetModifiedMaxSpeed", K2_GetModifiedMaxSpeed },
	{ "IsExceedingMaxSpeed", IsExceedingMaxSpeed },
	{ "GetPlaneConstraintOrigin", GetPlaneConstraintOrigin },
	{ "GetPlaneConstraintNormal", GetPlaneConstraintNormal },
	{ "GetPlaneConstraintAxisSetting", GetPlaneConstraintAxisSetting },
	{ "GetPhysicsVolume", GetPhysicsVolume },
	{ "GetMaxSpeed", GetMaxSpeed },
	{ "GetGravityZ", GetGravityZ },
	{ "ConstrainNormalToPlane", ConstrainNormalToPlane },
	{ "ConstrainLocationToPlane", ConstrainLocationToPlane },
	{ "ConstrainDirectionToPlane", ConstrainDirectionToPlane },
	{ "Get_UpdatedComponent", Get_UpdatedComponent },
	{ "Get_UpdatedPrimitive", Get_UpdatedPrimitive },
	{ "Get_Velocity", Get_Velocity },
	{ "Set_Velocity", Set_Velocity },
	{ "Get_PlaneConstraintNormal", Get_PlaneConstraintNormal },
	{ "Get_PlaneConstraintOrigin", Get_PlaneConstraintOrigin },
	{ "Get_bUpdateOnlyIfRendered", Get_bUpdateOnlyIfRendered },
	{ "Set_bUpdateOnlyIfRendered", Set_bUpdateOnlyIfRendered },
	{ "Get_bAutoUpdateTickRegistration", Get_bAutoUpdateTickRegistration },
	{ "Get_bTickBeforeOwner", Get_bTickBeforeOwner },
	{ "Get_bAutoRegisterUpdatedComponent", Get_bAutoRegisterUpdatedComponent },
	{ "Get_bConstrainToPlane", Get_bConstrainToPlane },
	{ "Get_bSnapToPlaneAtStart", Get_bSnapToPlaneAtStart },
	{ "Get_bAutoRegisterPhysicsVolumeUpdates", Get_bAutoRegisterPhysicsVolumeUpdates },
	{ "Get_bComponentShouldUpdatePhysicsVolume", Get_bComponentShouldUpdatePhysicsVolume },
	{ "Get_PlaneConstraintAxisSetting", Get_PlaneConstraintAxisSetting },
	{ "Set_PlaneConstraintAxisSetting", Set_PlaneConstraintAxisSetting },
	{ "is_nil", wLua::LuaStatic::isnil },
	{ "__gc", wLua::LuaStatic::removeUClassFrameCache },
	{ NULL, NULL }
};

void Register(lua_State *InScriptContext)
{
	lua_newtable(InScriptContext);
	luaL_register(InScriptContext, NULL, Lib_Funcs);
	AzureHelpFuncs::AuxRegister(InScriptContext, "MovementComponent");
}
void SetMtLink(lua_State *InScriptContext)
{
	AzureHelpFuncs::AuxSetMtLink(InScriptContext, "MovementComponent", "ActorComponent",USERDATATYPE_UOBJECT);
}

}