#include "Azure.h"
#include "Utility/help_funcs.h"
#include "wLua/UObjectHeaders.h"
#include "Asset/UIParticleEmitterAsset.h"
#include "AzureLuaIntegration.h"

namespace LuaUIParticleEmitterAsset
{
int32 Get_EmitterType(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"UIParticleEmitterAsset",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"UIParticleEmitterAsset must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UUIParticleEmitterAsset::StaticClass(), TEXT("EmitterType"));
	if(!Property) { check(false); return 0;}
	EEmitterType PropertyValue = EEmitterType();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushinteger(InScriptContext, (int)PropertyValue);
	return 1;
}

int32 Set_EmitterType(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"UIParticleEmitterAsset",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"UIParticleEmitterAsset must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UUIParticleEmitterAsset::StaticClass(), TEXT("EmitterType"));
	if(!Property) { check(false); return 0;}
	EEmitterType PropertyValue = (EEmitterType)(luaL_checkint(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_EmitSeconds(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"UIParticleEmitterAsset",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"UIParticleEmitterAsset must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UUIParticleEmitterAsset::StaticClass(), TEXT("EmitSeconds"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_EmitSeconds(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"UIParticleEmitterAsset",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"UIParticleEmitterAsset must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UUIParticleEmitterAsset::StaticClass(), TEXT("EmitSeconds"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_Max_Particles(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"UIParticleEmitterAsset",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"UIParticleEmitterAsset must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UUIParticleEmitterAsset::StaticClass(), TEXT("Max_Particles"));
	if(!Property) { check(false); return 0;}
	int32 PropertyValue = int32();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushinteger(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_Max_Particles(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"UIParticleEmitterAsset",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"UIParticleEmitterAsset must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UUIParticleEmitterAsset::StaticClass(), TEXT("Max_Particles"));
	if(!Property) { check(false); return 0;}
	int32 PropertyValue = (luaL_checkint(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_SpawnParticlePerSecond(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"UIParticleEmitterAsset",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"UIParticleEmitterAsset must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UUIParticleEmitterAsset::StaticClass(), TEXT("SpawnParticlePerSecond"));
	if(!Property) { check(false); return 0;}
	int32 PropertyValue = int32();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushinteger(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_SpawnParticlePerSecond(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"UIParticleEmitterAsset",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"UIParticleEmitterAsset must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UUIParticleEmitterAsset::StaticClass(), TEXT("SpawnParticlePerSecond"));
	if(!Property) { check(false); return 0;}
	int32 PropertyValue = (luaL_checkint(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_AutoEmitPosRange(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"UIParticleEmitterAsset",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"UIParticleEmitterAsset must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UUIParticleEmitterAsset::StaticClass(), TEXT("AutoEmitPosRange"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = bool();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_AutoEmitPosRange(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"UIParticleEmitterAsset",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"UIParticleEmitterAsset must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UUIParticleEmitterAsset::StaticClass(), TEXT("AutoEmitPosRange"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_AutoScale(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"UIParticleEmitterAsset",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"UIParticleEmitterAsset must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UUIParticleEmitterAsset::StaticClass(), TEXT("AutoScale"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = bool();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_AutoScale(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"UIParticleEmitterAsset",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"UIParticleEmitterAsset must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UUIParticleEmitterAsset::StaticClass(), TEXT("AutoScale"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_ScaleByX(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"UIParticleEmitterAsset",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"UIParticleEmitterAsset must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UUIParticleEmitterAsset::StaticClass(), TEXT("ScaleByX"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = bool();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_ScaleByX(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"UIParticleEmitterAsset",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"UIParticleEmitterAsset must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UUIParticleEmitterAsset::StaticClass(), TEXT("ScaleByX"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_DesignSize(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"UIParticleEmitterAsset",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"UIParticleEmitterAsset must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UUIParticleEmitterAsset::StaticClass(), TEXT("DesignSize"));
	if(!Property) { check(false); return 0;}
	FVector2D PropertyValue = FVector2D();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaVector2D::Return(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_DesignSize(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"UIParticleEmitterAsset",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"UIParticleEmitterAsset must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UUIParticleEmitterAsset::StaticClass(), TEXT("DesignSize"));
	if(!Property) { check(false); return 0;}
	FVector2D PropertyValue = (wLua::FLuaVector2D::Get(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_AutoPlay(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"UIParticleEmitterAsset",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"UIParticleEmitterAsset must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UUIParticleEmitterAsset::StaticClass(), TEXT("AutoPlay"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = bool();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_AutoPlay(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"UIParticleEmitterAsset",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"UIParticleEmitterAsset must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UUIParticleEmitterAsset::StaticClass(), TEXT("AutoPlay"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_AutoDestroy(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"UIParticleEmitterAsset",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"UIParticleEmitterAsset must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UUIParticleEmitterAsset::StaticClass(), TEXT("AutoDestroy"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = bool();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_AutoDestroy(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"UIParticleEmitterAsset",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"UIParticleEmitterAsset must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UUIParticleEmitterAsset::StaticClass(), TEXT("AutoDestroy"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_PositionType(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"UIParticleEmitterAsset",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"UIParticleEmitterAsset must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UUIParticleEmitterAsset::StaticClass(), TEXT("PositionType"));
	if(!Property) { check(false); return 0;}
	EPositionType PropertyValue = EPositionType();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushinteger(InScriptContext, (int)PropertyValue);
	return 1;
}

int32 Set_PositionType(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"UIParticleEmitterAsset",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"UIParticleEmitterAsset must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UUIParticleEmitterAsset::StaticClass(), TEXT("PositionType"));
	if(!Property) { check(false); return 0;}
	EPositionType PropertyValue = (EPositionType)(luaL_checkint(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_Pivot(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"UIParticleEmitterAsset",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"UIParticleEmitterAsset must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UUIParticleEmitterAsset::StaticClass(), TEXT("Pivot"));
	if(!Property) { check(false); return 0;}
	FVector2D PropertyValue = FVector2D();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaVector2D::Return(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_Pivot(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"UIParticleEmitterAsset",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"UIParticleEmitterAsset must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UUIParticleEmitterAsset::StaticClass(), TEXT("Pivot"));
	if(!Property) { check(false); return 0;}
	FVector2D PropertyValue = (wLua::FLuaVector2D::Get(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_RotationFollowSpeed(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"UIParticleEmitterAsset",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"UIParticleEmitterAsset must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UUIParticleEmitterAsset::StaticClass(), TEXT("RotationFollowSpeed"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = bool();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_RotationFollowSpeed(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"UIParticleEmitterAsset",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"UIParticleEmitterAsset must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UUIParticleEmitterAsset::StaticClass(), TEXT("RotationFollowSpeed"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_UseSeparateSize(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"UIParticleEmitterAsset",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"UIParticleEmitterAsset must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UUIParticleEmitterAsset::StaticClass(), TEXT("UseSeparateSize"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = bool();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_UseSeparateSize(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"UIParticleEmitterAsset",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"UIParticleEmitterAsset must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UUIParticleEmitterAsset::StaticClass(), TEXT("UseSeparateSize"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_UsePivotCurve(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"UIParticleEmitterAsset",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"UIParticleEmitterAsset must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UUIParticleEmitterAsset::StaticClass(), TEXT("UsePivotCurve"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = bool();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_UsePivotCurve(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"UIParticleEmitterAsset",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"UIParticleEmitterAsset must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UUIParticleEmitterAsset::StaticClass(), TEXT("UsePivotCurve"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_ResourceObject(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"UIParticleEmitterAsset",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"UIParticleEmitterAsset must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UUIParticleEmitterAsset::StaticClass(), TEXT("ResourceObject"));
	if(!Property) { check(false); return 0;}
	UObject* PropertyValue;
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaUtils::ReturnUObject(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_ResourceObject(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"UIParticleEmitterAsset",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"UIParticleEmitterAsset must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UUIParticleEmitterAsset::StaticClass(), TEXT("ResourceObject"));
	if(!Property) { check(false); return 0;}
	UObject* PropertyValue = (UObject*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"Object");;
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_Gravity_X(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"UIParticleEmitterAsset",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"UIParticleEmitterAsset must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UUIParticleEmitterAsset::StaticClass(), TEXT("Gravity_X"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_Gravity_X(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"UIParticleEmitterAsset",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"UIParticleEmitterAsset must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UUIParticleEmitterAsset::StaticClass(), TEXT("Gravity_X"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_Gravity_Y(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"UIParticleEmitterAsset",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"UIParticleEmitterAsset must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UUIParticleEmitterAsset::StaticClass(), TEXT("Gravity_Y"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_Gravity_Y(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"UIParticleEmitterAsset",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"UIParticleEmitterAsset must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UUIParticleEmitterAsset::StaticClass(), TEXT("Gravity_Y"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_DrawEffect(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"UIParticleEmitterAsset",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"UIParticleEmitterAsset must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UUIParticleEmitterAsset::StaticClass(), TEXT("DrawEffect"));
	if(!Property) { check(false); return 0;}
	EParticleDrawEffect PropertyValue = EParticleDrawEffect();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushinteger(InScriptContext, (int)PropertyValue);
	return 1;
}

int32 Set_DrawEffect(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"UIParticleEmitterAsset",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"UIParticleEmitterAsset must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UUIParticleEmitterAsset::StaticClass(), TEXT("DrawEffect"));
	if(!Property) { check(false); return 0;}
	EParticleDrawEffect PropertyValue = (EParticleDrawEffect)(luaL_checkint(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_UseScaleFollowSpeedDirection(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"UIParticleEmitterAsset",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"UIParticleEmitterAsset must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UUIParticleEmitterAsset::StaticClass(), TEXT("UseScaleFollowSpeedDirection"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = bool();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_UseScaleFollowSpeedDirection(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"UIParticleEmitterAsset",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"UIParticleEmitterAsset must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UUIParticleEmitterAsset::StaticClass(), TEXT("UseScaleFollowSpeedDirection"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_UseScaleFollowSpeedVertical(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"UIParticleEmitterAsset",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"UIParticleEmitterAsset must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UUIParticleEmitterAsset::StaticClass(), TEXT("UseScaleFollowSpeedVertical"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = bool();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_UseScaleFollowSpeedVertical(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"UIParticleEmitterAsset",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"UIParticleEmitterAsset must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UUIParticleEmitterAsset::StaticClass(), TEXT("UseScaleFollowSpeedVertical"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 New(lua_State* InScriptContext)
{
	UObject* Outer = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Object");
	FName Name = FName(luaL_checkstring(InScriptContext, 2));
	UObject* Obj = NewObject<UUIParticleEmitterAsset>(Outer, Name);
	wLua::FLuaUtils::ReturnUObject(InScriptContext,Obj);
	return 1;
}

int32 Destroy(lua_State* InScriptContext)
{
	return 0;
}

int32 Class(lua_State* InScriptContext)
{
	UClass* Class = UUIParticleEmitterAsset::StaticClass();
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Class);
	return 1;
}

const luaL_Reg Lib_Funcs[] =
{
	{ "New", New },
	{ "Destroy", Destroy },
	{ "Class", Class },
	{ "Get_EmitterType", Get_EmitterType },
	{ "Set_EmitterType", Set_EmitterType },
	{ "Get_EmitSeconds", Get_EmitSeconds },
	{ "Set_EmitSeconds", Set_EmitSeconds },
	{ "Get_Max_Particles", Get_Max_Particles },
	{ "Set_Max_Particles", Set_Max_Particles },
	{ "Get_SpawnParticlePerSecond", Get_SpawnParticlePerSecond },
	{ "Set_SpawnParticlePerSecond", Set_SpawnParticlePerSecond },
	{ "Get_AutoEmitPosRange", Get_AutoEmitPosRange },
	{ "Set_AutoEmitPosRange", Set_AutoEmitPosRange },
	{ "Get_AutoScale", Get_AutoScale },
	{ "Set_AutoScale", Set_AutoScale },
	{ "Get_ScaleByX", Get_ScaleByX },
	{ "Set_ScaleByX", Set_ScaleByX },
	{ "Get_DesignSize", Get_DesignSize },
	{ "Set_DesignSize", Set_DesignSize },
	{ "Get_AutoPlay", Get_AutoPlay },
	{ "Set_AutoPlay", Set_AutoPlay },
	{ "Get_AutoDestroy", Get_AutoDestroy },
	{ "Set_AutoDestroy", Set_AutoDestroy },
	{ "Get_PositionType", Get_PositionType },
	{ "Set_PositionType", Set_PositionType },
	{ "Get_Pivot", Get_Pivot },
	{ "Set_Pivot", Set_Pivot },
	{ "Get_RotationFollowSpeed", Get_RotationFollowSpeed },
	{ "Set_RotationFollowSpeed", Set_RotationFollowSpeed },
	{ "Get_UseSeparateSize", Get_UseSeparateSize },
	{ "Set_UseSeparateSize", Set_UseSeparateSize },
	{ "Get_UsePivotCurve", Get_UsePivotCurve },
	{ "Set_UsePivotCurve", Set_UsePivotCurve },
	{ "Get_ResourceObject", Get_ResourceObject },
	{ "Set_ResourceObject", Set_ResourceObject },
	{ "Get_Gravity_X", Get_Gravity_X },
	{ "Set_Gravity_X", Set_Gravity_X },
	{ "Get_Gravity_Y", Get_Gravity_Y },
	{ "Set_Gravity_Y", Set_Gravity_Y },
	{ "Get_DrawEffect", Get_DrawEffect },
	{ "Set_DrawEffect", Set_DrawEffect },
	{ "Get_UseScaleFollowSpeedDirection", Get_UseScaleFollowSpeedDirection },
	{ "Set_UseScaleFollowSpeedDirection", Set_UseScaleFollowSpeedDirection },
	{ "Get_UseScaleFollowSpeedVertical", Get_UseScaleFollowSpeedVertical },
	{ "Set_UseScaleFollowSpeedVertical", Set_UseScaleFollowSpeedVertical },
	{ "is_nil", wLua::LuaStatic::isnil },
	{ "__gc", wLua::LuaStatic::removeUClassFrameCache },
	{ NULL, NULL }
};

void Register(lua_State *InScriptContext)
{
	lua_newtable(InScriptContext);
	luaL_register(InScriptContext, NULL, Lib_Funcs);
	AzureHelpFuncs::AuxRegister(InScriptContext, "UIParticleEmitterAsset");
}
void SetMtLink(lua_State *InScriptContext)
{
	AzureHelpFuncs::AuxSetMtLink(InScriptContext, "UIParticleEmitterAsset", "Object",USERDATATYPE_UOBJECT);
}

}