#include "Azure.h"
#include "Utility/help_funcs.h"
#include "wLua/UObjectHeaders.h"
#include "GameFramework/CharacterMovementComponent.h"
#include "AzureLuaIntegration.h"

namespace LuaCharacterMovementComponent
{
int32 IsSwimming(lua_State*);
int32 GetGravityZ(lua_State*);
int32 IsWalkable(lua_State*);
int32 SetDefaultMovementMode(lua_State*);

int32 SetWalkableFloorZ(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CharacterMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CharacterMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float InWalkableFloorZ;
	} Params;
	Params.InWalkableFloorZ = (float)(luaL_checknumber(InScriptContext, 2));
#if UE_GAME
	UCharacterMovementComponent * This = (UCharacterMovementComponent *)Obj;
	This->SetWalkableFloorZ(Params.InWalkableFloorZ);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetWalkableFloorZ"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(float*)(params.GetStructMemory() + 0) = Params.InWalkableFloorZ;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.InWalkableFloorZ = *(float*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetWalkableFloorAngle(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CharacterMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CharacterMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float InWalkableFloorAngle;
	} Params;
	Params.InWalkableFloorAngle = (float)(luaL_checknumber(InScriptContext, 2));
#if UE_GAME
	UCharacterMovementComponent * This = (UCharacterMovementComponent *)Obj;
	This->SetWalkableFloorAngle(Params.InWalkableFloorAngle);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetWalkableFloorAngle"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(float*)(params.GetStructMemory() + 0) = Params.InWalkableFloorAngle;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.InWalkableFloorAngle = *(float*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetMovementMode(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CharacterMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CharacterMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		TEnumAsByte<EMovementMode> NewMovementMode;
		uint8 NewCustomMode;
	} Params;
	Params.NewMovementMode = (TEnumAsByte<EMovementMode>)(luaL_checkint(InScriptContext, 2));
	Params.NewCustomMode = lua_isnoneornil(InScriptContext,3) ? uint8(0) : (uint8)(luaL_checkint(InScriptContext, 3));
#if UE_GAME
	UCharacterMovementComponent * This = (UCharacterMovementComponent *)Obj;
	This->SetMovementMode(Params.NewMovementMode,Params.NewCustomMode);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetMovementMode"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(TEnumAsByte<EMovementMode>*)(params.GetStructMemory() + 0) = Params.NewMovementMode;
		*(uint8*)(params.GetStructMemory() + 1) = Params.NewCustomMode;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.NewMovementMode = *(TEnumAsByte<EMovementMode>*)(params.GetStructMemory() + 0);
		Params.NewCustomMode = *(uint8*)(params.GetStructMemory() + 1);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetAvoidanceEnabled(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CharacterMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CharacterMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool bEnable;
	} Params;
	Params.bEnable = !!(lua_toboolean(InScriptContext, 2));
#if UE_GAME
	UCharacterMovementComponent * This = (UCharacterMovementComponent *)Obj;
	This->SetAvoidanceEnabled(Params.bEnable);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetAvoidanceEnabled"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(bool*)(params.GetStructMemory() + 0) = Params.bEnable;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.bEnable = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 K2_GetWalkableFloorZ(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CharacterMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CharacterMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float ReturnValue;
	} Params;
#if UE_GAME
	UCharacterMovementComponent * This = (UCharacterMovementComponent *)Obj;
	Params.ReturnValue = This->K2_GetWalkableFloorZ();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("K2_GetWalkableFloorZ"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(float*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushnumber(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 K2_GetWalkableFloorAngle(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CharacterMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CharacterMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float ReturnValue;
	} Params;
#if UE_GAME
	UCharacterMovementComponent * This = (UCharacterMovementComponent *)Obj;
	Params.ReturnValue = This->K2_GetWalkableFloorAngle();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("K2_GetWalkableFloorAngle"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(float*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushnumber(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 IsWalking(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CharacterMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CharacterMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool ReturnValue;
	} Params;
#if UE_GAME
	UCharacterMovementComponent * This = (UCharacterMovementComponent *)Obj;
	Params.ReturnValue = This->IsWalking();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("IsWalking"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushboolean(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetValidPerchRadius(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CharacterMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CharacterMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float ReturnValue;
	} Params;
#if UE_GAME
	UCharacterMovementComponent * This = (UCharacterMovementComponent *)Obj;
	Params.ReturnValue = This->GetValidPerchRadius();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetValidPerchRadius"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(float*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushnumber(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetPerchRadiusThreshold(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CharacterMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CharacterMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float ReturnValue;
	} Params;
#if UE_GAME
	UCharacterMovementComponent * This = (UCharacterMovementComponent *)Obj;
	Params.ReturnValue = This->GetPerchRadiusThreshold();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetPerchRadiusThreshold"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(float*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushnumber(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetMovementBase(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CharacterMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CharacterMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		UPrimitiveComponent* ReturnValue = nullptr;
	} Params;
#if UE_GAME
	UCharacterMovementComponent * This = (UCharacterMovementComponent *)Obj;
	Params.ReturnValue = This->GetMovementBase();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetMovementBase"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(UPrimitiveComponent**)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetMinAnalogSpeed(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CharacterMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CharacterMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float ReturnValue;
	} Params;
#if UE_GAME
	UCharacterMovementComponent * This = (UCharacterMovementComponent *)Obj;
	Params.ReturnValue = This->GetMinAnalogSpeed();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetMinAnalogSpeed"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(float*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushnumber(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetMaxJumpHeightWithJumpTime(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CharacterMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CharacterMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float ReturnValue;
	} Params;
#if UE_GAME
	UCharacterMovementComponent * This = (UCharacterMovementComponent *)Obj;
	Params.ReturnValue = This->GetMaxJumpHeightWithJumpTime();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetMaxJumpHeightWithJumpTime"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(float*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushnumber(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetMaxJumpHeight(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CharacterMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CharacterMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float ReturnValue;
	} Params;
#if UE_GAME
	UCharacterMovementComponent * This = (UCharacterMovementComponent *)Obj;
	Params.ReturnValue = This->GetMaxJumpHeight();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetMaxJumpHeight"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(float*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushnumber(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetMaxBrakingDeceleration(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CharacterMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CharacterMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float ReturnValue;
	} Params;
#if UE_GAME
	UCharacterMovementComponent * This = (UCharacterMovementComponent *)Obj;
	Params.ReturnValue = This->GetMaxBrakingDeceleration();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetMaxBrakingDeceleration"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(float*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushnumber(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetMaxAcceleration(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CharacterMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CharacterMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float ReturnValue;
	} Params;
#if UE_GAME
	UCharacterMovementComponent * This = (UCharacterMovementComponent *)Obj;
	Params.ReturnValue = This->GetMaxAcceleration();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetMaxAcceleration"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(float*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushnumber(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetLastUpdateVelocity(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CharacterMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CharacterMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FVector ReturnValue;
	} Params;
#if UE_GAME
	UCharacterMovementComponent * This = (UCharacterMovementComponent *)Obj;
	Params.ReturnValue = This->GetLastUpdateVelocity();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetLastUpdateVelocity"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(FVector*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaVector::Return(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetLastUpdateRotation(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CharacterMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CharacterMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FRotator ReturnValue;
	} Params;
#if UE_GAME
	UCharacterMovementComponent * This = (UCharacterMovementComponent *)Obj;
	Params.ReturnValue = This->GetLastUpdateRotation();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetLastUpdateRotation"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(FRotator*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaRotator::Return(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetLastUpdateLocation(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CharacterMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CharacterMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FVector ReturnValue;
	} Params;
#if UE_GAME
	UCharacterMovementComponent * This = (UCharacterMovementComponent *)Obj;
	Params.ReturnValue = This->GetLastUpdateLocation();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetLastUpdateLocation"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(FVector*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaVector::Return(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetImpartedMovementBaseVelocity(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CharacterMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CharacterMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FVector ReturnValue;
	} Params;
#if UE_GAME
	UCharacterMovementComponent * This = (UCharacterMovementComponent *)Obj;
	Params.ReturnValue = This->GetImpartedMovementBaseVelocity();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetImpartedMovementBaseVelocity"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(FVector*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaVector::Return(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetCurrentAcceleration(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CharacterMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CharacterMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FVector ReturnValue;
	} Params;
#if UE_GAME
	UCharacterMovementComponent * This = (UCharacterMovementComponent *)Obj;
	Params.ReturnValue = This->GetCurrentAcceleration();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetCurrentAcceleration"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(FVector*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaVector::Return(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetCharacterOwner(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CharacterMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CharacterMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		ACharacter* ReturnValue = nullptr;
	} Params;
#if UE_GAME
	UCharacterMovementComponent * This = (UCharacterMovementComponent *)Obj;
	Params.ReturnValue = This->GetCharacterOwner();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetCharacterOwner"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(ACharacter**)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetAnalogInputModifier(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CharacterMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CharacterMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float ReturnValue;
	} Params;
#if UE_GAME
	UCharacterMovementComponent * This = (UCharacterMovementComponent *)Obj;
	Params.ReturnValue = This->GetAnalogInputModifier();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetAnalogInputModifier"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(float*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushnumber(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 DisableMovement(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CharacterMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CharacterMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
#if UE_GAME
	UCharacterMovementComponent * This = (UCharacterMovementComponent *)Obj;
	This->DisableMovement();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("DisableMovement"));
	if(!Function) { check(false); return 0;}
	Obj->ProcessEvent(Function, NULL);
#endif
	return 0;
}

int32 ClearAccumulatedForces(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CharacterMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CharacterMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
#if UE_GAME
	UCharacterMovementComponent * This = (UCharacterMovementComponent *)Obj;
	This->ClearAccumulatedForces();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("ClearAccumulatedForces"));
	if(!Function) { check(false); return 0;}
	Obj->ProcessEvent(Function, NULL);
#endif
	return 0;
}

int32 CalcVelocity(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CharacterMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CharacterMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float DeltaTime;
		float Friction;
		bool bFluid;
		float BrakingDeceleration;
	} Params;
	Params.DeltaTime = (float)(luaL_checknumber(InScriptContext, 2));
	Params.Friction = (float)(luaL_checknumber(InScriptContext, 3));
	Params.bFluid = !!(lua_toboolean(InScriptContext, 4));
	Params.BrakingDeceleration = (float)(luaL_checknumber(InScriptContext, 5));
#if UE_GAME
	UCharacterMovementComponent * This = (UCharacterMovementComponent *)Obj;
	This->CalcVelocity(Params.DeltaTime,Params.Friction,Params.bFluid,Params.BrakingDeceleration);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("CalcVelocity"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(float*)(params.GetStructMemory() + 0) = Params.DeltaTime;
		*(float*)(params.GetStructMemory() + 4) = Params.Friction;
		*(bool*)(params.GetStructMemory() + 8) = Params.bFluid;
		*(float*)(params.GetStructMemory() + 12) = Params.BrakingDeceleration;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.DeltaTime = *(float*)(params.GetStructMemory() + 0);
		Params.Friction = *(float*)(params.GetStructMemory() + 4);
		Params.bFluid = *(bool*)(params.GetStructMemory() + 8);
		Params.BrakingDeceleration = *(float*)(params.GetStructMemory() + 12);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 AddImpulse(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CharacterMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CharacterMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FVector Impulse;
		bool bVelocityChange;
	} Params;
	Params.Impulse = (wLua::FLuaVector::Get(InScriptContext, 2));
	Params.bVelocityChange = lua_isnoneornil(InScriptContext,3) ? bool(false) : !!(lua_toboolean(InScriptContext, 3));
#if UE_GAME
	UCharacterMovementComponent * This = (UCharacterMovementComponent *)Obj;
	This->AddImpulse(Params.Impulse,Params.bVelocityChange);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("AddImpulse"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FVector*)(params.GetStructMemory() + 0) = Params.Impulse;
		*(bool*)(params.GetStructMemory() + 12) = Params.bVelocityChange;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.Impulse = *(FVector*)(params.GetStructMemory() + 0);
		Params.bVelocityChange = *(bool*)(params.GetStructMemory() + 12);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 AddForce(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CharacterMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CharacterMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FVector Force;
	} Params;
	Params.Force = (wLua::FLuaVector::Get(InScriptContext, 2));
#if UE_GAME
	UCharacterMovementComponent * This = (UCharacterMovementComponent *)Obj;
	This->AddForce(Params.Force);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("AddForce"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FVector*)(params.GetStructMemory() + 0) = Params.Force;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.Force = *(FVector*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 Get_GravityScale(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CharacterMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CharacterMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UCharacterMovementComponent::StaticClass(), TEXT("GravityScale"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_GravityScale(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CharacterMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CharacterMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UCharacterMovementComponent::StaticClass(), TEXT("GravityScale"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_MaxStepHeight(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CharacterMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CharacterMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UCharacterMovementComponent::StaticClass(), TEXT("MaxStepHeight"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_MaxStepHeight(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CharacterMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CharacterMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UCharacterMovementComponent::StaticClass(), TEXT("MaxStepHeight"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_JumpZVelocity(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CharacterMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CharacterMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UCharacterMovementComponent::StaticClass(), TEXT("JumpZVelocity"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_JumpZVelocity(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CharacterMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CharacterMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UCharacterMovementComponent::StaticClass(), TEXT("JumpZVelocity"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_JumpOffJumpZFactor(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CharacterMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CharacterMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UCharacterMovementComponent::StaticClass(), TEXT("JumpOffJumpZFactor"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_JumpOffJumpZFactor(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CharacterMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CharacterMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UCharacterMovementComponent::StaticClass(), TEXT("JumpOffJumpZFactor"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_WalkableFloorAngle(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CharacterMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CharacterMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UCharacterMovementComponent::StaticClass(), TEXT("WalkableFloorAngle"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_WalkableFloorAngle(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CharacterMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CharacterMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UCharacterMovementComponent::StaticClass(), TEXT("WalkableFloorAngle"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_WalkableFloorZ(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CharacterMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CharacterMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UCharacterMovementComponent::StaticClass(), TEXT("WalkableFloorZ"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_WalkableFloorZ(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CharacterMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CharacterMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UCharacterMovementComponent::StaticClass(), TEXT("WalkableFloorZ"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_MovementMode(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CharacterMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CharacterMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UCharacterMovementComponent::StaticClass(), TEXT("MovementMode"));
	if(!Property) { check(false); return 0;}
	TEnumAsByte<EMovementMode> PropertyValue = TEnumAsByte<EMovementMode>();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushinteger(InScriptContext, (int)PropertyValue);
	return 1;
}

int32 Get_CustomMovementMode(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CharacterMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CharacterMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UCharacterMovementComponent::StaticClass(), TEXT("CustomMovementMode"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushinteger(InScriptContext, (int)PropertyValue);
	return 1;
}

int32 Get_NetworkSmoothingMode(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CharacterMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CharacterMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UCharacterMovementComponent::StaticClass(), TEXT("NetworkSmoothingMode"));
	if(!Property) { check(false); return 0;}
	ENetworkSmoothingMode PropertyValue = ENetworkSmoothingMode();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushinteger(InScriptContext, (int)PropertyValue);
	return 1;
}

int32 Get_GroundFriction(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CharacterMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CharacterMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UCharacterMovementComponent::StaticClass(), TEXT("GroundFriction"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_GroundFriction(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CharacterMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CharacterMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UCharacterMovementComponent::StaticClass(), TEXT("GroundFriction"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_MaxWalkSpeed(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CharacterMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CharacterMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UCharacterMovementComponent::StaticClass(), TEXT("MaxWalkSpeed"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_MaxWalkSpeed(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CharacterMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CharacterMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UCharacterMovementComponent::StaticClass(), TEXT("MaxWalkSpeed"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_MaxWalkSpeedCrouched(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CharacterMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CharacterMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UCharacterMovementComponent::StaticClass(), TEXT("MaxWalkSpeedCrouched"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_MaxWalkSpeedCrouched(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CharacterMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CharacterMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UCharacterMovementComponent::StaticClass(), TEXT("MaxWalkSpeedCrouched"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_MaxSwimSpeed(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CharacterMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CharacterMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UCharacterMovementComponent::StaticClass(), TEXT("MaxSwimSpeed"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_MaxSwimSpeed(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CharacterMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CharacterMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UCharacterMovementComponent::StaticClass(), TEXT("MaxSwimSpeed"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_MaxFlySpeed(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CharacterMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CharacterMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UCharacterMovementComponent::StaticClass(), TEXT("MaxFlySpeed"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_MaxFlySpeed(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CharacterMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CharacterMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UCharacterMovementComponent::StaticClass(), TEXT("MaxFlySpeed"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_MaxCustomMovementSpeed(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CharacterMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CharacterMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UCharacterMovementComponent::StaticClass(), TEXT("MaxCustomMovementSpeed"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_MaxCustomMovementSpeed(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CharacterMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CharacterMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UCharacterMovementComponent::StaticClass(), TEXT("MaxCustomMovementSpeed"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_MaxAcceleration(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CharacterMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CharacterMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UCharacterMovementComponent::StaticClass(), TEXT("MaxAcceleration"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_MaxAcceleration(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CharacterMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CharacterMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UCharacterMovementComponent::StaticClass(), TEXT("MaxAcceleration"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_MinAnalogWalkSpeed(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CharacterMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CharacterMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UCharacterMovementComponent::StaticClass(), TEXT("MinAnalogWalkSpeed"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_MinAnalogWalkSpeed(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CharacterMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CharacterMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UCharacterMovementComponent::StaticClass(), TEXT("MinAnalogWalkSpeed"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_BrakingFrictionFactor(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CharacterMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CharacterMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UCharacterMovementComponent::StaticClass(), TEXT("BrakingFrictionFactor"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_BrakingFrictionFactor(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CharacterMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CharacterMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UCharacterMovementComponent::StaticClass(), TEXT("BrakingFrictionFactor"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_BrakingFriction(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CharacterMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CharacterMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UCharacterMovementComponent::StaticClass(), TEXT("BrakingFriction"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_BrakingFriction(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CharacterMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CharacterMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UCharacterMovementComponent::StaticClass(), TEXT("BrakingFriction"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_BrakingDecelerationWalking(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CharacterMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CharacterMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UCharacterMovementComponent::StaticClass(), TEXT("BrakingDecelerationWalking"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_BrakingDecelerationWalking(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CharacterMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CharacterMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UCharacterMovementComponent::StaticClass(), TEXT("BrakingDecelerationWalking"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_BrakingDecelerationFalling(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CharacterMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CharacterMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UCharacterMovementComponent::StaticClass(), TEXT("BrakingDecelerationFalling"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_BrakingDecelerationFalling(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CharacterMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CharacterMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UCharacterMovementComponent::StaticClass(), TEXT("BrakingDecelerationFalling"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_BrakingDecelerationSwimming(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CharacterMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CharacterMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UCharacterMovementComponent::StaticClass(), TEXT("BrakingDecelerationSwimming"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_BrakingDecelerationSwimming(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CharacterMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CharacterMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UCharacterMovementComponent::StaticClass(), TEXT("BrakingDecelerationSwimming"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_BrakingDecelerationFlying(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CharacterMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CharacterMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UCharacterMovementComponent::StaticClass(), TEXT("BrakingDecelerationFlying"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_BrakingDecelerationFlying(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CharacterMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CharacterMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UCharacterMovementComponent::StaticClass(), TEXT("BrakingDecelerationFlying"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_AirControl(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CharacterMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CharacterMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UCharacterMovementComponent::StaticClass(), TEXT("AirControl"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_AirControl(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CharacterMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CharacterMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UCharacterMovementComponent::StaticClass(), TEXT("AirControl"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_AirControlBoostMultiplier(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CharacterMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CharacterMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UCharacterMovementComponent::StaticClass(), TEXT("AirControlBoostMultiplier"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_AirControlBoostMultiplier(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CharacterMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CharacterMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UCharacterMovementComponent::StaticClass(), TEXT("AirControlBoostMultiplier"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_AirControlBoostVelocityThreshold(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CharacterMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CharacterMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UCharacterMovementComponent::StaticClass(), TEXT("AirControlBoostVelocityThreshold"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_AirControlBoostVelocityThreshold(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CharacterMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CharacterMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UCharacterMovementComponent::StaticClass(), TEXT("AirControlBoostVelocityThreshold"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_FallingLateralFriction(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CharacterMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CharacterMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UCharacterMovementComponent::StaticClass(), TEXT("FallingLateralFriction"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_FallingLateralFriction(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CharacterMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CharacterMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UCharacterMovementComponent::StaticClass(), TEXT("FallingLateralFriction"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_CrouchedHalfHeight(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CharacterMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CharacterMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UCharacterMovementComponent::StaticClass(), TEXT("CrouchedHalfHeight"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_Buoyancy(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CharacterMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CharacterMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UCharacterMovementComponent::StaticClass(), TEXT("Buoyancy"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_Buoyancy(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CharacterMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CharacterMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UCharacterMovementComponent::StaticClass(), TEXT("Buoyancy"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_PerchRadiusThreshold(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CharacterMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CharacterMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UCharacterMovementComponent::StaticClass(), TEXT("PerchRadiusThreshold"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_PerchRadiusThreshold(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CharacterMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CharacterMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UCharacterMovementComponent::StaticClass(), TEXT("PerchRadiusThreshold"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_PerchAdditionalHeight(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CharacterMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CharacterMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UCharacterMovementComponent::StaticClass(), TEXT("PerchAdditionalHeight"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_PerchAdditionalHeight(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CharacterMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CharacterMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UCharacterMovementComponent::StaticClass(), TEXT("PerchAdditionalHeight"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_RotationRate(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CharacterMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CharacterMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UCharacterMovementComponent::StaticClass(), TEXT("RotationRate"));
	if(!Property) { check(false); return 0;}
	FRotator PropertyValue = FRotator();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaRotator::Return(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_RotationRate(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CharacterMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CharacterMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UCharacterMovementComponent::StaticClass(), TEXT("RotationRate"));
	if(!Property) { check(false); return 0;}
	FRotator PropertyValue = (wLua::FLuaRotator::Get(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bUseSeparateBrakingFriction(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CharacterMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CharacterMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UCharacterMovementComponent::StaticClass(), TEXT("bUseSeparateBrakingFriction"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bUseSeparateBrakingFriction(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CharacterMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CharacterMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UCharacterMovementComponent::StaticClass(), TEXT("bUseSeparateBrakingFriction"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bApplyGravityWhileJumping(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CharacterMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CharacterMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UCharacterMovementComponent::StaticClass(), TEXT("bApplyGravityWhileJumping"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bApplyGravityWhileJumping(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CharacterMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CharacterMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UCharacterMovementComponent::StaticClass(), TEXT("bApplyGravityWhileJumping"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bUseControllerDesiredRotation(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CharacterMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CharacterMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UCharacterMovementComponent::StaticClass(), TEXT("bUseControllerDesiredRotation"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bUseControllerDesiredRotation(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CharacterMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CharacterMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UCharacterMovementComponent::StaticClass(), TEXT("bUseControllerDesiredRotation"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bOrientRotationToMovement(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CharacterMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CharacterMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UCharacterMovementComponent::StaticClass(), TEXT("bOrientRotationToMovement"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bOrientRotationToMovement(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CharacterMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CharacterMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UCharacterMovementComponent::StaticClass(), TEXT("bOrientRotationToMovement"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bSweepWhileNavWalking(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CharacterMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CharacterMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UCharacterMovementComponent::StaticClass(), TEXT("bSweepWhileNavWalking"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bSweepWhileNavWalking(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CharacterMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CharacterMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UCharacterMovementComponent::StaticClass(), TEXT("bSweepWhileNavWalking"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bEnableScopedMovementUpdates(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CharacterMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CharacterMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UCharacterMovementComponent::StaticClass(), TEXT("bEnableScopedMovementUpdates"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bEnableScopedMovementUpdates(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CharacterMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CharacterMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UCharacterMovementComponent::StaticClass(), TEXT("bEnableScopedMovementUpdates"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bRunPhysicsWithNoController(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CharacterMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CharacterMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UCharacterMovementComponent::StaticClass(), TEXT("bRunPhysicsWithNoController"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bRunPhysicsWithNoController(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CharacterMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CharacterMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UCharacterMovementComponent::StaticClass(), TEXT("bRunPhysicsWithNoController"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bForceNextFloorCheck(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CharacterMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CharacterMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UCharacterMovementComponent::StaticClass(), TEXT("bForceNextFloorCheck"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bForceNextFloorCheck(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CharacterMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CharacterMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UCharacterMovementComponent::StaticClass(), TEXT("bForceNextFloorCheck"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bCanWalkOffLedges(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CharacterMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CharacterMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UCharacterMovementComponent::StaticClass(), TEXT("bCanWalkOffLedges"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bCanWalkOffLedges(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CharacterMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CharacterMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UCharacterMovementComponent::StaticClass(), TEXT("bCanWalkOffLedges"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bCanWalkOffLedgesWhenCrouching(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CharacterMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CharacterMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UCharacterMovementComponent::StaticClass(), TEXT("bCanWalkOffLedgesWhenCrouching"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bCanWalkOffLedgesWhenCrouching(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CharacterMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CharacterMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UCharacterMovementComponent::StaticClass(), TEXT("bCanWalkOffLedgesWhenCrouching"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bNetworkSkipProxyPredictionOnNetUpdate(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CharacterMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CharacterMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UCharacterMovementComponent::StaticClass(), TEXT("bNetworkSkipProxyPredictionOnNetUpdate"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bNetworkSkipProxyPredictionOnNetUpdate(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CharacterMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CharacterMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UCharacterMovementComponent::StaticClass(), TEXT("bNetworkSkipProxyPredictionOnNetUpdate"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bNetworkAlwaysReplicateTransformUpdateTimestamp(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CharacterMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CharacterMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UCharacterMovementComponent::StaticClass(), TEXT("bNetworkAlwaysReplicateTransformUpdateTimestamp"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bNetworkAlwaysReplicateTransformUpdateTimestamp(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CharacterMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CharacterMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UCharacterMovementComponent::StaticClass(), TEXT("bNetworkAlwaysReplicateTransformUpdateTimestamp"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bEnablePhysicsInteraction(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CharacterMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CharacterMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UCharacterMovementComponent::StaticClass(), TEXT("bEnablePhysicsInteraction"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bEnablePhysicsInteraction(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CharacterMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CharacterMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UCharacterMovementComponent::StaticClass(), TEXT("bEnablePhysicsInteraction"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bTouchForceScaledToMass(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CharacterMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CharacterMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UCharacterMovementComponent::StaticClass(), TEXT("bTouchForceScaledToMass"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bTouchForceScaledToMass(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CharacterMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CharacterMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UCharacterMovementComponent::StaticClass(), TEXT("bTouchForceScaledToMass"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bPushForceScaledToMass(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CharacterMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CharacterMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UCharacterMovementComponent::StaticClass(), TEXT("bPushForceScaledToMass"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bPushForceScaledToMass(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CharacterMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CharacterMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UCharacterMovementComponent::StaticClass(), TEXT("bPushForceScaledToMass"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bPushForceUsingZOffset(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CharacterMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CharacterMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UCharacterMovementComponent::StaticClass(), TEXT("bPushForceUsingZOffset"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bPushForceUsingZOffset(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CharacterMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CharacterMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UCharacterMovementComponent::StaticClass(), TEXT("bPushForceUsingZOffset"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bScalePushForceToVelocity(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CharacterMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CharacterMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UCharacterMovementComponent::StaticClass(), TEXT("bScalePushForceToVelocity"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bScalePushForceToVelocity(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CharacterMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CharacterMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UCharacterMovementComponent::StaticClass(), TEXT("bScalePushForceToVelocity"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_MaxOutOfWaterStepHeight(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CharacterMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CharacterMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UCharacterMovementComponent::StaticClass(), TEXT("MaxOutOfWaterStepHeight"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_MaxOutOfWaterStepHeight(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CharacterMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CharacterMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UCharacterMovementComponent::StaticClass(), TEXT("MaxOutOfWaterStepHeight"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_OutofWaterZ(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CharacterMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CharacterMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UCharacterMovementComponent::StaticClass(), TEXT("OutofWaterZ"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_OutofWaterZ(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CharacterMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CharacterMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UCharacterMovementComponent::StaticClass(), TEXT("OutofWaterZ"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_Mass(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CharacterMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CharacterMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UCharacterMovementComponent::StaticClass(), TEXT("Mass"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_Mass(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CharacterMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CharacterMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UCharacterMovementComponent::StaticClass(), TEXT("Mass"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_StandingDownwardForceScale(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CharacterMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CharacterMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UCharacterMovementComponent::StaticClass(), TEXT("StandingDownwardForceScale"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_StandingDownwardForceScale(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CharacterMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CharacterMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UCharacterMovementComponent::StaticClass(), TEXT("StandingDownwardForceScale"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_InitialPushForceFactor(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CharacterMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CharacterMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UCharacterMovementComponent::StaticClass(), TEXT("InitialPushForceFactor"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_InitialPushForceFactor(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CharacterMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CharacterMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UCharacterMovementComponent::StaticClass(), TEXT("InitialPushForceFactor"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_PushForceFactor(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CharacterMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CharacterMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UCharacterMovementComponent::StaticClass(), TEXT("PushForceFactor"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_PushForceFactor(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CharacterMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CharacterMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UCharacterMovementComponent::StaticClass(), TEXT("PushForceFactor"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_PushForcePointZOffsetFactor(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CharacterMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CharacterMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UCharacterMovementComponent::StaticClass(), TEXT("PushForcePointZOffsetFactor"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_PushForcePointZOffsetFactor(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CharacterMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CharacterMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UCharacterMovementComponent::StaticClass(), TEXT("PushForcePointZOffsetFactor"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_TouchForceFactor(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CharacterMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CharacterMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UCharacterMovementComponent::StaticClass(), TEXT("TouchForceFactor"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_TouchForceFactor(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CharacterMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CharacterMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UCharacterMovementComponent::StaticClass(), TEXT("TouchForceFactor"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_MinTouchForce(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CharacterMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CharacterMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UCharacterMovementComponent::StaticClass(), TEXT("MinTouchForce"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_MinTouchForce(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CharacterMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CharacterMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UCharacterMovementComponent::StaticClass(), TEXT("MinTouchForce"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_MaxTouchForce(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CharacterMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CharacterMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UCharacterMovementComponent::StaticClass(), TEXT("MaxTouchForce"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_MaxTouchForce(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CharacterMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CharacterMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UCharacterMovementComponent::StaticClass(), TEXT("MaxTouchForce"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_RepulsionForce(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CharacterMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CharacterMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UCharacterMovementComponent::StaticClass(), TEXT("RepulsionForce"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_RepulsionForce(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CharacterMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CharacterMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UCharacterMovementComponent::StaticClass(), TEXT("RepulsionForce"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_MaxSimulationTimeStep(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CharacterMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CharacterMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UCharacterMovementComponent::StaticClass(), TEXT("MaxSimulationTimeStep"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_MaxSimulationTimeStep(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CharacterMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CharacterMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UCharacterMovementComponent::StaticClass(), TEXT("MaxSimulationTimeStep"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_MaxSimulationIterations(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CharacterMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CharacterMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UCharacterMovementComponent::StaticClass(), TEXT("MaxSimulationIterations"));
	if(!Property) { check(false); return 0;}
	int32 PropertyValue = int32();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushinteger(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_MaxSimulationIterations(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CharacterMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CharacterMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UCharacterMovementComponent::StaticClass(), TEXT("MaxSimulationIterations"));
	if(!Property) { check(false); return 0;}
	int32 PropertyValue = (luaL_checkint(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_MaxDepenetrationWithGeometry(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CharacterMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CharacterMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UCharacterMovementComponent::StaticClass(), TEXT("MaxDepenetrationWithGeometry"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_MaxDepenetrationWithGeometry(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CharacterMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CharacterMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UCharacterMovementComponent::StaticClass(), TEXT("MaxDepenetrationWithGeometry"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_MaxDepenetrationWithGeometryAsProxy(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CharacterMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CharacterMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UCharacterMovementComponent::StaticClass(), TEXT("MaxDepenetrationWithGeometryAsProxy"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_MaxDepenetrationWithGeometryAsProxy(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CharacterMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CharacterMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UCharacterMovementComponent::StaticClass(), TEXT("MaxDepenetrationWithGeometryAsProxy"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_MaxDepenetrationWithPawn(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CharacterMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CharacterMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UCharacterMovementComponent::StaticClass(), TEXT("MaxDepenetrationWithPawn"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_MaxDepenetrationWithPawn(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CharacterMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CharacterMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UCharacterMovementComponent::StaticClass(), TEXT("MaxDepenetrationWithPawn"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_MaxDepenetrationWithPawnAsProxy(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CharacterMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CharacterMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UCharacterMovementComponent::StaticClass(), TEXT("MaxDepenetrationWithPawnAsProxy"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_MaxDepenetrationWithPawnAsProxy(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CharacterMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CharacterMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UCharacterMovementComponent::StaticClass(), TEXT("MaxDepenetrationWithPawnAsProxy"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_NetworkSimulatedSmoothLocationTime(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CharacterMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CharacterMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UCharacterMovementComponent::StaticClass(), TEXT("NetworkSimulatedSmoothLocationTime"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_NetworkSimulatedSmoothLocationTime(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CharacterMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CharacterMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UCharacterMovementComponent::StaticClass(), TEXT("NetworkSimulatedSmoothLocationTime"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_NetworkSimulatedSmoothRotationTime(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CharacterMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CharacterMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UCharacterMovementComponent::StaticClass(), TEXT("NetworkSimulatedSmoothRotationTime"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_NetworkSimulatedSmoothRotationTime(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CharacterMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CharacterMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UCharacterMovementComponent::StaticClass(), TEXT("NetworkSimulatedSmoothRotationTime"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_ListenServerNetworkSimulatedSmoothLocationTime(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CharacterMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CharacterMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UCharacterMovementComponent::StaticClass(), TEXT("ListenServerNetworkSimulatedSmoothLocationTime"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_ListenServerNetworkSimulatedSmoothLocationTime(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CharacterMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CharacterMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UCharacterMovementComponent::StaticClass(), TEXT("ListenServerNetworkSimulatedSmoothLocationTime"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_ListenServerNetworkSimulatedSmoothRotationTime(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CharacterMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CharacterMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UCharacterMovementComponent::StaticClass(), TEXT("ListenServerNetworkSimulatedSmoothRotationTime"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_ListenServerNetworkSimulatedSmoothRotationTime(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CharacterMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CharacterMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UCharacterMovementComponent::StaticClass(), TEXT("ListenServerNetworkSimulatedSmoothRotationTime"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_NetProxyShrinkRadius(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CharacterMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CharacterMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UCharacterMovementComponent::StaticClass(), TEXT("NetProxyShrinkRadius"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_NetProxyShrinkRadius(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CharacterMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CharacterMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UCharacterMovementComponent::StaticClass(), TEXT("NetProxyShrinkRadius"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_NetProxyShrinkHalfHeight(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CharacterMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CharacterMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UCharacterMovementComponent::StaticClass(), TEXT("NetProxyShrinkHalfHeight"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_NetProxyShrinkHalfHeight(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CharacterMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CharacterMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UCharacterMovementComponent::StaticClass(), TEXT("NetProxyShrinkHalfHeight"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_NetworkMaxSmoothUpdateDistance(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CharacterMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CharacterMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UCharacterMovementComponent::StaticClass(), TEXT("NetworkMaxSmoothUpdateDistance"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_NetworkMaxSmoothUpdateDistance(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CharacterMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CharacterMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UCharacterMovementComponent::StaticClass(), TEXT("NetworkMaxSmoothUpdateDistance"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_NetworkNoSmoothUpdateDistance(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CharacterMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CharacterMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UCharacterMovementComponent::StaticClass(), TEXT("NetworkNoSmoothUpdateDistance"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_NetworkNoSmoothUpdateDistance(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CharacterMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CharacterMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UCharacterMovementComponent::StaticClass(), TEXT("NetworkNoSmoothUpdateDistance"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_NetworkMinTimeBetweenClientAckGoodMoves(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CharacterMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CharacterMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UCharacterMovementComponent::StaticClass(), TEXT("NetworkMinTimeBetweenClientAckGoodMoves"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_NetworkMinTimeBetweenClientAckGoodMoves(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CharacterMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CharacterMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UCharacterMovementComponent::StaticClass(), TEXT("NetworkMinTimeBetweenClientAckGoodMoves"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_NetworkMinTimeBetweenClientAdjustments(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CharacterMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CharacterMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UCharacterMovementComponent::StaticClass(), TEXT("NetworkMinTimeBetweenClientAdjustments"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_NetworkMinTimeBetweenClientAdjustments(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CharacterMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CharacterMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UCharacterMovementComponent::StaticClass(), TEXT("NetworkMinTimeBetweenClientAdjustments"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_NetworkMinTimeBetweenClientAdjustmentsLargeCorrection(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CharacterMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CharacterMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UCharacterMovementComponent::StaticClass(), TEXT("NetworkMinTimeBetweenClientAdjustmentsLargeCorrection"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_NetworkMinTimeBetweenClientAdjustmentsLargeCorrection(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CharacterMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CharacterMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UCharacterMovementComponent::StaticClass(), TEXT("NetworkMinTimeBetweenClientAdjustmentsLargeCorrection"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_NetworkLargeClientCorrectionDistance(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CharacterMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CharacterMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UCharacterMovementComponent::StaticClass(), TEXT("NetworkLargeClientCorrectionDistance"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_NetworkLargeClientCorrectionDistance(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CharacterMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CharacterMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UCharacterMovementComponent::StaticClass(), TEXT("NetworkLargeClientCorrectionDistance"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_LedgeCheckThreshold(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CharacterMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CharacterMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UCharacterMovementComponent::StaticClass(), TEXT("LedgeCheckThreshold"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_LedgeCheckThreshold(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CharacterMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CharacterMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UCharacterMovementComponent::StaticClass(), TEXT("LedgeCheckThreshold"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_JumpOutOfWaterPitch(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CharacterMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CharacterMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UCharacterMovementComponent::StaticClass(), TEXT("JumpOutOfWaterPitch"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_JumpOutOfWaterPitch(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CharacterMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CharacterMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UCharacterMovementComponent::StaticClass(), TEXT("JumpOutOfWaterPitch"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_DefaultLandMovementMode(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CharacterMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CharacterMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UCharacterMovementComponent::StaticClass(), TEXT("DefaultLandMovementMode"));
	if(!Property) { check(false); return 0;}
	TEnumAsByte<EMovementMode> PropertyValue = TEnumAsByte<EMovementMode>();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushinteger(InScriptContext, (int)PropertyValue);
	return 1;
}

int32 Set_DefaultLandMovementMode(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CharacterMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CharacterMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UCharacterMovementComponent::StaticClass(), TEXT("DefaultLandMovementMode"));
	if(!Property) { check(false); return 0;}
	TEnumAsByte<EMovementMode> PropertyValue = (TEnumAsByte<EMovementMode>)(luaL_checkint(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_DefaultWaterMovementMode(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CharacterMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CharacterMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UCharacterMovementComponent::StaticClass(), TEXT("DefaultWaterMovementMode"));
	if(!Property) { check(false); return 0;}
	TEnumAsByte<EMovementMode> PropertyValue = TEnumAsByte<EMovementMode>();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushinteger(InScriptContext, (int)PropertyValue);
	return 1;
}

int32 Set_DefaultWaterMovementMode(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CharacterMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CharacterMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UCharacterMovementComponent::StaticClass(), TEXT("DefaultWaterMovementMode"));
	if(!Property) { check(false); return 0;}
	TEnumAsByte<EMovementMode> PropertyValue = (TEnumAsByte<EMovementMode>)(luaL_checkint(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bMaintainHorizontalGroundVelocity(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CharacterMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CharacterMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UCharacterMovementComponent::StaticClass(), TEXT("bMaintainHorizontalGroundVelocity"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bMaintainHorizontalGroundVelocity(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CharacterMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CharacterMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UCharacterMovementComponent::StaticClass(), TEXT("bMaintainHorizontalGroundVelocity"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bImpartBaseVelocityX(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CharacterMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CharacterMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UCharacterMovementComponent::StaticClass(), TEXT("bImpartBaseVelocityX"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bImpartBaseVelocityX(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CharacterMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CharacterMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UCharacterMovementComponent::StaticClass(), TEXT("bImpartBaseVelocityX"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bImpartBaseVelocityY(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CharacterMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CharacterMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UCharacterMovementComponent::StaticClass(), TEXT("bImpartBaseVelocityY"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bImpartBaseVelocityY(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CharacterMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CharacterMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UCharacterMovementComponent::StaticClass(), TEXT("bImpartBaseVelocityY"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bImpartBaseVelocityZ(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CharacterMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CharacterMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UCharacterMovementComponent::StaticClass(), TEXT("bImpartBaseVelocityZ"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bImpartBaseVelocityZ(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CharacterMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CharacterMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UCharacterMovementComponent::StaticClass(), TEXT("bImpartBaseVelocityZ"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bImpartBaseAngularVelocity(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CharacterMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CharacterMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UCharacterMovementComponent::StaticClass(), TEXT("bImpartBaseAngularVelocity"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bImpartBaseAngularVelocity(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CharacterMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CharacterMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UCharacterMovementComponent::StaticClass(), TEXT("bImpartBaseAngularVelocity"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bJustTeleported(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CharacterMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CharacterMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UCharacterMovementComponent::StaticClass(), TEXT("bJustTeleported"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bJustTeleported(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CharacterMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CharacterMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UCharacterMovementComponent::StaticClass(), TEXT("bJustTeleported"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bIgnoreClientMovementErrorChecksAndCorrection(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CharacterMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CharacterMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UCharacterMovementComponent::StaticClass(), TEXT("bIgnoreClientMovementErrorChecksAndCorrection"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bIgnoreClientMovementErrorChecksAndCorrection(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CharacterMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CharacterMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UCharacterMovementComponent::StaticClass(), TEXT("bIgnoreClientMovementErrorChecksAndCorrection"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bNotifyApex(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CharacterMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CharacterMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UCharacterMovementComponent::StaticClass(), TEXT("bNotifyApex"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bNotifyApex(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CharacterMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CharacterMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UCharacterMovementComponent::StaticClass(), TEXT("bNotifyApex"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bWantsToCrouch(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CharacterMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CharacterMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UCharacterMovementComponent::StaticClass(), TEXT("bWantsToCrouch"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_bCrouchMaintainsBaseLocation(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CharacterMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CharacterMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UCharacterMovementComponent::StaticClass(), TEXT("bCrouchMaintainsBaseLocation"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bCrouchMaintainsBaseLocation(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CharacterMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CharacterMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UCharacterMovementComponent::StaticClass(), TEXT("bCrouchMaintainsBaseLocation"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bIgnoreBaseRotation(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CharacterMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CharacterMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UCharacterMovementComponent::StaticClass(), TEXT("bIgnoreBaseRotation"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bIgnoreBaseRotation(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CharacterMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CharacterMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UCharacterMovementComponent::StaticClass(), TEXT("bIgnoreBaseRotation"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bAlwaysCheckFloor(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CharacterMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CharacterMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UCharacterMovementComponent::StaticClass(), TEXT("bAlwaysCheckFloor"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bAlwaysCheckFloor(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CharacterMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CharacterMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UCharacterMovementComponent::StaticClass(), TEXT("bAlwaysCheckFloor"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bUseFlatBaseForFloorChecks(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CharacterMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CharacterMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UCharacterMovementComponent::StaticClass(), TEXT("bUseFlatBaseForFloorChecks"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bUseFlatBaseForFloorChecks(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CharacterMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CharacterMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UCharacterMovementComponent::StaticClass(), TEXT("bUseFlatBaseForFloorChecks"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bUseRVOAvoidance(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CharacterMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CharacterMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UCharacterMovementComponent::StaticClass(), TEXT("bUseRVOAvoidance"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_bRequestedMoveUseAcceleration(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CharacterMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CharacterMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UCharacterMovementComponent::StaticClass(), TEXT("bRequestedMoveUseAcceleration"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bRequestedMoveUseAcceleration(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CharacterMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CharacterMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UCharacterMovementComponent::StaticClass(), TEXT("bRequestedMoveUseAcceleration"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bAllowPhysicsRotationDuringAnimRootMotion(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CharacterMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CharacterMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UCharacterMovementComponent::StaticClass(), TEXT("bAllowPhysicsRotationDuringAnimRootMotion"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bAllowPhysicsRotationDuringAnimRootMotion(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CharacterMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CharacterMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UCharacterMovementComponent::StaticClass(), TEXT("bAllowPhysicsRotationDuringAnimRootMotion"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bProjectNavMeshWalking(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CharacterMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CharacterMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UCharacterMovementComponent::StaticClass(), TEXT("bProjectNavMeshWalking"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_bProjectNavMeshOnBothWorldChannels(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CharacterMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CharacterMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UCharacterMovementComponent::StaticClass(), TEXT("bProjectNavMeshOnBothWorldChannels"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_AvoidanceConsiderationRadius(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CharacterMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CharacterMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UCharacterMovementComponent::StaticClass(), TEXT("AvoidanceConsiderationRadius"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_AvoidanceUID(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CharacterMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CharacterMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UCharacterMovementComponent::StaticClass(), TEXT("AvoidanceUID"));
	if(!Property) { check(false); return 0;}
	int32 PropertyValue = int32();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushinteger(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_AvoidanceWeight(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CharacterMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CharacterMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UCharacterMovementComponent::StaticClass(), TEXT("AvoidanceWeight"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_NavMeshProjectionInterval(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CharacterMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CharacterMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UCharacterMovementComponent::StaticClass(), TEXT("NavMeshProjectionInterval"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_NavMeshProjectionInterval(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CharacterMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CharacterMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UCharacterMovementComponent::StaticClass(), TEXT("NavMeshProjectionInterval"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_NavMeshProjectionInterpSpeed(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CharacterMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CharacterMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UCharacterMovementComponent::StaticClass(), TEXT("NavMeshProjectionInterpSpeed"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_NavMeshProjectionInterpSpeed(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CharacterMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CharacterMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UCharacterMovementComponent::StaticClass(), TEXT("NavMeshProjectionInterpSpeed"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_NavMeshProjectionHeightScaleUp(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CharacterMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CharacterMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UCharacterMovementComponent::StaticClass(), TEXT("NavMeshProjectionHeightScaleUp"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_NavMeshProjectionHeightScaleUp(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CharacterMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CharacterMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UCharacterMovementComponent::StaticClass(), TEXT("NavMeshProjectionHeightScaleUp"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_NavMeshProjectionHeightScaleDown(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CharacterMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CharacterMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UCharacterMovementComponent::StaticClass(), TEXT("NavMeshProjectionHeightScaleDown"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_NavMeshProjectionHeightScaleDown(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CharacterMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CharacterMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UCharacterMovementComponent::StaticClass(), TEXT("NavMeshProjectionHeightScaleDown"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_NavWalkingFloorDistTolerance(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CharacterMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CharacterMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UCharacterMovementComponent::StaticClass(), TEXT("NavWalkingFloorDistTolerance"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_NavWalkingFloorDistTolerance(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CharacterMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CharacterMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UCharacterMovementComponent::StaticClass(), TEXT("NavWalkingFloorDistTolerance"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 New(lua_State* InScriptContext)
{
	UObject* Outer = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Object");
	FName Name = FName(luaL_checkstring(InScriptContext, 2));
	UObject* Obj = NewObject<UCharacterMovementComponent>(Outer, Name);
	wLua::FLuaUtils::ReturnUObject(InScriptContext,Obj);
	return 1;
}

int32 Destroy(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CharacterMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CharacterMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
		UActorComponent * com = Cast<UActorComponent>(Obj);
		if(lua_isnoneornil(InScriptContext,2))
			com->DestroyComponent();
		else
			com->DestroyComponent(!!lua_toboolean(InScriptContext,2));
		userdata->flag |= wLua::LuaObjectFlag::DESTROYED;
		wLua::FLuaUtils::RemoveObjectReference(Obj, userdata->stamp, InScriptContext);
#ifdef AZURE_BUILD_WLUACHECK
		UE_LOG(LogAzure, Warning, TEXT("Destroy CharacterMovementComponent: %x userdata:%x   stamp:%x"),Obj,userdata,userdata->stamp);
#endif
	return 0;
}

int32 Class(lua_State* InScriptContext)
{
	UClass* Class = UCharacterMovementComponent::StaticClass();
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Class);
	return 1;
}

const luaL_Reg Lib_Funcs[] =
{
	{ "New", New },
	{ "Destroy", Destroy },
	{ "Class", Class },
	{ "SetWalkableFloorZ", SetWalkableFloorZ },
	{ "SetWalkableFloorAngle", SetWalkableFloorAngle },
	{ "SetMovementMode", SetMovementMode },
	{ "SetAvoidanceEnabled", SetAvoidanceEnabled },
	{ "GetWalkableFloorZ", K2_GetWalkableFloorZ },
	{ "GetWalkableFloorAngle", K2_GetWalkableFloorAngle },
	{ "IsWalking", IsWalking },
	{ "GetValidPerchRadius", GetValidPerchRadius },
	{ "GetPerchRadiusThreshold", GetPerchRadiusThreshold },
	{ "GetMovementBase", GetMovementBase },
	{ "GetMinAnalogSpeed", GetMinAnalogSpeed },
	{ "GetMaxJumpHeightWithJumpTime", GetMaxJumpHeightWithJumpTime },
	{ "GetMaxJumpHeight", GetMaxJumpHeight },
	{ "GetMaxBrakingDeceleration", GetMaxBrakingDeceleration },
	{ "GetMaxAcceleration", GetMaxAcceleration },
	{ "GetLastUpdateVelocity", GetLastUpdateVelocity },
	{ "GetLastUpdateRotation", GetLastUpdateRotation },
	{ "GetLastUpdateLocation", GetLastUpdateLocation },
	{ "GetImpartedMovementBaseVelocity", GetImpartedMovementBaseVelocity },
	{ "GetCurrentAcceleration", GetCurrentAcceleration },
	{ "GetCharacterOwner", GetCharacterOwner },
	{ "GetAnalogInputModifier", GetAnalogInputModifier },
	{ "DisableMovement", DisableMovement },
	{ "ClearAccumulatedForces", ClearAccumulatedForces },
	{ "CalcVelocity", CalcVelocity },
	{ "AddImpulse", AddImpulse },
	{ "AddForce", AddForce },
	{ "Get_GravityScale", Get_GravityScale },
	{ "Set_GravityScale", Set_GravityScale },
	{ "Get_MaxStepHeight", Get_MaxStepHeight },
	{ "Set_MaxStepHeight", Set_MaxStepHeight },
	{ "Get_JumpZVelocity", Get_JumpZVelocity },
	{ "Set_JumpZVelocity", Set_JumpZVelocity },
	{ "Get_JumpOffJumpZFactor", Get_JumpOffJumpZFactor },
	{ "Set_JumpOffJumpZFactor", Set_JumpOffJumpZFactor },
	{ "Get_WalkableFloorAngle", Get_WalkableFloorAngle },
	{ "Set_WalkableFloorAngle", Set_WalkableFloorAngle },
	{ "Get_WalkableFloorZ", Get_WalkableFloorZ },
	{ "Set_WalkableFloorZ", Set_WalkableFloorZ },
	{ "Get_MovementMode", Get_MovementMode },
	{ "Get_CustomMovementMode", Get_CustomMovementMode },
	{ "Get_NetworkSmoothingMode", Get_NetworkSmoothingMode },
	{ "Get_GroundFriction", Get_GroundFriction },
	{ "Set_GroundFriction", Set_GroundFriction },
	{ "Get_MaxWalkSpeed", Get_MaxWalkSpeed },
	{ "Set_MaxWalkSpeed", Set_MaxWalkSpeed },
	{ "Get_MaxWalkSpeedCrouched", Get_MaxWalkSpeedCrouched },
	{ "Set_MaxWalkSpeedCrouched", Set_MaxWalkSpeedCrouched },
	{ "Get_MaxSwimSpeed", Get_MaxSwimSpeed },
	{ "Set_MaxSwimSpeed", Set_MaxSwimSpeed },
	{ "Get_MaxFlySpeed", Get_MaxFlySpeed },
	{ "Set_MaxFlySpeed", Set_MaxFlySpeed },
	{ "Get_MaxCustomMovementSpeed", Get_MaxCustomMovementSpeed },
	{ "Set_MaxCustomMovementSpeed", Set_MaxCustomMovementSpeed },
	{ "Get_MaxAcceleration", Get_MaxAcceleration },
	{ "Set_MaxAcceleration", Set_MaxAcceleration },
	{ "Get_MinAnalogWalkSpeed", Get_MinAnalogWalkSpeed },
	{ "Set_MinAnalogWalkSpeed", Set_MinAnalogWalkSpeed },
	{ "Get_BrakingFrictionFactor", Get_BrakingFrictionFactor },
	{ "Set_BrakingFrictionFactor", Set_BrakingFrictionFactor },
	{ "Get_BrakingFriction", Get_BrakingFriction },
	{ "Set_BrakingFriction", Set_BrakingFriction },
	{ "Get_BrakingDecelerationWalking", Get_BrakingDecelerationWalking },
	{ "Set_BrakingDecelerationWalking", Set_BrakingDecelerationWalking },
	{ "Get_BrakingDecelerationFalling", Get_BrakingDecelerationFalling },
	{ "Set_BrakingDecelerationFalling", Set_BrakingDecelerationFalling },
	{ "Get_BrakingDecelerationSwimming", Get_BrakingDecelerationSwimming },
	{ "Set_BrakingDecelerationSwimming", Set_BrakingDecelerationSwimming },
	{ "Get_BrakingDecelerationFlying", Get_BrakingDecelerationFlying },
	{ "Set_BrakingDecelerationFlying", Set_BrakingDecelerationFlying },
	{ "Get_AirControl", Get_AirControl },
	{ "Set_AirControl", Set_AirControl },
	{ "Get_AirControlBoostMultiplier", Get_AirControlBoostMultiplier },
	{ "Set_AirControlBoostMultiplier", Set_AirControlBoostMultiplier },
	{ "Get_AirControlBoostVelocityThreshold", Get_AirControlBoostVelocityThreshold },
	{ "Set_AirControlBoostVelocityThreshold", Set_AirControlBoostVelocityThreshold },
	{ "Get_FallingLateralFriction", Get_FallingLateralFriction },
	{ "Set_FallingLateralFriction", Set_FallingLateralFriction },
	{ "Get_CrouchedHalfHeight", Get_CrouchedHalfHeight },
	{ "Get_Buoyancy", Get_Buoyancy },
	{ "Set_Buoyancy", Set_Buoyancy },
	{ "Get_PerchRadiusThreshold", Get_PerchRadiusThreshold },
	{ "Set_PerchRadiusThreshold", Set_PerchRadiusThreshold },
	{ "Get_PerchAdditionalHeight", Get_PerchAdditionalHeight },
	{ "Set_PerchAdditionalHeight", Set_PerchAdditionalHeight },
	{ "Get_RotationRate", Get_RotationRate },
	{ "Set_RotationRate", Set_RotationRate },
	{ "Get_bUseSeparateBrakingFriction", Get_bUseSeparateBrakingFriction },
	{ "Set_bUseSeparateBrakingFriction", Set_bUseSeparateBrakingFriction },
	{ "Get_bApplyGravityWhileJumping", Get_bApplyGravityWhileJumping },
	{ "Set_bApplyGravityWhileJumping", Set_bApplyGravityWhileJumping },
	{ "Get_bUseControllerDesiredRotation", Get_bUseControllerDesiredRotation },
	{ "Set_bUseControllerDesiredRotation", Set_bUseControllerDesiredRotation },
	{ "Get_bOrientRotationToMovement", Get_bOrientRotationToMovement },
	{ "Set_bOrientRotationToMovement", Set_bOrientRotationToMovement },
	{ "Get_bSweepWhileNavWalking", Get_bSweepWhileNavWalking },
	{ "Set_bSweepWhileNavWalking", Set_bSweepWhileNavWalking },
	{ "Get_bEnableScopedMovementUpdates", Get_bEnableScopedMovementUpdates },
	{ "Set_bEnableScopedMovementUpdates", Set_bEnableScopedMovementUpdates },
	{ "Get_bRunPhysicsWithNoController", Get_bRunPhysicsWithNoController },
	{ "Set_bRunPhysicsWithNoController", Set_bRunPhysicsWithNoController },
	{ "Get_bForceNextFloorCheck", Get_bForceNextFloorCheck },
	{ "Set_bForceNextFloorCheck", Set_bForceNextFloorCheck },
	{ "Get_bCanWalkOffLedges", Get_bCanWalkOffLedges },
	{ "Set_bCanWalkOffLedges", Set_bCanWalkOffLedges },
	{ "Get_bCanWalkOffLedgesWhenCrouching", Get_bCanWalkOffLedgesWhenCrouching },
	{ "Set_bCanWalkOffLedgesWhenCrouching", Set_bCanWalkOffLedgesWhenCrouching },
	{ "Get_bNetworkSkipProxyPredictionOnNetUpdate", Get_bNetworkSkipProxyPredictionOnNetUpdate },
	{ "Set_bNetworkSkipProxyPredictionOnNetUpdate", Set_bNetworkSkipProxyPredictionOnNetUpdate },
	{ "Get_bNetworkAlwaysReplicateTransformUpdateTimestamp", Get_bNetworkAlwaysReplicateTransformUpdateTimestamp },
	{ "Set_bNetworkAlwaysReplicateTransformUpdateTimestamp", Set_bNetworkAlwaysReplicateTransformUpdateTimestamp },
	{ "Get_bEnablePhysicsInteraction", Get_bEnablePhysicsInteraction },
	{ "Set_bEnablePhysicsInteraction", Set_bEnablePhysicsInteraction },
	{ "Get_bTouchForceScaledToMass", Get_bTouchForceScaledToMass },
	{ "Set_bTouchForceScaledToMass", Set_bTouchForceScaledToMass },
	{ "Get_bPushForceScaledToMass", Get_bPushForceScaledToMass },
	{ "Set_bPushForceScaledToMass", Set_bPushForceScaledToMass },
	{ "Get_bPushForceUsingZOffset", Get_bPushForceUsingZOffset },
	{ "Set_bPushForceUsingZOffset", Set_bPushForceUsingZOffset },
	{ "Get_bScalePushForceToVelocity", Get_bScalePushForceToVelocity },
	{ "Set_bScalePushForceToVelocity", Set_bScalePushForceToVelocity },
	{ "Get_MaxOutOfWaterStepHeight", Get_MaxOutOfWaterStepHeight },
	{ "Set_MaxOutOfWaterStepHeight", Set_MaxOutOfWaterStepHeight },
	{ "Get_OutofWaterZ", Get_OutofWaterZ },
	{ "Set_OutofWaterZ", Set_OutofWaterZ },
	{ "Get_Mass", Get_Mass },
	{ "Set_Mass", Set_Mass },
	{ "Get_StandingDownwardForceScale", Get_StandingDownwardForceScale },
	{ "Set_StandingDownwardForceScale", Set_StandingDownwardForceScale },
	{ "Get_InitialPushForceFactor", Get_InitialPushForceFactor },
	{ "Set_InitialPushForceFactor", Set_InitialPushForceFactor },
	{ "Get_PushForceFactor", Get_PushForceFactor },
	{ "Set_PushForceFactor", Set_PushForceFactor },
	{ "Get_PushForcePointZOffsetFactor", Get_PushForcePointZOffsetFactor },
	{ "Set_PushForcePointZOffsetFactor", Set_PushForcePointZOffsetFactor },
	{ "Get_TouchForceFactor", Get_TouchForceFactor },
	{ "Set_TouchForceFactor", Set_TouchForceFactor },
	{ "Get_MinTouchForce", Get_MinTouchForce },
	{ "Set_MinTouchForce", Set_MinTouchForce },
	{ "Get_MaxTouchForce", Get_MaxTouchForce },
	{ "Set_MaxTouchForce", Set_MaxTouchForce },
	{ "Get_RepulsionForce", Get_RepulsionForce },
	{ "Set_RepulsionForce", Set_RepulsionForce },
	{ "Get_MaxSimulationTimeStep", Get_MaxSimulationTimeStep },
	{ "Set_MaxSimulationTimeStep", Set_MaxSimulationTimeStep },
	{ "Get_MaxSimulationIterations", Get_MaxSimulationIterations },
	{ "Set_MaxSimulationIterations", Set_MaxSimulationIterations },
	{ "Get_MaxDepenetrationWithGeometry", Get_MaxDepenetrationWithGeometry },
	{ "Set_MaxDepenetrationWithGeometry", Set_MaxDepenetrationWithGeometry },
	{ "Get_MaxDepenetrationWithGeometryAsProxy", Get_MaxDepenetrationWithGeometryAsProxy },
	{ "Set_MaxDepenetrationWithGeometryAsProxy", Set_MaxDepenetrationWithGeometryAsProxy },
	{ "Get_MaxDepenetrationWithPawn", Get_MaxDepenetrationWithPawn },
	{ "Set_MaxDepenetrationWithPawn", Set_MaxDepenetrationWithPawn },
	{ "Get_MaxDepenetrationWithPawnAsProxy", Get_MaxDepenetrationWithPawnAsProxy },
	{ "Set_MaxDepenetrationWithPawnAsProxy", Set_MaxDepenetrationWithPawnAsProxy },
	{ "Get_NetworkSimulatedSmoothLocationTime", Get_NetworkSimulatedSmoothLocationTime },
	{ "Set_NetworkSimulatedSmoothLocationTime", Set_NetworkSimulatedSmoothLocationTime },
	{ "Get_NetworkSimulatedSmoothRotationTime", Get_NetworkSimulatedSmoothRotationTime },
	{ "Set_NetworkSimulatedSmoothRotationTime", Set_NetworkSimulatedSmoothRotationTime },
	{ "Get_ListenServerNetworkSimulatedSmoothLocationTime", Get_ListenServerNetworkSimulatedSmoothLocationTime },
	{ "Set_ListenServerNetworkSimulatedSmoothLocationTime", Set_ListenServerNetworkSimulatedSmoothLocationTime },
	{ "Get_ListenServerNetworkSimulatedSmoothRotationTime", Get_ListenServerNetworkSimulatedSmoothRotationTime },
	{ "Set_ListenServerNetworkSimulatedSmoothRotationTime", Set_ListenServerNetworkSimulatedSmoothRotationTime },
	{ "Get_NetProxyShrinkRadius", Get_NetProxyShrinkRadius },
	{ "Set_NetProxyShrinkRadius", Set_NetProxyShrinkRadius },
	{ "Get_NetProxyShrinkHalfHeight", Get_NetProxyShrinkHalfHeight },
	{ "Set_NetProxyShrinkHalfHeight", Set_NetProxyShrinkHalfHeight },
	{ "Get_NetworkMaxSmoothUpdateDistance", Get_NetworkMaxSmoothUpdateDistance },
	{ "Set_NetworkMaxSmoothUpdateDistance", Set_NetworkMaxSmoothUpdateDistance },
	{ "Get_NetworkNoSmoothUpdateDistance", Get_NetworkNoSmoothUpdateDistance },
	{ "Set_NetworkNoSmoothUpdateDistance", Set_NetworkNoSmoothUpdateDistance },
	{ "Get_NetworkMinTimeBetweenClientAckGoodMoves", Get_NetworkMinTimeBetweenClientAckGoodMoves },
	{ "Set_NetworkMinTimeBetweenClientAckGoodMoves", Set_NetworkMinTimeBetweenClientAckGoodMoves },
	{ "Get_NetworkMinTimeBetweenClientAdjustments", Get_NetworkMinTimeBetweenClientAdjustments },
	{ "Set_NetworkMinTimeBetweenClientAdjustments", Set_NetworkMinTimeBetweenClientAdjustments },
	{ "Get_NetworkMinTimeBetweenClientAdjustmentsLargeCorrection", Get_NetworkMinTimeBetweenClientAdjustmentsLargeCorrection },
	{ "Set_NetworkMinTimeBetweenClientAdjustmentsLargeCorrection", Set_NetworkMinTimeBetweenClientAdjustmentsLargeCorrection },
	{ "Get_NetworkLargeClientCorrectionDistance", Get_NetworkLargeClientCorrectionDistance },
	{ "Set_NetworkLargeClientCorrectionDistance", Set_NetworkLargeClientCorrectionDistance },
	{ "Get_LedgeCheckThreshold", Get_LedgeCheckThreshold },
	{ "Set_LedgeCheckThreshold", Set_LedgeCheckThreshold },
	{ "Get_JumpOutOfWaterPitch", Get_JumpOutOfWaterPitch },
	{ "Set_JumpOutOfWaterPitch", Set_JumpOutOfWaterPitch },
	{ "Get_DefaultLandMovementMode", Get_DefaultLandMovementMode },
	{ "Set_DefaultLandMovementMode", Set_DefaultLandMovementMode },
	{ "Get_DefaultWaterMovementMode", Get_DefaultWaterMovementMode },
	{ "Set_DefaultWaterMovementMode", Set_DefaultWaterMovementMode },
	{ "Get_bMaintainHorizontalGroundVelocity", Get_bMaintainHorizontalGroundVelocity },
	{ "Set_bMaintainHorizontalGroundVelocity", Set_bMaintainHorizontalGroundVelocity },
	{ "Get_bImpartBaseVelocityX", Get_bImpartBaseVelocityX },
	{ "Set_bImpartBaseVelocityX", Set_bImpartBaseVelocityX },
	{ "Get_bImpartBaseVelocityY", Get_bImpartBaseVelocityY },
	{ "Set_bImpartBaseVelocityY", Set_bImpartBaseVelocityY },
	{ "Get_bImpartBaseVelocityZ", Get_bImpartBaseVelocityZ },
	{ "Set_bImpartBaseVelocityZ", Set_bImpartBaseVelocityZ },
	{ "Get_bImpartBaseAngularVelocity", Get_bImpartBaseAngularVelocity },
	{ "Set_bImpartBaseAngularVelocity", Set_bImpartBaseAngularVelocity },
	{ "Get_bJustTeleported", Get_bJustTeleported },
	{ "Set_bJustTeleported", Set_bJustTeleported },
	{ "Get_bIgnoreClientMovementErrorChecksAndCorrection", Get_bIgnoreClientMovementErrorChecksAndCorrection },
	{ "Set_bIgnoreClientMovementErrorChecksAndCorrection", Set_bIgnoreClientMovementErrorChecksAndCorrection },
	{ "Get_bNotifyApex", Get_bNotifyApex },
	{ "Set_bNotifyApex", Set_bNotifyApex },
	{ "Get_bWantsToCrouch", Get_bWantsToCrouch },
	{ "Get_bCrouchMaintainsBaseLocation", Get_bCrouchMaintainsBaseLocation },
	{ "Set_bCrouchMaintainsBaseLocation", Set_bCrouchMaintainsBaseLocation },
	{ "Get_bIgnoreBaseRotation", Get_bIgnoreBaseRotation },
	{ "Set_bIgnoreBaseRotation", Set_bIgnoreBaseRotation },
	{ "Get_bAlwaysCheckFloor", Get_bAlwaysCheckFloor },
	{ "Set_bAlwaysCheckFloor", Set_bAlwaysCheckFloor },
	{ "Get_bUseFlatBaseForFloorChecks", Get_bUseFlatBaseForFloorChecks },
	{ "Set_bUseFlatBaseForFloorChecks", Set_bUseFlatBaseForFloorChecks },
	{ "Get_bUseRVOAvoidance", Get_bUseRVOAvoidance },
	{ "Get_bRequestedMoveUseAcceleration", Get_bRequestedMoveUseAcceleration },
	{ "Set_bRequestedMoveUseAcceleration", Set_bRequestedMoveUseAcceleration },
	{ "Get_bAllowPhysicsRotationDuringAnimRootMotion", Get_bAllowPhysicsRotationDuringAnimRootMotion },
	{ "Set_bAllowPhysicsRotationDuringAnimRootMotion", Set_bAllowPhysicsRotationDuringAnimRootMotion },
	{ "Get_bProjectNavMeshWalking", Get_bProjectNavMeshWalking },
	{ "Get_bProjectNavMeshOnBothWorldChannels", Get_bProjectNavMeshOnBothWorldChannels },
	{ "Get_AvoidanceConsiderationRadius", Get_AvoidanceConsiderationRadius },
	{ "Get_AvoidanceUID", Get_AvoidanceUID },
	{ "Get_AvoidanceWeight", Get_AvoidanceWeight },
	{ "Get_NavMeshProjectionInterval", Get_NavMeshProjectionInterval },
	{ "Set_NavMeshProjectionInterval", Set_NavMeshProjectionInterval },
	{ "Get_NavMeshProjectionInterpSpeed", Get_NavMeshProjectionInterpSpeed },
	{ "Set_NavMeshProjectionInterpSpeed", Set_NavMeshProjectionInterpSpeed },
	{ "Get_NavMeshProjectionHeightScaleUp", Get_NavMeshProjectionHeightScaleUp },
	{ "Set_NavMeshProjectionHeightScaleUp", Set_NavMeshProjectionHeightScaleUp },
	{ "Get_NavMeshProjectionHeightScaleDown", Get_NavMeshProjectionHeightScaleDown },
	{ "Set_NavMeshProjectionHeightScaleDown", Set_NavMeshProjectionHeightScaleDown },
	{ "Get_NavWalkingFloorDistTolerance", Get_NavWalkingFloorDistTolerance },
	{ "Set_NavWalkingFloorDistTolerance", Set_NavWalkingFloorDistTolerance },
	{ "IsSwimming", IsSwimming },
	{ "GetGravityZ", GetGravityZ },
	{ "IsWalkable", IsWalkable },
	{ "SetDefaultMovementMode", SetDefaultMovementMode },
	{ "is_nil", wLua::LuaStatic::isnil },
	{ "__gc", wLua::LuaStatic::removeUClassFrameCache },
	{ NULL, NULL }
};

void Register(lua_State *InScriptContext)
{
	lua_newtable(InScriptContext);
	luaL_register(InScriptContext, NULL, Lib_Funcs);
	AzureHelpFuncs::AuxRegister(InScriptContext, "CharacterMovementComponent");
}
void SetMtLink(lua_State *InScriptContext)
{
	AzureHelpFuncs::AuxSetMtLink(InScriptContext, "CharacterMovementComponent", "PawnMovementComponent",USERDATATYPE_UOBJECT);
}

}