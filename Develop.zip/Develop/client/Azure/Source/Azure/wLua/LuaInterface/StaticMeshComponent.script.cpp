#include "Azure.h"
#include "Utility/help_funcs.h"
#include "wLua/UObjectHeaders.h"
#include "Components/StaticMeshComponent.h"
#include "AzureLuaIntegration.h"

namespace LuaStaticMeshComponent
{
int32 GetStaticMesh(lua_State*);
int32 QuerySupportedSockets(lua_State*);
int32 GetSocketTransform(lua_State*);
int32 HasAnySockets(lua_State*);
int32 DoesSocketExist(lua_State*);

int32 SetStaticMesh(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"StaticMeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"StaticMeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		UStaticMesh* NewMesh = nullptr;
		bool ReturnValue;
	} Params;
	Params.NewMesh = (UStaticMesh*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"StaticMesh");;
#if UE_GAME
	UStaticMeshComponent * This = (UStaticMeshComponent *)Obj;
	Params.ReturnValue = This->SetStaticMesh(Params.NewMesh);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetStaticMesh"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(UStaticMesh**)(params.GetStructMemory() + 0) = Params.NewMesh;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.NewMesh = *(UStaticMesh**)(params.GetStructMemory() + 0);
		Params.ReturnValue = *(bool*)(params.GetStructMemory() + 8);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushboolean(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 SetReverseCulling(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"StaticMeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"StaticMeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool ReverseCulling;
	} Params;
	Params.ReverseCulling = !!(lua_toboolean(InScriptContext, 2));
#if UE_GAME
	UStaticMeshComponent * This = (UStaticMeshComponent *)Obj;
	This->SetReverseCulling(Params.ReverseCulling);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetReverseCulling"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(bool*)(params.GetStructMemory() + 0) = Params.ReverseCulling;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReverseCulling = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetForcedLodModel(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"StaticMeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"StaticMeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		int32 NewForcedLodModel;
	} Params;
	Params.NewForcedLodModel = (luaL_checkint(InScriptContext, 2));
#if UE_GAME
	UStaticMeshComponent * This = (UStaticMeshComponent *)Obj;
	This->SetForcedLodModel(Params.NewForcedLodModel);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetForcedLodModel"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(int32*)(params.GetStructMemory() + 0) = Params.NewForcedLodModel;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.NewForcedLodModel = *(int32*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetDistanceFieldSelfShadowBias(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"StaticMeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"StaticMeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float NewValue;
	} Params;
	Params.NewValue = (float)(luaL_checknumber(InScriptContext, 2));
#if UE_GAME
	UStaticMeshComponent * This = (UStaticMeshComponent *)Obj;
	This->SetDistanceFieldSelfShadowBias(Params.NewValue);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetDistanceFieldSelfShadowBias"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(float*)(params.GetStructMemory() + 0) = Params.NewValue;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.NewValue = *(float*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 OnRep_StaticMesh(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"StaticMeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"StaticMeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		UStaticMesh* OldStaticMesh = nullptr;
	} Params;
	Params.OldStaticMesh = (UStaticMesh*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"StaticMesh");;
#if UE_GAME
	UStaticMeshComponent * This = (UStaticMeshComponent *)Obj;
	This->OnRep_StaticMesh(Params.OldStaticMesh);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("OnRep_StaticMesh"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(UStaticMesh**)(params.GetStructMemory() + 0) = Params.OldStaticMesh;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.OldStaticMesh = *(UStaticMesh**)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 GetLocalBounds(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"StaticMeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"StaticMeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FVector Min;
		FVector Max;
	} Params;
#if UE_GAME
	UStaticMeshComponent * This = (UStaticMeshComponent *)Obj;
	This->GetLocalBounds(Params.Min,Params.Max);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetLocalBounds"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.Min = *(FVector*)(params.GetStructMemory() + 0);
		Params.Max = *(FVector*)(params.GetStructMemory() + 12);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaVector::Return(InScriptContext, Params.Min);
	wLua::FLuaVector::Return(InScriptContext, Params.Max);
	return 2;
}

int32 Get_ForcedLodModel(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"StaticMeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"StaticMeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UStaticMeshComponent::StaticClass(), TEXT("ForcedLodModel"));
	if(!Property) { check(false); return 0;}
	int32 PropertyValue = int32();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushinteger(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_ForcedShadowLod(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"StaticMeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"StaticMeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UStaticMeshComponent::StaticClass(), TEXT("ForcedShadowLod"));
	if(!Property) { check(false); return 0;}
	int32 PropertyValue = int32();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushinteger(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_ShadowLODBias(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"StaticMeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"StaticMeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UStaticMeshComponent::StaticClass(), TEXT("ShadowLODBias"));
	if(!Property) { check(false); return 0;}
	int32 PropertyValue = int32();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushinteger(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_MinLOD(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"StaticMeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"StaticMeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UStaticMeshComponent::StaticClass(), TEXT("MinLOD"));
	if(!Property) { check(false); return 0;}
	int32 PropertyValue = int32();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushinteger(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_StaticMesh(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"StaticMeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"StaticMeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UStaticMeshComponent::StaticClass(), TEXT("StaticMesh"));
	if(!Property) { check(false); return 0;}
	UStaticMesh* PropertyValue;
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaUtils::ReturnUObject(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_WireframeColorOverride(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"StaticMeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"StaticMeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UStaticMeshComponent::StaticClass(), TEXT("WireframeColorOverride"));
	if(!Property) { check(false); return 0;}
	FColor PropertyValue = FColor();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaLinearColor::Return(InScriptContext, FLinearColor(PropertyValue));
	return 1;
}

int32 Get_bOverrideWireframeColor(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"StaticMeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"StaticMeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UStaticMeshComponent::StaticClass(), TEXT("bOverrideWireframeColor"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_bOverrideMinLOD(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"StaticMeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"StaticMeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UStaticMeshComponent::StaticClass(), TEXT("bOverrideMinLOD"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_bDisallowMeshPaintPerInstance(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"StaticMeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"StaticMeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UStaticMeshComponent::StaticClass(), TEXT("bDisallowMeshPaintPerInstance"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bDisallowMeshPaintPerInstance(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"StaticMeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"StaticMeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UStaticMeshComponent::StaticClass(), TEXT("bDisallowMeshPaintPerInstance"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bIgnoreInstanceForTextureStreaming(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"StaticMeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"StaticMeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UStaticMeshComponent::StaticClass(), TEXT("bIgnoreInstanceForTextureStreaming"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bIgnoreInstanceForTextureStreaming(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"StaticMeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"StaticMeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UStaticMeshComponent::StaticClass(), TEXT("bIgnoreInstanceForTextureStreaming"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bOverrideLightMapRes(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"StaticMeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"StaticMeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UStaticMeshComponent::StaticClass(), TEXT("bOverrideLightMapRes"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_bCastDistanceFieldIndirectShadow(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"StaticMeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"StaticMeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UStaticMeshComponent::StaticClass(), TEXT("bCastDistanceFieldIndirectShadow"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_bOverrideDistanceFieldSelfShadowBias(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"StaticMeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"StaticMeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UStaticMeshComponent::StaticClass(), TEXT("bOverrideDistanceFieldSelfShadowBias"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_bUseDefaultCollision(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"StaticMeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"StaticMeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UStaticMeshComponent::StaticClass(), TEXT("bUseDefaultCollision"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bUseDefaultCollision(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"StaticMeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"StaticMeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UStaticMeshComponent::StaticClass(), TEXT("bUseDefaultCollision"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bReverseCulling(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"StaticMeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"StaticMeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UStaticMeshComponent::StaticClass(), TEXT("bReverseCulling"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_OverriddenLightMapRes(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"StaticMeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"StaticMeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UStaticMeshComponent::StaticClass(), TEXT("OverriddenLightMapRes"));
	if(!Property) { check(false); return 0;}
	int32 PropertyValue = int32();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushinteger(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_DistanceFieldIndirectShadowMinVisibility(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"StaticMeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"StaticMeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UStaticMeshComponent::StaticClass(), TEXT("DistanceFieldIndirectShadowMinVisibility"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_DistanceFieldSelfShadowBias(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"StaticMeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"StaticMeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UStaticMeshComponent::StaticClass(), TEXT("DistanceFieldSelfShadowBias"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_StreamingDistanceMultiplier(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"StaticMeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"StaticMeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UStaticMeshComponent::StaticClass(), TEXT("StreamingDistanceMultiplier"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_StreamingDistanceMultiplier(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"StaticMeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"StaticMeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UStaticMeshComponent::StaticClass(), TEXT("StreamingDistanceMultiplier"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 New(lua_State* InScriptContext)
{
	UObject* Outer = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Object");
	FName Name = FName(luaL_checkstring(InScriptContext, 2));
	UObject* Obj = NewObject<UStaticMeshComponent>(Outer, Name);
	wLua::FLuaUtils::ReturnUObject(InScriptContext,Obj);
	return 1;
}

int32 Destroy(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"StaticMeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"StaticMeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
		UActorComponent * com = Cast<UActorComponent>(Obj);
		if(lua_isnoneornil(InScriptContext,2))
			com->DestroyComponent();
		else
			com->DestroyComponent(!!lua_toboolean(InScriptContext,2));
		userdata->flag |= wLua::LuaObjectFlag::DESTROYED;
		wLua::FLuaUtils::RemoveObjectReference(Obj, userdata->stamp, InScriptContext);
#ifdef AZURE_BUILD_WLUACHECK
		UE_LOG(LogAzure, Warning, TEXT("Destroy StaticMeshComponent: %x userdata:%x   stamp:%x"),Obj,userdata,userdata->stamp);
#endif
	return 0;
}

int32 Class(lua_State* InScriptContext)
{
	UClass* Class = UStaticMeshComponent::StaticClass();
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Class);
	return 1;
}

const luaL_Reg Lib_Funcs[] =
{
	{ "New", New },
	{ "Destroy", Destroy },
	{ "Class", Class },
	{ "SetStaticMesh", SetStaticMesh },
	{ "SetReverseCulling", SetReverseCulling },
	{ "SetForcedLodModel", SetForcedLodModel },
	{ "SetDistanceFieldSelfShadowBias", SetDistanceFieldSelfShadowBias },
	{ "OnRep_StaticMesh", OnRep_StaticMesh },
	{ "GetLocalBounds", GetLocalBounds },
	{ "Get_ForcedLodModel", Get_ForcedLodModel },
	{ "Get_ForcedShadowLod", Get_ForcedShadowLod },
	{ "Get_ShadowLODBias", Get_ShadowLODBias },
	{ "Get_MinLOD", Get_MinLOD },
	{ "Get_StaticMesh", Get_StaticMesh },
	{ "Get_WireframeColorOverride", Get_WireframeColorOverride },
	{ "Get_bOverrideWireframeColor", Get_bOverrideWireframeColor },
	{ "Get_bOverrideMinLOD", Get_bOverrideMinLOD },
	{ "Get_bDisallowMeshPaintPerInstance", Get_bDisallowMeshPaintPerInstance },
	{ "Set_bDisallowMeshPaintPerInstance", Set_bDisallowMeshPaintPerInstance },
	{ "Get_bIgnoreInstanceForTextureStreaming", Get_bIgnoreInstanceForTextureStreaming },
	{ "Set_bIgnoreInstanceForTextureStreaming", Set_bIgnoreInstanceForTextureStreaming },
	{ "Get_bOverrideLightMapRes", Get_bOverrideLightMapRes },
	{ "Get_bCastDistanceFieldIndirectShadow", Get_bCastDistanceFieldIndirectShadow },
	{ "Get_bOverrideDistanceFieldSelfShadowBias", Get_bOverrideDistanceFieldSelfShadowBias },
	{ "Get_bUseDefaultCollision", Get_bUseDefaultCollision },
	{ "Set_bUseDefaultCollision", Set_bUseDefaultCollision },
	{ "Get_bReverseCulling", Get_bReverseCulling },
	{ "Get_OverriddenLightMapRes", Get_OverriddenLightMapRes },
	{ "Get_DistanceFieldIndirectShadowMinVisibility", Get_DistanceFieldIndirectShadowMinVisibility },
	{ "Get_DistanceFieldSelfShadowBias", Get_DistanceFieldSelfShadowBias },
	{ "Get_StreamingDistanceMultiplier", Get_StreamingDistanceMultiplier },
	{ "Set_StreamingDistanceMultiplier", Set_StreamingDistanceMultiplier },
	{ "GetStaticMesh", GetStaticMesh },
	{ "QuerySupportedSockets", QuerySupportedSockets },
	{ "GetSocketTransform", GetSocketTransform },
	{ "HasAnySockets", HasAnySockets },
	{ "DoesSocketExist", DoesSocketExist },
	{ "is_nil", wLua::LuaStatic::isnil },
	{ "__gc", wLua::LuaStatic::removeUClassFrameCache },
	{ NULL, NULL }
};

void Register(lua_State *InScriptContext)
{
	lua_newtable(InScriptContext);
	luaL_register(InScriptContext, NULL, Lib_Funcs);
	AzureHelpFuncs::AuxRegister(InScriptContext, "StaticMeshComponent");
}
void SetMtLink(lua_State *InScriptContext)
{
	AzureHelpFuncs::AuxSetMtLink(InScriptContext, "StaticMeshComponent", "MeshComponent",USERDATATYPE_UOBJECT);
}

}