#include "Azure.h"
#include "Utility/help_funcs.h"
#include "wLua/UObjectHeaders.h"
#include "GameLogic/Player/WheeledVehicleCharacter.h"
#include "../UClassHeaders.h"
#include "AzureLuaIntegration.h"

namespace LuaWheeledVehicleCharacter
{
int32 SetSimulatePhysics(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"WheeledVehicleCharacter",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"WheeledVehicleCharacter must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool b;
	} Params;
	Params.b = !!(lua_toboolean(InScriptContext, 2));
#if UE_GAME
	AWheeledVehicleCharacter * This = (AWheeledVehicleCharacter *)Obj;
	This->SetSimulatePhysics(Params.b);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetSimulatePhysics"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(bool*)(params.GetStructMemory() + 0) = Params.b;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.b = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetEnableGravity(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"WheeledVehicleCharacter",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"WheeledVehicleCharacter must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool b;
	} Params;
	Params.b = !!(lua_toboolean(InScriptContext, 2));
#if UE_GAME
	AWheeledVehicleCharacter * This = (AWheeledVehicleCharacter *)Obj;
	This->SetEnableGravity(Params.b);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetEnableGravity"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(bool*)(params.GetStructMemory() + 0) = Params.b;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.b = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 OnInputMovement(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"WheeledVehicleCharacter",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"WheeledVehicleCharacter must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FVector2D InputMovement;
	} Params;
	Params.InputMovement = (wLua::FLuaVector2D::Get(InScriptContext, 2));
#if UE_GAME
	AWheeledVehicleCharacter * This = (AWheeledVehicleCharacter *)Obj;
	This->OnInputMovement(Params.InputMovement);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("OnInputMovement"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FVector2D*)(params.GetStructMemory() + 0) = Params.InputMovement;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.InputMovement = *(FVector2D*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 IsDrivenByPlayer(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"WheeledVehicleCharacter",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"WheeledVehicleCharacter must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool ReturnValue;
	} Params;
#if UE_GAME
	AWheeledVehicleCharacter * This = (AWheeledVehicleCharacter *)Obj;
	Params.ReturnValue = This->IsDrivenByPlayer();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("IsDrivenByPlayer"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushboolean(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetVehicleMovementComponent(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"WheeledVehicleCharacter",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"WheeledVehicleCharacter must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		UWheeledVehicleMovementComponent* ReturnValue = nullptr;
	} Params;
#if UE_GAME
	AWheeledVehicleCharacter * This = (AWheeledVehicleCharacter *)Obj;
	Params.ReturnValue = This->GetVehicleMovementComponent();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetVehicleMovementComponent"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(UWheeledVehicleMovementComponent**)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetVehicleMovement(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"WheeledVehicleCharacter",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"WheeledVehicleCharacter must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		UWheeledVehicleMovementComponent* ReturnValue = nullptr;
	} Params;
#if UE_GAME
	AWheeledVehicleCharacter * This = (AWheeledVehicleCharacter *)Obj;
	Params.ReturnValue = This->GetVehicleMovement();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetVehicleMovement"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(UWheeledVehicleMovementComponent**)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetMesh(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"WheeledVehicleCharacter",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"WheeledVehicleCharacter must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		USkeletalMeshComponent* ReturnValue = nullptr;
	} Params;
#if UE_GAME
	AWheeledVehicleCharacter * This = (AWheeledVehicleCharacter *)Obj;
	Params.ReturnValue = This->GetMesh();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetMesh"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(USkeletalMeshComponent**)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetDriver(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"WheeledVehicleCharacter",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"WheeledVehicleCharacter must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		APawn* ReturnValue = nullptr;
	} Params;
#if UE_GAME
	AWheeledVehicleCharacter * This = (AWheeledVehicleCharacter *)Obj;
	Params.ReturnValue = This->GetDriver();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetDriver"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(APawn**)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 Get_Mesh(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"WheeledVehicleCharacter",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"WheeledVehicleCharacter must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AWheeledVehicleCharacter::StaticClass(), TEXT("Mesh"));
	if(!Property) { check(false); return 0;}
	USkeletalMeshComponent* PropertyValue;
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaUtils::ReturnUObject(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_VehicleMovement(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"WheeledVehicleCharacter",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"WheeledVehicleCharacter must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AWheeledVehicleCharacter::StaticClass(), TEXT("VehicleMovement"));
	if(!Property) { check(false); return 0;}
	UWheeledVehicleMovementComponent* PropertyValue;
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaUtils::ReturnUObject(InScriptContext, PropertyValue);
	return 1;
}

int32 Class(lua_State* InScriptContext)
{
	UClass* Class = AWheeledVehicleCharacter::StaticClass();
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Class);
	return 1;
}

const luaL_Reg Lib_Funcs[] =
{
	{ "Class", Class },
	{ "SetSimulatePhysics", SetSimulatePhysics },
	{ "SetEnableGravity", SetEnableGravity },
	{ "OnInputMovement", OnInputMovement },
	{ "IsDrivenByPlayer", IsDrivenByPlayer },
	{ "GetVehicleMovementComponent", GetVehicleMovementComponent },
	{ "GetVehicleMovement", GetVehicleMovement },
	{ "GetMesh", GetMesh },
	{ "GetDriver", GetDriver },
	{ "Get_Mesh", Get_Mesh },
	{ "Get_VehicleMovement", Get_VehicleMovement },
	{ "is_nil", wLua::LuaStatic::isnil },
	{ "__gc", wLua::LuaStatic::removeUClassFrameCache },
	{ NULL, NULL }
};

void Register(lua_State *InScriptContext)
{
	lua_newtable(InScriptContext);
	luaL_register(InScriptContext, NULL, Lib_Funcs);
	AzureHelpFuncs::AuxRegister(InScriptContext, "WheeledVehicleCharacter");
}
void SetMtLink(lua_State *InScriptContext)
{
	AzureHelpFuncs::AuxSetMtLink(InScriptContext, "WheeledVehicleCharacter", "Pawn",USERDATATYPE_UOBJECT);
}

}