#include "Azure.h"
#include "Utility/help_funcs.h"
#include "wLua/UObjectHeaders.h"
#include "Blueprint/UserWidget.h"
#include "AzureLuaIntegration.h"

namespace LuaUserWidget
{
int32 SetMsgTable(lua_State*);
int32 CreateWidget(lua_State*);
int32 CreateWidgetWithParent(lua_State*);
int32 CreateWidgetAsync(lua_State*);
int32 FindChild(lua_State*);
int32 GetAnimationByName(lua_State*);
int32 PlayAnimationByName(lua_State*);
int32 PlayAnimationToByName(lua_State*);
int32 PauseAnimationByName(lua_State*);
int32 StopAnimationByName(lua_State*);
int32 RemoveFromParent2(lua_State*);
int32 FindInvalidationBox(lua_State*);
int32 CollectBackButtons(lua_State*);
int32 RemoveAllEventHandlers(lua_State*);

int32 UnregisterInputComponent(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"UserWidget",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"UserWidget must be non-null"); lua_error(InScriptContext);  return 0;}
	UFunction* Function = Obj->FindFunctionChecked(TEXT("UnregisterInputComponent"));
	if(!Function) { check(false); return 0;}
	Obj->ProcessEvent(Function, NULL);
	return 0;
}

int32 StopListeningForInputAction(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"UserWidget",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"UserWidget must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FName ActionName;
		TEnumAsByte<EInputEvent> EventType;
	} Params;
	Params.ActionName = FName(UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 2)));
	Params.EventType = (TEnumAsByte<EInputEvent>)(luaL_checkint(InScriptContext, 3));
	UFunction* Function = Obj->FindFunctionChecked(TEXT("StopListeningForInputAction"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FName*)(params.GetStructMemory() + 0) = Params.ActionName;
		*(TEnumAsByte<EInputEvent>*)(params.GetStructMemory() + 12) = Params.EventType;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ActionName = *(FName*)(params.GetStructMemory() + 0);
		Params.EventType = *(TEnumAsByte<EInputEvent>*)(params.GetStructMemory() + 12);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
	return 0;
}

int32 StopListeningForAllInputActions(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"UserWidget",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"UserWidget must be non-null"); lua_error(InScriptContext);  return 0;}
	UFunction* Function = Obj->FindFunctionChecked(TEXT("StopListeningForAllInputActions"));
	if(!Function) { check(false); return 0;}
	Obj->ProcessEvent(Function, NULL);
	return 0;
}

int32 StopAnimationsAndLatentActions(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"UserWidget",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"UserWidget must be non-null"); lua_error(InScriptContext);  return 0;}
#if UE_GAME
	UUserWidget * This = (UUserWidget *)Obj;
	This->StopAnimationsAndLatentActions();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("StopAnimationsAndLatentActions"));
	if(!Function) { check(false); return 0;}
	Obj->ProcessEvent(Function, NULL);
#endif
	return 0;
}

int32 StopAnimation(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"UserWidget",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"UserWidget must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		UWidgetAnimation* InAnimation = nullptr;
	} Params;
	Params.InAnimation = (UWidgetAnimation*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"WidgetAnimation");;
#if UE_GAME
	UUserWidget * This = (UUserWidget *)Obj;
	This->StopAnimation(Params.InAnimation);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("StopAnimation"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(UWidgetAnimation**)(params.GetStructMemory() + 0) = Params.InAnimation;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.InAnimation = *(UWidgetAnimation**)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 StopAllAnimations(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"UserWidget",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"UserWidget must be non-null"); lua_error(InScriptContext);  return 0;}
#if UE_GAME
	UUserWidget * This = (UUserWidget *)Obj;
	This->StopAllAnimations();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("StopAllAnimations"));
	if(!Function) { check(false); return 0;}
	Obj->ProcessEvent(Function, NULL);
#endif
	return 0;
}

int32 SetScene3D(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"UserWidget",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"UserWidget must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool InScene3D;
	} Params;
	Params.InScene3D = !!(lua_toboolean(InScriptContext, 2));
#if UE_GAME
	UUserWidget * This = (UUserWidget *)Obj;
	This->SetScene3D(Params.InScene3D);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetScene3D"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(bool*)(params.GetStructMemory() + 0) = Params.InScene3D;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.InScene3D = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetPositionInViewport(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"UserWidget",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"UserWidget must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FVector2D Position;
		bool bRemoveDPIScale;
	} Params;
	Params.Position = (wLua::FLuaVector2D::Get(InScriptContext, 2));
	Params.bRemoveDPIScale = lua_isnoneornil(InScriptContext,3) ? bool(true) : !!(lua_toboolean(InScriptContext, 3));
#if UE_GAME
	UUserWidget * This = (UUserWidget *)Obj;
	This->SetPositionInViewport(Params.Position,Params.bRemoveDPIScale);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetPositionInViewport"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FVector2D*)(params.GetStructMemory() + 0) = Params.Position;
		*(bool*)(params.GetStructMemory() + 8) = Params.bRemoveDPIScale;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.Position = *(FVector2D*)(params.GetStructMemory() + 0);
		Params.bRemoveDPIScale = *(bool*)(params.GetStructMemory() + 8);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetPlaybackSpeed(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"UserWidget",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"UserWidget must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		UWidgetAnimation* InAnimation = nullptr;
		float PlaybackSpeed;
	} Params;
	Params.InAnimation = (UWidgetAnimation*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"WidgetAnimation");;
	Params.PlaybackSpeed = lua_isnoneornil(InScriptContext,3) ? float(1.000000) : (float)(luaL_checknumber(InScriptContext, 3));
#if UE_GAME
	UUserWidget * This = (UUserWidget *)Obj;
	This->SetPlaybackSpeed(Params.InAnimation,Params.PlaybackSpeed);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetPlaybackSpeed"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(UWidgetAnimation**)(params.GetStructMemory() + 0) = Params.InAnimation;
		*(float*)(params.GetStructMemory() + 8) = Params.PlaybackSpeed;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.InAnimation = *(UWidgetAnimation**)(params.GetStructMemory() + 0);
		Params.PlaybackSpeed = *(float*)(params.GetStructMemory() + 8);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetOwningPlayer(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"UserWidget",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"UserWidget must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		APlayerController* LocalPlayerController = nullptr;
	} Params;
	Params.LocalPlayerController = (APlayerController*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"PlayerController");;
#if UE_GAME
	UUserWidget * This = (UUserWidget *)Obj;
	This->SetOwningPlayer(Params.LocalPlayerController);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetOwningPlayer"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(APlayerController**)(params.GetStructMemory() + 0) = Params.LocalPlayerController;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.LocalPlayerController = *(APlayerController**)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetNumLoopsToPlay(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"UserWidget",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"UserWidget must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		UWidgetAnimation* InAnimation = nullptr;
		int32 NumLoopsToPlay;
	} Params;
	Params.InAnimation = (UWidgetAnimation*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"WidgetAnimation");;
	Params.NumLoopsToPlay = (luaL_checkint(InScriptContext, 3));
#if UE_GAME
	UUserWidget * This = (UUserWidget *)Obj;
	This->SetNumLoopsToPlay(Params.InAnimation,Params.NumLoopsToPlay);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetNumLoopsToPlay"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(UWidgetAnimation**)(params.GetStructMemory() + 0) = Params.InAnimation;
		*(int32*)(params.GetStructMemory() + 8) = Params.NumLoopsToPlay;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.InAnimation = *(UWidgetAnimation**)(params.GetStructMemory() + 0);
		Params.NumLoopsToPlay = *(int32*)(params.GetStructMemory() + 8);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetNoCover(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"UserWidget",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"UserWidget must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool InNoCover;
	} Params;
	Params.InNoCover = !!(lua_toboolean(InScriptContext, 2));
#if UE_GAME
	UUserWidget * This = (UUserWidget *)Obj;
	This->SetNoCover(Params.InNoCover);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetNoCover"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(bool*)(params.GetStructMemory() + 0) = Params.InNoCover;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.InNoCover = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetInputActionPriority(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"UserWidget",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"UserWidget must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		int32 NewPriority;
	} Params;
	Params.NewPriority = (luaL_checkint(InScriptContext, 2));
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetInputActionPriority"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(int32*)(params.GetStructMemory() + 0) = Params.NewPriority;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.NewPriority = *(int32*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
	return 0;
}

int32 SetInputActionBlocking(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"UserWidget",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"UserWidget must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool bShouldBlock;
	} Params;
	Params.bShouldBlock = !!(lua_toboolean(InScriptContext, 2));
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetInputActionBlocking"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(bool*)(params.GetStructMemory() + 0) = Params.bShouldBlock;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.bShouldBlock = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
	return 0;
}

int32 SetDesiredSizeInViewport(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"UserWidget",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"UserWidget must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FVector2D Size;
	} Params;
	Params.Size = (wLua::FLuaVector2D::Get(InScriptContext, 2));
#if UE_GAME
	UUserWidget * This = (UUserWidget *)Obj;
	This->SetDesiredSizeInViewport(Params.Size);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetDesiredSizeInViewport"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FVector2D*)(params.GetStructMemory() + 0) = Params.Size;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.Size = *(FVector2D*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetDepth(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"UserWidget",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"UserWidget must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float InDepth;
	} Params;
	Params.InDepth = (float)(luaL_checknumber(InScriptContext, 2));
#if UE_GAME
	UUserWidget * This = (UUserWidget *)Obj;
	This->SetDepth(Params.InDepth);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetDepth"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(float*)(params.GetStructMemory() + 0) = Params.InDepth;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.InDepth = *(float*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetColorAndOpacity(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"UserWidget",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"UserWidget must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FLinearColor InColorAndOpacity;
	} Params;
	Params.InColorAndOpacity = (wLua::FLuaLinearColor::Get(InScriptContext, 2));
#if UE_GAME
	UUserWidget * This = (UUserWidget *)Obj;
	This->SetColorAndOpacity(Params.InColorAndOpacity);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetColorAndOpacity"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FLinearColor*)(params.GetStructMemory() + 0) = Params.InColorAndOpacity;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.InColorAndOpacity = *(FLinearColor*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetAnchorsInViewport(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"UserWidget",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"UserWidget must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FAnchors Anchors;
	} Params;
	Params.Anchors = (wLua::FLuaAnchors::Get(InScriptContext, 2));
#if UE_GAME
	UUserWidget * This = (UUserWidget *)Obj;
	This->SetAnchorsInViewport(Params.Anchors);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetAnchorsInViewport"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FAnchors*)(params.GetStructMemory() + 0) = Params.Anchors;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.Anchors = *(FAnchors*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetAlignmentInViewport(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"UserWidget",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"UserWidget must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FVector2D Alignment;
	} Params;
	Params.Alignment = (wLua::FLuaVector2D::Get(InScriptContext, 2));
#if UE_GAME
	UUserWidget * This = (UUserWidget *)Obj;
	This->SetAlignmentInViewport(Params.Alignment);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetAlignmentInViewport"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FVector2D*)(params.GetStructMemory() + 0) = Params.Alignment;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.Alignment = *(FVector2D*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 ReverseAnimation(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"UserWidget",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"UserWidget must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		UWidgetAnimation* InAnimation = nullptr;
	} Params;
	Params.InAnimation = (UWidgetAnimation*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"WidgetAnimation");;
#if UE_GAME
	UUserWidget * This = (UUserWidget *)Obj;
	This->ReverseAnimation(Params.InAnimation);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("ReverseAnimation"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(UWidgetAnimation**)(params.GetStructMemory() + 0) = Params.InAnimation;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.InAnimation = *(UWidgetAnimation**)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 RegisterInputComponent(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"UserWidget",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"UserWidget must be non-null"); lua_error(InScriptContext);  return 0;}
	UFunction* Function = Obj->FindFunctionChecked(TEXT("RegisterInputComponent"));
	if(!Function) { check(false); return 0;}
	Obj->ProcessEvent(Function, NULL);
	return 0;
}

int32 PreConstruct(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"UserWidget",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"UserWidget must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool IsDesignTime;
	} Params;
	Params.IsDesignTime = !!(lua_toboolean(InScriptContext, 2));
#if UE_GAME
	UUserWidget * This = (UUserWidget *)Obj;
	This->PreConstruct(Params.IsDesignTime);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("PreConstruct"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(bool*)(params.GetStructMemory() + 0) = Params.IsDesignTime;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.IsDesignTime = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 PlayAnimationTo(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"UserWidget",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"UserWidget must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		UWidgetAnimation* InAnimation = nullptr;
		float StartAtTime;
		float EndAtTime;
		int32 NumLoopsToPlay;
		TEnumAsByte<EUMGSequencePlayMode::Type> PlayMode;
		float PlaybackSpeed;
	} Params;
	Params.InAnimation = (UWidgetAnimation*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"WidgetAnimation");;
	Params.StartAtTime = lua_isnoneornil(InScriptContext,3) ? float(0.000000) : (float)(luaL_checknumber(InScriptContext, 3));
	Params.EndAtTime = lua_isnoneornil(InScriptContext,4) ? float(0.000000) : (float)(luaL_checknumber(InScriptContext, 4));
	Params.NumLoopsToPlay = lua_isnoneornil(InScriptContext,5) ? int32(1) : (luaL_checkint(InScriptContext, 5));
	Params.PlayMode = lua_isnoneornil(InScriptContext,6) ? TEnumAsByte<EUMGSequencePlayMode::Type>(EUMGSequencePlayMode::Type::Forward) : (TEnumAsByte<EUMGSequencePlayMode::Type>)(luaL_checkint(InScriptContext, 6));
	Params.PlaybackSpeed = lua_isnoneornil(InScriptContext,7) ? float(1.000000) : (float)(luaL_checknumber(InScriptContext, 7));
#if UE_GAME
	UUserWidget * This = (UUserWidget *)Obj;
	This->PlayAnimationTo(Params.InAnimation,Params.StartAtTime,Params.EndAtTime,Params.NumLoopsToPlay,Params.PlayMode,Params.PlaybackSpeed);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("PlayAnimationTo"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(UWidgetAnimation**)(params.GetStructMemory() + 0) = Params.InAnimation;
		*(float*)(params.GetStructMemory() + 8) = Params.StartAtTime;
		*(float*)(params.GetStructMemory() + 12) = Params.EndAtTime;
		*(int32*)(params.GetStructMemory() + 16) = Params.NumLoopsToPlay;
		*(TEnumAsByte<EUMGSequencePlayMode::Type>*)(params.GetStructMemory() + 20) = Params.PlayMode;
		*(float*)(params.GetStructMemory() + 24) = Params.PlaybackSpeed;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.InAnimation = *(UWidgetAnimation**)(params.GetStructMemory() + 0);
		Params.StartAtTime = *(float*)(params.GetStructMemory() + 8);
		Params.EndAtTime = *(float*)(params.GetStructMemory() + 12);
		Params.NumLoopsToPlay = *(int32*)(params.GetStructMemory() + 16);
		Params.PlayMode = *(TEnumAsByte<EUMGSequencePlayMode::Type>*)(params.GetStructMemory() + 20);
		Params.PlaybackSpeed = *(float*)(params.GetStructMemory() + 24);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 PlayAnimation(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"UserWidget",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"UserWidget must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		UWidgetAnimation* InAnimation = nullptr;
		float StartAtTime;
		int32 NumLoopsToPlay;
		TEnumAsByte<EUMGSequencePlayMode::Type> PlayMode;
		float PlaybackSpeed;
	} Params;
	Params.InAnimation = (UWidgetAnimation*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"WidgetAnimation");;
	Params.StartAtTime = lua_isnoneornil(InScriptContext,3) ? float(0.000000) : (float)(luaL_checknumber(InScriptContext, 3));
	Params.NumLoopsToPlay = lua_isnoneornil(InScriptContext,4) ? int32(1) : (luaL_checkint(InScriptContext, 4));
	Params.PlayMode = lua_isnoneornil(InScriptContext,5) ? TEnumAsByte<EUMGSequencePlayMode::Type>(EUMGSequencePlayMode::Type::Forward) : (TEnumAsByte<EUMGSequencePlayMode::Type>)(luaL_checkint(InScriptContext, 5));
	Params.PlaybackSpeed = lua_isnoneornil(InScriptContext,6) ? float(1.000000) : (float)(luaL_checknumber(InScriptContext, 6));
#if UE_GAME
	UUserWidget * This = (UUserWidget *)Obj;
	This->PlayAnimation(Params.InAnimation,Params.StartAtTime,Params.NumLoopsToPlay,Params.PlayMode,Params.PlaybackSpeed);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("PlayAnimation"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(UWidgetAnimation**)(params.GetStructMemory() + 0) = Params.InAnimation;
		*(float*)(params.GetStructMemory() + 8) = Params.StartAtTime;
		*(int32*)(params.GetStructMemory() + 12) = Params.NumLoopsToPlay;
		*(TEnumAsByte<EUMGSequencePlayMode::Type>*)(params.GetStructMemory() + 16) = Params.PlayMode;
		*(float*)(params.GetStructMemory() + 20) = Params.PlaybackSpeed;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.InAnimation = *(UWidgetAnimation**)(params.GetStructMemory() + 0);
		Params.StartAtTime = *(float*)(params.GetStructMemory() + 8);
		Params.NumLoopsToPlay = *(int32*)(params.GetStructMemory() + 12);
		Params.PlayMode = *(TEnumAsByte<EUMGSequencePlayMode::Type>*)(params.GetStructMemory() + 16);
		Params.PlaybackSpeed = *(float*)(params.GetStructMemory() + 20);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 PauseAnimation(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"UserWidget",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"UserWidget must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		UWidgetAnimation* InAnimation = nullptr;
		float ReturnValue;
	} Params;
	Params.InAnimation = (UWidgetAnimation*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"WidgetAnimation");;
#if UE_GAME
	UUserWidget * This = (UUserWidget *)Obj;
	Params.ReturnValue = This->PauseAnimation(Params.InAnimation);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("PauseAnimation"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(UWidgetAnimation**)(params.GetStructMemory() + 0) = Params.InAnimation;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.InAnimation = *(UWidgetAnimation**)(params.GetStructMemory() + 0);
		Params.ReturnValue = *(float*)(params.GetStructMemory() + 8);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushnumber(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 OnVisibilityChange(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"UserWidget",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"UserWidget must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		ESlateVisibility oldVisibility;
		ESlateVisibility newVisibility;
	} Params;
	Params.oldVisibility = (ESlateVisibility)(luaL_checkint(InScriptContext, 2));
	Params.newVisibility = (ESlateVisibility)(luaL_checkint(InScriptContext, 3));
#if UE_GAME
	UUserWidget * This = (UUserWidget *)Obj;
	This->OnVisibilityChange(Params.oldVisibility,Params.newVisibility);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("OnVisibilityChange"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(ESlateVisibility*)(params.GetStructMemory() + 0) = Params.oldVisibility;
		*(ESlateVisibility*)(params.GetStructMemory() + 1) = Params.newVisibility;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.oldVisibility = *(ESlateVisibility*)(params.GetStructMemory() + 0);
		Params.newVisibility = *(ESlateVisibility*)(params.GetStructMemory() + 1);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 OnUnhovered(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"UserWidget",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"UserWidget must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		UWidget* widget = nullptr;
	} Params;
	Params.widget = (UWidget*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"Widget");;
#if UE_GAME
	UUserWidget * This = (UUserWidget *)Obj;
	This->OnUnhovered(Params.widget);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("OnUnhovered"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(UWidget**)(params.GetStructMemory() + 0) = Params.widget;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.widget = *(UWidget**)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 OnTextCommitted(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"UserWidget",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"UserWidget must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		UWidget* widget = nullptr;
		FText InText;
		TEnumAsByte<ETextCommit::Type> CommitMethod;
	} Params;
	Params.widget = (UWidget*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"Widget");;
	Params.InText = FText::FromString(UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 3)));
	Params.CommitMethod = (TEnumAsByte<ETextCommit::Type>)(luaL_checkint(InScriptContext, 4));
#if UE_GAME
	UUserWidget * This = (UUserWidget *)Obj;
	This->OnTextCommitted(Params.widget,Params.InText,Params.CommitMethod);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("OnTextCommitted"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(UWidget**)(params.GetStructMemory() + 0) = Params.widget;
		*(FText*)(params.GetStructMemory() + 8) = Params.InText;
		*(TEnumAsByte<ETextCommit::Type>*)(params.GetStructMemory() + 32) = Params.CommitMethod;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.widget = *(UWidget**)(params.GetStructMemory() + 0);
		Params.InText = *(FText*)(params.GetStructMemory() + 8);
		Params.CommitMethod = *(TEnumAsByte<ETextCommit::Type>*)(params.GetStructMemory() + 32);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 OnTextChanged(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"UserWidget",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"UserWidget must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		UWidget* widget = nullptr;
		FText InText;
	} Params;
	Params.widget = (UWidget*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"Widget");;
	Params.InText = FText::FromString(UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 3)));
#if UE_GAME
	UUserWidget * This = (UUserWidget *)Obj;
	This->OnTextChanged(Params.widget,Params.InText);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("OnTextChanged"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(UWidget**)(params.GetStructMemory() + 0) = Params.widget;
		*(FText*)(params.GetStructMemory() + 8) = Params.InText;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.widget = *(UWidget**)(params.GetStructMemory() + 0);
		Params.InText = *(FText*)(params.GetStructMemory() + 8);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 OnScroll(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"UserWidget",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"UserWidget must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		UWidget* widget = nullptr;
	} Params;
	Params.widget = (UWidget*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"Widget");;
#if UE_GAME
	UUserWidget * This = (UUserWidget *)Obj;
	This->OnScroll(Params.widget);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("OnScroll"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(UWidget**)(params.GetStructMemory() + 0) = Params.widget;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.widget = *(UWidget**)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 OnReleased(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"UserWidget",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"UserWidget must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		UWidget* widget = nullptr;
	} Params;
	Params.widget = (UWidget*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"Widget");;
#if UE_GAME
	UUserWidget * This = (UUserWidget *)Obj;
	This->OnReleased(Params.widget);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("OnReleased"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(UWidget**)(params.GetStructMemory() + 0) = Params.widget;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.widget = *(UWidget**)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 OnPressed(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"UserWidget",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"UserWidget must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		UWidget* widget = nullptr;
	} Params;
	Params.widget = (UWidget*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"Widget");;
#if UE_GAME
	UUserWidget * This = (UUserWidget *)Obj;
	This->OnPressed(Params.widget);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("OnPressed"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(UWidget**)(params.GetStructMemory() + 0) = Params.widget;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.widget = *(UWidget**)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 OnMouseCaptureLost(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"UserWidget",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"UserWidget must be non-null"); lua_error(InScriptContext);  return 0;}
#if UE_GAME
	UUserWidget * This = (UUserWidget *)Obj;
	This->OnMouseCaptureLost();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("OnMouseCaptureLost"));
	if(!Function) { check(false); return 0;}
	Obj->ProcessEvent(Function, NULL);
#endif
	return 0;
}

int32 OnInitialized(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"UserWidget",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"UserWidget must be non-null"); lua_error(InScriptContext);  return 0;}
#if UE_GAME
	UUserWidget * This = (UUserWidget *)Obj;
	This->OnInitialized();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("OnInitialized"));
	if(!Function) { check(false); return 0;}
	Obj->ProcessEvent(Function, NULL);
#endif
	return 0;
}

int32 OnHovered(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"UserWidget",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"UserWidget must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		UWidget* widget = nullptr;
	} Params;
	Params.widget = (UWidget*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"Widget");;
#if UE_GAME
	UUserWidget * This = (UUserWidget *)Obj;
	This->OnHovered(Params.widget);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("OnHovered"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(UWidget**)(params.GetStructMemory() + 0) = Params.widget;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.widget = *(UWidget**)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 OnFocusChange(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"UserWidget",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"UserWidget must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		UWidget* widget = nullptr;
		bool bFocus;
	} Params;
	Params.widget = (UWidget*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"Widget");;
	Params.bFocus = !!(lua_toboolean(InScriptContext, 3));
#if UE_GAME
	UUserWidget * This = (UUserWidget *)Obj;
	This->OnFocusChange(Params.widget,Params.bFocus);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("OnFocusChange"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(UWidget**)(params.GetStructMemory() + 0) = Params.widget;
		*(bool*)(params.GetStructMemory() + 8) = Params.bFocus;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.widget = *(UWidget**)(params.GetStructMemory() + 0);
		Params.bFocus = *(bool*)(params.GetStructMemory() + 8);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 OnFetchFromCache(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"UserWidget",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"UserWidget must be non-null"); lua_error(InScriptContext);  return 0;}
#if UE_GAME
	UUserWidget * This = (UUserWidget *)Obj;
	This->OnFetchFromCache();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("OnFetchFromCache"));
	if(!Function) { check(false); return 0;}
	Obj->ProcessEvent(Function, NULL);
#endif
	return 0;
}

int32 OnClicked(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"UserWidget",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"UserWidget must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		UWidget* widget = nullptr;
	} Params;
	Params.widget = (UWidget*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"Widget");;
#if UE_GAME
	UUserWidget * This = (UUserWidget *)Obj;
	This->OnClicked(Params.widget);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("OnClicked"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(UWidget**)(params.GetStructMemory() + 0) = Params.widget;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.widget = *(UWidget**)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 OnChildVisibilityChange(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"UserWidget",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"UserWidget must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		UWidget* childWidget = nullptr;
		ESlateVisibility oldVisibility;
		ESlateVisibility newVisibility;
	} Params;
	Params.childWidget = (UWidget*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"Widget");;
	Params.oldVisibility = (ESlateVisibility)(luaL_checkint(InScriptContext, 3));
	Params.newVisibility = (ESlateVisibility)(luaL_checkint(InScriptContext, 4));
#if UE_GAME
	UUserWidget * This = (UUserWidget *)Obj;
	This->OnChildVisibilityChange(Params.childWidget,Params.oldVisibility,Params.newVisibility);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("OnChildVisibilityChange"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(UWidget**)(params.GetStructMemory() + 0) = Params.childWidget;
		*(ESlateVisibility*)(params.GetStructMemory() + 8) = Params.oldVisibility;
		*(ESlateVisibility*)(params.GetStructMemory() + 9) = Params.newVisibility;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.childWidget = *(UWidget**)(params.GetStructMemory() + 0);
		Params.oldVisibility = *(ESlateVisibility*)(params.GetStructMemory() + 8);
		Params.newVisibility = *(ESlateVisibility*)(params.GetStructMemory() + 9);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 OnChecked(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"UserWidget",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"UserWidget must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		UCheckBox* widget = nullptr;
		ECheckBoxState NewState;
	} Params;
	Params.widget = (UCheckBox*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"CheckBox");;
	Params.NewState = (ECheckBoxState)(luaL_checkint(InScriptContext, 3));
#if UE_GAME
	UUserWidget * This = (UUserWidget *)Obj;
	This->OnChecked(Params.widget,Params.NewState);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("OnChecked"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(UCheckBox**)(params.GetStructMemory() + 0) = Params.widget;
		*(ECheckBoxState*)(params.GetStructMemory() + 8) = Params.NewState;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.widget = *(UCheckBox**)(params.GetStructMemory() + 0);
		Params.NewState = *(ECheckBoxState*)(params.GetStructMemory() + 8);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 OnAnimationStarted(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"UserWidget",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"UserWidget must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		UWidgetAnimation* Animation = nullptr;
	} Params;
	Params.Animation = (UWidgetAnimation*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"WidgetAnimation");;
#if UE_GAME
	UUserWidget * This = (UUserWidget *)Obj;
	This->OnAnimationStarted(Params.Animation);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("OnAnimationStarted"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(UWidgetAnimation**)(params.GetStructMemory() + 0) = Params.Animation;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.Animation = *(UWidgetAnimation**)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 OnAnimationFinished(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"UserWidget",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"UserWidget must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		UWidgetAnimation* Animation = nullptr;
	} Params;
	Params.Animation = (UWidgetAnimation*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"WidgetAnimation");;
#if UE_GAME
	UUserWidget * This = (UUserWidget *)Obj;
	This->OnAnimationFinished(Params.Animation);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("OnAnimationFinished"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(UWidgetAnimation**)(params.GetStructMemory() + 0) = Params.Animation;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.Animation = *(UWidgetAnimation**)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 IsPlayingAnimation(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"UserWidget",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"UserWidget must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool ReturnValue;
	} Params;
#if UE_GAME
	UUserWidget * This = (UUserWidget *)Obj;
	Params.ReturnValue = This->IsPlayingAnimation();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("IsPlayingAnimation"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushboolean(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 IsListeningForInputAction(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"UserWidget",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"UserWidget must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FName ActionName;
		bool ReturnValue;
	} Params;
	Params.ActionName = FName(UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 2)));
	UFunction* Function = Obj->FindFunctionChecked(TEXT("IsListeningForInputAction"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FName*)(params.GetStructMemory() + 0) = Params.ActionName;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ActionName = *(FName*)(params.GetStructMemory() + 0);
		Params.ReturnValue = *(bool*)(params.GetStructMemory() + 12);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
	lua_pushboolean(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 IsInViewport(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"UserWidget",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"UserWidget must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool ReturnValue;
	} Params;
#if UE_GAME
	UUserWidget * This = (UUserWidget *)Obj;
	Params.ReturnValue = This->IsInViewport();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("IsInViewport"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushboolean(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 IsInteractable(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"UserWidget",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"UserWidget must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool ReturnValue;
	} Params;
#if UE_GAME
	UUserWidget * This = (UUserWidget *)Obj;
	Params.ReturnValue = This->IsInteractable();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("IsInteractable"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushboolean(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 IsAnyAnimationPlaying(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"UserWidget",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"UserWidget must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool ReturnValue;
	} Params;
#if UE_GAME
	UUserWidget * This = (UUserWidget *)Obj;
	Params.ReturnValue = This->IsAnyAnimationPlaying();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("IsAnyAnimationPlaying"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushboolean(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 IsAnimationPlayingForward(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"UserWidget",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"UserWidget must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		UWidgetAnimation* InAnimation = nullptr;
		bool ReturnValue;
	} Params;
	Params.InAnimation = (UWidgetAnimation*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"WidgetAnimation");;
#if UE_GAME
	UUserWidget * This = (UUserWidget *)Obj;
	Params.ReturnValue = This->IsAnimationPlayingForward(Params.InAnimation);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("IsAnimationPlayingForward"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(UWidgetAnimation**)(params.GetStructMemory() + 0) = Params.InAnimation;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.InAnimation = *(UWidgetAnimation**)(params.GetStructMemory() + 0);
		Params.ReturnValue = *(bool*)(params.GetStructMemory() + 8);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushboolean(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 IsAnimationPlaying(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"UserWidget",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"UserWidget must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		UWidgetAnimation* InAnimation = nullptr;
		bool ReturnValue;
	} Params;
	Params.InAnimation = (UWidgetAnimation*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"WidgetAnimation");;
#if UE_GAME
	UUserWidget * This = (UUserWidget *)Obj;
	Params.ReturnValue = This->IsAnimationPlaying(Params.InAnimation);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("IsAnimationPlaying"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(UWidgetAnimation**)(params.GetStructMemory() + 0) = Params.InAnimation;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.InAnimation = *(UWidgetAnimation**)(params.GetStructMemory() + 0);
		Params.ReturnValue = *(bool*)(params.GetStructMemory() + 8);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushboolean(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetWidgetFromName(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"UserWidget",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"UserWidget must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FName Name;
		UWidget* ReturnValue = nullptr;
	} Params;
	Params.Name = FName(UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 2)));
#if UE_GAME
	UUserWidget * This = (UUserWidget *)Obj;
	Params.ReturnValue = This->GetWidgetFromName(Params.Name);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetWidgetFromName"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FName*)(params.GetStructMemory() + 0) = Params.Name;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.Name = *(FName*)(params.GetStructMemory() + 0);
		Params.ReturnValue = *(UWidget**)(params.GetStructMemory() + 16);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetScene3D(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"UserWidget",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"UserWidget must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool ReturnValue;
	} Params;
#if UE_GAME
	UUserWidget * This = (UUserWidget *)Obj;
	Params.ReturnValue = This->GetScene3D();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetScene3D"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushboolean(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetRootWidget(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"UserWidget",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"UserWidget must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		UWidget* ReturnValue = nullptr;
	} Params;
#if UE_GAME
	UUserWidget * This = (UUserWidget *)Obj;
	Params.ReturnValue = This->GetRootWidget();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetRootWidget"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(UWidget**)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetOwningPlayerPawn(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"UserWidget",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"UserWidget must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		APawn* ReturnValue = nullptr;
	} Params;
#if UE_GAME
	UUserWidget * This = (UUserWidget *)Obj;
	Params.ReturnValue = This->GetOwningPlayerPawn();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetOwningPlayerPawn"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(APawn**)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetNoCover(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"UserWidget",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"UserWidget must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool ReturnValue;
	} Params;
#if UE_GAME
	UUserWidget * This = (UUserWidget *)Obj;
	Params.ReturnValue = This->GetNoCover();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetNoCover"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushboolean(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetAnimationCurrentTime(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"UserWidget",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"UserWidget must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		UWidgetAnimation* InAnimation = nullptr;
		float ReturnValue;
	} Params;
	Params.InAnimation = (UWidgetAnimation*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"WidgetAnimation");;
#if UE_GAME
	UUserWidget * This = (UUserWidget *)Obj;
	Params.ReturnValue = This->GetAnimationCurrentTime(Params.InAnimation);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetAnimationCurrentTime"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(UWidgetAnimation**)(params.GetStructMemory() + 0) = Params.InAnimation;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.InAnimation = *(UWidgetAnimation**)(params.GetStructMemory() + 0);
		Params.ReturnValue = *(float*)(params.GetStructMemory() + 8);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushnumber(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetAnchorsInViewport(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"UserWidget",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"UserWidget must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FAnchors ReturnValue;
	} Params;
#if UE_GAME
	UUserWidget * This = (UUserWidget *)Obj;
	Params.ReturnValue = This->GetAnchorsInViewport();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetAnchorsInViewport"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(FAnchors*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaAnchors::Return(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetAlignmentInViewport(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"UserWidget",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"UserWidget must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FVector2D ReturnValue;
	} Params;
#if UE_GAME
	UUserWidget * This = (UUserWidget *)Obj;
	Params.ReturnValue = This->GetAlignmentInViewport();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetAlignmentInViewport"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(FVector2D*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaVector2D::Return(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetActiveSequencePlayerName(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"UserWidget",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"UserWidget must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		TArray<FString> ReturnValue;
	} Params;
#if UE_GAME
	UUserWidget * This = (UUserWidget *)Obj;
	Params.ReturnValue = This->GetActiveSequencePlayerName();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetActiveSequencePlayerName"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(TArray<FString>*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	{lua_newtable(InScriptContext); int i = 1; for(auto It = Params.ReturnValue.CreateConstIterator(); It; ++It,++i) {  lua_pushstring(InScriptContext, TCHAR_TO_UTF8(*(*It))); lua_rawseti(InScriptContext,-2,i);     }  }
	return 1;
}

int32 Destruct(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"UserWidget",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"UserWidget must be non-null"); lua_error(InScriptContext);  return 0;}
#if UE_GAME
	UUserWidget * This = (UUserWidget *)Obj;
	This->Destruct();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("Destruct"));
	if(!Function) { check(false); return 0;}
	Obj->ProcessEvent(Function, NULL);
#endif
	return 0;
}

int32 Construct(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"UserWidget",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"UserWidget must be non-null"); lua_error(InScriptContext);  return 0;}
#if UE_GAME
	UUserWidget * This = (UUserWidget *)Obj;
	This->Construct();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("Construct"));
	if(!Function) { check(false); return 0;}
	Obj->ProcessEvent(Function, NULL);
#endif
	return 0;
}

int32 ChangeScreenZorder(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"UserWidget",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"UserWidget must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		ULocalPlayer* Player = nullptr;
		int32 ZOrder;
	} Params;
	Params.Player = (ULocalPlayer*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"LocalPlayer");;
	Params.ZOrder = (luaL_checkint(InScriptContext, 3));
#if UE_GAME
	UUserWidget * This = (UUserWidget *)Obj;
	This->ChangeScreenZorder(Params.Player,Params.ZOrder);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("ChangeScreenZorder"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(ULocalPlayer**)(params.GetStructMemory() + 0) = Params.Player;
		*(int32*)(params.GetStructMemory() + 8) = Params.ZOrder;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.Player = *(ULocalPlayer**)(params.GetStructMemory() + 0);
		Params.ZOrder = *(int32*)(params.GetStructMemory() + 8);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 CancelLatentActions(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"UserWidget",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"UserWidget must be non-null"); lua_error(InScriptContext);  return 0;}
#if UE_GAME
	UUserWidget * This = (UUserWidget *)Obj;
	This->CancelLatentActions();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("CancelLatentActions"));
	if(!Function) { check(false); return 0;}
	Obj->ProcessEvent(Function, NULL);
#endif
	return 0;
}

int32 AddToViewport(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"UserWidget",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"UserWidget must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		int32 ZOrder;
	} Params;
	Params.ZOrder = lua_isnoneornil(InScriptContext,2) ? int32(0) : (luaL_checkint(InScriptContext, 2));
#if UE_GAME
	UUserWidget * This = (UUserWidget *)Obj;
	This->AddToViewport(Params.ZOrder);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("AddToViewport"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(int32*)(params.GetStructMemory() + 0) = Params.ZOrder;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ZOrder = *(int32*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 AddToPlayerScreen(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"UserWidget",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"UserWidget must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		int32 ZOrder;
		bool ReturnValue;
	} Params;
	Params.ZOrder = lua_isnoneornil(InScriptContext,2) ? int32(0) : (luaL_checkint(InScriptContext, 2));
#if UE_GAME
	UUserWidget * This = (UUserWidget *)Obj;
	Params.ReturnValue = This->AddToPlayerScreen(Params.ZOrder);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("AddToPlayerScreen"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(int32*)(params.GetStructMemory() + 0) = Params.ZOrder;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ZOrder = *(int32*)(params.GetStructMemory() + 0);
		Params.ReturnValue = *(bool*)(params.GetStructMemory() + 4);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushboolean(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 Get_ColorAndOpacity(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"UserWidget",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"UserWidget must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UUserWidget::StaticClass(), TEXT("ColorAndOpacity"));
	if(!Property) { check(false); return 0;}
	FLinearColor PropertyValue = FLinearColor();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaLinearColor::Return(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_PreviewBackground(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"UserWidget",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"UserWidget must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UUserWidget::StaticClass(), TEXT("PreviewBackground"));
	if(!Property) { check(false); return 0;}
	UTexture2D* PropertyValue;
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaUtils::ReturnUObject(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_PreviewBackground(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"UserWidget",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"UserWidget must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UUserWidget::StaticClass(), TEXT("PreviewBackground"));
	if(!Property) { check(false); return 0;}
	UTexture2D* PropertyValue = (UTexture2D*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"Texture2D");;
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_Priority(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"UserWidget",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"UserWidget must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UUserWidget::StaticClass(), TEXT("Priority"));
	if(!Property) { check(false); return 0;}
	int32 PropertyValue = int32();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushinteger(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_bIsFocusable(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"UserWidget",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"UserWidget must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UUserWidget::StaticClass(), TEXT("bIsFocusable"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bIsFocusable(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"UserWidget",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"UserWidget must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UUserWidget::StaticClass(), TEXT("bIsFocusable"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bStopAction(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"UserWidget",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"UserWidget must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UUserWidget::StaticClass(), TEXT("bStopAction"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bStopAction(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"UserWidget",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"UserWidget must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UUserWidget::StaticClass(), TEXT("bStopAction"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_TickFrequency(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"UserWidget",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"UserWidget must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UUserWidget::StaticClass(), TEXT("TickFrequency"));
	if(!Property) { check(false); return 0;}
	EWidgetTickFrequency PropertyValue = EWidgetTickFrequency();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushinteger(InScriptContext, (int)PropertyValue);
	return 1;
}

int32 Class(lua_State* InScriptContext)
{
	UClass* Class = UUserWidget::StaticClass();
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Class);
	return 1;
}

const luaL_Reg Lib_Funcs[] =
{
	{ "Class", Class },
	{ "UnregisterInputComponent", UnregisterInputComponent },
	{ "StopListeningForInputAction", StopListeningForInputAction },
	{ "StopListeningForAllInputActions", StopListeningForAllInputActions },
	{ "StopAnimationsAndLatentActions", StopAnimationsAndLatentActions },
	{ "StopAnimation", StopAnimation },
	{ "StopAllAnimations", StopAllAnimations },
	{ "SetScene3D", SetScene3D },
	{ "SetPositionInViewport", SetPositionInViewport },
	{ "SetPlaybackSpeed", SetPlaybackSpeed },
	{ "SetOwningPlayer", SetOwningPlayer },
	{ "SetNumLoopsToPlay", SetNumLoopsToPlay },
	{ "SetNoCover", SetNoCover },
	{ "SetInputActionPriority", SetInputActionPriority },
	{ "SetInputActionBlocking", SetInputActionBlocking },
	{ "SetDesiredSizeInViewport", SetDesiredSizeInViewport },
	{ "SetDepth", SetDepth },
	{ "SetColorAndOpacity", SetColorAndOpacity },
	{ "SetAnchorsInViewport", SetAnchorsInViewport },
	{ "SetAlignmentInViewport", SetAlignmentInViewport },
	{ "ReverseAnimation", ReverseAnimation },
	{ "RegisterInputComponent", RegisterInputComponent },
	{ "PreConstruct", PreConstruct },
	{ "PlayAnimationTo", PlayAnimationTo },
	{ "PlayAnimation", PlayAnimation },
	{ "PauseAnimation", PauseAnimation },
	{ "OnVisibilityChange", OnVisibilityChange },
	{ "OnUnhovered", OnUnhovered },
	{ "OnTextCommitted", OnTextCommitted },
	{ "OnTextChanged", OnTextChanged },
	{ "OnScroll", OnScroll },
	{ "OnReleased", OnReleased },
	{ "OnPressed", OnPressed },
	{ "OnMouseCaptureLost", OnMouseCaptureLost },
	{ "OnInitialized", OnInitialized },
	{ "OnHovered", OnHovered },
	{ "OnFocusChange", OnFocusChange },
	{ "OnFetchFromCache", OnFetchFromCache },
	{ "OnClicked", OnClicked },
	{ "OnChildVisibilityChange", OnChildVisibilityChange },
	{ "OnChecked", OnChecked },
	{ "OnAnimationStarted", OnAnimationStarted },
	{ "OnAnimationFinished", OnAnimationFinished },
	{ "IsPlayingAnimation", IsPlayingAnimation },
	{ "IsListeningForInputAction", IsListeningForInputAction },
	{ "IsInViewport", IsInViewport },
	{ "IsInteractable", IsInteractable },
	{ "IsAnyAnimationPlaying", IsAnyAnimationPlaying },
	{ "IsAnimationPlayingForward", IsAnimationPlayingForward },
	{ "IsAnimationPlaying", IsAnimationPlaying },
	{ "GetWidgetFromName", GetWidgetFromName },
	{ "GetScene3D", GetScene3D },
	{ "GetRootWidget", GetRootWidget },
	{ "GetOwningPlayerPawn", GetOwningPlayerPawn },
	{ "GetNoCover", GetNoCover },
	{ "GetAnimationCurrentTime", GetAnimationCurrentTime },
	{ "GetAnchorsInViewport", GetAnchorsInViewport },
	{ "GetAlignmentInViewport", GetAlignmentInViewport },
	{ "GetActiveSequencePlayerName", GetActiveSequencePlayerName },
	{ "Destruct", Destruct },
	{ "Construct", Construct },
	{ "ChangeScreenZorder", ChangeScreenZorder },
	{ "CancelLatentActions", CancelLatentActions },
	{ "AddToViewport", AddToViewport },
	{ "AddToPlayerScreen", AddToPlayerScreen },
	{ "Get_ColorAndOpacity", Get_ColorAndOpacity },
	{ "Get_PreviewBackground", Get_PreviewBackground },
	{ "Set_PreviewBackground", Set_PreviewBackground },
	{ "Get_Priority", Get_Priority },
	{ "Get_bIsFocusable", Get_bIsFocusable },
	{ "Set_bIsFocusable", Set_bIsFocusable },
	{ "Get_bStopAction", Get_bStopAction },
	{ "Set_bStopAction", Set_bStopAction },
	{ "Get_TickFrequency", Get_TickFrequency },
	{ "SetMsgTable", SetMsgTable },
	{ "CreateWidget", CreateWidget },
	{ "CreateWidgetWithParent", CreateWidgetWithParent },
	{ "CreateWidgetAsync", CreateWidgetAsync },
	{ "FindChild", FindChild },
	{ "GetAnimationByName", GetAnimationByName },
	{ "PlayAnimationByName", PlayAnimationByName },
	{ "PlayAnimationToByName", PlayAnimationToByName },
	{ "PauseAnimationByName", PauseAnimationByName },
	{ "StopAnimationByName", StopAnimationByName },
	{ "RemoveFromParent", RemoveFromParent2 },
	{ "FindInvalidationBox", FindInvalidationBox },
	{ "CollectBackButtons", CollectBackButtons },
	{ "RemoveAllEventHandlers", RemoveAllEventHandlers },
	{ "is_nil", wLua::LuaStatic::isnil },
	{ "__gc", wLua::LuaStatic::removeUClassFrameCache },
	{ NULL, NULL }
};

void Register(lua_State *InScriptContext)
{
	lua_newtable(InScriptContext);
	luaL_register(InScriptContext, NULL, Lib_Funcs);
	AzureHelpFuncs::AuxRegister(InScriptContext, "UserWidget");
}
void SetMtLink(lua_State *InScriptContext)
{
	AzureHelpFuncs::AuxSetMtLink(InScriptContext, "UserWidget", "Widget",USERDATATYPE_UOBJECT);
}

}