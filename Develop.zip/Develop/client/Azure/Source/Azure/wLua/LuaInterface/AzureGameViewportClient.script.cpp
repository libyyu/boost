#include "Azure.h"
#include "Utility/help_funcs.h"
#include "wLua/UObjectHeaders.h"
#include "AzureGameViewportClient.h"
#include "AzureLuaIntegration.h"

namespace LuaAzureGameViewportClient
{
int32 Viewport_ShowCursor(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureGameViewportClient",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureGameViewportClient must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool bShow;
	} Params;
	Params.bShow = !!(lua_toboolean(InScriptContext, 2));
#if UE_GAME
	UAzureGameViewportClient * This = (UAzureGameViewportClient *)Obj;
	This->Viewport_ShowCursor(Params.bShow);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("Viewport_ShowCursor"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(bool*)(params.GetStructMemory() + 0) = Params.bShow;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.bShow = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 Viewport_SetUserFocus(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureGameViewportClient",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureGameViewportClient must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool bFocus;
	} Params;
	Params.bFocus = !!(lua_toboolean(InScriptContext, 2));
#if UE_GAME
	UAzureGameViewportClient * This = (UAzureGameViewportClient *)Obj;
	This->Viewport_SetUserFocus(Params.bFocus);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("Viewport_SetUserFocus"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(bool*)(params.GetStructMemory() + 0) = Params.bFocus;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.bFocus = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 Viewport_LockMouseToViewport(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureGameViewportClient",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureGameViewportClient must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool bLock;
	} Params;
	Params.bLock = !!(lua_toboolean(InScriptContext, 2));
#if UE_GAME
	UAzureGameViewportClient * This = (UAzureGameViewportClient *)Obj;
	This->Viewport_LockMouseToViewport(Params.bLock);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("Viewport_LockMouseToViewport"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(bool*)(params.GetStructMemory() + 0) = Params.bLock;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.bLock = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 Viewport_IsCursorVisible(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureGameViewportClient",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureGameViewportClient must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool ReturnValue;
	} Params;
#if UE_GAME
	UAzureGameViewportClient * This = (UAzureGameViewportClient *)Obj;
	Params.ReturnValue = This->Viewport_IsCursorVisible();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("Viewport_IsCursorVisible"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushboolean(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 Viewport_HasMouseCapture(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureGameViewportClient",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureGameViewportClient must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool ReturnValue;
	} Params;
#if UE_GAME
	UAzureGameViewportClient * This = (UAzureGameViewportClient *)Obj;
	Params.ReturnValue = This->Viewport_HasMouseCapture();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("Viewport_HasMouseCapture"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushboolean(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 Viewport_HasFocus(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureGameViewportClient",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureGameViewportClient must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool ReturnValue;
	} Params;
#if UE_GAME
	UAzureGameViewportClient * This = (UAzureGameViewportClient *)Obj;
	Params.ReturnValue = This->Viewport_HasFocus();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("Viewport_HasFocus"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushboolean(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 Viewport_CaptureMouse(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureGameViewportClient",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureGameViewportClient must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool bCapture;
	} Params;
	Params.bCapture = !!(lua_toboolean(InScriptContext, 2));
#if UE_GAME
	UAzureGameViewportClient * This = (UAzureGameViewportClient *)Obj;
	This->Viewport_CaptureMouse(Params.bCapture);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("Viewport_CaptureMouse"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(bool*)(params.GetStructMemory() + 0) = Params.bCapture;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.bCapture = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 StopAlwaysCaptureMouse(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureGameViewportClient",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureGameViewportClient must be non-null"); lua_error(InScriptContext);  return 0;}
#if UE_GAME
	UAzureGameViewportClient * This = (UAzureGameViewportClient *)Obj;
	This->StopAlwaysCaptureMouse();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("StopAlwaysCaptureMouse"));
	if(!Function) { check(false); return 0;}
	Obj->ProcessEvent(Function, NULL);
#endif
	return 0;
}

int32 StartAlwaysCaptureMouse(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureGameViewportClient",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureGameViewportClient must be non-null"); lua_error(InScriptContext);  return 0;}
#if UE_GAME
	UAzureGameViewportClient * This = (UAzureGameViewportClient *)Obj;
	This->StartAlwaysCaptureMouse();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("StartAlwaysCaptureMouse"));
	if(!Function) { check(false); return 0;}
	Obj->ProcessEvent(Function, NULL);
#endif
	return 0;
}

int32 IsAlwaysCaptureMouse(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureGameViewportClient",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureGameViewportClient must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool ReturnValue;
	} Params;
#if UE_GAME
	UAzureGameViewportClient * This = (UAzureGameViewportClient *)Obj;
	Params.ReturnValue = This->IsAlwaysCaptureMouse();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("IsAlwaysCaptureMouse"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushboolean(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 New(lua_State* InScriptContext)
{
	UObject* Outer = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Object");
	FName Name = FName(luaL_checkstring(InScriptContext, 2));
	UObject* Obj = NewObject<UAzureGameViewportClient>(Outer, Name);
	wLua::FLuaUtils::ReturnUObject(InScriptContext,Obj);
	return 1;
}

int32 Destroy(lua_State* InScriptContext)
{
	return 0;
}

int32 Class(lua_State* InScriptContext)
{
	UClass* Class = UAzureGameViewportClient::StaticClass();
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Class);
	return 1;
}

const luaL_Reg Lib_Funcs[] =
{
	{ "New", New },
	{ "Destroy", Destroy },
	{ "Class", Class },
	{ "Viewport_ShowCursor", Viewport_ShowCursor },
	{ "Viewport_SetUserFocus", Viewport_SetUserFocus },
	{ "Viewport_LockMouseToViewport", Viewport_LockMouseToViewport },
	{ "Viewport_IsCursorVisible", Viewport_IsCursorVisible },
	{ "Viewport_HasMouseCapture", Viewport_HasMouseCapture },
	{ "Viewport_HasFocus", Viewport_HasFocus },
	{ "Viewport_CaptureMouse", Viewport_CaptureMouse },
	{ "StopAlwaysCaptureMouse", StopAlwaysCaptureMouse },
	{ "StartAlwaysCaptureMouse", StartAlwaysCaptureMouse },
	{ "IsAlwaysCaptureMouse", IsAlwaysCaptureMouse },
	{ "is_nil", wLua::LuaStatic::isnil },
	{ "__gc", wLua::LuaStatic::removeUClassFrameCache },
	{ NULL, NULL }
};

void Register(lua_State *InScriptContext)
{
	lua_newtable(InScriptContext);
	luaL_register(InScriptContext, NULL, Lib_Funcs);
	AzureHelpFuncs::AuxRegister(InScriptContext, "AzureGameViewportClient");
}
void SetMtLink(lua_State *InScriptContext)
{
	AzureHelpFuncs::AuxSetMtLink(InScriptContext, "AzureGameViewportClient", "GameViewportClient",USERDATATYPE_UOBJECT);
}

}