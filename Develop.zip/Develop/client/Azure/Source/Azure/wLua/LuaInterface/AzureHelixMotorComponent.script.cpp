#include "Azure.h"
#include "Utility/help_funcs.h"
#include "wLua/UObjectHeaders.h"
#include "AzureHelixMotorComponent.h"
#include "AzureLuaIntegration.h"

namespace LuaAzureHelixMotorComponent
{
int32 StartMove(lua_State*);

int32 SetExtraParam(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureHelixMotorComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureHelixMotorComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float _fHelixRadius;
		float _RadiusShrinkSpeed;
		float _AngleSpeed;
	} Params;
	Params._fHelixRadius = (float)(luaL_checknumber(InScriptContext, 2));
	Params._RadiusShrinkSpeed = (float)(luaL_checknumber(InScriptContext, 3));
	Params._AngleSpeed = (float)(luaL_checknumber(InScriptContext, 4));
#if UE_GAME
	UAzureHelixMotorComponent * This = (UAzureHelixMotorComponent *)Obj;
	This->SetExtraParam(Params._fHelixRadius,Params._RadiusShrinkSpeed,Params._AngleSpeed);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetExtraParam"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(float*)(params.GetStructMemory() + 0) = Params._fHelixRadius;
		*(float*)(params.GetStructMemory() + 4) = Params._RadiusShrinkSpeed;
		*(float*)(params.GetStructMemory() + 8) = Params._AngleSpeed;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params._fHelixRadius = *(float*)(params.GetStructMemory() + 0);
		Params._RadiusShrinkSpeed = *(float*)(params.GetStructMemory() + 4);
		Params._AngleSpeed = *(float*)(params.GetStructMemory() + 8);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 New(lua_State* InScriptContext)
{
	UObject* Outer = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Object");
	FName Name = FName(luaL_checkstring(InScriptContext, 2));
	UObject* Obj = NewObject<UAzureHelixMotorComponent>(Outer, Name);
	wLua::FLuaUtils::ReturnUObject(InScriptContext,Obj);
	return 1;
}

int32 Destroy(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureHelixMotorComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureHelixMotorComponent must be non-null"); lua_error(InScriptContext);  return 0;}
		UActorComponent * com = Cast<UActorComponent>(Obj);
		if(lua_isnoneornil(InScriptContext,2))
			com->DestroyComponent();
		else
			com->DestroyComponent(!!lua_toboolean(InScriptContext,2));
		userdata->flag |= wLua::LuaObjectFlag::DESTROYED;
		wLua::FLuaUtils::RemoveObjectReference(Obj, userdata->stamp, InScriptContext);
#ifdef AZURE_BUILD_WLUACHECK
		UE_LOG(LogAzure, Warning, TEXT("Destroy AzureHelixMotorComponent: %x userdata:%x   stamp:%x"),Obj,userdata,userdata->stamp);
#endif
	return 0;
}

int32 Class(lua_State* InScriptContext)
{
	UClass* Class = UAzureHelixMotorComponent::StaticClass();
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Class);
	return 1;
}

const luaL_Reg Lib_Funcs[] =
{
	{ "New", New },
	{ "Destroy", Destroy },
	{ "Class", Class },
	{ "SetExtraParam", SetExtraParam },
	{ "StartMove", StartMove },
	{ "is_nil", wLua::LuaStatic::isnil },
	{ "__gc", wLua::LuaStatic::removeUClassFrameCache },
	{ NULL, NULL }
};

void Register(lua_State *InScriptContext)
{
	lua_newtable(InScriptContext);
	luaL_register(InScriptContext, NULL, Lib_Funcs);
	AzureHelpFuncs::AuxRegister(InScriptContext, "AzureHelixMotorComponent");
}
void SetMtLink(lua_State *InScriptContext)
{
	AzureHelpFuncs::AuxSetMtLink(InScriptContext, "AzureHelixMotorComponent", "AzureMotorComponent",USERDATATYPE_UOBJECT);
}

}