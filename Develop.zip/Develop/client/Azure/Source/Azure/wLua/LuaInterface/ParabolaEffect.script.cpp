#include "Azure.h"
#include "Utility/help_funcs.h"
#include "wLua/UObjectHeaders.h"
#include "GameLogic/Weapon/ParabolaEffect.h"
#include "AzureLuaIntegration.h"

namespace LuaParabolaEffect
{
int32 SetVectorProperty(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ParabolaEffect",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ParabolaEffect must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FName PropertyName;
		FVector4 Value;
	} Params;
	Params.PropertyName = FName(UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 2)));
	Params.Value = (wLua::FLuaVector4::Get(InScriptContext, 3));
#if UE_GAME
	AParabolaEffect * This = (AParabolaEffect *)Obj;
	This->SetVectorProperty(Params.PropertyName,Params.Value);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetVectorProperty"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FName*)(params.GetStructMemory() + 0) = Params.PropertyName;
		*(FVector4*)(params.GetStructMemory() + 16) = Params.Value;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.PropertyName = *(FName*)(params.GetStructMemory() + 0);
		Params.Value = *(FVector4*)(params.GetStructMemory() + 16);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetScalarProperty(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ParabolaEffect",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ParabolaEffect must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FName PropertyName;
		float Value;
	} Params;
	Params.PropertyName = FName(UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 2)));
	Params.Value = (float)(luaL_checknumber(InScriptContext, 3));
#if UE_GAME
	AParabolaEffect * This = (AParabolaEffect *)Obj;
	This->SetScalarProperty(Params.PropertyName,Params.Value);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetScalarProperty"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FName*)(params.GetStructMemory() + 0) = Params.PropertyName;
		*(float*)(params.GetStructMemory() + 12) = Params.Value;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.PropertyName = *(FName*)(params.GetStructMemory() + 0);
		Params.Value = *(float*)(params.GetStructMemory() + 12);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetParameters(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ParabolaEffect",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ParabolaEffect must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FVector Velocity;
		float G;
		float ElapsedTime;
	} Params;
	Params.Velocity = (wLua::FLuaVector::Get(InScriptContext, 2));
	Params.G = (float)(luaL_checknumber(InScriptContext, 3));
	Params.ElapsedTime = (float)(luaL_checknumber(InScriptContext, 4));
#if UE_GAME
	AParabolaEffect * This = (AParabolaEffect *)Obj;
	This->SetParameters(Params.Velocity,Params.G,Params.ElapsedTime);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetParameters"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FVector*)(params.GetStructMemory() + 0) = Params.Velocity;
		*(float*)(params.GetStructMemory() + 12) = Params.G;
		*(float*)(params.GetStructMemory() + 16) = Params.ElapsedTime;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.Velocity = *(FVector*)(params.GetStructMemory() + 0);
		Params.G = *(float*)(params.GetStructMemory() + 12);
		Params.ElapsedTime = *(float*)(params.GetStructMemory() + 16);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetEnabled(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ParabolaEffect",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ParabolaEffect must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool bEnable;
	} Params;
	Params.bEnable = !!(lua_toboolean(InScriptContext, 2));
#if UE_GAME
	AParabolaEffect * This = (AParabolaEffect *)Obj;
	This->SetEnabled(Params.bEnable);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetEnabled"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(bool*)(params.GetStructMemory() + 0) = Params.bEnable;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.bEnable = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 New(lua_State* InScriptContext)
{
	UObject* Outer = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Object");
	FName Name = FName(luaL_checkstring(InScriptContext, 2));
	UObject* Obj = NewObject<AParabolaEffect>(Outer, Name);
	wLua::FLuaUtils::ReturnUObject(InScriptContext,Obj);
	return 1;
}

int32 Destroy(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ParabolaEffect",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ParabolaEffect must be non-null"); lua_error(InScriptContext);  return 0;}
		AActor * actor = Cast<AActor>(Obj);
		actor->Destroy();
		userdata->flag |= wLua::LuaObjectFlag::DESTROYED;
		wLua::FLuaUtils::RemoveObjectReference(Obj, userdata->stamp, InScriptContext);
#ifdef AZURE_BUILD_WLUACHECK
		UE_LOG(LogAzure, Warning, TEXT("Destroy ParabolaEffect: %x userdata:%x   stamp:%x"),Obj,userdata,userdata->stamp);
#endif
	return 0;
}

int32 Class(lua_State* InScriptContext)
{
	UClass* Class = AParabolaEffect::StaticClass();
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Class);
	return 1;
}

const luaL_Reg Lib_Funcs[] =
{
	{ "New", New },
	{ "Destroy", Destroy },
	{ "Class", Class },
	{ "SetVectorProperty", SetVectorProperty },
	{ "SetScalarProperty", SetScalarProperty },
	{ "SetParameters", SetParameters },
	{ "SetEnabled", SetEnabled },
	{ "is_nil", wLua::LuaStatic::isnil },
	{ "__gc", wLua::LuaStatic::removeUClassFrameCache },
	{ NULL, NULL }
};

void Register(lua_State *InScriptContext)
{
	lua_newtable(InScriptContext);
	luaL_register(InScriptContext, NULL, Lib_Funcs);
	AzureHelpFuncs::AuxRegister(InScriptContext, "ParabolaEffect");
}
void SetMtLink(lua_State *InScriptContext)
{
	AzureHelpFuncs::AuxSetMtLink(InScriptContext, "ParabolaEffect", "Actor",USERDATATYPE_UOBJECT);
}

}