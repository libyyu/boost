#include "Azure.h"
#include "Utility/help_funcs.h"
#include "wLua/UObjectHeaders.h"
#include "MediaTexture.h"
#include "MediaPlayer.h"
#include "AzureLuaIntegration.h"

namespace LuaMediaTexture
{
int32 SetMediaPlayer(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MediaTexture",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MediaTexture must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		UMediaPlayer* NewMediaPlayer = nullptr;
	} Params;
	Params.NewMediaPlayer = (UMediaPlayer*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"MediaPlayer");;
#if UE_GAME
	UMediaTexture * This = (UMediaTexture *)Obj;
	This->SetMediaPlayer(Params.NewMediaPlayer);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetMediaPlayer"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(UMediaPlayer**)(params.GetStructMemory() + 0) = Params.NewMediaPlayer;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.NewMediaPlayer = *(UMediaPlayer**)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 GetWidth(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MediaTexture",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MediaTexture must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		int32 ReturnValue;
	} Params;
#if UE_GAME
	UMediaTexture * This = (UMediaTexture *)Obj;
	Params.ReturnValue = This->GetWidth();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetWidth"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(int32*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushinteger(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetMediaPlayer(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MediaTexture",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MediaTexture must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		UMediaPlayer* ReturnValue = nullptr;
	} Params;
#if UE_GAME
	UMediaTexture * This = (UMediaTexture *)Obj;
	Params.ReturnValue = This->GetMediaPlayer();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetMediaPlayer"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(UMediaPlayer**)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetHeight(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MediaTexture",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MediaTexture must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		int32 ReturnValue;
	} Params;
#if UE_GAME
	UMediaTexture * This = (UMediaTexture *)Obj;
	Params.ReturnValue = This->GetHeight();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetHeight"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(int32*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushinteger(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetAspectRatio(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MediaTexture",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MediaTexture must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float ReturnValue;
	} Params;
#if UE_GAME
	UMediaTexture * This = (UMediaTexture *)Obj;
	Params.ReturnValue = This->GetAspectRatio();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetAspectRatio"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(float*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushnumber(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 Get_AddressX(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MediaTexture",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MediaTexture must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UMediaTexture::StaticClass(), TEXT("AddressX"));
	if(!Property) { check(false); return 0;}
	TEnumAsByte<TextureAddress> PropertyValue = TEnumAsByte<TextureAddress>();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushinteger(InScriptContext, (int)PropertyValue);
	return 1;
}

int32 Set_AddressX(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MediaTexture",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MediaTexture must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UMediaTexture::StaticClass(), TEXT("AddressX"));
	if(!Property) { check(false); return 0;}
	TEnumAsByte<TextureAddress> PropertyValue = (TEnumAsByte<TextureAddress>)(luaL_checkint(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_AddressY(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MediaTexture",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MediaTexture must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UMediaTexture::StaticClass(), TEXT("AddressY"));
	if(!Property) { check(false); return 0;}
	TEnumAsByte<TextureAddress> PropertyValue = TEnumAsByte<TextureAddress>();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushinteger(InScriptContext, (int)PropertyValue);
	return 1;
}

int32 Set_AddressY(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MediaTexture",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MediaTexture must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UMediaTexture::StaticClass(), TEXT("AddressY"));
	if(!Property) { check(false); return 0;}
	TEnumAsByte<TextureAddress> PropertyValue = (TEnumAsByte<TextureAddress>)(luaL_checkint(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_AutoClear(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MediaTexture",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MediaTexture must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UMediaTexture::StaticClass(), TEXT("AutoClear"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = bool();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_AutoClear(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MediaTexture",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MediaTexture must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UMediaTexture::StaticClass(), TEXT("AutoClear"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_ClearColor(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MediaTexture",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MediaTexture must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UMediaTexture::StaticClass(), TEXT("ClearColor"));
	if(!Property) { check(false); return 0;}
	FLinearColor PropertyValue = FLinearColor();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaLinearColor::Return(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_ClearColor(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MediaTexture",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MediaTexture must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UMediaTexture::StaticClass(), TEXT("ClearColor"));
	if(!Property) { check(false); return 0;}
	FLinearColor PropertyValue = (wLua::FLuaLinearColor::Get(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_MediaPlayer(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MediaTexture",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MediaTexture must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UMediaTexture::StaticClass(), TEXT("MediaPlayer"));
	if(!Property) { check(false); return 0;}
	UMediaPlayer* PropertyValue;
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaUtils::ReturnUObject(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_MediaPlayer(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MediaTexture",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MediaTexture must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UMediaTexture::StaticClass(), TEXT("MediaPlayer"));
	if(!Property) { check(false); return 0;}
	UMediaPlayer* PropertyValue = (UMediaPlayer*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"MediaPlayer");;
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 New(lua_State* InScriptContext)
{
	UObject* Outer = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Object");
	FName Name = FName(luaL_checkstring(InScriptContext, 2));
	UObject* Obj = NewObject<UMediaTexture>(Outer, Name);
	wLua::FLuaUtils::ReturnUObject(InScriptContext,Obj);
	return 1;
}

int32 Destroy(lua_State* InScriptContext)
{
	return 0;
}

int32 Class(lua_State* InScriptContext)
{
	UClass* Class = UMediaTexture::StaticClass();
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Class);
	return 1;
}

const luaL_Reg Lib_Funcs[] =
{
	{ "New", New },
	{ "Destroy", Destroy },
	{ "Class", Class },
	{ "SetMediaPlayer", SetMediaPlayer },
	{ "GetWidth", GetWidth },
	{ "GetMediaPlayer", GetMediaPlayer },
	{ "GetHeight", GetHeight },
	{ "GetAspectRatio", GetAspectRatio },
	{ "Get_AddressX", Get_AddressX },
	{ "Set_AddressX", Set_AddressX },
	{ "Get_AddressY", Get_AddressY },
	{ "Set_AddressY", Set_AddressY },
	{ "Get_AutoClear", Get_AutoClear },
	{ "Set_AutoClear", Set_AutoClear },
	{ "Get_ClearColor", Get_ClearColor },
	{ "Set_ClearColor", Set_ClearColor },
	{ "Get_MediaPlayer", Get_MediaPlayer },
	{ "Set_MediaPlayer", Set_MediaPlayer },
	{ "is_nil", wLua::LuaStatic::isnil },
	{ "__gc", wLua::LuaStatic::removeUClassFrameCache },
	{ NULL, NULL }
};

void Register(lua_State *InScriptContext)
{
	lua_newtable(InScriptContext);
	luaL_register(InScriptContext, NULL, Lib_Funcs);
	AzureHelpFuncs::AuxRegister(InScriptContext, "MediaTexture");
}
void SetMtLink(lua_State *InScriptContext)
{
	AzureHelpFuncs::AuxSetMtLink(InScriptContext, "MediaTexture", "Texture",USERDATATYPE_UOBJECT);
}

}