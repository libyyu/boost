#include "Azure.h"
#include "Utility/help_funcs.h"
#include "wLua/UObjectHeaders.h"
#include "AIController.h"
#include "BehaviorTree/BlackboardComponent.h"
#include "Perception/AIPerceptionComponent.h"
#include "BrainComponent.h"
#include "Actions/PawnActionsComponent.h"
#include "AzureLuaIntegration.h"

namespace LuaAIController
{
int32 UseBlackboard(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AIController",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AIController must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		UBlackboardData* BlackboardAsset = nullptr;
		UBlackboardComponent* BlackboardComponent = nullptr;
		bool ReturnValue;
	} Params;
	Params.BlackboardAsset = (UBlackboardData*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"BlackboardData");;
#if UE_GAME
	AAIController * This = (AAIController *)Obj;
	Params.ReturnValue = This->UseBlackboard(Params.BlackboardAsset,Params.BlackboardComponent);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("UseBlackboard"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(UBlackboardData**)(params.GetStructMemory() + 0) = Params.BlackboardAsset;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.BlackboardAsset = *(UBlackboardData**)(params.GetStructMemory() + 0);
		Params.BlackboardComponent = *(UBlackboardComponent**)(params.GetStructMemory() + 8);
		Params.ReturnValue = *(bool*)(params.GetStructMemory() + 16);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushboolean(InScriptContext, Params.ReturnValue);
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Params.BlackboardComponent);
	return 2;
}

int32 UnclaimTaskResource(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AIController",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AIController must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		TSubclassOf<UGameplayTaskResource>  ResourceClass;
	} Params;
	Params.ResourceClass = (UClass*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"Class");;
#if UE_GAME
	AAIController * This = (AAIController *)Obj;
	This->UnclaimTaskResource(Params.ResourceClass);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("UnclaimTaskResource"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(TSubclassOf<UGameplayTaskResource> *)(params.GetStructMemory() + 0) = Params.ResourceClass;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ResourceClass = *(TSubclassOf<UGameplayTaskResource> *)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetPathFollowingComponent(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AIController",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AIController must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		UPathFollowingComponent* NewPFComponent = nullptr;
	} Params;
	Params.NewPFComponent = (UPathFollowingComponent*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"PathFollowingComponent");;
#if UE_GAME
	AAIController * This = (AAIController *)Obj;
	This->SetPathFollowingComponent(Params.NewPFComponent);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetPathFollowingComponent"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(UPathFollowingComponent**)(params.GetStructMemory() + 0) = Params.NewPFComponent;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.NewPFComponent = *(UPathFollowingComponent**)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetMoveBlockDetection(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AIController",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AIController must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool bEnable;
	} Params;
	Params.bEnable = !!(lua_toboolean(InScriptContext, 2));
#if UE_GAME
	AAIController * This = (AAIController *)Obj;
	This->SetMoveBlockDetection(Params.bEnable);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetMoveBlockDetection"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(bool*)(params.GetStructMemory() + 0) = Params.bEnable;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.bEnable = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 RunBehaviorTree(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AIController",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AIController must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		UBehaviorTree* BTAsset = nullptr;
		bool ReturnValue;
	} Params;
	Params.BTAsset = (UBehaviorTree*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"BehaviorTree");;
#if UE_GAME
	AAIController * This = (AAIController *)Obj;
	Params.ReturnValue = This->RunBehaviorTree(Params.BTAsset);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("RunBehaviorTree"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(UBehaviorTree**)(params.GetStructMemory() + 0) = Params.BTAsset;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.BTAsset = *(UBehaviorTree**)(params.GetStructMemory() + 0);
		Params.ReturnValue = *(bool*)(params.GetStructMemory() + 8);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushboolean(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 OnUsingBlackBoard(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AIController",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AIController must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		UBlackboardComponent* BlackboardComp = nullptr;
		UBlackboardData* BlackboardAsset = nullptr;
	} Params;
	Params.BlackboardComp = (UBlackboardComponent*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"BlackboardComponent");;
	Params.BlackboardAsset = (UBlackboardData*)wLua::FLuaUtils::GetUObject(InScriptContext,3,"BlackboardData");;
	UFunction* Function = Obj->FindFunctionChecked(TEXT("OnUsingBlackBoard"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(UBlackboardComponent**)(params.GetStructMemory() + 0) = Params.BlackboardComp;
		*(UBlackboardData**)(params.GetStructMemory() + 8) = Params.BlackboardAsset;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.BlackboardComp = *(UBlackboardComponent**)(params.GetStructMemory() + 0);
		Params.BlackboardAsset = *(UBlackboardData**)(params.GetStructMemory() + 8);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
	return 0;
}

int32 OnUnpossess(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AIController",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AIController must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		APawn* UnpossessedPawn = nullptr;
	} Params;
	Params.UnpossessedPawn = (APawn*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"Pawn");;
#if UE_GAME
	AAIController * This = (AAIController *)Obj;
	This->OnUnpossess(Params.UnpossessedPawn);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("OnUnpossess"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(APawn**)(params.GetStructMemory() + 0) = Params.UnpossessedPawn;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.UnpossessedPawn = *(APawn**)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 OnPossess(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AIController",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AIController must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		APawn* PossessedPawn = nullptr;
	} Params;
	Params.PossessedPawn = (APawn*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"Pawn");;
#if UE_GAME
	AAIController * This = (AAIController *)Obj;
	This->OnPossess(Params.PossessedPawn);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("OnPossess"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(APawn**)(params.GetStructMemory() + 0) = Params.PossessedPawn;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.PossessedPawn = *(APawn**)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 MoveToLocation(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AIController",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AIController must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FVector Dest;
		float AcceptanceRadius;
		bool bStopOnOverlap;
		bool bUsePathfinding;
		bool bProjectDestinationToNavigation;
		bool bCanStrafe;
		TSubclassOf<UNavigationQueryFilter>  FilterClass;
		bool bAllowPartialPath;
		TEnumAsByte<EPathFollowingRequestResult::Type> ReturnValue;
	} Params;
	Params.Dest = (wLua::FLuaVector::Get(InScriptContext, 2));
	Params.AcceptanceRadius = lua_isnoneornil(InScriptContext,3) ? float(-1.000000) : (float)(luaL_checknumber(InScriptContext, 3));
	Params.bStopOnOverlap = lua_isnoneornil(InScriptContext,4) ? bool(true) : !!(lua_toboolean(InScriptContext, 4));
	Params.bUsePathfinding = lua_isnoneornil(InScriptContext,5) ? bool(true) : !!(lua_toboolean(InScriptContext, 5));
	Params.bProjectDestinationToNavigation = lua_isnoneornil(InScriptContext,6) ? bool(false) : !!(lua_toboolean(InScriptContext, 6));
	Params.bCanStrafe = lua_isnoneornil(InScriptContext,7) ? bool(true) : !!(lua_toboolean(InScriptContext, 7));
	Params.FilterClass = lua_isnoneornil(InScriptContext,8) ? (UClass*)TSubclassOf<UNavigationQueryFilter> (nullptr) : (UClass*)wLua::FLuaUtils::GetUObject(InScriptContext,8,"Class");;
	Params.bAllowPartialPath = lua_isnoneornil(InScriptContext,9) ? bool(true) : !!(lua_toboolean(InScriptContext, 9));
#if UE_GAME
	AAIController * This = (AAIController *)Obj;
	Params.ReturnValue = This->MoveToLocation(Params.Dest,Params.AcceptanceRadius,Params.bStopOnOverlap,Params.bUsePathfinding,Params.bProjectDestinationToNavigation,Params.bCanStrafe,Params.FilterClass,Params.bAllowPartialPath);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("MoveToLocation"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FVector*)(params.GetStructMemory() + 0) = Params.Dest;
		*(float*)(params.GetStructMemory() + 12) = Params.AcceptanceRadius;
		*(bool*)(params.GetStructMemory() + 16) = Params.bStopOnOverlap;
		*(bool*)(params.GetStructMemory() + 17) = Params.bUsePathfinding;
		*(bool*)(params.GetStructMemory() + 18) = Params.bProjectDestinationToNavigation;
		*(bool*)(params.GetStructMemory() + 19) = Params.bCanStrafe;
		*(TSubclassOf<UNavigationQueryFilter> *)(params.GetStructMemory() + 24) = Params.FilterClass;
		*(bool*)(params.GetStructMemory() + 32) = Params.bAllowPartialPath;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.Dest = *(FVector*)(params.GetStructMemory() + 0);
		Params.AcceptanceRadius = *(float*)(params.GetStructMemory() + 12);
		Params.bStopOnOverlap = *(bool*)(params.GetStructMemory() + 16);
		Params.bUsePathfinding = *(bool*)(params.GetStructMemory() + 17);
		Params.bProjectDestinationToNavigation = *(bool*)(params.GetStructMemory() + 18);
		Params.bCanStrafe = *(bool*)(params.GetStructMemory() + 19);
		Params.FilterClass = *(TSubclassOf<UNavigationQueryFilter> *)(params.GetStructMemory() + 24);
		Params.bAllowPartialPath = *(bool*)(params.GetStructMemory() + 32);
		Params.ReturnValue = *(TEnumAsByte<EPathFollowingRequestResult::Type>*)(params.GetStructMemory() + 33);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushinteger(InScriptContext, (int)Params.ReturnValue);
	return 1;
}

int32 MoveToActor(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AIController",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AIController must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		AActor* Goal = nullptr;
		float AcceptanceRadius;
		bool bStopOnOverlap;
		bool bUsePathfinding;
		bool bCanStrafe;
		TSubclassOf<UNavigationQueryFilter>  FilterClass;
		bool bAllowPartialPath;
		TEnumAsByte<EPathFollowingRequestResult::Type> ReturnValue;
	} Params;
	Params.Goal = (AActor*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"Actor");;
	Params.AcceptanceRadius = lua_isnoneornil(InScriptContext,3) ? float(-1.000000) : (float)(luaL_checknumber(InScriptContext, 3));
	Params.bStopOnOverlap = lua_isnoneornil(InScriptContext,4) ? bool(true) : !!(lua_toboolean(InScriptContext, 4));
	Params.bUsePathfinding = lua_isnoneornil(InScriptContext,5) ? bool(true) : !!(lua_toboolean(InScriptContext, 5));
	Params.bCanStrafe = lua_isnoneornil(InScriptContext,6) ? bool(true) : !!(lua_toboolean(InScriptContext, 6));
	Params.FilterClass = lua_isnoneornil(InScriptContext,7) ? (UClass*)TSubclassOf<UNavigationQueryFilter> (nullptr) : (UClass*)wLua::FLuaUtils::GetUObject(InScriptContext,7,"Class");;
	Params.bAllowPartialPath = lua_isnoneornil(InScriptContext,8) ? bool(true) : !!(lua_toboolean(InScriptContext, 8));
#if UE_GAME
	AAIController * This = (AAIController *)Obj;
	Params.ReturnValue = This->MoveToActor(Params.Goal,Params.AcceptanceRadius,Params.bStopOnOverlap,Params.bUsePathfinding,Params.bCanStrafe,Params.FilterClass,Params.bAllowPartialPath);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("MoveToActor"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(AActor**)(params.GetStructMemory() + 0) = Params.Goal;
		*(float*)(params.GetStructMemory() + 8) = Params.AcceptanceRadius;
		*(bool*)(params.GetStructMemory() + 12) = Params.bStopOnOverlap;
		*(bool*)(params.GetStructMemory() + 13) = Params.bUsePathfinding;
		*(bool*)(params.GetStructMemory() + 14) = Params.bCanStrafe;
		*(TSubclassOf<UNavigationQueryFilter> *)(params.GetStructMemory() + 16) = Params.FilterClass;
		*(bool*)(params.GetStructMemory() + 24) = Params.bAllowPartialPath;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.Goal = *(AActor**)(params.GetStructMemory() + 0);
		Params.AcceptanceRadius = *(float*)(params.GetStructMemory() + 8);
		Params.bStopOnOverlap = *(bool*)(params.GetStructMemory() + 12);
		Params.bUsePathfinding = *(bool*)(params.GetStructMemory() + 13);
		Params.bCanStrafe = *(bool*)(params.GetStructMemory() + 14);
		Params.FilterClass = *(TSubclassOf<UNavigationQueryFilter> *)(params.GetStructMemory() + 16);
		Params.bAllowPartialPath = *(bool*)(params.GetStructMemory() + 24);
		Params.ReturnValue = *(TEnumAsByte<EPathFollowingRequestResult::Type>*)(params.GetStructMemory() + 25);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushinteger(InScriptContext, (int)Params.ReturnValue);
	return 1;
}

int32 K2_SetFocus(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AIController",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AIController must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		AActor* NewFocus = nullptr;
	} Params;
	Params.NewFocus = (AActor*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"Actor");;
#if UE_GAME
	AAIController * This = (AAIController *)Obj;
	This->K2_SetFocus(Params.NewFocus);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("K2_SetFocus"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(AActor**)(params.GetStructMemory() + 0) = Params.NewFocus;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.NewFocus = *(AActor**)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 K2_SetFocalPoint(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AIController",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AIController must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FVector FP;
	} Params;
	Params.FP = (wLua::FLuaVector::Get(InScriptContext, 2));
#if UE_GAME
	AAIController * This = (AAIController *)Obj;
	This->K2_SetFocalPoint(Params.FP);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("K2_SetFocalPoint"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FVector*)(params.GetStructMemory() + 0) = Params.FP;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.FP = *(FVector*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 K2_ClearFocus(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AIController",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AIController must be non-null"); lua_error(InScriptContext);  return 0;}
#if UE_GAME
	AAIController * This = (AAIController *)Obj;
	This->K2_ClearFocus();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("K2_ClearFocus"));
	if(!Function) { check(false); return 0;}
	Obj->ProcessEvent(Function, NULL);
#endif
	return 0;
}

int32 HasPartialPath(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AIController",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AIController must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool ReturnValue;
	} Params;
#if UE_GAME
	AAIController * This = (AAIController *)Obj;
	Params.ReturnValue = This->HasPartialPath();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("HasPartialPath"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushboolean(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetPathFollowingComponent(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AIController",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AIController must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		UPathFollowingComponent* ReturnValue = nullptr;
	} Params;
#if UE_GAME
	AAIController * This = (AAIController *)Obj;
	Params.ReturnValue = This->GetPathFollowingComponent();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetPathFollowingComponent"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(UPathFollowingComponent**)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetMoveStatus(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AIController",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AIController must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		TEnumAsByte<EPathFollowingStatus::Type> ReturnValue;
	} Params;
#if UE_GAME
	AAIController * This = (AAIController *)Obj;
	Params.ReturnValue = This->GetMoveStatus();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetMoveStatus"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(TEnumAsByte<EPathFollowingStatus::Type>*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushinteger(InScriptContext, (int)Params.ReturnValue);
	return 1;
}

int32 GetImmediateMoveDestination(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AIController",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AIController must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FVector ReturnValue;
	} Params;
#if UE_GAME
	AAIController * This = (AAIController *)Obj;
	Params.ReturnValue = This->GetImmediateMoveDestination();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetImmediateMoveDestination"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(FVector*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaVector::Return(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetFocusActor(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AIController",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AIController must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		AActor* ReturnValue = nullptr;
	} Params;
#if UE_GAME
	AAIController * This = (AAIController *)Obj;
	Params.ReturnValue = This->GetFocusActor();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetFocusActor"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(AActor**)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetFocalPointOnActor(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AIController",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AIController must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		AActor* Actor = nullptr;
		FVector ReturnValue;
	} Params;
	Params.Actor = (AActor*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"Actor");;
#if UE_GAME
	AAIController * This = (AAIController *)Obj;
	Params.ReturnValue = This->GetFocalPointOnActor(Params.Actor);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetFocalPointOnActor"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(AActor**)(params.GetStructMemory() + 0) = Params.Actor;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.Actor = *(AActor**)(params.GetStructMemory() + 0);
		Params.ReturnValue = *(FVector*)(params.GetStructMemory() + 8);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaVector::Return(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetFocalPoint(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AIController",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AIController must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FVector ReturnValue;
	} Params;
#if UE_GAME
	AAIController * This = (AAIController *)Obj;
	Params.ReturnValue = This->GetFocalPoint();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetFocalPoint"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(FVector*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaVector::Return(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetAIPerceptionComponent(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AIController",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AIController must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		UAIPerceptionComponent* ReturnValue = nullptr;
	} Params;
#if UE_GAME
	AAIController * This = (AAIController *)Obj;
	Params.ReturnValue = This->GetAIPerceptionComponent();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetAIPerceptionComponent"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(UAIPerceptionComponent**)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 ClaimTaskResource(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AIController",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AIController must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		TSubclassOf<UGameplayTaskResource>  ResourceClass;
	} Params;
	Params.ResourceClass = (UClass*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"Class");;
#if UE_GAME
	AAIController * This = (AAIController *)Obj;
	This->ClaimTaskResource(Params.ResourceClass);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("ClaimTaskResource"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(TSubclassOf<UGameplayTaskResource> *)(params.GetStructMemory() + 0) = Params.ResourceClass;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ResourceClass = *(TSubclassOf<UGameplayTaskResource> *)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 Get_bStopAILogicOnUnposses(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AIController",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AIController must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAIController::StaticClass(), TEXT("bStopAILogicOnUnposses"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bStopAILogicOnUnposses(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AIController",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AIController must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAIController::StaticClass(), TEXT("bStopAILogicOnUnposses"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bSkipExtraLOSChecks(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AIController",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AIController must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAIController::StaticClass(), TEXT("bSkipExtraLOSChecks"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bSkipExtraLOSChecks(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AIController",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AIController must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAIController::StaticClass(), TEXT("bSkipExtraLOSChecks"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bAllowStrafe(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AIController",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AIController must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAIController::StaticClass(), TEXT("bAllowStrafe"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bAllowStrafe(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AIController",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AIController must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAIController::StaticClass(), TEXT("bAllowStrafe"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bWantsPlayerState(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AIController",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AIController must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAIController::StaticClass(), TEXT("bWantsPlayerState"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bWantsPlayerState(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AIController",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AIController must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAIController::StaticClass(), TEXT("bWantsPlayerState"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bSetControlRotationFromPawnOrientation(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AIController",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AIController must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAIController::StaticClass(), TEXT("bSetControlRotationFromPawnOrientation"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bSetControlRotationFromPawnOrientation(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AIController",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AIController must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAIController::StaticClass(), TEXT("bSetControlRotationFromPawnOrientation"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_PathFollowingComponent(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AIController",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AIController must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAIController::StaticClass(), TEXT("PathFollowingComponent"));
	if(!Property) { check(false); return 0;}
	UPathFollowingComponent* PropertyValue;
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaUtils::ReturnUObject(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_PathFollowingComponent(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AIController",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AIController must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAIController::StaticClass(), TEXT("PathFollowingComponent"));
	if(!Property) { check(false); return 0;}
	UPathFollowingComponent* PropertyValue = (UPathFollowingComponent*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"PathFollowingComponent");;
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_BrainComponent(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AIController",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AIController must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAIController::StaticClass(), TEXT("BrainComponent"));
	if(!Property) { check(false); return 0;}
	UBrainComponent* PropertyValue;
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaUtils::ReturnUObject(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_BrainComponent(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AIController",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AIController must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAIController::StaticClass(), TEXT("BrainComponent"));
	if(!Property) { check(false); return 0;}
	UBrainComponent* PropertyValue = (UBrainComponent*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"BrainComponent");;
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_PerceptionComponent(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AIController",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AIController must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAIController::StaticClass(), TEXT("PerceptionComponent"));
	if(!Property) { check(false); return 0;}
	UAIPerceptionComponent* PropertyValue;
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaUtils::ReturnUObject(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_PerceptionComponent(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AIController",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AIController must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAIController::StaticClass(), TEXT("PerceptionComponent"));
	if(!Property) { check(false); return 0;}
	UAIPerceptionComponent* PropertyValue = (UAIPerceptionComponent*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"AIPerceptionComponent");;
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_ActionsComp(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AIController",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AIController must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAIController::StaticClass(), TEXT("ActionsComp"));
	if(!Property) { check(false); return 0;}
	UPawnActionsComponent* PropertyValue;
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaUtils::ReturnUObject(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_Blackboard(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AIController",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AIController must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAIController::StaticClass(), TEXT("Blackboard"));
	if(!Property) { check(false); return 0;}
	UBlackboardComponent* PropertyValue;
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaUtils::ReturnUObject(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_DefaultNavigationFilterClass(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AIController",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AIController must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAIController::StaticClass(), TEXT("DefaultNavigationFilterClass"));
	if(!Property) { check(false); return 0;}
	TSubclassOf<UNavigationQueryFilter>  PropertyValue = TSubclassOf<UNavigationQueryFilter> ();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaUtils::ReturnUObject(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_DefaultNavigationFilterClass(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AIController",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AIController must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAIController::StaticClass(), TEXT("DefaultNavigationFilterClass"));
	if(!Property) { check(false); return 0;}
	TSubclassOf<UNavigationQueryFilter>  PropertyValue = (UClass*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"Class");;
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 New(lua_State* InScriptContext)
{
	UObject* Outer = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Object");
	FName Name = FName(luaL_checkstring(InScriptContext, 2));
	UObject* Obj = NewObject<AAIController>(Outer, Name);
	wLua::FLuaUtils::ReturnUObject(InScriptContext,Obj);
	return 1;
}

int32 Destroy(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AIController",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AIController must be non-null"); lua_error(InScriptContext);  return 0;}
		AActor * actor = Cast<AActor>(Obj);
		actor->Destroy();
		userdata->flag |= wLua::LuaObjectFlag::DESTROYED;
		wLua::FLuaUtils::RemoveObjectReference(Obj, userdata->stamp, InScriptContext);
#ifdef AZURE_BUILD_WLUACHECK
		UE_LOG(LogAzure, Warning, TEXT("Destroy AIController: %x userdata:%x   stamp:%x"),Obj,userdata,userdata->stamp);
#endif
	return 0;
}

int32 Class(lua_State* InScriptContext)
{
	UClass* Class = AAIController::StaticClass();
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Class);
	return 1;
}

const luaL_Reg Lib_Funcs[] =
{
	{ "New", New },
	{ "Destroy", Destroy },
	{ "Class", Class },
	{ "UseBlackboard", UseBlackboard },
	{ "UnclaimTaskResource", UnclaimTaskResource },
	{ "SetPathFollowingComponent", SetPathFollowingComponent },
	{ "SetMoveBlockDetection", SetMoveBlockDetection },
	{ "RunBehaviorTree", RunBehaviorTree },
	{ "OnUsingBlackBoard", OnUsingBlackBoard },
	{ "OnUnpossess", OnUnpossess },
	{ "OnPossess", OnPossess },
	{ "MoveToLocation", MoveToLocation },
	{ "MoveToActor", MoveToActor },
	{ "SetFocus", K2_SetFocus },
	{ "SetFocalPoint", K2_SetFocalPoint },
	{ "ClearFocus", K2_ClearFocus },
	{ "HasPartialPath", HasPartialPath },
	{ "GetPathFollowingComponent", GetPathFollowingComponent },
	{ "GetMoveStatus", GetMoveStatus },
	{ "GetImmediateMoveDestination", GetImmediateMoveDestination },
	{ "GetFocusActor", GetFocusActor },
	{ "GetFocalPointOnActor", GetFocalPointOnActor },
	{ "GetFocalPoint", GetFocalPoint },
	{ "GetAIPerceptionComponent", GetAIPerceptionComponent },
	{ "ClaimTaskResource", ClaimTaskResource },
	{ "Get_bStopAILogicOnUnposses", Get_bStopAILogicOnUnposses },
	{ "Set_bStopAILogicOnUnposses", Set_bStopAILogicOnUnposses },
	{ "Get_bSkipExtraLOSChecks", Get_bSkipExtraLOSChecks },
	{ "Set_bSkipExtraLOSChecks", Set_bSkipExtraLOSChecks },
	{ "Get_bAllowStrafe", Get_bAllowStrafe },
	{ "Set_bAllowStrafe", Set_bAllowStrafe },
	{ "Get_bWantsPlayerState", Get_bWantsPlayerState },
	{ "Set_bWantsPlayerState", Set_bWantsPlayerState },
	{ "Get_bSetControlRotationFromPawnOrientation", Get_bSetControlRotationFromPawnOrientation },
	{ "Set_bSetControlRotationFromPawnOrientation", Set_bSetControlRotationFromPawnOrientation },
	{ "Get_PathFollowingComponent", Get_PathFollowingComponent },
	{ "Set_PathFollowingComponent", Set_PathFollowingComponent },
	{ "Get_BrainComponent", Get_BrainComponent },
	{ "Set_BrainComponent", Set_BrainComponent },
	{ "Get_PerceptionComponent", Get_PerceptionComponent },
	{ "Set_PerceptionComponent", Set_PerceptionComponent },
	{ "Get_ActionsComp", Get_ActionsComp },
	{ "Get_Blackboard", Get_Blackboard },
	{ "Get_DefaultNavigationFilterClass", Get_DefaultNavigationFilterClass },
	{ "Set_DefaultNavigationFilterClass", Set_DefaultNavigationFilterClass },
	{ "is_nil", wLua::LuaStatic::isnil },
	{ "__gc", wLua::LuaStatic::removeUClassFrameCache },
	{ NULL, NULL }
};

void Register(lua_State *InScriptContext)
{
	lua_newtable(InScriptContext);
	luaL_register(InScriptContext, NULL, Lib_Funcs);
	AzureHelpFuncs::AuxRegister(InScriptContext, "AIController");
}
void SetMtLink(lua_State *InScriptContext)
{
	AzureHelpFuncs::AuxSetMtLink(InScriptContext, "AIController", "Controller",USERDATATYPE_UOBJECT);
}

}