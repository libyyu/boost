#include "Azure.h"
#include "Utility/help_funcs.h"
#include "wLua/UObjectHeaders.h"
#include "AzureViewport.h"
#include "AzureLuaIntegration.h"

namespace LuaAzureViewport
{
int32 SetWorldRotation(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureViewport",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureViewport must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float InRoll;
		float InPitch;
		float InYaw;
	} Params;
	Params.InRoll = (float)(luaL_checknumber(InScriptContext, 2));
	Params.InPitch = (float)(luaL_checknumber(InScriptContext, 3));
	Params.InYaw = (float)(luaL_checknumber(InScriptContext, 4));
#if UE_GAME
	UAzureViewport * This = (UAzureViewport *)Obj;
	This->SetWorldRotation(Params.InRoll,Params.InPitch,Params.InYaw);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetWorldRotation"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(float*)(params.GetStructMemory() + 0) = Params.InRoll;
		*(float*)(params.GetStructMemory() + 4) = Params.InPitch;
		*(float*)(params.GetStructMemory() + 8) = Params.InYaw;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.InRoll = *(float*)(params.GetStructMemory() + 0);
		Params.InPitch = *(float*)(params.GetStructMemory() + 4);
		Params.InYaw = *(float*)(params.GetStructMemory() + 8);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetWorldPosition(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureViewport",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureViewport must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float x;
		float y;
		float z;
	} Params;
	Params.x = (float)(luaL_checknumber(InScriptContext, 2));
	Params.y = (float)(luaL_checknumber(InScriptContext, 3));
	Params.z = (float)(luaL_checknumber(InScriptContext, 4));
#if UE_GAME
	UAzureViewport * This = (UAzureViewport *)Obj;
	This->SetWorldPosition(Params.x,Params.y,Params.z);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetWorldPosition"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(float*)(params.GetStructMemory() + 0) = Params.x;
		*(float*)(params.GetStructMemory() + 4) = Params.y;
		*(float*)(params.GetStructMemory() + 8) = Params.z;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.x = *(float*)(params.GetStructMemory() + 0);
		Params.y = *(float*)(params.GetStructMemory() + 4);
		Params.z = *(float*)(params.GetStructMemory() + 8);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetFieldOfView(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureViewport",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureViewport must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float InFieldOfView;
	} Params;
	Params.InFieldOfView = (float)(luaL_checknumber(InScriptContext, 2));
#if UE_GAME
	UAzureViewport * This = (UAzureViewport *)Obj;
	This->SetFieldOfView(Params.InFieldOfView);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetFieldOfView"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(float*)(params.GetStructMemory() + 0) = Params.InFieldOfView;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.InFieldOfView = *(float*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetCameraComponent(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureViewport",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureViewport must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		UCameraComponent* InCameraComponent = nullptr;
	} Params;
	Params.InCameraComponent = (UCameraComponent*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"CameraComponent");;
#if UE_GAME
	UAzureViewport * This = (UAzureViewport *)Obj;
	This->SetCameraComponent(Params.InCameraComponent);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetCameraComponent"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(UCameraComponent**)(params.GetStructMemory() + 0) = Params.InCameraComponent;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.InCameraComponent = *(UCameraComponent**)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetCameraActor(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureViewport",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureViewport must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		ACameraActor* InCameraActor = nullptr;
	} Params;
	Params.InCameraActor = (ACameraActor*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"CameraActor");;
#if UE_GAME
	UAzureViewport * This = (UAzureViewport *)Obj;
	This->SetCameraActor(Params.InCameraActor);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetCameraActor"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(ACameraActor**)(params.GetStructMemory() + 0) = Params.InCameraActor;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.InCameraActor = *(ACameraActor**)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 Get_bRealTime(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureViewport",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureViewport must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzureViewport::StaticClass(), TEXT("bRealTime"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = bool();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 New(lua_State* InScriptContext)
{
	UObject* Outer = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Object");
	FName Name = FName(luaL_checkstring(InScriptContext, 2));
	UObject* Obj = NewObject<UAzureViewport>(Outer, Name);
	wLua::FLuaUtils::ReturnUObject(InScriptContext,Obj);
	return 1;
}

int32 Destroy(lua_State* InScriptContext)
{
	return 0;
}

int32 Class(lua_State* InScriptContext)
{
	UClass* Class = UAzureViewport::StaticClass();
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Class);
	return 1;
}

const luaL_Reg Lib_Funcs[] =
{
	{ "New", New },
	{ "Destroy", Destroy },
	{ "Class", Class },
	{ "SetWorldRotation", SetWorldRotation },
	{ "SetWorldPosition", SetWorldPosition },
	{ "SetFieldOfView", SetFieldOfView },
	{ "SetCameraComponent", SetCameraComponent },
	{ "SetCameraActor", SetCameraActor },
	{ "Get_bRealTime", Get_bRealTime },
	{ "is_nil", wLua::LuaStatic::isnil },
	{ "__gc", wLua::LuaStatic::removeUClassFrameCache },
	{ NULL, NULL }
};

void Register(lua_State *InScriptContext)
{
	lua_newtable(InScriptContext);
	luaL_register(InScriptContext, NULL, Lib_Funcs);
	AzureHelpFuncs::AuxRegister(InScriptContext, "AzureViewport");
}
void SetMtLink(lua_State *InScriptContext)
{
	AzureHelpFuncs::AuxSetMtLink(InScriptContext, "AzureViewport", "Widget",USERDATATYPE_UOBJECT);
}

}