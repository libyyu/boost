#include "Azure.h"
#include "Utility/help_funcs.h"
#include "wLua/UObjectHeaders.h"
#include "Components/RetainerBox.h"
#include "RetainerBox.h"
#include "AzureLuaIntegration.h"

namespace LuaRetainerBox
{
int32 SetTextureParameter(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"RetainerBox",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"RetainerBox must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FName TextureParameter;
	} Params;
	Params.TextureParameter = FName(UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 2)));
#if UE_GAME
	URetainerBox * This = (URetainerBox *)Obj;
	This->SetTextureParameter(Params.TextureParameter);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetTextureParameter"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FName*)(params.GetStructMemory() + 0) = Params.TextureParameter;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.TextureParameter = *(FName*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetRenderingPhase(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"RetainerBox",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"RetainerBox must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		int32 RenderPhase;
		int32 TotalPhases;
	} Params;
	Params.RenderPhase = (luaL_checkint(InScriptContext, 2));
	Params.TotalPhases = (luaL_checkint(InScriptContext, 3));
#if UE_GAME
	URetainerBox * This = (URetainerBox *)Obj;
	This->SetRenderingPhase(Params.RenderPhase,Params.TotalPhases);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetRenderingPhase"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(int32*)(params.GetStructMemory() + 0) = Params.RenderPhase;
		*(int32*)(params.GetStructMemory() + 4) = Params.TotalPhases;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.RenderPhase = *(int32*)(params.GetStructMemory() + 0);
		Params.TotalPhases = *(int32*)(params.GetStructMemory() + 4);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetEffectMaterial(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"RetainerBox",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"RetainerBox must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		UMaterialInterface* EffectMaterial = nullptr;
	} Params;
	Params.EffectMaterial = (UMaterialInterface*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"MaterialInterface");;
#if UE_GAME
	URetainerBox * This = (URetainerBox *)Obj;
	This->SetEffectMaterial(Params.EffectMaterial);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetEffectMaterial"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(UMaterialInterface**)(params.GetStructMemory() + 0) = Params.EffectMaterial;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.EffectMaterial = *(UMaterialInterface**)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 RequestRender(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"RetainerBox",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"RetainerBox must be non-null"); lua_error(InScriptContext);  return 0;}
#if UE_GAME
	URetainerBox * This = (URetainerBox *)Obj;
	This->RequestRender();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("RequestRender"));
	if(!Function) { check(false); return 0;}
	Obj->ProcessEvent(Function, NULL);
#endif
	return 0;
}

int32 GetEffectMaterial(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"RetainerBox",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"RetainerBox must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		UMaterialInstanceDynamic* ReturnValue = nullptr;
	} Params;
#if UE_GAME
	URetainerBox * This = (URetainerBox *)Obj;
	Params.ReturnValue = This->GetEffectMaterial();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetEffectMaterial"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(UMaterialInstanceDynamic**)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 Get_RenderOnInvalidation(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"RetainerBox",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"RetainerBox must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(URetainerBox::StaticClass(), TEXT("RenderOnInvalidation"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = bool();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_RenderOnPhase(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"RetainerBox",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"RetainerBox must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(URetainerBox::StaticClass(), TEXT("RenderOnPhase"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = bool();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_Phase(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"RetainerBox",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"RetainerBox must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(URetainerBox::StaticClass(), TEXT("Phase"));
	if(!Property) { check(false); return 0;}
	int32 PropertyValue = int32();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushinteger(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_PhaseCount(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"RetainerBox",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"RetainerBox must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(URetainerBox::StaticClass(), TEXT("PhaseCount"));
	if(!Property) { check(false); return 0;}
	int32 PropertyValue = int32();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushinteger(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_EffectMaterial(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"RetainerBox",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"RetainerBox must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(URetainerBox::StaticClass(), TEXT("EffectMaterial"));
	if(!Property) { check(false); return 0;}
	UMaterialInterface* PropertyValue;
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaUtils::ReturnUObject(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_TextureParameter(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"RetainerBox",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"RetainerBox must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(URetainerBox::StaticClass(), TEXT("TextureParameter"));
	if(!Property) { check(false); return 0;}
	FName PropertyValue = FName();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushstring(InScriptContext, TCHAR_TO_UTF8(*PropertyValue.ToString()));
	return 1;
}

int32 New(lua_State* InScriptContext)
{
	UObject* Outer = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Object");
	FName Name = FName(luaL_checkstring(InScriptContext, 2));
	UObject* Obj = NewObject<URetainerBox>(Outer, Name);
	wLua::FLuaUtils::ReturnUObject(InScriptContext,Obj);
	return 1;
}

int32 Destroy(lua_State* InScriptContext)
{
	return 0;
}

int32 Class(lua_State* InScriptContext)
{
	UClass* Class = URetainerBox::StaticClass();
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Class);
	return 1;
}

const luaL_Reg Lib_Funcs[] =
{
	{ "New", New },
	{ "Destroy", Destroy },
	{ "Class", Class },
	{ "SetTextureParameter", SetTextureParameter },
	{ "SetRenderingPhase", SetRenderingPhase },
	{ "SetEffectMaterial", SetEffectMaterial },
	{ "RequestRender", RequestRender },
	{ "GetEffectMaterial", GetEffectMaterial },
	{ "Get_RenderOnInvalidation", Get_RenderOnInvalidation },
	{ "Get_RenderOnPhase", Get_RenderOnPhase },
	{ "Get_Phase", Get_Phase },
	{ "Get_PhaseCount", Get_PhaseCount },
	{ "Get_EffectMaterial", Get_EffectMaterial },
	{ "Get_TextureParameter", Get_TextureParameter },
	{ "is_nil", wLua::LuaStatic::isnil },
	{ "__gc", wLua::LuaStatic::removeUClassFrameCache },
	{ NULL, NULL }
};

void Register(lua_State *InScriptContext)
{
	lua_newtable(InScriptContext);
	luaL_register(InScriptContext, NULL, Lib_Funcs);
	AzureHelpFuncs::AuxRegister(InScriptContext, "RetainerBox");
}
void SetMtLink(lua_State *InScriptContext)
{
	AzureHelpFuncs::AuxSetMtLink(InScriptContext, "RetainerBox", "ContentWidget",USERDATATYPE_UOBJECT);
}

}