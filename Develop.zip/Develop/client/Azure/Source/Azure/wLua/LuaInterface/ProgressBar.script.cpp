#include "Azure.h"
#include "Utility/help_funcs.h"
#include "wLua/UObjectHeaders.h"
#include "Components/ProgressBar.h"
#include "AzureLuaIntegration.h"

namespace LuaProgressBar
{
int32 SetBackgroundImage(lua_State*);
int32 SetFillImage(lua_State*);
int32 SetAtlasName(lua_State*);
int32 GetFillImageDynamicMaterial(lua_State*);
int32 GetBackgroundImageDynamicMaterial(lua_State*);

int32 SetPercent(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ProgressBar",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ProgressBar must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float InPercent;
	} Params;
	Params.InPercent = (float)(luaL_checknumber(InScriptContext, 2));
#if UE_GAME
	UProgressBar * This = (UProgressBar *)Obj;
	This->SetPercent(Params.InPercent);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetPercent"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(float*)(params.GetStructMemory() + 0) = Params.InPercent;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.InPercent = *(float*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetIsMarquee(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ProgressBar",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ProgressBar must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool InbIsMarquee;
	} Params;
	Params.InbIsMarquee = !!(lua_toboolean(InScriptContext, 2));
#if UE_GAME
	UProgressBar * This = (UProgressBar *)Obj;
	This->SetIsMarquee(Params.InbIsMarquee);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetIsMarquee"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(bool*)(params.GetStructMemory() + 0) = Params.InbIsMarquee;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.InbIsMarquee = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetFillColorAndOpacity(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ProgressBar",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ProgressBar must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FLinearColor InColor;
	} Params;
	Params.InColor = (wLua::FLuaLinearColor::Get(InScriptContext, 2));
#if UE_GAME
	UProgressBar * This = (UProgressBar *)Obj;
	This->SetFillColorAndOpacity(Params.InColor);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetFillColorAndOpacity"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FLinearColor*)(params.GetStructMemory() + 0) = Params.InColor;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.InColor = *(FLinearColor*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 Get_Percent(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ProgressBar",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ProgressBar must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UProgressBar::StaticClass(), TEXT("Percent"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_BarFillType(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ProgressBar",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ProgressBar must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UProgressBar::StaticClass(), TEXT("BarFillType"));
	if(!Property) { check(false); return 0;}
	TEnumAsByte<EProgressBarFillType::Type> PropertyValue = TEnumAsByte<EProgressBarFillType::Type>();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushinteger(InScriptContext, (int)PropertyValue);
	return 1;
}

int32 Get_bIsMarquee(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ProgressBar",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ProgressBar must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UProgressBar::StaticClass(), TEXT("bIsMarquee"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = bool();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_BorderPadding(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ProgressBar",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ProgressBar must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UProgressBar::StaticClass(), TEXT("BorderPadding"));
	if(!Property) { check(false); return 0;}
	FVector2D PropertyValue = FVector2D();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaVector2D::Return(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_FillColorAndOpacity(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ProgressBar",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ProgressBar must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UProgressBar::StaticClass(), TEXT("FillColorAndOpacity"));
	if(!Property) { check(false); return 0;}
	FLinearColor PropertyValue = FLinearColor();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaLinearColor::Return(InScriptContext, PropertyValue);
	return 1;
}

int32 New(lua_State* InScriptContext)
{
	UObject* Outer = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Object");
	FName Name = FName(luaL_checkstring(InScriptContext, 2));
	UObject* Obj = NewObject<UProgressBar>(Outer, Name);
	wLua::FLuaUtils::ReturnUObject(InScriptContext,Obj);
	return 1;
}

int32 Destroy(lua_State* InScriptContext)
{
	return 0;
}

int32 Class(lua_State* InScriptContext)
{
	UClass* Class = UProgressBar::StaticClass();
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Class);
	return 1;
}

const luaL_Reg Lib_Funcs[] =
{
	{ "New", New },
	{ "Destroy", Destroy },
	{ "Class", Class },
	{ "SetPercent", SetPercent },
	{ "SetIsMarquee", SetIsMarquee },
	{ "SetFillColorAndOpacity", SetFillColorAndOpacity },
	{ "Get_Percent", Get_Percent },
	{ "Get_BarFillType", Get_BarFillType },
	{ "Get_bIsMarquee", Get_bIsMarquee },
	{ "Get_BorderPadding", Get_BorderPadding },
	{ "Get_FillColorAndOpacity", Get_FillColorAndOpacity },
	{ "SetBackgroundImage", SetBackgroundImage },
	{ "SetFillImage", SetFillImage },
	{ "SetAtlasName", SetAtlasName },
	{ "GetFillImageDynamicMaterial", GetFillImageDynamicMaterial },
	{ "GetBackgroundImageDynamicMaterial", GetBackgroundImageDynamicMaterial },
	{ "is_nil", wLua::LuaStatic::isnil },
	{ "__gc", wLua::LuaStatic::removeUClassFrameCache },
	{ NULL, NULL }
};

void Register(lua_State *InScriptContext)
{
	lua_newtable(InScriptContext);
	luaL_register(InScriptContext, NULL, Lib_Funcs);
	AzureHelpFuncs::AuxRegister(InScriptContext, "ProgressBar");
}
void SetMtLink(lua_State *InScriptContext)
{
	AzureHelpFuncs::AuxSetMtLink(InScriptContext, "ProgressBar", "Widget",USERDATATYPE_UOBJECT);
}

}