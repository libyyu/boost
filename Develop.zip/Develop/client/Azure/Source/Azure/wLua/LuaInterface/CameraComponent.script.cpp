#include "Azure.h"
#include "Utility/help_funcs.h"
#include "wLua/UObjectHeaders.h"
#include "Camera/CameraComponent.h"
#include "AzureLuaIntegration.h"

namespace LuaCameraComponent
{
int32 SetUseFieldOfViewForLOD(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CameraComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CameraComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool bInUseFieldOfViewForLOD;
	} Params;
	Params.bInUseFieldOfViewForLOD = !!(lua_toboolean(InScriptContext, 2));
#if UE_GAME
	UCameraComponent * This = (UCameraComponent *)Obj;
	This->SetUseFieldOfViewForLOD(Params.bInUseFieldOfViewForLOD);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetUseFieldOfViewForLOD"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(bool*)(params.GetStructMemory() + 0) = Params.bInUseFieldOfViewForLOD;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.bInUseFieldOfViewForLOD = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetProjectionMode(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CameraComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CameraComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		TEnumAsByte<ECameraProjectionMode::Type> InProjectionMode;
	} Params;
	Params.InProjectionMode = (TEnumAsByte<ECameraProjectionMode::Type>)(luaL_checkint(InScriptContext, 2));
#if UE_GAME
	UCameraComponent * This = (UCameraComponent *)Obj;
	This->SetProjectionMode(Params.InProjectionMode);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetProjectionMode"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(TEnumAsByte<ECameraProjectionMode::Type>*)(params.GetStructMemory() + 0) = Params.InProjectionMode;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.InProjectionMode = *(TEnumAsByte<ECameraProjectionMode::Type>*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetPostProcessBlendWeight(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CameraComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CameraComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float InPostProcessBlendWeight;
	} Params;
	Params.InPostProcessBlendWeight = (float)(luaL_checknumber(InScriptContext, 2));
#if UE_GAME
	UCameraComponent * This = (UCameraComponent *)Obj;
	This->SetPostProcessBlendWeight(Params.InPostProcessBlendWeight);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetPostProcessBlendWeight"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(float*)(params.GetStructMemory() + 0) = Params.InPostProcessBlendWeight;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.InPostProcessBlendWeight = *(float*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetOrthoWidth(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CameraComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CameraComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float InOrthoWidth;
	} Params;
	Params.InOrthoWidth = (float)(luaL_checknumber(InScriptContext, 2));
#if UE_GAME
	UCameraComponent * This = (UCameraComponent *)Obj;
	This->SetOrthoWidth(Params.InOrthoWidth);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetOrthoWidth"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(float*)(params.GetStructMemory() + 0) = Params.InOrthoWidth;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.InOrthoWidth = *(float*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetOrthoNearClipPlane(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CameraComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CameraComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float InOrthoNearClipPlane;
	} Params;
	Params.InOrthoNearClipPlane = (float)(luaL_checknumber(InScriptContext, 2));
#if UE_GAME
	UCameraComponent * This = (UCameraComponent *)Obj;
	This->SetOrthoNearClipPlane(Params.InOrthoNearClipPlane);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetOrthoNearClipPlane"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(float*)(params.GetStructMemory() + 0) = Params.InOrthoNearClipPlane;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.InOrthoNearClipPlane = *(float*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetOrthoFarClipPlane(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CameraComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CameraComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float InOrthoFarClipPlane;
	} Params;
	Params.InOrthoFarClipPlane = (float)(luaL_checknumber(InScriptContext, 2));
#if UE_GAME
	UCameraComponent * This = (UCameraComponent *)Obj;
	This->SetOrthoFarClipPlane(Params.InOrthoFarClipPlane);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetOrthoFarClipPlane"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(float*)(params.GetStructMemory() + 0) = Params.InOrthoFarClipPlane;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.InOrthoFarClipPlane = *(float*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetOffCenterProjectionOffset(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CameraComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CameraComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FVector2D InOffCenterProjectionOffset;
	} Params;
	Params.InOffCenterProjectionOffset = (wLua::FLuaVector2D::Get(InScriptContext, 2));
#if UE_GAME
	UCameraComponent * This = (UCameraComponent *)Obj;
	This->SetOffCenterProjectionOffset(Params.InOffCenterProjectionOffset);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetOffCenterProjectionOffset"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FVector2D*)(params.GetStructMemory() + 0) = Params.InOffCenterProjectionOffset;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.InOffCenterProjectionOffset = *(FVector2D*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetFieldOfView(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CameraComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CameraComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float InFieldOfView;
	} Params;
	Params.InFieldOfView = (float)(luaL_checknumber(InScriptContext, 2));
#if UE_GAME
	UCameraComponent * This = (UCameraComponent *)Obj;
	This->SetFieldOfView(Params.InFieldOfView);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetFieldOfView"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(float*)(params.GetStructMemory() + 0) = Params.InFieldOfView;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.InFieldOfView = *(float*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetConstraintAspectRatio(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CameraComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CameraComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool bInConstrainAspectRatio;
	} Params;
	Params.bInConstrainAspectRatio = !!(lua_toboolean(InScriptContext, 2));
#if UE_GAME
	UCameraComponent * This = (UCameraComponent *)Obj;
	This->SetConstraintAspectRatio(Params.bInConstrainAspectRatio);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetConstraintAspectRatio"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(bool*)(params.GetStructMemory() + 0) = Params.bInConstrainAspectRatio;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.bInConstrainAspectRatio = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetAspectRatio(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CameraComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CameraComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float InAspectRatio;
	} Params;
	Params.InAspectRatio = (float)(luaL_checknumber(InScriptContext, 2));
#if UE_GAME
	UCameraComponent * This = (UCameraComponent *)Obj;
	This->SetAspectRatio(Params.InAspectRatio);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetAspectRatio"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(float*)(params.GetStructMemory() + 0) = Params.InAspectRatio;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.InAspectRatio = *(float*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 Get_FieldOfView(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CameraComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CameraComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UCameraComponent::StaticClass(), TEXT("FieldOfView"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_FieldOfView(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CameraComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CameraComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UCameraComponent::StaticClass(), TEXT("FieldOfView"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_OrthoWidth(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CameraComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CameraComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UCameraComponent::StaticClass(), TEXT("OrthoWidth"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_OrthoWidth(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CameraComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CameraComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UCameraComponent::StaticClass(), TEXT("OrthoWidth"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_OrthoNearClipPlane(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CameraComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CameraComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UCameraComponent::StaticClass(), TEXT("OrthoNearClipPlane"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_OrthoNearClipPlane(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CameraComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CameraComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UCameraComponent::StaticClass(), TEXT("OrthoNearClipPlane"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_OrthoFarClipPlane(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CameraComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CameraComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UCameraComponent::StaticClass(), TEXT("OrthoFarClipPlane"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_OrthoFarClipPlane(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CameraComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CameraComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UCameraComponent::StaticClass(), TEXT("OrthoFarClipPlane"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_AspectRatio(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CameraComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CameraComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UCameraComponent::StaticClass(), TEXT("AspectRatio"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_AspectRatio(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CameraComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CameraComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UCameraComponent::StaticClass(), TEXT("AspectRatio"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bConstrainAspectRatio(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CameraComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CameraComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UCameraComponent::StaticClass(), TEXT("bConstrainAspectRatio"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bConstrainAspectRatio(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CameraComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CameraComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UCameraComponent::StaticClass(), TEXT("bConstrainAspectRatio"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bUseFieldOfViewForLOD(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CameraComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CameraComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UCameraComponent::StaticClass(), TEXT("bUseFieldOfViewForLOD"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bUseFieldOfViewForLOD(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CameraComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CameraComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UCameraComponent::StaticClass(), TEXT("bUseFieldOfViewForLOD"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_OffCenterProjectionOffset(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CameraComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CameraComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UCameraComponent::StaticClass(), TEXT("OffCenterProjectionOffset"));
	if(!Property) { check(false); return 0;}
	FVector2D PropertyValue = FVector2D();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaVector2D::Return(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_OffCenterProjectionOffset(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CameraComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CameraComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UCameraComponent::StaticClass(), TEXT("OffCenterProjectionOffset"));
	if(!Property) { check(false); return 0;}
	FVector2D PropertyValue = (wLua::FLuaVector2D::Get(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bLockToHmd(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CameraComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CameraComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UCameraComponent::StaticClass(), TEXT("bLockToHmd"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bLockToHmd(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CameraComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CameraComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UCameraComponent::StaticClass(), TEXT("bLockToHmd"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bUsePawnControlRotation(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CameraComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CameraComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UCameraComponent::StaticClass(), TEXT("bUsePawnControlRotation"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bUsePawnControlRotation(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CameraComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CameraComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UCameraComponent::StaticClass(), TEXT("bUsePawnControlRotation"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_ProjectionMode(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CameraComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CameraComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UCameraComponent::StaticClass(), TEXT("ProjectionMode"));
	if(!Property) { check(false); return 0;}
	TEnumAsByte<ECameraProjectionMode::Type> PropertyValue = TEnumAsByte<ECameraProjectionMode::Type>();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushinteger(InScriptContext, (int)PropertyValue);
	return 1;
}

int32 Set_ProjectionMode(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CameraComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CameraComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UCameraComponent::StaticClass(), TEXT("ProjectionMode"));
	if(!Property) { check(false); return 0;}
	TEnumAsByte<ECameraProjectionMode::Type> PropertyValue = (TEnumAsByte<ECameraProjectionMode::Type>)(luaL_checkint(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_PostProcessBlendWeight(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CameraComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CameraComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UCameraComponent::StaticClass(), TEXT("PostProcessBlendWeight"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_PostProcessBlendWeight(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CameraComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CameraComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UCameraComponent::StaticClass(), TEXT("PostProcessBlendWeight"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 New(lua_State* InScriptContext)
{
	UObject* Outer = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Object");
	FName Name = FName(luaL_checkstring(InScriptContext, 2));
	UObject* Obj = NewObject<UCameraComponent>(Outer, Name);
	wLua::FLuaUtils::ReturnUObject(InScriptContext,Obj);
	return 1;
}

int32 Destroy(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CameraComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CameraComponent must be non-null"); lua_error(InScriptContext);  return 0;}
		UActorComponent * com = Cast<UActorComponent>(Obj);
		if(lua_isnoneornil(InScriptContext,2))
			com->DestroyComponent();
		else
			com->DestroyComponent(!!lua_toboolean(InScriptContext,2));
		userdata->flag |= wLua::LuaObjectFlag::DESTROYED;
		wLua::FLuaUtils::RemoveObjectReference(Obj, userdata->stamp, InScriptContext);
#ifdef AZURE_BUILD_WLUACHECK
		UE_LOG(LogAzure, Warning, TEXT("Destroy CameraComponent: %x userdata:%x   stamp:%x"),Obj,userdata,userdata->stamp);
#endif
	return 0;
}

int32 Class(lua_State* InScriptContext)
{
	UClass* Class = UCameraComponent::StaticClass();
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Class);
	return 1;
}

const luaL_Reg Lib_Funcs[] =
{
	{ "New", New },
	{ "Destroy", Destroy },
	{ "Class", Class },
	{ "SetUseFieldOfViewForLOD", SetUseFieldOfViewForLOD },
	{ "SetProjectionMode", SetProjectionMode },
	{ "SetPostProcessBlendWeight", SetPostProcessBlendWeight },
	{ "SetOrthoWidth", SetOrthoWidth },
	{ "SetOrthoNearClipPlane", SetOrthoNearClipPlane },
	{ "SetOrthoFarClipPlane", SetOrthoFarClipPlane },
	{ "SetOffCenterProjectionOffset", SetOffCenterProjectionOffset },
	{ "SetFieldOfView", SetFieldOfView },
	{ "SetConstraintAspectRatio", SetConstraintAspectRatio },
	{ "SetAspectRatio", SetAspectRatio },
	{ "Get_FieldOfView", Get_FieldOfView },
	{ "Set_FieldOfView", Set_FieldOfView },
	{ "Get_OrthoWidth", Get_OrthoWidth },
	{ "Set_OrthoWidth", Set_OrthoWidth },
	{ "Get_OrthoNearClipPlane", Get_OrthoNearClipPlane },
	{ "Set_OrthoNearClipPlane", Set_OrthoNearClipPlane },
	{ "Get_OrthoFarClipPlane", Get_OrthoFarClipPlane },
	{ "Set_OrthoFarClipPlane", Set_OrthoFarClipPlane },
	{ "Get_AspectRatio", Get_AspectRatio },
	{ "Set_AspectRatio", Set_AspectRatio },
	{ "Get_bConstrainAspectRatio", Get_bConstrainAspectRatio },
	{ "Set_bConstrainAspectRatio", Set_bConstrainAspectRatio },
	{ "Get_bUseFieldOfViewForLOD", Get_bUseFieldOfViewForLOD },
	{ "Set_bUseFieldOfViewForLOD", Set_bUseFieldOfViewForLOD },
	{ "Get_OffCenterProjectionOffset", Get_OffCenterProjectionOffset },
	{ "Set_OffCenterProjectionOffset", Set_OffCenterProjectionOffset },
	{ "Get_bLockToHmd", Get_bLockToHmd },
	{ "Set_bLockToHmd", Set_bLockToHmd },
	{ "Get_bUsePawnControlRotation", Get_bUsePawnControlRotation },
	{ "Set_bUsePawnControlRotation", Set_bUsePawnControlRotation },
	{ "Get_ProjectionMode", Get_ProjectionMode },
	{ "Set_ProjectionMode", Set_ProjectionMode },
	{ "Get_PostProcessBlendWeight", Get_PostProcessBlendWeight },
	{ "Set_PostProcessBlendWeight", Set_PostProcessBlendWeight },
	{ "is_nil", wLua::LuaStatic::isnil },
	{ "__gc", wLua::LuaStatic::removeUClassFrameCache },
	{ NULL, NULL }
};

void Register(lua_State *InScriptContext)
{
	lua_newtable(InScriptContext);
	luaL_register(InScriptContext, NULL, Lib_Funcs);
	AzureHelpFuncs::AuxRegister(InScriptContext, "CameraComponent");
}
void SetMtLink(lua_State *InScriptContext)
{
	AzureHelpFuncs::AuxSetMtLink(InScriptContext, "CameraComponent", "SceneComponent",USERDATATYPE_UOBJECT);
}

}