#include "Azure.h"
#include "Utility/help_funcs.h"
#include "wLua/UObjectHeaders.h"
#include "Components/SkeletalMeshComponent.h"
#include "AzureLuaIntegration.h"

namespace LuaSkeletalMeshComponent
{
int32 GetNearestPhysicBodyName(lua_State*);
int32 GetPhysicBodyCount(lua_State*);
int32 GetBlowPhysicBodyCount(lua_State*);
int32 GetRefPoseBoneLocation(lua_State*);

int32 UpdateMeshObjectLOD(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SkeletalMeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SkeletalMeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
#if UE_GAME
	USkeletalMeshComponent * This = (USkeletalMeshComponent *)Obj;
	This->UpdateMeshObjectLOD();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("UpdateMeshObjectLOD"));
	if(!Function) { check(false); return 0;}
	Obj->ProcessEvent(Function, NULL);
#endif
	return 0;
}

int32 UnbindClothFromMasterPoseComponent(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SkeletalMeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SkeletalMeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool bRestoreSimulationSpace;
	} Params;
	Params.bRestoreSimulationSpace = lua_isnoneornil(InScriptContext,2) ? bool(true) : !!(lua_toboolean(InScriptContext, 2));
#if UE_GAME
	USkeletalMeshComponent * This = (USkeletalMeshComponent *)Obj;
	This->UnbindClothFromMasterPoseComponent(Params.bRestoreSimulationSpace);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("UnbindClothFromMasterPoseComponent"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(bool*)(params.GetStructMemory() + 0) = Params.bRestoreSimulationSpace;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.bRestoreSimulationSpace = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 ToggleDisablePostProcessBlueprint(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SkeletalMeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SkeletalMeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
#if UE_GAME
	USkeletalMeshComponent * This = (USkeletalMeshComponent *)Obj;
	This->ToggleDisablePostProcessBlueprint();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("ToggleDisablePostProcessBlueprint"));
	if(!Function) { check(false); return 0;}
	Obj->ProcessEvent(Function, NULL);
#endif
	return 0;
}

int32 TermBodiesBelow(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SkeletalMeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SkeletalMeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FName ParentBoneName;
	} Params;
	Params.ParentBoneName = FName(UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 2)));
#if UE_GAME
	USkeletalMeshComponent * This = (USkeletalMeshComponent *)Obj;
	This->TermBodiesBelow(Params.ParentBoneName);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("TermBodiesBelow"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FName*)(params.GetStructMemory() + 0) = Params.ParentBoneName;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ParentBoneName = *(FName*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SuspendClothingSimulation(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SkeletalMeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SkeletalMeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
#if UE_GAME
	USkeletalMeshComponent * This = (USkeletalMeshComponent *)Obj;
	This->SuspendClothingSimulation();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SuspendClothingSimulation"));
	if(!Function) { check(false); return 0;}
	Obj->ProcessEvent(Function, NULL);
#endif
	return 0;
}

int32 Stop(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SkeletalMeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SkeletalMeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
#if UE_GAME
	USkeletalMeshComponent * This = (USkeletalMeshComponent *)Obj;
	This->Stop();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("Stop"));
	if(!Function) { check(false); return 0;}
	Obj->ProcessEvent(Function, NULL);
#endif
	return 0;
}

int32 SetUpdateAnimationInEditor(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SkeletalMeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SkeletalMeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool NewUpdateState;
	} Params;
	Params.NewUpdateState = !!(lua_toboolean(InScriptContext, 2));
#if UE_GAME
	USkeletalMeshComponent * This = (USkeletalMeshComponent *)Obj;
	This->SetUpdateAnimationInEditor(Params.NewUpdateState);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetUpdateAnimationInEditor"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(bool*)(params.GetStructMemory() + 0) = Params.NewUpdateState;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.NewUpdateState = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetTeleportRotationThreshold(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SkeletalMeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SkeletalMeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float Threshold;
	} Params;
	Params.Threshold = (float)(luaL_checknumber(InScriptContext, 2));
#if UE_GAME
	USkeletalMeshComponent * This = (USkeletalMeshComponent *)Obj;
	This->SetTeleportRotationThreshold(Params.Threshold);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetTeleportRotationThreshold"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(float*)(params.GetStructMemory() + 0) = Params.Threshold;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.Threshold = *(float*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetTeleportDistanceThreshold(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SkeletalMeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SkeletalMeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float Threshold;
	} Params;
	Params.Threshold = (float)(luaL_checknumber(InScriptContext, 2));
#if UE_GAME
	USkeletalMeshComponent * This = (USkeletalMeshComponent *)Obj;
	This->SetTeleportDistanceThreshold(Params.Threshold);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetTeleportDistanceThreshold"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(float*)(params.GetStructMemory() + 0) = Params.Threshold;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.Threshold = *(float*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetPosition(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SkeletalMeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SkeletalMeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float InPos;
		bool bFireNotifies;
	} Params;
	Params.InPos = (float)(luaL_checknumber(InScriptContext, 2));
	Params.bFireNotifies = lua_isnoneornil(InScriptContext,3) ? bool(true) : !!(lua_toboolean(InScriptContext, 3));
#if UE_GAME
	USkeletalMeshComponent * This = (USkeletalMeshComponent *)Obj;
	This->SetPosition(Params.InPos,Params.bFireNotifies);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetPosition"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(float*)(params.GetStructMemory() + 0) = Params.InPos;
		*(bool*)(params.GetStructMemory() + 4) = Params.bFireNotifies;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.InPos = *(float*)(params.GetStructMemory() + 0);
		Params.bFireNotifies = *(bool*)(params.GetStructMemory() + 4);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetPlayRate(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SkeletalMeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SkeletalMeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float Rate;
	} Params;
	Params.Rate = (float)(luaL_checknumber(InScriptContext, 2));
#if UE_GAME
	USkeletalMeshComponent * This = (USkeletalMeshComponent *)Obj;
	This->SetPlayRate(Params.Rate);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetPlayRate"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(float*)(params.GetStructMemory() + 0) = Params.Rate;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.Rate = *(float*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetPhysicsBlendWeight(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SkeletalMeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SkeletalMeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float PhysicsBlendWeight;
	} Params;
	Params.PhysicsBlendWeight = (float)(luaL_checknumber(InScriptContext, 2));
#if UE_GAME
	USkeletalMeshComponent * This = (USkeletalMeshComponent *)Obj;
	This->SetPhysicsBlendWeight(Params.PhysicsBlendWeight);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetPhysicsBlendWeight"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(float*)(params.GetStructMemory() + 0) = Params.PhysicsBlendWeight;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.PhysicsBlendWeight = *(float*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetNotifyRigidBodyCollisionBelow(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SkeletalMeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SkeletalMeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool bNewNotifyRigidBodyCollision;
		FName BoneName;
		bool bIncludeSelf;
	} Params;
	Params.bNewNotifyRigidBodyCollision = !!(lua_toboolean(InScriptContext, 2));
	Params.BoneName = lua_isnoneornil(InScriptContext,3) ? FName(TEXT("")) : FName(UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 3)));
	Params.bIncludeSelf = lua_isnoneornil(InScriptContext,4) ? bool(true) : !!(lua_toboolean(InScriptContext, 4));
#if UE_GAME
	USkeletalMeshComponent * This = (USkeletalMeshComponent *)Obj;
	This->SetNotifyRigidBodyCollisionBelow(Params.bNewNotifyRigidBodyCollision,Params.BoneName,Params.bIncludeSelf);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetNotifyRigidBodyCollisionBelow"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(bool*)(params.GetStructMemory() + 0) = Params.bNewNotifyRigidBodyCollision;
		*(FName*)(params.GetStructMemory() + 4) = Params.BoneName;
		*(bool*)(params.GetStructMemory() + 16) = Params.bIncludeSelf;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.bNewNotifyRigidBodyCollision = *(bool*)(params.GetStructMemory() + 0);
		Params.BoneName = *(FName*)(params.GetStructMemory() + 4);
		Params.bIncludeSelf = *(bool*)(params.GetStructMemory() + 16);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetMorphTarget(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SkeletalMeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SkeletalMeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FName MorphTargetName;
		float Value;
		bool bRemoveZeroWeight;
	} Params;
	Params.MorphTargetName = FName(UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 2)));
	Params.Value = (float)(luaL_checknumber(InScriptContext, 3));
	Params.bRemoveZeroWeight = lua_isnoneornil(InScriptContext,4) ? bool(true) : !!(lua_toboolean(InScriptContext, 4));
#if UE_GAME
	USkeletalMeshComponent * This = (USkeletalMeshComponent *)Obj;
	This->SetMorphTarget(Params.MorphTargetName,Params.Value,Params.bRemoveZeroWeight);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetMorphTarget"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FName*)(params.GetStructMemory() + 0) = Params.MorphTargetName;
		*(float*)(params.GetStructMemory() + 12) = Params.Value;
		*(bool*)(params.GetStructMemory() + 16) = Params.bRemoveZeroWeight;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.MorphTargetName = *(FName*)(params.GetStructMemory() + 0);
		Params.Value = *(float*)(params.GetStructMemory() + 12);
		Params.bRemoveZeroWeight = *(bool*)(params.GetStructMemory() + 16);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetEnablePhysicsBlending(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SkeletalMeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SkeletalMeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool bNewBlendPhysics;
	} Params;
	Params.bNewBlendPhysics = !!(lua_toboolean(InScriptContext, 2));
#if UE_GAME
	USkeletalMeshComponent * This = (USkeletalMeshComponent *)Obj;
	This->SetEnablePhysicsBlending(Params.bNewBlendPhysics);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetEnablePhysicsBlending"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(bool*)(params.GetStructMemory() + 0) = Params.bNewBlendPhysics;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.bNewBlendPhysics = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetEnableGravityOnAllBodiesBelow(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SkeletalMeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SkeletalMeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool bEnableGravity;
		FName BoneName;
		bool bIncludeSelf;
	} Params;
	Params.bEnableGravity = !!(lua_toboolean(InScriptContext, 2));
	Params.BoneName = FName(UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 3)));
	Params.bIncludeSelf = lua_isnoneornil(InScriptContext,4) ? bool(true) : !!(lua_toboolean(InScriptContext, 4));
#if UE_GAME
	USkeletalMeshComponent * This = (USkeletalMeshComponent *)Obj;
	This->SetEnableGravityOnAllBodiesBelow(Params.bEnableGravity,Params.BoneName,Params.bIncludeSelf);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetEnableGravityOnAllBodiesBelow"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(bool*)(params.GetStructMemory() + 0) = Params.bEnableGravity;
		*(FName*)(params.GetStructMemory() + 4) = Params.BoneName;
		*(bool*)(params.GetStructMemory() + 16) = Params.bIncludeSelf;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.bEnableGravity = *(bool*)(params.GetStructMemory() + 0);
		Params.BoneName = *(FName*)(params.GetStructMemory() + 4);
		Params.bIncludeSelf = *(bool*)(params.GetStructMemory() + 16);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetEnableBodyGravity(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SkeletalMeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SkeletalMeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool bEnableGravity;
		FName BoneName;
	} Params;
	Params.bEnableGravity = !!(lua_toboolean(InScriptContext, 2));
	Params.BoneName = FName(UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 3)));
#if UE_GAME
	USkeletalMeshComponent * This = (USkeletalMeshComponent *)Obj;
	This->SetEnableBodyGravity(Params.bEnableGravity,Params.BoneName);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetEnableBodyGravity"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(bool*)(params.GetStructMemory() + 0) = Params.bEnableGravity;
		*(FName*)(params.GetStructMemory() + 4) = Params.BoneName;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.bEnableGravity = *(bool*)(params.GetStructMemory() + 0);
		Params.BoneName = *(FName*)(params.GetStructMemory() + 4);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetDisablePostProcessBlueprint(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SkeletalMeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SkeletalMeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool bInDisablePostProcess;
	} Params;
	Params.bInDisablePostProcess = !!(lua_toboolean(InScriptContext, 2));
#if UE_GAME
	USkeletalMeshComponent * This = (USkeletalMeshComponent *)Obj;
	This->SetDisablePostProcessBlueprint(Params.bInDisablePostProcess);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetDisablePostProcessBlueprint"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(bool*)(params.GetStructMemory() + 0) = Params.bInDisablePostProcess;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.bInDisablePostProcess = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetDisableAnimCurves(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SkeletalMeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SkeletalMeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool bInDisableAnimCurves;
	} Params;
	Params.bInDisableAnimCurves = !!(lua_toboolean(InScriptContext, 2));
#if UE_GAME
	USkeletalMeshComponent * This = (USkeletalMeshComponent *)Obj;
	This->SetDisableAnimCurves(Params.bInDisableAnimCurves);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetDisableAnimCurves"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(bool*)(params.GetStructMemory() + 0) = Params.bInDisableAnimCurves;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.bInDisableAnimCurves = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetConstraintProfileForAll(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SkeletalMeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SkeletalMeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FName ProfileName;
		bool bDefaultIfNotFound;
	} Params;
	Params.ProfileName = FName(UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 2)));
	Params.bDefaultIfNotFound = lua_isnoneornil(InScriptContext,3) ? bool(false) : !!(lua_toboolean(InScriptContext, 3));
#if UE_GAME
	USkeletalMeshComponent * This = (USkeletalMeshComponent *)Obj;
	This->SetConstraintProfileForAll(Params.ProfileName,Params.bDefaultIfNotFound);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetConstraintProfileForAll"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FName*)(params.GetStructMemory() + 0) = Params.ProfileName;
		*(bool*)(params.GetStructMemory() + 12) = Params.bDefaultIfNotFound;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ProfileName = *(FName*)(params.GetStructMemory() + 0);
		Params.bDefaultIfNotFound = *(bool*)(params.GetStructMemory() + 12);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetConstraintProfile(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SkeletalMeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SkeletalMeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FName JointName;
		FName ProfileName;
		bool bDefaultIfNotFound;
	} Params;
	Params.JointName = FName(UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 2)));
	Params.ProfileName = FName(UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 3)));
	Params.bDefaultIfNotFound = lua_isnoneornil(InScriptContext,4) ? bool(false) : !!(lua_toboolean(InScriptContext, 4));
#if UE_GAME
	USkeletalMeshComponent * This = (USkeletalMeshComponent *)Obj;
	This->SetConstraintProfile(Params.JointName,Params.ProfileName,Params.bDefaultIfNotFound);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetConstraintProfile"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FName*)(params.GetStructMemory() + 0) = Params.JointName;
		*(FName*)(params.GetStructMemory() + 12) = Params.ProfileName;
		*(bool*)(params.GetStructMemory() + 24) = Params.bDefaultIfNotFound;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.JointName = *(FName*)(params.GetStructMemory() + 0);
		Params.ProfileName = *(FName*)(params.GetStructMemory() + 12);
		Params.bDefaultIfNotFound = *(bool*)(params.GetStructMemory() + 24);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetClothMaxDistanceScale(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SkeletalMeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SkeletalMeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float Scale;
	} Params;
	Params.Scale = (float)(luaL_checknumber(InScriptContext, 2));
#if UE_GAME
	USkeletalMeshComponent * This = (USkeletalMeshComponent *)Obj;
	This->SetClothMaxDistanceScale(Params.Scale);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetClothMaxDistanceScale"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(float*)(params.GetStructMemory() + 0) = Params.Scale;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.Scale = *(float*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetBodyNotifyRigidBodyCollision(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SkeletalMeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SkeletalMeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool bNewNotifyRigidBodyCollision;
		FName BoneName;
	} Params;
	Params.bNewNotifyRigidBodyCollision = !!(lua_toboolean(InScriptContext, 2));
	Params.BoneName = lua_isnoneornil(InScriptContext,3) ? FName(TEXT("")) : FName(UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 3)));
#if UE_GAME
	USkeletalMeshComponent * This = (USkeletalMeshComponent *)Obj;
	This->SetBodyNotifyRigidBodyCollision(Params.bNewNotifyRigidBodyCollision,Params.BoneName);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetBodyNotifyRigidBodyCollision"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(bool*)(params.GetStructMemory() + 0) = Params.bNewNotifyRigidBodyCollision;
		*(FName*)(params.GetStructMemory() + 4) = Params.BoneName;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.bNewNotifyRigidBodyCollision = *(bool*)(params.GetStructMemory() + 0);
		Params.BoneName = *(FName*)(params.GetStructMemory() + 4);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetAnimationMode(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SkeletalMeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SkeletalMeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		TEnumAsByte<EAnimationMode::Type> InAnimationMode;
	} Params;
	Params.InAnimationMode = (TEnumAsByte<EAnimationMode::Type>)(luaL_checkint(InScriptContext, 2));
#if UE_GAME
	USkeletalMeshComponent * This = (USkeletalMeshComponent *)Obj;
	This->SetAnimationMode(Params.InAnimationMode);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetAnimationMode"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(TEnumAsByte<EAnimationMode::Type>*)(params.GetStructMemory() + 0) = Params.InAnimationMode;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.InAnimationMode = *(TEnumAsByte<EAnimationMode::Type>*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetAnimation(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SkeletalMeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SkeletalMeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		UAnimationAsset* NewAnimToPlay = nullptr;
	} Params;
	Params.NewAnimToPlay = (UAnimationAsset*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"AnimationAsset");;
#if UE_GAME
	USkeletalMeshComponent * This = (USkeletalMeshComponent *)Obj;
	This->SetAnimation(Params.NewAnimToPlay);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetAnimation"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(UAnimationAsset**)(params.GetStructMemory() + 0) = Params.NewAnimToPlay;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.NewAnimToPlay = *(UAnimationAsset**)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetAngularLimits(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SkeletalMeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SkeletalMeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FName InBoneName;
		float Swing1LimitAngle;
		float TwistLimitAngle;
		float Swing2LimitAngle;
	} Params;
	Params.InBoneName = FName(UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 2)));
	Params.Swing1LimitAngle = (float)(luaL_checknumber(InScriptContext, 3));
	Params.TwistLimitAngle = (float)(luaL_checknumber(InScriptContext, 4));
	Params.Swing2LimitAngle = (float)(luaL_checknumber(InScriptContext, 5));
#if UE_GAME
	USkeletalMeshComponent * This = (USkeletalMeshComponent *)Obj;
	This->SetAngularLimits(Params.InBoneName,Params.Swing1LimitAngle,Params.TwistLimitAngle,Params.Swing2LimitAngle);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetAngularLimits"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FName*)(params.GetStructMemory() + 0) = Params.InBoneName;
		*(float*)(params.GetStructMemory() + 12) = Params.Swing1LimitAngle;
		*(float*)(params.GetStructMemory() + 16) = Params.TwistLimitAngle;
		*(float*)(params.GetStructMemory() + 20) = Params.Swing2LimitAngle;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.InBoneName = *(FName*)(params.GetStructMemory() + 0);
		Params.Swing1LimitAngle = *(float*)(params.GetStructMemory() + 12);
		Params.TwistLimitAngle = *(float*)(params.GetStructMemory() + 16);
		Params.Swing2LimitAngle = *(float*)(params.GetStructMemory() + 20);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetAllowedAnimCurvesEvaluation(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SkeletalMeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SkeletalMeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		TArray<FName> List;
		bool bAllow;
	} Params;
	Params.List = [](lua_State * _InScriptContext){ TArray<FName> ret; lua_pushnil(_InScriptContext); while(lua_next(_InScriptContext,2)!=0){ FName item = FName(UTF8_TO_TCHAR(luaL_checkstring(_InScriptContext, -1))); ret.Add(item); lua_pop(_InScriptContext,1);  } return ret; }(InScriptContext);;
	Params.bAllow = !!(lua_toboolean(InScriptContext, 3));
#if UE_GAME
	USkeletalMeshComponent * This = (USkeletalMeshComponent *)Obj;
	This->SetAllowedAnimCurvesEvaluation(Params.List,Params.bAllow);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetAllowedAnimCurvesEvaluation"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(TArray<FName>*)(params.GetStructMemory() + 0) = Params.List;
		*(bool*)(params.GetStructMemory() + 16) = Params.bAllow;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.List = *(TArray<FName>*)(params.GetStructMemory() + 0);
		Params.bAllow = *(bool*)(params.GetStructMemory() + 16);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetAllowAnimCurveEvaluation(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SkeletalMeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SkeletalMeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool bInAllow;
	} Params;
	Params.bInAllow = !!(lua_toboolean(InScriptContext, 2));
#if UE_GAME
	USkeletalMeshComponent * This = (USkeletalMeshComponent *)Obj;
	This->SetAllowAnimCurveEvaluation(Params.bInAllow);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetAllowAnimCurveEvaluation"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(bool*)(params.GetStructMemory() + 0) = Params.bInAllow;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.bInAllow = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetAllMotorsAngularVelocityDrive(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SkeletalMeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SkeletalMeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool bEnableSwingDrive;
		bool bEnableTwistDrive;
		bool bSkipCustomPhysicsType;
	} Params;
	Params.bEnableSwingDrive = !!(lua_toboolean(InScriptContext, 2));
	Params.bEnableTwistDrive = !!(lua_toboolean(InScriptContext, 3));
	Params.bSkipCustomPhysicsType = lua_isnoneornil(InScriptContext,4) ? bool(false) : !!(lua_toboolean(InScriptContext, 4));
#if UE_GAME
	USkeletalMeshComponent * This = (USkeletalMeshComponent *)Obj;
	This->SetAllMotorsAngularVelocityDrive(Params.bEnableSwingDrive,Params.bEnableTwistDrive,Params.bSkipCustomPhysicsType);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetAllMotorsAngularVelocityDrive"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(bool*)(params.GetStructMemory() + 0) = Params.bEnableSwingDrive;
		*(bool*)(params.GetStructMemory() + 1) = Params.bEnableTwistDrive;
		*(bool*)(params.GetStructMemory() + 2) = Params.bSkipCustomPhysicsType;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.bEnableSwingDrive = *(bool*)(params.GetStructMemory() + 0);
		Params.bEnableTwistDrive = *(bool*)(params.GetStructMemory() + 1);
		Params.bSkipCustomPhysicsType = *(bool*)(params.GetStructMemory() + 2);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetAllMotorsAngularPositionDrive(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SkeletalMeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SkeletalMeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool bEnableSwingDrive;
		bool bEnableTwistDrive;
		bool bSkipCustomPhysicsType;
	} Params;
	Params.bEnableSwingDrive = !!(lua_toboolean(InScriptContext, 2));
	Params.bEnableTwistDrive = !!(lua_toboolean(InScriptContext, 3));
	Params.bSkipCustomPhysicsType = lua_isnoneornil(InScriptContext,4) ? bool(false) : !!(lua_toboolean(InScriptContext, 4));
#if UE_GAME
	USkeletalMeshComponent * This = (USkeletalMeshComponent *)Obj;
	This->SetAllMotorsAngularPositionDrive(Params.bEnableSwingDrive,Params.bEnableTwistDrive,Params.bSkipCustomPhysicsType);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetAllMotorsAngularPositionDrive"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(bool*)(params.GetStructMemory() + 0) = Params.bEnableSwingDrive;
		*(bool*)(params.GetStructMemory() + 1) = Params.bEnableTwistDrive;
		*(bool*)(params.GetStructMemory() + 2) = Params.bSkipCustomPhysicsType;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.bEnableSwingDrive = *(bool*)(params.GetStructMemory() + 0);
		Params.bEnableTwistDrive = *(bool*)(params.GetStructMemory() + 1);
		Params.bSkipCustomPhysicsType = *(bool*)(params.GetStructMemory() + 2);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetAllMotorsAngularDriveParams(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SkeletalMeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SkeletalMeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float InSpring;
		float InDamping;
		float InForceLimit;
		bool bSkipCustomPhysicsType;
	} Params;
	Params.InSpring = (float)(luaL_checknumber(InScriptContext, 2));
	Params.InDamping = (float)(luaL_checknumber(InScriptContext, 3));
	Params.InForceLimit = (float)(luaL_checknumber(InScriptContext, 4));
	Params.bSkipCustomPhysicsType = lua_isnoneornil(InScriptContext,5) ? bool(false) : !!(lua_toboolean(InScriptContext, 5));
#if UE_GAME
	USkeletalMeshComponent * This = (USkeletalMeshComponent *)Obj;
	This->SetAllMotorsAngularDriveParams(Params.InSpring,Params.InDamping,Params.InForceLimit,Params.bSkipCustomPhysicsType);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetAllMotorsAngularDriveParams"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(float*)(params.GetStructMemory() + 0) = Params.InSpring;
		*(float*)(params.GetStructMemory() + 4) = Params.InDamping;
		*(float*)(params.GetStructMemory() + 8) = Params.InForceLimit;
		*(bool*)(params.GetStructMemory() + 12) = Params.bSkipCustomPhysicsType;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.InSpring = *(float*)(params.GetStructMemory() + 0);
		Params.InDamping = *(float*)(params.GetStructMemory() + 4);
		Params.InForceLimit = *(float*)(params.GetStructMemory() + 8);
		Params.bSkipCustomPhysicsType = *(bool*)(params.GetStructMemory() + 12);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetAllBodiesSimulatePhysics(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SkeletalMeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SkeletalMeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool bNewSimulate;
	} Params;
	Params.bNewSimulate = !!(lua_toboolean(InScriptContext, 2));
#if UE_GAME
	USkeletalMeshComponent * This = (USkeletalMeshComponent *)Obj;
	This->SetAllBodiesSimulatePhysics(Params.bNewSimulate);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetAllBodiesSimulatePhysics"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(bool*)(params.GetStructMemory() + 0) = Params.bNewSimulate;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.bNewSimulate = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetAllBodiesPhysicsBlendWeight(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SkeletalMeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SkeletalMeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float PhysicsBlendWeight;
		bool bSkipCustomPhysicsType;
	} Params;
	Params.PhysicsBlendWeight = (float)(luaL_checknumber(InScriptContext, 2));
	Params.bSkipCustomPhysicsType = lua_isnoneornil(InScriptContext,3) ? bool(false) : !!(lua_toboolean(InScriptContext, 3));
#if UE_GAME
	USkeletalMeshComponent * This = (USkeletalMeshComponent *)Obj;
	This->SetAllBodiesPhysicsBlendWeight(Params.PhysicsBlendWeight,Params.bSkipCustomPhysicsType);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetAllBodiesPhysicsBlendWeight"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(float*)(params.GetStructMemory() + 0) = Params.PhysicsBlendWeight;
		*(bool*)(params.GetStructMemory() + 4) = Params.bSkipCustomPhysicsType;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.PhysicsBlendWeight = *(float*)(params.GetStructMemory() + 0);
		Params.bSkipCustomPhysicsType = *(bool*)(params.GetStructMemory() + 4);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetAllBodiesBelowSimulatePhysics(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SkeletalMeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SkeletalMeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FName InBoneName;
		bool bNewSimulate;
		bool bIncludeSelf;
	} Params;
	Params.InBoneName = FName(UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 2)));
	Params.bNewSimulate = !!(lua_toboolean(InScriptContext, 3));
	Params.bIncludeSelf = lua_isnoneornil(InScriptContext,4) ? bool(true) : !!(lua_toboolean(InScriptContext, 4));
#if UE_GAME
	USkeletalMeshComponent * This = (USkeletalMeshComponent *)Obj;
	This->SetAllBodiesBelowSimulatePhysics(Params.InBoneName,Params.bNewSimulate,Params.bIncludeSelf);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetAllBodiesBelowSimulatePhysics"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FName*)(params.GetStructMemory() + 0) = Params.InBoneName;
		*(bool*)(params.GetStructMemory() + 12) = Params.bNewSimulate;
		*(bool*)(params.GetStructMemory() + 13) = Params.bIncludeSelf;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.InBoneName = *(FName*)(params.GetStructMemory() + 0);
		Params.bNewSimulate = *(bool*)(params.GetStructMemory() + 12);
		Params.bIncludeSelf = *(bool*)(params.GetStructMemory() + 13);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetAllBodiesBelowPhysicsBlendWeight(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SkeletalMeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SkeletalMeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FName InBoneName;
		float PhysicsBlendWeight;
		bool bSkipCustomPhysicsType;
		bool bIncludeSelf;
	} Params;
	Params.InBoneName = FName(UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 2)));
	Params.PhysicsBlendWeight = (float)(luaL_checknumber(InScriptContext, 3));
	Params.bSkipCustomPhysicsType = lua_isnoneornil(InScriptContext,4) ? bool(false) : !!(lua_toboolean(InScriptContext, 4));
	Params.bIncludeSelf = lua_isnoneornil(InScriptContext,5) ? bool(true) : !!(lua_toboolean(InScriptContext, 5));
#if UE_GAME
	USkeletalMeshComponent * This = (USkeletalMeshComponent *)Obj;
	This->SetAllBodiesBelowPhysicsBlendWeight(Params.InBoneName,Params.PhysicsBlendWeight,Params.bSkipCustomPhysicsType,Params.bIncludeSelf);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetAllBodiesBelowPhysicsBlendWeight"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FName*)(params.GetStructMemory() + 0) = Params.InBoneName;
		*(float*)(params.GetStructMemory() + 12) = Params.PhysicsBlendWeight;
		*(bool*)(params.GetStructMemory() + 16) = Params.bSkipCustomPhysicsType;
		*(bool*)(params.GetStructMemory() + 17) = Params.bIncludeSelf;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.InBoneName = *(FName*)(params.GetStructMemory() + 0);
		Params.PhysicsBlendWeight = *(float*)(params.GetStructMemory() + 12);
		Params.bSkipCustomPhysicsType = *(bool*)(params.GetStructMemory() + 16);
		Params.bIncludeSelf = *(bool*)(params.GetStructMemory() + 17);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 ResumeClothingSimulation(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SkeletalMeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SkeletalMeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
#if UE_GAME
	USkeletalMeshComponent * This = (USkeletalMeshComponent *)Obj;
	This->ResumeClothingSimulation();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("ResumeClothingSimulation"));
	if(!Function) { check(false); return 0;}
	Obj->ProcessEvent(Function, NULL);
#endif
	return 0;
}

int32 ResetClothTeleportMode(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SkeletalMeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SkeletalMeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
#if UE_GAME
	USkeletalMeshComponent * This = (USkeletalMeshComponent *)Obj;
	This->ResetClothTeleportMode();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("ResetClothTeleportMode"));
	if(!Function) { check(false); return 0;}
	Obj->ProcessEvent(Function, NULL);
#endif
	return 0;
}

int32 ResetAnimInstanceDynamics(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SkeletalMeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SkeletalMeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		ETeleportType InTeleportType;
	} Params;
	Params.InTeleportType = lua_isnoneornil(InScriptContext,2) ? ETeleportType(ETeleportType::ResetPhysics) : (ETeleportType)(luaL_checkint(InScriptContext, 2));
#if UE_GAME
	USkeletalMeshComponent * This = (USkeletalMeshComponent *)Obj;
	This->ResetAnimInstanceDynamics(Params.InTeleportType);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("ResetAnimInstanceDynamics"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(ETeleportType*)(params.GetStructMemory() + 0) = Params.InTeleportType;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.InTeleportType = *(ETeleportType*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 ResetAllowedAnimCurveEvaluation(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SkeletalMeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SkeletalMeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
#if UE_GAME
	USkeletalMeshComponent * This = (USkeletalMeshComponent *)Obj;
	This->ResetAllowedAnimCurveEvaluation();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("ResetAllowedAnimCurveEvaluation"));
	if(!Function) { check(false); return 0;}
	Obj->ProcessEvent(Function, NULL);
#endif
	return 0;
}

int32 ResetAllBodiesSimulatePhysics(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SkeletalMeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SkeletalMeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
#if UE_GAME
	USkeletalMeshComponent * This = (USkeletalMeshComponent *)Obj;
	This->ResetAllBodiesSimulatePhysics();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("ResetAllBodiesSimulatePhysics"));
	if(!Function) { check(false); return 0;}
	Obj->ProcessEvent(Function, NULL);
#endif
	return 0;
}

int32 PlayAnimation(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SkeletalMeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SkeletalMeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		UAnimationAsset* NewAnimToPlay = nullptr;
		bool bLooping;
	} Params;
	Params.NewAnimToPlay = (UAnimationAsset*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"AnimationAsset");;
	Params.bLooping = !!(lua_toboolean(InScriptContext, 3));
#if UE_GAME
	USkeletalMeshComponent * This = (USkeletalMeshComponent *)Obj;
	This->PlayAnimation(Params.NewAnimToPlay,Params.bLooping);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("PlayAnimation"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(UAnimationAsset**)(params.GetStructMemory() + 0) = Params.NewAnimToPlay;
		*(bool*)(params.GetStructMemory() + 8) = Params.bLooping;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.NewAnimToPlay = *(UAnimationAsset**)(params.GetStructMemory() + 0);
		Params.bLooping = *(bool*)(params.GetStructMemory() + 8);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 Play(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SkeletalMeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SkeletalMeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool bLooping;
	} Params;
	Params.bLooping = !!(lua_toboolean(InScriptContext, 2));
#if UE_GAME
	USkeletalMeshComponent * This = (USkeletalMeshComponent *)Obj;
	This->Play(Params.bLooping);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("Play"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(bool*)(params.GetStructMemory() + 0) = Params.bLooping;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.bLooping = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 OverrideAnimationData(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SkeletalMeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SkeletalMeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		UAnimationAsset* InAnimToPlay = nullptr;
		bool bIsLooping;
		bool bIsPlaying;
		float Position;
		float PlayRate;
	} Params;
	Params.InAnimToPlay = (UAnimationAsset*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"AnimationAsset");;
	Params.bIsLooping = lua_isnoneornil(InScriptContext,3) ? bool(true) : !!(lua_toboolean(InScriptContext, 3));
	Params.bIsPlaying = lua_isnoneornil(InScriptContext,4) ? bool(true) : !!(lua_toboolean(InScriptContext, 4));
	Params.Position = lua_isnoneornil(InScriptContext,5) ? float(0.000000) : (float)(luaL_checknumber(InScriptContext, 5));
	Params.PlayRate = lua_isnoneornil(InScriptContext,6) ? float(1.000000) : (float)(luaL_checknumber(InScriptContext, 6));
#if UE_GAME
	USkeletalMeshComponent * This = (USkeletalMeshComponent *)Obj;
	This->OverrideAnimationData(Params.InAnimToPlay,Params.bIsLooping,Params.bIsPlaying,Params.Position,Params.PlayRate);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("OverrideAnimationData"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(UAnimationAsset**)(params.GetStructMemory() + 0) = Params.InAnimToPlay;
		*(bool*)(params.GetStructMemory() + 8) = Params.bIsLooping;
		*(bool*)(params.GetStructMemory() + 9) = Params.bIsPlaying;
		*(float*)(params.GetStructMemory() + 12) = Params.Position;
		*(float*)(params.GetStructMemory() + 16) = Params.PlayRate;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.InAnimToPlay = *(UAnimationAsset**)(params.GetStructMemory() + 0);
		Params.bIsLooping = *(bool*)(params.GetStructMemory() + 8);
		Params.bIsPlaying = *(bool*)(params.GetStructMemory() + 9);
		Params.Position = *(float*)(params.GetStructMemory() + 12);
		Params.PlayRate = *(float*)(params.GetStructMemory() + 16);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 K2_SetAnimInstanceClass(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SkeletalMeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SkeletalMeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		UClass* NewClass = nullptr;
	} Params;
	Params.NewClass = (UClass*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"Class");;
#if UE_GAME
	USkeletalMeshComponent * This = (USkeletalMeshComponent *)Obj;
	This->K2_SetAnimInstanceClass(Params.NewClass);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("K2_SetAnimInstanceClass"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(UClass**)(params.GetStructMemory() + 0) = Params.NewClass;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.NewClass = *(UClass**)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 K2_GetClosestPointOnPhysicsAsset(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SkeletalMeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SkeletalMeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FVector WorldPosition;
		FVector ClosestWorldPosition;
		FVector Normal;
		FName BoneName;
		float Distance;
		bool ReturnValue;
	} Params;
	Params.WorldPosition = (wLua::FLuaVector::Get(InScriptContext, 2));
#if UE_GAME
	USkeletalMeshComponent * This = (USkeletalMeshComponent *)Obj;
	Params.ReturnValue = This->K2_GetClosestPointOnPhysicsAsset(Params.WorldPosition,Params.ClosestWorldPosition,Params.Normal,Params.BoneName,Params.Distance);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("K2_GetClosestPointOnPhysicsAsset"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FVector*)(params.GetStructMemory() + 0) = Params.WorldPosition;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.WorldPosition = *(FVector*)(params.GetStructMemory() + 0);
		Params.ClosestWorldPosition = *(FVector*)(params.GetStructMemory() + 12);
		Params.Normal = *(FVector*)(params.GetStructMemory() + 24);
		Params.BoneName = *(FName*)(params.GetStructMemory() + 36);
		Params.Distance = *(float*)(params.GetStructMemory() + 48);
		Params.ReturnValue = *(bool*)(params.GetStructMemory() + 52);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushboolean(InScriptContext, Params.ReturnValue);
	wLua::FLuaVector::Return(InScriptContext, Params.ClosestWorldPosition);
	wLua::FLuaVector::Return(InScriptContext, Params.Normal);
	lua_pushstring(InScriptContext, TCHAR_TO_UTF8(*Params.BoneName.ToString()));
	lua_pushnumber(InScriptContext, Params.Distance);
	return 5;
}

int32 IsPlaying(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SkeletalMeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SkeletalMeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool ReturnValue;
	} Params;
#if UE_GAME
	USkeletalMeshComponent * This = (USkeletalMeshComponent *)Obj;
	Params.ReturnValue = This->IsPlaying();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("IsPlaying"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushboolean(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 IsClothingSimulationSuspended(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SkeletalMeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SkeletalMeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool ReturnValue;
	} Params;
#if UE_GAME
	USkeletalMeshComponent * This = (USkeletalMeshComponent *)Obj;
	Params.ReturnValue = This->IsClothingSimulationSuspended();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("IsClothingSimulationSuspended"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushboolean(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 IsBodyGravityEnabled(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SkeletalMeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SkeletalMeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FName BoneName;
		bool ReturnValue;
	} Params;
	Params.BoneName = FName(UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 2)));
#if UE_GAME
	USkeletalMeshComponent * This = (USkeletalMeshComponent *)Obj;
	Params.ReturnValue = This->IsBodyGravityEnabled(Params.BoneName);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("IsBodyGravityEnabled"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FName*)(params.GetStructMemory() + 0) = Params.BoneName;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.BoneName = *(FName*)(params.GetStructMemory() + 0);
		Params.ReturnValue = *(bool*)(params.GetStructMemory() + 12);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushboolean(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 HasValidAnimationInstance(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SkeletalMeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SkeletalMeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool ReturnValue;
	} Params;
#if UE_GAME
	USkeletalMeshComponent * This = (USkeletalMeshComponent *)Obj;
	Params.ReturnValue = This->HasValidAnimationInstance();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("HasValidAnimationInstance"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushboolean(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetTeleportRotationThreshold(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SkeletalMeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SkeletalMeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float ReturnValue;
	} Params;
#if UE_GAME
	USkeletalMeshComponent * This = (USkeletalMeshComponent *)Obj;
	Params.ReturnValue = This->GetTeleportRotationThreshold();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetTeleportRotationThreshold"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(float*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushnumber(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetTeleportDistanceThreshold(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SkeletalMeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SkeletalMeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float ReturnValue;
	} Params;
#if UE_GAME
	USkeletalMeshComponent * This = (USkeletalMeshComponent *)Obj;
	Params.ReturnValue = This->GetTeleportDistanceThreshold();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetTeleportDistanceThreshold"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(float*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushnumber(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetSubInstanceByName(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SkeletalMeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SkeletalMeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FName InName;
		UAnimInstance* ReturnValue = nullptr;
	} Params;
	Params.InName = FName(UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 2)));
#if UE_GAME
	USkeletalMeshComponent * This = (USkeletalMeshComponent *)Obj;
	Params.ReturnValue = This->GetSubInstanceByName(Params.InName);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetSubInstanceByName"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FName*)(params.GetStructMemory() + 0) = Params.InName;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.InName = *(FName*)(params.GetStructMemory() + 0);
		Params.ReturnValue = *(UAnimInstance**)(params.GetStructMemory() + 16);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetSkeletalCenterOfMass(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SkeletalMeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SkeletalMeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FVector ReturnValue;
	} Params;
#if UE_GAME
	USkeletalMeshComponent * This = (USkeletalMeshComponent *)Obj;
	Params.ReturnValue = This->GetSkeletalCenterOfMass();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetSkeletalCenterOfMass"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(FVector*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaVector::Return(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetPostProcessInstance(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SkeletalMeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SkeletalMeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		UAnimInstance* ReturnValue = nullptr;
	} Params;
#if UE_GAME
	USkeletalMeshComponent * This = (USkeletalMeshComponent *)Obj;
	Params.ReturnValue = This->GetPostProcessInstance();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetPostProcessInstance"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(UAnimInstance**)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetPosition(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SkeletalMeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SkeletalMeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float ReturnValue;
	} Params;
#if UE_GAME
	USkeletalMeshComponent * This = (USkeletalMeshComponent *)Obj;
	Params.ReturnValue = This->GetPosition();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetPosition"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(float*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushnumber(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetPlayRate(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SkeletalMeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SkeletalMeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float ReturnValue;
	} Params;
#if UE_GAME
	USkeletalMeshComponent * This = (USkeletalMeshComponent *)Obj;
	Params.ReturnValue = This->GetPlayRate();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetPlayRate"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(float*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushnumber(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetMorphTarget(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SkeletalMeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SkeletalMeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FName MorphTargetName;
		float ReturnValue;
	} Params;
	Params.MorphTargetName = FName(UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 2)));
#if UE_GAME
	USkeletalMeshComponent * This = (USkeletalMeshComponent *)Obj;
	Params.ReturnValue = This->GetMorphTarget(Params.MorphTargetName);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetMorphTarget"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FName*)(params.GetStructMemory() + 0) = Params.MorphTargetName;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.MorphTargetName = *(FName*)(params.GetStructMemory() + 0);
		Params.ReturnValue = *(float*)(params.GetStructMemory() + 12);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushnumber(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetDisablePostProcessBlueprint(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SkeletalMeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SkeletalMeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool ReturnValue;
	} Params;
#if UE_GAME
	USkeletalMeshComponent * This = (USkeletalMeshComponent *)Obj;
	Params.ReturnValue = This->GetDisablePostProcessBlueprint();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetDisablePostProcessBlueprint"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushboolean(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetDisableAnimCurves(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SkeletalMeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SkeletalMeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool ReturnValue;
	} Params;
#if UE_GAME
	USkeletalMeshComponent * This = (USkeletalMeshComponent *)Obj;
	Params.ReturnValue = This->GetDisableAnimCurves();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetDisableAnimCurves"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushboolean(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetCurrentJointAngles(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SkeletalMeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SkeletalMeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FName InBoneName;
		float Swing1Angle;
		float TwistAngle;
		float Swing2Angle;
	} Params;
	Params.InBoneName = FName(UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 2)));
#if UE_GAME
	USkeletalMeshComponent * This = (USkeletalMeshComponent *)Obj;
	This->GetCurrentJointAngles(Params.InBoneName,Params.Swing1Angle,Params.TwistAngle,Params.Swing2Angle);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetCurrentJointAngles"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FName*)(params.GetStructMemory() + 0) = Params.InBoneName;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.InBoneName = *(FName*)(params.GetStructMemory() + 0);
		Params.Swing1Angle = *(float*)(params.GetStructMemory() + 12);
		Params.TwistAngle = *(float*)(params.GetStructMemory() + 16);
		Params.Swing2Angle = *(float*)(params.GetStructMemory() + 20);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushnumber(InScriptContext, Params.Swing1Angle);
	lua_pushnumber(InScriptContext, Params.TwistAngle);
	lua_pushnumber(InScriptContext, Params.Swing2Angle);
	return 3;
}

int32 GetClothMaxDistanceScale(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SkeletalMeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SkeletalMeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float ReturnValue;
	} Params;
#if UE_GAME
	USkeletalMeshComponent * This = (USkeletalMeshComponent *)Obj;
	Params.ReturnValue = This->GetClothMaxDistanceScale();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetClothMaxDistanceScale"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(float*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushnumber(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetClothingSimulationInteractor(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SkeletalMeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SkeletalMeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		UClothingSimulationInteractor* ReturnValue = nullptr;
	} Params;
#if UE_GAME
	USkeletalMeshComponent * This = (USkeletalMeshComponent *)Obj;
	Params.ReturnValue = This->GetClothingSimulationInteractor();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetClothingSimulationInteractor"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(UClothingSimulationInteractor**)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetBoneMass(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SkeletalMeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SkeletalMeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FName BoneName;
		bool bScaleMass;
		float ReturnValue;
	} Params;
	Params.BoneName = lua_isnoneornil(InScriptContext,2) ? FName(TEXT("")) : FName(UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 2)));
	Params.bScaleMass = lua_isnoneornil(InScriptContext,3) ? bool(true) : !!(lua_toboolean(InScriptContext, 3));
#if UE_GAME
	USkeletalMeshComponent * This = (USkeletalMeshComponent *)Obj;
	Params.ReturnValue = This->GetBoneMass(Params.BoneName,Params.bScaleMass);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetBoneMass"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FName*)(params.GetStructMemory() + 0) = Params.BoneName;
		*(bool*)(params.GetStructMemory() + 12) = Params.bScaleMass;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.BoneName = *(FName*)(params.GetStructMemory() + 0);
		Params.bScaleMass = *(bool*)(params.GetStructMemory() + 12);
		Params.ReturnValue = *(float*)(params.GetStructMemory() + 16);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushnumber(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetAnimInstance(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SkeletalMeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SkeletalMeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		UAnimInstance* ReturnValue = nullptr;
	} Params;
#if UE_GAME
	USkeletalMeshComponent * This = (USkeletalMeshComponent *)Obj;
	Params.ReturnValue = This->GetAnimInstance();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetAnimInstance"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(UAnimInstance**)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetAnimationMode(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SkeletalMeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SkeletalMeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		TEnumAsByte<EAnimationMode::Type> ReturnValue;
	} Params;
#if UE_GAME
	USkeletalMeshComponent * This = (USkeletalMeshComponent *)Obj;
	Params.ReturnValue = This->GetAnimationMode();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetAnimationMode"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(TEnumAsByte<EAnimationMode::Type>*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushinteger(InScriptContext, (int)Params.ReturnValue);
	return 1;
}

int32 GetAllowedAnimCurveEvaluate(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SkeletalMeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SkeletalMeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool ReturnValue;
	} Params;
#if UE_GAME
	USkeletalMeshComponent * This = (USkeletalMeshComponent *)Obj;
	Params.ReturnValue = This->GetAllowedAnimCurveEvaluate();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetAllowedAnimCurveEvaluate"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushboolean(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 ForceClothNextUpdateTeleportAndReset(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SkeletalMeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SkeletalMeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
#if UE_GAME
	USkeletalMeshComponent * This = (USkeletalMeshComponent *)Obj;
	This->ForceClothNextUpdateTeleportAndReset();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("ForceClothNextUpdateTeleportAndReset"));
	if(!Function) { check(false); return 0;}
	Obj->ProcessEvent(Function, NULL);
#endif
	return 0;
}

int32 ForceClothNextUpdateTeleport(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SkeletalMeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SkeletalMeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
#if UE_GAME
	USkeletalMeshComponent * This = (USkeletalMeshComponent *)Obj;
	This->ForceClothNextUpdateTeleport();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("ForceClothNextUpdateTeleport"));
	if(!Function) { check(false); return 0;}
	Obj->ProcessEvent(Function, NULL);
#endif
	return 0;
}

int32 FindConstraintBoneName(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SkeletalMeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SkeletalMeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		int32 ConstraintIndex;
		FName ReturnValue;
	} Params;
	Params.ConstraintIndex = (luaL_checkint(InScriptContext, 2));
#if UE_GAME
	USkeletalMeshComponent * This = (USkeletalMeshComponent *)Obj;
	Params.ReturnValue = This->FindConstraintBoneName(Params.ConstraintIndex);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("FindConstraintBoneName"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(int32*)(params.GetStructMemory() + 0) = Params.ConstraintIndex;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ConstraintIndex = *(int32*)(params.GetStructMemory() + 0);
		Params.ReturnValue = *(FName*)(params.GetStructMemory() + 4);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushstring(InScriptContext, TCHAR_TO_UTF8(*Params.ReturnValue.ToString()));
	return 1;
}

int32 ClearMorphTargets(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SkeletalMeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SkeletalMeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
#if UE_GAME
	USkeletalMeshComponent * This = (USkeletalMeshComponent *)Obj;
	This->ClearMorphTargets();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("ClearMorphTargets"));
	if(!Function) { check(false); return 0;}
	Obj->ProcessEvent(Function, NULL);
#endif
	return 0;
}

int32 BreakConstraint(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SkeletalMeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SkeletalMeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FVector Impulse;
		FVector HitLocation;
		FName InBoneName;
	} Params;
	Params.Impulse = (wLua::FLuaVector::Get(InScriptContext, 2));
	Params.HitLocation = (wLua::FLuaVector::Get(InScriptContext, 3));
	Params.InBoneName = FName(UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 4)));
#if UE_GAME
	USkeletalMeshComponent * This = (USkeletalMeshComponent *)Obj;
	This->BreakConstraint(Params.Impulse,Params.HitLocation,Params.InBoneName);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("BreakConstraint"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FVector*)(params.GetStructMemory() + 0) = Params.Impulse;
		*(FVector*)(params.GetStructMemory() + 12) = Params.HitLocation;
		*(FName*)(params.GetStructMemory() + 24) = Params.InBoneName;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.Impulse = *(FVector*)(params.GetStructMemory() + 0);
		Params.HitLocation = *(FVector*)(params.GetStructMemory() + 12);
		Params.InBoneName = *(FName*)(params.GetStructMemory() + 24);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 BindClothToMasterPoseComponent(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SkeletalMeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SkeletalMeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
#if UE_GAME
	USkeletalMeshComponent * This = (USkeletalMeshComponent *)Obj;
	This->BindClothToMasterPoseComponent();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("BindClothToMasterPoseComponent"));
	if(!Function) { check(false); return 0;}
	Obj->ProcessEvent(Function, NULL);
#endif
	return 0;
}

int32 AllowAnimCurveEvaluation(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SkeletalMeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SkeletalMeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FName NameOfCurve;
		bool bAllow;
	} Params;
	Params.NameOfCurve = FName(UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 2)));
	Params.bAllow = !!(lua_toboolean(InScriptContext, 3));
#if UE_GAME
	USkeletalMeshComponent * This = (USkeletalMeshComponent *)Obj;
	This->AllowAnimCurveEvaluation(Params.NameOfCurve,Params.bAllow);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("AllowAnimCurveEvaluation"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FName*)(params.GetStructMemory() + 0) = Params.NameOfCurve;
		*(bool*)(params.GetStructMemory() + 12) = Params.bAllow;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.NameOfCurve = *(FName*)(params.GetStructMemory() + 0);
		Params.bAllow = *(bool*)(params.GetStructMemory() + 12);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 AddImpulseToAllBodiesBelow(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SkeletalMeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SkeletalMeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FVector Impulse;
		FName BoneName;
		bool bVelChange;
		bool bIncludeSelf;
	} Params;
	Params.Impulse = (wLua::FLuaVector::Get(InScriptContext, 2));
	Params.BoneName = lua_isnoneornil(InScriptContext,3) ? FName(TEXT("")) : FName(UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 3)));
	Params.bVelChange = lua_isnoneornil(InScriptContext,4) ? bool(false) : !!(lua_toboolean(InScriptContext, 4));
	Params.bIncludeSelf = lua_isnoneornil(InScriptContext,5) ? bool(true) : !!(lua_toboolean(InScriptContext, 5));
#if UE_GAME
	USkeletalMeshComponent * This = (USkeletalMeshComponent *)Obj;
	This->AddImpulseToAllBodiesBelow(Params.Impulse,Params.BoneName,Params.bVelChange,Params.bIncludeSelf);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("AddImpulseToAllBodiesBelow"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FVector*)(params.GetStructMemory() + 0) = Params.Impulse;
		*(FName*)(params.GetStructMemory() + 12) = Params.BoneName;
		*(bool*)(params.GetStructMemory() + 24) = Params.bVelChange;
		*(bool*)(params.GetStructMemory() + 25) = Params.bIncludeSelf;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.Impulse = *(FVector*)(params.GetStructMemory() + 0);
		Params.BoneName = *(FName*)(params.GetStructMemory() + 12);
		Params.bVelChange = *(bool*)(params.GetStructMemory() + 24);
		Params.bIncludeSelf = *(bool*)(params.GetStructMemory() + 25);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 AddForceToAllBodiesBelow(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SkeletalMeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SkeletalMeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FVector Force;
		FName BoneName;
		bool bAccelChange;
		bool bIncludeSelf;
	} Params;
	Params.Force = (wLua::FLuaVector::Get(InScriptContext, 2));
	Params.BoneName = lua_isnoneornil(InScriptContext,3) ? FName(TEXT("")) : FName(UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 3)));
	Params.bAccelChange = lua_isnoneornil(InScriptContext,4) ? bool(false) : !!(lua_toboolean(InScriptContext, 4));
	Params.bIncludeSelf = lua_isnoneornil(InScriptContext,5) ? bool(true) : !!(lua_toboolean(InScriptContext, 5));
#if UE_GAME
	USkeletalMeshComponent * This = (USkeletalMeshComponent *)Obj;
	This->AddForceToAllBodiesBelow(Params.Force,Params.BoneName,Params.bAccelChange,Params.bIncludeSelf);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("AddForceToAllBodiesBelow"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FVector*)(params.GetStructMemory() + 0) = Params.Force;
		*(FName*)(params.GetStructMemory() + 12) = Params.BoneName;
		*(bool*)(params.GetStructMemory() + 24) = Params.bAccelChange;
		*(bool*)(params.GetStructMemory() + 25) = Params.bIncludeSelf;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.Force = *(FVector*)(params.GetStructMemory() + 0);
		Params.BoneName = *(FName*)(params.GetStructMemory() + 12);
		Params.bAccelChange = *(bool*)(params.GetStructMemory() + 24);
		Params.bIncludeSelf = *(bool*)(params.GetStructMemory() + 25);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 AccumulateAllBodiesBelowPhysicsBlendWeight(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SkeletalMeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SkeletalMeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FName InBoneName;
		float AddPhysicsBlendWeight;
		bool bSkipCustomPhysicsType;
	} Params;
	Params.InBoneName = FName(UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 2)));
	Params.AddPhysicsBlendWeight = (float)(luaL_checknumber(InScriptContext, 3));
	Params.bSkipCustomPhysicsType = lua_isnoneornil(InScriptContext,4) ? bool(false) : !!(lua_toboolean(InScriptContext, 4));
#if UE_GAME
	USkeletalMeshComponent * This = (USkeletalMeshComponent *)Obj;
	This->AccumulateAllBodiesBelowPhysicsBlendWeight(Params.InBoneName,Params.AddPhysicsBlendWeight,Params.bSkipCustomPhysicsType);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("AccumulateAllBodiesBelowPhysicsBlendWeight"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FName*)(params.GetStructMemory() + 0) = Params.InBoneName;
		*(float*)(params.GetStructMemory() + 12) = Params.AddPhysicsBlendWeight;
		*(bool*)(params.GetStructMemory() + 16) = Params.bSkipCustomPhysicsType;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.InBoneName = *(FName*)(params.GetStructMemory() + 0);
		Params.AddPhysicsBlendWeight = *(float*)(params.GetStructMemory() + 12);
		Params.bSkipCustomPhysicsType = *(bool*)(params.GetStructMemory() + 16);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 Get_AnimBlueprintGeneratedClass(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SkeletalMeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SkeletalMeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USkeletalMeshComponent::StaticClass(), TEXT("AnimBlueprintGeneratedClass"));
	if(!Property) { check(false); return 0;}
	UClass* PropertyValue;
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaUtils::ReturnUObject(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_AnimClass(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SkeletalMeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SkeletalMeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USkeletalMeshComponent::StaticClass(), TEXT("AnimClass"));
	if(!Property) { check(false); return 0;}
	TSubclassOf<UAnimInstance>  PropertyValue = TSubclassOf<UAnimInstance> ();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaUtils::ReturnUObject(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_GlobalAnimRateScale(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SkeletalMeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SkeletalMeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USkeletalMeshComponent::StaticClass(), TEXT("GlobalAnimRateScale"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_GlobalAnimRateScale(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SkeletalMeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SkeletalMeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USkeletalMeshComponent::StaticClass(), TEXT("GlobalAnimRateScale"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_UseAsyncScene(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SkeletalMeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SkeletalMeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USkeletalMeshComponent::StaticClass(), TEXT("UseAsyncScene"));
	if(!Property) { check(false); return 0;}
	EDynamicActorScene PropertyValue = EDynamicActorScene();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushinteger(InScriptContext, (int)PropertyValue);
	return 1;
}

int32 Get_KinematicBonesUpdateType(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SkeletalMeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SkeletalMeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USkeletalMeshComponent::StaticClass(), TEXT("KinematicBonesUpdateType"));
	if(!Property) { check(false); return 0;}
	TEnumAsByte<EKinematicBonesUpdateToPhysics::Type> PropertyValue = TEnumAsByte<EKinematicBonesUpdateToPhysics::Type>();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushinteger(InScriptContext, (int)PropertyValue);
	return 1;
}

int32 Set_KinematicBonesUpdateType(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SkeletalMeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SkeletalMeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USkeletalMeshComponent::StaticClass(), TEXT("KinematicBonesUpdateType"));
	if(!Property) { check(false); return 0;}
	TEnumAsByte<EKinematicBonesUpdateToPhysics::Type> PropertyValue = (TEnumAsByte<EKinematicBonesUpdateToPhysics::Type>)(luaL_checkint(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_PhysicsTransformUpdateMode(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SkeletalMeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SkeletalMeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USkeletalMeshComponent::StaticClass(), TEXT("PhysicsTransformUpdateMode"));
	if(!Property) { check(false); return 0;}
	TEnumAsByte<EPhysicsTransformUpdateMode::Type> PropertyValue = TEnumAsByte<EPhysicsTransformUpdateMode::Type>();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushinteger(InScriptContext, (int)PropertyValue);
	return 1;
}

int32 Set_PhysicsTransformUpdateMode(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SkeletalMeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SkeletalMeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USkeletalMeshComponent::StaticClass(), TEXT("PhysicsTransformUpdateMode"));
	if(!Property) { check(false); return 0;}
	TEnumAsByte<EPhysicsTransformUpdateMode::Type> PropertyValue = (TEnumAsByte<EPhysicsTransformUpdateMode::Type>)(luaL_checkint(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_AnimationMode(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SkeletalMeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SkeletalMeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USkeletalMeshComponent::StaticClass(), TEXT("AnimationMode"));
	if(!Property) { check(false); return 0;}
	TEnumAsByte<EAnimationMode::Type> PropertyValue = TEnumAsByte<EAnimationMode::Type>();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushinteger(InScriptContext, (int)PropertyValue);
	return 1;
}

int32 Get_bDisablePostProcessBlueprint(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SkeletalMeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SkeletalMeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USkeletalMeshComponent::StaticClass(), TEXT("bDisablePostProcessBlueprint"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bDisablePostProcessBlueprint(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SkeletalMeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SkeletalMeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USkeletalMeshComponent::StaticClass(), TEXT("bDisablePostProcessBlueprint"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bUpdateOverlapsOnAnimationFinalize(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SkeletalMeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SkeletalMeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USkeletalMeshComponent::StaticClass(), TEXT("bUpdateOverlapsOnAnimationFinalize"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bUpdateOverlapsOnAnimationFinalize(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SkeletalMeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SkeletalMeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USkeletalMeshComponent::StaticClass(), TEXT("bUpdateOverlapsOnAnimationFinalize"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bEnablePhysicsOnDedicatedServer(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SkeletalMeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SkeletalMeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USkeletalMeshComponent::StaticClass(), TEXT("bEnablePhysicsOnDedicatedServer"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bEnablePhysicsOnDedicatedServer(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SkeletalMeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SkeletalMeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USkeletalMeshComponent::StaticClass(), TEXT("bEnablePhysicsOnDedicatedServer"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bUpdateJointsFromAnimation(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SkeletalMeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SkeletalMeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USkeletalMeshComponent::StaticClass(), TEXT("bUpdateJointsFromAnimation"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bUpdateJointsFromAnimation(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SkeletalMeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SkeletalMeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USkeletalMeshComponent::StaticClass(), TEXT("bUpdateJointsFromAnimation"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bDisableClothSimulation(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SkeletalMeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SkeletalMeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USkeletalMeshComponent::StaticClass(), TEXT("bDisableClothSimulation"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bDisableClothSimulation(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SkeletalMeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SkeletalMeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USkeletalMeshComponent::StaticClass(), TEXT("bDisableClothSimulation"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bAllowAnimCurveEvaluation(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SkeletalMeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SkeletalMeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USkeletalMeshComponent::StaticClass(), TEXT("bAllowAnimCurveEvaluation"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bAllowAnimCurveEvaluation(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SkeletalMeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SkeletalMeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USkeletalMeshComponent::StaticClass(), TEXT("bAllowAnimCurveEvaluation"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bCollideWithEnvironment(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SkeletalMeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SkeletalMeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USkeletalMeshComponent::StaticClass(), TEXT("bCollideWithEnvironment"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bCollideWithEnvironment(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SkeletalMeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SkeletalMeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USkeletalMeshComponent::StaticClass(), TEXT("bCollideWithEnvironment"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bCollideWithAttachedChildren(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SkeletalMeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SkeletalMeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USkeletalMeshComponent::StaticClass(), TEXT("bCollideWithAttachedChildren"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bCollideWithAttachedChildren(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SkeletalMeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SkeletalMeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USkeletalMeshComponent::StaticClass(), TEXT("bCollideWithAttachedChildren"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bLocalSpaceSimulation(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SkeletalMeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SkeletalMeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USkeletalMeshComponent::StaticClass(), TEXT("bLocalSpaceSimulation"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bLocalSpaceSimulation(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SkeletalMeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SkeletalMeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USkeletalMeshComponent::StaticClass(), TEXT("bLocalSpaceSimulation"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bResetAfterTeleport(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SkeletalMeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SkeletalMeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USkeletalMeshComponent::StaticClass(), TEXT("bResetAfterTeleport"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bResetAfterTeleport(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SkeletalMeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SkeletalMeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USkeletalMeshComponent::StaticClass(), TEXT("bResetAfterTeleport"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bNoSkeletonUpdate(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SkeletalMeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SkeletalMeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USkeletalMeshComponent::StaticClass(), TEXT("bNoSkeletonUpdate"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bNoSkeletonUpdate(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SkeletalMeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SkeletalMeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USkeletalMeshComponent::StaticClass(), TEXT("bNoSkeletonUpdate"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bPauseAnims(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SkeletalMeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SkeletalMeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USkeletalMeshComponent::StaticClass(), TEXT("bPauseAnims"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bPauseAnims(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SkeletalMeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SkeletalMeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USkeletalMeshComponent::StaticClass(), TEXT("bPauseAnims"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bUseRefPoseOnInitAnim(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SkeletalMeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SkeletalMeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USkeletalMeshComponent::StaticClass(), TEXT("bUseRefPoseOnInitAnim"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bUseRefPoseOnInitAnim(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SkeletalMeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SkeletalMeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USkeletalMeshComponent::StaticClass(), TEXT("bUseRefPoseOnInitAnim"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bEnablePerPolyCollision(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SkeletalMeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SkeletalMeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USkeletalMeshComponent::StaticClass(), TEXT("bEnablePerPolyCollision"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_bIncludeComponentLocationIntoBounds(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SkeletalMeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SkeletalMeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USkeletalMeshComponent::StaticClass(), TEXT("bIncludeComponentLocationIntoBounds"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bIncludeComponentLocationIntoBounds(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SkeletalMeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SkeletalMeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USkeletalMeshComponent::StaticClass(), TEXT("bIncludeComponentLocationIntoBounds"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bIncludeAttachParentCompLocationIntoFixBounds(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SkeletalMeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SkeletalMeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USkeletalMeshComponent::StaticClass(), TEXT("bIncludeAttachParentCompLocationIntoFixBounds"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bIncludeAttachParentCompLocationIntoFixBounds(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SkeletalMeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SkeletalMeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USkeletalMeshComponent::StaticClass(), TEXT("bIncludeAttachParentCompLocationIntoFixBounds"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bUseBendingElements(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SkeletalMeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SkeletalMeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USkeletalMeshComponent::StaticClass(), TEXT("bUseBendingElements"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bUseBendingElements(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SkeletalMeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SkeletalMeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USkeletalMeshComponent::StaticClass(), TEXT("bUseBendingElements"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bUseTetrahedralConstraints(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SkeletalMeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SkeletalMeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USkeletalMeshComponent::StaticClass(), TEXT("bUseTetrahedralConstraints"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bUseTetrahedralConstraints(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SkeletalMeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SkeletalMeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USkeletalMeshComponent::StaticClass(), TEXT("bUseTetrahedralConstraints"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bUseThinShellVolumeConstraints(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SkeletalMeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SkeletalMeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USkeletalMeshComponent::StaticClass(), TEXT("bUseThinShellVolumeConstraints"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bUseThinShellVolumeConstraints(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SkeletalMeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SkeletalMeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USkeletalMeshComponent::StaticClass(), TEXT("bUseThinShellVolumeConstraints"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bUseSelfCollisions(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SkeletalMeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SkeletalMeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USkeletalMeshComponent::StaticClass(), TEXT("bUseSelfCollisions"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bUseSelfCollisions(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SkeletalMeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SkeletalMeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USkeletalMeshComponent::StaticClass(), TEXT("bUseSelfCollisions"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bUseContinuousCollisionDetection(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SkeletalMeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SkeletalMeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USkeletalMeshComponent::StaticClass(), TEXT("bUseContinuousCollisionDetection"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bUseContinuousCollisionDetection(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SkeletalMeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SkeletalMeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USkeletalMeshComponent::StaticClass(), TEXT("bUseContinuousCollisionDetection"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bUpdateAnimationInEditor(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SkeletalMeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SkeletalMeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USkeletalMeshComponent::StaticClass(), TEXT("bUpdateAnimationInEditor"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bUpdateAnimationInEditor(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SkeletalMeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SkeletalMeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USkeletalMeshComponent::StaticClass(), TEXT("bUpdateAnimationInEditor"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_ClothBlendWeight(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SkeletalMeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SkeletalMeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USkeletalMeshComponent::StaticClass(), TEXT("ClothBlendWeight"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_ClothBlendWeight(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SkeletalMeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SkeletalMeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USkeletalMeshComponent::StaticClass(), TEXT("ClothBlendWeight"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_EdgeStiffness(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SkeletalMeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SkeletalMeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USkeletalMeshComponent::StaticClass(), TEXT("EdgeStiffness"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_EdgeStiffness(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SkeletalMeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SkeletalMeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USkeletalMeshComponent::StaticClass(), TEXT("EdgeStiffness"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_BendingStiffness(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SkeletalMeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SkeletalMeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USkeletalMeshComponent::StaticClass(), TEXT("BendingStiffness"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_BendingStiffness(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SkeletalMeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SkeletalMeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USkeletalMeshComponent::StaticClass(), TEXT("BendingStiffness"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_AreaStiffness(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SkeletalMeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SkeletalMeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USkeletalMeshComponent::StaticClass(), TEXT("AreaStiffness"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_AreaStiffness(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SkeletalMeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SkeletalMeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USkeletalMeshComponent::StaticClass(), TEXT("AreaStiffness"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_VolumeStiffness(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SkeletalMeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SkeletalMeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USkeletalMeshComponent::StaticClass(), TEXT("VolumeStiffness"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_VolumeStiffness(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SkeletalMeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SkeletalMeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USkeletalMeshComponent::StaticClass(), TEXT("VolumeStiffness"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_StrainLimitingStiffness(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SkeletalMeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SkeletalMeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USkeletalMeshComponent::StaticClass(), TEXT("StrainLimitingStiffness"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_StrainLimitingStiffness(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SkeletalMeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SkeletalMeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USkeletalMeshComponent::StaticClass(), TEXT("StrainLimitingStiffness"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_ShapeTargetStiffness(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SkeletalMeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SkeletalMeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USkeletalMeshComponent::StaticClass(), TEXT("ShapeTargetStiffness"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_ShapeTargetStiffness(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SkeletalMeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SkeletalMeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USkeletalMeshComponent::StaticClass(), TEXT("ShapeTargetStiffness"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Call_OnConstraintBroken(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SkeletalMeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SkeletalMeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		int32 ConstraintIndex;
	} Params;
	Params.ConstraintIndex = (luaL_checkint(InScriptContext, 2));
	USkeletalMeshComponent * This = (USkeletalMeshComponent *)Obj;
	This->OnConstraintBroken.Broadcast(Params.ConstraintIndex);
	return 0;
}

int32 Get_TeleportDistanceThreshold(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SkeletalMeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SkeletalMeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USkeletalMeshComponent::StaticClass(), TEXT("TeleportDistanceThreshold"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_TeleportDistanceThreshold(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SkeletalMeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SkeletalMeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USkeletalMeshComponent::StaticClass(), TEXT("TeleportDistanceThreshold"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_TeleportRotationThreshold(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SkeletalMeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SkeletalMeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USkeletalMeshComponent::StaticClass(), TEXT("TeleportRotationThreshold"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_TeleportRotationThreshold(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SkeletalMeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SkeletalMeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USkeletalMeshComponent::StaticClass(), TEXT("TeleportRotationThreshold"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Call_OnAnimInitialized(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SkeletalMeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SkeletalMeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	USkeletalMeshComponent * This = (USkeletalMeshComponent *)Obj;
	This->OnAnimInitialized.Broadcast();
	return 0;
}

int32 New(lua_State* InScriptContext)
{
	UObject* Outer = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Object");
	FName Name = FName(luaL_checkstring(InScriptContext, 2));
	UObject* Obj = NewObject<USkeletalMeshComponent>(Outer, Name);
	wLua::FLuaUtils::ReturnUObject(InScriptContext,Obj);
	return 1;
}

int32 Destroy(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SkeletalMeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SkeletalMeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
		UActorComponent * com = Cast<UActorComponent>(Obj);
		if(lua_isnoneornil(InScriptContext,2))
			com->DestroyComponent();
		else
			com->DestroyComponent(!!lua_toboolean(InScriptContext,2));
		userdata->flag |= wLua::LuaObjectFlag::DESTROYED;
		wLua::FLuaUtils::RemoveObjectReference(Obj, userdata->stamp, InScriptContext);
#ifdef AZURE_BUILD_WLUACHECK
		UE_LOG(LogAzure, Warning, TEXT("Destroy SkeletalMeshComponent: %x userdata:%x   stamp:%x"),Obj,userdata,userdata->stamp);
#endif
	return 0;
}

int32 Class(lua_State* InScriptContext)
{
	UClass* Class = USkeletalMeshComponent::StaticClass();
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Class);
	return 1;
}

const luaL_Reg Lib_Funcs[] =
{
	{ "New", New },
	{ "Destroy", Destroy },
	{ "Class", Class },
	{ "UpdateMeshObjectLOD", UpdateMeshObjectLOD },
	{ "UnbindClothFromMasterPoseComponent", UnbindClothFromMasterPoseComponent },
	{ "ToggleDisablePostProcessBlueprint", ToggleDisablePostProcessBlueprint },
	{ "TermBodiesBelow", TermBodiesBelow },
	{ "SuspendClothingSimulation", SuspendClothingSimulation },
	{ "Stop", Stop },
	{ "SetUpdateAnimationInEditor", SetUpdateAnimationInEditor },
	{ "SetTeleportRotationThreshold", SetTeleportRotationThreshold },
	{ "SetTeleportDistanceThreshold", SetTeleportDistanceThreshold },
	{ "SetPosition", SetPosition },
	{ "SetPlayRate", SetPlayRate },
	{ "SetPhysicsBlendWeight", SetPhysicsBlendWeight },
	{ "SetNotifyRigidBodyCollisionBelow", SetNotifyRigidBodyCollisionBelow },
	{ "SetMorphTarget", SetMorphTarget },
	{ "SetEnablePhysicsBlending", SetEnablePhysicsBlending },
	{ "SetEnableGravityOnAllBodiesBelow", SetEnableGravityOnAllBodiesBelow },
	{ "SetEnableBodyGravity", SetEnableBodyGravity },
	{ "SetDisablePostProcessBlueprint", SetDisablePostProcessBlueprint },
	{ "SetDisableAnimCurves", SetDisableAnimCurves },
	{ "SetConstraintProfileForAll", SetConstraintProfileForAll },
	{ "SetConstraintProfile", SetConstraintProfile },
	{ "SetClothMaxDistanceScale", SetClothMaxDistanceScale },
	{ "SetBodyNotifyRigidBodyCollision", SetBodyNotifyRigidBodyCollision },
	{ "SetAnimationMode", SetAnimationMode },
	{ "SetAnimation", SetAnimation },
	{ "SetAngularLimits", SetAngularLimits },
	{ "SetAllowedAnimCurvesEvaluation", SetAllowedAnimCurvesEvaluation },
	{ "SetAllowAnimCurveEvaluation", SetAllowAnimCurveEvaluation },
	{ "SetAllMotorsAngularVelocityDrive", SetAllMotorsAngularVelocityDrive },
	{ "SetAllMotorsAngularPositionDrive", SetAllMotorsAngularPositionDrive },
	{ "SetAllMotorsAngularDriveParams", SetAllMotorsAngularDriveParams },
	{ "SetAllBodiesSimulatePhysics", SetAllBodiesSimulatePhysics },
	{ "SetAllBodiesPhysicsBlendWeight", SetAllBodiesPhysicsBlendWeight },
	{ "SetAllBodiesBelowSimulatePhysics", SetAllBodiesBelowSimulatePhysics },
	{ "SetAllBodiesBelowPhysicsBlendWeight", SetAllBodiesBelowPhysicsBlendWeight },
	{ "ResumeClothingSimulation", ResumeClothingSimulation },
	{ "ResetClothTeleportMode", ResetClothTeleportMode },
	{ "ResetAnimInstanceDynamics", ResetAnimInstanceDynamics },
	{ "ResetAllowedAnimCurveEvaluation", ResetAllowedAnimCurveEvaluation },
	{ "ResetAllBodiesSimulatePhysics", ResetAllBodiesSimulatePhysics },
	{ "PlayAnimation", PlayAnimation },
	{ "Play", Play },
	{ "OverrideAnimationData", OverrideAnimationData },
	{ "SetAnimInstanceClass", K2_SetAnimInstanceClass },
	{ "GetClosestPointOnPhysicsAsset", K2_GetClosestPointOnPhysicsAsset },
	{ "IsPlaying", IsPlaying },
	{ "IsClothingSimulationSuspended", IsClothingSimulationSuspended },
	{ "IsBodyGravityEnabled", IsBodyGravityEnabled },
	{ "HasValidAnimationInstance", HasValidAnimationInstance },
	{ "GetTeleportRotationThreshold", GetTeleportRotationThreshold },
	{ "GetTeleportDistanceThreshold", GetTeleportDistanceThreshold },
	{ "GetSubInstanceByName", GetSubInstanceByName },
	{ "GetSkeletalCenterOfMass", GetSkeletalCenterOfMass },
	{ "GetPostProcessInstance", GetPostProcessInstance },
	{ "GetPosition", GetPosition },
	{ "GetPlayRate", GetPlayRate },
	{ "GetMorphTarget", GetMorphTarget },
	{ "GetDisablePostProcessBlueprint", GetDisablePostProcessBlueprint },
	{ "GetDisableAnimCurves", GetDisableAnimCurves },
	{ "GetCurrentJointAngles", GetCurrentJointAngles },
	{ "GetClothMaxDistanceScale", GetClothMaxDistanceScale },
	{ "GetClothingSimulationInteractor", GetClothingSimulationInteractor },
	{ "GetBoneMass", GetBoneMass },
	{ "GetAnimInstance", GetAnimInstance },
	{ "GetAnimationMode", GetAnimationMode },
	{ "GetAllowedAnimCurveEvaluate", GetAllowedAnimCurveEvaluate },
	{ "ForceClothNextUpdateTeleportAndReset", ForceClothNextUpdateTeleportAndReset },
	{ "ForceClothNextUpdateTeleport", ForceClothNextUpdateTeleport },
	{ "FindConstraintBoneName", FindConstraintBoneName },
	{ "ClearMorphTargets", ClearMorphTargets },
	{ "BreakConstraint", BreakConstraint },
	{ "BindClothToMasterPoseComponent", BindClothToMasterPoseComponent },
	{ "AllowAnimCurveEvaluation", AllowAnimCurveEvaluation },
	{ "AddImpulseToAllBodiesBelow", AddImpulseToAllBodiesBelow },
	{ "AddForceToAllBodiesBelow", AddForceToAllBodiesBelow },
	{ "AccumulateAllBodiesBelowPhysicsBlendWeight", AccumulateAllBodiesBelowPhysicsBlendWeight },
	{ "Get_AnimBlueprintGeneratedClass", Get_AnimBlueprintGeneratedClass },
	{ "Get_AnimClass", Get_AnimClass },
	{ "Get_GlobalAnimRateScale", Get_GlobalAnimRateScale },
	{ "Set_GlobalAnimRateScale", Set_GlobalAnimRateScale },
	{ "Get_UseAsyncScene", Get_UseAsyncScene },
	{ "Get_KinematicBonesUpdateType", Get_KinematicBonesUpdateType },
	{ "Set_KinematicBonesUpdateType", Set_KinematicBonesUpdateType },
	{ "Get_PhysicsTransformUpdateMode", Get_PhysicsTransformUpdateMode },
	{ "Set_PhysicsTransformUpdateMode", Set_PhysicsTransformUpdateMode },
	{ "Get_AnimationMode", Get_AnimationMode },
	{ "Get_bDisablePostProcessBlueprint", Get_bDisablePostProcessBlueprint },
	{ "Set_bDisablePostProcessBlueprint", Set_bDisablePostProcessBlueprint },
	{ "Get_bUpdateOverlapsOnAnimationFinalize", Get_bUpdateOverlapsOnAnimationFinalize },
	{ "Set_bUpdateOverlapsOnAnimationFinalize", Set_bUpdateOverlapsOnAnimationFinalize },
	{ "Get_bEnablePhysicsOnDedicatedServer", Get_bEnablePhysicsOnDedicatedServer },
	{ "Set_bEnablePhysicsOnDedicatedServer", Set_bEnablePhysicsOnDedicatedServer },
	{ "Get_bUpdateJointsFromAnimation", Get_bUpdateJointsFromAnimation },
	{ "Set_bUpdateJointsFromAnimation", Set_bUpdateJointsFromAnimation },
	{ "Get_bDisableClothSimulation", Get_bDisableClothSimulation },
	{ "Set_bDisableClothSimulation", Set_bDisableClothSimulation },
	{ "Get_bAllowAnimCurveEvaluation", Get_bAllowAnimCurveEvaluation },
	{ "Set_bAllowAnimCurveEvaluation", Set_bAllowAnimCurveEvaluation },
	{ "Get_bCollideWithEnvironment", Get_bCollideWithEnvironment },
	{ "Set_bCollideWithEnvironment", Set_bCollideWithEnvironment },
	{ "Get_bCollideWithAttachedChildren", Get_bCollideWithAttachedChildren },
	{ "Set_bCollideWithAttachedChildren", Set_bCollideWithAttachedChildren },
	{ "Get_bLocalSpaceSimulation", Get_bLocalSpaceSimulation },
	{ "Set_bLocalSpaceSimulation", Set_bLocalSpaceSimulation },
	{ "Get_bResetAfterTeleport", Get_bResetAfterTeleport },
	{ "Set_bResetAfterTeleport", Set_bResetAfterTeleport },
	{ "Get_bNoSkeletonUpdate", Get_bNoSkeletonUpdate },
	{ "Set_bNoSkeletonUpdate", Set_bNoSkeletonUpdate },
	{ "Get_bPauseAnims", Get_bPauseAnims },
	{ "Set_bPauseAnims", Set_bPauseAnims },
	{ "Get_bUseRefPoseOnInitAnim", Get_bUseRefPoseOnInitAnim },
	{ "Set_bUseRefPoseOnInitAnim", Set_bUseRefPoseOnInitAnim },
	{ "Get_bEnablePerPolyCollision", Get_bEnablePerPolyCollision },
	{ "Get_bIncludeComponentLocationIntoBounds", Get_bIncludeComponentLocationIntoBounds },
	{ "Set_bIncludeComponentLocationIntoBounds", Set_bIncludeComponentLocationIntoBounds },
	{ "Get_bIncludeAttachParentCompLocationIntoFixBounds", Get_bIncludeAttachParentCompLocationIntoFixBounds },
	{ "Set_bIncludeAttachParentCompLocationIntoFixBounds", Set_bIncludeAttachParentCompLocationIntoFixBounds },
	{ "Get_bUseBendingElements", Get_bUseBendingElements },
	{ "Set_bUseBendingElements", Set_bUseBendingElements },
	{ "Get_bUseTetrahedralConstraints", Get_bUseTetrahedralConstraints },
	{ "Set_bUseTetrahedralConstraints", Set_bUseTetrahedralConstraints },
	{ "Get_bUseThinShellVolumeConstraints", Get_bUseThinShellVolumeConstraints },
	{ "Set_bUseThinShellVolumeConstraints", Set_bUseThinShellVolumeConstraints },
	{ "Get_bUseSelfCollisions", Get_bUseSelfCollisions },
	{ "Set_bUseSelfCollisions", Set_bUseSelfCollisions },
	{ "Get_bUseContinuousCollisionDetection", Get_bUseContinuousCollisionDetection },
	{ "Set_bUseContinuousCollisionDetection", Set_bUseContinuousCollisionDetection },
	{ "Get_bUpdateAnimationInEditor", Get_bUpdateAnimationInEditor },
	{ "Set_bUpdateAnimationInEditor", Set_bUpdateAnimationInEditor },
	{ "Get_ClothBlendWeight", Get_ClothBlendWeight },
	{ "Set_ClothBlendWeight", Set_ClothBlendWeight },
	{ "Get_EdgeStiffness", Get_EdgeStiffness },
	{ "Set_EdgeStiffness", Set_EdgeStiffness },
	{ "Get_BendingStiffness", Get_BendingStiffness },
	{ "Set_BendingStiffness", Set_BendingStiffness },
	{ "Get_AreaStiffness", Get_AreaStiffness },
	{ "Set_AreaStiffness", Set_AreaStiffness },
	{ "Get_VolumeStiffness", Get_VolumeStiffness },
	{ "Set_VolumeStiffness", Set_VolumeStiffness },
	{ "Get_StrainLimitingStiffness", Get_StrainLimitingStiffness },
	{ "Set_StrainLimitingStiffness", Set_StrainLimitingStiffness },
	{ "Get_ShapeTargetStiffness", Get_ShapeTargetStiffness },
	{ "Set_ShapeTargetStiffness", Set_ShapeTargetStiffness },
	{ "Call_OnConstraintBroken", Call_OnConstraintBroken },
	{ "Get_TeleportDistanceThreshold", Get_TeleportDistanceThreshold },
	{ "Set_TeleportDistanceThreshold", Set_TeleportDistanceThreshold },
	{ "Get_TeleportRotationThreshold", Get_TeleportRotationThreshold },
	{ "Set_TeleportRotationThreshold", Set_TeleportRotationThreshold },
	{ "Call_OnAnimInitialized", Call_OnAnimInitialized },
	{ "GetNearestPhysicBodyName", GetNearestPhysicBodyName },
	{ "GetPhysicBodyCount", GetPhysicBodyCount },
	{ "GetBlowPhysicBodyCount", GetBlowPhysicBodyCount },
	{ "GetRefPoseBoneLocation", GetRefPoseBoneLocation },
	{ "is_nil", wLua::LuaStatic::isnil },
	{ "__gc", wLua::LuaStatic::removeUClassFrameCache },
	{ NULL, NULL }
};

void Register(lua_State *InScriptContext)
{
	lua_newtable(InScriptContext);
	luaL_register(InScriptContext, NULL, Lib_Funcs);
	AzureHelpFuncs::AuxRegister(InScriptContext, "SkeletalMeshComponent");
}
void SetMtLink(lua_State *InScriptContext)
{
	AzureHelpFuncs::AuxSetMtLink(InScriptContext, "SkeletalMeshComponent", "SkinnedMeshComponent",USERDATATYPE_UOBJECT);
}

}