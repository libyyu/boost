#include "Azure.h"
#include "Utility/help_funcs.h"
#include "wLua/UObjectHeaders.h"
#include "Widget/UIParticle.h"
#include "AzureLuaIntegration.h"

namespace LuaUIParticle
{
int32 StopEmit(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"UIParticle",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"UIParticle must be non-null"); lua_error(InScriptContext);  return 0;}
#if UE_GAME
	UUIParticle * This = (UUIParticle *)Obj;
	This->StopEmit();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("StopEmit"));
	if(!Function) { check(false); return 0;}
	Obj->ProcessEvent(Function, NULL);
#endif
	return 0;
}

int32 Stop(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"UIParticle",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"UIParticle must be non-null"); lua_error(InScriptContext);  return 0;}
#if UE_GAME
	UUIParticle * This = (UUIParticle *)Obj;
	This->Stop();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("Stop"));
	if(!Function) { check(false); return 0;}
	Obj->ProcessEvent(Function, NULL);
#endif
	return 0;
}

int32 Play(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"UIParticle",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"UIParticle must be non-null"); lua_error(InScriptContext);  return 0;}
#if UE_GAME
	UUIParticle * This = (UUIParticle *)Obj;
	This->Play();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("Play"));
	if(!Function) { check(false); return 0;}
	Obj->ProcessEvent(Function, NULL);
#endif
	return 0;
}

int32 IsLoop(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"UIParticle",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"UIParticle must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool ReturnValue;
	} Params;
#if UE_GAME
	UUIParticle * This = (UUIParticle *)Obj;
	Params.ReturnValue = This->IsLoop();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("IsLoop"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushboolean(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 Get_Asset(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"UIParticle",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"UIParticle must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UUIParticle::StaticClass(), TEXT("Asset"));
	if(!Property) { check(false); return 0;}
	UUIParticleAsset* PropertyValue;
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaUtils::ReturnUObject(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_Asset(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"UIParticle",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"UIParticle must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UUIParticle::StaticClass(), TEXT("Asset"));
	if(!Property) { check(false); return 0;}
	UUIParticleAsset* PropertyValue = (UUIParticleAsset*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"UIParticleAsset");;
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Call_EventOnEnd(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"UIParticle",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"UIParticle must be non-null"); lua_error(InScriptContext);  return 0;}
	UUIParticle * This = (UUIParticle *)Obj;
	This->EventOnEnd.Broadcast();
	return 0;
}

int32 Get_IsPlaying(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"UIParticle",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"UIParticle must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UUIParticle::StaticClass(), TEXT("IsPlaying"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = bool();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 New(lua_State* InScriptContext)
{
	UObject* Outer = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Object");
	FName Name = FName(luaL_checkstring(InScriptContext, 2));
	UObject* Obj = NewObject<UUIParticle>(Outer, Name);
	wLua::FLuaUtils::ReturnUObject(InScriptContext,Obj);
	return 1;
}

int32 Destroy(lua_State* InScriptContext)
{
	return 0;
}

int32 Class(lua_State* InScriptContext)
{
	UClass* Class = UUIParticle::StaticClass();
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Class);
	return 1;
}

const luaL_Reg Lib_Funcs[] =
{
	{ "New", New },
	{ "Destroy", Destroy },
	{ "Class", Class },
	{ "StopEmit", StopEmit },
	{ "Stop", Stop },
	{ "Play", Play },
	{ "IsLoop", IsLoop },
	{ "Get_Asset", Get_Asset },
	{ "Set_Asset", Set_Asset },
	{ "Call_EventOnEnd", Call_EventOnEnd },
	{ "Get_IsPlaying", Get_IsPlaying },
	{ "is_nil", wLua::LuaStatic::isnil },
	{ "__gc", wLua::LuaStatic::removeUClassFrameCache },
	{ NULL, NULL }
};

void Register(lua_State *InScriptContext)
{
	lua_newtable(InScriptContext);
	luaL_register(InScriptContext, NULL, Lib_Funcs);
	AzureHelpFuncs::AuxRegister(InScriptContext, "UIParticle");
}
void SetMtLink(lua_State *InScriptContext)
{
	AzureHelpFuncs::AuxSetMtLink(InScriptContext, "UIParticle", "Widget",USERDATATYPE_UOBJECT);
}

}