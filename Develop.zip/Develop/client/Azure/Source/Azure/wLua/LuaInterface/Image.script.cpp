#include "Azure.h"
#include "Utility/help_funcs.h"
#include "wLua/UObjectHeaders.h"
#include "Components/Image.h"
#include "AzureLuaIntegration.h"

namespace LuaImage
{
int32 SetBrushFromAtlas(lua_State*);
int32 ResetAzureAtlasInfo(lua_State*);
int32 SetAtlasName(lua_State*);
int32 SetMirror(lua_State*);
int32 SetBrushTintColor(lua_State*);

int32 SetOpacity(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Image",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Image must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float InOpacity;
	} Params;
	Params.InOpacity = (float)(luaL_checknumber(InScriptContext, 2));
#if UE_GAME
	UImage * This = (UImage *)Obj;
	This->SetOpacity(Params.InOpacity);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetOpacity"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(float*)(params.GetStructMemory() + 0) = Params.InOpacity;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.InOpacity = *(float*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetColorAndOpacity(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Image",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Image must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FLinearColor InColorAndOpacity;
	} Params;
	Params.InColorAndOpacity = (wLua::FLuaLinearColor::Get(InScriptContext, 2));
#if UE_GAME
	UImage * This = (UImage *)Obj;
	This->SetColorAndOpacity(Params.InColorAndOpacity);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetColorAndOpacity"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FLinearColor*)(params.GetStructMemory() + 0) = Params.InColorAndOpacity;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.InColorAndOpacity = *(FLinearColor*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetBrushSize(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Image",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Image must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FVector2D DesiredSize;
	} Params;
	Params.DesiredSize = (wLua::FLuaVector2D::Get(InScriptContext, 2));
#if UE_GAME
	UImage * This = (UImage *)Obj;
	This->SetBrushSize(Params.DesiredSize);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetBrushSize"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FVector2D*)(params.GetStructMemory() + 0) = Params.DesiredSize;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.DesiredSize = *(FVector2D*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetBrushFromTextureDynamic(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Image",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Image must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		UTexture2DDynamic* Texture = nullptr;
		bool bMatchSize;
	} Params;
	Params.Texture = (UTexture2DDynamic*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"Texture2DDynamic");;
	Params.bMatchSize = lua_isnoneornil(InScriptContext,3) ? bool(false) : !!(lua_toboolean(InScriptContext, 3));
#if UE_GAME
	UImage * This = (UImage *)Obj;
	This->SetBrushFromTextureDynamic(Params.Texture,Params.bMatchSize);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetBrushFromTextureDynamic"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(UTexture2DDynamic**)(params.GetStructMemory() + 0) = Params.Texture;
		*(bool*)(params.GetStructMemory() + 8) = Params.bMatchSize;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.Texture = *(UTexture2DDynamic**)(params.GetStructMemory() + 0);
		Params.bMatchSize = *(bool*)(params.GetStructMemory() + 8);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetBrushFromTexture(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Image",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Image must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		UTexture2D* Texture = nullptr;
		bool bMatchSize;
	} Params;
	Params.Texture = (UTexture2D*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"Texture2D");;
	Params.bMatchSize = lua_isnoneornil(InScriptContext,3) ? bool(false) : !!(lua_toboolean(InScriptContext, 3));
#if UE_GAME
	UImage * This = (UImage *)Obj;
	This->SetBrushFromTexture(Params.Texture,Params.bMatchSize);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetBrushFromTexture"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(UTexture2D**)(params.GetStructMemory() + 0) = Params.Texture;
		*(bool*)(params.GetStructMemory() + 8) = Params.bMatchSize;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.Texture = *(UTexture2D**)(params.GetStructMemory() + 0);
		Params.bMatchSize = *(bool*)(params.GetStructMemory() + 8);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetBrushFromMaterial(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Image",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Image must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		UMaterialInterface* Material = nullptr;
	} Params;
	Params.Material = (UMaterialInterface*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"MaterialInterface");;
#if UE_GAME
	UImage * This = (UImage *)Obj;
	This->SetBrushFromMaterial(Params.Material);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetBrushFromMaterial"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(UMaterialInterface**)(params.GetStructMemory() + 0) = Params.Material;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.Material = *(UMaterialInterface**)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetBrushFromAsset(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Image",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Image must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		USlateBrushAsset* Asset = nullptr;
	} Params;
	Params.Asset = (USlateBrushAsset*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"SlateBrushAsset");;
#if UE_GAME
	UImage * This = (UImage *)Obj;
	This->SetBrushFromAsset(Params.Asset);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetBrushFromAsset"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(USlateBrushAsset**)(params.GetStructMemory() + 0) = Params.Asset;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.Asset = *(USlateBrushAsset**)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetBrushByAzureAtlasInfo(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Image",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Image must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		UObject* InAtlasResourceObject = nullptr;
		FName InAtlasName;
	} Params;
	Params.InAtlasResourceObject = (UObject*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"Object");;
	Params.InAtlasName = FName(UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 3)));
#if UE_GAME
	UImage * This = (UImage *)Obj;
	This->SetBrushByAzureAtlasInfo(Params.InAtlasResourceObject,Params.InAtlasName);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetBrushByAzureAtlasInfo"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(UObject**)(params.GetStructMemory() + 0) = Params.InAtlasResourceObject;
		*(FName*)(params.GetStructMemory() + 8) = Params.InAtlasName;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.InAtlasResourceObject = *(UObject**)(params.GetStructMemory() + 0);
		Params.InAtlasName = *(FName*)(params.GetStructMemory() + 8);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 GetDynamicMaterial(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Image",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Image must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		UMaterialInstanceDynamic* ReturnValue = nullptr;
	} Params;
#if UE_GAME
	UImage * This = (UImage *)Obj;
	Params.ReturnValue = This->GetDynamicMaterial();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetDynamicMaterial"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(UMaterialInstanceDynamic**)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 ClearAzureAtlasInfoIfNeeded(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Image",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Image must be non-null"); lua_error(InScriptContext);  return 0;}
#if UE_GAME
	UImage * This = (UImage *)Obj;
	This->ClearAzureAtlasInfoIfNeeded();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("ClearAzureAtlasInfoIfNeeded"));
	if(!Function) { check(false); return 0;}
	Obj->ProcessEvent(Function, NULL);
#endif
	return 0;
}

int32 Get_ColorAndOpacity(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Image",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Image must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UImage::StaticClass(), TEXT("ColorAndOpacity"));
	if(!Property) { check(false); return 0;}
	FLinearColor PropertyValue = FLinearColor();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaLinearColor::Return(InScriptContext, PropertyValue);
	return 1;
}

int32 New(lua_State* InScriptContext)
{
	UObject* Outer = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Object");
	FName Name = FName(luaL_checkstring(InScriptContext, 2));
	UObject* Obj = NewObject<UImage>(Outer, Name);
	wLua::FLuaUtils::ReturnUObject(InScriptContext,Obj);
	return 1;
}

int32 Destroy(lua_State* InScriptContext)
{
	return 0;
}

int32 Class(lua_State* InScriptContext)
{
	UClass* Class = UImage::StaticClass();
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Class);
	return 1;
}

const luaL_Reg Lib_Funcs[] =
{
	{ "New", New },
	{ "Destroy", Destroy },
	{ "Class", Class },
	{ "SetOpacity", SetOpacity },
	{ "SetColorAndOpacity", SetColorAndOpacity },
	{ "SetBrushSize", SetBrushSize },
	{ "SetBrushFromTextureDynamic", SetBrushFromTextureDynamic },
	{ "SetBrushFromTexture", SetBrushFromTexture },
	{ "SetBrushFromMaterial", SetBrushFromMaterial },
	{ "SetBrushFromAsset", SetBrushFromAsset },
	{ "SetBrushByAzureAtlasInfo", SetBrushByAzureAtlasInfo },
	{ "GetDynamicMaterial", GetDynamicMaterial },
	{ "ClearAzureAtlasInfoIfNeeded", ClearAzureAtlasInfoIfNeeded },
	{ "Get_ColorAndOpacity", Get_ColorAndOpacity },
	{ "SetBrushFromAtlas", SetBrushFromAtlas },
	{ "ResetAzureAtlasInfo", ResetAzureAtlasInfo },
	{ "SetAtlasName", SetAtlasName },
	{ "SetMirror", SetMirror },
	{ "SetBrushTintColor", SetBrushTintColor },
	{ "is_nil", wLua::LuaStatic::isnil },
	{ "__gc", wLua::LuaStatic::removeUClassFrameCache },
	{ NULL, NULL }
};

void Register(lua_State *InScriptContext)
{
	lua_newtable(InScriptContext);
	luaL_register(InScriptContext, NULL, Lib_Funcs);
	AzureHelpFuncs::AuxRegister(InScriptContext, "Image");
}
void SetMtLink(lua_State *InScriptContext)
{
	AzureHelpFuncs::AuxSetMtLink(InScriptContext, "Image", "Widget",USERDATATYPE_UOBJECT);
}

}