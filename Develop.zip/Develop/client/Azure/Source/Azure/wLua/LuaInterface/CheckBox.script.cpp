#include "Azure.h"
#include "Utility/help_funcs.h"
#include "wLua/UObjectHeaders.h"
#include "Components/CheckBox.h"
#include "AzureLuaIntegration.h"

namespace LuaCheckBox
{
int32 SetIsChecked(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CheckBox",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CheckBox must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool InIsChecked;
	} Params;
	Params.InIsChecked = !!(lua_toboolean(InScriptContext, 2));
#if UE_GAME
	UCheckBox * This = (UCheckBox *)Obj;
	This->SetIsChecked(Params.InIsChecked);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetIsChecked"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(bool*)(params.GetStructMemory() + 0) = Params.InIsChecked;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.InIsChecked = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetCheckedStateAndTriggerEvents(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CheckBox",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CheckBox must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		ECheckBoxState InCheckedState;
	} Params;
	Params.InCheckedState = (ECheckBoxState)(luaL_checkint(InScriptContext, 2));
#if UE_GAME
	UCheckBox * This = (UCheckBox *)Obj;
	This->SetCheckedStateAndTriggerEvents(Params.InCheckedState);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetCheckedStateAndTriggerEvents"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(ECheckBoxState*)(params.GetStructMemory() + 0) = Params.InCheckedState;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.InCheckedState = *(ECheckBoxState*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetCheckedState(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CheckBox",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CheckBox must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		ECheckBoxState InCheckedState;
	} Params;
	Params.InCheckedState = (ECheckBoxState)(luaL_checkint(InScriptContext, 2));
#if UE_GAME
	UCheckBox * This = (UCheckBox *)Obj;
	This->SetCheckedState(Params.InCheckedState);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetCheckedState"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(ECheckBoxState*)(params.GetStructMemory() + 0) = Params.InCheckedState;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.InCheckedState = *(ECheckBoxState*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 IsPressed(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CheckBox",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CheckBox must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool ReturnValue;
	} Params;
#if UE_GAME
	UCheckBox * This = (UCheckBox *)Obj;
	Params.ReturnValue = This->IsPressed();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("IsPressed"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushboolean(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 IsChecked(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CheckBox",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CheckBox must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool ReturnValue;
	} Params;
#if UE_GAME
	UCheckBox * This = (UCheckBox *)Obj;
	Params.ReturnValue = This->IsChecked();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("IsChecked"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushboolean(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetCheckedState(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CheckBox",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CheckBox must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		ECheckBoxState ReturnValue;
	} Params;
#if UE_GAME
	UCheckBox * This = (UCheckBox *)Obj;
	Params.ReturnValue = This->GetCheckedState();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetCheckedState"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(ECheckBoxState*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushinteger(InScriptContext, (int)Params.ReturnValue);
	return 1;
}

int32 Get_CheckedState(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CheckBox",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CheckBox must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UCheckBox::StaticClass(), TEXT("CheckedState"));
	if(!Property) { check(false); return 0;}
	ECheckBoxState PropertyValue = ECheckBoxState();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushinteger(InScriptContext, (int)PropertyValue);
	return 1;
}

int32 Set_CheckedState(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CheckBox",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CheckBox must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UCheckBox::StaticClass(), TEXT("CheckedState"));
	if(!Property) { check(false); return 0;}
	ECheckBoxState PropertyValue = (ECheckBoxState)(luaL_checkint(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_HorizontalAlignment(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CheckBox",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CheckBox must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UCheckBox::StaticClass(), TEXT("HorizontalAlignment"));
	if(!Property) { check(false); return 0;}
	TEnumAsByte<EHorizontalAlignment> PropertyValue = TEnumAsByte<EHorizontalAlignment>();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushinteger(InScriptContext, (int)PropertyValue);
	return 1;
}

int32 Get_IsFocusable(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CheckBox",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CheckBox must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UCheckBox::StaticClass(), TEXT("IsFocusable"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = bool();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Call_OnCheckStateChanged(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CheckBox",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CheckBox must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool bIsChecked;
	} Params;
	Params.bIsChecked = !!(lua_toboolean(InScriptContext, 2));
	UCheckBox * This = (UCheckBox *)Obj;
	This->OnCheckStateChanged.Broadcast(Params.bIsChecked);
	return 0;
}

int32 New(lua_State* InScriptContext)
{
	UObject* Outer = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Object");
	FName Name = FName(luaL_checkstring(InScriptContext, 2));
	UObject* Obj = NewObject<UCheckBox>(Outer, Name);
	wLua::FLuaUtils::ReturnUObject(InScriptContext,Obj);
	return 1;
}

int32 Destroy(lua_State* InScriptContext)
{
	return 0;
}

int32 Class(lua_State* InScriptContext)
{
	UClass* Class = UCheckBox::StaticClass();
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Class);
	return 1;
}

const luaL_Reg Lib_Funcs[] =
{
	{ "New", New },
	{ "Destroy", Destroy },
	{ "Class", Class },
	{ "SetIsChecked", SetIsChecked },
	{ "SetCheckedStateAndTriggerEvents", SetCheckedStateAndTriggerEvents },
	{ "SetCheckedState", SetCheckedState },
	{ "IsPressed", IsPressed },
	{ "IsChecked", IsChecked },
	{ "GetCheckedState", GetCheckedState },
	{ "Get_CheckedState", Get_CheckedState },
	{ "Set_CheckedState", Set_CheckedState },
	{ "Get_HorizontalAlignment", Get_HorizontalAlignment },
	{ "Get_IsFocusable", Get_IsFocusable },
	{ "Call_OnCheckStateChanged", Call_OnCheckStateChanged },
	{ "is_nil", wLua::LuaStatic::isnil },
	{ "__gc", wLua::LuaStatic::removeUClassFrameCache },
	{ NULL, NULL }
};

void Register(lua_State *InScriptContext)
{
	lua_newtable(InScriptContext);
	luaL_register(InScriptContext, NULL, Lib_Funcs);
	AzureHelpFuncs::AuxRegister(InScriptContext, "CheckBox");
}
void SetMtLink(lua_State *InScriptContext)
{
	AzureHelpFuncs::AuxSetMtLink(InScriptContext, "CheckBox", "ContentWidget",USERDATATYPE_UOBJECT);
}

}