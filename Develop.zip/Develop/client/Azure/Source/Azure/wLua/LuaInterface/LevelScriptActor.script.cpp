#include "Azure.h"
#include "Utility/help_funcs.h"
#include "wLua/UObjectHeaders.h"
#include "Engine/LevelScriptActor.h"
#include "AzureLuaIntegration.h"

namespace LuaLevelScriptActor
{
int32 SetCinematicMode(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"LevelScriptActor",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"LevelScriptActor must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool bCinematicMode;
		bool bHidePlayer;
		bool bAffectsHUD;
		bool bAffectsMovement;
		bool bAffectsTurning;
	} Params;
	Params.bCinematicMode = !!(lua_toboolean(InScriptContext, 2));
	Params.bHidePlayer = lua_isnoneornil(InScriptContext,3) ? bool(true) : !!(lua_toboolean(InScriptContext, 3));
	Params.bAffectsHUD = lua_isnoneornil(InScriptContext,4) ? bool(true) : !!(lua_toboolean(InScriptContext, 4));
	Params.bAffectsMovement = lua_isnoneornil(InScriptContext,5) ? bool(false) : !!(lua_toboolean(InScriptContext, 5));
	Params.bAffectsTurning = lua_isnoneornil(InScriptContext,6) ? bool(false) : !!(lua_toboolean(InScriptContext, 6));
#if UE_GAME
	ALevelScriptActor * This = (ALevelScriptActor *)Obj;
	This->SetCinematicMode(Params.bCinematicMode,Params.bHidePlayer,Params.bAffectsHUD,Params.bAffectsMovement,Params.bAffectsTurning);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetCinematicMode"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(bool*)(params.GetStructMemory() + 0) = Params.bCinematicMode;
		*(bool*)(params.GetStructMemory() + 1) = Params.bHidePlayer;
		*(bool*)(params.GetStructMemory() + 2) = Params.bAffectsHUD;
		*(bool*)(params.GetStructMemory() + 3) = Params.bAffectsMovement;
		*(bool*)(params.GetStructMemory() + 4) = Params.bAffectsTurning;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.bCinematicMode = *(bool*)(params.GetStructMemory() + 0);
		Params.bHidePlayer = *(bool*)(params.GetStructMemory() + 1);
		Params.bAffectsHUD = *(bool*)(params.GetStructMemory() + 2);
		Params.bAffectsMovement = *(bool*)(params.GetStructMemory() + 3);
		Params.bAffectsTurning = *(bool*)(params.GetStructMemory() + 4);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 RemoteEvent(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"LevelScriptActor",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"LevelScriptActor must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FName EventName;
		bool ReturnValue;
	} Params;
	Params.EventName = FName(UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 2)));
#if UE_GAME
	ALevelScriptActor * This = (ALevelScriptActor *)Obj;
	Params.ReturnValue = This->RemoteEvent(Params.EventName);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("RemoteEvent"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FName*)(params.GetStructMemory() + 0) = Params.EventName;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.EventName = *(FName*)(params.GetStructMemory() + 0);
		Params.ReturnValue = *(bool*)(params.GetStructMemory() + 12);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushboolean(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 LevelReset(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"LevelScriptActor",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"LevelScriptActor must be non-null"); lua_error(InScriptContext);  return 0;}
#if UE_GAME
	ALevelScriptActor * This = (ALevelScriptActor *)Obj;
	This->LevelReset();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("LevelReset"));
	if(!Function) { check(false); return 0;}
	Obj->ProcessEvent(Function, NULL);
#endif
	return 0;
}

int32 New(lua_State* InScriptContext)
{
	UObject* Outer = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Object");
	FName Name = FName(luaL_checkstring(InScriptContext, 2));
	UObject* Obj = NewObject<ALevelScriptActor>(Outer, Name);
	wLua::FLuaUtils::ReturnUObject(InScriptContext,Obj);
	return 1;
}

int32 Destroy(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"LevelScriptActor",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"LevelScriptActor must be non-null"); lua_error(InScriptContext);  return 0;}
		AActor * actor = Cast<AActor>(Obj);
		actor->Destroy();
		userdata->flag |= wLua::LuaObjectFlag::DESTROYED;
		wLua::FLuaUtils::RemoveObjectReference(Obj, userdata->stamp, InScriptContext);
#ifdef AZURE_BUILD_WLUACHECK
		UE_LOG(LogAzure, Warning, TEXT("Destroy LevelScriptActor: %x userdata:%x   stamp:%x"),Obj,userdata,userdata->stamp);
#endif
	return 0;
}

int32 Class(lua_State* InScriptContext)
{
	UClass* Class = ALevelScriptActor::StaticClass();
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Class);
	return 1;
}

const luaL_Reg Lib_Funcs[] =
{
	{ "New", New },
	{ "Destroy", Destroy },
	{ "Class", Class },
	{ "SetCinematicMode", SetCinematicMode },
	{ "RemoteEvent", RemoteEvent },
	{ "LevelReset", LevelReset },
	{ "is_nil", wLua::LuaStatic::isnil },
	{ "__gc", wLua::LuaStatic::removeUClassFrameCache },
	{ NULL, NULL }
};

void Register(lua_State *InScriptContext)
{
	lua_newtable(InScriptContext);
	luaL_register(InScriptContext, NULL, Lib_Funcs);
	AzureHelpFuncs::AuxRegister(InScriptContext, "LevelScriptActor");
}
void SetMtLink(lua_State *InScriptContext)
{
	AzureHelpFuncs::AuxSetMtLink(InScriptContext, "LevelScriptActor", "Actor",USERDATATYPE_UOBJECT);
}

}