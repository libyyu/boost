#include "Azure.h"
#include "Utility/help_funcs.h"
#include "wLua/UObjectHeaders.h"
#include "Fx/FxOne.h"
#include "../UClassHeaders.h"
#include "AzureLuaIntegration.h"

namespace LuaFxOne
{
int32 AddOnStopCallback(lua_State*);

int32 Stop(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"FxOne",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"FxOne must be non-null"); lua_error(InScriptContext);  return 0;}
#if UE_GAME
	AFxOne * This = (AFxOne *)Obj;
	This->Stop();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("Stop"));
	if(!Function) { check(false); return 0;}
	Obj->ProcessEvent(Function, NULL);
#endif
	return 0;
}

int32 SetTrailParam(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"FxOne",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"FxOne must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		UMeshComponent* MeshComponent = nullptr;
		FName InFirstSocketName;
		FName InSecondSocketName;
		TEnumAsByte<ETrailWidthMode> Mode;
		UAnimInstance* Anim = nullptr;
		FName CurveName;
	} Params;
	Params.MeshComponent = (UMeshComponent*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"MeshComponent");;
	Params.InFirstSocketName = FName(UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 3)));
	Params.InSecondSocketName = FName(UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 4)));
	Params.Mode = (TEnumAsByte<ETrailWidthMode>)(luaL_checkint(InScriptContext, 5));
	Params.Anim = (UAnimInstance*)wLua::FLuaUtils::GetUObject(InScriptContext,6,"AnimInstance");;
	Params.CurveName = FName(UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 7)));
#if UE_GAME
	AFxOne * This = (AFxOne *)Obj;
	This->SetTrailParam(Params.MeshComponent,Params.InFirstSocketName,Params.InSecondSocketName,Params.Mode,Params.Anim,Params.CurveName);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetTrailParam"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(UMeshComponent**)(params.GetStructMemory() + 0) = Params.MeshComponent;
		*(FName*)(params.GetStructMemory() + 8) = Params.InFirstSocketName;
		*(FName*)(params.GetStructMemory() + 20) = Params.InSecondSocketName;
		*(TEnumAsByte<ETrailWidthMode>*)(params.GetStructMemory() + 32) = Params.Mode;
		*(UAnimInstance**)(params.GetStructMemory() + 40) = Params.Anim;
		*(FName*)(params.GetStructMemory() + 48) = Params.CurveName;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.MeshComponent = *(UMeshComponent**)(params.GetStructMemory() + 0);
		Params.InFirstSocketName = *(FName*)(params.GetStructMemory() + 8);
		Params.InSecondSocketName = *(FName*)(params.GetStructMemory() + 20);
		Params.Mode = *(TEnumAsByte<ETrailWidthMode>*)(params.GetStructMemory() + 32);
		Params.Anim = *(UAnimInstance**)(params.GetStructMemory() + 40);
		Params.CurveName = *(FName*)(params.GetStructMemory() + 48);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetNotEffectByManRenderHide(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"FxOne",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"FxOne must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool notEffect;
	} Params;
	Params.notEffect = !!(lua_toboolean(InScriptContext, 2));
#if UE_GAME
	AFxOne * This = (AFxOne *)Obj;
	This->SetNotEffectByManRenderHide(Params.notEffect);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetNotEffectByManRenderHide"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(bool*)(params.GetStructMemory() + 0) = Params.notEffect;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.notEffect = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetFXVisibleEx(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"FxOne",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"FxOne must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool bVisible;
		int32 mask;
	} Params;
	Params.bVisible = !!(lua_toboolean(InScriptContext, 2));
	Params.mask = (luaL_checkint(InScriptContext, 3));
#if UE_GAME
	AFxOne * This = (AFxOne *)Obj;
	This->SetFXVisibleEx(Params.bVisible,Params.mask);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetFXVisibleEx"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(bool*)(params.GetStructMemory() + 0) = Params.bVisible;
		*(int32*)(params.GetStructMemory() + 4) = Params.mask;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.bVisible = *(bool*)(params.GetStructMemory() + 0);
		Params.mask = *(int32*)(params.GetStructMemory() + 4);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetFXVisible(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"FxOne",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"FxOne must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool bVisible;
	} Params;
	Params.bVisible = !!(lua_toboolean(InScriptContext, 2));
#if UE_GAME
	AFxOne * This = (AFxOne *)Obj;
	This->SetFXVisible(Params.bVisible);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetFXVisible"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(bool*)(params.GetStructMemory() + 0) = Params.bVisible;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.bVisible = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 Set_MaxFxQuality(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"FxOne",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"FxOne must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		EAzureFxQuality q;
	} Params;
	Params.q = (EAzureFxQuality)(luaL_checkint(InScriptContext, 2));
#if UE_GAME
	AFxOne * This = (AFxOne *)Obj;
	This->Set_MaxFxQuality(Params.q);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("Set_MaxFxQuality"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(EAzureFxQuality*)(params.GetStructMemory() + 0) = Params.q;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.q = *(EAzureFxQuality*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 Set_MaxFxLod(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"FxOne",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"FxOne must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		int32 InMaxLod;
	} Params;
	Params.InMaxLod = (luaL_checkint(InScriptContext, 2));
#if UE_GAME
	AFxOne * This = (AFxOne *)Obj;
	This->Set_MaxFxLod(Params.InMaxLod);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("Set_MaxFxLod"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(int32*)(params.GetStructMemory() + 0) = Params.InMaxLod;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.InMaxLod = *(int32*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 Set_CanReplay(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"FxOne",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"FxOne must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool b;
	} Params;
	Params.b = !!(lua_toboolean(InScriptContext, 2));
#if UE_GAME
	AFxOne * This = (AFxOne *)Obj;
	This->Set_CanReplay(Params.b);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("Set_CanReplay"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(bool*)(params.GetStructMemory() + 0) = Params.b;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.b = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 Play(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"FxOne",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"FxOne must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float duration;
		bool needHighLod;
	} Params;
	Params.duration = (float)(luaL_checknumber(InScriptContext, 2));
	Params.needHighLod = !!(lua_toboolean(InScriptContext, 3));
#if UE_GAME
	AFxOne * This = (AFxOne *)Obj;
	This->Play(Params.duration,Params.needHighLod);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("Play"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(float*)(params.GetStructMemory() + 0) = Params.duration;
		*(bool*)(params.GetStructMemory() + 4) = Params.needHighLod;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.duration = *(float*)(params.GetStructMemory() + 0);
		Params.needHighLod = *(bool*)(params.GetStructMemory() + 4);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 OnParticleSystemFinished(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"FxOne",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"FxOne must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		UParticleSystemComponent* FinishedComponent = nullptr;
	} Params;
	Params.FinishedComponent = (UParticleSystemComponent*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"ParticleSystemComponent");;
#if UE_GAME
	AFxOne * This = (AFxOne *)Obj;
	This->OnParticleSystemFinished(Params.FinishedComponent);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("OnParticleSystemFinished"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(UParticleSystemComponent**)(params.GetStructMemory() + 0) = Params.FinishedComponent;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.FinishedComponent = *(UParticleSystemComponent**)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 IsReallyPlaying(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"FxOne",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"FxOne must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool ReturnValue;
	} Params;
#if UE_GAME
	AFxOne * This = (AFxOne *)Obj;
	Params.ReturnValue = This->IsReallyPlaying();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("IsReallyPlaying"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushboolean(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 IsLogicallyPlaying(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"FxOne",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"FxOne must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool ReturnValue;
	} Params;
#if UE_GAME
	AFxOne * This = (AFxOne *)Obj;
	Params.ReturnValue = This->IsLogicallyPlaying();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("IsLogicallyPlaying"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushboolean(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetParticleSystemComp(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"FxOne",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"FxOne must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		UParticleSystemComponent* ReturnValue = nullptr;
	} Params;
#if UE_GAME
	AFxOne * This = (AFxOne *)Obj;
	Params.ReturnValue = This->GetParticleSystemComp();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetParticleSystemComp"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(UParticleSystemComponent**)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetLeftDurationFloat(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"FxOne",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"FxOne must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float ReturnValue;
	} Params;
#if UE_GAME
	AFxOne * This = (AFxOne *)Obj;
	Params.ReturnValue = This->GetLeftDurationFloat();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetLeftDurationFloat"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(float*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushnumber(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 Get_CountLimited(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"FxOne",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"FxOne must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool ReturnValue;
	} Params;
#if UE_GAME
	AFxOne * This = (AFxOne *)Obj;
	Params.ReturnValue = This->Get_CountLimited();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("Get_CountLimited"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushboolean(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 Get_CanReplay(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"FxOne",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"FxOne must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool ReturnValue;
	} Params;
#if UE_GAME
	AFxOne * This = (AFxOne *)Obj;
	Params.ReturnValue = This->Get_CanReplay();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("Get_CanReplay"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushboolean(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 DelayStop(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"FxOne",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"FxOne must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float fDelayTime;
	} Params;
	Params.fDelayTime = (float)(luaL_checknumber(InScriptContext, 2));
#if UE_GAME
	AFxOne * This = (AFxOne *)Obj;
	This->DelayStop(Params.fDelayTime);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("DelayStop"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(float*)(params.GetStructMemory() + 0) = Params.fDelayTime;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.fDelayTime = *(float*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 Get_mDuration(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"FxOne",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"FxOne must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AFxOne::StaticClass(), TEXT("mDuration"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_FxComponent(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"FxOne",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"FxOne must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AFxOne::StaticClass(), TEXT("FxComponent"));
	if(!Property) { check(false); return 0;}
	UParticleSystemComponent* PropertyValue;
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaUtils::ReturnUObject(InScriptContext, PropertyValue);
	return 1;
}

int32 New(lua_State* InScriptContext)
{
	UObject* Outer = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Object");
	FName Name = FName(luaL_checkstring(InScriptContext, 2));
	UObject* Obj = NewObject<AFxOne>(Outer, Name);
	wLua::FLuaUtils::ReturnUObject(InScriptContext,Obj);
	return 1;
}

int32 Destroy(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"FxOne",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"FxOne must be non-null"); lua_error(InScriptContext);  return 0;}
		AActor * actor = Cast<AActor>(Obj);
		actor->Destroy();
		userdata->flag |= wLua::LuaObjectFlag::DESTROYED;
		wLua::FLuaUtils::RemoveObjectReference(Obj, userdata->stamp, InScriptContext);
#ifdef AZURE_BUILD_WLUACHECK
		UE_LOG(LogAzure, Warning, TEXT("Destroy FxOne: %x userdata:%x   stamp:%x"),Obj,userdata,userdata->stamp);
#endif
	return 0;
}

int32 Class(lua_State* InScriptContext)
{
	UClass* Class = AFxOne::StaticClass();
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Class);
	return 1;
}

const luaL_Reg Lib_Funcs[] =
{
	{ "New", New },
	{ "Destroy", Destroy },
	{ "Class", Class },
	{ "Stop", Stop },
	{ "SetTrailParam", SetTrailParam },
	{ "SetNotEffectByManRenderHide", SetNotEffectByManRenderHide },
	{ "SetFXVisibleEx", SetFXVisibleEx },
	{ "SetFXVisible", SetFXVisible },
	{ "Set_MaxFxQuality", Set_MaxFxQuality },
	{ "Set_MaxFxLod", Set_MaxFxLod },
	{ "Set_CanReplay", Set_CanReplay },
	{ "Play", Play },
	{ "OnParticleSystemFinished", OnParticleSystemFinished },
	{ "IsReallyPlaying", IsReallyPlaying },
	{ "IsLogicallyPlaying", IsLogicallyPlaying },
	{ "GetParticleSystemComp", GetParticleSystemComp },
	{ "GetLeftDurationFloat", GetLeftDurationFloat },
	{ "Get_CountLimited", Get_CountLimited },
	{ "Get_CanReplay", Get_CanReplay },
	{ "DelayStop", DelayStop },
	{ "Get_mDuration", Get_mDuration },
	{ "Get_FxComponent", Get_FxComponent },
	{ "AddOnStopCallback", AddOnStopCallback },
	{ "is_nil", wLua::LuaStatic::isnil },
	{ "__gc", wLua::LuaStatic::removeUClassFrameCache },
	{ NULL, NULL }
};

void Register(lua_State *InScriptContext)
{
	lua_newtable(InScriptContext);
	luaL_register(InScriptContext, NULL, Lib_Funcs);
	AzureHelpFuncs::AuxRegister(InScriptContext, "FxOne");
}
void SetMtLink(lua_State *InScriptContext)
{
	AzureHelpFuncs::AuxSetMtLink(InScriptContext, "FxOne", "Actor",USERDATATYPE_UOBJECT);
}

}