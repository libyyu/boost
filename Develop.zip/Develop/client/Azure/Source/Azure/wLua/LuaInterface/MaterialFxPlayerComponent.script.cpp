#include "Azure.h"
#include "Utility/help_funcs.h"
#include "wLua/UObjectHeaders.h"
#include "Utilities/MaterialFxPlayerComponent.h"
#include "AzureLuaIntegration.h"

namespace LuaMaterialFxPlayerComponent
{
int32 StopFx(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MaterialFxPlayerComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MaterialFxPlayerComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		UDataTable* Fx = nullptr;
		bool SkipExit;
	} Params;
	Params.Fx = (UDataTable*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"DataTable");;
	Params.SkipExit = lua_isnoneornil(InScriptContext,3) ? bool(false) : !!(lua_toboolean(InScriptContext, 3));
#if UE_GAME
	UMaterialFxPlayerComponent * This = (UMaterialFxPlayerComponent *)Obj;
	This->StopFx(Params.Fx,Params.SkipExit);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("StopFx"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(UDataTable**)(params.GetStructMemory() + 0) = Params.Fx;
		*(bool*)(params.GetStructMemory() + 8) = Params.SkipExit;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.Fx = *(UDataTable**)(params.GetStructMemory() + 0);
		Params.SkipExit = *(bool*)(params.GetStructMemory() + 8);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 Stop(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MaterialFxPlayerComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MaterialFxPlayerComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool SkipExit;
	} Params;
	Params.SkipExit = lua_isnoneornil(InScriptContext,2) ? bool(false) : !!(lua_toboolean(InScriptContext, 2));
#if UE_GAME
	UMaterialFxPlayerComponent * This = (UMaterialFxPlayerComponent *)Obj;
	This->Stop(Params.SkipExit);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("Stop"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(bool*)(params.GetStructMemory() + 0) = Params.SkipExit;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.SkipExit = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 PlayFxWithDurationScale(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MaterialFxPlayerComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MaterialFxPlayerComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		UDataTable* Fx = nullptr;
		float DurationScale;
	} Params;
	Params.Fx = (UDataTable*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"DataTable");;
	Params.DurationScale = lua_isnoneornil(InScriptContext,3) ? float(1.000000) : (float)(luaL_checknumber(InScriptContext, 3));
#if UE_GAME
	UMaterialFxPlayerComponent * This = (UMaterialFxPlayerComponent *)Obj;
	This->PlayFxWithDurationScale(Params.Fx,Params.DurationScale);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("PlayFxWithDurationScale"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(UDataTable**)(params.GetStructMemory() + 0) = Params.Fx;
		*(float*)(params.GetStructMemory() + 8) = Params.DurationScale;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.Fx = *(UDataTable**)(params.GetStructMemory() + 0);
		Params.DurationScale = *(float*)(params.GetStructMemory() + 8);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 PlayFx(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MaterialFxPlayerComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MaterialFxPlayerComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		UDataTable* Fx = nullptr;
	} Params;
	Params.Fx = (UDataTable*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"DataTable");;
#if UE_GAME
	UMaterialFxPlayerComponent * This = (UMaterialFxPlayerComponent *)Obj;
	This->PlayFx(Params.Fx);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("PlayFx"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(UDataTable**)(params.GetStructMemory() + 0) = Params.Fx;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.Fx = *(UDataTable**)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 OnModelChanged(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MaterialFxPlayerComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MaterialFxPlayerComponent must be non-null"); lua_error(InScriptContext);  return 0;}
#if UE_GAME
	UMaterialFxPlayerComponent * This = (UMaterialFxPlayerComponent *)Obj;
	This->OnModelChanged();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("OnModelChanged"));
	if(!Function) { check(false); return 0;}
	Obj->ProcessEvent(Function, NULL);
#endif
	return 0;
}

int32 IsPlaying(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MaterialFxPlayerComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MaterialFxPlayerComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool ReturnValue;
	} Params;
#if UE_GAME
	UMaterialFxPlayerComponent * This = (UMaterialFxPlayerComponent *)Obj;
	Params.ReturnValue = This->IsPlaying();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("IsPlaying"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushboolean(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetCorrespondingOriDynamicMaterial(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MaterialFxPlayerComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MaterialFxPlayerComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		UPrimitiveComponent* comp = nullptr;
		UMaterialInterface* mat = nullptr;
		UMaterialInstanceDynamic* ReturnValue = nullptr;
	} Params;
	Params.comp = (UPrimitiveComponent*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"PrimitiveComponent");;
	Params.mat = (UMaterialInterface*)wLua::FLuaUtils::GetUObject(InScriptContext,3,"MaterialInterface");;
#if UE_GAME
	UMaterialFxPlayerComponent * This = (UMaterialFxPlayerComponent *)Obj;
	Params.ReturnValue = This->GetCorrespondingOriDynamicMaterial(Params.comp,Params.mat);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetCorrespondingOriDynamicMaterial"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(UPrimitiveComponent**)(params.GetStructMemory() + 0) = Params.comp;
		*(UMaterialInterface**)(params.GetStructMemory() + 8) = Params.mat;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.comp = *(UPrimitiveComponent**)(params.GetStructMemory() + 0);
		Params.mat = *(UMaterialInterface**)(params.GetStructMemory() + 8);
		Params.ReturnValue = *(UMaterialInstanceDynamic**)(params.GetStructMemory() + 16);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 CleanUp(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MaterialFxPlayerComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MaterialFxPlayerComponent must be non-null"); lua_error(InScriptContext);  return 0;}
#if UE_GAME
	UMaterialFxPlayerComponent * This = (UMaterialFxPlayerComponent *)Obj;
	This->CleanUp();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("CleanUp"));
	if(!Function) { check(false); return 0;}
	Obj->ProcessEvent(Function, NULL);
#endif
	return 0;
}

int32 ApplyBodyPart(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MaterialFxPlayerComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MaterialFxPlayerComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		int32 Mask;
	} Params;
	Params.Mask = (luaL_checkint(InScriptContext, 2));
#if UE_GAME
	UMaterialFxPlayerComponent * This = (UMaterialFxPlayerComponent *)Obj;
	This->ApplyBodyPart(Params.Mask);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("ApplyBodyPart"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(int32*)(params.GetStructMemory() + 0) = Params.Mask;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.Mask = *(int32*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 New(lua_State* InScriptContext)
{
	UObject* Outer = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Object");
	FName Name = FName(luaL_checkstring(InScriptContext, 2));
	UObject* Obj = NewObject<UMaterialFxPlayerComponent>(Outer, Name);
	wLua::FLuaUtils::ReturnUObject(InScriptContext,Obj);
	return 1;
}

int32 Destroy(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MaterialFxPlayerComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MaterialFxPlayerComponent must be non-null"); lua_error(InScriptContext);  return 0;}
		UActorComponent * com = Cast<UActorComponent>(Obj);
		if(lua_isnoneornil(InScriptContext,2))
			com->DestroyComponent();
		else
			com->DestroyComponent(!!lua_toboolean(InScriptContext,2));
		userdata->flag |= wLua::LuaObjectFlag::DESTROYED;
		wLua::FLuaUtils::RemoveObjectReference(Obj, userdata->stamp, InScriptContext);
#ifdef AZURE_BUILD_WLUACHECK
		UE_LOG(LogAzure, Warning, TEXT("Destroy MaterialFxPlayerComponent: %x userdata:%x   stamp:%x"),Obj,userdata,userdata->stamp);
#endif
	return 0;
}

int32 Class(lua_State* InScriptContext)
{
	UClass* Class = UMaterialFxPlayerComponent::StaticClass();
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Class);
	return 1;
}

const luaL_Reg Lib_Funcs[] =
{
	{ "New", New },
	{ "Destroy", Destroy },
	{ "Class", Class },
	{ "StopFx", StopFx },
	{ "Stop", Stop },
	{ "PlayFxWithDurationScale", PlayFxWithDurationScale },
	{ "PlayFx", PlayFx },
	{ "OnModelChanged", OnModelChanged },
	{ "IsPlaying", IsPlaying },
	{ "GetCorrespondingOriDynamicMaterial", GetCorrespondingOriDynamicMaterial },
	{ "CleanUp", CleanUp },
	{ "ApplyBodyPart", ApplyBodyPart },
	{ "is_nil", wLua::LuaStatic::isnil },
	{ "__gc", wLua::LuaStatic::removeUClassFrameCache },
	{ NULL, NULL }
};

void Register(lua_State *InScriptContext)
{
	lua_newtable(InScriptContext);
	luaL_register(InScriptContext, NULL, Lib_Funcs);
	AzureHelpFuncs::AuxRegister(InScriptContext, "MaterialFxPlayerComponent");
}
void SetMtLink(lua_State *InScriptContext)
{
	AzureHelpFuncs::AuxSetMtLink(InScriptContext, "MaterialFxPlayerComponent", "ActorComponent",USERDATATYPE_UOBJECT);
}

}