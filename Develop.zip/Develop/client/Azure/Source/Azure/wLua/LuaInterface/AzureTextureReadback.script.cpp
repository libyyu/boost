#include "Azure.h"
#include "Utility/help_funcs.h"
#include "wLua/UObjectHeaders.h"
#include "Utilities/AzureTextureReadback.h"
#include "AzureLuaIntegration.h"

namespace LuaAzureTextureReadback
{
int32 ReadPixel_Manual(lua_State*);
int32 ReadPixelRGBA8(lua_State*);
int32 ReadPixelRGBAFloat(lua_State*);

int32 IsReadbackEnabled(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureTextureReadback",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureTextureReadback must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool ReturnValue;
	} Params;
#if UE_GAME
	AAzureTextureReadback * This = (AAzureTextureReadback *)Obj;
	Params.ReturnValue = This->IsReadbackEnabled();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("IsReadbackEnabled"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushboolean(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 EnableReadback(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureTextureReadback",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureTextureReadback must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool bEnabled;
	} Params;
	Params.bEnabled = !!(lua_toboolean(InScriptContext, 2));
#if UE_GAME
	AAzureTextureReadback * This = (AAzureTextureReadback *)Obj;
	This->EnableReadback(Params.bEnabled);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("EnableReadback"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(bool*)(params.GetStructMemory() + 0) = Params.bEnabled;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.bEnabled = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 Get_sourceTexture(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureTextureReadback",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureTextureReadback must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureTextureReadback::StaticClass(), TEXT("sourceTexture"));
	if(!Property) { check(false); return 0;}
	UTextureRenderTarget2D* PropertyValue;
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaUtils::ReturnUObject(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_sourceTexture(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureTextureReadback",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureTextureReadback must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureTextureReadback::StaticClass(), TEXT("sourceTexture"));
	if(!Property) { check(false); return 0;}
	UTextureRenderTarget2D* PropertyValue = (UTextureRenderTarget2D*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"TextureRenderTarget2D");;
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 New(lua_State* InScriptContext)
{
	UObject* Outer = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Object");
	FName Name = FName(luaL_checkstring(InScriptContext, 2));
	UObject* Obj = NewObject<AAzureTextureReadback>(Outer, Name);
	wLua::FLuaUtils::ReturnUObject(InScriptContext,Obj);
	return 1;
}

int32 Destroy(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureTextureReadback",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureTextureReadback must be non-null"); lua_error(InScriptContext);  return 0;}
		AActor * actor = Cast<AActor>(Obj);
		actor->Destroy();
		userdata->flag |= wLua::LuaObjectFlag::DESTROYED;
		wLua::FLuaUtils::RemoveObjectReference(Obj, userdata->stamp, InScriptContext);
#ifdef AZURE_BUILD_WLUACHECK
		UE_LOG(LogAzure, Warning, TEXT("Destroy AzureTextureReadback: %x userdata:%x   stamp:%x"),Obj,userdata,userdata->stamp);
#endif
	return 0;
}

int32 Class(lua_State* InScriptContext)
{
	UClass* Class = AAzureTextureReadback::StaticClass();
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Class);
	return 1;
}

const luaL_Reg Lib_Funcs[] =
{
	{ "New", New },
	{ "Destroy", Destroy },
	{ "Class", Class },
	{ "IsReadbackEnabled", IsReadbackEnabled },
	{ "EnableReadback", EnableReadback },
	{ "Get_sourceTexture", Get_sourceTexture },
	{ "Set_sourceTexture", Set_sourceTexture },
	{ "ReadPixel", ReadPixel_Manual },
	{ "ReadPixelRGBA8", ReadPixelRGBA8 },
	{ "ReadPixelRGBAFloat", ReadPixelRGBAFloat },
	{ "is_nil", wLua::LuaStatic::isnil },
	{ "__gc", wLua::LuaStatic::removeUClassFrameCache },
	{ NULL, NULL }
};

void Register(lua_State *InScriptContext)
{
	lua_newtable(InScriptContext);
	luaL_register(InScriptContext, NULL, Lib_Funcs);
	AzureHelpFuncs::AuxRegister(InScriptContext, "AzureTextureReadback");
}
void SetMtLink(lua_State *InScriptContext)
{
	AzureHelpFuncs::AuxSetMtLink(InScriptContext, "AzureTextureReadback", "Actor",USERDATATYPE_UOBJECT);
}

}