#include "Azure.h"
#include "Utility/help_funcs.h"
#include "wLua/UObjectHeaders.h"
#include "Engine/TextureRenderTarget2D.h"
#include "AzureLuaIntegration.h"

namespace LuaTextureRenderTarget2D
{
int32 SetRenderTargetFormat(lua_State*);
int32 InitCustomFormat(lua_State*);
int32 InitAutoFormat(lua_State*);
int32 Get_bForceLinearGamma(lua_State*);

int32 Get_SizeX(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"TextureRenderTarget2D",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"TextureRenderTarget2D must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UTextureRenderTarget2D::StaticClass(), TEXT("SizeX"));
	if(!Property) { check(false); return 0;}
	int32 PropertyValue = int32();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushinteger(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_SizeY(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"TextureRenderTarget2D",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"TextureRenderTarget2D must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UTextureRenderTarget2D::StaticClass(), TEXT("SizeY"));
	if(!Property) { check(false); return 0;}
	int32 PropertyValue = int32();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushinteger(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_ClearColor(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"TextureRenderTarget2D",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"TextureRenderTarget2D must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UTextureRenderTarget2D::StaticClass(), TEXT("ClearColor"));
	if(!Property) { check(false); return 0;}
	FLinearColor PropertyValue = FLinearColor();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaLinearColor::Return(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_AddressX(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"TextureRenderTarget2D",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"TextureRenderTarget2D must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UTextureRenderTarget2D::StaticClass(), TEXT("AddressX"));
	if(!Property) { check(false); return 0;}
	TEnumAsByte<TextureAddress> PropertyValue = TEnumAsByte<TextureAddress>();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushinteger(InScriptContext, (int)PropertyValue);
	return 1;
}

int32 Set_AddressX(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"TextureRenderTarget2D",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"TextureRenderTarget2D must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UTextureRenderTarget2D::StaticClass(), TEXT("AddressX"));
	if(!Property) { check(false); return 0;}
	TEnumAsByte<TextureAddress> PropertyValue = (TEnumAsByte<TextureAddress>)(luaL_checkint(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_AddressY(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"TextureRenderTarget2D",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"TextureRenderTarget2D must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UTextureRenderTarget2D::StaticClass(), TEXT("AddressY"));
	if(!Property) { check(false); return 0;}
	TEnumAsByte<TextureAddress> PropertyValue = TEnumAsByte<TextureAddress>();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushinteger(InScriptContext, (int)PropertyValue);
	return 1;
}

int32 Set_AddressY(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"TextureRenderTarget2D",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"TextureRenderTarget2D must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UTextureRenderTarget2D::StaticClass(), TEXT("AddressY"));
	if(!Property) { check(false); return 0;}
	TEnumAsByte<TextureAddress> PropertyValue = (TEnumAsByte<TextureAddress>)(luaL_checkint(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bGPUSharedFlag(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"TextureRenderTarget2D",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"TextureRenderTarget2D must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UTextureRenderTarget2D::StaticClass(), TEXT("bGPUSharedFlag"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_bAutoGenerateMips(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"TextureRenderTarget2D",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"TextureRenderTarget2D must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UTextureRenderTarget2D::StaticClass(), TEXT("bAutoGenerateMips"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_RenderTargetFormat(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"TextureRenderTarget2D",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"TextureRenderTarget2D must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UTextureRenderTarget2D::StaticClass(), TEXT("RenderTargetFormat"));
	if(!Property) { check(false); return 0;}
	TEnumAsByte<ETextureRenderTargetFormat> PropertyValue = TEnumAsByte<ETextureRenderTargetFormat>();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushinteger(InScriptContext, (int)PropertyValue);
	return 1;
}

int32 New(lua_State* InScriptContext)
{
	UObject* Outer = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Object");
	FName Name = FName(luaL_checkstring(InScriptContext, 2));
	UObject* Obj = NewObject<UTextureRenderTarget2D>(Outer, Name);
	wLua::FLuaUtils::ReturnUObject(InScriptContext,Obj);
	return 1;
}

int32 Destroy(lua_State* InScriptContext)
{
	return 0;
}

int32 Class(lua_State* InScriptContext)
{
	UClass* Class = UTextureRenderTarget2D::StaticClass();
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Class);
	return 1;
}

const luaL_Reg Lib_Funcs[] =
{
	{ "New", New },
	{ "Destroy", Destroy },
	{ "Class", Class },
	{ "Get_SizeX", Get_SizeX },
	{ "Get_SizeY", Get_SizeY },
	{ "Get_ClearColor", Get_ClearColor },
	{ "Get_AddressX", Get_AddressX },
	{ "Set_AddressX", Set_AddressX },
	{ "Get_AddressY", Get_AddressY },
	{ "Set_AddressY", Set_AddressY },
	{ "Get_bGPUSharedFlag", Get_bGPUSharedFlag },
	{ "Get_bAutoGenerateMips", Get_bAutoGenerateMips },
	{ "Get_RenderTargetFormat", Get_RenderTargetFormat },
	{ "SetRenderTargetFormat", SetRenderTargetFormat },
	{ "InitCustomFormat", InitCustomFormat },
	{ "InitAutoFormat", InitAutoFormat },
	{ "Get_bForceLinearGamma", Get_bForceLinearGamma },
	{ "is_nil", wLua::LuaStatic::isnil },
	{ "__gc", wLua::LuaStatic::removeUClassFrameCache },
	{ NULL, NULL }
};

void Register(lua_State *InScriptContext)
{
	lua_newtable(InScriptContext);
	luaL_register(InScriptContext, NULL, Lib_Funcs);
	AzureHelpFuncs::AuxRegister(InScriptContext, "TextureRenderTarget2D");
}
void SetMtLink(lua_State *InScriptContext)
{
	AzureHelpFuncs::AuxSetMtLink(InScriptContext, "TextureRenderTarget2D", "TextureRenderTarget",USERDATATYPE_UOBJECT);
}

}