#include "Azure.h"
#include "Utility/help_funcs.h"
#include "wLua/UObjectHeaders.h"
#include "CineCameraComponent.h"
#include "AzureLuaIntegration.h"

namespace LuaCineCameraComponent
{
int32 SetLensPresetByName(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CineCameraComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CineCameraComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FString InPresetName;
	} Params;
	Params.InPresetName = UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 2));
#if UE_GAME
	UCineCameraComponent * This = (UCineCameraComponent *)Obj;
	This->SetLensPresetByName(Params.InPresetName);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetLensPresetByName"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FString*)(params.GetStructMemory() + 0) = Params.InPresetName;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.InPresetName = *(FString*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetFilmbackPresetByName(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CineCameraComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CineCameraComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FString InPresetName;
	} Params;
	Params.InPresetName = UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 2));
#if UE_GAME
	UCineCameraComponent * This = (UCineCameraComponent *)Obj;
	This->SetFilmbackPresetByName(Params.InPresetName);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetFilmbackPresetByName"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FString*)(params.GetStructMemory() + 0) = Params.InPresetName;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.InPresetName = *(FString*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 GetVerticalFieldOfView(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CineCameraComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CineCameraComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float ReturnValue;
	} Params;
#if UE_GAME
	UCineCameraComponent * This = (UCineCameraComponent *)Obj;
	Params.ReturnValue = This->GetVerticalFieldOfView();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetVerticalFieldOfView"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(float*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushnumber(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetLensPresetName(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CineCameraComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CineCameraComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FString ReturnValue;
	} Params;
#if UE_GAME
	UCineCameraComponent * This = (UCineCameraComponent *)Obj;
	Params.ReturnValue = This->GetLensPresetName();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetLensPresetName"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(FString*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushstring(InScriptContext, TCHAR_TO_UTF8(*Params.ReturnValue));
	return 1;
}

int32 GetHorizontalFieldOfView(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CineCameraComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CineCameraComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float ReturnValue;
	} Params;
#if UE_GAME
	UCineCameraComponent * This = (UCineCameraComponent *)Obj;
	Params.ReturnValue = This->GetHorizontalFieldOfView();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetHorizontalFieldOfView"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(float*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushnumber(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetFilmbackPresetName(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CineCameraComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CineCameraComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FString ReturnValue;
	} Params;
#if UE_GAME
	UCineCameraComponent * This = (UCineCameraComponent *)Obj;
	Params.ReturnValue = This->GetFilmbackPresetName();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetFilmbackPresetName"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(FString*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushstring(InScriptContext, TCHAR_TO_UTF8(*Params.ReturnValue));
	return 1;
}

int32 Get_CurrentFocalLength(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CineCameraComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CineCameraComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UCineCameraComponent::StaticClass(), TEXT("CurrentFocalLength"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_CurrentFocalLength(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CineCameraComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CineCameraComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UCineCameraComponent::StaticClass(), TEXT("CurrentFocalLength"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_CurrentAperture(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CineCameraComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CineCameraComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UCineCameraComponent::StaticClass(), TEXT("CurrentAperture"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_CurrentAperture(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CineCameraComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CineCameraComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UCineCameraComponent::StaticClass(), TEXT("CurrentAperture"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_CurrentFocusDistance(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CineCameraComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CineCameraComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UCineCameraComponent::StaticClass(), TEXT("CurrentFocusDistance"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_CurrentHorizontalFOV(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CineCameraComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CineCameraComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UCineCameraComponent::StaticClass(), TEXT("CurrentHorizontalFOV"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_CurrentHorizontalFOV(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CineCameraComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CineCameraComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UCineCameraComponent::StaticClass(), TEXT("CurrentHorizontalFOV"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 New(lua_State* InScriptContext)
{
	UObject* Outer = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Object");
	FName Name = FName(luaL_checkstring(InScriptContext, 2));
	UObject* Obj = NewObject<UCineCameraComponent>(Outer, Name);
	wLua::FLuaUtils::ReturnUObject(InScriptContext,Obj);
	return 1;
}

int32 Destroy(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CineCameraComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CineCameraComponent must be non-null"); lua_error(InScriptContext);  return 0;}
		UActorComponent * com = Cast<UActorComponent>(Obj);
		if(lua_isnoneornil(InScriptContext,2))
			com->DestroyComponent();
		else
			com->DestroyComponent(!!lua_toboolean(InScriptContext,2));
		userdata->flag |= wLua::LuaObjectFlag::DESTROYED;
		wLua::FLuaUtils::RemoveObjectReference(Obj, userdata->stamp, InScriptContext);
#ifdef AZURE_BUILD_WLUACHECK
		UE_LOG(LogAzure, Warning, TEXT("Destroy CineCameraComponent: %x userdata:%x   stamp:%x"),Obj,userdata,userdata->stamp);
#endif
	return 0;
}

int32 Class(lua_State* InScriptContext)
{
	UClass* Class = UCineCameraComponent::StaticClass();
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Class);
	return 1;
}

const luaL_Reg Lib_Funcs[] =
{
	{ "New", New },
	{ "Destroy", Destroy },
	{ "Class", Class },
	{ "SetLensPresetByName", SetLensPresetByName },
	{ "SetFilmbackPresetByName", SetFilmbackPresetByName },
	{ "GetVerticalFieldOfView", GetVerticalFieldOfView },
	{ "GetLensPresetName", GetLensPresetName },
	{ "GetHorizontalFieldOfView", GetHorizontalFieldOfView },
	{ "GetFilmbackPresetName", GetFilmbackPresetName },
	{ "Get_CurrentFocalLength", Get_CurrentFocalLength },
	{ "Set_CurrentFocalLength", Set_CurrentFocalLength },
	{ "Get_CurrentAperture", Get_CurrentAperture },
	{ "Set_CurrentAperture", Set_CurrentAperture },
	{ "Get_CurrentFocusDistance", Get_CurrentFocusDistance },
	{ "Get_CurrentHorizontalFOV", Get_CurrentHorizontalFOV },
	{ "Set_CurrentHorizontalFOV", Set_CurrentHorizontalFOV },
	{ "is_nil", wLua::LuaStatic::isnil },
	{ "__gc", wLua::LuaStatic::removeUClassFrameCache },
	{ NULL, NULL }
};

void Register(lua_State *InScriptContext)
{
	lua_newtable(InScriptContext);
	luaL_register(InScriptContext, NULL, Lib_Funcs);
	AzureHelpFuncs::AuxRegister(InScriptContext, "CineCameraComponent");
}
void SetMtLink(lua_State *InScriptContext)
{
	AzureHelpFuncs::AuxSetMtLink(InScriptContext, "CineCameraComponent", "CameraComponent",USERDATATYPE_UOBJECT);
}

}