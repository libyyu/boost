#include "Azure.h"
#include "Utility/help_funcs.h"
#include "wLua/UObjectHeaders.h"
#include "Components/Widget.h"
#include "AzureLuaIntegration.h"

namespace LuaWidget
{
int32 SetActive(lua_State*);
int32 GetActive(lua_State*);
int32 SetActiveAndTriggerBlueprint(lua_State*);
int32 GetName(lua_State*);
int32 FindDirect(lua_State*);
int32 GetOuterUserWidget(lua_State*);
int32 GetTopUserWidget(lua_State*);
int32 SetSlotPosition(lua_State*);
int32 GetSlotPosition(lua_State*);
int32 SetSlotAnchors(lua_State*);
int32 GetSlotAnchors(lua_State*);
int32 SetSlotOffsets(lua_State*);
int32 GetSlotOffsets(lua_State*);
int32 SetSlotAlignment(lua_State*);
int32 GetSlotAlignment(lua_State*);
int32 SetSlotSize(lua_State*);
int32 SetSlotSizeAbsolute(lua_State*);
int32 GetSlotSize(lua_State*);
int32 GetWidgetSize(lua_State*);
int32 GetWidgetSizeAbsolute(lua_State*);
int32 SetSlotPositionAbsolute(lua_State*);
int32 GetSlotPositionAbsolute(lua_State*);
int32 SetSlotPositionViewport(lua_State*);
int32 GetSlotPositionViewport(lua_State*);
int32 LocalToAbsolute(lua_State*);
int32 AbsoluteToLocal(lua_State*);
int32 LocalToAbsoluateSize(lua_State*);
int32 AbsoluteToLocalSize(lua_State*);
int32 GetRenderAngle(lua_State*);
int32 GetRenderScale(lua_State*);
int32 GetRenderTranslation(lua_State*);
int32 GetWidgetGeometrySize(lua_State*);
int32 RegisterClickNotification(lua_State*);
int32 AddEventHandler(lua_State*);
int32 RemoveAllEventHandlers(lua_State*);
int32 SetWidgetUserData(lua_State*);
int32 GetWidgetUserData(lua_State*);

int32 SetVolatileFlag(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Widget",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Widget must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		TEnumAsByte<EForceVolatileFlag::Type> InFlag;
		bool bFlagValue;
	} Params;
	Params.InFlag = (TEnumAsByte<EForceVolatileFlag::Type>)(luaL_checkint(InScriptContext, 2));
	Params.bFlagValue = !!(lua_toboolean(InScriptContext, 3));
#if UE_GAME
	UWidget * This = (UWidget *)Obj;
	This->SetVolatileFlag(Params.InFlag,Params.bFlagValue);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetVolatileFlag"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(TEnumAsByte<EForceVolatileFlag::Type>*)(params.GetStructMemory() + 0) = Params.InFlag;
		*(bool*)(params.GetStructMemory() + 1) = Params.bFlagValue;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.InFlag = *(TEnumAsByte<EForceVolatileFlag::Type>*)(params.GetStructMemory() + 0);
		Params.bFlagValue = *(bool*)(params.GetStructMemory() + 1);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetVisibilityAndTriggerBlueprint(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Widget",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Widget must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		ESlateVisibility InVisibility;
	} Params;
	Params.InVisibility = (ESlateVisibility)(luaL_checkint(InScriptContext, 2));
#if UE_GAME
	UWidget * This = (UWidget *)Obj;
	This->SetVisibilityAndTriggerBlueprint(Params.InVisibility);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetVisibilityAndTriggerBlueprint"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(ESlateVisibility*)(params.GetStructMemory() + 0) = Params.InVisibility;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.InVisibility = *(ESlateVisibility*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetVisibility(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Widget",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Widget must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		ESlateVisibility InVisibility;
	} Params;
	Params.InVisibility = (ESlateVisibility)(luaL_checkint(InScriptContext, 2));
#if UE_GAME
	UWidget * This = (UWidget *)Obj;
	This->SetVisibility(Params.InVisibility);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetVisibility"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(ESlateVisibility*)(params.GetStructMemory() + 0) = Params.InVisibility;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.InVisibility = *(ESlateVisibility*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetUserFocus(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Widget",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Widget must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		APlayerController* PlayerController = nullptr;
	} Params;
	Params.PlayerController = (APlayerController*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"PlayerController");;
#if UE_GAME
	UWidget * This = (UWidget *)Obj;
	This->SetUserFocus(Params.PlayerController);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetUserFocus"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(APlayerController**)(params.GetStructMemory() + 0) = Params.PlayerController;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.PlayerController = *(APlayerController**)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetToolTipText(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Widget",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Widget must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FText InToolTipText;
	} Params;
	Params.InToolTipText = FText::FromString(UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 2)));
#if UE_GAME
	UWidget * This = (UWidget *)Obj;
	This->SetToolTipText(Params.InToolTipText);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetToolTipText"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FText*)(params.GetStructMemory() + 0) = Params.InToolTipText;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.InToolTipText = *(FText*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetToolTip(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Widget",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Widget must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		UWidget* Widget = nullptr;
	} Params;
	Params.Widget = (UWidget*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"Widget");;
#if UE_GAME
	UWidget * This = (UWidget *)Obj;
	This->SetToolTip(Params.Widget);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetToolTip"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(UWidget**)(params.GetStructMemory() + 0) = Params.Widget;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.Widget = *(UWidget**)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetRenderTranslation(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Widget",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Widget must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FVector2D Translation;
	} Params;
	Params.Translation = (wLua::FLuaVector2D::Get(InScriptContext, 2));
#if UE_GAME
	UWidget * This = (UWidget *)Obj;
	This->SetRenderTranslation(Params.Translation);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetRenderTranslation"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FVector2D*)(params.GetStructMemory() + 0) = Params.Translation;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.Translation = *(FVector2D*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetRenderTransformPivot(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Widget",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Widget must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FVector2D Pivot;
	} Params;
	Params.Pivot = (wLua::FLuaVector2D::Get(InScriptContext, 2));
#if UE_GAME
	UWidget * This = (UWidget *)Obj;
	This->SetRenderTransformPivot(Params.Pivot);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetRenderTransformPivot"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FVector2D*)(params.GetStructMemory() + 0) = Params.Pivot;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.Pivot = *(FVector2D*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetRenderShear(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Widget",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Widget must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FVector2D Shear;
	} Params;
	Params.Shear = (wLua::FLuaVector2D::Get(InScriptContext, 2));
#if UE_GAME
	UWidget * This = (UWidget *)Obj;
	This->SetRenderShear(Params.Shear);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetRenderShear"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FVector2D*)(params.GetStructMemory() + 0) = Params.Shear;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.Shear = *(FVector2D*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetRenderScale(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Widget",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Widget must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FVector2D Scale;
	} Params;
	Params.Scale = (wLua::FLuaVector2D::Get(InScriptContext, 2));
#if UE_GAME
	UWidget * This = (UWidget *)Obj;
	This->SetRenderScale(Params.Scale);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetRenderScale"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FVector2D*)(params.GetStructMemory() + 0) = Params.Scale;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.Scale = *(FVector2D*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetRenderOpacity(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Widget",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Widget must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float InOpacity;
	} Params;
	Params.InOpacity = (float)(luaL_checknumber(InScriptContext, 2));
#if UE_GAME
	UWidget * This = (UWidget *)Obj;
	This->SetRenderOpacity(Params.InOpacity);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetRenderOpacity"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(float*)(params.GetStructMemory() + 0) = Params.InOpacity;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.InOpacity = *(float*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetRenderAngle(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Widget",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Widget must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float Angle;
	} Params;
	Params.Angle = (float)(luaL_checknumber(InScriptContext, 2));
#if UE_GAME
	UWidget * This = (UWidget *)Obj;
	This->SetRenderAngle(Params.Angle);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetRenderAngle"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(float*)(params.GetStructMemory() + 0) = Params.Angle;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.Angle = *(float*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetNavigationRule(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Widget",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Widget must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		EUINavigation Direction;
		EUINavigationRule Rule;
		FName WidgetToFocus;
	} Params;
	Params.Direction = (EUINavigation)(luaL_checkint(InScriptContext, 2));
	Params.Rule = (EUINavigationRule)(luaL_checkint(InScriptContext, 3));
	Params.WidgetToFocus = FName(UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 4)));
#if UE_GAME
	UWidget * This = (UWidget *)Obj;
	This->SetNavigationRule(Params.Direction,Params.Rule,Params.WidgetToFocus);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetNavigationRule"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(EUINavigation*)(params.GetStructMemory() + 0) = Params.Direction;
		*(EUINavigationRule*)(params.GetStructMemory() + 1) = Params.Rule;
		*(FName*)(params.GetStructMemory() + 4) = Params.WidgetToFocus;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.Direction = *(EUINavigation*)(params.GetStructMemory() + 0);
		Params.Rule = *(EUINavigationRule*)(params.GetStructMemory() + 1);
		Params.WidgetToFocus = *(FName*)(params.GetStructMemory() + 4);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetKeyboardFocus(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Widget",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Widget must be non-null"); lua_error(InScriptContext);  return 0;}
#if UE_GAME
	UWidget * This = (UWidget *)Obj;
	This->SetKeyboardFocus();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetKeyboardFocus"));
	if(!Function) { check(false); return 0;}
	Obj->ProcessEvent(Function, NULL);
#endif
	return 0;
}

int32 SetIsEnabled(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Widget",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Widget must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool bInIsEnabled;
	} Params;
	Params.bInIsEnabled = !!(lua_toboolean(InScriptContext, 2));
#if UE_GAME
	UWidget * This = (UWidget *)Obj;
	This->SetIsEnabled(Params.bInIsEnabled);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetIsEnabled"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(bool*)(params.GetStructMemory() + 0) = Params.bInIsEnabled;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.bInIsEnabled = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetCursor(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Widget",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Widget must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		TEnumAsByte<EMouseCursor::Type> InCursor;
	} Params;
	Params.InCursor = (TEnumAsByte<EMouseCursor::Type>)(luaL_checkint(InScriptContext, 2));
#if UE_GAME
	UWidget * This = (UWidget *)Obj;
	This->SetCursor(Params.InCursor);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetCursor"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(TEnumAsByte<EMouseCursor::Type>*)(params.GetStructMemory() + 0) = Params.InCursor;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.InCursor = *(TEnumAsByte<EMouseCursor::Type>*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetClippingTexture(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Widget",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Widget must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		UTexture2D* InClippintTexture = nullptr;
	} Params;
	Params.InClippintTexture = (UTexture2D*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"Texture2D");;
#if UE_GAME
	UWidget * This = (UWidget *)Obj;
	This->SetClippingTexture(Params.InClippintTexture);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetClippingTexture"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(UTexture2D**)(params.GetStructMemory() + 0) = Params.InClippintTexture;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.InClippintTexture = *(UTexture2D**)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetClippingSoftnessY(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Widget",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Widget must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float InClippingSoftness;
	} Params;
	Params.InClippingSoftness = (float)(luaL_checknumber(InScriptContext, 2));
#if UE_GAME
	UWidget * This = (UWidget *)Obj;
	This->SetClippingSoftnessY(Params.InClippingSoftness);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetClippingSoftnessY"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(float*)(params.GetStructMemory() + 0) = Params.InClippingSoftness;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.InClippingSoftness = *(float*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetClippingSoftnessX(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Widget",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Widget must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float InClippingSoftness;
	} Params;
	Params.InClippingSoftness = (float)(luaL_checknumber(InScriptContext, 2));
#if UE_GAME
	UWidget * This = (UWidget *)Obj;
	This->SetClippingSoftnessX(Params.InClippingSoftness);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetClippingSoftnessX"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(float*)(params.GetStructMemory() + 0) = Params.InClippingSoftness;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.InClippingSoftness = *(float*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetClippingSoftness(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Widget",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Widget must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FVector2D InClippingSoftness;
	} Params;
	Params.InClippingSoftness = (wLua::FLuaVector2D::Get(InScriptContext, 2));
#if UE_GAME
	UWidget * This = (UWidget *)Obj;
	This->SetClippingSoftness(Params.InClippingSoftness);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetClippingSoftness"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FVector2D*)(params.GetStructMemory() + 0) = Params.InClippingSoftness;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.InClippingSoftness = *(FVector2D*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetClipping(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Widget",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Widget must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		EWidgetClipping InClipping;
	} Params;
	Params.InClipping = (EWidgetClipping)(luaL_checkint(InScriptContext, 2));
#if UE_GAME
	UWidget * This = (UWidget *)Obj;
	This->SetClipping(Params.InClipping);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetClipping"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(EWidgetClipping*)(params.GetStructMemory() + 0) = Params.InClipping;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.InClipping = *(EWidgetClipping*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetAllNavigationRules(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Widget",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Widget must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		EUINavigationRule Rule;
		FName WidgetToFocus;
	} Params;
	Params.Rule = (EUINavigationRule)(luaL_checkint(InScriptContext, 2));
	Params.WidgetToFocus = FName(UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 3)));
#if UE_GAME
	UWidget * This = (UWidget *)Obj;
	This->SetAllNavigationRules(Params.Rule,Params.WidgetToFocus);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetAllNavigationRules"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(EUINavigationRule*)(params.GetStructMemory() + 0) = Params.Rule;
		*(FName*)(params.GetStructMemory() + 4) = Params.WidgetToFocus;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.Rule = *(EUINavigationRule*)(params.GetStructMemory() + 0);
		Params.WidgetToFocus = *(FName*)(params.GetStructMemory() + 4);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 ResetCursor(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Widget",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Widget must be non-null"); lua_error(InScriptContext);  return 0;}
#if UE_GAME
	UWidget * This = (UWidget *)Obj;
	This->ResetCursor();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("ResetCursor"));
	if(!Function) { check(false); return 0;}
	Obj->ProcessEvent(Function, NULL);
#endif
	return 0;
}

int32 RemoveFromParent(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Widget",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Widget must be non-null"); lua_error(InScriptContext);  return 0;}
#if UE_GAME
	UWidget * This = (UWidget *)Obj;
	This->RemoveFromParent();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("RemoveFromParent"));
	if(!Function) { check(false); return 0;}
	Obj->ProcessEvent(Function, NULL);
#endif
	return 0;
}

int32 IsVisible(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Widget",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Widget must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool ReturnValue;
	} Params;
#if UE_GAME
	UWidget * This = (UWidget *)Obj;
	Params.ReturnValue = This->IsVisible();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("IsVisible"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushboolean(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 IsHovered(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Widget",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Widget must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool ReturnValue;
	} Params;
#if UE_GAME
	UWidget * This = (UWidget *)Obj;
	Params.ReturnValue = This->IsHovered();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("IsHovered"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushboolean(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 IsHierarchyVisible(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Widget",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Widget must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool ReturnValue;
	} Params;
#if UE_GAME
	UWidget * This = (UWidget *)Obj;
	Params.ReturnValue = This->IsHierarchyVisible();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("IsHierarchyVisible"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushboolean(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 InvalidateLayoutAndVolatility(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Widget",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Widget must be non-null"); lua_error(InScriptContext);  return 0;}
#if UE_GAME
	UWidget * This = (UWidget *)Obj;
	This->InvalidateLayoutAndVolatility();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("InvalidateLayoutAndVolatility"));
	if(!Function) { check(false); return 0;}
	Obj->ProcessEvent(Function, NULL);
#endif
	return 0;
}

int32 HasUserFocusedDescendants(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Widget",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Widget must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		APlayerController* PlayerController = nullptr;
		bool ReturnValue;
	} Params;
	Params.PlayerController = (APlayerController*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"PlayerController");;
#if UE_GAME
	UWidget * This = (UWidget *)Obj;
	Params.ReturnValue = This->HasUserFocusedDescendants(Params.PlayerController);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("HasUserFocusedDescendants"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(APlayerController**)(params.GetStructMemory() + 0) = Params.PlayerController;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.PlayerController = *(APlayerController**)(params.GetStructMemory() + 0);
		Params.ReturnValue = *(bool*)(params.GetStructMemory() + 8);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushboolean(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 HasUserFocus(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Widget",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Widget must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		APlayerController* PlayerController = nullptr;
		bool ReturnValue;
	} Params;
	Params.PlayerController = (APlayerController*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"PlayerController");;
#if UE_GAME
	UWidget * This = (UWidget *)Obj;
	Params.ReturnValue = This->HasUserFocus(Params.PlayerController);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("HasUserFocus"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(APlayerController**)(params.GetStructMemory() + 0) = Params.PlayerController;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.PlayerController = *(APlayerController**)(params.GetStructMemory() + 0);
		Params.ReturnValue = *(bool*)(params.GetStructMemory() + 8);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushboolean(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 HasMouseCaptureByUser(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Widget",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Widget must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		int32 UserIndex;
		int32 PointerIndex;
		bool ReturnValue;
	} Params;
	Params.UserIndex = (luaL_checkint(InScriptContext, 2));
	Params.PointerIndex = lua_isnoneornil(InScriptContext,3) ? int32(-1) : (luaL_checkint(InScriptContext, 3));
#if UE_GAME
	UWidget * This = (UWidget *)Obj;
	Params.ReturnValue = This->HasMouseCaptureByUser(Params.UserIndex,Params.PointerIndex);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("HasMouseCaptureByUser"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(int32*)(params.GetStructMemory() + 0) = Params.UserIndex;
		*(int32*)(params.GetStructMemory() + 4) = Params.PointerIndex;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.UserIndex = *(int32*)(params.GetStructMemory() + 0);
		Params.PointerIndex = *(int32*)(params.GetStructMemory() + 4);
		Params.ReturnValue = *(bool*)(params.GetStructMemory() + 8);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushboolean(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 HasMouseCapture(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Widget",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Widget must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool ReturnValue;
	} Params;
#if UE_GAME
	UWidget * This = (UWidget *)Obj;
	Params.ReturnValue = This->HasMouseCapture();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("HasMouseCapture"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushboolean(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 HasKeyboardFocus(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Widget",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Widget must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool ReturnValue;
	} Params;
#if UE_GAME
	UWidget * This = (UWidget *)Obj;
	Params.ReturnValue = This->HasKeyboardFocus();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("HasKeyboardFocus"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushboolean(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 HasFocusedDescendants(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Widget",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Widget must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool ReturnValue;
	} Params;
#if UE_GAME
	UWidget * This = (UWidget *)Obj;
	Params.ReturnValue = This->HasFocusedDescendants();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("HasFocusedDescendants"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushboolean(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 HasAnyUserFocus(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Widget",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Widget must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool ReturnValue;
	} Params;
#if UE_GAME
	UWidget * This = (UWidget *)Obj;
	Params.ReturnValue = This->HasAnyUserFocus();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("HasAnyUserFocus"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushboolean(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetVisibility(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Widget",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Widget must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		ESlateVisibility ReturnValue;
	} Params;
#if UE_GAME
	UWidget * This = (UWidget *)Obj;
	Params.ReturnValue = This->GetVisibility();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetVisibility"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(ESlateVisibility*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushinteger(InScriptContext, (int)Params.ReturnValue);
	return 1;
}

int32 GetRenderOpacity(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Widget",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Widget must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float ReturnValue;
	} Params;
#if UE_GAME
	UWidget * This = (UWidget *)Obj;
	Params.ReturnValue = This->GetRenderOpacity();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetRenderOpacity"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(float*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushnumber(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetParent(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Widget",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Widget must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		UPanelWidget* ReturnValue = nullptr;
	} Params;
#if UE_GAME
	UWidget * This = (UWidget *)Obj;
	Params.ReturnValue = This->GetParent();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetParent"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(UPanelWidget**)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetOwningPlayer(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Widget",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Widget must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		APlayerController* ReturnValue = nullptr;
	} Params;
#if UE_GAME
	UWidget * This = (UWidget *)Obj;
	Params.ReturnValue = This->GetOwningPlayer();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetOwningPlayer"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(APlayerController**)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetOwningLocalPlayer(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Widget",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Widget must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		ULocalPlayer* ReturnValue = nullptr;
	} Params;
#if UE_GAME
	UWidget * This = (UWidget *)Obj;
	Params.ReturnValue = This->GetOwningLocalPlayer();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetOwningLocalPlayer"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(ULocalPlayer**)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetIsEnabled(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Widget",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Widget must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool ReturnValue;
	} Params;
#if UE_GAME
	UWidget * This = (UWidget *)Obj;
	Params.ReturnValue = This->GetIsEnabled();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetIsEnabled"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushboolean(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetDesiredSize(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Widget",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Widget must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FVector2D ReturnValue;
	} Params;
#if UE_GAME
	UWidget * This = (UWidget *)Obj;
	Params.ReturnValue = This->GetDesiredSize();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetDesiredSize"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(FVector2D*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaVector2D::Return(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetClipping(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Widget",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Widget must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		EWidgetClipping ReturnValue;
	} Params;
#if UE_GAME
	UWidget * This = (UWidget *)Obj;
	Params.ReturnValue = This->GetClipping();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetClipping"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(EWidgetClipping*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushinteger(InScriptContext, (int)Params.ReturnValue);
	return 1;
}

int32 GetBatchCountTotal(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Widget",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Widget must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		int32 ReturnValue;
	} Params;
#if UE_GAME
	UWidget * This = (UWidget *)Obj;
	Params.ReturnValue = This->GetBatchCountTotal();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetBatchCountTotal"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(int32*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushinteger(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetBatchCountSelf(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Widget",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Widget must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		int32 ReturnValue;
	} Params;
#if UE_GAME
	UWidget * This = (UWidget *)Obj;
	Params.ReturnValue = This->GetBatchCountSelf();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetBatchCountSelf"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(int32*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushinteger(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 ForceVolatile(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Widget",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Widget must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool bForce;
	} Params;
	Params.bForce = !!(lua_toboolean(InScriptContext, 2));
#if UE_GAME
	UWidget * This = (UWidget *)Obj;
	This->ForceVolatile(Params.bForce);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("ForceVolatile"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(bool*)(params.GetStructMemory() + 0) = Params.bForce;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.bForce = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 ForceLayoutPrepassWithParentScale(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Widget",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Widget must be non-null"); lua_error(InScriptContext);  return 0;}
#if UE_GAME
	UWidget * This = (UWidget *)Obj;
	This->ForceLayoutPrepassWithParentScale();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("ForceLayoutPrepassWithParentScale"));
	if(!Function) { check(false); return 0;}
	Obj->ProcessEvent(Function, NULL);
#endif
	return 0;
}

int32 ForceLayoutPrepass(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Widget",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Widget must be non-null"); lua_error(InScriptContext);  return 0;}
#if UE_GAME
	UWidget * This = (UWidget *)Obj;
	This->ForceLayoutPrepass();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("ForceLayoutPrepass"));
	if(!Function) { check(false); return 0;}
	Obj->ProcessEvent(Function, NULL);
#endif
	return 0;
}

int32 Get_Slot(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Widget",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Widget must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UWidget::StaticClass(), TEXT("Slot"));
	if(!Property) { check(false); return 0;}
	UPanelSlot* PropertyValue;
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaUtils::ReturnUObject(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_ToolTipText(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Widget",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Widget must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UWidget::StaticClass(), TEXT("ToolTipText"));
	if(!Property) { check(false); return 0;}
	FText PropertyValue;
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushstring(InScriptContext, TCHAR_TO_UTF8(*PropertyValue.ToString()));
	return 1;
}

int32 Get_ToolTipWidget(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Widget",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Widget must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UWidget::StaticClass(), TEXT("ToolTipWidget"));
	if(!Property) { check(false); return 0;}
	UWidget* PropertyValue;
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaUtils::ReturnUObject(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_RenderTransformPivot(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Widget",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Widget must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UWidget::StaticClass(), TEXT("RenderTransformPivot"));
	if(!Property) { check(false); return 0;}
	FVector2D PropertyValue = FVector2D();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaVector2D::Return(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_bIsEnabled(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Widget",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Widget must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UWidget::StaticClass(), TEXT("bIsEnabled"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_bOverride_Cursor(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Widget",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Widget must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UWidget::StaticClass(), TEXT("bOverride_Cursor"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bOverride_Cursor(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Widget",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Widget must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UWidget::StaticClass(), TEXT("bOverride_Cursor"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bIsVolatile(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Widget",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Widget must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UWidget::StaticClass(), TEXT("bIsVolatile"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_Cursor(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Widget",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Widget must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UWidget::StaticClass(), TEXT("Cursor"));
	if(!Property) { check(false); return 0;}
	TEnumAsByte<EMouseCursor::Type> PropertyValue = TEnumAsByte<EMouseCursor::Type>();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushinteger(InScriptContext, (int)PropertyValue);
	return 1;
}

int32 Get_Clipping(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Widget",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Widget must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UWidget::StaticClass(), TEXT("Clipping"));
	if(!Property) { check(false); return 0;}
	EWidgetClipping PropertyValue = EWidgetClipping();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushinteger(InScriptContext, (int)PropertyValue);
	return 1;
}

int32 Set_Clipping(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Widget",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Widget must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UWidget::StaticClass(), TEXT("Clipping"));
	if(!Property) { check(false); return 0;}
	EWidgetClipping PropertyValue = (EWidgetClipping)(luaL_checkint(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_ClippingSoftnessX(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Widget",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Widget must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UWidget::StaticClass(), TEXT("ClippingSoftnessX"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_ClippingSoftnessX(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Widget",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Widget must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UWidget::StaticClass(), TEXT("ClippingSoftnessX"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_ClippingSoftnessY(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Widget",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Widget must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UWidget::StaticClass(), TEXT("ClippingSoftnessY"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_ClippingSoftnessY(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Widget",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Widget must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UWidget::StaticClass(), TEXT("ClippingSoftnessY"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_ClippingTexture(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Widget",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Widget must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UWidget::StaticClass(), TEXT("ClippingTexture"));
	if(!Property) { check(false); return 0;}
	UTexture2D* PropertyValue;
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaUtils::ReturnUObject(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_ClippingTexture(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Widget",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Widget must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UWidget::StaticClass(), TEXT("ClippingTexture"));
	if(!Property) { check(false); return 0;}
	UTexture2D* PropertyValue = (UTexture2D*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"Texture2D");;
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_Visibility(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Widget",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Widget must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UWidget::StaticClass(), TEXT("Visibility"));
	if(!Property) { check(false); return 0;}
	ESlateVisibility PropertyValue = ESlateVisibility();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushinteger(InScriptContext, (int)PropertyValue);
	return 1;
}

int32 Set_Visibility(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Widget",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Widget must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UWidget::StaticClass(), TEXT("Visibility"));
	if(!Property) { check(false); return 0;}
	ESlateVisibility PropertyValue = (ESlateVisibility)(luaL_checkint(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_RenderOpacity(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Widget",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Widget must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UWidget::StaticClass(), TEXT("RenderOpacity"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_RenderOpacity(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Widget",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Widget must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UWidget::StaticClass(), TEXT("RenderOpacity"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_Navigation(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Widget",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Widget must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UWidget::StaticClass(), TEXT("Navigation"));
	if(!Property) { check(false); return 0;}
	UWidgetNavigation* PropertyValue;
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaUtils::ReturnUObject(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_bEvaluationChangeVisibility(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Widget",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Widget must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UWidget::StaticClass(), TEXT("bEvaluationChangeVisibility"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_EvaluationVisibility(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Widget",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Widget must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UWidget::StaticClass(), TEXT("EvaluationVisibility"));
	if(!Property) { check(false); return 0;}
	ESlateVisibility PropertyValue = ESlateVisibility();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushinteger(InScriptContext, (int)PropertyValue);
	return 1;
}

int32 Get_bEnglishChangeVisibility(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Widget",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Widget must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UWidget::StaticClass(), TEXT("bEnglishChangeVisibility"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_EnglishVisibility(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Widget",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Widget must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UWidget::StaticClass(), TEXT("EnglishVisibility"));
	if(!Property) { check(false); return 0;}
	ESlateVisibility PropertyValue = ESlateVisibility();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushinteger(InScriptContext, (int)PropertyValue);
	return 1;
}

int32 Class(lua_State* InScriptContext)
{
	UClass* Class = UWidget::StaticClass();
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Class);
	return 1;
}

const luaL_Reg Lib_Funcs[] =
{
	{ "Class", Class },
	{ "SetVolatileFlag", SetVolatileFlag },
	{ "SetVisibilityAndTriggerBlueprint", SetVisibilityAndTriggerBlueprint },
	{ "SetVisibility", SetVisibility },
	{ "SetUserFocus", SetUserFocus },
	{ "SetToolTipText", SetToolTipText },
	{ "SetToolTip", SetToolTip },
	{ "SetRenderTranslation", SetRenderTranslation },
	{ "SetRenderTransformPivot", SetRenderTransformPivot },
	{ "SetRenderShear", SetRenderShear },
	{ "SetRenderScale", SetRenderScale },
	{ "SetRenderOpacity", SetRenderOpacity },
	{ "SetRenderAngle", SetRenderAngle },
	{ "SetNavigationRule", SetNavigationRule },
	{ "SetKeyboardFocus", SetKeyboardFocus },
	{ "SetIsEnabled", SetIsEnabled },
	{ "SetCursor", SetCursor },
	{ "SetClippingTexture", SetClippingTexture },
	{ "SetClippingSoftnessY", SetClippingSoftnessY },
	{ "SetClippingSoftnessX", SetClippingSoftnessX },
	{ "SetClippingSoftness", SetClippingSoftness },
	{ "SetClipping", SetClipping },
	{ "SetAllNavigationRules", SetAllNavigationRules },
	{ "ResetCursor", ResetCursor },
	{ "RemoveFromParent", RemoveFromParent },
	{ "IsVisible", IsVisible },
	{ "IsHovered", IsHovered },
	{ "IsHierarchyVisible", IsHierarchyVisible },
	{ "InvalidateLayoutAndVolatility", InvalidateLayoutAndVolatility },
	{ "HasUserFocusedDescendants", HasUserFocusedDescendants },
	{ "HasUserFocus", HasUserFocus },
	{ "HasMouseCaptureByUser", HasMouseCaptureByUser },
	{ "HasMouseCapture", HasMouseCapture },
	{ "HasKeyboardFocus", HasKeyboardFocus },
	{ "HasFocusedDescendants", HasFocusedDescendants },
	{ "HasAnyUserFocus", HasAnyUserFocus },
	{ "GetVisibility", GetVisibility },
	{ "GetRenderOpacity", GetRenderOpacity },
	{ "GetParent", GetParent },
	{ "GetOwningPlayer", GetOwningPlayer },
	{ "GetOwningLocalPlayer", GetOwningLocalPlayer },
	{ "GetIsEnabled", GetIsEnabled },
	{ "GetDesiredSize", GetDesiredSize },
	{ "GetClipping", GetClipping },
	{ "GetBatchCountTotal", GetBatchCountTotal },
	{ "GetBatchCountSelf", GetBatchCountSelf },
	{ "ForceVolatile", ForceVolatile },
	{ "ForceLayoutPrepassWithParentScale", ForceLayoutPrepassWithParentScale },
	{ "ForceLayoutPrepass", ForceLayoutPrepass },
	{ "Get_Slot", Get_Slot },
	{ "Get_ToolTipText", Get_ToolTipText },
	{ "Get_ToolTipWidget", Get_ToolTipWidget },
	{ "Get_RenderTransformPivot", Get_RenderTransformPivot },
	{ "Get_bIsEnabled", Get_bIsEnabled },
	{ "Get_bOverride_Cursor", Get_bOverride_Cursor },
	{ "Set_bOverride_Cursor", Set_bOverride_Cursor },
	{ "Get_bIsVolatile", Get_bIsVolatile },
	{ "Get_Cursor", Get_Cursor },
	{ "Get_Clipping", Get_Clipping },
	{ "Set_Clipping", Set_Clipping },
	{ "Get_ClippingSoftnessX", Get_ClippingSoftnessX },
	{ "Set_ClippingSoftnessX", Set_ClippingSoftnessX },
	{ "Get_ClippingSoftnessY", Get_ClippingSoftnessY },
	{ "Set_ClippingSoftnessY", Set_ClippingSoftnessY },
	{ "Get_ClippingTexture", Get_ClippingTexture },
	{ "Set_ClippingTexture", Set_ClippingTexture },
	{ "Get_Visibility", Get_Visibility },
	{ "Set_Visibility", Set_Visibility },
	{ "Get_RenderOpacity", Get_RenderOpacity },
	{ "Set_RenderOpacity", Set_RenderOpacity },
	{ "Get_Navigation", Get_Navigation },
	{ "Get_bEvaluationChangeVisibility", Get_bEvaluationChangeVisibility },
	{ "Get_EvaluationVisibility", Get_EvaluationVisibility },
	{ "Get_bEnglishChangeVisibility", Get_bEnglishChangeVisibility },
	{ "Get_EnglishVisibility", Get_EnglishVisibility },
	{ "SetActive", SetActive },
	{ "GetActive", GetActive },
	{ "SetActiveAndTriggerBlueprint", SetActiveAndTriggerBlueprint },
	{ "GetName", GetName },
	{ "FindDirect", FindDirect },
	{ "GetOuterUserWidget", GetOuterUserWidget },
	{ "GetTopUserWidget", GetTopUserWidget },
	{ "SetSlotPosition", SetSlotPosition },
	{ "GetSlotPosition", GetSlotPosition },
	{ "SetSlotAnchors", SetSlotAnchors },
	{ "GetSlotAnchors", GetSlotAnchors },
	{ "SetSlotOffsets", SetSlotOffsets },
	{ "GetSlotOffsets", GetSlotOffsets },
	{ "SetSlotAlignment", SetSlotAlignment },
	{ "GetSlotAlignment", GetSlotAlignment },
	{ "SetSlotSize", SetSlotSize },
	{ "SetSlotSizeAbsolute", SetSlotSizeAbsolute },
	{ "GetSlotSize", GetSlotSize },
	{ "GetWidgetSize", GetWidgetSize },
	{ "GetWidgetSizeAbsolute", GetWidgetSizeAbsolute },
	{ "SetSlotPositionAbsolute", SetSlotPositionAbsolute },
	{ "GetSlotPositionAbsolute", GetSlotPositionAbsolute },
	{ "SetSlotPositionViewport", SetSlotPositionViewport },
	{ "GetSlotPositionViewport", GetSlotPositionViewport },
	{ "LocalToAbsolute", LocalToAbsolute },
	{ "AbsoluteToLocal", AbsoluteToLocal },
	{ "LocalToAbsoluateSize", LocalToAbsoluateSize },
	{ "AbsoluteToLocalSize", AbsoluteToLocalSize },
	{ "GetRenderAngle", GetRenderAngle },
	{ "GetRenderScale", GetRenderScale },
	{ "GetRenderTranslation", GetRenderTranslation },
	{ "GetWidgetGeometrySize", GetWidgetGeometrySize },
	{ "RegisterClickNotification", RegisterClickNotification },
	{ "AddEventHandler", AddEventHandler },
	{ "RemoveAllEventHandlers", RemoveAllEventHandlers },
	{ "SetWidgetUserData", SetWidgetUserData },
	{ "GetWidgetUserData", GetWidgetUserData },
	{ "is_nil", wLua::LuaStatic::isnil },
	{ "__gc", wLua::LuaStatic::removeUClassFrameCache },
	{ NULL, NULL }
};

void Register(lua_State *InScriptContext)
{
	lua_newtable(InScriptContext);
	luaL_register(InScriptContext, NULL, Lib_Funcs);
	AzureHelpFuncs::AuxRegister(InScriptContext, "Widget");
}
void SetMtLink(lua_State *InScriptContext)
{
	AzureHelpFuncs::AuxSetMtLink(InScriptContext, "Widget", "Visual",USERDATATYPE_UOBJECT);
}

}