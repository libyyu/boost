#include "Azure.h"
#include "Utility/help_funcs.h"
#include "wLua/UObjectHeaders.h"
#include "Particles/Emitter.h"
#include "AzureLuaIntegration.h"

namespace LuaEmitter
{
int32 OnRep_bCurrentlyActive(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Emitter",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Emitter must be non-null"); lua_error(InScriptContext);  return 0;}
#if UE_GAME
	AEmitter * This = (AEmitter *)Obj;
	This->OnRep_bCurrentlyActive();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("OnRep_bCurrentlyActive"));
	if(!Function) { check(false); return 0;}
	Obj->ProcessEvent(Function, NULL);
#endif
	return 0;
}

int32 OnParticleSystemFinished(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Emitter",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Emitter must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		UParticleSystemComponent* FinishedComponent = nullptr;
	} Params;
	Params.FinishedComponent = (UParticleSystemComponent*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"ParticleSystemComponent");;
#if UE_GAME
	AEmitter * This = (AEmitter *)Obj;
	This->OnParticleSystemFinished(Params.FinishedComponent);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("OnParticleSystemFinished"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(UParticleSystemComponent**)(params.GetStructMemory() + 0) = Params.FinishedComponent;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.FinishedComponent = *(UParticleSystemComponent**)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 Get_ParticleSystemComponent(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Emitter",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Emitter must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AEmitter::StaticClass(), TEXT("ParticleSystemComponent"));
	if(!Property) { check(false); return 0;}
	UParticleSystemComponent* PropertyValue;
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaUtils::ReturnUObject(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_bPostUpdateTickGroup(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Emitter",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Emitter must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AEmitter::StaticClass(), TEXT("bPostUpdateTickGroup"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bPostUpdateTickGroup(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Emitter",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Emitter must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AEmitter::StaticClass(), TEXT("bPostUpdateTickGroup"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Call_OnParticleSpawn(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Emitter",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Emitter must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FName EventName;
		float EmitterTime;
		FVector Location;
		FVector Velocity;
	} Params;
	Params.EventName = FName(UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 2)));
	Params.EmitterTime = (float)(luaL_checknumber(InScriptContext, 3));
	Params.Location = (wLua::FLuaVector::Get(InScriptContext, 4));
	Params.Velocity = (wLua::FLuaVector::Get(InScriptContext, 5));
	AEmitter * This = (AEmitter *)Obj;
	This->OnParticleSpawn.Broadcast(Params.EventName,Params.EmitterTime,Params.Location,Params.Velocity);
	return 0;
}

int32 Call_OnParticleBurst(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Emitter",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Emitter must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FName EventName;
		float EmitterTime;
		int32 ParticleCount;
	} Params;
	Params.EventName = FName(UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 2)));
	Params.EmitterTime = (float)(luaL_checknumber(InScriptContext, 3));
	Params.ParticleCount = (luaL_checkint(InScriptContext, 4));
	AEmitter * This = (AEmitter *)Obj;
	This->OnParticleBurst.Broadcast(Params.EventName,Params.EmitterTime,Params.ParticleCount);
	return 0;
}

int32 Call_OnParticleDeath(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Emitter",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Emitter must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FName EventName;
		float EmitterTime;
		int32 ParticleTime;
		FVector Location;
		FVector Velocity;
		FVector Direction;
	} Params;
	Params.EventName = FName(UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 2)));
	Params.EmitterTime = (float)(luaL_checknumber(InScriptContext, 3));
	Params.ParticleTime = (luaL_checkint(InScriptContext, 4));
	Params.Location = (wLua::FLuaVector::Get(InScriptContext, 5));
	Params.Velocity = (wLua::FLuaVector::Get(InScriptContext, 6));
	Params.Direction = (wLua::FLuaVector::Get(InScriptContext, 7));
	AEmitter * This = (AEmitter *)Obj;
	This->OnParticleDeath.Broadcast(Params.EventName,Params.EmitterTime,Params.ParticleTime,Params.Location,Params.Velocity,Params.Direction);
	return 0;
}

int32 Call_OnParticleCollide(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Emitter",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Emitter must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FName EventName;
		float EmitterTime;
		int32 ParticleTime;
		FVector Location;
		FVector Velocity;
		FVector Direction;
		FVector Normal;
		FName BoneName;
		UPhysicalMaterial* PhysMat = nullptr;
	} Params;
	Params.EventName = FName(UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 2)));
	Params.EmitterTime = (float)(luaL_checknumber(InScriptContext, 3));
	Params.ParticleTime = (luaL_checkint(InScriptContext, 4));
	Params.Location = (wLua::FLuaVector::Get(InScriptContext, 5));
	Params.Velocity = (wLua::FLuaVector::Get(InScriptContext, 6));
	Params.Direction = (wLua::FLuaVector::Get(InScriptContext, 7));
	Params.Normal = (wLua::FLuaVector::Get(InScriptContext, 8));
	Params.BoneName = FName(UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 9)));
	Params.PhysMat = (UPhysicalMaterial*)wLua::FLuaUtils::GetUObject(InScriptContext,10,"PhysicalMaterial");;
	AEmitter * This = (AEmitter *)Obj;
	This->OnParticleCollide.Broadcast(Params.EventName,Params.EmitterTime,Params.ParticleTime,Params.Location,Params.Velocity,Params.Direction,Params.Normal,Params.BoneName,Params.PhysMat);
	return 0;
}

int32 New(lua_State* InScriptContext)
{
	UObject* Outer = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Object");
	FName Name = FName(luaL_checkstring(InScriptContext, 2));
	UObject* Obj = NewObject<AEmitter>(Outer, Name);
	wLua::FLuaUtils::ReturnUObject(InScriptContext,Obj);
	return 1;
}

int32 Destroy(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Emitter",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Emitter must be non-null"); lua_error(InScriptContext);  return 0;}
		AActor * actor = Cast<AActor>(Obj);
		actor->Destroy();
		userdata->flag |= wLua::LuaObjectFlag::DESTROYED;
		wLua::FLuaUtils::RemoveObjectReference(Obj, userdata->stamp, InScriptContext);
#ifdef AZURE_BUILD_WLUACHECK
		UE_LOG(LogAzure, Warning, TEXT("Destroy Emitter: %x userdata:%x   stamp:%x"),Obj,userdata,userdata->stamp);
#endif
	return 0;
}

int32 Class(lua_State* InScriptContext)
{
	UClass* Class = AEmitter::StaticClass();
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Class);
	return 1;
}

const luaL_Reg Lib_Funcs[] =
{
	{ "New", New },
	{ "Destroy", Destroy },
	{ "Class", Class },
	{ "OnRep_bCurrentlyActive", OnRep_bCurrentlyActive },
	{ "OnParticleSystemFinished", OnParticleSystemFinished },
	{ "Get_ParticleSystemComponent", Get_ParticleSystemComponent },
	{ "Get_bPostUpdateTickGroup", Get_bPostUpdateTickGroup },
	{ "Set_bPostUpdateTickGroup", Set_bPostUpdateTickGroup },
	{ "Call_OnParticleSpawn", Call_OnParticleSpawn },
	{ "Call_OnParticleBurst", Call_OnParticleBurst },
	{ "Call_OnParticleDeath", Call_OnParticleDeath },
	{ "Call_OnParticleCollide", Call_OnParticleCollide },
	{ "is_nil", wLua::LuaStatic::isnil },
	{ "__gc", wLua::LuaStatic::removeUClassFrameCache },
	{ NULL, NULL }
};

void Register(lua_State *InScriptContext)
{
	lua_newtable(InScriptContext);
	luaL_register(InScriptContext, NULL, Lib_Funcs);
	AzureHelpFuncs::AuxRegister(InScriptContext, "Emitter");
}
void SetMtLink(lua_State *InScriptContext)
{
	AzureHelpFuncs::AuxSetMtLink(InScriptContext, "Emitter", "Actor",USERDATATYPE_UOBJECT);
}

}