#include "Azure.h"
#include "Utility/help_funcs.h"
#include "wLua/UObjectHeaders.h"
#include "AzureBarChart.h"
#include "AzureLuaIntegration.h"

namespace LuaAzureBarChart
{
int32 SetValueRange(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureBarChart",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureBarChart must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		int32 InMin;
		int32 InMax;
	} Params;
	Params.InMin = (luaL_checkint(InScriptContext, 2));
	Params.InMax = (luaL_checkint(InScriptContext, 3));
#if UE_GAME
	UAzureBarChart * This = (UAzureBarChart *)Obj;
	This->SetValueRange(Params.InMin,Params.InMax);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetValueRange"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(int32*)(params.GetStructMemory() + 0) = Params.InMin;
		*(int32*)(params.GetStructMemory() + 4) = Params.InMax;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.InMin = *(int32*)(params.GetStructMemory() + 0);
		Params.InMax = *(int32*)(params.GetStructMemory() + 4);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetValueAndString(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureBarChart",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureBarChart must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		int32 InIndex;
		int32 InValue;
		FString InValueString;
	} Params;
	Params.InIndex = (luaL_checkint(InScriptContext, 2));
	Params.InValue = (luaL_checkint(InScriptContext, 3));
	Params.InValueString = UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 4));
#if UE_GAME
	UAzureBarChart * This = (UAzureBarChart *)Obj;
	This->SetValueAndString(Params.InIndex,Params.InValue,Params.InValueString);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetValueAndString"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(int32*)(params.GetStructMemory() + 0) = Params.InIndex;
		*(int32*)(params.GetStructMemory() + 4) = Params.InValue;
		*(FString*)(params.GetStructMemory() + 8) = Params.InValueString;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.InIndex = *(int32*)(params.GetStructMemory() + 0);
		Params.InValue = *(int32*)(params.GetStructMemory() + 4);
		Params.InValueString = *(FString*)(params.GetStructMemory() + 8);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetValue(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureBarChart",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureBarChart must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		int32 InIndex;
		int32 InValue;
	} Params;
	Params.InIndex = (luaL_checkint(InScriptContext, 2));
	Params.InValue = (luaL_checkint(InScriptContext, 3));
#if UE_GAME
	UAzureBarChart * This = (UAzureBarChart *)Obj;
	This->SetValue(Params.InIndex,Params.InValue);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetValue"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(int32*)(params.GetStructMemory() + 0) = Params.InIndex;
		*(int32*)(params.GetStructMemory() + 4) = Params.InValue;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.InIndex = *(int32*)(params.GetStructMemory() + 0);
		Params.InValue = *(int32*)(params.GetStructMemory() + 4);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 GetValue(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureBarChart",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureBarChart must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		int32 InIndex;
		int32 ReturnValue;
	} Params;
	Params.InIndex = (luaL_checkint(InScriptContext, 2));
#if UE_GAME
	UAzureBarChart * This = (UAzureBarChart *)Obj;
	Params.ReturnValue = This->GetValue(Params.InIndex);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetValue"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(int32*)(params.GetStructMemory() + 0) = Params.InIndex;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.InIndex = *(int32*)(params.GetStructMemory() + 0);
		Params.ReturnValue = *(int32*)(params.GetStructMemory() + 4);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushinteger(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 Get_BarNumber(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureBarChart",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureBarChart must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzureBarChart::StaticClass(), TEXT("BarNumber"));
	if(!Property) { check(false); return 0;}
	int32 PropertyValue = int32();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushinteger(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_BarSize(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureBarChart",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureBarChart must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzureBarChart::StaticClass(), TEXT("BarSize"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_MinValue(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureBarChart",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureBarChart must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzureBarChart::StaticClass(), TEXT("MinValue"));
	if(!Property) { check(false); return 0;}
	int32 PropertyValue = int32();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushinteger(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_MaxValue(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureBarChart",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureBarChart must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzureBarChart::StaticClass(), TEXT("MaxValue"));
	if(!Property) { check(false); return 0;}
	int32 PropertyValue = int32();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushinteger(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_ValueGap(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureBarChart",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureBarChart must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzureBarChart::StaticClass(), TEXT("ValueGap"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_DesiredSize(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureBarChart",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureBarChart must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzureBarChart::StaticClass(), TEXT("DesiredSize"));
	if(!Property) { check(false); return 0;}
	FVector2D PropertyValue = FVector2D();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaVector2D::Return(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_IsVertical(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureBarChart",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureBarChart must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzureBarChart::StaticClass(), TEXT("IsVertical"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = bool();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_IsUpsidedown(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureBarChart",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureBarChart must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzureBarChart::StaticClass(), TEXT("IsUpsidedown"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = bool();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 New(lua_State* InScriptContext)
{
	UObject* Outer = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Object");
	FName Name = FName(luaL_checkstring(InScriptContext, 2));
	UObject* Obj = NewObject<UAzureBarChart>(Outer, Name);
	wLua::FLuaUtils::ReturnUObject(InScriptContext,Obj);
	return 1;
}

int32 Destroy(lua_State* InScriptContext)
{
	return 0;
}

int32 Class(lua_State* InScriptContext)
{
	UClass* Class = UAzureBarChart::StaticClass();
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Class);
	return 1;
}

const luaL_Reg Lib_Funcs[] =
{
	{ "New", New },
	{ "Destroy", Destroy },
	{ "Class", Class },
	{ "SetValueRange", SetValueRange },
	{ "SetValueAndString", SetValueAndString },
	{ "SetValue", SetValue },
	{ "GetValue", GetValue },
	{ "Get_BarNumber", Get_BarNumber },
	{ "Get_BarSize", Get_BarSize },
	{ "Get_MinValue", Get_MinValue },
	{ "Get_MaxValue", Get_MaxValue },
	{ "Get_ValueGap", Get_ValueGap },
	{ "Get_DesiredSize", Get_DesiredSize },
	{ "Get_IsVertical", Get_IsVertical },
	{ "Get_IsUpsidedown", Get_IsUpsidedown },
	{ "is_nil", wLua::LuaStatic::isnil },
	{ "__gc", wLua::LuaStatic::removeUClassFrameCache },
	{ NULL, NULL }
};

void Register(lua_State *InScriptContext)
{
	lua_newtable(InScriptContext);
	luaL_register(InScriptContext, NULL, Lib_Funcs);
	AzureHelpFuncs::AuxRegister(InScriptContext, "AzureBarChart");
}
void SetMtLink(lua_State *InScriptContext)
{
	AzureHelpFuncs::AuxSetMtLink(InScriptContext, "AzureBarChart", "Widget",USERDATATYPE_UOBJECT);
}

}