#include "Azure.h"
#include "Utility/help_funcs.h"
#include "wLua/UObjectHeaders.h"
#include "GameLogic/Environment/Grass/GrassMower.h"
#include "AzureLuaIntegration.h"

namespace LuaGrassMower
{
int32 SetFocusPosition(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"GrassMower",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"GrassMower must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FVector WorldPosition;
		FVector4 ReturnValue;
	} Params;
	Params.WorldPosition = (wLua::FLuaVector::Get(InScriptContext, 2));
#if UE_GAME
	AGrassMower * This = (AGrassMower *)Obj;
	Params.ReturnValue = This->SetFocusPosition(Params.WorldPosition);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetFocusPosition"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FVector*)(params.GetStructMemory() + 0) = Params.WorldPosition;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.WorldPosition = *(FVector*)(params.GetStructMemory() + 0);
		Params.ReturnValue = *(FVector4*)(params.GetStructMemory() + 16);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaVector4::Return(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 Paint(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"GrassMower",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"GrassMower must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FVector WorldPosition;
		int32 StampID;
		FVector Size;
		FVector Direction;
		int32 Mode;
	} Params;
	Params.WorldPosition = (wLua::FLuaVector::Get(InScriptContext, 2));
	Params.StampID = (luaL_checkint(InScriptContext, 3));
	Params.Size = (wLua::FLuaVector::Get(InScriptContext, 4));
	Params.Direction = (wLua::FLuaVector::Get(InScriptContext, 5));
	Params.Mode = (luaL_checkint(InScriptContext, 6));
#if UE_GAME
	AGrassMower * This = (AGrassMower *)Obj;
	This->Paint(Params.WorldPosition,Params.StampID,Params.Size,Params.Direction,Params.Mode);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("Paint"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FVector*)(params.GetStructMemory() + 0) = Params.WorldPosition;
		*(int32*)(params.GetStructMemory() + 12) = Params.StampID;
		*(FVector*)(params.GetStructMemory() + 16) = Params.Size;
		*(FVector*)(params.GetStructMemory() + 28) = Params.Direction;
		*(int32*)(params.GetStructMemory() + 40) = Params.Mode;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.WorldPosition = *(FVector*)(params.GetStructMemory() + 0);
		Params.StampID = *(int32*)(params.GetStructMemory() + 12);
		Params.Size = *(FVector*)(params.GetStructMemory() + 16);
		Params.Direction = *(FVector*)(params.GetStructMemory() + 28);
		Params.Mode = *(int32*)(params.GetStructMemory() + 40);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 ClearAll(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"GrassMower",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"GrassMower must be non-null"); lua_error(InScriptContext);  return 0;}
#if UE_GAME
	AGrassMower * This = (AGrassMower *)Obj;
	This->ClearAll();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("ClearAll"));
	if(!Function) { check(false); return 0;}
	Obj->ProcessEvent(Function, NULL);
#endif
	return 0;
}

int32 ApplyMaterials(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"GrassMower",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"GrassMower must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		TArray<UMaterialInstanceDynamic*> Materials;
	} Params;
	Params.Materials = [](lua_State * _InScriptContext){ TArray<UMaterialInstanceDynamic*> ret; lua_pushnil(_InScriptContext); while(lua_next(_InScriptContext,2)!=0){ UMaterialInstanceDynamic* item = (UMaterialInstanceDynamic*)wLua::FLuaUtils::GetUObject(_InScriptContext,-1,"MaterialInstanceDynamic");; ret.Add(item); lua_pop(_InScriptContext,1);  } return ret; }(InScriptContext);;
#if UE_GAME
	AGrassMower * This = (AGrassMower *)Obj;
	This->ApplyMaterials(Params.Materials);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("ApplyMaterials"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(TArray<UMaterialInstanceDynamic*>*)(params.GetStructMemory() + 0) = Params.Materials;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.Materials = *(TArray<UMaterialInstanceDynamic*>*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 New(lua_State* InScriptContext)
{
	UObject* Outer = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Object");
	FName Name = FName(luaL_checkstring(InScriptContext, 2));
	UObject* Obj = NewObject<AGrassMower>(Outer, Name);
	wLua::FLuaUtils::ReturnUObject(InScriptContext,Obj);
	return 1;
}

int32 Destroy(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"GrassMower",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"GrassMower must be non-null"); lua_error(InScriptContext);  return 0;}
		AActor * actor = Cast<AActor>(Obj);
		actor->Destroy();
		userdata->flag |= wLua::LuaObjectFlag::DESTROYED;
		wLua::FLuaUtils::RemoveObjectReference(Obj, userdata->stamp, InScriptContext);
#ifdef AZURE_BUILD_WLUACHECK
		UE_LOG(LogAzure, Warning, TEXT("Destroy GrassMower: %x userdata:%x   stamp:%x"),Obj,userdata,userdata->stamp);
#endif
	return 0;
}

int32 Class(lua_State* InScriptContext)
{
	UClass* Class = AGrassMower::StaticClass();
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Class);
	return 1;
}

const luaL_Reg Lib_Funcs[] =
{
	{ "New", New },
	{ "Destroy", Destroy },
	{ "Class", Class },
	{ "SetFocusPosition", SetFocusPosition },
	{ "Paint", Paint },
	{ "ClearAll", ClearAll },
	{ "ApplyMaterials", ApplyMaterials },
	{ "is_nil", wLua::LuaStatic::isnil },
	{ "__gc", wLua::LuaStatic::removeUClassFrameCache },
	{ NULL, NULL }
};

void Register(lua_State *InScriptContext)
{
	lua_newtable(InScriptContext);
	luaL_register(InScriptContext, NULL, Lib_Funcs);
	AzureHelpFuncs::AuxRegister(InScriptContext, "GrassMower");
}
void SetMtLink(lua_State *InScriptContext)
{
	AzureHelpFuncs::AuxSetMtLink(InScriptContext, "GrassMower", "Actor",USERDATATYPE_UOBJECT);
}

}