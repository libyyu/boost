#include "Azure.h"
#include "Utility/help_funcs.h"
#include "wLua/UObjectHeaders.h"
#include "Components/SceneComponent.h"
#include "AzureLuaIntegration.h"

namespace LuaSceneComponent
{
int32 GetComponentLocationSplit(lua_State*);
int32 GetComponentRotationSplit(lua_State*);
int32 SetupAttachment(lua_State*);
int32 SetRelativeLocation(lua_State*);
int32 SetRelativeRotation(lua_State*);
int32 SetRelativeLocationAndRotation(lua_State*);
int32 SocketTransformPoint(lua_State*);
int32 SocketTransformRotator(lua_State*);
int32 SetWorldLocation(lua_State*);
int32 SetWorldRotation(lua_State*);
int32 SetHiddenIngame(lua_State*);
int32 SetComponentToWorld(lua_State*);
int32 GetComponentToWorld(lua_State*);
int32 GetAttachChildCount(lua_State*);
int32 GetAttachChild(lua_State*);
int32 UpdateCompOverlaps(lua_State*);

int32 ToggleVisibility(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SceneComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SceneComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool bPropagateToChildren;
	} Params;
	Params.bPropagateToChildren = lua_isnoneornil(InScriptContext,2) ? bool(false) : !!(lua_toboolean(InScriptContext, 2));
#if UE_GAME
	USceneComponent * This = (USceneComponent *)Obj;
	This->ToggleVisibility(Params.bPropagateToChildren);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("ToggleVisibility"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(bool*)(params.GetStructMemory() + 0) = Params.bPropagateToChildren;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.bPropagateToChildren = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetWorldScale3D(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SceneComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SceneComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FVector NewScale;
	} Params;
	Params.NewScale = (wLua::FLuaVector::Get(InScriptContext, 2));
#if UE_GAME
	USceneComponent * This = (USceneComponent *)Obj;
	This->SetWorldScale3D(Params.NewScale);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetWorldScale3D"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FVector*)(params.GetStructMemory() + 0) = Params.NewScale;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.NewScale = *(FVector*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetVisibility(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SceneComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SceneComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool bNewVisibility;
		bool bPropagateToChildren;
	} Params;
	Params.bNewVisibility = !!(lua_toboolean(InScriptContext, 2));
	Params.bPropagateToChildren = lua_isnoneornil(InScriptContext,3) ? bool(false) : !!(lua_toboolean(InScriptContext, 3));
#if UE_GAME
	USceneComponent * This = (USceneComponent *)Obj;
	This->SetVisibility(Params.bNewVisibility,Params.bPropagateToChildren);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetVisibility"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(bool*)(params.GetStructMemory() + 0) = Params.bNewVisibility;
		*(bool*)(params.GetStructMemory() + 1) = Params.bPropagateToChildren;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.bNewVisibility = *(bool*)(params.GetStructMemory() + 0);
		Params.bPropagateToChildren = *(bool*)(params.GetStructMemory() + 1);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetShouldUpdatePhysicsVolume(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SceneComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SceneComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool bInShouldUpdatePhysicsVolume;
	} Params;
	Params.bInShouldUpdatePhysicsVolume = !!(lua_toboolean(InScriptContext, 2));
#if UE_GAME
	USceneComponent * This = (USceneComponent *)Obj;
	This->SetShouldUpdatePhysicsVolume(Params.bInShouldUpdatePhysicsVolume);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetShouldUpdatePhysicsVolume"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(bool*)(params.GetStructMemory() + 0) = Params.bInShouldUpdatePhysicsVolume;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.bInShouldUpdatePhysicsVolume = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetRelativeScale3D(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SceneComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SceneComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FVector NewScale3D;
	} Params;
	Params.NewScale3D = (wLua::FLuaVector::Get(InScriptContext, 2));
#if UE_GAME
	USceneComponent * This = (USceneComponent *)Obj;
	This->SetRelativeScale3D(Params.NewScale3D);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetRelativeScale3D"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FVector*)(params.GetStructMemory() + 0) = Params.NewScale3D;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.NewScale3D = *(FVector*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetMobility(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SceneComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SceneComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		TEnumAsByte<EComponentMobility::Type> NewMobility;
	} Params;
	Params.NewMobility = (TEnumAsByte<EComponentMobility::Type>)(luaL_checkint(InScriptContext, 2));
#if UE_GAME
	USceneComponent * This = (USceneComponent *)Obj;
	This->SetMobility(Params.NewMobility);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetMobility"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(TEnumAsByte<EComponentMobility::Type>*)(params.GetStructMemory() + 0) = Params.NewMobility;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.NewMobility = *(TEnumAsByte<EComponentMobility::Type>*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetHiddenInGame(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SceneComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SceneComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool NewHidden;
		bool bPropagateToChildren;
	} Params;
	Params.NewHidden = !!(lua_toboolean(InScriptContext, 2));
	Params.bPropagateToChildren = lua_isnoneornil(InScriptContext,3) ? bool(false) : !!(lua_toboolean(InScriptContext, 3));
#if UE_GAME
	USceneComponent * This = (USceneComponent *)Obj;
	This->SetHiddenInGame(Params.NewHidden,Params.bPropagateToChildren);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetHiddenInGame"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(bool*)(params.GetStructMemory() + 0) = Params.NewHidden;
		*(bool*)(params.GetStructMemory() + 1) = Params.bPropagateToChildren;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.NewHidden = *(bool*)(params.GetStructMemory() + 0);
		Params.bPropagateToChildren = *(bool*)(params.GetStructMemory() + 1);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetAbsolute(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SceneComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SceneComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool bNewAbsoluteLocation;
		bool bNewAbsoluteRotation;
		bool bNewAbsoluteScale;
	} Params;
	Params.bNewAbsoluteLocation = lua_isnoneornil(InScriptContext,2) ? bool(false) : !!(lua_toboolean(InScriptContext, 2));
	Params.bNewAbsoluteRotation = lua_isnoneornil(InScriptContext,3) ? bool(false) : !!(lua_toboolean(InScriptContext, 3));
	Params.bNewAbsoluteScale = lua_isnoneornil(InScriptContext,4) ? bool(false) : !!(lua_toboolean(InScriptContext, 4));
#if UE_GAME
	USceneComponent * This = (USceneComponent *)Obj;
	This->SetAbsolute(Params.bNewAbsoluteLocation,Params.bNewAbsoluteRotation,Params.bNewAbsoluteScale);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetAbsolute"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(bool*)(params.GetStructMemory() + 0) = Params.bNewAbsoluteLocation;
		*(bool*)(params.GetStructMemory() + 1) = Params.bNewAbsoluteRotation;
		*(bool*)(params.GetStructMemory() + 2) = Params.bNewAbsoluteScale;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.bNewAbsoluteLocation = *(bool*)(params.GetStructMemory() + 0);
		Params.bNewAbsoluteRotation = *(bool*)(params.GetStructMemory() + 1);
		Params.bNewAbsoluteScale = *(bool*)(params.GetStructMemory() + 2);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 ResetRelativeTransform(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SceneComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SceneComponent must be non-null"); lua_error(InScriptContext);  return 0;}
#if UE_GAME
	USceneComponent * This = (USceneComponent *)Obj;
	This->ResetRelativeTransform();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("ResetRelativeTransform"));
	if(!Function) { check(false); return 0;}
	Obj->ProcessEvent(Function, NULL);
#endif
	return 0;
}

int32 OnRep_Visibility(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SceneComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SceneComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool OldValue;
	} Params;
	Params.OldValue = !!(lua_toboolean(InScriptContext, 2));
	UFunction* Function = Obj->FindFunctionChecked(TEXT("OnRep_Visibility"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(bool*)(params.GetStructMemory() + 0) = Params.OldValue;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.OldValue = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
	return 0;
}

int32 OnRep_Transform(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SceneComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SceneComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	UFunction* Function = Obj->FindFunctionChecked(TEXT("OnRep_Transform"));
	if(!Function) { check(false); return 0;}
	Obj->ProcessEvent(Function, NULL);
	return 0;
}

int32 OnRep_AttachSocketName(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SceneComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SceneComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	UFunction* Function = Obj->FindFunctionChecked(TEXT("OnRep_AttachSocketName"));
	if(!Function) { check(false); return 0;}
	Obj->ProcessEvent(Function, NULL);
	return 0;
}

int32 OnRep_AttachParent(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SceneComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SceneComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	UFunction* Function = Obj->FindFunctionChecked(TEXT("OnRep_AttachParent"));
	if(!Function) { check(false); return 0;}
	Obj->ProcessEvent(Function, NULL);
	return 0;
}

int32 OnRep_AttachChildren(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SceneComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SceneComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	UFunction* Function = Obj->FindFunctionChecked(TEXT("OnRep_AttachChildren"));
	if(!Function) { check(false); return 0;}
	Obj->ProcessEvent(Function, NULL);
	return 0;
}

int32 K2_GetComponentToWorld(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SceneComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SceneComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FTransform ReturnValue;
	} Params;
#if UE_GAME
	USceneComponent * This = (USceneComponent *)Obj;
	Params.ReturnValue = This->K2_GetComponentToWorld();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("K2_GetComponentToWorld"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(FTransform*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaTransform::Return(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 K2_GetComponentScale(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SceneComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SceneComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FVector ReturnValue;
	} Params;
#if UE_GAME
	USceneComponent * This = (USceneComponent *)Obj;
	Params.ReturnValue = This->K2_GetComponentScale();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("K2_GetComponentScale"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(FVector*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaVector::Return(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 K2_GetComponentRotation(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SceneComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SceneComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FRotator ReturnValue;
	} Params;
#if UE_GAME
	USceneComponent * This = (USceneComponent *)Obj;
	Params.ReturnValue = This->K2_GetComponentRotation();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("K2_GetComponentRotation"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(FRotator*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaRotator::Return(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 K2_GetComponentLocation(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SceneComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SceneComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FVector ReturnValue;
	} Params;
#if UE_GAME
	USceneComponent * This = (USceneComponent *)Obj;
	Params.ReturnValue = This->K2_GetComponentLocation();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("K2_GetComponentLocation"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(FVector*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaVector::Return(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 K2_DetachFromComponent(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SceneComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SceneComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		EDetachmentRule LocationRule;
		EDetachmentRule RotationRule;
		EDetachmentRule ScaleRule;
		bool bCallModify;
	} Params;
	Params.LocationRule = lua_isnoneornil(InScriptContext,2) ? EDetachmentRule(EDetachmentRule::KeepRelative) : (EDetachmentRule)(luaL_checkint(InScriptContext, 2));
	Params.RotationRule = lua_isnoneornil(InScriptContext,3) ? EDetachmentRule(EDetachmentRule::KeepRelative) : (EDetachmentRule)(luaL_checkint(InScriptContext, 3));
	Params.ScaleRule = lua_isnoneornil(InScriptContext,4) ? EDetachmentRule(EDetachmentRule::KeepRelative) : (EDetachmentRule)(luaL_checkint(InScriptContext, 4));
	Params.bCallModify = lua_isnoneornil(InScriptContext,5) ? bool(true) : !!(lua_toboolean(InScriptContext, 5));
#if UE_GAME
	USceneComponent * This = (USceneComponent *)Obj;
	This->K2_DetachFromComponent(Params.LocationRule,Params.RotationRule,Params.ScaleRule,Params.bCallModify);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("K2_DetachFromComponent"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(EDetachmentRule*)(params.GetStructMemory() + 0) = Params.LocationRule;
		*(EDetachmentRule*)(params.GetStructMemory() + 1) = Params.RotationRule;
		*(EDetachmentRule*)(params.GetStructMemory() + 2) = Params.ScaleRule;
		*(bool*)(params.GetStructMemory() + 3) = Params.bCallModify;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.LocationRule = *(EDetachmentRule*)(params.GetStructMemory() + 0);
		Params.RotationRule = *(EDetachmentRule*)(params.GetStructMemory() + 1);
		Params.ScaleRule = *(EDetachmentRule*)(params.GetStructMemory() + 2);
		Params.bCallModify = *(bool*)(params.GetStructMemory() + 3);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 K2_AttachToComponent(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SceneComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SceneComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		USceneComponent* Parent = nullptr;
		FName SocketName;
		EAttachmentRule LocationRule;
		EAttachmentRule RotationRule;
		EAttachmentRule ScaleRule;
		bool bWeldSimulatedBodies;
		bool ReturnValue;
	} Params;
	Params.Parent = (USceneComponent*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"SceneComponent");;
	Params.SocketName = FName(UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 3)));
	Params.LocationRule = (EAttachmentRule)(luaL_checkint(InScriptContext, 4));
	Params.RotationRule = (EAttachmentRule)(luaL_checkint(InScriptContext, 5));
	Params.ScaleRule = (EAttachmentRule)(luaL_checkint(InScriptContext, 6));
	Params.bWeldSimulatedBodies = !!(lua_toboolean(InScriptContext, 7));
#if UE_GAME
	USceneComponent * This = (USceneComponent *)Obj;
	Params.ReturnValue = This->K2_AttachToComponent(Params.Parent,Params.SocketName,Params.LocationRule,Params.RotationRule,Params.ScaleRule,Params.bWeldSimulatedBodies);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("K2_AttachToComponent"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(USceneComponent**)(params.GetStructMemory() + 0) = Params.Parent;
		*(FName*)(params.GetStructMemory() + 8) = Params.SocketName;
		*(EAttachmentRule*)(params.GetStructMemory() + 20) = Params.LocationRule;
		*(EAttachmentRule*)(params.GetStructMemory() + 21) = Params.RotationRule;
		*(EAttachmentRule*)(params.GetStructMemory() + 22) = Params.ScaleRule;
		*(bool*)(params.GetStructMemory() + 23) = Params.bWeldSimulatedBodies;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.Parent = *(USceneComponent**)(params.GetStructMemory() + 0);
		Params.SocketName = *(FName*)(params.GetStructMemory() + 8);
		Params.LocationRule = *(EAttachmentRule*)(params.GetStructMemory() + 20);
		Params.RotationRule = *(EAttachmentRule*)(params.GetStructMemory() + 21);
		Params.ScaleRule = *(EAttachmentRule*)(params.GetStructMemory() + 22);
		Params.bWeldSimulatedBodies = *(bool*)(params.GetStructMemory() + 23);
		Params.ReturnValue = *(bool*)(params.GetStructMemory() + 24);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushboolean(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 K2_AttachTo(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SceneComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SceneComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		USceneComponent* InParent = nullptr;
		FName InSocketName;
		TEnumAsByte<EAttachLocation::Type> AttachType;
		bool bWeldSimulatedBodies;
		bool ReturnValue;
	} Params;
	Params.InParent = (USceneComponent*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"SceneComponent");;
	Params.InSocketName = lua_isnoneornil(InScriptContext,3) ? FName(TEXT("")) : FName(UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 3)));
	Params.AttachType = lua_isnoneornil(InScriptContext,4) ? TEnumAsByte<EAttachLocation::Type>(EAttachLocation::Type::KeepRelativeOffset) : (TEnumAsByte<EAttachLocation::Type>)(luaL_checkint(InScriptContext, 4));
	Params.bWeldSimulatedBodies = lua_isnoneornil(InScriptContext,5) ? bool(true) : !!(lua_toboolean(InScriptContext, 5));
#if UE_GAME
	USceneComponent * This = (USceneComponent *)Obj;
	Params.ReturnValue = This->K2_AttachTo(Params.InParent,Params.InSocketName,Params.AttachType,Params.bWeldSimulatedBodies);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("K2_AttachTo"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(USceneComponent**)(params.GetStructMemory() + 0) = Params.InParent;
		*(FName*)(params.GetStructMemory() + 8) = Params.InSocketName;
		*(TEnumAsByte<EAttachLocation::Type>*)(params.GetStructMemory() + 20) = Params.AttachType;
		*(bool*)(params.GetStructMemory() + 21) = Params.bWeldSimulatedBodies;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.InParent = *(USceneComponent**)(params.GetStructMemory() + 0);
		Params.InSocketName = *(FName*)(params.GetStructMemory() + 8);
		Params.AttachType = *(TEnumAsByte<EAttachLocation::Type>*)(params.GetStructMemory() + 20);
		Params.bWeldSimulatedBodies = *(bool*)(params.GetStructMemory() + 21);
		Params.ReturnValue = *(bool*)(params.GetStructMemory() + 22);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushboolean(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 IsVisible(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SceneComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SceneComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool ReturnValue;
	} Params;
#if UE_GAME
	USceneComponent * This = (USceneComponent *)Obj;
	Params.ReturnValue = This->IsVisible();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("IsVisible"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushboolean(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 IsSimulatingPhysics(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SceneComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SceneComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FName BoneName;
		bool ReturnValue;
	} Params;
	Params.BoneName = lua_isnoneornil(InScriptContext,2) ? FName(TEXT("")) : FName(UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 2)));
#if UE_GAME
	USceneComponent * This = (USceneComponent *)Obj;
	Params.ReturnValue = This->IsSimulatingPhysics(Params.BoneName);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("IsSimulatingPhysics"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FName*)(params.GetStructMemory() + 0) = Params.BoneName;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.BoneName = *(FName*)(params.GetStructMemory() + 0);
		Params.ReturnValue = *(bool*)(params.GetStructMemory() + 12);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushboolean(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 IsAnySimulatingPhysics(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SceneComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SceneComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool ReturnValue;
	} Params;
#if UE_GAME
	USceneComponent * This = (USceneComponent *)Obj;
	Params.ReturnValue = This->IsAnySimulatingPhysics();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("IsAnySimulatingPhysics"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushboolean(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetUpVector(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SceneComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SceneComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FVector ReturnValue;
	} Params;
#if UE_GAME
	USceneComponent * This = (USceneComponent *)Obj;
	Params.ReturnValue = This->GetUpVector();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetUpVector"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(FVector*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaVector::Return(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetSocketTransform(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SceneComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SceneComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FName InSocketName;
		TEnumAsByte<ERelativeTransformSpace> TransformSpace;
		FTransform ReturnValue;
	} Params;
	Params.InSocketName = FName(UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 2)));
	Params.TransformSpace = lua_isnoneornil(InScriptContext,3) ? TEnumAsByte<ERelativeTransformSpace>(ERelativeTransformSpace::RTS_World) : (TEnumAsByte<ERelativeTransformSpace>)(luaL_checkint(InScriptContext, 3));
#if UE_GAME
	USceneComponent * This = (USceneComponent *)Obj;
	Params.ReturnValue = This->GetSocketTransform(Params.InSocketName,Params.TransformSpace);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetSocketTransform"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FName*)(params.GetStructMemory() + 0) = Params.InSocketName;
		*(TEnumAsByte<ERelativeTransformSpace>*)(params.GetStructMemory() + 12) = Params.TransformSpace;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.InSocketName = *(FName*)(params.GetStructMemory() + 0);
		Params.TransformSpace = *(TEnumAsByte<ERelativeTransformSpace>*)(params.GetStructMemory() + 12);
		Params.ReturnValue = *(FTransform*)(params.GetStructMemory() + 16);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaTransform::Return(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetSocketRotation(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SceneComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SceneComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FName InSocketName;
		FRotator ReturnValue;
	} Params;
	Params.InSocketName = FName(UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 2)));
#if UE_GAME
	USceneComponent * This = (USceneComponent *)Obj;
	Params.ReturnValue = This->GetSocketRotation(Params.InSocketName);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetSocketRotation"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FName*)(params.GetStructMemory() + 0) = Params.InSocketName;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.InSocketName = *(FName*)(params.GetStructMemory() + 0);
		Params.ReturnValue = *(FRotator*)(params.GetStructMemory() + 12);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaRotator::Return(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetSocketLocation(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SceneComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SceneComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FName InSocketName;
		FVector ReturnValue;
	} Params;
	Params.InSocketName = FName(UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 2)));
#if UE_GAME
	USceneComponent * This = (USceneComponent *)Obj;
	Params.ReturnValue = This->GetSocketLocation(Params.InSocketName);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetSocketLocation"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FName*)(params.GetStructMemory() + 0) = Params.InSocketName;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.InSocketName = *(FName*)(params.GetStructMemory() + 0);
		Params.ReturnValue = *(FVector*)(params.GetStructMemory() + 12);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaVector::Return(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetShouldUpdatePhysicsVolume(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SceneComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SceneComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool ReturnValue;
	} Params;
#if UE_GAME
	USceneComponent * This = (USceneComponent *)Obj;
	Params.ReturnValue = This->GetShouldUpdatePhysicsVolume();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetShouldUpdatePhysicsVolume"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushboolean(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetRightVector(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SceneComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SceneComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FVector ReturnValue;
	} Params;
#if UE_GAME
	USceneComponent * This = (USceneComponent *)Obj;
	Params.ReturnValue = This->GetRightVector();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetRightVector"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(FVector*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaVector::Return(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetRelativeTransform(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SceneComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SceneComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FTransform ReturnValue;
	} Params;
#if UE_GAME
	USceneComponent * This = (USceneComponent *)Obj;
	Params.ReturnValue = This->GetRelativeTransform();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetRelativeTransform"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(FTransform*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaTransform::Return(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetPhysicsVolume(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SceneComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SceneComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		APhysicsVolume* ReturnValue = nullptr;
	} Params;
#if UE_GAME
	USceneComponent * This = (USceneComponent *)Obj;
	Params.ReturnValue = This->GetPhysicsVolume();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetPhysicsVolume"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(APhysicsVolume**)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetParentComponents(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SceneComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SceneComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		TArray<USceneComponent*> Parents;
	} Params;
#if UE_GAME
	USceneComponent * This = (USceneComponent *)Obj;
	This->GetParentComponents(Params.Parents);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetParentComponents"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.Parents = *(TArray<USceneComponent*>*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	{lua_newtable(InScriptContext); int i = 1; for(auto It = Params.Parents.CreateConstIterator(); It; ++It,++i) {  wLua::FLuaUtils::ReturnUObject(InScriptContext, (*It)); lua_rawseti(InScriptContext,-2,i);     }  }
	return 1;
}

int32 GetNumChildrenComponents(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SceneComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SceneComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		int32 ReturnValue;
	} Params;
#if UE_GAME
	USceneComponent * This = (USceneComponent *)Obj;
	Params.ReturnValue = This->GetNumChildrenComponents();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetNumChildrenComponents"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(int32*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushinteger(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetForwardVector(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SceneComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SceneComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FVector ReturnValue;
	} Params;
#if UE_GAME
	USceneComponent * This = (USceneComponent *)Obj;
	Params.ReturnValue = This->GetForwardVector();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetForwardVector"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(FVector*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaVector::Return(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetComponentVelocity(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SceneComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SceneComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FVector ReturnValue;
	} Params;
#if UE_GAME
	USceneComponent * This = (USceneComponent *)Obj;
	Params.ReturnValue = This->GetComponentVelocity();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetComponentVelocity"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(FVector*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaVector::Return(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetChildrenComponents(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SceneComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SceneComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool bIncludeAllDescendants;
		TArray<USceneComponent*> Children;
	} Params;
	Params.bIncludeAllDescendants = !!(lua_toboolean(InScriptContext, 2));
#if UE_GAME
	USceneComponent * This = (USceneComponent *)Obj;
	This->GetChildrenComponents(Params.bIncludeAllDescendants,Params.Children);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetChildrenComponents"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(bool*)(params.GetStructMemory() + 0) = Params.bIncludeAllDescendants;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.bIncludeAllDescendants = *(bool*)(params.GetStructMemory() + 0);
		Params.Children = *(TArray<USceneComponent*>*)(params.GetStructMemory() + 8);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	{lua_newtable(InScriptContext); int i = 1; for(auto It = Params.Children.CreateConstIterator(); It; ++It,++i) {  wLua::FLuaUtils::ReturnUObject(InScriptContext, (*It)); lua_rawseti(InScriptContext,-2,i);     }  }
	return 1;
}

int32 GetChildComponent(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SceneComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SceneComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		int32 ChildIndex;
		USceneComponent* ReturnValue = nullptr;
	} Params;
	Params.ChildIndex = (luaL_checkint(InScriptContext, 2));
#if UE_GAME
	USceneComponent * This = (USceneComponent *)Obj;
	Params.ReturnValue = This->GetChildComponent(Params.ChildIndex);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetChildComponent"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(int32*)(params.GetStructMemory() + 0) = Params.ChildIndex;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ChildIndex = *(int32*)(params.GetStructMemory() + 0);
		Params.ReturnValue = *(USceneComponent**)(params.GetStructMemory() + 8);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetAttachSocketName(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SceneComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SceneComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FName ReturnValue;
	} Params;
#if UE_GAME
	USceneComponent * This = (USceneComponent *)Obj;
	Params.ReturnValue = This->GetAttachSocketName();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetAttachSocketName"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(FName*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushstring(InScriptContext, TCHAR_TO_UTF8(*Params.ReturnValue.ToString()));
	return 1;
}

int32 GetAttachParent(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SceneComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SceneComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		USceneComponent* ReturnValue = nullptr;
	} Params;
#if UE_GAME
	USceneComponent * This = (USceneComponent *)Obj;
	Params.ReturnValue = This->GetAttachParent();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetAttachParent"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(USceneComponent**)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetAllSocketNames(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SceneComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SceneComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		TArray<FName> ReturnValue;
	} Params;
#if UE_GAME
	USceneComponent * This = (USceneComponent *)Obj;
	Params.ReturnValue = This->GetAllSocketNames();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetAllSocketNames"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(TArray<FName>*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	{lua_newtable(InScriptContext); int i = 1; for(auto It = Params.ReturnValue.CreateConstIterator(); It; ++It,++i) {  lua_pushstring(InScriptContext, TCHAR_TO_UTF8(*(*It).ToString())); lua_rawseti(InScriptContext,-2,i);     }  }
	return 1;
}

int32 DoesSocketExist(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SceneComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SceneComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FName InSocketName;
		bool ReturnValue;
	} Params;
	Params.InSocketName = FName(UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 2)));
#if UE_GAME
	USceneComponent * This = (USceneComponent *)Obj;
	Params.ReturnValue = This->DoesSocketExist(Params.InSocketName);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("DoesSocketExist"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FName*)(params.GetStructMemory() + 0) = Params.InSocketName;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.InSocketName = *(FName*)(params.GetStructMemory() + 0);
		Params.ReturnValue = *(bool*)(params.GetStructMemory() + 12);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushboolean(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 DetachFromParent(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SceneComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SceneComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool bMaintainWorldPosition;
		bool bCallModify;
	} Params;
	Params.bMaintainWorldPosition = lua_isnoneornil(InScriptContext,2) ? bool(false) : !!(lua_toboolean(InScriptContext, 2));
	Params.bCallModify = lua_isnoneornil(InScriptContext,3) ? bool(true) : !!(lua_toboolean(InScriptContext, 3));
#if UE_GAME
	USceneComponent * This = (USceneComponent *)Obj;
	This->DetachFromParent(Params.bMaintainWorldPosition,Params.bCallModify);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("DetachFromParent"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(bool*)(params.GetStructMemory() + 0) = Params.bMaintainWorldPosition;
		*(bool*)(params.GetStructMemory() + 1) = Params.bCallModify;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.bMaintainWorldPosition = *(bool*)(params.GetStructMemory() + 0);
		Params.bCallModify = *(bool*)(params.GetStructMemory() + 1);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 Get_AzureLightParent(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SceneComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SceneComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USceneComponent::StaticClass(), TEXT("AzureLightParent"));
	if(!Property) { check(false); return 0;}
	USceneComponent* PropertyValue;
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaUtils::ReturnUObject(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_AzureLightParent(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SceneComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SceneComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USceneComponent::StaticClass(), TEXT("AzureLightParent"));
	if(!Property) { check(false); return 0;}
	USceneComponent* PropertyValue = (USceneComponent*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"SceneComponent");;
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_RelativeLocation(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SceneComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SceneComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USceneComponent::StaticClass(), TEXT("RelativeLocation"));
	if(!Property) { check(false); return 0;}
	FVector PropertyValue = FVector();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaVector::Return(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_RelativeRotation(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SceneComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SceneComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USceneComponent::StaticClass(), TEXT("RelativeRotation"));
	if(!Property) { check(false); return 0;}
	FRotator PropertyValue = FRotator();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaRotator::Return(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_RelativeScale3D(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SceneComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SceneComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USceneComponent::StaticClass(), TEXT("RelativeScale3D"));
	if(!Property) { check(false); return 0;}
	FVector PropertyValue = FVector();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaVector::Return(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_bAbsoluteLocation(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SceneComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SceneComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USceneComponent::StaticClass(), TEXT("bAbsoluteLocation"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bAbsoluteLocation(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SceneComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SceneComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USceneComponent::StaticClass(), TEXT("bAbsoluteLocation"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bAbsoluteRotation(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SceneComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SceneComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USceneComponent::StaticClass(), TEXT("bAbsoluteRotation"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bAbsoluteRotation(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SceneComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SceneComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USceneComponent::StaticClass(), TEXT("bAbsoluteRotation"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bAbsoluteScale(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SceneComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SceneComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USceneComponent::StaticClass(), TEXT("bAbsoluteScale"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bAbsoluteScale(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SceneComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SceneComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USceneComponent::StaticClass(), TEXT("bAbsoluteScale"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bVisible(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SceneComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SceneComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USceneComponent::StaticClass(), TEXT("bVisible"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_bHiddenInGame(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SceneComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SceneComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USceneComponent::StaticClass(), TEXT("bHiddenInGame"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_bShouldUpdatePhysicsVolume(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SceneComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SceneComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USceneComponent::StaticClass(), TEXT("bShouldUpdatePhysicsVolume"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bShouldUpdatePhysicsVolume(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SceneComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SceneComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USceneComponent::StaticClass(), TEXT("bShouldUpdatePhysicsVolume"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bUseAttachParentBound(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SceneComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SceneComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USceneComponent::StaticClass(), TEXT("bUseAttachParentBound"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bUseAttachParentBound(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SceneComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SceneComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USceneComponent::StaticClass(), TEXT("bUseAttachParentBound"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_Mobility(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SceneComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SceneComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USceneComponent::StaticClass(), TEXT("Mobility"));
	if(!Property) { check(false); return 0;}
	TEnumAsByte<EComponentMobility::Type> PropertyValue = TEnumAsByte<EComponentMobility::Type>();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushinteger(InScriptContext, (int)PropertyValue);
	return 1;
}

int32 Get_DetailMode(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SceneComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SceneComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USceneComponent::StaticClass(), TEXT("DetailMode"));
	if(!Property) { check(false); return 0;}
	TEnumAsByte<EDetailMode> PropertyValue = TEnumAsByte<EDetailMode>();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushinteger(InScriptContext, (int)PropertyValue);
	return 1;
}

int32 Call_PhysicsVolumeChangedDelegate(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SceneComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SceneComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		APhysicsVolume* NewVolume = nullptr;
	} Params;
	Params.NewVolume = (APhysicsVolume*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"PhysicsVolume");;
	USceneComponent * This = (USceneComponent *)Obj;
	This->PhysicsVolumeChangedDelegate.Broadcast(Params.NewVolume);
	return 0;
}

int32 New(lua_State* InScriptContext)
{
	UObject* Outer = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Object");
	FName Name = FName(luaL_checkstring(InScriptContext, 2));
	UObject* Obj = NewObject<USceneComponent>(Outer, Name);
	wLua::FLuaUtils::ReturnUObject(InScriptContext,Obj);
	return 1;
}

int32 Destroy(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SceneComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SceneComponent must be non-null"); lua_error(InScriptContext);  return 0;}
		UActorComponent * com = Cast<UActorComponent>(Obj);
		if(lua_isnoneornil(InScriptContext,2))
			com->DestroyComponent();
		else
			com->DestroyComponent(!!lua_toboolean(InScriptContext,2));
		userdata->flag |= wLua::LuaObjectFlag::DESTROYED;
		wLua::FLuaUtils::RemoveObjectReference(Obj, userdata->stamp, InScriptContext);
#ifdef AZURE_BUILD_WLUACHECK
		UE_LOG(LogAzure, Warning, TEXT("Destroy SceneComponent: %x userdata:%x   stamp:%x"),Obj,userdata,userdata->stamp);
#endif
	return 0;
}

int32 Class(lua_State* InScriptContext)
{
	UClass* Class = USceneComponent::StaticClass();
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Class);
	return 1;
}

const luaL_Reg Lib_Funcs[] =
{
	{ "New", New },
	{ "Destroy", Destroy },
	{ "Class", Class },
	{ "ToggleVisibility", ToggleVisibility },
	{ "SetWorldScale3D", SetWorldScale3D },
	{ "SetVisibility", SetVisibility },
	{ "SetShouldUpdatePhysicsVolume", SetShouldUpdatePhysicsVolume },
	{ "SetRelativeScale3D", SetRelativeScale3D },
	{ "SetMobility", SetMobility },
	{ "SetHiddenInGame", SetHiddenInGame },
	{ "SetAbsolute", SetAbsolute },
	{ "ResetRelativeTransform", ResetRelativeTransform },
	{ "OnRep_Visibility", OnRep_Visibility },
	{ "OnRep_Transform", OnRep_Transform },
	{ "OnRep_AttachSocketName", OnRep_AttachSocketName },
	{ "OnRep_AttachParent", OnRep_AttachParent },
	{ "OnRep_AttachChildren", OnRep_AttachChildren },
	{ "GetComponentToWorld", K2_GetComponentToWorld },
	{ "GetComponentScale", K2_GetComponentScale },
	{ "GetComponentRotation", K2_GetComponentRotation },
	{ "GetComponentLocation", K2_GetComponentLocation },
	{ "DetachFromComponent", K2_DetachFromComponent },
	{ "AttachToComponent", K2_AttachToComponent },
	{ "AttachTo", K2_AttachTo },
	{ "IsVisible", IsVisible },
	{ "IsSimulatingPhysics", IsSimulatingPhysics },
	{ "IsAnySimulatingPhysics", IsAnySimulatingPhysics },
	{ "GetUpVector", GetUpVector },
	{ "GetSocketTransform", GetSocketTransform },
	{ "GetSocketRotation", GetSocketRotation },
	{ "GetSocketLocation", GetSocketLocation },
	{ "GetShouldUpdatePhysicsVolume", GetShouldUpdatePhysicsVolume },
	{ "GetRightVector", GetRightVector },
	{ "GetRelativeTransform", GetRelativeTransform },
	{ "GetPhysicsVolume", GetPhysicsVolume },
	{ "GetParentComponents", GetParentComponents },
	{ "GetNumChildrenComponents", GetNumChildrenComponents },
	{ "GetForwardVector", GetForwardVector },
	{ "GetComponentVelocity", GetComponentVelocity },
	{ "GetChildrenComponents", GetChildrenComponents },
	{ "GetChildComponent", GetChildComponent },
	{ "GetAttachSocketName", GetAttachSocketName },
	{ "GetAttachParent", GetAttachParent },
	{ "GetAllSocketNames", GetAllSocketNames },
	{ "DoesSocketExist", DoesSocketExist },
	{ "DetachFromParent", DetachFromParent },
	{ "Get_AzureLightParent", Get_AzureLightParent },
	{ "Set_AzureLightParent", Set_AzureLightParent },
	{ "Get_RelativeLocation", Get_RelativeLocation },
	{ "Get_RelativeRotation", Get_RelativeRotation },
	{ "Get_RelativeScale3D", Get_RelativeScale3D },
	{ "Get_bAbsoluteLocation", Get_bAbsoluteLocation },
	{ "Set_bAbsoluteLocation", Set_bAbsoluteLocation },
	{ "Get_bAbsoluteRotation", Get_bAbsoluteRotation },
	{ "Set_bAbsoluteRotation", Set_bAbsoluteRotation },
	{ "Get_bAbsoluteScale", Get_bAbsoluteScale },
	{ "Set_bAbsoluteScale", Set_bAbsoluteScale },
	{ "Get_bVisible", Get_bVisible },
	{ "Get_bHiddenInGame", Get_bHiddenInGame },
	{ "Get_bShouldUpdatePhysicsVolume", Get_bShouldUpdatePhysicsVolume },
	{ "Set_bShouldUpdatePhysicsVolume", Set_bShouldUpdatePhysicsVolume },
	{ "Get_bUseAttachParentBound", Get_bUseAttachParentBound },
	{ "Set_bUseAttachParentBound", Set_bUseAttachParentBound },
	{ "Get_Mobility", Get_Mobility },
	{ "Get_DetailMode", Get_DetailMode },
	{ "Call_PhysicsVolumeChangedDelegate", Call_PhysicsVolumeChangedDelegate },
	{ "GetComponentLocationSplit", GetComponentLocationSplit },
	{ "GetComponentRotationSplit", GetComponentRotationSplit },
	{ "SetupAttachment", SetupAttachment },
	{ "SetRelativeLocation", SetRelativeLocation },
	{ "SetRelativeRotation", SetRelativeRotation },
	{ "SetRelativeLocationAndRotation", SetRelativeLocationAndRotation },
	{ "SocketTransformPoint", SocketTransformPoint },
	{ "SocketTransformRotator", SocketTransformRotator },
	{ "SetWorldLocation", SetWorldLocation },
	{ "SetWorldRotation", SetWorldRotation },
	{ "SetHiddenIngame", SetHiddenIngame },
	{ "SetComponentToWorld", SetComponentToWorld },
	{ "GetComponentToWorld", GetComponentToWorld },
	{ "GetAttachChildCount", GetAttachChildCount },
	{ "GetAttachChild", GetAttachChild },
	{ "UpdateCompOverlaps", UpdateCompOverlaps },
	{ "is_nil", wLua::LuaStatic::isnil },
	{ "__gc", wLua::LuaStatic::removeUClassFrameCache },
	{ NULL, NULL }
};

void Register(lua_State *InScriptContext)
{
	lua_newtable(InScriptContext);
	luaL_register(InScriptContext, NULL, Lib_Funcs);
	AzureHelpFuncs::AuxRegister(InScriptContext, "SceneComponent");
}
void SetMtLink(lua_State *InScriptContext)
{
	AzureHelpFuncs::AuxSetMtLink(InScriptContext, "SceneComponent", "ActorComponent",USERDATATYPE_UOBJECT);
}

}