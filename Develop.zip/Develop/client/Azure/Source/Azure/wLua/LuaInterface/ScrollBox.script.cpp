#include "Azure.h"
#include "Utility/help_funcs.h"
#include "wLua/UObjectHeaders.h"
#include "Components/ScrollBox.h"
#include "AzureLuaIntegration.h"

namespace LuaScrollBox
{
int32 SetScrollOffset(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ScrollBox",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ScrollBox must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float NewScrollOffset;
	} Params;
	Params.NewScrollOffset = (float)(luaL_checknumber(InScriptContext, 2));
#if UE_GAME
	UScrollBox * This = (UScrollBox *)Obj;
	This->SetScrollOffset(Params.NewScrollOffset);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetScrollOffset"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(float*)(params.GetStructMemory() + 0) = Params.NewScrollOffset;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.NewScrollOffset = *(float*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetScrollBarVisibility(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ScrollBox",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ScrollBox must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		ESlateVisibility NewScrollBarVisibility;
	} Params;
	Params.NewScrollBarVisibility = (ESlateVisibility)(luaL_checkint(InScriptContext, 2));
#if UE_GAME
	UScrollBox * This = (UScrollBox *)Obj;
	This->SetScrollBarVisibility(Params.NewScrollBarVisibility);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetScrollBarVisibility"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(ESlateVisibility*)(params.GetStructMemory() + 0) = Params.NewScrollBarVisibility;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.NewScrollBarVisibility = *(ESlateVisibility*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetScrollbarThickness(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ScrollBox",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ScrollBox must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FVector2D NewScrollbarThickness;
	} Params;
	Params.NewScrollbarThickness = (wLua::FLuaVector2D::Get(InScriptContext, 2));
#if UE_GAME
	UScrollBox * This = (UScrollBox *)Obj;
	This->SetScrollbarThickness(Params.NewScrollbarThickness);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetScrollbarThickness"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FVector2D*)(params.GetStructMemory() + 0) = Params.NewScrollbarThickness;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.NewScrollbarThickness = *(FVector2D*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetOrientation(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ScrollBox",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ScrollBox must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		TEnumAsByte<EOrientation> NewOrientation;
	} Params;
	Params.NewOrientation = (TEnumAsByte<EOrientation>)(luaL_checkint(InScriptContext, 2));
#if UE_GAME
	UScrollBox * This = (UScrollBox *)Obj;
	This->SetOrientation(Params.NewOrientation);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetOrientation"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(TEnumAsByte<EOrientation>*)(params.GetStructMemory() + 0) = Params.NewOrientation;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.NewOrientation = *(TEnumAsByte<EOrientation>*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetAlwaysShowScrollbar(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ScrollBox",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ScrollBox must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool NewAlwaysShowScrollbar;
	} Params;
	Params.NewAlwaysShowScrollbar = !!(lua_toboolean(InScriptContext, 2));
#if UE_GAME
	UScrollBox * This = (UScrollBox *)Obj;
	This->SetAlwaysShowScrollbar(Params.NewAlwaysShowScrollbar);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetAlwaysShowScrollbar"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(bool*)(params.GetStructMemory() + 0) = Params.NewAlwaysShowScrollbar;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.NewAlwaysShowScrollbar = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetAllowOverscroll(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ScrollBox",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ScrollBox must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool NewAllowOverscroll;
	} Params;
	Params.NewAllowOverscroll = !!(lua_toboolean(InScriptContext, 2));
#if UE_GAME
	UScrollBox * This = (UScrollBox *)Obj;
	This->SetAllowOverscroll(Params.NewAllowOverscroll);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetAllowOverscroll"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(bool*)(params.GetStructMemory() + 0) = Params.NewAllowOverscroll;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.NewAllowOverscroll = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 ScrollWidgetIntoView(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ScrollBox",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ScrollBox must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		UWidget* WidgetToFind = nullptr;
		bool AnimateScroll;
		EDescendantScrollDestination ScrollDestination;
	} Params;
	Params.WidgetToFind = (UWidget*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"Widget");;
	Params.AnimateScroll = lua_isnoneornil(InScriptContext,3) ? bool(true) : !!(lua_toboolean(InScriptContext, 3));
	Params.ScrollDestination = lua_isnoneornil(InScriptContext,4) ? EDescendantScrollDestination(EDescendantScrollDestination::IntoView) : (EDescendantScrollDestination)(luaL_checkint(InScriptContext, 4));
#if UE_GAME
	UScrollBox * This = (UScrollBox *)Obj;
	This->ScrollWidgetIntoView(Params.WidgetToFind,Params.AnimateScroll,Params.ScrollDestination);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("ScrollWidgetIntoView"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(UWidget**)(params.GetStructMemory() + 0) = Params.WidgetToFind;
		*(bool*)(params.GetStructMemory() + 8) = Params.AnimateScroll;
		*(EDescendantScrollDestination*)(params.GetStructMemory() + 9) = Params.ScrollDestination;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.WidgetToFind = *(UWidget**)(params.GetStructMemory() + 0);
		Params.AnimateScroll = *(bool*)(params.GetStructMemory() + 8);
		Params.ScrollDestination = *(EDescendantScrollDestination*)(params.GetStructMemory() + 9);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 ScrollToStart(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ScrollBox",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ScrollBox must be non-null"); lua_error(InScriptContext);  return 0;}
#if UE_GAME
	UScrollBox * This = (UScrollBox *)Obj;
	This->ScrollToStart();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("ScrollToStart"));
	if(!Function) { check(false); return 0;}
	Obj->ProcessEvent(Function, NULL);
#endif
	return 0;
}

int32 ScrollToEnd(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ScrollBox",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ScrollBox must be non-null"); lua_error(InScriptContext);  return 0;}
#if UE_GAME
	UScrollBox * This = (UScrollBox *)Obj;
	This->ScrollToEnd();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("ScrollToEnd"));
	if(!Function) { check(false); return 0;}
	Obj->ProcessEvent(Function, NULL);
#endif
	return 0;
}

int32 GetViewOffsetFraction(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ScrollBox",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ScrollBox must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float ReturnValue;
	} Params;
#if UE_GAME
	UScrollBox * This = (UScrollBox *)Obj;
	Params.ReturnValue = This->GetViewOffsetFraction();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetViewOffsetFraction"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(float*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushnumber(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetScrollOffset(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ScrollBox",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ScrollBox must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float ReturnValue;
	} Params;
#if UE_GAME
	UScrollBox * This = (UScrollBox *)Obj;
	Params.ReturnValue = This->GetScrollOffset();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetScrollOffset"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(float*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushnumber(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 Get_Orientation(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ScrollBox",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ScrollBox must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UScrollBox::StaticClass(), TEXT("Orientation"));
	if(!Property) { check(false); return 0;}
	TEnumAsByte<EOrientation> PropertyValue = TEnumAsByte<EOrientation>();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushinteger(InScriptContext, (int)PropertyValue);
	return 1;
}

int32 Get_ScrollBarVisibility(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ScrollBox",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ScrollBox must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UScrollBox::StaticClass(), TEXT("ScrollBarVisibility"));
	if(!Property) { check(false); return 0;}
	ESlateVisibility PropertyValue = ESlateVisibility();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushinteger(InScriptContext, (int)PropertyValue);
	return 1;
}

int32 Get_ConsumeMouseWheel(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ScrollBox",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ScrollBox must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UScrollBox::StaticClass(), TEXT("ConsumeMouseWheel"));
	if(!Property) { check(false); return 0;}
	EConsumeMouseWheel PropertyValue = EConsumeMouseWheel();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushinteger(InScriptContext, (int)PropertyValue);
	return 1;
}

int32 Get_ScrollbarThickness(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ScrollBox",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ScrollBox must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UScrollBox::StaticClass(), TEXT("ScrollbarThickness"));
	if(!Property) { check(false); return 0;}
	FVector2D PropertyValue = FVector2D();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaVector2D::Return(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_AlwaysShowScrollbar(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ScrollBox",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ScrollBox must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UScrollBox::StaticClass(), TEXT("AlwaysShowScrollbar"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = bool();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_AllowOverscroll(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ScrollBox",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ScrollBox must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UScrollBox::StaticClass(), TEXT("AllowOverscroll"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = bool();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_UsePhysicalOverscroll(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ScrollBox",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ScrollBox must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UScrollBox::StaticClass(), TEXT("UsePhysicalOverscroll"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = bool();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_Looseness(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ScrollBox",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ScrollBox must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UScrollBox::StaticClass(), TEXT("Looseness"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_OvershootLooseMax(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ScrollBox",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ScrollBox must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UScrollBox::StaticClass(), TEXT("OvershootLooseMax"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_OvershootBounceRate(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ScrollBox",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ScrollBox must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UScrollBox::StaticClass(), TEXT("OvershootBounceRate"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_NavigationDestination(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ScrollBox",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ScrollBox must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UScrollBox::StaticClass(), TEXT("NavigationDestination"));
	if(!Property) { check(false); return 0;}
	EDescendantScrollDestination PropertyValue = EDescendantScrollDestination();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushinteger(InScriptContext, (int)PropertyValue);
	return 1;
}

int32 Get_NavigationScrollPadding(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ScrollBox",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ScrollBox must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UScrollBox::StaticClass(), TEXT("NavigationScrollPadding"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_MinimumInertialVelocity(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ScrollBox",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ScrollBox must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UScrollBox::StaticClass(), TEXT("MinimumInertialVelocity"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_MinimumInertialVelocity(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ScrollBox",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ScrollBox must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UScrollBox::StaticClass(), TEXT("MinimumInertialVelocity"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_AnimateScrollVelocity(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ScrollBox",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ScrollBox must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UScrollBox::StaticClass(), TEXT("AnimateScrollVelocity"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_AnimateScrollVelocity(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ScrollBox",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ScrollBox must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UScrollBox::StaticClass(), TEXT("AnimateScrollVelocity"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bAllowRightClickDragScrolling(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ScrollBox",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ScrollBox must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UScrollBox::StaticClass(), TEXT("bAllowRightClickDragScrolling"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = bool();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_bIsNeedCaptureMovementAxisAligned(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ScrollBox",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ScrollBox must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UScrollBox::StaticClass(), TEXT("bIsNeedCaptureMovementAxisAligned"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = bool();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Call_OnUserScrolled(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ScrollBox",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ScrollBox must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float CurrentOffset;
	} Params;
	Params.CurrentOffset = (float)(luaL_checknumber(InScriptContext, 2));
	UScrollBox * This = (UScrollBox *)Obj;
	This->OnUserScrolled.Broadcast(Params.CurrentOffset);
	return 0;
}

int32 New(lua_State* InScriptContext)
{
	UObject* Outer = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Object");
	FName Name = FName(luaL_checkstring(InScriptContext, 2));
	UObject* Obj = NewObject<UScrollBox>(Outer, Name);
	wLua::FLuaUtils::ReturnUObject(InScriptContext,Obj);
	return 1;
}

int32 Destroy(lua_State* InScriptContext)
{
	return 0;
}

int32 Class(lua_State* InScriptContext)
{
	UClass* Class = UScrollBox::StaticClass();
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Class);
	return 1;
}

const luaL_Reg Lib_Funcs[] =
{
	{ "New", New },
	{ "Destroy", Destroy },
	{ "Class", Class },
	{ "SetScrollOffset", SetScrollOffset },
	{ "SetScrollBarVisibility", SetScrollBarVisibility },
	{ "SetScrollbarThickness", SetScrollbarThickness },
	{ "SetOrientation", SetOrientation },
	{ "SetAlwaysShowScrollbar", SetAlwaysShowScrollbar },
	{ "SetAllowOverscroll", SetAllowOverscroll },
	{ "ScrollWidgetIntoView", ScrollWidgetIntoView },
	{ "ScrollToStart", ScrollToStart },
	{ "ScrollToEnd", ScrollToEnd },
	{ "GetViewOffsetFraction", GetViewOffsetFraction },
	{ "GetScrollOffset", GetScrollOffset },
	{ "Get_Orientation", Get_Orientation },
	{ "Get_ScrollBarVisibility", Get_ScrollBarVisibility },
	{ "Get_ConsumeMouseWheel", Get_ConsumeMouseWheel },
	{ "Get_ScrollbarThickness", Get_ScrollbarThickness },
	{ "Get_AlwaysShowScrollbar", Get_AlwaysShowScrollbar },
	{ "Get_AllowOverscroll", Get_AllowOverscroll },
	{ "Get_UsePhysicalOverscroll", Get_UsePhysicalOverscroll },
	{ "Get_Looseness", Get_Looseness },
	{ "Get_OvershootLooseMax", Get_OvershootLooseMax },
	{ "Get_OvershootBounceRate", Get_OvershootBounceRate },
	{ "Get_NavigationDestination", Get_NavigationDestination },
	{ "Get_NavigationScrollPadding", Get_NavigationScrollPadding },
	{ "Get_MinimumInertialVelocity", Get_MinimumInertialVelocity },
	{ "Set_MinimumInertialVelocity", Set_MinimumInertialVelocity },
	{ "Get_AnimateScrollVelocity", Get_AnimateScrollVelocity },
	{ "Set_AnimateScrollVelocity", Set_AnimateScrollVelocity },
	{ "Get_bAllowRightClickDragScrolling", Get_bAllowRightClickDragScrolling },
	{ "Get_bIsNeedCaptureMovementAxisAligned", Get_bIsNeedCaptureMovementAxisAligned },
	{ "Call_OnUserScrolled", Call_OnUserScrolled },
	{ "is_nil", wLua::LuaStatic::isnil },
	{ "__gc", wLua::LuaStatic::removeUClassFrameCache },
	{ NULL, NULL }
};

void Register(lua_State *InScriptContext)
{
	lua_newtable(InScriptContext);
	luaL_register(InScriptContext, NULL, Lib_Funcs);
	AzureHelpFuncs::AuxRegister(InScriptContext, "ScrollBox");
}
void SetMtLink(lua_State *InScriptContext)
{
	AzureHelpFuncs::AuxSetMtLink(InScriptContext, "ScrollBox", "PanelWidget",USERDATATYPE_UOBJECT);
}

}