#include "Azure.h"
#include "Utility/help_funcs.h"
#include "wLua/UObjectHeaders.h"
#include "GameFramework/Character.h"
#include "AzureLuaIntegration.h"

namespace LuaCharacter
{
int32 SetAnimRootMotionTranslationScale(lua_State*);

int32 UnCrouch(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Character",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Character must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool bClientSimulation;
	} Params;
	Params.bClientSimulation = lua_isnoneornil(InScriptContext,2) ? bool(false) : !!(lua_toboolean(InScriptContext, 2));
#if UE_GAME
	ACharacter * This = (ACharacter *)Obj;
	This->UnCrouch(Params.bClientSimulation);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("UnCrouch"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(bool*)(params.GetStructMemory() + 0) = Params.bClientSimulation;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.bClientSimulation = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 StopJumping(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Character",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Character must be non-null"); lua_error(InScriptContext);  return 0;}
#if UE_GAME
	ACharacter * This = (ACharacter *)Obj;
	This->StopJumping();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("StopJumping"));
	if(!Function) { check(false); return 0;}
	Obj->ProcessEvent(Function, NULL);
#endif
	return 0;
}

int32 StopAnimMontage(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Character",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Character must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		UAnimMontage* AnimMontage = nullptr;
	} Params;
	Params.AnimMontage = lua_isnoneornil(InScriptContext,2) ? nullptr : (UAnimMontage*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"AnimMontage");;
#if UE_GAME
	ACharacter * This = (ACharacter *)Obj;
	This->StopAnimMontage(Params.AnimMontage);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("StopAnimMontage"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(UAnimMontage**)(params.GetStructMemory() + 0) = Params.AnimMontage;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.AnimMontage = *(UAnimMontage**)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 RootMotionDebugClientPrintOnScreen(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Character",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Character must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FString InString;
	} Params;
	Params.InString = UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 2));
#if UE_GAME
	ACharacter * This = (ACharacter *)Obj;
	This->RootMotionDebugClientPrintOnScreen(Params.InString);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("RootMotionDebugClientPrintOnScreen"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FString*)(params.GetStructMemory() + 0) = Params.InString;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.InString = *(FString*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 PlayAnimMontage(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Character",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Character must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		UAnimMontage* AnimMontage = nullptr;
		float InPlayRate;
		FName StartSectionName;
		float ReturnValue;
	} Params;
	Params.AnimMontage = (UAnimMontage*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"AnimMontage");;
	Params.InPlayRate = lua_isnoneornil(InScriptContext,3) ? float(1.000000) : (float)(luaL_checknumber(InScriptContext, 3));
	Params.StartSectionName = lua_isnoneornil(InScriptContext,4) ? FName(TEXT("")) : FName(UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 4)));
#if UE_GAME
	ACharacter * This = (ACharacter *)Obj;
	Params.ReturnValue = This->PlayAnimMontage(Params.AnimMontage,Params.InPlayRate,Params.StartSectionName);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("PlayAnimMontage"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(UAnimMontage**)(params.GetStructMemory() + 0) = Params.AnimMontage;
		*(float*)(params.GetStructMemory() + 8) = Params.InPlayRate;
		*(FName*)(params.GetStructMemory() + 12) = Params.StartSectionName;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.AnimMontage = *(UAnimMontage**)(params.GetStructMemory() + 0);
		Params.InPlayRate = *(float*)(params.GetStructMemory() + 8);
		Params.StartSectionName = *(FName*)(params.GetStructMemory() + 12);
		Params.ReturnValue = *(float*)(params.GetStructMemory() + 24);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushnumber(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 OnWalkingOffLedge(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Character",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Character must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FVector PreviousFloorImpactNormal;
		FVector PreviousFloorContactNormal;
		FVector PreviousLocation;
		float TimeDelta;
	} Params;
	Params.PreviousFloorImpactNormal = (wLua::FLuaVector::Get(InScriptContext, 2));
	Params.PreviousFloorContactNormal = (wLua::FLuaVector::Get(InScriptContext, 3));
	Params.PreviousLocation = (wLua::FLuaVector::Get(InScriptContext, 4));
	Params.TimeDelta = (float)(luaL_checknumber(InScriptContext, 5));
#if UE_GAME
	ACharacter * This = (ACharacter *)Obj;
	This->OnWalkingOffLedge(Params.PreviousFloorImpactNormal,Params.PreviousFloorContactNormal,Params.PreviousLocation,Params.TimeDelta);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("OnWalkingOffLedge"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FVector*)(params.GetStructMemory() + 0) = Params.PreviousFloorImpactNormal;
		*(FVector*)(params.GetStructMemory() + 12) = Params.PreviousFloorContactNormal;
		*(FVector*)(params.GetStructMemory() + 24) = Params.PreviousLocation;
		*(float*)(params.GetStructMemory() + 36) = Params.TimeDelta;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.PreviousFloorImpactNormal = *(FVector*)(params.GetStructMemory() + 0);
		Params.PreviousFloorContactNormal = *(FVector*)(params.GetStructMemory() + 12);
		Params.PreviousLocation = *(FVector*)(params.GetStructMemory() + 24);
		Params.TimeDelta = *(float*)(params.GetStructMemory() + 36);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 OnRep_RootMotion(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Character",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Character must be non-null"); lua_error(InScriptContext);  return 0;}
#if UE_GAME
	ACharacter * This = (ACharacter *)Obj;
	This->OnRep_RootMotion();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("OnRep_RootMotion"));
	if(!Function) { check(false); return 0;}
	Obj->ProcessEvent(Function, NULL);
#endif
	return 0;
}

int32 OnRep_ReplicatedBasedMovement(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Character",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Character must be non-null"); lua_error(InScriptContext);  return 0;}
#if UE_GAME
	ACharacter * This = (ACharacter *)Obj;
	This->OnRep_ReplicatedBasedMovement();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("OnRep_ReplicatedBasedMovement"));
	if(!Function) { check(false); return 0;}
	Obj->ProcessEvent(Function, NULL);
#endif
	return 0;
}

int32 OnRep_ReplayLastTransformUpdateTimeStamp(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Character",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Character must be non-null"); lua_error(InScriptContext);  return 0;}
#if UE_GAME
	ACharacter * This = (ACharacter *)Obj;
	This->OnRep_ReplayLastTransformUpdateTimeStamp();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("OnRep_ReplayLastTransformUpdateTimeStamp"));
	if(!Function) { check(false); return 0;}
	Obj->ProcessEvent(Function, NULL);
#endif
	return 0;
}

int32 OnRep_IsCrouched(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Character",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Character must be non-null"); lua_error(InScriptContext);  return 0;}
#if UE_GAME
	ACharacter * This = (ACharacter *)Obj;
	This->OnRep_IsCrouched();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("OnRep_IsCrouched"));
	if(!Function) { check(false); return 0;}
	Obj->ProcessEvent(Function, NULL);
#endif
	return 0;
}

int32 OnLaunched(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Character",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Character must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FVector LaunchVelocity;
		bool bXYOverride;
		bool bZOverride;
	} Params;
	Params.LaunchVelocity = (wLua::FLuaVector::Get(InScriptContext, 2));
	Params.bXYOverride = !!(lua_toboolean(InScriptContext, 3));
	Params.bZOverride = !!(lua_toboolean(InScriptContext, 4));
#if UE_GAME
	ACharacter * This = (ACharacter *)Obj;
	This->OnLaunched(Params.LaunchVelocity,Params.bXYOverride,Params.bZOverride);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("OnLaunched"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FVector*)(params.GetStructMemory() + 0) = Params.LaunchVelocity;
		*(bool*)(params.GetStructMemory() + 12) = Params.bXYOverride;
		*(bool*)(params.GetStructMemory() + 13) = Params.bZOverride;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.LaunchVelocity = *(FVector*)(params.GetStructMemory() + 0);
		Params.bXYOverride = *(bool*)(params.GetStructMemory() + 12);
		Params.bZOverride = *(bool*)(params.GetStructMemory() + 13);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 OnJumped(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Character",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Character must be non-null"); lua_error(InScriptContext);  return 0;}
#if UE_GAME
	ACharacter * This = (ACharacter *)Obj;
	This->OnJumped();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("OnJumped"));
	if(!Function) { check(false); return 0;}
	Obj->ProcessEvent(Function, NULL);
#endif
	return 0;
}

int32 LaunchCharacter(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Character",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Character must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FVector LaunchVelocity;
		bool bXYOverride;
		bool bZOverride;
	} Params;
	Params.LaunchVelocity = (wLua::FLuaVector::Get(InScriptContext, 2));
	Params.bXYOverride = !!(lua_toboolean(InScriptContext, 3));
	Params.bZOverride = !!(lua_toboolean(InScriptContext, 4));
#if UE_GAME
	ACharacter * This = (ACharacter *)Obj;
	This->LaunchCharacter(Params.LaunchVelocity,Params.bXYOverride,Params.bZOverride);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("LaunchCharacter"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FVector*)(params.GetStructMemory() + 0) = Params.LaunchVelocity;
		*(bool*)(params.GetStructMemory() + 12) = Params.bXYOverride;
		*(bool*)(params.GetStructMemory() + 13) = Params.bZOverride;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.LaunchVelocity = *(FVector*)(params.GetStructMemory() + 0);
		Params.bXYOverride = *(bool*)(params.GetStructMemory() + 12);
		Params.bZOverride = *(bool*)(params.GetStructMemory() + 13);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 K2_UpdateCustomMovement(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Character",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Character must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float DeltaTime;
	} Params;
	Params.DeltaTime = (float)(luaL_checknumber(InScriptContext, 2));
#if UE_GAME
	ACharacter * This = (ACharacter *)Obj;
	This->K2_UpdateCustomMovement(Params.DeltaTime);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("K2_UpdateCustomMovement"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(float*)(params.GetStructMemory() + 0) = Params.DeltaTime;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.DeltaTime = *(float*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 K2_OnStartCrouch(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Character",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Character must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float HalfHeightAdjust;
		float ScaledHalfHeightAdjust;
	} Params;
	Params.HalfHeightAdjust = (float)(luaL_checknumber(InScriptContext, 2));
	Params.ScaledHalfHeightAdjust = (float)(luaL_checknumber(InScriptContext, 3));
#if UE_GAME
	ACharacter * This = (ACharacter *)Obj;
	This->K2_OnStartCrouch(Params.HalfHeightAdjust,Params.ScaledHalfHeightAdjust);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("K2_OnStartCrouch"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(float*)(params.GetStructMemory() + 0) = Params.HalfHeightAdjust;
		*(float*)(params.GetStructMemory() + 4) = Params.ScaledHalfHeightAdjust;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.HalfHeightAdjust = *(float*)(params.GetStructMemory() + 0);
		Params.ScaledHalfHeightAdjust = *(float*)(params.GetStructMemory() + 4);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 K2_OnMovementModeChanged(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Character",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Character must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		TEnumAsByte<EMovementMode> PrevMovementMode;
		TEnumAsByte<EMovementMode> NewMovementMode;
		uint8 PrevCustomMode;
		uint8 NewCustomMode;
	} Params;
	Params.PrevMovementMode = (TEnumAsByte<EMovementMode>)(luaL_checkint(InScriptContext, 2));
	Params.NewMovementMode = (TEnumAsByte<EMovementMode>)(luaL_checkint(InScriptContext, 3));
	Params.PrevCustomMode = (uint8)(luaL_checkint(InScriptContext, 4));
	Params.NewCustomMode = (uint8)(luaL_checkint(InScriptContext, 5));
#if UE_GAME
	ACharacter * This = (ACharacter *)Obj;
	This->K2_OnMovementModeChanged(Params.PrevMovementMode,Params.NewMovementMode,Params.PrevCustomMode,Params.NewCustomMode);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("K2_OnMovementModeChanged"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(TEnumAsByte<EMovementMode>*)(params.GetStructMemory() + 0) = Params.PrevMovementMode;
		*(TEnumAsByte<EMovementMode>*)(params.GetStructMemory() + 1) = Params.NewMovementMode;
		*(uint8*)(params.GetStructMemory() + 2) = Params.PrevCustomMode;
		*(uint8*)(params.GetStructMemory() + 3) = Params.NewCustomMode;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.PrevMovementMode = *(TEnumAsByte<EMovementMode>*)(params.GetStructMemory() + 0);
		Params.NewMovementMode = *(TEnumAsByte<EMovementMode>*)(params.GetStructMemory() + 1);
		Params.PrevCustomMode = *(uint8*)(params.GetStructMemory() + 2);
		Params.NewCustomMode = *(uint8*)(params.GetStructMemory() + 3);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 K2_OnEndCrouch(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Character",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Character must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float HalfHeightAdjust;
		float ScaledHalfHeightAdjust;
	} Params;
	Params.HalfHeightAdjust = (float)(luaL_checknumber(InScriptContext, 2));
	Params.ScaledHalfHeightAdjust = (float)(luaL_checknumber(InScriptContext, 3));
#if UE_GAME
	ACharacter * This = (ACharacter *)Obj;
	This->K2_OnEndCrouch(Params.HalfHeightAdjust,Params.ScaledHalfHeightAdjust);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("K2_OnEndCrouch"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(float*)(params.GetStructMemory() + 0) = Params.HalfHeightAdjust;
		*(float*)(params.GetStructMemory() + 4) = Params.ScaledHalfHeightAdjust;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.HalfHeightAdjust = *(float*)(params.GetStructMemory() + 0);
		Params.ScaledHalfHeightAdjust = *(float*)(params.GetStructMemory() + 4);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 Jump(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Character",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Character must be non-null"); lua_error(InScriptContext);  return 0;}
#if UE_GAME
	ACharacter * This = (ACharacter *)Obj;
	This->Jump();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("Jump"));
	if(!Function) { check(false); return 0;}
	Obj->ProcessEvent(Function, NULL);
#endif
	return 0;
}

int32 IsPlayingRootMotion(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Character",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Character must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool ReturnValue;
	} Params;
#if UE_GAME
	ACharacter * This = (ACharacter *)Obj;
	Params.ReturnValue = This->IsPlayingRootMotion();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("IsPlayingRootMotion"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushboolean(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 IsPlayingNetworkedRootMotionMontage(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Character",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Character must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool ReturnValue;
	} Params;
#if UE_GAME
	ACharacter * This = (ACharacter *)Obj;
	Params.ReturnValue = This->IsPlayingNetworkedRootMotionMontage();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("IsPlayingNetworkedRootMotionMontage"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushboolean(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 IsJumpProvidingForce(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Character",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Character must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool ReturnValue;
	} Params;
#if UE_GAME
	ACharacter * This = (ACharacter *)Obj;
	Params.ReturnValue = This->IsJumpProvidingForce();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("IsJumpProvidingForce"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushboolean(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetCurrentMontage(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Character",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Character must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		UAnimMontage* ReturnValue = nullptr;
	} Params;
#if UE_GAME
	ACharacter * This = (ACharacter *)Obj;
	Params.ReturnValue = This->GetCurrentMontage();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetCurrentMontage"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(UAnimMontage**)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetBaseTranslationOffset(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Character",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Character must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FVector ReturnValue;
	} Params;
#if UE_GAME
	ACharacter * This = (ACharacter *)Obj;
	Params.ReturnValue = This->GetBaseTranslationOffset();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetBaseTranslationOffset"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(FVector*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaVector::Return(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetBaseRotationOffsetRotator(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Character",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Character must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FRotator ReturnValue;
	} Params;
#if UE_GAME
	ACharacter * This = (ACharacter *)Obj;
	Params.ReturnValue = This->GetBaseRotationOffsetRotator();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetBaseRotationOffsetRotator"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(FRotator*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaRotator::Return(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetAnimRootMotionTranslationScale(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Character",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Character must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float ReturnValue;
	} Params;
#if UE_GAME
	ACharacter * This = (ACharacter *)Obj;
	Params.ReturnValue = This->GetAnimRootMotionTranslationScale();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetAnimRootMotionTranslationScale"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(float*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushnumber(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 Crouch(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Character",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Character must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool bClientSimulation;
	} Params;
	Params.bClientSimulation = lua_isnoneornil(InScriptContext,2) ? bool(false) : !!(lua_toboolean(InScriptContext, 2));
#if UE_GAME
	ACharacter * This = (ACharacter *)Obj;
	This->Crouch(Params.bClientSimulation);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("Crouch"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(bool*)(params.GetStructMemory() + 0) = Params.bClientSimulation;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.bClientSimulation = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 ClientVeryShortAdjustPosition(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Character",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Character must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float TimeStamp;
		FVector NewLoc;
		UPrimitiveComponent* NewBase = nullptr;
		FName NewBaseBoneName;
		bool bHasBase;
		bool bBaseRelativePosition;
		uint8 ServerMovementMode;
	} Params;
	Params.TimeStamp = (float)(luaL_checknumber(InScriptContext, 2));
	Params.NewLoc = (wLua::FLuaVector::Get(InScriptContext, 3));
	Params.NewBase = (UPrimitiveComponent*)wLua::FLuaUtils::GetUObject(InScriptContext,4,"PrimitiveComponent");;
	Params.NewBaseBoneName = FName(UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 5)));
	Params.bHasBase = !!(lua_toboolean(InScriptContext, 6));
	Params.bBaseRelativePosition = !!(lua_toboolean(InScriptContext, 7));
	Params.ServerMovementMode = (uint8)(luaL_checkint(InScriptContext, 8));
#if UE_GAME
	ACharacter * This = (ACharacter *)Obj;
	This->ClientVeryShortAdjustPosition(Params.TimeStamp,Params.NewLoc,Params.NewBase,Params.NewBaseBoneName,Params.bHasBase,Params.bBaseRelativePosition,Params.ServerMovementMode);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("ClientVeryShortAdjustPosition"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(float*)(params.GetStructMemory() + 0) = Params.TimeStamp;
		*(FVector*)(params.GetStructMemory() + 4) = Params.NewLoc;
		*(UPrimitiveComponent**)(params.GetStructMemory() + 16) = Params.NewBase;
		*(FName*)(params.GetStructMemory() + 24) = Params.NewBaseBoneName;
		*(bool*)(params.GetStructMemory() + 36) = Params.bHasBase;
		*(bool*)(params.GetStructMemory() + 37) = Params.bBaseRelativePosition;
		*(uint8*)(params.GetStructMemory() + 38) = Params.ServerMovementMode;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.TimeStamp = *(float*)(params.GetStructMemory() + 0);
		Params.NewLoc = *(FVector*)(params.GetStructMemory() + 4);
		Params.NewBase = *(UPrimitiveComponent**)(params.GetStructMemory() + 16);
		Params.NewBaseBoneName = *(FName*)(params.GetStructMemory() + 24);
		Params.bHasBase = *(bool*)(params.GetStructMemory() + 36);
		Params.bBaseRelativePosition = *(bool*)(params.GetStructMemory() + 37);
		Params.ServerMovementMode = *(uint8*)(params.GetStructMemory() + 38);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 ClientCheatWalk(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Character",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Character must be non-null"); lua_error(InScriptContext);  return 0;}
#if UE_GAME
	ACharacter * This = (ACharacter *)Obj;
	This->ClientCheatWalk();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("ClientCheatWalk"));
	if(!Function) { check(false); return 0;}
	Obj->ProcessEvent(Function, NULL);
#endif
	return 0;
}

int32 ClientCheatGhost(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Character",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Character must be non-null"); lua_error(InScriptContext);  return 0;}
#if UE_GAME
	ACharacter * This = (ACharacter *)Obj;
	This->ClientCheatGhost();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("ClientCheatGhost"));
	if(!Function) { check(false); return 0;}
	Obj->ProcessEvent(Function, NULL);
#endif
	return 0;
}

int32 ClientCheatFly(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Character",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Character must be non-null"); lua_error(InScriptContext);  return 0;}
#if UE_GAME
	ACharacter * This = (ACharacter *)Obj;
	This->ClientCheatFly();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("ClientCheatFly"));
	if(!Function) { check(false); return 0;}
	Obj->ProcessEvent(Function, NULL);
#endif
	return 0;
}

int32 ClientAdjustPosition(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Character",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Character must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float TimeStamp;
		FVector NewLoc;
		FVector NewVel;
		UPrimitiveComponent* NewBase = nullptr;
		FName NewBaseBoneName;
		bool bHasBase;
		bool bBaseRelativePosition;
		uint8 ServerMovementMode;
	} Params;
	Params.TimeStamp = (float)(luaL_checknumber(InScriptContext, 2));
	Params.NewLoc = (wLua::FLuaVector::Get(InScriptContext, 3));
	Params.NewVel = (wLua::FLuaVector::Get(InScriptContext, 4));
	Params.NewBase = (UPrimitiveComponent*)wLua::FLuaUtils::GetUObject(InScriptContext,5,"PrimitiveComponent");;
	Params.NewBaseBoneName = FName(UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 6)));
	Params.bHasBase = !!(lua_toboolean(InScriptContext, 7));
	Params.bBaseRelativePosition = !!(lua_toboolean(InScriptContext, 8));
	Params.ServerMovementMode = (uint8)(luaL_checkint(InScriptContext, 9));
#if UE_GAME
	ACharacter * This = (ACharacter *)Obj;
	This->ClientAdjustPosition(Params.TimeStamp,Params.NewLoc,Params.NewVel,Params.NewBase,Params.NewBaseBoneName,Params.bHasBase,Params.bBaseRelativePosition,Params.ServerMovementMode);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("ClientAdjustPosition"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(float*)(params.GetStructMemory() + 0) = Params.TimeStamp;
		*(FVector*)(params.GetStructMemory() + 4) = Params.NewLoc;
		*(FVector*)(params.GetStructMemory() + 16) = Params.NewVel;
		*(UPrimitiveComponent**)(params.GetStructMemory() + 32) = Params.NewBase;
		*(FName*)(params.GetStructMemory() + 40) = Params.NewBaseBoneName;
		*(bool*)(params.GetStructMemory() + 52) = Params.bHasBase;
		*(bool*)(params.GetStructMemory() + 53) = Params.bBaseRelativePosition;
		*(uint8*)(params.GetStructMemory() + 54) = Params.ServerMovementMode;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.TimeStamp = *(float*)(params.GetStructMemory() + 0);
		Params.NewLoc = *(FVector*)(params.GetStructMemory() + 4);
		Params.NewVel = *(FVector*)(params.GetStructMemory() + 16);
		Params.NewBase = *(UPrimitiveComponent**)(params.GetStructMemory() + 32);
		Params.NewBaseBoneName = *(FName*)(params.GetStructMemory() + 40);
		Params.bHasBase = *(bool*)(params.GetStructMemory() + 52);
		Params.bBaseRelativePosition = *(bool*)(params.GetStructMemory() + 53);
		Params.ServerMovementMode = *(uint8*)(params.GetStructMemory() + 54);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 ClientAckGoodMove(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Character",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Character must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float TimeStamp;
	} Params;
	Params.TimeStamp = (float)(luaL_checknumber(InScriptContext, 2));
#if UE_GAME
	ACharacter * This = (ACharacter *)Obj;
	This->ClientAckGoodMove(Params.TimeStamp);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("ClientAckGoodMove"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(float*)(params.GetStructMemory() + 0) = Params.TimeStamp;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.TimeStamp = *(float*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 CanJumpInternal(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Character",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Character must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool ReturnValue;
	} Params;
	UFunction* Function = Obj->FindFunctionChecked(TEXT("CanJumpInternal"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
	lua_pushboolean(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 CanJump(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Character",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Character must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool ReturnValue;
	} Params;
#if UE_GAME
	ACharacter * This = (ACharacter *)Obj;
	Params.ReturnValue = This->CanJump();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("CanJump"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushboolean(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 CacheInitialMeshOffset(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Character",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Character must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FVector MeshRelativeLocation;
		FRotator MeshRelativeRotation;
	} Params;
	Params.MeshRelativeLocation = (wLua::FLuaVector::Get(InScriptContext, 2));
	Params.MeshRelativeRotation = (wLua::FLuaRotator::Get(InScriptContext, 3));
#if UE_GAME
	ACharacter * This = (ACharacter *)Obj;
	This->CacheInitialMeshOffset(Params.MeshRelativeLocation,Params.MeshRelativeRotation);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("CacheInitialMeshOffset"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FVector*)(params.GetStructMemory() + 0) = Params.MeshRelativeLocation;
		*(FRotator*)(params.GetStructMemory() + 12) = Params.MeshRelativeRotation;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.MeshRelativeLocation = *(FVector*)(params.GetStructMemory() + 0);
		Params.MeshRelativeRotation = *(FRotator*)(params.GetStructMemory() + 12);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 Get_Mesh(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Character",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Character must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(ACharacter::StaticClass(), TEXT("Mesh"));
	if(!Property) { check(false); return 0;}
	USkeletalMeshComponent* PropertyValue;
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaUtils::ReturnUObject(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_CharacterMovement(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Character",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Character must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(ACharacter::StaticClass(), TEXT("CharacterMovement"));
	if(!Property) { check(false); return 0;}
	UCharacterMovementComponent* PropertyValue;
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaUtils::ReturnUObject(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_CapsuleComponent(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Character",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Character must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(ACharacter::StaticClass(), TEXT("CapsuleComponent"));
	if(!Property) { check(false); return 0;}
	UCapsuleComponent* PropertyValue;
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaUtils::ReturnUObject(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_CrouchedEyeHeight(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Character",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Character must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(ACharacter::StaticClass(), TEXT("CrouchedEyeHeight"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_CrouchedEyeHeight(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Character",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Character must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(ACharacter::StaticClass(), TEXT("CrouchedEyeHeight"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bIsCrouched(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Character",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Character must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(ACharacter::StaticClass(), TEXT("bIsCrouched"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_bPressedJump(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Character",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Character must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(ACharacter::StaticClass(), TEXT("bPressedJump"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_bWasJumping(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Character",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Character must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(ACharacter::StaticClass(), TEXT("bWasJumping"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_JumpKeyHoldTime(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Character",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Character must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(ACharacter::StaticClass(), TEXT("JumpKeyHoldTime"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_JumpForceTimeRemaining(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Character",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Character must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(ACharacter::StaticClass(), TEXT("JumpForceTimeRemaining"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_ProxyJumpForceStartedTime(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Character",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Character must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(ACharacter::StaticClass(), TEXT("ProxyJumpForceStartedTime"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_JumpMaxHoldTime(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Character",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Character must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(ACharacter::StaticClass(), TEXT("JumpMaxHoldTime"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_JumpMaxHoldTime(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Character",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Character must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(ACharacter::StaticClass(), TEXT("JumpMaxHoldTime"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_JumpMaxCount(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Character",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Character must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(ACharacter::StaticClass(), TEXT("JumpMaxCount"));
	if(!Property) { check(false); return 0;}
	int32 PropertyValue = int32();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushinteger(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_JumpMaxCount(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Character",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Character must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(ACharacter::StaticClass(), TEXT("JumpMaxCount"));
	if(!Property) { check(false); return 0;}
	int32 PropertyValue = (luaL_checkint(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_JumpCurrentCount(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Character",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Character must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(ACharacter::StaticClass(), TEXT("JumpCurrentCount"));
	if(!Property) { check(false); return 0;}
	int32 PropertyValue = int32();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushinteger(InScriptContext, PropertyValue);
	return 1;
}

int32 Call_OnReachedJumpApex(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Character",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Character must be non-null"); lua_error(InScriptContext);  return 0;}
	ACharacter * This = (ACharacter *)Obj;
	This->OnReachedJumpApex.Broadcast();
	return 0;
}

int32 Call_MovementModeChangedDelegate(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Character",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Character must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		ACharacter* Character = nullptr;
		TEnumAsByte<EMovementMode> PrevMovementMode;
		uint8 PreviousCustomMode;
	} Params;
	Params.Character = (ACharacter*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"Character");;
	Params.PrevMovementMode = (TEnumAsByte<EMovementMode>)(luaL_checkint(InScriptContext, 3));
	Params.PreviousCustomMode = (uint8)(luaL_checkint(InScriptContext, 4));
	ACharacter * This = (ACharacter *)Obj;
	This->MovementModeChangedDelegate.Broadcast(Params.Character,Params.PrevMovementMode,Params.PreviousCustomMode);
	return 0;
}

int32 Call_OnCharacterMovementUpdated(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Character",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Character must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float DeltaSeconds;
		FVector OldLocation;
		FVector OldVelocity;
	} Params;
	Params.DeltaSeconds = (float)(luaL_checknumber(InScriptContext, 2));
	Params.OldLocation = (wLua::FLuaVector::Get(InScriptContext, 3));
	Params.OldVelocity = (wLua::FLuaVector::Get(InScriptContext, 4));
	ACharacter * This = (ACharacter *)Obj;
	This->OnCharacterMovementUpdated.Broadcast(Params.DeltaSeconds,Params.OldLocation,Params.OldVelocity);
	return 0;
}

int32 New(lua_State* InScriptContext)
{
	UObject* Outer = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Object");
	FName Name = FName(luaL_checkstring(InScriptContext, 2));
	UObject* Obj = NewObject<ACharacter>(Outer, Name);
	wLua::FLuaUtils::ReturnUObject(InScriptContext,Obj);
	return 1;
}

int32 Destroy(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Character",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Character must be non-null"); lua_error(InScriptContext);  return 0;}
		AActor * actor = Cast<AActor>(Obj);
		actor->Destroy();
		userdata->flag |= wLua::LuaObjectFlag::DESTROYED;
		wLua::FLuaUtils::RemoveObjectReference(Obj, userdata->stamp, InScriptContext);
#ifdef AZURE_BUILD_WLUACHECK
		UE_LOG(LogAzure, Warning, TEXT("Destroy Character: %x userdata:%x   stamp:%x"),Obj,userdata,userdata->stamp);
#endif
	return 0;
}

int32 Class(lua_State* InScriptContext)
{
	UClass* Class = ACharacter::StaticClass();
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Class);
	return 1;
}

const luaL_Reg Lib_Funcs[] =
{
	{ "New", New },
	{ "Destroy", Destroy },
	{ "Class", Class },
	{ "UnCrouch", UnCrouch },
	{ "StopJumping", StopJumping },
	{ "StopAnimMontage", StopAnimMontage },
	{ "RootMotionDebugClientPrintOnScreen", RootMotionDebugClientPrintOnScreen },
	{ "PlayAnimMontage", PlayAnimMontage },
	{ "OnWalkingOffLedge", OnWalkingOffLedge },
	{ "OnRep_RootMotion", OnRep_RootMotion },
	{ "OnRep_ReplicatedBasedMovement", OnRep_ReplicatedBasedMovement },
	{ "OnRep_ReplayLastTransformUpdateTimeStamp", OnRep_ReplayLastTransformUpdateTimeStamp },
	{ "OnRep_IsCrouched", OnRep_IsCrouched },
	{ "OnLaunched", OnLaunched },
	{ "OnJumped", OnJumped },
	{ "LaunchCharacter", LaunchCharacter },
	{ "UpdateCustomMovement", K2_UpdateCustomMovement },
	{ "OnStartCrouch", K2_OnStartCrouch },
	{ "OnMovementModeChanged", K2_OnMovementModeChanged },
	{ "OnEndCrouch", K2_OnEndCrouch },
	{ "Jump", Jump },
	{ "IsPlayingRootMotion", IsPlayingRootMotion },
	{ "IsPlayingNetworkedRootMotionMontage", IsPlayingNetworkedRootMotionMontage },
	{ "IsJumpProvidingForce", IsJumpProvidingForce },
	{ "GetCurrentMontage", GetCurrentMontage },
	{ "GetBaseTranslationOffset", GetBaseTranslationOffset },
	{ "GetBaseRotationOffsetRotator", GetBaseRotationOffsetRotator },
	{ "GetAnimRootMotionTranslationScale", GetAnimRootMotionTranslationScale },
	{ "Crouch", Crouch },
	{ "ClientVeryShortAdjustPosition", ClientVeryShortAdjustPosition },
	{ "ClientCheatWalk", ClientCheatWalk },
	{ "ClientCheatGhost", ClientCheatGhost },
	{ "ClientCheatFly", ClientCheatFly },
	{ "ClientAdjustPosition", ClientAdjustPosition },
	{ "ClientAckGoodMove", ClientAckGoodMove },
	{ "CanJumpInternal", CanJumpInternal },
	{ "CanJump", CanJump },
	{ "CacheInitialMeshOffset", CacheInitialMeshOffset },
	{ "Get_Mesh", Get_Mesh },
	{ "Get_CharacterMovement", Get_CharacterMovement },
	{ "Get_CapsuleComponent", Get_CapsuleComponent },
	{ "Get_CrouchedEyeHeight", Get_CrouchedEyeHeight },
	{ "Set_CrouchedEyeHeight", Set_CrouchedEyeHeight },
	{ "Get_bIsCrouched", Get_bIsCrouched },
	{ "Get_bPressedJump", Get_bPressedJump },
	{ "Get_bWasJumping", Get_bWasJumping },
	{ "Get_JumpKeyHoldTime", Get_JumpKeyHoldTime },
	{ "Get_JumpForceTimeRemaining", Get_JumpForceTimeRemaining },
	{ "Get_ProxyJumpForceStartedTime", Get_ProxyJumpForceStartedTime },
	{ "Get_JumpMaxHoldTime", Get_JumpMaxHoldTime },
	{ "Set_JumpMaxHoldTime", Set_JumpMaxHoldTime },
	{ "Get_JumpMaxCount", Get_JumpMaxCount },
	{ "Set_JumpMaxCount", Set_JumpMaxCount },
	{ "Get_JumpCurrentCount", Get_JumpCurrentCount },
	{ "Call_OnReachedJumpApex", Call_OnReachedJumpApex },
	{ "Call_MovementModeChangedDelegate", Call_MovementModeChangedDelegate },
	{ "Call_OnCharacterMovementUpdated", Call_OnCharacterMovementUpdated },
	{ "SetAnimRootMotionTranslationScale", SetAnimRootMotionTranslationScale },
	{ "is_nil", wLua::LuaStatic::isnil },
	{ "__gc", wLua::LuaStatic::removeUClassFrameCache },
	{ NULL, NULL }
};

void Register(lua_State *InScriptContext)
{
	lua_newtable(InScriptContext);
	luaL_register(InScriptContext, NULL, Lib_Funcs);
	AzureHelpFuncs::AuxRegister(InScriptContext, "Character");
}
void SetMtLink(lua_State *InScriptContext)
{
	AzureHelpFuncs::AuxSetMtLink(InScriptContext, "Character", "Pawn",USERDATATYPE_UOBJECT);
}

}