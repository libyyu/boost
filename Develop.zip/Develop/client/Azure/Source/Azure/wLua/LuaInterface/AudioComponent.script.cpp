#include "Azure.h"
#include "Utility/help_funcs.h"
#include "wLua/UObjectHeaders.h"
#include "Components/AudioComponent.h"
#include "AzureLuaIntegration.h"

namespace LuaAudioComponent
{
int32 Stop(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AudioComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AudioComponent must be non-null"); lua_error(InScriptContext);  return 0;}
#if UE_GAME
	UAudioComponent * This = (UAudioComponent *)Obj;
	This->Stop();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("Stop"));
	if(!Function) { check(false); return 0;}
	Obj->ProcessEvent(Function, NULL);
#endif
	return 0;
}

int32 SetWaveParameter(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AudioComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AudioComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FName InName;
		USoundWave* InWave = nullptr;
	} Params;
	Params.InName = FName(UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 2)));
	Params.InWave = (USoundWave*)wLua::FLuaUtils::GetUObject(InScriptContext,3,"SoundWave");;
#if UE_GAME
	UAudioComponent * This = (UAudioComponent *)Obj;
	This->SetWaveParameter(Params.InName,Params.InWave);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetWaveParameter"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FName*)(params.GetStructMemory() + 0) = Params.InName;
		*(USoundWave**)(params.GetStructMemory() + 16) = Params.InWave;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.InName = *(FName*)(params.GetStructMemory() + 0);
		Params.InWave = *(USoundWave**)(params.GetStructMemory() + 16);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetVolumeMultiplier(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AudioComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AudioComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float NewVolumeMultiplier;
	} Params;
	Params.NewVolumeMultiplier = (float)(luaL_checknumber(InScriptContext, 2));
#if UE_GAME
	UAudioComponent * This = (UAudioComponent *)Obj;
	This->SetVolumeMultiplier(Params.NewVolumeMultiplier);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetVolumeMultiplier"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(float*)(params.GetStructMemory() + 0) = Params.NewVolumeMultiplier;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.NewVolumeMultiplier = *(float*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetUISound(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AudioComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AudioComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool bInUISound;
	} Params;
	Params.bInUISound = !!(lua_toboolean(InScriptContext, 2));
#if UE_GAME
	UAudioComponent * This = (UAudioComponent *)Obj;
	This->SetUISound(Params.bInUISound);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetUISound"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(bool*)(params.GetStructMemory() + 0) = Params.bInUISound;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.bInUISound = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetSubmixSend(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AudioComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AudioComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		USoundSubmix* Submix = nullptr;
		float SendLevel;
	} Params;
	Params.Submix = (USoundSubmix*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"SoundSubmix");;
	Params.SendLevel = (float)(luaL_checknumber(InScriptContext, 3));
#if UE_GAME
	UAudioComponent * This = (UAudioComponent *)Obj;
	This->SetSubmixSend(Params.Submix,Params.SendLevel);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetSubmixSend"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(USoundSubmix**)(params.GetStructMemory() + 0) = Params.Submix;
		*(float*)(params.GetStructMemory() + 8) = Params.SendLevel;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.Submix = *(USoundSubmix**)(params.GetStructMemory() + 0);
		Params.SendLevel = *(float*)(params.GetStructMemory() + 8);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetSound(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AudioComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AudioComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		USoundBase* NewSound = nullptr;
	} Params;
	Params.NewSound = (USoundBase*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"SoundBase");;
#if UE_GAME
	UAudioComponent * This = (UAudioComponent *)Obj;
	This->SetSound(Params.NewSound);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetSound"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(USoundBase**)(params.GetStructMemory() + 0) = Params.NewSound;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.NewSound = *(USoundBase**)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetPitchMultiplier(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AudioComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AudioComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float NewPitchMultiplier;
	} Params;
	Params.NewPitchMultiplier = (float)(luaL_checknumber(InScriptContext, 2));
#if UE_GAME
	UAudioComponent * This = (UAudioComponent *)Obj;
	This->SetPitchMultiplier(Params.NewPitchMultiplier);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetPitchMultiplier"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(float*)(params.GetStructMemory() + 0) = Params.NewPitchMultiplier;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.NewPitchMultiplier = *(float*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetPaused(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AudioComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AudioComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool bPause;
	} Params;
	Params.bPause = !!(lua_toboolean(InScriptContext, 2));
#if UE_GAME
	UAudioComponent * This = (UAudioComponent *)Obj;
	This->SetPaused(Params.bPause);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetPaused"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(bool*)(params.GetStructMemory() + 0) = Params.bPause;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.bPause = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetLowPassFilterFrequency(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AudioComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AudioComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float InLowPassFilterFrequency;
	} Params;
	Params.InLowPassFilterFrequency = (float)(luaL_checknumber(InScriptContext, 2));
#if UE_GAME
	UAudioComponent * This = (UAudioComponent *)Obj;
	This->SetLowPassFilterFrequency(Params.InLowPassFilterFrequency);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetLowPassFilterFrequency"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(float*)(params.GetStructMemory() + 0) = Params.InLowPassFilterFrequency;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.InLowPassFilterFrequency = *(float*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetLowPassFilterEnabled(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AudioComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AudioComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool InLowPassFilterEnabled;
	} Params;
	Params.InLowPassFilterEnabled = !!(lua_toboolean(InScriptContext, 2));
#if UE_GAME
	UAudioComponent * This = (UAudioComponent *)Obj;
	This->SetLowPassFilterEnabled(Params.InLowPassFilterEnabled);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetLowPassFilterEnabled"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(bool*)(params.GetStructMemory() + 0) = Params.InLowPassFilterEnabled;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.InLowPassFilterEnabled = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetIntParameter(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AudioComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AudioComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FName InName;
		int32 InInt;
	} Params;
	Params.InName = FName(UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 2)));
	Params.InInt = (luaL_checkint(InScriptContext, 3));
#if UE_GAME
	UAudioComponent * This = (UAudioComponent *)Obj;
	This->SetIntParameter(Params.InName,Params.InInt);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetIntParameter"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FName*)(params.GetStructMemory() + 0) = Params.InName;
		*(int32*)(params.GetStructMemory() + 12) = Params.InInt;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.InName = *(FName*)(params.GetStructMemory() + 0);
		Params.InInt = *(int32*)(params.GetStructMemory() + 12);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetFloatParameter(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AudioComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AudioComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FName InName;
		float InFloat;
	} Params;
	Params.InName = FName(UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 2)));
	Params.InFloat = (float)(luaL_checknumber(InScriptContext, 3));
#if UE_GAME
	UAudioComponent * This = (UAudioComponent *)Obj;
	This->SetFloatParameter(Params.InName,Params.InFloat);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetFloatParameter"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FName*)(params.GetStructMemory() + 0) = Params.InName;
		*(float*)(params.GetStructMemory() + 12) = Params.InFloat;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.InName = *(FName*)(params.GetStructMemory() + 0);
		Params.InFloat = *(float*)(params.GetStructMemory() + 12);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetBoolParameter(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AudioComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AudioComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FName InName;
		bool InBool;
	} Params;
	Params.InName = FName(UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 2)));
	Params.InBool = !!(lua_toboolean(InScriptContext, 3));
#if UE_GAME
	UAudioComponent * This = (UAudioComponent *)Obj;
	This->SetBoolParameter(Params.InName,Params.InBool);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetBoolParameter"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FName*)(params.GetStructMemory() + 0) = Params.InName;
		*(bool*)(params.GetStructMemory() + 12) = Params.InBool;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.InName = *(FName*)(params.GetStructMemory() + 0);
		Params.InBool = *(bool*)(params.GetStructMemory() + 12);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 Play(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AudioComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AudioComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float StartTime;
	} Params;
	Params.StartTime = lua_isnoneornil(InScriptContext,2) ? float(0.000000) : (float)(luaL_checknumber(InScriptContext, 2));
#if UE_GAME
	UAudioComponent * This = (UAudioComponent *)Obj;
	This->Play(Params.StartTime);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("Play"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(float*)(params.GetStructMemory() + 0) = Params.StartTime;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.StartTime = *(float*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 IsPlaying(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AudioComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AudioComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool ReturnValue;
	} Params;
#if UE_GAME
	UAudioComponent * This = (UAudioComponent *)Obj;
	Params.ReturnValue = This->IsPlaying();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("IsPlaying"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushboolean(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 FadeOut(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AudioComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AudioComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float FadeOutDuration;
		float FadeVolumeLevel;
	} Params;
	Params.FadeOutDuration = (float)(luaL_checknumber(InScriptContext, 2));
	Params.FadeVolumeLevel = (float)(luaL_checknumber(InScriptContext, 3));
#if UE_GAME
	UAudioComponent * This = (UAudioComponent *)Obj;
	This->FadeOut(Params.FadeOutDuration,Params.FadeVolumeLevel);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("FadeOut"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(float*)(params.GetStructMemory() + 0) = Params.FadeOutDuration;
		*(float*)(params.GetStructMemory() + 4) = Params.FadeVolumeLevel;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.FadeOutDuration = *(float*)(params.GetStructMemory() + 0);
		Params.FadeVolumeLevel = *(float*)(params.GetStructMemory() + 4);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 FadeIn(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AudioComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AudioComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float FadeInDuration;
		float FadeVolumeLevel;
		float StartTime;
	} Params;
	Params.FadeInDuration = (float)(luaL_checknumber(InScriptContext, 2));
	Params.FadeVolumeLevel = lua_isnoneornil(InScriptContext,3) ? float(1.000000) : (float)(luaL_checknumber(InScriptContext, 3));
	Params.StartTime = lua_isnoneornil(InScriptContext,4) ? float(0.000000) : (float)(luaL_checknumber(InScriptContext, 4));
#if UE_GAME
	UAudioComponent * This = (UAudioComponent *)Obj;
	This->FadeIn(Params.FadeInDuration,Params.FadeVolumeLevel,Params.StartTime);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("FadeIn"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(float*)(params.GetStructMemory() + 0) = Params.FadeInDuration;
		*(float*)(params.GetStructMemory() + 4) = Params.FadeVolumeLevel;
		*(float*)(params.GetStructMemory() + 8) = Params.StartTime;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.FadeInDuration = *(float*)(params.GetStructMemory() + 0);
		Params.FadeVolumeLevel = *(float*)(params.GetStructMemory() + 4);
		Params.StartTime = *(float*)(params.GetStructMemory() + 8);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 AdjustVolume(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AudioComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AudioComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float AdjustVolumeDuration;
		float AdjustVolumeLevel;
	} Params;
	Params.AdjustVolumeDuration = (float)(luaL_checknumber(InScriptContext, 2));
	Params.AdjustVolumeLevel = (float)(luaL_checknumber(InScriptContext, 3));
#if UE_GAME
	UAudioComponent * This = (UAudioComponent *)Obj;
	This->AdjustVolume(Params.AdjustVolumeDuration,Params.AdjustVolumeLevel);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("AdjustVolume"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(float*)(params.GetStructMemory() + 0) = Params.AdjustVolumeDuration;
		*(float*)(params.GetStructMemory() + 4) = Params.AdjustVolumeLevel;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.AdjustVolumeDuration = *(float*)(params.GetStructMemory() + 0);
		Params.AdjustVolumeLevel = *(float*)(params.GetStructMemory() + 4);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 Get_Sound(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AudioComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AudioComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAudioComponent::StaticClass(), TEXT("Sound"));
	if(!Property) { check(false); return 0;}
	USoundBase* PropertyValue;
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaUtils::ReturnUObject(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_Sound(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AudioComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AudioComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAudioComponent::StaticClass(), TEXT("Sound"));
	if(!Property) { check(false); return 0;}
	USoundBase* PropertyValue = (USoundBase*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"SoundBase");;
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_SoundClassOverride(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AudioComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AudioComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAudioComponent::StaticClass(), TEXT("SoundClassOverride"));
	if(!Property) { check(false); return 0;}
	USoundClass* PropertyValue;
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaUtils::ReturnUObject(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_SoundClassOverride(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AudioComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AudioComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAudioComponent::StaticClass(), TEXT("SoundClassOverride"));
	if(!Property) { check(false); return 0;}
	USoundClass* PropertyValue = (USoundClass*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"SoundClass");;
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bAllowSpatialization(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AudioComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AudioComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAudioComponent::StaticClass(), TEXT("bAllowSpatialization"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bAllowSpatialization(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AudioComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AudioComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAudioComponent::StaticClass(), TEXT("bAllowSpatialization"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bOverrideAttenuation(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AudioComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AudioComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAudioComponent::StaticClass(), TEXT("bOverrideAttenuation"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bOverrideAttenuation(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AudioComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AudioComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAudioComponent::StaticClass(), TEXT("bOverrideAttenuation"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bOverrideSubtitlePriority(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AudioComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AudioComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAudioComponent::StaticClass(), TEXT("bOverrideSubtitlePriority"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bOverrideSubtitlePriority(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AudioComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AudioComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAudioComponent::StaticClass(), TEXT("bOverrideSubtitlePriority"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bIsUISound(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AudioComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AudioComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAudioComponent::StaticClass(), TEXT("bIsUISound"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bIsUISound(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AudioComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AudioComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAudioComponent::StaticClass(), TEXT("bIsUISound"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bEnableLowPassFilter(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AudioComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AudioComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAudioComponent::StaticClass(), TEXT("bEnableLowPassFilter"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bEnableLowPassFilter(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AudioComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AudioComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAudioComponent::StaticClass(), TEXT("bEnableLowPassFilter"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bOverridePriority(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AudioComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AudioComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAudioComponent::StaticClass(), TEXT("bOverridePriority"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bOverridePriority(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AudioComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AudioComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAudioComponent::StaticClass(), TEXT("bOverridePriority"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bSuppressSubtitles(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AudioComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AudioComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAudioComponent::StaticClass(), TEXT("bSuppressSubtitles"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bSuppressSubtitles(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AudioComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AudioComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAudioComponent::StaticClass(), TEXT("bSuppressSubtitles"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bAutoManageAttachment(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AudioComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AudioComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAudioComponent::StaticClass(), TEXT("bAutoManageAttachment"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_PitchModulationMin(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AudioComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AudioComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAudioComponent::StaticClass(), TEXT("PitchModulationMin"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_PitchModulationMin(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AudioComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AudioComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAudioComponent::StaticClass(), TEXT("PitchModulationMin"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_PitchModulationMax(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AudioComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AudioComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAudioComponent::StaticClass(), TEXT("PitchModulationMax"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_PitchModulationMax(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AudioComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AudioComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAudioComponent::StaticClass(), TEXT("PitchModulationMax"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_VolumeModulationMin(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AudioComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AudioComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAudioComponent::StaticClass(), TEXT("VolumeModulationMin"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_VolumeModulationMin(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AudioComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AudioComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAudioComponent::StaticClass(), TEXT("VolumeModulationMin"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_VolumeModulationMax(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AudioComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AudioComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAudioComponent::StaticClass(), TEXT("VolumeModulationMax"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_VolumeModulationMax(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AudioComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AudioComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAudioComponent::StaticClass(), TEXT("VolumeModulationMax"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_VolumeMultiplier(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AudioComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AudioComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAudioComponent::StaticClass(), TEXT("VolumeMultiplier"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_VolumeMultiplier(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AudioComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AudioComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAudioComponent::StaticClass(), TEXT("VolumeMultiplier"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_EnvelopeFollowerAttackTime(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AudioComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AudioComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAudioComponent::StaticClass(), TEXT("EnvelopeFollowerAttackTime"));
	if(!Property) { check(false); return 0;}
	int32 PropertyValue = int32();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushinteger(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_EnvelopeFollowerAttackTime(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AudioComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AudioComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAudioComponent::StaticClass(), TEXT("EnvelopeFollowerAttackTime"));
	if(!Property) { check(false); return 0;}
	int32 PropertyValue = (luaL_checkint(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_EnvelopeFollowerReleaseTime(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AudioComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AudioComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAudioComponent::StaticClass(), TEXT("EnvelopeFollowerReleaseTime"));
	if(!Property) { check(false); return 0;}
	int32 PropertyValue = int32();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushinteger(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_EnvelopeFollowerReleaseTime(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AudioComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AudioComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAudioComponent::StaticClass(), TEXT("EnvelopeFollowerReleaseTime"));
	if(!Property) { check(false); return 0;}
	int32 PropertyValue = (luaL_checkint(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_Priority(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AudioComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AudioComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAudioComponent::StaticClass(), TEXT("Priority"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_Priority(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AudioComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AudioComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAudioComponent::StaticClass(), TEXT("Priority"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_SubtitlePriority(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AudioComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AudioComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAudioComponent::StaticClass(), TEXT("SubtitlePriority"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_SubtitlePriority(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AudioComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AudioComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAudioComponent::StaticClass(), TEXT("SubtitlePriority"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_PitchMultiplier(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AudioComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AudioComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAudioComponent::StaticClass(), TEXT("PitchMultiplier"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_PitchMultiplier(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AudioComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AudioComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAudioComponent::StaticClass(), TEXT("PitchMultiplier"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_LowPassFilterFrequency(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AudioComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AudioComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAudioComponent::StaticClass(), TEXT("LowPassFilterFrequency"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_LowPassFilterFrequency(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AudioComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AudioComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAudioComponent::StaticClass(), TEXT("LowPassFilterFrequency"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_AttenuationSettings(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AudioComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AudioComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAudioComponent::StaticClass(), TEXT("AttenuationSettings"));
	if(!Property) { check(false); return 0;}
	USoundAttenuation* PropertyValue;
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaUtils::ReturnUObject(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_AttenuationSettings(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AudioComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AudioComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAudioComponent::StaticClass(), TEXT("AttenuationSettings"));
	if(!Property) { check(false); return 0;}
	USoundAttenuation* PropertyValue = (USoundAttenuation*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"SoundAttenuation");;
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_ConcurrencySettings(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AudioComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AudioComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAudioComponent::StaticClass(), TEXT("ConcurrencySettings"));
	if(!Property) { check(false); return 0;}
	USoundConcurrency* PropertyValue;
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaUtils::ReturnUObject(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_ConcurrencySettings(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AudioComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AudioComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAudioComponent::StaticClass(), TEXT("ConcurrencySettings"));
	if(!Property) { check(false); return 0;}
	USoundConcurrency* PropertyValue = (USoundConcurrency*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"SoundConcurrency");;
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_AutoAttachLocationRule(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AudioComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AudioComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAudioComponent::StaticClass(), TEXT("AutoAttachLocationRule"));
	if(!Property) { check(false); return 0;}
	EAttachmentRule PropertyValue = EAttachmentRule();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushinteger(InScriptContext, (int)PropertyValue);
	return 1;
}

int32 Set_AutoAttachLocationRule(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AudioComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AudioComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAudioComponent::StaticClass(), TEXT("AutoAttachLocationRule"));
	if(!Property) { check(false); return 0;}
	EAttachmentRule PropertyValue = (EAttachmentRule)(luaL_checkint(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_AutoAttachRotationRule(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AudioComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AudioComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAudioComponent::StaticClass(), TEXT("AutoAttachRotationRule"));
	if(!Property) { check(false); return 0;}
	EAttachmentRule PropertyValue = EAttachmentRule();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushinteger(InScriptContext, (int)PropertyValue);
	return 1;
}

int32 Set_AutoAttachRotationRule(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AudioComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AudioComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAudioComponent::StaticClass(), TEXT("AutoAttachRotationRule"));
	if(!Property) { check(false); return 0;}
	EAttachmentRule PropertyValue = (EAttachmentRule)(luaL_checkint(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_AutoAttachScaleRule(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AudioComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AudioComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAudioComponent::StaticClass(), TEXT("AutoAttachScaleRule"));
	if(!Property) { check(false); return 0;}
	EAttachmentRule PropertyValue = EAttachmentRule();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushinteger(InScriptContext, (int)PropertyValue);
	return 1;
}

int32 Set_AutoAttachScaleRule(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AudioComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AudioComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAudioComponent::StaticClass(), TEXT("AutoAttachScaleRule"));
	if(!Property) { check(false); return 0;}
	EAttachmentRule PropertyValue = (EAttachmentRule)(luaL_checkint(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Call_OnAudioFinished(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AudioComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AudioComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	UAudioComponent * This = (UAudioComponent *)Obj;
	This->OnAudioFinished.Broadcast();
	return 0;
}

int32 Call_OnAudioPlaybackPercent(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AudioComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AudioComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		USoundWave* PlayingSoundWave = nullptr;
		float PlaybackPercent;
	} Params;
	Params.PlayingSoundWave = (USoundWave*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"SoundWave");;
	Params.PlaybackPercent = (float)(luaL_checknumber(InScriptContext, 3));
	UAudioComponent * This = (UAudioComponent *)Obj;
	This->OnAudioPlaybackPercent.Broadcast(Params.PlayingSoundWave,Params.PlaybackPercent);
	return 0;
}

int32 Call_OnAudioSingleEnvelopeValue(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AudioComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AudioComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		USoundWave* PlayingSoundWave = nullptr;
		float EnvelopeValue;
	} Params;
	Params.PlayingSoundWave = (USoundWave*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"SoundWave");;
	Params.EnvelopeValue = (float)(luaL_checknumber(InScriptContext, 3));
	UAudioComponent * This = (UAudioComponent *)Obj;
	This->OnAudioSingleEnvelopeValue.Broadcast(Params.PlayingSoundWave,Params.EnvelopeValue);
	return 0;
}

int32 Call_OnAudioMultiEnvelopeValue(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AudioComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AudioComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float AverageEnvelopeValue;
		float MaxEnvelope;
		int32 NumWaveInstances;
	} Params;
	Params.AverageEnvelopeValue = (float)(luaL_checknumber(InScriptContext, 2));
	Params.MaxEnvelope = (float)(luaL_checknumber(InScriptContext, 3));
	Params.NumWaveInstances = (luaL_checkint(InScriptContext, 4));
	UAudioComponent * This = (UAudioComponent *)Obj;
	This->OnAudioMultiEnvelopeValue.Broadcast(Params.AverageEnvelopeValue,Params.MaxEnvelope,Params.NumWaveInstances);
	return 0;
}

int32 Get_AutoAttachSocketName(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AudioComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AudioComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAudioComponent::StaticClass(), TEXT("AutoAttachSocketName"));
	if(!Property) { check(false); return 0;}
	FName PropertyValue = FName();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushstring(InScriptContext, TCHAR_TO_UTF8(*PropertyValue.ToString()));
	return 1;
}

int32 Set_AutoAttachSocketName(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AudioComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AudioComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAudioComponent::StaticClass(), TEXT("AutoAttachSocketName"));
	if(!Property) { check(false); return 0;}
	FName PropertyValue = FName(UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 2)));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 New(lua_State* InScriptContext)
{
	UObject* Outer = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Object");
	FName Name = FName(luaL_checkstring(InScriptContext, 2));
	UObject* Obj = NewObject<UAudioComponent>(Outer, Name);
	wLua::FLuaUtils::ReturnUObject(InScriptContext,Obj);
	return 1;
}

int32 Destroy(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AudioComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AudioComponent must be non-null"); lua_error(InScriptContext);  return 0;}
		UActorComponent * com = Cast<UActorComponent>(Obj);
		if(lua_isnoneornil(InScriptContext,2))
			com->DestroyComponent();
		else
			com->DestroyComponent(!!lua_toboolean(InScriptContext,2));
		userdata->flag |= wLua::LuaObjectFlag::DESTROYED;
		wLua::FLuaUtils::RemoveObjectReference(Obj, userdata->stamp, InScriptContext);
#ifdef AZURE_BUILD_WLUACHECK
		UE_LOG(LogAzure, Warning, TEXT("Destroy AudioComponent: %x userdata:%x   stamp:%x"),Obj,userdata,userdata->stamp);
#endif
	return 0;
}

int32 Class(lua_State* InScriptContext)
{
	UClass* Class = UAudioComponent::StaticClass();
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Class);
	return 1;
}

const luaL_Reg Lib_Funcs[] =
{
	{ "New", New },
	{ "Destroy", Destroy },
	{ "Class", Class },
	{ "Stop", Stop },
	{ "SetWaveParameter", SetWaveParameter },
	{ "SetVolumeMultiplier", SetVolumeMultiplier },
	{ "SetUISound", SetUISound },
	{ "SetSubmixSend", SetSubmixSend },
	{ "SetSound", SetSound },
	{ "SetPitchMultiplier", SetPitchMultiplier },
	{ "SetPaused", SetPaused },
	{ "SetLowPassFilterFrequency", SetLowPassFilterFrequency },
	{ "SetLowPassFilterEnabled", SetLowPassFilterEnabled },
	{ "SetIntParameter", SetIntParameter },
	{ "SetFloatParameter", SetFloatParameter },
	{ "SetBoolParameter", SetBoolParameter },
	{ "Play", Play },
	{ "IsPlaying", IsPlaying },
	{ "FadeOut", FadeOut },
	{ "FadeIn", FadeIn },
	{ "AdjustVolume", AdjustVolume },
	{ "Get_Sound", Get_Sound },
	{ "Set_Sound", Set_Sound },
	{ "Get_SoundClassOverride", Get_SoundClassOverride },
	{ "Set_SoundClassOverride", Set_SoundClassOverride },
	{ "Get_bAllowSpatialization", Get_bAllowSpatialization },
	{ "Set_bAllowSpatialization", Set_bAllowSpatialization },
	{ "Get_bOverrideAttenuation", Get_bOverrideAttenuation },
	{ "Set_bOverrideAttenuation", Set_bOverrideAttenuation },
	{ "Get_bOverrideSubtitlePriority", Get_bOverrideSubtitlePriority },
	{ "Set_bOverrideSubtitlePriority", Set_bOverrideSubtitlePriority },
	{ "Get_bIsUISound", Get_bIsUISound },
	{ "Set_bIsUISound", Set_bIsUISound },
	{ "Get_bEnableLowPassFilter", Get_bEnableLowPassFilter },
	{ "Set_bEnableLowPassFilter", Set_bEnableLowPassFilter },
	{ "Get_bOverridePriority", Get_bOverridePriority },
	{ "Set_bOverridePriority", Set_bOverridePriority },
	{ "Get_bSuppressSubtitles", Get_bSuppressSubtitles },
	{ "Set_bSuppressSubtitles", Set_bSuppressSubtitles },
	{ "Get_bAutoManageAttachment", Get_bAutoManageAttachment },
	{ "Get_PitchModulationMin", Get_PitchModulationMin },
	{ "Set_PitchModulationMin", Set_PitchModulationMin },
	{ "Get_PitchModulationMax", Get_PitchModulationMax },
	{ "Set_PitchModulationMax", Set_PitchModulationMax },
	{ "Get_VolumeModulationMin", Get_VolumeModulationMin },
	{ "Set_VolumeModulationMin", Set_VolumeModulationMin },
	{ "Get_VolumeModulationMax", Get_VolumeModulationMax },
	{ "Set_VolumeModulationMax", Set_VolumeModulationMax },
	{ "Get_VolumeMultiplier", Get_VolumeMultiplier },
	{ "Set_VolumeMultiplier", Set_VolumeMultiplier },
	{ "Get_EnvelopeFollowerAttackTime", Get_EnvelopeFollowerAttackTime },
	{ "Set_EnvelopeFollowerAttackTime", Set_EnvelopeFollowerAttackTime },
	{ "Get_EnvelopeFollowerReleaseTime", Get_EnvelopeFollowerReleaseTime },
	{ "Set_EnvelopeFollowerReleaseTime", Set_EnvelopeFollowerReleaseTime },
	{ "Get_Priority", Get_Priority },
	{ "Set_Priority", Set_Priority },
	{ "Get_SubtitlePriority", Get_SubtitlePriority },
	{ "Set_SubtitlePriority", Set_SubtitlePriority },
	{ "Get_PitchMultiplier", Get_PitchMultiplier },
	{ "Set_PitchMultiplier", Set_PitchMultiplier },
	{ "Get_LowPassFilterFrequency", Get_LowPassFilterFrequency },
	{ "Set_LowPassFilterFrequency", Set_LowPassFilterFrequency },
	{ "Get_AttenuationSettings", Get_AttenuationSettings },
	{ "Set_AttenuationSettings", Set_AttenuationSettings },
	{ "Get_ConcurrencySettings", Get_ConcurrencySettings },
	{ "Set_ConcurrencySettings", Set_ConcurrencySettings },
	{ "Get_AutoAttachLocationRule", Get_AutoAttachLocationRule },
	{ "Set_AutoAttachLocationRule", Set_AutoAttachLocationRule },
	{ "Get_AutoAttachRotationRule", Get_AutoAttachRotationRule },
	{ "Set_AutoAttachRotationRule", Set_AutoAttachRotationRule },
	{ "Get_AutoAttachScaleRule", Get_AutoAttachScaleRule },
	{ "Set_AutoAttachScaleRule", Set_AutoAttachScaleRule },
	{ "Call_OnAudioFinished", Call_OnAudioFinished },
	{ "Call_OnAudioPlaybackPercent", Call_OnAudioPlaybackPercent },
	{ "Call_OnAudioSingleEnvelopeValue", Call_OnAudioSingleEnvelopeValue },
	{ "Call_OnAudioMultiEnvelopeValue", Call_OnAudioMultiEnvelopeValue },
	{ "Get_AutoAttachSocketName", Get_AutoAttachSocketName },
	{ "Set_AutoAttachSocketName", Set_AutoAttachSocketName },
	{ "is_nil", wLua::LuaStatic::isnil },
	{ "__gc", wLua::LuaStatic::removeUClassFrameCache },
	{ NULL, NULL }
};

void Register(lua_State *InScriptContext)
{
	lua_newtable(InScriptContext);
	luaL_register(InScriptContext, NULL, Lib_Funcs);
	AzureHelpFuncs::AuxRegister(InScriptContext, "AudioComponent");
}
void SetMtLink(lua_State *InScriptContext)
{
	AzureHelpFuncs::AuxSetMtLink(InScriptContext, "AudioComponent", "SceneComponent",USERDATATYPE_UOBJECT);
}

}