#include "Azure.h"
#include "Utility/help_funcs.h"
#include "wLua/UObjectHeaders.h"
#include "AzurePateComponent.h"
#include "AzureLuaIntegration.h"

namespace LuaAzurePateComponent
{
int32 AttachLuaObject(lua_State*);

int32 SetViewOffset(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzurePateComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzurePateComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FVector offset;
	} Params;
	Params.offset = (wLua::FLuaVector::Get(InScriptContext, 2));
#if UE_GAME
	UAzurePateComponent * This = (UAzurePateComponent *)Obj;
	This->SetViewOffset(Params.offset);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetViewOffset"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FVector*)(params.GetStructMemory() + 0) = Params.offset;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.offset = *(FVector*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetPateWidget(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzurePateComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzurePateComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		UUserWidget* NewUserWidget = nullptr;
	} Params;
	Params.NewUserWidget = (UUserWidget*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"UserWidget");;
#if UE_GAME
	UAzurePateComponent * This = (UAzurePateComponent *)Obj;
	This->SetPateWidget(Params.NewUserWidget);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetPateWidget"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(UUserWidget**)(params.GetStructMemory() + 0) = Params.NewUserWidget;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.NewUserWidget = *(UUserWidget**)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetHudTextString(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzurePateComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzurePateComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FString InText;
		UAzureBMFont* Font = nullptr;
		int32 fontSize;
		float lifeTime;
		FVector2D velocity;
		float moveTime;
		float scaleFrom;
		float scaleFromTime;
		float scaleTo;
		float scaleToTime;
		FVector Woffset;
		FVector2D offset;
	} Params;
	Params.Font = (UAzureBMFont*)wLua::FLuaUtils::GetUObject(InScriptContext,3,"AzureBMFont");;
	Params.fontSize = (luaL_checkint(InScriptContext, 4));
	Params.lifeTime = (float)(luaL_checknumber(InScriptContext, 5));
	Params.moveTime = (float)(luaL_checknumber(InScriptContext, 7));
	Params.scaleFrom = (float)(luaL_checknumber(InScriptContext, 8));
	Params.scaleFromTime = (float)(luaL_checknumber(InScriptContext, 9));
	Params.scaleTo = (float)(luaL_checknumber(InScriptContext, 10));
	Params.scaleToTime = (float)(luaL_checknumber(InScriptContext, 11));
#if UE_GAME
	UAzurePateComponent * This = (UAzurePateComponent *)Obj;
	This->SetHudTextString(Params.InText,Params.Font,Params.fontSize,Params.lifeTime,Params.velocity,Params.moveTime,Params.scaleFrom,Params.scaleFromTime,Params.scaleTo,Params.scaleToTime,Params.Woffset,Params.offset);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetHudTextString"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(UAzureBMFont**)(params.GetStructMemory() + 16) = Params.Font;
		*(int32*)(params.GetStructMemory() + 24) = Params.fontSize;
		*(float*)(params.GetStructMemory() + 28) = Params.lifeTime;
		*(float*)(params.GetStructMemory() + 40) = Params.moveTime;
		*(float*)(params.GetStructMemory() + 44) = Params.scaleFrom;
		*(float*)(params.GetStructMemory() + 48) = Params.scaleFromTime;
		*(float*)(params.GetStructMemory() + 52) = Params.scaleTo;
		*(float*)(params.GetStructMemory() + 56) = Params.scaleToTime;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.InText = *(FString*)(params.GetStructMemory() + 0);
		Params.Font = *(UAzureBMFont**)(params.GetStructMemory() + 16);
		Params.fontSize = *(int32*)(params.GetStructMemory() + 24);
		Params.lifeTime = *(float*)(params.GetStructMemory() + 28);
		Params.velocity = *(FVector2D*)(params.GetStructMemory() + 32);
		Params.moveTime = *(float*)(params.GetStructMemory() + 40);
		Params.scaleFrom = *(float*)(params.GetStructMemory() + 44);
		Params.scaleFromTime = *(float*)(params.GetStructMemory() + 48);
		Params.scaleTo = *(float*)(params.GetStructMemory() + 52);
		Params.scaleToTime = *(float*)(params.GetStructMemory() + 56);
		Params.Woffset = *(FVector*)(params.GetStructMemory() + 60);
		Params.offset = *(FVector2D*)(params.GetStructMemory() + 72);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushstring(InScriptContext, TCHAR_TO_UTF8(*Params.InText));
	wLua::FLuaVector2D::Return(InScriptContext, Params.velocity);
	wLua::FLuaVector::Return(InScriptContext, Params.Woffset);
	wLua::FLuaVector2D::Return(InScriptContext, Params.offset);
	return 4;
}

int32 SetFixedZ(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzurePateComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzurePateComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool useFixedz;
		float fixedZ;
	} Params;
	Params.useFixedz = !!(lua_toboolean(InScriptContext, 2));
	Params.fixedZ = (float)(luaL_checknumber(InScriptContext, 3));
#if UE_GAME
	UAzurePateComponent * This = (UAzurePateComponent *)Obj;
	This->SetFixedZ(Params.useFixedz,Params.fixedZ);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetFixedZ"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(bool*)(params.GetStructMemory() + 0) = Params.useFixedz;
		*(float*)(params.GetStructMemory() + 4) = Params.fixedZ;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.useFixedz = *(bool*)(params.GetStructMemory() + 0);
		Params.fixedZ = *(float*)(params.GetStructMemory() + 4);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetExtraPateWidget(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzurePateComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzurePateComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		UUserWidget* NewUserWidget = nullptr;
	} Params;
	Params.NewUserWidget = (UUserWidget*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"UserWidget");;
#if UE_GAME
	UAzurePateComponent * This = (UAzurePateComponent *)Obj;
	This->SetExtraPateWidget(Params.NewUserWidget);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetExtraPateWidget"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(UUserWidget**)(params.GetStructMemory() + 0) = Params.NewUserWidget;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.NewUserWidget = *(UUserWidget**)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetAttachComponent(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzurePateComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzurePateComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		USceneComponent* component = nullptr;
		FString socket;
		FString socket2;
	} Params;
	Params.component = (USceneComponent*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"SceneComponent");;
	Params.socket = UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 3));
	Params.socket2 = UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 4));
#if UE_GAME
	UAzurePateComponent * This = (UAzurePateComponent *)Obj;
	This->SetAttachComponent(Params.component,Params.socket,Params.socket2);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetAttachComponent"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(USceneComponent**)(params.GetStructMemory() + 0) = Params.component;
		*(FString*)(params.GetStructMemory() + 8) = Params.socket;
		*(FString*)(params.GetStructMemory() + 24) = Params.socket2;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.component = *(USceneComponent**)(params.GetStructMemory() + 0);
		Params.socket = *(FString*)(params.GetStructMemory() + 8);
		Params.socket2 = *(FString*)(params.GetStructMemory() + 24);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 GetUserWidget(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzurePateComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzurePateComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		UUserWidget* ReturnValue = nullptr;
	} Params;
#if UE_GAME
	UAzurePateComponent * This = (UAzurePateComponent *)Obj;
	Params.ReturnValue = This->GetUserWidget();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetUserWidget"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(UUserWidget**)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetPaintingWidget(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzurePateComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzurePateComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		UUserWidget* pWidget = nullptr;
		UWidget* ReturnValue = nullptr;
	} Params;
	Params.pWidget = (UUserWidget*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"UserWidget");;
#if UE_GAME
	UAzurePateComponent * This = (UAzurePateComponent *)Obj;
	Params.ReturnValue = This->GetPaintingWidget(Params.pWidget);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetPaintingWidget"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(UUserWidget**)(params.GetStructMemory() + 0) = Params.pWidget;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.pWidget = *(UUserWidget**)(params.GetStructMemory() + 0);
		Params.ReturnValue = *(UWidget**)(params.GetStructMemory() + 8);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetExtraUserWidget(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzurePateComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzurePateComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		UUserWidget* ReturnValue = nullptr;
	} Params;
#if UE_GAME
	UAzurePateComponent * This = (UAzurePateComponent *)Obj;
	Params.ReturnValue = This->GetExtraUserWidget();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetExtraUserWidget"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(UUserWidget**)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 Get_UserWidgetClass(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzurePateComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzurePateComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzurePateComponent::StaticClass(), TEXT("UserWidgetClass"));
	if(!Property) { check(false); return 0;}
	TSubclassOf<UUserWidget>  PropertyValue = TSubclassOf<UUserWidget> ();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaUtils::ReturnUObject(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_UserWidgetClass(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzurePateComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzurePateComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzurePateComponent::StaticClass(), TEXT("UserWidgetClass"));
	if(!Property) { check(false); return 0;}
	TSubclassOf<UUserWidget>  PropertyValue = (UClass*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"Class");;
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_WorldOffset(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzurePateComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzurePateComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzurePateComponent::StaticClass(), TEXT("WorldOffset"));
	if(!Property) { check(false); return 0;}
	FVector PropertyValue = FVector();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaVector::Return(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_WorldOffset(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzurePateComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzurePateComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzurePateComponent::StaticClass(), TEXT("WorldOffset"));
	if(!Property) { check(false); return 0;}
	FVector PropertyValue = (wLua::FLuaVector::Get(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_ScreenOffset(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzurePateComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzurePateComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzurePateComponent::StaticClass(), TEXT("ScreenOffset"));
	if(!Property) { check(false); return 0;}
	FVector2D PropertyValue = FVector2D();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaVector2D::Return(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_ScreenOffset(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzurePateComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzurePateComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzurePateComponent::StaticClass(), TEXT("ScreenOffset"));
	if(!Property) { check(false); return 0;}
	FVector2D PropertyValue = (wLua::FLuaVector2D::Get(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_ExtraWorldOffset(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzurePateComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzurePateComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzurePateComponent::StaticClass(), TEXT("ExtraWorldOffset"));
	if(!Property) { check(false); return 0;}
	FVector PropertyValue = FVector();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaVector::Return(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_ExtraWorldOffset(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzurePateComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzurePateComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzurePateComponent::StaticClass(), TEXT("ExtraWorldOffset"));
	if(!Property) { check(false); return 0;}
	FVector PropertyValue = (wLua::FLuaVector::Get(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_ExtraScreenOffset(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzurePateComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzurePateComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzurePateComponent::StaticClass(), TEXT("ExtraScreenOffset"));
	if(!Property) { check(false); return 0;}
	FVector2D PropertyValue = FVector2D();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaVector2D::Return(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_ExtraScreenOffset(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzurePateComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzurePateComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzurePateComponent::StaticClass(), TEXT("ExtraScreenOffset"));
	if(!Property) { check(false); return 0;}
	FVector2D PropertyValue = (wLua::FLuaVector2D::Get(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_targetSocket(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzurePateComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzurePateComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzurePateComponent::StaticClass(), TEXT("targetSocket"));
	if(!Property) { check(false); return 0;}
	FName PropertyValue = FName();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushstring(InScriptContext, TCHAR_TO_UTF8(*PropertyValue.ToString()));
	return 1;
}

int32 Set_targetSocket(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzurePateComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzurePateComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzurePateComponent::StaticClass(), TEXT("targetSocket"));
	if(!Property) { check(false); return 0;}
	FName PropertyValue = FName(UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 2)));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_baseSocket(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzurePateComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzurePateComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzurePateComponent::StaticClass(), TEXT("baseSocket"));
	if(!Property) { check(false); return 0;}
	FName PropertyValue = FName();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushstring(InScriptContext, TCHAR_TO_UTF8(*PropertyValue.ToString()));
	return 1;
}

int32 Set_baseSocket(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzurePateComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzurePateComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzurePateComponent::StaticClass(), TEXT("baseSocket"));
	if(!Property) { check(false); return 0;}
	FName PropertyValue = FName(UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 2)));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_IsLimitScreenPosition(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzurePateComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzurePateComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzurePateComponent::StaticClass(), TEXT("IsLimitScreenPosition"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = bool();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_IsLimitScreenPosition(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzurePateComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzurePateComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzurePateComponent::StaticClass(), TEXT("IsLimitScreenPosition"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_LimitDistToTopScreen(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzurePateComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzurePateComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzurePateComponent::StaticClass(), TEXT("LimitDistToTopScreen"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_LimitDistToTopScreen(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzurePateComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzurePateComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzurePateComponent::StaticClass(), TEXT("LimitDistToTopScreen"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_keepZSquaredDisThreshold(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzurePateComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzurePateComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzurePateComponent::StaticClass(), TEXT("keepZSquaredDisThreshold"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_keepZSquaredDisThreshold(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzurePateComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzurePateComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzurePateComponent::StaticClass(), TEXT("keepZSquaredDisThreshold"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 New(lua_State* InScriptContext)
{
	UObject* Outer = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Object");
	FName Name = FName(luaL_checkstring(InScriptContext, 2));
	UObject* Obj = NewObject<UAzurePateComponent>(Outer, Name);
	wLua::FLuaUtils::ReturnUObject(InScriptContext,Obj);
	return 1;
}

int32 Destroy(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzurePateComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzurePateComponent must be non-null"); lua_error(InScriptContext);  return 0;}
		UActorComponent * com = Cast<UActorComponent>(Obj);
		if(lua_isnoneornil(InScriptContext,2))
			com->DestroyComponent();
		else
			com->DestroyComponent(!!lua_toboolean(InScriptContext,2));
		userdata->flag |= wLua::LuaObjectFlag::DESTROYED;
		wLua::FLuaUtils::RemoveObjectReference(Obj, userdata->stamp, InScriptContext);
#ifdef AZURE_BUILD_WLUACHECK
		UE_LOG(LogAzure, Warning, TEXT("Destroy AzurePateComponent: %x userdata:%x   stamp:%x"),Obj,userdata,userdata->stamp);
#endif
	return 0;
}

int32 Class(lua_State* InScriptContext)
{
	UClass* Class = UAzurePateComponent::StaticClass();
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Class);
	return 1;
}

const luaL_Reg Lib_Funcs[] =
{
	{ "New", New },
	{ "Destroy", Destroy },
	{ "Class", Class },
	{ "SetViewOffset", SetViewOffset },
	{ "SetPateWidget", SetPateWidget },
	{ "SetHudTextString", SetHudTextString },
	{ "SetFixedZ", SetFixedZ },
	{ "SetExtraPateWidget", SetExtraPateWidget },
	{ "SetAttachComponent", SetAttachComponent },
	{ "GetUserWidget", GetUserWidget },
	{ "GetPaintingWidget", GetPaintingWidget },
	{ "GetExtraUserWidget", GetExtraUserWidget },
	{ "Get_UserWidgetClass", Get_UserWidgetClass },
	{ "Set_UserWidgetClass", Set_UserWidgetClass },
	{ "Get_WorldOffset", Get_WorldOffset },
	{ "Set_WorldOffset", Set_WorldOffset },
	{ "Get_ScreenOffset", Get_ScreenOffset },
	{ "Set_ScreenOffset", Set_ScreenOffset },
	{ "Get_ExtraWorldOffset", Get_ExtraWorldOffset },
	{ "Set_ExtraWorldOffset", Set_ExtraWorldOffset },
	{ "Get_ExtraScreenOffset", Get_ExtraScreenOffset },
	{ "Set_ExtraScreenOffset", Set_ExtraScreenOffset },
	{ "Get_targetSocket", Get_targetSocket },
	{ "Set_targetSocket", Set_targetSocket },
	{ "Get_baseSocket", Get_baseSocket },
	{ "Set_baseSocket", Set_baseSocket },
	{ "Get_IsLimitScreenPosition", Get_IsLimitScreenPosition },
	{ "Set_IsLimitScreenPosition", Set_IsLimitScreenPosition },
	{ "Get_LimitDistToTopScreen", Get_LimitDistToTopScreen },
	{ "Set_LimitDistToTopScreen", Set_LimitDistToTopScreen },
	{ "Get_keepZSquaredDisThreshold", Get_keepZSquaredDisThreshold },
	{ "Set_keepZSquaredDisThreshold", Set_keepZSquaredDisThreshold },
	{ "AttachLuaObject", AttachLuaObject },
	{ "is_nil", wLua::LuaStatic::isnil },
	{ "__gc", wLua::LuaStatic::removeUClassFrameCache },
	{ NULL, NULL }
};

void Register(lua_State *InScriptContext)
{
	lua_newtable(InScriptContext);
	luaL_register(InScriptContext, NULL, Lib_Funcs);
	AzureHelpFuncs::AuxRegister(InScriptContext, "AzurePateComponent");
}
void SetMtLink(lua_State *InScriptContext)
{
	AzureHelpFuncs::AuxSetMtLink(InScriptContext, "AzurePateComponent", "ActorComponent",USERDATATYPE_UOBJECT);
}

}