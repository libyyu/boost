#include "Azure.h"
#include "Utility/help_funcs.h"
#include "wLua/UObjectHeaders.h"
#include "NavigationPath.h"
#include "AzureLuaIntegration.h"

namespace LuaNavigationPath
{
int32 IsValid(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"NavigationPath",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"NavigationPath must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool ReturnValue;
	} Params;
#if UE_GAME
	UNavigationPath * This = (UNavigationPath *)Obj;
	Params.ReturnValue = This->IsValid();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("IsValid"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushboolean(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 IsStringPulled(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"NavigationPath",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"NavigationPath must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool ReturnValue;
	} Params;
#if UE_GAME
	UNavigationPath * This = (UNavigationPath *)Obj;
	Params.ReturnValue = This->IsStringPulled();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("IsStringPulled"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushboolean(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 IsPartial(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"NavigationPath",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"NavigationPath must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool ReturnValue;
	} Params;
#if UE_GAME
	UNavigationPath * This = (UNavigationPath *)Obj;
	Params.ReturnValue = This->IsPartial();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("IsPartial"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushboolean(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetPathLength(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"NavigationPath",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"NavigationPath must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float ReturnValue;
	} Params;
#if UE_GAME
	UNavigationPath * This = (UNavigationPath *)Obj;
	Params.ReturnValue = This->GetPathLength();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetPathLength"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(float*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushnumber(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetPathCost(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"NavigationPath",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"NavigationPath must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float ReturnValue;
	} Params;
#if UE_GAME
	UNavigationPath * This = (UNavigationPath *)Obj;
	Params.ReturnValue = This->GetPathCost();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetPathCost"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(float*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushnumber(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetDebugString(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"NavigationPath",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"NavigationPath must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FString ReturnValue;
	} Params;
#if UE_GAME
	UNavigationPath * This = (UNavigationPath *)Obj;
	Params.ReturnValue = This->GetDebugString();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetDebugString"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(FString*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushstring(InScriptContext, TCHAR_TO_UTF8(*Params.ReturnValue));
	return 1;
}

int32 EnableRecalculationOnInvalidation(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"NavigationPath",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"NavigationPath must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		TEnumAsByte<ENavigationOptionFlag::Type> DoRecalculation;
	} Params;
	Params.DoRecalculation = (TEnumAsByte<ENavigationOptionFlag::Type>)(luaL_checkint(InScriptContext, 2));
#if UE_GAME
	UNavigationPath * This = (UNavigationPath *)Obj;
	This->EnableRecalculationOnInvalidation(Params.DoRecalculation);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("EnableRecalculationOnInvalidation"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(TEnumAsByte<ENavigationOptionFlag::Type>*)(params.GetStructMemory() + 0) = Params.DoRecalculation;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.DoRecalculation = *(TEnumAsByte<ENavigationOptionFlag::Type>*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 EnableDebugDrawing(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"NavigationPath",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"NavigationPath must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool bShouldDrawDebugData;
		FLinearColor PathColor;
	} Params;
	Params.bShouldDrawDebugData = !!(lua_toboolean(InScriptContext, 2));
	if(lua_isnoneornil(InScriptContext,3))
	{
		Params.PathColor.R=1.000000;
		Params.PathColor.G=1.000000;
		Params.PathColor.B=1.000000;
		Params.PathColor.A=1.000000;
	}
	else
		Params.PathColor = (wLua::FLuaLinearColor::Get(InScriptContext, 3));
#if UE_GAME
	UNavigationPath * This = (UNavigationPath *)Obj;
	This->EnableDebugDrawing(Params.bShouldDrawDebugData,Params.PathColor);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("EnableDebugDrawing"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(bool*)(params.GetStructMemory() + 0) = Params.bShouldDrawDebugData;
		*(FLinearColor*)(params.GetStructMemory() + 4) = Params.PathColor;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.bShouldDrawDebugData = *(bool*)(params.GetStructMemory() + 0);
		Params.PathColor = *(FLinearColor*)(params.GetStructMemory() + 4);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 Call_PathUpdatedNotifier(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"NavigationPath",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"NavigationPath must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		UNavigationPath* AffectedPath = nullptr;
		TEnumAsByte<ENavPathEvent::Type> PathEvent;
	} Params;
	Params.AffectedPath = (UNavigationPath*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"NavigationPath");;
	Params.PathEvent = (TEnumAsByte<ENavPathEvent::Type>)(luaL_checkint(InScriptContext, 3));
	UNavigationPath * This = (UNavigationPath *)Obj;
	This->PathUpdatedNotifier.Broadcast(Params.AffectedPath,Params.PathEvent);
	return 0;
}

int32 Get_PathPoints(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"NavigationPath",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"NavigationPath must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UNavigationPath::StaticClass(), TEXT("PathPoints"));
	if(!Property) { check(false); return 0;}
	TArray<FVector> PropertyValue;
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	{lua_newtable(InScriptContext); int i = 1; for(auto It = PropertyValue.CreateConstIterator(); It; ++It,++i) {  wLua::FLuaVector::Return(InScriptContext, (*It)); lua_rawseti(InScriptContext,-2,i);     }  }
	return 1;
}

int32 Get_RecalculateOnInvalidation(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"NavigationPath",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"NavigationPath must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UNavigationPath::StaticClass(), TEXT("RecalculateOnInvalidation"));
	if(!Property) { check(false); return 0;}
	TEnumAsByte<ENavigationOptionFlag::Type> PropertyValue = TEnumAsByte<ENavigationOptionFlag::Type>();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushinteger(InScriptContext, (int)PropertyValue);
	return 1;
}

int32 New(lua_State* InScriptContext)
{
	UObject* Outer = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Object");
	FName Name = FName(luaL_checkstring(InScriptContext, 2));
	UObject* Obj = NewObject<UNavigationPath>(Outer, Name);
	wLua::FLuaUtils::ReturnUObject(InScriptContext,Obj);
	return 1;
}

int32 Destroy(lua_State* InScriptContext)
{
	return 0;
}

int32 Class(lua_State* InScriptContext)
{
	UClass* Class = UNavigationPath::StaticClass();
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Class);
	return 1;
}

const luaL_Reg Lib_Funcs[] =
{
	{ "New", New },
	{ "Destroy", Destroy },
	{ "Class", Class },
	{ "IsValid", IsValid },
	{ "IsStringPulled", IsStringPulled },
	{ "IsPartial", IsPartial },
	{ "GetPathLength", GetPathLength },
	{ "GetPathCost", GetPathCost },
	{ "GetDebugString", GetDebugString },
	{ "EnableRecalculationOnInvalidation", EnableRecalculationOnInvalidation },
	{ "EnableDebugDrawing", EnableDebugDrawing },
	{ "Call_PathUpdatedNotifier", Call_PathUpdatedNotifier },
	{ "Get_PathPoints", Get_PathPoints },
	{ "Get_RecalculateOnInvalidation", Get_RecalculateOnInvalidation },
	{ "is_nil", wLua::LuaStatic::isnil },
	{ "__gc", wLua::LuaStatic::removeUClassFrameCache },
	{ NULL, NULL }
};

void Register(lua_State *InScriptContext)
{
	lua_newtable(InScriptContext);
	luaL_register(InScriptContext, NULL, Lib_Funcs);
	AzureHelpFuncs::AuxRegister(InScriptContext, "NavigationPath");
}
void SetMtLink(lua_State *InScriptContext)
{
	AzureHelpFuncs::AuxSetMtLink(InScriptContext, "NavigationPath", "Object",USERDATATYPE_UOBJECT);
}

}