#include "Azure.h"
#include "Utility/help_funcs.h"
#include "wLua/UObjectHeaders.h"
#include "GameLogic/Player/VehicleCharacter.h"
#include "../UClassHeaders.h"
#include "AzureLuaIntegration.h"

namespace LuaVehicleCharacter
{
int32 SetNeedKeepCloseToGround(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"VehicleCharacter",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"VehicleCharacter must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool need;
	} Params;
	Params.need = !!(lua_toboolean(InScriptContext, 2));
#if UE_GAME
	AVehicleCharacter * This = (AVehicleCharacter *)Obj;
	This->SetNeedKeepCloseToGround(Params.need);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetNeedKeepCloseToGround"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(bool*)(params.GetStructMemory() + 0) = Params.need;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.need = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetFixedMovePhase(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"VehicleCharacter",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"VehicleCharacter must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		VehicleMovePhase phase;
	} Params;
	Params.phase = (VehicleMovePhase)(luaL_checkint(InScriptContext, 2));
#if UE_GAME
	AVehicleCharacter * This = (AVehicleCharacter *)Obj;
	This->SetFixedMovePhase(Params.phase);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetFixedMovePhase"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(VehicleMovePhase*)(params.GetStructMemory() + 0) = Params.phase;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.phase = *(VehicleMovePhase*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 PrepareJump(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"VehicleCharacter",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"VehicleCharacter must be non-null"); lua_error(InScriptContext);  return 0;}
#if UE_GAME
	AVehicleCharacter * This = (AVehicleCharacter *)Obj;
	This->PrepareJump();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("PrepareJump"));
	if(!Function) { check(false); return 0;}
	Obj->ProcessEvent(Function, NULL);
#endif
	return 0;
}

int32 GetNormalizationSpeed(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"VehicleCharacter",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"VehicleCharacter must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float ReturnValue;
	} Params;
#if UE_GAME
	AVehicleCharacter * This = (AVehicleCharacter *)Obj;
	Params.ReturnValue = This->GetNormalizationSpeed();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetNormalizationSpeed"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(float*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushnumber(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetNeedKeepCloseToGround(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"VehicleCharacter",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"VehicleCharacter must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool ReturnValue;
	} Params;
#if UE_GAME
	AVehicleCharacter * This = (AVehicleCharacter *)Obj;
	Params.ReturnValue = This->GetNeedKeepCloseToGround();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetNeedKeepCloseToGround"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushboolean(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetLastMovePhase(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"VehicleCharacter",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"VehicleCharacter must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		VehicleMovePhase ReturnValue;
	} Params;
#if UE_GAME
	AVehicleCharacter * This = (AVehicleCharacter *)Obj;
	Params.ReturnValue = This->GetLastMovePhase();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetLastMovePhase"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(VehicleMovePhase*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushinteger(InScriptContext, (int)Params.ReturnValue);
	return 1;
}

int32 EnableDash(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"VehicleCharacter",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"VehicleCharacter must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool enable;
	} Params;
	Params.enable = !!(lua_toboolean(InScriptContext, 2));
#if UE_GAME
	AVehicleCharacter * This = (AVehicleCharacter *)Obj;
	This->EnableDash(Params.enable);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("EnableDash"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(bool*)(params.GetStructMemory() + 0) = Params.enable;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.enable = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 CalcKeepCloseToGroudAngle(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"VehicleCharacter",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"VehicleCharacter must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool force;
	} Params;
	Params.force = !!(lua_toboolean(InScriptContext, 2));
#if UE_GAME
	AVehicleCharacter * This = (AVehicleCharacter *)Obj;
	This->CalcKeepCloseToGroudAngle(Params.force);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("CalcKeepCloseToGroudAngle"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(bool*)(params.GetStructMemory() + 0) = Params.force;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.force = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 BrakeStop(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"VehicleCharacter",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"VehicleCharacter must be non-null"); lua_error(InScriptContext);  return 0;}
#if UE_GAME
	AVehicleCharacter * This = (AVehicleCharacter *)Obj;
	This->BrakeStop();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("BrakeStop"));
	if(!Function) { check(false); return 0;}
	Obj->ProcessEvent(Function, NULL);
#endif
	return 0;
}

int32 Get_brakeStopFiction(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"VehicleCharacter",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"VehicleCharacter must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AVehicleCharacter::StaticClass(), TEXT("brakeStopFiction"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_brakeStopFiction(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"VehicleCharacter",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"VehicleCharacter must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AVehicleCharacter::StaticClass(), TEXT("brakeStopFiction"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_normalStopFiction(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"VehicleCharacter",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"VehicleCharacter must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AVehicleCharacter::StaticClass(), TEXT("normalStopFiction"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_normalStopFiction(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"VehicleCharacter",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"VehicleCharacter must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AVehicleCharacter::StaticClass(), TEXT("normalStopFiction"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_calcGradientWidth(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"VehicleCharacter",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"VehicleCharacter must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AVehicleCharacter::StaticClass(), TEXT("calcGradientWidth"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_calcGradientWidth(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"VehicleCharacter",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"VehicleCharacter must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AVehicleCharacter::StaticClass(), TEXT("calcGradientWidth"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_calcGradientLength(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"VehicleCharacter",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"VehicleCharacter must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AVehicleCharacter::StaticClass(), TEXT("calcGradientLength"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_calcGradientLength(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"VehicleCharacter",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"VehicleCharacter must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AVehicleCharacter::StaticClass(), TEXT("calcGradientLength"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_keepCloseGroundMaxPitch(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"VehicleCharacter",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"VehicleCharacter must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AVehicleCharacter::StaticClass(), TEXT("keepCloseGroundMaxPitch"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_keepCloseGroundMaxPitch(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"VehicleCharacter",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"VehicleCharacter must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AVehicleCharacter::StaticClass(), TEXT("keepCloseGroundMaxPitch"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_keepCloseGroundMaxRoll(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"VehicleCharacter",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"VehicleCharacter must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AVehicleCharacter::StaticClass(), TEXT("keepCloseGroundMaxRoll"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_keepCloseGroundMaxRoll(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"VehicleCharacter",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"VehicleCharacter must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AVehicleCharacter::StaticClass(), TEXT("keepCloseGroundMaxRoll"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_needKeepCloseToGround(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"VehicleCharacter",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"VehicleCharacter must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AVehicleCharacter::StaticClass(), TEXT("needKeepCloseToGround"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = bool();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_needKeepCloseToGround(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"VehicleCharacter",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"VehicleCharacter must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AVehicleCharacter::StaticClass(), TEXT("needKeepCloseToGround"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_needKeepCloseGroundRoll(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"VehicleCharacter",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"VehicleCharacter must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AVehicleCharacter::StaticClass(), TEXT("needKeepCloseGroundRoll"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = bool();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_needKeepCloseGroundRoll(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"VehicleCharacter",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"VehicleCharacter must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AVehicleCharacter::StaticClass(), TEXT("needKeepCloseGroundRoll"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_frameCalcKeepCloseGroundOnce(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"VehicleCharacter",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"VehicleCharacter must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AVehicleCharacter::StaticClass(), TEXT("frameCalcKeepCloseGroundOnce"));
	if(!Property) { check(false); return 0;}
	int32 PropertyValue = int32();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushinteger(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_frameCalcKeepCloseGroundOnce(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"VehicleCharacter",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"VehicleCharacter must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AVehicleCharacter::StaticClass(), TEXT("frameCalcKeepCloseGroundOnce"));
	if(!Property) { check(false); return 0;}
	int32 PropertyValue = (luaL_checkint(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_keepCloseGroundInterpSpeed(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"VehicleCharacter",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"VehicleCharacter must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AVehicleCharacter::StaticClass(), TEXT("keepCloseGroundInterpSpeed"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_keepCloseGroundInterpSpeed(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"VehicleCharacter",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"VehicleCharacter must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AVehicleCharacter::StaticClass(), TEXT("keepCloseGroundInterpSpeed"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_normalizeGradient2MaxSpeedRateCurve(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"VehicleCharacter",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"VehicleCharacter must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AVehicleCharacter::StaticClass(), TEXT("normalizeGradient2MaxSpeedRateCurve"));
	if(!Property) { check(false); return 0;}
	UCurveFloat* PropertyValue;
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaUtils::ReturnUObject(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_normalizeGradient2MaxSpeedRateCurve(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"VehicleCharacter",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"VehicleCharacter must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AVehicleCharacter::StaticClass(), TEXT("normalizeGradient2MaxSpeedRateCurve"));
	if(!Property) { check(false); return 0;}
	UCurveFloat* PropertyValue = (UCurveFloat*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"CurveFloat");;
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_effectMaxSpeedMaxGradient(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"VehicleCharacter",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"VehicleCharacter must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AVehicleCharacter::StaticClass(), TEXT("effectMaxSpeedMaxGradient"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_effectMaxSpeedMaxGradient(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"VehicleCharacter",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"VehicleCharacter must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AVehicleCharacter::StaticClass(), TEXT("effectMaxSpeedMaxGradient"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_effectMaxSpeedMinGradient(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"VehicleCharacter",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"VehicleCharacter must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AVehicleCharacter::StaticClass(), TEXT("effectMaxSpeedMinGradient"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_effectMaxSpeedMinGradient(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"VehicleCharacter",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"VehicleCharacter must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AVehicleCharacter::StaticClass(), TEXT("effectMaxSpeedMinGradient"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_extMaxSpeedScale(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"VehicleCharacter",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"VehicleCharacter must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AVehicleCharacter::StaticClass(), TEXT("extMaxSpeedScale"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_extMaxSpeedScale(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"VehicleCharacter",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"VehicleCharacter must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AVehicleCharacter::StaticClass(), TEXT("extMaxSpeedScale"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 New(lua_State* InScriptContext)
{
	UObject* Outer = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Object");
	FName Name = FName(luaL_checkstring(InScriptContext, 2));
	UObject* Obj = NewObject<AVehicleCharacter>(Outer, Name);
	wLua::FLuaUtils::ReturnUObject(InScriptContext,Obj);
	return 1;
}

int32 Destroy(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"VehicleCharacter",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"VehicleCharacter must be non-null"); lua_error(InScriptContext);  return 0;}
		AActor * actor = Cast<AActor>(Obj);
		actor->Destroy();
		userdata->flag |= wLua::LuaObjectFlag::DESTROYED;
		wLua::FLuaUtils::RemoveObjectReference(Obj, userdata->stamp, InScriptContext);
#ifdef AZURE_BUILD_WLUACHECK
		UE_LOG(LogAzure, Warning, TEXT("Destroy VehicleCharacter: %x userdata:%x   stamp:%x"),Obj,userdata,userdata->stamp);
#endif
	return 0;
}

int32 Class(lua_State* InScriptContext)
{
	UClass* Class = AVehicleCharacter::StaticClass();
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Class);
	return 1;
}

const luaL_Reg Lib_Funcs[] =
{
	{ "New", New },
	{ "Destroy", Destroy },
	{ "Class", Class },
	{ "SetNeedKeepCloseToGround", SetNeedKeepCloseToGround },
	{ "SetFixedMovePhase", SetFixedMovePhase },
	{ "PrepareJump", PrepareJump },
	{ "GetNormalizationSpeed", GetNormalizationSpeed },
	{ "GetNeedKeepCloseToGround", GetNeedKeepCloseToGround },
	{ "GetLastMovePhase", GetLastMovePhase },
	{ "EnableDash", EnableDash },
	{ "CalcKeepCloseToGroudAngle", CalcKeepCloseToGroudAngle },
	{ "BrakeStop", BrakeStop },
	{ "Get_brakeStopFiction", Get_brakeStopFiction },
	{ "Set_brakeStopFiction", Set_brakeStopFiction },
	{ "Get_normalStopFiction", Get_normalStopFiction },
	{ "Set_normalStopFiction", Set_normalStopFiction },
	{ "Get_calcGradientWidth", Get_calcGradientWidth },
	{ "Set_calcGradientWidth", Set_calcGradientWidth },
	{ "Get_calcGradientLength", Get_calcGradientLength },
	{ "Set_calcGradientLength", Set_calcGradientLength },
	{ "Get_keepCloseGroundMaxPitch", Get_keepCloseGroundMaxPitch },
	{ "Set_keepCloseGroundMaxPitch", Set_keepCloseGroundMaxPitch },
	{ "Get_keepCloseGroundMaxRoll", Get_keepCloseGroundMaxRoll },
	{ "Set_keepCloseGroundMaxRoll", Set_keepCloseGroundMaxRoll },
	{ "Get_needKeepCloseToGround", Get_needKeepCloseToGround },
	{ "Set_needKeepCloseToGround", Set_needKeepCloseToGround },
	{ "Get_needKeepCloseGroundRoll", Get_needKeepCloseGroundRoll },
	{ "Set_needKeepCloseGroundRoll", Set_needKeepCloseGroundRoll },
	{ "Get_frameCalcKeepCloseGroundOnce", Get_frameCalcKeepCloseGroundOnce },
	{ "Set_frameCalcKeepCloseGroundOnce", Set_frameCalcKeepCloseGroundOnce },
	{ "Get_keepCloseGroundInterpSpeed", Get_keepCloseGroundInterpSpeed },
	{ "Set_keepCloseGroundInterpSpeed", Set_keepCloseGroundInterpSpeed },
	{ "Get_normalizeGradient2MaxSpeedRateCurve", Get_normalizeGradient2MaxSpeedRateCurve },
	{ "Set_normalizeGradient2MaxSpeedRateCurve", Set_normalizeGradient2MaxSpeedRateCurve },
	{ "Get_effectMaxSpeedMaxGradient", Get_effectMaxSpeedMaxGradient },
	{ "Set_effectMaxSpeedMaxGradient", Set_effectMaxSpeedMaxGradient },
	{ "Get_effectMaxSpeedMinGradient", Get_effectMaxSpeedMinGradient },
	{ "Set_effectMaxSpeedMinGradient", Set_effectMaxSpeedMinGradient },
	{ "Get_extMaxSpeedScale", Get_extMaxSpeedScale },
	{ "Set_extMaxSpeedScale", Set_extMaxSpeedScale },
	{ "is_nil", wLua::LuaStatic::isnil },
	{ "__gc", wLua::LuaStatic::removeUClassFrameCache },
	{ NULL, NULL }
};

void Register(lua_State *InScriptContext)
{
	lua_newtable(InScriptContext);
	luaL_register(InScriptContext, NULL, Lib_Funcs);
	AzureHelpFuncs::AuxRegister(InScriptContext, "VehicleCharacter");
}
void SetMtLink(lua_State *InScriptContext)
{
	AzureHelpFuncs::AuxSetMtLink(InScriptContext, "VehicleCharacter", "CarrierCharacterBase",USERDATATYPE_UOBJECT);
}

}