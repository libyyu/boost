#include "Azure.h"
#include "Utility/help_funcs.h"
#include "wLua/UObjectHeaders.h"
#include "AWaterWaveActor.h"
#include "AzureLuaIntegration.h"

namespace LuaWaterWaveActor
{
int32 UpdateCenter(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"WaterWaveActor",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"WaterWaveActor must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FVector Center;
	} Params;
	Params.Center = (wLua::FLuaVector::Get(InScriptContext, 2));
#if UE_GAME
	AWaterWaveActor * This = (AWaterWaveActor *)Obj;
	This->UpdateCenter(Params.Center);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("UpdateCenter"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FVector*)(params.GetStructMemory() + 0) = Params.Center;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.Center = *(FVector*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 HitPoint(lua_State* InScriptContext)
{
	UClass * Obj = AWaterWaveActor::StaticClass(); 
	struct FDispatchParams
	{
		FVector Pos;
	} Params;
	Params.Pos = (wLua::FLuaVector::Get(InScriptContext, 1));
#if UE_GAME
	AWaterWaveActor::HitPoint(Params.Pos);
#else
	UFunction* Function = Obj->FindFunctionByName(TEXT("HitPoint"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FVector*)(params.GetStructMemory() + 0) = Params.Pos;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.Pos = *(FVector*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 Get_OpenWaveWater(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"WaterWaveActor",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"WaterWaveActor must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AWaterWaveActor::StaticClass(), TEXT("OpenWaveWater"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = bool();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_OpenWaveWater(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"WaterWaveActor",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"WaterWaveActor must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AWaterWaveActor::StaticClass(), TEXT("OpenWaveWater"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_WaterMat(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"WaterWaveActor",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"WaterWaveActor must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AWaterWaveActor::StaticClass(), TEXT("WaterMat"));
	if(!Property) { check(false); return 0;}
	UMaterialInterface* PropertyValue;
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaUtils::ReturnUObject(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_WaterMat(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"WaterWaveActor",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"WaterWaveActor must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AWaterWaveActor::StaticClass(), TEXT("WaterMat"));
	if(!Property) { check(false); return 0;}
	UMaterialInterface* PropertyValue = (UMaterialInterface*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"MaterialInterface");;
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_MapSize(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"WaterWaveActor",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"WaterWaveActor must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AWaterWaveActor::StaticClass(), TEXT("MapSize"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_MapSize(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"WaterWaveActor",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"WaterWaveActor must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AWaterWaveActor::StaticClass(), TEXT("MapSize"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_HeightfieldNormal(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"WaterWaveActor",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"WaterWaveActor must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AWaterWaveActor::StaticClass(), TEXT("HeightfieldNormal"));
	if(!Property) { check(false); return 0;}
	UTextureRenderTarget2D* PropertyValue;
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaUtils::ReturnUObject(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_HeightfieldNormal(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"WaterWaveActor",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"WaterWaveActor must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AWaterWaveActor::StaticClass(), TEXT("HeightfieldNormal"));
	if(!Property) { check(false); return 0;}
	UTextureRenderTarget2D* PropertyValue = (UTextureRenderTarget2D*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"TextureRenderTarget2D");;
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_DefaultTex(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"WaterWaveActor",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"WaterWaveActor must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AWaterWaveActor::StaticClass(), TEXT("DefaultTex"));
	if(!Property) { check(false); return 0;}
	UTexture2D* PropertyValue;
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaUtils::ReturnUObject(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_DefaultTex(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"WaterWaveActor",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"WaterWaveActor must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AWaterWaveActor::StaticClass(), TEXT("DefaultTex"));
	if(!Property) { check(false); return 0;}
	UTexture2D* PropertyValue = (UTexture2D*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"Texture2D");;
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_TextureTile(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"WaterWaveActor",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"WaterWaveActor must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AWaterWaveActor::StaticClass(), TEXT("TextureTile"));
	if(!Property) { check(false); return 0;}
	int32 PropertyValue = int32();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushinteger(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_TextureTile(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"WaterWaveActor",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"WaterWaveActor must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AWaterWaveActor::StaticClass(), TEXT("TextureTile"));
	if(!Property) { check(false); return 0;}
	int32 PropertyValue = (luaL_checkint(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_TotalTime(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"WaterWaveActor",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"WaterWaveActor must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AWaterWaveActor::StaticClass(), TEXT("TotalTime"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_TotalTime(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"WaterWaveActor",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"WaterWaveActor must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AWaterWaveActor::StaticClass(), TEXT("TotalTime"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_CurveData(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"WaterWaveActor",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"WaterWaveActor must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AWaterWaveActor::StaticClass(), TEXT("CurveData"));
	if(!Property) { check(false); return 0;}
	UCurveVector* PropertyValue;
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaUtils::ReturnUObject(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_CurveData(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"WaterWaveActor",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"WaterWaveActor must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AWaterWaveActor::StaticClass(), TEXT("CurveData"));
	if(!Property) { check(false); return 0;}
	UCurveVector* PropertyValue = (UCurveVector*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"CurveVector");;
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_ComputeNormal(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"WaterWaveActor",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"WaterWaveActor must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AWaterWaveActor::StaticClass(), TEXT("ComputeNormal"));
	if(!Property) { check(false); return 0;}
	UMaterialInterface* PropertyValue;
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaUtils::ReturnUObject(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_ComputeNormal(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"WaterWaveActor",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"WaterWaveActor must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AWaterWaveActor::StaticClass(), TEXT("ComputeNormal"));
	if(!Property) { check(false); return 0;}
	UMaterialInterface* PropertyValue = (UMaterialInterface*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"MaterialInterface");;
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_HeightMap(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"WaterWaveActor",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"WaterWaveActor must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AWaterWaveActor::StaticClass(), TEXT("HeightMap"));
	if(!Property) { check(false); return 0;}
	UTextureRenderTarget2D* PropertyValue;
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaUtils::ReturnUObject(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_HeightMap(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"WaterWaveActor",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"WaterWaveActor must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AWaterWaveActor::StaticClass(), TEXT("HeightMap"));
	if(!Property) { check(false); return 0;}
	UTextureRenderTarget2D* PropertyValue = (UTextureRenderTarget2D*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"TextureRenderTarget2D");;
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 New(lua_State* InScriptContext)
{
	UObject* Outer = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Object");
	FName Name = FName(luaL_checkstring(InScriptContext, 2));
	UObject* Obj = NewObject<AWaterWaveActor>(Outer, Name);
	wLua::FLuaUtils::ReturnUObject(InScriptContext,Obj);
	return 1;
}

int32 Destroy(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"WaterWaveActor",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"WaterWaveActor must be non-null"); lua_error(InScriptContext);  return 0;}
		AActor * actor = Cast<AActor>(Obj);
		actor->Destroy();
		userdata->flag |= wLua::LuaObjectFlag::DESTROYED;
		wLua::FLuaUtils::RemoveObjectReference(Obj, userdata->stamp, InScriptContext);
#ifdef AZURE_BUILD_WLUACHECK
		UE_LOG(LogAzure, Warning, TEXT("Destroy WaterWaveActor: %x userdata:%x   stamp:%x"),Obj,userdata,userdata->stamp);
#endif
	return 0;
}

int32 Class(lua_State* InScriptContext)
{
	UClass* Class = AWaterWaveActor::StaticClass();
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Class);
	return 1;
}

const luaL_Reg Lib_Funcs[] =
{
	{ "New", New },
	{ "Destroy", Destroy },
	{ "Class", Class },
	{ "UpdateCenter", UpdateCenter },
	{ "HitPoint", HitPoint },
	{ "Get_OpenWaveWater", Get_OpenWaveWater },
	{ "Set_OpenWaveWater", Set_OpenWaveWater },
	{ "Get_WaterMat", Get_WaterMat },
	{ "Set_WaterMat", Set_WaterMat },
	{ "Get_MapSize", Get_MapSize },
	{ "Set_MapSize", Set_MapSize },
	{ "Get_HeightfieldNormal", Get_HeightfieldNormal },
	{ "Set_HeightfieldNormal", Set_HeightfieldNormal },
	{ "Get_DefaultTex", Get_DefaultTex },
	{ "Set_DefaultTex", Set_DefaultTex },
	{ "Get_TextureTile", Get_TextureTile },
	{ "Set_TextureTile", Set_TextureTile },
	{ "Get_TotalTime", Get_TotalTime },
	{ "Set_TotalTime", Set_TotalTime },
	{ "Get_CurveData", Get_CurveData },
	{ "Set_CurveData", Set_CurveData },
	{ "Get_ComputeNormal", Get_ComputeNormal },
	{ "Set_ComputeNormal", Set_ComputeNormal },
	{ "Get_HeightMap", Get_HeightMap },
	{ "Set_HeightMap", Set_HeightMap },
	{ "is_nil", wLua::LuaStatic::isnil },
	{ "__gc", wLua::LuaStatic::removeUClassFrameCache },
	{ NULL, NULL }
};

void Register(lua_State *InScriptContext)
{
	lua_newtable(InScriptContext);
	luaL_register(InScriptContext, NULL, Lib_Funcs);
	AzureHelpFuncs::AuxRegister(InScriptContext, "WaterWaveActor");
}
void SetMtLink(lua_State *InScriptContext)
{
	AzureHelpFuncs::AuxSetMtLink(InScriptContext, "WaterWaveActor", "StaticMeshActor",USERDATATYPE_UOBJECT);
}

}