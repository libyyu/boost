#include "Azure.h"
#include "Utility/help_funcs.h"
#include "wLua/UObjectHeaders.h"
#include "LevelSequencePlayer.h"
#include "AzureLuaIntegration.h"

namespace LuaLevelSequencePlayer
{
int32 Play(lua_State*);
int32 PlayReverse(lua_State*);
int32 JumpToFrame(lua_State*);
int32 Pause(lua_State*);
int32 Stop(lua_State*);
int32 IsPlaying(lua_State*);
int32 SetTransformOffset(lua_State*);
int32 GetLength(lua_State*);

int32 Call_OnCameraCut(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"LevelSequencePlayer",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"LevelSequencePlayer must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		UCameraComponent* CameraComponent = nullptr;
	} Params;
	Params.CameraComponent = (UCameraComponent*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"CameraComponent");;
	ULevelSequencePlayer * This = (ULevelSequencePlayer *)Obj;
	This->OnCameraCut.Broadcast(Params.CameraComponent);
	return 0;
}

int32 New(lua_State* InScriptContext)
{
	UObject* Outer = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Object");
	FName Name = FName(luaL_checkstring(InScriptContext, 2));
	UObject* Obj = NewObject<ULevelSequencePlayer>(Outer, Name);
	wLua::FLuaUtils::ReturnUObject(InScriptContext,Obj);
	return 1;
}

int32 Destroy(lua_State* InScriptContext)
{
	return 0;
}

int32 Class(lua_State* InScriptContext)
{
	UClass* Class = ULevelSequencePlayer::StaticClass();
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Class);
	return 1;
}

const luaL_Reg Lib_Funcs[] =
{
	{ "New", New },
	{ "Destroy", Destroy },
	{ "Class", Class },
	{ "Call_OnCameraCut", Call_OnCameraCut },
	{ "Play", Play },
	{ "PlayReverse", PlayReverse },
	{ "JumpToFrame", JumpToFrame },
	{ "Pause", Pause },
	{ "Stop", Stop },
	{ "IsPlaying", IsPlaying },
	{ "SetTransformOffset", SetTransformOffset },
	{ "GetLength", GetLength },
	{ "is_nil", wLua::LuaStatic::isnil },
	{ "__gc", wLua::LuaStatic::removeUClassFrameCache },
	{ NULL, NULL }
};

void Register(lua_State *InScriptContext)
{
	lua_newtable(InScriptContext);
	luaL_register(InScriptContext, NULL, Lib_Funcs);
	AzureHelpFuncs::AuxRegister(InScriptContext, "LevelSequencePlayer");
}
void SetMtLink(lua_State *InScriptContext)
{
	AzureHelpFuncs::AuxSetMtLink(InScriptContext, "LevelSequencePlayer", "MovieSceneSequencePlayer",USERDATATYPE_UOBJECT);
}

}