#include "Azure.h"
#include "Utility/help_funcs.h"
#include "wLua/UObjectHeaders.h"
#include "Particles/ParticleSystem.h"
#include "AzureLuaIntegration.h"

namespace LuaParticleSystem
{
int32 ContainsEmitterType(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ParticleSystem",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ParticleSystem must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		UClass* TypeData = nullptr;
		bool ReturnValue;
	} Params;
	Params.TypeData = (UClass*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"Class");;
#if UE_GAME
	UParticleSystem * This = (UParticleSystem *)Obj;
	Params.ReturnValue = This->ContainsEmitterType(Params.TypeData);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("ContainsEmitterType"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(UClass**)(params.GetStructMemory() + 0) = Params.TypeData;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.TypeData = *(UClass**)(params.GetStructMemory() + 0);
		Params.ReturnValue = *(bool*)(params.GetStructMemory() + 8);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushboolean(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 Get_SystemUpdateMode(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ParticleSystem",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ParticleSystem must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UParticleSystem::StaticClass(), TEXT("SystemUpdateMode"));
	if(!Property) { check(false); return 0;}
	TEnumAsByte<EParticleSystemUpdateMode> PropertyValue = TEnumAsByte<EParticleSystemUpdateMode>();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushinteger(InScriptContext, (int)PropertyValue);
	return 1;
}

int32 Set_SystemUpdateMode(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ParticleSystem",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ParticleSystem must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UParticleSystem::StaticClass(), TEXT("SystemUpdateMode"));
	if(!Property) { check(false); return 0;}
	TEnumAsByte<EParticleSystemUpdateMode> PropertyValue = (TEnumAsByte<EParticleSystemUpdateMode>)(luaL_checkint(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_UpdateTime_FPS(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ParticleSystem",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ParticleSystem must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UParticleSystem::StaticClass(), TEXT("UpdateTime_FPS"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_UpdateTime_FPS(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ParticleSystem",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ParticleSystem must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UParticleSystem::StaticClass(), TEXT("UpdateTime_FPS"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_WarmupTime(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ParticleSystem",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ParticleSystem must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UParticleSystem::StaticClass(), TEXT("WarmupTime"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_WarmupTime(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ParticleSystem",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ParticleSystem must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UParticleSystem::StaticClass(), TEXT("WarmupTime"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_WarmupTickRate(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ParticleSystem",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ParticleSystem must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UParticleSystem::StaticClass(), TEXT("WarmupTickRate"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_WarmupTickRate(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ParticleSystem",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ParticleSystem must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UParticleSystem::StaticClass(), TEXT("WarmupTickRate"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_ThumbnailWarmup(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ParticleSystem",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ParticleSystem must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UParticleSystem::StaticClass(), TEXT("ThumbnailWarmup"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_ThumbnailWarmup(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ParticleSystem",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ParticleSystem must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UParticleSystem::StaticClass(), TEXT("ThumbnailWarmup"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bOrientZAxisTowardCamera(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ParticleSystem",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ParticleSystem must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UParticleSystem::StaticClass(), TEXT("bOrientZAxisTowardCamera"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bOrientZAxisTowardCamera(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ParticleSystem",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ParticleSystem must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UParticleSystem::StaticClass(), TEXT("bOrientZAxisTowardCamera"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_LODDistanceCheckTime(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ParticleSystem",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ParticleSystem must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UParticleSystem::StaticClass(), TEXT("LODDistanceCheckTime"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_LODDistanceCheckTime(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ParticleSystem",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ParticleSystem must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UParticleSystem::StaticClass(), TEXT("LODDistanceCheckTime"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_LODMethod(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ParticleSystem",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ParticleSystem must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UParticleSystem::StaticClass(), TEXT("LODMethod"));
	if(!Property) { check(false); return 0;}
	TEnumAsByte<ParticleSystemLODMethod> PropertyValue = TEnumAsByte<ParticleSystemLODMethod>();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushinteger(InScriptContext, (int)PropertyValue);
	return 1;
}

int32 Set_LODMethod(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ParticleSystem",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ParticleSystem must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UParticleSystem::StaticClass(), TEXT("LODMethod"));
	if(!Property) { check(false); return 0;}
	TEnumAsByte<ParticleSystemLODMethod> PropertyValue = (TEnumAsByte<ParticleSystemLODMethod>)(luaL_checkint(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_LODDistances(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ParticleSystem",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ParticleSystem must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UParticleSystem::StaticClass(), TEXT("LODDistances"));
	if(!Property) { check(false); return 0;}
	TArray<float> PropertyValue;
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	{lua_newtable(InScriptContext); int i = 1; for(auto It = PropertyValue.CreateConstIterator(); It; ++It,++i) {  lua_pushnumber(InScriptContext, (*It)); lua_rawseti(InScriptContext,-2,i);     }  }
	return 1;
}

int32 Set_LODDistances(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ParticleSystem",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ParticleSystem must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UParticleSystem::StaticClass(), TEXT("LODDistances"));
	if(!Property) { check(false); return 0;}
	TArray<float> PropertyValue = [](lua_State * _InScriptContext){ TArray<float> ret; lua_pushnil(_InScriptContext); while(lua_next(_InScriptContext,2)!=0){ float item = (float)(luaL_checknumber(_InScriptContext, -1)); ret.Add(item); lua_pop(_InScriptContext,1);  } return ret; }(InScriptContext);;
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bUseFixedRelativeBoundingBox(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ParticleSystem",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ParticleSystem must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UParticleSystem::StaticClass(), TEXT("bUseFixedRelativeBoundingBox"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bUseFixedRelativeBoundingBox(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ParticleSystem",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ParticleSystem must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UParticleSystem::StaticClass(), TEXT("bUseFixedRelativeBoundingBox"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_SecondsBeforeInactive(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ParticleSystem",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ParticleSystem must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UParticleSystem::StaticClass(), TEXT("SecondsBeforeInactive"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_SecondsBeforeInactive(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ParticleSystem",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ParticleSystem must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UParticleSystem::StaticClass(), TEXT("SecondsBeforeInactive"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bUseRealtimeThumbnail(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ParticleSystem",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ParticleSystem must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UParticleSystem::StaticClass(), TEXT("bUseRealtimeThumbnail"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bUseRealtimeThumbnail(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ParticleSystem",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ParticleSystem must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UParticleSystem::StaticClass(), TEXT("bUseRealtimeThumbnail"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_Delay(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ParticleSystem",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ParticleSystem must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UParticleSystem::StaticClass(), TEXT("Delay"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_Delay(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ParticleSystem",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ParticleSystem must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UParticleSystem::StaticClass(), TEXT("Delay"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_DelayLow(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ParticleSystem",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ParticleSystem must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UParticleSystem::StaticClass(), TEXT("DelayLow"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_DelayLow(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ParticleSystem",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ParticleSystem must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UParticleSystem::StaticClass(), TEXT("DelayLow"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bUseDelayRange(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ParticleSystem",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ParticleSystem must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UParticleSystem::StaticClass(), TEXT("bUseDelayRange"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bUseDelayRange(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ParticleSystem",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ParticleSystem must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UParticleSystem::StaticClass(), TEXT("bUseDelayRange"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bAutoDeactivate(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ParticleSystem",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ParticleSystem must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UParticleSystem::StaticClass(), TEXT("bAutoDeactivate"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = bool();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bAutoDeactivate(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ParticleSystem",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ParticleSystem must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UParticleSystem::StaticClass(), TEXT("bAutoDeactivate"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_InsignificantReaction(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ParticleSystem",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ParticleSystem must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UParticleSystem::StaticClass(), TEXT("InsignificantReaction"));
	if(!Property) { check(false); return 0;}
	EParticleSystemInsignificanceReaction PropertyValue = EParticleSystemInsignificanceReaction();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushinteger(InScriptContext, (int)PropertyValue);
	return 1;
}

int32 Set_InsignificantReaction(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ParticleSystem",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ParticleSystem must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UParticleSystem::StaticClass(), TEXT("InsignificantReaction"));
	if(!Property) { check(false); return 0;}
	EParticleSystemInsignificanceReaction PropertyValue = (EParticleSystemInsignificanceReaction)(luaL_checkint(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_InsignificanceDelay(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ParticleSystem",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ParticleSystem must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UParticleSystem::StaticClass(), TEXT("InsignificanceDelay"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_InsignificanceDelay(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ParticleSystem",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ParticleSystem must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UParticleSystem::StaticClass(), TEXT("InsignificanceDelay"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_MaxSignificanceLevel(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ParticleSystem",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ParticleSystem must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UParticleSystem::StaticClass(), TEXT("MaxSignificanceLevel"));
	if(!Property) { check(false); return 0;}
	EParticleSignificanceLevel PropertyValue = EParticleSignificanceLevel();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushinteger(InScriptContext, (int)PropertyValue);
	return 1;
}

int32 Set_MaxSignificanceLevel(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ParticleSystem",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ParticleSystem must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UParticleSystem::StaticClass(), TEXT("MaxSignificanceLevel"));
	if(!Property) { check(false); return 0;}
	EParticleSignificanceLevel PropertyValue = (EParticleSignificanceLevel)(luaL_checkint(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_AzureCostLevel(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ParticleSystem",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ParticleSystem must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UParticleSystem::StaticClass(), TEXT("AzureCostLevel"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushinteger(InScriptContext, (int)PropertyValue);
	return 1;
}

int32 Set_AzureCostLevel(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ParticleSystem",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ParticleSystem must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UParticleSystem::StaticClass(), TEXT("AzureCostLevel"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = (uint8)(luaL_checkint(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_MacroUVPosition(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ParticleSystem",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ParticleSystem must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UParticleSystem::StaticClass(), TEXT("MacroUVPosition"));
	if(!Property) { check(false); return 0;}
	FVector PropertyValue = FVector();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaVector::Return(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_MacroUVPosition(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ParticleSystem",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ParticleSystem must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UParticleSystem::StaticClass(), TEXT("MacroUVPosition"));
	if(!Property) { check(false); return 0;}
	FVector PropertyValue = (wLua::FLuaVector::Get(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_MacroUVRadius(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ParticleSystem",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ParticleSystem must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UParticleSystem::StaticClass(), TEXT("MacroUVRadius"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_MacroUVRadius(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ParticleSystem",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ParticleSystem must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UParticleSystem::StaticClass(), TEXT("MacroUVRadius"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_OcclusionBoundsMethod(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ParticleSystem",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ParticleSystem must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UParticleSystem::StaticClass(), TEXT("OcclusionBoundsMethod"));
	if(!Property) { check(false); return 0;}
	TEnumAsByte<EParticleSystemOcclusionBoundsMethod> PropertyValue = TEnumAsByte<EParticleSystemOcclusionBoundsMethod>();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushinteger(InScriptContext, (int)PropertyValue);
	return 1;
}

int32 Set_OcclusionBoundsMethod(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ParticleSystem",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ParticleSystem must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UParticleSystem::StaticClass(), TEXT("OcclusionBoundsMethod"));
	if(!Property) { check(false); return 0;}
	TEnumAsByte<EParticleSystemOcclusionBoundsMethod> PropertyValue = (TEnumAsByte<EParticleSystemOcclusionBoundsMethod>)(luaL_checkint(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 New(lua_State* InScriptContext)
{
	UObject* Outer = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Object");
	FName Name = FName(luaL_checkstring(InScriptContext, 2));
	UObject* Obj = NewObject<UParticleSystem>(Outer, Name);
	wLua::FLuaUtils::ReturnUObject(InScriptContext,Obj);
	return 1;
}

int32 Destroy(lua_State* InScriptContext)
{
	return 0;
}

int32 Class(lua_State* InScriptContext)
{
	UClass* Class = UParticleSystem::StaticClass();
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Class);
	return 1;
}

const luaL_Reg Lib_Funcs[] =
{
	{ "New", New },
	{ "Destroy", Destroy },
	{ "Class", Class },
	{ "ContainsEmitterType", ContainsEmitterType },
	{ "Get_SystemUpdateMode", Get_SystemUpdateMode },
	{ "Set_SystemUpdateMode", Set_SystemUpdateMode },
	{ "Get_UpdateTime_FPS", Get_UpdateTime_FPS },
	{ "Set_UpdateTime_FPS", Set_UpdateTime_FPS },
	{ "Get_WarmupTime", Get_WarmupTime },
	{ "Set_WarmupTime", Set_WarmupTime },
	{ "Get_WarmupTickRate", Get_WarmupTickRate },
	{ "Set_WarmupTickRate", Set_WarmupTickRate },
	{ "Get_ThumbnailWarmup", Get_ThumbnailWarmup },
	{ "Set_ThumbnailWarmup", Set_ThumbnailWarmup },
	{ "Get_bOrientZAxisTowardCamera", Get_bOrientZAxisTowardCamera },
	{ "Set_bOrientZAxisTowardCamera", Set_bOrientZAxisTowardCamera },
	{ "Get_LODDistanceCheckTime", Get_LODDistanceCheckTime },
	{ "Set_LODDistanceCheckTime", Set_LODDistanceCheckTime },
	{ "Get_LODMethod", Get_LODMethod },
	{ "Set_LODMethod", Set_LODMethod },
	{ "Get_LODDistances", Get_LODDistances },
	{ "Set_LODDistances", Set_LODDistances },
	{ "Get_bUseFixedRelativeBoundingBox", Get_bUseFixedRelativeBoundingBox },
	{ "Set_bUseFixedRelativeBoundingBox", Set_bUseFixedRelativeBoundingBox },
	{ "Get_SecondsBeforeInactive", Get_SecondsBeforeInactive },
	{ "Set_SecondsBeforeInactive", Set_SecondsBeforeInactive },
	{ "Get_bUseRealtimeThumbnail", Get_bUseRealtimeThumbnail },
	{ "Set_bUseRealtimeThumbnail", Set_bUseRealtimeThumbnail },
	{ "Get_Delay", Get_Delay },
	{ "Set_Delay", Set_Delay },
	{ "Get_DelayLow", Get_DelayLow },
	{ "Set_DelayLow", Set_DelayLow },
	{ "Get_bUseDelayRange", Get_bUseDelayRange },
	{ "Set_bUseDelayRange", Set_bUseDelayRange },
	{ "Get_bAutoDeactivate", Get_bAutoDeactivate },
	{ "Set_bAutoDeactivate", Set_bAutoDeactivate },
	{ "Get_InsignificantReaction", Get_InsignificantReaction },
	{ "Set_InsignificantReaction", Set_InsignificantReaction },
	{ "Get_InsignificanceDelay", Get_InsignificanceDelay },
	{ "Set_InsignificanceDelay", Set_InsignificanceDelay },
	{ "Get_MaxSignificanceLevel", Get_MaxSignificanceLevel },
	{ "Set_MaxSignificanceLevel", Set_MaxSignificanceLevel },
	{ "Get_AzureCostLevel", Get_AzureCostLevel },
	{ "Set_AzureCostLevel", Set_AzureCostLevel },
	{ "Get_MacroUVPosition", Get_MacroUVPosition },
	{ "Set_MacroUVPosition", Set_MacroUVPosition },
	{ "Get_MacroUVRadius", Get_MacroUVRadius },
	{ "Set_MacroUVRadius", Set_MacroUVRadius },
	{ "Get_OcclusionBoundsMethod", Get_OcclusionBoundsMethod },
	{ "Set_OcclusionBoundsMethod", Set_OcclusionBoundsMethod },
	{ "is_nil", wLua::LuaStatic::isnil },
	{ "__gc", wLua::LuaStatic::removeUClassFrameCache },
	{ NULL, NULL }
};

void Register(lua_State *InScriptContext)
{
	lua_newtable(InScriptContext);
	luaL_register(InScriptContext, NULL, Lib_Funcs);
	AzureHelpFuncs::AuxRegister(InScriptContext, "ParticleSystem");
}
void SetMtLink(lua_State *InScriptContext)
{
	AzureHelpFuncs::AuxSetMtLink(InScriptContext, "ParticleSystem", "Object",USERDATATYPE_UOBJECT);
}

}