#include "Azure.h"
#include "Utility/help_funcs.h"
#include "wLua/UObjectHeaders.h"
#include "Components/Button.h"
#include "AzureLuaIntegration.h"

namespace LuaButton
{
int32 SetBrushTexture(lua_State*);
int32 SetButtonAtlasName(lua_State*);

int32 SetTouchMethod(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Button",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Button must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		TEnumAsByte<EButtonTouchMethod::Type> InTouchMethod;
	} Params;
	Params.InTouchMethod = (TEnumAsByte<EButtonTouchMethod::Type>)(luaL_checkint(InScriptContext, 2));
#if UE_GAME
	UButton * This = (UButton *)Obj;
	This->SetTouchMethod(Params.InTouchMethod);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetTouchMethod"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(TEnumAsByte<EButtonTouchMethod::Type>*)(params.GetStructMemory() + 0) = Params.InTouchMethod;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.InTouchMethod = *(TEnumAsByte<EButtonTouchMethod::Type>*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetPressMethod(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Button",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Button must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		TEnumAsByte<EButtonPressMethod::Type> InPressMethod;
	} Params;
	Params.InPressMethod = (TEnumAsByte<EButtonPressMethod::Type>)(luaL_checkint(InScriptContext, 2));
#if UE_GAME
	UButton * This = (UButton *)Obj;
	This->SetPressMethod(Params.InPressMethod);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetPressMethod"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(TEnumAsByte<EButtonPressMethod::Type>*)(params.GetStructMemory() + 0) = Params.InPressMethod;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.InPressMethod = *(TEnumAsByte<EButtonPressMethod::Type>*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetColorAndOpacity(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Button",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Button must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FLinearColor InColorAndOpacity;
	} Params;
	Params.InColorAndOpacity = (wLua::FLuaLinearColor::Get(InScriptContext, 2));
#if UE_GAME
	UButton * This = (UButton *)Obj;
	This->SetColorAndOpacity(Params.InColorAndOpacity);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetColorAndOpacity"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FLinearColor*)(params.GetStructMemory() + 0) = Params.InColorAndOpacity;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.InColorAndOpacity = *(FLinearColor*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetClickMethod(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Button",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Button must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		TEnumAsByte<EButtonClickMethod::Type> InClickMethod;
	} Params;
	Params.InClickMethod = (TEnumAsByte<EButtonClickMethod::Type>)(luaL_checkint(InScriptContext, 2));
#if UE_GAME
	UButton * This = (UButton *)Obj;
	This->SetClickMethod(Params.InClickMethod);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetClickMethod"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(TEnumAsByte<EButtonClickMethod::Type>*)(params.GetStructMemory() + 0) = Params.InClickMethod;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.InClickMethod = *(TEnumAsByte<EButtonClickMethod::Type>*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetBackgroundColor(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Button",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Button must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FLinearColor InBackgroundColor;
	} Params;
	Params.InBackgroundColor = (wLua::FLuaLinearColor::Get(InScriptContext, 2));
#if UE_GAME
	UButton * This = (UButton *)Obj;
	This->SetBackgroundColor(Params.InBackgroundColor);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetBackgroundColor"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FLinearColor*)(params.GetStructMemory() + 0) = Params.InBackgroundColor;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.InBackgroundColor = *(FLinearColor*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 IsPressed(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Button",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Button must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool ReturnValue;
	} Params;
#if UE_GAME
	UButton * This = (UButton *)Obj;
	Params.ReturnValue = This->IsPressed();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("IsPressed"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushboolean(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 Get_ColorAndOpacity(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Button",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Button must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UButton::StaticClass(), TEXT("ColorAndOpacity"));
	if(!Property) { check(false); return 0;}
	FLinearColor PropertyValue = FLinearColor();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaLinearColor::Return(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_BackgroundColor(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Button",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Button must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UButton::StaticClass(), TEXT("BackgroundColor"));
	if(!Property) { check(false); return 0;}
	FLinearColor PropertyValue = FLinearColor();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaLinearColor::Return(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_ClickMethod(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Button",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Button must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UButton::StaticClass(), TEXT("ClickMethod"));
	if(!Property) { check(false); return 0;}
	TEnumAsByte<EButtonClickMethod::Type> PropertyValue = TEnumAsByte<EButtonClickMethod::Type>();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushinteger(InScriptContext, (int)PropertyValue);
	return 1;
}

int32 Get_TouchMethod(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Button",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Button must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UButton::StaticClass(), TEXT("TouchMethod"));
	if(!Property) { check(false); return 0;}
	TEnumAsByte<EButtonTouchMethod::Type> PropertyValue = TEnumAsByte<EButtonTouchMethod::Type>();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushinteger(InScriptContext, (int)PropertyValue);
	return 1;
}

int32 Get_PressMethod(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Button",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Button must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UButton::StaticClass(), TEXT("PressMethod"));
	if(!Property) { check(false); return 0;}
	TEnumAsByte<EButtonPressMethod::Type> PropertyValue = TEnumAsByte<EButtonPressMethod::Type>();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushinteger(InScriptContext, (int)PropertyValue);
	return 1;
}

int32 Get_IsFocusable(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Button",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Button must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UButton::StaticClass(), TEXT("IsFocusable"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = bool();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_IsInheritStateColors(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Button",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Button must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UButton::StaticClass(), TEXT("IsInheritStateColors"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = bool();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Call_OnClicked(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Button",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Button must be non-null"); lua_error(InScriptContext);  return 0;}
	UButton * This = (UButton *)Obj;
	This->OnClicked.Broadcast();
	return 0;
}

int32 Call_OnPressed(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Button",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Button must be non-null"); lua_error(InScriptContext);  return 0;}
	UButton * This = (UButton *)Obj;
	This->OnPressed.Broadcast();
	return 0;
}

int32 Call_OnReleased(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Button",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Button must be non-null"); lua_error(InScriptContext);  return 0;}
	UButton * This = (UButton *)Obj;
	This->OnReleased.Broadcast();
	return 0;
}

int32 Call_OnHovered(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Button",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Button must be non-null"); lua_error(InScriptContext);  return 0;}
	UButton * This = (UButton *)Obj;
	This->OnHovered.Broadcast();
	return 0;
}

int32 Call_OnUnhovered(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Button",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Button must be non-null"); lua_error(InScriptContext);  return 0;}
	UButton * This = (UButton *)Obj;
	This->OnUnhovered.Broadcast();
	return 0;
}

int32 Get_DisableColor(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Button",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Button must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UButton::StaticClass(), TEXT("DisableColor"));
	if(!Property) { check(false); return 0;}
	FLinearColor PropertyValue = FLinearColor();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaLinearColor::Return(InScriptContext, PropertyValue);
	return 1;
}

int32 New(lua_State* InScriptContext)
{
	UObject* Outer = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Object");
	FName Name = FName(luaL_checkstring(InScriptContext, 2));
	UObject* Obj = NewObject<UButton>(Outer, Name);
	wLua::FLuaUtils::ReturnUObject(InScriptContext,Obj);
	return 1;
}

int32 Destroy(lua_State* InScriptContext)
{
	return 0;
}

int32 Class(lua_State* InScriptContext)
{
	UClass* Class = UButton::StaticClass();
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Class);
	return 1;
}

const luaL_Reg Lib_Funcs[] =
{
	{ "New", New },
	{ "Destroy", Destroy },
	{ "Class", Class },
	{ "SetTouchMethod", SetTouchMethod },
	{ "SetPressMethod", SetPressMethod },
	{ "SetColorAndOpacity", SetColorAndOpacity },
	{ "SetClickMethod", SetClickMethod },
	{ "SetBackgroundColor", SetBackgroundColor },
	{ "IsPressed", IsPressed },
	{ "Get_ColorAndOpacity", Get_ColorAndOpacity },
	{ "Get_BackgroundColor", Get_BackgroundColor },
	{ "Get_ClickMethod", Get_ClickMethod },
	{ "Get_TouchMethod", Get_TouchMethod },
	{ "Get_PressMethod", Get_PressMethod },
	{ "Get_IsFocusable", Get_IsFocusable },
	{ "Get_IsInheritStateColors", Get_IsInheritStateColors },
	{ "Call_OnClicked", Call_OnClicked },
	{ "Call_OnPressed", Call_OnPressed },
	{ "Call_OnReleased", Call_OnReleased },
	{ "Call_OnHovered", Call_OnHovered },
	{ "Call_OnUnhovered", Call_OnUnhovered },
	{ "Get_DisableColor", Get_DisableColor },
	{ "SetBrushTexture", SetBrushTexture },
	{ "SetButtonAtlasName", SetButtonAtlasName },
	{ "is_nil", wLua::LuaStatic::isnil },
	{ "__gc", wLua::LuaStatic::removeUClassFrameCache },
	{ NULL, NULL }
};

void Register(lua_State *InScriptContext)
{
	lua_newtable(InScriptContext);
	luaL_register(InScriptContext, NULL, Lib_Funcs);
	AzureHelpFuncs::AuxRegister(InScriptContext, "Button");
}
void SetMtLink(lua_State *InScriptContext)
{
	AzureHelpFuncs::AuxSetMtLink(InScriptContext, "Button", "ContentWidget",USERDATATYPE_UOBJECT);
}

}