#include "Azure.h"
#include "Utility/help_funcs.h"
#include "wLua/UObjectHeaders.h"
#include "AzureLuaIntegration.h"

namespace LuaObject
{
int32 GetName(lua_State*);
int32 GetFullName(lua_State*);
int32 GetPathName(lua_State*);
int32 GetOuter(lua_State*);
int32 GetClass(lua_State*);
int32 GetClassName2(lua_State*);
int32 GetWorld(lua_State*);
int32 GetReferenced(lua_State*);
int32 GetReferencing(lua_State*);
int32 GetReferencingChains(lua_State*);
int32 GetInnerObjects(lua_State*);
int32 IsA(lua_State*);
int32 GetUniqueID(lua_State*);
int32 GetResourceSizeBytes(lua_State*);
int32 Rename(lua_State*);
int32 GetAddress(lua_State*);
int32 FromAddress(lua_State*);
int32 GetOutermost(lua_State*);
int32 GetTypedOuter(lua_State*);
int32 IsIn(lua_State*);
int32 IsInA(lua_State*);
int32 GetFlags(lua_State*);
int32 SetFlags(lua_State*);
int32 GetInternalFlags(lua_State*);
int32 SetInternalFlags(lua_State*);
int32 AddToRoot(lua_State*);
int32 RemoveFromRoot(lua_State*);
int32 IsRooted(lua_State*);

int32 Class(lua_State* InScriptContext)
{
	UClass* Class = UObject::StaticClass();
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Class);
	return 1;
}

const luaL_Reg Lib_Funcs[] =
{
	{ "Class", Class },
	{ "GetName", GetName },
	{ "GetFullName", GetFullName },
	{ "GetPathName", GetPathName },
	{ "GetOuter", GetOuter },
	{ "GetClass", GetClass },
	{ "GetClassName", GetClassName2 },
	{ "GetWorld", GetWorld },
	{ "GetReferenced", GetReferenced },
	{ "GetReferencing", GetReferencing },
	{ "GetReferencingChains", GetReferencingChains },
	{ "GetInnerObjects", GetInnerObjects },
	{ "IsA", IsA },
	{ "GetUniqueID", GetUniqueID },
	{ "GetResourceSizeBytes", GetResourceSizeBytes },
	{ "Rename", Rename },
	{ "GetAddress", GetAddress },
	{ "FromAddress", FromAddress },
	{ "GetOutermost", GetOutermost },
	{ "GetTypedOuter", GetTypedOuter },
	{ "IsIn", IsIn },
	{ "IsInA", IsInA },
	{ "GetFlags", GetFlags },
	{ "SetFlags", SetFlags },
	{ "GetInternalFlags", GetInternalFlags },
	{ "SetInternalFlags", SetInternalFlags },
	{ "AddToRoot", AddToRoot },
	{ "RemoveFromRoot", RemoveFromRoot },
	{ "IsRooted", IsRooted },
	{ "is_nil", wLua::LuaStatic::isnil },
	{ "__gc", wLua::LuaStatic::removeUClassFrameCache },
	{ NULL, NULL }
};

void Register(lua_State *InScriptContext)
{
	lua_newtable(InScriptContext);
	luaL_register(InScriptContext, NULL, Lib_Funcs);
	AzureHelpFuncs::AuxRegister(InScriptContext, "Object");
}
void SetMtLink(lua_State *InScriptContext)
{
	AzureHelpFuncs::AuxSetMtLink(InScriptContext, "Object",nullptr,USERDATATYPE_UOBJECT);
}

}