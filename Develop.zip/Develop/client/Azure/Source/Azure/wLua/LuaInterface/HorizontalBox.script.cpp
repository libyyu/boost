#include "Azure.h"
#include "Utility/help_funcs.h"
#include "wLua/UObjectHeaders.h"
#include "Components/HorizontalBox.h"
#include "AzureLuaIntegration.h"

namespace LuaHorizontalBox
{
int32 AddChildToHorizontalBox(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"HorizontalBox",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"HorizontalBox must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		UWidget* Content = nullptr;
		UHorizontalBoxSlot* ReturnValue = nullptr;
	} Params;
	Params.Content = (UWidget*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"Widget");;
#if UE_GAME
	UHorizontalBox * This = (UHorizontalBox *)Obj;
	Params.ReturnValue = This->AddChildToHorizontalBox(Params.Content);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("AddChildToHorizontalBox"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(UWidget**)(params.GetStructMemory() + 0) = Params.Content;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.Content = *(UWidget**)(params.GetStructMemory() + 0);
		Params.ReturnValue = *(UHorizontalBoxSlot**)(params.GetStructMemory() + 8);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 New(lua_State* InScriptContext)
{
	UObject* Outer = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Object");
	FName Name = FName(luaL_checkstring(InScriptContext, 2));
	UObject* Obj = NewObject<UHorizontalBox>(Outer, Name);
	wLua::FLuaUtils::ReturnUObject(InScriptContext,Obj);
	return 1;
}

int32 Destroy(lua_State* InScriptContext)
{
	return 0;
}

int32 Class(lua_State* InScriptContext)
{
	UClass* Class = UHorizontalBox::StaticClass();
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Class);
	return 1;
}

const luaL_Reg Lib_Funcs[] =
{
	{ "New", New },
	{ "Destroy", Destroy },
	{ "Class", Class },
	{ "AddChildToHorizontalBox", AddChildToHorizontalBox },
	{ "is_nil", wLua::LuaStatic::isnil },
	{ "__gc", wLua::LuaStatic::removeUClassFrameCache },
	{ NULL, NULL }
};

void Register(lua_State *InScriptContext)
{
	lua_newtable(InScriptContext);
	luaL_register(InScriptContext, NULL, Lib_Funcs);
	AzureHelpFuncs::AuxRegister(InScriptContext, "HorizontalBox");
}
void SetMtLink(lua_State *InScriptContext)
{
	AzureHelpFuncs::AuxSetMtLink(InScriptContext, "HorizontalBox", "PanelWidget",USERDATATYPE_UOBJECT);
}

}