#include "Azure.h"
#include "Utility/help_funcs.h"
#include "wLua/UObjectHeaders.h"
#include "GameLogic/Player/CarrierCharacterBase.h"
#include "../UClassHeaders.h"
#include "AzureLuaIntegration.h"

namespace LuaCarrierCharacterBase
{
int32 SetupAuthority(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CarrierCharacterBase",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CarrierCharacterBase must be non-null"); lua_error(InScriptContext);  return 0;}
#if UE_GAME
	ACarrierCharacterBase * This = (ACarrierCharacterBase *)Obj;
	This->SetupAuthority();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetupAuthority"));
	if(!Function) { check(false); return 0;}
	Obj->ProcessEvent(Function, NULL);
#endif
	return 0;
}

int32 SetDriver(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CarrierCharacterBase",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CarrierCharacterBase must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		AGamePlayer* driver = nullptr;
	} Params;
	Params.driver = (AGamePlayer*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"GamePlayer");;
#if UE_GAME
	ACarrierCharacterBase * This = (ACarrierCharacterBase *)Obj;
	This->SetDriver(Params.driver);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetDriver"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(AGamePlayer**)(params.GetStructMemory() + 0) = Params.driver;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.driver = *(AGamePlayer**)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 RemovePassenger(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CarrierCharacterBase",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CarrierCharacterBase must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		AGamePlayer* passenger = nullptr;
	} Params;
	Params.passenger = (AGamePlayer*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"GamePlayer");;
#if UE_GAME
	ACarrierCharacterBase * This = (ACarrierCharacterBase *)Obj;
	This->RemovePassenger(Params.passenger);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("RemovePassenger"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(AGamePlayer**)(params.GetStructMemory() + 0) = Params.passenger;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.passenger = *(AGamePlayer**)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 GetDriver(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CarrierCharacterBase",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CarrierCharacterBase must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		AGamePlayer* ReturnValue = nullptr;
	} Params;
#if UE_GAME
	ACarrierCharacterBase * This = (ACarrierCharacterBase *)Obj;
	Params.ReturnValue = This->GetDriver();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetDriver"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(AGamePlayer**)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 CancleAuthority(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CarrierCharacterBase",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CarrierCharacterBase must be non-null"); lua_error(InScriptContext);  return 0;}
#if UE_GAME
	ACarrierCharacterBase * This = (ACarrierCharacterBase *)Obj;
	This->CancleAuthority();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("CancleAuthority"));
	if(!Function) { check(false); return 0;}
	Obj->ProcessEvent(Function, NULL);
#endif
	return 0;
}

int32 ApplyInputVector(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CarrierCharacterBase",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CarrierCharacterBase must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FVector2D input;
	} Params;
	Params.input = (wLua::FLuaVector2D::Get(InScriptContext, 2));
#if UE_GAME
	ACarrierCharacterBase * This = (ACarrierCharacterBase *)Obj;
	This->ApplyInputVector(Params.input);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("ApplyInputVector"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FVector2D*)(params.GetStructMemory() + 0) = Params.input;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.input = *(FVector2D*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 AddPassenger(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CarrierCharacterBase",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CarrierCharacterBase must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		AGamePlayer* passenger = nullptr;
		int32 pos;
	} Params;
	Params.passenger = (AGamePlayer*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"GamePlayer");;
	Params.pos = (luaL_checkint(InScriptContext, 3));
#if UE_GAME
	ACarrierCharacterBase * This = (ACarrierCharacterBase *)Obj;
	This->AddPassenger(Params.passenger,Params.pos);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("AddPassenger"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(AGamePlayer**)(params.GetStructMemory() + 0) = Params.passenger;
		*(int32*)(params.GetStructMemory() + 8) = Params.pos;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.passenger = *(AGamePlayer**)(params.GetStructMemory() + 0);
		Params.pos = *(int32*)(params.GetStructMemory() + 8);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 Get_debugFlag(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CarrierCharacterBase",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CarrierCharacterBase must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(ACarrierCharacterBase::StaticClass(), TEXT("debugFlag"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = bool();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_debugFlag(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CarrierCharacterBase",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CarrierCharacterBase must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(ACarrierCharacterBase::StaticClass(), TEXT("debugFlag"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_debugPrintToScreen(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CarrierCharacterBase",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CarrierCharacterBase must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(ACarrierCharacterBase::StaticClass(), TEXT("debugPrintToScreen"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = bool();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_debugPrintToScreen(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CarrierCharacterBase",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CarrierCharacterBase must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(ACarrierCharacterBase::StaticClass(), TEXT("debugPrintToScreen"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_debugLogConsole(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CarrierCharacterBase",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CarrierCharacterBase must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(ACarrierCharacterBase::StaticClass(), TEXT("debugLogConsole"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = bool();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_debugLogConsole(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CarrierCharacterBase",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CarrierCharacterBase must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(ACarrierCharacterBase::StaticClass(), TEXT("debugLogConsole"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 New(lua_State* InScriptContext)
{
	UObject* Outer = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Object");
	FName Name = FName(luaL_checkstring(InScriptContext, 2));
	UObject* Obj = NewObject<ACarrierCharacterBase>(Outer, Name);
	wLua::FLuaUtils::ReturnUObject(InScriptContext,Obj);
	return 1;
}

int32 Destroy(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CarrierCharacterBase",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CarrierCharacterBase must be non-null"); lua_error(InScriptContext);  return 0;}
		AActor * actor = Cast<AActor>(Obj);
		actor->Destroy();
		userdata->flag |= wLua::LuaObjectFlag::DESTROYED;
		wLua::FLuaUtils::RemoveObjectReference(Obj, userdata->stamp, InScriptContext);
#ifdef AZURE_BUILD_WLUACHECK
		UE_LOG(LogAzure, Warning, TEXT("Destroy CarrierCharacterBase: %x userdata:%x   stamp:%x"),Obj,userdata,userdata->stamp);
#endif
	return 0;
}

int32 Class(lua_State* InScriptContext)
{
	UClass* Class = ACarrierCharacterBase::StaticClass();
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Class);
	return 1;
}

const luaL_Reg Lib_Funcs[] =
{
	{ "New", New },
	{ "Destroy", Destroy },
	{ "Class", Class },
	{ "SetupAuthority", SetupAuthority },
	{ "SetDriver", SetDriver },
	{ "RemovePassenger", RemovePassenger },
	{ "GetDriver", GetDriver },
	{ "CancleAuthority", CancleAuthority },
	{ "ApplyInputVector", ApplyInputVector },
	{ "AddPassenger", AddPassenger },
	{ "Get_debugFlag", Get_debugFlag },
	{ "Set_debugFlag", Set_debugFlag },
	{ "Get_debugPrintToScreen", Get_debugPrintToScreen },
	{ "Set_debugPrintToScreen", Set_debugPrintToScreen },
	{ "Get_debugLogConsole", Get_debugLogConsole },
	{ "Set_debugLogConsole", Set_debugLogConsole },
	{ "is_nil", wLua::LuaStatic::isnil },
	{ "__gc", wLua::LuaStatic::removeUClassFrameCache },
	{ NULL, NULL }
};

void Register(lua_State *InScriptContext)
{
	lua_newtable(InScriptContext);
	luaL_register(InScriptContext, NULL, Lib_Funcs);
	AzureHelpFuncs::AuxRegister(InScriptContext, "CarrierCharacterBase");
}
void SetMtLink(lua_State *InScriptContext)
{
	AzureHelpFuncs::AuxSetMtLink(InScriptContext, "CarrierCharacterBase", "GamePlayer",USERDATATYPE_UOBJECT);
}

}