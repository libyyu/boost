#include "Azure.h"
#include "Utility/help_funcs.h"
#include "wLua/UObjectHeaders.h"
#include "Components/SplineComponent.h"
#include "AzureLuaIntegration.h"

namespace LuaSplineComponent
{
int32 UpdateSpline(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SplineComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SplineComponent must be non-null"); lua_error(InScriptContext);  return 0;}
#if UE_GAME
	USplineComponent * This = (USplineComponent *)Obj;
	This->UpdateSpline();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("UpdateSpline"));
	if(!Function) { check(false); return 0;}
	Obj->ProcessEvent(Function, NULL);
#endif
	return 0;
}

int32 SetUpVectorAtSplinePoint(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SplineComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SplineComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		int32 PointIndex;
		FVector InUpVector;
		TEnumAsByte<ESplineCoordinateSpace::Type> CoordinateSpace;
		bool bUpdateSpline;
	} Params;
	Params.PointIndex = (luaL_checkint(InScriptContext, 2));
	Params.InUpVector = (wLua::FLuaVector::Get(InScriptContext, 3));
	Params.CoordinateSpace = (TEnumAsByte<ESplineCoordinateSpace::Type>)(luaL_checkint(InScriptContext, 4));
	Params.bUpdateSpline = lua_isnoneornil(InScriptContext,5) ? bool(true) : !!(lua_toboolean(InScriptContext, 5));
#if UE_GAME
	USplineComponent * This = (USplineComponent *)Obj;
	This->SetUpVectorAtSplinePoint(Params.PointIndex,Params.InUpVector,Params.CoordinateSpace,Params.bUpdateSpline);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetUpVectorAtSplinePoint"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(int32*)(params.GetStructMemory() + 0) = Params.PointIndex;
		*(FVector*)(params.GetStructMemory() + 4) = Params.InUpVector;
		*(TEnumAsByte<ESplineCoordinateSpace::Type>*)(params.GetStructMemory() + 16) = Params.CoordinateSpace;
		*(bool*)(params.GetStructMemory() + 17) = Params.bUpdateSpline;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.PointIndex = *(int32*)(params.GetStructMemory() + 0);
		Params.InUpVector = *(FVector*)(params.GetStructMemory() + 4);
		Params.CoordinateSpace = *(TEnumAsByte<ESplineCoordinateSpace::Type>*)(params.GetStructMemory() + 16);
		Params.bUpdateSpline = *(bool*)(params.GetStructMemory() + 17);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetUnselectedSplineSegmentColor(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SplineComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SplineComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FLinearColor SegmentColor;
	} Params;
	Params.SegmentColor = (wLua::FLuaLinearColor::Get(InScriptContext, 2));
#if UE_GAME
	USplineComponent * This = (USplineComponent *)Obj;
	This->SetUnselectedSplineSegmentColor(Params.SegmentColor);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetUnselectedSplineSegmentColor"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FLinearColor*)(params.GetStructMemory() + 0) = Params.SegmentColor;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.SegmentColor = *(FLinearColor*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetTangentsAtSplinePoint(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SplineComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SplineComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		int32 PointIndex;
		FVector InArriveTangent;
		FVector InLeaveTangent;
		TEnumAsByte<ESplineCoordinateSpace::Type> CoordinateSpace;
		bool bUpdateSpline;
	} Params;
	Params.PointIndex = (luaL_checkint(InScriptContext, 2));
	Params.InArriveTangent = (wLua::FLuaVector::Get(InScriptContext, 3));
	Params.InLeaveTangent = (wLua::FLuaVector::Get(InScriptContext, 4));
	Params.CoordinateSpace = (TEnumAsByte<ESplineCoordinateSpace::Type>)(luaL_checkint(InScriptContext, 5));
	Params.bUpdateSpline = lua_isnoneornil(InScriptContext,6) ? bool(true) : !!(lua_toboolean(InScriptContext, 6));
#if UE_GAME
	USplineComponent * This = (USplineComponent *)Obj;
	This->SetTangentsAtSplinePoint(Params.PointIndex,Params.InArriveTangent,Params.InLeaveTangent,Params.CoordinateSpace,Params.bUpdateSpline);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetTangentsAtSplinePoint"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(int32*)(params.GetStructMemory() + 0) = Params.PointIndex;
		*(FVector*)(params.GetStructMemory() + 4) = Params.InArriveTangent;
		*(FVector*)(params.GetStructMemory() + 16) = Params.InLeaveTangent;
		*(TEnumAsByte<ESplineCoordinateSpace::Type>*)(params.GetStructMemory() + 28) = Params.CoordinateSpace;
		*(bool*)(params.GetStructMemory() + 29) = Params.bUpdateSpline;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.PointIndex = *(int32*)(params.GetStructMemory() + 0);
		Params.InArriveTangent = *(FVector*)(params.GetStructMemory() + 4);
		Params.InLeaveTangent = *(FVector*)(params.GetStructMemory() + 16);
		Params.CoordinateSpace = *(TEnumAsByte<ESplineCoordinateSpace::Type>*)(params.GetStructMemory() + 28);
		Params.bUpdateSpline = *(bool*)(params.GetStructMemory() + 29);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetTangentAtSplinePoint(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SplineComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SplineComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		int32 PointIndex;
		FVector InTangent;
		TEnumAsByte<ESplineCoordinateSpace::Type> CoordinateSpace;
		bool bUpdateSpline;
	} Params;
	Params.PointIndex = (luaL_checkint(InScriptContext, 2));
	Params.InTangent = (wLua::FLuaVector::Get(InScriptContext, 3));
	Params.CoordinateSpace = (TEnumAsByte<ESplineCoordinateSpace::Type>)(luaL_checkint(InScriptContext, 4));
	Params.bUpdateSpline = lua_isnoneornil(InScriptContext,5) ? bool(true) : !!(lua_toboolean(InScriptContext, 5));
#if UE_GAME
	USplineComponent * This = (USplineComponent *)Obj;
	This->SetTangentAtSplinePoint(Params.PointIndex,Params.InTangent,Params.CoordinateSpace,Params.bUpdateSpline);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetTangentAtSplinePoint"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(int32*)(params.GetStructMemory() + 0) = Params.PointIndex;
		*(FVector*)(params.GetStructMemory() + 4) = Params.InTangent;
		*(TEnumAsByte<ESplineCoordinateSpace::Type>*)(params.GetStructMemory() + 16) = Params.CoordinateSpace;
		*(bool*)(params.GetStructMemory() + 17) = Params.bUpdateSpline;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.PointIndex = *(int32*)(params.GetStructMemory() + 0);
		Params.InTangent = *(FVector*)(params.GetStructMemory() + 4);
		Params.CoordinateSpace = *(TEnumAsByte<ESplineCoordinateSpace::Type>*)(params.GetStructMemory() + 16);
		Params.bUpdateSpline = *(bool*)(params.GetStructMemory() + 17);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetSplinePointType(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SplineComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SplineComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		int32 PointIndex;
		TEnumAsByte<ESplinePointType::Type> Type;
		bool bUpdateSpline;
	} Params;
	Params.PointIndex = (luaL_checkint(InScriptContext, 2));
	Params.Type = (TEnumAsByte<ESplinePointType::Type>)(luaL_checkint(InScriptContext, 3));
	Params.bUpdateSpline = lua_isnoneornil(InScriptContext,4) ? bool(true) : !!(lua_toboolean(InScriptContext, 4));
#if UE_GAME
	USplineComponent * This = (USplineComponent *)Obj;
	This->SetSplinePointType(Params.PointIndex,Params.Type,Params.bUpdateSpline);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetSplinePointType"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(int32*)(params.GetStructMemory() + 0) = Params.PointIndex;
		*(TEnumAsByte<ESplinePointType::Type>*)(params.GetStructMemory() + 4) = Params.Type;
		*(bool*)(params.GetStructMemory() + 5) = Params.bUpdateSpline;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.PointIndex = *(int32*)(params.GetStructMemory() + 0);
		Params.Type = *(TEnumAsByte<ESplinePointType::Type>*)(params.GetStructMemory() + 4);
		Params.bUpdateSpline = *(bool*)(params.GetStructMemory() + 5);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetSplinePoints(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SplineComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SplineComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		TArray<FVector> Points;
		TEnumAsByte<ESplineCoordinateSpace::Type> CoordinateSpace;
		bool bUpdateSpline;
	} Params;
	Params.Points = [](lua_State * _InScriptContext){ TArray<FVector> ret; lua_pushnil(_InScriptContext); while(lua_next(_InScriptContext,2)!=0){ FVector item = (wLua::FLuaVector::Get(_InScriptContext, -1)); ret.Add(item); lua_pop(_InScriptContext,1);  } return ret; }(InScriptContext);;
	Params.CoordinateSpace = (TEnumAsByte<ESplineCoordinateSpace::Type>)(luaL_checkint(InScriptContext, 3));
	Params.bUpdateSpline = lua_isnoneornil(InScriptContext,4) ? bool(true) : !!(lua_toboolean(InScriptContext, 4));
#if UE_GAME
	USplineComponent * This = (USplineComponent *)Obj;
	This->SetSplinePoints(Params.Points,Params.CoordinateSpace,Params.bUpdateSpline);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetSplinePoints"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(TArray<FVector>*)(params.GetStructMemory() + 0) = Params.Points;
		*(TEnumAsByte<ESplineCoordinateSpace::Type>*)(params.GetStructMemory() + 16) = Params.CoordinateSpace;
		*(bool*)(params.GetStructMemory() + 17) = Params.bUpdateSpline;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.Points = *(TArray<FVector>*)(params.GetStructMemory() + 0);
		Params.CoordinateSpace = *(TEnumAsByte<ESplineCoordinateSpace::Type>*)(params.GetStructMemory() + 16);
		Params.bUpdateSpline = *(bool*)(params.GetStructMemory() + 17);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetSelectedSplineSegmentColor(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SplineComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SplineComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FLinearColor SegmentColor;
	} Params;
	Params.SegmentColor = (wLua::FLuaLinearColor::Get(InScriptContext, 2));
#if UE_GAME
	USplineComponent * This = (USplineComponent *)Obj;
	This->SetSelectedSplineSegmentColor(Params.SegmentColor);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetSelectedSplineSegmentColor"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FLinearColor*)(params.GetStructMemory() + 0) = Params.SegmentColor;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.SegmentColor = *(FLinearColor*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetLocationAtSplinePoint(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SplineComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SplineComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		int32 PointIndex;
		FVector InLocation;
		TEnumAsByte<ESplineCoordinateSpace::Type> CoordinateSpace;
		bool bUpdateSpline;
	} Params;
	Params.PointIndex = (luaL_checkint(InScriptContext, 2));
	Params.InLocation = (wLua::FLuaVector::Get(InScriptContext, 3));
	Params.CoordinateSpace = (TEnumAsByte<ESplineCoordinateSpace::Type>)(luaL_checkint(InScriptContext, 4));
	Params.bUpdateSpline = lua_isnoneornil(InScriptContext,5) ? bool(true) : !!(lua_toboolean(InScriptContext, 5));
#if UE_GAME
	USplineComponent * This = (USplineComponent *)Obj;
	This->SetLocationAtSplinePoint(Params.PointIndex,Params.InLocation,Params.CoordinateSpace,Params.bUpdateSpline);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetLocationAtSplinePoint"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(int32*)(params.GetStructMemory() + 0) = Params.PointIndex;
		*(FVector*)(params.GetStructMemory() + 4) = Params.InLocation;
		*(TEnumAsByte<ESplineCoordinateSpace::Type>*)(params.GetStructMemory() + 16) = Params.CoordinateSpace;
		*(bool*)(params.GetStructMemory() + 17) = Params.bUpdateSpline;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.PointIndex = *(int32*)(params.GetStructMemory() + 0);
		Params.InLocation = *(FVector*)(params.GetStructMemory() + 4);
		Params.CoordinateSpace = *(TEnumAsByte<ESplineCoordinateSpace::Type>*)(params.GetStructMemory() + 16);
		Params.bUpdateSpline = *(bool*)(params.GetStructMemory() + 17);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetDrawDebug(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SplineComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SplineComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool bShow;
	} Params;
	Params.bShow = !!(lua_toboolean(InScriptContext, 2));
#if UE_GAME
	USplineComponent * This = (USplineComponent *)Obj;
	This->SetDrawDebug(Params.bShow);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetDrawDebug"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(bool*)(params.GetStructMemory() + 0) = Params.bShow;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.bShow = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetDefaultUpVector(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SplineComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SplineComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FVector UpVector;
		TEnumAsByte<ESplineCoordinateSpace::Type> CoordinateSpace;
	} Params;
	Params.UpVector = (wLua::FLuaVector::Get(InScriptContext, 2));
	Params.CoordinateSpace = (TEnumAsByte<ESplineCoordinateSpace::Type>)(luaL_checkint(InScriptContext, 3));
#if UE_GAME
	USplineComponent * This = (USplineComponent *)Obj;
	This->SetDefaultUpVector(Params.UpVector,Params.CoordinateSpace);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetDefaultUpVector"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FVector*)(params.GetStructMemory() + 0) = Params.UpVector;
		*(TEnumAsByte<ESplineCoordinateSpace::Type>*)(params.GetStructMemory() + 12) = Params.CoordinateSpace;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.UpVector = *(FVector*)(params.GetStructMemory() + 0);
		Params.CoordinateSpace = *(TEnumAsByte<ESplineCoordinateSpace::Type>*)(params.GetStructMemory() + 12);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetClosedLoopAtPosition(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SplineComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SplineComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool bInClosedLoop;
		float Key;
		bool bUpdateSpline;
	} Params;
	Params.bInClosedLoop = !!(lua_toboolean(InScriptContext, 2));
	Params.Key = (float)(luaL_checknumber(InScriptContext, 3));
	Params.bUpdateSpline = lua_isnoneornil(InScriptContext,4) ? bool(true) : !!(lua_toboolean(InScriptContext, 4));
#if UE_GAME
	USplineComponent * This = (USplineComponent *)Obj;
	This->SetClosedLoopAtPosition(Params.bInClosedLoop,Params.Key,Params.bUpdateSpline);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetClosedLoopAtPosition"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(bool*)(params.GetStructMemory() + 0) = Params.bInClosedLoop;
		*(float*)(params.GetStructMemory() + 4) = Params.Key;
		*(bool*)(params.GetStructMemory() + 8) = Params.bUpdateSpline;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.bInClosedLoop = *(bool*)(params.GetStructMemory() + 0);
		Params.Key = *(float*)(params.GetStructMemory() + 4);
		Params.bUpdateSpline = *(bool*)(params.GetStructMemory() + 8);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetClosedLoop(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SplineComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SplineComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool bInClosedLoop;
		bool bUpdateSpline;
	} Params;
	Params.bInClosedLoop = !!(lua_toboolean(InScriptContext, 2));
	Params.bUpdateSpline = lua_isnoneornil(InScriptContext,3) ? bool(true) : !!(lua_toboolean(InScriptContext, 3));
#if UE_GAME
	USplineComponent * This = (USplineComponent *)Obj;
	This->SetClosedLoop(Params.bInClosedLoop,Params.bUpdateSpline);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetClosedLoop"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(bool*)(params.GetStructMemory() + 0) = Params.bInClosedLoop;
		*(bool*)(params.GetStructMemory() + 1) = Params.bUpdateSpline;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.bInClosedLoop = *(bool*)(params.GetStructMemory() + 0);
		Params.bUpdateSpline = *(bool*)(params.GetStructMemory() + 1);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 RemoveSplinePoint(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SplineComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SplineComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		int32 Index;
		bool bUpdateSpline;
	} Params;
	Params.Index = (luaL_checkint(InScriptContext, 2));
	Params.bUpdateSpline = lua_isnoneornil(InScriptContext,3) ? bool(true) : !!(lua_toboolean(InScriptContext, 3));
#if UE_GAME
	USplineComponent * This = (USplineComponent *)Obj;
	This->RemoveSplinePoint(Params.Index,Params.bUpdateSpline);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("RemoveSplinePoint"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(int32*)(params.GetStructMemory() + 0) = Params.Index;
		*(bool*)(params.GetStructMemory() + 4) = Params.bUpdateSpline;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.Index = *(int32*)(params.GetStructMemory() + 0);
		Params.bUpdateSpline = *(bool*)(params.GetStructMemory() + 4);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 IsClosedLoop(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SplineComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SplineComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool ReturnValue;
	} Params;
#if UE_GAME
	USplineComponent * This = (USplineComponent *)Obj;
	Params.ReturnValue = This->IsClosedLoop();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("IsClosedLoop"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushboolean(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetUpVectorAtTime(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SplineComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SplineComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float Time;
		TEnumAsByte<ESplineCoordinateSpace::Type> CoordinateSpace;
		bool bUseConstantVelocity;
		FVector ReturnValue;
	} Params;
	Params.Time = (float)(luaL_checknumber(InScriptContext, 2));
	Params.CoordinateSpace = (TEnumAsByte<ESplineCoordinateSpace::Type>)(luaL_checkint(InScriptContext, 3));
	Params.bUseConstantVelocity = lua_isnoneornil(InScriptContext,4) ? bool(false) : !!(lua_toboolean(InScriptContext, 4));
#if UE_GAME
	USplineComponent * This = (USplineComponent *)Obj;
	Params.ReturnValue = This->GetUpVectorAtTime(Params.Time,Params.CoordinateSpace,Params.bUseConstantVelocity);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetUpVectorAtTime"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(float*)(params.GetStructMemory() + 0) = Params.Time;
		*(TEnumAsByte<ESplineCoordinateSpace::Type>*)(params.GetStructMemory() + 4) = Params.CoordinateSpace;
		*(bool*)(params.GetStructMemory() + 5) = Params.bUseConstantVelocity;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.Time = *(float*)(params.GetStructMemory() + 0);
		Params.CoordinateSpace = *(TEnumAsByte<ESplineCoordinateSpace::Type>*)(params.GetStructMemory() + 4);
		Params.bUseConstantVelocity = *(bool*)(params.GetStructMemory() + 5);
		Params.ReturnValue = *(FVector*)(params.GetStructMemory() + 8);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaVector::Return(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetUpVectorAtSplinePoint(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SplineComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SplineComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		int32 PointIndex;
		TEnumAsByte<ESplineCoordinateSpace::Type> CoordinateSpace;
		FVector ReturnValue;
	} Params;
	Params.PointIndex = (luaL_checkint(InScriptContext, 2));
	Params.CoordinateSpace = (TEnumAsByte<ESplineCoordinateSpace::Type>)(luaL_checkint(InScriptContext, 3));
#if UE_GAME
	USplineComponent * This = (USplineComponent *)Obj;
	Params.ReturnValue = This->GetUpVectorAtSplinePoint(Params.PointIndex,Params.CoordinateSpace);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetUpVectorAtSplinePoint"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(int32*)(params.GetStructMemory() + 0) = Params.PointIndex;
		*(TEnumAsByte<ESplineCoordinateSpace::Type>*)(params.GetStructMemory() + 4) = Params.CoordinateSpace;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.PointIndex = *(int32*)(params.GetStructMemory() + 0);
		Params.CoordinateSpace = *(TEnumAsByte<ESplineCoordinateSpace::Type>*)(params.GetStructMemory() + 4);
		Params.ReturnValue = *(FVector*)(params.GetStructMemory() + 8);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaVector::Return(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetUpVectorAtDistanceAlongSplineWithSegment(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SplineComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SplineComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float Distance;
		int32 Segment;
		TEnumAsByte<ESplineCoordinateSpace::Type> CoordinateSpace;
		FVector ReturnValue;
	} Params;
	Params.Distance = (float)(luaL_checknumber(InScriptContext, 2));
	Params.Segment = (luaL_checkint(InScriptContext, 3));
	Params.CoordinateSpace = (TEnumAsByte<ESplineCoordinateSpace::Type>)(luaL_checkint(InScriptContext, 4));
#if UE_GAME
	USplineComponent * This = (USplineComponent *)Obj;
	Params.ReturnValue = This->GetUpVectorAtDistanceAlongSplineWithSegment(Params.Distance,Params.Segment,Params.CoordinateSpace);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetUpVectorAtDistanceAlongSplineWithSegment"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(float*)(params.GetStructMemory() + 0) = Params.Distance;
		*(int32*)(params.GetStructMemory() + 4) = Params.Segment;
		*(TEnumAsByte<ESplineCoordinateSpace::Type>*)(params.GetStructMemory() + 8) = Params.CoordinateSpace;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.Distance = *(float*)(params.GetStructMemory() + 0);
		Params.Segment = *(int32*)(params.GetStructMemory() + 4);
		Params.CoordinateSpace = *(TEnumAsByte<ESplineCoordinateSpace::Type>*)(params.GetStructMemory() + 8);
		Params.ReturnValue = *(FVector*)(params.GetStructMemory() + 12);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaVector::Return(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetUpVectorAtDistanceAlongSpline(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SplineComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SplineComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float Distance;
		TEnumAsByte<ESplineCoordinateSpace::Type> CoordinateSpace;
		FVector ReturnValue;
	} Params;
	Params.Distance = (float)(luaL_checknumber(InScriptContext, 2));
	Params.CoordinateSpace = (TEnumAsByte<ESplineCoordinateSpace::Type>)(luaL_checkint(InScriptContext, 3));
#if UE_GAME
	USplineComponent * This = (USplineComponent *)Obj;
	Params.ReturnValue = This->GetUpVectorAtDistanceAlongSpline(Params.Distance,Params.CoordinateSpace);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetUpVectorAtDistanceAlongSpline"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(float*)(params.GetStructMemory() + 0) = Params.Distance;
		*(TEnumAsByte<ESplineCoordinateSpace::Type>*)(params.GetStructMemory() + 4) = Params.CoordinateSpace;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.Distance = *(float*)(params.GetStructMemory() + 0);
		Params.CoordinateSpace = *(TEnumAsByte<ESplineCoordinateSpace::Type>*)(params.GetStructMemory() + 4);
		Params.ReturnValue = *(FVector*)(params.GetStructMemory() + 8);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaVector::Return(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetTransformAtTime(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SplineComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SplineComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float Time;
		TEnumAsByte<ESplineCoordinateSpace::Type> CoordinateSpace;
		bool bUseConstantVelocity;
		bool bUseScale;
		FTransform ReturnValue;
	} Params;
	Params.Time = (float)(luaL_checknumber(InScriptContext, 2));
	Params.CoordinateSpace = (TEnumAsByte<ESplineCoordinateSpace::Type>)(luaL_checkint(InScriptContext, 3));
	Params.bUseConstantVelocity = lua_isnoneornil(InScriptContext,4) ? bool(false) : !!(lua_toboolean(InScriptContext, 4));
	Params.bUseScale = lua_isnoneornil(InScriptContext,5) ? bool(false) : !!(lua_toboolean(InScriptContext, 5));
#if UE_GAME
	USplineComponent * This = (USplineComponent *)Obj;
	Params.ReturnValue = This->GetTransformAtTime(Params.Time,Params.CoordinateSpace,Params.bUseConstantVelocity,Params.bUseScale);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetTransformAtTime"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(float*)(params.GetStructMemory() + 0) = Params.Time;
		*(TEnumAsByte<ESplineCoordinateSpace::Type>*)(params.GetStructMemory() + 4) = Params.CoordinateSpace;
		*(bool*)(params.GetStructMemory() + 5) = Params.bUseConstantVelocity;
		*(bool*)(params.GetStructMemory() + 6) = Params.bUseScale;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.Time = *(float*)(params.GetStructMemory() + 0);
		Params.CoordinateSpace = *(TEnumAsByte<ESplineCoordinateSpace::Type>*)(params.GetStructMemory() + 4);
		Params.bUseConstantVelocity = *(bool*)(params.GetStructMemory() + 5);
		Params.bUseScale = *(bool*)(params.GetStructMemory() + 6);
		Params.ReturnValue = *(FTransform*)(params.GetStructMemory() + 16);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaTransform::Return(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetTransformAtSplinePoint(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SplineComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SplineComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		int32 PointIndex;
		TEnumAsByte<ESplineCoordinateSpace::Type> CoordinateSpace;
		bool bUseScale;
		FTransform ReturnValue;
	} Params;
	Params.PointIndex = (luaL_checkint(InScriptContext, 2));
	Params.CoordinateSpace = (TEnumAsByte<ESplineCoordinateSpace::Type>)(luaL_checkint(InScriptContext, 3));
	Params.bUseScale = lua_isnoneornil(InScriptContext,4) ? bool(false) : !!(lua_toboolean(InScriptContext, 4));
#if UE_GAME
	USplineComponent * This = (USplineComponent *)Obj;
	Params.ReturnValue = This->GetTransformAtSplinePoint(Params.PointIndex,Params.CoordinateSpace,Params.bUseScale);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetTransformAtSplinePoint"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(int32*)(params.GetStructMemory() + 0) = Params.PointIndex;
		*(TEnumAsByte<ESplineCoordinateSpace::Type>*)(params.GetStructMemory() + 4) = Params.CoordinateSpace;
		*(bool*)(params.GetStructMemory() + 5) = Params.bUseScale;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.PointIndex = *(int32*)(params.GetStructMemory() + 0);
		Params.CoordinateSpace = *(TEnumAsByte<ESplineCoordinateSpace::Type>*)(params.GetStructMemory() + 4);
		Params.bUseScale = *(bool*)(params.GetStructMemory() + 5);
		Params.ReturnValue = *(FTransform*)(params.GetStructMemory() + 16);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaTransform::Return(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetTransformAtDistanceAlongSpline(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SplineComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SplineComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float Distance;
		TEnumAsByte<ESplineCoordinateSpace::Type> CoordinateSpace;
		bool bUseScale;
		FTransform ReturnValue;
	} Params;
	Params.Distance = (float)(luaL_checknumber(InScriptContext, 2));
	Params.CoordinateSpace = (TEnumAsByte<ESplineCoordinateSpace::Type>)(luaL_checkint(InScriptContext, 3));
	Params.bUseScale = lua_isnoneornil(InScriptContext,4) ? bool(false) : !!(lua_toboolean(InScriptContext, 4));
#if UE_GAME
	USplineComponent * This = (USplineComponent *)Obj;
	Params.ReturnValue = This->GetTransformAtDistanceAlongSpline(Params.Distance,Params.CoordinateSpace,Params.bUseScale);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetTransformAtDistanceAlongSpline"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(float*)(params.GetStructMemory() + 0) = Params.Distance;
		*(TEnumAsByte<ESplineCoordinateSpace::Type>*)(params.GetStructMemory() + 4) = Params.CoordinateSpace;
		*(bool*)(params.GetStructMemory() + 5) = Params.bUseScale;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.Distance = *(float*)(params.GetStructMemory() + 0);
		Params.CoordinateSpace = *(TEnumAsByte<ESplineCoordinateSpace::Type>*)(params.GetStructMemory() + 4);
		Params.bUseScale = *(bool*)(params.GetStructMemory() + 5);
		Params.ReturnValue = *(FTransform*)(params.GetStructMemory() + 16);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaTransform::Return(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetTangentAtTime(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SplineComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SplineComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float Time;
		TEnumAsByte<ESplineCoordinateSpace::Type> CoordinateSpace;
		bool bUseConstantVelocity;
		FVector ReturnValue;
	} Params;
	Params.Time = (float)(luaL_checknumber(InScriptContext, 2));
	Params.CoordinateSpace = (TEnumAsByte<ESplineCoordinateSpace::Type>)(luaL_checkint(InScriptContext, 3));
	Params.bUseConstantVelocity = lua_isnoneornil(InScriptContext,4) ? bool(false) : !!(lua_toboolean(InScriptContext, 4));
#if UE_GAME
	USplineComponent * This = (USplineComponent *)Obj;
	Params.ReturnValue = This->GetTangentAtTime(Params.Time,Params.CoordinateSpace,Params.bUseConstantVelocity);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetTangentAtTime"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(float*)(params.GetStructMemory() + 0) = Params.Time;
		*(TEnumAsByte<ESplineCoordinateSpace::Type>*)(params.GetStructMemory() + 4) = Params.CoordinateSpace;
		*(bool*)(params.GetStructMemory() + 5) = Params.bUseConstantVelocity;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.Time = *(float*)(params.GetStructMemory() + 0);
		Params.CoordinateSpace = *(TEnumAsByte<ESplineCoordinateSpace::Type>*)(params.GetStructMemory() + 4);
		Params.bUseConstantVelocity = *(bool*)(params.GetStructMemory() + 5);
		Params.ReturnValue = *(FVector*)(params.GetStructMemory() + 8);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaVector::Return(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetTangentAtSplinePoint(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SplineComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SplineComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		int32 PointIndex;
		TEnumAsByte<ESplineCoordinateSpace::Type> CoordinateSpace;
		FVector ReturnValue;
	} Params;
	Params.PointIndex = (luaL_checkint(InScriptContext, 2));
	Params.CoordinateSpace = (TEnumAsByte<ESplineCoordinateSpace::Type>)(luaL_checkint(InScriptContext, 3));
#if UE_GAME
	USplineComponent * This = (USplineComponent *)Obj;
	Params.ReturnValue = This->GetTangentAtSplinePoint(Params.PointIndex,Params.CoordinateSpace);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetTangentAtSplinePoint"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(int32*)(params.GetStructMemory() + 0) = Params.PointIndex;
		*(TEnumAsByte<ESplineCoordinateSpace::Type>*)(params.GetStructMemory() + 4) = Params.CoordinateSpace;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.PointIndex = *(int32*)(params.GetStructMemory() + 0);
		Params.CoordinateSpace = *(TEnumAsByte<ESplineCoordinateSpace::Type>*)(params.GetStructMemory() + 4);
		Params.ReturnValue = *(FVector*)(params.GetStructMemory() + 8);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaVector::Return(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetTangentAtDistanceAlongSplineWithSegment(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SplineComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SplineComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float Distance;
		int32 Segment;
		TEnumAsByte<ESplineCoordinateSpace::Type> CoordinateSpace;
		FVector ReturnValue;
	} Params;
	Params.Distance = (float)(luaL_checknumber(InScriptContext, 2));
	Params.Segment = (luaL_checkint(InScriptContext, 3));
	Params.CoordinateSpace = (TEnumAsByte<ESplineCoordinateSpace::Type>)(luaL_checkint(InScriptContext, 4));
#if UE_GAME
	USplineComponent * This = (USplineComponent *)Obj;
	Params.ReturnValue = This->GetTangentAtDistanceAlongSplineWithSegment(Params.Distance,Params.Segment,Params.CoordinateSpace);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetTangentAtDistanceAlongSplineWithSegment"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(float*)(params.GetStructMemory() + 0) = Params.Distance;
		*(int32*)(params.GetStructMemory() + 4) = Params.Segment;
		*(TEnumAsByte<ESplineCoordinateSpace::Type>*)(params.GetStructMemory() + 8) = Params.CoordinateSpace;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.Distance = *(float*)(params.GetStructMemory() + 0);
		Params.Segment = *(int32*)(params.GetStructMemory() + 4);
		Params.CoordinateSpace = *(TEnumAsByte<ESplineCoordinateSpace::Type>*)(params.GetStructMemory() + 8);
		Params.ReturnValue = *(FVector*)(params.GetStructMemory() + 12);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaVector::Return(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetTangentAtDistanceAlongSpline(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SplineComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SplineComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float Distance;
		TEnumAsByte<ESplineCoordinateSpace::Type> CoordinateSpace;
		FVector ReturnValue;
	} Params;
	Params.Distance = (float)(luaL_checknumber(InScriptContext, 2));
	Params.CoordinateSpace = (TEnumAsByte<ESplineCoordinateSpace::Type>)(luaL_checkint(InScriptContext, 3));
#if UE_GAME
	USplineComponent * This = (USplineComponent *)Obj;
	Params.ReturnValue = This->GetTangentAtDistanceAlongSpline(Params.Distance,Params.CoordinateSpace);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetTangentAtDistanceAlongSpline"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(float*)(params.GetStructMemory() + 0) = Params.Distance;
		*(TEnumAsByte<ESplineCoordinateSpace::Type>*)(params.GetStructMemory() + 4) = Params.CoordinateSpace;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.Distance = *(float*)(params.GetStructMemory() + 0);
		Params.CoordinateSpace = *(TEnumAsByte<ESplineCoordinateSpace::Type>*)(params.GetStructMemory() + 4);
		Params.ReturnValue = *(FVector*)(params.GetStructMemory() + 8);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaVector::Return(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetSplinePointType(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SplineComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SplineComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		int32 PointIndex;
		TEnumAsByte<ESplinePointType::Type> ReturnValue;
	} Params;
	Params.PointIndex = (luaL_checkint(InScriptContext, 2));
#if UE_GAME
	USplineComponent * This = (USplineComponent *)Obj;
	Params.ReturnValue = This->GetSplinePointType(Params.PointIndex);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetSplinePointType"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(int32*)(params.GetStructMemory() + 0) = Params.PointIndex;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.PointIndex = *(int32*)(params.GetStructMemory() + 0);
		Params.ReturnValue = *(TEnumAsByte<ESplinePointType::Type>*)(params.GetStructMemory() + 4);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushinteger(InScriptContext, (int)Params.ReturnValue);
	return 1;
}

int32 GetSplineLength(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SplineComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SplineComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float ReturnValue;
	} Params;
#if UE_GAME
	USplineComponent * This = (USplineComponent *)Obj;
	Params.ReturnValue = This->GetSplineLength();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetSplineLength"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(float*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushnumber(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetScaleAtTime(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SplineComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SplineComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float Time;
		bool bUseConstantVelocity;
		FVector ReturnValue;
	} Params;
	Params.Time = (float)(luaL_checknumber(InScriptContext, 2));
	Params.bUseConstantVelocity = lua_isnoneornil(InScriptContext,3) ? bool(false) : !!(lua_toboolean(InScriptContext, 3));
#if UE_GAME
	USplineComponent * This = (USplineComponent *)Obj;
	Params.ReturnValue = This->GetScaleAtTime(Params.Time,Params.bUseConstantVelocity);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetScaleAtTime"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(float*)(params.GetStructMemory() + 0) = Params.Time;
		*(bool*)(params.GetStructMemory() + 4) = Params.bUseConstantVelocity;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.Time = *(float*)(params.GetStructMemory() + 0);
		Params.bUseConstantVelocity = *(bool*)(params.GetStructMemory() + 4);
		Params.ReturnValue = *(FVector*)(params.GetStructMemory() + 8);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaVector::Return(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetScaleAtSplinePoint(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SplineComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SplineComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		int32 PointIndex;
		FVector ReturnValue;
	} Params;
	Params.PointIndex = (luaL_checkint(InScriptContext, 2));
#if UE_GAME
	USplineComponent * This = (USplineComponent *)Obj;
	Params.ReturnValue = This->GetScaleAtSplinePoint(Params.PointIndex);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetScaleAtSplinePoint"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(int32*)(params.GetStructMemory() + 0) = Params.PointIndex;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.PointIndex = *(int32*)(params.GetStructMemory() + 0);
		Params.ReturnValue = *(FVector*)(params.GetStructMemory() + 4);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaVector::Return(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetScaleAtDistanceAlongSpline(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SplineComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SplineComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float Distance;
		FVector ReturnValue;
	} Params;
	Params.Distance = (float)(luaL_checknumber(InScriptContext, 2));
#if UE_GAME
	USplineComponent * This = (USplineComponent *)Obj;
	Params.ReturnValue = This->GetScaleAtDistanceAlongSpline(Params.Distance);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetScaleAtDistanceAlongSpline"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(float*)(params.GetStructMemory() + 0) = Params.Distance;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.Distance = *(float*)(params.GetStructMemory() + 0);
		Params.ReturnValue = *(FVector*)(params.GetStructMemory() + 4);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaVector::Return(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetRotationAtTime(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SplineComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SplineComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float Time;
		TEnumAsByte<ESplineCoordinateSpace::Type> CoordinateSpace;
		bool bUseConstantVelocity;
		FRotator ReturnValue;
	} Params;
	Params.Time = (float)(luaL_checknumber(InScriptContext, 2));
	Params.CoordinateSpace = (TEnumAsByte<ESplineCoordinateSpace::Type>)(luaL_checkint(InScriptContext, 3));
	Params.bUseConstantVelocity = lua_isnoneornil(InScriptContext,4) ? bool(false) : !!(lua_toboolean(InScriptContext, 4));
#if UE_GAME
	USplineComponent * This = (USplineComponent *)Obj;
	Params.ReturnValue = This->GetRotationAtTime(Params.Time,Params.CoordinateSpace,Params.bUseConstantVelocity);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetRotationAtTime"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(float*)(params.GetStructMemory() + 0) = Params.Time;
		*(TEnumAsByte<ESplineCoordinateSpace::Type>*)(params.GetStructMemory() + 4) = Params.CoordinateSpace;
		*(bool*)(params.GetStructMemory() + 5) = Params.bUseConstantVelocity;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.Time = *(float*)(params.GetStructMemory() + 0);
		Params.CoordinateSpace = *(TEnumAsByte<ESplineCoordinateSpace::Type>*)(params.GetStructMemory() + 4);
		Params.bUseConstantVelocity = *(bool*)(params.GetStructMemory() + 5);
		Params.ReturnValue = *(FRotator*)(params.GetStructMemory() + 8);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaRotator::Return(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetRotationAtSplinePoint(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SplineComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SplineComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		int32 PointIndex;
		TEnumAsByte<ESplineCoordinateSpace::Type> CoordinateSpace;
		FRotator ReturnValue;
	} Params;
	Params.PointIndex = (luaL_checkint(InScriptContext, 2));
	Params.CoordinateSpace = (TEnumAsByte<ESplineCoordinateSpace::Type>)(luaL_checkint(InScriptContext, 3));
#if UE_GAME
	USplineComponent * This = (USplineComponent *)Obj;
	Params.ReturnValue = This->GetRotationAtSplinePoint(Params.PointIndex,Params.CoordinateSpace);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetRotationAtSplinePoint"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(int32*)(params.GetStructMemory() + 0) = Params.PointIndex;
		*(TEnumAsByte<ESplineCoordinateSpace::Type>*)(params.GetStructMemory() + 4) = Params.CoordinateSpace;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.PointIndex = *(int32*)(params.GetStructMemory() + 0);
		Params.CoordinateSpace = *(TEnumAsByte<ESplineCoordinateSpace::Type>*)(params.GetStructMemory() + 4);
		Params.ReturnValue = *(FRotator*)(params.GetStructMemory() + 8);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaRotator::Return(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetRotationAtDistanceAlongSplineWithSegment(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SplineComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SplineComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float Distance;
		int32 Segment;
		TEnumAsByte<ESplineCoordinateSpace::Type> CoordinateSpace;
		FRotator ReturnValue;
	} Params;
	Params.Distance = (float)(luaL_checknumber(InScriptContext, 2));
	Params.Segment = (luaL_checkint(InScriptContext, 3));
	Params.CoordinateSpace = (TEnumAsByte<ESplineCoordinateSpace::Type>)(luaL_checkint(InScriptContext, 4));
#if UE_GAME
	USplineComponent * This = (USplineComponent *)Obj;
	Params.ReturnValue = This->GetRotationAtDistanceAlongSplineWithSegment(Params.Distance,Params.Segment,Params.CoordinateSpace);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetRotationAtDistanceAlongSplineWithSegment"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(float*)(params.GetStructMemory() + 0) = Params.Distance;
		*(int32*)(params.GetStructMemory() + 4) = Params.Segment;
		*(TEnumAsByte<ESplineCoordinateSpace::Type>*)(params.GetStructMemory() + 8) = Params.CoordinateSpace;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.Distance = *(float*)(params.GetStructMemory() + 0);
		Params.Segment = *(int32*)(params.GetStructMemory() + 4);
		Params.CoordinateSpace = *(TEnumAsByte<ESplineCoordinateSpace::Type>*)(params.GetStructMemory() + 8);
		Params.ReturnValue = *(FRotator*)(params.GetStructMemory() + 12);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaRotator::Return(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetRotationAtDistanceAlongSpline(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SplineComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SplineComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float Distance;
		TEnumAsByte<ESplineCoordinateSpace::Type> CoordinateSpace;
		FRotator ReturnValue;
	} Params;
	Params.Distance = (float)(luaL_checknumber(InScriptContext, 2));
	Params.CoordinateSpace = (TEnumAsByte<ESplineCoordinateSpace::Type>)(luaL_checkint(InScriptContext, 3));
#if UE_GAME
	USplineComponent * This = (USplineComponent *)Obj;
	Params.ReturnValue = This->GetRotationAtDistanceAlongSpline(Params.Distance,Params.CoordinateSpace);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetRotationAtDistanceAlongSpline"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(float*)(params.GetStructMemory() + 0) = Params.Distance;
		*(TEnumAsByte<ESplineCoordinateSpace::Type>*)(params.GetStructMemory() + 4) = Params.CoordinateSpace;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.Distance = *(float*)(params.GetStructMemory() + 0);
		Params.CoordinateSpace = *(TEnumAsByte<ESplineCoordinateSpace::Type>*)(params.GetStructMemory() + 4);
		Params.ReturnValue = *(FRotator*)(params.GetStructMemory() + 8);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaRotator::Return(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetRollAtTime(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SplineComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SplineComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float Time;
		TEnumAsByte<ESplineCoordinateSpace::Type> CoordinateSpace;
		bool bUseConstantVelocity;
		float ReturnValue;
	} Params;
	Params.Time = (float)(luaL_checknumber(InScriptContext, 2));
	Params.CoordinateSpace = (TEnumAsByte<ESplineCoordinateSpace::Type>)(luaL_checkint(InScriptContext, 3));
	Params.bUseConstantVelocity = lua_isnoneornil(InScriptContext,4) ? bool(false) : !!(lua_toboolean(InScriptContext, 4));
#if UE_GAME
	USplineComponent * This = (USplineComponent *)Obj;
	Params.ReturnValue = This->GetRollAtTime(Params.Time,Params.CoordinateSpace,Params.bUseConstantVelocity);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetRollAtTime"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(float*)(params.GetStructMemory() + 0) = Params.Time;
		*(TEnumAsByte<ESplineCoordinateSpace::Type>*)(params.GetStructMemory() + 4) = Params.CoordinateSpace;
		*(bool*)(params.GetStructMemory() + 5) = Params.bUseConstantVelocity;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.Time = *(float*)(params.GetStructMemory() + 0);
		Params.CoordinateSpace = *(TEnumAsByte<ESplineCoordinateSpace::Type>*)(params.GetStructMemory() + 4);
		Params.bUseConstantVelocity = *(bool*)(params.GetStructMemory() + 5);
		Params.ReturnValue = *(float*)(params.GetStructMemory() + 8);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushnumber(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetRollAtSplinePoint(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SplineComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SplineComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		int32 PointIndex;
		TEnumAsByte<ESplineCoordinateSpace::Type> CoordinateSpace;
		float ReturnValue;
	} Params;
	Params.PointIndex = (luaL_checkint(InScriptContext, 2));
	Params.CoordinateSpace = (TEnumAsByte<ESplineCoordinateSpace::Type>)(luaL_checkint(InScriptContext, 3));
#if UE_GAME
	USplineComponent * This = (USplineComponent *)Obj;
	Params.ReturnValue = This->GetRollAtSplinePoint(Params.PointIndex,Params.CoordinateSpace);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetRollAtSplinePoint"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(int32*)(params.GetStructMemory() + 0) = Params.PointIndex;
		*(TEnumAsByte<ESplineCoordinateSpace::Type>*)(params.GetStructMemory() + 4) = Params.CoordinateSpace;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.PointIndex = *(int32*)(params.GetStructMemory() + 0);
		Params.CoordinateSpace = *(TEnumAsByte<ESplineCoordinateSpace::Type>*)(params.GetStructMemory() + 4);
		Params.ReturnValue = *(float*)(params.GetStructMemory() + 8);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushnumber(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetRollAtDistanceAlongSpline(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SplineComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SplineComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float Distance;
		TEnumAsByte<ESplineCoordinateSpace::Type> CoordinateSpace;
		float ReturnValue;
	} Params;
	Params.Distance = (float)(luaL_checknumber(InScriptContext, 2));
	Params.CoordinateSpace = (TEnumAsByte<ESplineCoordinateSpace::Type>)(luaL_checkint(InScriptContext, 3));
#if UE_GAME
	USplineComponent * This = (USplineComponent *)Obj;
	Params.ReturnValue = This->GetRollAtDistanceAlongSpline(Params.Distance,Params.CoordinateSpace);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetRollAtDistanceAlongSpline"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(float*)(params.GetStructMemory() + 0) = Params.Distance;
		*(TEnumAsByte<ESplineCoordinateSpace::Type>*)(params.GetStructMemory() + 4) = Params.CoordinateSpace;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.Distance = *(float*)(params.GetStructMemory() + 0);
		Params.CoordinateSpace = *(TEnumAsByte<ESplineCoordinateSpace::Type>*)(params.GetStructMemory() + 4);
		Params.ReturnValue = *(float*)(params.GetStructMemory() + 8);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushnumber(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetRightVectorAtTime(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SplineComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SplineComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float Time;
		TEnumAsByte<ESplineCoordinateSpace::Type> CoordinateSpace;
		bool bUseConstantVelocity;
		FVector ReturnValue;
	} Params;
	Params.Time = (float)(luaL_checknumber(InScriptContext, 2));
	Params.CoordinateSpace = (TEnumAsByte<ESplineCoordinateSpace::Type>)(luaL_checkint(InScriptContext, 3));
	Params.bUseConstantVelocity = lua_isnoneornil(InScriptContext,4) ? bool(false) : !!(lua_toboolean(InScriptContext, 4));
#if UE_GAME
	USplineComponent * This = (USplineComponent *)Obj;
	Params.ReturnValue = This->GetRightVectorAtTime(Params.Time,Params.CoordinateSpace,Params.bUseConstantVelocity);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetRightVectorAtTime"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(float*)(params.GetStructMemory() + 0) = Params.Time;
		*(TEnumAsByte<ESplineCoordinateSpace::Type>*)(params.GetStructMemory() + 4) = Params.CoordinateSpace;
		*(bool*)(params.GetStructMemory() + 5) = Params.bUseConstantVelocity;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.Time = *(float*)(params.GetStructMemory() + 0);
		Params.CoordinateSpace = *(TEnumAsByte<ESplineCoordinateSpace::Type>*)(params.GetStructMemory() + 4);
		Params.bUseConstantVelocity = *(bool*)(params.GetStructMemory() + 5);
		Params.ReturnValue = *(FVector*)(params.GetStructMemory() + 8);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaVector::Return(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetRightVectorAtSplinePoint(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SplineComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SplineComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		int32 PointIndex;
		TEnumAsByte<ESplineCoordinateSpace::Type> CoordinateSpace;
		FVector ReturnValue;
	} Params;
	Params.PointIndex = (luaL_checkint(InScriptContext, 2));
	Params.CoordinateSpace = (TEnumAsByte<ESplineCoordinateSpace::Type>)(luaL_checkint(InScriptContext, 3));
#if UE_GAME
	USplineComponent * This = (USplineComponent *)Obj;
	Params.ReturnValue = This->GetRightVectorAtSplinePoint(Params.PointIndex,Params.CoordinateSpace);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetRightVectorAtSplinePoint"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(int32*)(params.GetStructMemory() + 0) = Params.PointIndex;
		*(TEnumAsByte<ESplineCoordinateSpace::Type>*)(params.GetStructMemory() + 4) = Params.CoordinateSpace;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.PointIndex = *(int32*)(params.GetStructMemory() + 0);
		Params.CoordinateSpace = *(TEnumAsByte<ESplineCoordinateSpace::Type>*)(params.GetStructMemory() + 4);
		Params.ReturnValue = *(FVector*)(params.GetStructMemory() + 8);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaVector::Return(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetRightVectorAtDistanceAlongSpline(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SplineComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SplineComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float Distance;
		TEnumAsByte<ESplineCoordinateSpace::Type> CoordinateSpace;
		FVector ReturnValue;
	} Params;
	Params.Distance = (float)(luaL_checknumber(InScriptContext, 2));
	Params.CoordinateSpace = (TEnumAsByte<ESplineCoordinateSpace::Type>)(luaL_checkint(InScriptContext, 3));
#if UE_GAME
	USplineComponent * This = (USplineComponent *)Obj;
	Params.ReturnValue = This->GetRightVectorAtDistanceAlongSpline(Params.Distance,Params.CoordinateSpace);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetRightVectorAtDistanceAlongSpline"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(float*)(params.GetStructMemory() + 0) = Params.Distance;
		*(TEnumAsByte<ESplineCoordinateSpace::Type>*)(params.GetStructMemory() + 4) = Params.CoordinateSpace;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.Distance = *(float*)(params.GetStructMemory() + 0);
		Params.CoordinateSpace = *(TEnumAsByte<ESplineCoordinateSpace::Type>*)(params.GetStructMemory() + 4);
		Params.ReturnValue = *(FVector*)(params.GetStructMemory() + 8);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaVector::Return(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetPointIndexAtDistance(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SplineComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SplineComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float Distance;
		int32 ReturnValue;
	} Params;
	Params.Distance = (float)(luaL_checknumber(InScriptContext, 2));
#if UE_GAME
	USplineComponent * This = (USplineComponent *)Obj;
	Params.ReturnValue = This->GetPointIndexAtDistance(Params.Distance);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetPointIndexAtDistance"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(float*)(params.GetStructMemory() + 0) = Params.Distance;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.Distance = *(float*)(params.GetStructMemory() + 0);
		Params.ReturnValue = *(int32*)(params.GetStructMemory() + 4);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushinteger(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetNumberOfSplinePoints(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SplineComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SplineComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		int32 ReturnValue;
	} Params;
#if UE_GAME
	USplineComponent * This = (USplineComponent *)Obj;
	Params.ReturnValue = This->GetNumberOfSplinePoints();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetNumberOfSplinePoints"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(int32*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushinteger(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetLocationAtTime(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SplineComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SplineComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float Time;
		TEnumAsByte<ESplineCoordinateSpace::Type> CoordinateSpace;
		bool bUseConstantVelocity;
		FVector ReturnValue;
	} Params;
	Params.Time = (float)(luaL_checknumber(InScriptContext, 2));
	Params.CoordinateSpace = (TEnumAsByte<ESplineCoordinateSpace::Type>)(luaL_checkint(InScriptContext, 3));
	Params.bUseConstantVelocity = lua_isnoneornil(InScriptContext,4) ? bool(false) : !!(lua_toboolean(InScriptContext, 4));
#if UE_GAME
	USplineComponent * This = (USplineComponent *)Obj;
	Params.ReturnValue = This->GetLocationAtTime(Params.Time,Params.CoordinateSpace,Params.bUseConstantVelocity);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetLocationAtTime"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(float*)(params.GetStructMemory() + 0) = Params.Time;
		*(TEnumAsByte<ESplineCoordinateSpace::Type>*)(params.GetStructMemory() + 4) = Params.CoordinateSpace;
		*(bool*)(params.GetStructMemory() + 5) = Params.bUseConstantVelocity;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.Time = *(float*)(params.GetStructMemory() + 0);
		Params.CoordinateSpace = *(TEnumAsByte<ESplineCoordinateSpace::Type>*)(params.GetStructMemory() + 4);
		Params.bUseConstantVelocity = *(bool*)(params.GetStructMemory() + 5);
		Params.ReturnValue = *(FVector*)(params.GetStructMemory() + 8);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaVector::Return(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetLocationAtSplinePoint(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SplineComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SplineComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		int32 PointIndex;
		TEnumAsByte<ESplineCoordinateSpace::Type> CoordinateSpace;
		FVector ReturnValue;
	} Params;
	Params.PointIndex = (luaL_checkint(InScriptContext, 2));
	Params.CoordinateSpace = (TEnumAsByte<ESplineCoordinateSpace::Type>)(luaL_checkint(InScriptContext, 3));
#if UE_GAME
	USplineComponent * This = (USplineComponent *)Obj;
	Params.ReturnValue = This->GetLocationAtSplinePoint(Params.PointIndex,Params.CoordinateSpace);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetLocationAtSplinePoint"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(int32*)(params.GetStructMemory() + 0) = Params.PointIndex;
		*(TEnumAsByte<ESplineCoordinateSpace::Type>*)(params.GetStructMemory() + 4) = Params.CoordinateSpace;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.PointIndex = *(int32*)(params.GetStructMemory() + 0);
		Params.CoordinateSpace = *(TEnumAsByte<ESplineCoordinateSpace::Type>*)(params.GetStructMemory() + 4);
		Params.ReturnValue = *(FVector*)(params.GetStructMemory() + 8);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaVector::Return(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetLocationAtDistanceAlongSplineWithSegment(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SplineComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SplineComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float Distance;
		int32 Segment;
		TEnumAsByte<ESplineCoordinateSpace::Type> CoordinateSpace;
		FVector ReturnValue;
	} Params;
	Params.Distance = (float)(luaL_checknumber(InScriptContext, 2));
	Params.Segment = (luaL_checkint(InScriptContext, 3));
	Params.CoordinateSpace = (TEnumAsByte<ESplineCoordinateSpace::Type>)(luaL_checkint(InScriptContext, 4));
#if UE_GAME
	USplineComponent * This = (USplineComponent *)Obj;
	Params.ReturnValue = This->GetLocationAtDistanceAlongSplineWithSegment(Params.Distance,Params.Segment,Params.CoordinateSpace);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetLocationAtDistanceAlongSplineWithSegment"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(float*)(params.GetStructMemory() + 0) = Params.Distance;
		*(int32*)(params.GetStructMemory() + 4) = Params.Segment;
		*(TEnumAsByte<ESplineCoordinateSpace::Type>*)(params.GetStructMemory() + 8) = Params.CoordinateSpace;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.Distance = *(float*)(params.GetStructMemory() + 0);
		Params.Segment = *(int32*)(params.GetStructMemory() + 4);
		Params.CoordinateSpace = *(TEnumAsByte<ESplineCoordinateSpace::Type>*)(params.GetStructMemory() + 8);
		Params.ReturnValue = *(FVector*)(params.GetStructMemory() + 12);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaVector::Return(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetLocationAtDistanceAlongSpline(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SplineComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SplineComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float Distance;
		TEnumAsByte<ESplineCoordinateSpace::Type> CoordinateSpace;
		FVector ReturnValue;
	} Params;
	Params.Distance = (float)(luaL_checknumber(InScriptContext, 2));
	Params.CoordinateSpace = (TEnumAsByte<ESplineCoordinateSpace::Type>)(luaL_checkint(InScriptContext, 3));
#if UE_GAME
	USplineComponent * This = (USplineComponent *)Obj;
	Params.ReturnValue = This->GetLocationAtDistanceAlongSpline(Params.Distance,Params.CoordinateSpace);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetLocationAtDistanceAlongSpline"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(float*)(params.GetStructMemory() + 0) = Params.Distance;
		*(TEnumAsByte<ESplineCoordinateSpace::Type>*)(params.GetStructMemory() + 4) = Params.CoordinateSpace;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.Distance = *(float*)(params.GetStructMemory() + 0);
		Params.CoordinateSpace = *(TEnumAsByte<ESplineCoordinateSpace::Type>*)(params.GetStructMemory() + 4);
		Params.ReturnValue = *(FVector*)(params.GetStructMemory() + 8);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaVector::Return(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetLocationAndTangentAtSplinePoint(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SplineComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SplineComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		int32 PointIndex;
		FVector Location;
		FVector Tangent;
		TEnumAsByte<ESplineCoordinateSpace::Type> CoordinateSpace;
	} Params;
	Params.PointIndex = (luaL_checkint(InScriptContext, 2));
	Params.CoordinateSpace = (TEnumAsByte<ESplineCoordinateSpace::Type>)(luaL_checkint(InScriptContext, 5));
#if UE_GAME
	USplineComponent * This = (USplineComponent *)Obj;
	This->GetLocationAndTangentAtSplinePoint(Params.PointIndex,Params.Location,Params.Tangent,Params.CoordinateSpace);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetLocationAndTangentAtSplinePoint"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(int32*)(params.GetStructMemory() + 0) = Params.PointIndex;
		*(TEnumAsByte<ESplineCoordinateSpace::Type>*)(params.GetStructMemory() + 28) = Params.CoordinateSpace;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.PointIndex = *(int32*)(params.GetStructMemory() + 0);
		Params.Location = *(FVector*)(params.GetStructMemory() + 4);
		Params.Tangent = *(FVector*)(params.GetStructMemory() + 16);
		Params.CoordinateSpace = *(TEnumAsByte<ESplineCoordinateSpace::Type>*)(params.GetStructMemory() + 28);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaVector::Return(InScriptContext, Params.Location);
	wLua::FLuaVector::Return(InScriptContext, Params.Tangent);
	return 2;
}

int32 GetLeaveTangentAtSplinePoint(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SplineComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SplineComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		int32 PointIndex;
		TEnumAsByte<ESplineCoordinateSpace::Type> CoordinateSpace;
		FVector ReturnValue;
	} Params;
	Params.PointIndex = (luaL_checkint(InScriptContext, 2));
	Params.CoordinateSpace = (TEnumAsByte<ESplineCoordinateSpace::Type>)(luaL_checkint(InScriptContext, 3));
#if UE_GAME
	USplineComponent * This = (USplineComponent *)Obj;
	Params.ReturnValue = This->GetLeaveTangentAtSplinePoint(Params.PointIndex,Params.CoordinateSpace);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetLeaveTangentAtSplinePoint"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(int32*)(params.GetStructMemory() + 0) = Params.PointIndex;
		*(TEnumAsByte<ESplineCoordinateSpace::Type>*)(params.GetStructMemory() + 4) = Params.CoordinateSpace;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.PointIndex = *(int32*)(params.GetStructMemory() + 0);
		Params.CoordinateSpace = *(TEnumAsByte<ESplineCoordinateSpace::Type>*)(params.GetStructMemory() + 4);
		Params.ReturnValue = *(FVector*)(params.GetStructMemory() + 8);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaVector::Return(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetInputKeyAtDistanceAlongSpline(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SplineComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SplineComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float Distance;
		float ReturnValue;
	} Params;
	Params.Distance = (float)(luaL_checknumber(InScriptContext, 2));
#if UE_GAME
	USplineComponent * This = (USplineComponent *)Obj;
	Params.ReturnValue = This->GetInputKeyAtDistanceAlongSpline(Params.Distance);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetInputKeyAtDistanceAlongSpline"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(float*)(params.GetStructMemory() + 0) = Params.Distance;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.Distance = *(float*)(params.GetStructMemory() + 0);
		Params.ReturnValue = *(float*)(params.GetStructMemory() + 4);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushnumber(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetDistanceAlongSplineAtSplinePoint(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SplineComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SplineComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		int32 PointIndex;
		float ReturnValue;
	} Params;
	Params.PointIndex = (luaL_checkint(InScriptContext, 2));
#if UE_GAME
	USplineComponent * This = (USplineComponent *)Obj;
	Params.ReturnValue = This->GetDistanceAlongSplineAtSplinePoint(Params.PointIndex);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetDistanceAlongSplineAtSplinePoint"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(int32*)(params.GetStructMemory() + 0) = Params.PointIndex;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.PointIndex = *(int32*)(params.GetStructMemory() + 0);
		Params.ReturnValue = *(float*)(params.GetStructMemory() + 4);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushnumber(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetDirectionAtTime(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SplineComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SplineComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float Time;
		TEnumAsByte<ESplineCoordinateSpace::Type> CoordinateSpace;
		bool bUseConstantVelocity;
		FVector ReturnValue;
	} Params;
	Params.Time = (float)(luaL_checknumber(InScriptContext, 2));
	Params.CoordinateSpace = (TEnumAsByte<ESplineCoordinateSpace::Type>)(luaL_checkint(InScriptContext, 3));
	Params.bUseConstantVelocity = lua_isnoneornil(InScriptContext,4) ? bool(false) : !!(lua_toboolean(InScriptContext, 4));
#if UE_GAME
	USplineComponent * This = (USplineComponent *)Obj;
	Params.ReturnValue = This->GetDirectionAtTime(Params.Time,Params.CoordinateSpace,Params.bUseConstantVelocity);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetDirectionAtTime"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(float*)(params.GetStructMemory() + 0) = Params.Time;
		*(TEnumAsByte<ESplineCoordinateSpace::Type>*)(params.GetStructMemory() + 4) = Params.CoordinateSpace;
		*(bool*)(params.GetStructMemory() + 5) = Params.bUseConstantVelocity;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.Time = *(float*)(params.GetStructMemory() + 0);
		Params.CoordinateSpace = *(TEnumAsByte<ESplineCoordinateSpace::Type>*)(params.GetStructMemory() + 4);
		Params.bUseConstantVelocity = *(bool*)(params.GetStructMemory() + 5);
		Params.ReturnValue = *(FVector*)(params.GetStructMemory() + 8);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaVector::Return(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetDirectionAtSplinePoint(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SplineComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SplineComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		int32 PointIndex;
		TEnumAsByte<ESplineCoordinateSpace::Type> CoordinateSpace;
		FVector ReturnValue;
	} Params;
	Params.PointIndex = (luaL_checkint(InScriptContext, 2));
	Params.CoordinateSpace = (TEnumAsByte<ESplineCoordinateSpace::Type>)(luaL_checkint(InScriptContext, 3));
#if UE_GAME
	USplineComponent * This = (USplineComponent *)Obj;
	Params.ReturnValue = This->GetDirectionAtSplinePoint(Params.PointIndex,Params.CoordinateSpace);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetDirectionAtSplinePoint"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(int32*)(params.GetStructMemory() + 0) = Params.PointIndex;
		*(TEnumAsByte<ESplineCoordinateSpace::Type>*)(params.GetStructMemory() + 4) = Params.CoordinateSpace;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.PointIndex = *(int32*)(params.GetStructMemory() + 0);
		Params.CoordinateSpace = *(TEnumAsByte<ESplineCoordinateSpace::Type>*)(params.GetStructMemory() + 4);
		Params.ReturnValue = *(FVector*)(params.GetStructMemory() + 8);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaVector::Return(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetDirectionAtDistanceAlongSplineWithSegment(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SplineComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SplineComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float Distance;
		int32 Segment;
		TEnumAsByte<ESplineCoordinateSpace::Type> CoordinateSpace;
		FVector ReturnValue;
	} Params;
	Params.Distance = (float)(luaL_checknumber(InScriptContext, 2));
	Params.Segment = (luaL_checkint(InScriptContext, 3));
	Params.CoordinateSpace = (TEnumAsByte<ESplineCoordinateSpace::Type>)(luaL_checkint(InScriptContext, 4));
#if UE_GAME
	USplineComponent * This = (USplineComponent *)Obj;
	Params.ReturnValue = This->GetDirectionAtDistanceAlongSplineWithSegment(Params.Distance,Params.Segment,Params.CoordinateSpace);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetDirectionAtDistanceAlongSplineWithSegment"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(float*)(params.GetStructMemory() + 0) = Params.Distance;
		*(int32*)(params.GetStructMemory() + 4) = Params.Segment;
		*(TEnumAsByte<ESplineCoordinateSpace::Type>*)(params.GetStructMemory() + 8) = Params.CoordinateSpace;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.Distance = *(float*)(params.GetStructMemory() + 0);
		Params.Segment = *(int32*)(params.GetStructMemory() + 4);
		Params.CoordinateSpace = *(TEnumAsByte<ESplineCoordinateSpace::Type>*)(params.GetStructMemory() + 8);
		Params.ReturnValue = *(FVector*)(params.GetStructMemory() + 12);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaVector::Return(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetDirectionAtDistanceAlongSpline(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SplineComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SplineComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float Distance;
		TEnumAsByte<ESplineCoordinateSpace::Type> CoordinateSpace;
		FVector ReturnValue;
	} Params;
	Params.Distance = (float)(luaL_checknumber(InScriptContext, 2));
	Params.CoordinateSpace = (TEnumAsByte<ESplineCoordinateSpace::Type>)(luaL_checkint(InScriptContext, 3));
#if UE_GAME
	USplineComponent * This = (USplineComponent *)Obj;
	Params.ReturnValue = This->GetDirectionAtDistanceAlongSpline(Params.Distance,Params.CoordinateSpace);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetDirectionAtDistanceAlongSpline"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(float*)(params.GetStructMemory() + 0) = Params.Distance;
		*(TEnumAsByte<ESplineCoordinateSpace::Type>*)(params.GetStructMemory() + 4) = Params.CoordinateSpace;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.Distance = *(float*)(params.GetStructMemory() + 0);
		Params.CoordinateSpace = *(TEnumAsByte<ESplineCoordinateSpace::Type>*)(params.GetStructMemory() + 4);
		Params.ReturnValue = *(FVector*)(params.GetStructMemory() + 8);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaVector::Return(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetDefaultUpVector(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SplineComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SplineComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		TEnumAsByte<ESplineCoordinateSpace::Type> CoordinateSpace;
		FVector ReturnValue;
	} Params;
	Params.CoordinateSpace = (TEnumAsByte<ESplineCoordinateSpace::Type>)(luaL_checkint(InScriptContext, 2));
#if UE_GAME
	USplineComponent * This = (USplineComponent *)Obj;
	Params.ReturnValue = This->GetDefaultUpVector(Params.CoordinateSpace);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetDefaultUpVector"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(TEnumAsByte<ESplineCoordinateSpace::Type>*)(params.GetStructMemory() + 0) = Params.CoordinateSpace;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.CoordinateSpace = *(TEnumAsByte<ESplineCoordinateSpace::Type>*)(params.GetStructMemory() + 0);
		Params.ReturnValue = *(FVector*)(params.GetStructMemory() + 4);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaVector::Return(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetArriveTangentAtSplinePoint(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SplineComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SplineComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		int32 PointIndex;
		TEnumAsByte<ESplineCoordinateSpace::Type> CoordinateSpace;
		FVector ReturnValue;
	} Params;
	Params.PointIndex = (luaL_checkint(InScriptContext, 2));
	Params.CoordinateSpace = (TEnumAsByte<ESplineCoordinateSpace::Type>)(luaL_checkint(InScriptContext, 3));
#if UE_GAME
	USplineComponent * This = (USplineComponent *)Obj;
	Params.ReturnValue = This->GetArriveTangentAtSplinePoint(Params.PointIndex,Params.CoordinateSpace);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetArriveTangentAtSplinePoint"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(int32*)(params.GetStructMemory() + 0) = Params.PointIndex;
		*(TEnumAsByte<ESplineCoordinateSpace::Type>*)(params.GetStructMemory() + 4) = Params.CoordinateSpace;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.PointIndex = *(int32*)(params.GetStructMemory() + 0);
		Params.CoordinateSpace = *(TEnumAsByte<ESplineCoordinateSpace::Type>*)(params.GetStructMemory() + 4);
		Params.ReturnValue = *(FVector*)(params.GetStructMemory() + 8);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaVector::Return(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 FindUpVectorClosestToWorldLocation(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SplineComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SplineComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FVector WorldLocation;
		TEnumAsByte<ESplineCoordinateSpace::Type> CoordinateSpace;
		FVector ReturnValue;
	} Params;
	Params.WorldLocation = (wLua::FLuaVector::Get(InScriptContext, 2));
	Params.CoordinateSpace = (TEnumAsByte<ESplineCoordinateSpace::Type>)(luaL_checkint(InScriptContext, 3));
#if UE_GAME
	USplineComponent * This = (USplineComponent *)Obj;
	Params.ReturnValue = This->FindUpVectorClosestToWorldLocation(Params.WorldLocation,Params.CoordinateSpace);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("FindUpVectorClosestToWorldLocation"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FVector*)(params.GetStructMemory() + 0) = Params.WorldLocation;
		*(TEnumAsByte<ESplineCoordinateSpace::Type>*)(params.GetStructMemory() + 12) = Params.CoordinateSpace;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.WorldLocation = *(FVector*)(params.GetStructMemory() + 0);
		Params.CoordinateSpace = *(TEnumAsByte<ESplineCoordinateSpace::Type>*)(params.GetStructMemory() + 12);
		Params.ReturnValue = *(FVector*)(params.GetStructMemory() + 16);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaVector::Return(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 FindTransformClosestToWorldLocation(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SplineComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SplineComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FVector WorldLocation;
		TEnumAsByte<ESplineCoordinateSpace::Type> CoordinateSpace;
		bool bUseScale;
		FTransform ReturnValue;
	} Params;
	Params.WorldLocation = (wLua::FLuaVector::Get(InScriptContext, 2));
	Params.CoordinateSpace = (TEnumAsByte<ESplineCoordinateSpace::Type>)(luaL_checkint(InScriptContext, 3));
	Params.bUseScale = lua_isnoneornil(InScriptContext,4) ? bool(false) : !!(lua_toboolean(InScriptContext, 4));
#if UE_GAME
	USplineComponent * This = (USplineComponent *)Obj;
	Params.ReturnValue = This->FindTransformClosestToWorldLocation(Params.WorldLocation,Params.CoordinateSpace,Params.bUseScale);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("FindTransformClosestToWorldLocation"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FVector*)(params.GetStructMemory() + 0) = Params.WorldLocation;
		*(TEnumAsByte<ESplineCoordinateSpace::Type>*)(params.GetStructMemory() + 12) = Params.CoordinateSpace;
		*(bool*)(params.GetStructMemory() + 13) = Params.bUseScale;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.WorldLocation = *(FVector*)(params.GetStructMemory() + 0);
		Params.CoordinateSpace = *(TEnumAsByte<ESplineCoordinateSpace::Type>*)(params.GetStructMemory() + 12);
		Params.bUseScale = *(bool*)(params.GetStructMemory() + 13);
		Params.ReturnValue = *(FTransform*)(params.GetStructMemory() + 16);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaTransform::Return(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 FindTangentClosestToWorldLocation(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SplineComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SplineComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FVector WorldLocation;
		TEnumAsByte<ESplineCoordinateSpace::Type> CoordinateSpace;
		FVector ReturnValue;
	} Params;
	Params.WorldLocation = (wLua::FLuaVector::Get(InScriptContext, 2));
	Params.CoordinateSpace = (TEnumAsByte<ESplineCoordinateSpace::Type>)(luaL_checkint(InScriptContext, 3));
#if UE_GAME
	USplineComponent * This = (USplineComponent *)Obj;
	Params.ReturnValue = This->FindTangentClosestToWorldLocation(Params.WorldLocation,Params.CoordinateSpace);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("FindTangentClosestToWorldLocation"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FVector*)(params.GetStructMemory() + 0) = Params.WorldLocation;
		*(TEnumAsByte<ESplineCoordinateSpace::Type>*)(params.GetStructMemory() + 12) = Params.CoordinateSpace;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.WorldLocation = *(FVector*)(params.GetStructMemory() + 0);
		Params.CoordinateSpace = *(TEnumAsByte<ESplineCoordinateSpace::Type>*)(params.GetStructMemory() + 12);
		Params.ReturnValue = *(FVector*)(params.GetStructMemory() + 16);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaVector::Return(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 FindScaleClosestToWorldLocation(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SplineComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SplineComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FVector WorldLocation;
		FVector ReturnValue;
	} Params;
	Params.WorldLocation = (wLua::FLuaVector::Get(InScriptContext, 2));
#if UE_GAME
	USplineComponent * This = (USplineComponent *)Obj;
	Params.ReturnValue = This->FindScaleClosestToWorldLocation(Params.WorldLocation);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("FindScaleClosestToWorldLocation"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FVector*)(params.GetStructMemory() + 0) = Params.WorldLocation;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.WorldLocation = *(FVector*)(params.GetStructMemory() + 0);
		Params.ReturnValue = *(FVector*)(params.GetStructMemory() + 12);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaVector::Return(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 FindRotationClosestToWorldLocation(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SplineComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SplineComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FVector WorldLocation;
		TEnumAsByte<ESplineCoordinateSpace::Type> CoordinateSpace;
		FRotator ReturnValue;
	} Params;
	Params.WorldLocation = (wLua::FLuaVector::Get(InScriptContext, 2));
	Params.CoordinateSpace = (TEnumAsByte<ESplineCoordinateSpace::Type>)(luaL_checkint(InScriptContext, 3));
#if UE_GAME
	USplineComponent * This = (USplineComponent *)Obj;
	Params.ReturnValue = This->FindRotationClosestToWorldLocation(Params.WorldLocation,Params.CoordinateSpace);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("FindRotationClosestToWorldLocation"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FVector*)(params.GetStructMemory() + 0) = Params.WorldLocation;
		*(TEnumAsByte<ESplineCoordinateSpace::Type>*)(params.GetStructMemory() + 12) = Params.CoordinateSpace;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.WorldLocation = *(FVector*)(params.GetStructMemory() + 0);
		Params.CoordinateSpace = *(TEnumAsByte<ESplineCoordinateSpace::Type>*)(params.GetStructMemory() + 12);
		Params.ReturnValue = *(FRotator*)(params.GetStructMemory() + 16);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaRotator::Return(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 FindRollClosestToWorldLocation(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SplineComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SplineComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FVector WorldLocation;
		TEnumAsByte<ESplineCoordinateSpace::Type> CoordinateSpace;
		float ReturnValue;
	} Params;
	Params.WorldLocation = (wLua::FLuaVector::Get(InScriptContext, 2));
	Params.CoordinateSpace = (TEnumAsByte<ESplineCoordinateSpace::Type>)(luaL_checkint(InScriptContext, 3));
#if UE_GAME
	USplineComponent * This = (USplineComponent *)Obj;
	Params.ReturnValue = This->FindRollClosestToWorldLocation(Params.WorldLocation,Params.CoordinateSpace);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("FindRollClosestToWorldLocation"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FVector*)(params.GetStructMemory() + 0) = Params.WorldLocation;
		*(TEnumAsByte<ESplineCoordinateSpace::Type>*)(params.GetStructMemory() + 12) = Params.CoordinateSpace;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.WorldLocation = *(FVector*)(params.GetStructMemory() + 0);
		Params.CoordinateSpace = *(TEnumAsByte<ESplineCoordinateSpace::Type>*)(params.GetStructMemory() + 12);
		Params.ReturnValue = *(float*)(params.GetStructMemory() + 16);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushnumber(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 FindRightVectorClosestToWorldLocation(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SplineComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SplineComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FVector WorldLocation;
		TEnumAsByte<ESplineCoordinateSpace::Type> CoordinateSpace;
		FVector ReturnValue;
	} Params;
	Params.WorldLocation = (wLua::FLuaVector::Get(InScriptContext, 2));
	Params.CoordinateSpace = (TEnumAsByte<ESplineCoordinateSpace::Type>)(luaL_checkint(InScriptContext, 3));
#if UE_GAME
	USplineComponent * This = (USplineComponent *)Obj;
	Params.ReturnValue = This->FindRightVectorClosestToWorldLocation(Params.WorldLocation,Params.CoordinateSpace);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("FindRightVectorClosestToWorldLocation"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FVector*)(params.GetStructMemory() + 0) = Params.WorldLocation;
		*(TEnumAsByte<ESplineCoordinateSpace::Type>*)(params.GetStructMemory() + 12) = Params.CoordinateSpace;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.WorldLocation = *(FVector*)(params.GetStructMemory() + 0);
		Params.CoordinateSpace = *(TEnumAsByte<ESplineCoordinateSpace::Type>*)(params.GetStructMemory() + 12);
		Params.ReturnValue = *(FVector*)(params.GetStructMemory() + 16);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaVector::Return(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 FindLocationClosestToWorldLocationWithSegment(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SplineComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SplineComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FVector WorldLocation;
		TEnumAsByte<ESplineCoordinateSpace::Type> CoordinateSpace;
		int32 segment;
		FVector ReturnValue;
	} Params;
	Params.WorldLocation = (wLua::FLuaVector::Get(InScriptContext, 2));
	Params.CoordinateSpace = (TEnumAsByte<ESplineCoordinateSpace::Type>)(luaL_checkint(InScriptContext, 3));
#if UE_GAME
	USplineComponent * This = (USplineComponent *)Obj;
	Params.ReturnValue = This->FindLocationClosestToWorldLocationWithSegment(Params.WorldLocation,Params.CoordinateSpace,Params.segment);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("FindLocationClosestToWorldLocationWithSegment"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FVector*)(params.GetStructMemory() + 0) = Params.WorldLocation;
		*(TEnumAsByte<ESplineCoordinateSpace::Type>*)(params.GetStructMemory() + 12) = Params.CoordinateSpace;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.WorldLocation = *(FVector*)(params.GetStructMemory() + 0);
		Params.CoordinateSpace = *(TEnumAsByte<ESplineCoordinateSpace::Type>*)(params.GetStructMemory() + 12);
		Params.segment = *(int32*)(params.GetStructMemory() + 16);
		Params.ReturnValue = *(FVector*)(params.GetStructMemory() + 20);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaVector::Return(InScriptContext, Params.ReturnValue);
	lua_pushinteger(InScriptContext, Params.segment);
	return 2;
}

int32 FindLocationClosestToWorldLocation(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SplineComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SplineComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FVector WorldLocation;
		TEnumAsByte<ESplineCoordinateSpace::Type> CoordinateSpace;
		FVector ReturnValue;
	} Params;
	Params.WorldLocation = (wLua::FLuaVector::Get(InScriptContext, 2));
	Params.CoordinateSpace = (TEnumAsByte<ESplineCoordinateSpace::Type>)(luaL_checkint(InScriptContext, 3));
#if UE_GAME
	USplineComponent * This = (USplineComponent *)Obj;
	Params.ReturnValue = This->FindLocationClosestToWorldLocation(Params.WorldLocation,Params.CoordinateSpace);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("FindLocationClosestToWorldLocation"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FVector*)(params.GetStructMemory() + 0) = Params.WorldLocation;
		*(TEnumAsByte<ESplineCoordinateSpace::Type>*)(params.GetStructMemory() + 12) = Params.CoordinateSpace;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.WorldLocation = *(FVector*)(params.GetStructMemory() + 0);
		Params.CoordinateSpace = *(TEnumAsByte<ESplineCoordinateSpace::Type>*)(params.GetStructMemory() + 12);
		Params.ReturnValue = *(FVector*)(params.GetStructMemory() + 16);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaVector::Return(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 FindInputKeyClosestToWorldLocationWithSegment(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SplineComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SplineComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FVector WorldLocation;
		int32 segment;
		float ReturnValue;
	} Params;
	Params.WorldLocation = (wLua::FLuaVector::Get(InScriptContext, 2));
#if UE_GAME
	USplineComponent * This = (USplineComponent *)Obj;
	Params.ReturnValue = This->FindInputKeyClosestToWorldLocationWithSegment(Params.WorldLocation,Params.segment);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("FindInputKeyClosestToWorldLocationWithSegment"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FVector*)(params.GetStructMemory() + 0) = Params.WorldLocation;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.WorldLocation = *(FVector*)(params.GetStructMemory() + 0);
		Params.segment = *(int32*)(params.GetStructMemory() + 12);
		Params.ReturnValue = *(float*)(params.GetStructMemory() + 16);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushnumber(InScriptContext, Params.ReturnValue);
	lua_pushinteger(InScriptContext, Params.segment);
	return 2;
}

int32 FindInputKeyClosestToWorldLocation(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SplineComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SplineComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FVector WorldLocation;
		float ReturnValue;
	} Params;
	Params.WorldLocation = (wLua::FLuaVector::Get(InScriptContext, 2));
#if UE_GAME
	USplineComponent * This = (USplineComponent *)Obj;
	Params.ReturnValue = This->FindInputKeyClosestToWorldLocation(Params.WorldLocation);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("FindInputKeyClosestToWorldLocation"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FVector*)(params.GetStructMemory() + 0) = Params.WorldLocation;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.WorldLocation = *(FVector*)(params.GetStructMemory() + 0);
		Params.ReturnValue = *(float*)(params.GetStructMemory() + 12);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushnumber(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 FindDirectionClosestToWorldLocationWithSegment(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SplineComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SplineComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FVector WorldLocation;
		TEnumAsByte<ESplineCoordinateSpace::Type> CoordinateSpace;
		int32 segment;
		FVector ReturnValue;
	} Params;
	Params.WorldLocation = (wLua::FLuaVector::Get(InScriptContext, 2));
	Params.CoordinateSpace = (TEnumAsByte<ESplineCoordinateSpace::Type>)(luaL_checkint(InScriptContext, 3));
#if UE_GAME
	USplineComponent * This = (USplineComponent *)Obj;
	Params.ReturnValue = This->FindDirectionClosestToWorldLocationWithSegment(Params.WorldLocation,Params.CoordinateSpace,Params.segment);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("FindDirectionClosestToWorldLocationWithSegment"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FVector*)(params.GetStructMemory() + 0) = Params.WorldLocation;
		*(TEnumAsByte<ESplineCoordinateSpace::Type>*)(params.GetStructMemory() + 12) = Params.CoordinateSpace;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.WorldLocation = *(FVector*)(params.GetStructMemory() + 0);
		Params.CoordinateSpace = *(TEnumAsByte<ESplineCoordinateSpace::Type>*)(params.GetStructMemory() + 12);
		Params.segment = *(int32*)(params.GetStructMemory() + 16);
		Params.ReturnValue = *(FVector*)(params.GetStructMemory() + 20);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaVector::Return(InScriptContext, Params.ReturnValue);
	lua_pushinteger(InScriptContext, Params.segment);
	return 2;
}

int32 FindDirectionClosestToWorldLocation(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SplineComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SplineComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FVector WorldLocation;
		TEnumAsByte<ESplineCoordinateSpace::Type> CoordinateSpace;
		FVector ReturnValue;
	} Params;
	Params.WorldLocation = (wLua::FLuaVector::Get(InScriptContext, 2));
	Params.CoordinateSpace = (TEnumAsByte<ESplineCoordinateSpace::Type>)(luaL_checkint(InScriptContext, 3));
#if UE_GAME
	USplineComponent * This = (USplineComponent *)Obj;
	Params.ReturnValue = This->FindDirectionClosestToWorldLocation(Params.WorldLocation,Params.CoordinateSpace);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("FindDirectionClosestToWorldLocation"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FVector*)(params.GetStructMemory() + 0) = Params.WorldLocation;
		*(TEnumAsByte<ESplineCoordinateSpace::Type>*)(params.GetStructMemory() + 12) = Params.CoordinateSpace;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.WorldLocation = *(FVector*)(params.GetStructMemory() + 0);
		Params.CoordinateSpace = *(TEnumAsByte<ESplineCoordinateSpace::Type>*)(params.GetStructMemory() + 12);
		Params.ReturnValue = *(FVector*)(params.GetStructMemory() + 16);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaVector::Return(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 ClearSplinePoints(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SplineComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SplineComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool bUpdateSpline;
	} Params;
	Params.bUpdateSpline = lua_isnoneornil(InScriptContext,2) ? bool(true) : !!(lua_toboolean(InScriptContext, 2));
#if UE_GAME
	USplineComponent * This = (USplineComponent *)Obj;
	This->ClearSplinePoints(Params.bUpdateSpline);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("ClearSplinePoints"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(bool*)(params.GetStructMemory() + 0) = Params.bUpdateSpline;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.bUpdateSpline = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 AddSplinePointAtIndex(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SplineComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SplineComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FVector Position;
		int32 Index;
		TEnumAsByte<ESplineCoordinateSpace::Type> CoordinateSpace;
		bool bUpdateSpline;
	} Params;
	Params.Position = (wLua::FLuaVector::Get(InScriptContext, 2));
	Params.Index = (luaL_checkint(InScriptContext, 3));
	Params.CoordinateSpace = (TEnumAsByte<ESplineCoordinateSpace::Type>)(luaL_checkint(InScriptContext, 4));
	Params.bUpdateSpline = lua_isnoneornil(InScriptContext,5) ? bool(true) : !!(lua_toboolean(InScriptContext, 5));
#if UE_GAME
	USplineComponent * This = (USplineComponent *)Obj;
	This->AddSplinePointAtIndex(Params.Position,Params.Index,Params.CoordinateSpace,Params.bUpdateSpline);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("AddSplinePointAtIndex"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FVector*)(params.GetStructMemory() + 0) = Params.Position;
		*(int32*)(params.GetStructMemory() + 12) = Params.Index;
		*(TEnumAsByte<ESplineCoordinateSpace::Type>*)(params.GetStructMemory() + 16) = Params.CoordinateSpace;
		*(bool*)(params.GetStructMemory() + 17) = Params.bUpdateSpline;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.Position = *(FVector*)(params.GetStructMemory() + 0);
		Params.Index = *(int32*)(params.GetStructMemory() + 12);
		Params.CoordinateSpace = *(TEnumAsByte<ESplineCoordinateSpace::Type>*)(params.GetStructMemory() + 16);
		Params.bUpdateSpline = *(bool*)(params.GetStructMemory() + 17);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 AddSplinePoint(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SplineComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SplineComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FVector Position;
		TEnumAsByte<ESplineCoordinateSpace::Type> CoordinateSpace;
		bool bUpdateSpline;
	} Params;
	Params.Position = (wLua::FLuaVector::Get(InScriptContext, 2));
	Params.CoordinateSpace = (TEnumAsByte<ESplineCoordinateSpace::Type>)(luaL_checkint(InScriptContext, 3));
	Params.bUpdateSpline = lua_isnoneornil(InScriptContext,4) ? bool(true) : !!(lua_toboolean(InScriptContext, 4));
#if UE_GAME
	USplineComponent * This = (USplineComponent *)Obj;
	This->AddSplinePoint(Params.Position,Params.CoordinateSpace,Params.bUpdateSpline);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("AddSplinePoint"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FVector*)(params.GetStructMemory() + 0) = Params.Position;
		*(TEnumAsByte<ESplineCoordinateSpace::Type>*)(params.GetStructMemory() + 12) = Params.CoordinateSpace;
		*(bool*)(params.GetStructMemory() + 13) = Params.bUpdateSpline;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.Position = *(FVector*)(params.GetStructMemory() + 0);
		Params.CoordinateSpace = *(TEnumAsByte<ESplineCoordinateSpace::Type>*)(params.GetStructMemory() + 12);
		Params.bUpdateSpline = *(bool*)(params.GetStructMemory() + 13);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 Get_ReparamStepsPerSegment(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SplineComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SplineComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USplineComponent::StaticClass(), TEXT("ReparamStepsPerSegment"));
	if(!Property) { check(false); return 0;}
	int32 PropertyValue = int32();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushinteger(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_ReparamStepsPerSegment(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SplineComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SplineComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USplineComponent::StaticClass(), TEXT("ReparamStepsPerSegment"));
	if(!Property) { check(false); return 0;}
	int32 PropertyValue = (luaL_checkint(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_Duration(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SplineComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SplineComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USplineComponent::StaticClass(), TEXT("Duration"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_Duration(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SplineComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SplineComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USplineComponent::StaticClass(), TEXT("Duration"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bStationaryEndpoints(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SplineComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SplineComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USplineComponent::StaticClass(), TEXT("bStationaryEndpoints"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = bool();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bStationaryEndpoints(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SplineComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SplineComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USplineComponent::StaticClass(), TEXT("bStationaryEndpoints"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bSplineHasBeenEdited(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SplineComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SplineComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USplineComponent::StaticClass(), TEXT("bSplineHasBeenEdited"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = bool();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bSplineHasBeenEdited(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SplineComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SplineComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USplineComponent::StaticClass(), TEXT("bSplineHasBeenEdited"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bInputSplinePointsToConstructionScript(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SplineComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SplineComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USplineComponent::StaticClass(), TEXT("bInputSplinePointsToConstructionScript"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = bool();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bInputSplinePointsToConstructionScript(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SplineComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SplineComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USplineComponent::StaticClass(), TEXT("bInputSplinePointsToConstructionScript"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bDrawDebug(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SplineComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SplineComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USplineComponent::StaticClass(), TEXT("bDrawDebug"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = bool();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bDrawDebug(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SplineComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SplineComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USplineComponent::StaticClass(), TEXT("bDrawDebug"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bClosedLoop(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SplineComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SplineComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USplineComponent::StaticClass(), TEXT("bClosedLoop"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = bool();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bClosedLoop(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SplineComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SplineComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USplineComponent::StaticClass(), TEXT("bClosedLoop"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bLoopPositionOverride(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SplineComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SplineComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USplineComponent::StaticClass(), TEXT("bLoopPositionOverride"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = bool();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bLoopPositionOverride(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SplineComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SplineComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USplineComponent::StaticClass(), TEXT("bLoopPositionOverride"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_LoopPosition(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SplineComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SplineComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USplineComponent::StaticClass(), TEXT("LoopPosition"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_LoopPosition(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SplineComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SplineComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USplineComponent::StaticClass(), TEXT("LoopPosition"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_DefaultUpVector(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SplineComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SplineComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USplineComponent::StaticClass(), TEXT("DefaultUpVector"));
	if(!Property) { check(false); return 0;}
	FVector PropertyValue = FVector();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaVector::Return(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_DefaultUpVector(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SplineComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SplineComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USplineComponent::StaticClass(), TEXT("DefaultUpVector"));
	if(!Property) { check(false); return 0;}
	FVector PropertyValue = (wLua::FLuaVector::Get(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_EditorUnselectedSplineSegmentColor(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SplineComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SplineComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USplineComponent::StaticClass(), TEXT("EditorUnselectedSplineSegmentColor"));
	if(!Property) { check(false); return 0;}
	FLinearColor PropertyValue = FLinearColor();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaLinearColor::Return(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_EditorUnselectedSplineSegmentColor(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SplineComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SplineComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USplineComponent::StaticClass(), TEXT("EditorUnselectedSplineSegmentColor"));
	if(!Property) { check(false); return 0;}
	FLinearColor PropertyValue = (wLua::FLuaLinearColor::Get(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_EditorSelectedSplineSegmentColor(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SplineComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SplineComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USplineComponent::StaticClass(), TEXT("EditorSelectedSplineSegmentColor"));
	if(!Property) { check(false); return 0;}
	FLinearColor PropertyValue = FLinearColor();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaLinearColor::Return(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_EditorSelectedSplineSegmentColor(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SplineComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SplineComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USplineComponent::StaticClass(), TEXT("EditorSelectedSplineSegmentColor"));
	if(!Property) { check(false); return 0;}
	FLinearColor PropertyValue = (wLua::FLuaLinearColor::Get(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bAllowDiscontinuousSpline(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SplineComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SplineComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USplineComponent::StaticClass(), TEXT("bAllowDiscontinuousSpline"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = bool();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bAllowDiscontinuousSpline(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SplineComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SplineComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USplineComponent::StaticClass(), TEXT("bAllowDiscontinuousSpline"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bShouldVisualizeScale(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SplineComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SplineComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USplineComponent::StaticClass(), TEXT("bShouldVisualizeScale"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = bool();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bShouldVisualizeScale(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SplineComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SplineComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USplineComponent::StaticClass(), TEXT("bShouldVisualizeScale"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_ScaleVisualizationWidth(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SplineComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SplineComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USplineComponent::StaticClass(), TEXT("ScaleVisualizationWidth"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_ScaleVisualizationWidth(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SplineComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SplineComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USplineComponent::StaticClass(), TEXT("ScaleVisualizationWidth"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 New(lua_State* InScriptContext)
{
	UObject* Outer = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Object");
	FName Name = FName(luaL_checkstring(InScriptContext, 2));
	UObject* Obj = NewObject<USplineComponent>(Outer, Name);
	wLua::FLuaUtils::ReturnUObject(InScriptContext,Obj);
	return 1;
}

int32 Destroy(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SplineComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SplineComponent must be non-null"); lua_error(InScriptContext);  return 0;}
		UActorComponent * com = Cast<UActorComponent>(Obj);
		if(lua_isnoneornil(InScriptContext,2))
			com->DestroyComponent();
		else
			com->DestroyComponent(!!lua_toboolean(InScriptContext,2));
		userdata->flag |= wLua::LuaObjectFlag::DESTROYED;
		wLua::FLuaUtils::RemoveObjectReference(Obj, userdata->stamp, InScriptContext);
#ifdef AZURE_BUILD_WLUACHECK
		UE_LOG(LogAzure, Warning, TEXT("Destroy SplineComponent: %x userdata:%x   stamp:%x"),Obj,userdata,userdata->stamp);
#endif
	return 0;
}

int32 Class(lua_State* InScriptContext)
{
	UClass* Class = USplineComponent::StaticClass();
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Class);
	return 1;
}

const luaL_Reg Lib_Funcs[] =
{
	{ "New", New },
	{ "Destroy", Destroy },
	{ "Class", Class },
	{ "UpdateSpline", UpdateSpline },
	{ "SetUpVectorAtSplinePoint", SetUpVectorAtSplinePoint },
	{ "SetUnselectedSplineSegmentColor", SetUnselectedSplineSegmentColor },
	{ "SetTangentsAtSplinePoint", SetTangentsAtSplinePoint },
	{ "SetTangentAtSplinePoint", SetTangentAtSplinePoint },
	{ "SetSplinePointType", SetSplinePointType },
	{ "SetSplinePoints", SetSplinePoints },
	{ "SetSelectedSplineSegmentColor", SetSelectedSplineSegmentColor },
	{ "SetLocationAtSplinePoint", SetLocationAtSplinePoint },
	{ "SetDrawDebug", SetDrawDebug },
	{ "SetDefaultUpVector", SetDefaultUpVector },
	{ "SetClosedLoopAtPosition", SetClosedLoopAtPosition },
	{ "SetClosedLoop", SetClosedLoop },
	{ "RemoveSplinePoint", RemoveSplinePoint },
	{ "IsClosedLoop", IsClosedLoop },
	{ "GetUpVectorAtTime", GetUpVectorAtTime },
	{ "GetUpVectorAtSplinePoint", GetUpVectorAtSplinePoint },
	{ "GetUpVectorAtDistanceAlongSplineWithSegment", GetUpVectorAtDistanceAlongSplineWithSegment },
	{ "GetUpVectorAtDistanceAlongSpline", GetUpVectorAtDistanceAlongSpline },
	{ "GetTransformAtTime", GetTransformAtTime },
	{ "GetTransformAtSplinePoint", GetTransformAtSplinePoint },
	{ "GetTransformAtDistanceAlongSpline", GetTransformAtDistanceAlongSpline },
	{ "GetTangentAtTime", GetTangentAtTime },
	{ "GetTangentAtSplinePoint", GetTangentAtSplinePoint },
	{ "GetTangentAtDistanceAlongSplineWithSegment", GetTangentAtDistanceAlongSplineWithSegment },
	{ "GetTangentAtDistanceAlongSpline", GetTangentAtDistanceAlongSpline },
	{ "GetSplinePointType", GetSplinePointType },
	{ "GetSplineLength", GetSplineLength },
	{ "GetScaleAtTime", GetScaleAtTime },
	{ "GetScaleAtSplinePoint", GetScaleAtSplinePoint },
	{ "GetScaleAtDistanceAlongSpline", GetScaleAtDistanceAlongSpline },
	{ "GetRotationAtTime", GetRotationAtTime },
	{ "GetRotationAtSplinePoint", GetRotationAtSplinePoint },
	{ "GetRotationAtDistanceAlongSplineWithSegment", GetRotationAtDistanceAlongSplineWithSegment },
	{ "GetRotationAtDistanceAlongSpline", GetRotationAtDistanceAlongSpline },
	{ "GetRollAtTime", GetRollAtTime },
	{ "GetRollAtSplinePoint", GetRollAtSplinePoint },
	{ "GetRollAtDistanceAlongSpline", GetRollAtDistanceAlongSpline },
	{ "GetRightVectorAtTime", GetRightVectorAtTime },
	{ "GetRightVectorAtSplinePoint", GetRightVectorAtSplinePoint },
	{ "GetRightVectorAtDistanceAlongSpline", GetRightVectorAtDistanceAlongSpline },
	{ "GetPointIndexAtDistance", GetPointIndexAtDistance },
	{ "GetNumberOfSplinePoints", GetNumberOfSplinePoints },
	{ "GetLocationAtTime", GetLocationAtTime },
	{ "GetLocationAtSplinePoint", GetLocationAtSplinePoint },
	{ "GetLocationAtDistanceAlongSplineWithSegment", GetLocationAtDistanceAlongSplineWithSegment },
	{ "GetLocationAtDistanceAlongSpline", GetLocationAtDistanceAlongSpline },
	{ "GetLocationAndTangentAtSplinePoint", GetLocationAndTangentAtSplinePoint },
	{ "GetLeaveTangentAtSplinePoint", GetLeaveTangentAtSplinePoint },
	{ "GetInputKeyAtDistanceAlongSpline", GetInputKeyAtDistanceAlongSpline },
	{ "GetDistanceAlongSplineAtSplinePoint", GetDistanceAlongSplineAtSplinePoint },
	{ "GetDirectionAtTime", GetDirectionAtTime },
	{ "GetDirectionAtSplinePoint", GetDirectionAtSplinePoint },
	{ "GetDirectionAtDistanceAlongSplineWithSegment", GetDirectionAtDistanceAlongSplineWithSegment },
	{ "GetDirectionAtDistanceAlongSpline", GetDirectionAtDistanceAlongSpline },
	{ "GetDefaultUpVector", GetDefaultUpVector },
	{ "GetArriveTangentAtSplinePoint", GetArriveTangentAtSplinePoint },
	{ "FindUpVectorClosestToWorldLocation", FindUpVectorClosestToWorldLocation },
	{ "FindTransformClosestToWorldLocation", FindTransformClosestToWorldLocation },
	{ "FindTangentClosestToWorldLocation", FindTangentClosestToWorldLocation },
	{ "FindScaleClosestToWorldLocation", FindScaleClosestToWorldLocation },
	{ "FindRotationClosestToWorldLocation", FindRotationClosestToWorldLocation },
	{ "FindRollClosestToWorldLocation", FindRollClosestToWorldLocation },
	{ "FindRightVectorClosestToWorldLocation", FindRightVectorClosestToWorldLocation },
	{ "FindLocationClosestToWorldLocationWithSegment", FindLocationClosestToWorldLocationWithSegment },
	{ "FindLocationClosestToWorldLocation", FindLocationClosestToWorldLocation },
	{ "FindInputKeyClosestToWorldLocationWithSegment", FindInputKeyClosestToWorldLocationWithSegment },
	{ "FindInputKeyClosestToWorldLocation", FindInputKeyClosestToWorldLocation },
	{ "FindDirectionClosestToWorldLocationWithSegment", FindDirectionClosestToWorldLocationWithSegment },
	{ "FindDirectionClosestToWorldLocation", FindDirectionClosestToWorldLocation },
	{ "ClearSplinePoints", ClearSplinePoints },
	{ "AddSplinePointAtIndex", AddSplinePointAtIndex },
	{ "AddSplinePoint", AddSplinePoint },
	{ "Get_ReparamStepsPerSegment", Get_ReparamStepsPerSegment },
	{ "Set_ReparamStepsPerSegment", Set_ReparamStepsPerSegment },
	{ "Get_Duration", Get_Duration },
	{ "Set_Duration", Set_Duration },
	{ "Get_bStationaryEndpoints", Get_bStationaryEndpoints },
	{ "Set_bStationaryEndpoints", Set_bStationaryEndpoints },
	{ "Get_bSplineHasBeenEdited", Get_bSplineHasBeenEdited },
	{ "Set_bSplineHasBeenEdited", Set_bSplineHasBeenEdited },
	{ "Get_bInputSplinePointsToConstructionScript", Get_bInputSplinePointsToConstructionScript },
	{ "Set_bInputSplinePointsToConstructionScript", Set_bInputSplinePointsToConstructionScript },
	{ "Get_bDrawDebug", Get_bDrawDebug },
	{ "Set_bDrawDebug", Set_bDrawDebug },
	{ "Get_bClosedLoop", Get_bClosedLoop },
	{ "Set_bClosedLoop", Set_bClosedLoop },
	{ "Get_bLoopPositionOverride", Get_bLoopPositionOverride },
	{ "Set_bLoopPositionOverride", Set_bLoopPositionOverride },
	{ "Get_LoopPosition", Get_LoopPosition },
	{ "Set_LoopPosition", Set_LoopPosition },
	{ "Get_DefaultUpVector", Get_DefaultUpVector },
	{ "Set_DefaultUpVector", Set_DefaultUpVector },
	{ "Get_EditorUnselectedSplineSegmentColor", Get_EditorUnselectedSplineSegmentColor },
	{ "Set_EditorUnselectedSplineSegmentColor", Set_EditorUnselectedSplineSegmentColor },
	{ "Get_EditorSelectedSplineSegmentColor", Get_EditorSelectedSplineSegmentColor },
	{ "Set_EditorSelectedSplineSegmentColor", Set_EditorSelectedSplineSegmentColor },
	{ "Get_bAllowDiscontinuousSpline", Get_bAllowDiscontinuousSpline },
	{ "Set_bAllowDiscontinuousSpline", Set_bAllowDiscontinuousSpline },
	{ "Get_bShouldVisualizeScale", Get_bShouldVisualizeScale },
	{ "Set_bShouldVisualizeScale", Set_bShouldVisualizeScale },
	{ "Get_ScaleVisualizationWidth", Get_ScaleVisualizationWidth },
	{ "Set_ScaleVisualizationWidth", Set_ScaleVisualizationWidth },
	{ "is_nil", wLua::LuaStatic::isnil },
	{ "__gc", wLua::LuaStatic::removeUClassFrameCache },
	{ NULL, NULL }
};

void Register(lua_State *InScriptContext)
{
	lua_newtable(InScriptContext);
	luaL_register(InScriptContext, NULL, Lib_Funcs);
	AzureHelpFuncs::AuxRegister(InScriptContext, "SplineComponent");
}
void SetMtLink(lua_State *InScriptContext)
{
	AzureHelpFuncs::AuxSetMtLink(InScriptContext, "SplineComponent", "PrimitiveComponent",USERDATATYPE_UOBJECT);
}

}