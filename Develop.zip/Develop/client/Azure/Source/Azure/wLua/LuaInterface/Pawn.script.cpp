#include "Azure.h"
#include "Utility/help_funcs.h"
#include "wLua/UObjectHeaders.h"
#include "GameFramework/Pawn.h"
#include "AzureLuaIntegration.h"

namespace LuaPawn
{
int32 SpawnDefaultController(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Pawn",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Pawn must be non-null"); lua_error(InScriptContext);  return 0;}
#if UE_GAME
	APawn * This = (APawn *)Obj;
	This->SpawnDefaultController();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SpawnDefaultController"));
	if(!Function) { check(false); return 0;}
	Obj->ProcessEvent(Function, NULL);
#endif
	return 0;
}

int32 SetCanAffectNavigationGeneration(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Pawn",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Pawn must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool bNewValue;
		bool bForceUpdate;
	} Params;
	Params.bNewValue = !!(lua_toboolean(InScriptContext, 2));
	Params.bForceUpdate = lua_isnoneornil(InScriptContext,3) ? bool(false) : !!(lua_toboolean(InScriptContext, 3));
#if UE_GAME
	APawn * This = (APawn *)Obj;
	This->SetCanAffectNavigationGeneration(Params.bNewValue,Params.bForceUpdate);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetCanAffectNavigationGeneration"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(bool*)(params.GetStructMemory() + 0) = Params.bNewValue;
		*(bool*)(params.GetStructMemory() + 1) = Params.bForceUpdate;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.bNewValue = *(bool*)(params.GetStructMemory() + 0);
		Params.bForceUpdate = *(bool*)(params.GetStructMemory() + 1);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 ReceiveUnpossessed(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Pawn",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Pawn must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		AController* OldController = nullptr;
	} Params;
	Params.OldController = (AController*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"Controller");;
#if UE_GAME
	APawn * This = (APawn *)Obj;
	This->ReceiveUnpossessed(Params.OldController);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("ReceiveUnpossessed"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(AController**)(params.GetStructMemory() + 0) = Params.OldController;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.OldController = *(AController**)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 ReceivePossessed(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Pawn",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Pawn must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		AController* NewController = nullptr;
	} Params;
	Params.NewController = (AController*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"Controller");;
#if UE_GAME
	APawn * This = (APawn *)Obj;
	This->ReceivePossessed(Params.NewController);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("ReceivePossessed"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(AController**)(params.GetStructMemory() + 0) = Params.NewController;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.NewController = *(AController**)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 PawnMakeNoise(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Pawn",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Pawn must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float Loudness;
		FVector NoiseLocation;
		bool bUseNoiseMakerLocation;
		AActor* NoiseMaker = nullptr;
	} Params;
	Params.Loudness = (float)(luaL_checknumber(InScriptContext, 2));
	Params.NoiseLocation = (wLua::FLuaVector::Get(InScriptContext, 3));
	Params.bUseNoiseMakerLocation = lua_isnoneornil(InScriptContext,4) ? bool(true) : !!(lua_toboolean(InScriptContext, 4));
	Params.NoiseMaker = lua_isnoneornil(InScriptContext,5) ? nullptr : (AActor*)wLua::FLuaUtils::GetUObject(InScriptContext,5,"Actor");;
#if UE_GAME
	APawn * This = (APawn *)Obj;
	This->PawnMakeNoise(Params.Loudness,Params.NoiseLocation,Params.bUseNoiseMakerLocation,Params.NoiseMaker);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("PawnMakeNoise"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(float*)(params.GetStructMemory() + 0) = Params.Loudness;
		*(FVector*)(params.GetStructMemory() + 4) = Params.NoiseLocation;
		*(bool*)(params.GetStructMemory() + 16) = Params.bUseNoiseMakerLocation;
		*(AActor**)(params.GetStructMemory() + 24) = Params.NoiseMaker;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.Loudness = *(float*)(params.GetStructMemory() + 0);
		Params.NoiseLocation = *(FVector*)(params.GetStructMemory() + 4);
		Params.bUseNoiseMakerLocation = *(bool*)(params.GetStructMemory() + 16);
		Params.NoiseMaker = *(AActor**)(params.GetStructMemory() + 24);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 OnRep_PlayerState(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Pawn",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Pawn must be non-null"); lua_error(InScriptContext);  return 0;}
#if UE_GAME
	APawn * This = (APawn *)Obj;
	This->OnRep_PlayerState();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("OnRep_PlayerState"));
	if(!Function) { check(false); return 0;}
	Obj->ProcessEvent(Function, NULL);
#endif
	return 0;
}

int32 OnRep_Controller(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Pawn",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Pawn must be non-null"); lua_error(InScriptContext);  return 0;}
#if UE_GAME
	APawn * This = (APawn *)Obj;
	This->OnRep_Controller();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("OnRep_Controller"));
	if(!Function) { check(false); return 0;}
	Obj->ProcessEvent(Function, NULL);
#endif
	return 0;
}

int32 IsPlayerControlled(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Pawn",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Pawn must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool ReturnValue;
	} Params;
#if UE_GAME
	APawn * This = (APawn *)Obj;
	Params.ReturnValue = This->IsPlayerControlled();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("IsPlayerControlled"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushboolean(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 IsMoveInputIgnored(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Pawn",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Pawn must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool ReturnValue;
	} Params;
#if UE_GAME
	APawn * This = (APawn *)Obj;
	Params.ReturnValue = This->IsMoveInputIgnored();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("IsMoveInputIgnored"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushboolean(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 IsLocallyControlled(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Pawn",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Pawn must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool ReturnValue;
	} Params;
#if UE_GAME
	APawn * This = (APawn *)Obj;
	Params.ReturnValue = This->IsLocallyControlled();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("IsLocallyControlled"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushboolean(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 IsControlled(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Pawn",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Pawn must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool ReturnValue;
	} Params;
#if UE_GAME
	APawn * This = (APawn *)Obj;
	Params.ReturnValue = This->IsControlled();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("IsControlled"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushboolean(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetPendingMovementInputVector(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Pawn",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Pawn must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FVector ReturnValue;
	} Params;
#if UE_GAME
	APawn * This = (APawn *)Obj;
	Params.ReturnValue = This->GetPendingMovementInputVector();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetPendingMovementInputVector"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(FVector*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaVector::Return(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetNavAgentLocation(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Pawn",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Pawn must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FVector ReturnValue;
	} Params;
#if UE_GAME
	APawn * This = (APawn *)Obj;
	Params.ReturnValue = This->GetNavAgentLocation();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetNavAgentLocation"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(FVector*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaVector::Return(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetMovementComponent(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Pawn",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Pawn must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		UPawnMovementComponent* ReturnValue = nullptr;
	} Params;
#if UE_GAME
	APawn * This = (APawn *)Obj;
	Params.ReturnValue = This->GetMovementComponent();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetMovementComponent"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(UPawnMovementComponent**)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetMovementBaseActor(lua_State* InScriptContext)
{
	UClass * Obj = APawn::StaticClass(); 
	struct FDispatchParams
	{
		APawn* Pawn = nullptr;
		AActor* ReturnValue = nullptr;
	} Params;
	Params.Pawn = (APawn*)wLua::FLuaUtils::GetUObject(InScriptContext,1,"Pawn");;
#if UE_GAME
	Params.ReturnValue = APawn::GetMovementBaseActor(Params.Pawn);
#else
	UFunction* Function = Obj->FindFunctionByName(TEXT("GetMovementBaseActor"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(APawn**)(params.GetStructMemory() + 0) = Params.Pawn;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.Pawn = *(APawn**)(params.GetStructMemory() + 0);
		Params.ReturnValue = *(AActor**)(params.GetStructMemory() + 8);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetLastMovementInputVector(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Pawn",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Pawn must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FVector ReturnValue;
	} Params;
#if UE_GAME
	APawn * This = (APawn *)Obj;
	Params.ReturnValue = This->GetLastMovementInputVector();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetLastMovementInputVector"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(FVector*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaVector::Return(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetControlRotation(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Pawn",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Pawn must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FRotator ReturnValue;
	} Params;
#if UE_GAME
	APawn * This = (APawn *)Obj;
	Params.ReturnValue = This->GetControlRotation();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetControlRotation"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(FRotator*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaRotator::Return(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetController(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Pawn",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Pawn must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		AController* ReturnValue = nullptr;
	} Params;
#if UE_GAME
	APawn * This = (APawn *)Obj;
	Params.ReturnValue = This->GetController();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetController"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(AController**)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetBaseAimRotation(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Pawn",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Pawn must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FRotator ReturnValue;
	} Params;
#if UE_GAME
	APawn * This = (APawn *)Obj;
	Params.ReturnValue = This->GetBaseAimRotation();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetBaseAimRotation"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(FRotator*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaRotator::Return(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 DetachFromControllerPendingDestroy(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Pawn",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Pawn must be non-null"); lua_error(InScriptContext);  return 0;}
#if UE_GAME
	APawn * This = (APawn *)Obj;
	This->DetachFromControllerPendingDestroy();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("DetachFromControllerPendingDestroy"));
	if(!Function) { check(false); return 0;}
	Obj->ProcessEvent(Function, NULL);
#endif
	return 0;
}

int32 ConsumeMovementInputVector(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Pawn",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Pawn must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FVector ReturnValue;
	} Params;
#if UE_GAME
	APawn * This = (APawn *)Obj;
	Params.ReturnValue = This->ConsumeMovementInputVector();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("ConsumeMovementInputVector"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(FVector*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaVector::Return(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 AddMovementInput(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Pawn",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Pawn must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FVector WorldDirection;
		float ScaleValue;
		bool bForce;
	} Params;
	Params.WorldDirection = (wLua::FLuaVector::Get(InScriptContext, 2));
	Params.ScaleValue = lua_isnoneornil(InScriptContext,3) ? float(1.000000) : (float)(luaL_checknumber(InScriptContext, 3));
	Params.bForce = lua_isnoneornil(InScriptContext,4) ? bool(false) : !!(lua_toboolean(InScriptContext, 4));
#if UE_GAME
	APawn * This = (APawn *)Obj;
	This->AddMovementInput(Params.WorldDirection,Params.ScaleValue,Params.bForce);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("AddMovementInput"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FVector*)(params.GetStructMemory() + 0) = Params.WorldDirection;
		*(float*)(params.GetStructMemory() + 12) = Params.ScaleValue;
		*(bool*)(params.GetStructMemory() + 16) = Params.bForce;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.WorldDirection = *(FVector*)(params.GetStructMemory() + 0);
		Params.ScaleValue = *(float*)(params.GetStructMemory() + 12);
		Params.bForce = *(bool*)(params.GetStructMemory() + 16);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 AddControllerYawInput(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Pawn",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Pawn must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float Val;
	} Params;
	Params.Val = (float)(luaL_checknumber(InScriptContext, 2));
#if UE_GAME
	APawn * This = (APawn *)Obj;
	This->AddControllerYawInput(Params.Val);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("AddControllerYawInput"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(float*)(params.GetStructMemory() + 0) = Params.Val;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.Val = *(float*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 AddControllerRollInput(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Pawn",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Pawn must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float Val;
	} Params;
	Params.Val = (float)(luaL_checknumber(InScriptContext, 2));
#if UE_GAME
	APawn * This = (APawn *)Obj;
	This->AddControllerRollInput(Params.Val);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("AddControllerRollInput"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(float*)(params.GetStructMemory() + 0) = Params.Val;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.Val = *(float*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 AddControllerPitchInput(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Pawn",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Pawn must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float Val;
	} Params;
	Params.Val = (float)(luaL_checknumber(InScriptContext, 2));
#if UE_GAME
	APawn * This = (APawn *)Obj;
	This->AddControllerPitchInput(Params.Val);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("AddControllerPitchInput"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(float*)(params.GetStructMemory() + 0) = Params.Val;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.Val = *(float*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 Get_bUseControllerRotationPitch(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Pawn",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Pawn must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(APawn::StaticClass(), TEXT("bUseControllerRotationPitch"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bUseControllerRotationPitch(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Pawn",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Pawn must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(APawn::StaticClass(), TEXT("bUseControllerRotationPitch"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bUseControllerRotationYaw(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Pawn",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Pawn must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(APawn::StaticClass(), TEXT("bUseControllerRotationYaw"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bUseControllerRotationYaw(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Pawn",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Pawn must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(APawn::StaticClass(), TEXT("bUseControllerRotationYaw"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bUseControllerRotationRoll(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Pawn",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Pawn must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(APawn::StaticClass(), TEXT("bUseControllerRotationRoll"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bUseControllerRotationRoll(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Pawn",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Pawn must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(APawn::StaticClass(), TEXT("bUseControllerRotationRoll"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bCanAffectNavigationGeneration(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Pawn",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Pawn must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(APawn::StaticClass(), TEXT("bCanAffectNavigationGeneration"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_BaseEyeHeight(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Pawn",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Pawn must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(APawn::StaticClass(), TEXT("BaseEyeHeight"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_BaseEyeHeight(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Pawn",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Pawn must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(APawn::StaticClass(), TEXT("BaseEyeHeight"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_AutoPossessPlayer(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Pawn",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Pawn must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(APawn::StaticClass(), TEXT("AutoPossessPlayer"));
	if(!Property) { check(false); return 0;}
	TEnumAsByte<EAutoReceiveInput::Type> PropertyValue = TEnumAsByte<EAutoReceiveInput::Type>();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushinteger(InScriptContext, (int)PropertyValue);
	return 1;
}

int32 Set_AutoPossessPlayer(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Pawn",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Pawn must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(APawn::StaticClass(), TEXT("AutoPossessPlayer"));
	if(!Property) { check(false); return 0;}
	TEnumAsByte<EAutoReceiveInput::Type> PropertyValue = (TEnumAsByte<EAutoReceiveInput::Type>)(luaL_checkint(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_AutoPossessAI(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Pawn",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Pawn must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(APawn::StaticClass(), TEXT("AutoPossessAI"));
	if(!Property) { check(false); return 0;}
	EAutoPossessAI PropertyValue = EAutoPossessAI();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushinteger(InScriptContext, (int)PropertyValue);
	return 1;
}

int32 Set_AutoPossessAI(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Pawn",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Pawn must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(APawn::StaticClass(), TEXT("AutoPossessAI"));
	if(!Property) { check(false); return 0;}
	EAutoPossessAI PropertyValue = (EAutoPossessAI)(luaL_checkint(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_AIControllerClass(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Pawn",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Pawn must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(APawn::StaticClass(), TEXT("AIControllerClass"));
	if(!Property) { check(false); return 0;}
	TSubclassOf<AController>  PropertyValue = TSubclassOf<AController> ();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaUtils::ReturnUObject(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_AIControllerClass(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Pawn",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Pawn must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(APawn::StaticClass(), TEXT("AIControllerClass"));
	if(!Property) { check(false); return 0;}
	TSubclassOf<AController>  PropertyValue = (UClass*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"Class");;
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_PlayerState(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Pawn",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Pawn must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(APawn::StaticClass(), TEXT("PlayerState"));
	if(!Property) { check(false); return 0;}
	APlayerState* PropertyValue;
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaUtils::ReturnUObject(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_LastHitBy(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Pawn",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Pawn must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(APawn::StaticClass(), TEXT("LastHitBy"));
	if(!Property) { check(false); return 0;}
	AController* PropertyValue;
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaUtils::ReturnUObject(InScriptContext, PropertyValue);
	return 1;
}

int32 New(lua_State* InScriptContext)
{
	UObject* Outer = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Object");
	FName Name = FName(luaL_checkstring(InScriptContext, 2));
	UObject* Obj = NewObject<APawn>(Outer, Name);
	wLua::FLuaUtils::ReturnUObject(InScriptContext,Obj);
	return 1;
}

int32 Destroy(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Pawn",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"Pawn must be non-null"); lua_error(InScriptContext);  return 0;}
		AActor * actor = Cast<AActor>(Obj);
		actor->Destroy();
		userdata->flag |= wLua::LuaObjectFlag::DESTROYED;
		wLua::FLuaUtils::RemoveObjectReference(Obj, userdata->stamp, InScriptContext);
#ifdef AZURE_BUILD_WLUACHECK
		UE_LOG(LogAzure, Warning, TEXT("Destroy Pawn: %x userdata:%x   stamp:%x"),Obj,userdata,userdata->stamp);
#endif
	return 0;
}

int32 Class(lua_State* InScriptContext)
{
	UClass* Class = APawn::StaticClass();
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Class);
	return 1;
}

const luaL_Reg Lib_Funcs[] =
{
	{ "New", New },
	{ "Destroy", Destroy },
	{ "Class", Class },
	{ "SpawnDefaultController", SpawnDefaultController },
	{ "SetCanAffectNavigationGeneration", SetCanAffectNavigationGeneration },
	{ "ReceiveUnpossessed", ReceiveUnpossessed },
	{ "ReceivePossessed", ReceivePossessed },
	{ "PawnMakeNoise", PawnMakeNoise },
	{ "OnRep_PlayerState", OnRep_PlayerState },
	{ "OnRep_Controller", OnRep_Controller },
	{ "IsPlayerControlled", IsPlayerControlled },
	{ "IsMoveInputIgnored", IsMoveInputIgnored },
	{ "IsLocallyControlled", IsLocallyControlled },
	{ "IsControlled", IsControlled },
	{ "GetPendingMovementInputVector", GetPendingMovementInputVector },
	{ "GetNavAgentLocation", GetNavAgentLocation },
	{ "GetMovementComponent", GetMovementComponent },
	{ "GetMovementBaseActor", GetMovementBaseActor },
	{ "GetLastMovementInputVector", GetLastMovementInputVector },
	{ "GetControlRotation", GetControlRotation },
	{ "GetController", GetController },
	{ "GetBaseAimRotation", GetBaseAimRotation },
	{ "DetachFromControllerPendingDestroy", DetachFromControllerPendingDestroy },
	{ "ConsumeMovementInputVector", ConsumeMovementInputVector },
	{ "AddMovementInput", AddMovementInput },
	{ "AddControllerYawInput", AddControllerYawInput },
	{ "AddControllerRollInput", AddControllerRollInput },
	{ "AddControllerPitchInput", AddControllerPitchInput },
	{ "Get_bUseControllerRotationPitch", Get_bUseControllerRotationPitch },
	{ "Set_bUseControllerRotationPitch", Set_bUseControllerRotationPitch },
	{ "Get_bUseControllerRotationYaw", Get_bUseControllerRotationYaw },
	{ "Set_bUseControllerRotationYaw", Set_bUseControllerRotationYaw },
	{ "Get_bUseControllerRotationRoll", Get_bUseControllerRotationRoll },
	{ "Set_bUseControllerRotationRoll", Set_bUseControllerRotationRoll },
	{ "Get_bCanAffectNavigationGeneration", Get_bCanAffectNavigationGeneration },
	{ "Get_BaseEyeHeight", Get_BaseEyeHeight },
	{ "Set_BaseEyeHeight", Set_BaseEyeHeight },
	{ "Get_AutoPossessPlayer", Get_AutoPossessPlayer },
	{ "Set_AutoPossessPlayer", Set_AutoPossessPlayer },
	{ "Get_AutoPossessAI", Get_AutoPossessAI },
	{ "Set_AutoPossessAI", Set_AutoPossessAI },
	{ "Get_AIControllerClass", Get_AIControllerClass },
	{ "Set_AIControllerClass", Set_AIControllerClass },
	{ "Get_PlayerState", Get_PlayerState },
	{ "Get_LastHitBy", Get_LastHitBy },
	{ "is_nil", wLua::LuaStatic::isnil },
	{ "__gc", wLua::LuaStatic::removeUClassFrameCache },
	{ NULL, NULL }
};

void Register(lua_State *InScriptContext)
{
	lua_newtable(InScriptContext);
	luaL_register(InScriptContext, NULL, Lib_Funcs);
	AzureHelpFuncs::AuxRegister(InScriptContext, "Pawn");
}
void SetMtLink(lua_State *InScriptContext)
{
	AzureHelpFuncs::AuxSetMtLink(InScriptContext, "Pawn", "Actor",USERDATATYPE_UOBJECT);
}

}