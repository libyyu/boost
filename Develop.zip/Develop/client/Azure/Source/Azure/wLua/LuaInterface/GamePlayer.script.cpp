#include "Azure.h"
#include "Utility/help_funcs.h"
#include "wLua/UObjectHeaders.h"
#include "GameLogic/Player/GamePlayer.h"
#include "../UClassHeaders.h"
#include "OVRLipSyncPlaybackActorComponent.h"
#include "AzureLuaIntegration.h"

namespace LuaGamePlayer
{
int32 GetFeetLocation2(lua_State*);
int32 GetNpcLookatOriginalYaw(lua_State*);

int32 UpdateBaseLocation(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"GamePlayer",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"GamePlayer must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool force;
	} Params;
	Params.force = !!(lua_toboolean(InScriptContext, 2));
#if UE_GAME
	AGamePlayer * This = (AGamePlayer *)Obj;
	This->UpdateBaseLocation(Params.force);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("UpdateBaseLocation"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(bool*)(params.GetStructMemory() + 0) = Params.force;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.force = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 TimelinePhysicsHitReactionFinishedCallback(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"GamePlayer",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"GamePlayer must be non-null"); lua_error(InScriptContext);  return 0;}
	UFunction* Function = Obj->FindFunctionChecked(TEXT("TimelinePhysicsHitReactionFinishedCallback"));
	if(!Function) { check(false); return 0;}
	Obj->ProcessEvent(Function, NULL);
	return 0;
}

int32 TimelinePhysicsHitReactionCallback(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"GamePlayer",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"GamePlayer must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float val;
	} Params;
	Params.val = (float)(luaL_checknumber(InScriptContext, 2));
	UFunction* Function = Obj->FindFunctionChecked(TEXT("TimelinePhysicsHitReactionCallback"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(float*)(params.GetStructMemory() + 0) = Params.val;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.val = *(float*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
	return 0;
}

int32 StopPhysicsHitReaction(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"GamePlayer",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"GamePlayer must be non-null"); lua_error(InScriptContext);  return 0;}
#if UE_GAME
	AGamePlayer * This = (AGamePlayer *)Obj;
	This->StopPhysicsHitReaction();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("StopPhysicsHitReaction"));
	if(!Function) { check(false); return 0;}
	Obj->ProcessEvent(Function, NULL);
#endif
	return 0;
}

int32 StopMyReplicatedMovement2(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"GamePlayer",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"GamePlayer must be non-null"); lua_error(InScriptContext);  return 0;}
#if UE_GAME
	AGamePlayer * This = (AGamePlayer *)Obj;
	This->StopMyReplicatedMovement2();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("StopMyReplicatedMovement2"));
	if(!Function) { check(false); return 0;}
	Obj->ProcessEvent(Function, NULL);
#endif
	return 0;
}

int32 StopMyReplicatedMovement(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"GamePlayer",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"GamePlayer must be non-null"); lua_error(InScriptContext);  return 0;}
#if UE_GAME
	AGamePlayer * This = (AGamePlayer *)Obj;
	This->StopMyReplicatedMovement();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("StopMyReplicatedMovement"));
	if(!Function) { check(false); return 0;}
	Obj->ProcessEvent(Function, NULL);
#endif
	return 0;
}

int32 StopAnimGetOnOrOffVehicle(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"GamePlayer",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"GamePlayer must be non-null"); lua_error(InScriptContext);  return 0;}
#if UE_GAME
	AGamePlayer * This = (AGamePlayer *)Obj;
	This->StopAnimGetOnOrOffVehicle();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("StopAnimGetOnOrOffVehicle"));
	if(!Function) { check(false); return 0;}
	Obj->ProcessEvent(Function, NULL);
#endif
	return 0;
}

int32 StartAnimGetOnVehicle(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"GamePlayer",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"GamePlayer must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FString anchorSocket;
		float anchorZOffset;
	} Params;
	Params.anchorSocket = UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 2));
	Params.anchorZOffset = (float)(luaL_checknumber(InScriptContext, 3));
#if UE_GAME
	AGamePlayer * This = (AGamePlayer *)Obj;
	This->StartAnimGetOnVehicle(Params.anchorSocket,Params.anchorZOffset);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("StartAnimGetOnVehicle"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FString*)(params.GetStructMemory() + 0) = Params.anchorSocket;
		*(float*)(params.GetStructMemory() + 16) = Params.anchorZOffset;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.anchorSocket = *(FString*)(params.GetStructMemory() + 0);
		Params.anchorZOffset = *(float*)(params.GetStructMemory() + 16);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 StartAnimGetOffVehicle(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"GamePlayer",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"GamePlayer must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FString anchorSocket;
	} Params;
	Params.anchorSocket = UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 2));
#if UE_GAME
	AGamePlayer * This = (AGamePlayer *)Obj;
	This->StartAnimGetOffVehicle(Params.anchorSocket);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("StartAnimGetOffVehicle"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FString*)(params.GetStructMemory() + 0) = Params.anchorSocket;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.anchorSocket = *(FString*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetReceiveInputWhenJump(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"GamePlayer",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"GamePlayer must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool bReceive;
	} Params;
	Params.bReceive = !!(lua_toboolean(InScriptContext, 2));
#if UE_GAME
	AGamePlayer * This = (AGamePlayer *)Obj;
	This->SetReceiveInputWhenJump(Params.bReceive);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetReceiveInputWhenJump"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(bool*)(params.GetStructMemory() + 0) = Params.bReceive;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.bReceive = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetRadialBlurWeight(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"GamePlayer",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"GamePlayer must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float weight;
	} Params;
	Params.weight = (float)(luaL_checknumber(InScriptContext, 2));
#if UE_GAME
	AGamePlayer * This = (AGamePlayer *)Obj;
	This->SetRadialBlurWeight(Params.weight);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetRadialBlurWeight"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(float*)(params.GetStructMemory() + 0) = Params.weight;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.weight = *(float*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetMoveMode(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"GamePlayer",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"GamePlayer must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		EGamePlayerMoveType mode;
	} Params;
	Params.mode = (EGamePlayerMoveType)(luaL_checkint(InScriptContext, 2));
#if UE_GAME
	AGamePlayer * This = (AGamePlayer *)Obj;
	This->SetMoveMode(Params.mode);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetMoveMode"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(EGamePlayerMoveType*)(params.GetStructMemory() + 0) = Params.mode;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.mode = *(EGamePlayerMoveType*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetMeshRoll(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"GamePlayer",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"GamePlayer must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float roll;
	} Params;
	Params.roll = (float)(luaL_checknumber(InScriptContext, 2));
#if UE_GAME
	AGamePlayer * This = (AGamePlayer *)Obj;
	This->SetMeshRoll(Params.roll);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetMeshRoll"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(float*)(params.GetStructMemory() + 0) = Params.roll;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.roll = *(float*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetJustDetached(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"GamePlayer",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"GamePlayer must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool b;
	} Params;
	Params.b = !!(lua_toboolean(InScriptContext, 2));
#if UE_GAME
	AGamePlayer * This = (AGamePlayer *)Obj;
	This->SetJustDetached(Params.b);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetJustDetached"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(bool*)(params.GetStructMemory() + 0) = Params.b;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.b = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetHeadMeshCom(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"GamePlayer",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"GamePlayer must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		USkeletalMeshComponent* _headMeshComp = nullptr;
	} Params;
	Params._headMeshComp = (USkeletalMeshComponent*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"SkeletalMeshComponent");;
#if UE_GAME
	AGamePlayer * This = (AGamePlayer *)Obj;
	This->SetHeadMeshCom(Params._headMeshComp);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetHeadMeshCom"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(USkeletalMeshComponent**)(params.GetStructMemory() + 0) = Params._headMeshComp;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params._headMeshComp = *(USkeletalMeshComponent**)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetFeetLocation(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"GamePlayer",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"GamePlayer must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float x;
		float y;
		float z;
	} Params;
	Params.x = (float)(luaL_checknumber(InScriptContext, 2));
	Params.y = (float)(luaL_checknumber(InScriptContext, 3));
	Params.z = (float)(luaL_checknumber(InScriptContext, 4));
#if UE_GAME
	AGamePlayer * This = (AGamePlayer *)Obj;
	This->SetFeetLocation(Params.x,Params.y,Params.z);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetFeetLocation"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(float*)(params.GetStructMemory() + 0) = Params.x;
		*(float*)(params.GetStructMemory() + 4) = Params.y;
		*(float*)(params.GetStructMemory() + 8) = Params.z;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.x = *(float*)(params.GetStructMemory() + 0);
		Params.y = *(float*)(params.GetStructMemory() + 4);
		Params.z = *(float*)(params.GetStructMemory() + 8);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetFeetLocalLocation(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"GamePlayer",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"GamePlayer must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FVector pos;
	} Params;
	Params.pos = (wLua::FLuaVector::Get(InScriptContext, 2));
#if UE_GAME
	AGamePlayer * This = (AGamePlayer *)Obj;
	This->SetFeetLocalLocation(Params.pos);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetFeetLocalLocation"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FVector*)(params.GetStructMemory() + 0) = Params.pos;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.pos = *(FVector*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetFaceTargetOffset(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"GamePlayer",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"GamePlayer must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FVector offset;
	} Params;
	Params.offset = (wLua::FLuaVector::Get(InScriptContext, 2));
#if UE_GAME
	AGamePlayer * This = (AGamePlayer *)Obj;
	This->SetFaceTargetOffset(Params.offset);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetFaceTargetOffset"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FVector*)(params.GetStructMemory() + 0) = Params.offset;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.offset = *(FVector*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetFaceTargetComponent(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"GamePlayer",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"GamePlayer must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FName face_socket_name;
		USceneComponent* face_target_comp = nullptr;
		FName face_target_socket_name;
		FName face_dir_socket_name;
	} Params;
	Params.face_socket_name = FName(UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 2)));
	Params.face_target_comp = (USceneComponent*)wLua::FLuaUtils::GetUObject(InScriptContext,3,"SceneComponent");;
	Params.face_target_socket_name = FName(UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 4)));
	Params.face_dir_socket_name = lua_isnoneornil(InScriptContext,5) ? FName(TEXT("")) : FName(UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 5)));
#if UE_GAME
	AGamePlayer * This = (AGamePlayer *)Obj;
	This->SetFaceTargetComponent(Params.face_socket_name,Params.face_target_comp,Params.face_target_socket_name,Params.face_dir_socket_name);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetFaceTargetComponent"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FName*)(params.GetStructMemory() + 0) = Params.face_socket_name;
		*(USceneComponent**)(params.GetStructMemory() + 16) = Params.face_target_comp;
		*(FName*)(params.GetStructMemory() + 24) = Params.face_target_socket_name;
		*(FName*)(params.GetStructMemory() + 36) = Params.face_dir_socket_name;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.face_socket_name = *(FName*)(params.GetStructMemory() + 0);
		Params.face_target_comp = *(USceneComponent**)(params.GetStructMemory() + 16);
		Params.face_target_socket_name = *(FName*)(params.GetStructMemory() + 24);
		Params.face_dir_socket_name = *(FName*)(params.GetStructMemory() + 36);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetEnableSwim(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"GamePlayer",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"GamePlayer must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool b;
	} Params;
	Params.b = !!(lua_toboolean(InScriptContext, 2));
#if UE_GAME
	AGamePlayer * This = (AGamePlayer *)Obj;
	This->SetEnableSwim(Params.b);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetEnableSwim"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(bool*)(params.GetStructMemory() + 0) = Params.b;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.b = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetCurrentJumpCount(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"GamePlayer",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"GamePlayer must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		int32 count;
	} Params;
	Params.count = (luaL_checkint(InScriptContext, 2));
#if UE_GAME
	AGamePlayer * This = (AGamePlayer *)Obj;
	This->SetCurrentJumpCount(Params.count);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetCurrentJumpCount"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(int32*)(params.GetStructMemory() + 0) = Params.count;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.count = *(int32*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetControlCarrier(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"GamePlayer",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"GamePlayer must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool b;
	} Params;
	Params.b = !!(lua_toboolean(InScriptContext, 2));
#if UE_GAME
	AGamePlayer * This = (AGamePlayer *)Obj;
	This->SetControlCarrier(Params.b);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetControlCarrier"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(bool*)(params.GetStructMemory() + 0) = Params.b;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.b = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetBaseComponent(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"GamePlayer",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"GamePlayer must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		UPrimitiveComponent* NewBase = nullptr;
		FName BoneName;
		bool bNotifyActor;
	} Params;
	Params.NewBase = (UPrimitiveComponent*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"PrimitiveComponent");;
	Params.BoneName = FName(UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 3)));
	Params.bNotifyActor = !!(lua_toboolean(InScriptContext, 4));
#if UE_GAME
	AGamePlayer * This = (AGamePlayer *)Obj;
	This->SetBaseComponent(Params.NewBase,Params.BoneName,Params.bNotifyActor);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetBaseComponent"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(UPrimitiveComponent**)(params.GetStructMemory() + 0) = Params.NewBase;
		*(FName*)(params.GetStructMemory() + 8) = Params.BoneName;
		*(bool*)(params.GetStructMemory() + 20) = Params.bNotifyActor;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.NewBase = *(UPrimitiveComponent**)(params.GetStructMemory() + 0);
		Params.BoneName = *(FName*)(params.GetStructMemory() + 8);
		Params.bNotifyActor = *(bool*)(params.GetStructMemory() + 20);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetAimRotator(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"GamePlayer",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"GamePlayer must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FRotator rotator;
	} Params;
	Params.rotator = (wLua::FLuaRotator::Get(InScriptContext, 2));
#if UE_GAME
	AGamePlayer * This = (AGamePlayer *)Obj;
	This->SetAimRotator(Params.rotator);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetAimRotator"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FRotator*)(params.GetStructMemory() + 0) = Params.rotator;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.rotator = *(FRotator*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 ResetToOriginalState(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"GamePlayer",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"GamePlayer must be non-null"); lua_error(InScriptContext);  return 0;}
#if UE_GAME
	AGamePlayer * This = (AGamePlayer *)Obj;
	This->ResetToOriginalState();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("ResetToOriginalState"));
	if(!Function) { check(false); return 0;}
	Obj->ProcessEvent(Function, NULL);
#endif
	return 0;
}

int32 ResetMeshLocalTransform(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"GamePlayer",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"GamePlayer must be non-null"); lua_error(InScriptContext);  return 0;}
#if UE_GAME
	AGamePlayer * This = (AGamePlayer *)Obj;
	This->ResetMeshLocalTransform();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("ResetMeshLocalTransform"));
	if(!Function) { check(false); return 0;}
	Obj->ProcessEvent(Function, NULL);
#endif
	return 0;
}

int32 RequestOVRLipSyncPlayBackComp(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"GamePlayer",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"GamePlayer must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		UOVRLipSyncPlaybackActorComponent* ReturnValue = nullptr;
	} Params;
#if UE_GAME
	AGamePlayer * This = (AGamePlayer *)Obj;
	Params.ReturnValue = This->RequestOVRLipSyncPlayBackComp();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("RequestOVRLipSyncPlayBackComp"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(UOVRLipSyncPlaybackActorComponent**)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 PhysicsHitReaction(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"GamePlayer",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"GamePlayer must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FVector HitLocation;
		FName HitBoneName;
		FVector Orientation;
		UCurveFloat* PunchCurve = nullptr;
	} Params;
	Params.HitLocation = (wLua::FLuaVector::Get(InScriptContext, 2));
	Params.HitBoneName = FName(UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 3)));
	Params.Orientation = (wLua::FLuaVector::Get(InScriptContext, 4));
	Params.PunchCurve = (UCurveFloat*)wLua::FLuaUtils::GetUObject(InScriptContext,5,"CurveFloat");;
#if UE_GAME
	AGamePlayer * This = (AGamePlayer *)Obj;
	This->PhysicsHitReaction(Params.HitLocation,Params.HitBoneName,Params.Orientation,Params.PunchCurve);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("PhysicsHitReaction"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FVector*)(params.GetStructMemory() + 0) = Params.HitLocation;
		*(FName*)(params.GetStructMemory() + 12) = Params.HitBoneName;
		*(FVector*)(params.GetStructMemory() + 24) = Params.Orientation;
		*(UCurveFloat**)(params.GetStructMemory() + 40) = Params.PunchCurve;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.HitLocation = *(FVector*)(params.GetStructMemory() + 0);
		Params.HitBoneName = *(FName*)(params.GetStructMemory() + 12);
		Params.Orientation = *(FVector*)(params.GetStructMemory() + 24);
		Params.PunchCurve = *(UCurveFloat**)(params.GetStructMemory() + 40);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 OVRLIP_OnVisemesStop(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"GamePlayer",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"GamePlayer must be non-null"); lua_error(InScriptContext);  return 0;}
	UFunction* Function = Obj->FindFunctionChecked(TEXT("OVRLIP_OnVisemesStop"));
	if(!Function) { check(false); return 0;}
	Obj->ProcessEvent(Function, NULL);
	return 0;
}

int32 OVRLIP_OnVisemesReady(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"GamePlayer",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"GamePlayer must be non-null"); lua_error(InScriptContext);  return 0;}
	UFunction* Function = Obj->FindFunctionChecked(TEXT("OVRLIP_OnVisemesReady"));
	if(!Function) { check(false); return 0;}
	Obj->ProcessEvent(Function, NULL);
	return 0;
}

int32 OnHostEndOverlap(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"GamePlayer",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"GamePlayer must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		UPrimitiveComponent* activatedComp = nullptr;
		AActor* otherActor = nullptr;
		UPrimitiveComponent* otherComp = nullptr;
		int32 otherBodyIndex;
	} Params;
	Params.activatedComp = (UPrimitiveComponent*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"PrimitiveComponent");;
	Params.otherActor = (AActor*)wLua::FLuaUtils::GetUObject(InScriptContext,3,"Actor");;
	Params.otherComp = (UPrimitiveComponent*)wLua::FLuaUtils::GetUObject(InScriptContext,4,"PrimitiveComponent");;
	Params.otherBodyIndex = (luaL_checkint(InScriptContext, 5));
#if UE_GAME
	AGamePlayer * This = (AGamePlayer *)Obj;
	This->OnHostEndOverlap(Params.activatedComp,Params.otherActor,Params.otherComp,Params.otherBodyIndex);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("OnHostEndOverlap"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(UPrimitiveComponent**)(params.GetStructMemory() + 0) = Params.activatedComp;
		*(AActor**)(params.GetStructMemory() + 8) = Params.otherActor;
		*(UPrimitiveComponent**)(params.GetStructMemory() + 16) = Params.otherComp;
		*(int32*)(params.GetStructMemory() + 24) = Params.otherBodyIndex;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.activatedComp = *(UPrimitiveComponent**)(params.GetStructMemory() + 0);
		Params.otherActor = *(AActor**)(params.GetStructMemory() + 8);
		Params.otherComp = *(UPrimitiveComponent**)(params.GetStructMemory() + 16);
		Params.otherBodyIndex = *(int32*)(params.GetStructMemory() + 24);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 NPC_PlaySubpartBreakEffect(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"GamePlayer",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"GamePlayer must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		int32 part_index;
		FVector pos;
		FVector impulse;
	} Params;
	Params.part_index = (luaL_checkint(InScriptContext, 2));
	Params.pos = (wLua::FLuaVector::Get(InScriptContext, 3));
	Params.impulse = (wLua::FLuaVector::Get(InScriptContext, 4));
#if UE_GAME
	AGamePlayer * This = (AGamePlayer *)Obj;
	This->NPC_PlaySubpartBreakEffect(Params.part_index,Params.pos,Params.impulse);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("NPC_PlaySubpartBreakEffect"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(int32*)(params.GetStructMemory() + 0) = Params.part_index;
		*(FVector*)(params.GetStructMemory() + 4) = Params.pos;
		*(FVector*)(params.GetStructMemory() + 16) = Params.impulse;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.part_index = *(int32*)(params.GetStructMemory() + 0);
		Params.pos = *(FVector*)(params.GetStructMemory() + 4);
		Params.impulse = *(FVector*)(params.GetStructMemory() + 16);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 NPC_CustomRagDollEffect(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"GamePlayer",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"GamePlayer must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FName boneName;
		FVector pos;
		FVector impulse;
	} Params;
	Params.boneName = FName(UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 2)));
	Params.pos = (wLua::FLuaVector::Get(InScriptContext, 3));
	Params.impulse = (wLua::FLuaVector::Get(InScriptContext, 4));
#if UE_GAME
	AGamePlayer * This = (AGamePlayer *)Obj;
	This->NPC_CustomRagDollEffect(Params.boneName,Params.pos,Params.impulse);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("NPC_CustomRagDollEffect"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FName*)(params.GetStructMemory() + 0) = Params.boneName;
		*(FVector*)(params.GetStructMemory() + 12) = Params.pos;
		*(FVector*)(params.GetStructMemory() + 24) = Params.impulse;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.boneName = *(FName*)(params.GetStructMemory() + 0);
		Params.pos = *(FVector*)(params.GetStructMemory() + 12);
		Params.impulse = *(FVector*)(params.GetStructMemory() + 24);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 IsReceiveInputWhenJump(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"GamePlayer",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"GamePlayer must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool ReturnValue;
	} Params;
#if UE_GAME
	AGamePlayer * This = (AGamePlayer *)Obj;
	Params.ReturnValue = This->IsReceiveInputWhenJump();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("IsReceiveInputWhenJump"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushboolean(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 IsPhysicsHitReactionEnabled(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"GamePlayer",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"GamePlayer must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool ReturnValue;
	} Params;
#if UE_GAME
	AGamePlayer * This = (AGamePlayer *)Obj;
	Params.ReturnValue = This->IsPhysicsHitReactionEnabled();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("IsPhysicsHitReactionEnabled"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushboolean(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 IsJustDetached(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"GamePlayer",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"GamePlayer must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool ReturnValue;
	} Params;
#if UE_GAME
	AGamePlayer * This = (AGamePlayer *)Obj;
	Params.ReturnValue = This->IsJustDetached();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("IsJustDetached"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushboolean(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 InitCGGamePlayer(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"GamePlayer",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"GamePlayer must be non-null"); lua_error(InScriptContext);  return 0;}
#if UE_GAME
	AGamePlayer * This = (AGamePlayer *)Obj;
	This->InitCGGamePlayer();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("InitCGGamePlayer"));
	if(!Function) { check(false); return 0;}
	Obj->ProcessEvent(Function, NULL);
#endif
	return 0;
}

int32 GetOnVehicle(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"GamePlayer",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"GamePlayer must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		AVehicleCharacter* _vehicle = nullptr;
		bool localControl;
		int32 pos;
	} Params;
	Params._vehicle = (AVehicleCharacter*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"VehicleCharacter");;
	Params.localControl = !!(lua_toboolean(InScriptContext, 3));
	Params.pos = (luaL_checkint(InScriptContext, 4));
#if UE_GAME
	AGamePlayer * This = (AGamePlayer *)Obj;
	This->GetOnVehicle(Params._vehicle,Params.localControl,Params.pos);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetOnVehicle"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(AVehicleCharacter**)(params.GetStructMemory() + 0) = Params._vehicle;
		*(bool*)(params.GetStructMemory() + 8) = Params.localControl;
		*(int32*)(params.GetStructMemory() + 12) = Params.pos;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params._vehicle = *(AVehicleCharacter**)(params.GetStructMemory() + 0);
		Params.localControl = *(bool*)(params.GetStructMemory() + 8);
		Params.pos = *(int32*)(params.GetStructMemory() + 12);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 GetOffVehicle(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"GamePlayer",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"GamePlayer must be non-null"); lua_error(InScriptContext);  return 0;}
#if UE_GAME
	AGamePlayer * This = (AGamePlayer *)Obj;
	This->GetOffVehicle();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetOffVehicle"));
	if(!Function) { check(false); return 0;}
	Obj->ProcessEvent(Function, NULL);
#endif
	return 0;
}

int32 GetBaseComponent(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"GamePlayer",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"GamePlayer must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		UPrimitiveComponent* ReturnValue = nullptr;
	} Params;
#if UE_GAME
	AGamePlayer * This = (AGamePlayer *)Obj;
	Params.ReturnValue = This->GetBaseComponent();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetBaseComponent"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(UPrimitiveComponent**)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 CancelFaceTarget(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"GamePlayer",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"GamePlayer must be non-null"); lua_error(InScriptContext);  return 0;}
#if UE_GAME
	AGamePlayer * This = (AGamePlayer *)Obj;
	This->CancelFaceTarget();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("CancelFaceTarget"));
	if(!Function) { check(false); return 0;}
	Obj->ProcessEvent(Function, NULL);
#endif
	return 0;
}

int32 CallLuaObjectFunction(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"GamePlayer",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"GamePlayer must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FString FunctionName;
		UObject* Param1 = nullptr;
		int32 Param2;
		FString Param3;
	} Params;
	Params.FunctionName = UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 2));
	Params.Param1 = (UObject*)wLua::FLuaUtils::GetUObject(InScriptContext,3,"Object");;
	Params.Param2 = (luaL_checkint(InScriptContext, 4));
	Params.Param3 = UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 5));
#if UE_GAME
	AGamePlayer * This = (AGamePlayer *)Obj;
	This->CallLuaObjectFunction(Params.FunctionName,Params.Param1,Params.Param2,Params.Param3);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("CallLuaObjectFunction"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FString*)(params.GetStructMemory() + 0) = Params.FunctionName;
		*(UObject**)(params.GetStructMemory() + 16) = Params.Param1;
		*(int32*)(params.GetStructMemory() + 24) = Params.Param2;
		*(FString*)(params.GetStructMemory() + 32) = Params.Param3;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.FunctionName = *(FString*)(params.GetStructMemory() + 0);
		Params.Param1 = *(UObject**)(params.GetStructMemory() + 16);
		Params.Param2 = *(int32*)(params.GetStructMemory() + 24);
		Params.Param3 = *(FString*)(params.GetStructMemory() + 32);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 Call_UpdateAnim_ForCPP(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"GamePlayer",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"GamePlayer must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float DeltaTime;
	} Params;
	Params.DeltaTime = (float)(luaL_checknumber(InScriptContext, 2));
#if UE_GAME
	AGamePlayer * This = (AGamePlayer *)Obj;
	This->Call_UpdateAnim_ForCPP(Params.DeltaTime);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("Call_UpdateAnim_ForCPP"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(float*)(params.GetStructMemory() + 0) = Params.DeltaTime;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.DeltaTime = *(float*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 Call_NPC_PlaySubpartBreakEffect(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"GamePlayer",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"GamePlayer must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		int32 part_index;
		FVector pos;
		FVector impulse;
		bool ReturnValue;
	} Params;
	Params.part_index = (luaL_checkint(InScriptContext, 2));
	Params.pos = (wLua::FLuaVector::Get(InScriptContext, 3));
	Params.impulse = (wLua::FLuaVector::Get(InScriptContext, 4));
#if UE_GAME
	AGamePlayer * This = (AGamePlayer *)Obj;
	Params.ReturnValue = This->Call_NPC_PlaySubpartBreakEffect(Params.part_index,Params.pos,Params.impulse);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("Call_NPC_PlaySubpartBreakEffect"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(int32*)(params.GetStructMemory() + 0) = Params.part_index;
		*(FVector*)(params.GetStructMemory() + 4) = Params.pos;
		*(FVector*)(params.GetStructMemory() + 16) = Params.impulse;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.part_index = *(int32*)(params.GetStructMemory() + 0);
		Params.pos = *(FVector*)(params.GetStructMemory() + 4);
		Params.impulse = *(FVector*)(params.GetStructMemory() + 16);
		Params.ReturnValue = *(bool*)(params.GetStructMemory() + 28);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushboolean(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 Call_NPC_CustomRagDollEffect_IfBlueprintOverride(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"GamePlayer",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"GamePlayer must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FName boneName;
		FVector pos;
		FVector impulse;
		bool ReturnValue;
	} Params;
	Params.boneName = FName(UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 2)));
	Params.pos = (wLua::FLuaVector::Get(InScriptContext, 3));
	Params.impulse = (wLua::FLuaVector::Get(InScriptContext, 4));
#if UE_GAME
	AGamePlayer * This = (AGamePlayer *)Obj;
	Params.ReturnValue = This->Call_NPC_CustomRagDollEffect_IfBlueprintOverride(Params.boneName,Params.pos,Params.impulse);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("Call_NPC_CustomRagDollEffect_IfBlueprintOverride"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FName*)(params.GetStructMemory() + 0) = Params.boneName;
		*(FVector*)(params.GetStructMemory() + 12) = Params.pos;
		*(FVector*)(params.GetStructMemory() + 24) = Params.impulse;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.boneName = *(FName*)(params.GetStructMemory() + 0);
		Params.pos = *(FVector*)(params.GetStructMemory() + 12);
		Params.impulse = *(FVector*)(params.GetStructMemory() + 24);
		Params.ReturnValue = *(bool*)(params.GetStructMemory() + 36);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushboolean(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 Get_enableFootIK(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"GamePlayer",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"GamePlayer must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AGamePlayer::StaticClass(), TEXT("enableFootIK"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = bool();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_getOnVehicleAdjustPosAnimCurveName(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"GamePlayer",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"GamePlayer must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AGamePlayer::StaticClass(), TEXT("getOnVehicleAdjustPosAnimCurveName"));
	if(!Property) { check(false); return 0;}
	FName PropertyValue = FName();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushstring(InScriptContext, TCHAR_TO_UTF8(*PropertyValue.ToString()));
	return 1;
}

int32 Set_getOnVehicleAdjustPosAnimCurveName(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"GamePlayer",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"GamePlayer must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AGamePlayer::StaticClass(), TEXT("getOnVehicleAdjustPosAnimCurveName"));
	if(!Property) { check(false); return 0;}
	FName PropertyValue = FName(UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 2)));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_getOffVehicleAdjustPosAnimCurveName(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"GamePlayer",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"GamePlayer must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AGamePlayer::StaticClass(), TEXT("getOffVehicleAdjustPosAnimCurveName"));
	if(!Property) { check(false); return 0;}
	FName PropertyValue = FName();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushstring(InScriptContext, TCHAR_TO_UTF8(*PropertyValue.ToString()));
	return 1;
}

int32 Set_getOffVehicleAdjustPosAnimCurveName(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"GamePlayer",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"GamePlayer must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AGamePlayer::StaticClass(), TEXT("getOffVehicleAdjustPosAnimCurveName"));
	if(!Property) { check(false); return 0;}
	FName PropertyValue = FName(UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 2)));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_CameraBoom(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"GamePlayer",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"GamePlayer must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AGamePlayer::StaticClass(), TEXT("CameraBoom"));
	if(!Property) { check(false); return 0;}
	UECCameraSpringArmComponent* PropertyValue;
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaUtils::ReturnUObject(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_FollowCamera(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"GamePlayer",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"GamePlayer must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AGamePlayer::StaticClass(), TEXT("FollowCamera"));
	if(!Property) { check(false); return 0;}
	UCameraComponent* PropertyValue;
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaUtils::ReturnUObject(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_m_isSwimmingSpeedup(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"GamePlayer",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"GamePlayer must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AGamePlayer::StaticClass(), TEXT("m_isSwimmingSpeedup"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = bool();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_m_isSwimmingSpeedup(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"GamePlayer",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"GamePlayer must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AGamePlayer::StaticClass(), TEXT("m_isSwimmingSpeedup"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_m_ImmersionDepth(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"GamePlayer",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"GamePlayer must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AGamePlayer::StaticClass(), TEXT("m_ImmersionDepth"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_m_ImmersionDepth(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"GamePlayer",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"GamePlayer must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AGamePlayer::StaticClass(), TEXT("m_ImmersionDepth"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_m_ImmersionDepthThreshold(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"GamePlayer",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"GamePlayer must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AGamePlayer::StaticClass(), TEXT("m_ImmersionDepthThreshold"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_m_ImmersionDepthThreshold(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"GamePlayer",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"GamePlayer must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AGamePlayer::StaticClass(), TEXT("m_ImmersionDepthThreshold"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_m_WaterHeightOffset(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"GamePlayer",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"GamePlayer must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AGamePlayer::StaticClass(), TEXT("m_WaterHeightOffset"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_m_WaterHeightOffset(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"GamePlayer",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"GamePlayer must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AGamePlayer::StaticClass(), TEXT("m_WaterHeightOffset"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_needSync3DRotator(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"GamePlayer",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"GamePlayer must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AGamePlayer::StaticClass(), TEXT("needSync3DRotator"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = bool();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_needSync3DRotator(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"GamePlayer",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"GamePlayer must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AGamePlayer::StaticClass(), TEXT("needSync3DRotator"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_PhysicsHitReactionBoneNames(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"GamePlayer",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"GamePlayer must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AGamePlayer::StaticClass(), TEXT("PhysicsHitReactionBoneNames"));
	if(!Property) { check(false); return 0;}
	TArray<FName> PropertyValue;
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	{lua_newtable(InScriptContext); int i = 1; for(auto It = PropertyValue.CreateConstIterator(); It; ++It,++i) {  lua_pushstring(InScriptContext, TCHAR_TO_UTF8(*(*It).ToString())); lua_rawseti(InScriptContext,-2,i);     }  }
	return 1;
}

int32 Set_PhysicsHitReactionBoneNames(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"GamePlayer",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"GamePlayer must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AGamePlayer::StaticClass(), TEXT("PhysicsHitReactionBoneNames"));
	if(!Property) { check(false); return 0;}
	TArray<FName> PropertyValue = [](lua_State * _InScriptContext){ TArray<FName> ret; lua_pushnil(_InScriptContext); while(lua_next(_InScriptContext,2)!=0){ FName item = FName(UTF8_TO_TCHAR(luaL_checkstring(_InScriptContext, -1))); ret.Add(item); lua_pop(_InScriptContext,1);  } return ret; }(InScriptContext);;
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_m_cancel_face_target_max_yaw(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"GamePlayer",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"GamePlayer must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AGamePlayer::StaticClass(), TEXT("m_cancel_face_target_max_yaw"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_m_cancel_face_target_max_yaw(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"GamePlayer",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"GamePlayer must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AGamePlayer::StaticClass(), TEXT("m_cancel_face_target_max_yaw"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_m_cancel_face_target_max_pitch(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"GamePlayer",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"GamePlayer must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AGamePlayer::StaticClass(), TEXT("m_cancel_face_target_max_pitch"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_m_cancel_face_target_max_pitch(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"GamePlayer",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"GamePlayer must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AGamePlayer::StaticClass(), TEXT("m_cancel_face_target_max_pitch"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_m_cancel_face_target_min_pitch(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"GamePlayer",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"GamePlayer must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AGamePlayer::StaticClass(), TEXT("m_cancel_face_target_min_pitch"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_m_cancel_face_target_min_pitch(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"GamePlayer",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"GamePlayer must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AGamePlayer::StaticClass(), TEXT("m_cancel_face_target_min_pitch"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_m_face_target_offset(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"GamePlayer",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"GamePlayer must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AGamePlayer::StaticClass(), TEXT("m_face_target_offset"));
	if(!Property) { check(false); return 0;}
	FVector PropertyValue = FVector();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaVector::Return(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_m_face_target_offset(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"GamePlayer",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"GamePlayer must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AGamePlayer::StaticClass(), TEXT("m_face_target_offset"));
	if(!Property) { check(false); return 0;}
	FVector PropertyValue = (wLua::FLuaVector::Get(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_faceTargetEyeFactor(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"GamePlayer",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"GamePlayer must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AGamePlayer::StaticClass(), TEXT("faceTargetEyeFactor"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_faceTargetEyeFactor(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"GamePlayer",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"GamePlayer must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AGamePlayer::StaticClass(), TEXT("faceTargetEyeFactor"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_faceTargetHeadYawThreshold(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"GamePlayer",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"GamePlayer must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AGamePlayer::StaticClass(), TEXT("faceTargetHeadYawThreshold"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_faceTargetHeadYawThreshold(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"GamePlayer",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"GamePlayer must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AGamePlayer::StaticClass(), TEXT("faceTargetHeadYawThreshold"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_faceTargetHeadPitchThreshold(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"GamePlayer",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"GamePlayer must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AGamePlayer::StaticClass(), TEXT("faceTargetHeadPitchThreshold"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_faceTargetHeadPitchThreshold(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"GamePlayer",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"GamePlayer must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AGamePlayer::StaticClass(), TEXT("faceTargetHeadPitchThreshold"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_m_UserFlags(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"GamePlayer",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"GamePlayer must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AGamePlayer::StaticClass(), TEXT("m_UserFlags"));
	if(!Property) { check(false); return 0;}
	FString PropertyValue;
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushstring(InScriptContext, TCHAR_TO_UTF8(*PropertyValue));
	return 1;
}

int32 New(lua_State* InScriptContext)
{
	UObject* Outer = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Object");
	FName Name = FName(luaL_checkstring(InScriptContext, 2));
	UObject* Obj = NewObject<AGamePlayer>(Outer, Name);
	wLua::FLuaUtils::ReturnUObject(InScriptContext,Obj);
	return 1;
}

int32 Destroy(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"GamePlayer",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"GamePlayer must be non-null"); lua_error(InScriptContext);  return 0;}
		AActor * actor = Cast<AActor>(Obj);
		actor->Destroy();
		userdata->flag |= wLua::LuaObjectFlag::DESTROYED;
		wLua::FLuaUtils::RemoveObjectReference(Obj, userdata->stamp, InScriptContext);
#ifdef AZURE_BUILD_WLUACHECK
		UE_LOG(LogAzure, Warning, TEXT("Destroy GamePlayer: %x userdata:%x   stamp:%x"),Obj,userdata,userdata->stamp);
#endif
	return 0;
}

int32 Class(lua_State* InScriptContext)
{
	UClass* Class = AGamePlayer::StaticClass();
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Class);
	return 1;
}

const luaL_Reg Lib_Funcs[] =
{
	{ "New", New },
	{ "Destroy", Destroy },
	{ "Class", Class },
	{ "UpdateBaseLocation", UpdateBaseLocation },
	{ "TimelinePhysicsHitReactionFinishedCallback", TimelinePhysicsHitReactionFinishedCallback },
	{ "TimelinePhysicsHitReactionCallback", TimelinePhysicsHitReactionCallback },
	{ "StopPhysicsHitReaction", StopPhysicsHitReaction },
	{ "StopMyReplicatedMovement2", StopMyReplicatedMovement2 },
	{ "StopMyReplicatedMovement", StopMyReplicatedMovement },
	{ "StopAnimGetOnOrOffVehicle", StopAnimGetOnOrOffVehicle },
	{ "StartAnimGetOnVehicle", StartAnimGetOnVehicle },
	{ "StartAnimGetOffVehicle", StartAnimGetOffVehicle },
	{ "SetReceiveInputWhenJump", SetReceiveInputWhenJump },
	{ "SetRadialBlurWeight", SetRadialBlurWeight },
	{ "SetMoveMode", SetMoveMode },
	{ "SetMeshRoll", SetMeshRoll },
	{ "SetJustDetached", SetJustDetached },
	{ "SetHeadMeshCom", SetHeadMeshCom },
	{ "SetFeetLocation", SetFeetLocation },
	{ "SetFeetLocalLocation", SetFeetLocalLocation },
	{ "SetFaceTargetOffset", SetFaceTargetOffset },
	{ "SetFaceTargetComponent", SetFaceTargetComponent },
	{ "SetEnableSwim", SetEnableSwim },
	{ "SetCurrentJumpCount", SetCurrentJumpCount },
	{ "SetControlCarrier", SetControlCarrier },
	{ "SetBaseComponent", SetBaseComponent },
	{ "SetAimRotator", SetAimRotator },
	{ "ResetToOriginalState", ResetToOriginalState },
	{ "ResetMeshLocalTransform", ResetMeshLocalTransform },
	{ "RequestOVRLipSyncPlayBackComp", RequestOVRLipSyncPlayBackComp },
	{ "PhysicsHitReaction", PhysicsHitReaction },
	{ "OVRLIP_OnVisemesStop", OVRLIP_OnVisemesStop },
	{ "OVRLIP_OnVisemesReady", OVRLIP_OnVisemesReady },
	{ "OnHostEndOverlap", OnHostEndOverlap },
	{ "NPC_PlaySubpartBreakEffect", NPC_PlaySubpartBreakEffect },
	{ "NPC_CustomRagDollEffect", NPC_CustomRagDollEffect },
	{ "IsReceiveInputWhenJump", IsReceiveInputWhenJump },
	{ "IsPhysicsHitReactionEnabled", IsPhysicsHitReactionEnabled },
	{ "IsJustDetached", IsJustDetached },
	{ "InitCGGamePlayer", InitCGGamePlayer },
	{ "GetOnVehicle", GetOnVehicle },
	{ "GetOffVehicle", GetOffVehicle },
	{ "GetBaseComponent", GetBaseComponent },
	{ "CancelFaceTarget", CancelFaceTarget },
	{ "CallLuaObjectFunction", CallLuaObjectFunction },
	{ "Call_UpdateAnim_ForCPP", Call_UpdateAnim_ForCPP },
	{ "Call_NPC_PlaySubpartBreakEffect", Call_NPC_PlaySubpartBreakEffect },
	{ "Call_NPC_CustomRagDollEffect_IfBlueprintOverride", Call_NPC_CustomRagDollEffect_IfBlueprintOverride },
	{ "Get_enableFootIK", Get_enableFootIK },
	{ "Get_getOnVehicleAdjustPosAnimCurveName", Get_getOnVehicleAdjustPosAnimCurveName },
	{ "Set_getOnVehicleAdjustPosAnimCurveName", Set_getOnVehicleAdjustPosAnimCurveName },
	{ "Get_getOffVehicleAdjustPosAnimCurveName", Get_getOffVehicleAdjustPosAnimCurveName },
	{ "Set_getOffVehicleAdjustPosAnimCurveName", Set_getOffVehicleAdjustPosAnimCurveName },
	{ "Get_CameraBoom", Get_CameraBoom },
	{ "Get_FollowCamera", Get_FollowCamera },
	{ "Get_m_isSwimmingSpeedup", Get_m_isSwimmingSpeedup },
	{ "Set_m_isSwimmingSpeedup", Set_m_isSwimmingSpeedup },
	{ "Get_m_ImmersionDepth", Get_m_ImmersionDepth },
	{ "Set_m_ImmersionDepth", Set_m_ImmersionDepth },
	{ "Get_m_ImmersionDepthThreshold", Get_m_ImmersionDepthThreshold },
	{ "Set_m_ImmersionDepthThreshold", Set_m_ImmersionDepthThreshold },
	{ "Get_m_WaterHeightOffset", Get_m_WaterHeightOffset },
	{ "Set_m_WaterHeightOffset", Set_m_WaterHeightOffset },
	{ "Get_needSync3DRotator", Get_needSync3DRotator },
	{ "Set_needSync3DRotator", Set_needSync3DRotator },
	{ "Get_PhysicsHitReactionBoneNames", Get_PhysicsHitReactionBoneNames },
	{ "Set_PhysicsHitReactionBoneNames", Set_PhysicsHitReactionBoneNames },
	{ "Get_m_cancel_face_target_max_yaw", Get_m_cancel_face_target_max_yaw },
	{ "Set_m_cancel_face_target_max_yaw", Set_m_cancel_face_target_max_yaw },
	{ "Get_m_cancel_face_target_max_pitch", Get_m_cancel_face_target_max_pitch },
	{ "Set_m_cancel_face_target_max_pitch", Set_m_cancel_face_target_max_pitch },
	{ "Get_m_cancel_face_target_min_pitch", Get_m_cancel_face_target_min_pitch },
	{ "Set_m_cancel_face_target_min_pitch", Set_m_cancel_face_target_min_pitch },
	{ "Get_m_face_target_offset", Get_m_face_target_offset },
	{ "Set_m_face_target_offset", Set_m_face_target_offset },
	{ "Get_faceTargetEyeFactor", Get_faceTargetEyeFactor },
	{ "Set_faceTargetEyeFactor", Set_faceTargetEyeFactor },
	{ "Get_faceTargetHeadYawThreshold", Get_faceTargetHeadYawThreshold },
	{ "Set_faceTargetHeadYawThreshold", Set_faceTargetHeadYawThreshold },
	{ "Get_faceTargetHeadPitchThreshold", Get_faceTargetHeadPitchThreshold },
	{ "Set_faceTargetHeadPitchThreshold", Set_faceTargetHeadPitchThreshold },
	{ "Get_m_UserFlags", Get_m_UserFlags },
	{ "GetFeetLocation", GetFeetLocation2 },
	{ "GetNpcLookatOriginalYaw", GetNpcLookatOriginalYaw },
	{ "is_nil", wLua::LuaStatic::isnil },
	{ "__gc", wLua::LuaStatic::removeUClassFrameCache },
	{ NULL, NULL }
};

void Register(lua_State *InScriptContext)
{
	lua_newtable(InScriptContext);
	luaL_register(InScriptContext, NULL, Lib_Funcs);
	AzureHelpFuncs::AuxRegister(InScriptContext, "GamePlayer");
}
void SetMtLink(lua_State *InScriptContext)
{
	AzureHelpFuncs::AuxSetMtLink(InScriptContext, "GamePlayer", "GameCharacterBase",USERDATATYPE_UOBJECT);
}

}