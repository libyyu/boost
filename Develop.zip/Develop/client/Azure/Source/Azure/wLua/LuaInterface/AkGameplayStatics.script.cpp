#include "Azure.h"
#include "Utility/help_funcs.h"
#include "wLua/UObjectHeaders.h"
#include "AkGameplayStatics.h"
#include "AzureLuaIntegration.h"

namespace LuaAkGameplayStatics
{
int32 LoadBank(lua_State*);
int32 LoadBankAsync(lua_State*);
int32 UnloadBank(lua_State*);
int32 PostEvent(lua_State*);
int32 AkComponentPostEvent(lua_State*);
int32 PostEventWithCallBack(lua_State*);
int32 GetRTPCValueEx(lua_State*);

int32 WakeupFromSuspend(lua_State* InScriptContext)
{
	UClass * Obj = UAkGameplayStatics::StaticClass(); 
#if UE_GAME
	UAkGameplayStatics::WakeupFromSuspend();
#else
	UFunction* Function = Obj->FindFunctionByName(TEXT("WakeupFromSuspend"));
	if(!Function) { check(false); return 0;}
	Obj->ProcessEvent(Function, NULL);
#endif
	return 0;
}

int32 UseReverbVolumes(lua_State* InScriptContext)
{
	UClass * Obj = UAkGameplayStatics::StaticClass(); 
	struct FDispatchParams
	{
		bool inUseReverbVolumes;
		AActor* Actor = nullptr;
	} Params;
	Params.inUseReverbVolumes = !!(lua_toboolean(InScriptContext, 1));
	Params.Actor = (AActor*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"Actor");;
#if UE_GAME
	UAkGameplayStatics::UseReverbVolumes(Params.inUseReverbVolumes,Params.Actor);
#else
	UFunction* Function = Obj->FindFunctionByName(TEXT("UseReverbVolumes"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(bool*)(params.GetStructMemory() + 0) = Params.inUseReverbVolumes;
		*(AActor**)(params.GetStructMemory() + 8) = Params.Actor;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.inUseReverbVolumes = *(bool*)(params.GetStructMemory() + 0);
		Params.Actor = *(AActor**)(params.GetStructMemory() + 8);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 UseEarlyReflections(lua_State* InScriptContext)
{
	UClass * Obj = UAkGameplayStatics::StaticClass(); 
	struct FDispatchParams
	{
		AActor* Actor = nullptr;
		UAkAuxBus* AuxBus = nullptr;
		int32 Order;
		float BusSendGain;
		float MaxPathLength;
		bool SpotReflectors;
		FString AuxBusName;
	} Params;
	Params.Actor = (AActor*)wLua::FLuaUtils::GetUObject(InScriptContext,1,"Actor");;
	Params.AuxBus = UAkGameplayStatics::UObject2UAkAuxBus(wLua::FLuaUtils::GetUObject(InScriptContext,2,"AkAuxBus"));;
	Params.Order = lua_isnoneornil(InScriptContext,3) ? int32(1) : (luaL_checkint(InScriptContext, 3));
	Params.BusSendGain = lua_isnoneornil(InScriptContext,4) ? float(1.000000) : (float)(luaL_checknumber(InScriptContext, 4));
	Params.MaxPathLength = lua_isnoneornil(InScriptContext,5) ? float(100000.000000) : (float)(luaL_checknumber(InScriptContext, 5));
	Params.SpotReflectors = lua_isnoneornil(InScriptContext,6) ? bool(false) : !!(lua_toboolean(InScriptContext, 6));
	Params.AuxBusName = lua_isnoneornil(InScriptContext,7) ? FString(TEXT("")) : UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 7));
#if UE_GAME
	UAkGameplayStatics::UseEarlyReflections(Params.Actor,Params.AuxBus,Params.Order,Params.BusSendGain,Params.MaxPathLength,Params.SpotReflectors,Params.AuxBusName);
#else
	UFunction* Function = Obj->FindFunctionByName(TEXT("UseEarlyReflections"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(AActor**)(params.GetStructMemory() + 0) = Params.Actor;
		*(UAkAuxBus**)(params.GetStructMemory() + 8) = Params.AuxBus;
		*(int32*)(params.GetStructMemory() + 16) = Params.Order;
		*(float*)(params.GetStructMemory() + 20) = Params.BusSendGain;
		*(float*)(params.GetStructMemory() + 24) = Params.MaxPathLength;
		*(bool*)(params.GetStructMemory() + 28) = Params.SpotReflectors;
		*(FString*)(params.GetStructMemory() + 32) = Params.AuxBusName;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.Actor = *(AActor**)(params.GetStructMemory() + 0);
		Params.AuxBus = *(UAkAuxBus**)(params.GetStructMemory() + 8);
		Params.Order = *(int32*)(params.GetStructMemory() + 16);
		Params.BusSendGain = *(float*)(params.GetStructMemory() + 20);
		Params.MaxPathLength = *(float*)(params.GetStructMemory() + 24);
		Params.SpotReflectors = *(bool*)(params.GetStructMemory() + 28);
		Params.AuxBusName = *(FString*)(params.GetStructMemory() + 32);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 Suspend(lua_State* InScriptContext)
{
	UClass * Obj = UAkGameplayStatics::StaticClass(); 
	struct FDispatchParams
	{
		bool bRenderAnyway;
	} Params;
	Params.bRenderAnyway = lua_isnoneornil(InScriptContext,1) ? bool(false) : !!(lua_toboolean(InScriptContext, 1));
#if UE_GAME
	UAkGameplayStatics::Suspend(Params.bRenderAnyway);
#else
	UFunction* Function = Obj->FindFunctionByName(TEXT("Suspend"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(bool*)(params.GetStructMemory() + 0) = Params.bRenderAnyway;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.bRenderAnyway = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 StopProfilerCapture(lua_State* InScriptContext)
{
	UClass * Obj = UAkGameplayStatics::StaticClass(); 
#if UE_GAME
	UAkGameplayStatics::StopProfilerCapture();
#else
	UFunction* Function = Obj->FindFunctionByName(TEXT("StopProfilerCapture"));
	if(!Function) { check(false); return 0;}
	Obj->ProcessEvent(Function, NULL);
#endif
	return 0;
}

int32 StopPlayingID(lua_State* InScriptContext)
{
	UClass * Obj = UAkGameplayStatics::StaticClass(); 
	struct FDispatchParams
	{
		int32 playingID;
		int32 transitionDuration;
		EAkCurveInterpolation akCurveInterpolation;
	} Params;
	Params.playingID = (luaL_checkint(InScriptContext, 1));
	Params.transitionDuration = lua_isnoneornil(InScriptContext,2) ? int32(0) : (luaL_checkint(InScriptContext, 2));
	Params.akCurveInterpolation = lua_isnoneornil(InScriptContext,3) ? EAkCurveInterpolation(EAkCurveInterpolation::Linear) : (EAkCurveInterpolation)(luaL_checkint(InScriptContext, 3));
#if UE_GAME
	UAkGameplayStatics::StopPlayingID(Params.playingID,Params.transitionDuration,Params.akCurveInterpolation);
#else
	UFunction* Function = Obj->FindFunctionByName(TEXT("StopPlayingID"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(int32*)(params.GetStructMemory() + 0) = Params.playingID;
		*(int32*)(params.GetStructMemory() + 4) = Params.transitionDuration;
		*(EAkCurveInterpolation*)(params.GetStructMemory() + 8) = Params.akCurveInterpolation;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.playingID = *(int32*)(params.GetStructMemory() + 0);
		Params.transitionDuration = *(int32*)(params.GetStructMemory() + 4);
		Params.akCurveInterpolation = *(EAkCurveInterpolation*)(params.GetStructMemory() + 8);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 StopOutputCapture(lua_State* InScriptContext)
{
	UClass * Obj = UAkGameplayStatics::StaticClass(); 
#if UE_GAME
	UAkGameplayStatics::StopOutputCapture();
#else
	UFunction* Function = Obj->FindFunctionByName(TEXT("StopOutputCapture"));
	if(!Function) { check(false); return 0;}
	Obj->ProcessEvent(Function, NULL);
#endif
	return 0;
}

int32 StopAllAmbientSounds(lua_State* InScriptContext)
{
	UClass * Obj = UAkGameplayStatics::StaticClass(); 
	struct FDispatchParams
	{
		UObject* WorldContextObject = nullptr;
	} Params;
	Params.WorldContextObject = (UObject*)wLua::FLuaUtils::GetUObject(InScriptContext,1,"Object");;
#if UE_GAME
	UAkGameplayStatics::StopAllAmbientSounds(Params.WorldContextObject);
#else
	UFunction* Function = Obj->FindFunctionByName(TEXT("StopAllAmbientSounds"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(UObject**)(params.GetStructMemory() + 0) = Params.WorldContextObject;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.WorldContextObject = *(UObject**)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 StopAll(lua_State* InScriptContext)
{
	UClass * Obj = UAkGameplayStatics::StaticClass(); 
#if UE_GAME
	UAkGameplayStatics::StopAll();
#else
	UFunction* Function = Obj->FindFunctionByName(TEXT("StopAll"));
	if(!Function) { check(false); return 0;}
	Obj->ProcessEvent(Function, NULL);
#endif
	return 0;
}

int32 StopActor(lua_State* InScriptContext)
{
	UClass * Obj = UAkGameplayStatics::StaticClass(); 
	struct FDispatchParams
	{
		AActor* Actor = nullptr;
	} Params;
	Params.Actor = (AActor*)wLua::FLuaUtils::GetUObject(InScriptContext,1,"Actor");;
#if UE_GAME
	UAkGameplayStatics::StopActor(Params.Actor);
#else
	UFunction* Function = Obj->FindFunctionByName(TEXT("StopActor"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(AActor**)(params.GetStructMemory() + 0) = Params.Actor;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.Actor = *(AActor**)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 StartProfilerCapture(lua_State* InScriptContext)
{
	UClass * Obj = UAkGameplayStatics::StaticClass(); 
	struct FDispatchParams
	{
		FString Filename;
	} Params;
	Params.Filename = UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 1));
#if UE_GAME
	UAkGameplayStatics::StartProfilerCapture(Params.Filename);
#else
	UFunction* Function = Obj->FindFunctionByName(TEXT("StartProfilerCapture"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FString*)(params.GetStructMemory() + 0) = Params.Filename;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.Filename = *(FString*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 StartOutputCapture(lua_State* InScriptContext)
{
	UClass * Obj = UAkGameplayStatics::StaticClass(); 
	struct FDispatchParams
	{
		FString Filename;
	} Params;
	Params.Filename = UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 1));
#if UE_GAME
	UAkGameplayStatics::StartOutputCapture(Params.Filename);
#else
	UFunction* Function = Obj->FindFunctionByName(TEXT("StartOutputCapture"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FString*)(params.GetStructMemory() + 0) = Params.Filename;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.Filename = *(FString*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 StartAllAmbientSounds(lua_State* InScriptContext)
{
	UClass * Obj = UAkGameplayStatics::StaticClass(); 
	struct FDispatchParams
	{
		UObject* WorldContextObject = nullptr;
	} Params;
	Params.WorldContextObject = (UObject*)wLua::FLuaUtils::GetUObject(InScriptContext,1,"Object");;
#if UE_GAME
	UAkGameplayStatics::StartAllAmbientSounds(Params.WorldContextObject);
#else
	UFunction* Function = Obj->FindFunctionByName(TEXT("StartAllAmbientSounds"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(UObject**)(params.GetStructMemory() + 0) = Params.WorldContextObject;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.WorldContextObject = *(UObject**)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SpawnAkComponentAtLocation(lua_State* InScriptContext)
{
	UClass * Obj = UAkGameplayStatics::StaticClass(); 
	struct FDispatchParams
	{
		UObject* WorldContextObject = nullptr;
		UAkAudioEvent* AkEvent = nullptr;
		UAkAuxBus* EarlyReflectionsBus = nullptr;
		FVector Location;
		FRotator Orientation;
		bool AutoPost;
		FString EventName;
		FString EarlyReflectionsBusName;
		bool AutoDestroy;
		UAkComponent* ReturnValue = nullptr;
	} Params;
	Params.WorldContextObject = (UObject*)wLua::FLuaUtils::GetUObject(InScriptContext,1,"Object");;
	Params.AkEvent = UAkGameplayStatics::UObject2UAkAudioEvent(wLua::FLuaUtils::GetUObject(InScriptContext,2,"AkAudioEvent"));;
	Params.EarlyReflectionsBus = UAkGameplayStatics::UObject2UAkAuxBus(wLua::FLuaUtils::GetUObject(InScriptContext,3,"AkAuxBus"));;
	Params.Location = (wLua::FLuaVector::Get(InScriptContext, 4));
	Params.Orientation = (wLua::FLuaRotator::Get(InScriptContext, 5));
	Params.AutoPost = !!(lua_toboolean(InScriptContext, 6));
	Params.EventName = UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 7));
	Params.EarlyReflectionsBusName = lua_isnoneornil(InScriptContext,8) ? FString(TEXT("")) : UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 8));
	Params.AutoDestroy = lua_isnoneornil(InScriptContext,9) ? bool(true) : !!(lua_toboolean(InScriptContext, 9));
#if UE_GAME
	Params.ReturnValue = UAkGameplayStatics::SpawnAkComponentAtLocation(Params.WorldContextObject,Params.AkEvent,Params.EarlyReflectionsBus,Params.Location,Params.Orientation,Params.AutoPost,Params.EventName,Params.EarlyReflectionsBusName,Params.AutoDestroy);
#else
	UFunction* Function = Obj->FindFunctionByName(TEXT("SpawnAkComponentAtLocation"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(UObject**)(params.GetStructMemory() + 0) = Params.WorldContextObject;
		*(UAkAudioEvent**)(params.GetStructMemory() + 8) = Params.AkEvent;
		*(UAkAuxBus**)(params.GetStructMemory() + 16) = Params.EarlyReflectionsBus;
		*(FVector*)(params.GetStructMemory() + 24) = Params.Location;
		*(FRotator*)(params.GetStructMemory() + 36) = Params.Orientation;
		*(bool*)(params.GetStructMemory() + 48) = Params.AutoPost;
		*(FString*)(params.GetStructMemory() + 56) = Params.EventName;
		*(FString*)(params.GetStructMemory() + 72) = Params.EarlyReflectionsBusName;
		*(bool*)(params.GetStructMemory() + 88) = Params.AutoDestroy;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.WorldContextObject = *(UObject**)(params.GetStructMemory() + 0);
		Params.AkEvent = *(UAkAudioEvent**)(params.GetStructMemory() + 8);
		Params.EarlyReflectionsBus = *(UAkAuxBus**)(params.GetStructMemory() + 16);
		Params.Location = *(FVector*)(params.GetStructMemory() + 24);
		Params.Orientation = *(FRotator*)(params.GetStructMemory() + 36);
		Params.AutoPost = *(bool*)(params.GetStructMemory() + 48);
		Params.EventName = *(FString*)(params.GetStructMemory() + 56);
		Params.EarlyReflectionsBusName = *(FString*)(params.GetStructMemory() + 72);
		Params.AutoDestroy = *(bool*)(params.GetStructMemory() + 88);
		Params.ReturnValue = *(UAkComponent**)(params.GetStructMemory() + 96);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaUtils::ReturnUObject(InScriptContext, UAkGameplayStatics::UAkComponent2UObject(Params.ReturnValue));
	return 1;
}

int32 SetSwitch(lua_State* InScriptContext)
{
	UClass * Obj = UAkGameplayStatics::StaticClass(); 
	struct FDispatchParams
	{
		FName SwitchGroup;
		FName SwitchState;
		AActor* Actor = nullptr;
	} Params;
	Params.SwitchGroup = FName(UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 1)));
	Params.SwitchState = FName(UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 2)));
	Params.Actor = (AActor*)wLua::FLuaUtils::GetUObject(InScriptContext,3,"Actor");;
#if UE_GAME
	UAkGameplayStatics::SetSwitch(Params.SwitchGroup,Params.SwitchState,Params.Actor);
#else
	UFunction* Function = Obj->FindFunctionByName(TEXT("SetSwitch"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FName*)(params.GetStructMemory() + 0) = Params.SwitchGroup;
		*(FName*)(params.GetStructMemory() + 12) = Params.SwitchState;
		*(AActor**)(params.GetStructMemory() + 24) = Params.Actor;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.SwitchGroup = *(FName*)(params.GetStructMemory() + 0);
		Params.SwitchState = *(FName*)(params.GetStructMemory() + 12);
		Params.Actor = *(AActor**)(params.GetStructMemory() + 24);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetState(lua_State* InScriptContext)
{
	UClass * Obj = UAkGameplayStatics::StaticClass(); 
	struct FDispatchParams
	{
		FName StateGroup;
		FName State;
	} Params;
	Params.StateGroup = FName(UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 1)));
	Params.State = FName(UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 2)));
#if UE_GAME
	UAkGameplayStatics::SetState(Params.StateGroup,Params.State);
#else
	UFunction* Function = Obj->FindFunctionByName(TEXT("SetState"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FName*)(params.GetStructMemory() + 0) = Params.StateGroup;
		*(FName*)(params.GetStructMemory() + 12) = Params.State;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.StateGroup = *(FName*)(params.GetStructMemory() + 0);
		Params.State = *(FName*)(params.GetStructMemory() + 12);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetSpeakerAngles(lua_State* InScriptContext)
{
	UClass * Obj = UAkGameplayStatics::StaticClass(); 
	struct FDispatchParams
	{
		TArray<float> SpeakerAngles;
		float HeightAngle;
		FString DeviceShareset;
	} Params;
	Params.SpeakerAngles = [](lua_State * _InScriptContext){ TArray<float> ret; lua_pushnil(_InScriptContext); while(lua_next(_InScriptContext,1)!=0){ float item = (float)(luaL_checknumber(_InScriptContext, -1)); ret.Add(item); lua_pop(_InScriptContext,1);  } return ret; }(InScriptContext);;
	Params.HeightAngle = (float)(luaL_checknumber(InScriptContext, 2));
	Params.DeviceShareset = lua_isnoneornil(InScriptContext,3) ? FString(TEXT("")) : UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 3));
#if UE_GAME
	UAkGameplayStatics::SetSpeakerAngles(Params.SpeakerAngles,Params.HeightAngle,Params.DeviceShareset);
#else
	UFunction* Function = Obj->FindFunctionByName(TEXT("SetSpeakerAngles"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(TArray<float>*)(params.GetStructMemory() + 0) = Params.SpeakerAngles;
		*(float*)(params.GetStructMemory() + 16) = Params.HeightAngle;
		*(FString*)(params.GetStructMemory() + 24) = Params.DeviceShareset;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.SpeakerAngles = *(TArray<float>*)(params.GetStructMemory() + 0);
		Params.HeightAngle = *(float*)(params.GetStructMemory() + 16);
		Params.DeviceShareset = *(FString*)(params.GetStructMemory() + 24);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetRTPCValue(lua_State* InScriptContext)
{
	UClass * Obj = UAkGameplayStatics::StaticClass(); 
	struct FDispatchParams
	{
		FName RTPC;
		float Value;
		int32 InterpolationTimeMs;
		AActor* Actor = nullptr;
	} Params;
	Params.RTPC = FName(UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 1)));
	Params.Value = (float)(luaL_checknumber(InScriptContext, 2));
	Params.InterpolationTimeMs = (luaL_checkint(InScriptContext, 3));
	Params.Actor = (AActor*)wLua::FLuaUtils::GetUObject(InScriptContext,4,"Actor");;
#if UE_GAME
	UAkGameplayStatics::SetRTPCValue(Params.RTPC,Params.Value,Params.InterpolationTimeMs,Params.Actor);
#else
	UFunction* Function = Obj->FindFunctionByName(TEXT("SetRTPCValue"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FName*)(params.GetStructMemory() + 0) = Params.RTPC;
		*(float*)(params.GetStructMemory() + 12) = Params.Value;
		*(int32*)(params.GetStructMemory() + 16) = Params.InterpolationTimeMs;
		*(AActor**)(params.GetStructMemory() + 24) = Params.Actor;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.RTPC = *(FName*)(params.GetStructMemory() + 0);
		Params.Value = *(float*)(params.GetStructMemory() + 12);
		Params.InterpolationTimeMs = *(int32*)(params.GetStructMemory() + 16);
		Params.Actor = *(AActor**)(params.GetStructMemory() + 24);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetPanningRule(lua_State* InScriptContext)
{
	UClass * Obj = UAkGameplayStatics::StaticClass(); 
	struct FDispatchParams
	{
		PanningRule PanRule;
	} Params;
	Params.PanRule = (PanningRule)(luaL_checkint(InScriptContext, 1));
#if UE_GAME
	UAkGameplayStatics::SetPanningRule(Params.PanRule);
#else
	UFunction* Function = Obj->FindFunctionByName(TEXT("SetPanningRule"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(PanningRule*)(params.GetStructMemory() + 0) = Params.PanRule;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.PanRule = *(PanningRule*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetOutputBusVolume(lua_State* InScriptContext)
{
	UClass * Obj = UAkGameplayStatics::StaticClass(); 
	struct FDispatchParams
	{
		float BusVolume;
		AActor* Actor = nullptr;
	} Params;
	Params.BusVolume = (float)(luaL_checknumber(InScriptContext, 1));
	Params.Actor = (AActor*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"Actor");;
#if UE_GAME
	UAkGameplayStatics::SetOutputBusVolume(Params.BusVolume,Params.Actor);
#else
	UFunction* Function = Obj->FindFunctionByName(TEXT("SetOutputBusVolume"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(float*)(params.GetStructMemory() + 0) = Params.BusVolume;
		*(AActor**)(params.GetStructMemory() + 8) = Params.Actor;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.BusVolume = *(float*)(params.GetStructMemory() + 0);
		Params.Actor = *(AActor**)(params.GetStructMemory() + 8);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetOcclusionScalingFactor(lua_State* InScriptContext)
{
	UClass * Obj = UAkGameplayStatics::StaticClass(); 
	struct FDispatchParams
	{
		float ScalingFactor;
	} Params;
	Params.ScalingFactor = (float)(luaL_checknumber(InScriptContext, 1));
#if UE_GAME
	UAkGameplayStatics::SetOcclusionScalingFactor(Params.ScalingFactor);
#else
	UFunction* Function = Obj->FindFunctionByName(TEXT("SetOcclusionScalingFactor"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(float*)(params.GetStructMemory() + 0) = Params.ScalingFactor;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ScalingFactor = *(float*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetOcclusionRefreshInterval(lua_State* InScriptContext)
{
	UClass * Obj = UAkGameplayStatics::StaticClass(); 
	struct FDispatchParams
	{
		float RefreshInterval;
		AActor* Actor = nullptr;
	} Params;
	Params.RefreshInterval = (float)(luaL_checknumber(InScriptContext, 1));
	Params.Actor = (AActor*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"Actor");;
#if UE_GAME
	UAkGameplayStatics::SetOcclusionRefreshInterval(Params.RefreshInterval,Params.Actor);
#else
	UFunction* Function = Obj->FindFunctionByName(TEXT("SetOcclusionRefreshInterval"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(float*)(params.GetStructMemory() + 0) = Params.RefreshInterval;
		*(AActor**)(params.GetStructMemory() + 8) = Params.Actor;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.RefreshInterval = *(float*)(params.GetStructMemory() + 0);
		Params.Actor = *(AActor**)(params.GetStructMemory() + 8);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetMultiplePositions(lua_State* InScriptContext)
{
	UClass * Obj = UAkGameplayStatics::StaticClass(); 
	struct FDispatchParams
	{
		UAkComponent* GameObjectAkComponent = nullptr;
		TArray<FTransform> Positions;
		AkMultiPositionType MultiPositionType;
	} Params;
	Params.GameObjectAkComponent = UAkGameplayStatics::UObject2UAkComponent(wLua::FLuaUtils::GetUObject(InScriptContext,1,"AkComponent"));;
	Params.Positions = [](lua_State * _InScriptContext){ TArray<FTransform> ret; lua_pushnil(_InScriptContext); while(lua_next(_InScriptContext,2)!=0){ FTransform item = (wLua::FLuaTransform::Get(_InScriptContext, -1)); ret.Add(item); lua_pop(_InScriptContext,1);  } return ret; }(InScriptContext);;
	Params.MultiPositionType = lua_isnoneornil(InScriptContext,3) ? AkMultiPositionType(AkMultiPositionType::MultiDirections) : (AkMultiPositionType)(luaL_checkint(InScriptContext, 3));
#if UE_GAME
	UAkGameplayStatics::SetMultiplePositions(Params.GameObjectAkComponent,Params.Positions,Params.MultiPositionType);
#else
	UFunction* Function = Obj->FindFunctionByName(TEXT("SetMultiplePositions"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(UAkComponent**)(params.GetStructMemory() + 0) = Params.GameObjectAkComponent;
		*(TArray<FTransform>*)(params.GetStructMemory() + 8) = Params.Positions;
		*(AkMultiPositionType*)(params.GetStructMemory() + 24) = Params.MultiPositionType;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.GameObjectAkComponent = *(UAkComponent**)(params.GetStructMemory() + 0);
		Params.Positions = *(TArray<FTransform>*)(params.GetStructMemory() + 8);
		Params.MultiPositionType = *(AkMultiPositionType*)(params.GetStructMemory() + 24);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetMultipleChannelEmitterPositions(lua_State* InScriptContext)
{
	UClass * Obj = UAkGameplayStatics::StaticClass(); 
	struct FDispatchParams
	{
		UAkComponent* GameObjectAkComponent = nullptr;
		TArray<AkChannelConfiguration> ChannelMasks;
		TArray<FTransform> Positions;
		AkMultiPositionType MultiPositionType;
	} Params;
	Params.GameObjectAkComponent = UAkGameplayStatics::UObject2UAkComponent(wLua::FLuaUtils::GetUObject(InScriptContext,1,"AkComponent"));;
	Params.ChannelMasks = [](lua_State * _InScriptContext){ TArray<AkChannelConfiguration> ret; lua_pushnil(_InScriptContext); while(lua_next(_InScriptContext,2)!=0){ AkChannelConfiguration item = (AkChannelConfiguration)(luaL_checkint(_InScriptContext, -1)); ret.Add(item); lua_pop(_InScriptContext,1);  } return ret; }(InScriptContext);;
	Params.Positions = [](lua_State * _InScriptContext){ TArray<FTransform> ret; lua_pushnil(_InScriptContext); while(lua_next(_InScriptContext,3)!=0){ FTransform item = (wLua::FLuaTransform::Get(_InScriptContext, -1)); ret.Add(item); lua_pop(_InScriptContext,1);  } return ret; }(InScriptContext);;
	Params.MultiPositionType = lua_isnoneornil(InScriptContext,4) ? AkMultiPositionType(AkMultiPositionType::MultiDirections) : (AkMultiPositionType)(luaL_checkint(InScriptContext, 4));
#if UE_GAME
	UAkGameplayStatics::SetMultipleChannelEmitterPositions(Params.GameObjectAkComponent,Params.ChannelMasks,Params.Positions,Params.MultiPositionType);
#else
	UFunction* Function = Obj->FindFunctionByName(TEXT("SetMultipleChannelEmitterPositions"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(UAkComponent**)(params.GetStructMemory() + 0) = Params.GameObjectAkComponent;
		*(TArray<AkChannelConfiguration>*)(params.GetStructMemory() + 8) = Params.ChannelMasks;
		*(TArray<FTransform>*)(params.GetStructMemory() + 24) = Params.Positions;
		*(AkMultiPositionType*)(params.GetStructMemory() + 40) = Params.MultiPositionType;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.GameObjectAkComponent = *(UAkComponent**)(params.GetStructMemory() + 0);
		Params.ChannelMasks = *(TArray<AkChannelConfiguration>*)(params.GetStructMemory() + 8);
		Params.Positions = *(TArray<FTransform>*)(params.GetStructMemory() + 24);
		Params.MultiPositionType = *(AkMultiPositionType*)(params.GetStructMemory() + 40);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetGameObjectOutputBusVolume(lua_State* InScriptContext)
{
	UClass * Obj = UAkGameplayStatics::StaticClass(); 
	struct FDispatchParams
	{
		UAkComponent* emitter = nullptr;
		UAkComponent* listener = nullptr;
		float controlValue;
		int32 ReturnValue;
	} Params;
	Params.emitter = UAkGameplayStatics::UObject2UAkComponent(wLua::FLuaUtils::GetUObject(InScriptContext,1,"AkComponent"));;
	Params.listener = UAkGameplayStatics::UObject2UAkComponent(wLua::FLuaUtils::GetUObject(InScriptContext,2,"AkComponent"));;
	Params.controlValue = (float)(luaL_checknumber(InScriptContext, 3));
#if UE_GAME
	Params.ReturnValue = UAkGameplayStatics::SetGameObjectOutputBusVolume(Params.emitter,Params.listener,Params.controlValue);
#else
	UFunction* Function = Obj->FindFunctionByName(TEXT("SetGameObjectOutputBusVolume"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(UAkComponent**)(params.GetStructMemory() + 0) = Params.emitter;
		*(UAkComponent**)(params.GetStructMemory() + 8) = Params.listener;
		*(float*)(params.GetStructMemory() + 16) = Params.controlValue;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.emitter = *(UAkComponent**)(params.GetStructMemory() + 0);
		Params.listener = *(UAkComponent**)(params.GetStructMemory() + 8);
		Params.controlValue = *(float*)(params.GetStructMemory() + 16);
		Params.ReturnValue = *(int32*)(params.GetStructMemory() + 20);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushinteger(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 SetBusConfig(lua_State* InScriptContext)
{
	UClass * Obj = UAkGameplayStatics::StaticClass(); 
	struct FDispatchParams
	{
		FString BusName;
		AkChannelConfiguration ChannelConfiguration;
	} Params;
	Params.BusName = UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 1));
	Params.ChannelConfiguration = (AkChannelConfiguration)(luaL_checkint(InScriptContext, 2));
#if UE_GAME
	UAkGameplayStatics::SetBusConfig(Params.BusName,Params.ChannelConfiguration);
#else
	UFunction* Function = Obj->FindFunctionByName(TEXT("SetBusConfig"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FString*)(params.GetStructMemory() + 0) = Params.BusName;
		*(AkChannelConfiguration*)(params.GetStructMemory() + 16) = Params.ChannelConfiguration;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.BusName = *(FString*)(params.GetStructMemory() + 0);
		Params.ChannelConfiguration = *(AkChannelConfiguration*)(params.GetStructMemory() + 16);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetAKCurrentLanguage(lua_State* InScriptContext)
{
	UClass * Obj = UAkGameplayStatics::StaticClass(); 
	struct FDispatchParams
	{
		FString language;
	} Params;
	Params.language = UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 1));
#if UE_GAME
	UAkGameplayStatics::SetAKCurrentLanguage(Params.language);
#else
	UFunction* Function = Obj->FindFunctionByName(TEXT("SetAKCurrentLanguage"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FString*)(params.GetStructMemory() + 0) = Params.language;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.language = *(FString*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetAkComponentPositionAndRotation(lua_State* InScriptContext)
{
	UClass * Obj = UAkGameplayStatics::StaticClass(); 
	struct FDispatchParams
	{
		UAkComponent* akComponent = nullptr;
		FVector position;
		FVector front;
		FVector up;
		int32 ReturnValue;
	} Params;
	Params.akComponent = UAkGameplayStatics::UObject2UAkComponent(wLua::FLuaUtils::GetUObject(InScriptContext,1,"AkComponent"));;
	Params.position = (wLua::FLuaVector::Get(InScriptContext, 2));
	Params.front = (wLua::FLuaVector::Get(InScriptContext, 3));
	Params.up = (wLua::FLuaVector::Get(InScriptContext, 4));
#if UE_GAME
	Params.ReturnValue = UAkGameplayStatics::SetAkComponentPositionAndRotation(Params.akComponent,Params.position,Params.front,Params.up);
#else
	UFunction* Function = Obj->FindFunctionByName(TEXT("SetAkComponentPositionAndRotation"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(UAkComponent**)(params.GetStructMemory() + 0) = Params.akComponent;
		*(FVector*)(params.GetStructMemory() + 8) = Params.position;
		*(FVector*)(params.GetStructMemory() + 20) = Params.front;
		*(FVector*)(params.GetStructMemory() + 32) = Params.up;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.akComponent = *(UAkComponent**)(params.GetStructMemory() + 0);
		Params.position = *(FVector*)(params.GetStructMemory() + 8);
		Params.front = *(FVector*)(params.GetStructMemory() + 20);
		Params.up = *(FVector*)(params.GetStructMemory() + 32);
		Params.ReturnValue = *(int32*)(params.GetStructMemory() + 44);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushinteger(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 SeekOnEvent(lua_State* InScriptContext)
{
	UClass * Obj = UAkGameplayStatics::StaticClass(); 
	struct FDispatchParams
	{
		FString eventName;
		AActor* actor = nullptr;
		float percent;
		bool bSeekToNearestMarker;
		int32 playingID;
		int32 ReturnValue;
	} Params;
	Params.eventName = UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 1));
	Params.actor = (AActor*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"Actor");;
	Params.percent = (float)(luaL_checknumber(InScriptContext, 3));
	Params.bSeekToNearestMarker = lua_isnoneornil(InScriptContext,4) ? bool(false) : !!(lua_toboolean(InScriptContext, 4));
	Params.playingID = lua_isnoneornil(InScriptContext,5) ? int32(0) : (luaL_checkint(InScriptContext, 5));
#if UE_GAME
	Params.ReturnValue = UAkGameplayStatics::SeekOnEvent(Params.eventName,Params.actor,Params.percent,Params.bSeekToNearestMarker,Params.playingID);
#else
	UFunction* Function = Obj->FindFunctionByName(TEXT("SeekOnEvent"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FString*)(params.GetStructMemory() + 0) = Params.eventName;
		*(AActor**)(params.GetStructMemory() + 16) = Params.actor;
		*(float*)(params.GetStructMemory() + 24) = Params.percent;
		*(bool*)(params.GetStructMemory() + 28) = Params.bSeekToNearestMarker;
		*(int32*)(params.GetStructMemory() + 32) = Params.playingID;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.eventName = *(FString*)(params.GetStructMemory() + 0);
		Params.actor = *(AActor**)(params.GetStructMemory() + 16);
		Params.percent = *(float*)(params.GetStructMemory() + 24);
		Params.bSeekToNearestMarker = *(bool*)(params.GetStructMemory() + 28);
		Params.playingID = *(int32*)(params.GetStructMemory() + 32);
		Params.ReturnValue = *(int32*)(params.GetStructMemory() + 36);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushinteger(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 RemoveDefaultListener(lua_State* InScriptContext)
{
	UClass * Obj = UAkGameplayStatics::StaticClass(); 
	struct FDispatchParams
	{
		AActor* actor = nullptr;
	} Params;
	Params.actor = (AActor*)wLua::FLuaUtils::GetUObject(InScriptContext,1,"Actor");;
#if UE_GAME
	UAkGameplayStatics::RemoveDefaultListener(Params.actor);
#else
	UFunction* Function = Obj->FindFunctionByName(TEXT("RemoveDefaultListener"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(AActor**)(params.GetStructMemory() + 0) = Params.actor;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.actor = *(AActor**)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 PostTrigger(lua_State* InScriptContext)
{
	UClass * Obj = UAkGameplayStatics::StaticClass(); 
	struct FDispatchParams
	{
		FName Trigger;
		AActor* Actor = nullptr;
	} Params;
	Params.Trigger = FName(UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 1)));
	Params.Actor = (AActor*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"Actor");;
#if UE_GAME
	UAkGameplayStatics::PostTrigger(Params.Trigger,Params.Actor);
#else
	UFunction* Function = Obj->FindFunctionByName(TEXT("PostTrigger"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FName*)(params.GetStructMemory() + 0) = Params.Trigger;
		*(AActor**)(params.GetStructMemory() + 16) = Params.Actor;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.Trigger = *(FName*)(params.GetStructMemory() + 0);
		Params.Actor = *(AActor**)(params.GetStructMemory() + 16);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 PostEventAtLocation(lua_State* InScriptContext)
{
	UClass * Obj = UAkGameplayStatics::StaticClass(); 
	struct FDispatchParams
	{
		UAkAudioEvent* AkEvent = nullptr;
		FVector Location;
		FRotator Orientation;
		FString EventName;
		UObject* WorldContextObject = nullptr;
		int32 ReturnValue;
	} Params;
	Params.AkEvent = UAkGameplayStatics::UObject2UAkAudioEvent(wLua::FLuaUtils::GetUObject(InScriptContext,1,"AkAudioEvent"));;
	Params.Location = (wLua::FLuaVector::Get(InScriptContext, 2));
	Params.Orientation = (wLua::FLuaRotator::Get(InScriptContext, 3));
	Params.EventName = UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 4));
	Params.WorldContextObject = (UObject*)wLua::FLuaUtils::GetUObject(InScriptContext,5,"Object");;
#if UE_GAME
	Params.ReturnValue = UAkGameplayStatics::PostEventAtLocation(Params.AkEvent,Params.Location,Params.Orientation,Params.EventName,Params.WorldContextObject);
#else
	UFunction* Function = Obj->FindFunctionByName(TEXT("PostEventAtLocation"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(UAkAudioEvent**)(params.GetStructMemory() + 0) = Params.AkEvent;
		*(FVector*)(params.GetStructMemory() + 8) = Params.Location;
		*(FRotator*)(params.GetStructMemory() + 20) = Params.Orientation;
		*(FString*)(params.GetStructMemory() + 32) = Params.EventName;
		*(UObject**)(params.GetStructMemory() + 48) = Params.WorldContextObject;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.AkEvent = *(UAkAudioEvent**)(params.GetStructMemory() + 0);
		Params.Location = *(FVector*)(params.GetStructMemory() + 8);
		Params.Orientation = *(FRotator*)(params.GetStructMemory() + 20);
		Params.EventName = *(FString*)(params.GetStructMemory() + 32);
		Params.WorldContextObject = *(UObject**)(params.GetStructMemory() + 48);
		Params.ReturnValue = *(int32*)(params.GetStructMemory() + 56);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushinteger(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 LoadInitBank(lua_State* InScriptContext)
{
	UClass * Obj = UAkGameplayStatics::StaticClass(); 
#if UE_GAME
	UAkGameplayStatics::LoadInitBank();
#else
	UFunction* Function = Obj->FindFunctionByName(TEXT("LoadInitBank"));
	if(!Function) { check(false); return 0;}
	Obj->ProcessEvent(Function, NULL);
#endif
	return 0;
}

int32 LoadBanks(lua_State* InScriptContext)
{
	UClass * Obj = UAkGameplayStatics::StaticClass(); 
	struct FDispatchParams
	{
		TArray<UAkAudioBank*> SoundBanks;
		bool SynchronizeSoundBanks;
	} Params;
	Params.SoundBanks = [](lua_State * _InScriptContext){ TArray<UAkAudioBank*> ret; lua_pushnil(_InScriptContext); while(lua_next(_InScriptContext,1)!=0){ UAkAudioBank* item = (UAkAudioBank*)wLua::FLuaUtils::GetUObject(_InScriptContext,-1,"AkAudioBank");; ret.Add(item); lua_pop(_InScriptContext,1);  } return ret; }(InScriptContext);;
	Params.SynchronizeSoundBanks = !!(lua_toboolean(InScriptContext, 2));
#if UE_GAME
	UAkGameplayStatics::LoadBanks(Params.SoundBanks,Params.SynchronizeSoundBanks);
#else
	UFunction* Function = Obj->FindFunctionByName(TEXT("LoadBanks"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(TArray<UAkAudioBank*>*)(params.GetStructMemory() + 0) = Params.SoundBanks;
		*(bool*)(params.GetStructMemory() + 16) = Params.SynchronizeSoundBanks;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.SoundBanks = *(TArray<UAkAudioBank*>*)(params.GetStructMemory() + 0);
		Params.SynchronizeSoundBanks = *(bool*)(params.GetStructMemory() + 16);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 IsGame(lua_State* InScriptContext)
{
	UClass * Obj = UAkGameplayStatics::StaticClass(); 
	struct FDispatchParams
	{
		UObject* WorldContextObject = nullptr;
		bool ReturnValue;
	} Params;
	Params.WorldContextObject = (UObject*)wLua::FLuaUtils::GetUObject(InScriptContext,1,"Object");;
#if UE_GAME
	Params.ReturnValue = UAkGameplayStatics::IsGame(Params.WorldContextObject);
#else
	UFunction* Function = Obj->FindFunctionByName(TEXT("IsGame"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(UObject**)(params.GetStructMemory() + 0) = Params.WorldContextObject;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.WorldContextObject = *(UObject**)(params.GetStructMemory() + 0);
		Params.ReturnValue = *(bool*)(params.GetStructMemory() + 8);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushboolean(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 IsEditor(lua_State* InScriptContext)
{
	UClass * Obj = UAkGameplayStatics::StaticClass(); 
	struct FDispatchParams
	{
		bool ReturnValue;
	} Params;
#if UE_GAME
	Params.ReturnValue = UAkGameplayStatics::IsEditor();
#else
	UFunction* Function = Obj->FindFunctionByName(TEXT("IsEditor"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushboolean(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetSpeakerAngles(lua_State* InScriptContext)
{
	UClass * Obj = UAkGameplayStatics::StaticClass(); 
	struct FDispatchParams
	{
		TArray<float> SpeakerAngles;
		float HeightAngle;
		FString DeviceShareset;
	} Params;
	Params.DeviceShareset = lua_isnoneornil(InScriptContext,3) ? FString(TEXT("")) : UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 3));
#if UE_GAME
	UAkGameplayStatics::GetSpeakerAngles(Params.SpeakerAngles,Params.HeightAngle,Params.DeviceShareset);
#else
	UFunction* Function = Obj->FindFunctionByName(TEXT("GetSpeakerAngles"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FString*)(params.GetStructMemory() + 24) = Params.DeviceShareset;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.SpeakerAngles = *(TArray<float>*)(params.GetStructMemory() + 0);
		Params.HeightAngle = *(float*)(params.GetStructMemory() + 16);
		Params.DeviceShareset = *(FString*)(params.GetStructMemory() + 24);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	{lua_newtable(InScriptContext); int i = 1; for(auto It = Params.SpeakerAngles.CreateConstIterator(); It; ++It,++i) {  lua_pushnumber(InScriptContext, (*It)); lua_rawseti(InScriptContext,-2,i);     }  }
	lua_pushnumber(InScriptContext, Params.HeightAngle);
	return 2;
}

int32 GetSourcePlayPosition(lua_State* InScriptContext)
{
	UClass * Obj = UAkGameplayStatics::StaticClass(); 
	struct FDispatchParams
	{
		int32 playingID;
		bool extrapolate;
		int32 ReturnValue;
	} Params;
	Params.playingID = (luaL_checkint(InScriptContext, 1));
	Params.extrapolate = lua_isnoneornil(InScriptContext,2) ? bool(true) : !!(lua_toboolean(InScriptContext, 2));
#if UE_GAME
	Params.ReturnValue = UAkGameplayStatics::GetSourcePlayPosition(Params.playingID,Params.extrapolate);
#else
	UFunction* Function = Obj->FindFunctionByName(TEXT("GetSourcePlayPosition"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(int32*)(params.GetStructMemory() + 0) = Params.playingID;
		*(bool*)(params.GetStructMemory() + 4) = Params.extrapolate;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.playingID = *(int32*)(params.GetStructMemory() + 0);
		Params.extrapolate = *(bool*)(params.GetStructMemory() + 4);
		Params.ReturnValue = *(int32*)(params.GetStructMemory() + 8);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushinteger(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetRTPCValue(lua_State* InScriptContext)
{
	UClass * Obj = UAkGameplayStatics::StaticClass(); 
	struct FDispatchParams
	{
		FName RTPC;
		int32 PlayingID;
		ERTPCValueType InputValueType;
		float Value;
		ERTPCValueType OutputValueType;
		AActor* Actor = nullptr;
	} Params;
	Params.RTPC = FName(UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 1)));
	Params.PlayingID = (luaL_checkint(InScriptContext, 2));
	Params.InputValueType = (ERTPCValueType)(luaL_checkint(InScriptContext, 3));
	Params.Actor = lua_isnoneornil(InScriptContext,6) ? nullptr : (AActor*)wLua::FLuaUtils::GetUObject(InScriptContext,6,"Actor");;
#if UE_GAME
	UAkGameplayStatics::GetRTPCValue(Params.RTPC,Params.PlayingID,Params.InputValueType,Params.Value,Params.OutputValueType,Params.Actor);
#else
	UFunction* Function = Obj->FindFunctionByName(TEXT("GetRTPCValue"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FName*)(params.GetStructMemory() + 0) = Params.RTPC;
		*(int32*)(params.GetStructMemory() + 12) = Params.PlayingID;
		*(ERTPCValueType*)(params.GetStructMemory() + 16) = Params.InputValueType;
		*(AActor**)(params.GetStructMemory() + 32) = Params.Actor;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.RTPC = *(FName*)(params.GetStructMemory() + 0);
		Params.PlayingID = *(int32*)(params.GetStructMemory() + 12);
		Params.InputValueType = *(ERTPCValueType*)(params.GetStructMemory() + 16);
		Params.Value = *(float*)(params.GetStructMemory() + 20);
		Params.OutputValueType = *(ERTPCValueType*)(params.GetStructMemory() + 24);
		Params.Actor = *(AActor**)(params.GetStructMemory() + 32);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushnumber(InScriptContext, Params.Value);
	lua_pushinteger(InScriptContext, (int)Params.OutputValueType);
	return 2;
}

int32 GetOcclusionScalingFactor(lua_State* InScriptContext)
{
	UClass * Obj = UAkGameplayStatics::StaticClass(); 
	struct FDispatchParams
	{
		float ReturnValue;
	} Params;
#if UE_GAME
	Params.ReturnValue = UAkGameplayStatics::GetOcclusionScalingFactor();
#else
	UFunction* Function = Obj->FindFunctionByName(TEXT("GetOcclusionScalingFactor"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(float*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushnumber(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetListener(lua_State* InScriptContext)
{
	UClass * Obj = UAkGameplayStatics::StaticClass(); 
	struct FDispatchParams
	{
		UAkComponent* ReturnValue = nullptr;
	} Params;
#if UE_GAME
	Params.ReturnValue = UAkGameplayStatics::GetListener();
#else
	UFunction* Function = Obj->FindFunctionByName(TEXT("GetListener"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(UAkComponent**)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaUtils::ReturnUObject(InScriptContext, UAkGameplayStatics::UAkComponent2UObject(Params.ReturnValue));
	return 1;
}

int32 GetAKCurrentLanguage(lua_State* InScriptContext)
{
	UClass * Obj = UAkGameplayStatics::StaticClass(); 
	struct FDispatchParams
	{
		FString ReturnValue;
	} Params;
#if UE_GAME
	Params.ReturnValue = UAkGameplayStatics::GetAKCurrentLanguage();
#else
	UFunction* Function = Obj->FindFunctionByName(TEXT("GetAKCurrentLanguage"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(FString*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushstring(InScriptContext, TCHAR_TO_UTF8(*Params.ReturnValue));
	return 1;
}

int32 GetAkComponent(lua_State* InScriptContext)
{
	UClass * Obj = UAkGameplayStatics::StaticClass(); 
	struct FDispatchParams
	{
		USceneComponent* AttachToComponent = nullptr;
		bool ComponentCreated;
		FName AttachPointName;
		FVector Location;
		TEnumAsByte<EAttachLocation::Type> LocationType;
		UAkComponent* ReturnValue = nullptr;
	} Params;
	Params.AttachToComponent = (USceneComponent*)wLua::FLuaUtils::GetUObject(InScriptContext,1,"SceneComponent");;
	Params.AttachPointName = lua_isnoneornil(InScriptContext,3) ? FName(TEXT("")) : FName(UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 3)));
	Params.Location = lua_isnoneornil(InScriptContext,4) ? FVector(0.f) : (wLua::FLuaVector::Get(InScriptContext, 4));
	Params.LocationType = lua_isnoneornil(InScriptContext,5) ? TEnumAsByte<EAttachLocation::Type>(EAttachLocation::Type::KeepRelativeOffset) : (TEnumAsByte<EAttachLocation::Type>)(luaL_checkint(InScriptContext, 5));
#if UE_GAME
	Params.ReturnValue = UAkGameplayStatics::GetAkComponent(Params.AttachToComponent,Params.ComponentCreated,Params.AttachPointName,Params.Location,Params.LocationType);
#else
	UFunction* Function = Obj->FindFunctionByName(TEXT("GetAkComponent"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(USceneComponent**)(params.GetStructMemory() + 0) = Params.AttachToComponent;
		*(FName*)(params.GetStructMemory() + 12) = Params.AttachPointName;
		*(FVector*)(params.GetStructMemory() + 24) = Params.Location;
		*(TEnumAsByte<EAttachLocation::Type>*)(params.GetStructMemory() + 36) = Params.LocationType;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.AttachToComponent = *(USceneComponent**)(params.GetStructMemory() + 0);
		Params.ComponentCreated = *(bool*)(params.GetStructMemory() + 8);
		Params.AttachPointName = *(FName*)(params.GetStructMemory() + 12);
		Params.Location = *(FVector*)(params.GetStructMemory() + 24);
		Params.LocationType = *(TEnumAsByte<EAttachLocation::Type>*)(params.GetStructMemory() + 36);
		Params.ReturnValue = *(UAkComponent**)(params.GetStructMemory() + 40);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaUtils::ReturnUObject(InScriptContext, UAkGameplayStatics::UAkComponent2UObject(Params.ReturnValue));
	lua_pushboolean(InScriptContext, Params.ComponentCreated);
	return 2;
}

int32 ExecuteActionOnPlayingID(lua_State* InScriptContext)
{
	UClass * Obj = UAkGameplayStatics::StaticClass(); 
	struct FDispatchParams
	{
		AkActionOnEventType ActionType;
		int32 PlayingID;
		int32 TransitionDuration;
		EAkCurveInterpolation FadeCurve;
	} Params;
	Params.ActionType = (AkActionOnEventType)(luaL_checkint(InScriptContext, 1));
	Params.PlayingID = (luaL_checkint(InScriptContext, 2));
	Params.TransitionDuration = lua_isnoneornil(InScriptContext,3) ? int32(0) : (luaL_checkint(InScriptContext, 3));
	Params.FadeCurve = lua_isnoneornil(InScriptContext,4) ? EAkCurveInterpolation(EAkCurveInterpolation::Linear) : (EAkCurveInterpolation)(luaL_checkint(InScriptContext, 4));
#if UE_GAME
	UAkGameplayStatics::ExecuteActionOnPlayingID(Params.ActionType,Params.PlayingID,Params.TransitionDuration,Params.FadeCurve);
#else
	UFunction* Function = Obj->FindFunctionByName(TEXT("ExecuteActionOnPlayingID"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(AkActionOnEventType*)(params.GetStructMemory() + 0) = Params.ActionType;
		*(int32*)(params.GetStructMemory() + 4) = Params.PlayingID;
		*(int32*)(params.GetStructMemory() + 8) = Params.TransitionDuration;
		*(EAkCurveInterpolation*)(params.GetStructMemory() + 12) = Params.FadeCurve;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ActionType = *(AkActionOnEventType*)(params.GetStructMemory() + 0);
		Params.PlayingID = *(int32*)(params.GetStructMemory() + 4);
		Params.TransitionDuration = *(int32*)(params.GetStructMemory() + 8);
		Params.FadeCurve = *(EAkCurveInterpolation*)(params.GetStructMemory() + 12);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 ExecuteActionOnEventByName(lua_State* InScriptContext)
{
	UClass * Obj = UAkGameplayStatics::StaticClass(); 
	struct FDispatchParams
	{
		FString eventName;
		AkActionOnEventType ActionType;
		AActor* Actor = nullptr;
		int32 TransitionDuration;
		EAkCurveInterpolation FadeCurve;
		int32 PlayingID;
	} Params;
	Params.eventName = UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 1));
	Params.ActionType = (AkActionOnEventType)(luaL_checkint(InScriptContext, 2));
	Params.Actor = (AActor*)wLua::FLuaUtils::GetUObject(InScriptContext,3,"Actor");;
	Params.TransitionDuration = lua_isnoneornil(InScriptContext,4) ? int32(0) : (luaL_checkint(InScriptContext, 4));
	Params.FadeCurve = lua_isnoneornil(InScriptContext,5) ? EAkCurveInterpolation(EAkCurveInterpolation::Linear) : (EAkCurveInterpolation)(luaL_checkint(InScriptContext, 5));
	Params.PlayingID = lua_isnoneornil(InScriptContext,6) ? int32(0) : (luaL_checkint(InScriptContext, 6));
#if UE_GAME
	UAkGameplayStatics::ExecuteActionOnEventByName(Params.eventName,Params.ActionType,Params.Actor,Params.TransitionDuration,Params.FadeCurve,Params.PlayingID);
#else
	UFunction* Function = Obj->FindFunctionByName(TEXT("ExecuteActionOnEventByName"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FString*)(params.GetStructMemory() + 0) = Params.eventName;
		*(AkActionOnEventType*)(params.GetStructMemory() + 16) = Params.ActionType;
		*(AActor**)(params.GetStructMemory() + 24) = Params.Actor;
		*(int32*)(params.GetStructMemory() + 32) = Params.TransitionDuration;
		*(EAkCurveInterpolation*)(params.GetStructMemory() + 36) = Params.FadeCurve;
		*(int32*)(params.GetStructMemory() + 40) = Params.PlayingID;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.eventName = *(FString*)(params.GetStructMemory() + 0);
		Params.ActionType = *(AkActionOnEventType*)(params.GetStructMemory() + 16);
		Params.Actor = *(AActor**)(params.GetStructMemory() + 24);
		Params.TransitionDuration = *(int32*)(params.GetStructMemory() + 32);
		Params.FadeCurve = *(EAkCurveInterpolation*)(params.GetStructMemory() + 36);
		Params.PlayingID = *(int32*)(params.GetStructMemory() + 40);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 ExecuteActionOnEvent(lua_State* InScriptContext)
{
	UClass * Obj = UAkGameplayStatics::StaticClass(); 
	struct FDispatchParams
	{
		UAkAudioEvent* AkEvent = nullptr;
		AkActionOnEventType ActionType;
		AActor* Actor = nullptr;
		int32 TransitionDuration;
		EAkCurveInterpolation FadeCurve;
		int32 PlayingID;
	} Params;
	Params.AkEvent = UAkGameplayStatics::UObject2UAkAudioEvent(wLua::FLuaUtils::GetUObject(InScriptContext,1,"AkAudioEvent"));;
	Params.ActionType = (AkActionOnEventType)(luaL_checkint(InScriptContext, 2));
	Params.Actor = (AActor*)wLua::FLuaUtils::GetUObject(InScriptContext,3,"Actor");;
	Params.TransitionDuration = lua_isnoneornil(InScriptContext,4) ? int32(0) : (luaL_checkint(InScriptContext, 4));
	Params.FadeCurve = lua_isnoneornil(InScriptContext,5) ? EAkCurveInterpolation(EAkCurveInterpolation::Linear) : (EAkCurveInterpolation)(luaL_checkint(InScriptContext, 5));
	Params.PlayingID = lua_isnoneornil(InScriptContext,6) ? int32(0) : (luaL_checkint(InScriptContext, 6));
#if UE_GAME
	UAkGameplayStatics::ExecuteActionOnEvent(Params.AkEvent,Params.ActionType,Params.Actor,Params.TransitionDuration,Params.FadeCurve,Params.PlayingID);
#else
	UFunction* Function = Obj->FindFunctionByName(TEXT("ExecuteActionOnEvent"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(UAkAudioEvent**)(params.GetStructMemory() + 0) = Params.AkEvent;
		*(AkActionOnEventType*)(params.GetStructMemory() + 8) = Params.ActionType;
		*(AActor**)(params.GetStructMemory() + 16) = Params.Actor;
		*(int32*)(params.GetStructMemory() + 24) = Params.TransitionDuration;
		*(EAkCurveInterpolation*)(params.GetStructMemory() + 28) = Params.FadeCurve;
		*(int32*)(params.GetStructMemory() + 32) = Params.PlayingID;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.AkEvent = *(UAkAudioEvent**)(params.GetStructMemory() + 0);
		Params.ActionType = *(AkActionOnEventType*)(params.GetStructMemory() + 8);
		Params.Actor = *(AActor**)(params.GetStructMemory() + 16);
		Params.TransitionDuration = *(int32*)(params.GetStructMemory() + 24);
		Params.FadeCurve = *(EAkCurveInterpolation*)(params.GetStructMemory() + 28);
		Params.PlayingID = *(int32*)(params.GetStructMemory() + 32);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 ClearBanks(lua_State* InScriptContext)
{
	UClass * Obj = UAkGameplayStatics::StaticClass(); 
#if UE_GAME
	UAkGameplayStatics::ClearBanks();
#else
	UFunction* Function = Obj->FindFunctionByName(TEXT("ClearBanks"));
	if(!Function) { check(false); return 0;}
	Obj->ProcessEvent(Function, NULL);
#endif
	return 0;
}

int32 AzureStartupWwise(lua_State* InScriptContext)
{
	UClass * Obj = UAkGameplayStatics::StaticClass(); 
#if UE_GAME
	UAkGameplayStatics::AzureStartupWwise();
#else
	UFunction* Function = Obj->FindFunctionByName(TEXT("AzureStartupWwise"));
	if(!Function) { check(false); return 0;}
	Obj->ProcessEvent(Function, NULL);
#endif
	return 0;
}

int32 AzureShutdownWwise(lua_State* InScriptContext)
{
	UClass * Obj = UAkGameplayStatics::StaticClass(); 
#if UE_GAME
	UAkGameplayStatics::AzureShutdownWwise();
#else
	UFunction* Function = Obj->FindFunctionByName(TEXT("AzureShutdownWwise"));
	if(!Function) { check(false); return 0;}
	Obj->ProcessEvent(Function, NULL);
#endif
	return 0;
}

int32 AddOutputCaptureMarker(lua_State* InScriptContext)
{
	UClass * Obj = UAkGameplayStatics::StaticClass(); 
	struct FDispatchParams
	{
		FString MarkerText;
	} Params;
	Params.MarkerText = UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 1));
#if UE_GAME
	UAkGameplayStatics::AddOutputCaptureMarker(Params.MarkerText);
#else
	UFunction* Function = Obj->FindFunctionByName(TEXT("AddOutputCaptureMarker"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FString*)(params.GetStructMemory() + 0) = Params.MarkerText;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.MarkerText = *(FString*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 AddListener(lua_State* InScriptContext)
{
	UClass * Obj = UAkGameplayStatics::StaticClass(); 
	struct FDispatchParams
	{
		USceneComponent* component = nullptr;
		FName listenerName;
	} Params;
	Params.component = (USceneComponent*)wLua::FLuaUtils::GetUObject(InScriptContext,1,"SceneComponent");;
	Params.listenerName = lua_isnoneornil(InScriptContext,2) ? FName(TEXT("AkAudioListener")) : FName(UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 2)));
#if UE_GAME
	UAkGameplayStatics::AddListener(Params.component,Params.listenerName);
#else
	UFunction* Function = Obj->FindFunctionByName(TEXT("AddListener"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(USceneComponent**)(params.GetStructMemory() + 0) = Params.component;
		*(FName*)(params.GetStructMemory() + 8) = Params.listenerName;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.component = *(USceneComponent**)(params.GetStructMemory() + 0);
		Params.listenerName = *(FName*)(params.GetStructMemory() + 8);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 AddDefaultListener(lua_State* InScriptContext)
{
	UClass * Obj = UAkGameplayStatics::StaticClass(); 
	struct FDispatchParams
	{
		AActor* actor = nullptr;
		FName listenerName;
	} Params;
	Params.actor = (AActor*)wLua::FLuaUtils::GetUObject(InScriptContext,1,"Actor");;
	Params.listenerName = lua_isnoneornil(InScriptContext,2) ? FName(TEXT("AkAudioListener")) : FName(UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 2)));
#if UE_GAME
	UAkGameplayStatics::AddDefaultListener(Params.actor,Params.listenerName);
#else
	UFunction* Function = Obj->FindFunctionByName(TEXT("AddDefaultListener"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(AActor**)(params.GetStructMemory() + 0) = Params.actor;
		*(FName*)(params.GetStructMemory() + 8) = Params.listenerName;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.actor = *(AActor**)(params.GetStructMemory() + 0);
		Params.listenerName = *(FName*)(params.GetStructMemory() + 8);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 New(lua_State* InScriptContext)
{
	UObject* Outer = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Object");
	FName Name = FName(luaL_checkstring(InScriptContext, 2));
	UObject* Obj = NewObject<UAkGameplayStatics>(Outer, Name);
	wLua::FLuaUtils::ReturnUObject(InScriptContext,Obj);
	return 1;
}

int32 Destroy(lua_State* InScriptContext)
{
	return 0;
}

int32 Class(lua_State* InScriptContext)
{
	UClass* Class = UAkGameplayStatics::StaticClass();
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Class);
	return 1;
}

const luaL_Reg Lib_Funcs[] =
{
	{ "New", New },
	{ "Destroy", Destroy },
	{ "Class", Class },
	{ "WakeupFromSuspend", WakeupFromSuspend },
	{ "UseReverbVolumes", UseReverbVolumes },
	{ "UseEarlyReflections", UseEarlyReflections },
	{ "Suspend", Suspend },
	{ "StopProfilerCapture", StopProfilerCapture },
	{ "StopPlayingID", StopPlayingID },
	{ "StopOutputCapture", StopOutputCapture },
	{ "StopAllAmbientSounds", StopAllAmbientSounds },
	{ "StopAll", StopAll },
	{ "StopActor", StopActor },
	{ "StartProfilerCapture", StartProfilerCapture },
	{ "StartOutputCapture", StartOutputCapture },
	{ "StartAllAmbientSounds", StartAllAmbientSounds },
	{ "SpawnAkComponentAtLocation", SpawnAkComponentAtLocation },
	{ "SetSwitch", SetSwitch },
	{ "SetState", SetState },
	{ "SetSpeakerAngles", SetSpeakerAngles },
	{ "SetRTPCValue", SetRTPCValue },
	{ "SetPanningRule", SetPanningRule },
	{ "SetOutputBusVolume", SetOutputBusVolume },
	{ "SetOcclusionScalingFactor", SetOcclusionScalingFactor },
	{ "SetOcclusionRefreshInterval", SetOcclusionRefreshInterval },
	{ "SetMultiplePositions", SetMultiplePositions },
	{ "SetMultipleChannelEmitterPositions", SetMultipleChannelEmitterPositions },
	{ "SetGameObjectOutputBusVolume", SetGameObjectOutputBusVolume },
	{ "SetBusConfig", SetBusConfig },
	{ "SetAKCurrentLanguage", SetAKCurrentLanguage },
	{ "SetAkComponentPositionAndRotation", SetAkComponentPositionAndRotation },
	{ "SeekOnEvent", SeekOnEvent },
	{ "RemoveDefaultListener", RemoveDefaultListener },
	{ "PostTrigger", PostTrigger },
	{ "PostEventAtLocation", PostEventAtLocation },
	{ "LoadInitBank", LoadInitBank },
	{ "LoadBanks", LoadBanks },
	{ "IsGame", IsGame },
	{ "IsEditor", IsEditor },
	{ "GetSpeakerAngles", GetSpeakerAngles },
	{ "GetSourcePlayPosition", GetSourcePlayPosition },
	{ "GetRTPCValue", GetRTPCValue },
	{ "GetOcclusionScalingFactor", GetOcclusionScalingFactor },
	{ "GetListener", GetListener },
	{ "GetAKCurrentLanguage", GetAKCurrentLanguage },
	{ "GetAkComponent", GetAkComponent },
	{ "ExecuteActionOnPlayingID", ExecuteActionOnPlayingID },
	{ "ExecuteActionOnEventByName", ExecuteActionOnEventByName },
	{ "ExecuteActionOnEvent", ExecuteActionOnEvent },
	{ "ClearBanks", ClearBanks },
	{ "AzureStartupWwise", AzureStartupWwise },
	{ "AzureShutdownWwise", AzureShutdownWwise },
	{ "AddOutputCaptureMarker", AddOutputCaptureMarker },
	{ "AddListener", AddListener },
	{ "AddDefaultListener", AddDefaultListener },
	{ "LoadBank", LoadBank },
	{ "LoadBankAsync", LoadBankAsync },
	{ "UnloadBank", UnloadBank },
	{ "PostEvent", PostEvent },
	{ "AkComponentPostEvent", AkComponentPostEvent },
	{ "PostEventWithCallBack", PostEventWithCallBack },
	{ "GetRTPCValueEx", GetRTPCValueEx },
	{ "is_nil", wLua::LuaStatic::isnil },
	{ "__gc", wLua::LuaStatic::removeUClassFrameCache },
	{ NULL, NULL }
};

void Register(lua_State *InScriptContext)
{
	lua_newtable(InScriptContext);
	luaL_register(InScriptContext, NULL, Lib_Funcs);
	AzureHelpFuncs::AuxRegister(InScriptContext, "AkGameplayStatics");
}
void SetMtLink(lua_State *InScriptContext)
{
	AzureHelpFuncs::AuxSetMtLink(InScriptContext, "AkGameplayStatics", "Object",USERDATATYPE_UOBJECT);
}

}