#include "Azure.h"
#include "Utility/help_funcs.h"
#include "wLua/UObjectHeaders.h"
#include "AzureRichTextBlock.h"
#include "AzureLuaIntegration.h"

namespace LuaAzureRichTextBlock
{
int32 SetText(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureRichTextBlock",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureRichTextBlock must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FString InText;
	} Params;
	Params.InText = UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 2));
#if UE_GAME
	UAzureRichTextBlock * This = (UAzureRichTextBlock *)Obj;
	This->SetText(Params.InText);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetText"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FString*)(params.GetStructMemory() + 0) = Params.InText;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.InText = *(FString*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetMinDesiredWidth(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureRichTextBlock",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureRichTextBlock must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float InMinDesiredWidth;
	} Params;
	Params.InMinDesiredWidth = (float)(luaL_checknumber(InScriptContext, 2));
#if UE_GAME
	UAzureRichTextBlock * This = (UAzureRichTextBlock *)Obj;
	This->SetMinDesiredWidth(Params.InMinDesiredWidth);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetMinDesiredWidth"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(float*)(params.GetStructMemory() + 0) = Params.InMinDesiredWidth;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.InMinDesiredWidth = *(float*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 Get_Text(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureRichTextBlock",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureRichTextBlock must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzureRichTextBlock::StaticClass(), TEXT("Text"));
	if(!Property) { check(false); return 0;}
	FText PropertyValue;
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushstring(InScriptContext, TCHAR_TO_UTF8(*PropertyValue.ToString()));
	return 1;
}

int32 Set_Text(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureRichTextBlock",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureRichTextBlock must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzureRichTextBlock::StaticClass(), TEXT("Text"));
	if(!Property) { check(false); return 0;}
	FText PropertyValue = FText::FromString(UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 2)));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_UseNoPixelSnapping(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureRichTextBlock",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureRichTextBlock must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzureRichTextBlock::StaticClass(), TEXT("UseNoPixelSnapping"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = bool();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_UseNoPixelSnapping(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureRichTextBlock",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureRichTextBlock must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzureRichTextBlock::StaticClass(), TEXT("UseNoPixelSnapping"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bHeightToContent(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureRichTextBlock",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureRichTextBlock must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzureRichTextBlock::StaticClass(), TEXT("bHeightToContent"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = bool();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_MinDesiredWidth(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureRichTextBlock",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureRichTextBlock must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzureRichTextBlock::StaticClass(), TEXT("MinDesiredWidth"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 New(lua_State* InScriptContext)
{
	UObject* Outer = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Object");
	FName Name = FName(luaL_checkstring(InScriptContext, 2));
	UObject* Obj = NewObject<UAzureRichTextBlock>(Outer, Name);
	wLua::FLuaUtils::ReturnUObject(InScriptContext,Obj);
	return 1;
}

int32 Destroy(lua_State* InScriptContext)
{
	return 0;
}

int32 Class(lua_State* InScriptContext)
{
	UClass* Class = UAzureRichTextBlock::StaticClass();
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Class);
	return 1;
}

const luaL_Reg Lib_Funcs[] =
{
	{ "New", New },
	{ "Destroy", Destroy },
	{ "Class", Class },
	{ "SetText", SetText },
	{ "SetMinDesiredWidth", SetMinDesiredWidth },
	{ "Get_Text", Get_Text },
	{ "Set_Text", Set_Text },
	{ "Get_UseNoPixelSnapping", Get_UseNoPixelSnapping },
	{ "Set_UseNoPixelSnapping", Set_UseNoPixelSnapping },
	{ "Get_bHeightToContent", Get_bHeightToContent },
	{ "Get_MinDesiredWidth", Get_MinDesiredWidth },
	{ "is_nil", wLua::LuaStatic::isnil },
	{ "__gc", wLua::LuaStatic::removeUClassFrameCache },
	{ NULL, NULL }
};

void Register(lua_State *InScriptContext)
{
	lua_newtable(InScriptContext);
	luaL_register(InScriptContext, NULL, Lib_Funcs);
	AzureHelpFuncs::AuxRegister(InScriptContext, "AzureRichTextBlock");
}
void SetMtLink(lua_State *InScriptContext)
{
	AzureHelpFuncs::AuxSetMtLink(InScriptContext, "AzureRichTextBlock", "TextLayoutWidget",USERDATATYPE_UOBJECT);
}

}