#include "Azure.h"
#include "Utility/help_funcs.h"
#include "wLua/UObjectHeaders.h"
#include "NavigationSystem.h"
#include "NavigationPath.h"
#include "CrowdManagerBase.h"
#include "AzureLuaIntegration.h"

namespace LuaNavigationSystemV1
{
int32 FindPathAsync(lua_State*);
int32 UpdateActorAndComponentsInNavOctree(lua_State*);

int32 UnregisterNavigationInvoker(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"NavigationSystemV1",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"NavigationSystemV1 must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		AActor* Invoker = nullptr;
	} Params;
	Params.Invoker = (AActor*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"Actor");;
#if UE_GAME
	UNavigationSystemV1 * This = (UNavigationSystemV1 *)Obj;
	This->UnregisterNavigationInvoker(Params.Invoker);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("UnregisterNavigationInvoker"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(AActor**)(params.GetStructMemory() + 0) = Params.Invoker;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.Invoker = *(AActor**)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetMaxSimultaneousTileGenerationJobsCount(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"NavigationSystemV1",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"NavigationSystemV1 must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		int32 MaxNumberOfJobs;
	} Params;
	Params.MaxNumberOfJobs = (luaL_checkint(InScriptContext, 2));
#if UE_GAME
	UNavigationSystemV1 * This = (UNavigationSystemV1 *)Obj;
	This->SetMaxSimultaneousTileGenerationJobsCount(Params.MaxNumberOfJobs);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetMaxSimultaneousTileGenerationJobsCount"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(int32*)(params.GetStructMemory() + 0) = Params.MaxNumberOfJobs;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.MaxNumberOfJobs = *(int32*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetGeometryGatheringMode(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"NavigationSystemV1",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"NavigationSystemV1 must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		ENavDataGatheringModeConfig NewMode;
	} Params;
	Params.NewMode = (ENavDataGatheringModeConfig)(luaL_checkint(InScriptContext, 2));
#if UE_GAME
	UNavigationSystemV1 * This = (UNavigationSystemV1 *)Obj;
	This->SetGeometryGatheringMode(Params.NewMode);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetGeometryGatheringMode"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(ENavDataGatheringModeConfig*)(params.GetStructMemory() + 0) = Params.NewMode;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.NewMode = *(ENavDataGatheringModeConfig*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 ResetMaxSimultaneousTileGenerationJobsCount(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"NavigationSystemV1",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"NavigationSystemV1 must be non-null"); lua_error(InScriptContext);  return 0;}
#if UE_GAME
	UNavigationSystemV1 * This = (UNavigationSystemV1 *)Obj;
	This->ResetMaxSimultaneousTileGenerationJobsCount();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("ResetMaxSimultaneousTileGenerationJobsCount"));
	if(!Function) { check(false); return 0;}
	Obj->ProcessEvent(Function, NULL);
#endif
	return 0;
}

int32 RegisterNavigationInvoker(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"NavigationSystemV1",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"NavigationSystemV1 must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		AActor* Invoker = nullptr;
		float TileGenerationRadius;
		float TileRemovalRadius;
	} Params;
	Params.Invoker = (AActor*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"Actor");;
	Params.TileGenerationRadius = lua_isnoneornil(InScriptContext,3) ? float(3000.000000) : (float)(luaL_checknumber(InScriptContext, 3));
	Params.TileRemovalRadius = lua_isnoneornil(InScriptContext,4) ? float(5000.000000) : (float)(luaL_checknumber(InScriptContext, 4));
#if UE_GAME
	UNavigationSystemV1 * This = (UNavigationSystemV1 *)Obj;
	This->RegisterNavigationInvoker(Params.Invoker,Params.TileGenerationRadius,Params.TileRemovalRadius);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("RegisterNavigationInvoker"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(AActor**)(params.GetStructMemory() + 0) = Params.Invoker;
		*(float*)(params.GetStructMemory() + 8) = Params.TileGenerationRadius;
		*(float*)(params.GetStructMemory() + 12) = Params.TileRemovalRadius;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.Invoker = *(AActor**)(params.GetStructMemory() + 0);
		Params.TileGenerationRadius = *(float*)(params.GetStructMemory() + 8);
		Params.TileRemovalRadius = *(float*)(params.GetStructMemory() + 12);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 OnNavigationBoundsUpdated(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"NavigationSystemV1",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"NavigationSystemV1 must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		ANavMeshBoundsVolume* NavVolume = nullptr;
	} Params;
	Params.NavVolume = (ANavMeshBoundsVolume*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"NavMeshBoundsVolume");;
#if UE_GAME
	UNavigationSystemV1 * This = (UNavigationSystemV1 *)Obj;
	This->OnNavigationBoundsUpdated(Params.NavVolume);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("OnNavigationBoundsUpdated"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(ANavMeshBoundsVolume**)(params.GetStructMemory() + 0) = Params.NavVolume;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.NavVolume = *(ANavMeshBoundsVolume**)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 NavigationRaycast(lua_State* InScriptContext)
{
	UClass * Obj = UNavigationSystemV1::StaticClass(); 
	struct FDispatchParams
	{
		UObject* WorldContextObject = nullptr;
		FVector RayStart;
		FVector RayEnd;
		FVector HitLocation;
		TSubclassOf<UNavigationQueryFilter>  FilterClass;
		AController* Querier = nullptr;
		bool ReturnValue;
	} Params;
	Params.WorldContextObject = (UObject*)wLua::FLuaUtils::GetUObject(InScriptContext,1,"Object");;
	Params.RayStart = (wLua::FLuaVector::Get(InScriptContext, 2));
	Params.RayEnd = (wLua::FLuaVector::Get(InScriptContext, 3));
	Params.FilterClass = lua_isnoneornil(InScriptContext,5) ? (UClass*)TSubclassOf<UNavigationQueryFilter> (nullptr) : (UClass*)wLua::FLuaUtils::GetUObject(InScriptContext,5,"Class");;
	Params.Querier = lua_isnoneornil(InScriptContext,6) ? nullptr : (AController*)wLua::FLuaUtils::GetUObject(InScriptContext,6,"Controller");;
#if UE_GAME
	Params.ReturnValue = UNavigationSystemV1::NavigationRaycast(Params.WorldContextObject,Params.RayStart,Params.RayEnd,Params.HitLocation,Params.FilterClass,Params.Querier);
#else
	UFunction* Function = Obj->FindFunctionByName(TEXT("NavigationRaycast"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(UObject**)(params.GetStructMemory() + 0) = Params.WorldContextObject;
		*(FVector*)(params.GetStructMemory() + 8) = Params.RayStart;
		*(FVector*)(params.GetStructMemory() + 20) = Params.RayEnd;
		*(TSubclassOf<UNavigationQueryFilter> *)(params.GetStructMemory() + 48) = Params.FilterClass;
		*(AController**)(params.GetStructMemory() + 56) = Params.Querier;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.WorldContextObject = *(UObject**)(params.GetStructMemory() + 0);
		Params.RayStart = *(FVector*)(params.GetStructMemory() + 8);
		Params.RayEnd = *(FVector*)(params.GetStructMemory() + 20);
		Params.HitLocation = *(FVector*)(params.GetStructMemory() + 32);
		Params.FilterClass = *(TSubclassOf<UNavigationQueryFilter> *)(params.GetStructMemory() + 48);
		Params.Querier = *(AController**)(params.GetStructMemory() + 56);
		Params.ReturnValue = *(bool*)(params.GetStructMemory() + 64);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushboolean(InScriptContext, Params.ReturnValue);
	wLua::FLuaVector::Return(InScriptContext, Params.HitLocation);
	return 2;
}

int32 K2_ProjectPointToNavigation(lua_State* InScriptContext)
{
	UClass * Obj = UNavigationSystemV1::StaticClass(); 
	struct FDispatchParams
	{
		UObject* WorldContextObject = nullptr;
		FVector Point;
		FVector ProjectedLocation;
		ANavigationData* NavData = nullptr;
		TSubclassOf<UNavigationQueryFilter>  FilterClass;
		FVector QueryExtent;
		bool ReturnValue;
	} Params;
	Params.WorldContextObject = (UObject*)wLua::FLuaUtils::GetUObject(InScriptContext,1,"Object");;
	Params.Point = (wLua::FLuaVector::Get(InScriptContext, 2));
	Params.NavData = (ANavigationData*)wLua::FLuaUtils::GetUObject(InScriptContext,4,"NavigationData");;
	Params.FilterClass = (UClass*)wLua::FLuaUtils::GetUObject(InScriptContext,5,"Class");;
	Params.QueryExtent = lua_isnoneornil(InScriptContext,6) ? FVector(0.f) : (wLua::FLuaVector::Get(InScriptContext, 6));
#if UE_GAME
	Params.ReturnValue = UNavigationSystemV1::K2_ProjectPointToNavigation(Params.WorldContextObject,Params.Point,Params.ProjectedLocation,Params.NavData,Params.FilterClass,Params.QueryExtent);
#else
	UFunction* Function = Obj->FindFunctionByName(TEXT("K2_ProjectPointToNavigation"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(UObject**)(params.GetStructMemory() + 0) = Params.WorldContextObject;
		*(FVector*)(params.GetStructMemory() + 8) = Params.Point;
		*(ANavigationData**)(params.GetStructMemory() + 32) = Params.NavData;
		*(TSubclassOf<UNavigationQueryFilter> *)(params.GetStructMemory() + 40) = Params.FilterClass;
		*(FVector*)(params.GetStructMemory() + 48) = Params.QueryExtent;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.WorldContextObject = *(UObject**)(params.GetStructMemory() + 0);
		Params.Point = *(FVector*)(params.GetStructMemory() + 8);
		Params.ProjectedLocation = *(FVector*)(params.GetStructMemory() + 20);
		Params.NavData = *(ANavigationData**)(params.GetStructMemory() + 32);
		Params.FilterClass = *(TSubclassOf<UNavigationQueryFilter> *)(params.GetStructMemory() + 40);
		Params.QueryExtent = *(FVector*)(params.GetStructMemory() + 48);
		Params.ReturnValue = *(bool*)(params.GetStructMemory() + 60);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushboolean(InScriptContext, Params.ReturnValue);
	wLua::FLuaVector::Return(InScriptContext, Params.ProjectedLocation);
	return 2;
}

int32 K2_GetRandomReachablePointInRadius(lua_State* InScriptContext)
{
	UClass * Obj = UNavigationSystemV1::StaticClass(); 
	struct FDispatchParams
	{
		UObject* WorldContextObject = nullptr;
		FVector Origin;
		FVector RandomLocation;
		float Radius;
		ANavigationData* NavData = nullptr;
		TSubclassOf<UNavigationQueryFilter>  FilterClass;
		bool ReturnValue;
	} Params;
	Params.WorldContextObject = (UObject*)wLua::FLuaUtils::GetUObject(InScriptContext,1,"Object");;
	Params.Origin = (wLua::FLuaVector::Get(InScriptContext, 2));
	Params.Radius = (float)(luaL_checknumber(InScriptContext, 4));
	Params.NavData = lua_isnoneornil(InScriptContext,5) ? nullptr : (ANavigationData*)wLua::FLuaUtils::GetUObject(InScriptContext,5,"NavigationData");;
	Params.FilterClass = lua_isnoneornil(InScriptContext,6) ? (UClass*)TSubclassOf<UNavigationQueryFilter> (nullptr) : (UClass*)wLua::FLuaUtils::GetUObject(InScriptContext,6,"Class");;
#if UE_GAME
	Params.ReturnValue = UNavigationSystemV1::K2_GetRandomReachablePointInRadius(Params.WorldContextObject,Params.Origin,Params.RandomLocation,Params.Radius,Params.NavData,Params.FilterClass);
#else
	UFunction* Function = Obj->FindFunctionByName(TEXT("K2_GetRandomReachablePointInRadius"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(UObject**)(params.GetStructMemory() + 0) = Params.WorldContextObject;
		*(FVector*)(params.GetStructMemory() + 8) = Params.Origin;
		*(float*)(params.GetStructMemory() + 32) = Params.Radius;
		*(ANavigationData**)(params.GetStructMemory() + 40) = Params.NavData;
		*(TSubclassOf<UNavigationQueryFilter> *)(params.GetStructMemory() + 48) = Params.FilterClass;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.WorldContextObject = *(UObject**)(params.GetStructMemory() + 0);
		Params.Origin = *(FVector*)(params.GetStructMemory() + 8);
		Params.RandomLocation = *(FVector*)(params.GetStructMemory() + 20);
		Params.Radius = *(float*)(params.GetStructMemory() + 32);
		Params.NavData = *(ANavigationData**)(params.GetStructMemory() + 40);
		Params.FilterClass = *(TSubclassOf<UNavigationQueryFilter> *)(params.GetStructMemory() + 48);
		Params.ReturnValue = *(bool*)(params.GetStructMemory() + 56);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushboolean(InScriptContext, Params.ReturnValue);
	wLua::FLuaVector::Return(InScriptContext, Params.RandomLocation);
	return 2;
}

int32 K2_GetRandomPointInNavigableRadius(lua_State* InScriptContext)
{
	UClass * Obj = UNavigationSystemV1::StaticClass(); 
	struct FDispatchParams
	{
		UObject* WorldContextObject = nullptr;
		FVector Origin;
		FVector RandomLocation;
		float Radius;
		ANavigationData* NavData = nullptr;
		TSubclassOf<UNavigationQueryFilter>  FilterClass;
		bool ReturnValue;
	} Params;
	Params.WorldContextObject = (UObject*)wLua::FLuaUtils::GetUObject(InScriptContext,1,"Object");;
	Params.Origin = (wLua::FLuaVector::Get(InScriptContext, 2));
	Params.Radius = (float)(luaL_checknumber(InScriptContext, 4));
	Params.NavData = lua_isnoneornil(InScriptContext,5) ? nullptr : (ANavigationData*)wLua::FLuaUtils::GetUObject(InScriptContext,5,"NavigationData");;
	Params.FilterClass = lua_isnoneornil(InScriptContext,6) ? (UClass*)TSubclassOf<UNavigationQueryFilter> (nullptr) : (UClass*)wLua::FLuaUtils::GetUObject(InScriptContext,6,"Class");;
#if UE_GAME
	Params.ReturnValue = UNavigationSystemV1::K2_GetRandomPointInNavigableRadius(Params.WorldContextObject,Params.Origin,Params.RandomLocation,Params.Radius,Params.NavData,Params.FilterClass);
#else
	UFunction* Function = Obj->FindFunctionByName(TEXT("K2_GetRandomPointInNavigableRadius"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(UObject**)(params.GetStructMemory() + 0) = Params.WorldContextObject;
		*(FVector*)(params.GetStructMemory() + 8) = Params.Origin;
		*(float*)(params.GetStructMemory() + 32) = Params.Radius;
		*(ANavigationData**)(params.GetStructMemory() + 40) = Params.NavData;
		*(TSubclassOf<UNavigationQueryFilter> *)(params.GetStructMemory() + 48) = Params.FilterClass;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.WorldContextObject = *(UObject**)(params.GetStructMemory() + 0);
		Params.Origin = *(FVector*)(params.GetStructMemory() + 8);
		Params.RandomLocation = *(FVector*)(params.GetStructMemory() + 20);
		Params.Radius = *(float*)(params.GetStructMemory() + 32);
		Params.NavData = *(ANavigationData**)(params.GetStructMemory() + 40);
		Params.FilterClass = *(TSubclassOf<UNavigationQueryFilter> *)(params.GetStructMemory() + 48);
		Params.ReturnValue = *(bool*)(params.GetStructMemory() + 56);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushboolean(InScriptContext, Params.ReturnValue);
	wLua::FLuaVector::Return(InScriptContext, Params.RandomLocation);
	return 2;
}

int32 IsNavigationBeingBuiltOrLocked(lua_State* InScriptContext)
{
	UClass * Obj = UNavigationSystemV1::StaticClass(); 
	struct FDispatchParams
	{
		UObject* WorldContextObject = nullptr;
		bool ReturnValue;
	} Params;
	Params.WorldContextObject = (UObject*)wLua::FLuaUtils::GetUObject(InScriptContext,1,"Object");;
#if UE_GAME
	Params.ReturnValue = UNavigationSystemV1::IsNavigationBeingBuiltOrLocked(Params.WorldContextObject);
#else
	UFunction* Function = Obj->FindFunctionByName(TEXT("IsNavigationBeingBuiltOrLocked"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(UObject**)(params.GetStructMemory() + 0) = Params.WorldContextObject;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.WorldContextObject = *(UObject**)(params.GetStructMemory() + 0);
		Params.ReturnValue = *(bool*)(params.GetStructMemory() + 8);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushboolean(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 IsNavigationBeingBuilt(lua_State* InScriptContext)
{
	UClass * Obj = UNavigationSystemV1::StaticClass(); 
	struct FDispatchParams
	{
		UObject* WorldContextObject = nullptr;
		bool ReturnValue;
	} Params;
	Params.WorldContextObject = (UObject*)wLua::FLuaUtils::GetUObject(InScriptContext,1,"Object");;
#if UE_GAME
	Params.ReturnValue = UNavigationSystemV1::IsNavigationBeingBuilt(Params.WorldContextObject);
#else
	UFunction* Function = Obj->FindFunctionByName(TEXT("IsNavigationBeingBuilt"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(UObject**)(params.GetStructMemory() + 0) = Params.WorldContextObject;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.WorldContextObject = *(UObject**)(params.GetStructMemory() + 0);
		Params.ReturnValue = *(bool*)(params.GetStructMemory() + 8);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushboolean(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetPathLength(lua_State* InScriptContext)
{
	UClass * Obj = UNavigationSystemV1::StaticClass(); 
	struct FDispatchParams
	{
		UObject* WorldContextObject = nullptr;
		FVector PathStart;
		FVector PathEnd;
		float PathLength;
		ANavigationData* NavData = nullptr;
		TSubclassOf<UNavigationQueryFilter>  FilterClass;
		TEnumAsByte<ENavigationQueryResult::Type> ReturnValue;
	} Params;
	Params.WorldContextObject = (UObject*)wLua::FLuaUtils::GetUObject(InScriptContext,1,"Object");;
	Params.PathStart = (wLua::FLuaVector::Get(InScriptContext, 2));
	Params.PathEnd = (wLua::FLuaVector::Get(InScriptContext, 3));
	Params.NavData = lua_isnoneornil(InScriptContext,5) ? nullptr : (ANavigationData*)wLua::FLuaUtils::GetUObject(InScriptContext,5,"NavigationData");;
	Params.FilterClass = lua_isnoneornil(InScriptContext,6) ? (UClass*)TSubclassOf<UNavigationQueryFilter> (nullptr) : (UClass*)wLua::FLuaUtils::GetUObject(InScriptContext,6,"Class");;
#if UE_GAME
	Params.ReturnValue = UNavigationSystemV1::GetPathLength(Params.WorldContextObject,Params.PathStart,Params.PathEnd,Params.PathLength,Params.NavData,Params.FilterClass);
#else
	UFunction* Function = Obj->FindFunctionByName(TEXT("GetPathLength"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(UObject**)(params.GetStructMemory() + 0) = Params.WorldContextObject;
		*(FVector*)(params.GetStructMemory() + 8) = Params.PathStart;
		*(FVector*)(params.GetStructMemory() + 20) = Params.PathEnd;
		*(ANavigationData**)(params.GetStructMemory() + 40) = Params.NavData;
		*(TSubclassOf<UNavigationQueryFilter> *)(params.GetStructMemory() + 48) = Params.FilterClass;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.WorldContextObject = *(UObject**)(params.GetStructMemory() + 0);
		Params.PathStart = *(FVector*)(params.GetStructMemory() + 8);
		Params.PathEnd = *(FVector*)(params.GetStructMemory() + 20);
		Params.PathLength = *(float*)(params.GetStructMemory() + 32);
		Params.NavData = *(ANavigationData**)(params.GetStructMemory() + 40);
		Params.FilterClass = *(TSubclassOf<UNavigationQueryFilter> *)(params.GetStructMemory() + 48);
		Params.ReturnValue = *(TEnumAsByte<ENavigationQueryResult::Type>*)(params.GetStructMemory() + 56);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushinteger(InScriptContext, (int)Params.ReturnValue);
	lua_pushnumber(InScriptContext, Params.PathLength);
	return 2;
}

int32 GetPathCost(lua_State* InScriptContext)
{
	UClass * Obj = UNavigationSystemV1::StaticClass(); 
	struct FDispatchParams
	{
		UObject* WorldContextObject = nullptr;
		FVector PathStart;
		FVector PathEnd;
		float PathCost;
		ANavigationData* NavData = nullptr;
		TSubclassOf<UNavigationQueryFilter>  FilterClass;
		TEnumAsByte<ENavigationQueryResult::Type> ReturnValue;
	} Params;
	Params.WorldContextObject = (UObject*)wLua::FLuaUtils::GetUObject(InScriptContext,1,"Object");;
	Params.PathStart = (wLua::FLuaVector::Get(InScriptContext, 2));
	Params.PathEnd = (wLua::FLuaVector::Get(InScriptContext, 3));
	Params.NavData = lua_isnoneornil(InScriptContext,5) ? nullptr : (ANavigationData*)wLua::FLuaUtils::GetUObject(InScriptContext,5,"NavigationData");;
	Params.FilterClass = lua_isnoneornil(InScriptContext,6) ? (UClass*)TSubclassOf<UNavigationQueryFilter> (nullptr) : (UClass*)wLua::FLuaUtils::GetUObject(InScriptContext,6,"Class");;
#if UE_GAME
	Params.ReturnValue = UNavigationSystemV1::GetPathCost(Params.WorldContextObject,Params.PathStart,Params.PathEnd,Params.PathCost,Params.NavData,Params.FilterClass);
#else
	UFunction* Function = Obj->FindFunctionByName(TEXT("GetPathCost"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(UObject**)(params.GetStructMemory() + 0) = Params.WorldContextObject;
		*(FVector*)(params.GetStructMemory() + 8) = Params.PathStart;
		*(FVector*)(params.GetStructMemory() + 20) = Params.PathEnd;
		*(ANavigationData**)(params.GetStructMemory() + 40) = Params.NavData;
		*(TSubclassOf<UNavigationQueryFilter> *)(params.GetStructMemory() + 48) = Params.FilterClass;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.WorldContextObject = *(UObject**)(params.GetStructMemory() + 0);
		Params.PathStart = *(FVector*)(params.GetStructMemory() + 8);
		Params.PathEnd = *(FVector*)(params.GetStructMemory() + 20);
		Params.PathCost = *(float*)(params.GetStructMemory() + 32);
		Params.NavData = *(ANavigationData**)(params.GetStructMemory() + 40);
		Params.FilterClass = *(TSubclassOf<UNavigationQueryFilter> *)(params.GetStructMemory() + 48);
		Params.ReturnValue = *(TEnumAsByte<ENavigationQueryResult::Type>*)(params.GetStructMemory() + 56);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushinteger(InScriptContext, (int)Params.ReturnValue);
	lua_pushnumber(InScriptContext, Params.PathCost);
	return 2;
}

int32 GetNavigationSystem(lua_State* InScriptContext)
{
	UClass * Obj = UNavigationSystemV1::StaticClass(); 
	struct FDispatchParams
	{
		UObject* WorldContextObject = nullptr;
		UNavigationSystemV1* ReturnValue = nullptr;
	} Params;
	Params.WorldContextObject = (UObject*)wLua::FLuaUtils::GetUObject(InScriptContext,1,"Object");;
#if UE_GAME
	Params.ReturnValue = UNavigationSystemV1::GetNavigationSystem(Params.WorldContextObject);
#else
	UFunction* Function = Obj->FindFunctionByName(TEXT("GetNavigationSystem"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(UObject**)(params.GetStructMemory() + 0) = Params.WorldContextObject;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.WorldContextObject = *(UObject**)(params.GetStructMemory() + 0);
		Params.ReturnValue = *(UNavigationSystemV1**)(params.GetStructMemory() + 8);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 FindPathToLocationSynchronously(lua_State* InScriptContext)
{
	UClass * Obj = UNavigationSystemV1::StaticClass(); 
	struct FDispatchParams
	{
		UObject* WorldContextObject = nullptr;
		FVector PathStart;
		FVector PathEnd;
		AActor* PathfindingContext = nullptr;
		TSubclassOf<UNavigationQueryFilter>  FilterClass;
		UNavigationPath* ReturnValue = nullptr;
	} Params;
	Params.WorldContextObject = (UObject*)wLua::FLuaUtils::GetUObject(InScriptContext,1,"Object");;
	Params.PathStart = (wLua::FLuaVector::Get(InScriptContext, 2));
	Params.PathEnd = (wLua::FLuaVector::Get(InScriptContext, 3));
	Params.PathfindingContext = lua_isnoneornil(InScriptContext,4) ? nullptr : (AActor*)wLua::FLuaUtils::GetUObject(InScriptContext,4,"Actor");;
	Params.FilterClass = lua_isnoneornil(InScriptContext,5) ? (UClass*)TSubclassOf<UNavigationQueryFilter> (nullptr) : (UClass*)wLua::FLuaUtils::GetUObject(InScriptContext,5,"Class");;
#if UE_GAME
	Params.ReturnValue = UNavigationSystemV1::FindPathToLocationSynchronously(Params.WorldContextObject,Params.PathStart,Params.PathEnd,Params.PathfindingContext,Params.FilterClass);
#else
	UFunction* Function = Obj->FindFunctionByName(TEXT("FindPathToLocationSynchronously"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(UObject**)(params.GetStructMemory() + 0) = Params.WorldContextObject;
		*(FVector*)(params.GetStructMemory() + 8) = Params.PathStart;
		*(FVector*)(params.GetStructMemory() + 20) = Params.PathEnd;
		*(AActor**)(params.GetStructMemory() + 32) = Params.PathfindingContext;
		*(TSubclassOf<UNavigationQueryFilter> *)(params.GetStructMemory() + 40) = Params.FilterClass;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.WorldContextObject = *(UObject**)(params.GetStructMemory() + 0);
		Params.PathStart = *(FVector*)(params.GetStructMemory() + 8);
		Params.PathEnd = *(FVector*)(params.GetStructMemory() + 20);
		Params.PathfindingContext = *(AActor**)(params.GetStructMemory() + 32);
		Params.FilterClass = *(TSubclassOf<UNavigationQueryFilter> *)(params.GetStructMemory() + 40);
		Params.ReturnValue = *(UNavigationPath**)(params.GetStructMemory() + 48);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 FindPathToActorSynchronously(lua_State* InScriptContext)
{
	UClass * Obj = UNavigationSystemV1::StaticClass(); 
	struct FDispatchParams
	{
		UObject* WorldContextObject = nullptr;
		FVector PathStart;
		AActor* GoalActor = nullptr;
		float TetherDistance;
		AActor* PathfindingContext = nullptr;
		TSubclassOf<UNavigationQueryFilter>  FilterClass;
		UNavigationPath* ReturnValue = nullptr;
	} Params;
	Params.WorldContextObject = (UObject*)wLua::FLuaUtils::GetUObject(InScriptContext,1,"Object");;
	Params.PathStart = (wLua::FLuaVector::Get(InScriptContext, 2));
	Params.GoalActor = (AActor*)wLua::FLuaUtils::GetUObject(InScriptContext,3,"Actor");;
	Params.TetherDistance = lua_isnoneornil(InScriptContext,4) ? float(50.000000) : (float)(luaL_checknumber(InScriptContext, 4));
	Params.PathfindingContext = lua_isnoneornil(InScriptContext,5) ? nullptr : (AActor*)wLua::FLuaUtils::GetUObject(InScriptContext,5,"Actor");;
	Params.FilterClass = lua_isnoneornil(InScriptContext,6) ? (UClass*)TSubclassOf<UNavigationQueryFilter> (nullptr) : (UClass*)wLua::FLuaUtils::GetUObject(InScriptContext,6,"Class");;
#if UE_GAME
	Params.ReturnValue = UNavigationSystemV1::FindPathToActorSynchronously(Params.WorldContextObject,Params.PathStart,Params.GoalActor,Params.TetherDistance,Params.PathfindingContext,Params.FilterClass);
#else
	UFunction* Function = Obj->FindFunctionByName(TEXT("FindPathToActorSynchronously"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(UObject**)(params.GetStructMemory() + 0) = Params.WorldContextObject;
		*(FVector*)(params.GetStructMemory() + 8) = Params.PathStart;
		*(AActor**)(params.GetStructMemory() + 24) = Params.GoalActor;
		*(float*)(params.GetStructMemory() + 32) = Params.TetherDistance;
		*(AActor**)(params.GetStructMemory() + 40) = Params.PathfindingContext;
		*(TSubclassOf<UNavigationQueryFilter> *)(params.GetStructMemory() + 48) = Params.FilterClass;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.WorldContextObject = *(UObject**)(params.GetStructMemory() + 0);
		Params.PathStart = *(FVector*)(params.GetStructMemory() + 8);
		Params.GoalActor = *(AActor**)(params.GetStructMemory() + 24);
		Params.TetherDistance = *(float*)(params.GetStructMemory() + 32);
		Params.PathfindingContext = *(AActor**)(params.GetStructMemory() + 40);
		Params.FilterClass = *(TSubclassOf<UNavigationQueryFilter> *)(params.GetStructMemory() + 48);
		Params.ReturnValue = *(UNavigationPath**)(params.GetStructMemory() + 56);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 Get_CrowdManagerClass(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"NavigationSystemV1",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"NavigationSystemV1 must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UNavigationSystemV1::StaticClass(), TEXT("CrowdManagerClass"));
	if(!Property) { check(false); return 0;}
	TSubclassOf<UCrowdManagerBase>  PropertyValue = TSubclassOf<UCrowdManagerBase> ();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaUtils::ReturnUObject(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_bAutoCreateNavigationData(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"NavigationSystemV1",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"NavigationSystemV1 must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UNavigationSystemV1::StaticClass(), TEXT("bAutoCreateNavigationData"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bAutoCreateNavigationData(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"NavigationSystemV1",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"NavigationSystemV1 must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UNavigationSystemV1::StaticClass(), TEXT("bAutoCreateNavigationData"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bSpawnNavDataInNavBoundsLevel(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"NavigationSystemV1",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"NavigationSystemV1 must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UNavigationSystemV1::StaticClass(), TEXT("bSpawnNavDataInNavBoundsLevel"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bSpawnNavDataInNavBoundsLevel(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"NavigationSystemV1",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"NavigationSystemV1 must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UNavigationSystemV1::StaticClass(), TEXT("bSpawnNavDataInNavBoundsLevel"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bAllowClientSideNavigation(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"NavigationSystemV1",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"NavigationSystemV1 must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UNavigationSystemV1::StaticClass(), TEXT("bAllowClientSideNavigation"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bAllowClientSideNavigation(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"NavigationSystemV1",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"NavigationSystemV1 must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UNavigationSystemV1::StaticClass(), TEXT("bAllowClientSideNavigation"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bShouldDiscardSubLevelNavData(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"NavigationSystemV1",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"NavigationSystemV1 must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UNavigationSystemV1::StaticClass(), TEXT("bShouldDiscardSubLevelNavData"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bShouldDiscardSubLevelNavData(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"NavigationSystemV1",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"NavigationSystemV1 must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UNavigationSystemV1::StaticClass(), TEXT("bShouldDiscardSubLevelNavData"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bTickWhilePaused(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"NavigationSystemV1",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"NavigationSystemV1 must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UNavigationSystemV1::StaticClass(), TEXT("bTickWhilePaused"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bTickWhilePaused(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"NavigationSystemV1",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"NavigationSystemV1 must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UNavigationSystemV1::StaticClass(), TEXT("bTickWhilePaused"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bInitialBuildingLocked(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"NavigationSystemV1",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"NavigationSystemV1 must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UNavigationSystemV1::StaticClass(), TEXT("bInitialBuildingLocked"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bInitialBuildingLocked(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"NavigationSystemV1",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"NavigationSystemV1 must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UNavigationSystemV1::StaticClass(), TEXT("bInitialBuildingLocked"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bSkipAgentHeightCheckWhenPickingNavData(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"NavigationSystemV1",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"NavigationSystemV1 must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UNavigationSystemV1::StaticClass(), TEXT("bSkipAgentHeightCheckWhenPickingNavData"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bSkipAgentHeightCheckWhenPickingNavData(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"NavigationSystemV1",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"NavigationSystemV1 must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UNavigationSystemV1::StaticClass(), TEXT("bSkipAgentHeightCheckWhenPickingNavData"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_DataGatheringMode(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"NavigationSystemV1",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"NavigationSystemV1 must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UNavigationSystemV1::StaticClass(), TEXT("DataGatheringMode"));
	if(!Property) { check(false); return 0;}
	ENavDataGatheringModeConfig PropertyValue = ENavDataGatheringModeConfig();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushinteger(InScriptContext, (int)PropertyValue);
	return 1;
}

int32 Set_DataGatheringMode(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"NavigationSystemV1",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"NavigationSystemV1 must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UNavigationSystemV1::StaticClass(), TEXT("DataGatheringMode"));
	if(!Property) { check(false); return 0;}
	ENavDataGatheringModeConfig PropertyValue = (ENavDataGatheringModeConfig)(luaL_checkint(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bGenerateNavigationOnlyAroundNavigationInvokers(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"NavigationSystemV1",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"NavigationSystemV1 must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UNavigationSystemV1::StaticClass(), TEXT("bGenerateNavigationOnlyAroundNavigationInvokers"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bGenerateNavigationOnlyAroundNavigationInvokers(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"NavigationSystemV1",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"NavigationSystemV1 must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UNavigationSystemV1::StaticClass(), TEXT("bGenerateNavigationOnlyAroundNavigationInvokers"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_ActiveTilesUpdateInterval(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"NavigationSystemV1",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"NavigationSystemV1 must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UNavigationSystemV1::StaticClass(), TEXT("ActiveTilesUpdateInterval"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_ActiveTilesUpdateInterval(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"NavigationSystemV1",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"NavigationSystemV1 must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UNavigationSystemV1::StaticClass(), TEXT("ActiveTilesUpdateInterval"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_DirtyAreasUpdateFreq(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"NavigationSystemV1",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"NavigationSystemV1 must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UNavigationSystemV1::StaticClass(), TEXT("DirtyAreasUpdateFreq"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_DirtyAreasUpdateFreq(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"NavigationSystemV1",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"NavigationSystemV1 must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UNavigationSystemV1::StaticClass(), TEXT("DirtyAreasUpdateFreq"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Call_OnNavigationGenerationFinishedDelegate(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"NavigationSystemV1",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"NavigationSystemV1 must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		ANavigationData* NavData = nullptr;
	} Params;
	Params.NavData = (ANavigationData*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"NavigationData");;
	UNavigationSystemV1 * This = (UNavigationSystemV1 *)Obj;
	This->OnNavigationGenerationFinishedDelegate.Broadcast(Params.NavData);
	return 0;
}

int32 New(lua_State* InScriptContext)
{
	UObject* Outer = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Object");
	FName Name = FName(luaL_checkstring(InScriptContext, 2));
	UObject* Obj = NewObject<UNavigationSystemV1>(Outer, Name);
	wLua::FLuaUtils::ReturnUObject(InScriptContext,Obj);
	return 1;
}

int32 Destroy(lua_State* InScriptContext)
{
	return 0;
}

int32 Class(lua_State* InScriptContext)
{
	UClass* Class = UNavigationSystemV1::StaticClass();
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Class);
	return 1;
}

const luaL_Reg Lib_Funcs[] =
{
	{ "New", New },
	{ "Destroy", Destroy },
	{ "Class", Class },
	{ "UnregisterNavigationInvoker", UnregisterNavigationInvoker },
	{ "SetMaxSimultaneousTileGenerationJobsCount", SetMaxSimultaneousTileGenerationJobsCount },
	{ "SetGeometryGatheringMode", SetGeometryGatheringMode },
	{ "ResetMaxSimultaneousTileGenerationJobsCount", ResetMaxSimultaneousTileGenerationJobsCount },
	{ "RegisterNavigationInvoker", RegisterNavigationInvoker },
	{ "OnNavigationBoundsUpdated", OnNavigationBoundsUpdated },
	{ "NavigationRaycast", NavigationRaycast },
	{ "ProjectPointToNavigation", K2_ProjectPointToNavigation },
	{ "GetRandomReachablePointInRadius", K2_GetRandomReachablePointInRadius },
	{ "GetRandomPointInNavigableRadius", K2_GetRandomPointInNavigableRadius },
	{ "IsNavigationBeingBuiltOrLocked", IsNavigationBeingBuiltOrLocked },
	{ "IsNavigationBeingBuilt", IsNavigationBeingBuilt },
	{ "GetPathLength", GetPathLength },
	{ "GetPathCost", GetPathCost },
	{ "GetNavigationSystem", GetNavigationSystem },
	{ "FindPathToLocationSynchronously", FindPathToLocationSynchronously },
	{ "FindPathToActorSynchronously", FindPathToActorSynchronously },
	{ "Get_CrowdManagerClass", Get_CrowdManagerClass },
	{ "Get_bAutoCreateNavigationData", Get_bAutoCreateNavigationData },
	{ "Set_bAutoCreateNavigationData", Set_bAutoCreateNavigationData },
	{ "Get_bSpawnNavDataInNavBoundsLevel", Get_bSpawnNavDataInNavBoundsLevel },
	{ "Set_bSpawnNavDataInNavBoundsLevel", Set_bSpawnNavDataInNavBoundsLevel },
	{ "Get_bAllowClientSideNavigation", Get_bAllowClientSideNavigation },
	{ "Set_bAllowClientSideNavigation", Set_bAllowClientSideNavigation },
	{ "Get_bShouldDiscardSubLevelNavData", Get_bShouldDiscardSubLevelNavData },
	{ "Set_bShouldDiscardSubLevelNavData", Set_bShouldDiscardSubLevelNavData },
	{ "Get_bTickWhilePaused", Get_bTickWhilePaused },
	{ "Set_bTickWhilePaused", Set_bTickWhilePaused },
	{ "Get_bInitialBuildingLocked", Get_bInitialBuildingLocked },
	{ "Set_bInitialBuildingLocked", Set_bInitialBuildingLocked },
	{ "Get_bSkipAgentHeightCheckWhenPickingNavData", Get_bSkipAgentHeightCheckWhenPickingNavData },
	{ "Set_bSkipAgentHeightCheckWhenPickingNavData", Set_bSkipAgentHeightCheckWhenPickingNavData },
	{ "Get_DataGatheringMode", Get_DataGatheringMode },
	{ "Set_DataGatheringMode", Set_DataGatheringMode },
	{ "Get_bGenerateNavigationOnlyAroundNavigationInvokers", Get_bGenerateNavigationOnlyAroundNavigationInvokers },
	{ "Set_bGenerateNavigationOnlyAroundNavigationInvokers", Set_bGenerateNavigationOnlyAroundNavigationInvokers },
	{ "Get_ActiveTilesUpdateInterval", Get_ActiveTilesUpdateInterval },
	{ "Set_ActiveTilesUpdateInterval", Set_ActiveTilesUpdateInterval },
	{ "Get_DirtyAreasUpdateFreq", Get_DirtyAreasUpdateFreq },
	{ "Set_DirtyAreasUpdateFreq", Set_DirtyAreasUpdateFreq },
	{ "Call_OnNavigationGenerationFinishedDelegate", Call_OnNavigationGenerationFinishedDelegate },
	{ "FindPathAsync", FindPathAsync },
	{ "UpdateActorAndComponentsInNavOctree", UpdateActorAndComponentsInNavOctree },
	{ "is_nil", wLua::LuaStatic::isnil },
	{ "__gc", wLua::LuaStatic::removeUClassFrameCache },
	{ NULL, NULL }
};

void Register(lua_State *InScriptContext)
{
	lua_newtable(InScriptContext);
	luaL_register(InScriptContext, NULL, Lib_Funcs);
	AzureHelpFuncs::AuxRegister(InScriptContext, "NavigationSystemV1");
}
void SetMtLink(lua_State *InScriptContext)
{
	AzureHelpFuncs::AuxSetMtLink(InScriptContext, "NavigationSystemV1", "Object",USERDATATYPE_UOBJECT);
}

}