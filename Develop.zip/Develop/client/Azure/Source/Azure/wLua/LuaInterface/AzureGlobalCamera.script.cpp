#include "Azure.h"
#include "Utility/help_funcs.h"
#include "wLua/UObjectHeaders.h"
#include "GameLogic/Camera/AzureGlobalCamera.h"
#include "AzureLuaIntegration.h"

namespace LuaAzureGlobalCamera
{
int32 TransitTo(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureGlobalCamera",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureGlobalCamera must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FVector pos;
		FRotator rot;
		float duration;
	} Params;
	Params.pos = (wLua::FLuaVector::Get(InScriptContext, 2));
	Params.rot = (wLua::FLuaRotator::Get(InScriptContext, 3));
	Params.duration = (float)(luaL_checknumber(InScriptContext, 4));
#if UE_GAME
	AAzureGlobalCamera * This = (AAzureGlobalCamera *)Obj;
	This->TransitTo(Params.pos,Params.rot,Params.duration);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("TransitTo"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FVector*)(params.GetStructMemory() + 0) = Params.pos;
		*(FRotator*)(params.GetStructMemory() + 12) = Params.rot;
		*(float*)(params.GetStructMemory() + 24) = Params.duration;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.pos = *(FVector*)(params.GetStructMemory() + 0);
		Params.rot = *(FRotator*)(params.GetStructMemory() + 12);
		Params.duration = *(float*)(params.GetStructMemory() + 24);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetMaxRangeBox(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureGlobalCamera",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureGlobalCamera must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FVector vMin;
		FVector vMax;
	} Params;
	Params.vMin = (wLua::FLuaVector::Get(InScriptContext, 2));
	Params.vMax = (wLua::FLuaVector::Get(InScriptContext, 3));
#if UE_GAME
	AAzureGlobalCamera * This = (AAzureGlobalCamera *)Obj;
	This->SetMaxRangeBox(Params.vMin,Params.vMax);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetMaxRangeBox"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FVector*)(params.GetStructMemory() + 0) = Params.vMin;
		*(FVector*)(params.GetStructMemory() + 12) = Params.vMax;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.vMin = *(FVector*)(params.GetStructMemory() + 0);
		Params.vMax = *(FVector*)(params.GetStructMemory() + 12);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetLookAtComponent(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureGlobalCamera",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureGlobalCamera must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		USceneComponent* comp = nullptr;
	} Params;
	Params.comp = (USceneComponent*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"SceneComponent");;
#if UE_GAME
	AAzureGlobalCamera * This = (AAzureGlobalCamera *)Obj;
	This->SetLookAtComponent(Params.comp);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetLookAtComponent"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(USceneComponent**)(params.GetStructMemory() + 0) = Params.comp;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.comp = *(USceneComponent**)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetGlobalCameraValue(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureGlobalCamera",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureGlobalCamera must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float verticalShift;
		float horizonalShift;
	} Params;
	Params.verticalShift = (float)(luaL_checknumber(InScriptContext, 2));
	Params.horizonalShift = (float)(luaL_checknumber(InScriptContext, 3));
#if UE_GAME
	AAzureGlobalCamera * This = (AAzureGlobalCamera *)Obj;
	This->SetGlobalCameraValue(Params.verticalShift,Params.horizonalShift);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetGlobalCameraValue"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(float*)(params.GetStructMemory() + 0) = Params.verticalShift;
		*(float*)(params.GetStructMemory() + 4) = Params.horizonalShift;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.verticalShift = *(float*)(params.GetStructMemory() + 0);
		Params.horizonalShift = *(float*)(params.GetStructMemory() + 4);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetCameraMode(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureGlobalCamera",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureGlobalCamera must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		EAzureGlobalCameraMode Mode;
	} Params;
	Params.Mode = (EAzureGlobalCameraMode)(luaL_checkint(InScriptContext, 2));
#if UE_GAME
	AAzureGlobalCamera * This = (AAzureGlobalCamera *)Obj;
	This->SetCameraMode(Params.Mode);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetCameraMode"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(EAzureGlobalCameraMode*)(params.GetStructMemory() + 0) = Params.Mode;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.Mode = *(EAzureGlobalCameraMode*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 IsTransiting(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureGlobalCamera",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureGlobalCamera must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool ReturnValue;
	} Params;
#if UE_GAME
	AAzureGlobalCamera * This = (AAzureGlobalCamera *)Obj;
	Params.ReturnValue = This->IsTransiting();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("IsTransiting"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushboolean(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 InitPosAndRot(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureGlobalCamera",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureGlobalCamera must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FVector pos;
		FRotator rot;
	} Params;
	Params.pos = (wLua::FLuaVector::Get(InScriptContext, 2));
	Params.rot = (wLua::FLuaRotator::Get(InScriptContext, 3));
#if UE_GAME
	AAzureGlobalCamera * This = (AAzureGlobalCamera *)Obj;
	This->InitPosAndRot(Params.pos,Params.rot);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("InitPosAndRot"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FVector*)(params.GetStructMemory() + 0) = Params.pos;
		*(FRotator*)(params.GetStructMemory() + 12) = Params.rot;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.pos = *(FVector*)(params.GetStructMemory() + 0);
		Params.rot = *(FRotator*)(params.GetStructMemory() + 12);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 AddRotationInput(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureGlobalCamera",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureGlobalCamera must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float fPitch;
		float fYaw;
	} Params;
	Params.fPitch = (float)(luaL_checknumber(InScriptContext, 2));
	Params.fYaw = (float)(luaL_checknumber(InScriptContext, 3));
#if UE_GAME
	AAzureGlobalCamera * This = (AAzureGlobalCamera *)Obj;
	This->AddRotationInput(Params.fPitch,Params.fYaw);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("AddRotationInput"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(float*)(params.GetStructMemory() + 0) = Params.fPitch;
		*(float*)(params.GetStructMemory() + 4) = Params.fYaw;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.fPitch = *(float*)(params.GetStructMemory() + 0);
		Params.fYaw = *(float*)(params.GetStructMemory() + 4);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 AddLocationInput(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureGlobalCamera",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureGlobalCamera must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FVector Direction;
	} Params;
	Params.Direction = (wLua::FLuaVector::Get(InScriptContext, 2));
#if UE_GAME
	AAzureGlobalCamera * This = (AAzureGlobalCamera *)Obj;
	This->AddLocationInput(Params.Direction);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("AddLocationInput"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FVector*)(params.GetStructMemory() + 0) = Params.Direction;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.Direction = *(FVector*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 Get_RotationRate(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureGlobalCamera",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureGlobalCamera must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureGlobalCamera::StaticClass(), TEXT("RotationRate"));
	if(!Property) { check(false); return 0;}
	FVector PropertyValue = FVector();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaVector::Return(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_RotationRate(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureGlobalCamera",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureGlobalCamera must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureGlobalCamera::StaticClass(), TEXT("RotationRate"));
	if(!Property) { check(false); return 0;}
	FVector PropertyValue = (wLua::FLuaVector::Get(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_MaxMoveRange(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureGlobalCamera",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureGlobalCamera must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureGlobalCamera::StaticClass(), TEXT("MaxMoveRange"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_MaxMoveRange(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureGlobalCamera",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureGlobalCamera must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureGlobalCamera::StaticClass(), TEXT("MaxMoveRange"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_CanMoveByJoystick(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureGlobalCamera",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureGlobalCamera must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureGlobalCamera::StaticClass(), TEXT("CanMoveByJoystick"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = bool();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_CanMoveByJoystick(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureGlobalCamera",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureGlobalCamera must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureGlobalCamera::StaticClass(), TEXT("CanMoveByJoystick"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_HorizontalLimitation(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureGlobalCamera",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureGlobalCamera must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureGlobalCamera::StaticClass(), TEXT("HorizontalLimitation"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_HorizontalLimitation(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureGlobalCamera",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureGlobalCamera must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureGlobalCamera::StaticClass(), TEXT("HorizontalLimitation"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_CheckCollision(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureGlobalCamera",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureGlobalCamera must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureGlobalCamera::StaticClass(), TEXT("CheckCollision"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = bool();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_CheckCollision(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureGlobalCamera",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureGlobalCamera must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureGlobalCamera::StaticClass(), TEXT("CheckCollision"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 New(lua_State* InScriptContext)
{
	UObject* Outer = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Object");
	FName Name = FName(luaL_checkstring(InScriptContext, 2));
	UObject* Obj = NewObject<AAzureGlobalCamera>(Outer, Name);
	wLua::FLuaUtils::ReturnUObject(InScriptContext,Obj);
	return 1;
}

int32 Destroy(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureGlobalCamera",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureGlobalCamera must be non-null"); lua_error(InScriptContext);  return 0;}
		AActor * actor = Cast<AActor>(Obj);
		actor->Destroy();
		userdata->flag |= wLua::LuaObjectFlag::DESTROYED;
		wLua::FLuaUtils::RemoveObjectReference(Obj, userdata->stamp, InScriptContext);
#ifdef AZURE_BUILD_WLUACHECK
		UE_LOG(LogAzure, Warning, TEXT("Destroy AzureGlobalCamera: %x userdata:%x   stamp:%x"),Obj,userdata,userdata->stamp);
#endif
	return 0;
}

int32 Class(lua_State* InScriptContext)
{
	UClass* Class = AAzureGlobalCamera::StaticClass();
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Class);
	return 1;
}

const luaL_Reg Lib_Funcs[] =
{
	{ "New", New },
	{ "Destroy", Destroy },
	{ "Class", Class },
	{ "TransitTo", TransitTo },
	{ "SetMaxRangeBox", SetMaxRangeBox },
	{ "SetLookAtComponent", SetLookAtComponent },
	{ "SetGlobalCameraValue", SetGlobalCameraValue },
	{ "SetCameraMode", SetCameraMode },
	{ "IsTransiting", IsTransiting },
	{ "InitPosAndRot", InitPosAndRot },
	{ "AddRotationInput", AddRotationInput },
	{ "AddLocationInput", AddLocationInput },
	{ "Get_RotationRate", Get_RotationRate },
	{ "Set_RotationRate", Set_RotationRate },
	{ "Get_MaxMoveRange", Get_MaxMoveRange },
	{ "Set_MaxMoveRange", Set_MaxMoveRange },
	{ "Get_CanMoveByJoystick", Get_CanMoveByJoystick },
	{ "Set_CanMoveByJoystick", Set_CanMoveByJoystick },
	{ "Get_HorizontalLimitation", Get_HorizontalLimitation },
	{ "Set_HorizontalLimitation", Set_HorizontalLimitation },
	{ "Get_CheckCollision", Get_CheckCollision },
	{ "Set_CheckCollision", Set_CheckCollision },
	{ "is_nil", wLua::LuaStatic::isnil },
	{ "__gc", wLua::LuaStatic::removeUClassFrameCache },
	{ NULL, NULL }
};

void Register(lua_State *InScriptContext)
{
	lua_newtable(InScriptContext);
	luaL_register(InScriptContext, NULL, Lib_Funcs);
	AzureHelpFuncs::AuxRegister(InScriptContext, "AzureGlobalCamera");
}
void SetMtLink(lua_State *InScriptContext)
{
	AzureHelpFuncs::AuxSetMtLink(InScriptContext, "AzureGlobalCamera", "CameraActor",USERDATATYPE_UOBJECT);
}

}