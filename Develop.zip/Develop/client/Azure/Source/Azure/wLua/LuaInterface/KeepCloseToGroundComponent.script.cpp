#include "Azure.h"
#include "Utility/help_funcs.h"
#include "wLua/UObjectHeaders.h"
#include "GameLogic/PlayerComponent/KeepCloseToGroundComponent.h"
#include "AzureLuaIntegration.h"

namespace LuaKeepCloseToGroundComponent
{
int32 UpdateRotator(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"KeepCloseToGroundComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"KeepCloseToGroundComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float dt;
	} Params;
	Params.dt = (float)(luaL_checknumber(InScriptContext, 2));
	UFunction* Function = Obj->FindFunctionChecked(TEXT("UpdateRotator"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(float*)(params.GetStructMemory() + 0) = Params.dt;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.dt = *(float*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
	return 0;
}

int32 ImmediatelyUpdateRotator(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"KeepCloseToGroundComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"KeepCloseToGroundComponent must be non-null"); lua_error(InScriptContext);  return 0;}
#if UE_GAME
	UKeepCloseToGroundComponent * This = (UKeepCloseToGroundComponent *)Obj;
	This->ImmediatelyUpdateRotator();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("ImmediatelyUpdateRotator"));
	if(!Function) { check(false); return 0;}
	Obj->ProcessEvent(Function, NULL);
#endif
	return 0;
}

int32 Get_changePitch(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"KeepCloseToGroundComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"KeepCloseToGroundComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UKeepCloseToGroundComponent::StaticClass(), TEXT("changePitch"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = bool();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_changePitch(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"KeepCloseToGroundComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"KeepCloseToGroundComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UKeepCloseToGroundComponent::StaticClass(), TEXT("changePitch"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_changeRoll(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"KeepCloseToGroundComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"KeepCloseToGroundComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UKeepCloseToGroundComponent::StaticClass(), TEXT("changeRoll"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = bool();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_changeRoll(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"KeepCloseToGroundComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"KeepCloseToGroundComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UKeepCloseToGroundComponent::StaticClass(), TEXT("changeRoll"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_keepCloseGroundInterpSpeed(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"KeepCloseToGroundComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"KeepCloseToGroundComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UKeepCloseToGroundComponent::StaticClass(), TEXT("keepCloseGroundInterpSpeed"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_keepCloseGroundInterpSpeed(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"KeepCloseToGroundComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"KeepCloseToGroundComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UKeepCloseToGroundComponent::StaticClass(), TEXT("keepCloseGroundInterpSpeed"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_traceRaiseUpLength(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"KeepCloseToGroundComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"KeepCloseToGroundComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UKeepCloseToGroundComponent::StaticClass(), TEXT("traceRaiseUpLength"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_traceRaiseUpLength(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"KeepCloseToGroundComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"KeepCloseToGroundComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UKeepCloseToGroundComponent::StaticClass(), TEXT("traceRaiseUpLength"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_traceDownLength(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"KeepCloseToGroundComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"KeepCloseToGroundComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UKeepCloseToGroundComponent::StaticClass(), TEXT("traceDownLength"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_traceDownLength(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"KeepCloseToGroundComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"KeepCloseToGroundComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UKeepCloseToGroundComponent::StaticClass(), TEXT("traceDownLength"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_maxCloseGroundAngle(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"KeepCloseToGroundComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"KeepCloseToGroundComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UKeepCloseToGroundComponent::StaticClass(), TEXT("maxCloseGroundAngle"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_maxCloseGroundAngle(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"KeepCloseToGroundComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"KeepCloseToGroundComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UKeepCloseToGroundComponent::StaticClass(), TEXT("maxCloseGroundAngle"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_traceChannel(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"KeepCloseToGroundComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"KeepCloseToGroundComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UKeepCloseToGroundComponent::StaticClass(), TEXT("traceChannel"));
	if(!Property) { check(false); return 0;}
	TEnumAsByte<ECollisionChannel> PropertyValue = TEnumAsByte<ECollisionChannel>();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushinteger(InScriptContext, (int)PropertyValue);
	return 1;
}

int32 Set_traceChannel(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"KeepCloseToGroundComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"KeepCloseToGroundComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UKeepCloseToGroundComponent::StaticClass(), TEXT("traceChannel"));
	if(!Property) { check(false); return 0;}
	TEnumAsByte<ECollisionChannel> PropertyValue = (TEnumAsByte<ECollisionChannel>)(luaL_checkint(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_enableCloseGround(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"KeepCloseToGroundComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"KeepCloseToGroundComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UKeepCloseToGroundComponent::StaticClass(), TEXT("enableCloseGround"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = bool();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_enableCloseGround(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"KeepCloseToGroundComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"KeepCloseToGroundComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UKeepCloseToGroundComponent::StaticClass(), TEXT("enableCloseGround"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_changeMeshAngle(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"KeepCloseToGroundComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"KeepCloseToGroundComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UKeepCloseToGroundComponent::StaticClass(), TEXT("changeMeshAngle"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = bool();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_changeMeshAngle(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"KeepCloseToGroundComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"KeepCloseToGroundComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UKeepCloseToGroundComponent::StaticClass(), TEXT("changeMeshAngle"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_drawDebug(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"KeepCloseToGroundComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"KeepCloseToGroundComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UKeepCloseToGroundComponent::StaticClass(), TEXT("drawDebug"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = bool();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_drawDebug(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"KeepCloseToGroundComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"KeepCloseToGroundComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UKeepCloseToGroundComponent::StaticClass(), TEXT("drawDebug"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_targetRotator(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"KeepCloseToGroundComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"KeepCloseToGroundComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UKeepCloseToGroundComponent::StaticClass(), TEXT("targetRotator"));
	if(!Property) { check(false); return 0;}
	FRotator PropertyValue = FRotator();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaRotator::Return(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_capsuleComponent(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"KeepCloseToGroundComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"KeepCloseToGroundComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UKeepCloseToGroundComponent::StaticClass(), TEXT("capsuleComponent"));
	if(!Property) { check(false); return 0;}
	UCapsuleComponent* PropertyValue;
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaUtils::ReturnUObject(InScriptContext, PropertyValue);
	return 1;
}

int32 New(lua_State* InScriptContext)
{
	UObject* Outer = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Object");
	FName Name = FName(luaL_checkstring(InScriptContext, 2));
	UObject* Obj = NewObject<UKeepCloseToGroundComponent>(Outer, Name);
	wLua::FLuaUtils::ReturnUObject(InScriptContext,Obj);
	return 1;
}

int32 Destroy(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"KeepCloseToGroundComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"KeepCloseToGroundComponent must be non-null"); lua_error(InScriptContext);  return 0;}
		UActorComponent * com = Cast<UActorComponent>(Obj);
		if(lua_isnoneornil(InScriptContext,2))
			com->DestroyComponent();
		else
			com->DestroyComponent(!!lua_toboolean(InScriptContext,2));
		userdata->flag |= wLua::LuaObjectFlag::DESTROYED;
		wLua::FLuaUtils::RemoveObjectReference(Obj, userdata->stamp, InScriptContext);
#ifdef AZURE_BUILD_WLUACHECK
		UE_LOG(LogAzure, Warning, TEXT("Destroy KeepCloseToGroundComponent: %x userdata:%x   stamp:%x"),Obj,userdata,userdata->stamp);
#endif
	return 0;
}

int32 Class(lua_State* InScriptContext)
{
	UClass* Class = UKeepCloseToGroundComponent::StaticClass();
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Class);
	return 1;
}

const luaL_Reg Lib_Funcs[] =
{
	{ "New", New },
	{ "Destroy", Destroy },
	{ "Class", Class },
	{ "UpdateRotator", UpdateRotator },
	{ "ImmediatelyUpdateRotator", ImmediatelyUpdateRotator },
	{ "Get_changePitch", Get_changePitch },
	{ "Set_changePitch", Set_changePitch },
	{ "Get_changeRoll", Get_changeRoll },
	{ "Set_changeRoll", Set_changeRoll },
	{ "Get_keepCloseGroundInterpSpeed", Get_keepCloseGroundInterpSpeed },
	{ "Set_keepCloseGroundInterpSpeed", Set_keepCloseGroundInterpSpeed },
	{ "Get_traceRaiseUpLength", Get_traceRaiseUpLength },
	{ "Set_traceRaiseUpLength", Set_traceRaiseUpLength },
	{ "Get_traceDownLength", Get_traceDownLength },
	{ "Set_traceDownLength", Set_traceDownLength },
	{ "Get_maxCloseGroundAngle", Get_maxCloseGroundAngle },
	{ "Set_maxCloseGroundAngle", Set_maxCloseGroundAngle },
	{ "Get_traceChannel", Get_traceChannel },
	{ "Set_traceChannel", Set_traceChannel },
	{ "Get_enableCloseGround", Get_enableCloseGround },
	{ "Set_enableCloseGround", Set_enableCloseGround },
	{ "Get_changeMeshAngle", Get_changeMeshAngle },
	{ "Set_changeMeshAngle", Set_changeMeshAngle },
	{ "Get_drawDebug", Get_drawDebug },
	{ "Set_drawDebug", Set_drawDebug },
	{ "Get_targetRotator", Get_targetRotator },
	{ "Get_capsuleComponent", Get_capsuleComponent },
	{ "is_nil", wLua::LuaStatic::isnil },
	{ "__gc", wLua::LuaStatic::removeUClassFrameCache },
	{ NULL, NULL }
};

void Register(lua_State *InScriptContext)
{
	lua_newtable(InScriptContext);
	luaL_register(InScriptContext, NULL, Lib_Funcs);
	AzureHelpFuncs::AuxRegister(InScriptContext, "KeepCloseToGroundComponent");
}
void SetMtLink(lua_State *InScriptContext)
{
	AzureHelpFuncs::AuxSetMtLink(InScriptContext, "KeepCloseToGroundComponent", "ActorComponent",USERDATATYPE_UOBJECT);
}

}