#include "Azure.h"
#include "Utility/help_funcs.h"
#include "wLua/UObjectHeaders.h"
#include "AzureLuaIntegration.h"

namespace LuaSoundBase
{
int32 Get_SoundClassObject(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SoundBase",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SoundBase must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USoundBase::StaticClass(), TEXT("SoundClassObject"));
	if(!Property) { check(false); return 0;}
	USoundClass* PropertyValue;
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaUtils::ReturnUObject(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_SoundClassObject(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SoundBase",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SoundBase must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USoundBase::StaticClass(), TEXT("SoundClassObject"));
	if(!Property) { check(false); return 0;}
	USoundClass* PropertyValue = (USoundClass*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"SoundClass");;
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bDebug(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SoundBase",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SoundBase must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USoundBase::StaticClass(), TEXT("bDebug"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bDebug(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SoundBase",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SoundBase must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USoundBase::StaticClass(), TEXT("bDebug"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bOverrideConcurrency(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SoundBase",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SoundBase must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USoundBase::StaticClass(), TEXT("bOverrideConcurrency"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bOverrideConcurrency(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SoundBase",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SoundBase must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USoundBase::StaticClass(), TEXT("bOverrideConcurrency"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bOutputToBusOnly(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SoundBase",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SoundBase must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USoundBase::StaticClass(), TEXT("bOutputToBusOnly"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bOutputToBusOnly(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SoundBase",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SoundBase must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USoundBase::StaticClass(), TEXT("bOutputToBusOnly"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bBypassVolumeScaleForPriority(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SoundBase",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SoundBase must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USoundBase::StaticClass(), TEXT("bBypassVolumeScaleForPriority"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bBypassVolumeScaleForPriority(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SoundBase",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SoundBase must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USoundBase::StaticClass(), TEXT("bBypassVolumeScaleForPriority"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_SoundConcurrencySettings(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SoundBase",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SoundBase must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USoundBase::StaticClass(), TEXT("SoundConcurrencySettings"));
	if(!Property) { check(false); return 0;}
	USoundConcurrency* PropertyValue;
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaUtils::ReturnUObject(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_SoundConcurrencySettings(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SoundBase",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SoundBase must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USoundBase::StaticClass(), TEXT("SoundConcurrencySettings"));
	if(!Property) { check(false); return 0;}
	USoundConcurrency* PropertyValue = (USoundConcurrency*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"SoundConcurrency");;
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_Duration(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SoundBase",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SoundBase must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USoundBase::StaticClass(), TEXT("Duration"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_MaxDistance(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SoundBase",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SoundBase must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USoundBase::StaticClass(), TEXT("MaxDistance"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_TotalSamples(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SoundBase",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SoundBase must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USoundBase::StaticClass(), TEXT("TotalSamples"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_Priority(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SoundBase",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SoundBase must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USoundBase::StaticClass(), TEXT("Priority"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_Priority(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SoundBase",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SoundBase must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USoundBase::StaticClass(), TEXT("Priority"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_AttenuationSettings(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SoundBase",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SoundBase must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USoundBase::StaticClass(), TEXT("AttenuationSettings"));
	if(!Property) { check(false); return 0;}
	USoundAttenuation* PropertyValue;
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaUtils::ReturnUObject(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_AttenuationSettings(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SoundBase",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SoundBase must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USoundBase::StaticClass(), TEXT("AttenuationSettings"));
	if(!Property) { check(false); return 0;}
	USoundAttenuation* PropertyValue = (USoundAttenuation*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"SoundAttenuation");;
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_SoundSubmixObject(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SoundBase",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SoundBase must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USoundBase::StaticClass(), TEXT("SoundSubmixObject"));
	if(!Property) { check(false); return 0;}
	USoundSubmix* PropertyValue;
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaUtils::ReturnUObject(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_SoundSubmixObject(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SoundBase",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SoundBase must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USoundBase::StaticClass(), TEXT("SoundSubmixObject"));
	if(!Property) { check(false); return 0;}
	USoundSubmix* PropertyValue = (USoundSubmix*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"SoundSubmix");;
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_SourceEffectChain(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SoundBase",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SoundBase must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USoundBase::StaticClass(), TEXT("SourceEffectChain"));
	if(!Property) { check(false); return 0;}
	USoundEffectSourcePresetChain* PropertyValue;
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaUtils::ReturnUObject(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_SourceEffectChain(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SoundBase",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SoundBase must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USoundBase::StaticClass(), TEXT("SourceEffectChain"));
	if(!Property) { check(false); return 0;}
	USoundEffectSourcePresetChain* PropertyValue = (USoundEffectSourcePresetChain*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"SoundEffectSourcePresetChain");;
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Class(lua_State* InScriptContext)
{
	UClass* Class = USoundBase::StaticClass();
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Class);
	return 1;
}

const luaL_Reg Lib_Funcs[] =
{
	{ "Class", Class },
	{ "Get_SoundClassObject", Get_SoundClassObject },
	{ "Set_SoundClassObject", Set_SoundClassObject },
	{ "Get_bDebug", Get_bDebug },
	{ "Set_bDebug", Set_bDebug },
	{ "Get_bOverrideConcurrency", Get_bOverrideConcurrency },
	{ "Set_bOverrideConcurrency", Set_bOverrideConcurrency },
	{ "Get_bOutputToBusOnly", Get_bOutputToBusOnly },
	{ "Set_bOutputToBusOnly", Set_bOutputToBusOnly },
	{ "Get_bBypassVolumeScaleForPriority", Get_bBypassVolumeScaleForPriority },
	{ "Set_bBypassVolumeScaleForPriority", Set_bBypassVolumeScaleForPriority },
	{ "Get_SoundConcurrencySettings", Get_SoundConcurrencySettings },
	{ "Set_SoundConcurrencySettings", Set_SoundConcurrencySettings },
	{ "Get_Duration", Get_Duration },
	{ "Get_MaxDistance", Get_MaxDistance },
	{ "Get_TotalSamples", Get_TotalSamples },
	{ "Get_Priority", Get_Priority },
	{ "Set_Priority", Set_Priority },
	{ "Get_AttenuationSettings", Get_AttenuationSettings },
	{ "Set_AttenuationSettings", Set_AttenuationSettings },
	{ "Get_SoundSubmixObject", Get_SoundSubmixObject },
	{ "Set_SoundSubmixObject", Set_SoundSubmixObject },
	{ "Get_SourceEffectChain", Get_SourceEffectChain },
	{ "Set_SourceEffectChain", Set_SourceEffectChain },
	{ "is_nil", wLua::LuaStatic::isnil },
	{ "__gc", wLua::LuaStatic::removeUClassFrameCache },
	{ NULL, NULL }
};

void Register(lua_State *InScriptContext)
{
	lua_newtable(InScriptContext);
	luaL_register(InScriptContext, NULL, Lib_Funcs);
	AzureHelpFuncs::AuxRegister(InScriptContext, "SoundBase");
}
void SetMtLink(lua_State *InScriptContext)
{
	AzureHelpFuncs::AuxSetMtLink(InScriptContext, "SoundBase", "Object",USERDATATYPE_UOBJECT);
}

}