#include "Azure.h"
#include "Utility/help_funcs.h"
#include "wLua/UObjectHeaders.h"
#include "GameFramework/NavMovementComponent.h"
#include "AzureLuaIntegration.h"

namespace LuaNavMovementComponent
{
int32 StopMovementKeepPathing(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"NavMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"NavMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
#if UE_GAME
	UNavMovementComponent * This = (UNavMovementComponent *)Obj;
	This->StopMovementKeepPathing();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("StopMovementKeepPathing"));
	if(!Function) { check(false); return 0;}
	Obj->ProcessEvent(Function, NULL);
#endif
	return 0;
}

int32 StopActiveMovement(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"NavMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"NavMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
#if UE_GAME
	UNavMovementComponent * This = (UNavMovementComponent *)Obj;
	This->StopActiveMovement();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("StopActiveMovement"));
	if(!Function) { check(false); return 0;}
	Obj->ProcessEvent(Function, NULL);
#endif
	return 0;
}

int32 IsSwimming(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"NavMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"NavMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool ReturnValue;
	} Params;
#if UE_GAME
	UNavMovementComponent * This = (UNavMovementComponent *)Obj;
	Params.ReturnValue = This->IsSwimming();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("IsSwimming"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushboolean(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 IsMovingOnGround(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"NavMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"NavMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool ReturnValue;
	} Params;
#if UE_GAME
	UNavMovementComponent * This = (UNavMovementComponent *)Obj;
	Params.ReturnValue = This->IsMovingOnGround();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("IsMovingOnGround"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushboolean(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 IsFlying(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"NavMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"NavMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool ReturnValue;
	} Params;
#if UE_GAME
	UNavMovementComponent * This = (UNavMovementComponent *)Obj;
	Params.ReturnValue = This->IsFlying();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("IsFlying"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushboolean(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 IsFalling(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"NavMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"NavMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool ReturnValue;
	} Params;
#if UE_GAME
	UNavMovementComponent * This = (UNavMovementComponent *)Obj;
	Params.ReturnValue = This->IsFalling();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("IsFalling"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushboolean(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 IsCrouching(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"NavMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"NavMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool ReturnValue;
	} Params;
#if UE_GAME
	UNavMovementComponent * This = (UNavMovementComponent *)Obj;
	Params.ReturnValue = This->IsCrouching();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("IsCrouching"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushboolean(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 Get_FixedPathBrakingDistance(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"NavMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"NavMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UNavMovementComponent::StaticClass(), TEXT("FixedPathBrakingDistance"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_FixedPathBrakingDistance(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"NavMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"NavMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UNavMovementComponent::StaticClass(), TEXT("FixedPathBrakingDistance"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bUpdateNavAgentWithOwnersCollision(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"NavMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"NavMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UNavMovementComponent::StaticClass(), TEXT("bUpdateNavAgentWithOwnersCollision"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bUpdateNavAgentWithOwnersCollision(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"NavMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"NavMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UNavMovementComponent::StaticClass(), TEXT("bUpdateNavAgentWithOwnersCollision"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bUseAccelerationForPaths(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"NavMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"NavMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UNavMovementComponent::StaticClass(), TEXT("bUseAccelerationForPaths"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bUseAccelerationForPaths(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"NavMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"NavMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UNavMovementComponent::StaticClass(), TEXT("bUseAccelerationForPaths"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bUseFixedBrakingDistanceForPaths(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"NavMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"NavMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UNavMovementComponent::StaticClass(), TEXT("bUseFixedBrakingDistanceForPaths"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bUseFixedBrakingDistanceForPaths(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"NavMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"NavMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UNavMovementComponent::StaticClass(), TEXT("bUseFixedBrakingDistanceForPaths"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Class(lua_State* InScriptContext)
{
	UClass* Class = UNavMovementComponent::StaticClass();
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Class);
	return 1;
}

const luaL_Reg Lib_Funcs[] =
{
	{ "Class", Class },
	{ "StopMovementKeepPathing", StopMovementKeepPathing },
	{ "StopActiveMovement", StopActiveMovement },
	{ "IsSwimming", IsSwimming },
	{ "IsMovingOnGround", IsMovingOnGround },
	{ "IsFlying", IsFlying },
	{ "IsFalling", IsFalling },
	{ "IsCrouching", IsCrouching },
	{ "Get_FixedPathBrakingDistance", Get_FixedPathBrakingDistance },
	{ "Set_FixedPathBrakingDistance", Set_FixedPathBrakingDistance },
	{ "Get_bUpdateNavAgentWithOwnersCollision", Get_bUpdateNavAgentWithOwnersCollision },
	{ "Set_bUpdateNavAgentWithOwnersCollision", Set_bUpdateNavAgentWithOwnersCollision },
	{ "Get_bUseAccelerationForPaths", Get_bUseAccelerationForPaths },
	{ "Set_bUseAccelerationForPaths", Set_bUseAccelerationForPaths },
	{ "Get_bUseFixedBrakingDistanceForPaths", Get_bUseFixedBrakingDistanceForPaths },
	{ "Set_bUseFixedBrakingDistanceForPaths", Set_bUseFixedBrakingDistanceForPaths },
	{ "is_nil", wLua::LuaStatic::isnil },
	{ "__gc", wLua::LuaStatic::removeUClassFrameCache },
	{ NULL, NULL }
};

void Register(lua_State *InScriptContext)
{
	lua_newtable(InScriptContext);
	luaL_register(InScriptContext, NULL, Lib_Funcs);
	AzureHelpFuncs::AuxRegister(InScriptContext, "NavMovementComponent");
}
void SetMtLink(lua_State *InScriptContext)
{
	AzureHelpFuncs::AuxSetMtLink(InScriptContext, "NavMovementComponent", "MovementComponent",USERDATATYPE_UOBJECT);
}

}