#include "Azure.h"
#include "Utility/help_funcs.h"
#include "wLua/UObjectHeaders.h"
#include "Components/TextBlock.h"
#include "AzureLuaIntegration.h"

namespace LuaTextBlock
{
int32 SetColorAndOpacity(lua_State*);
int32 SetFontSize(lua_State*);

int32 SetUnderlineColor(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"TextBlock",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"TextBlock must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FLinearColor InColor;
	} Params;
	Params.InColor = (wLua::FLuaLinearColor::Get(InScriptContext, 2));
#if UE_GAME
	UTextBlock * This = (UTextBlock *)Obj;
	This->SetUnderlineColor(Params.InColor);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetUnderlineColor"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FLinearColor*)(params.GetStructMemory() + 0) = Params.InColor;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.InColor = *(FLinearColor*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetText(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"TextBlock",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"TextBlock must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FText InText;
	} Params;
	Params.InText = FText::FromString(UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 2)));
#if UE_GAME
	UTextBlock * This = (UTextBlock *)Obj;
	This->SetText(Params.InText);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetText"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FText*)(params.GetStructMemory() + 0) = Params.InText;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.InText = *(FText*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetStrikeoutColor(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"TextBlock",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"TextBlock must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FLinearColor InColor;
	} Params;
	Params.InColor = (wLua::FLuaLinearColor::Get(InScriptContext, 2));
#if UE_GAME
	UTextBlock * This = (UTextBlock *)Obj;
	This->SetStrikeoutColor(Params.InColor);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetStrikeoutColor"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FLinearColor*)(params.GetStructMemory() + 0) = Params.InColor;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.InColor = *(FLinearColor*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetShadowOffset(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"TextBlock",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"TextBlock must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FVector2D InShadowOffset;
	} Params;
	Params.InShadowOffset = (wLua::FLuaVector2D::Get(InScriptContext, 2));
#if UE_GAME
	UTextBlock * This = (UTextBlock *)Obj;
	This->SetShadowOffset(Params.InShadowOffset);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetShadowOffset"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FVector2D*)(params.GetStructMemory() + 0) = Params.InShadowOffset;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.InShadowOffset = *(FVector2D*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetShadowColorAndOpacity(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"TextBlock",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"TextBlock must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FLinearColor InShadowColorAndOpacity;
	} Params;
	Params.InShadowColorAndOpacity = (wLua::FLuaLinearColor::Get(InScriptContext, 2));
#if UE_GAME
	UTextBlock * This = (UTextBlock *)Obj;
	This->SetShadowColorAndOpacity(Params.InShadowColorAndOpacity);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetShadowColorAndOpacity"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FLinearColor*)(params.GetStructMemory() + 0) = Params.InShadowColorAndOpacity;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.InShadowColorAndOpacity = *(FLinearColor*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetOpacity(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"TextBlock",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"TextBlock must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float InOpacity;
	} Params;
	Params.InOpacity = (float)(luaL_checknumber(InScriptContext, 2));
#if UE_GAME
	UTextBlock * This = (UTextBlock *)Obj;
	This->SetOpacity(Params.InOpacity);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetOpacity"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(float*)(params.GetStructMemory() + 0) = Params.InOpacity;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.InOpacity = *(float*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetMinDesiredWidth(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"TextBlock",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"TextBlock must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float InMinDesiredWidth;
	} Params;
	Params.InMinDesiredWidth = (float)(luaL_checknumber(InScriptContext, 2));
#if UE_GAME
	UTextBlock * This = (UTextBlock *)Obj;
	This->SetMinDesiredWidth(Params.InMinDesiredWidth);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetMinDesiredWidth"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(float*)(params.GetStructMemory() + 0) = Params.InMinDesiredWidth;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.InMinDesiredWidth = *(float*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetJustification(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"TextBlock",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"TextBlock must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		TEnumAsByte<ETextJustify::Type> InJustification;
	} Params;
	Params.InJustification = (TEnumAsByte<ETextJustify::Type>)(luaL_checkint(InScriptContext, 2));
#if UE_GAME
	UTextBlock * This = (UTextBlock *)Obj;
	This->SetJustification(Params.InJustification);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetJustification"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(TEnumAsByte<ETextJustify::Type>*)(params.GetStructMemory() + 0) = Params.InJustification;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.InJustification = *(TEnumAsByte<ETextJustify::Type>*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetAutoWrapText(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"TextBlock",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"TextBlock must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool InAutoTextWrap;
	} Params;
	Params.InAutoTextWrap = !!(lua_toboolean(InScriptContext, 2));
#if UE_GAME
	UTextBlock * This = (UTextBlock *)Obj;
	This->SetAutoWrapText(Params.InAutoTextWrap);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetAutoWrapText"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(bool*)(params.GetStructMemory() + 0) = Params.InAutoTextWrap;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.InAutoTextWrap = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 GetUnderlineColor(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"TextBlock",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"TextBlock must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FLinearColor ReturnValue;
	} Params;
#if UE_GAME
	UTextBlock * This = (UTextBlock *)Obj;
	Params.ReturnValue = This->GetUnderlineColor();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetUnderlineColor"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(FLinearColor*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaLinearColor::Return(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetText(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"TextBlock",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"TextBlock must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FText ReturnValue;
	} Params;
#if UE_GAME
	UTextBlock * This = (UTextBlock *)Obj;
	Params.ReturnValue = This->GetText();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetText"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(FText*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushstring(InScriptContext, TCHAR_TO_UTF8(*Params.ReturnValue.ToString()));
	return 1;
}

int32 GetStrikeoutColor(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"TextBlock",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"TextBlock must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FLinearColor ReturnValue;
	} Params;
#if UE_GAME
	UTextBlock * This = (UTextBlock *)Obj;
	Params.ReturnValue = This->GetStrikeoutColor();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetStrikeoutColor"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(FLinearColor*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaLinearColor::Return(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetDynamicOutlineMaterial(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"TextBlock",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"TextBlock must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		UMaterialInstanceDynamic* ReturnValue = nullptr;
	} Params;
#if UE_GAME
	UTextBlock * This = (UTextBlock *)Obj;
	Params.ReturnValue = This->GetDynamicOutlineMaterial();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetDynamicOutlineMaterial"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(UMaterialInstanceDynamic**)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetDynamicFontMaterial(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"TextBlock",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"TextBlock must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		UMaterialInstanceDynamic* ReturnValue = nullptr;
	} Params;
#if UE_GAME
	UTextBlock * This = (UTextBlock *)Obj;
	Params.ReturnValue = This->GetDynamicFontMaterial();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetDynamicFontMaterial"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(UMaterialInstanceDynamic**)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 ChangeUnderlineColor(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"TextBlock",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"TextBlock must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FLinearColor InColor;
	} Params;
	Params.InColor = (wLua::FLuaLinearColor::Get(InScriptContext, 2));
#if UE_GAME
	UTextBlock * This = (UTextBlock *)Obj;
	This->ChangeUnderlineColor(Params.InColor);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("ChangeUnderlineColor"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FLinearColor*)(params.GetStructMemory() + 0) = Params.InColor;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.InColor = *(FLinearColor*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 ChangeStrikeoutColor(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"TextBlock",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"TextBlock must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FLinearColor InColor;
	} Params;
	Params.InColor = (wLua::FLuaLinearColor::Get(InScriptContext, 2));
#if UE_GAME
	UTextBlock * This = (UTextBlock *)Obj;
	This->ChangeStrikeoutColor(Params.InColor);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("ChangeStrikeoutColor"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FLinearColor*)(params.GetStructMemory() + 0) = Params.InColor;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.InColor = *(FLinearColor*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 Get_Text(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"TextBlock",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"TextBlock must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UTextBlock::StaticClass(), TEXT("Text"));
	if(!Property) { check(false); return 0;}
	FText PropertyValue;
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushstring(InScriptContext, TCHAR_TO_UTF8(*PropertyValue.ToString()));
	return 1;
}

int32 Set_Text(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"TextBlock",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"TextBlock must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UTextBlock::StaticClass(), TEXT("Text"));
	if(!Property) { check(false); return 0;}
	FText PropertyValue = FText::FromString(UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 2)));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_ShadowOffset(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"TextBlock",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"TextBlock must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UTextBlock::StaticClass(), TEXT("ShadowOffset"));
	if(!Property) { check(false); return 0;}
	FVector2D PropertyValue = FVector2D();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaVector2D::Return(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_ShadowColorAndOpacity(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"TextBlock",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"TextBlock must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UTextBlock::StaticClass(), TEXT("ShadowColorAndOpacity"));
	if(!Property) { check(false); return 0;}
	FLinearColor PropertyValue = FLinearColor();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaLinearColor::Return(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_ShadowMaterialOverride(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"TextBlock",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"TextBlock must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UTextBlock::StaticClass(), TEXT("ShadowMaterialOverride"));
	if(!Property) { check(false); return 0;}
	UObject* PropertyValue;
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaUtils::ReturnUObject(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_ShadowMaterialOverride(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"TextBlock",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"TextBlock must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UTextBlock::StaticClass(), TEXT("ShadowMaterialOverride"));
	if(!Property) { check(false); return 0;}
	UObject* PropertyValue = (UObject*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"Object");;
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_UnderlineColor(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"TextBlock",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"TextBlock must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UTextBlock::StaticClass(), TEXT("UnderlineColor"));
	if(!Property) { check(false); return 0;}
	FLinearColor PropertyValue = FLinearColor();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaLinearColor::Return(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_UnderlineColor(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"TextBlock",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"TextBlock must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UTextBlock::StaticClass(), TEXT("UnderlineColor"));
	if(!Property) { check(false); return 0;}
	FLinearColor PropertyValue = (wLua::FLuaLinearColor::Get(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_StrikeoutColor(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"TextBlock",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"TextBlock must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UTextBlock::StaticClass(), TEXT("StrikeoutColor"));
	if(!Property) { check(false); return 0;}
	FLinearColor PropertyValue = FLinearColor();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaLinearColor::Return(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_StrikeoutColor(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"TextBlock",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"TextBlock must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UTextBlock::StaticClass(), TEXT("StrikeoutColor"));
	if(!Property) { check(false); return 0;}
	FLinearColor PropertyValue = (wLua::FLuaLinearColor::Get(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_MinDesiredWidth(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"TextBlock",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"TextBlock must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UTextBlock::StaticClass(), TEXT("MinDesiredWidth"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_bWrapWithInvalidationPanel(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"TextBlock",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"TextBlock must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UTextBlock::StaticClass(), TEXT("bWrapWithInvalidationPanel"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = bool();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_UseNoPixelSnapping(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"TextBlock",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"TextBlock must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UTextBlock::StaticClass(), TEXT("UseNoPixelSnapping"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = bool();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_UseNoPixelSnapping(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"TextBlock",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"TextBlock must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UTextBlock::StaticClass(), TEXT("UseNoPixelSnapping"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bAutoWrapTextHeight(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"TextBlock",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"TextBlock must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UTextBlock::StaticClass(), TEXT("bAutoWrapTextHeight"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = bool();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_WrapTextHeightAt(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"TextBlock",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"TextBlock must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UTextBlock::StaticClass(), TEXT("WrapTextHeightAt"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 New(lua_State* InScriptContext)
{
	UObject* Outer = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Object");
	FName Name = FName(luaL_checkstring(InScriptContext, 2));
	UObject* Obj = NewObject<UTextBlock>(Outer, Name);
	wLua::FLuaUtils::ReturnUObject(InScriptContext,Obj);
	return 1;
}

int32 Destroy(lua_State* InScriptContext)
{
	return 0;
}

int32 Class(lua_State* InScriptContext)
{
	UClass* Class = UTextBlock::StaticClass();
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Class);
	return 1;
}

const luaL_Reg Lib_Funcs[] =
{
	{ "New", New },
	{ "Destroy", Destroy },
	{ "Class", Class },
	{ "SetUnderlineColor", SetUnderlineColor },
	{ "SetText", SetText },
	{ "SetStrikeoutColor", SetStrikeoutColor },
	{ "SetShadowOffset", SetShadowOffset },
	{ "SetShadowColorAndOpacity", SetShadowColorAndOpacity },
	{ "SetOpacity", SetOpacity },
	{ "SetMinDesiredWidth", SetMinDesiredWidth },
	{ "SetJustification", SetJustification },
	{ "SetAutoWrapText", SetAutoWrapText },
	{ "GetUnderlineColor", GetUnderlineColor },
	{ "GetText", GetText },
	{ "GetStrikeoutColor", GetStrikeoutColor },
	{ "GetDynamicOutlineMaterial", GetDynamicOutlineMaterial },
	{ "GetDynamicFontMaterial", GetDynamicFontMaterial },
	{ "ChangeUnderlineColor", ChangeUnderlineColor },
	{ "ChangeStrikeoutColor", ChangeStrikeoutColor },
	{ "Get_Text", Get_Text },
	{ "Set_Text", Set_Text },
	{ "Get_ShadowOffset", Get_ShadowOffset },
	{ "Get_ShadowColorAndOpacity", Get_ShadowColorAndOpacity },
	{ "Get_ShadowMaterialOverride", Get_ShadowMaterialOverride },
	{ "Set_ShadowMaterialOverride", Set_ShadowMaterialOverride },
	{ "Get_UnderlineColor", Get_UnderlineColor },
	{ "Set_UnderlineColor", Set_UnderlineColor },
	{ "Get_StrikeoutColor", Get_StrikeoutColor },
	{ "Set_StrikeoutColor", Set_StrikeoutColor },
	{ "Get_MinDesiredWidth", Get_MinDesiredWidth },
	{ "Get_bWrapWithInvalidationPanel", Get_bWrapWithInvalidationPanel },
	{ "Get_UseNoPixelSnapping", Get_UseNoPixelSnapping },
	{ "Set_UseNoPixelSnapping", Set_UseNoPixelSnapping },
	{ "Get_bAutoWrapTextHeight", Get_bAutoWrapTextHeight },
	{ "Get_WrapTextHeightAt", Get_WrapTextHeightAt },
	{ "SetColorAndOpacity", SetColorAndOpacity },
	{ "SetFontSize", SetFontSize },
	{ "is_nil", wLua::LuaStatic::isnil },
	{ "__gc", wLua::LuaStatic::removeUClassFrameCache },
	{ NULL, NULL }
};

void Register(lua_State *InScriptContext)
{
	lua_newtable(InScriptContext);
	luaL_register(InScriptContext, NULL, Lib_Funcs);
	AzureHelpFuncs::AuxRegister(InScriptContext, "TextBlock");
}
void SetMtLink(lua_State *InScriptContext)
{
	AzureHelpFuncs::AuxSetMtLink(InScriptContext, "TextBlock", "TextLayoutWidget",USERDATATYPE_UOBJECT);
}

}