#include "Azure.h"
#include "Utility/help_funcs.h"
#include "wLua/UObjectHeaders.h"
#include "Components/SceneCaptureComponent2D.h"
#include "AzureLuaIntegration.h"

namespace LuaSceneCaptureComponent2D
{
int32 DisableAllPostProcess(lua_State*);

int32 CaptureScene(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SceneCaptureComponent2D",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SceneCaptureComponent2D must be non-null"); lua_error(InScriptContext);  return 0;}
#if UE_GAME
	USceneCaptureComponent2D * This = (USceneCaptureComponent2D *)Obj;
	This->CaptureScene();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("CaptureScene"));
	if(!Function) { check(false); return 0;}
	Obj->ProcessEvent(Function, NULL);
#endif
	return 0;
}

int32 Get_ProjectionType(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SceneCaptureComponent2D",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SceneCaptureComponent2D must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USceneCaptureComponent2D::StaticClass(), TEXT("ProjectionType"));
	if(!Property) { check(false); return 0;}
	TEnumAsByte<ECameraProjectionMode::Type> PropertyValue = TEnumAsByte<ECameraProjectionMode::Type>();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushinteger(InScriptContext, (int)PropertyValue);
	return 1;
}

int32 Set_ProjectionType(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SceneCaptureComponent2D",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SceneCaptureComponent2D must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USceneCaptureComponent2D::StaticClass(), TEXT("ProjectionType"));
	if(!Property) { check(false); return 0;}
	TEnumAsByte<ECameraProjectionMode::Type> PropertyValue = (TEnumAsByte<ECameraProjectionMode::Type>)(luaL_checkint(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_FOVAngle(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SceneCaptureComponent2D",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SceneCaptureComponent2D must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USceneCaptureComponent2D::StaticClass(), TEXT("FOVAngle"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_FOVAngle(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SceneCaptureComponent2D",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SceneCaptureComponent2D must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USceneCaptureComponent2D::StaticClass(), TEXT("FOVAngle"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_OrthoWidth(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SceneCaptureComponent2D",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SceneCaptureComponent2D must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USceneCaptureComponent2D::StaticClass(), TEXT("OrthoWidth"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_OrthoWidth(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SceneCaptureComponent2D",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SceneCaptureComponent2D must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USceneCaptureComponent2D::StaticClass(), TEXT("OrthoWidth"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_TextureTarget(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SceneCaptureComponent2D",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SceneCaptureComponent2D must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USceneCaptureComponent2D::StaticClass(), TEXT("TextureTarget"));
	if(!Property) { check(false); return 0;}
	UTextureRenderTarget2D* PropertyValue;
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaUtils::ReturnUObject(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_TextureTarget(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SceneCaptureComponent2D",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SceneCaptureComponent2D must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USceneCaptureComponent2D::StaticClass(), TEXT("TextureTarget"));
	if(!Property) { check(false); return 0;}
	UTextureRenderTarget2D* PropertyValue = (UTextureRenderTarget2D*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"TextureRenderTarget2D");;
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_CaptureSource(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SceneCaptureComponent2D",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SceneCaptureComponent2D must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USceneCaptureComponent2D::StaticClass(), TEXT("CaptureSource"));
	if(!Property) { check(false); return 0;}
	TEnumAsByte<ESceneCaptureSource> PropertyValue = TEnumAsByte<ESceneCaptureSource>();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushinteger(InScriptContext, (int)PropertyValue);
	return 1;
}

int32 Set_CaptureSource(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SceneCaptureComponent2D",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SceneCaptureComponent2D must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USceneCaptureComponent2D::StaticClass(), TEXT("CaptureSource"));
	if(!Property) { check(false); return 0;}
	TEnumAsByte<ESceneCaptureSource> PropertyValue = (TEnumAsByte<ESceneCaptureSource>)(luaL_checkint(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_CompositeMode(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SceneCaptureComponent2D",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SceneCaptureComponent2D must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USceneCaptureComponent2D::StaticClass(), TEXT("CompositeMode"));
	if(!Property) { check(false); return 0;}
	TEnumAsByte<ESceneCaptureCompositeMode> PropertyValue = TEnumAsByte<ESceneCaptureCompositeMode>();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushinteger(InScriptContext, (int)PropertyValue);
	return 1;
}

int32 Set_CompositeMode(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SceneCaptureComponent2D",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SceneCaptureComponent2D must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USceneCaptureComponent2D::StaticClass(), TEXT("CompositeMode"));
	if(!Property) { check(false); return 0;}
	TEnumAsByte<ESceneCaptureCompositeMode> PropertyValue = (TEnumAsByte<ESceneCaptureCompositeMode>)(luaL_checkint(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_PostProcessBlendWeight(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SceneCaptureComponent2D",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SceneCaptureComponent2D must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USceneCaptureComponent2D::StaticClass(), TEXT("PostProcessBlendWeight"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_PostProcessBlendWeight(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SceneCaptureComponent2D",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SceneCaptureComponent2D must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USceneCaptureComponent2D::StaticClass(), TEXT("PostProcessBlendWeight"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bUseCustomProjectionMatrix(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SceneCaptureComponent2D",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SceneCaptureComponent2D must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USceneCaptureComponent2D::StaticClass(), TEXT("bUseCustomProjectionMatrix"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = bool();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bUseCustomProjectionMatrix(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SceneCaptureComponent2D",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SceneCaptureComponent2D must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USceneCaptureComponent2D::StaticClass(), TEXT("bUseCustomProjectionMatrix"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bEnableClipPlane(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SceneCaptureComponent2D",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SceneCaptureComponent2D must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USceneCaptureComponent2D::StaticClass(), TEXT("bEnableClipPlane"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = bool();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bEnableClipPlane(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SceneCaptureComponent2D",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SceneCaptureComponent2D must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USceneCaptureComponent2D::StaticClass(), TEXT("bEnableClipPlane"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_ClipPlaneBase(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SceneCaptureComponent2D",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SceneCaptureComponent2D must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USceneCaptureComponent2D::StaticClass(), TEXT("ClipPlaneBase"));
	if(!Property) { check(false); return 0;}
	FVector PropertyValue = FVector();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaVector::Return(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_ClipPlaneBase(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SceneCaptureComponent2D",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SceneCaptureComponent2D must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USceneCaptureComponent2D::StaticClass(), TEXT("ClipPlaneBase"));
	if(!Property) { check(false); return 0;}
	FVector PropertyValue = (wLua::FLuaVector::Get(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_ClipPlaneNormal(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SceneCaptureComponent2D",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SceneCaptureComponent2D must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USceneCaptureComponent2D::StaticClass(), TEXT("ClipPlaneNormal"));
	if(!Property) { check(false); return 0;}
	FVector PropertyValue = FVector();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaVector::Return(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_ClipPlaneNormal(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SceneCaptureComponent2D",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SceneCaptureComponent2D must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USceneCaptureComponent2D::StaticClass(), TEXT("ClipPlaneNormal"));
	if(!Property) { check(false); return 0;}
	FVector PropertyValue = (wLua::FLuaVector::Get(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bCameraCutThisFrame(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SceneCaptureComponent2D",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SceneCaptureComponent2D must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USceneCaptureComponent2D::StaticClass(), TEXT("bCameraCutThisFrame"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bCameraCutThisFrame(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SceneCaptureComponent2D",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SceneCaptureComponent2D must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USceneCaptureComponent2D::StaticClass(), TEXT("bCameraCutThisFrame"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 New(lua_State* InScriptContext)
{
	UObject* Outer = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Object");
	FName Name = FName(luaL_checkstring(InScriptContext, 2));
	UObject* Obj = NewObject<USceneCaptureComponent2D>(Outer, Name);
	wLua::FLuaUtils::ReturnUObject(InScriptContext,Obj);
	return 1;
}

int32 Destroy(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SceneCaptureComponent2D",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SceneCaptureComponent2D must be non-null"); lua_error(InScriptContext);  return 0;}
		UActorComponent * com = Cast<UActorComponent>(Obj);
		if(lua_isnoneornil(InScriptContext,2))
			com->DestroyComponent();
		else
			com->DestroyComponent(!!lua_toboolean(InScriptContext,2));
		userdata->flag |= wLua::LuaObjectFlag::DESTROYED;
		wLua::FLuaUtils::RemoveObjectReference(Obj, userdata->stamp, InScriptContext);
#ifdef AZURE_BUILD_WLUACHECK
		UE_LOG(LogAzure, Warning, TEXT("Destroy SceneCaptureComponent2D: %x userdata:%x   stamp:%x"),Obj,userdata,userdata->stamp);
#endif
	return 0;
}

int32 Class(lua_State* InScriptContext)
{
	UClass* Class = USceneCaptureComponent2D::StaticClass();
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Class);
	return 1;
}

const luaL_Reg Lib_Funcs[] =
{
	{ "New", New },
	{ "Destroy", Destroy },
	{ "Class", Class },
	{ "CaptureScene", CaptureScene },
	{ "Get_ProjectionType", Get_ProjectionType },
	{ "Set_ProjectionType", Set_ProjectionType },
	{ "Get_FOVAngle", Get_FOVAngle },
	{ "Set_FOVAngle", Set_FOVAngle },
	{ "Get_OrthoWidth", Get_OrthoWidth },
	{ "Set_OrthoWidth", Set_OrthoWidth },
	{ "Get_TextureTarget", Get_TextureTarget },
	{ "Set_TextureTarget", Set_TextureTarget },
	{ "Get_CaptureSource", Get_CaptureSource },
	{ "Set_CaptureSource", Set_CaptureSource },
	{ "Get_CompositeMode", Get_CompositeMode },
	{ "Set_CompositeMode", Set_CompositeMode },
	{ "Get_PostProcessBlendWeight", Get_PostProcessBlendWeight },
	{ "Set_PostProcessBlendWeight", Set_PostProcessBlendWeight },
	{ "Get_bUseCustomProjectionMatrix", Get_bUseCustomProjectionMatrix },
	{ "Set_bUseCustomProjectionMatrix", Set_bUseCustomProjectionMatrix },
	{ "Get_bEnableClipPlane", Get_bEnableClipPlane },
	{ "Set_bEnableClipPlane", Set_bEnableClipPlane },
	{ "Get_ClipPlaneBase", Get_ClipPlaneBase },
	{ "Set_ClipPlaneBase", Set_ClipPlaneBase },
	{ "Get_ClipPlaneNormal", Get_ClipPlaneNormal },
	{ "Set_ClipPlaneNormal", Set_ClipPlaneNormal },
	{ "Get_bCameraCutThisFrame", Get_bCameraCutThisFrame },
	{ "Set_bCameraCutThisFrame", Set_bCameraCutThisFrame },
	{ "DisableAllPostProcess", DisableAllPostProcess },
	{ "is_nil", wLua::LuaStatic::isnil },
	{ "__gc", wLua::LuaStatic::removeUClassFrameCache },
	{ NULL, NULL }
};

void Register(lua_State *InScriptContext)
{
	lua_newtable(InScriptContext);
	luaL_register(InScriptContext, NULL, Lib_Funcs);
	AzureHelpFuncs::AuxRegister(InScriptContext, "SceneCaptureComponent2D");
}
void SetMtLink(lua_State *InScriptContext)
{
	AzureHelpFuncs::AuxSetMtLink(InScriptContext, "SceneCaptureComponent2D", "SceneCaptureComponent",USERDATATYPE_UOBJECT);
}

}