#include "Azure.h"
#include "Utility/help_funcs.h"
#include "wLua/UObjectHeaders.h"
#include "Utilities/LevelSequencePlayerEx.h"
#include "AzureLuaIntegration.h"

namespace LuaLevelSequencePlayerEx
{
int32 TranslateFrameToSeconds(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"LevelSequencePlayerEx",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"LevelSequencePlayerEx must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		int32 frameNumber;
		float ReturnValue;
	} Params;
	Params.frameNumber = (luaL_checkint(InScriptContext, 2));
#if UE_GAME
	ULevelSequencePlayerEx * This = (ULevelSequencePlayerEx *)Obj;
	Params.ReturnValue = This->TranslateFrameToSeconds(Params.frameNumber);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("TranslateFrameToSeconds"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(int32*)(params.GetStructMemory() + 0) = Params.frameNumber;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.frameNumber = *(int32*)(params.GetStructMemory() + 0);
		Params.ReturnValue = *(float*)(params.GetStructMemory() + 4);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushnumber(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 SetTransformOffsetFollowObj(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"LevelSequencePlayerEx",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"LevelSequencePlayerEx must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		AActor* pActor = nullptr;
	} Params;
	Params.pActor = (AActor*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"Actor");;
#if UE_GAME
	ULevelSequencePlayerEx * This = (ULevelSequencePlayerEx *)Obj;
	This->SetTransformOffsetFollowObj(Params.pActor);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetTransformOffsetFollowObj"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(AActor**)(params.GetStructMemory() + 0) = Params.pActor;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.pActor = *(AActor**)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 GetCurrentTimeAsSeconds(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"LevelSequencePlayerEx",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"LevelSequencePlayerEx must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float ReturnValue;
	} Params;
#if UE_GAME
	ULevelSequencePlayerEx * This = (ULevelSequencePlayerEx *)Obj;
	Params.ReturnValue = This->GetCurrentTimeAsSeconds();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetCurrentTimeAsSeconds"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(float*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushnumber(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetCurrentFrameTime(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"LevelSequencePlayerEx",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"LevelSequencePlayerEx must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		int32 ReturnValue;
	} Params;
#if UE_GAME
	ULevelSequencePlayerEx * This = (ULevelSequencePlayerEx *)Obj;
	Params.ReturnValue = This->GetCurrentFrameTime();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetCurrentFrameTime"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(int32*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushinteger(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 New(lua_State* InScriptContext)
{
	UObject* Outer = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Object");
	FName Name = FName(luaL_checkstring(InScriptContext, 2));
	UObject* Obj = NewObject<ULevelSequencePlayerEx>(Outer, Name);
	wLua::FLuaUtils::ReturnUObject(InScriptContext,Obj);
	return 1;
}

int32 Destroy(lua_State* InScriptContext)
{
	return 0;
}

int32 Class(lua_State* InScriptContext)
{
	UClass* Class = ULevelSequencePlayerEx::StaticClass();
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Class);
	return 1;
}

const luaL_Reg Lib_Funcs[] =
{
	{ "New", New },
	{ "Destroy", Destroy },
	{ "Class", Class },
	{ "TranslateFrameToSeconds", TranslateFrameToSeconds },
	{ "SetTransformOffsetFollowObj", SetTransformOffsetFollowObj },
	{ "GetCurrentTimeAsSeconds", GetCurrentTimeAsSeconds },
	{ "GetCurrentFrameTime", GetCurrentFrameTime },
	{ "is_nil", wLua::LuaStatic::isnil },
	{ "__gc", wLua::LuaStatic::removeUClassFrameCache },
	{ NULL, NULL }
};

void Register(lua_State *InScriptContext)
{
	lua_newtable(InScriptContext);
	luaL_register(InScriptContext, NULL, Lib_Funcs);
	AzureHelpFuncs::AuxRegister(InScriptContext, "LevelSequencePlayerEx");
}
void SetMtLink(lua_State *InScriptContext)
{
	AzureHelpFuncs::AuxSetMtLink(InScriptContext, "LevelSequencePlayerEx", "LevelSequencePlayer",USERDATATYPE_UOBJECT);
}

}