#include "Azure.h"
#include "Utility/help_funcs.h"
#include "wLua/UObjectHeaders.h"
#include "Components/ActorComponent.h"
#include "AzureLuaIntegration.h"

namespace LuaActorComponent
{
int32 RegisterComponent(lua_State*);
int32 IsRegistered(lua_State*);

int32 ToggleActive(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ActorComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ActorComponent must be non-null"); lua_error(InScriptContext);  return 0;}
#if UE_GAME
	UActorComponent * This = (UActorComponent *)Obj;
	This->ToggleActive();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("ToggleActive"));
	if(!Function) { check(false); return 0;}
	Obj->ProcessEvent(Function, NULL);
#endif
	return 0;
}

int32 SetTickGroup(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ActorComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ActorComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		TEnumAsByte<ETickingGroup> NewTickGroup;
	} Params;
	Params.NewTickGroup = (TEnumAsByte<ETickingGroup>)(luaL_checkint(InScriptContext, 2));
#if UE_GAME
	UActorComponent * This = (UActorComponent *)Obj;
	This->SetTickGroup(Params.NewTickGroup);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetTickGroup"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(TEnumAsByte<ETickingGroup>*)(params.GetStructMemory() + 0) = Params.NewTickGroup;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.NewTickGroup = *(TEnumAsByte<ETickingGroup>*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetTickableWhenPaused(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ActorComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ActorComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool bTickableWhenPaused;
	} Params;
	Params.bTickableWhenPaused = !!(lua_toboolean(InScriptContext, 2));
#if UE_GAME
	UActorComponent * This = (UActorComponent *)Obj;
	This->SetTickableWhenPaused(Params.bTickableWhenPaused);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetTickableWhenPaused"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(bool*)(params.GetStructMemory() + 0) = Params.bTickableWhenPaused;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.bTickableWhenPaused = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetIsReplicated(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ActorComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ActorComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool ShouldReplicate;
	} Params;
	Params.ShouldReplicate = !!(lua_toboolean(InScriptContext, 2));
#if UE_GAME
	UActorComponent * This = (UActorComponent *)Obj;
	This->SetIsReplicated(Params.ShouldReplicate);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetIsReplicated"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(bool*)(params.GetStructMemory() + 0) = Params.ShouldReplicate;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ShouldReplicate = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetComponentTickInterval(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ActorComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ActorComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float TickInterval;
	} Params;
	Params.TickInterval = (float)(luaL_checknumber(InScriptContext, 2));
#if UE_GAME
	UActorComponent * This = (UActorComponent *)Obj;
	This->SetComponentTickInterval(Params.TickInterval);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetComponentTickInterval"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(float*)(params.GetStructMemory() + 0) = Params.TickInterval;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.TickInterval = *(float*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetComponentTickEnabled(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ActorComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ActorComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool bEnabled;
	} Params;
	Params.bEnabled = !!(lua_toboolean(InScriptContext, 2));
#if UE_GAME
	UActorComponent * This = (UActorComponent *)Obj;
	This->SetComponentTickEnabled(Params.bEnabled);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetComponentTickEnabled"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(bool*)(params.GetStructMemory() + 0) = Params.bEnabled;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.bEnabled = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetAutoActivate(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ActorComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ActorComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool bNewAutoActivate;
	} Params;
	Params.bNewAutoActivate = !!(lua_toboolean(InScriptContext, 2));
#if UE_GAME
	UActorComponent * This = (UActorComponent *)Obj;
	This->SetAutoActivate(Params.bNewAutoActivate);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetAutoActivate"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(bool*)(params.GetStructMemory() + 0) = Params.bNewAutoActivate;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.bNewAutoActivate = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetActive(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ActorComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ActorComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool bNewActive;
		bool bReset;
	} Params;
	Params.bNewActive = !!(lua_toboolean(InScriptContext, 2));
	Params.bReset = lua_isnoneornil(InScriptContext,3) ? bool(false) : !!(lua_toboolean(InScriptContext, 3));
#if UE_GAME
	UActorComponent * This = (UActorComponent *)Obj;
	This->SetActive(Params.bNewActive,Params.bReset);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetActive"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(bool*)(params.GetStructMemory() + 0) = Params.bNewActive;
		*(bool*)(params.GetStructMemory() + 1) = Params.bReset;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.bNewActive = *(bool*)(params.GetStructMemory() + 0);
		Params.bReset = *(bool*)(params.GetStructMemory() + 1);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 RemoveTickPrerequisiteComponent(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ActorComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ActorComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		UActorComponent* PrerequisiteComponent = nullptr;
	} Params;
	Params.PrerequisiteComponent = (UActorComponent*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"ActorComponent");;
#if UE_GAME
	UActorComponent * This = (UActorComponent *)Obj;
	This->RemoveTickPrerequisiteComponent(Params.PrerequisiteComponent);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("RemoveTickPrerequisiteComponent"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(UActorComponent**)(params.GetStructMemory() + 0) = Params.PrerequisiteComponent;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.PrerequisiteComponent = *(UActorComponent**)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 RemoveTickPrerequisiteActor(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ActorComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ActorComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		AActor* PrerequisiteActor = nullptr;
	} Params;
	Params.PrerequisiteActor = (AActor*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"Actor");;
#if UE_GAME
	UActorComponent * This = (UActorComponent *)Obj;
	This->RemoveTickPrerequisiteActor(Params.PrerequisiteActor);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("RemoveTickPrerequisiteActor"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(AActor**)(params.GetStructMemory() + 0) = Params.PrerequisiteActor;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.PrerequisiteActor = *(AActor**)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 ReceiveTick(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ActorComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ActorComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float DeltaSeconds;
	} Params;
	Params.DeltaSeconds = (float)(luaL_checknumber(InScriptContext, 2));
#if UE_GAME
	UActorComponent * This = (UActorComponent *)Obj;
	This->ReceiveTick(Params.DeltaSeconds);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("ReceiveTick"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(float*)(params.GetStructMemory() + 0) = Params.DeltaSeconds;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.DeltaSeconds = *(float*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 ReceiveEndPlay(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ActorComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ActorComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		TEnumAsByte<EEndPlayReason::Type> EndPlayReason;
	} Params;
	Params.EndPlayReason = (TEnumAsByte<EEndPlayReason::Type>)(luaL_checkint(InScriptContext, 2));
#if UE_GAME
	UActorComponent * This = (UActorComponent *)Obj;
	This->ReceiveEndPlay(Params.EndPlayReason);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("ReceiveEndPlay"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(TEnumAsByte<EEndPlayReason::Type>*)(params.GetStructMemory() + 0) = Params.EndPlayReason;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.EndPlayReason = *(TEnumAsByte<EEndPlayReason::Type>*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 ReceiveBeginPlay(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ActorComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ActorComponent must be non-null"); lua_error(InScriptContext);  return 0;}
#if UE_GAME
	UActorComponent * This = (UActorComponent *)Obj;
	This->ReceiveBeginPlay();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("ReceiveBeginPlay"));
	if(!Function) { check(false); return 0;}
	Obj->ProcessEvent(Function, NULL);
#endif
	return 0;
}

int32 OnRep_IsActive(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ActorComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ActorComponent must be non-null"); lua_error(InScriptContext);  return 0;}
#if UE_GAME
	UActorComponent * This = (UActorComponent *)Obj;
	This->OnRep_IsActive();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("OnRep_IsActive"));
	if(!Function) { check(false); return 0;}
	Obj->ProcessEvent(Function, NULL);
#endif
	return 0;
}

int32 K2_DestroyComponent(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ActorComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ActorComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		UObject* Object = nullptr;
	} Params;
	Params.Object = (UObject*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"Object");;
#if UE_GAME
	UActorComponent * This = (UActorComponent *)Obj;
	This->K2_DestroyComponent(Params.Object);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("K2_DestroyComponent"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(UObject**)(params.GetStructMemory() + 0) = Params.Object;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.Object = *(UObject**)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 IsComponentTickEnabled(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ActorComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ActorComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool ReturnValue;
	} Params;
#if UE_GAME
	UActorComponent * This = (UActorComponent *)Obj;
	Params.ReturnValue = This->IsComponentTickEnabled();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("IsComponentTickEnabled"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushboolean(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 IsBeingDestroyed(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ActorComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ActorComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool ReturnValue;
	} Params;
#if UE_GAME
	UActorComponent * This = (UActorComponent *)Obj;
	Params.ReturnValue = This->IsBeingDestroyed();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("IsBeingDestroyed"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushboolean(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 IsActive(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ActorComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ActorComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool ReturnValue;
	} Params;
#if UE_GAME
	UActorComponent * This = (UActorComponent *)Obj;
	Params.ReturnValue = This->IsActive();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("IsActive"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushboolean(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetOwner(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ActorComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ActorComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		AActor* ReturnValue = nullptr;
	} Params;
#if UE_GAME
	UActorComponent * This = (UActorComponent *)Obj;
	Params.ReturnValue = This->GetOwner();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetOwner"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(AActor**)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetComponentTickInterval(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ActorComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ActorComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float ReturnValue;
	} Params;
#if UE_GAME
	UActorComponent * This = (UActorComponent *)Obj;
	Params.ReturnValue = This->GetComponentTickInterval();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetComponentTickInterval"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(float*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushnumber(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 Deactivate(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ActorComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ActorComponent must be non-null"); lua_error(InScriptContext);  return 0;}
#if UE_GAME
	UActorComponent * This = (UActorComponent *)Obj;
	This->Deactivate();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("Deactivate"));
	if(!Function) { check(false); return 0;}
	Obj->ProcessEvent(Function, NULL);
#endif
	return 0;
}

int32 ComponentHasTag(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ActorComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ActorComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FName Tag;
		bool ReturnValue;
	} Params;
	Params.Tag = FName(UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 2)));
#if UE_GAME
	UActorComponent * This = (UActorComponent *)Obj;
	Params.ReturnValue = This->ComponentHasTag(Params.Tag);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("ComponentHasTag"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FName*)(params.GetStructMemory() + 0) = Params.Tag;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.Tag = *(FName*)(params.GetStructMemory() + 0);
		Params.ReturnValue = *(bool*)(params.GetStructMemory() + 12);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushboolean(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 AddTickPrerequisiteComponent(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ActorComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ActorComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		UActorComponent* PrerequisiteComponent = nullptr;
	} Params;
	Params.PrerequisiteComponent = (UActorComponent*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"ActorComponent");;
#if UE_GAME
	UActorComponent * This = (UActorComponent *)Obj;
	This->AddTickPrerequisiteComponent(Params.PrerequisiteComponent);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("AddTickPrerequisiteComponent"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(UActorComponent**)(params.GetStructMemory() + 0) = Params.PrerequisiteComponent;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.PrerequisiteComponent = *(UActorComponent**)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 AddTickPrerequisiteActor(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ActorComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ActorComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		AActor* PrerequisiteActor = nullptr;
	} Params;
	Params.PrerequisiteActor = (AActor*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"Actor");;
#if UE_GAME
	UActorComponent * This = (UActorComponent *)Obj;
	This->AddTickPrerequisiteActor(Params.PrerequisiteActor);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("AddTickPrerequisiteActor"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(AActor**)(params.GetStructMemory() + 0) = Params.PrerequisiteActor;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.PrerequisiteActor = *(AActor**)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 Activate(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ActorComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ActorComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool bReset;
	} Params;
	Params.bReset = lua_isnoneornil(InScriptContext,2) ? bool(false) : !!(lua_toboolean(InScriptContext, 2));
#if UE_GAME
	UActorComponent * This = (UActorComponent *)Obj;
	This->Activate(Params.bReset);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("Activate"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(bool*)(params.GetStructMemory() + 0) = Params.bReset;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.bReset = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 Get_ComponentTags(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ActorComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ActorComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UActorComponent::StaticClass(), TEXT("ComponentTags"));
	if(!Property) { check(false); return 0;}
	TArray<FName> PropertyValue;
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	{lua_newtable(InScriptContext); int i = 1; for(auto It = PropertyValue.CreateConstIterator(); It; ++It,++i) {  lua_pushstring(InScriptContext, TCHAR_TO_UTF8(*(*It).ToString())); lua_rawseti(InScriptContext,-2,i);     }  }
	return 1;
}

int32 Set_ComponentTags(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ActorComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ActorComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UActorComponent::StaticClass(), TEXT("ComponentTags"));
	if(!Property) { check(false); return 0;}
	TArray<FName> PropertyValue = [](lua_State * _InScriptContext){ TArray<FName> ret; lua_pushnil(_InScriptContext); while(lua_next(_InScriptContext,2)!=0){ FName item = FName(UTF8_TO_TCHAR(luaL_checkstring(_InScriptContext, -1))); ret.Add(item); lua_pop(_InScriptContext,1);  } return ret; }(InScriptContext);;
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_AssetUserData(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ActorComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ActorComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UActorComponent::StaticClass(), TEXT("AssetUserData"));
	if(!Property) { check(false); return 0;}
	TArray<UAssetUserData*> PropertyValue;
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	{lua_newtable(InScriptContext); int i = 1; for(auto It = PropertyValue.CreateConstIterator(); It; ++It,++i) {  wLua::FLuaUtils::ReturnUObject(InScriptContext, (*It)); lua_rawseti(InScriptContext,-2,i);     }  }
	return 1;
}

int32 Set_AssetUserData(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ActorComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ActorComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UActorComponent::StaticClass(), TEXT("AssetUserData"));
	if(!Property) { check(false); return 0;}
	TArray<UAssetUserData*> PropertyValue = [](lua_State * _InScriptContext){ TArray<UAssetUserData*> ret; lua_pushnil(_InScriptContext); while(lua_next(_InScriptContext,2)!=0){ UAssetUserData* item = (UAssetUserData*)wLua::FLuaUtils::GetUObject(_InScriptContext,-1,"AssetUserData");; ret.Add(item); lua_pop(_InScriptContext,1);  } return ret; }(InScriptContext);;
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bReplicates(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ActorComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ActorComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UActorComponent::StaticClass(), TEXT("bReplicates"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_bAutoActivate(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ActorComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ActorComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UActorComponent::StaticClass(), TEXT("bAutoActivate"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_bEditableWhenInherited(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ActorComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ActorComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UActorComponent::StaticClass(), TEXT("bEditableWhenInherited"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bEditableWhenInherited(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ActorComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ActorComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UActorComponent::StaticClass(), TEXT("bEditableWhenInherited"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bCanEverAffectNavigation(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ActorComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ActorComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UActorComponent::StaticClass(), TEXT("bCanEverAffectNavigation"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bCanEverAffectNavigation(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ActorComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ActorComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UActorComponent::StaticClass(), TEXT("bCanEverAffectNavigation"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bIsEditorOnly(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ActorComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ActorComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UActorComponent::StaticClass(), TEXT("bIsEditorOnly"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Call_OnComponentActivated(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ActorComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ActorComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		UActorComponent* Component = nullptr;
		bool bReset;
	} Params;
	Params.Component = (UActorComponent*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"ActorComponent");;
	Params.bReset = !!(lua_toboolean(InScriptContext, 3));
	UActorComponent * This = (UActorComponent *)Obj;
	This->OnComponentActivated.Broadcast(Params.Component,Params.bReset);
	return 0;
}

int32 Call_OnComponentDeactivated(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ActorComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ActorComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		UActorComponent* Component = nullptr;
	} Params;
	Params.Component = (UActorComponent*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"ActorComponent");;
	UActorComponent * This = (UActorComponent *)Obj;
	This->OnComponentDeactivated.Broadcast(Params.Component);
	return 0;
}

int32 Class(lua_State* InScriptContext)
{
	UClass* Class = UActorComponent::StaticClass();
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Class);
	return 1;
}

const luaL_Reg Lib_Funcs[] =
{
	{ "Class", Class },
	{ "ToggleActive", ToggleActive },
	{ "SetTickGroup", SetTickGroup },
	{ "SetTickableWhenPaused", SetTickableWhenPaused },
	{ "SetIsReplicated", SetIsReplicated },
	{ "SetComponentTickInterval", SetComponentTickInterval },
	{ "SetComponentTickEnabled", SetComponentTickEnabled },
	{ "SetAutoActivate", SetAutoActivate },
	{ "SetActive", SetActive },
	{ "RemoveTickPrerequisiteComponent", RemoveTickPrerequisiteComponent },
	{ "RemoveTickPrerequisiteActor", RemoveTickPrerequisiteActor },
	{ "ReceiveTick", ReceiveTick },
	{ "ReceiveEndPlay", ReceiveEndPlay },
	{ "ReceiveBeginPlay", ReceiveBeginPlay },
	{ "OnRep_IsActive", OnRep_IsActive },
	{ "DestroyComponent", K2_DestroyComponent },
	{ "IsComponentTickEnabled", IsComponentTickEnabled },
	{ "IsBeingDestroyed", IsBeingDestroyed },
	{ "IsActive", IsActive },
	{ "GetOwner", GetOwner },
	{ "GetComponentTickInterval", GetComponentTickInterval },
	{ "Deactivate", Deactivate },
	{ "ComponentHasTag", ComponentHasTag },
	{ "AddTickPrerequisiteComponent", AddTickPrerequisiteComponent },
	{ "AddTickPrerequisiteActor", AddTickPrerequisiteActor },
	{ "Activate", Activate },
	{ "Get_ComponentTags", Get_ComponentTags },
	{ "Set_ComponentTags", Set_ComponentTags },
	{ "Get_AssetUserData", Get_AssetUserData },
	{ "Set_AssetUserData", Set_AssetUserData },
	{ "Get_bReplicates", Get_bReplicates },
	{ "Get_bAutoActivate", Get_bAutoActivate },
	{ "Get_bEditableWhenInherited", Get_bEditableWhenInherited },
	{ "Set_bEditableWhenInherited", Set_bEditableWhenInherited },
	{ "Get_bCanEverAffectNavigation", Get_bCanEverAffectNavigation },
	{ "Set_bCanEverAffectNavigation", Set_bCanEverAffectNavigation },
	{ "Get_bIsEditorOnly", Get_bIsEditorOnly },
	{ "Call_OnComponentActivated", Call_OnComponentActivated },
	{ "Call_OnComponentDeactivated", Call_OnComponentDeactivated },
	{ "RegisterComponent", RegisterComponent },
	{ "IsRegistered", IsRegistered },
	{ "is_nil", wLua::LuaStatic::isnil },
	{ "__gc", wLua::LuaStatic::removeUClassFrameCache },
	{ NULL, NULL }
};

void Register(lua_State *InScriptContext)
{
	lua_newtable(InScriptContext);
	luaL_register(InScriptContext, NULL, Lib_Funcs);
	AzureHelpFuncs::AuxRegister(InScriptContext, "ActorComponent");
}
void SetMtLink(lua_State *InScriptContext)
{
	AzureHelpFuncs::AuxSetMtLink(InScriptContext, "ActorComponent", "Object",USERDATATYPE_UOBJECT);
}

}