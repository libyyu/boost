#include "Azure.h"
#include "Utility/help_funcs.h"
#include "wLua/UObjectHeaders.h"
#include "OVRLipSyncPlaybackActorComponent.h"
#include "AzureLuaIntegration.h"

namespace LuaOVRLipSyncPlaybackActorComponent
{
int32 Stop(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"OVRLipSyncPlaybackActorComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"OVRLipSyncPlaybackActorComponent must be non-null"); lua_error(InScriptContext);  return 0;}
#if UE_GAME
	UOVRLipSyncPlaybackActorComponent * This = (UOVRLipSyncPlaybackActorComponent *)Obj;
	This->Stop();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("Stop"));
	if(!Function) { check(false); return 0;}
	Obj->ProcessEvent(Function, NULL);
#endif
	return 0;
}

int32 SetPosition(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"OVRLipSyncPlaybackActorComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"OVRLipSyncPlaybackActorComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float Position;
	} Params;
	Params.Position = (float)(luaL_checknumber(InScriptContext, 2));
#if UE_GAME
	UOVRLipSyncPlaybackActorComponent * This = (UOVRLipSyncPlaybackActorComponent *)Obj;
	This->SetPosition(Params.Position);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetPosition"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(float*)(params.GetStructMemory() + 0) = Params.Position;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.Position = *(float*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetEmotionCurve(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"OVRLipSyncPlaybackActorComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"OVRLipSyncPlaybackActorComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FName Name;
		UCurveFloat* Curve = nullptr;
	} Params;
	Params.Name = FName(UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 2)));
	Params.Curve = (UCurveFloat*)wLua::FLuaUtils::GetUObject(InScriptContext,3,"CurveFloat");;
#if UE_GAME
	UOVRLipSyncPlaybackActorComponent * This = (UOVRLipSyncPlaybackActorComponent *)Obj;
	This->SetEmotionCurve(Params.Name,Params.Curve);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetEmotionCurve"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FName*)(params.GetStructMemory() + 0) = Params.Name;
		*(UCurveFloat**)(params.GetStructMemory() + 16) = Params.Curve;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.Name = *(FName*)(params.GetStructMemory() + 0);
		Params.Curve = *(UCurveFloat**)(params.GetStructMemory() + 16);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 PlayWithPlayingId(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"OVRLipSyncPlaybackActorComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"OVRLipSyncPlaybackActorComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		UOVRLipSyncFrameSequence* inSequence = nullptr;
		int32 _playingID;
	} Params;
	Params.inSequence = (UOVRLipSyncFrameSequence*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"OVRLipSyncFrameSequence");;
	Params._playingID = (luaL_checkint(InScriptContext, 3));
#if UE_GAME
	UOVRLipSyncPlaybackActorComponent * This = (UOVRLipSyncPlaybackActorComponent *)Obj;
	This->PlayWithPlayingId(Params.inSequence,Params._playingID);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("PlayWithPlayingId"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(UOVRLipSyncFrameSequence**)(params.GetStructMemory() + 0) = Params.inSequence;
		*(int32*)(params.GetStructMemory() + 8) = Params._playingID;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.inSequence = *(UOVRLipSyncFrameSequence**)(params.GetStructMemory() + 0);
		Params._playingID = *(int32*)(params.GetStructMemory() + 8);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 PlaySequence(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"OVRLipSyncPlaybackActorComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"OVRLipSyncPlaybackActorComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		UOVRLipSyncFrameSequence* inSequence = nullptr;
	} Params;
	Params.inSequence = (UOVRLipSyncFrameSequence*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"OVRLipSyncFrameSequence");;
#if UE_GAME
	UOVRLipSyncPlaybackActorComponent * This = (UOVRLipSyncPlaybackActorComponent *)Obj;
	This->PlaySequence(Params.inSequence);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("PlaySequence"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(UOVRLipSyncFrameSequence**)(params.GetStructMemory() + 0) = Params.inSequence;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.inSequence = *(UOVRLipSyncFrameSequence**)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 PlayByName(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"OVRLipSyncPlaybackActorComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"OVRLipSyncPlaybackActorComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		UOVRLipSyncFrameSequence* inSequence = nullptr;
		FString EventName;
	} Params;
	Params.inSequence = (UOVRLipSyncFrameSequence*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"OVRLipSyncFrameSequence");;
	Params.EventName = UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 3));
#if UE_GAME
	UOVRLipSyncPlaybackActorComponent * This = (UOVRLipSyncPlaybackActorComponent *)Obj;
	This->PlayByName(Params.inSequence,Params.EventName);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("PlayByName"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(UOVRLipSyncFrameSequence**)(params.GetStructMemory() + 0) = Params.inSequence;
		*(FString*)(params.GetStructMemory() + 8) = Params.EventName;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.inSequence = *(UOVRLipSyncFrameSequence**)(params.GetStructMemory() + 0);
		Params.EventName = *(FString*)(params.GetStructMemory() + 8);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 Play(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"OVRLipSyncPlaybackActorComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"OVRLipSyncPlaybackActorComponent must be non-null"); lua_error(InScriptContext);  return 0;}
#if UE_GAME
	UOVRLipSyncPlaybackActorComponent * This = (UOVRLipSyncPlaybackActorComponent *)Obj;
	This->Play();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("Play"));
	if(!Function) { check(false); return 0;}
	Obj->ProcessEvent(Function, NULL);
#endif
	return 0;
}

int32 OnVisemesReadyToSync(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"OVRLipSyncPlaybackActorComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"OVRLipSyncPlaybackActorComponent must be non-null"); lua_error(InScriptContext);  return 0;}
#if UE_GAME
	UOVRLipSyncPlaybackActorComponent * This = (UOVRLipSyncPlaybackActorComponent *)Obj;
	This->OnVisemesReadyToSync();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("OnVisemesReadyToSync"));
	if(!Function) { check(false); return 0;}
	Obj->ProcessEvent(Function, NULL);
#endif
	return 0;
}

int32 Init(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"OVRLipSyncPlaybackActorComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"OVRLipSyncPlaybackActorComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		UAkComponent* inAkComponent = nullptr;
		USkeletalMeshComponent* inSkeletalMesh = nullptr;
	} Params;
	Params.inAkComponent = UAkGameplayStatics::UObject2UAkComponent(wLua::FLuaUtils::GetUObject(InScriptContext,2,"AkComponent"));;
	Params.inSkeletalMesh = lua_isnoneornil(InScriptContext,3) ? nullptr : (USkeletalMeshComponent*)wLua::FLuaUtils::GetUObject(InScriptContext,3,"SkeletalMeshComponent");;
#if UE_GAME
	UOVRLipSyncPlaybackActorComponent * This = (UOVRLipSyncPlaybackActorComponent *)Obj;
	This->Init(Params.inAkComponent,Params.inSkeletalMesh);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("Init"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(UAkComponent**)(params.GetStructMemory() + 0) = Params.inAkComponent;
		*(USkeletalMeshComponent**)(params.GetStructMemory() + 8) = Params.inSkeletalMesh;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.inAkComponent = *(UAkComponent**)(params.GetStructMemory() + 0);
		Params.inSkeletalMesh = *(USkeletalMeshComponent**)(params.GetStructMemory() + 8);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 GetVisemesValueMap(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"OVRLipSyncPlaybackActorComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"OVRLipSyncPlaybackActorComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		TMap<FName,float> ReturnValue;
	} Params;
#if UE_GAME
	UOVRLipSyncPlaybackActorComponent * This = (UOVRLipSyncPlaybackActorComponent *)Obj;
	Params.ReturnValue = This->GetVisemesValueMap();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetVisemesValueMap"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(TMap<FName,float>*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	{lua_newtable(InScriptContext); for(auto It = Params.ReturnValue.CreateConstIterator(); It; ++It) {  lua_pushstring(InScriptContext, TCHAR_TO_UTF8(*((*It).Key).ToString()));  lua_pushnumber(InScriptContext, ((*It).Value));  lua_settable(InScriptContext,-3);     }  }
	return 1;
}

int32 GetSequence(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"OVRLipSyncPlaybackActorComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"OVRLipSyncPlaybackActorComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		UOVRLipSyncFrameSequence* ReturnValue = nullptr;
	} Params;
#if UE_GAME
	UOVRLipSyncPlaybackActorComponent * This = (UOVRLipSyncPlaybackActorComponent *)Obj;
	Params.ReturnValue = This->GetSequence();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetSequence"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(UOVRLipSyncFrameSequence**)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 Get_EmotionCurves(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"OVRLipSyncPlaybackActorComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"OVRLipSyncPlaybackActorComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UOVRLipSyncPlaybackActorComponent::StaticClass(), TEXT("EmotionCurves"));
	if(!Property) { check(false); return 0;}
	TMap<FName,UCurveFloat*> PropertyValue;
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	{lua_newtable(InScriptContext); for(auto It = PropertyValue.CreateConstIterator(); It; ++It) {  lua_pushstring(InScriptContext, TCHAR_TO_UTF8(*((*It).Key).ToString()));  wLua::FLuaUtils::ReturnUObject(InScriptContext, ((*It).Value));  lua_settable(InScriptContext,-3);     }  }
	return 1;
}

int32 Get_EmotionData(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"OVRLipSyncPlaybackActorComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"OVRLipSyncPlaybackActorComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UOVRLipSyncPlaybackActorComponent::StaticClass(), TEXT("EmotionData"));
	if(!Property) { check(false); return 0;}
	TMap<FName,float> PropertyValue;
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	{lua_newtable(InScriptContext); for(auto It = PropertyValue.CreateConstIterator(); It; ++It) {  lua_pushstring(InScriptContext, TCHAR_TO_UTF8(*((*It).Key).ToString()));  lua_pushnumber(InScriptContext, ((*It).Value));  lua_settable(InScriptContext,-3);     }  }
	return 1;
}

int32 Get_sequenceStopFadeTime(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"OVRLipSyncPlaybackActorComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"OVRLipSyncPlaybackActorComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UOVRLipSyncPlaybackActorComponent::StaticClass(), TEXT("sequenceStopFadeTime"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_sequenceStopFadeTime(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"OVRLipSyncPlaybackActorComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"OVRLipSyncPlaybackActorComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UOVRLipSyncPlaybackActorComponent::StaticClass(), TEXT("sequenceStopFadeTime"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 New(lua_State* InScriptContext)
{
	UObject* Outer = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Object");
	FName Name = FName(luaL_checkstring(InScriptContext, 2));
	UObject* Obj = NewObject<UOVRLipSyncPlaybackActorComponent>(Outer, Name);
	wLua::FLuaUtils::ReturnUObject(InScriptContext,Obj);
	return 1;
}

int32 Destroy(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"OVRLipSyncPlaybackActorComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"OVRLipSyncPlaybackActorComponent must be non-null"); lua_error(InScriptContext);  return 0;}
		UActorComponent * com = Cast<UActorComponent>(Obj);
		if(lua_isnoneornil(InScriptContext,2))
			com->DestroyComponent();
		else
			com->DestroyComponent(!!lua_toboolean(InScriptContext,2));
		userdata->flag |= wLua::LuaObjectFlag::DESTROYED;
		wLua::FLuaUtils::RemoveObjectReference(Obj, userdata->stamp, InScriptContext);
#ifdef AZURE_BUILD_WLUACHECK
		UE_LOG(LogAzure, Warning, TEXT("Destroy OVRLipSyncPlaybackActorComponent: %x userdata:%x   stamp:%x"),Obj,userdata,userdata->stamp);
#endif
	return 0;
}

int32 Class(lua_State* InScriptContext)
{
	UClass* Class = UOVRLipSyncPlaybackActorComponent::StaticClass();
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Class);
	return 1;
}

const luaL_Reg Lib_Funcs[] =
{
	{ "New", New },
	{ "Destroy", Destroy },
	{ "Class", Class },
	{ "Stop", Stop },
	{ "SetPosition", SetPosition },
	{ "SetEmotionCurve", SetEmotionCurve },
	{ "PlayWithPlayingId", PlayWithPlayingId },
	{ "PlaySequence", PlaySequence },
	{ "PlayByName", PlayByName },
	{ "Play", Play },
	{ "OnVisemesReadyToSync", OnVisemesReadyToSync },
	{ "Init", Init },
	{ "GetVisemesValueMap", GetVisemesValueMap },
	{ "GetSequence", GetSequence },
	{ "Get_EmotionCurves", Get_EmotionCurves },
	{ "Get_EmotionData", Get_EmotionData },
	{ "Get_sequenceStopFadeTime", Get_sequenceStopFadeTime },
	{ "Set_sequenceStopFadeTime", Set_sequenceStopFadeTime },
	{ "is_nil", wLua::LuaStatic::isnil },
	{ "__gc", wLua::LuaStatic::removeUClassFrameCache },
	{ NULL, NULL }
};

void Register(lua_State *InScriptContext)
{
	lua_newtable(InScriptContext);
	luaL_register(InScriptContext, NULL, Lib_Funcs);
	AzureHelpFuncs::AuxRegister(InScriptContext, "OVRLipSyncPlaybackActorComponent");
}
void SetMtLink(lua_State *InScriptContext)
{
	AzureHelpFuncs::AuxSetMtLink(InScriptContext, "OVRLipSyncPlaybackActorComponent", "ActorComponent",USERDATATYPE_UOBJECT);
}

}