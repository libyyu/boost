#include "Azure.h"
#include "Utility/help_funcs.h"
#include "wLua/UObjectHeaders.h"
#include "AzureInfiniteList.h"
#include "AzureLuaIntegration.h"

namespace LuaAzureInfiniteList
{
int32 SetOnUpdateFunc(lua_State*);

int32 SetSlotCount(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureInfiniteList",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureInfiniteList must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		int32 InCount;
	} Params;
	Params.InCount = (luaL_checkint(InScriptContext, 2));
#if UE_GAME
	UAzureInfiniteList * This = (UAzureInfiniteList *)Obj;
	This->SetSlotCount(Params.InCount);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetSlotCount"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(int32*)(params.GetStructMemory() + 0) = Params.InCount;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.InCount = *(int32*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 ScrollWidgetIntoView(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureInfiniteList",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureInfiniteList must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		UWidget* InWidgetToFind = nullptr;
		bool InAnimateScroll;
		EDescendantScrollDestination InScrollDestination;
	} Params;
	Params.InWidgetToFind = (UWidget*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"Widget");;
	Params.InAnimateScroll = lua_isnoneornil(InScriptContext,3) ? bool(true) : !!(lua_toboolean(InScriptContext, 3));
	Params.InScrollDestination = lua_isnoneornil(InScriptContext,4) ? EDescendantScrollDestination(EDescendantScrollDestination::IntoView) : (EDescendantScrollDestination)(luaL_checkint(InScriptContext, 4));
#if UE_GAME
	UAzureInfiniteList * This = (UAzureInfiniteList *)Obj;
	This->ScrollWidgetIntoView(Params.InWidgetToFind,Params.InAnimateScroll,Params.InScrollDestination);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("ScrollWidgetIntoView"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(UWidget**)(params.GetStructMemory() + 0) = Params.InWidgetToFind;
		*(bool*)(params.GetStructMemory() + 8) = Params.InAnimateScroll;
		*(EDescendantScrollDestination*)(params.GetStructMemory() + 9) = Params.InScrollDestination;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.InWidgetToFind = *(UWidget**)(params.GetStructMemory() + 0);
		Params.InAnimateScroll = *(bool*)(params.GetStructMemory() + 8);
		Params.InScrollDestination = *(EDescendantScrollDestination*)(params.GetStructMemory() + 9);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 ScrollToEnd(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureInfiniteList",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureInfiniteList must be non-null"); lua_error(InScriptContext);  return 0;}
#if UE_GAME
	UAzureInfiniteList * This = (UAzureInfiniteList *)Obj;
	This->ScrollToEnd();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("ScrollToEnd"));
	if(!Function) { check(false); return 0;}
	Obj->ProcessEvent(Function, NULL);
#endif
	return 0;
}

int32 ScrollToBegin(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureInfiniteList",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureInfiniteList must be non-null"); lua_error(InScriptContext);  return 0;}
#if UE_GAME
	UAzureInfiniteList * This = (UAzureInfiniteList *)Obj;
	This->ScrollToBegin();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("ScrollToBegin"));
	if(!Function) { check(false); return 0;}
	Obj->ProcessEvent(Function, NULL);
#endif
	return 0;
}

int32 IsScrollAtEnd(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureInfiniteList",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureInfiniteList must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool ReturnValue;
	} Params;
#if UE_GAME
	UAzureInfiniteList * This = (UAzureInfiniteList *)Obj;
	Params.ReturnValue = This->IsScrollAtEnd();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("IsScrollAtEnd"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushboolean(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 IsScrollAtBegin(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureInfiniteList",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureInfiniteList must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool ReturnValue;
	} Params;
#if UE_GAME
	UAzureInfiniteList * This = (UAzureInfiniteList *)Obj;
	Params.ReturnValue = This->IsScrollAtBegin();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("IsScrollAtBegin"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushboolean(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 IsEmpty(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureInfiniteList",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureInfiniteList must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool ReturnValue;
	} Params;
#if UE_GAME
	UAzureInfiniteList * This = (UAzureInfiniteList *)Obj;
	Params.ReturnValue = This->IsEmpty();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("IsEmpty"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushboolean(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 IsCanScroll(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureInfiniteList",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureInfiniteList must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool ReturnValue;
	} Params;
#if UE_GAME
	UAzureInfiniteList * This = (UAzureInfiniteList *)Obj;
	Params.ReturnValue = This->IsCanScroll();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("IsCanScroll"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushboolean(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetTailIndex(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureInfiniteList",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureInfiniteList must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		int32 ReturnValue;
	} Params;
#if UE_GAME
	UAzureInfiniteList * This = (UAzureInfiniteList *)Obj;
	Params.ReturnValue = This->GetTailIndex();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetTailIndex"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(int32*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushinteger(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetSlotCount(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureInfiniteList",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureInfiniteList must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		int32 ReturnValue;
	} Params;
#if UE_GAME
	UAzureInfiniteList * This = (UAzureInfiniteList *)Obj;
	Params.ReturnValue = This->GetSlotCount();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetSlotCount"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(int32*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushinteger(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetHeadIndex(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureInfiniteList",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureInfiniteList must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		int32 ReturnValue;
	} Params;
#if UE_GAME
	UAzureInfiniteList * This = (UAzureInfiniteList *)Obj;
	Params.ReturnValue = This->GetHeadIndex();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetHeadIndex"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(int32*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushinteger(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 ForceStopInertialScroll(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureInfiniteList",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureInfiniteList must be non-null"); lua_error(InScriptContext);  return 0;}
#if UE_GAME
	UAzureInfiniteList * This = (UAzureInfiniteList *)Obj;
	This->ForceStopInertialScroll();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("ForceStopInertialScroll"));
	if(!Function) { check(false); return 0;}
	Obj->ProcessEvent(Function, NULL);
#endif
	return 0;
}

int32 FindWidgetByIndex(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureInfiniteList",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureInfiniteList must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		int32 InIndex;
		UWidget* ReturnValue = nullptr;
	} Params;
	Params.InIndex = (luaL_checkint(InScriptContext, 2));
#if UE_GAME
	UAzureInfiniteList * This = (UAzureInfiniteList *)Obj;
	Params.ReturnValue = This->FindWidgetByIndex(Params.InIndex);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("FindWidgetByIndex"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(int32*)(params.GetStructMemory() + 0) = Params.InIndex;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.InIndex = *(int32*)(params.GetStructMemory() + 0);
		Params.ReturnValue = *(UWidget**)(params.GetStructMemory() + 8);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 FindIndexByWidget(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureInfiniteList",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureInfiniteList must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		UWidget* InWidget = nullptr;
		int32 ReturnValue;
	} Params;
	Params.InWidget = (UWidget*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"Widget");;
#if UE_GAME
	UAzureInfiniteList * This = (UAzureInfiniteList *)Obj;
	Params.ReturnValue = This->FindIndexByWidget(Params.InWidget);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("FindIndexByWidget"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(UWidget**)(params.GetStructMemory() + 0) = Params.InWidget;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.InWidget = *(UWidget**)(params.GetStructMemory() + 0);
		Params.ReturnValue = *(int32*)(params.GetStructMemory() + 8);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushinteger(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 FetchCachedWidget(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureInfiniteList",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureInfiniteList must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		UWidget* ReturnValue = nullptr;
	} Params;
#if UE_GAME
	UAzureInfiniteList * This = (UAzureInfiniteList *)Obj;
	Params.ReturnValue = This->FetchCachedWidget();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("FetchCachedWidget"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(UWidget**)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 ClearWidgetCache(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureInfiniteList",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureInfiniteList must be non-null"); lua_error(InScriptContext);  return 0;}
#if UE_GAME
	UAzureInfiniteList * This = (UAzureInfiniteList *)Obj;
	This->ClearWidgetCache();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("ClearWidgetCache"));
	if(!Function) { check(false); return 0;}
	Obj->ProcessEvent(Function, NULL);
#endif
	return 0;
}

int32 Clear(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureInfiniteList",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureInfiniteList must be non-null"); lua_error(InScriptContext);  return 0;}
#if UE_GAME
	UAzureInfiniteList * This = (UAzureInfiniteList *)Obj;
	This->Clear();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("Clear"));
	if(!Function) { check(false); return 0;}
	Obj->ProcessEvent(Function, NULL);
#endif
	return 0;
}

int32 AddTail(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureInfiniteList",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureInfiniteList must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		UWidget* InWidget = nullptr;
		int32 InIndex;
	} Params;
	Params.InWidget = (UWidget*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"Widget");;
	Params.InIndex = (luaL_checkint(InScriptContext, 3));
#if UE_GAME
	UAzureInfiniteList * This = (UAzureInfiniteList *)Obj;
	This->AddTail(Params.InWidget,Params.InIndex);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("AddTail"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(UWidget**)(params.GetStructMemory() + 0) = Params.InWidget;
		*(int32*)(params.GetStructMemory() + 8) = Params.InIndex;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.InWidget = *(UWidget**)(params.GetStructMemory() + 0);
		Params.InIndex = *(int32*)(params.GetStructMemory() + 8);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 AddHead(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureInfiniteList",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureInfiniteList must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		UWidget* InWidget = nullptr;
		int32 InIndex;
	} Params;
	Params.InWidget = (UWidget*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"Widget");;
	Params.InIndex = (luaL_checkint(InScriptContext, 3));
#if UE_GAME
	UAzureInfiniteList * This = (UAzureInfiniteList *)Obj;
	This->AddHead(Params.InWidget,Params.InIndex);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("AddHead"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(UWidget**)(params.GetStructMemory() + 0) = Params.InWidget;
		*(int32*)(params.GetStructMemory() + 8) = Params.InIndex;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.InWidget = *(UWidget**)(params.GetStructMemory() + 0);
		Params.InIndex = *(int32*)(params.GetStructMemory() + 8);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 Get_Orientation(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureInfiniteList",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureInfiniteList must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzureInfiniteList::StaticClass(), TEXT("Orientation"));
	if(!Property) { check(false); return 0;}
	TEnumAsByte<EOrientation> PropertyValue = TEnumAsByte<EOrientation>();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushinteger(InScriptContext, (int)PropertyValue);
	return 1;
}

int32 Get_ScrollBarVisibility(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureInfiniteList",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureInfiniteList must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzureInfiniteList::StaticClass(), TEXT("ScrollBarVisibility"));
	if(!Property) { check(false); return 0;}
	ESlateVisibility PropertyValue = ESlateVisibility();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushinteger(InScriptContext, (int)PropertyValue);
	return 1;
}

int32 Get_ConsumeMouseWheel(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureInfiniteList",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureInfiniteList must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzureInfiniteList::StaticClass(), TEXT("ConsumeMouseWheel"));
	if(!Property) { check(false); return 0;}
	EConsumeMouseWheel PropertyValue = EConsumeMouseWheel();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushinteger(InScriptContext, (int)PropertyValue);
	return 1;
}

int32 Get_ScrollbarThickness(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureInfiniteList",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureInfiniteList must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzureInfiniteList::StaticClass(), TEXT("ScrollbarThickness"));
	if(!Property) { check(false); return 0;}
	FVector2D PropertyValue = FVector2D();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaVector2D::Return(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_AlwaysShowScrollbar(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureInfiniteList",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureInfiniteList must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzureInfiniteList::StaticClass(), TEXT("AlwaysShowScrollbar"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = bool();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_AllowOverscroll(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureInfiniteList",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureInfiniteList must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzureInfiniteList::StaticClass(), TEXT("AllowOverscroll"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = bool();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_bAddFinishEvent(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureInfiniteList",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureInfiniteList must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzureInfiniteList::StaticClass(), TEXT("bAddFinishEvent"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = bool();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_bTriggerBlueprintScrollEvent(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureInfiniteList",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureInfiniteList must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzureInfiniteList::StaticClass(), TEXT("bTriggerBlueprintScrollEvent"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = bool();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_SlotCount(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureInfiniteList",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureInfiniteList must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzureInfiniteList::StaticClass(), TEXT("SlotCount"));
	if(!Property) { check(false); return 0;}
	int32 PropertyValue = int32();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushinteger(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_bScrollEvent(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureInfiniteList",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureInfiniteList must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzureInfiniteList::StaticClass(), TEXT("bScrollEvent"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = bool();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 New(lua_State* InScriptContext)
{
	UObject* Outer = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Object");
	FName Name = FName(luaL_checkstring(InScriptContext, 2));
	UObject* Obj = NewObject<UAzureInfiniteList>(Outer, Name);
	wLua::FLuaUtils::ReturnUObject(InScriptContext,Obj);
	return 1;
}

int32 Destroy(lua_State* InScriptContext)
{
	return 0;
}

int32 Class(lua_State* InScriptContext)
{
	UClass* Class = UAzureInfiniteList::StaticClass();
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Class);
	return 1;
}

const luaL_Reg Lib_Funcs[] =
{
	{ "New", New },
	{ "Destroy", Destroy },
	{ "Class", Class },
	{ "SetSlotCount", SetSlotCount },
	{ "ScrollWidgetIntoView", ScrollWidgetIntoView },
	{ "ScrollToEnd", ScrollToEnd },
	{ "ScrollToBegin", ScrollToBegin },
	{ "IsScrollAtEnd", IsScrollAtEnd },
	{ "IsScrollAtBegin", IsScrollAtBegin },
	{ "IsEmpty", IsEmpty },
	{ "IsCanScroll", IsCanScroll },
	{ "GetTailIndex", GetTailIndex },
	{ "GetSlotCount", GetSlotCount },
	{ "GetHeadIndex", GetHeadIndex },
	{ "ForceStopInertialScroll", ForceStopInertialScroll },
	{ "FindWidgetByIndex", FindWidgetByIndex },
	{ "FindIndexByWidget", FindIndexByWidget },
	{ "FetchCachedWidget", FetchCachedWidget },
	{ "ClearWidgetCache", ClearWidgetCache },
	{ "Clear", Clear },
	{ "AddTail", AddTail },
	{ "AddHead", AddHead },
	{ "Get_Orientation", Get_Orientation },
	{ "Get_ScrollBarVisibility", Get_ScrollBarVisibility },
	{ "Get_ConsumeMouseWheel", Get_ConsumeMouseWheel },
	{ "Get_ScrollbarThickness", Get_ScrollbarThickness },
	{ "Get_AlwaysShowScrollbar", Get_AlwaysShowScrollbar },
	{ "Get_AllowOverscroll", Get_AllowOverscroll },
	{ "Get_bAddFinishEvent", Get_bAddFinishEvent },
	{ "Get_bTriggerBlueprintScrollEvent", Get_bTriggerBlueprintScrollEvent },
	{ "Get_SlotCount", Get_SlotCount },
	{ "Get_bScrollEvent", Get_bScrollEvent },
	{ "SetOnUpdateFunc", SetOnUpdateFunc },
	{ "is_nil", wLua::LuaStatic::isnil },
	{ "__gc", wLua::LuaStatic::removeUClassFrameCache },
	{ NULL, NULL }
};

void Register(lua_State *InScriptContext)
{
	lua_newtable(InScriptContext);
	luaL_register(InScriptContext, NULL, Lib_Funcs);
	AzureHelpFuncs::AuxRegister(InScriptContext, "AzureInfiniteList");
}
void SetMtLink(lua_State *InScriptContext)
{
	AzureHelpFuncs::AuxSetMtLink(InScriptContext, "AzureInfiniteList", "Widget",USERDATATYPE_UOBJECT);
}

}