#include "Azure.h"
#include "Utility/help_funcs.h"
#include "wLua/UObjectHeaders.h"
#include "MediaPlayer.h"
#include "MediaPlaylist.h"
#include "AzureLuaIntegration.h"

namespace LuaMediaPlayer
{
int32 SeekByTimeStamp(lua_State*);
int32 GetDurationTimeStamp(lua_State*);
int32 GetTimeTimeStamp(lua_State*);
int32 bindOnEndReached(lua_State*);
int32 unbindOnEndReached(lua_State*);
int32 bindOnSeekCompleted(lua_State*);
int32 unbindOnSeekCompleted(lua_State*);
int32 bindOnMediaOpened(lua_State*);
int32 unbindOnMediaOpened(lua_State*);
int32 bindOnMediaOpenFailed(lua_State*);
int32 unbindOnMediaOpenFailed(lua_State*);

int32 SupportsSeeking(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MediaPlayer",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MediaPlayer must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool ReturnValue;
	} Params;
#if UE_GAME
	UMediaPlayer * This = (UMediaPlayer *)Obj;
	Params.ReturnValue = This->SupportsSeeking();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SupportsSeeking"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushboolean(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 SupportsScrubbing(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MediaPlayer",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MediaPlayer must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool ReturnValue;
	} Params;
#if UE_GAME
	UMediaPlayer * This = (UMediaPlayer *)Obj;
	Params.ReturnValue = This->SupportsScrubbing();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SupportsScrubbing"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushboolean(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 SupportsRate(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MediaPlayer",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MediaPlayer must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float Rate;
		bool Unthinned;
		bool ReturnValue;
	} Params;
	Params.Rate = (float)(luaL_checknumber(InScriptContext, 2));
	Params.Unthinned = !!(lua_toboolean(InScriptContext, 3));
#if UE_GAME
	UMediaPlayer * This = (UMediaPlayer *)Obj;
	Params.ReturnValue = This->SupportsRate(Params.Rate,Params.Unthinned);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SupportsRate"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(float*)(params.GetStructMemory() + 0) = Params.Rate;
		*(bool*)(params.GetStructMemory() + 4) = Params.Unthinned;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.Rate = *(float*)(params.GetStructMemory() + 0);
		Params.Unthinned = *(bool*)(params.GetStructMemory() + 4);
		Params.ReturnValue = *(bool*)(params.GetStructMemory() + 5);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushboolean(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 SetViewRotation(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MediaPlayer",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MediaPlayer must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FRotator Rotation;
		bool Absolute;
		bool ReturnValue;
	} Params;
	Params.Rotation = (wLua::FLuaRotator::Get(InScriptContext, 2));
	Params.Absolute = !!(lua_toboolean(InScriptContext, 3));
#if UE_GAME
	UMediaPlayer * This = (UMediaPlayer *)Obj;
	Params.ReturnValue = This->SetViewRotation(Params.Rotation,Params.Absolute);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetViewRotation"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FRotator*)(params.GetStructMemory() + 0) = Params.Rotation;
		*(bool*)(params.GetStructMemory() + 12) = Params.Absolute;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.Rotation = *(FRotator*)(params.GetStructMemory() + 0);
		Params.Absolute = *(bool*)(params.GetStructMemory() + 12);
		Params.ReturnValue = *(bool*)(params.GetStructMemory() + 13);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushboolean(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 SetViewField(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MediaPlayer",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MediaPlayer must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float Horizontal;
		float Vertical;
		bool Absolute;
		bool ReturnValue;
	} Params;
	Params.Horizontal = (float)(luaL_checknumber(InScriptContext, 2));
	Params.Vertical = (float)(luaL_checknumber(InScriptContext, 3));
	Params.Absolute = !!(lua_toboolean(InScriptContext, 4));
#if UE_GAME
	UMediaPlayer * This = (UMediaPlayer *)Obj;
	Params.ReturnValue = This->SetViewField(Params.Horizontal,Params.Vertical,Params.Absolute);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetViewField"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(float*)(params.GetStructMemory() + 0) = Params.Horizontal;
		*(float*)(params.GetStructMemory() + 4) = Params.Vertical;
		*(bool*)(params.GetStructMemory() + 8) = Params.Absolute;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.Horizontal = *(float*)(params.GetStructMemory() + 0);
		Params.Vertical = *(float*)(params.GetStructMemory() + 4);
		Params.Absolute = *(bool*)(params.GetStructMemory() + 8);
		Params.ReturnValue = *(bool*)(params.GetStructMemory() + 9);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushboolean(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 SetVideoTrackFrameRate(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MediaPlayer",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MediaPlayer must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		int32 TrackIndex;
		int32 FormatIndex;
		float FrameRate;
		bool ReturnValue;
	} Params;
	Params.TrackIndex = (luaL_checkint(InScriptContext, 2));
	Params.FormatIndex = (luaL_checkint(InScriptContext, 3));
	Params.FrameRate = (float)(luaL_checknumber(InScriptContext, 4));
#if UE_GAME
	UMediaPlayer * This = (UMediaPlayer *)Obj;
	Params.ReturnValue = This->SetVideoTrackFrameRate(Params.TrackIndex,Params.FormatIndex,Params.FrameRate);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetVideoTrackFrameRate"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(int32*)(params.GetStructMemory() + 0) = Params.TrackIndex;
		*(int32*)(params.GetStructMemory() + 4) = Params.FormatIndex;
		*(float*)(params.GetStructMemory() + 8) = Params.FrameRate;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.TrackIndex = *(int32*)(params.GetStructMemory() + 0);
		Params.FormatIndex = *(int32*)(params.GetStructMemory() + 4);
		Params.FrameRate = *(float*)(params.GetStructMemory() + 8);
		Params.ReturnValue = *(bool*)(params.GetStructMemory() + 12);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushboolean(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 SetTrackFormat(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MediaPlayer",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MediaPlayer must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		EMediaPlayerTrack TrackType;
		int32 TrackIndex;
		int32 FormatIndex;
		bool ReturnValue;
	} Params;
	Params.TrackType = (EMediaPlayerTrack)(luaL_checkint(InScriptContext, 2));
	Params.TrackIndex = (luaL_checkint(InScriptContext, 3));
	Params.FormatIndex = (luaL_checkint(InScriptContext, 4));
#if UE_GAME
	UMediaPlayer * This = (UMediaPlayer *)Obj;
	Params.ReturnValue = This->SetTrackFormat(Params.TrackType,Params.TrackIndex,Params.FormatIndex);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetTrackFormat"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(EMediaPlayerTrack*)(params.GetStructMemory() + 0) = Params.TrackType;
		*(int32*)(params.GetStructMemory() + 4) = Params.TrackIndex;
		*(int32*)(params.GetStructMemory() + 8) = Params.FormatIndex;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.TrackType = *(EMediaPlayerTrack*)(params.GetStructMemory() + 0);
		Params.TrackIndex = *(int32*)(params.GetStructMemory() + 4);
		Params.FormatIndex = *(int32*)(params.GetStructMemory() + 8);
		Params.ReturnValue = *(bool*)(params.GetStructMemory() + 12);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushboolean(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 SetRate(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MediaPlayer",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MediaPlayer must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float Rate;
		bool ReturnValue;
	} Params;
	Params.Rate = (float)(luaL_checknumber(InScriptContext, 2));
#if UE_GAME
	UMediaPlayer * This = (UMediaPlayer *)Obj;
	Params.ReturnValue = This->SetRate(Params.Rate);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetRate"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(float*)(params.GetStructMemory() + 0) = Params.Rate;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.Rate = *(float*)(params.GetStructMemory() + 0);
		Params.ReturnValue = *(bool*)(params.GetStructMemory() + 4);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushboolean(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 SetNativeVolume(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MediaPlayer",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MediaPlayer must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float Volume;
		bool ReturnValue;
	} Params;
	Params.Volume = (float)(luaL_checknumber(InScriptContext, 2));
#if UE_GAME
	UMediaPlayer * This = (UMediaPlayer *)Obj;
	Params.ReturnValue = This->SetNativeVolume(Params.Volume);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetNativeVolume"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(float*)(params.GetStructMemory() + 0) = Params.Volume;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.Volume = *(float*)(params.GetStructMemory() + 0);
		Params.ReturnValue = *(bool*)(params.GetStructMemory() + 4);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushboolean(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 SetLooping(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MediaPlayer",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MediaPlayer must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool Looping;
		bool ReturnValue;
	} Params;
	Params.Looping = !!(lua_toboolean(InScriptContext, 2));
#if UE_GAME
	UMediaPlayer * This = (UMediaPlayer *)Obj;
	Params.ReturnValue = This->SetLooping(Params.Looping);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetLooping"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(bool*)(params.GetStructMemory() + 0) = Params.Looping;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.Looping = *(bool*)(params.GetStructMemory() + 0);
		Params.ReturnValue = *(bool*)(params.GetStructMemory() + 1);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushboolean(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 SetDesiredPlayerName(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MediaPlayer",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MediaPlayer must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FName PlayerName;
	} Params;
	Params.PlayerName = FName(UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 2)));
#if UE_GAME
	UMediaPlayer * This = (UMediaPlayer *)Obj;
	This->SetDesiredPlayerName(Params.PlayerName);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetDesiredPlayerName"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FName*)(params.GetStructMemory() + 0) = Params.PlayerName;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.PlayerName = *(FName*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SelectTrack(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MediaPlayer",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MediaPlayer must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		EMediaPlayerTrack TrackType;
		int32 TrackIndex;
		bool ReturnValue;
	} Params;
	Params.TrackType = (EMediaPlayerTrack)(luaL_checkint(InScriptContext, 2));
	Params.TrackIndex = (luaL_checkint(InScriptContext, 3));
#if UE_GAME
	UMediaPlayer * This = (UMediaPlayer *)Obj;
	Params.ReturnValue = This->SelectTrack(Params.TrackType,Params.TrackIndex);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SelectTrack"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(EMediaPlayerTrack*)(params.GetStructMemory() + 0) = Params.TrackType;
		*(int32*)(params.GetStructMemory() + 4) = Params.TrackIndex;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.TrackType = *(EMediaPlayerTrack*)(params.GetStructMemory() + 0);
		Params.TrackIndex = *(int32*)(params.GetStructMemory() + 4);
		Params.ReturnValue = *(bool*)(params.GetStructMemory() + 8);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushboolean(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 Rewind(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MediaPlayer",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MediaPlayer must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool ReturnValue;
	} Params;
#if UE_GAME
	UMediaPlayer * This = (UMediaPlayer *)Obj;
	Params.ReturnValue = This->Rewind();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("Rewind"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushboolean(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 Reopen(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MediaPlayer",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MediaPlayer must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool ReturnValue;
	} Params;
#if UE_GAME
	UMediaPlayer * This = (UMediaPlayer *)Obj;
	Params.ReturnValue = This->Reopen();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("Reopen"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushboolean(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 Previous(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MediaPlayer",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MediaPlayer must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool ReturnValue;
	} Params;
#if UE_GAME
	UMediaPlayer * This = (UMediaPlayer *)Obj;
	Params.ReturnValue = This->Previous();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("Previous"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushboolean(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 Play(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MediaPlayer",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MediaPlayer must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool ReturnValue;
	} Params;
#if UE_GAME
	UMediaPlayer * This = (UMediaPlayer *)Obj;
	Params.ReturnValue = This->Play();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("Play"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushboolean(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 Pause(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MediaPlayer",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MediaPlayer must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool ReturnValue;
	} Params;
#if UE_GAME
	UMediaPlayer * This = (UMediaPlayer *)Obj;
	Params.ReturnValue = This->Pause();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("Pause"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushboolean(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 OpenUrl(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MediaPlayer",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MediaPlayer must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FString Url;
		bool ReturnValue;
	} Params;
	Params.Url = UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 2));
#if UE_GAME
	UMediaPlayer * This = (UMediaPlayer *)Obj;
	Params.ReturnValue = This->OpenUrl(Params.Url);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("OpenUrl"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FString*)(params.GetStructMemory() + 0) = Params.Url;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.Url = *(FString*)(params.GetStructMemory() + 0);
		Params.ReturnValue = *(bool*)(params.GetStructMemory() + 16);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushboolean(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 OpenSource(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MediaPlayer",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MediaPlayer must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		UMediaSource* MediaSource = nullptr;
		bool ReturnValue;
	} Params;
	Params.MediaSource = (UMediaSource*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"MediaSource");;
#if UE_GAME
	UMediaPlayer * This = (UMediaPlayer *)Obj;
	Params.ReturnValue = This->OpenSource(Params.MediaSource);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("OpenSource"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(UMediaSource**)(params.GetStructMemory() + 0) = Params.MediaSource;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.MediaSource = *(UMediaSource**)(params.GetStructMemory() + 0);
		Params.ReturnValue = *(bool*)(params.GetStructMemory() + 8);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushboolean(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 OpenPlaylistIndex(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MediaPlayer",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MediaPlayer must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		UMediaPlaylist* InPlaylist = nullptr;
		int32 Index;
		bool ReturnValue;
	} Params;
	Params.InPlaylist = (UMediaPlaylist*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"MediaPlaylist");;
	Params.Index = (luaL_checkint(InScriptContext, 3));
#if UE_GAME
	UMediaPlayer * This = (UMediaPlayer *)Obj;
	Params.ReturnValue = This->OpenPlaylistIndex(Params.InPlaylist,Params.Index);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("OpenPlaylistIndex"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(UMediaPlaylist**)(params.GetStructMemory() + 0) = Params.InPlaylist;
		*(int32*)(params.GetStructMemory() + 8) = Params.Index;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.InPlaylist = *(UMediaPlaylist**)(params.GetStructMemory() + 0);
		Params.Index = *(int32*)(params.GetStructMemory() + 8);
		Params.ReturnValue = *(bool*)(params.GetStructMemory() + 12);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushboolean(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 OpenPlaylist(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MediaPlayer",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MediaPlayer must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		UMediaPlaylist* InPlaylist = nullptr;
		bool ReturnValue;
	} Params;
	Params.InPlaylist = (UMediaPlaylist*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"MediaPlaylist");;
#if UE_GAME
	UMediaPlayer * This = (UMediaPlayer *)Obj;
	Params.ReturnValue = This->OpenPlaylist(Params.InPlaylist);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("OpenPlaylist"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(UMediaPlaylist**)(params.GetStructMemory() + 0) = Params.InPlaylist;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.InPlaylist = *(UMediaPlaylist**)(params.GetStructMemory() + 0);
		Params.ReturnValue = *(bool*)(params.GetStructMemory() + 8);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushboolean(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 OpenFile(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MediaPlayer",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MediaPlayer must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FString FilePath;
		bool ReturnValue;
	} Params;
	Params.FilePath = UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 2));
#if UE_GAME
	UMediaPlayer * This = (UMediaPlayer *)Obj;
	Params.ReturnValue = This->OpenFile(Params.FilePath);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("OpenFile"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FString*)(params.GetStructMemory() + 0) = Params.FilePath;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.FilePath = *(FString*)(params.GetStructMemory() + 0);
		Params.ReturnValue = *(bool*)(params.GetStructMemory() + 16);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushboolean(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 Next(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MediaPlayer",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MediaPlayer must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool ReturnValue;
	} Params;
#if UE_GAME
	UMediaPlayer * This = (UMediaPlayer *)Obj;
	Params.ReturnValue = This->Next();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("Next"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushboolean(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 IsReady(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MediaPlayer",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MediaPlayer must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool ReturnValue;
	} Params;
#if UE_GAME
	UMediaPlayer * This = (UMediaPlayer *)Obj;
	Params.ReturnValue = This->IsReady();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("IsReady"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushboolean(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 IsPreparing(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MediaPlayer",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MediaPlayer must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool ReturnValue;
	} Params;
#if UE_GAME
	UMediaPlayer * This = (UMediaPlayer *)Obj;
	Params.ReturnValue = This->IsPreparing();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("IsPreparing"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushboolean(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 IsPlaying(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MediaPlayer",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MediaPlayer must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool ReturnValue;
	} Params;
#if UE_GAME
	UMediaPlayer * This = (UMediaPlayer *)Obj;
	Params.ReturnValue = This->IsPlaying();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("IsPlaying"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushboolean(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 IsPaused(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MediaPlayer",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MediaPlayer must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool ReturnValue;
	} Params;
#if UE_GAME
	UMediaPlayer * This = (UMediaPlayer *)Obj;
	Params.ReturnValue = This->IsPaused();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("IsPaused"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushboolean(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 IsLooping(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MediaPlayer",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MediaPlayer must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool ReturnValue;
	} Params;
#if UE_GAME
	UMediaPlayer * This = (UMediaPlayer *)Obj;
	Params.ReturnValue = This->IsLooping();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("IsLooping"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushboolean(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 IsConnecting(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MediaPlayer",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MediaPlayer must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool ReturnValue;
	} Params;
#if UE_GAME
	UMediaPlayer * This = (UMediaPlayer *)Obj;
	Params.ReturnValue = This->IsConnecting();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("IsConnecting"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushboolean(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 IsBuffering(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MediaPlayer",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MediaPlayer must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool ReturnValue;
	} Params;
#if UE_GAME
	UMediaPlayer * This = (UMediaPlayer *)Obj;
	Params.ReturnValue = This->IsBuffering();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("IsBuffering"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushboolean(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 HasError(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MediaPlayer",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MediaPlayer must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool ReturnValue;
	} Params;
#if UE_GAME
	UMediaPlayer * This = (UMediaPlayer *)Obj;
	Params.ReturnValue = This->HasError();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("HasError"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushboolean(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetViewRotation(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MediaPlayer",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MediaPlayer must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FRotator ReturnValue;
	} Params;
#if UE_GAME
	UMediaPlayer * This = (UMediaPlayer *)Obj;
	Params.ReturnValue = This->GetViewRotation();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetViewRotation"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(FRotator*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaRotator::Return(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetVideoTrackType(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MediaPlayer",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MediaPlayer must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		int32 TrackIndex;
		int32 FormatIndex;
		FString ReturnValue;
	} Params;
	Params.TrackIndex = (luaL_checkint(InScriptContext, 2));
	Params.FormatIndex = (luaL_checkint(InScriptContext, 3));
#if UE_GAME
	UMediaPlayer * This = (UMediaPlayer *)Obj;
	Params.ReturnValue = This->GetVideoTrackType(Params.TrackIndex,Params.FormatIndex);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetVideoTrackType"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(int32*)(params.GetStructMemory() + 0) = Params.TrackIndex;
		*(int32*)(params.GetStructMemory() + 4) = Params.FormatIndex;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.TrackIndex = *(int32*)(params.GetStructMemory() + 0);
		Params.FormatIndex = *(int32*)(params.GetStructMemory() + 4);
		Params.ReturnValue = *(FString*)(params.GetStructMemory() + 8);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushstring(InScriptContext, TCHAR_TO_UTF8(*Params.ReturnValue));
	return 1;
}

int32 GetVideoTrackFrameRate(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MediaPlayer",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MediaPlayer must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		int32 TrackIndex;
		int32 FormatIndex;
		float ReturnValue;
	} Params;
	Params.TrackIndex = (luaL_checkint(InScriptContext, 2));
	Params.FormatIndex = (luaL_checkint(InScriptContext, 3));
#if UE_GAME
	UMediaPlayer * This = (UMediaPlayer *)Obj;
	Params.ReturnValue = This->GetVideoTrackFrameRate(Params.TrackIndex,Params.FormatIndex);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetVideoTrackFrameRate"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(int32*)(params.GetStructMemory() + 0) = Params.TrackIndex;
		*(int32*)(params.GetStructMemory() + 4) = Params.FormatIndex;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.TrackIndex = *(int32*)(params.GetStructMemory() + 0);
		Params.FormatIndex = *(int32*)(params.GetStructMemory() + 4);
		Params.ReturnValue = *(float*)(params.GetStructMemory() + 8);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushnumber(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetVideoTrackAspectRatio(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MediaPlayer",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MediaPlayer must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		int32 TrackIndex;
		int32 FormatIndex;
		float ReturnValue;
	} Params;
	Params.TrackIndex = (luaL_checkint(InScriptContext, 2));
	Params.FormatIndex = (luaL_checkint(InScriptContext, 3));
#if UE_GAME
	UMediaPlayer * This = (UMediaPlayer *)Obj;
	Params.ReturnValue = This->GetVideoTrackAspectRatio(Params.TrackIndex,Params.FormatIndex);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetVideoTrackAspectRatio"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(int32*)(params.GetStructMemory() + 0) = Params.TrackIndex;
		*(int32*)(params.GetStructMemory() + 4) = Params.FormatIndex;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.TrackIndex = *(int32*)(params.GetStructMemory() + 0);
		Params.FormatIndex = *(int32*)(params.GetStructMemory() + 4);
		Params.ReturnValue = *(float*)(params.GetStructMemory() + 8);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushnumber(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetVerticalFieldOfView(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MediaPlayer",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MediaPlayer must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float ReturnValue;
	} Params;
#if UE_GAME
	UMediaPlayer * This = (UMediaPlayer *)Obj;
	Params.ReturnValue = This->GetVerticalFieldOfView();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetVerticalFieldOfView"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(float*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushnumber(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetUrl(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MediaPlayer",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MediaPlayer must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FString ReturnValue;
	} Params;
#if UE_GAME
	UMediaPlayer * This = (UMediaPlayer *)Obj;
	Params.ReturnValue = This->GetUrl();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetUrl"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(FString*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushstring(InScriptContext, TCHAR_TO_UTF8(*Params.ReturnValue));
	return 1;
}

int32 GetTrackLanguage(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MediaPlayer",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MediaPlayer must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		EMediaPlayerTrack TrackType;
		int32 TrackIndex;
		FString ReturnValue;
	} Params;
	Params.TrackType = (EMediaPlayerTrack)(luaL_checkint(InScriptContext, 2));
	Params.TrackIndex = (luaL_checkint(InScriptContext, 3));
#if UE_GAME
	UMediaPlayer * This = (UMediaPlayer *)Obj;
	Params.ReturnValue = This->GetTrackLanguage(Params.TrackType,Params.TrackIndex);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetTrackLanguage"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(EMediaPlayerTrack*)(params.GetStructMemory() + 0) = Params.TrackType;
		*(int32*)(params.GetStructMemory() + 4) = Params.TrackIndex;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.TrackType = *(EMediaPlayerTrack*)(params.GetStructMemory() + 0);
		Params.TrackIndex = *(int32*)(params.GetStructMemory() + 4);
		Params.ReturnValue = *(FString*)(params.GetStructMemory() + 8);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushstring(InScriptContext, TCHAR_TO_UTF8(*Params.ReturnValue));
	return 1;
}

int32 GetTrackFormat(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MediaPlayer",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MediaPlayer must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		EMediaPlayerTrack TrackType;
		int32 TrackIndex;
		int32 ReturnValue;
	} Params;
	Params.TrackType = (EMediaPlayerTrack)(luaL_checkint(InScriptContext, 2));
	Params.TrackIndex = (luaL_checkint(InScriptContext, 3));
#if UE_GAME
	UMediaPlayer * This = (UMediaPlayer *)Obj;
	Params.ReturnValue = This->GetTrackFormat(Params.TrackType,Params.TrackIndex);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetTrackFormat"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(EMediaPlayerTrack*)(params.GetStructMemory() + 0) = Params.TrackType;
		*(int32*)(params.GetStructMemory() + 4) = Params.TrackIndex;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.TrackType = *(EMediaPlayerTrack*)(params.GetStructMemory() + 0);
		Params.TrackIndex = *(int32*)(params.GetStructMemory() + 4);
		Params.ReturnValue = *(int32*)(params.GetStructMemory() + 8);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushinteger(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetTrackDisplayName(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MediaPlayer",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MediaPlayer must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		EMediaPlayerTrack TrackType;
		int32 TrackIndex;
		FText ReturnValue;
	} Params;
	Params.TrackType = (EMediaPlayerTrack)(luaL_checkint(InScriptContext, 2));
	Params.TrackIndex = (luaL_checkint(InScriptContext, 3));
#if UE_GAME
	UMediaPlayer * This = (UMediaPlayer *)Obj;
	Params.ReturnValue = This->GetTrackDisplayName(Params.TrackType,Params.TrackIndex);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetTrackDisplayName"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(EMediaPlayerTrack*)(params.GetStructMemory() + 0) = Params.TrackType;
		*(int32*)(params.GetStructMemory() + 4) = Params.TrackIndex;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.TrackType = *(EMediaPlayerTrack*)(params.GetStructMemory() + 0);
		Params.TrackIndex = *(int32*)(params.GetStructMemory() + 4);
		Params.ReturnValue = *(FText*)(params.GetStructMemory() + 8);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushstring(InScriptContext, TCHAR_TO_UTF8(*Params.ReturnValue.ToString()));
	return 1;
}

int32 GetSelectedTrack(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MediaPlayer",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MediaPlayer must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		EMediaPlayerTrack TrackType;
		int32 ReturnValue;
	} Params;
	Params.TrackType = (EMediaPlayerTrack)(luaL_checkint(InScriptContext, 2));
#if UE_GAME
	UMediaPlayer * This = (UMediaPlayer *)Obj;
	Params.ReturnValue = This->GetSelectedTrack(Params.TrackType);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetSelectedTrack"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(EMediaPlayerTrack*)(params.GetStructMemory() + 0) = Params.TrackType;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.TrackType = *(EMediaPlayerTrack*)(params.GetStructMemory() + 0);
		Params.ReturnValue = *(int32*)(params.GetStructMemory() + 4);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushinteger(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetRate(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MediaPlayer",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MediaPlayer must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float ReturnValue;
	} Params;
#if UE_GAME
	UMediaPlayer * This = (UMediaPlayer *)Obj;
	Params.ReturnValue = This->GetRate();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetRate"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(float*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushnumber(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetPlaylistIndex(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MediaPlayer",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MediaPlayer must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		int32 ReturnValue;
	} Params;
#if UE_GAME
	UMediaPlayer * This = (UMediaPlayer *)Obj;
	Params.ReturnValue = This->GetPlaylistIndex();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetPlaylistIndex"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(int32*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushinteger(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetPlaylist(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MediaPlayer",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MediaPlayer must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		UMediaPlaylist* ReturnValue = nullptr;
	} Params;
#if UE_GAME
	UMediaPlayer * This = (UMediaPlayer *)Obj;
	Params.ReturnValue = This->GetPlaylist();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetPlaylist"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(UMediaPlaylist**)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetPlayerName(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MediaPlayer",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MediaPlayer must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FName ReturnValue;
	} Params;
#if UE_GAME
	UMediaPlayer * This = (UMediaPlayer *)Obj;
	Params.ReturnValue = This->GetPlayerName();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetPlayerName"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(FName*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushstring(InScriptContext, TCHAR_TO_UTF8(*Params.ReturnValue.ToString()));
	return 1;
}

int32 GetNumTracks(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MediaPlayer",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MediaPlayer must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		EMediaPlayerTrack TrackType;
		int32 ReturnValue;
	} Params;
	Params.TrackType = (EMediaPlayerTrack)(luaL_checkint(InScriptContext, 2));
#if UE_GAME
	UMediaPlayer * This = (UMediaPlayer *)Obj;
	Params.ReturnValue = This->GetNumTracks(Params.TrackType);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetNumTracks"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(EMediaPlayerTrack*)(params.GetStructMemory() + 0) = Params.TrackType;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.TrackType = *(EMediaPlayerTrack*)(params.GetStructMemory() + 0);
		Params.ReturnValue = *(int32*)(params.GetStructMemory() + 4);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushinteger(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetNumTrackFormats(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MediaPlayer",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MediaPlayer must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		EMediaPlayerTrack TrackType;
		int32 TrackIndex;
		int32 ReturnValue;
	} Params;
	Params.TrackType = (EMediaPlayerTrack)(luaL_checkint(InScriptContext, 2));
	Params.TrackIndex = (luaL_checkint(InScriptContext, 3));
#if UE_GAME
	UMediaPlayer * This = (UMediaPlayer *)Obj;
	Params.ReturnValue = This->GetNumTrackFormats(Params.TrackType,Params.TrackIndex);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetNumTrackFormats"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(EMediaPlayerTrack*)(params.GetStructMemory() + 0) = Params.TrackType;
		*(int32*)(params.GetStructMemory() + 4) = Params.TrackIndex;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.TrackType = *(EMediaPlayerTrack*)(params.GetStructMemory() + 0);
		Params.TrackIndex = *(int32*)(params.GetStructMemory() + 4);
		Params.ReturnValue = *(int32*)(params.GetStructMemory() + 8);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushinteger(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetMediaName(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MediaPlayer",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MediaPlayer must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FText ReturnValue;
	} Params;
#if UE_GAME
	UMediaPlayer * This = (UMediaPlayer *)Obj;
	Params.ReturnValue = This->GetMediaName();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetMediaName"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(FText*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushstring(InScriptContext, TCHAR_TO_UTF8(*Params.ReturnValue.ToString()));
	return 1;
}

int32 GetHorizontalFieldOfView(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MediaPlayer",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MediaPlayer must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float ReturnValue;
	} Params;
#if UE_GAME
	UMediaPlayer * This = (UMediaPlayer *)Obj;
	Params.ReturnValue = This->GetHorizontalFieldOfView();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetHorizontalFieldOfView"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(float*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushnumber(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetDesiredPlayerName(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MediaPlayer",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MediaPlayer must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FName ReturnValue;
	} Params;
#if UE_GAME
	UMediaPlayer * This = (UMediaPlayer *)Obj;
	Params.ReturnValue = This->GetDesiredPlayerName();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetDesiredPlayerName"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(FName*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushstring(InScriptContext, TCHAR_TO_UTF8(*Params.ReturnValue.ToString()));
	return 1;
}

int32 GetAudioTrackType(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MediaPlayer",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MediaPlayer must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		int32 TrackIndex;
		int32 FormatIndex;
		FString ReturnValue;
	} Params;
	Params.TrackIndex = (luaL_checkint(InScriptContext, 2));
	Params.FormatIndex = (luaL_checkint(InScriptContext, 3));
#if UE_GAME
	UMediaPlayer * This = (UMediaPlayer *)Obj;
	Params.ReturnValue = This->GetAudioTrackType(Params.TrackIndex,Params.FormatIndex);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetAudioTrackType"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(int32*)(params.GetStructMemory() + 0) = Params.TrackIndex;
		*(int32*)(params.GetStructMemory() + 4) = Params.FormatIndex;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.TrackIndex = *(int32*)(params.GetStructMemory() + 0);
		Params.FormatIndex = *(int32*)(params.GetStructMemory() + 4);
		Params.ReturnValue = *(FString*)(params.GetStructMemory() + 8);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushstring(InScriptContext, TCHAR_TO_UTF8(*Params.ReturnValue));
	return 1;
}

int32 GetAudioTrackSampleRate(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MediaPlayer",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MediaPlayer must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		int32 TrackIndex;
		int32 FormatIndex;
		int32 ReturnValue;
	} Params;
	Params.TrackIndex = (luaL_checkint(InScriptContext, 2));
	Params.FormatIndex = (luaL_checkint(InScriptContext, 3));
#if UE_GAME
	UMediaPlayer * This = (UMediaPlayer *)Obj;
	Params.ReturnValue = This->GetAudioTrackSampleRate(Params.TrackIndex,Params.FormatIndex);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetAudioTrackSampleRate"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(int32*)(params.GetStructMemory() + 0) = Params.TrackIndex;
		*(int32*)(params.GetStructMemory() + 4) = Params.FormatIndex;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.TrackIndex = *(int32*)(params.GetStructMemory() + 0);
		Params.FormatIndex = *(int32*)(params.GetStructMemory() + 4);
		Params.ReturnValue = *(int32*)(params.GetStructMemory() + 8);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushinteger(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetAudioTrackChannels(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MediaPlayer",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MediaPlayer must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		int32 TrackIndex;
		int32 FormatIndex;
		int32 ReturnValue;
	} Params;
	Params.TrackIndex = (luaL_checkint(InScriptContext, 2));
	Params.FormatIndex = (luaL_checkint(InScriptContext, 3));
#if UE_GAME
	UMediaPlayer * This = (UMediaPlayer *)Obj;
	Params.ReturnValue = This->GetAudioTrackChannels(Params.TrackIndex,Params.FormatIndex);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetAudioTrackChannels"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(int32*)(params.GetStructMemory() + 0) = Params.TrackIndex;
		*(int32*)(params.GetStructMemory() + 4) = Params.FormatIndex;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.TrackIndex = *(int32*)(params.GetStructMemory() + 0);
		Params.FormatIndex = *(int32*)(params.GetStructMemory() + 4);
		Params.ReturnValue = *(int32*)(params.GetStructMemory() + 8);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushinteger(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 Close(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MediaPlayer",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MediaPlayer must be non-null"); lua_error(InScriptContext);  return 0;}
#if UE_GAME
	UMediaPlayer * This = (UMediaPlayer *)Obj;
	This->Close();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("Close"));
	if(!Function) { check(false); return 0;}
	Obj->ProcessEvent(Function, NULL);
#endif
	return 0;
}

int32 CanPlayUrl(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MediaPlayer",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MediaPlayer must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FString Url;
		bool ReturnValue;
	} Params;
	Params.Url = UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 2));
#if UE_GAME
	UMediaPlayer * This = (UMediaPlayer *)Obj;
	Params.ReturnValue = This->CanPlayUrl(Params.Url);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("CanPlayUrl"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FString*)(params.GetStructMemory() + 0) = Params.Url;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.Url = *(FString*)(params.GetStructMemory() + 0);
		Params.ReturnValue = *(bool*)(params.GetStructMemory() + 16);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushboolean(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 CanPlaySource(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MediaPlayer",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MediaPlayer must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		UMediaSource* MediaSource = nullptr;
		bool ReturnValue;
	} Params;
	Params.MediaSource = (UMediaSource*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"MediaSource");;
#if UE_GAME
	UMediaPlayer * This = (UMediaPlayer *)Obj;
	Params.ReturnValue = This->CanPlaySource(Params.MediaSource);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("CanPlaySource"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(UMediaSource**)(params.GetStructMemory() + 0) = Params.MediaSource;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.MediaSource = *(UMediaSource**)(params.GetStructMemory() + 0);
		Params.ReturnValue = *(bool*)(params.GetStructMemory() + 8);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushboolean(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 CanPause(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MediaPlayer",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MediaPlayer must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool ReturnValue;
	} Params;
#if UE_GAME
	UMediaPlayer * This = (UMediaPlayer *)Obj;
	Params.ReturnValue = This->CanPause();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("CanPause"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushboolean(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 Call_OnEndReached(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MediaPlayer",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MediaPlayer must be non-null"); lua_error(InScriptContext);  return 0;}
	UMediaPlayer * This = (UMediaPlayer *)Obj;
	This->OnEndReached.Broadcast();
	return 0;
}

int32 Call_OnMediaClosed(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MediaPlayer",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MediaPlayer must be non-null"); lua_error(InScriptContext);  return 0;}
	UMediaPlayer * This = (UMediaPlayer *)Obj;
	This->OnMediaClosed.Broadcast();
	return 0;
}

int32 Call_OnMediaOpened(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MediaPlayer",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MediaPlayer must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FString OpenedUrl;
	} Params;
	Params.OpenedUrl = UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 2));
	UMediaPlayer * This = (UMediaPlayer *)Obj;
	This->OnMediaOpened.Broadcast(Params.OpenedUrl);
	return 0;
}

int32 Call_OnMediaOpenFailed(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MediaPlayer",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MediaPlayer must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FString FailedUrl;
	} Params;
	Params.FailedUrl = UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 2));
	UMediaPlayer * This = (UMediaPlayer *)Obj;
	This->OnMediaOpenFailed.Broadcast(Params.FailedUrl);
	return 0;
}

int32 Call_OnPlaybackResumed(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MediaPlayer",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MediaPlayer must be non-null"); lua_error(InScriptContext);  return 0;}
	UMediaPlayer * This = (UMediaPlayer *)Obj;
	This->OnPlaybackResumed.Broadcast();
	return 0;
}

int32 Call_OnPlaybackSuspended(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MediaPlayer",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MediaPlayer must be non-null"); lua_error(InScriptContext);  return 0;}
	UMediaPlayer * This = (UMediaPlayer *)Obj;
	This->OnPlaybackSuspended.Broadcast();
	return 0;
}

int32 Call_OnSeekCompleted(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MediaPlayer",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MediaPlayer must be non-null"); lua_error(InScriptContext);  return 0;}
	UMediaPlayer * This = (UMediaPlayer *)Obj;
	This->OnSeekCompleted.Broadcast();
	return 0;
}

int32 Call_OnTracksChanged(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MediaPlayer",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MediaPlayer must be non-null"); lua_error(InScriptContext);  return 0;}
	UMediaPlayer * This = (UMediaPlayer *)Obj;
	This->OnTracksChanged.Broadcast();
	return 0;
}

int32 Get_NativeAudioOut(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MediaPlayer",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MediaPlayer must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UMediaPlayer::StaticClass(), TEXT("NativeAudioOut"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = bool();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_NativeAudioOut(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MediaPlayer",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MediaPlayer must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UMediaPlayer::StaticClass(), TEXT("NativeAudioOut"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_PlayOnOpen(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MediaPlayer",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MediaPlayer must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UMediaPlayer::StaticClass(), TEXT("PlayOnOpen"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = bool();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_PlayOnOpen(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MediaPlayer",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MediaPlayer must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UMediaPlayer::StaticClass(), TEXT("PlayOnOpen"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_Shuffle(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MediaPlayer",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MediaPlayer must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UMediaPlayer::StaticClass(), TEXT("Shuffle"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_Shuffle(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MediaPlayer",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MediaPlayer must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UMediaPlayer::StaticClass(), TEXT("Shuffle"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_Loop(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MediaPlayer",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MediaPlayer must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UMediaPlayer::StaticClass(), TEXT("Loop"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_Playlist(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MediaPlayer",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MediaPlayer must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UMediaPlayer::StaticClass(), TEXT("Playlist"));
	if(!Property) { check(false); return 0;}
	UMediaPlaylist* PropertyValue;
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaUtils::ReturnUObject(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_PlaylistIndex(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MediaPlayer",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MediaPlayer must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UMediaPlayer::StaticClass(), TEXT("PlaylistIndex"));
	if(!Property) { check(false); return 0;}
	int32 PropertyValue = int32();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushinteger(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_HorizontalFieldOfView(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MediaPlayer",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MediaPlayer must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UMediaPlayer::StaticClass(), TEXT("HorizontalFieldOfView"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_HorizontalFieldOfView(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MediaPlayer",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MediaPlayer must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UMediaPlayer::StaticClass(), TEXT("HorizontalFieldOfView"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_VerticalFieldOfView(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MediaPlayer",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MediaPlayer must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UMediaPlayer::StaticClass(), TEXT("VerticalFieldOfView"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_VerticalFieldOfView(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MediaPlayer",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MediaPlayer must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UMediaPlayer::StaticClass(), TEXT("VerticalFieldOfView"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_ViewRotation(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MediaPlayer",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MediaPlayer must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UMediaPlayer::StaticClass(), TEXT("ViewRotation"));
	if(!Property) { check(false); return 0;}
	FRotator PropertyValue = FRotator();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaRotator::Return(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_ViewRotation(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MediaPlayer",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MediaPlayer must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UMediaPlayer::StaticClass(), TEXT("ViewRotation"));
	if(!Property) { check(false); return 0;}
	FRotator PropertyValue = (wLua::FLuaRotator::Get(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_AffectedByPIEHandling(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MediaPlayer",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MediaPlayer must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UMediaPlayer::StaticClass(), TEXT("AffectedByPIEHandling"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = bool();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_AffectedByPIEHandling(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MediaPlayer",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MediaPlayer must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UMediaPlayer::StaticClass(), TEXT("AffectedByPIEHandling"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 New(lua_State* InScriptContext)
{
	UObject* Outer = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Object");
	FName Name = FName(luaL_checkstring(InScriptContext, 2));
	UObject* Obj = NewObject<UMediaPlayer>(Outer, Name);
	wLua::FLuaUtils::ReturnUObject(InScriptContext,Obj);
	return 1;
}

int32 Destroy(lua_State* InScriptContext)
{
	return 0;
}

int32 Class(lua_State* InScriptContext)
{
	UClass* Class = UMediaPlayer::StaticClass();
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Class);
	return 1;
}

const luaL_Reg Lib_Funcs[] =
{
	{ "New", New },
	{ "Destroy", Destroy },
	{ "Class", Class },
	{ "SupportsSeeking", SupportsSeeking },
	{ "SupportsScrubbing", SupportsScrubbing },
	{ "SupportsRate", SupportsRate },
	{ "SetViewRotation", SetViewRotation },
	{ "SetViewField", SetViewField },
	{ "SetVideoTrackFrameRate", SetVideoTrackFrameRate },
	{ "SetTrackFormat", SetTrackFormat },
	{ "SetRate", SetRate },
	{ "SetNativeVolume", SetNativeVolume },
	{ "SetLooping", SetLooping },
	{ "SetDesiredPlayerName", SetDesiredPlayerName },
	{ "SelectTrack", SelectTrack },
	{ "Rewind", Rewind },
	{ "Reopen", Reopen },
	{ "Previous", Previous },
	{ "Play", Play },
	{ "Pause", Pause },
	{ "OpenUrl", OpenUrl },
	{ "OpenSource", OpenSource },
	{ "OpenPlaylistIndex", OpenPlaylistIndex },
	{ "OpenPlaylist", OpenPlaylist },
	{ "OpenFile", OpenFile },
	{ "Next", Next },
	{ "IsReady", IsReady },
	{ "IsPreparing", IsPreparing },
	{ "IsPlaying", IsPlaying },
	{ "IsPaused", IsPaused },
	{ "IsLooping", IsLooping },
	{ "IsConnecting", IsConnecting },
	{ "IsBuffering", IsBuffering },
	{ "HasError", HasError },
	{ "GetViewRotation", GetViewRotation },
	{ "GetVideoTrackType", GetVideoTrackType },
	{ "GetVideoTrackFrameRate", GetVideoTrackFrameRate },
	{ "GetVideoTrackAspectRatio", GetVideoTrackAspectRatio },
	{ "GetVerticalFieldOfView", GetVerticalFieldOfView },
	{ "GetUrl", GetUrl },
	{ "GetTrackLanguage", GetTrackLanguage },
	{ "GetTrackFormat", GetTrackFormat },
	{ "GetTrackDisplayName", GetTrackDisplayName },
	{ "GetSelectedTrack", GetSelectedTrack },
	{ "GetRate", GetRate },
	{ "GetPlaylistIndex", GetPlaylistIndex },
	{ "GetPlaylist", GetPlaylist },
	{ "GetPlayerName", GetPlayerName },
	{ "GetNumTracks", GetNumTracks },
	{ "GetNumTrackFormats", GetNumTrackFormats },
	{ "GetMediaName", GetMediaName },
	{ "GetHorizontalFieldOfView", GetHorizontalFieldOfView },
	{ "GetDesiredPlayerName", GetDesiredPlayerName },
	{ "GetAudioTrackType", GetAudioTrackType },
	{ "GetAudioTrackSampleRate", GetAudioTrackSampleRate },
	{ "GetAudioTrackChannels", GetAudioTrackChannels },
	{ "Close", Close },
	{ "CanPlayUrl", CanPlayUrl },
	{ "CanPlaySource", CanPlaySource },
	{ "CanPause", CanPause },
	{ "Call_OnEndReached", Call_OnEndReached },
	{ "Call_OnMediaClosed", Call_OnMediaClosed },
	{ "Call_OnMediaOpened", Call_OnMediaOpened },
	{ "Call_OnMediaOpenFailed", Call_OnMediaOpenFailed },
	{ "Call_OnPlaybackResumed", Call_OnPlaybackResumed },
	{ "Call_OnPlaybackSuspended", Call_OnPlaybackSuspended },
	{ "Call_OnSeekCompleted", Call_OnSeekCompleted },
	{ "Call_OnTracksChanged", Call_OnTracksChanged },
	{ "Get_NativeAudioOut", Get_NativeAudioOut },
	{ "Set_NativeAudioOut", Set_NativeAudioOut },
	{ "Get_PlayOnOpen", Get_PlayOnOpen },
	{ "Set_PlayOnOpen", Set_PlayOnOpen },
	{ "Get_Shuffle", Get_Shuffle },
	{ "Set_Shuffle", Set_Shuffle },
	{ "Get_Loop", Get_Loop },
	{ "Get_Playlist", Get_Playlist },
	{ "Get_PlaylistIndex", Get_PlaylistIndex },
	{ "Get_HorizontalFieldOfView", Get_HorizontalFieldOfView },
	{ "Set_HorizontalFieldOfView", Set_HorizontalFieldOfView },
	{ "Get_VerticalFieldOfView", Get_VerticalFieldOfView },
	{ "Set_VerticalFieldOfView", Set_VerticalFieldOfView },
	{ "Get_ViewRotation", Get_ViewRotation },
	{ "Set_ViewRotation", Set_ViewRotation },
	{ "Get_AffectedByPIEHandling", Get_AffectedByPIEHandling },
	{ "Set_AffectedByPIEHandling", Set_AffectedByPIEHandling },
	{ "SeekByTimeStamp", SeekByTimeStamp },
	{ "GetDurationTimeStamp", GetDurationTimeStamp },
	{ "GetTimeTimeStamp", GetTimeTimeStamp },
	{ "bindOnEndReached", bindOnEndReached },
	{ "unbindOnEndReached", unbindOnEndReached },
	{ "bindOnSeekCompleted", bindOnSeekCompleted },
	{ "unbindOnSeekCompleted", unbindOnSeekCompleted },
	{ "bindOnMediaOpened", bindOnMediaOpened },
	{ "unbindOnMediaOpened", unbindOnMediaOpened },
	{ "bindOnMediaOpenFailed", bindOnMediaOpenFailed },
	{ "unbindOnMediaOpenFailed", unbindOnMediaOpenFailed },
	{ "is_nil", wLua::LuaStatic::isnil },
	{ "__gc", wLua::LuaStatic::removeUClassFrameCache },
	{ NULL, NULL }
};

void Register(lua_State *InScriptContext)
{
	lua_newtable(InScriptContext);
	luaL_register(InScriptContext, NULL, Lib_Funcs);
	AzureHelpFuncs::AuxRegister(InScriptContext, "MediaPlayer");
}
void SetMtLink(lua_State *InScriptContext)
{
	AzureHelpFuncs::AuxSetMtLink(InScriptContext, "MediaPlayer", "Object",USERDATATYPE_UOBJECT);
}

}