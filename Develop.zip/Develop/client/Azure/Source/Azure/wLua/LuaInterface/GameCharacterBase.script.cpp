#include "Azure.h"
#include "Utility/help_funcs.h"
#include "wLua/UObjectHeaders.h"
#include "GameLogic/Player/GameCharacterBase.h"
#include "../UClassHeaders.h"
#include "AzureLuaIntegration.h"

namespace LuaGameCharacterBase
{
int32 SetFeetRelativeLocationAlongDir(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"GameCharacterBase",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"GameCharacterBase must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FVector pos;
	} Params;
	Params.pos = (wLua::FLuaVector::Get(InScriptContext, 2));
#if UE_GAME
	AGameCharacterBase * This = (AGameCharacterBase *)Obj;
	This->SetFeetRelativeLocationAlongDir(Params.pos);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetFeetRelativeLocationAlongDir"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FVector*)(params.GetStructMemory() + 0) = Params.pos;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.pos = *(FVector*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetFeetLocationAlongDir(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"GameCharacterBase",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"GameCharacterBase must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FVector pos;
	} Params;
	Params.pos = (wLua::FLuaVector::Get(InScriptContext, 2));
#if UE_GAME
	AGameCharacterBase * This = (AGameCharacterBase *)Obj;
	This->SetFeetLocationAlongDir(Params.pos);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetFeetLocationAlongDir"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FVector*)(params.GetStructMemory() + 0) = Params.pos;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.pos = *(FVector*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 IsNone(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"GameCharacterBase",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"GameCharacterBase must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool ReturnValue;
	} Params;
#if UE_GAME
	AGameCharacterBase * This = (AGameCharacterBase *)Obj;
	Params.ReturnValue = This->IsNone();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("IsNone"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushboolean(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 IsHostPlayer(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"GameCharacterBase",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"GameCharacterBase must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool ReturnValue;
	} Params;
#if UE_GAME
	AGameCharacterBase * This = (AGameCharacterBase *)Obj;
	Params.ReturnValue = This->IsHostPlayer();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("IsHostPlayer"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushboolean(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetHalfHeight(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"GameCharacterBase",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"GameCharacterBase must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float ReturnValue;
	} Params;
#if UE_GAME
	AGameCharacterBase * This = (AGameCharacterBase *)Obj;
	Params.ReturnValue = This->GetHalfHeight();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetHalfHeight"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(float*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushnumber(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 New(lua_State* InScriptContext)
{
	UObject* Outer = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Object");
	FName Name = FName(luaL_checkstring(InScriptContext, 2));
	UObject* Obj = NewObject<AGameCharacterBase>(Outer, Name);
	wLua::FLuaUtils::ReturnUObject(InScriptContext,Obj);
	return 1;
}

int32 Destroy(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"GameCharacterBase",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"GameCharacterBase must be non-null"); lua_error(InScriptContext);  return 0;}
		AActor * actor = Cast<AActor>(Obj);
		actor->Destroy();
		userdata->flag |= wLua::LuaObjectFlag::DESTROYED;
		wLua::FLuaUtils::RemoveObjectReference(Obj, userdata->stamp, InScriptContext);
#ifdef AZURE_BUILD_WLUACHECK
		UE_LOG(LogAzure, Warning, TEXT("Destroy GameCharacterBase: %x userdata:%x   stamp:%x"),Obj,userdata,userdata->stamp);
#endif
	return 0;
}

int32 Class(lua_State* InScriptContext)
{
	UClass* Class = AGameCharacterBase::StaticClass();
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Class);
	return 1;
}

const luaL_Reg Lib_Funcs[] =
{
	{ "New", New },
	{ "Destroy", Destroy },
	{ "Class", Class },
	{ "SetFeetRelativeLocationAlongDir", SetFeetRelativeLocationAlongDir },
	{ "SetFeetLocationAlongDir", SetFeetLocationAlongDir },
	{ "IsNone", IsNone },
	{ "IsHostPlayer", IsHostPlayer },
	{ "GetHalfHeight", GetHalfHeight },
	{ "is_nil", wLua::LuaStatic::isnil },
	{ "__gc", wLua::LuaStatic::removeUClassFrameCache },
	{ NULL, NULL }
};

void Register(lua_State *InScriptContext)
{
	lua_newtable(InScriptContext);
	luaL_register(InScriptContext, NULL, Lib_Funcs);
	AzureHelpFuncs::AuxRegister(InScriptContext, "GameCharacterBase");
}
void SetMtLink(lua_State *InScriptContext)
{
	AzureHelpFuncs::AuxSetMtLink(InScriptContext, "GameCharacterBase", "Character",USERDATATYPE_UOBJECT);
}

}