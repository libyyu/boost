#include "Azure.h"
#include "Utility/help_funcs.h"
#include "wLua/UObjectHeaders.h"
#include "AzurePolygonImage.h"
#include "AzureLuaIntegration.h"

namespace LuaAzurePolygonImage
{
int32 SetPercentText(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzurePolygonImage",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzurePolygonImage must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FString InString;
		int32 InIndex;
	} Params;
	Params.InString = UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 2));
	Params.InIndex = (luaL_checkint(InScriptContext, 3));
#if UE_GAME
	UAzurePolygonImage * This = (UAzurePolygonImage *)Obj;
	This->SetPercentText(Params.InString,Params.InIndex);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetPercentText"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FString*)(params.GetStructMemory() + 0) = Params.InString;
		*(int32*)(params.GetStructMemory() + 16) = Params.InIndex;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.InString = *(FString*)(params.GetStructMemory() + 0);
		Params.InIndex = *(int32*)(params.GetStructMemory() + 16);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetPercentColor(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzurePolygonImage",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzurePolygonImage must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FLinearColor InTextColor;
		FLinearColor InDotColor;
		int32 InIndex;
	} Params;
	Params.InTextColor = (wLua::FLuaLinearColor::Get(InScriptContext, 2));
	Params.InDotColor = (wLua::FLuaLinearColor::Get(InScriptContext, 3));
	Params.InIndex = (luaL_checkint(InScriptContext, 4));
#if UE_GAME
	UAzurePolygonImage * This = (UAzurePolygonImage *)Obj;
	This->SetPercentColor(Params.InTextColor,Params.InDotColor,Params.InIndex);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetPercentColor"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FLinearColor*)(params.GetStructMemory() + 0) = Params.InTextColor;
		*(FLinearColor*)(params.GetStructMemory() + 16) = Params.InDotColor;
		*(int32*)(params.GetStructMemory() + 32) = Params.InIndex;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.InTextColor = *(FLinearColor*)(params.GetStructMemory() + 0);
		Params.InDotColor = *(FLinearColor*)(params.GetStructMemory() + 16);
		Params.InIndex = *(int32*)(params.GetStructMemory() + 32);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetPercent(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzurePolygonImage",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzurePolygonImage must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float InPercent;
		int32 InIndex;
	} Params;
	Params.InPercent = (float)(luaL_checknumber(InScriptContext, 2));
	Params.InIndex = (luaL_checkint(InScriptContext, 3));
#if UE_GAME
	UAzurePolygonImage * This = (UAzurePolygonImage *)Obj;
	This->SetPercent(Params.InPercent,Params.InIndex);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetPercent"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(float*)(params.GetStructMemory() + 0) = Params.InPercent;
		*(int32*)(params.GetStructMemory() + 4) = Params.InIndex;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.InPercent = *(float*)(params.GetStructMemory() + 0);
		Params.InIndex = *(int32*)(params.GetStructMemory() + 4);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 Get_PolygonN(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzurePolygonImage",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzurePolygonImage must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzurePolygonImage::StaticClass(), TEXT("PolygonN"));
	if(!Property) { check(false); return 0;}
	int32 PropertyValue = int32();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushinteger(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_TextPadding(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzurePolygonImage",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzurePolygonImage must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzurePolygonImage::StaticClass(), TEXT("TextPadding"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_BMFont(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzurePolygonImage",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzurePolygonImage must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzurePolygonImage::StaticClass(), TEXT("BMFont"));
	if(!Property) { check(false); return 0;}
	UAzureBMFont* PropertyValue;
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaUtils::ReturnUObject(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_FeatherOutline(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzurePolygonImage",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzurePolygonImage must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzurePolygonImage::StaticClass(), TEXT("FeatherOutline"));
	if(!Property) { check(false); return 0;}
	int32 PropertyValue = int32();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushinteger(InScriptContext, PropertyValue);
	return 1;
}

int32 New(lua_State* InScriptContext)
{
	UObject* Outer = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Object");
	FName Name = FName(luaL_checkstring(InScriptContext, 2));
	UObject* Obj = NewObject<UAzurePolygonImage>(Outer, Name);
	wLua::FLuaUtils::ReturnUObject(InScriptContext,Obj);
	return 1;
}

int32 Destroy(lua_State* InScriptContext)
{
	return 0;
}

int32 Class(lua_State* InScriptContext)
{
	UClass* Class = UAzurePolygonImage::StaticClass();
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Class);
	return 1;
}

const luaL_Reg Lib_Funcs[] =
{
	{ "New", New },
	{ "Destroy", Destroy },
	{ "Class", Class },
	{ "SetPercentText", SetPercentText },
	{ "SetPercentColor", SetPercentColor },
	{ "SetPercent", SetPercent },
	{ "Get_PolygonN", Get_PolygonN },
	{ "Get_TextPadding", Get_TextPadding },
	{ "Get_BMFont", Get_BMFont },
	{ "Get_FeatherOutline", Get_FeatherOutline },
	{ "is_nil", wLua::LuaStatic::isnil },
	{ "__gc", wLua::LuaStatic::removeUClassFrameCache },
	{ NULL, NULL }
};

void Register(lua_State *InScriptContext)
{
	lua_newtable(InScriptContext);
	luaL_register(InScriptContext, NULL, Lib_Funcs);
	AzureHelpFuncs::AuxRegister(InScriptContext, "AzurePolygonImage");
}
void SetMtLink(lua_State *InScriptContext)
{
	AzureHelpFuncs::AuxSetMtLink(InScriptContext, "AzurePolygonImage", "Image",USERDATATYPE_UOBJECT);
}

}