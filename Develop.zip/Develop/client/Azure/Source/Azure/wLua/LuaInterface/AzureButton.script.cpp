#include "Azure.h"
#include "Utility/help_funcs.h"
#include "wLua/UObjectHeaders.h"
#include "AzureButton.h"
#include "AzureLuaIntegration.h"

namespace LuaAzureButton
{
int32 setOnClickFunc(lua_State*);

int32 ClearScaleState(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureButton",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureButton must be non-null"); lua_error(InScriptContext);  return 0;}
#if UE_GAME
	UAzureButton * This = (UAzureButton *)Obj;
	This->ClearScaleState();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("ClearScaleState"));
	if(!Function) { check(false); return 0;}
	Obj->ProcessEvent(Function, NULL);
#endif
	return 0;
}

int32 Get_SeekParentDepth(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureButton",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureButton must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzureButton::StaticClass(), TEXT("SeekParentDepth"));
	if(!Property) { check(false); return 0;}
	int32 PropertyValue = int32();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushinteger(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_IsScaleOnPressed(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureButton",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureButton must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzureButton::StaticClass(), TEXT("IsScaleOnPressed"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = bool();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_ScaleFactor(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureButton",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureButton must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzureButton::StaticClass(), TEXT("ScaleFactor"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_ScaleTime(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureButton",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureButton must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzureButton::StaticClass(), TEXT("ScaleTime"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_bLongPress(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureButton",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureButton must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzureButton::StaticClass(), TEXT("bLongPress"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = bool();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_IsReponseToBackButton(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureButton",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureButton must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzureButton::StaticClass(), TEXT("IsReponseToBackButton"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = bool();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_IsReponseToBackButton(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureButton",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureButton must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzureButton::StaticClass(), TEXT("IsReponseToBackButton"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_BackButtonParent(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureButton",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureButton must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzureButton::StaticClass(), TEXT("BackButtonParent"));
	if(!Property) { check(false); return 0;}
	FName PropertyValue = FName();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushstring(InScriptContext, TCHAR_TO_UTF8(*PropertyValue.ToString()));
	return 1;
}

int32 Set_BackButtonParent(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureButton",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureButton must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzureButton::StaticClass(), TEXT("BackButtonParent"));
	if(!Property) { check(false); return 0;}
	FName PropertyValue = FName(UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 2)));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 New(lua_State* InScriptContext)
{
	UObject* Outer = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Object");
	FName Name = FName(luaL_checkstring(InScriptContext, 2));
	UObject* Obj = NewObject<UAzureButton>(Outer, Name);
	wLua::FLuaUtils::ReturnUObject(InScriptContext,Obj);
	return 1;
}

int32 Destroy(lua_State* InScriptContext)
{
	return 0;
}

int32 Class(lua_State* InScriptContext)
{
	UClass* Class = UAzureButton::StaticClass();
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Class);
	return 1;
}

const luaL_Reg Lib_Funcs[] =
{
	{ "New", New },
	{ "Destroy", Destroy },
	{ "Class", Class },
	{ "ClearScaleState", ClearScaleState },
	{ "Get_SeekParentDepth", Get_SeekParentDepth },
	{ "Get_IsScaleOnPressed", Get_IsScaleOnPressed },
	{ "Get_ScaleFactor", Get_ScaleFactor },
	{ "Get_ScaleTime", Get_ScaleTime },
	{ "Get_bLongPress", Get_bLongPress },
	{ "Get_IsReponseToBackButton", Get_IsReponseToBackButton },
	{ "Set_IsReponseToBackButton", Set_IsReponseToBackButton },
	{ "Get_BackButtonParent", Get_BackButtonParent },
	{ "Set_BackButtonParent", Set_BackButtonParent },
	{ "setOnClickFunc", setOnClickFunc },
	{ "is_nil", wLua::LuaStatic::isnil },
	{ "__gc", wLua::LuaStatic::removeUClassFrameCache },
	{ NULL, NULL }
};

void Register(lua_State *InScriptContext)
{
	lua_newtable(InScriptContext);
	luaL_register(InScriptContext, NULL, Lib_Funcs);
	AzureHelpFuncs::AuxRegister(InScriptContext, "AzureButton");
}
void SetMtLink(lua_State *InScriptContext)
{
	AzureHelpFuncs::AuxSetMtLink(InScriptContext, "AzureButton", "Button",USERDATATYPE_UOBJECT);
}

}