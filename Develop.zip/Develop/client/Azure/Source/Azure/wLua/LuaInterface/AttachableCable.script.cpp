#include "Azure.h"
#include "Utility/help_funcs.h"
#include "wLua/UObjectHeaders.h"
#include "GameLogic/Weapon/AttachableCable.h"
#include "AzureLuaIntegration.h"

namespace LuaAttachableCable
{
int32 SetEndRelativeLocation(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AttachableCable",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AttachableCable must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FVector Location;
	} Params;
	Params.Location = (wLua::FLuaVector::Get(InScriptContext, 2));
#if UE_GAME
	AAttachableCable * This = (AAttachableCable *)Obj;
	This->SetEndRelativeLocation(Params.Location);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetEndRelativeLocation"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FVector*)(params.GetStructMemory() + 0) = Params.Location;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.Location = *(FVector*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetEnabled(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AttachableCable",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AttachableCable must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool bEnabled;
	} Params;
	Params.bEnabled = !!(lua_toboolean(InScriptContext, 2));
#if UE_GAME
	AAttachableCable * This = (AAttachableCable *)Obj;
	This->SetEnabled(Params.bEnabled);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetEnabled"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(bool*)(params.GetStructMemory() + 0) = Params.bEnabled;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.bEnabled = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetCableLength(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AttachableCable",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AttachableCable must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float Length;
	} Params;
	Params.Length = (float)(luaL_checknumber(InScriptContext, 2));
#if UE_GAME
	AAttachableCable * This = (AAttachableCable *)Obj;
	This->SetCableLength(Params.Length);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetCableLength"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(float*)(params.GetStructMemory() + 0) = Params.Length;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.Length = *(float*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetAttachEndTo(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AttachableCable",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AttachableCable must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		AActor* Actor = nullptr;
		FName ComponentProperty;
		FName SocketName;
	} Params;
	Params.Actor = (AActor*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"Actor");;
	Params.ComponentProperty = FName(UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 3)));
	Params.SocketName = FName(UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 4)));
#if UE_GAME
	AAttachableCable * This = (AAttachableCable *)Obj;
	This->SetAttachEndTo(Params.Actor,Params.ComponentProperty,Params.SocketName);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetAttachEndTo"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(AActor**)(params.GetStructMemory() + 0) = Params.Actor;
		*(FName*)(params.GetStructMemory() + 8) = Params.ComponentProperty;
		*(FName*)(params.GetStructMemory() + 20) = Params.SocketName;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.Actor = *(AActor**)(params.GetStructMemory() + 0);
		Params.ComponentProperty = *(FName*)(params.GetStructMemory() + 8);
		Params.SocketName = *(FName*)(params.GetStructMemory() + 20);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 Reset(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AttachableCable",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AttachableCable must be non-null"); lua_error(InScriptContext);  return 0;}
#if UE_GAME
	AAttachableCable * This = (AAttachableCable *)Obj;
	This->Reset();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("Reset"));
	if(!Function) { check(false); return 0;}
	Obj->ProcessEvent(Function, NULL);
#endif
	return 0;
}

int32 DetachEnd(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AttachableCable",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AttachableCable must be non-null"); lua_error(InScriptContext);  return 0;}
#if UE_GAME
	AAttachableCable * This = (AAttachableCable *)Obj;
	This->DetachEnd();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("DetachEnd"));
	if(!Function) { check(false); return 0;}
	Obj->ProcessEvent(Function, NULL);
#endif
	return 0;
}

int32 New(lua_State* InScriptContext)
{
	UObject* Outer = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Object");
	FName Name = FName(luaL_checkstring(InScriptContext, 2));
	UObject* Obj = NewObject<AAttachableCable>(Outer, Name);
	wLua::FLuaUtils::ReturnUObject(InScriptContext,Obj);
	return 1;
}

int32 Destroy(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AttachableCable",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AttachableCable must be non-null"); lua_error(InScriptContext);  return 0;}
		AActor * actor = Cast<AActor>(Obj);
		actor->Destroy();
		userdata->flag |= wLua::LuaObjectFlag::DESTROYED;
		wLua::FLuaUtils::RemoveObjectReference(Obj, userdata->stamp, InScriptContext);
#ifdef AZURE_BUILD_WLUACHECK
		UE_LOG(LogAzure, Warning, TEXT("Destroy AttachableCable: %x userdata:%x   stamp:%x"),Obj,userdata,userdata->stamp);
#endif
	return 0;
}

int32 Class(lua_State* InScriptContext)
{
	UClass* Class = AAttachableCable::StaticClass();
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Class);
	return 1;
}

const luaL_Reg Lib_Funcs[] =
{
	{ "New", New },
	{ "Destroy", Destroy },
	{ "Class", Class },
	{ "SetEndRelativeLocation", SetEndRelativeLocation },
	{ "SetEnabled", SetEnabled },
	{ "SetCableLength", SetCableLength },
	{ "SetAttachEndTo", SetAttachEndTo },
	{ "Reset", Reset },
	{ "DetachEnd", DetachEnd },
	{ "is_nil", wLua::LuaStatic::isnil },
	{ "__gc", wLua::LuaStatic::removeUClassFrameCache },
	{ NULL, NULL }
};

void Register(lua_State *InScriptContext)
{
	lua_newtable(InScriptContext);
	luaL_register(InScriptContext, NULL, Lib_Funcs);
	AzureHelpFuncs::AuxRegister(InScriptContext, "AttachableCable");
}
void SetMtLink(lua_State *InScriptContext)
{
	AzureHelpFuncs::AuxSetMtLink(InScriptContext, "AttachableCable", "Actor",USERDATATYPE_UOBJECT);
}

}