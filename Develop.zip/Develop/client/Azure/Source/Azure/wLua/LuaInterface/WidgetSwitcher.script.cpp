#include "Azure.h"
#include "Utility/help_funcs.h"
#include "wLua/UObjectHeaders.h"
#include "Components/WidgetSwitcher.h"
#include "WidgetSwitcher.h"
#include "AzureLuaIntegration.h"

namespace LuaWidgetSwitcher
{
int32 SetActiveWidgetIndex(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"WidgetSwitcher",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"WidgetSwitcher must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		int32 Index;
	} Params;
	Params.Index = (luaL_checkint(InScriptContext, 2));
#if UE_GAME
	UWidgetSwitcher * This = (UWidgetSwitcher *)Obj;
	This->SetActiveWidgetIndex(Params.Index);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetActiveWidgetIndex"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(int32*)(params.GetStructMemory() + 0) = Params.Index;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.Index = *(int32*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetActiveWidget(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"WidgetSwitcher",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"WidgetSwitcher must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		UWidget* Widget = nullptr;
	} Params;
	Params.Widget = (UWidget*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"Widget");;
#if UE_GAME
	UWidgetSwitcher * This = (UWidgetSwitcher *)Obj;
	This->SetActiveWidget(Params.Widget);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetActiveWidget"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(UWidget**)(params.GetStructMemory() + 0) = Params.Widget;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.Widget = *(UWidget**)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 GetWidgetAtIndex(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"WidgetSwitcher",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"WidgetSwitcher must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		int32 Index;
		UWidget* ReturnValue = nullptr;
	} Params;
	Params.Index = (luaL_checkint(InScriptContext, 2));
#if UE_GAME
	UWidgetSwitcher * This = (UWidgetSwitcher *)Obj;
	Params.ReturnValue = This->GetWidgetAtIndex(Params.Index);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetWidgetAtIndex"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(int32*)(params.GetStructMemory() + 0) = Params.Index;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.Index = *(int32*)(params.GetStructMemory() + 0);
		Params.ReturnValue = *(UWidget**)(params.GetStructMemory() + 8);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetNumWidgets(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"WidgetSwitcher",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"WidgetSwitcher must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		int32 ReturnValue;
	} Params;
#if UE_GAME
	UWidgetSwitcher * This = (UWidgetSwitcher *)Obj;
	Params.ReturnValue = This->GetNumWidgets();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetNumWidgets"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(int32*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushinteger(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetActiveWidgetIndex(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"WidgetSwitcher",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"WidgetSwitcher must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		int32 ReturnValue;
	} Params;
#if UE_GAME
	UWidgetSwitcher * This = (UWidgetSwitcher *)Obj;
	Params.ReturnValue = This->GetActiveWidgetIndex();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetActiveWidgetIndex"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(int32*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushinteger(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetActiveWidget(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"WidgetSwitcher",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"WidgetSwitcher must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		UWidget* ReturnValue = nullptr;
	} Params;
#if UE_GAME
	UWidgetSwitcher * This = (UWidgetSwitcher *)Obj;
	Params.ReturnValue = This->GetActiveWidget();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetActiveWidget"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(UWidget**)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 Get_ActiveWidgetIndex(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"WidgetSwitcher",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"WidgetSwitcher must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UWidgetSwitcher::StaticClass(), TEXT("ActiveWidgetIndex"));
	if(!Property) { check(false); return 0;}
	int32 PropertyValue = int32();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushinteger(InScriptContext, PropertyValue);
	return 1;
}

int32 New(lua_State* InScriptContext)
{
	UObject* Outer = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Object");
	FName Name = FName(luaL_checkstring(InScriptContext, 2));
	UObject* Obj = NewObject<UWidgetSwitcher>(Outer, Name);
	wLua::FLuaUtils::ReturnUObject(InScriptContext,Obj);
	return 1;
}

int32 Destroy(lua_State* InScriptContext)
{
	return 0;
}

int32 Class(lua_State* InScriptContext)
{
	UClass* Class = UWidgetSwitcher::StaticClass();
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Class);
	return 1;
}

const luaL_Reg Lib_Funcs[] =
{
	{ "New", New },
	{ "Destroy", Destroy },
	{ "Class", Class },
	{ "SetActiveWidgetIndex", SetActiveWidgetIndex },
	{ "SetActiveWidget", SetActiveWidget },
	{ "GetWidgetAtIndex", GetWidgetAtIndex },
	{ "GetNumWidgets", GetNumWidgets },
	{ "GetActiveWidgetIndex", GetActiveWidgetIndex },
	{ "GetActiveWidget", GetActiveWidget },
	{ "Get_ActiveWidgetIndex", Get_ActiveWidgetIndex },
	{ "is_nil", wLua::LuaStatic::isnil },
	{ "__gc", wLua::LuaStatic::removeUClassFrameCache },
	{ NULL, NULL }
};

void Register(lua_State *InScriptContext)
{
	lua_newtable(InScriptContext);
	luaL_register(InScriptContext, NULL, Lib_Funcs);
	AzureHelpFuncs::AuxRegister(InScriptContext, "WidgetSwitcher");
}
void SetMtLink(lua_State *InScriptContext)
{
	AzureHelpFuncs::AuxSetMtLink(InScriptContext, "WidgetSwitcher", "PanelWidget",USERDATATYPE_UOBJECT);
}

}