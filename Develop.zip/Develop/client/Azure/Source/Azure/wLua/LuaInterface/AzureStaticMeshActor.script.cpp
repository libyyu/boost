#include "Azure.h"
#include "Utility/help_funcs.h"
#include "wLua/UObjectHeaders.h"
#include "GameLogic/Home/AzureStaticMeshActor.h"
#include "AzureLuaIntegration.h"

namespace LuaAzureStaticMeshActor
{
int32 SetStaticMesh(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureStaticMeshActor",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureStaticMeshActor must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		UStaticMesh* NewMesh = nullptr;
		bool ReturnValue;
	} Params;
	Params.NewMesh = (UStaticMesh*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"StaticMesh");;
#if UE_GAME
	AAzureStaticMeshActor * This = (AAzureStaticMeshActor *)Obj;
	Params.ReturnValue = This->SetStaticMesh(Params.NewMesh);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetStaticMesh"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(UStaticMesh**)(params.GetStructMemory() + 0) = Params.NewMesh;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.NewMesh = *(UStaticMesh**)(params.GetStructMemory() + 0);
		Params.ReturnValue = *(bool*)(params.GetStructMemory() + 8);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushboolean(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 SetRelativeLocationAndRotationAndScale(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureStaticMeshActor",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureStaticMeshActor must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FVector NewLocation;
		FRotator NewRotation;
		FVector NewScale3D;
	} Params;
	Params.NewLocation = (wLua::FLuaVector::Get(InScriptContext, 2));
	Params.NewRotation = (wLua::FLuaRotator::Get(InScriptContext, 3));
	Params.NewScale3D = (wLua::FLuaVector::Get(InScriptContext, 4));
#if UE_GAME
	AAzureStaticMeshActor * This = (AAzureStaticMeshActor *)Obj;
	This->SetRelativeLocationAndRotationAndScale(Params.NewLocation,Params.NewRotation,Params.NewScale3D);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetRelativeLocationAndRotationAndScale"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FVector*)(params.GetStructMemory() + 0) = Params.NewLocation;
		*(FRotator*)(params.GetStructMemory() + 12) = Params.NewRotation;
		*(FVector*)(params.GetStructMemory() + 24) = Params.NewScale3D;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.NewLocation = *(FVector*)(params.GetStructMemory() + 0);
		Params.NewRotation = *(FRotator*)(params.GetStructMemory() + 12);
		Params.NewScale3D = *(FVector*)(params.GetStructMemory() + 24);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetMaterial(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureStaticMeshActor",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureStaticMeshActor must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		int32 idx;
		UMaterialInterface* Mat = nullptr;
	} Params;
	Params.idx = (luaL_checkint(InScriptContext, 2));
	Params.Mat = (UMaterialInterface*)wLua::FLuaUtils::GetUObject(InScriptContext,3,"MaterialInterface");;
#if UE_GAME
	AAzureStaticMeshActor * This = (AAzureStaticMeshActor *)Obj;
	This->SetMaterial(Params.idx,Params.Mat);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetMaterial"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(int32*)(params.GetStructMemory() + 0) = Params.idx;
		*(UMaterialInterface**)(params.GetStructMemory() + 8) = Params.Mat;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.idx = *(int32*)(params.GetStructMemory() + 0);
		Params.Mat = *(UMaterialInterface**)(params.GetStructMemory() + 8);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetCollisionProfileName(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureStaticMeshActor",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureStaticMeshActor must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FString ProfileName;
	} Params;
	Params.ProfileName = UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 2));
#if UE_GAME
	AAzureStaticMeshActor * This = (AAzureStaticMeshActor *)Obj;
	This->SetCollisionProfileName(Params.ProfileName);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetCollisionProfileName"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FString*)(params.GetStructMemory() + 0) = Params.ProfileName;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ProfileName = *(FString*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 GetStaticMeshComponent(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureStaticMeshActor",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureStaticMeshActor must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		UStaticMeshComponent* ReturnValue = nullptr;
	} Params;
#if UE_GAME
	AAzureStaticMeshActor * This = (AAzureStaticMeshActor *)Obj;
	Params.ReturnValue = This->GetStaticMeshComponent();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetStaticMeshComponent"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(UStaticMeshComponent**)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetStaticMesh(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureStaticMeshActor",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureStaticMeshActor must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		UStaticMesh* ReturnValue = nullptr;
	} Params;
#if UE_GAME
	AAzureStaticMeshActor * This = (AAzureStaticMeshActor *)Obj;
	Params.ReturnValue = This->GetStaticMesh();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetStaticMesh"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(UStaticMesh**)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetMaterialIndex(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureStaticMeshActor",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureStaticMeshActor must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FName MaterialSlot;
		int32 ReturnValue;
	} Params;
	Params.MaterialSlot = FName(UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 2)));
#if UE_GAME
	AAzureStaticMeshActor * This = (AAzureStaticMeshActor *)Obj;
	Params.ReturnValue = This->GetMaterialIndex(Params.MaterialSlot);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetMaterialIndex"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FName*)(params.GetStructMemory() + 0) = Params.MaterialSlot;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.MaterialSlot = *(FName*)(params.GetStructMemory() + 0);
		Params.ReturnValue = *(int32*)(params.GetStructMemory() + 12);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushinteger(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetMaterial(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureStaticMeshActor",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureStaticMeshActor must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		int32 idx;
		UMaterialInterface* MaterialWall = nullptr;
		UMaterialInterface* ReturnValue = nullptr;
	} Params;
	Params.idx = (luaL_checkint(InScriptContext, 2));
	Params.MaterialWall = (UMaterialInterface*)wLua::FLuaUtils::GetUObject(InScriptContext,3,"MaterialInterface");;
#if UE_GAME
	AAzureStaticMeshActor * This = (AAzureStaticMeshActor *)Obj;
	Params.ReturnValue = This->GetMaterial(Params.idx,Params.MaterialWall);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetMaterial"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(int32*)(params.GetStructMemory() + 0) = Params.idx;
		*(UMaterialInterface**)(params.GetStructMemory() + 8) = Params.MaterialWall;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.idx = *(int32*)(params.GetStructMemory() + 0);
		Params.MaterialWall = *(UMaterialInterface**)(params.GetStructMemory() + 8);
		Params.ReturnValue = *(UMaterialInterface**)(params.GetStructMemory() + 16);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 New(lua_State* InScriptContext)
{
	UObject* Outer = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Object");
	FName Name = FName(luaL_checkstring(InScriptContext, 2));
	UObject* Obj = NewObject<AAzureStaticMeshActor>(Outer, Name);
	wLua::FLuaUtils::ReturnUObject(InScriptContext,Obj);
	return 1;
}

int32 Destroy(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureStaticMeshActor",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureStaticMeshActor must be non-null"); lua_error(InScriptContext);  return 0;}
		AActor * actor = Cast<AActor>(Obj);
		actor->Destroy();
		userdata->flag |= wLua::LuaObjectFlag::DESTROYED;
		wLua::FLuaUtils::RemoveObjectReference(Obj, userdata->stamp, InScriptContext);
#ifdef AZURE_BUILD_WLUACHECK
		UE_LOG(LogAzure, Warning, TEXT("Destroy AzureStaticMeshActor: %x userdata:%x   stamp:%x"),Obj,userdata,userdata->stamp);
#endif
	return 0;
}

int32 Class(lua_State* InScriptContext)
{
	UClass* Class = AAzureStaticMeshActor::StaticClass();
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Class);
	return 1;
}

const luaL_Reg Lib_Funcs[] =
{
	{ "New", New },
	{ "Destroy", Destroy },
	{ "Class", Class },
	{ "SetStaticMesh", SetStaticMesh },
	{ "SetRelativeLocationAndRotationAndScale", SetRelativeLocationAndRotationAndScale },
	{ "SetMaterial", SetMaterial },
	{ "SetCollisionProfileName", SetCollisionProfileName },
	{ "GetStaticMeshComponent", GetStaticMeshComponent },
	{ "GetStaticMesh", GetStaticMesh },
	{ "GetMaterialIndex", GetMaterialIndex },
	{ "GetMaterial", GetMaterial },
	{ "is_nil", wLua::LuaStatic::isnil },
	{ "__gc", wLua::LuaStatic::removeUClassFrameCache },
	{ NULL, NULL }
};

void Register(lua_State *InScriptContext)
{
	lua_newtable(InScriptContext);
	luaL_register(InScriptContext, NULL, Lib_Funcs);
	AzureHelpFuncs::AuxRegister(InScriptContext, "AzureStaticMeshActor");
}
void SetMtLink(lua_State *InScriptContext)
{
	AzureHelpFuncs::AuxSetMtLink(InScriptContext, "AzureStaticMeshActor", "Actor",USERDATATYPE_UOBJECT);
}

}