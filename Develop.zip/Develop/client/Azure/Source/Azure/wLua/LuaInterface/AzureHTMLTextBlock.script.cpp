#include "Azure.h"
#include "Utility/help_funcs.h"
#include "wLua/UObjectHeaders.h"
#include "AzureHTMLTextBlock.h"
#include "AzureLuaIntegration.h"

namespace LuaAzureHTMLTextBlock
{
int32 SetColorAndOpacity(lua_State*);

int32 SetText(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureHTMLTextBlock",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureHTMLTextBlock must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FString InText;
	} Params;
	Params.InText = UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 2));
#if UE_GAME
	UAzureHTMLTextBlock * This = (UAzureHTMLTextBlock *)Obj;
	This->SetText(Params.InText);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetText"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FString*)(params.GetStructMemory() + 0) = Params.InText;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.InText = *(FString*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetOpacity(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureHTMLTextBlock",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureHTMLTextBlock must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float InOpacity;
	} Params;
	Params.InOpacity = (float)(luaL_checknumber(InScriptContext, 2));
#if UE_GAME
	UAzureHTMLTextBlock * This = (UAzureHTMLTextBlock *)Obj;
	This->SetOpacity(Params.InOpacity);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetOpacity"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(float*)(params.GetStructMemory() + 0) = Params.InOpacity;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.InOpacity = *(float*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetJustification(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureHTMLTextBlock",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureHTMLTextBlock must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		TEnumAsByte<ETextJustify::Type> InJustification;
	} Params;
	Params.InJustification = (TEnumAsByte<ETextJustify::Type>)(luaL_checkint(InScriptContext, 2));
#if UE_GAME
	UAzureHTMLTextBlock * This = (UAzureHTMLTextBlock *)Obj;
	This->SetJustification(Params.InJustification);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetJustification"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(TEnumAsByte<ETextJustify::Type>*)(params.GetStructMemory() + 0) = Params.InJustification;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.InJustification = *(TEnumAsByte<ETextJustify::Type>*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetCurPageIdx(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureHTMLTextBlock",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureHTMLTextBlock must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		int32 pageIdx;
	} Params;
	Params.pageIdx = (luaL_checkint(InScriptContext, 2));
#if UE_GAME
	UAzureHTMLTextBlock * This = (UAzureHTMLTextBlock *)Obj;
	This->SetCurPageIdx(Params.pageIdx);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetCurPageIdx"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(int32*)(params.GetStructMemory() + 0) = Params.pageIdx;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.pageIdx = *(int32*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 GetTextSize(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureHTMLTextBlock",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureHTMLTextBlock must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FVector2D ReturnValue;
	} Params;
#if UE_GAME
	UAzureHTMLTextBlock * This = (UAzureHTMLTextBlock *)Obj;
	Params.ReturnValue = This->GetTextSize();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetTextSize"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(FVector2D*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaVector2D::Return(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetTextLineCount(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureHTMLTextBlock",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureHTMLTextBlock must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		int32 ReturnValue;
	} Params;
#if UE_GAME
	UAzureHTMLTextBlock * This = (UAzureHTMLTextBlock *)Obj;
	Params.ReturnValue = This->GetTextLineCount();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetTextLineCount"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(int32*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushinteger(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetTextDrawSize(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureHTMLTextBlock",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureHTMLTextBlock must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FVector2D ReturnValue;
	} Params;
#if UE_GAME
	UAzureHTMLTextBlock * This = (UAzureHTMLTextBlock *)Obj;
	Params.ReturnValue = This->GetTextDrawSize();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetTextDrawSize"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(FVector2D*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaVector2D::Return(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetPageCount(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureHTMLTextBlock",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureHTMLTextBlock must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		int32 ReturnValue;
	} Params;
#if UE_GAME
	UAzureHTMLTextBlock * This = (UAzureHTMLTextBlock *)Obj;
	Params.ReturnValue = This->GetPageCount();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetPageCount"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(int32*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushinteger(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 Clear(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureHTMLTextBlock",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureHTMLTextBlock must be non-null"); lua_error(InScriptContext);  return 0;}
#if UE_GAME
	UAzureHTMLTextBlock * This = (UAzureHTMLTextBlock *)Obj;
	This->Clear();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("Clear"));
	if(!Function) { check(false); return 0;}
	Obj->ProcessEvent(Function, NULL);
#endif
	return 0;
}

int32 AppendText(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureHTMLTextBlock",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureHTMLTextBlock must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FString InText;
	} Params;
	Params.InText = UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 2));
#if UE_GAME
	UAzureHTMLTextBlock * This = (UAzureHTMLTextBlock *)Obj;
	This->AppendText(Params.InText);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("AppendText"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FString*)(params.GetStructMemory() + 0) = Params.InText;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.InText = *(FString*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 Get_Text(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureHTMLTextBlock",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureHTMLTextBlock must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzureHTMLTextBlock::StaticClass(), TEXT("Text"));
	if(!Property) { check(false); return 0;}
	FText PropertyValue;
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushstring(InScriptContext, TCHAR_TO_UTF8(*PropertyValue.ToString()));
	return 1;
}

int32 Get_bAutoWrapTextHeight(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureHTMLTextBlock",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureHTMLTextBlock must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzureHTMLTextBlock::StaticClass(), TEXT("bAutoWrapTextHeight"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = bool();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_WrapTextHeightAt(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureHTMLTextBlock",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureHTMLTextBlock must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzureHTMLTextBlock::StaticClass(), TEXT("WrapTextHeightAt"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_UseNoPixelSnapping(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureHTMLTextBlock",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureHTMLTextBlock must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzureHTMLTextBlock::StaticClass(), TEXT("UseNoPixelSnapping"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = bool();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_UseNoPixelSnapping(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureHTMLTextBlock",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureHTMLTextBlock must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzureHTMLTextBlock::StaticClass(), TEXT("UseNoPixelSnapping"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_ClickRadius(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureHTMLTextBlock",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureHTMLTextBlock must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzureHTMLTextBlock::StaticClass(), TEXT("ClickRadius"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_ClickRadius(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureHTMLTextBlock",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureHTMLTextBlock must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzureHTMLTextBlock::StaticClass(), TEXT("ClickRadius"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_UsePerPixelHittest(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureHTMLTextBlock",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureHTMLTextBlock must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzureHTMLTextBlock::StaticClass(), TEXT("UsePerPixelHittest"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = bool();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_UsePerPixelHittest(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureHTMLTextBlock",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureHTMLTextBlock must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzureHTMLTextBlock::StaticClass(), TEXT("UsePerPixelHittest"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bHeightToContent(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureHTMLTextBlock",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureHTMLTextBlock must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzureHTMLTextBlock::StaticClass(), TEXT("bHeightToContent"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = bool();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_Opacity(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureHTMLTextBlock",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureHTMLTextBlock must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzureHTMLTextBlock::StaticClass(), TEXT("Opacity"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_bClickEnabled(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureHTMLTextBlock",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureHTMLTextBlock must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzureHTMLTextBlock::StaticClass(), TEXT("bClickEnabled"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = bool();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_UseLegacyBreak(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureHTMLTextBlock",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureHTMLTextBlock must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzureHTMLTextBlock::StaticClass(), TEXT("UseLegacyBreak"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = bool();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_bLongPress(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureHTMLTextBlock",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureHTMLTextBlock must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzureHTMLTextBlock::StaticClass(), TEXT("bLongPress"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = bool();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_LongPressTime(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureHTMLTextBlock",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureHTMLTextBlock must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzureHTMLTextBlock::StaticClass(), TEXT("LongPressTime"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_LongPressTime(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureHTMLTextBlock",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureHTMLTextBlock must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzureHTMLTextBlock::StaticClass(), TEXT("LongPressTime"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 New(lua_State* InScriptContext)
{
	UObject* Outer = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Object");
	FName Name = FName(luaL_checkstring(InScriptContext, 2));
	UObject* Obj = NewObject<UAzureHTMLTextBlock>(Outer, Name);
	wLua::FLuaUtils::ReturnUObject(InScriptContext,Obj);
	return 1;
}

int32 Destroy(lua_State* InScriptContext)
{
	return 0;
}

int32 Class(lua_State* InScriptContext)
{
	UClass* Class = UAzureHTMLTextBlock::StaticClass();
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Class);
	return 1;
}

const luaL_Reg Lib_Funcs[] =
{
	{ "New", New },
	{ "Destroy", Destroy },
	{ "Class", Class },
	{ "SetText", SetText },
	{ "SetOpacity", SetOpacity },
	{ "SetJustification", SetJustification },
	{ "SetCurPageIdx", SetCurPageIdx },
	{ "GetTextSize", GetTextSize },
	{ "GetTextLineCount", GetTextLineCount },
	{ "GetTextDrawSize", GetTextDrawSize },
	{ "GetPageCount", GetPageCount },
	{ "Clear", Clear },
	{ "AppendText", AppendText },
	{ "Get_Text", Get_Text },
	{ "Get_bAutoWrapTextHeight", Get_bAutoWrapTextHeight },
	{ "Get_WrapTextHeightAt", Get_WrapTextHeightAt },
	{ "Get_UseNoPixelSnapping", Get_UseNoPixelSnapping },
	{ "Set_UseNoPixelSnapping", Set_UseNoPixelSnapping },
	{ "Get_ClickRadius", Get_ClickRadius },
	{ "Set_ClickRadius", Set_ClickRadius },
	{ "Get_UsePerPixelHittest", Get_UsePerPixelHittest },
	{ "Set_UsePerPixelHittest", Set_UsePerPixelHittest },
	{ "Get_bHeightToContent", Get_bHeightToContent },
	{ "Get_Opacity", Get_Opacity },
	{ "Get_bClickEnabled", Get_bClickEnabled },
	{ "Get_UseLegacyBreak", Get_UseLegacyBreak },
	{ "Get_bLongPress", Get_bLongPress },
	{ "Get_LongPressTime", Get_LongPressTime },
	{ "Set_LongPressTime", Set_LongPressTime },
	{ "SetColorAndOpacity", SetColorAndOpacity },
	{ "is_nil", wLua::LuaStatic::isnil },
	{ "__gc", wLua::LuaStatic::removeUClassFrameCache },
	{ NULL, NULL }
};

void Register(lua_State *InScriptContext)
{
	lua_newtable(InScriptContext);
	luaL_register(InScriptContext, NULL, Lib_Funcs);
	AzureHelpFuncs::AuxRegister(InScriptContext, "AzureHTMLTextBlock");
}
void SetMtLink(lua_State *InScriptContext)
{
	AzureHelpFuncs::AuxSetMtLink(InScriptContext, "AzureHTMLTextBlock", "TextLayoutWidget",USERDATATYPE_UOBJECT);
}

}