#include "Azure.h"
#include "Utility/help_funcs.h"
#include "wLua/UObjectHeaders.h"
#include "Components/GridPanel.h"
#include "Components/GridSlot.h"
#include "AzureLuaIntegration.h"

namespace LuaGridPanel
{
int32 SetRowFill(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"GridPanel",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"GridPanel must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		int32 ColumnIndex;
		float Coefficient;
	} Params;
	Params.ColumnIndex = (luaL_checkint(InScriptContext, 2));
	Params.Coefficient = (float)(luaL_checknumber(InScriptContext, 3));
#if UE_GAME
	UGridPanel * This = (UGridPanel *)Obj;
	This->SetRowFill(Params.ColumnIndex,Params.Coefficient);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetRowFill"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(int32*)(params.GetStructMemory() + 0) = Params.ColumnIndex;
		*(float*)(params.GetStructMemory() + 4) = Params.Coefficient;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ColumnIndex = *(int32*)(params.GetStructMemory() + 0);
		Params.Coefficient = *(float*)(params.GetStructMemory() + 4);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetColumnFill(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"GridPanel",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"GridPanel must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		int32 ColumnIndex;
		float Coefficient;
	} Params;
	Params.ColumnIndex = (luaL_checkint(InScriptContext, 2));
	Params.Coefficient = (float)(luaL_checknumber(InScriptContext, 3));
#if UE_GAME
	UGridPanel * This = (UGridPanel *)Obj;
	This->SetColumnFill(Params.ColumnIndex,Params.Coefficient);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetColumnFill"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(int32*)(params.GetStructMemory() + 0) = Params.ColumnIndex;
		*(float*)(params.GetStructMemory() + 4) = Params.Coefficient;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ColumnIndex = *(int32*)(params.GetStructMemory() + 0);
		Params.Coefficient = *(float*)(params.GetStructMemory() + 4);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 AddChildToGrid(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"GridPanel",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"GridPanel must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		UWidget* Content = nullptr;
		UGridSlot* ReturnValue = nullptr;
	} Params;
	Params.Content = (UWidget*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"Widget");;
#if UE_GAME
	UGridPanel * This = (UGridPanel *)Obj;
	Params.ReturnValue = This->AddChildToGrid(Params.Content);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("AddChildToGrid"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(UWidget**)(params.GetStructMemory() + 0) = Params.Content;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.Content = *(UWidget**)(params.GetStructMemory() + 0);
		Params.ReturnValue = *(UGridSlot**)(params.GetStructMemory() + 8);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 Get_ColumnFill(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"GridPanel",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"GridPanel must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UGridPanel::StaticClass(), TEXT("ColumnFill"));
	if(!Property) { check(false); return 0;}
	TArray<float> PropertyValue;
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	{lua_newtable(InScriptContext); int i = 1; for(auto It = PropertyValue.CreateConstIterator(); It; ++It,++i) {  lua_pushnumber(InScriptContext, (*It)); lua_rawseti(InScriptContext,-2,i);     }  }
	return 1;
}

int32 Get_RowFill(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"GridPanel",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"GridPanel must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UGridPanel::StaticClass(), TEXT("RowFill"));
	if(!Property) { check(false); return 0;}
	TArray<float> PropertyValue;
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	{lua_newtable(InScriptContext); int i = 1; for(auto It = PropertyValue.CreateConstIterator(); It; ++It,++i) {  lua_pushnumber(InScriptContext, (*It)); lua_rawseti(InScriptContext,-2,i);     }  }
	return 1;
}

int32 New(lua_State* InScriptContext)
{
	UObject* Outer = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Object");
	FName Name = FName(luaL_checkstring(InScriptContext, 2));
	UObject* Obj = NewObject<UGridPanel>(Outer, Name);
	wLua::FLuaUtils::ReturnUObject(InScriptContext,Obj);
	return 1;
}

int32 Destroy(lua_State* InScriptContext)
{
	return 0;
}

int32 Class(lua_State* InScriptContext)
{
	UClass* Class = UGridPanel::StaticClass();
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Class);
	return 1;
}

const luaL_Reg Lib_Funcs[] =
{
	{ "New", New },
	{ "Destroy", Destroy },
	{ "Class", Class },
	{ "SetRowFill", SetRowFill },
	{ "SetColumnFill", SetColumnFill },
	{ "AddChildToGrid", AddChildToGrid },
	{ "Get_ColumnFill", Get_ColumnFill },
	{ "Get_RowFill", Get_RowFill },
	{ "is_nil", wLua::LuaStatic::isnil },
	{ "__gc", wLua::LuaStatic::removeUClassFrameCache },
	{ NULL, NULL }
};

void Register(lua_State *InScriptContext)
{
	lua_newtable(InScriptContext);
	luaL_register(InScriptContext, NULL, Lib_Funcs);
	AzureHelpFuncs::AuxRegister(InScriptContext, "GridPanel");
}
void SetMtLink(lua_State *InScriptContext)
{
	AzureHelpFuncs::AuxSetMtLink(InScriptContext, "GridPanel", "PanelWidget",USERDATATYPE_UOBJECT);
}

}