#include "Azure.h"
#include "Utility/help_funcs.h"
#include "wLua/UObjectHeaders.h"
#include "AzureRadioBox.h"
#include "AzureLuaIntegration.h"

namespace LuaAzureRadioBox
{
int32 setStateChangedFunc(lua_State*);

int32 SetGroup(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureRadioBox",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureRadioBox must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		int32 g;
	} Params;
	Params.g = (luaL_checkint(InScriptContext, 2));
#if UE_GAME
	UAzureRadioBox * This = (UAzureRadioBox *)Obj;
	This->SetGroup(Params.g);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetGroup"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(int32*)(params.GetStructMemory() + 0) = Params.g;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.g = *(int32*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetChecked(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureRadioBox",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureRadioBox must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool Checked;
	} Params;
	Params.Checked = !!(lua_toboolean(InScriptContext, 2));
#if UE_GAME
	UAzureRadioBox * This = (UAzureRadioBox *)Obj;
	This->SetChecked(Params.Checked);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetChecked"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(bool*)(params.GetStructMemory() + 0) = Params.Checked;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.Checked = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetAllowUnchecked(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureRadioBox",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureRadioBox must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool bAllow;
	} Params;
	Params.bAllow = !!(lua_toboolean(InScriptContext, 2));
#if UE_GAME
	UAzureRadioBox * This = (UAzureRadioBox *)Obj;
	This->SetAllowUnchecked(Params.bAllow);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetAllowUnchecked"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(bool*)(params.GetStructMemory() + 0) = Params.bAllow;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.bAllow = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 GetRadioBoxChecked(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureRadioBox",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureRadioBox must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		UAzureRadioBox* ReturnValue = nullptr;
	} Params;
#if UE_GAME
	UAzureRadioBox * This = (UAzureRadioBox *)Obj;
	Params.ReturnValue = This->GetRadioBoxChecked();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetRadioBoxChecked"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(UAzureRadioBox**)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetChecked(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureRadioBox",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureRadioBox must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool ReturnValue;
	} Params;
#if UE_GAME
	UAzureRadioBox * This = (UAzureRadioBox *)Obj;
	Params.ReturnValue = This->GetChecked();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetChecked"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushboolean(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 ClearScaleState(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureRadioBox",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureRadioBox must be non-null"); lua_error(InScriptContext);  return 0;}
#if UE_GAME
	UAzureRadioBox * This = (UAzureRadioBox *)Obj;
	This->ClearScaleState();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("ClearScaleState"));
	if(!Function) { check(false); return 0;}
	Obj->ProcessEvent(Function, NULL);
#endif
	return 0;
}

int32 Get_Group(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureRadioBox",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureRadioBox must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzureRadioBox::StaticClass(), TEXT("Group"));
	if(!Property) { check(false); return 0;}
	int32 PropertyValue = int32();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushinteger(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_bForceTopmost(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureRadioBox",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureRadioBox must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzureRadioBox::StaticClass(), TEXT("bForceTopmost"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = bool();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_AllowUnchecked(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureRadioBox",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureRadioBox must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzureRadioBox::StaticClass(), TEXT("AllowUnchecked"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = bool();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_AllowUnchecked(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureRadioBox",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureRadioBox must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzureRadioBox::StaticClass(), TEXT("AllowUnchecked"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bTabView(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureRadioBox",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureRadioBox must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzureRadioBox::StaticClass(), TEXT("bTabView"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = bool();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_ViewIndex(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureRadioBox",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureRadioBox must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzureRadioBox::StaticClass(), TEXT("ViewIndex"));
	if(!Property) { check(false); return 0;}
	int32 PropertyValue = int32();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushinteger(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_bPreciseClick(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureRadioBox",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureRadioBox must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzureRadioBox::StaticClass(), TEXT("bPreciseClick"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = bool();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 New(lua_State* InScriptContext)
{
	UObject* Outer = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Object");
	FName Name = FName(luaL_checkstring(InScriptContext, 2));
	UObject* Obj = NewObject<UAzureRadioBox>(Outer, Name);
	wLua::FLuaUtils::ReturnUObject(InScriptContext,Obj);
	return 1;
}

int32 Destroy(lua_State* InScriptContext)
{
	return 0;
}

int32 Class(lua_State* InScriptContext)
{
	UClass* Class = UAzureRadioBox::StaticClass();
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Class);
	return 1;
}

const luaL_Reg Lib_Funcs[] =
{
	{ "New", New },
	{ "Destroy", Destroy },
	{ "Class", Class },
	{ "SetGroup", SetGroup },
	{ "SetChecked", SetChecked },
	{ "SetAllowUnchecked", SetAllowUnchecked },
	{ "GetRadioBoxChecked", GetRadioBoxChecked },
	{ "GetChecked", GetChecked },
	{ "ClearScaleState", ClearScaleState },
	{ "Get_Group", Get_Group },
	{ "Get_bForceTopmost", Get_bForceTopmost },
	{ "Get_AllowUnchecked", Get_AllowUnchecked },
	{ "Set_AllowUnchecked", Set_AllowUnchecked },
	{ "Get_bTabView", Get_bTabView },
	{ "Get_ViewIndex", Get_ViewIndex },
	{ "Get_bPreciseClick", Get_bPreciseClick },
	{ "setStateChangedFunc", setStateChangedFunc },
	{ "is_nil", wLua::LuaStatic::isnil },
	{ "__gc", wLua::LuaStatic::removeUClassFrameCache },
	{ NULL, NULL }
};

void Register(lua_State *InScriptContext)
{
	lua_newtable(InScriptContext);
	luaL_register(InScriptContext, NULL, Lib_Funcs);
	AzureHelpFuncs::AuxRegister(InScriptContext, "AzureRadioBox");
}
void SetMtLink(lua_State *InScriptContext)
{
	AzureHelpFuncs::AuxSetMtLink(InScriptContext, "AzureRadioBox", "CheckBox",USERDATATYPE_UOBJECT);
}

}