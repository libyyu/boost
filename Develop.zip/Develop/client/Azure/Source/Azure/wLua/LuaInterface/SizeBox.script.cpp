#include "Azure.h"
#include "Utility/help_funcs.h"
#include "wLua/UObjectHeaders.h"
#include "Components/SizeBox.h"
#include "AzureLuaIntegration.h"

namespace LuaSizeBox
{
int32 SetWidthOverride(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SizeBox",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SizeBox must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float InWidthOverride;
	} Params;
	Params.InWidthOverride = (float)(luaL_checknumber(InScriptContext, 2));
#if UE_GAME
	USizeBox * This = (USizeBox *)Obj;
	This->SetWidthOverride(Params.InWidthOverride);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetWidthOverride"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(float*)(params.GetStructMemory() + 0) = Params.InWidthOverride;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.InWidthOverride = *(float*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetMinDesiredWidth(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SizeBox",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SizeBox must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float InMinDesiredWidth;
	} Params;
	Params.InMinDesiredWidth = (float)(luaL_checknumber(InScriptContext, 2));
#if UE_GAME
	USizeBox * This = (USizeBox *)Obj;
	This->SetMinDesiredWidth(Params.InMinDesiredWidth);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetMinDesiredWidth"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(float*)(params.GetStructMemory() + 0) = Params.InMinDesiredWidth;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.InMinDesiredWidth = *(float*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetMinDesiredHeight(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SizeBox",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SizeBox must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float InMinDesiredHeight;
	} Params;
	Params.InMinDesiredHeight = (float)(luaL_checknumber(InScriptContext, 2));
#if UE_GAME
	USizeBox * This = (USizeBox *)Obj;
	This->SetMinDesiredHeight(Params.InMinDesiredHeight);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetMinDesiredHeight"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(float*)(params.GetStructMemory() + 0) = Params.InMinDesiredHeight;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.InMinDesiredHeight = *(float*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetMaxDesiredWidth(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SizeBox",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SizeBox must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float InMaxDesiredWidth;
	} Params;
	Params.InMaxDesiredWidth = (float)(luaL_checknumber(InScriptContext, 2));
#if UE_GAME
	USizeBox * This = (USizeBox *)Obj;
	This->SetMaxDesiredWidth(Params.InMaxDesiredWidth);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetMaxDesiredWidth"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(float*)(params.GetStructMemory() + 0) = Params.InMaxDesiredWidth;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.InMaxDesiredWidth = *(float*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetMaxDesiredHeight(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SizeBox",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SizeBox must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float InMaxDesiredHeight;
	} Params;
	Params.InMaxDesiredHeight = (float)(luaL_checknumber(InScriptContext, 2));
#if UE_GAME
	USizeBox * This = (USizeBox *)Obj;
	This->SetMaxDesiredHeight(Params.InMaxDesiredHeight);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetMaxDesiredHeight"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(float*)(params.GetStructMemory() + 0) = Params.InMaxDesiredHeight;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.InMaxDesiredHeight = *(float*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetMaxAspectRatio(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SizeBox",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SizeBox must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float InMaxAspectRatio;
	} Params;
	Params.InMaxAspectRatio = (float)(luaL_checknumber(InScriptContext, 2));
#if UE_GAME
	USizeBox * This = (USizeBox *)Obj;
	This->SetMaxAspectRatio(Params.InMaxAspectRatio);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetMaxAspectRatio"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(float*)(params.GetStructMemory() + 0) = Params.InMaxAspectRatio;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.InMaxAspectRatio = *(float*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetHeightOverride(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SizeBox",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SizeBox must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float InHeightOverride;
	} Params;
	Params.InHeightOverride = (float)(luaL_checknumber(InScriptContext, 2));
#if UE_GAME
	USizeBox * This = (USizeBox *)Obj;
	This->SetHeightOverride(Params.InHeightOverride);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetHeightOverride"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(float*)(params.GetStructMemory() + 0) = Params.InHeightOverride;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.InHeightOverride = *(float*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 ClearWidthOverride(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SizeBox",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SizeBox must be non-null"); lua_error(InScriptContext);  return 0;}
#if UE_GAME
	USizeBox * This = (USizeBox *)Obj;
	This->ClearWidthOverride();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("ClearWidthOverride"));
	if(!Function) { check(false); return 0;}
	Obj->ProcessEvent(Function, NULL);
#endif
	return 0;
}

int32 ClearMinDesiredWidth(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SizeBox",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SizeBox must be non-null"); lua_error(InScriptContext);  return 0;}
#if UE_GAME
	USizeBox * This = (USizeBox *)Obj;
	This->ClearMinDesiredWidth();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("ClearMinDesiredWidth"));
	if(!Function) { check(false); return 0;}
	Obj->ProcessEvent(Function, NULL);
#endif
	return 0;
}

int32 ClearMinDesiredHeight(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SizeBox",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SizeBox must be non-null"); lua_error(InScriptContext);  return 0;}
#if UE_GAME
	USizeBox * This = (USizeBox *)Obj;
	This->ClearMinDesiredHeight();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("ClearMinDesiredHeight"));
	if(!Function) { check(false); return 0;}
	Obj->ProcessEvent(Function, NULL);
#endif
	return 0;
}

int32 ClearMaxDesiredWidth(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SizeBox",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SizeBox must be non-null"); lua_error(InScriptContext);  return 0;}
#if UE_GAME
	USizeBox * This = (USizeBox *)Obj;
	This->ClearMaxDesiredWidth();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("ClearMaxDesiredWidth"));
	if(!Function) { check(false); return 0;}
	Obj->ProcessEvent(Function, NULL);
#endif
	return 0;
}

int32 ClearMaxDesiredHeight(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SizeBox",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SizeBox must be non-null"); lua_error(InScriptContext);  return 0;}
#if UE_GAME
	USizeBox * This = (USizeBox *)Obj;
	This->ClearMaxDesiredHeight();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("ClearMaxDesiredHeight"));
	if(!Function) { check(false); return 0;}
	Obj->ProcessEvent(Function, NULL);
#endif
	return 0;
}

int32 ClearMaxAspectRatio(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SizeBox",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SizeBox must be non-null"); lua_error(InScriptContext);  return 0;}
#if UE_GAME
	USizeBox * This = (USizeBox *)Obj;
	This->ClearMaxAspectRatio();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("ClearMaxAspectRatio"));
	if(!Function) { check(false); return 0;}
	Obj->ProcessEvent(Function, NULL);
#endif
	return 0;
}

int32 ClearHeightOverride(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SizeBox",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SizeBox must be non-null"); lua_error(InScriptContext);  return 0;}
#if UE_GAME
	USizeBox * This = (USizeBox *)Obj;
	This->ClearHeightOverride();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("ClearHeightOverride"));
	if(!Function) { check(false); return 0;}
	Obj->ProcessEvent(Function, NULL);
#endif
	return 0;
}

int32 Get_bOverride_WidthOverride(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SizeBox",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SizeBox must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USizeBox::StaticClass(), TEXT("bOverride_WidthOverride"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bOverride_WidthOverride(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SizeBox",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SizeBox must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USizeBox::StaticClass(), TEXT("bOverride_WidthOverride"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bOverride_HeightOverride(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SizeBox",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SizeBox must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USizeBox::StaticClass(), TEXT("bOverride_HeightOverride"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bOverride_HeightOverride(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SizeBox",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SizeBox must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USizeBox::StaticClass(), TEXT("bOverride_HeightOverride"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bOverride_MinDesiredWidth(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SizeBox",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SizeBox must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USizeBox::StaticClass(), TEXT("bOverride_MinDesiredWidth"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bOverride_MinDesiredWidth(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SizeBox",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SizeBox must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USizeBox::StaticClass(), TEXT("bOverride_MinDesiredWidth"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bOverride_MinDesiredHeight(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SizeBox",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SizeBox must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USizeBox::StaticClass(), TEXT("bOverride_MinDesiredHeight"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bOverride_MinDesiredHeight(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SizeBox",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SizeBox must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USizeBox::StaticClass(), TEXT("bOverride_MinDesiredHeight"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bOverride_MaxDesiredWidth(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SizeBox",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SizeBox must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USizeBox::StaticClass(), TEXT("bOverride_MaxDesiredWidth"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bOverride_MaxDesiredWidth(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SizeBox",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SizeBox must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USizeBox::StaticClass(), TEXT("bOverride_MaxDesiredWidth"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bOverride_MaxDesiredHeight(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SizeBox",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SizeBox must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USizeBox::StaticClass(), TEXT("bOverride_MaxDesiredHeight"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bOverride_MaxDesiredHeight(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SizeBox",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SizeBox must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USizeBox::StaticClass(), TEXT("bOverride_MaxDesiredHeight"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bOverride_MaxAspectRatio(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SizeBox",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SizeBox must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USizeBox::StaticClass(), TEXT("bOverride_MaxAspectRatio"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bOverride_MaxAspectRatio(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SizeBox",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SizeBox must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USizeBox::StaticClass(), TEXT("bOverride_MaxAspectRatio"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_WidthOverride(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SizeBox",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SizeBox must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USizeBox::StaticClass(), TEXT("WidthOverride"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_HeightOverride(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SizeBox",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SizeBox must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USizeBox::StaticClass(), TEXT("HeightOverride"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_MinDesiredWidth(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SizeBox",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SizeBox must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USizeBox::StaticClass(), TEXT("MinDesiredWidth"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_MinDesiredHeight(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SizeBox",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SizeBox must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USizeBox::StaticClass(), TEXT("MinDesiredHeight"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_MaxDesiredWidth(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SizeBox",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SizeBox must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USizeBox::StaticClass(), TEXT("MaxDesiredWidth"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_MaxDesiredHeight(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SizeBox",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SizeBox must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USizeBox::StaticClass(), TEXT("MaxDesiredHeight"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_MaxAspectRatio(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"SizeBox",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"SizeBox must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(USizeBox::StaticClass(), TEXT("MaxAspectRatio"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 New(lua_State* InScriptContext)
{
	UObject* Outer = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Object");
	FName Name = FName(luaL_checkstring(InScriptContext, 2));
	UObject* Obj = NewObject<USizeBox>(Outer, Name);
	wLua::FLuaUtils::ReturnUObject(InScriptContext,Obj);
	return 1;
}

int32 Destroy(lua_State* InScriptContext)
{
	return 0;
}

int32 Class(lua_State* InScriptContext)
{
	UClass* Class = USizeBox::StaticClass();
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Class);
	return 1;
}

const luaL_Reg Lib_Funcs[] =
{
	{ "New", New },
	{ "Destroy", Destroy },
	{ "Class", Class },
	{ "SetWidthOverride", SetWidthOverride },
	{ "SetMinDesiredWidth", SetMinDesiredWidth },
	{ "SetMinDesiredHeight", SetMinDesiredHeight },
	{ "SetMaxDesiredWidth", SetMaxDesiredWidth },
	{ "SetMaxDesiredHeight", SetMaxDesiredHeight },
	{ "SetMaxAspectRatio", SetMaxAspectRatio },
	{ "SetHeightOverride", SetHeightOverride },
	{ "ClearWidthOverride", ClearWidthOverride },
	{ "ClearMinDesiredWidth", ClearMinDesiredWidth },
	{ "ClearMinDesiredHeight", ClearMinDesiredHeight },
	{ "ClearMaxDesiredWidth", ClearMaxDesiredWidth },
	{ "ClearMaxDesiredHeight", ClearMaxDesiredHeight },
	{ "ClearMaxAspectRatio", ClearMaxAspectRatio },
	{ "ClearHeightOverride", ClearHeightOverride },
	{ "Get_bOverride_WidthOverride", Get_bOverride_WidthOverride },
	{ "Set_bOverride_WidthOverride", Set_bOverride_WidthOverride },
	{ "Get_bOverride_HeightOverride", Get_bOverride_HeightOverride },
	{ "Set_bOverride_HeightOverride", Set_bOverride_HeightOverride },
	{ "Get_bOverride_MinDesiredWidth", Get_bOverride_MinDesiredWidth },
	{ "Set_bOverride_MinDesiredWidth", Set_bOverride_MinDesiredWidth },
	{ "Get_bOverride_MinDesiredHeight", Get_bOverride_MinDesiredHeight },
	{ "Set_bOverride_MinDesiredHeight", Set_bOverride_MinDesiredHeight },
	{ "Get_bOverride_MaxDesiredWidth", Get_bOverride_MaxDesiredWidth },
	{ "Set_bOverride_MaxDesiredWidth", Set_bOverride_MaxDesiredWidth },
	{ "Get_bOverride_MaxDesiredHeight", Get_bOverride_MaxDesiredHeight },
	{ "Set_bOverride_MaxDesiredHeight", Set_bOverride_MaxDesiredHeight },
	{ "Get_bOverride_MaxAspectRatio", Get_bOverride_MaxAspectRatio },
	{ "Set_bOverride_MaxAspectRatio", Set_bOverride_MaxAspectRatio },
	{ "Get_WidthOverride", Get_WidthOverride },
	{ "Get_HeightOverride", Get_HeightOverride },
	{ "Get_MinDesiredWidth", Get_MinDesiredWidth },
	{ "Get_MinDesiredHeight", Get_MinDesiredHeight },
	{ "Get_MaxDesiredWidth", Get_MaxDesiredWidth },
	{ "Get_MaxDesiredHeight", Get_MaxDesiredHeight },
	{ "Get_MaxAspectRatio", Get_MaxAspectRatio },
	{ "is_nil", wLua::LuaStatic::isnil },
	{ "__gc", wLua::LuaStatic::removeUClassFrameCache },
	{ NULL, NULL }
};

void Register(lua_State *InScriptContext)
{
	lua_newtable(InScriptContext);
	luaL_register(InScriptContext, NULL, Lib_Funcs);
	AzureHelpFuncs::AuxRegister(InScriptContext, "SizeBox");
}
void SetMtLink(lua_State *InScriptContext)
{
	AzureHelpFuncs::AuxSetMtLink(InScriptContext, "SizeBox", "ContentWidget",USERDATATYPE_UOBJECT);
}

}