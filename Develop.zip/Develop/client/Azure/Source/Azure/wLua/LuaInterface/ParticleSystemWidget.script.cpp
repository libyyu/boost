#include "Azure.h"
#include "Utility/help_funcs.h"
#include "wLua/UObjectHeaders.h"
#include "ParticleWidget.h"
#include "AzureLuaIntegration.h"

namespace LuaParticleSystemWidget
{
int32 SetReactivate(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ParticleSystemWidget",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ParticleSystemWidget must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool bActivateAndReset;
	} Params;
	Params.bActivateAndReset = !!(lua_toboolean(InScriptContext, 2));
#if UE_GAME
	UParticleSystemWidget * This = (UParticleSystemWidget *)Obj;
	This->SetReactivate(Params.bActivateAndReset);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetReactivate"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(bool*)(params.GetStructMemory() + 0) = Params.bActivateAndReset;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.bActivateAndReset = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetParticleSystemTemplate(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ParticleSystemWidget",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ParticleSystemWidget must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		UParticleSystem* InParticleSystemTemplate = nullptr;
	} Params;
	Params.InParticleSystemTemplate = (UParticleSystem*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"ParticleSystem");;
#if UE_GAME
	UParticleSystemWidget * This = (UParticleSystemWidget *)Obj;
	This->SetParticleSystemTemplate(Params.InParticleSystemTemplate);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetParticleSystemTemplate"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(UParticleSystem**)(params.GetStructMemory() + 0) = Params.InParticleSystemTemplate;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.InParticleSystemTemplate = *(UParticleSystem**)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 ActivateParticles(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ParticleSystemWidget",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ParticleSystemWidget must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool bActive;
		bool bReset;
	} Params;
	Params.bActive = !!(lua_toboolean(InScriptContext, 2));
	Params.bReset = !!(lua_toboolean(InScriptContext, 3));
#if UE_GAME
	UParticleSystemWidget * This = (UParticleSystemWidget *)Obj;
	This->ActivateParticles(Params.bActive,Params.bReset);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("ActivateParticles"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(bool*)(params.GetStructMemory() + 0) = Params.bActive;
		*(bool*)(params.GetStructMemory() + 1) = Params.bReset;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.bActive = *(bool*)(params.GetStructMemory() + 0);
		Params.bReset = *(bool*)(params.GetStructMemory() + 1);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 Get_ParticleSystemTemplate(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ParticleSystemWidget",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ParticleSystemWidget must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UParticleSystemWidget::StaticClass(), TEXT("ParticleSystemTemplate"));
	if(!Property) { check(false); return 0;}
	UParticleSystem* PropertyValue;
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaUtils::ReturnUObject(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_bReactivate(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ParticleSystemWidget",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ParticleSystemWidget must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UParticleSystemWidget::StaticClass(), TEXT("bReactivate"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = bool();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_bAutoActive(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ParticleSystemWidget",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ParticleSystemWidget must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UParticleSystemWidget::StaticClass(), TEXT("bAutoActive"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = bool();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_bForceRotateVertices(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"ParticleSystemWidget",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"ParticleSystemWidget must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UParticleSystemWidget::StaticClass(), TEXT("bForceRotateVertices"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = bool();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 New(lua_State* InScriptContext)
{
	UObject* Outer = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Object");
	FName Name = FName(luaL_checkstring(InScriptContext, 2));
	UObject* Obj = NewObject<UParticleSystemWidget>(Outer, Name);
	wLua::FLuaUtils::ReturnUObject(InScriptContext,Obj);
	return 1;
}

int32 Destroy(lua_State* InScriptContext)
{
	return 0;
}

int32 Class(lua_State* InScriptContext)
{
	UClass* Class = UParticleSystemWidget::StaticClass();
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Class);
	return 1;
}

const luaL_Reg Lib_Funcs[] =
{
	{ "New", New },
	{ "Destroy", Destroy },
	{ "Class", Class },
	{ "SetReactivate", SetReactivate },
	{ "SetParticleSystemTemplate", SetParticleSystemTemplate },
	{ "ActivateParticles", ActivateParticles },
	{ "Get_ParticleSystemTemplate", Get_ParticleSystemTemplate },
	{ "Get_bReactivate", Get_bReactivate },
	{ "Get_bAutoActive", Get_bAutoActive },
	{ "Get_bForceRotateVertices", Get_bForceRotateVertices },
	{ "is_nil", wLua::LuaStatic::isnil },
	{ "__gc", wLua::LuaStatic::removeUClassFrameCache },
	{ NULL, NULL }
};

void Register(lua_State *InScriptContext)
{
	lua_newtable(InScriptContext);
	luaL_register(InScriptContext, NULL, Lib_Funcs);
	AzureHelpFuncs::AuxRegister(InScriptContext, "ParticleSystemWidget");
}
void SetMtLink(lua_State *InScriptContext)
{
	AzureHelpFuncs::AuxSetMtLink(InScriptContext, "ParticleSystemWidget", "Widget",USERDATATYPE_UOBJECT);
}

}