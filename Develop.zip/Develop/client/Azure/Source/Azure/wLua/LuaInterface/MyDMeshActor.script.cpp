#include "Azure.h"
#include "Utility/help_funcs.h"
#include "wLua/UObjectHeaders.h"
#include "Debug/MyDMeshActor.h"
#include "AzureLuaIntegration.h"

namespace LuaMyDMeshActor
{
int32 CreateMeshSection(lua_State*);
int32 UpdateMeshSection(lua_State*);
int32 CreateMeshSectionByColorIndex(lua_State*);
int32 UpdateMeshSectionByColorIndex(lua_State*);

int32 SetMeshMaterial(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MyDMeshActor",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MyDMeshActor must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		int32 ElementIndex;
		UMaterialInterface* Material = nullptr;
	} Params;
	Params.ElementIndex = (luaL_checkint(InScriptContext, 2));
	Params.Material = (UMaterialInterface*)wLua::FLuaUtils::GetUObject(InScriptContext,3,"MaterialInterface");;
#if UE_GAME
	AMyDMeshActor * This = (AMyDMeshActor *)Obj;
	This->SetMeshMaterial(Params.ElementIndex,Params.Material);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetMeshMaterial"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(int32*)(params.GetStructMemory() + 0) = Params.ElementIndex;
		*(UMaterialInterface**)(params.GetStructMemory() + 8) = Params.Material;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ElementIndex = *(int32*)(params.GetStructMemory() + 0);
		Params.Material = *(UMaterialInterface**)(params.GetStructMemory() + 8);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 MarkRenderStateDirty(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MyDMeshActor",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MyDMeshActor must be non-null"); lua_error(InScriptContext);  return 0;}
#if UE_GAME
	AMyDMeshActor * This = (AMyDMeshActor *)Obj;
	This->MarkRenderStateDirty();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("MarkRenderStateDirty"));
	if(!Function) { check(false); return 0;}
	Obj->ProcessEvent(Function, NULL);
#endif
	return 0;
}

int32 Get_Segment(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MyDMeshActor",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MyDMeshActor must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AMyDMeshActor::StaticClass(), TEXT("Segment"));
	if(!Property) { check(false); return 0;}
	int32 PropertyValue = int32();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushinteger(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_Segment(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MyDMeshActor",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MyDMeshActor must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AMyDMeshActor::StaticClass(), TEXT("Segment"));
	if(!Property) { check(false); return 0;}
	int32 PropertyValue = (luaL_checkint(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 New(lua_State* InScriptContext)
{
	UObject* Outer = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Object");
	FName Name = FName(luaL_checkstring(InScriptContext, 2));
	UObject* Obj = NewObject<AMyDMeshActor>(Outer, Name);
	wLua::FLuaUtils::ReturnUObject(InScriptContext,Obj);
	return 1;
}

int32 Destroy(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MyDMeshActor",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MyDMeshActor must be non-null"); lua_error(InScriptContext);  return 0;}
		AActor * actor = Cast<AActor>(Obj);
		actor->Destroy();
		userdata->flag |= wLua::LuaObjectFlag::DESTROYED;
		wLua::FLuaUtils::RemoveObjectReference(Obj, userdata->stamp, InScriptContext);
#ifdef AZURE_BUILD_WLUACHECK
		UE_LOG(LogAzure, Warning, TEXT("Destroy MyDMeshActor: %x userdata:%x   stamp:%x"),Obj,userdata,userdata->stamp);
#endif
	return 0;
}

int32 Class(lua_State* InScriptContext)
{
	UClass* Class = AMyDMeshActor::StaticClass();
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Class);
	return 1;
}

const luaL_Reg Lib_Funcs[] =
{
	{ "New", New },
	{ "Destroy", Destroy },
	{ "Class", Class },
	{ "SetMeshMaterial", SetMeshMaterial },
	{ "MarkRenderStateDirty", MarkRenderStateDirty },
	{ "Get_Segment", Get_Segment },
	{ "Set_Segment", Set_Segment },
	{ "CreateMeshSection", CreateMeshSection },
	{ "UpdateMeshSection", UpdateMeshSection },
	{ "CreateMeshSectionByColorIndex", CreateMeshSectionByColorIndex },
	{ "UpdateMeshSectionByColorIndex", UpdateMeshSectionByColorIndex },
	{ "is_nil", wLua::LuaStatic::isnil },
	{ "__gc", wLua::LuaStatic::removeUClassFrameCache },
	{ NULL, NULL }
};

void Register(lua_State *InScriptContext)
{
	lua_newtable(InScriptContext);
	luaL_register(InScriptContext, NULL, Lib_Funcs);
	AzureHelpFuncs::AuxRegister(InScriptContext, "MyDMeshActor");
}
void SetMtLink(lua_State *InScriptContext)
{
	AzureHelpFuncs::AuxSetMtLink(InScriptContext, "MyDMeshActor", "Actor",USERDATATYPE_UOBJECT);
}

}