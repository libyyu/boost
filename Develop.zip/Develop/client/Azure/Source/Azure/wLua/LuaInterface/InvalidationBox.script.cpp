#include "Azure.h"
#include "Utility/help_funcs.h"
#include "wLua/UObjectHeaders.h"
#include "Components/InvalidationBox.h"
#include "InvalidationBox.h"
#include "Widgets/SInvalidationPanel.h"
#include "AzureLuaIntegration.h"

namespace LuaInvalidationBox
{
int32 SetAzureDisableWidgetCaching(lua_State*);

int32 SetDisableCacheRenderData(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"InvalidationBox",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"InvalidationBox must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool bDisable;
	} Params;
	Params.bDisable = !!(lua_toboolean(InScriptContext, 2));
#if UE_GAME
	UInvalidationBox * This = (UInvalidationBox *)Obj;
	This->SetDisableCacheRenderData(Params.bDisable);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetDisableCacheRenderData"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(bool*)(params.GetStructMemory() + 0) = Params.bDisable;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.bDisable = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetCanCache(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"InvalidationBox",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"InvalidationBox must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool CanCache;
	} Params;
	Params.CanCache = !!(lua_toboolean(InScriptContext, 2));
#if UE_GAME
	UInvalidationBox * This = (UInvalidationBox *)Obj;
	This->SetCanCache(Params.CanCache);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetCanCache"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(bool*)(params.GetStructMemory() + 0) = Params.CanCache;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.CanCache = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 InvalidateCache(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"InvalidationBox",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"InvalidationBox must be non-null"); lua_error(InScriptContext);  return 0;}
#if UE_GAME
	UInvalidationBox * This = (UInvalidationBox *)Obj;
	This->InvalidateCache();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("InvalidateCache"));
	if(!Function) { check(false); return 0;}
	Obj->ProcessEvent(Function, NULL);
#endif
	return 0;
}

int32 GetCanCache(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"InvalidationBox",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"InvalidationBox must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool ReturnValue;
	} Params;
#if UE_GAME
	UInvalidationBox * This = (UInvalidationBox *)Obj;
	Params.ReturnValue = This->GetCanCache();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetCanCache"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushboolean(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 Get_bCanCache(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"InvalidationBox",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"InvalidationBox must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UInvalidationBox::StaticClass(), TEXT("bCanCache"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = bool();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bCanCache(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"InvalidationBox",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"InvalidationBox must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UInvalidationBox::StaticClass(), TEXT("bCanCache"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_CacheRelativeTransforms(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"InvalidationBox",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"InvalidationBox must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UInvalidationBox::StaticClass(), TEXT("CacheRelativeTransforms"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = bool();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_DisableCacheRenderData(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"InvalidationBox",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"InvalidationBox must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UInvalidationBox::StaticClass(), TEXT("DisableCacheRenderData"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = bool();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 New(lua_State* InScriptContext)
{
	UObject* Outer = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Object");
	FName Name = FName(luaL_checkstring(InScriptContext, 2));
	UObject* Obj = NewObject<UInvalidationBox>(Outer, Name);
	wLua::FLuaUtils::ReturnUObject(InScriptContext,Obj);
	return 1;
}

int32 Destroy(lua_State* InScriptContext)
{
	return 0;
}

int32 Class(lua_State* InScriptContext)
{
	UClass* Class = UInvalidationBox::StaticClass();
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Class);
	return 1;
}

const luaL_Reg Lib_Funcs[] =
{
	{ "New", New },
	{ "Destroy", Destroy },
	{ "Class", Class },
	{ "SetDisableCacheRenderData", SetDisableCacheRenderData },
	{ "SetCanCache", SetCanCache },
	{ "InvalidateCache", InvalidateCache },
	{ "GetCanCache", GetCanCache },
	{ "Get_bCanCache", Get_bCanCache },
	{ "Set_bCanCache", Set_bCanCache },
	{ "Get_CacheRelativeTransforms", Get_CacheRelativeTransforms },
	{ "Get_DisableCacheRenderData", Get_DisableCacheRenderData },
	{ "SetAzureDisableWidgetCaching", SetAzureDisableWidgetCaching },
	{ "is_nil", wLua::LuaStatic::isnil },
	{ "__gc", wLua::LuaStatic::removeUClassFrameCache },
	{ NULL, NULL }
};

void Register(lua_State *InScriptContext)
{
	lua_newtable(InScriptContext);
	luaL_register(InScriptContext, NULL, Lib_Funcs);
	AzureHelpFuncs::AuxRegister(InScriptContext, "InvalidationBox");
}
void SetMtLink(lua_State *InScriptContext)
{
	AzureHelpFuncs::AuxSetMtLink(InScriptContext, "InvalidationBox", "ContentWidget",USERDATATYPE_UOBJECT);
}

}