#include "Azure.h"
#include "Utility/help_funcs.h"
#include "wLua/UObjectHeaders.h"
#include "Animation/WidgetAnimation.h"
#include "AzureLuaIntegration.h"

namespace LuaWidgetAnimation
{
int32 GetStartTime(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"WidgetAnimation",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"WidgetAnimation must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float ReturnValue;
	} Params;
	UWidgetAnimation * This = (UWidgetAnimation *)Obj;
	Params.ReturnValue = This->GetStartTime();
	lua_pushnumber(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetEndTime(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"WidgetAnimation",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"WidgetAnimation must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float ReturnValue;
	} Params;
	UWidgetAnimation * This = (UWidgetAnimation *)Obj;
	Params.ReturnValue = This->GetEndTime();
	lua_pushnumber(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 Call_OnAnimationStarted(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"WidgetAnimation",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"WidgetAnimation must be non-null"); lua_error(InScriptContext);  return 0;}
	UWidgetAnimation * This = (UWidgetAnimation *)Obj;
	This->OnAnimationStarted.Broadcast();
	return 0;
}

int32 Call_OnAnimationFinished(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"WidgetAnimation",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"WidgetAnimation must be non-null"); lua_error(InScriptContext);  return 0;}
	UWidgetAnimation * This = (UWidgetAnimation *)Obj;
	This->OnAnimationFinished.Broadcast();
	return 0;
}

int32 Get_GroupId(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"WidgetAnimation",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"WidgetAnimation must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UWidgetAnimation::StaticClass(), TEXT("GroupId"));
	if(!Property) { check(false); return 0;}
	int32 PropertyValue = int32();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushinteger(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_GroupId(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"WidgetAnimation",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"WidgetAnimation must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UWidgetAnimation::StaticClass(), TEXT("GroupId"));
	if(!Property) { check(false); return 0;}
	int32 PropertyValue = (luaL_checkint(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 New(lua_State* InScriptContext)
{
	UObject* Outer = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Object");
	FName Name = FName(luaL_checkstring(InScriptContext, 2));
	UObject* Obj = NewObject<UWidgetAnimation>(Outer, Name);
	wLua::FLuaUtils::ReturnUObject(InScriptContext,Obj);
	return 1;
}

int32 Destroy(lua_State* InScriptContext)
{
	return 0;
}

int32 Class(lua_State* InScriptContext)
{
	UClass* Class = UWidgetAnimation::StaticClass();
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Class);
	return 1;
}

const luaL_Reg Lib_Funcs[] =
{
	{ "New", New },
	{ "Destroy", Destroy },
	{ "Class", Class },
	{ "GetStartTime", GetStartTime },
	{ "GetEndTime", GetEndTime },
	{ "Call_OnAnimationStarted", Call_OnAnimationStarted },
	{ "Call_OnAnimationFinished", Call_OnAnimationFinished },
	{ "Get_GroupId", Get_GroupId },
	{ "Set_GroupId", Set_GroupId },
	{ "is_nil", wLua::LuaStatic::isnil },
	{ "__gc", wLua::LuaStatic::removeUClassFrameCache },
	{ NULL, NULL }
};

void Register(lua_State *InScriptContext)
{
	lua_newtable(InScriptContext);
	luaL_register(InScriptContext, NULL, Lib_Funcs);
	AzureHelpFuncs::AuxRegister(InScriptContext, "WidgetAnimation");
}
void SetMtLink(lua_State *InScriptContext)
{
	AzureHelpFuncs::AuxSetMtLink(InScriptContext, "WidgetAnimation", "Object",USERDATATYPE_UOBJECT);
}

}