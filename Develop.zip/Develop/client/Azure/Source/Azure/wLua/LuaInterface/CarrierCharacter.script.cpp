#include "Azure.h"
#include "Utility/help_funcs.h"
#include "wLua/UObjectHeaders.h"
#include "GameLogic/Player/CarrierCharacter.h"
#include "../UClassHeaders.h"
#include "AzureLuaIntegration.h"

namespace LuaCarrierCharacter
{
int32 SetTickToLua(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CarrierCharacter",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CarrierCharacter must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool b;
	} Params;
	Params.b = !!(lua_toboolean(InScriptContext, 2));
#if UE_GAME
	ACarrierCharacter * This = (ACarrierCharacter *)Obj;
	This->SetTickToLua(Params.b);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetTickToLua"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(bool*)(params.GetStructMemory() + 0) = Params.b;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.b = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetShipOutlineCapsuleComponent(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CarrierCharacter",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CarrierCharacter must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		UCapsuleComponent* capluse = nullptr;
	} Params;
	Params.capluse = (UCapsuleComponent*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"CapsuleComponent");;
#if UE_GAME
	ACarrierCharacter * This = (ACarrierCharacter *)Obj;
	This->SetShipOutlineCapsuleComponent(Params.capluse);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetShipOutlineCapsuleComponent"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(UCapsuleComponent**)(params.GetStructMemory() + 0) = Params.capluse;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.capluse = *(UCapsuleComponent**)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetRotationConfig(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CarrierCharacter",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CarrierCharacter must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		int32 index;
		float yaw;
		float rot;
	} Params;
	Params.index = (luaL_checkint(InScriptContext, 2));
	Params.yaw = (float)(luaL_checknumber(InScriptContext, 3));
	Params.rot = (float)(luaL_checknumber(InScriptContext, 4));
#if UE_GAME
	ACarrierCharacter * This = (ACarrierCharacter *)Obj;
	This->SetRotationConfig(Params.index,Params.yaw,Params.rot);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetRotationConfig"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(int32*)(params.GetStructMemory() + 0) = Params.index;
		*(float*)(params.GetStructMemory() + 4) = Params.yaw;
		*(float*)(params.GetStructMemory() + 8) = Params.rot;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.index = *(int32*)(params.GetStructMemory() + 0);
		Params.yaw = *(float*)(params.GetStructMemory() + 4);
		Params.rot = *(float*)(params.GetStructMemory() + 8);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetMovePhaseParamsConfig(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CarrierCharacter",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CarrierCharacter must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		int32 phaseIndex;
		float maxSpeed;
		float acceleration;
		float deceleration;
		float turnMaxSpeed;
		float turnAcceleration;
		float turnMaxAngle;
	} Params;
	Params.phaseIndex = (luaL_checkint(InScriptContext, 2));
	Params.maxSpeed = (float)(luaL_checknumber(InScriptContext, 3));
	Params.acceleration = (float)(luaL_checknumber(InScriptContext, 4));
	Params.deceleration = (float)(luaL_checknumber(InScriptContext, 5));
	Params.turnMaxSpeed = (float)(luaL_checknumber(InScriptContext, 6));
	Params.turnAcceleration = (float)(luaL_checknumber(InScriptContext, 7));
	Params.turnMaxAngle = (float)(luaL_checknumber(InScriptContext, 8));
#if UE_GAME
	ACarrierCharacter * This = (ACarrierCharacter *)Obj;
	This->SetMovePhaseParamsConfig(Params.phaseIndex,Params.maxSpeed,Params.acceleration,Params.deceleration,Params.turnMaxSpeed,Params.turnAcceleration,Params.turnMaxAngle);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetMovePhaseParamsConfig"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(int32*)(params.GetStructMemory() + 0) = Params.phaseIndex;
		*(float*)(params.GetStructMemory() + 4) = Params.maxSpeed;
		*(float*)(params.GetStructMemory() + 8) = Params.acceleration;
		*(float*)(params.GetStructMemory() + 12) = Params.deceleration;
		*(float*)(params.GetStructMemory() + 16) = Params.turnMaxSpeed;
		*(float*)(params.GetStructMemory() + 20) = Params.turnAcceleration;
		*(float*)(params.GetStructMemory() + 24) = Params.turnMaxAngle;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.phaseIndex = *(int32*)(params.GetStructMemory() + 0);
		Params.maxSpeed = *(float*)(params.GetStructMemory() + 4);
		Params.acceleration = *(float*)(params.GetStructMemory() + 8);
		Params.deceleration = *(float*)(params.GetStructMemory() + 12);
		Params.turnMaxSpeed = *(float*)(params.GetStructMemory() + 16);
		Params.turnAcceleration = *(float*)(params.GetStructMemory() + 20);
		Params.turnMaxAngle = *(float*)(params.GetStructMemory() + 24);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetMoveCheckMulti(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CarrierCharacter",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CarrierCharacter must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool b;
	} Params;
	Params.b = !!(lua_toboolean(InScriptContext, 2));
#if UE_GAME
	ACarrierCharacter * This = (ACarrierCharacter *)Obj;
	This->SetMoveCheckMulti(Params.b);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetMoveCheckMulti"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(bool*)(params.GetStructMemory() + 0) = Params.b;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.b = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetLateTickToLua(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CarrierCharacter",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CarrierCharacter must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool b;
	} Params;
	Params.b = !!(lua_toboolean(InScriptContext, 2));
#if UE_GAME
	ACarrierCharacter * This = (ACarrierCharacter *)Obj;
	This->SetLateTickToLua(Params.b);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetLateTickToLua"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(bool*)(params.GetStructMemory() + 0) = Params.b;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.b = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetKeepMovingWhileNoDriver(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CarrierCharacter",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CarrierCharacter must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool b;
	} Params;
	Params.b = !!(lua_toboolean(InScriptContext, 2));
#if UE_GAME
	ACarrierCharacter * This = (ACarrierCharacter *)Obj;
	This->SetKeepMovingWhileNoDriver(Params.b);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetKeepMovingWhileNoDriver"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(bool*)(params.GetStructMemory() + 0) = Params.b;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.b = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetEnableDash(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CarrierCharacter",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CarrierCharacter must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool enable;
	} Params;
	Params.enable = !!(lua_toboolean(InScriptContext, 2));
#if UE_GAME
	ACarrierCharacter * This = (ACarrierCharacter *)Obj;
	This->SetEnableDash(Params.enable);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetEnableDash"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(bool*)(params.GetStructMemory() + 0) = Params.enable;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.enable = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetCurrentMovePhaseIndex(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CarrierCharacter",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CarrierCharacter must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		int32 phaseIndex;
	} Params;
	Params.phaseIndex = (luaL_checkint(InScriptContext, 2));
#if UE_GAME
	ACarrierCharacter * This = (ACarrierCharacter *)Obj;
	This->SetCurrentMovePhaseIndex(Params.phaseIndex);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetCurrentMovePhaseIndex"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(int32*)(params.GetStructMemory() + 0) = Params.phaseIndex;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.phaseIndex = *(int32*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetCheckHitBearing(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CarrierCharacter",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CarrierCharacter must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool b;
	} Params;
	Params.b = !!(lua_toboolean(InScriptContext, 2));
#if UE_GAME
	ACarrierCharacter * This = (ACarrierCharacter *)Obj;
	This->SetCheckHitBearing(Params.b);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetCheckHitBearing"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(bool*)(params.GetStructMemory() + 0) = Params.b;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.b = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetCarrierType(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CarrierCharacter",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CarrierCharacter must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		int32 type;
	} Params;
	Params.type = (luaL_checkint(InScriptContext, 2));
#if UE_GAME
	ACarrierCharacter * This = (ACarrierCharacter *)Obj;
	This->SetCarrierType(Params.type);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetCarrierType"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(int32*)(params.GetStructMemory() + 0) = Params.type;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.type = *(int32*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetBackMoveParamsConfig(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CarrierCharacter",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CarrierCharacter must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float maxSpeed;
		float acceleration;
		float deceleration;
		float turnMaxSpeed;
		float turnAcceleration;
		float turnMaxAngle;
	} Params;
	Params.maxSpeed = (float)(luaL_checknumber(InScriptContext, 2));
	Params.acceleration = (float)(luaL_checknumber(InScriptContext, 3));
	Params.deceleration = (float)(luaL_checknumber(InScriptContext, 4));
	Params.turnMaxSpeed = (float)(luaL_checknumber(InScriptContext, 5));
	Params.turnAcceleration = (float)(luaL_checknumber(InScriptContext, 6));
	Params.turnMaxAngle = (float)(luaL_checknumber(InScriptContext, 7));
#if UE_GAME
	ACarrierCharacter * This = (ACarrierCharacter *)Obj;
	This->SetBackMoveParamsConfig(Params.maxSpeed,Params.acceleration,Params.deceleration,Params.turnMaxSpeed,Params.turnAcceleration,Params.turnMaxAngle);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetBackMoveParamsConfig"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(float*)(params.GetStructMemory() + 0) = Params.maxSpeed;
		*(float*)(params.GetStructMemory() + 4) = Params.acceleration;
		*(float*)(params.GetStructMemory() + 8) = Params.deceleration;
		*(float*)(params.GetStructMemory() + 12) = Params.turnMaxSpeed;
		*(float*)(params.GetStructMemory() + 16) = Params.turnAcceleration;
		*(float*)(params.GetStructMemory() + 20) = Params.turnMaxAngle;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.maxSpeed = *(float*)(params.GetStructMemory() + 0);
		Params.acceleration = *(float*)(params.GetStructMemory() + 4);
		Params.deceleration = *(float*)(params.GetStructMemory() + 8);
		Params.turnMaxSpeed = *(float*)(params.GetStructMemory() + 12);
		Params.turnAcceleration = *(float*)(params.GetStructMemory() + 16);
		Params.turnMaxAngle = *(float*)(params.GetStructMemory() + 20);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SeNormalMoveParamsConfig(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CarrierCharacter",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CarrierCharacter must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float maxSpeed;
		float acceleration;
		float deceleration;
		float turnMaxSpeed;
		float turnAcceleration;
		float turnMaxAngle;
	} Params;
	Params.maxSpeed = (float)(luaL_checknumber(InScriptContext, 2));
	Params.acceleration = (float)(luaL_checknumber(InScriptContext, 3));
	Params.deceleration = (float)(luaL_checknumber(InScriptContext, 4));
	Params.turnMaxSpeed = (float)(luaL_checknumber(InScriptContext, 5));
	Params.turnAcceleration = (float)(luaL_checknumber(InScriptContext, 6));
	Params.turnMaxAngle = (float)(luaL_checknumber(InScriptContext, 7));
#if UE_GAME
	ACarrierCharacter * This = (ACarrierCharacter *)Obj;
	This->SeNormalMoveParamsConfig(Params.maxSpeed,Params.acceleration,Params.deceleration,Params.turnMaxSpeed,Params.turnAcceleration,Params.turnMaxAngle);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SeNormalMoveParamsConfig"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(float*)(params.GetStructMemory() + 0) = Params.maxSpeed;
		*(float*)(params.GetStructMemory() + 4) = Params.acceleration;
		*(float*)(params.GetStructMemory() + 8) = Params.deceleration;
		*(float*)(params.GetStructMemory() + 12) = Params.turnMaxSpeed;
		*(float*)(params.GetStructMemory() + 16) = Params.turnAcceleration;
		*(float*)(params.GetStructMemory() + 20) = Params.turnMaxAngle;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.maxSpeed = *(float*)(params.GetStructMemory() + 0);
		Params.acceleration = *(float*)(params.GetStructMemory() + 4);
		Params.deceleration = *(float*)(params.GetStructMemory() + 8);
		Params.turnMaxSpeed = *(float*)(params.GetStructMemory() + 12);
		Params.turnAcceleration = *(float*)(params.GetStructMemory() + 16);
		Params.turnMaxAngle = *(float*)(params.GetStructMemory() + 20);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 GetIsTrain(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CarrierCharacter",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CarrierCharacter must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool ReturnValue;
	} Params;
#if UE_GAME
	ACarrierCharacter * This = (ACarrierCharacter *)Obj;
	Params.ReturnValue = This->GetIsTrain();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetIsTrain"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushboolean(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetIsShip(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CarrierCharacter",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CarrierCharacter must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool ReturnValue;
	} Params;
#if UE_GAME
	ACarrierCharacter * This = (ACarrierCharacter *)Obj;
	Params.ReturnValue = This->GetIsShip();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetIsShip"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushboolean(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetBlockState(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CarrierCharacter",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CarrierCharacter must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FVector center_pos;
		int32 cdir;
		int32 ReturnValue;
	} Params;
	Params.center_pos = (wLua::FLuaVector::Get(InScriptContext, 2));
	Params.cdir = (luaL_checkint(InScriptContext, 3));
#if UE_GAME
	ACarrierCharacter * This = (ACarrierCharacter *)Obj;
	Params.ReturnValue = This->GetBlockState(Params.center_pos,Params.cdir);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetBlockState"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FVector*)(params.GetStructMemory() + 0) = Params.center_pos;
		*(int32*)(params.GetStructMemory() + 12) = Params.cdir;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.center_pos = *(FVector*)(params.GetStructMemory() + 0);
		Params.cdir = *(int32*)(params.GetStructMemory() + 12);
		Params.ReturnValue = *(int32*)(params.GetStructMemory() + 16);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushinteger(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 EnableBrake(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CarrierCharacter",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CarrierCharacter must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool enable;
	} Params;
	Params.enable = !!(lua_toboolean(InScriptContext, 2));
#if UE_GAME
	ACarrierCharacter * This = (ACarrierCharacter *)Obj;
	This->EnableBrake(Params.enable);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("EnableBrake"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(bool*)(params.GetStructMemory() + 0) = Params.enable;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.enable = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 ClearRotationConfig(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CarrierCharacter",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CarrierCharacter must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		int32 index;
	} Params;
	Params.index = (luaL_checkint(InScriptContext, 2));
#if UE_GAME
	ACarrierCharacter * This = (ACarrierCharacter *)Obj;
	This->ClearRotationConfig(Params.index);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("ClearRotationConfig"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(int32*)(params.GetStructMemory() + 0) = Params.index;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.index = *(int32*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 ClearMovePhaseParamsConfig(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CarrierCharacter",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CarrierCharacter must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		int32 phaseIndex;
	} Params;
	Params.phaseIndex = (luaL_checkint(InScriptContext, 2));
#if UE_GAME
	ACarrierCharacter * This = (ACarrierCharacter *)Obj;
	This->ClearMovePhaseParamsConfig(Params.phaseIndex);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("ClearMovePhaseParamsConfig"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(int32*)(params.GetStructMemory() + 0) = Params.phaseIndex;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.phaseIndex = *(int32*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 ClearAllRotationConfig(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CarrierCharacter",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CarrierCharacter must be non-null"); lua_error(InScriptContext);  return 0;}
#if UE_GAME
	ACarrierCharacter * This = (ACarrierCharacter *)Obj;
	This->ClearAllRotationConfig();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("ClearAllRotationConfig"));
	if(!Function) { check(false); return 0;}
	Obj->ProcessEvent(Function, NULL);
#endif
	return 0;
}

int32 ClearAllMovePhaseParamsConfig(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CarrierCharacter",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CarrierCharacter must be non-null"); lua_error(InScriptContext);  return 0;}
#if UE_GAME
	ACarrierCharacter * This = (ACarrierCharacter *)Obj;
	This->ClearAllMovePhaseParamsConfig();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("ClearAllMovePhaseParamsConfig"));
	if(!Function) { check(false); return 0;}
	Obj->ProcessEvent(Function, NULL);
#endif
	return 0;
}

int32 BrakeStop(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CarrierCharacter",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CarrierCharacter must be non-null"); lua_error(InScriptContext);  return 0;}
#if UE_GAME
	ACarrierCharacter * This = (ACarrierCharacter *)Obj;
	This->BrakeStop();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("BrakeStop"));
	if(!Function) { check(false); return 0;}
	Obj->ProcessEvent(Function, NULL);
#endif
	return 0;
}

int32 AppendRotationConfig(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CarrierCharacter",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CarrierCharacter must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float yaw;
		float rot;
	} Params;
	Params.yaw = (float)(luaL_checknumber(InScriptContext, 2));
	Params.rot = (float)(luaL_checknumber(InScriptContext, 3));
#if UE_GAME
	ACarrierCharacter * This = (ACarrierCharacter *)Obj;
	This->AppendRotationConfig(Params.yaw,Params.rot);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("AppendRotationConfig"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(float*)(params.GetStructMemory() + 0) = Params.yaw;
		*(float*)(params.GetStructMemory() + 4) = Params.rot;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.yaw = *(float*)(params.GetStructMemory() + 0);
		Params.rot = *(float*)(params.GetStructMemory() + 4);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 AppendMovePhaseParamsConfig(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CarrierCharacter",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CarrierCharacter must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float maxSpeed;
		float acceleration;
		float deceleration;
		float turnMaxSpeed;
		float turnAcceleration;
		float turnMaxAngle;
	} Params;
	Params.maxSpeed = (float)(luaL_checknumber(InScriptContext, 2));
	Params.acceleration = (float)(luaL_checknumber(InScriptContext, 3));
	Params.deceleration = (float)(luaL_checknumber(InScriptContext, 4));
	Params.turnMaxSpeed = (float)(luaL_checknumber(InScriptContext, 5));
	Params.turnAcceleration = (float)(luaL_checknumber(InScriptContext, 6));
	Params.turnMaxAngle = (float)(luaL_checknumber(InScriptContext, 7));
#if UE_GAME
	ACarrierCharacter * This = (ACarrierCharacter *)Obj;
	This->AppendMovePhaseParamsConfig(Params.maxSpeed,Params.acceleration,Params.deceleration,Params.turnMaxSpeed,Params.turnAcceleration,Params.turnMaxAngle);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("AppendMovePhaseParamsConfig"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(float*)(params.GetStructMemory() + 0) = Params.maxSpeed;
		*(float*)(params.GetStructMemory() + 4) = Params.acceleration;
		*(float*)(params.GetStructMemory() + 8) = Params.deceleration;
		*(float*)(params.GetStructMemory() + 12) = Params.turnMaxSpeed;
		*(float*)(params.GetStructMemory() + 16) = Params.turnAcceleration;
		*(float*)(params.GetStructMemory() + 20) = Params.turnMaxAngle;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.maxSpeed = *(float*)(params.GetStructMemory() + 0);
		Params.acceleration = *(float*)(params.GetStructMemory() + 4);
		Params.deceleration = *(float*)(params.GetStructMemory() + 8);
		Params.turnMaxSpeed = *(float*)(params.GetStructMemory() + 12);
		Params.turnAcceleration = *(float*)(params.GetStructMemory() + 16);
		Params.turnMaxAngle = *(float*)(params.GetStructMemory() + 20);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 Get_enableDash(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CarrierCharacter",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CarrierCharacter must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(ACarrierCharacter::StaticClass(), TEXT("enableDash"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = bool();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_enableDash(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CarrierCharacter",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CarrierCharacter must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(ACarrierCharacter::StaticClass(), TEXT("enableDash"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_beingBrakeStop(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CarrierCharacter",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CarrierCharacter must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(ACarrierCharacter::StaticClass(), TEXT("beingBrakeStop"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = bool();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_beingBrakeStop(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CarrierCharacter",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CarrierCharacter must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(ACarrierCharacter::StaticClass(), TEXT("beingBrakeStop"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_beingBreak(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CarrierCharacter",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CarrierCharacter must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(ACarrierCharacter::StaticClass(), TEXT("beingBreak"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = bool();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_beingBreak(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CarrierCharacter",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CarrierCharacter must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(ACarrierCharacter::StaticClass(), TEXT("beingBreak"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_waitChangeToSimulatedProxy(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CarrierCharacter",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CarrierCharacter must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(ACarrierCharacter::StaticClass(), TEXT("waitChangeToSimulatedProxy"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = bool();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_waitChangeToSimulatedProxy(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CarrierCharacter",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CarrierCharacter must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(ACarrierCharacter::StaticClass(), TEXT("waitChangeToSimulatedProxy"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_currentNormalizationSpeed(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CarrierCharacter",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CarrierCharacter must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(ACarrierCharacter::StaticClass(), TEXT("currentNormalizationSpeed"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_currentNormalizationSpeed(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CarrierCharacter",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CarrierCharacter must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(ACarrierCharacter::StaticClass(), TEXT("currentNormalizationSpeed"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_currentRotaitonSpeed(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CarrierCharacter",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CarrierCharacter must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(ACarrierCharacter::StaticClass(), TEXT("currentRotaitonSpeed"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_currentRotaitonSpeed(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CarrierCharacter",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CarrierCharacter must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(ACarrierCharacter::StaticClass(), TEXT("currentRotaitonSpeed"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_currentWheelYaw(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CarrierCharacter",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CarrierCharacter must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(ACarrierCharacter::StaticClass(), TEXT("currentWheelYaw"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_currentWheelYaw(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CarrierCharacter",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CarrierCharacter must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(ACarrierCharacter::StaticClass(), TEXT("currentWheelYaw"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_wheelToRotFactor(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CarrierCharacter",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CarrierCharacter must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(ACarrierCharacter::StaticClass(), TEXT("wheelToRotFactor"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_wheelToRotFactor(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CarrierCharacter",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CarrierCharacter must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(ACarrierCharacter::StaticClass(), TEXT("wheelToRotFactor"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_move_phase(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CarrierCharacter",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CarrierCharacter must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(ACarrierCharacter::StaticClass(), TEXT("move_phase"));
	if(!Property) { check(false); return 0;}
	int32 PropertyValue = int32();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushinteger(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_move_phase(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CarrierCharacter",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CarrierCharacter must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(ACarrierCharacter::StaticClass(), TEXT("move_phase"));
	if(!Property) { check(false); return 0;}
	int32 PropertyValue = (luaL_checkint(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_brakeStopFiction(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CarrierCharacter",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CarrierCharacter must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(ACarrierCharacter::StaticClass(), TEXT("brakeStopFiction"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_brakeStopFiction(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CarrierCharacter",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CarrierCharacter must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(ACarrierCharacter::StaticClass(), TEXT("brakeStopFiction"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_normalStopFiction(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CarrierCharacter",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CarrierCharacter must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(ACarrierCharacter::StaticClass(), TEXT("normalStopFiction"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_normalStopFiction(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CarrierCharacter",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CarrierCharacter must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(ACarrierCharacter::StaticClass(), TEXT("normalStopFiction"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_extMaxSpeedScale(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CarrierCharacter",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CarrierCharacter must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(ACarrierCharacter::StaticClass(), TEXT("extMaxSpeedScale"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_extMaxSpeedScale(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CarrierCharacter",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CarrierCharacter must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(ACarrierCharacter::StaticClass(), TEXT("extMaxSpeedScale"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_turnBackToForwardAcceleration(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CarrierCharacter",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CarrierCharacter must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(ACarrierCharacter::StaticClass(), TEXT("turnBackToForwardAcceleration"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_turnBackToForwardAcceleration(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CarrierCharacter",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CarrierCharacter must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(ACarrierCharacter::StaticClass(), TEXT("turnBackToForwardAcceleration"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_separateTurnMoveMode(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CarrierCharacter",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CarrierCharacter must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(ACarrierCharacter::StaticClass(), TEXT("separateTurnMoveMode"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = bool();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_separateTurnMoveMode(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CarrierCharacter",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CarrierCharacter must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(ACarrierCharacter::StaticClass(), TEXT("separateTurnMoveMode"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_canBackwardsMove(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CarrierCharacter",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CarrierCharacter must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(ACarrierCharacter::StaticClass(), TEXT("canBackwardsMove"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = bool();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_canBackwardsMove(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CarrierCharacter",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CarrierCharacter must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(ACarrierCharacter::StaticClass(), TEXT("canBackwardsMove"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_limitSeaDepth(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CarrierCharacter",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CarrierCharacter must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(ACarrierCharacter::StaticClass(), TEXT("limitSeaDepth"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_limitSeaDepth(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CarrierCharacter",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CarrierCharacter must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(ACarrierCharacter::StaticClass(), TEXT("limitSeaDepth"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_currentSeaDepth(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CarrierCharacter",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CarrierCharacter must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(ACarrierCharacter::StaticClass(), TEXT("currentSeaDepth"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_currentSeaDepth(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CarrierCharacter",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CarrierCharacter must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(ACarrierCharacter::StaticClass(), TEXT("currentSeaDepth"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_currentStatus(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CarrierCharacter",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CarrierCharacter must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(ACarrierCharacter::StaticClass(), TEXT("currentStatus"));
	if(!Property) { check(false); return 0;}
	ShipStatus PropertyValue = ShipStatus();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushinteger(InScriptContext, (int)PropertyValue);
	return 1;
}

int32 Set_currentStatus(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CarrierCharacter",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CarrierCharacter must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(ACarrierCharacter::StaticClass(), TEXT("currentStatus"));
	if(!Property) { check(false); return 0;}
	ShipStatus PropertyValue = (ShipStatus)(luaL_checkint(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_RanAgroundSeaDepth(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CarrierCharacter",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CarrierCharacter must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(ACarrierCharacter::StaticClass(), TEXT("RanAgroundSeaDepth"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_RanAgroundSeaDepth(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CarrierCharacter",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CarrierCharacter must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(ACarrierCharacter::StaticClass(), TEXT("RanAgroundSeaDepth"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_defaultFlyingMode(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CarrierCharacter",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CarrierCharacter must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(ACarrierCharacter::StaticClass(), TEXT("defaultFlyingMode"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = bool();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_defaultFlyingMode(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CarrierCharacter",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CarrierCharacter must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(ACarrierCharacter::StaticClass(), TEXT("defaultFlyingMode"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_fixShipOutlineCapsuleComponentPitch(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CarrierCharacter",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CarrierCharacter must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(ACarrierCharacter::StaticClass(), TEXT("fixShipOutlineCapsuleComponentPitch"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_fixShipOutlineCapsuleComponentPitch(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CarrierCharacter",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CarrierCharacter must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(ACarrierCharacter::StaticClass(), TEXT("fixShipOutlineCapsuleComponentPitch"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_fixShipOutlineCapsuleComponentPosZ(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CarrierCharacter",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CarrierCharacter must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(ACarrierCharacter::StaticClass(), TEXT("fixShipOutlineCapsuleComponentPosZ"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_fixShipOutlineCapsuleComponentPosZ(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CarrierCharacter",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CarrierCharacter must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(ACarrierCharacter::StaticClass(), TEXT("fixShipOutlineCapsuleComponentPosZ"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_fixShipPenetrationDepthMax(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CarrierCharacter",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CarrierCharacter must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(ACarrierCharacter::StaticClass(), TEXT("fixShipPenetrationDepthMax"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_fixShipPenetrationDepthMax(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CarrierCharacter",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CarrierCharacter must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(ACarrierCharacter::StaticClass(), TEXT("fixShipPenetrationDepthMax"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_fShipOutlineCapsuleComponentRadius(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CarrierCharacter",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CarrierCharacter must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(ACarrierCharacter::StaticClass(), TEXT("fShipOutlineCapsuleComponentRadius"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_fShipOutlineCapsuleComponentRadius(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CarrierCharacter",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CarrierCharacter must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(ACarrierCharacter::StaticClass(), TEXT("fShipOutlineCapsuleComponentRadius"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_fShipOutlineCapsuleComponentHalfHeight(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CarrierCharacter",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CarrierCharacter must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(ACarrierCharacter::StaticClass(), TEXT("fShipOutlineCapsuleComponentHalfHeight"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_fShipOutlineCapsuleComponentHalfHeight(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CarrierCharacter",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CarrierCharacter must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(ACarrierCharacter::StaticClass(), TEXT("fShipOutlineCapsuleComponentHalfHeight"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_carrier_type(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CarrierCharacter",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CarrierCharacter must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(ACarrierCharacter::StaticClass(), TEXT("carrier_type"));
	if(!Property) { check(false); return 0;}
	TEnumAsByte<FCarrierType> PropertyValue = TEnumAsByte<FCarrierType>();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushinteger(InScriptContext, (int)PropertyValue);
	return 1;
}

int32 New(lua_State* InScriptContext)
{
	UObject* Outer = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Object");
	FName Name = FName(luaL_checkstring(InScriptContext, 2));
	UObject* Obj = NewObject<ACarrierCharacter>(Outer, Name);
	wLua::FLuaUtils::ReturnUObject(InScriptContext,Obj);
	return 1;
}

int32 Destroy(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CarrierCharacter",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CarrierCharacter must be non-null"); lua_error(InScriptContext);  return 0;}
		AActor * actor = Cast<AActor>(Obj);
		actor->Destroy();
		userdata->flag |= wLua::LuaObjectFlag::DESTROYED;
		wLua::FLuaUtils::RemoveObjectReference(Obj, userdata->stamp, InScriptContext);
#ifdef AZURE_BUILD_WLUACHECK
		UE_LOG(LogAzure, Warning, TEXT("Destroy CarrierCharacter: %x userdata:%x   stamp:%x"),Obj,userdata,userdata->stamp);
#endif
	return 0;
}

int32 Class(lua_State* InScriptContext)
{
	UClass* Class = ACarrierCharacter::StaticClass();
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Class);
	return 1;
}

const luaL_Reg Lib_Funcs[] =
{
	{ "New", New },
	{ "Destroy", Destroy },
	{ "Class", Class },
	{ "SetTickToLua", SetTickToLua },
	{ "SetShipOutlineCapsuleComponent", SetShipOutlineCapsuleComponent },
	{ "SetRotationConfig", SetRotationConfig },
	{ "SetMovePhaseParamsConfig", SetMovePhaseParamsConfig },
	{ "SetMoveCheckMulti", SetMoveCheckMulti },
	{ "SetLateTickToLua", SetLateTickToLua },
	{ "SetKeepMovingWhileNoDriver", SetKeepMovingWhileNoDriver },
	{ "SetEnableDash", SetEnableDash },
	{ "SetCurrentMovePhaseIndex", SetCurrentMovePhaseIndex },
	{ "SetCheckHitBearing", SetCheckHitBearing },
	{ "SetCarrierType", SetCarrierType },
	{ "SetBackMoveParamsConfig", SetBackMoveParamsConfig },
	{ "SeNormalMoveParamsConfig", SeNormalMoveParamsConfig },
	{ "GetIsTrain", GetIsTrain },
	{ "GetIsShip", GetIsShip },
	{ "GetBlockState", GetBlockState },
	{ "EnableBrake", EnableBrake },
	{ "ClearRotationConfig", ClearRotationConfig },
	{ "ClearMovePhaseParamsConfig", ClearMovePhaseParamsConfig },
	{ "ClearAllRotationConfig", ClearAllRotationConfig },
	{ "ClearAllMovePhaseParamsConfig", ClearAllMovePhaseParamsConfig },
	{ "BrakeStop", BrakeStop },
	{ "AppendRotationConfig", AppendRotationConfig },
	{ "AppendMovePhaseParamsConfig", AppendMovePhaseParamsConfig },
	{ "Get_enableDash", Get_enableDash },
	{ "Set_enableDash", Set_enableDash },
	{ "Get_beingBrakeStop", Get_beingBrakeStop },
	{ "Set_beingBrakeStop", Set_beingBrakeStop },
	{ "Get_beingBreak", Get_beingBreak },
	{ "Set_beingBreak", Set_beingBreak },
	{ "Get_waitChangeToSimulatedProxy", Get_waitChangeToSimulatedProxy },
	{ "Set_waitChangeToSimulatedProxy", Set_waitChangeToSimulatedProxy },
	{ "Get_currentNormalizationSpeed", Get_currentNormalizationSpeed },
	{ "Set_currentNormalizationSpeed", Set_currentNormalizationSpeed },
	{ "Get_currentRotaitonSpeed", Get_currentRotaitonSpeed },
	{ "Set_currentRotaitonSpeed", Set_currentRotaitonSpeed },
	{ "Get_currentWheelYaw", Get_currentWheelYaw },
	{ "Set_currentWheelYaw", Set_currentWheelYaw },
	{ "Get_wheelToRotFactor", Get_wheelToRotFactor },
	{ "Set_wheelToRotFactor", Set_wheelToRotFactor },
	{ "Get_move_phase", Get_move_phase },
	{ "Set_move_phase", Set_move_phase },
	{ "Get_brakeStopFiction", Get_brakeStopFiction },
	{ "Set_brakeStopFiction", Set_brakeStopFiction },
	{ "Get_normalStopFiction", Get_normalStopFiction },
	{ "Set_normalStopFiction", Set_normalStopFiction },
	{ "Get_extMaxSpeedScale", Get_extMaxSpeedScale },
	{ "Set_extMaxSpeedScale", Set_extMaxSpeedScale },
	{ "Get_turnBackToForwardAcceleration", Get_turnBackToForwardAcceleration },
	{ "Set_turnBackToForwardAcceleration", Set_turnBackToForwardAcceleration },
	{ "Get_separateTurnMoveMode", Get_separateTurnMoveMode },
	{ "Set_separateTurnMoveMode", Set_separateTurnMoveMode },
	{ "Get_canBackwardsMove", Get_canBackwardsMove },
	{ "Set_canBackwardsMove", Set_canBackwardsMove },
	{ "Get_limitSeaDepth", Get_limitSeaDepth },
	{ "Set_limitSeaDepth", Set_limitSeaDepth },
	{ "Get_currentSeaDepth", Get_currentSeaDepth },
	{ "Set_currentSeaDepth", Set_currentSeaDepth },
	{ "Get_currentStatus", Get_currentStatus },
	{ "Set_currentStatus", Set_currentStatus },
	{ "Get_RanAgroundSeaDepth", Get_RanAgroundSeaDepth },
	{ "Set_RanAgroundSeaDepth", Set_RanAgroundSeaDepth },
	{ "Get_defaultFlyingMode", Get_defaultFlyingMode },
	{ "Set_defaultFlyingMode", Set_defaultFlyingMode },
	{ "Get_fixShipOutlineCapsuleComponentPitch", Get_fixShipOutlineCapsuleComponentPitch },
	{ "Set_fixShipOutlineCapsuleComponentPitch", Set_fixShipOutlineCapsuleComponentPitch },
	{ "Get_fixShipOutlineCapsuleComponentPosZ", Get_fixShipOutlineCapsuleComponentPosZ },
	{ "Set_fixShipOutlineCapsuleComponentPosZ", Set_fixShipOutlineCapsuleComponentPosZ },
	{ "Get_fixShipPenetrationDepthMax", Get_fixShipPenetrationDepthMax },
	{ "Set_fixShipPenetrationDepthMax", Set_fixShipPenetrationDepthMax },
	{ "Get_fShipOutlineCapsuleComponentRadius", Get_fShipOutlineCapsuleComponentRadius },
	{ "Set_fShipOutlineCapsuleComponentRadius", Set_fShipOutlineCapsuleComponentRadius },
	{ "Get_fShipOutlineCapsuleComponentHalfHeight", Get_fShipOutlineCapsuleComponentHalfHeight },
	{ "Set_fShipOutlineCapsuleComponentHalfHeight", Set_fShipOutlineCapsuleComponentHalfHeight },
	{ "Get_carrier_type", Get_carrier_type },
	{ "is_nil", wLua::LuaStatic::isnil },
	{ "__gc", wLua::LuaStatic::removeUClassFrameCache },
	{ NULL, NULL }
};

void Register(lua_State *InScriptContext)
{
	lua_newtable(InScriptContext);
	luaL_register(InScriptContext, NULL, Lib_Funcs);
	AzureHelpFuncs::AuxRegister(InScriptContext, "CarrierCharacter");
}
void SetMtLink(lua_State *InScriptContext)
{
	AzureHelpFuncs::AuxSetMtLink(InScriptContext, "CarrierCharacter", "CarrierCharacterBase",USERDATATYPE_UOBJECT);
}

}