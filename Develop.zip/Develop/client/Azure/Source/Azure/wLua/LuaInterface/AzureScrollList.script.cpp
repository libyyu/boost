#include "Azure.h"
#include "Utility/help_funcs.h"
#include "wLua/UObjectHeaders.h"
#include "AzureScrollList.h"
#include "AzureLuaIntegration.h"

namespace LuaAzureScrollList
{
int32 setUpdateFunc(lua_State*);
int32 getItem(lua_State*);
int32 setCount(lua_State*);
int32 forceUpdate(lua_State*);
int32 scrollToBegin(lua_State*);
int32 scrollToEnd(lua_State*);
int32 setFirstIndex(lua_State*);
int32 getFirstIndex(lua_State*);
int32 clear(lua_State*);
int32 SetFirstIndex(lua_State*);
int32 ScrollToBegin(lua_State*);
int32 ScrollToEnd(lua_State*);
int32 GetFirstIndex(lua_State*);
int32 ForceUpdate(lua_State*);
int32 setMiddleItemChangeFunc(lua_State*);
int32 Clear(lua_State*);

int32 TemporarilyShutOffTakeTurnAnim(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureScrollList",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureScrollList must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool bIsOff;
	} Params;
	Params.bIsOff = !!(lua_toboolean(InScriptContext, 2));
#if UE_GAME
	UAzureScrollList * This = (UAzureScrollList *)Obj;
	This->TemporarilyShutOffTakeTurnAnim(Params.bIsOff);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("TemporarilyShutOffTakeTurnAnim"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(bool*)(params.GetStructMemory() + 0) = Params.bIsOff;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.bIsOff = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetCount(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureScrollList",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureScrollList must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		int32 count;
	} Params;
	Params.count = (luaL_checkint(InScriptContext, 2));
#if UE_GAME
	UAzureScrollList * This = (UAzureScrollList *)Obj;
	This->SetCount(Params.count);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetCount"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(int32*)(params.GetStructMemory() + 0) = Params.count;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.count = *(int32*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 ReplyTaketurnAnim(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureScrollList",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureScrollList must be non-null"); lua_error(InScriptContext);  return 0;}
#if UE_GAME
	UAzureScrollList * This = (UAzureScrollList *)Obj;
	This->ReplyTaketurnAnim();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("ReplyTaketurnAnim"));
	if(!Function) { check(false); return 0;}
	Obj->ProcessEvent(Function, NULL);
#endif
	return 0;
}

int32 ReplyGapAnim(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureScrollList",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureScrollList must be non-null"); lua_error(InScriptContext);  return 0;}
#if UE_GAME
	UAzureScrollList * This = (UAzureScrollList *)Obj;
	This->ReplyGapAnim();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("ReplyGapAnim"));
	if(!Function) { check(false); return 0;}
	Obj->ProcessEvent(Function, NULL);
#endif
	return 0;
}

int32 GetScrollOffset(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureScrollList",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureScrollList must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float ReturnValue;
	} Params;
#if UE_GAME
	UAzureScrollList * This = (UAzureScrollList *)Obj;
	Params.ReturnValue = This->GetScrollOffset();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetScrollOffset"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(float*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushnumber(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetOverscrollAmount(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureScrollList",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureScrollList must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float ReturnValue;
	} Params;
#if UE_GAME
	UAzureScrollList * This = (UAzureScrollList *)Obj;
	Params.ReturnValue = This->GetOverscrollAmount();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetOverscrollAmount"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(float*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushnumber(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetItemByWidget(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureScrollList",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureScrollList must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		UWidget* Widget = nullptr;
		int32 Index;
		UUserWidget* ReturnValue = nullptr;
	} Params;
	Params.Widget = (UWidget*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"Widget");;
#if UE_GAME
	UAzureScrollList * This = (UAzureScrollList *)Obj;
	Params.ReturnValue = This->GetItemByWidget(Params.Widget,Params.Index);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetItemByWidget"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(UWidget**)(params.GetStructMemory() + 0) = Params.Widget;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.Widget = *(UWidget**)(params.GetStructMemory() + 0);
		Params.Index = *(int32*)(params.GetStructMemory() + 8);
		Params.ReturnValue = *(UUserWidget**)(params.GetStructMemory() + 16);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Params.ReturnValue);
	lua_pushinteger(InScriptContext, Params.Index);
	return 2;
}

int32 GetItemByIndex(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureScrollList",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureScrollList must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		int32 index;
		UUserWidget* ReturnValue = nullptr;
	} Params;
	Params.index = (luaL_checkint(InScriptContext, 2));
#if UE_GAME
	UAzureScrollList * This = (UAzureScrollList *)Obj;
	Params.ReturnValue = This->GetItemByIndex(Params.index);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetItemByIndex"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(int32*)(params.GetStructMemory() + 0) = Params.index;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.index = *(int32*)(params.GetStructMemory() + 0);
		Params.ReturnValue = *(UUserWidget**)(params.GetStructMemory() + 8);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetIndexByItem(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureScrollList",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureScrollList must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		UUserWidget* Item = nullptr;
		int32 ReturnValue;
	} Params;
	Params.Item = (UUserWidget*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"UserWidget");;
#if UE_GAME
	UAzureScrollList * This = (UAzureScrollList *)Obj;
	Params.ReturnValue = This->GetIndexByItem(Params.Item);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetIndexByItem"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(UUserWidget**)(params.GetStructMemory() + 0) = Params.Item;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.Item = *(UUserWidget**)(params.GetStructMemory() + 0);
		Params.ReturnValue = *(int32*)(params.GetStructMemory() + 8);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushinteger(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetCount(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureScrollList",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureScrollList must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		int32 ReturnValue;
	} Params;
#if UE_GAME
	UAzureScrollList * This = (UAzureScrollList *)Obj;
	Params.ReturnValue = This->GetCount();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetCount"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(int32*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushinteger(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 Get_TemplateClass(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureScrollList",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureScrollList must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzureScrollList::StaticClass(), TEXT("TemplateClass"));
	if(!Property) { check(false); return 0;}
	TSubclassOf<UUserWidget>  PropertyValue = TSubclassOf<UUserWidget> ();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaUtils::ReturnUObject(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_TemplateClass(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureScrollList",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureScrollList must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzureScrollList::StaticClass(), TEXT("TemplateClass"));
	if(!Property) { check(false); return 0;}
	TSubclassOf<UUserWidget>  PropertyValue = (UClass*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"Class");;
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_ItemWidth(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureScrollList",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureScrollList must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzureScrollList::StaticClass(), TEXT("ItemWidth"));
	if(!Property) { check(false); return 0;}
	int32 PropertyValue = int32();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushinteger(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_ItemWidth(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureScrollList",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureScrollList must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzureScrollList::StaticClass(), TEXT("ItemWidth"));
	if(!Property) { check(false); return 0;}
	int32 PropertyValue = (luaL_checkint(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_ItemHeight(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureScrollList",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureScrollList must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzureScrollList::StaticClass(), TEXT("ItemHeight"));
	if(!Property) { check(false); return 0;}
	int32 PropertyValue = int32();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushinteger(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_ItemHeight(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureScrollList",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureScrollList must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzureScrollList::StaticClass(), TEXT("ItemHeight"));
	if(!Property) { check(false); return 0;}
	int32 PropertyValue = (luaL_checkint(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_Segment(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureScrollList",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureScrollList must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzureScrollList::StaticClass(), TEXT("Segment"));
	if(!Property) { check(false); return 0;}
	int32 PropertyValue = int32();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushinteger(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_Segment(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureScrollList",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureScrollList must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzureScrollList::StaticClass(), TEXT("Segment"));
	if(!Property) { check(false); return 0;}
	int32 PropertyValue = (luaL_checkint(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_RowGap(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureScrollList",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureScrollList must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzureScrollList::StaticClass(), TEXT("RowGap"));
	if(!Property) { check(false); return 0;}
	int32 PropertyValue = int32();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushinteger(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_RowGap(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureScrollList",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureScrollList must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzureScrollList::StaticClass(), TEXT("RowGap"));
	if(!Property) { check(false); return 0;}
	int32 PropertyValue = (luaL_checkint(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_ColGap(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureScrollList",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureScrollList must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzureScrollList::StaticClass(), TEXT("ColGap"));
	if(!Property) { check(false); return 0;}
	int32 PropertyValue = int32();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushinteger(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_ColGap(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureScrollList",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureScrollList must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzureScrollList::StaticClass(), TEXT("ColGap"));
	if(!Property) { check(false); return 0;}
	int32 PropertyValue = (luaL_checkint(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bAutoSizeItem(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureScrollList",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureScrollList must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzureScrollList::StaticClass(), TEXT("bAutoSizeItem"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = bool();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bAutoSizeItem(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureScrollList",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureScrollList must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzureScrollList::StaticClass(), TEXT("bAutoSizeItem"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bStretchItem(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureScrollList",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureScrollList must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzureScrollList::StaticClass(), TEXT("bStretchItem"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = bool();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bStretchItem(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureScrollList",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureScrollList must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzureScrollList::StaticClass(), TEXT("bStretchItem"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bTileItem(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureScrollList",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureScrollList must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzureScrollList::StaticClass(), TEXT("bTileItem"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = bool();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bTileItem(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureScrollList",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureScrollList must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzureScrollList::StaticClass(), TEXT("bTileItem"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bAutoSize(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureScrollList",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureScrollList must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzureScrollList::StaticClass(), TEXT("bAutoSize"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = bool();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bAutoSize(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureScrollList",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureScrollList must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzureScrollList::StaticClass(), TEXT("bAutoSize"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_Trim(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureScrollList",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureScrollList must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzureScrollList::StaticClass(), TEXT("Trim"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = bool();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_Trim(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureScrollList",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureScrollList must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzureScrollList::StaticClass(), TEXT("Trim"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bAutoScrollToItem(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureScrollList",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureScrollList must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzureScrollList::StaticClass(), TEXT("bAutoScrollToItem"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = bool();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bAutoScrollToItem(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureScrollList",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureScrollList must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzureScrollList::StaticClass(), TEXT("bAutoScrollToItem"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_autoScrollToItemAnchor(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureScrollList",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureScrollList must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzureScrollList::StaticClass(), TEXT("autoScrollToItemAnchor"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_autoScrollToItemAnchor(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureScrollList",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureScrollList must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzureScrollList::StaticClass(), TEXT("autoScrollToItemAnchor"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_autoScrollToItemCenter(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureScrollList",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureScrollList must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzureScrollList::StaticClass(), TEXT("autoScrollToItemCenter"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = bool();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_autoScrollToItemCenter(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureScrollList",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureScrollList must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzureScrollList::StaticClass(), TEXT("autoScrollToItemCenter"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_ListWidth(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureScrollList",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureScrollList must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzureScrollList::StaticClass(), TEXT("ListWidth"));
	if(!Property) { check(false); return 0;}
	int32 PropertyValue = int32();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushinteger(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_ListWidth(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureScrollList",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureScrollList must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzureScrollList::StaticClass(), TEXT("ListWidth"));
	if(!Property) { check(false); return 0;}
	int32 PropertyValue = (luaL_checkint(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_ListHeight(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureScrollList",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureScrollList must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzureScrollList::StaticClass(), TEXT("ListHeight"));
	if(!Property) { check(false); return 0;}
	int32 PropertyValue = int32();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushinteger(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_ListHeight(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureScrollList",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureScrollList must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzureScrollList::StaticClass(), TEXT("ListHeight"));
	if(!Property) { check(false); return 0;}
	int32 PropertyValue = (luaL_checkint(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_ItemSize(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureScrollList",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureScrollList must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzureScrollList::StaticClass(), TEXT("ItemSize"));
	if(!Property) { check(false); return 0;}
	FVector2D PropertyValue = FVector2D();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaVector2D::Return(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_ItemSize(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureScrollList",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureScrollList must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzureScrollList::StaticClass(), TEXT("ItemSize"));
	if(!Property) { check(false); return 0;}
	FVector2D PropertyValue = (wLua::FLuaVector2D::Get(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_MarginPadding(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureScrollList",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureScrollList must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzureScrollList::StaticClass(), TEXT("MarginPadding"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_bScrollEvent(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureScrollList",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureScrollList must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzureScrollList::StaticClass(), TEXT("bScrollEvent"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = bool();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_bPageView(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureScrollList",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureScrollList must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzureScrollList::StaticClass(), TEXT("bPageView"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = bool();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_PageSize(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureScrollList",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureScrollList must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzureScrollList::StaticClass(), TEXT("PageSize"));
	if(!Property) { check(false); return 0;}
	int32 PropertyValue = int32();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushinteger(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_MinimumInertialVelocity(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureScrollList",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureScrollList must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzureScrollList::StaticClass(), TEXT("MinimumInertialVelocity"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_MinimumInertialVelocity(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureScrollList",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureScrollList must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzureScrollList::StaticClass(), TEXT("MinimumInertialVelocity"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_AnimateScrollVelocity(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureScrollList",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureScrollList must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzureScrollList::StaticClass(), TEXT("AnimateScrollVelocity"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_AnimateScrollVelocity(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureScrollList",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureScrollList must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzureScrollList::StaticClass(), TEXT("AnimateScrollVelocity"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bTriggerBlueprintScrollEvent(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureScrollList",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureScrollList must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzureScrollList::StaticClass(), TEXT("bTriggerBlueprintScrollEvent"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = bool();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_PlayItemAnimationOfName(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureScrollList",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureScrollList must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzureScrollList::StaticClass(), TEXT("PlayItemAnimationOfName"));
	if(!Property) { check(false); return 0;}
	FName PropertyValue = FName();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushstring(InScriptContext, TCHAR_TO_UTF8(*PropertyValue.ToString()));
	return 1;
}

int32 Get_bReverseOrientationX(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureScrollList",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureScrollList must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzureScrollList::StaticClass(), TEXT("bReverseOrientationX"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = bool();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_bReverseOrientationY(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureScrollList",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureScrollList must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzureScrollList::StaticClass(), TEXT("bReverseOrientationY"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = bool();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_bUseGapAnim(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureScrollList",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureScrollList must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzureScrollList::StaticClass(), TEXT("bUseGapAnim"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = bool();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_GapAnimSpeed(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureScrollList",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureScrollList must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzureScrollList::StaticClass(), TEXT("GapAnimSpeed"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_GapAnimStart(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureScrollList",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureScrollList must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzureScrollList::StaticClass(), TEXT("GapAnimStart"));
	if(!Property) { check(false); return 0;}
	TArray<float> PropertyValue;
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	{lua_newtable(InScriptContext); int i = 1; for(auto It = PropertyValue.CreateConstIterator(); It; ++It,++i) {  lua_pushnumber(InScriptContext, (*It)); lua_rawseti(InScriptContext,-2,i);     }  }
	return 1;
}

int32 Get_ScrollTopPadding(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureScrollList",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureScrollList must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzureScrollList::StaticClass(), TEXT("ScrollTopPadding"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_ScrollBotPadding(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureScrollList",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureScrollList must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzureScrollList::StaticClass(), TEXT("ScrollBotPadding"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_bUseTakeTurnAnim(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureScrollList",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureScrollList must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzureScrollList::StaticClass(), TEXT("bUseTakeTurnAnim"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = bool();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_Orientation(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureScrollList",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureScrollList must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzureScrollList::StaticClass(), TEXT("Orientation"));
	if(!Property) { check(false); return 0;}
	TEnumAsByte<EOrientation> PropertyValue = TEnumAsByte<EOrientation>();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushinteger(InScriptContext, (int)PropertyValue);
	return 1;
}

int32 Get_ScrollBarVisibility(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureScrollList",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureScrollList must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzureScrollList::StaticClass(), TEXT("ScrollBarVisibility"));
	if(!Property) { check(false); return 0;}
	ESlateVisibility PropertyValue = ESlateVisibility();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushinteger(InScriptContext, (int)PropertyValue);
	return 1;
}

int32 Get_ScrollBarOffset(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureScrollList",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureScrollList must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzureScrollList::StaticClass(), TEXT("ScrollBarOffset"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_ConsumeMouseWheel(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureScrollList",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureScrollList must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzureScrollList::StaticClass(), TEXT("ConsumeMouseWheel"));
	if(!Property) { check(false); return 0;}
	EConsumeMouseWheel PropertyValue = EConsumeMouseWheel();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushinteger(InScriptContext, (int)PropertyValue);
	return 1;
}

int32 Get_ScrollbarThickness(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureScrollList",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureScrollList must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzureScrollList::StaticClass(), TEXT("ScrollbarThickness"));
	if(!Property) { check(false); return 0;}
	FVector2D PropertyValue = FVector2D();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaVector2D::Return(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_AlwaysShowScrollbar(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureScrollList",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureScrollList must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzureScrollList::StaticClass(), TEXT("AlwaysShowScrollbar"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = bool();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_IsCurveUseItemMiddle(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureScrollList",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureScrollList must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzureScrollList::StaticClass(), TEXT("IsCurveUseItemMiddle"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = bool();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_IsUseCustomOffsetCurve(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureScrollList",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureScrollList must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzureScrollList::StaticClass(), TEXT("IsUseCustomOffsetCurve"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = bool();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_IsUseCustomHorizontalOffsetCurve(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureScrollList",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureScrollList must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzureScrollList::StaticClass(), TEXT("IsUseCustomHorizontalOffsetCurve"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = bool();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_IsUseCustomScaleCurve(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureScrollList",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureScrollList must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzureScrollList::StaticClass(), TEXT("IsUseCustomScaleCurve"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = bool();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_IsUseCustomOpacityCurve(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureScrollList",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureScrollList must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzureScrollList::StaticClass(), TEXT("IsUseCustomOpacityCurve"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = bool();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_IsUseZorderCurve(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureScrollList",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureScrollList must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzureScrollList::StaticClass(), TEXT("IsUseZorderCurve"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = bool();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_bIsNeedCaptureMovementAxisAligned(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureScrollList",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureScrollList must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzureScrollList::StaticClass(), TEXT("bIsNeedCaptureMovementAxisAligned"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = bool();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_ScrollDragTriggerDistance(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureScrollList",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureScrollList must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzureScrollList::StaticClass(), TEXT("ScrollDragTriggerDistance"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_ScrollDragTriggerDistance(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureScrollList",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureScrollList must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzureScrollList::StaticClass(), TEXT("ScrollDragTriggerDistance"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_AllowOverscroll(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureScrollList",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureScrollList must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzureScrollList::StaticClass(), TEXT("AllowOverscroll"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = bool();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_UsePhysicalOverscroll(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureScrollList",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureScrollList must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzureScrollList::StaticClass(), TEXT("UsePhysicalOverscroll"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = bool();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_Looseness(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureScrollList",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureScrollList must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzureScrollList::StaticClass(), TEXT("Looseness"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_OvershootLooseMax(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureScrollList",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureScrollList must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzureScrollList::StaticClass(), TEXT("OvershootLooseMax"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_OvershootBounceRate(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureScrollList",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureScrollList must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzureScrollList::StaticClass(), TEXT("OvershootBounceRate"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_MiddleAnchor(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureScrollList",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureScrollList must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzureScrollList::StaticClass(), TEXT("MiddleAnchor"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Call_OnBPUpdateItem(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureScrollList",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureScrollList must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		UUserWidget* Item = nullptr;
		int32 Index;
	} Params;
	Params.Item = (UUserWidget*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"UserWidget");;
	Params.Index = (luaL_checkint(InScriptContext, 3));
	UAzureScrollList * This = (UAzureScrollList *)Obj;
	This->OnBPUpdateItem.Broadcast(Params.Item,Params.Index);
	return 0;
}

int32 Call_OnBPMiddleItemChange(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureScrollList",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureScrollList must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		UUserWidget* Item = nullptr;
		int32 Index;
	} Params;
	Params.Item = (UUserWidget*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"UserWidget");;
	Params.Index = (luaL_checkint(InScriptContext, 3));
	UAzureScrollList * This = (UAzureScrollList *)Obj;
	This->OnBPMiddleItemChange.Broadcast(Params.Item,Params.Index);
	return 0;
}

int32 Get_CellLength(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureScrollList",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureScrollList must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzureScrollList::StaticClass(), TEXT("CellLength"));
	if(!Property) { check(false); return 0;}
	int32 PropertyValue = int32();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushinteger(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_CellLength(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureScrollList",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureScrollList must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzureScrollList::StaticClass(), TEXT("CellLength"));
	if(!Property) { check(false); return 0;}
	int32 PropertyValue = (luaL_checkint(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_ViewLength(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureScrollList",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureScrollList must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzureScrollList::StaticClass(), TEXT("ViewLength"));
	if(!Property) { check(false); return 0;}
	int32 PropertyValue = int32();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushinteger(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_ViewLength(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureScrollList",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureScrollList must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzureScrollList::StaticClass(), TEXT("ViewLength"));
	if(!Property) { check(false); return 0;}
	int32 PropertyValue = (luaL_checkint(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_GapLength(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureScrollList",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureScrollList must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzureScrollList::StaticClass(), TEXT("GapLength"));
	if(!Property) { check(false); return 0;}
	int32 PropertyValue = int32();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushinteger(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_GapLength(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureScrollList",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureScrollList must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzureScrollList::StaticClass(), TEXT("GapLength"));
	if(!Property) { check(false); return 0;}
	int32 PropertyValue = (luaL_checkint(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_CellCount(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureScrollList",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureScrollList must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzureScrollList::StaticClass(), TEXT("CellCount"));
	if(!Property) { check(false); return 0;}
	int32 PropertyValue = int32();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushinteger(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_CellCount(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureScrollList",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureScrollList must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzureScrollList::StaticClass(), TEXT("CellCount"));
	if(!Property) { check(false); return 0;}
	int32 PropertyValue = (luaL_checkint(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 New(lua_State* InScriptContext)
{
	UObject* Outer = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Object");
	FName Name = FName(luaL_checkstring(InScriptContext, 2));
	UObject* Obj = NewObject<UAzureScrollList>(Outer, Name);
	wLua::FLuaUtils::ReturnUObject(InScriptContext,Obj);
	return 1;
}

int32 Destroy(lua_State* InScriptContext)
{
	return 0;
}

int32 Class(lua_State* InScriptContext)
{
	UClass* Class = UAzureScrollList::StaticClass();
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Class);
	return 1;
}

const luaL_Reg Lib_Funcs[] =
{
	{ "New", New },
	{ "Destroy", Destroy },
	{ "Class", Class },
	{ "TemporarilyShutOffTakeTurnAnim", TemporarilyShutOffTakeTurnAnim },
	{ "SetCount", SetCount },
	{ "ReplyTaketurnAnim", ReplyTaketurnAnim },
	{ "ReplyGapAnim", ReplyGapAnim },
	{ "GetScrollOffset", GetScrollOffset },
	{ "GetOverscrollAmount", GetOverscrollAmount },
	{ "GetItemByWidget", GetItemByWidget },
	{ "GetItemByIndex", GetItemByIndex },
	{ "GetIndexByItem", GetIndexByItem },
	{ "GetCount", GetCount },
	{ "Get_TemplateClass", Get_TemplateClass },
	{ "Set_TemplateClass", Set_TemplateClass },
	{ "Get_ItemWidth", Get_ItemWidth },
	{ "Set_ItemWidth", Set_ItemWidth },
	{ "Get_ItemHeight", Get_ItemHeight },
	{ "Set_ItemHeight", Set_ItemHeight },
	{ "Get_Segment", Get_Segment },
	{ "Set_Segment", Set_Segment },
	{ "Get_RowGap", Get_RowGap },
	{ "Set_RowGap", Set_RowGap },
	{ "Get_ColGap", Get_ColGap },
	{ "Set_ColGap", Set_ColGap },
	{ "Get_bAutoSizeItem", Get_bAutoSizeItem },
	{ "Set_bAutoSizeItem", Set_bAutoSizeItem },
	{ "Get_bStretchItem", Get_bStretchItem },
	{ "Set_bStretchItem", Set_bStretchItem },
	{ "Get_bTileItem", Get_bTileItem },
	{ "Set_bTileItem", Set_bTileItem },
	{ "Get_bAutoSize", Get_bAutoSize },
	{ "Set_bAutoSize", Set_bAutoSize },
	{ "Get_Trim", Get_Trim },
	{ "Set_Trim", Set_Trim },
	{ "Get_bAutoScrollToItem", Get_bAutoScrollToItem },
	{ "Set_bAutoScrollToItem", Set_bAutoScrollToItem },
	{ "Get_autoScrollToItemAnchor", Get_autoScrollToItemAnchor },
	{ "Set_autoScrollToItemAnchor", Set_autoScrollToItemAnchor },
	{ "Get_autoScrollToItemCenter", Get_autoScrollToItemCenter },
	{ "Set_autoScrollToItemCenter", Set_autoScrollToItemCenter },
	{ "Get_ListWidth", Get_ListWidth },
	{ "Set_ListWidth", Set_ListWidth },
	{ "Get_ListHeight", Get_ListHeight },
	{ "Set_ListHeight", Set_ListHeight },
	{ "Get_ItemSize", Get_ItemSize },
	{ "Set_ItemSize", Set_ItemSize },
	{ "Get_MarginPadding", Get_MarginPadding },
	{ "Get_bScrollEvent", Get_bScrollEvent },
	{ "Get_bPageView", Get_bPageView },
	{ "Get_PageSize", Get_PageSize },
	{ "Get_MinimumInertialVelocity", Get_MinimumInertialVelocity },
	{ "Set_MinimumInertialVelocity", Set_MinimumInertialVelocity },
	{ "Get_AnimateScrollVelocity", Get_AnimateScrollVelocity },
	{ "Set_AnimateScrollVelocity", Set_AnimateScrollVelocity },
	{ "Get_bTriggerBlueprintScrollEvent", Get_bTriggerBlueprintScrollEvent },
	{ "Get_PlayItemAnimationOfName", Get_PlayItemAnimationOfName },
	{ "Get_bReverseOrientationX", Get_bReverseOrientationX },
	{ "Get_bReverseOrientationY", Get_bReverseOrientationY },
	{ "Get_bUseGapAnim", Get_bUseGapAnim },
	{ "Get_GapAnimSpeed", Get_GapAnimSpeed },
	{ "Get_GapAnimStart", Get_GapAnimStart },
	{ "Get_ScrollTopPadding", Get_ScrollTopPadding },
	{ "Get_ScrollBotPadding", Get_ScrollBotPadding },
	{ "Get_bUseTakeTurnAnim", Get_bUseTakeTurnAnim },
	{ "Get_Orientation", Get_Orientation },
	{ "Get_ScrollBarVisibility", Get_ScrollBarVisibility },
	{ "Get_ScrollBarOffset", Get_ScrollBarOffset },
	{ "Get_ConsumeMouseWheel", Get_ConsumeMouseWheel },
	{ "Get_ScrollbarThickness", Get_ScrollbarThickness },
	{ "Get_AlwaysShowScrollbar", Get_AlwaysShowScrollbar },
	{ "Get_IsCurveUseItemMiddle", Get_IsCurveUseItemMiddle },
	{ "Get_IsUseCustomOffsetCurve", Get_IsUseCustomOffsetCurve },
	{ "Get_IsUseCustomHorizontalOffsetCurve", Get_IsUseCustomHorizontalOffsetCurve },
	{ "Get_IsUseCustomScaleCurve", Get_IsUseCustomScaleCurve },
	{ "Get_IsUseCustomOpacityCurve", Get_IsUseCustomOpacityCurve },
	{ "Get_IsUseZorderCurve", Get_IsUseZorderCurve },
	{ "Get_bIsNeedCaptureMovementAxisAligned", Get_bIsNeedCaptureMovementAxisAligned },
	{ "Get_ScrollDragTriggerDistance", Get_ScrollDragTriggerDistance },
	{ "Set_ScrollDragTriggerDistance", Set_ScrollDragTriggerDistance },
	{ "Get_AllowOverscroll", Get_AllowOverscroll },
	{ "Get_UsePhysicalOverscroll", Get_UsePhysicalOverscroll },
	{ "Get_Looseness", Get_Looseness },
	{ "Get_OvershootLooseMax", Get_OvershootLooseMax },
	{ "Get_OvershootBounceRate", Get_OvershootBounceRate },
	{ "Get_MiddleAnchor", Get_MiddleAnchor },
	{ "Call_OnBPUpdateItem", Call_OnBPUpdateItem },
	{ "Call_OnBPMiddleItemChange", Call_OnBPMiddleItemChange },
	{ "Get_CellLength", Get_CellLength },
	{ "Set_CellLength", Set_CellLength },
	{ "Get_ViewLength", Get_ViewLength },
	{ "Set_ViewLength", Set_ViewLength },
	{ "Get_GapLength", Get_GapLength },
	{ "Set_GapLength", Set_GapLength },
	{ "Get_CellCount", Get_CellCount },
	{ "Set_CellCount", Set_CellCount },
	{ "setUpdateFunc", setUpdateFunc },
	{ "getItem", getItem },
	{ "setCount", setCount },
	{ "forceUpdate", forceUpdate },
	{ "scrollToBegin", scrollToBegin },
	{ "scrollToEnd", scrollToEnd },
	{ "setFirstIndex", setFirstIndex },
	{ "getFirstIndex", getFirstIndex },
	{ "clear", clear },
	{ "SetFirstIndex", SetFirstIndex },
	{ "ScrollToBegin", ScrollToBegin },
	{ "ScrollToEnd", ScrollToEnd },
	{ "GetFirstIndex", GetFirstIndex },
	{ "ForceUpdate", ForceUpdate },
	{ "setMiddleItemChangeFunc", setMiddleItemChangeFunc },
	{ "Clear", Clear },
	{ "is_nil", wLua::LuaStatic::isnil },
	{ "__gc", wLua::LuaStatic::removeUClassFrameCache },
	{ NULL, NULL }
};

void Register(lua_State *InScriptContext)
{
	lua_newtable(InScriptContext);
	luaL_register(InScriptContext, NULL, Lib_Funcs);
	AzureHelpFuncs::AuxRegister(InScriptContext, "AzureScrollList");
}
void SetMtLink(lua_State *InScriptContext)
{
	AzureHelpFuncs::AuxSetMtLink(InScriptContext, "AzureScrollList", "Widget",USERDATATYPE_UOBJECT);
}

}