#include "Azure.h"
#include "Utility/help_funcs.h"
#include "wLua/UObjectHeaders.h"
#include "MovieSceneSequencePlayer.h"
#include "AzureLuaIntegration.h"

namespace LuaMovieSceneSequencePlayer
{
int32 Stop(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MovieSceneSequencePlayer",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MovieSceneSequencePlayer must be non-null"); lua_error(InScriptContext);  return 0;}
#if UE_GAME
	UMovieSceneSequencePlayer * This = (UMovieSceneSequencePlayer *)Obj;
	This->Stop();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("Stop"));
	if(!Function) { check(false); return 0;}
	Obj->ProcessEvent(Function, NULL);
#endif
	return 0;
}

int32 SetTimeRange(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MovieSceneSequencePlayer",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MovieSceneSequencePlayer must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float StartTime;
		float Duration;
	} Params;
	Params.StartTime = (float)(luaL_checknumber(InScriptContext, 2));
	Params.Duration = (float)(luaL_checknumber(InScriptContext, 3));
#if UE_GAME
	UMovieSceneSequencePlayer * This = (UMovieSceneSequencePlayer *)Obj;
	This->SetTimeRange(Params.StartTime,Params.Duration);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetTimeRange"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(float*)(params.GetStructMemory() + 0) = Params.StartTime;
		*(float*)(params.GetStructMemory() + 4) = Params.Duration;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.StartTime = *(float*)(params.GetStructMemory() + 0);
		Params.Duration = *(float*)(params.GetStructMemory() + 4);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetPlayRate(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MovieSceneSequencePlayer",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MovieSceneSequencePlayer must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float PlayRate;
	} Params;
	Params.PlayRate = (float)(luaL_checknumber(InScriptContext, 2));
#if UE_GAME
	UMovieSceneSequencePlayer * This = (UMovieSceneSequencePlayer *)Obj;
	This->SetPlayRate(Params.PlayRate);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetPlayRate"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(float*)(params.GetStructMemory() + 0) = Params.PlayRate;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.PlayRate = *(float*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetPlaybackRange(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MovieSceneSequencePlayer",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MovieSceneSequencePlayer must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float NewStartTime;
		float NewEndTime;
	} Params;
	Params.NewStartTime = (float)(luaL_checknumber(InScriptContext, 2));
	Params.NewEndTime = (float)(luaL_checknumber(InScriptContext, 3));
#if UE_GAME
	UMovieSceneSequencePlayer * This = (UMovieSceneSequencePlayer *)Obj;
	This->SetPlaybackRange(Params.NewStartTime,Params.NewEndTime);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetPlaybackRange"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(float*)(params.GetStructMemory() + 0) = Params.NewStartTime;
		*(float*)(params.GetStructMemory() + 4) = Params.NewEndTime;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.NewStartTime = *(float*)(params.GetStructMemory() + 0);
		Params.NewEndTime = *(float*)(params.GetStructMemory() + 4);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetPlaybackPosition(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MovieSceneSequencePlayer",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MovieSceneSequencePlayer must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float NewPlaybackPosition;
	} Params;
	Params.NewPlaybackPosition = (float)(luaL_checknumber(InScriptContext, 2));
#if UE_GAME
	UMovieSceneSequencePlayer * This = (UMovieSceneSequencePlayer *)Obj;
	This->SetPlaybackPosition(Params.NewPlaybackPosition);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetPlaybackPosition"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(float*)(params.GetStructMemory() + 0) = Params.NewPlaybackPosition;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.NewPlaybackPosition = *(float*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetFrameRange(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MovieSceneSequencePlayer",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MovieSceneSequencePlayer must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		int32 StartFrame;
		int32 Duration;
	} Params;
	Params.StartFrame = (luaL_checkint(InScriptContext, 2));
	Params.Duration = (luaL_checkint(InScriptContext, 3));
#if UE_GAME
	UMovieSceneSequencePlayer * This = (UMovieSceneSequencePlayer *)Obj;
	This->SetFrameRange(Params.StartFrame,Params.Duration);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetFrameRange"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(int32*)(params.GetStructMemory() + 0) = Params.StartFrame;
		*(int32*)(params.GetStructMemory() + 4) = Params.Duration;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.StartFrame = *(int32*)(params.GetStructMemory() + 0);
		Params.Duration = *(int32*)(params.GetStructMemory() + 4);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetDisableCameraCuts(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MovieSceneSequencePlayer",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MovieSceneSequencePlayer must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool bInDisableCameraCuts;
	} Params;
	Params.bInDisableCameraCuts = !!(lua_toboolean(InScriptContext, 2));
#if UE_GAME
	UMovieSceneSequencePlayer * This = (UMovieSceneSequencePlayer *)Obj;
	This->SetDisableCameraCuts(Params.bInDisableCameraCuts);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetDisableCameraCuts"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(bool*)(params.GetStructMemory() + 0) = Params.bInDisableCameraCuts;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.bInDisableCameraCuts = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 ScrubToSeconds(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MovieSceneSequencePlayer",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MovieSceneSequencePlayer must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float TimeInSeconds;
	} Params;
	Params.TimeInSeconds = (float)(luaL_checknumber(InScriptContext, 2));
#if UE_GAME
	UMovieSceneSequencePlayer * This = (UMovieSceneSequencePlayer *)Obj;
	This->ScrubToSeconds(Params.TimeInSeconds);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("ScrubToSeconds"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(float*)(params.GetStructMemory() + 0) = Params.TimeInSeconds;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.TimeInSeconds = *(float*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 Scrub(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MovieSceneSequencePlayer",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MovieSceneSequencePlayer must be non-null"); lua_error(InScriptContext);  return 0;}
#if UE_GAME
	UMovieSceneSequencePlayer * This = (UMovieSceneSequencePlayer *)Obj;
	This->Scrub();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("Scrub"));
	if(!Function) { check(false); return 0;}
	Obj->ProcessEvent(Function, NULL);
#endif
	return 0;
}

int32 PlayToSeconds(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MovieSceneSequencePlayer",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MovieSceneSequencePlayer must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float TimeInSeconds;
	} Params;
	Params.TimeInSeconds = (float)(luaL_checknumber(InScriptContext, 2));
#if UE_GAME
	UMovieSceneSequencePlayer * This = (UMovieSceneSequencePlayer *)Obj;
	This->PlayToSeconds(Params.TimeInSeconds);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("PlayToSeconds"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(float*)(params.GetStructMemory() + 0) = Params.TimeInSeconds;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.TimeInSeconds = *(float*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 PlayReverse(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MovieSceneSequencePlayer",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MovieSceneSequencePlayer must be non-null"); lua_error(InScriptContext);  return 0;}
#if UE_GAME
	UMovieSceneSequencePlayer * This = (UMovieSceneSequencePlayer *)Obj;
	This->PlayReverse();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("PlayReverse"));
	if(!Function) { check(false); return 0;}
	Obj->ProcessEvent(Function, NULL);
#endif
	return 0;
}

int32 PlayLooping(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MovieSceneSequencePlayer",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MovieSceneSequencePlayer must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		int32 NumLoops;
	} Params;
	Params.NumLoops = lua_isnoneornil(InScriptContext,2) ? int32(-1) : (luaL_checkint(InScriptContext, 2));
#if UE_GAME
	UMovieSceneSequencePlayer * This = (UMovieSceneSequencePlayer *)Obj;
	This->PlayLooping(Params.NumLoops);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("PlayLooping"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(int32*)(params.GetStructMemory() + 0) = Params.NumLoops;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.NumLoops = *(int32*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 Play(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MovieSceneSequencePlayer",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MovieSceneSequencePlayer must be non-null"); lua_error(InScriptContext);  return 0;}
#if UE_GAME
	UMovieSceneSequencePlayer * This = (UMovieSceneSequencePlayer *)Obj;
	This->Play();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("Play"));
	if(!Function) { check(false); return 0;}
	Obj->ProcessEvent(Function, NULL);
#endif
	return 0;
}

int32 Pause(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MovieSceneSequencePlayer",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MovieSceneSequencePlayer must be non-null"); lua_error(InScriptContext);  return 0;}
#if UE_GAME
	UMovieSceneSequencePlayer * This = (UMovieSceneSequencePlayer *)Obj;
	This->Pause();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("Pause"));
	if(!Function) { check(false); return 0;}
	Obj->ProcessEvent(Function, NULL);
#endif
	return 0;
}

int32 JumpToSeconds(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MovieSceneSequencePlayer",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MovieSceneSequencePlayer must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float TimeInSeconds;
	} Params;
	Params.TimeInSeconds = (float)(luaL_checknumber(InScriptContext, 2));
#if UE_GAME
	UMovieSceneSequencePlayer * This = (UMovieSceneSequencePlayer *)Obj;
	This->JumpToSeconds(Params.TimeInSeconds);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("JumpToSeconds"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(float*)(params.GetStructMemory() + 0) = Params.TimeInSeconds;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.TimeInSeconds = *(float*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 JumpToPosition(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MovieSceneSequencePlayer",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MovieSceneSequencePlayer must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float NewPlaybackPosition;
	} Params;
	Params.NewPlaybackPosition = (float)(luaL_checknumber(InScriptContext, 2));
#if UE_GAME
	UMovieSceneSequencePlayer * This = (UMovieSceneSequencePlayer *)Obj;
	This->JumpToPosition(Params.NewPlaybackPosition);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("JumpToPosition"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(float*)(params.GetStructMemory() + 0) = Params.NewPlaybackPosition;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.NewPlaybackPosition = *(float*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 IsReversed(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MovieSceneSequencePlayer",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MovieSceneSequencePlayer must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool ReturnValue;
	} Params;
#if UE_GAME
	UMovieSceneSequencePlayer * This = (UMovieSceneSequencePlayer *)Obj;
	Params.ReturnValue = This->IsReversed();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("IsReversed"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushboolean(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 IsPlaying(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MovieSceneSequencePlayer",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MovieSceneSequencePlayer must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool ReturnValue;
	} Params;
#if UE_GAME
	UMovieSceneSequencePlayer * This = (UMovieSceneSequencePlayer *)Obj;
	Params.ReturnValue = This->IsPlaying();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("IsPlaying"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushboolean(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 IsPaused(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MovieSceneSequencePlayer",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MovieSceneSequencePlayer must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool ReturnValue;
	} Params;
#if UE_GAME
	UMovieSceneSequencePlayer * This = (UMovieSceneSequencePlayer *)Obj;
	Params.ReturnValue = This->IsPaused();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("IsPaused"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushboolean(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GoToEndAndStop(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MovieSceneSequencePlayer",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MovieSceneSequencePlayer must be non-null"); lua_error(InScriptContext);  return 0;}
#if UE_GAME
	UMovieSceneSequencePlayer * This = (UMovieSceneSequencePlayer *)Obj;
	This->GoToEndAndStop();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GoToEndAndStop"));
	if(!Function) { check(false); return 0;}
	Obj->ProcessEvent(Function, NULL);
#endif
	return 0;
}

int32 GetPlayRate(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MovieSceneSequencePlayer",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MovieSceneSequencePlayer must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float ReturnValue;
	} Params;
#if UE_GAME
	UMovieSceneSequencePlayer * This = (UMovieSceneSequencePlayer *)Obj;
	Params.ReturnValue = This->GetPlayRate();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetPlayRate"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(float*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushnumber(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetPlaybackStart(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MovieSceneSequencePlayer",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MovieSceneSequencePlayer must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float ReturnValue;
	} Params;
#if UE_GAME
	UMovieSceneSequencePlayer * This = (UMovieSceneSequencePlayer *)Obj;
	Params.ReturnValue = This->GetPlaybackStart();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetPlaybackStart"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(float*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushnumber(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetPlaybackPosition(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MovieSceneSequencePlayer",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MovieSceneSequencePlayer must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float ReturnValue;
	} Params;
#if UE_GAME
	UMovieSceneSequencePlayer * This = (UMovieSceneSequencePlayer *)Obj;
	Params.ReturnValue = This->GetPlaybackPosition();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetPlaybackPosition"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(float*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushnumber(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetPlaybackEnd(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MovieSceneSequencePlayer",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MovieSceneSequencePlayer must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float ReturnValue;
	} Params;
#if UE_GAME
	UMovieSceneSequencePlayer * This = (UMovieSceneSequencePlayer *)Obj;
	Params.ReturnValue = This->GetPlaybackEnd();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetPlaybackEnd"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(float*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushnumber(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetLength(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MovieSceneSequencePlayer",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MovieSceneSequencePlayer must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float ReturnValue;
	} Params;
#if UE_GAME
	UMovieSceneSequencePlayer * This = (UMovieSceneSequencePlayer *)Obj;
	Params.ReturnValue = This->GetLength();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetLength"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(float*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushnumber(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetFrameDuration(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MovieSceneSequencePlayer",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MovieSceneSequencePlayer must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		int32 ReturnValue;
	} Params;
#if UE_GAME
	UMovieSceneSequencePlayer * This = (UMovieSceneSequencePlayer *)Obj;
	Params.ReturnValue = This->GetFrameDuration();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetFrameDuration"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(int32*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushinteger(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetDisableCameraCuts(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MovieSceneSequencePlayer",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MovieSceneSequencePlayer must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool ReturnValue;
	} Params;
#if UE_GAME
	UMovieSceneSequencePlayer * This = (UMovieSceneSequencePlayer *)Obj;
	Params.ReturnValue = This->GetDisableCameraCuts();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetDisableCameraCuts"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushboolean(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 ChangePlaybackDirection(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MovieSceneSequencePlayer",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MovieSceneSequencePlayer must be non-null"); lua_error(InScriptContext);  return 0;}
#if UE_GAME
	UMovieSceneSequencePlayer * This = (UMovieSceneSequencePlayer *)Obj;
	This->ChangePlaybackDirection();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("ChangePlaybackDirection"));
	if(!Function) { check(false); return 0;}
	Obj->ProcessEvent(Function, NULL);
#endif
	return 0;
}

int32 Call_OnPlay(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MovieSceneSequencePlayer",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MovieSceneSequencePlayer must be non-null"); lua_error(InScriptContext);  return 0;}
	UMovieSceneSequencePlayer * This = (UMovieSceneSequencePlayer *)Obj;
	This->OnPlay.Broadcast();
	return 0;
}

int32 Call_OnPlayReverse(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MovieSceneSequencePlayer",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MovieSceneSequencePlayer must be non-null"); lua_error(InScriptContext);  return 0;}
	UMovieSceneSequencePlayer * This = (UMovieSceneSequencePlayer *)Obj;
	This->OnPlayReverse.Broadcast();
	return 0;
}

int32 Call_OnStop(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MovieSceneSequencePlayer",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MovieSceneSequencePlayer must be non-null"); lua_error(InScriptContext);  return 0;}
	UMovieSceneSequencePlayer * This = (UMovieSceneSequencePlayer *)Obj;
	This->OnStop.Broadcast();
	return 0;
}

int32 Call_OnPause(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MovieSceneSequencePlayer",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MovieSceneSequencePlayer must be non-null"); lua_error(InScriptContext);  return 0;}
	UMovieSceneSequencePlayer * This = (UMovieSceneSequencePlayer *)Obj;
	This->OnPause.Broadcast();
	return 0;
}

int32 Call_OnFinished(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MovieSceneSequencePlayer",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MovieSceneSequencePlayer must be non-null"); lua_error(InScriptContext);  return 0;}
	UMovieSceneSequencePlayer * This = (UMovieSceneSequencePlayer *)Obj;
	This->OnFinished.Broadcast();
	return 0;
}

int32 Class(lua_State* InScriptContext)
{
	UClass* Class = UMovieSceneSequencePlayer::StaticClass();
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Class);
	return 1;
}

const luaL_Reg Lib_Funcs[] =
{
	{ "Class", Class },
	{ "Stop", Stop },
	{ "SetTimeRange", SetTimeRange },
	{ "SetPlayRate", SetPlayRate },
	{ "SetPlaybackRange", SetPlaybackRange },
	{ "SetPlaybackPosition", SetPlaybackPosition },
	{ "SetFrameRange", SetFrameRange },
	{ "SetDisableCameraCuts", SetDisableCameraCuts },
	{ "ScrubToSeconds", ScrubToSeconds },
	{ "Scrub", Scrub },
	{ "PlayToSeconds", PlayToSeconds },
	{ "PlayReverse", PlayReverse },
	{ "PlayLooping", PlayLooping },
	{ "Play", Play },
	{ "Pause", Pause },
	{ "JumpToSeconds", JumpToSeconds },
	{ "JumpToPosition", JumpToPosition },
	{ "IsReversed", IsReversed },
	{ "IsPlaying", IsPlaying },
	{ "IsPaused", IsPaused },
	{ "GoToEndAndStop", GoToEndAndStop },
	{ "GetPlayRate", GetPlayRate },
	{ "GetPlaybackStart", GetPlaybackStart },
	{ "GetPlaybackPosition", GetPlaybackPosition },
	{ "GetPlaybackEnd", GetPlaybackEnd },
	{ "GetLength", GetLength },
	{ "GetFrameDuration", GetFrameDuration },
	{ "GetDisableCameraCuts", GetDisableCameraCuts },
	{ "ChangePlaybackDirection", ChangePlaybackDirection },
	{ "Call_OnPlay", Call_OnPlay },
	{ "Call_OnPlayReverse", Call_OnPlayReverse },
	{ "Call_OnStop", Call_OnStop },
	{ "Call_OnPause", Call_OnPause },
	{ "Call_OnFinished", Call_OnFinished },
	{ "is_nil", wLua::LuaStatic::isnil },
	{ "__gc", wLua::LuaStatic::removeUClassFrameCache },
	{ NULL, NULL }
};

void Register(lua_State *InScriptContext)
{
	lua_newtable(InScriptContext);
	luaL_register(InScriptContext, NULL, Lib_Funcs);
	AzureHelpFuncs::AuxRegister(InScriptContext, "MovieSceneSequencePlayer");
}
void SetMtLink(lua_State *InScriptContext)
{
	AzureHelpFuncs::AuxSetMtLink(InScriptContext, "MovieSceneSequencePlayer", "Object",USERDATATYPE_UOBJECT);
}

}