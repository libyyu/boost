#include "Azure.h"
#include "Utility/help_funcs.h"
#include "wLua/UObjectHeaders.h"
#include "GameLogic/Environment/AzureEnvironmentManager.h"
#include "../UClassHeaders.h"
#include "AzureLuaIntegration.h"

namespace LuaAzureEnvironmentManager
{
int32 ApplyImmediate(lua_State*);
int32 Set_TickInterval(lua_State*);

int32 TickSimuWindAzureComps(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float DeltaTime;
	} Params;
	Params.DeltaTime = (float)(luaL_checknumber(InScriptContext, 2));
#if UE_GAME
	AAzureEnvironmentManager * This = (AAzureEnvironmentManager *)Obj;
	This->TickSimuWindAzureComps(Params.DeltaTime);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("TickSimuWindAzureComps"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(float*)(params.GetStructMemory() + 0) = Params.DeltaTime;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.DeltaTime = *(float*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 TickHighFrequency(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float DeltaTime;
	} Params;
	Params.DeltaTime = (float)(luaL_checknumber(InScriptContext, 2));
#if UE_GAME
	AAzureEnvironmentManager * This = (AAzureEnvironmentManager *)Obj;
	This->TickHighFrequency(Params.DeltaTime);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("TickHighFrequency"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(float*)(params.GetStructMemory() + 0) = Params.DeltaTime;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.DeltaTime = *(float*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 RemoveSimuWindAzureComp(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		UAzureObjectComponent* Comp = nullptr;
	} Params;
	Params.Comp = (UAzureObjectComponent*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"AzureObjectComponent");;
#if UE_GAME
	AAzureEnvironmentManager * This = (AAzureEnvironmentManager *)Obj;
	This->RemoveSimuWindAzureComp(Params.Comp);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("RemoveSimuWindAzureComp"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(UAzureObjectComponent**)(params.GetStructMemory() + 0) = Params.Comp;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.Comp = *(UAzureObjectComponent**)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 PushTransition(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		UAzureEnvironmentTransition* Transition = nullptr;
	} Params;
	Params.Transition = (UAzureEnvironmentTransition*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"AzureEnvironmentTransition");;
#if UE_GAME
	AAzureEnvironmentManager * This = (AAzureEnvironmentManager *)Obj;
	This->PushTransition(Params.Transition);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("PushTransition"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(UAzureEnvironmentTransition**)(params.GetStructMemory() + 0) = Params.Transition;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.Transition = *(UAzureEnvironmentTransition**)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 PushPreset(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		UAzureEnvironmentPreset* Preset = nullptr;
		float Duration;
		bool bDelay;
	} Params;
	Params.Preset = (UAzureEnvironmentPreset*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"AzureEnvironmentPreset");;
	Params.Duration = (float)(luaL_checknumber(InScriptContext, 3));
	Params.bDelay = lua_isnoneornil(InScriptContext,4) ? bool(false) : !!(lua_toboolean(InScriptContext, 4));
#if UE_GAME
	AAzureEnvironmentManager * This = (AAzureEnvironmentManager *)Obj;
	This->PushPreset(Params.Preset,Params.Duration,Params.bDelay);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("PushPreset"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(UAzureEnvironmentPreset**)(params.GetStructMemory() + 0) = Params.Preset;
		*(float*)(params.GetStructMemory() + 8) = Params.Duration;
		*(bool*)(params.GetStructMemory() + 12) = Params.bDelay;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.Preset = *(UAzureEnvironmentPreset**)(params.GetStructMemory() + 0);
		Params.Duration = *(float*)(params.GetStructMemory() + 8);
		Params.bDelay = *(bool*)(params.GetStructMemory() + 12);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 PopTransition(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		UAzureEnvironmentTransition* Transition = nullptr;
	} Params;
	Params.Transition = (UAzureEnvironmentTransition*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"AzureEnvironmentTransition");;
#if UE_GAME
	AAzureEnvironmentManager * This = (AAzureEnvironmentManager *)Obj;
	This->PopTransition(Params.Transition);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("PopTransition"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(UAzureEnvironmentTransition**)(params.GetStructMemory() + 0) = Params.Transition;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.Transition = *(UAzureEnvironmentTransition**)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 PopPreset(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		UAzureEnvironmentPreset* Preset = nullptr;
		float Duration;
		bool bDelay;
	} Params;
	Params.Preset = (UAzureEnvironmentPreset*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"AzureEnvironmentPreset");;
	Params.Duration = (float)(luaL_checknumber(InScriptContext, 3));
	Params.bDelay = lua_isnoneornil(InScriptContext,4) ? bool(false) : !!(lua_toboolean(InScriptContext, 4));
#if UE_GAME
	AAzureEnvironmentManager * This = (AAzureEnvironmentManager *)Obj;
	This->PopPreset(Params.Preset,Params.Duration,Params.bDelay);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("PopPreset"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(UAzureEnvironmentPreset**)(params.GetStructMemory() + 0) = Params.Preset;
		*(float*)(params.GetStructMemory() + 8) = Params.Duration;
		*(bool*)(params.GetStructMemory() + 12) = Params.bDelay;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.Preset = *(UAzureEnvironmentPreset**)(params.GetStructMemory() + 0);
		Params.Duration = *(float*)(params.GetStructMemory() + 8);
		Params.bDelay = *(bool*)(params.GetStructMemory() + 12);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 OnParameterChanged(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float DeltaTime;
	} Params;
	Params.DeltaTime = (float)(luaL_checknumber(InScriptContext, 2));
#if UE_GAME
	AAzureEnvironmentManager * This = (AAzureEnvironmentManager *)Obj;
	This->OnParameterChanged(Params.DeltaTime);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("OnParameterChanged"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(float*)(params.GetStructMemory() + 0) = Params.DeltaTime;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.DeltaTime = *(float*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 InitShootingstar(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
#if UE_GAME
	AAzureEnvironmentManager * This = (AAzureEnvironmentManager *)Obj;
	This->InitShootingstar();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("InitShootingstar"));
	if(!Function) { check(false); return 0;}
	Obj->ProcessEvent(Function, NULL);
#endif
	return 0;
}

int32 InitRainBow(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
#if UE_GAME
	AAzureEnvironmentManager * This = (AAzureEnvironmentManager *)Obj;
	This->InitRainBow();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("InitRainBow"));
	if(!Function) { check(false); return 0;}
	Obj->ProcessEvent(Function, NULL);
#endif
	return 0;
}

int32 InitComet(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
#if UE_GAME
	AAzureEnvironmentManager * This = (AAzureEnvironmentManager *)Obj;
	This->InitComet();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("InitComet"));
	if(!Function) { check(false); return 0;}
	Obj->ProcessEvent(Function, NULL);
#endif
	return 0;
}

int32 InitAurora(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
#if UE_GAME
	AAzureEnvironmentManager * This = (AAzureEnvironmentManager *)Obj;
	This->InitAurora();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("InitAurora"));
	if(!Function) { check(false); return 0;}
	Obj->ProcessEvent(Function, NULL);
#endif
	return 0;
}

int32 InitAllRainBow(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
#if UE_GAME
	AAzureEnvironmentManager * This = (AAzureEnvironmentManager *)Obj;
	This->InitAllRainBow();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("InitAllRainBow"));
	if(!Function) { check(false); return 0;}
	Obj->ProcessEvent(Function, NULL);
#endif
	return 0;
}

int32 InitAllAurora(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
#if UE_GAME
	AAzureEnvironmentManager * This = (AAzureEnvironmentManager *)Obj;
	This->InitAllAurora();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("InitAllAurora"));
	if(!Function) { check(false); return 0;}
	Obj->ProcessEvent(Function, NULL);
#endif
	return 0;
}

int32 GetWeather(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		int32 ReturnValue;
	} Params;
#if UE_GAME
	AAzureEnvironmentManager * This = (AAzureEnvironmentManager *)Obj;
	Params.ReturnValue = This->GetWeather();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetWeather"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(int32*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushinteger(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetPreset(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		TSubclassOf<UAzureEnvironmentPreset>  Class;
		UAzureEnvironmentPreset* ReturnValue = nullptr;
	} Params;
	Params.Class = (UClass*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"Class");;
#if UE_GAME
	AAzureEnvironmentManager * This = (AAzureEnvironmentManager *)Obj;
	Params.ReturnValue = This->GetPreset(Params.Class);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetPreset"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(TSubclassOf<UAzureEnvironmentPreset> *)(params.GetStructMemory() + 0) = Params.Class;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.Class = *(TSubclassOf<UAzureEnvironmentPreset> *)(params.GetStructMemory() + 0);
		Params.ReturnValue = *(UAzureEnvironmentPreset**)(params.GetStructMemory() + 8);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetActivePreset(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		UAzureEnvironmentPreset* ReturnValue = nullptr;
	} Params;
#if UE_GAME
	AAzureEnvironmentManager * This = (AAzureEnvironmentManager *)Obj;
	Params.ReturnValue = This->GetActivePreset();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetActivePreset"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(UAzureEnvironmentPreset**)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 DumpPreset(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		int32 id;
	} Params;
	Params.id = (luaL_checkint(InScriptContext, 2));
#if UE_GAME
	AAzureEnvironmentManager * This = (AAzureEnvironmentManager *)Obj;
	This->DumpPreset(Params.id);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("DumpPreset"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(int32*)(params.GetStructMemory() + 0) = Params.id;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.id = *(int32*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 Dump(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
#if UE_GAME
	AAzureEnvironmentManager * This = (AAzureEnvironmentManager *)Obj;
	This->Dump();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("Dump"));
	if(!Function) { check(false); return 0;}
	Obj->ProcessEvent(Function, NULL);
#endif
	return 0;
}

int32 Deactive(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
#if UE_GAME
	AAzureEnvironmentManager * This = (AAzureEnvironmentManager *)Obj;
	This->Deactive();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("Deactive"));
	if(!Function) { check(false); return 0;}
	Obj->ProcessEvent(Function, NULL);
#endif
	return 0;
}

int32 ClearSimuWindAzureComps(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
#if UE_GAME
	AAzureEnvironmentManager * This = (AAzureEnvironmentManager *)Obj;
	This->ClearSimuWindAzureComps();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("ClearSimuWindAzureComps"));
	if(!Function) { check(false); return 0;}
	Obj->ProcessEvent(Function, NULL);
#endif
	return 0;
}

int32 ChangeWeather(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		int32 Index;
	} Params;
	Params.Index = (luaL_checkint(InScriptContext, 2));
#if UE_GAME
	AAzureEnvironmentManager * This = (AAzureEnvironmentManager *)Obj;
	This->ChangeWeather(Params.Index);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("ChangeWeather"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(int32*)(params.GetStructMemory() + 0) = Params.Index;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.Index = *(int32*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 AddSimuWindAzureComp(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		UAzureObjectComponent* Comp = nullptr;
	} Params;
	Params.Comp = (UAzureObjectComponent*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"AzureObjectComponent");;
#if UE_GAME
	AAzureEnvironmentManager * This = (AAzureEnvironmentManager *)Obj;
	This->AddSimuWindAzureComp(Params.Comp);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("AddSimuWindAzureComp"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(UAzureObjectComponent**)(params.GetStructMemory() + 0) = Params.Comp;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.Comp = *(UAzureObjectComponent**)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 Active(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
#if UE_GAME
	AAzureEnvironmentManager * This = (AAzureEnvironmentManager *)Obj;
	This->Active();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("Active"));
	if(!Function) { check(false); return 0;}
	Obj->ProcessEvent(Function, NULL);
#endif
	return 0;
}

int32 Get_CameraLocation(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("CameraLocation"));
	if(!Property) { check(false); return 0;}
	FVector PropertyValue = FVector();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaVector::Return(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_CameraLocation(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("CameraLocation"));
	if(!Property) { check(false); return 0;}
	FVector PropertyValue = (wLua::FLuaVector::Get(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_CameraRotation(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("CameraRotation"));
	if(!Property) { check(false); return 0;}
	FRotator PropertyValue = FRotator();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaRotator::Return(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_CameraRotation(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("CameraRotation"));
	if(!Property) { check(false); return 0;}
	FRotator PropertyValue = (wLua::FLuaRotator::Get(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_TimeOfDay(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("TimeOfDay"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_TimeOfDay(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("TimeOfDay"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_TimeScale(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("TimeScale"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_TimeScale(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("TimeScale"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_EditingPreset(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("EditingPreset"));
	if(!Property) { check(false); return 0;}
	TSubclassOf<UAzureEnvironmentPreset>  PropertyValue = TSubclassOf<UAzureEnvironmentPreset> ();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaUtils::ReturnUObject(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_EditingPreset(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("EditingPreset"));
	if(!Property) { check(false); return 0;}
	TSubclassOf<UAzureEnvironmentPreset>  PropertyValue = (UClass*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"Class");;
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bBakePreview(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("bBakePreview"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = bool();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bBakePreview(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("bBakePreview"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bEnable(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("bEnable"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = bool();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bEnable(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("bEnable"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bUpdate(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("bUpdate"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = bool();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bUpdate(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("bUpdate"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bApply(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("bApply"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = bool();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bApply(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("bApply"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bIsPhotoMode(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("bIsPhotoMode"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = bool();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bIsPhotoMode(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("bIsPhotoMode"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_Sky(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("Sky"));
	if(!Property) { check(false); return 0;}
	AAzureRefSky* PropertyValue;
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaUtils::ReturnUObject(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_Sky(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("Sky"));
	if(!Property) { check(false); return 0;}
	AAzureRefSky* PropertyValue = (AAzureRefSky*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"AzureRefSky");;
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_Fog(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("Fog"));
	if(!Property) { check(false); return 0;}
	AExponentialHeightFog* PropertyValue;
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaUtils::ReturnUObject(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_Fog(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("Fog"));
	if(!Property) { check(false); return 0;}
	AExponentialHeightFog* PropertyValue = (AExponentialHeightFog*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"ExponentialHeightFog");;
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_UnderWaterFog(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("UnderWaterFog"));
	if(!Property) { check(false); return 0;}
	AExponentialHeightFog* PropertyValue;
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaUtils::ReturnUObject(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_UnderWaterFog(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("UnderWaterFog"));
	if(!Property) { check(false); return 0;}
	AExponentialHeightFog* PropertyValue = (AExponentialHeightFog*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"ExponentialHeightFog");;
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_SunFlare(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("SunFlare"));
	if(!Property) { check(false); return 0;}
	AAzureLensFlare* PropertyValue;
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaUtils::ReturnUObject(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_SunFlare(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("SunFlare"));
	if(!Property) { check(false); return 0;}
	AAzureLensFlare* PropertyValue = (AAzureLensFlare*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"AzureLensFlare");;
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bUpdateLightDirection(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("bUpdateLightDirection"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = bool();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bUpdateLightDirection(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("bUpdateLightDirection"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_SunLightSource(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("SunLightSource"));
	if(!Property) { check(false); return 0;}
	TArray<ADirectionalLight*> PropertyValue;
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	{lua_newtable(InScriptContext); int i = 1; for(auto It = PropertyValue.CreateConstIterator(); It; ++It,++i) {  wLua::FLuaUtils::ReturnUObject(InScriptContext, (*It)); lua_rawseti(InScriptContext,-2,i);     }  }
	return 1;
}

int32 Set_SunLightSource(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("SunLightSource"));
	if(!Property) { check(false); return 0;}
	TArray<ADirectionalLight*> PropertyValue = [](lua_State * _InScriptContext){ TArray<ADirectionalLight*> ret; lua_pushnil(_InScriptContext); while(lua_next(_InScriptContext,2)!=0){ ADirectionalLight* item = (ADirectionalLight*)wLua::FLuaUtils::GetUObject(_InScriptContext,-1,"DirectionalLight");; ret.Add(item); lua_pop(_InScriptContext,1);  } return ret; }(InScriptContext);;
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_MoonLightSource(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("MoonLightSource"));
	if(!Property) { check(false); return 0;}
	ADirectionalLight* PropertyValue;
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaUtils::ReturnUObject(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_MoonLightSource(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("MoonLightSource"));
	if(!Property) { check(false); return 0;}
	ADirectionalLight* PropertyValue = (ADirectionalLight*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"DirectionalLight");;
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bWindTestMode(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("bWindTestMode"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = bool();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bWindTestMode(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("bWindTestMode"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_WindSource(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("WindSource"));
	if(!Property) { check(false); return 0;}
	AWindDirectionalSource* PropertyValue;
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaUtils::ReturnUObject(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_WindSource(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("WindSource"));
	if(!Property) { check(false); return 0;}
	AWindDirectionalSource* PropertyValue = (AWindDirectionalSource*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"WindDirectionalSource");;
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_WindForceMulCurve(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("WindForceMulCurve"));
	if(!Property) { check(false); return 0;}
	UCurveFloat* PropertyValue;
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaUtils::ReturnUObject(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_WindForceMulCurve(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("WindForceMulCurve"));
	if(!Property) { check(false); return 0;}
	UCurveFloat* PropertyValue = (UCurveFloat*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"CurveFloat");;
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_WindForceAddCurve(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("WindForceAddCurve"));
	if(!Property) { check(false); return 0;}
	UCurveFloat* PropertyValue;
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaUtils::ReturnUObject(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_WindForceAddCurve(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("WindForceAddCurve"));
	if(!Property) { check(false); return 0;}
	UCurveFloat* PropertyValue = (UCurveFloat*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"CurveFloat");;
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_GrassBlockInMap(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("GrassBlockInMap"));
	if(!Property) { check(false); return 0;}
	int32 PropertyValue = int32();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushinteger(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_GrassBlockInMap(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("GrassBlockInMap"));
	if(!Property) { check(false); return 0;}
	int32 PropertyValue = (luaL_checkint(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_PostProcessVolumesBloom(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("PostProcessVolumesBloom"));
	if(!Property) { check(false); return 0;}
	TArray<APostProcessVolume*> PropertyValue;
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	{lua_newtable(InScriptContext); int i = 1; for(auto It = PropertyValue.CreateConstIterator(); It; ++It,++i) {  wLua::FLuaUtils::ReturnUObject(InScriptContext, (*It)); lua_rawseti(InScriptContext,-2,i);     }  }
	return 1;
}

int32 Set_PostProcessVolumesBloom(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("PostProcessVolumesBloom"));
	if(!Property) { check(false); return 0;}
	TArray<APostProcessVolume*> PropertyValue = [](lua_State * _InScriptContext){ TArray<APostProcessVolume*> ret; lua_pushnil(_InScriptContext); while(lua_next(_InScriptContext,2)!=0){ APostProcessVolume* item = (APostProcessVolume*)wLua::FLuaUtils::GetUObject(_InScriptContext,-1,"PostProcessVolume");; ret.Add(item); lua_pop(_InScriptContext,1);  } return ret; }(InScriptContext);;
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_PostProcessVolumesIndirectLight(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("PostProcessVolumesIndirectLight"));
	if(!Property) { check(false); return 0;}
	TArray<APostProcessVolume*> PropertyValue;
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	{lua_newtable(InScriptContext); int i = 1; for(auto It = PropertyValue.CreateConstIterator(); It; ++It,++i) {  wLua::FLuaUtils::ReturnUObject(InScriptContext, (*It)); lua_rawseti(InScriptContext,-2,i);     }  }
	return 1;
}

int32 Set_PostProcessVolumesIndirectLight(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("PostProcessVolumesIndirectLight"));
	if(!Property) { check(false); return 0;}
	TArray<APostProcessVolume*> PropertyValue = [](lua_State * _InScriptContext){ TArray<APostProcessVolume*> ret; lua_pushnil(_InScriptContext); while(lua_next(_InScriptContext,2)!=0){ APostProcessVolume* item = (APostProcessVolume*)wLua::FLuaUtils::GetUObject(_InScriptContext,-1,"PostProcessVolume");; ret.Add(item); lua_pop(_InScriptContext,1);  } return ret; }(InScriptContext);;
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_PostProcessVolumesPostColor(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("PostProcessVolumesPostColor"));
	if(!Property) { check(false); return 0;}
	TArray<APostProcessVolume*> PropertyValue;
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	{lua_newtable(InScriptContext); int i = 1; for(auto It = PropertyValue.CreateConstIterator(); It; ++It,++i) {  wLua::FLuaUtils::ReturnUObject(InScriptContext, (*It)); lua_rawseti(InScriptContext,-2,i);     }  }
	return 1;
}

int32 Set_PostProcessVolumesPostColor(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("PostProcessVolumesPostColor"));
	if(!Property) { check(false); return 0;}
	TArray<APostProcessVolume*> PropertyValue = [](lua_State * _InScriptContext){ TArray<APostProcessVolume*> ret; lua_pushnil(_InScriptContext); while(lua_next(_InScriptContext,2)!=0){ APostProcessVolume* item = (APostProcessVolume*)wLua::FLuaUtils::GetUObject(_InScriptContext,-1,"PostProcessVolume");; ret.Add(item); lua_pop(_InScriptContext,1);  } return ret; }(InScriptContext);;
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_DefaultPreset(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("DefaultPreset"));
	if(!Property) { check(false); return 0;}
	TSubclassOf<UAzureEnvironmentPreset>  PropertyValue = TSubclassOf<UAzureEnvironmentPreset> ();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaUtils::ReturnUObject(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_DefaultPreset(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("DefaultPreset"));
	if(!Property) { check(false); return 0;}
	TSubclassOf<UAzureEnvironmentPreset>  PropertyValue = (UClass*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"Class");;
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_WeatherPresets(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("WeatherPresets"));
	if(!Property) { check(false); return 0;}
	TArray<TSubclassOf<UAzureEnvironmentPreset> > PropertyValue;
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	{lua_newtable(InScriptContext); int i = 1; for(auto It = PropertyValue.CreateConstIterator(); It; ++It,++i) {  wLua::FLuaUtils::ReturnUObject(InScriptContext, (*It)); lua_rawseti(InScriptContext,-2,i);     }  }
	return 1;
}

int32 Set_WeatherPresets(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("WeatherPresets"));
	if(!Property) { check(false); return 0;}
	TArray<TSubclassOf<UAzureEnvironmentPreset> > PropertyValue = [](lua_State * _InScriptContext){ TArray<TSubclassOf<UAzureEnvironmentPreset> > ret; lua_pushnil(_InScriptContext); while(lua_next(_InScriptContext,2)!=0){ TSubclassOf<UAzureEnvironmentPreset>  item = (UClass*)wLua::FLuaUtils::GetUObject(_InScriptContext,-1,"Class");; ret.Add(item); lua_pop(_InScriptContext,1);  } return ret; }(InScriptContext);;
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_SkyUpperColor(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("SkyUpperColor"));
	if(!Property) { check(false); return 0;}
	FLinearColor PropertyValue = FLinearColor();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaLinearColor::Return(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_SkyUpperColor(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("SkyUpperColor"));
	if(!Property) { check(false); return 0;}
	FLinearColor PropertyValue = (wLua::FLuaLinearColor::Get(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_SkyLowerColor(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("SkyLowerColor"));
	if(!Property) { check(false); return 0;}
	FLinearColor PropertyValue = FLinearColor();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaLinearColor::Return(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_SkyLowerColor(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("SkyLowerColor"));
	if(!Property) { check(false); return 0;}
	FLinearColor PropertyValue = (wLua::FLuaLinearColor::Get(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_SkyFogDensity(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("SkyFogDensity"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_SkyFogDensity(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("SkyFogDensity"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_SkyLightBrightness(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("SkyLightBrightness"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_SkyLightBrightness(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("SkyLightBrightness"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_HorizonTilt(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("HorizonTilt"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_HorizonTilt(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("HorizonTilt"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_HorizonFalloff(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("HorizonFalloff"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_HorizonFalloff(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("HorizonFalloff"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_Saturation(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("Saturation"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_Saturation(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("Saturation"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_SunZenith(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("SunZenith"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_SunZenith(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("SunZenith"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_SunAzimuth(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("SunAzimuth"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_SunAzimuth(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("SunAzimuth"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_SunRadius(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("SunRadius"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_SunRadius(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("SunRadius"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_SunShine(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("SunShine"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_SunShine(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("SunShine"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_SunColor(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("SunColor"));
	if(!Property) { check(false); return 0;}
	FLinearColor PropertyValue = FLinearColor();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaLinearColor::Return(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_SunColor(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("SunColor"));
	if(!Property) { check(false); return 0;}
	FLinearColor PropertyValue = (wLua::FLuaLinearColor::Get(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bUseSunPS(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("bUseSunPS"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = bool();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bUseSunPS(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("bUseSunPS"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_SunPSThreshold(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("SunPSThreshold"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_SunPSThreshold(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("SunPSThreshold"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_PS_SunTemplate(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("PS_SunTemplate"));
	if(!Property) { check(false); return 0;}
	UParticleSystem* PropertyValue;
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaUtils::ReturnUObject(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_PS_SunTemplate(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("PS_SunTemplate"));
	if(!Property) { check(false); return 0;}
	UParticleSystem* PropertyValue = (UParticleSystem*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"ParticleSystem");;
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_SunEffectScale(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("SunEffectScale"));
	if(!Property) { check(false); return 0;}
	FVector PropertyValue = FVector();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaVector::Return(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_SunEffectScale(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("SunEffectScale"));
	if(!Property) { check(false); return 0;}
	FVector PropertyValue = (wLua::FLuaVector::Get(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_SunEffectOffset(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("SunEffectOffset"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_SunEffectOffset(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("SunEffectOffset"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_UseLightShaft(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("UseLightShaft"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_UseLightShaft(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("UseLightShaft"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_LightShaftScale(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("LightShaftScale"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_LightShaftScale(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("LightShaftScale"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_LightShaftTint(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("LightShaftTint"));
	if(!Property) { check(false); return 0;}
	FLinearColor PropertyValue = FLinearColor();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaLinearColor::Return(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_LightShaftTint(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("LightShaftTint"));
	if(!Property) { check(false); return 0;}
	FLinearColor PropertyValue = (wLua::FLuaLinearColor::Get(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_SunTemperature(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("SunTemperature"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_SunTemperature(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("SunTemperature"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_SunTemperature2(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("SunTemperature2"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_SunTemperature2(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("SunTemperature2"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_SunExternalIntensity(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("SunExternalIntensity"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_SunExternalIntensity(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("SunExternalIntensity"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_SunExternalIntensity2(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("SunExternalIntensity2"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_SunExternalIntensity2(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("SunExternalIntensity2"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_SpecularIBLScale(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("SpecularIBLScale"));
	if(!Property) { check(false); return 0;}
	FLinearColor PropertyValue = FLinearColor();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaLinearColor::Return(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_SpecularIBLScale(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("SpecularIBLScale"));
	if(!Property) { check(false); return 0;}
	FLinearColor PropertyValue = (wLua::FLuaLinearColor::Get(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_MoonZenith(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("MoonZenith"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_MoonZenith(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("MoonZenith"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_MoonAzimuth(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("MoonAzimuth"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_MoonAzimuth(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("MoonAzimuth"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_MoonRadius(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("MoonRadius"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_MoonRadius(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("MoonRadius"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_MoonShine(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("MoonShine"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_MoonShine(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("MoonShine"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_MoonColor(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("MoonColor"));
	if(!Property) { check(false); return 0;}
	FLinearColor PropertyValue = FLinearColor();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaLinearColor::Return(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_MoonColor(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("MoonColor"));
	if(!Property) { check(false); return 0;}
	FLinearColor PropertyValue = (wLua::FLuaLinearColor::Get(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_MoonBrightness(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("MoonBrightness"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_MoonBrightness(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("MoonBrightness"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_MoonLightDir(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("MoonLightDir"));
	if(!Property) { check(false); return 0;}
	FLinearColor PropertyValue = FLinearColor();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaLinearColor::Return(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_MoonLightDir(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("MoonLightDir"));
	if(!Property) { check(false); return 0;}
	FLinearColor PropertyValue = (wLua::FLuaLinearColor::Get(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_Moon2Zenith(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("Moon2Zenith"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_Moon2Zenith(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("Moon2Zenith"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_Moon2Azimuth(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("Moon2Azimuth"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_Moon2Azimuth(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("Moon2Azimuth"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_Moon2Radius(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("Moon2Radius"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_Moon2Radius(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("Moon2Radius"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_Moon2Shine(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("Moon2Shine"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_Moon2Shine(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("Moon2Shine"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_Moon2Color(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("Moon2Color"));
	if(!Property) { check(false); return 0;}
	FLinearColor PropertyValue = FLinearColor();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaLinearColor::Return(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_Moon2Color(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("Moon2Color"));
	if(!Property) { check(false); return 0;}
	FLinearColor PropertyValue = (wLua::FLuaLinearColor::Get(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_Moon2Brightness(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("Moon2Brightness"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_Moon2Brightness(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("Moon2Brightness"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_Moon2LightDir(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("Moon2LightDir"));
	if(!Property) { check(false); return 0;}
	FLinearColor PropertyValue = FLinearColor();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaLinearColor::Return(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_Moon2LightDir(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("Moon2LightDir"));
	if(!Property) { check(false); return 0;}
	FLinearColor PropertyValue = (wLua::FLuaLinearColor::Get(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_Moon3Zenith(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("Moon3Zenith"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_Moon3Zenith(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("Moon3Zenith"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_Moon3Azimuth(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("Moon3Azimuth"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_Moon3Azimuth(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("Moon3Azimuth"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_Moon3Radius(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("Moon3Radius"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_Moon3Radius(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("Moon3Radius"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_Moon3Shine(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("Moon3Shine"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_Moon3Shine(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("Moon3Shine"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_Moon3Color(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("Moon3Color"));
	if(!Property) { check(false); return 0;}
	FLinearColor PropertyValue = FLinearColor();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaLinearColor::Return(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_Moon3Color(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("Moon3Color"));
	if(!Property) { check(false); return 0;}
	FLinearColor PropertyValue = (wLua::FLuaLinearColor::Get(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_Moon3Brightness(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("Moon3Brightness"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_Moon3Brightness(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("Moon3Brightness"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_Moon3LightDir(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("Moon3LightDir"));
	if(!Property) { check(false); return 0;}
	FLinearColor PropertyValue = FLinearColor();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaLinearColor::Return(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_Moon3LightDir(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("Moon3LightDir"));
	if(!Property) { check(false); return 0;}
	FLinearColor PropertyValue = (wLua::FLuaLinearColor::Get(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_Moon4Zenith(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("Moon4Zenith"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_Moon4Zenith(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("Moon4Zenith"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_Moon4Azimuth(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("Moon4Azimuth"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_Moon4Azimuth(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("Moon4Azimuth"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_Moon4Radius(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("Moon4Radius"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_Moon4Radius(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("Moon4Radius"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_Moon4Shine(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("Moon4Shine"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_Moon4Shine(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("Moon4Shine"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_Moon4Color(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("Moon4Color"));
	if(!Property) { check(false); return 0;}
	FLinearColor PropertyValue = FLinearColor();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaLinearColor::Return(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_Moon4Color(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("Moon4Color"));
	if(!Property) { check(false); return 0;}
	FLinearColor PropertyValue = (wLua::FLuaLinearColor::Get(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_Moon4Brightness(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("Moon4Brightness"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_Moon4Brightness(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("Moon4Brightness"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_Moon4LightDir(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("Moon4LightDir"));
	if(!Property) { check(false); return 0;}
	FLinearColor PropertyValue = FLinearColor();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaLinearColor::Return(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_Moon4LightDir(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("Moon4LightDir"));
	if(!Property) { check(false); return 0;}
	FLinearColor PropertyValue = (wLua::FLuaLinearColor::Get(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bUseMoonPS(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("bUseMoonPS"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = bool();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bUseMoonPS(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("bUseMoonPS"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_MoonPSThreshold(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("MoonPSThreshold"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_MoonPSThreshold(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("MoonPSThreshold"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_PS_MoonTemplate(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("PS_MoonTemplate"));
	if(!Property) { check(false); return 0;}
	UParticleSystem* PropertyValue;
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaUtils::ReturnUObject(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_PS_MoonTemplate(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("PS_MoonTemplate"));
	if(!Property) { check(false); return 0;}
	UParticleSystem* PropertyValue = (UParticleSystem*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"ParticleSystem");;
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_MoonEffectScale(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("MoonEffectScale"));
	if(!Property) { check(false); return 0;}
	FVector PropertyValue = FVector();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaVector::Return(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_MoonEffectScale(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("MoonEffectScale"));
	if(!Property) { check(false); return 0;}
	FVector PropertyValue = (wLua::FLuaVector::Get(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_MoonEffectOffset(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("MoonEffectOffset"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_MoonEffectOffset(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("MoonEffectOffset"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_MoonTemperature(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("MoonTemperature"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_MoonTemperature(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("MoonTemperature"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_MoonExternalIntensity(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("MoonExternalIntensity"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_MoonExternalIntensity(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("MoonExternalIntensity"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_StarBrightness(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("StarBrightness"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_StarBrightness(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("StarBrightness"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_StarColor(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("StarColor"));
	if(!Property) { check(false); return 0;}
	FLinearColor PropertyValue = FLinearColor();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaLinearColor::Return(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_StarColor(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("StarColor"));
	if(!Property) { check(false); return 0;}
	FLinearColor PropertyValue = (wLua::FLuaLinearColor::Get(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_StarHeightThreshold(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("StarHeightThreshold"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_StarHeightThreshold(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("StarHeightThreshold"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_StarLerpWidth(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("StarLerpWidth"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_StarLerpWidth(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("StarLerpWidth"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_GalaxyScale(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("GalaxyScale"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_GalaxyScale(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("GalaxyScale"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_GalaxyRotationAngle(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("GalaxyRotationAngle"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_GalaxyRotationAngle(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("GalaxyRotationAngle"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_GalaxyIntensity(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("GalaxyIntensity"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_GalaxyIntensity(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("GalaxyIntensity"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_CloudsDensity(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("CloudsDensity"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_CloudsDensity(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("CloudsDensity"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_CloudsTranslucent(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("CloudsTranslucent"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_CloudsTranslucent(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("CloudsTranslucent"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_CloudsScale(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("CloudsScale"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_CloudsScale(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("CloudsScale"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_CloudsHardness(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("CloudsHardness"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_CloudsHardness(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("CloudsHardness"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_CloudsBlend(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("CloudsBlend"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_CloudsBlend(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("CloudsBlend"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_CloudsDistortion(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("CloudsDistortion"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_CloudsDistortion(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("CloudsDistortion"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_CloudsScattering(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("CloudsScattering"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_CloudsScattering(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("CloudsScattering"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_CloudsAmbient(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("CloudsAmbient"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_CloudsAmbient(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("CloudsAmbient"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_CloudsShadowSize(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("CloudsShadowSize"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_CloudsShadowSize(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("CloudsShadowSize"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_CloudsShadowSoft(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("CloudsShadowSoft"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_CloudsShadowSoft(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("CloudsShadowSoft"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_CloudsHorizonDensity(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("CloudsHorizonDensity"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_CloudsHorizonDensity(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("CloudsHorizonDensity"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_CloudsHorizonAlpha(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("CloudsHorizonAlpha"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_CloudsHorizonAlpha(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("CloudsHorizonAlpha"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_CloudsHorizonScattering(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("CloudsHorizonScattering"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_CloudsHorizonScattering(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("CloudsHorizonScattering"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_CloudsUpperColor(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("CloudsUpperColor"));
	if(!Property) { check(false); return 0;}
	FLinearColor PropertyValue = FLinearColor();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaLinearColor::Return(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_CloudsUpperColor(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("CloudsUpperColor"));
	if(!Property) { check(false); return 0;}
	FLinearColor PropertyValue = (wLua::FLuaLinearColor::Get(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_CloudsUpperBrightness(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("CloudsUpperBrightness"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_CloudsUpperBrightness(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("CloudsUpperBrightness"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_CloudsLowerColor(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("CloudsLowerColor"));
	if(!Property) { check(false); return 0;}
	FLinearColor PropertyValue = FLinearColor();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaLinearColor::Return(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_CloudsLowerColor(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("CloudsLowerColor"));
	if(!Property) { check(false); return 0;}
	FLinearColor PropertyValue = (wLua::FLuaLinearColor::Get(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_CloudsLowerBrightness(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("CloudsLowerBrightness"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_CloudsLowerBrightness(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("CloudsLowerBrightness"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_CloudsBackgroundColor(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("CloudsBackgroundColor"));
	if(!Property) { check(false); return 0;}
	FLinearColor PropertyValue = FLinearColor();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaLinearColor::Return(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_CloudsBackgroundColor(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("CloudsBackgroundColor"));
	if(!Property) { check(false); return 0;}
	FLinearColor PropertyValue = (wLua::FLuaLinearColor::Get(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_CloudsBackgroundBrightness(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("CloudsBackgroundBrightness"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_CloudsBackgroundBrightness(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("CloudsBackgroundBrightness"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_CloudLayersScale(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("CloudLayersScale"));
	if(!Property) { check(false); return 0;}
	FLinearColor PropertyValue = FLinearColor();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaLinearColor::Return(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_CloudLayersScale(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("CloudLayersScale"));
	if(!Property) { check(false); return 0;}
	FLinearColor PropertyValue = (wLua::FLuaLinearColor::Get(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_FarHorizonCloudsLowerColor(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("FarHorizonCloudsLowerColor"));
	if(!Property) { check(false); return 0;}
	FLinearColor PropertyValue = FLinearColor();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaLinearColor::Return(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_FarHorizonCloudsLowerColor(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("FarHorizonCloudsLowerColor"));
	if(!Property) { check(false); return 0;}
	FLinearColor PropertyValue = (wLua::FLuaLinearColor::Get(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_FarHorizonCloudsUpperColor(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("FarHorizonCloudsUpperColor"));
	if(!Property) { check(false); return 0;}
	FLinearColor PropertyValue = FLinearColor();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaLinearColor::Return(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_FarHorizonCloudsUpperColor(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("FarHorizonCloudsUpperColor"));
	if(!Property) { check(false); return 0;}
	FLinearColor PropertyValue = (wLua::FLuaLinearColor::Get(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_FarHorizonCloudsSpeed(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("FarHorizonCloudsSpeed"));
	if(!Property) { check(false); return 0;}
	FLinearColor PropertyValue = FLinearColor();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaLinearColor::Return(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_FarHorizonCloudsSpeed(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("FarHorizonCloudsSpeed"));
	if(!Property) { check(false); return 0;}
	FLinearColor PropertyValue = (wLua::FLuaLinearColor::Get(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_FarHorizonCloudsMaxOpacity(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("FarHorizonCloudsMaxOpacity"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_FarHorizonCloudsMaxOpacity(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("FarHorizonCloudsMaxOpacity"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_FarHorizonClouds1TilingOffset(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("FarHorizonClouds1TilingOffset"));
	if(!Property) { check(false); return 0;}
	FLinearColor PropertyValue = FLinearColor();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaLinearColor::Return(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_FarHorizonClouds1TilingOffset(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("FarHorizonClouds1TilingOffset"));
	if(!Property) { check(false); return 0;}
	FLinearColor PropertyValue = (wLua::FLuaLinearColor::Get(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_FarHorizonClouds2TilingOffset(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("FarHorizonClouds2TilingOffset"));
	if(!Property) { check(false); return 0;}
	FLinearColor PropertyValue = FLinearColor();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaLinearColor::Return(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_FarHorizonClouds2TilingOffset(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("FarHorizonClouds2TilingOffset"));
	if(!Property) { check(false); return 0;}
	FLinearColor PropertyValue = (wLua::FLuaLinearColor::Get(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_FarHorizonCloudsTex(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("FarHorizonCloudsTex"));
	if(!Property) { check(false); return 0;}
	UTexture2D* PropertyValue;
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaUtils::ReturnUObject(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_FarHorizonCloudsTex(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("FarHorizonCloudsTex"));
	if(!Property) { check(false); return 0;}
	UTexture2D* PropertyValue = (UTexture2D*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"Texture2D");;
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_FogHeight(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("FogHeight"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_FogHeight(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("FogHeight"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_FogColor(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("FogColor"));
	if(!Property) { check(false); return 0;}
	FLinearColor PropertyValue = FLinearColor();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaLinearColor::Return(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_FogColor(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("FogColor"));
	if(!Property) { check(false); return 0;}
	FLinearColor PropertyValue = (wLua::FLuaLinearColor::Get(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_FogDensity(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("FogDensity"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_FogDensity(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("FogDensity"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_FogDensityOffset(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("FogDensityOffset"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_FogDensityOffset(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("FogDensityOffset"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_FogDensityScale(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("FogDensityScale"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_FogDensityScale(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("FogDensityScale"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_FogStartDistance(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("FogStartDistance"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_FogStartDistance(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("FogStartDistance"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_FogStartDistanceScale(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("FogStartDistanceScale"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_FogStartDistanceScale(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("FogStartDistanceScale"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_FogStartDistanceOffset(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("FogStartDistanceOffset"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_FogStartDistanceOffset(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("FogStartDistanceOffset"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_FogHeightFalloff(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("FogHeightFalloff"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_FogHeightFalloff(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("FogHeightFalloff"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_FogHeightFalloffScale(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("FogHeightFalloffScale"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_FogHeightFalloffScale(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("FogHeightFalloffScale"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_FogHeightFalloffOffset(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("FogHeightFalloffOffset"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_FogHeightFalloffOffset(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("FogHeightFalloffOffset"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_FogDirInscatteringExponent(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("FogDirInscatteringExponent"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_FogDirInscatteringExponent(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("FogDirInscatteringExponent"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_FogDirInscatteringStartDist(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("FogDirInscatteringStartDist"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_FogDirInscatteringStartDist(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("FogDirInscatteringStartDist"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_FogDirInscatteringColor(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("FogDirInscatteringColor"));
	if(!Property) { check(false); return 0;}
	FLinearColor PropertyValue = FLinearColor();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaLinearColor::Return(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_FogDirInscatteringColor(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("FogDirInscatteringColor"));
	if(!Property) { check(false); return 0;}
	FLinearColor PropertyValue = (wLua::FLuaLinearColor::Get(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_FogMaxOpacity(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("FogMaxOpacity"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_FogMaxOpacity(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("FogMaxOpacity"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_FogInscatteringDirection(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("FogInscatteringDirection"));
	if(!Property) { check(false); return 0;}
	FVector PropertyValue = FVector();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaVector::Return(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_FogInscatteringDirection(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("FogInscatteringDirection"));
	if(!Property) { check(false); return 0;}
	FVector PropertyValue = (wLua::FLuaVector::Get(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_EnableUnderWaterFog(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("EnableUnderWaterFog"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = bool();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_EnableUnderWaterFog(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("EnableUnderWaterFog"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_UnderWaterFogHeight(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("UnderWaterFogHeight"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_UnderWaterFogHeight(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("UnderWaterFogHeight"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_UnderWaterFogDensity(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("UnderWaterFogDensity"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_UnderWaterFogDensity(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("UnderWaterFogDensity"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_UnderWaterFogStartDistance(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("UnderWaterFogStartDistance"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_UnderWaterFogStartDistance(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("UnderWaterFogStartDistance"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_UnderWaterFogHeightFalloff(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("UnderWaterFogHeightFalloff"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_UnderWaterFogHeightFalloff(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("UnderWaterFogHeightFalloff"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_UnderWaterFogDirInscatteringColor(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("UnderWaterFogDirInscatteringColor"));
	if(!Property) { check(false); return 0;}
	FLinearColor PropertyValue = FLinearColor();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaLinearColor::Return(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_UnderWaterFogDirInscatteringColor(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("UnderWaterFogDirInscatteringColor"));
	if(!Property) { check(false); return 0;}
	FLinearColor PropertyValue = (wLua::FLuaLinearColor::Get(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_FogScaleMap(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("FogScaleMap"));
	if(!Property) { check(false); return 0;}
	UTextureRenderTarget2D* PropertyValue;
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaUtils::ReturnUObject(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_FogScaleMap(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("FogScaleMap"));
	if(!Property) { check(false); return 0;}
	UTextureRenderTarget2D* PropertyValue = (UTextureRenderTarget2D*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"TextureRenderTarget2D");;
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_WindIntensity(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("WindIntensity"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_WindIntensity(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("WindIntensity"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_WindSpeed(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("WindSpeed"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_WindSpeed(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("WindSpeed"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_WindStrength(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("WindStrength"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_WindStrength(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("WindStrength"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_WindMinGustAmount(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("WindMinGustAmount"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_WindMinGustAmount(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("WindMinGustAmount"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_WindMaxGustAmount(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("WindMaxGustAmount"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_WindMaxGustAmount(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("WindMaxGustAmount"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_WindDirection(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("WindDirection"));
	if(!Property) { check(false); return 0;}
	FVector PropertyValue = FVector();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaVector::Return(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_WindDirection(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("WindDirection"));
	if(!Property) { check(false); return 0;}
	FVector PropertyValue = (wLua::FLuaVector::Get(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_WindDisturbance(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("WindDisturbance"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_WindDisturbance(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("WindDisturbance"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_WindDirectionDisturbance(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("WindDirectionDisturbance"));
	if(!Property) { check(false); return 0;}
	FVector PropertyValue = FVector();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaVector::Return(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_WindDirectionDisturbance(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("WindDirectionDisturbance"));
	if(!Property) { check(false); return 0;}
	FVector PropertyValue = (wLua::FLuaVector::Get(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bUnderShelter(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("bUnderShelter"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = bool();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bUnderShelter(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("bUnderShelter"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_RainIntensity(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("RainIntensity"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_RainIntensity(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("RainIntensity"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_RainRoughnessScale(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("RainRoughnessScale"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_RainRoughnessScale(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("RainRoughnessScale"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_RippleIntensity(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("RippleIntensity"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_RippleIntensity(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("RippleIntensity"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_RippleUVScale(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("RippleUVScale"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_RippleUVScale(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("RippleUVScale"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_RippleTimeScale(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("RippleTimeScale"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_RippleTimeScale(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("RippleTimeScale"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_PuddleDepthScale(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("PuddleDepthScale"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_PuddleDepthScale(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("PuddleDepthScale"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_PuddleWavesNormalIntensity(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("PuddleWavesNormalIntensity"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_PuddleWavesNormalIntensity(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("PuddleWavesNormalIntensity"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_PuddleWavesTimeScale(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("PuddleWavesTimeScale"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_PuddleWavesTimeScale(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("PuddleWavesTimeScale"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_PuddleWavesUVScale(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("PuddleWavesUVScale"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_PuddleWavesUVScale(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("PuddleWavesUVScale"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_SnowIntensity(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("SnowIntensity"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_SnowIntensity(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("SnowIntensity"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_SnowSide(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("SnowSide"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_SnowSide(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("SnowSide"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_SnowSmooth(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("SnowSmooth"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_SnowSmooth(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("SnowSmooth"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_SnowRoughnessScale(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("SnowRoughnessScale"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_SnowRoughnessScale(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("SnowRoughnessScale"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_SnowThreshold(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("SnowThreshold"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_SnowThreshold(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("SnowThreshold"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_SnowMaskAmount(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("SnowMaskAmount"));
	if(!Property) { check(false); return 0;}
	FLinearColor PropertyValue = FLinearColor();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaLinearColor::Return(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_SnowMaskAmount(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("SnowMaskAmount"));
	if(!Property) { check(false); return 0;}
	FLinearColor PropertyValue = (wLua::FLuaLinearColor::Get(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_SnowDirection(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("SnowDirection"));
	if(!Property) { check(false); return 0;}
	FVector PropertyValue = FVector();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaVector::Return(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_SnowDirection(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("SnowDirection"));
	if(!Property) { check(false); return 0;}
	FVector PropertyValue = (wLua::FLuaVector::Get(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_GrassColorMap(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("GrassColorMap"));
	if(!Property) { check(false); return 0;}
	UTextureRenderTarget2D* PropertyValue;
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaUtils::ReturnUObject(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_GrassColorMap(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("GrassColorMap"));
	if(!Property) { check(false); return 0;}
	UTextureRenderTarget2D* PropertyValue = (UTextureRenderTarget2D*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"TextureRenderTarget2D");;
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_LightningIntensity(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("LightningIntensity"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_LightningIntensity(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("LightningIntensity"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_LightningRate(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("LightningRate"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_LightningRate(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("LightningRate"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_LightningHeight(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("LightningHeight"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_LightningHeight(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("LightningHeight"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bLightning(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("bLightning"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = bool();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bLightning(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("bLightning"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_LightningBrightnessScale(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("LightningBrightnessScale"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_LightningBrightnessScale(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("LightningBrightnessScale"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_FogDirInscatteringColorLightningScale(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("FogDirInscatteringColorLightningScale"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_FogDirInscatteringColorLightningScale(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("FogDirInscatteringColorLightningScale"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_BloomIntensity(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("BloomIntensity"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_BloomIntensity(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("BloomIntensity"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_BloomThreshold(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("BloomThreshold"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_BloomThreshold(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("BloomThreshold"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_BloomIntensityWithToneMapping(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("BloomIntensityWithToneMapping"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_BloomIntensityWithToneMapping(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("BloomIntensityWithToneMapping"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_BloomThresholdWithToneMapping(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("BloomThresholdWithToneMapping"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_BloomThresholdWithToneMapping(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("BloomThresholdWithToneMapping"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bUseLensFlare(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("bUseLensFlare"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = bool();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bUseLensFlare(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("bUseLensFlare"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_WorldLayerDepth(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("WorldLayerDepth"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_WorldLayerDepth(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("WorldLayerDepth"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_WorldLayerFog(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("WorldLayerFog"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_WorldLayerFog(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("WorldLayerFog"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_WorldLayerColor(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("WorldLayerColor"));
	if(!Property) { check(false); return 0;}
	FLinearColor PropertyValue = FLinearColor();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaLinearColor::Return(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_WorldLayerColor(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("WorldLayerColor"));
	if(!Property) { check(false); return 0;}
	FLinearColor PropertyValue = (wLua::FLuaLinearColor::Get(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_WorldRotationSpeed(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("WorldRotationSpeed"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_WorldRotationSpeed(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("WorldRotationSpeed"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_CharacterDirectLightScale(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("CharacterDirectLightScale"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_CharacterDirectLightScale(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("CharacterDirectLightScale"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_CharacterIndirectLightScale(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("CharacterIndirectLightScale"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_CharacterIndirectLightScale(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("CharacterIndirectLightScale"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_CharacterIndirectLightColor(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("CharacterIndirectLightColor"));
	if(!Property) { check(false); return 0;}
	FLinearColor PropertyValue = FLinearColor();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaLinearColor::Return(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_CharacterIndirectLightColor(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("CharacterIndirectLightColor"));
	if(!Property) { check(false); return 0;}
	FLinearColor PropertyValue = (wLua::FLuaLinearColor::Get(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_ShouldCopyDataFromSkin(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("ShouldCopyDataFromSkin"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = bool();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_ShouldCopyDataFromSkin(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("ShouldCopyDataFromSkin"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_CharacterEquipDirectLightScale(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("CharacterEquipDirectLightScale"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_CharacterEquipDirectLightScale(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("CharacterEquipDirectLightScale"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_CharacterEquipIndirectLightScale(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("CharacterEquipIndirectLightScale"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_CharacterEquipIndirectLightScale(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("CharacterEquipIndirectLightScale"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_CharacterEquipIndirectLightColor(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("CharacterEquipIndirectLightColor"));
	if(!Property) { check(false); return 0;}
	FLinearColor PropertyValue = FLinearColor();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaLinearColor::Return(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_CharacterEquipIndirectLightColor(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("CharacterEquipIndirectLightColor"));
	if(!Property) { check(false); return 0;}
	FLinearColor PropertyValue = (wLua::FLuaLinearColor::Get(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_CharacterTemperatureMax(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("CharacterTemperatureMax"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_CharacterTemperatureMax(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("CharacterTemperatureMax"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_IndirectLightColor(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("IndirectLightColor"));
	if(!Property) { check(false); return 0;}
	FLinearColor PropertyValue = FLinearColor();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaLinearColor::Return(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_IndirectLightColor(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("IndirectLightColor"));
	if(!Property) { check(false); return 0;}
	FLinearColor PropertyValue = (wLua::FLuaLinearColor::Get(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_IndirectLightIntensity(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("IndirectLightIntensity"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_IndirectLightIntensity(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("IndirectLightIntensity"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_PointLightIntensity(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("PointLightIntensity"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_PointLightIntensity(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("PointLightIntensity"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_NightEmissivePositive(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("NightEmissivePositive"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_NightEmissivePositive(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("NightEmissivePositive"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_NightEmissiveNegative(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("NightEmissiveNegative"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_NightEmissiveNegative(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("NightEmissiveNegative"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_PostForegroundColorScale(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("PostForegroundColorScale"));
	if(!Property) { check(false); return 0;}
	FLinearColor PropertyValue = FLinearColor();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaLinearColor::Return(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_PostForegroundColorScale(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("PostForegroundColorScale"));
	if(!Property) { check(false); return 0;}
	FLinearColor PropertyValue = (wLua::FLuaLinearColor::Get(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_PostBackgroundColorScale(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("PostBackgroundColorScale"));
	if(!Property) { check(false); return 0;}
	FLinearColor PropertyValue = FLinearColor();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaLinearColor::Return(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_PostBackgroundColorScale(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("PostBackgroundColorScale"));
	if(!Property) { check(false); return 0;}
	FLinearColor PropertyValue = (wLua::FLuaLinearColor::Get(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_UseShootingstar(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("UseShootingstar"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = bool();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_UseShootingstar(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("UseShootingstar"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_PS_ShootingStarTemplate(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("PS_ShootingStarTemplate"));
	if(!Property) { check(false); return 0;}
	UParticleSystem* PropertyValue;
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaUtils::ReturnUObject(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_PS_ShootingStarTemplate(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("PS_ShootingStarTemplate"));
	if(!Property) { check(false); return 0;}
	UParticleSystem* PropertyValue = (UParticleSystem*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"ParticleSystem");;
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_ShootingStarTransform(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("ShootingStarTransform"));
	if(!Property) { check(false); return 0;}
	FTransform PropertyValue = FTransform();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaTransform::Return(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_ShootingStarTransform(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("ShootingStarTransform"));
	if(!Property) { check(false); return 0;}
	FTransform PropertyValue = (wLua::FLuaTransform::Get(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_ShootingStarThreshold(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("ShootingStarThreshold"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_ShootingStarThreshold(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("ShootingStarThreshold"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_UseComet(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("UseComet"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = bool();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_UseComet(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("UseComet"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_PS_CometTemplate(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("PS_CometTemplate"));
	if(!Property) { check(false); return 0;}
	UParticleSystem* PropertyValue;
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaUtils::ReturnUObject(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_PS_CometTemplate(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("PS_CometTemplate"));
	if(!Property) { check(false); return 0;}
	UParticleSystem* PropertyValue = (UParticleSystem*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"ParticleSystem");;
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_CometTransform(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("CometTransform"));
	if(!Property) { check(false); return 0;}
	FTransform PropertyValue = FTransform();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaTransform::Return(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_CometTransform(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("CometTransform"));
	if(!Property) { check(false); return 0;}
	FTransform PropertyValue = (wLua::FLuaTransform::Get(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_CometThreshold(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("CometThreshold"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_CometThreshold(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("CometThreshold"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_UseAurora(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("UseAurora"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = bool();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_UseAurora(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("UseAurora"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_AuroraTranslucent(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("AuroraTranslucent"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_AuroraTranslucent(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("AuroraTranslucent"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_AuroraClass(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("AuroraClass"));
	if(!Property) { check(false); return 0;}
	TSubclassOf<AStaticMeshActor>  PropertyValue = TSubclassOf<AStaticMeshActor> ();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaUtils::ReturnUObject(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_AuroraClass(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("AuroraClass"));
	if(!Property) { check(false); return 0;}
	TSubclassOf<AStaticMeshActor>  PropertyValue = (UClass*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"Class");;
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_SM_AuroraSimple(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("SM_AuroraSimple"));
	if(!Property) { check(false); return 0;}
	UStaticMesh* PropertyValue;
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaUtils::ReturnUObject(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_SM_AuroraSimple(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("SM_AuroraSimple"));
	if(!Property) { check(false); return 0;}
	UStaticMesh* PropertyValue = (UStaticMesh*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"StaticMesh");;
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_SM_AuroraComplex(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("SM_AuroraComplex"));
	if(!Property) { check(false); return 0;}
	UStaticMesh* PropertyValue;
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaUtils::ReturnUObject(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_SM_AuroraComplex(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("SM_AuroraComplex"));
	if(!Property) { check(false); return 0;}
	UStaticMesh* PropertyValue = (UStaticMesh*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"StaticMesh");;
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_SM_AuroraSpiral(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("SM_AuroraSpiral"));
	if(!Property) { check(false); return 0;}
	UStaticMesh* PropertyValue;
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaUtils::ReturnUObject(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_SM_AuroraSpiral(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("SM_AuroraSpiral"));
	if(!Property) { check(false); return 0;}
	UStaticMesh* PropertyValue = (UStaticMesh*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"StaticMesh");;
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_AuroraSimpleTransform(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("AuroraSimpleTransform"));
	if(!Property) { check(false); return 0;}
	FTransform PropertyValue = FTransform();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaTransform::Return(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_AuroraSimpleTransform(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("AuroraSimpleTransform"));
	if(!Property) { check(false); return 0;}
	FTransform PropertyValue = (wLua::FLuaTransform::Get(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_AuroraComplexTransform(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("AuroraComplexTransform"));
	if(!Property) { check(false); return 0;}
	FTransform PropertyValue = FTransform();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaTransform::Return(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_AuroraComplexTransform(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("AuroraComplexTransform"));
	if(!Property) { check(false); return 0;}
	FTransform PropertyValue = (wLua::FLuaTransform::Get(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_AuroraSpiralTransform(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("AuroraSpiralTransform"));
	if(!Property) { check(false); return 0;}
	FTransform PropertyValue = FTransform();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaTransform::Return(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_AuroraSpiralTransform(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("AuroraSpiralTransform"));
	if(!Property) { check(false); return 0;}
	FTransform PropertyValue = (wLua::FLuaTransform::Get(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_UseRainBow(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("UseRainBow"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = bool();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_UseRainBow(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("UseRainBow"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_SM_RainBowSmall(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("SM_RainBowSmall"));
	if(!Property) { check(false); return 0;}
	UStaticMesh* PropertyValue;
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaUtils::ReturnUObject(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_SM_RainBowSmall(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("SM_RainBowSmall"));
	if(!Property) { check(false); return 0;}
	UStaticMesh* PropertyValue = (UStaticMesh*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"StaticMesh");;
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_SM_RainBowLarge(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("SM_RainBowLarge"));
	if(!Property) { check(false); return 0;}
	UStaticMesh* PropertyValue;
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaUtils::ReturnUObject(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_SM_RainBowLarge(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("SM_RainBowLarge"));
	if(!Property) { check(false); return 0;}
	UStaticMesh* PropertyValue = (UStaticMesh*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"StaticMesh");;
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_SmallRainBowTransform(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("SmallRainBowTransform"));
	if(!Property) { check(false); return 0;}
	FTransform PropertyValue = FTransform();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaTransform::Return(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_SmallRainBowTransform(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("SmallRainBowTransform"));
	if(!Property) { check(false); return 0;}
	FTransform PropertyValue = (wLua::FLuaTransform::Get(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_LargeRainBowTransform(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("LargeRainBowTransform"));
	if(!Property) { check(false); return 0;}
	FTransform PropertyValue = FTransform();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaTransform::Return(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_LargeRainBowTransform(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("LargeRainBowTransform"));
	if(!Property) { check(false); return 0;}
	FTransform PropertyValue = (wLua::FLuaTransform::Get(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_RainBowTranslucent(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("RainBowTranslucent"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_RainBowTranslucent(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(AAzureEnvironmentManager::StaticClass(), TEXT("RainBowTranslucent"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 New(lua_State* InScriptContext)
{
	UObject* Outer = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Object");
	FName Name = FName(luaL_checkstring(InScriptContext, 2));
	UObject* Obj = NewObject<AAzureEnvironmentManager>(Outer, Name);
	wLua::FLuaUtils::ReturnUObject(InScriptContext,Obj);
	return 1;
}

int32 Destroy(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEnvironmentManager must be non-null"); lua_error(InScriptContext);  return 0;}
		AActor * actor = Cast<AActor>(Obj);
		actor->Destroy();
		userdata->flag |= wLua::LuaObjectFlag::DESTROYED;
		wLua::FLuaUtils::RemoveObjectReference(Obj, userdata->stamp, InScriptContext);
#ifdef AZURE_BUILD_WLUACHECK
		UE_LOG(LogAzure, Warning, TEXT("Destroy AzureEnvironmentManager: %x userdata:%x   stamp:%x"),Obj,userdata,userdata->stamp);
#endif
	return 0;
}

int32 Class(lua_State* InScriptContext)
{
	UClass* Class = AAzureEnvironmentManager::StaticClass();
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Class);
	return 1;
}

const luaL_Reg Lib_Funcs[] =
{
	{ "New", New },
	{ "Destroy", Destroy },
	{ "Class", Class },
	{ "TickSimuWindAzureComps", TickSimuWindAzureComps },
	{ "TickHighFrequency", TickHighFrequency },
	{ "RemoveSimuWindAzureComp", RemoveSimuWindAzureComp },
	{ "PushTransition", PushTransition },
	{ "PushPreset", PushPreset },
	{ "PopTransition", PopTransition },
	{ "PopPreset", PopPreset },
	{ "OnParameterChanged", OnParameterChanged },
	{ "InitShootingstar", InitShootingstar },
	{ "InitRainBow", InitRainBow },
	{ "InitComet", InitComet },
	{ "InitAurora", InitAurora },
	{ "InitAllRainBow", InitAllRainBow },
	{ "InitAllAurora", InitAllAurora },
	{ "GetWeather", GetWeather },
	{ "GetPreset", GetPreset },
	{ "GetActivePreset", GetActivePreset },
	{ "DumpPreset", DumpPreset },
	{ "Dump", Dump },
	{ "Deactive", Deactive },
	{ "ClearSimuWindAzureComps", ClearSimuWindAzureComps },
	{ "ChangeWeather", ChangeWeather },
	{ "AddSimuWindAzureComp", AddSimuWindAzureComp },
	{ "Active", Active },
	{ "Get_CameraLocation", Get_CameraLocation },
	{ "Set_CameraLocation", Set_CameraLocation },
	{ "Get_CameraRotation", Get_CameraRotation },
	{ "Set_CameraRotation", Set_CameraRotation },
	{ "Get_TimeOfDay", Get_TimeOfDay },
	{ "Set_TimeOfDay", Set_TimeOfDay },
	{ "Get_TimeScale", Get_TimeScale },
	{ "Set_TimeScale", Set_TimeScale },
	{ "Get_EditingPreset", Get_EditingPreset },
	{ "Set_EditingPreset", Set_EditingPreset },
	{ "Get_bBakePreview", Get_bBakePreview },
	{ "Set_bBakePreview", Set_bBakePreview },
	{ "Get_bEnable", Get_bEnable },
	{ "Set_bEnable", Set_bEnable },
	{ "Get_bUpdate", Get_bUpdate },
	{ "Set_bUpdate", Set_bUpdate },
	{ "Get_bApply", Get_bApply },
	{ "Set_bApply", Set_bApply },
	{ "Get_bIsPhotoMode", Get_bIsPhotoMode },
	{ "Set_bIsPhotoMode", Set_bIsPhotoMode },
	{ "Get_Sky", Get_Sky },
	{ "Set_Sky", Set_Sky },
	{ "Get_Fog", Get_Fog },
	{ "Set_Fog", Set_Fog },
	{ "Get_UnderWaterFog", Get_UnderWaterFog },
	{ "Set_UnderWaterFog", Set_UnderWaterFog },
	{ "Get_SunFlare", Get_SunFlare },
	{ "Set_SunFlare", Set_SunFlare },
	{ "Get_bUpdateLightDirection", Get_bUpdateLightDirection },
	{ "Set_bUpdateLightDirection", Set_bUpdateLightDirection },
	{ "Get_SunLightSource", Get_SunLightSource },
	{ "Set_SunLightSource", Set_SunLightSource },
	{ "Get_MoonLightSource", Get_MoonLightSource },
	{ "Set_MoonLightSource", Set_MoonLightSource },
	{ "Get_bWindTestMode", Get_bWindTestMode },
	{ "Set_bWindTestMode", Set_bWindTestMode },
	{ "Get_WindSource", Get_WindSource },
	{ "Set_WindSource", Set_WindSource },
	{ "Get_WindForceMulCurve", Get_WindForceMulCurve },
	{ "Set_WindForceMulCurve", Set_WindForceMulCurve },
	{ "Get_WindForceAddCurve", Get_WindForceAddCurve },
	{ "Set_WindForceAddCurve", Set_WindForceAddCurve },
	{ "Get_GrassBlockInMap", Get_GrassBlockInMap },
	{ "Set_GrassBlockInMap", Set_GrassBlockInMap },
	{ "Get_PostProcessVolumesBloom", Get_PostProcessVolumesBloom },
	{ "Set_PostProcessVolumesBloom", Set_PostProcessVolumesBloom },
	{ "Get_PostProcessVolumesIndirectLight", Get_PostProcessVolumesIndirectLight },
	{ "Set_PostProcessVolumesIndirectLight", Set_PostProcessVolumesIndirectLight },
	{ "Get_PostProcessVolumesPostColor", Get_PostProcessVolumesPostColor },
	{ "Set_PostProcessVolumesPostColor", Set_PostProcessVolumesPostColor },
	{ "Get_DefaultPreset", Get_DefaultPreset },
	{ "Set_DefaultPreset", Set_DefaultPreset },
	{ "Get_WeatherPresets", Get_WeatherPresets },
	{ "Set_WeatherPresets", Set_WeatherPresets },
	{ "Get_SkyUpperColor", Get_SkyUpperColor },
	{ "Set_SkyUpperColor", Set_SkyUpperColor },
	{ "Get_SkyLowerColor", Get_SkyLowerColor },
	{ "Set_SkyLowerColor", Set_SkyLowerColor },
	{ "Get_SkyFogDensity", Get_SkyFogDensity },
	{ "Set_SkyFogDensity", Set_SkyFogDensity },
	{ "Get_SkyLightBrightness", Get_SkyLightBrightness },
	{ "Set_SkyLightBrightness", Set_SkyLightBrightness },
	{ "Get_HorizonTilt", Get_HorizonTilt },
	{ "Set_HorizonTilt", Set_HorizonTilt },
	{ "Get_HorizonFalloff", Get_HorizonFalloff },
	{ "Set_HorizonFalloff", Set_HorizonFalloff },
	{ "Get_Saturation", Get_Saturation },
	{ "Set_Saturation", Set_Saturation },
	{ "Get_SunZenith", Get_SunZenith },
	{ "Set_SunZenith", Set_SunZenith },
	{ "Get_SunAzimuth", Get_SunAzimuth },
	{ "Set_SunAzimuth", Set_SunAzimuth },
	{ "Get_SunRadius", Get_SunRadius },
	{ "Set_SunRadius", Set_SunRadius },
	{ "Get_SunShine", Get_SunShine },
	{ "Set_SunShine", Set_SunShine },
	{ "Get_SunColor", Get_SunColor },
	{ "Set_SunColor", Set_SunColor },
	{ "Get_bUseSunPS", Get_bUseSunPS },
	{ "Set_bUseSunPS", Set_bUseSunPS },
	{ "Get_SunPSThreshold", Get_SunPSThreshold },
	{ "Set_SunPSThreshold", Set_SunPSThreshold },
	{ "Get_PS_SunTemplate", Get_PS_SunTemplate },
	{ "Set_PS_SunTemplate", Set_PS_SunTemplate },
	{ "Get_SunEffectScale", Get_SunEffectScale },
	{ "Set_SunEffectScale", Set_SunEffectScale },
	{ "Get_SunEffectOffset", Get_SunEffectOffset },
	{ "Set_SunEffectOffset", Set_SunEffectOffset },
	{ "Get_UseLightShaft", Get_UseLightShaft },
	{ "Set_UseLightShaft", Set_UseLightShaft },
	{ "Get_LightShaftScale", Get_LightShaftScale },
	{ "Set_LightShaftScale", Set_LightShaftScale },
	{ "Get_LightShaftTint", Get_LightShaftTint },
	{ "Set_LightShaftTint", Set_LightShaftTint },
	{ "Get_SunTemperature", Get_SunTemperature },
	{ "Set_SunTemperature", Set_SunTemperature },
	{ "Get_SunTemperature2", Get_SunTemperature2 },
	{ "Set_SunTemperature2", Set_SunTemperature2 },
	{ "Get_SunExternalIntensity", Get_SunExternalIntensity },
	{ "Set_SunExternalIntensity", Set_SunExternalIntensity },
	{ "Get_SunExternalIntensity2", Get_SunExternalIntensity2 },
	{ "Set_SunExternalIntensity2", Set_SunExternalIntensity2 },
	{ "Get_SpecularIBLScale", Get_SpecularIBLScale },
	{ "Set_SpecularIBLScale", Set_SpecularIBLScale },
	{ "Get_MoonZenith", Get_MoonZenith },
	{ "Set_MoonZenith", Set_MoonZenith },
	{ "Get_MoonAzimuth", Get_MoonAzimuth },
	{ "Set_MoonAzimuth", Set_MoonAzimuth },
	{ "Get_MoonRadius", Get_MoonRadius },
	{ "Set_MoonRadius", Set_MoonRadius },
	{ "Get_MoonShine", Get_MoonShine },
	{ "Set_MoonShine", Set_MoonShine },
	{ "Get_MoonColor", Get_MoonColor },
	{ "Set_MoonColor", Set_MoonColor },
	{ "Get_MoonBrightness", Get_MoonBrightness },
	{ "Set_MoonBrightness", Set_MoonBrightness },
	{ "Get_MoonLightDir", Get_MoonLightDir },
	{ "Set_MoonLightDir", Set_MoonLightDir },
	{ "Get_Moon2Zenith", Get_Moon2Zenith },
	{ "Set_Moon2Zenith", Set_Moon2Zenith },
	{ "Get_Moon2Azimuth", Get_Moon2Azimuth },
	{ "Set_Moon2Azimuth", Set_Moon2Azimuth },
	{ "Get_Moon2Radius", Get_Moon2Radius },
	{ "Set_Moon2Radius", Set_Moon2Radius },
	{ "Get_Moon2Shine", Get_Moon2Shine },
	{ "Set_Moon2Shine", Set_Moon2Shine },
	{ "Get_Moon2Color", Get_Moon2Color },
	{ "Set_Moon2Color", Set_Moon2Color },
	{ "Get_Moon2Brightness", Get_Moon2Brightness },
	{ "Set_Moon2Brightness", Set_Moon2Brightness },
	{ "Get_Moon2LightDir", Get_Moon2LightDir },
	{ "Set_Moon2LightDir", Set_Moon2LightDir },
	{ "Get_Moon3Zenith", Get_Moon3Zenith },
	{ "Set_Moon3Zenith", Set_Moon3Zenith },
	{ "Get_Moon3Azimuth", Get_Moon3Azimuth },
	{ "Set_Moon3Azimuth", Set_Moon3Azimuth },
	{ "Get_Moon3Radius", Get_Moon3Radius },
	{ "Set_Moon3Radius", Set_Moon3Radius },
	{ "Get_Moon3Shine", Get_Moon3Shine },
	{ "Set_Moon3Shine", Set_Moon3Shine },
	{ "Get_Moon3Color", Get_Moon3Color },
	{ "Set_Moon3Color", Set_Moon3Color },
	{ "Get_Moon3Brightness", Get_Moon3Brightness },
	{ "Set_Moon3Brightness", Set_Moon3Brightness },
	{ "Get_Moon3LightDir", Get_Moon3LightDir },
	{ "Set_Moon3LightDir", Set_Moon3LightDir },
	{ "Get_Moon4Zenith", Get_Moon4Zenith },
	{ "Set_Moon4Zenith", Set_Moon4Zenith },
	{ "Get_Moon4Azimuth", Get_Moon4Azimuth },
	{ "Set_Moon4Azimuth", Set_Moon4Azimuth },
	{ "Get_Moon4Radius", Get_Moon4Radius },
	{ "Set_Moon4Radius", Set_Moon4Radius },
	{ "Get_Moon4Shine", Get_Moon4Shine },
	{ "Set_Moon4Shine", Set_Moon4Shine },
	{ "Get_Moon4Color", Get_Moon4Color },
	{ "Set_Moon4Color", Set_Moon4Color },
	{ "Get_Moon4Brightness", Get_Moon4Brightness },
	{ "Set_Moon4Brightness", Set_Moon4Brightness },
	{ "Get_Moon4LightDir", Get_Moon4LightDir },
	{ "Set_Moon4LightDir", Set_Moon4LightDir },
	{ "Get_bUseMoonPS", Get_bUseMoonPS },
	{ "Set_bUseMoonPS", Set_bUseMoonPS },
	{ "Get_MoonPSThreshold", Get_MoonPSThreshold },
	{ "Set_MoonPSThreshold", Set_MoonPSThreshold },
	{ "Get_PS_MoonTemplate", Get_PS_MoonTemplate },
	{ "Set_PS_MoonTemplate", Set_PS_MoonTemplate },
	{ "Get_MoonEffectScale", Get_MoonEffectScale },
	{ "Set_MoonEffectScale", Set_MoonEffectScale },
	{ "Get_MoonEffectOffset", Get_MoonEffectOffset },
	{ "Set_MoonEffectOffset", Set_MoonEffectOffset },
	{ "Get_MoonTemperature", Get_MoonTemperature },
	{ "Set_MoonTemperature", Set_MoonTemperature },
	{ "Get_MoonExternalIntensity", Get_MoonExternalIntensity },
	{ "Set_MoonExternalIntensity", Set_MoonExternalIntensity },
	{ "Get_StarBrightness", Get_StarBrightness },
	{ "Set_StarBrightness", Set_StarBrightness },
	{ "Get_StarColor", Get_StarColor },
	{ "Set_StarColor", Set_StarColor },
	{ "Get_StarHeightThreshold", Get_StarHeightThreshold },
	{ "Set_StarHeightThreshold", Set_StarHeightThreshold },
	{ "Get_StarLerpWidth", Get_StarLerpWidth },
	{ "Set_StarLerpWidth", Set_StarLerpWidth },
	{ "Get_GalaxyScale", Get_GalaxyScale },
	{ "Set_GalaxyScale", Set_GalaxyScale },
	{ "Get_GalaxyRotationAngle", Get_GalaxyRotationAngle },
	{ "Set_GalaxyRotationAngle", Set_GalaxyRotationAngle },
	{ "Get_GalaxyIntensity", Get_GalaxyIntensity },
	{ "Set_GalaxyIntensity", Set_GalaxyIntensity },
	{ "Get_CloudsDensity", Get_CloudsDensity },
	{ "Set_CloudsDensity", Set_CloudsDensity },
	{ "Get_CloudsTranslucent", Get_CloudsTranslucent },
	{ "Set_CloudsTranslucent", Set_CloudsTranslucent },
	{ "Get_CloudsScale", Get_CloudsScale },
	{ "Set_CloudsScale", Set_CloudsScale },
	{ "Get_CloudsHardness", Get_CloudsHardness },
	{ "Set_CloudsHardness", Set_CloudsHardness },
	{ "Get_CloudsBlend", Get_CloudsBlend },
	{ "Set_CloudsBlend", Set_CloudsBlend },
	{ "Get_CloudsDistortion", Get_CloudsDistortion },
	{ "Set_CloudsDistortion", Set_CloudsDistortion },
	{ "Get_CloudsScattering", Get_CloudsScattering },
	{ "Set_CloudsScattering", Set_CloudsScattering },
	{ "Get_CloudsAmbient", Get_CloudsAmbient },
	{ "Set_CloudsAmbient", Set_CloudsAmbient },
	{ "Get_CloudsShadowSize", Get_CloudsShadowSize },
	{ "Set_CloudsShadowSize", Set_CloudsShadowSize },
	{ "Get_CloudsShadowSoft", Get_CloudsShadowSoft },
	{ "Set_CloudsShadowSoft", Set_CloudsShadowSoft },
	{ "Get_CloudsHorizonDensity", Get_CloudsHorizonDensity },
	{ "Set_CloudsHorizonDensity", Set_CloudsHorizonDensity },
	{ "Get_CloudsHorizonAlpha", Get_CloudsHorizonAlpha },
	{ "Set_CloudsHorizonAlpha", Set_CloudsHorizonAlpha },
	{ "Get_CloudsHorizonScattering", Get_CloudsHorizonScattering },
	{ "Set_CloudsHorizonScattering", Set_CloudsHorizonScattering },
	{ "Get_CloudsUpperColor", Get_CloudsUpperColor },
	{ "Set_CloudsUpperColor", Set_CloudsUpperColor },
	{ "Get_CloudsUpperBrightness", Get_CloudsUpperBrightness },
	{ "Set_CloudsUpperBrightness", Set_CloudsUpperBrightness },
	{ "Get_CloudsLowerColor", Get_CloudsLowerColor },
	{ "Set_CloudsLowerColor", Set_CloudsLowerColor },
	{ "Get_CloudsLowerBrightness", Get_CloudsLowerBrightness },
	{ "Set_CloudsLowerBrightness", Set_CloudsLowerBrightness },
	{ "Get_CloudsBackgroundColor", Get_CloudsBackgroundColor },
	{ "Set_CloudsBackgroundColor", Set_CloudsBackgroundColor },
	{ "Get_CloudsBackgroundBrightness", Get_CloudsBackgroundBrightness },
	{ "Set_CloudsBackgroundBrightness", Set_CloudsBackgroundBrightness },
	{ "Get_CloudLayersScale", Get_CloudLayersScale },
	{ "Set_CloudLayersScale", Set_CloudLayersScale },
	{ "Get_FarHorizonCloudsLowerColor", Get_FarHorizonCloudsLowerColor },
	{ "Set_FarHorizonCloudsLowerColor", Set_FarHorizonCloudsLowerColor },
	{ "Get_FarHorizonCloudsUpperColor", Get_FarHorizonCloudsUpperColor },
	{ "Set_FarHorizonCloudsUpperColor", Set_FarHorizonCloudsUpperColor },
	{ "Get_FarHorizonCloudsSpeed", Get_FarHorizonCloudsSpeed },
	{ "Set_FarHorizonCloudsSpeed", Set_FarHorizonCloudsSpeed },
	{ "Get_FarHorizonCloudsMaxOpacity", Get_FarHorizonCloudsMaxOpacity },
	{ "Set_FarHorizonCloudsMaxOpacity", Set_FarHorizonCloudsMaxOpacity },
	{ "Get_FarHorizonClouds1TilingOffset", Get_FarHorizonClouds1TilingOffset },
	{ "Set_FarHorizonClouds1TilingOffset", Set_FarHorizonClouds1TilingOffset },
	{ "Get_FarHorizonClouds2TilingOffset", Get_FarHorizonClouds2TilingOffset },
	{ "Set_FarHorizonClouds2TilingOffset", Set_FarHorizonClouds2TilingOffset },
	{ "Get_FarHorizonCloudsTex", Get_FarHorizonCloudsTex },
	{ "Set_FarHorizonCloudsTex", Set_FarHorizonCloudsTex },
	{ "Get_FogHeight", Get_FogHeight },
	{ "Set_FogHeight", Set_FogHeight },
	{ "Get_FogColor", Get_FogColor },
	{ "Set_FogColor", Set_FogColor },
	{ "Get_FogDensity", Get_FogDensity },
	{ "Set_FogDensity", Set_FogDensity },
	{ "Get_FogDensityOffset", Get_FogDensityOffset },
	{ "Set_FogDensityOffset", Set_FogDensityOffset },
	{ "Get_FogDensityScale", Get_FogDensityScale },
	{ "Set_FogDensityScale", Set_FogDensityScale },
	{ "Get_FogStartDistance", Get_FogStartDistance },
	{ "Set_FogStartDistance", Set_FogStartDistance },
	{ "Get_FogStartDistanceScale", Get_FogStartDistanceScale },
	{ "Set_FogStartDistanceScale", Set_FogStartDistanceScale },
	{ "Get_FogStartDistanceOffset", Get_FogStartDistanceOffset },
	{ "Set_FogStartDistanceOffset", Set_FogStartDistanceOffset },
	{ "Get_FogHeightFalloff", Get_FogHeightFalloff },
	{ "Set_FogHeightFalloff", Set_FogHeightFalloff },
	{ "Get_FogHeightFalloffScale", Get_FogHeightFalloffScale },
	{ "Set_FogHeightFalloffScale", Set_FogHeightFalloffScale },
	{ "Get_FogHeightFalloffOffset", Get_FogHeightFalloffOffset },
	{ "Set_FogHeightFalloffOffset", Set_FogHeightFalloffOffset },
	{ "Get_FogDirInscatteringExponent", Get_FogDirInscatteringExponent },
	{ "Set_FogDirInscatteringExponent", Set_FogDirInscatteringExponent },
	{ "Get_FogDirInscatteringStartDist", Get_FogDirInscatteringStartDist },
	{ "Set_FogDirInscatteringStartDist", Set_FogDirInscatteringStartDist },
	{ "Get_FogDirInscatteringColor", Get_FogDirInscatteringColor },
	{ "Set_FogDirInscatteringColor", Set_FogDirInscatteringColor },
	{ "Get_FogMaxOpacity", Get_FogMaxOpacity },
	{ "Set_FogMaxOpacity", Set_FogMaxOpacity },
	{ "Get_FogInscatteringDirection", Get_FogInscatteringDirection },
	{ "Set_FogInscatteringDirection", Set_FogInscatteringDirection },
	{ "Get_EnableUnderWaterFog", Get_EnableUnderWaterFog },
	{ "Set_EnableUnderWaterFog", Set_EnableUnderWaterFog },
	{ "Get_UnderWaterFogHeight", Get_UnderWaterFogHeight },
	{ "Set_UnderWaterFogHeight", Set_UnderWaterFogHeight },
	{ "Get_UnderWaterFogDensity", Get_UnderWaterFogDensity },
	{ "Set_UnderWaterFogDensity", Set_UnderWaterFogDensity },
	{ "Get_UnderWaterFogStartDistance", Get_UnderWaterFogStartDistance },
	{ "Set_UnderWaterFogStartDistance", Set_UnderWaterFogStartDistance },
	{ "Get_UnderWaterFogHeightFalloff", Get_UnderWaterFogHeightFalloff },
	{ "Set_UnderWaterFogHeightFalloff", Set_UnderWaterFogHeightFalloff },
	{ "Get_UnderWaterFogDirInscatteringColor", Get_UnderWaterFogDirInscatteringColor },
	{ "Set_UnderWaterFogDirInscatteringColor", Set_UnderWaterFogDirInscatteringColor },
	{ "Get_FogScaleMap", Get_FogScaleMap },
	{ "Set_FogScaleMap", Set_FogScaleMap },
	{ "Get_WindIntensity", Get_WindIntensity },
	{ "Set_WindIntensity", Set_WindIntensity },
	{ "Get_WindSpeed", Get_WindSpeed },
	{ "Set_WindSpeed", Set_WindSpeed },
	{ "Get_WindStrength", Get_WindStrength },
	{ "Set_WindStrength", Set_WindStrength },
	{ "Get_WindMinGustAmount", Get_WindMinGustAmount },
	{ "Set_WindMinGustAmount", Set_WindMinGustAmount },
	{ "Get_WindMaxGustAmount", Get_WindMaxGustAmount },
	{ "Set_WindMaxGustAmount", Set_WindMaxGustAmount },
	{ "Get_WindDirection", Get_WindDirection },
	{ "Set_WindDirection", Set_WindDirection },
	{ "Get_WindDisturbance", Get_WindDisturbance },
	{ "Set_WindDisturbance", Set_WindDisturbance },
	{ "Get_WindDirectionDisturbance", Get_WindDirectionDisturbance },
	{ "Set_WindDirectionDisturbance", Set_WindDirectionDisturbance },
	{ "Get_bUnderShelter", Get_bUnderShelter },
	{ "Set_bUnderShelter", Set_bUnderShelter },
	{ "Get_RainIntensity", Get_RainIntensity },
	{ "Set_RainIntensity", Set_RainIntensity },
	{ "Get_RainRoughnessScale", Get_RainRoughnessScale },
	{ "Set_RainRoughnessScale", Set_RainRoughnessScale },
	{ "Get_RippleIntensity", Get_RippleIntensity },
	{ "Set_RippleIntensity", Set_RippleIntensity },
	{ "Get_RippleUVScale", Get_RippleUVScale },
	{ "Set_RippleUVScale", Set_RippleUVScale },
	{ "Get_RippleTimeScale", Get_RippleTimeScale },
	{ "Set_RippleTimeScale", Set_RippleTimeScale },
	{ "Get_PuddleDepthScale", Get_PuddleDepthScale },
	{ "Set_PuddleDepthScale", Set_PuddleDepthScale },
	{ "Get_PuddleWavesNormalIntensity", Get_PuddleWavesNormalIntensity },
	{ "Set_PuddleWavesNormalIntensity", Set_PuddleWavesNormalIntensity },
	{ "Get_PuddleWavesTimeScale", Get_PuddleWavesTimeScale },
	{ "Set_PuddleWavesTimeScale", Set_PuddleWavesTimeScale },
	{ "Get_PuddleWavesUVScale", Get_PuddleWavesUVScale },
	{ "Set_PuddleWavesUVScale", Set_PuddleWavesUVScale },
	{ "Get_SnowIntensity", Get_SnowIntensity },
	{ "Set_SnowIntensity", Set_SnowIntensity },
	{ "Get_SnowSide", Get_SnowSide },
	{ "Set_SnowSide", Set_SnowSide },
	{ "Get_SnowSmooth", Get_SnowSmooth },
	{ "Set_SnowSmooth", Set_SnowSmooth },
	{ "Get_SnowRoughnessScale", Get_SnowRoughnessScale },
	{ "Set_SnowRoughnessScale", Set_SnowRoughnessScale },
	{ "Get_SnowThreshold", Get_SnowThreshold },
	{ "Set_SnowThreshold", Set_SnowThreshold },
	{ "Get_SnowMaskAmount", Get_SnowMaskAmount },
	{ "Set_SnowMaskAmount", Set_SnowMaskAmount },
	{ "Get_SnowDirection", Get_SnowDirection },
	{ "Set_SnowDirection", Set_SnowDirection },
	{ "Get_GrassColorMap", Get_GrassColorMap },
	{ "Set_GrassColorMap", Set_GrassColorMap },
	{ "Get_LightningIntensity", Get_LightningIntensity },
	{ "Set_LightningIntensity", Set_LightningIntensity },
	{ "Get_LightningRate", Get_LightningRate },
	{ "Set_LightningRate", Set_LightningRate },
	{ "Get_LightningHeight", Get_LightningHeight },
	{ "Set_LightningHeight", Set_LightningHeight },
	{ "Get_bLightning", Get_bLightning },
	{ "Set_bLightning", Set_bLightning },
	{ "Get_LightningBrightnessScale", Get_LightningBrightnessScale },
	{ "Set_LightningBrightnessScale", Set_LightningBrightnessScale },
	{ "Get_FogDirInscatteringColorLightningScale", Get_FogDirInscatteringColorLightningScale },
	{ "Set_FogDirInscatteringColorLightningScale", Set_FogDirInscatteringColorLightningScale },
	{ "Get_BloomIntensity", Get_BloomIntensity },
	{ "Set_BloomIntensity", Set_BloomIntensity },
	{ "Get_BloomThreshold", Get_BloomThreshold },
	{ "Set_BloomThreshold", Set_BloomThreshold },
	{ "Get_BloomIntensityWithToneMapping", Get_BloomIntensityWithToneMapping },
	{ "Set_BloomIntensityWithToneMapping", Set_BloomIntensityWithToneMapping },
	{ "Get_BloomThresholdWithToneMapping", Get_BloomThresholdWithToneMapping },
	{ "Set_BloomThresholdWithToneMapping", Set_BloomThresholdWithToneMapping },
	{ "Get_bUseLensFlare", Get_bUseLensFlare },
	{ "Set_bUseLensFlare", Set_bUseLensFlare },
	{ "Get_WorldLayerDepth", Get_WorldLayerDepth },
	{ "Set_WorldLayerDepth", Set_WorldLayerDepth },
	{ "Get_WorldLayerFog", Get_WorldLayerFog },
	{ "Set_WorldLayerFog", Set_WorldLayerFog },
	{ "Get_WorldLayerColor", Get_WorldLayerColor },
	{ "Set_WorldLayerColor", Set_WorldLayerColor },
	{ "Get_WorldRotationSpeed", Get_WorldRotationSpeed },
	{ "Set_WorldRotationSpeed", Set_WorldRotationSpeed },
	{ "Get_CharacterDirectLightScale", Get_CharacterDirectLightScale },
	{ "Set_CharacterDirectLightScale", Set_CharacterDirectLightScale },
	{ "Get_CharacterIndirectLightScale", Get_CharacterIndirectLightScale },
	{ "Set_CharacterIndirectLightScale", Set_CharacterIndirectLightScale },
	{ "Get_CharacterIndirectLightColor", Get_CharacterIndirectLightColor },
	{ "Set_CharacterIndirectLightColor", Set_CharacterIndirectLightColor },
	{ "Get_ShouldCopyDataFromSkin", Get_ShouldCopyDataFromSkin },
	{ "Set_ShouldCopyDataFromSkin", Set_ShouldCopyDataFromSkin },
	{ "Get_CharacterEquipDirectLightScale", Get_CharacterEquipDirectLightScale },
	{ "Set_CharacterEquipDirectLightScale", Set_CharacterEquipDirectLightScale },
	{ "Get_CharacterEquipIndirectLightScale", Get_CharacterEquipIndirectLightScale },
	{ "Set_CharacterEquipIndirectLightScale", Set_CharacterEquipIndirectLightScale },
	{ "Get_CharacterEquipIndirectLightColor", Get_CharacterEquipIndirectLightColor },
	{ "Set_CharacterEquipIndirectLightColor", Set_CharacterEquipIndirectLightColor },
	{ "Get_CharacterTemperatureMax", Get_CharacterTemperatureMax },
	{ "Set_CharacterTemperatureMax", Set_CharacterTemperatureMax },
	{ "Get_IndirectLightColor", Get_IndirectLightColor },
	{ "Set_IndirectLightColor", Set_IndirectLightColor },
	{ "Get_IndirectLightIntensity", Get_IndirectLightIntensity },
	{ "Set_IndirectLightIntensity", Set_IndirectLightIntensity },
	{ "Get_PointLightIntensity", Get_PointLightIntensity },
	{ "Set_PointLightIntensity", Set_PointLightIntensity },
	{ "Get_NightEmissivePositive", Get_NightEmissivePositive },
	{ "Set_NightEmissivePositive", Set_NightEmissivePositive },
	{ "Get_NightEmissiveNegative", Get_NightEmissiveNegative },
	{ "Set_NightEmissiveNegative", Set_NightEmissiveNegative },
	{ "Get_PostForegroundColorScale", Get_PostForegroundColorScale },
	{ "Set_PostForegroundColorScale", Set_PostForegroundColorScale },
	{ "Get_PostBackgroundColorScale", Get_PostBackgroundColorScale },
	{ "Set_PostBackgroundColorScale", Set_PostBackgroundColorScale },
	{ "Get_UseShootingstar", Get_UseShootingstar },
	{ "Set_UseShootingstar", Set_UseShootingstar },
	{ "Get_PS_ShootingStarTemplate", Get_PS_ShootingStarTemplate },
	{ "Set_PS_ShootingStarTemplate", Set_PS_ShootingStarTemplate },
	{ "Get_ShootingStarTransform", Get_ShootingStarTransform },
	{ "Set_ShootingStarTransform", Set_ShootingStarTransform },
	{ "Get_ShootingStarThreshold", Get_ShootingStarThreshold },
	{ "Set_ShootingStarThreshold", Set_ShootingStarThreshold },
	{ "Get_UseComet", Get_UseComet },
	{ "Set_UseComet", Set_UseComet },
	{ "Get_PS_CometTemplate", Get_PS_CometTemplate },
	{ "Set_PS_CometTemplate", Set_PS_CometTemplate },
	{ "Get_CometTransform", Get_CometTransform },
	{ "Set_CometTransform", Set_CometTransform },
	{ "Get_CometThreshold", Get_CometThreshold },
	{ "Set_CometThreshold", Set_CometThreshold },
	{ "Get_UseAurora", Get_UseAurora },
	{ "Set_UseAurora", Set_UseAurora },
	{ "Get_AuroraTranslucent", Get_AuroraTranslucent },
	{ "Set_AuroraTranslucent", Set_AuroraTranslucent },
	{ "Get_AuroraClass", Get_AuroraClass },
	{ "Set_AuroraClass", Set_AuroraClass },
	{ "Get_SM_AuroraSimple", Get_SM_AuroraSimple },
	{ "Set_SM_AuroraSimple", Set_SM_AuroraSimple },
	{ "Get_SM_AuroraComplex", Get_SM_AuroraComplex },
	{ "Set_SM_AuroraComplex", Set_SM_AuroraComplex },
	{ "Get_SM_AuroraSpiral", Get_SM_AuroraSpiral },
	{ "Set_SM_AuroraSpiral", Set_SM_AuroraSpiral },
	{ "Get_AuroraSimpleTransform", Get_AuroraSimpleTransform },
	{ "Set_AuroraSimpleTransform", Set_AuroraSimpleTransform },
	{ "Get_AuroraComplexTransform", Get_AuroraComplexTransform },
	{ "Set_AuroraComplexTransform", Set_AuroraComplexTransform },
	{ "Get_AuroraSpiralTransform", Get_AuroraSpiralTransform },
	{ "Set_AuroraSpiralTransform", Set_AuroraSpiralTransform },
	{ "Get_UseRainBow", Get_UseRainBow },
	{ "Set_UseRainBow", Set_UseRainBow },
	{ "Get_SM_RainBowSmall", Get_SM_RainBowSmall },
	{ "Set_SM_RainBowSmall", Set_SM_RainBowSmall },
	{ "Get_SM_RainBowLarge", Get_SM_RainBowLarge },
	{ "Set_SM_RainBowLarge", Set_SM_RainBowLarge },
	{ "Get_SmallRainBowTransform", Get_SmallRainBowTransform },
	{ "Set_SmallRainBowTransform", Set_SmallRainBowTransform },
	{ "Get_LargeRainBowTransform", Get_LargeRainBowTransform },
	{ "Set_LargeRainBowTransform", Set_LargeRainBowTransform },
	{ "Get_RainBowTranslucent", Get_RainBowTranslucent },
	{ "Set_RainBowTranslucent", Set_RainBowTranslucent },
	{ "ApplyImmediate", ApplyImmediate },
	{ "Set_TickInterval", Set_TickInterval },
	{ "is_nil", wLua::LuaStatic::isnil },
	{ "__gc", wLua::LuaStatic::removeUClassFrameCache },
	{ NULL, NULL }
};

void Register(lua_State *InScriptContext)
{
	lua_newtable(InScriptContext);
	luaL_register(InScriptContext, NULL, Lib_Funcs);
	AzureHelpFuncs::AuxRegister(InScriptContext, "AzureEnvironmentManager");
}
void SetMtLink(lua_State *InScriptContext)
{
	AzureHelpFuncs::AuxSetMtLink(InScriptContext, "AzureEnvironmentManager", "Actor",USERDATATYPE_UOBJECT);
}

}