#include "Azure.h"
#include "Utility/help_funcs.h"
#include "wLua/UObjectHeaders.h"
#include "Utilities/LevelSequenceActorEx.h"
#include "AzureLuaIntegration.h"

namespace LuaLevelSequenceActorEx
{
int32 lua_GetEventsDataByName(lua_State*);
int32 RegistLuaEvent(lua_State*);
int32 AddBindingSceneObj(lua_State*);
int32 RemoveBindingSceneObj(lua_State*);
int32 FindSpawnedObject(lua_State*);
int32 FindBindingObject(lua_State*);
int32 FadeGameCamera(lua_State*);
int32 CreateCameraOffset(lua_State*);
int32 RemoveCameraOffset(lua_State*);

int32 SpawnObjectByTrack(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"LevelSequenceActorEx",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"LevelSequenceActorEx must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FString strCGTrackDisplayName;
		FString strCGTrackGUID;
		FString sequenceIDStr;
		UObject* ReturnValue = nullptr;
	} Params;
	Params.strCGTrackDisplayName = UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 2));
	Params.strCGTrackGUID = UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 3));
	Params.sequenceIDStr = UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 4));
#if UE_GAME
	ALevelSequenceActorEx * This = (ALevelSequenceActorEx *)Obj;
	Params.ReturnValue = This->SpawnObjectByTrack(Params.strCGTrackDisplayName,Params.strCGTrackGUID,Params.sequenceIDStr);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SpawnObjectByTrack"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FString*)(params.GetStructMemory() + 0) = Params.strCGTrackDisplayName;
		*(FString*)(params.GetStructMemory() + 16) = Params.strCGTrackGUID;
		*(FString*)(params.GetStructMemory() + 32) = Params.sequenceIDStr;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.strCGTrackDisplayName = *(FString*)(params.GetStructMemory() + 0);
		Params.strCGTrackGUID = *(FString*)(params.GetStructMemory() + 16);
		Params.sequenceIDStr = *(FString*)(params.GetStructMemory() + 32);
		Params.ReturnValue = *(UObject**)(params.GetStructMemory() + 48);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 SetWorldStreamingVisibleExcludeCG(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"LevelSequenceActorEx",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"LevelSequenceActorEx must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool bActive;
	} Params;
	Params.bActive = !!(lua_toboolean(InScriptContext, 2));
#if UE_GAME
	ALevelSequenceActorEx * This = (ALevelSequenceActorEx *)Obj;
	This->SetWorldStreamingVisibleExcludeCG(Params.bActive);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetWorldStreamingVisibleExcludeCG"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(bool*)(params.GetStructMemory() + 0) = Params.bActive;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.bActive = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetSequenceEx(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"LevelSequenceActorEx",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"LevelSequenceActorEx must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		ULevelSequence* InSequence = nullptr;
		int32 cgid;
	} Params;
	Params.InSequence = (ULevelSequence*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"LevelSequence");;
	Params.cgid = (luaL_checkint(InScriptContext, 3));
#if UE_GAME
	ALevelSequenceActorEx * This = (ALevelSequenceActorEx *)Obj;
	This->SetSequenceEx(Params.InSequence,Params.cgid);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetSequenceEx"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(ULevelSequence**)(params.GetStructMemory() + 0) = Params.InSequence;
		*(int32*)(params.GetStructMemory() + 8) = Params.cgid;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.InSequence = *(ULevelSequence**)(params.GetStructMemory() + 0);
		Params.cgid = *(int32*)(params.GetStructMemory() + 8);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetPlaybackSettingStartOffset(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"LevelSequenceActorEx",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"LevelSequenceActorEx must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float startOffset;
	} Params;
	Params.startOffset = (float)(luaL_checknumber(InScriptContext, 2));
#if UE_GAME
	ALevelSequenceActorEx * This = (ALevelSequenceActorEx *)Obj;
	This->SetPlaybackSettingStartOffset(Params.startOffset);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetPlaybackSettingStartOffset"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(float*)(params.GetStructMemory() + 0) = Params.startOffset;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.startOffset = *(float*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetPlaybackSettingLoopCount(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"LevelSequenceActorEx",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"LevelSequenceActorEx must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		int32 loopCount;
	} Params;
	Params.loopCount = (luaL_checkint(InScriptContext, 2));
#if UE_GAME
	ALevelSequenceActorEx * This = (ALevelSequenceActorEx *)Obj;
	This->SetPlaybackSettingLoopCount(Params.loopCount);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetPlaybackSettingLoopCount"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(int32*)(params.GetStructMemory() + 0) = Params.loopCount;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.loopCount = *(int32*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetLevelVisibleExcludeCG(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"LevelSequenceActorEx",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"LevelSequenceActorEx must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		ULevel* level = nullptr;
		bool bActive;
	} Params;
	Params.level = (ULevel*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"Level");;
	Params.bActive = !!(lua_toboolean(InScriptContext, 3));
#if UE_GAME
	ALevelSequenceActorEx * This = (ALevelSequenceActorEx *)Obj;
	This->SetLevelVisibleExcludeCG(Params.level,Params.bActive);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetLevelVisibleExcludeCG"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(ULevel**)(params.GetStructMemory() + 0) = Params.level;
		*(bool*)(params.GetStructMemory() + 8) = Params.bActive;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.level = *(ULevel**)(params.GetStructMemory() + 0);
		Params.bActive = *(bool*)(params.GetStructMemory() + 8);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetCurWorld(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"LevelSequenceActorEx",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"LevelSequenceActorEx must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FString strWorld;
	} Params;
	Params.strWorld = UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 2));
#if UE_GAME
	ALevelSequenceActorEx * This = (ALevelSequenceActorEx *)Obj;
	This->SetCurWorld(Params.strWorld);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetCurWorld"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FString*)(params.GetStructMemory() + 0) = Params.strWorld;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.strWorld = *(FString*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 lua_GetTransformTrackValue(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"LevelSequenceActorEx",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"LevelSequenceActorEx must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FString strCGTrackDisplayName;
		FString strCGTrackGUID;
		FString sequenceIDStr;
		bool isEndKey;
		FTransform outTrans;
		bool ReturnValue;
	} Params;
	Params.strCGTrackDisplayName = UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 2));
	Params.strCGTrackGUID = UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 3));
	Params.sequenceIDStr = UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 4));
	Params.isEndKey = !!(lua_toboolean(InScriptContext, 5));
#if UE_GAME
	ALevelSequenceActorEx * This = (ALevelSequenceActorEx *)Obj;
	Params.ReturnValue = This->lua_GetTransformTrackValue(Params.strCGTrackDisplayName,Params.strCGTrackGUID,Params.sequenceIDStr,Params.isEndKey,Params.outTrans);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("lua_GetTransformTrackValue"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FString*)(params.GetStructMemory() + 0) = Params.strCGTrackDisplayName;
		*(FString*)(params.GetStructMemory() + 16) = Params.strCGTrackGUID;
		*(FString*)(params.GetStructMemory() + 32) = Params.sequenceIDStr;
		*(bool*)(params.GetStructMemory() + 48) = Params.isEndKey;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.strCGTrackDisplayName = *(FString*)(params.GetStructMemory() + 0);
		Params.strCGTrackGUID = *(FString*)(params.GetStructMemory() + 16);
		Params.sequenceIDStr = *(FString*)(params.GetStructMemory() + 32);
		Params.isEndKey = *(bool*)(params.GetStructMemory() + 48);
		Params.outTrans = *(FTransform*)(params.GetStructMemory() + 64);
		Params.ReturnValue = *(bool*)(params.GetStructMemory() + 112);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushboolean(InScriptContext, Params.ReturnValue);
	wLua::FLuaTransform::Return(InScriptContext, Params.outTrans);
	return 2;
}

int32 GetSequencePlayerEx(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"LevelSequenceActorEx",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"LevelSequenceActorEx must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		ULevelSequencePlayerEx* ReturnValue = nullptr;
	} Params;
#if UE_GAME
	ALevelSequenceActorEx * This = (ALevelSequenceActorEx *)Obj;
	Params.ReturnValue = This->GetSequencePlayerEx();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetSequencePlayerEx"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(ULevelSequencePlayerEx**)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetHostBeginTransform(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"LevelSequenceActorEx",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"LevelSequenceActorEx must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FTransform outTrans;
		bool ReturnValue;
	} Params;
#if UE_GAME
	ALevelSequenceActorEx * This = (ALevelSequenceActorEx *)Obj;
	Params.ReturnValue = This->GetHostBeginTransform(Params.outTrans);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetHostBeginTransform"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.outTrans = *(FTransform*)(params.GetStructMemory() + 0);
		Params.ReturnValue = *(bool*)(params.GetStructMemory() + 48);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushboolean(InScriptContext, Params.ReturnValue);
	wLua::FLuaTransform::Return(InScriptContext, Params.outTrans);
	return 2;
}

int32 DissolveCameraScreenShot(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"LevelSequenceActorEx",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"LevelSequenceActorEx must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		UCameraComponent* cameraComp = nullptr;
		UTextureRenderTarget2D* rtTexture = nullptr;
		float dissolveTime;
	} Params;
	Params.cameraComp = (UCameraComponent*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"CameraComponent");;
	Params.rtTexture = (UTextureRenderTarget2D*)wLua::FLuaUtils::GetUObject(InScriptContext,3,"TextureRenderTarget2D");;
	Params.dissolveTime = (float)(luaL_checknumber(InScriptContext, 4));
#if UE_GAME
	ALevelSequenceActorEx * This = (ALevelSequenceActorEx *)Obj;
	This->DissolveCameraScreenShot(Params.cameraComp,Params.rtTexture,Params.dissolveTime);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("DissolveCameraScreenShot"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(UCameraComponent**)(params.GetStructMemory() + 0) = Params.cameraComp;
		*(UTextureRenderTarget2D**)(params.GetStructMemory() + 8) = Params.rtTexture;
		*(float*)(params.GetStructMemory() + 16) = Params.dissolveTime;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.cameraComp = *(UCameraComponent**)(params.GetStructMemory() + 0);
		Params.rtTexture = *(UTextureRenderTarget2D**)(params.GetStructMemory() + 8);
		Params.dissolveTime = *(float*)(params.GetStructMemory() + 16);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 DestroySpawnObjectByTrack(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"LevelSequenceActorEx",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"LevelSequenceActorEx must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		UObject* Obj = nullptr;
	} Params;
	Params.Obj = (UObject*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"Object");;
#if UE_GAME
	ALevelSequenceActorEx * This = (ALevelSequenceActorEx *)Obj;
	This->DestroySpawnObjectByTrack(Params.Obj);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("DestroySpawnObjectByTrack"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(UObject**)(params.GetStructMemory() + 0) = Params.Obj;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.Obj = *(UObject**)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 Get_enableFadeCameraCollisionCheck(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"LevelSequenceActorEx",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"LevelSequenceActorEx must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(ALevelSequenceActorEx::StaticClass(), TEXT("enableFadeCameraCollisionCheck"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = bool();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_enableFadeCameraCollisionCheck(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"LevelSequenceActorEx",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"LevelSequenceActorEx must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(ALevelSequenceActorEx::StaticClass(), TEXT("enableFadeCameraCollisionCheck"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_captureComp(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"LevelSequenceActorEx",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"LevelSequenceActorEx must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(ALevelSequenceActorEx::StaticClass(), TEXT("captureComp"));
	if(!Property) { check(false); return 0;}
	USceneCaptureComponent2D* PropertyValue;
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaUtils::ReturnUObject(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_captureComp(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"LevelSequenceActorEx",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"LevelSequenceActorEx must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(ALevelSequenceActorEx::StaticClass(), TEXT("captureComp"));
	if(!Property) { check(false); return 0;}
	USceneCaptureComponent2D* PropertyValue = (USceneCaptureComponent2D*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"SceneCaptureComponent2D");;
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 New(lua_State* InScriptContext)
{
	UObject* Outer = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Object");
	FName Name = FName(luaL_checkstring(InScriptContext, 2));
	UObject* Obj = NewObject<ALevelSequenceActorEx>(Outer, Name);
	wLua::FLuaUtils::ReturnUObject(InScriptContext,Obj);
	return 1;
}

int32 Destroy(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"LevelSequenceActorEx",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"LevelSequenceActorEx must be non-null"); lua_error(InScriptContext);  return 0;}
		AActor * actor = Cast<AActor>(Obj);
		actor->Destroy();
		userdata->flag |= wLua::LuaObjectFlag::DESTROYED;
		wLua::FLuaUtils::RemoveObjectReference(Obj, userdata->stamp, InScriptContext);
#ifdef AZURE_BUILD_WLUACHECK
		UE_LOG(LogAzure, Warning, TEXT("Destroy LevelSequenceActorEx: %x userdata:%x   stamp:%x"),Obj,userdata,userdata->stamp);
#endif
	return 0;
}

int32 Class(lua_State* InScriptContext)
{
	UClass* Class = ALevelSequenceActorEx::StaticClass();
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Class);
	return 1;
}

const luaL_Reg Lib_Funcs[] =
{
	{ "New", New },
	{ "Destroy", Destroy },
	{ "Class", Class },
	{ "SpawnObjectByTrack", SpawnObjectByTrack },
	{ "SetWorldStreamingVisibleExcludeCG", SetWorldStreamingVisibleExcludeCG },
	{ "SetSequenceEx", SetSequenceEx },
	{ "SetPlaybackSettingStartOffset", SetPlaybackSettingStartOffset },
	{ "SetPlaybackSettingLoopCount", SetPlaybackSettingLoopCount },
	{ "SetLevelVisibleExcludeCG", SetLevelVisibleExcludeCG },
	{ "SetCurWorld", SetCurWorld },
	{ "lua_GetTransformTrackValue", lua_GetTransformTrackValue },
	{ "GetSequencePlayerEx", GetSequencePlayerEx },
	{ "GetHostBeginTransform", GetHostBeginTransform },
	{ "DissolveCameraScreenShot", DissolveCameraScreenShot },
	{ "DestroySpawnObjectByTrack", DestroySpawnObjectByTrack },
	{ "Get_enableFadeCameraCollisionCheck", Get_enableFadeCameraCollisionCheck },
	{ "Set_enableFadeCameraCollisionCheck", Set_enableFadeCameraCollisionCheck },
	{ "Get_captureComp", Get_captureComp },
	{ "Set_captureComp", Set_captureComp },
	{ "lua_GetEventsDataByName", lua_GetEventsDataByName },
	{ "RegistLuaEvent", RegistLuaEvent },
	{ "AddBindingSceneObj", AddBindingSceneObj },
	{ "RemoveBindingSceneObj", RemoveBindingSceneObj },
	{ "FindSpawnedObject", FindSpawnedObject },
	{ "FindBindingObject", FindBindingObject },
	{ "FadeGameCamera", FadeGameCamera },
	{ "CreateCameraOffset", CreateCameraOffset },
	{ "RemoveCameraOffset", RemoveCameraOffset },
	{ "is_nil", wLua::LuaStatic::isnil },
	{ "__gc", wLua::LuaStatic::removeUClassFrameCache },
	{ NULL, NULL }
};

void Register(lua_State *InScriptContext)
{
	lua_newtable(InScriptContext);
	luaL_register(InScriptContext, NULL, Lib_Funcs);
	AzureHelpFuncs::AuxRegister(InScriptContext, "LevelSequenceActorEx");
}
void SetMtLink(lua_State *InScriptContext)
{
	AzureHelpFuncs::AuxSetMtLink(InScriptContext, "LevelSequenceActorEx", "LevelSequenceActor",USERDATATYPE_UOBJECT);
}

}