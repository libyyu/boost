#include "Azure.h"
#include "Utility/help_funcs.h"
#include "wLua/UObjectHeaders.h"
#include "Components/MultiLineEditableText.h"
#include "MultiLineEditableText.h"
#include "AzureLuaIntegration.h"

namespace LuaMultiLineEditableText
{
int32 SetColorAndOpacity(lua_State*);
int32 SetFontSize(lua_State*);

int32 SetText(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MultiLineEditableText",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MultiLineEditableText must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FText InText;
	} Params;
	Params.InText = FText::FromString(UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 2)));
#if UE_GAME
	UMultiLineEditableText * This = (UMultiLineEditableText *)Obj;
	This->SetText(Params.InText);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetText"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FText*)(params.GetStructMemory() + 0) = Params.InText;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.InText = *(FText*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetIsReadOnly(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MultiLineEditableText",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MultiLineEditableText must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool bReadOnly;
	} Params;
	Params.bReadOnly = !!(lua_toboolean(InScriptContext, 2));
#if UE_GAME
	UMultiLineEditableText * This = (UMultiLineEditableText *)Obj;
	This->SetIsReadOnly(Params.bReadOnly);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetIsReadOnly"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(bool*)(params.GetStructMemory() + 0) = Params.bReadOnly;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.bReadOnly = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 GetText(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MultiLineEditableText",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MultiLineEditableText must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FText ReturnValue;
	} Params;
#if UE_GAME
	UMultiLineEditableText * This = (UMultiLineEditableText *)Obj;
	Params.ReturnValue = This->GetText();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetText"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(FText*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushstring(InScriptContext, TCHAR_TO_UTF8(*Params.ReturnValue.ToString()));
	return 1;
}

int32 Get_Text(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MultiLineEditableText",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MultiLineEditableText must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UMultiLineEditableText::StaticClass(), TEXT("Text"));
	if(!Property) { check(false); return 0;}
	FText PropertyValue;
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushstring(InScriptContext, TCHAR_TO_UTF8(*PropertyValue.ToString()));
	return 1;
}

int32 Set_Text(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MultiLineEditableText",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MultiLineEditableText must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UMultiLineEditableText::StaticClass(), TEXT("Text"));
	if(!Property) { check(false); return 0;}
	FText PropertyValue = FText::FromString(UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 2)));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_HintText(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MultiLineEditableText",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MultiLineEditableText must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UMultiLineEditableText::StaticClass(), TEXT("HintText"));
	if(!Property) { check(false); return 0;}
	FText PropertyValue;
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushstring(InScriptContext, TCHAR_TO_UTF8(*PropertyValue.ToString()));
	return 1;
}

int32 Set_HintText(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MultiLineEditableText",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MultiLineEditableText must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UMultiLineEditableText::StaticClass(), TEXT("HintText"));
	if(!Property) { check(false); return 0;}
	FText PropertyValue = FText::FromString(UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 2)));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bIsReadOnly(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MultiLineEditableText",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MultiLineEditableText must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UMultiLineEditableText::StaticClass(), TEXT("bIsReadOnly"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = bool();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_SelectAllTextWhenFocused(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MultiLineEditableText",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MultiLineEditableText must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UMultiLineEditableText::StaticClass(), TEXT("SelectAllTextWhenFocused"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = bool();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_SelectAllTextWhenFocused(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MultiLineEditableText",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MultiLineEditableText must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UMultiLineEditableText::StaticClass(), TEXT("SelectAllTextWhenFocused"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_ClearTextSelectionOnFocusLoss(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MultiLineEditableText",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MultiLineEditableText must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UMultiLineEditableText::StaticClass(), TEXT("ClearTextSelectionOnFocusLoss"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = bool();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_ClearTextSelectionOnFocusLoss(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MultiLineEditableText",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MultiLineEditableText must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UMultiLineEditableText::StaticClass(), TEXT("ClearTextSelectionOnFocusLoss"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_RevertTextOnEscape(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MultiLineEditableText",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MultiLineEditableText must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UMultiLineEditableText::StaticClass(), TEXT("RevertTextOnEscape"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = bool();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_RevertTextOnEscape(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MultiLineEditableText",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MultiLineEditableText must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UMultiLineEditableText::StaticClass(), TEXT("RevertTextOnEscape"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_ClearKeyboardFocusOnCommit(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MultiLineEditableText",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MultiLineEditableText must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UMultiLineEditableText::StaticClass(), TEXT("ClearKeyboardFocusOnCommit"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = bool();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_ClearKeyboardFocusOnCommit(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MultiLineEditableText",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MultiLineEditableText must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UMultiLineEditableText::StaticClass(), TEXT("ClearKeyboardFocusOnCommit"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_AllowContextMenu(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MultiLineEditableText",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MultiLineEditableText must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UMultiLineEditableText::StaticClass(), TEXT("AllowContextMenu"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = bool();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_AllowContextMenu(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MultiLineEditableText",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MultiLineEditableText must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UMultiLineEditableText::StaticClass(), TEXT("AllowContextMenu"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_VirtualKeyboardDismissAction(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MultiLineEditableText",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MultiLineEditableText must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UMultiLineEditableText::StaticClass(), TEXT("VirtualKeyboardDismissAction"));
	if(!Property) { check(false); return 0;}
	EVirtualKeyboardDismissAction PropertyValue = EVirtualKeyboardDismissAction();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushinteger(InScriptContext, (int)PropertyValue);
	return 1;
}

int32 Set_VirtualKeyboardDismissAction(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MultiLineEditableText",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MultiLineEditableText must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UMultiLineEditableText::StaticClass(), TEXT("VirtualKeyboardDismissAction"));
	if(!Property) { check(false); return 0;}
	EVirtualKeyboardDismissAction PropertyValue = (EVirtualKeyboardDismissAction)(luaL_checkint(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Call_OnTextChanged(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MultiLineEditableText",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MultiLineEditableText must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FText Text;
	} Params;
	Params.Text = FText::FromString(UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 2)));
	UMultiLineEditableText * This = (UMultiLineEditableText *)Obj;
	This->OnTextChanged.Broadcast(Params.Text);
	return 0;
}

int32 Call_OnTextCommitted(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MultiLineEditableText",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MultiLineEditableText must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FText Text;
		TEnumAsByte<ETextCommit::Type> CommitMethod;
	} Params;
	Params.Text = FText::FromString(UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 2)));
	Params.CommitMethod = (TEnumAsByte<ETextCommit::Type>)(luaL_checkint(InScriptContext, 3));
	UMultiLineEditableText * This = (UMultiLineEditableText *)Obj;
	This->OnTextCommitted.Broadcast(Params.Text,Params.CommitMethod);
	return 0;
}

int32 New(lua_State* InScriptContext)
{
	UObject* Outer = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Object");
	FName Name = FName(luaL_checkstring(InScriptContext, 2));
	UObject* Obj = NewObject<UMultiLineEditableText>(Outer, Name);
	wLua::FLuaUtils::ReturnUObject(InScriptContext,Obj);
	return 1;
}

int32 Destroy(lua_State* InScriptContext)
{
	return 0;
}

int32 Class(lua_State* InScriptContext)
{
	UClass* Class = UMultiLineEditableText::StaticClass();
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Class);
	return 1;
}

const luaL_Reg Lib_Funcs[] =
{
	{ "New", New },
	{ "Destroy", Destroy },
	{ "Class", Class },
	{ "SetText", SetText },
	{ "SetIsReadOnly", SetIsReadOnly },
	{ "GetText", GetText },
	{ "Get_Text", Get_Text },
	{ "Set_Text", Set_Text },
	{ "Get_HintText", Get_HintText },
	{ "Set_HintText", Set_HintText },
	{ "Get_bIsReadOnly", Get_bIsReadOnly },
	{ "Get_SelectAllTextWhenFocused", Get_SelectAllTextWhenFocused },
	{ "Set_SelectAllTextWhenFocused", Set_SelectAllTextWhenFocused },
	{ "Get_ClearTextSelectionOnFocusLoss", Get_ClearTextSelectionOnFocusLoss },
	{ "Set_ClearTextSelectionOnFocusLoss", Set_ClearTextSelectionOnFocusLoss },
	{ "Get_RevertTextOnEscape", Get_RevertTextOnEscape },
	{ "Set_RevertTextOnEscape", Set_RevertTextOnEscape },
	{ "Get_ClearKeyboardFocusOnCommit", Get_ClearKeyboardFocusOnCommit },
	{ "Set_ClearKeyboardFocusOnCommit", Set_ClearKeyboardFocusOnCommit },
	{ "Get_AllowContextMenu", Get_AllowContextMenu },
	{ "Set_AllowContextMenu", Set_AllowContextMenu },
	{ "Get_VirtualKeyboardDismissAction", Get_VirtualKeyboardDismissAction },
	{ "Set_VirtualKeyboardDismissAction", Set_VirtualKeyboardDismissAction },
	{ "Call_OnTextChanged", Call_OnTextChanged },
	{ "Call_OnTextCommitted", Call_OnTextCommitted },
	{ "SetColorAndOpacity", SetColorAndOpacity },
	{ "SetFontSize", SetFontSize },
	{ "is_nil", wLua::LuaStatic::isnil },
	{ "__gc", wLua::LuaStatic::removeUClassFrameCache },
	{ NULL, NULL }
};

void Register(lua_State *InScriptContext)
{
	lua_newtable(InScriptContext);
	luaL_register(InScriptContext, NULL, Lib_Funcs);
	AzureHelpFuncs::AuxRegister(InScriptContext, "MultiLineEditableText");
}
void SetMtLink(lua_State *InScriptContext)
{
	AzureHelpFuncs::AuxSetMtLink(InScriptContext, "MultiLineEditableText", "TextLayoutWidget",USERDATATYPE_UOBJECT);
}

}