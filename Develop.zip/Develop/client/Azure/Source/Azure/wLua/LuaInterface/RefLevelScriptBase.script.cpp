#include "Azure.h"
#include "Utility/help_funcs.h"
#include "wLua/UObjectHeaders.h"
#include "GameLogic/Main/RefLevelScriptBase.h"
#include "AzureLuaIntegration.h"

namespace LuaRefLevelScriptBase
{
int32 InitLuaInterfaceRef(lua_State*);

int32 UnLoadAllSubLevel(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"RefLevelScriptBase",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"RefLevelScriptBase must be non-null"); lua_error(InScriptContext);  return 0;}
#if UE_GAME
	ARefLevelScriptBase * This = (ARefLevelScriptBase *)Obj;
	This->UnLoadAllSubLevel();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("UnLoadAllSubLevel"));
	if(!Function) { check(false); return 0;}
	Obj->ProcessEvent(Function, NULL);
#endif
	return 0;
}

int32 SwitchToOriginLevel(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"RefLevelScriptBase",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"RefLevelScriptBase must be non-null"); lua_error(InScriptContext);  return 0;}
#if UE_GAME
	ARefLevelScriptBase * This = (ARefLevelScriptBase *)Obj;
	This->SwitchToOriginLevel();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SwitchToOriginLevel"));
	if(!Function) { check(false); return 0;}
	Obj->ProcessEvent(Function, NULL);
#endif
	return 0;
}

int32 SetEnvironmentPresetVaild(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"RefLevelScriptBase",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"RefLevelScriptBase must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		TSubclassOf<UAzureEnvironmentPreset>  preset;
		bool isValid;
		float fadeTime;
	} Params;
	Params.preset = (UClass*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"Class");;
	Params.isValid = !!(lua_toboolean(InScriptContext, 3));
	Params.fadeTime = (float)(luaL_checknumber(InScriptContext, 4));
#if UE_GAME
	ARefLevelScriptBase * This = (ARefLevelScriptBase *)Obj;
	This->SetEnvironmentPresetVaild(Params.preset,Params.isValid,Params.fadeTime);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetEnvironmentPresetVaild"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(TSubclassOf<UAzureEnvironmentPreset> *)(params.GetStructMemory() + 0) = Params.preset;
		*(bool*)(params.GetStructMemory() + 8) = Params.isValid;
		*(float*)(params.GetStructMemory() + 12) = Params.fadeTime;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.preset = *(TSubclassOf<UAzureEnvironmentPreset> *)(params.GetStructMemory() + 0);
		Params.isValid = *(bool*)(params.GetStructMemory() + 8);
		Params.fadeTime = *(float*)(params.GetStructMemory() + 12);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetAttributeValue(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"RefLevelScriptBase",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"RefLevelScriptBase must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		int32 key;
		int32 value;
		bool isInit;
	} Params;
	Params.key = (luaL_checkint(InScriptContext, 2));
	Params.value = (luaL_checkint(InScriptContext, 3));
	Params.isInit = !!(lua_toboolean(InScriptContext, 4));
#if UE_GAME
	ARefLevelScriptBase * This = (ARefLevelScriptBase *)Obj;
	This->SetAttributeValue(Params.key,Params.value,Params.isInit);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetAttributeValue"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(int32*)(params.GetStructMemory() + 0) = Params.key;
		*(int32*)(params.GetStructMemory() + 4) = Params.value;
		*(bool*)(params.GetStructMemory() + 8) = Params.isInit;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.key = *(int32*)(params.GetStructMemory() + 0);
		Params.value = *(int32*)(params.GetStructMemory() + 4);
		Params.isInit = *(bool*)(params.GetStructMemory() + 8);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 OnAttributeChange(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"RefLevelScriptBase",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"RefLevelScriptBase must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		int32 key;
		int32 value;
		bool isInit;
	} Params;
	Params.key = (luaL_checkint(InScriptContext, 2));
	Params.value = (luaL_checkint(InScriptContext, 3));
	Params.isInit = !!(lua_toboolean(InScriptContext, 4));
#if UE_GAME
	ARefLevelScriptBase * This = (ARefLevelScriptBase *)Obj;
	This->OnAttributeChange(Params.key,Params.value,Params.isInit);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("OnAttributeChange"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(int32*)(params.GetStructMemory() + 0) = Params.key;
		*(int32*)(params.GetStructMemory() + 4) = Params.value;
		*(bool*)(params.GetStructMemory() + 8) = Params.isInit;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.key = *(int32*)(params.GetStructMemory() + 0);
		Params.value = *(int32*)(params.GetStructMemory() + 4);
		Params.isInit = *(bool*)(params.GetStructMemory() + 8);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 GetAttribute(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"RefLevelScriptBase",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"RefLevelScriptBase must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		int32 key;
		int32 ReturnValue;
	} Params;
	Params.key = (luaL_checkint(InScriptContext, 2));
#if UE_GAME
	ARefLevelScriptBase * This = (ARefLevelScriptBase *)Obj;
	Params.ReturnValue = This->GetAttribute(Params.key);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetAttribute"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(int32*)(params.GetStructMemory() + 0) = Params.key;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.key = *(int32*)(params.GetStructMemory() + 0);
		Params.ReturnValue = *(int32*)(params.GetStructMemory() + 4);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushinteger(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 FindLevelObjcet(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"RefLevelScriptBase",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"RefLevelScriptBase must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FString PathStr;
		UObject* ReturnValue = nullptr;
	} Params;
	Params.PathStr = UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 2));
#if UE_GAME
	ARefLevelScriptBase * This = (ARefLevelScriptBase *)Obj;
	Params.ReturnValue = This->FindLevelObjcet(Params.PathStr);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("FindLevelObjcet"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FString*)(params.GetStructMemory() + 0) = Params.PathStr;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.PathStr = *(FString*)(params.GetStructMemory() + 0);
		Params.ReturnValue = *(UObject**)(params.GetStructMemory() + 16);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 EnableGravityOfPlayers(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"RefLevelScriptBase",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"RefLevelScriptBase must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool isEnable;
	} Params;
	Params.isEnable = !!(lua_toboolean(InScriptContext, 2));
#if UE_GAME
	ARefLevelScriptBase * This = (ARefLevelScriptBase *)Obj;
	This->EnableGravityOfPlayers(Params.isEnable);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("EnableGravityOfPlayers"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(bool*)(params.GetStructMemory() + 0) = Params.isEnable;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.isEnable = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 CallDynamicLuaInterface(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"RefLevelScriptBase",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"RefLevelScriptBase must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		TMap<FString,float> InFloatMap;
		TMap<FString,FString> InStringMap;
	} Params;
	Params.InFloatMap = [](lua_State * _InScriptContext){ TMap<FString,float> ret; lua_pushnil(_InScriptContext); while(lua_next(_InScriptContext,2)!=0){FString key =UTF8_TO_TCHAR(luaL_checkstring(_InScriptContext, -2)); float item = (float)(luaL_checknumber(_InScriptContext, -1)); ret.Add(key,item); lua_pop(_InScriptContext,1);  } return ret; }(InScriptContext);;
	Params.InStringMap = [](lua_State * _InScriptContext){ TMap<FString,FString> ret; lua_pushnil(_InScriptContext); while(lua_next(_InScriptContext,3)!=0){FString key =UTF8_TO_TCHAR(luaL_checkstring(_InScriptContext, -2)); FString item = UTF8_TO_TCHAR(luaL_checkstring(_InScriptContext, -1)); ret.Add(key,item); lua_pop(_InScriptContext,1);  } return ret; }(InScriptContext);;
#if UE_GAME
	ARefLevelScriptBase * This = (ARefLevelScriptBase *)Obj;
	This->CallDynamicLuaInterface(Params.InFloatMap,Params.InStringMap);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("CallDynamicLuaInterface"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(TMap<FString,float>*)(params.GetStructMemory() + 0) = Params.InFloatMap;
		*(TMap<FString,FString>*)(params.GetStructMemory() + 80) = Params.InStringMap;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.InFloatMap = *(TMap<FString,float>*)(params.GetStructMemory() + 0);
		Params.InStringMap = *(TMap<FString,FString>*)(params.GetStructMemory() + 80);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 New(lua_State* InScriptContext)
{
	UObject* Outer = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Object");
	FName Name = FName(luaL_checkstring(InScriptContext, 2));
	UObject* Obj = NewObject<ARefLevelScriptBase>(Outer, Name);
	wLua::FLuaUtils::ReturnUObject(InScriptContext,Obj);
	return 1;
}

int32 Destroy(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"RefLevelScriptBase",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"RefLevelScriptBase must be non-null"); lua_error(InScriptContext);  return 0;}
		AActor * actor = Cast<AActor>(Obj);
		actor->Destroy();
		userdata->flag |= wLua::LuaObjectFlag::DESTROYED;
		wLua::FLuaUtils::RemoveObjectReference(Obj, userdata->stamp, InScriptContext);
#ifdef AZURE_BUILD_WLUACHECK
		UE_LOG(LogAzure, Warning, TEXT("Destroy RefLevelScriptBase: %x userdata:%x   stamp:%x"),Obj,userdata,userdata->stamp);
#endif
	return 0;
}

int32 Class(lua_State* InScriptContext)
{
	UClass* Class = ARefLevelScriptBase::StaticClass();
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Class);
	return 1;
}

const luaL_Reg Lib_Funcs[] =
{
	{ "New", New },
	{ "Destroy", Destroy },
	{ "Class", Class },
	{ "UnLoadAllSubLevel", UnLoadAllSubLevel },
	{ "SwitchToOriginLevel", SwitchToOriginLevel },
	{ "SetEnvironmentPresetVaild", SetEnvironmentPresetVaild },
	{ "SetAttributeValue", SetAttributeValue },
	{ "OnAttributeChange", OnAttributeChange },
	{ "GetAttribute", GetAttribute },
	{ "FindLevelObjcet", FindLevelObjcet },
	{ "EnableGravityOfPlayers", EnableGravityOfPlayers },
	{ "CallDynamicLuaInterface", CallDynamicLuaInterface },
	{ "InitLuaInterfaceRef", InitLuaInterfaceRef },
	{ "is_nil", wLua::LuaStatic::isnil },
	{ "__gc", wLua::LuaStatic::removeUClassFrameCache },
	{ NULL, NULL }
};

void Register(lua_State *InScriptContext)
{
	lua_newtable(InScriptContext);
	luaL_register(InScriptContext, NULL, Lib_Funcs);
	AzureHelpFuncs::AuxRegister(InScriptContext, "RefLevelScriptBase");
}
void SetMtLink(lua_State *InScriptContext)
{
	AzureHelpFuncs::AuxSetMtLink(InScriptContext, "RefLevelScriptBase", "Actor",USERDATATYPE_UOBJECT);
}

}