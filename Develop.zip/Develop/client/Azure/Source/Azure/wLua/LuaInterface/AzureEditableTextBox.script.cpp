#include "Azure.h"
#include "Utility/help_funcs.h"
#include "wLua/UObjectHeaders.h"
#include "AzureEditableTextBox.h"
#include "AzureLuaIntegration.h"

namespace LuaAzureEditableTextBox
{
int32 InsertRawHTMLTextAtLast(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEditableTextBox",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEditableTextBox must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FString InString;
	} Params;
	Params.InString = UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 2));
#if UE_GAME
	UAzureEditableTextBox * This = (UAzureEditableTextBox *)Obj;
	This->InsertRawHTMLTextAtLast(Params.InString);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("InsertRawHTMLTextAtLast"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FString*)(params.GetStructMemory() + 0) = Params.InString;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.InString = *(FString*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 InsertRawHTMLTextAtCursor(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEditableTextBox",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEditableTextBox must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FString InString;
	} Params;
	Params.InString = UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 2));
#if UE_GAME
	UAzureEditableTextBox * This = (UAzureEditableTextBox *)Obj;
	This->InsertRawHTMLTextAtCursor(Params.InString);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("InsertRawHTMLTextAtCursor"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FString*)(params.GetStructMemory() + 0) = Params.InString;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.InString = *(FString*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 GetCursorLocation(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEditableTextBox",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEditableTextBox must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		int32 ReturnValue;
	} Params;
#if UE_GAME
	UAzureEditableTextBox * This = (UAzureEditableTextBox *)Obj;
	Params.ReturnValue = This->GetCursorLocation();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetCursorLocation"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(int32*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushinteger(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 Get_LengthLimited(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEditableTextBox",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEditableTextBox must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzureEditableTextBox::StaticClass(), TEXT("LengthLimited"));
	if(!Property) { check(false); return 0;}
	int32 PropertyValue = int32();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushinteger(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_LengthLimited(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEditableTextBox",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEditableTextBox must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzureEditableTextBox::StaticClass(), TEXT("LengthLimited"));
	if(!Property) { check(false); return 0;}
	int32 PropertyValue = (luaL_checkint(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_IsNumericOnly(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEditableTextBox",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEditableTextBox must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzureEditableTextBox::StaticClass(), TEXT("IsNumericOnly"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = bool();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_IsNumericOnly(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEditableTextBox",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEditableTextBox must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzureEditableTextBox::StaticClass(), TEXT("IsNumericOnly"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_NotifyWhenVirtualKeyboardShowHide(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEditableTextBox",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEditableTextBox must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzureEditableTextBox::StaticClass(), TEXT("NotifyWhenVirtualKeyboardShowHide"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = bool();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_NotifyWhenVirtualKeyboardShowHide(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEditableTextBox",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEditableTextBox must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzureEditableTextBox::StaticClass(), TEXT("NotifyWhenVirtualKeyboardShowHide"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bIsHTML(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEditableTextBox",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEditableTextBox must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzureEditableTextBox::StaticClass(), TEXT("bIsHTML"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = bool();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bIsHTML(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureEditableTextBox",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureEditableTextBox must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzureEditableTextBox::StaticClass(), TEXT("bIsHTML"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 New(lua_State* InScriptContext)
{
	UObject* Outer = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Object");
	FName Name = FName(luaL_checkstring(InScriptContext, 2));
	UObject* Obj = NewObject<UAzureEditableTextBox>(Outer, Name);
	wLua::FLuaUtils::ReturnUObject(InScriptContext,Obj);
	return 1;
}

int32 Destroy(lua_State* InScriptContext)
{
	return 0;
}

int32 Class(lua_State* InScriptContext)
{
	UClass* Class = UAzureEditableTextBox::StaticClass();
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Class);
	return 1;
}

const luaL_Reg Lib_Funcs[] =
{
	{ "New", New },
	{ "Destroy", Destroy },
	{ "Class", Class },
	{ "InsertRawHTMLTextAtLast", InsertRawHTMLTextAtLast },
	{ "InsertRawHTMLTextAtCursor", InsertRawHTMLTextAtCursor },
	{ "GetCursorLocation", GetCursorLocation },
	{ "Get_LengthLimited", Get_LengthLimited },
	{ "Set_LengthLimited", Set_LengthLimited },
	{ "Get_IsNumericOnly", Get_IsNumericOnly },
	{ "Set_IsNumericOnly", Set_IsNumericOnly },
	{ "Get_NotifyWhenVirtualKeyboardShowHide", Get_NotifyWhenVirtualKeyboardShowHide },
	{ "Set_NotifyWhenVirtualKeyboardShowHide", Set_NotifyWhenVirtualKeyboardShowHide },
	{ "Get_bIsHTML", Get_bIsHTML },
	{ "Set_bIsHTML", Set_bIsHTML },
	{ "is_nil", wLua::LuaStatic::isnil },
	{ "__gc", wLua::LuaStatic::removeUClassFrameCache },
	{ NULL, NULL }
};

void Register(lua_State *InScriptContext)
{
	lua_newtable(InScriptContext);
	luaL_register(InScriptContext, NULL, Lib_Funcs);
	AzureHelpFuncs::AuxRegister(InScriptContext, "AzureEditableTextBox");
}
void SetMtLink(lua_State *InScriptContext)
{
	AzureHelpFuncs::AuxSetMtLink(InScriptContext, "AzureEditableTextBox", "EditableTextBox",USERDATATYPE_UOBJECT);
}

}