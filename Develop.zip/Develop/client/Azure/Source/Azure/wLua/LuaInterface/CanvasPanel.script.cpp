#include "Azure.h"
#include "Utility/help_funcs.h"
#include "wLua/UObjectHeaders.h"
#include "Components/CanvasPanel.h"
#include "AzureLuaIntegration.h"

namespace LuaCanvasPanel
{
int32 AddChildToCanvas(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"CanvasPanel",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"CanvasPanel must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		UWidget* Content = nullptr;
		UCanvasPanelSlot* ReturnValue = nullptr;
	} Params;
	Params.Content = (UWidget*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"Widget");;
#if UE_GAME
	UCanvasPanel * This = (UCanvasPanel *)Obj;
	Params.ReturnValue = This->AddChildToCanvas(Params.Content);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("AddChildToCanvas"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(UWidget**)(params.GetStructMemory() + 0) = Params.Content;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.Content = *(UWidget**)(params.GetStructMemory() + 0);
		Params.ReturnValue = *(UCanvasPanelSlot**)(params.GetStructMemory() + 8);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 New(lua_State* InScriptContext)
{
	UObject* Outer = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Object");
	FName Name = FName(luaL_checkstring(InScriptContext, 2));
	UObject* Obj = NewObject<UCanvasPanel>(Outer, Name);
	wLua::FLuaUtils::ReturnUObject(InScriptContext,Obj);
	return 1;
}

int32 Destroy(lua_State* InScriptContext)
{
	return 0;
}

int32 Class(lua_State* InScriptContext)
{
	UClass* Class = UCanvasPanel::StaticClass();
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Class);
	return 1;
}

const luaL_Reg Lib_Funcs[] =
{
	{ "New", New },
	{ "Destroy", Destroy },
	{ "Class", Class },
	{ "AddChildToCanvas", AddChildToCanvas },
	{ "is_nil", wLua::LuaStatic::isnil },
	{ "__gc", wLua::LuaStatic::removeUClassFrameCache },
	{ NULL, NULL }
};

void Register(lua_State *InScriptContext)
{
	lua_newtable(InScriptContext);
	luaL_register(InScriptContext, NULL, Lib_Funcs);
	AzureHelpFuncs::AuxRegister(InScriptContext, "CanvasPanel");
}
void SetMtLink(lua_State *InScriptContext)
{
	AzureHelpFuncs::AuxSetMtLink(InScriptContext, "CanvasPanel", "PanelWidget",USERDATATYPE_UOBJECT);
}

}