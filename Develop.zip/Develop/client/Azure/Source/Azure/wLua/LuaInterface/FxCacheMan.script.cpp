#include "Azure.h"
#include "Utility/help_funcs.h"
#include "wLua/UObjectHeaders.h"
#include "Fx/FxCacheMan.h"
#include "../UClassHeaders.h"
#include "AzureLuaIntegration.h"

namespace LuaFxCacheMan
{
int32 CollectActiveFxRestriction(lua_State*);
int32 DumpActiveFxProxyInfo(lua_State*);
int32 StopAllActiveFx(lua_State*);

int32 UnRegisterAzureFxProxy(lua_State* InScriptContext)
{
	UClass * Obj = AFxCacheMan::StaticClass(); 
	struct FDispatchParams
	{
		UParticleSystemComponent* PSComponent = nullptr;
	} Params;
	Params.PSComponent = (UParticleSystemComponent*)wLua::FLuaUtils::GetUObject(InScriptContext,1,"ParticleSystemComponent");;
#if UE_GAME
	AFxCacheMan::UnRegisterAzureFxProxy(Params.PSComponent);
#else
	UFunction* Function = Obj->FindFunctionByName(TEXT("UnRegisterAzureFxProxy"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(UParticleSystemComponent**)(params.GetStructMemory() + 0) = Params.PSComponent;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.PSComponent = *(UParticleSystemComponent**)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetMaxFxCountWithQualityAndCost(lua_State* InScriptContext)
{
	UClass * Obj = AFxCacheMan::StaticClass(); 
	struct FDispatchParams
	{
		int32 InFxQuality;
		int32 InFxCost;
		int32 count;
	} Params;
	Params.InFxQuality = (luaL_checkint(InScriptContext, 1));
	Params.InFxCost = (luaL_checkint(InScriptContext, 2));
	Params.count = (luaL_checkint(InScriptContext, 3));
#if UE_GAME
	AFxCacheMan::SetMaxFxCountWithQualityAndCost(Params.InFxQuality,Params.InFxCost,Params.count);
#else
	UFunction* Function = Obj->FindFunctionByName(TEXT("SetMaxFxCountWithQualityAndCost"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(int32*)(params.GetStructMemory() + 0) = Params.InFxQuality;
		*(int32*)(params.GetStructMemory() + 4) = Params.InFxCost;
		*(int32*)(params.GetStructMemory() + 8) = Params.count;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.InFxQuality = *(int32*)(params.GetStructMemory() + 0);
		Params.InFxCost = *(int32*)(params.GetStructMemory() + 4);
		Params.count = *(int32*)(params.GetStructMemory() + 8);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetLodCostofQuality(lua_State* InScriptContext)
{
	UClass * Obj = AFxCacheMan::StaticClass(); 
	struct FDispatchParams
	{
		int32 Quality;
		int32 MaxLod;
		int32 MaxCost;
	} Params;
	Params.Quality = (luaL_checkint(InScriptContext, 1));
	Params.MaxLod = (luaL_checkint(InScriptContext, 2));
	Params.MaxCost = (luaL_checkint(InScriptContext, 3));
#if UE_GAME
	AFxCacheMan::SetLodCostofQuality(Params.Quality,Params.MaxLod,Params.MaxCost);
#else
	UFunction* Function = Obj->FindFunctionByName(TEXT("SetLodCostofQuality"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(int32*)(params.GetStructMemory() + 0) = Params.Quality;
		*(int32*)(params.GetStructMemory() + 4) = Params.MaxLod;
		*(int32*)(params.GetStructMemory() + 8) = Params.MaxCost;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.Quality = *(int32*)(params.GetStructMemory() + 0);
		Params.MaxLod = *(int32*)(params.GetStructMemory() + 4);
		Params.MaxCost = *(int32*)(params.GetStructMemory() + 8);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetFxCachePolicy(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"FxCacheMan",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"FxCacheMan must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FxCachePolicy Policy;
	} Params;
	Params.Policy = (FxCachePolicy)(luaL_checkint(InScriptContext, 2));
#if UE_GAME
	AFxCacheMan * This = (AFxCacheMan *)Obj;
	This->SetFxCachePolicy(Params.Policy);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetFxCachePolicy"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FxCachePolicy*)(params.GetStructMemory() + 0) = Params.Policy;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.Policy = *(FxCachePolicy*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetCurrentQuality(lua_State* InScriptContext)
{
	UClass * Obj = AFxCacheMan::StaticClass(); 
	struct FDispatchParams
	{
		int32 Quality;
	} Params;
	Params.Quality = (luaL_checkint(InScriptContext, 1));
#if UE_GAME
	AFxCacheMan::SetCurrentQuality(Params.Quality);
#else
	UFunction* Function = Obj->FindFunctionByName(TEXT("SetCurrentQuality"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(int32*)(params.GetStructMemory() + 0) = Params.Quality;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.Quality = *(int32*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetCurFxCountWithQualityAndCost(lua_State* InScriptContext)
{
	UClass * Obj = AFxCacheMan::StaticClass(); 
	struct FDispatchParams
	{
		int32 InFxQuality;
		int32 InFxCost;
		int32 count;
	} Params;
	Params.InFxQuality = (luaL_checkint(InScriptContext, 1));
	Params.InFxCost = (luaL_checkint(InScriptContext, 2));
	Params.count = (luaL_checkint(InScriptContext, 3));
#if UE_GAME
	AFxCacheMan::SetCurFxCountWithQualityAndCost(Params.InFxQuality,Params.InFxCost,Params.count);
#else
	UFunction* Function = Obj->FindFunctionByName(TEXT("SetCurFxCountWithQualityAndCost"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(int32*)(params.GetStructMemory() + 0) = Params.InFxQuality;
		*(int32*)(params.GetStructMemory() + 4) = Params.InFxCost;
		*(int32*)(params.GetStructMemory() + 8) = Params.count;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.InFxQuality = *(int32*)(params.GetStructMemory() + 0);
		Params.InFxCost = *(int32*)(params.GetStructMemory() + 4);
		Params.count = *(int32*)(params.GetStructMemory() + 8);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 Set_RenderHide(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"FxCacheMan",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"FxCacheMan must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool hide;
	} Params;
	Params.hide = !!(lua_toboolean(InScriptContext, 2));
#if UE_GAME
	AFxCacheMan * This = (AFxCacheMan *)Obj;
	This->Set_RenderHide(Params.hide);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("Set_RenderHide"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(bool*)(params.GetStructMemory() + 0) = Params.hide;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.hide = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 Set_maxUnusedFxCount(lua_State* InScriptContext)
{
	UClass * Obj = AFxCacheMan::StaticClass(); 
	struct FDispatchParams
	{
		int32 count;
	} Params;
	Params.count = (luaL_checkint(InScriptContext, 1));
#if UE_GAME
	AFxCacheMan::Set_maxUnusedFxCount(Params.count);
#else
	UFunction* Function = Obj->FindFunctionByName(TEXT("Set_maxUnusedFxCount"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(int32*)(params.GetStructMemory() + 0) = Params.count;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.count = *(int32*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 Set_maxFxCount(lua_State* InScriptContext)
{
	UClass * Obj = AFxCacheMan::StaticClass(); 
	struct FDispatchParams
	{
		int32 count;
	} Params;
	Params.count = (luaL_checkint(InScriptContext, 1));
#if UE_GAME
	AFxCacheMan::Set_maxFxCount(Params.count);
#else
	UFunction* Function = Obj->FindFunctionByName(TEXT("Set_maxFxCount"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(int32*)(params.GetStructMemory() + 0) = Params.count;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.count = *(int32*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 Set_FxQuality(lua_State* InScriptContext)
{
	UClass * Obj = AFxCacheMan::StaticClass(); 
	struct FDispatchParams
	{
		int32 value;
	} Params;
	Params.value = (luaL_checkint(InScriptContext, 1));
#if UE_GAME
	AFxCacheMan::Set_FxQuality(Params.value);
#else
	UFunction* Function = Obj->FindFunctionByName(TEXT("Set_FxQuality"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(int32*)(params.GetStructMemory() + 0) = Params.value;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.value = *(int32*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 RequestFx(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"FxCacheMan",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"FxCacheMan must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FString InName;
		int32 InPriority;
		UParticleSystem* InFxTemplate = nullptr;
		bool bCanReplay;
		bool bCountLimited;
		AFxOne* ReturnValue = nullptr;
	} Params;
	Params.InName = UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 2));
	Params.InPriority = lua_isnoneornil(InScriptContext,3) ? int32(0) : (luaL_checkint(InScriptContext, 3));
	Params.InFxTemplate = lua_isnoneornil(InScriptContext,4) ? nullptr : (UParticleSystem*)wLua::FLuaUtils::GetUObject(InScriptContext,4,"ParticleSystem");;
	Params.bCanReplay = lua_isnoneornil(InScriptContext,5) ? bool(false) : !!(lua_toboolean(InScriptContext, 5));
	Params.bCountLimited = lua_isnoneornil(InScriptContext,6) ? bool(true) : !!(lua_toboolean(InScriptContext, 6));
#if UE_GAME
	AFxCacheMan * This = (AFxCacheMan *)Obj;
	Params.ReturnValue = This->RequestFx(Params.InName,Params.InPriority,Params.InFxTemplate,Params.bCanReplay,Params.bCountLimited);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("RequestFx"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FString*)(params.GetStructMemory() + 0) = Params.InName;
		*(int32*)(params.GetStructMemory() + 16) = Params.InPriority;
		*(UParticleSystem**)(params.GetStructMemory() + 24) = Params.InFxTemplate;
		*(bool*)(params.GetStructMemory() + 32) = Params.bCanReplay;
		*(bool*)(params.GetStructMemory() + 33) = Params.bCountLimited;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.InName = *(FString*)(params.GetStructMemory() + 0);
		Params.InPriority = *(int32*)(params.GetStructMemory() + 16);
		Params.InFxTemplate = *(UParticleSystem**)(params.GetStructMemory() + 24);
		Params.bCanReplay = *(bool*)(params.GetStructMemory() + 32);
		Params.bCountLimited = *(bool*)(params.GetStructMemory() + 33);
		Params.ReturnValue = *(AFxOne**)(params.GetStructMemory() + 40);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 RegisterAzureFxProxy(lua_State* InScriptContext)
{
	UClass * Obj = AFxCacheMan::StaticClass(); 
	struct FDispatchParams
	{
		UParticleSystemComponent* PSComponent = nullptr;
		int32 Priority;
		int32 Lod;
	} Params;
	Params.PSComponent = (UParticleSystemComponent*)wLua::FLuaUtils::GetUObject(InScriptContext,1,"ParticleSystemComponent");;
	Params.Priority = (luaL_checkint(InScriptContext, 2));
	Params.Lod = lua_isnoneornil(InScriptContext,3) ? int32(0) : (luaL_checkint(InScriptContext, 3));
#if UE_GAME
	AFxCacheMan::RegisterAzureFxProxy(Params.PSComponent,Params.Priority,Params.Lod);
#else
	UFunction* Function = Obj->FindFunctionByName(TEXT("RegisterAzureFxProxy"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(UParticleSystemComponent**)(params.GetStructMemory() + 0) = Params.PSComponent;
		*(int32*)(params.GetStructMemory() + 8) = Params.Priority;
		*(int32*)(params.GetStructMemory() + 12) = Params.Lod;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.PSComponent = *(UParticleSystemComponent**)(params.GetStructMemory() + 0);
		Params.Priority = *(int32*)(params.GetStructMemory() + 8);
		Params.Lod = *(int32*)(params.GetStructMemory() + 12);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 IsExceedingFxLimitWithQualityAndCost(lua_State* InScriptContext)
{
	UClass * Obj = AFxCacheMan::StaticClass(); 
	struct FDispatchParams
	{
		int32 InFxQuality;
		int32 InFxCost;
		int32 ReturnValue;
	} Params;
	Params.InFxQuality = (luaL_checkint(InScriptContext, 1));
	Params.InFxCost = (luaL_checkint(InScriptContext, 2));
#if UE_GAME
	Params.ReturnValue = AFxCacheMan::IsExceedingFxLimitWithQualityAndCost(Params.InFxQuality,Params.InFxCost);
#else
	UFunction* Function = Obj->FindFunctionByName(TEXT("IsExceedingFxLimitWithQualityAndCost"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(int32*)(params.GetStructMemory() + 0) = Params.InFxQuality;
		*(int32*)(params.GetStructMemory() + 4) = Params.InFxCost;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.InFxQuality = *(int32*)(params.GetStructMemory() + 0);
		Params.InFxCost = *(int32*)(params.GetStructMemory() + 4);
		Params.ReturnValue = *(int32*)(params.GetStructMemory() + 8);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushinteger(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 IncreaseCurFxCountWithQualityAndCost(lua_State* InScriptContext)
{
	UClass * Obj = AFxCacheMan::StaticClass(); 
	struct FDispatchParams
	{
		int32 InFxQuality;
		int32 InFxCost;
	} Params;
	Params.InFxQuality = (luaL_checkint(InScriptContext, 1));
	Params.InFxCost = (luaL_checkint(InScriptContext, 2));
#if UE_GAME
	AFxCacheMan::IncreaseCurFxCountWithQualityAndCost(Params.InFxQuality,Params.InFxCost);
#else
	UFunction* Function = Obj->FindFunctionByName(TEXT("IncreaseCurFxCountWithQualityAndCost"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(int32*)(params.GetStructMemory() + 0) = Params.InFxQuality;
		*(int32*)(params.GetStructMemory() + 4) = Params.InFxCost;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.InFxQuality = *(int32*)(params.GetStructMemory() + 0);
		Params.InFxCost = *(int32*)(params.GetStructMemory() + 4);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 GetMaxLodofCurrentQuality(lua_State* InScriptContext)
{
	UClass * Obj = AFxCacheMan::StaticClass(); 
	struct FDispatchParams
	{
		int32 ReturnValue;
	} Params;
#if UE_GAME
	Params.ReturnValue = AFxCacheMan::GetMaxLodofCurrentQuality();
#else
	UFunction* Function = Obj->FindFunctionByName(TEXT("GetMaxLodofCurrentQuality"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(int32*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushinteger(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetMaxLodCostofCurrentQuality(lua_State* InScriptContext)
{
	UClass * Obj = AFxCacheMan::StaticClass(); 
	struct FDispatchParams
	{
		int32 ReturnValue;
	} Params;
#if UE_GAME
	Params.ReturnValue = AFxCacheMan::GetMaxLodCostofCurrentQuality();
#else
	UFunction* Function = Obj->FindFunctionByName(TEXT("GetMaxLodCostofCurrentQuality"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(int32*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushinteger(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetMaxFxCountWithQualityAndCost(lua_State* InScriptContext)
{
	UClass * Obj = AFxCacheMan::StaticClass(); 
	struct FDispatchParams
	{
		int32 InFxQuality;
		int32 InFxCost;
		int32 ReturnValue;
	} Params;
	Params.InFxQuality = (luaL_checkint(InScriptContext, 1));
	Params.InFxCost = (luaL_checkint(InScriptContext, 2));
#if UE_GAME
	Params.ReturnValue = AFxCacheMan::GetMaxFxCountWithQualityAndCost(Params.InFxQuality,Params.InFxCost);
#else
	UFunction* Function = Obj->FindFunctionByName(TEXT("GetMaxFxCountWithQualityAndCost"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(int32*)(params.GetStructMemory() + 0) = Params.InFxQuality;
		*(int32*)(params.GetStructMemory() + 4) = Params.InFxCost;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.InFxQuality = *(int32*)(params.GetStructMemory() + 0);
		Params.InFxCost = *(int32*)(params.GetStructMemory() + 4);
		Params.ReturnValue = *(int32*)(params.GetStructMemory() + 8);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushinteger(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetFxCachePolicy(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"FxCacheMan",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"FxCacheMan must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FxCachePolicy ReturnValue;
	} Params;
#if UE_GAME
	AFxCacheMan * This = (AFxCacheMan *)Obj;
	Params.ReturnValue = This->GetFxCachePolicy();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetFxCachePolicy"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(FxCachePolicy*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushinteger(InScriptContext, (int)Params.ReturnValue);
	return 1;
}

int32 GetCurrentTotalCost(lua_State* InScriptContext)
{
	UClass * Obj = AFxCacheMan::StaticClass(); 
	struct FDispatchParams
	{
		int32 ReturnValue;
	} Params;
#if UE_GAME
	Params.ReturnValue = AFxCacheMan::GetCurrentTotalCost();
#else
	UFunction* Function = Obj->FindFunctionByName(TEXT("GetCurrentTotalCost"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(int32*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushinteger(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetCurrentQuality(lua_State* InScriptContext)
{
	UClass * Obj = AFxCacheMan::StaticClass(); 
	struct FDispatchParams
	{
		int32 ReturnValue;
	} Params;
#if UE_GAME
	Params.ReturnValue = AFxCacheMan::GetCurrentQuality();
#else
	UFunction* Function = Obj->FindFunctionByName(TEXT("GetCurrentQuality"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(int32*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushinteger(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetCurFxCountWithQualityAndCost(lua_State* InScriptContext)
{
	UClass * Obj = AFxCacheMan::StaticClass(); 
	struct FDispatchParams
	{
		int32 InFxQuality;
		int32 InFxCost;
		int32 ReturnValue;
	} Params;
	Params.InFxQuality = (luaL_checkint(InScriptContext, 1));
	Params.InFxCost = (luaL_checkint(InScriptContext, 2));
#if UE_GAME
	Params.ReturnValue = AFxCacheMan::GetCurFxCountWithQualityAndCost(Params.InFxQuality,Params.InFxCost);
#else
	UFunction* Function = Obj->FindFunctionByName(TEXT("GetCurFxCountWithQualityAndCost"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(int32*)(params.GetStructMemory() + 0) = Params.InFxQuality;
		*(int32*)(params.GetStructMemory() + 4) = Params.InFxCost;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.InFxQuality = *(int32*)(params.GetStructMemory() + 0);
		Params.InFxCost = *(int32*)(params.GetStructMemory() + 4);
		Params.ReturnValue = *(int32*)(params.GetStructMemory() + 8);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushinteger(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetActiveFxOnes(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"FxCacheMan",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"FxCacheMan must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		TArray<AFxOne*> ReturnValue;
	} Params;
#if UE_GAME
	AFxCacheMan * This = (AFxCacheMan *)Obj;
	Params.ReturnValue = This->GetActiveFxOnes();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetActiveFxOnes"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(TArray<AFxOne*>*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	{lua_newtable(InScriptContext); int i = 1; for(auto It = Params.ReturnValue.CreateConstIterator(); It; ++It,++i) {  wLua::FLuaUtils::ReturnUObject(InScriptContext, (*It)); lua_rawseti(InScriptContext,-2,i);     }  }
	return 1;
}

int32 Get_RenderHide(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"FxCacheMan",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"FxCacheMan must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool ReturnValue;
	} Params;
#if UE_GAME
	AFxCacheMan * This = (AFxCacheMan *)Obj;
	Params.ReturnValue = This->Get_RenderHide();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("Get_RenderHide"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushboolean(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 Get_maxUnusedFxCount(lua_State* InScriptContext)
{
	UClass * Obj = AFxCacheMan::StaticClass(); 
	struct FDispatchParams
	{
		int32 ReturnValue;
	} Params;
#if UE_GAME
	Params.ReturnValue = AFxCacheMan::Get_maxUnusedFxCount();
#else
	UFunction* Function = Obj->FindFunctionByName(TEXT("Get_maxUnusedFxCount"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(int32*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushinteger(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 Get_maxFxCount(lua_State* InScriptContext)
{
	UClass * Obj = AFxCacheMan::StaticClass(); 
	struct FDispatchParams
	{
		int32 ReturnValue;
	} Params;
#if UE_GAME
	Params.ReturnValue = AFxCacheMan::Get_maxFxCount();
#else
	UFunction* Function = Obj->FindFunctionByName(TEXT("Get_maxFxCount"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(int32*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushinteger(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 Get_FxQuality(lua_State* InScriptContext)
{
	UClass * Obj = AFxCacheMan::StaticClass(); 
	struct FDispatchParams
	{
		int32 ReturnValue;
	} Params;
#if UE_GAME
	Params.ReturnValue = AFxCacheMan::Get_FxQuality();
#else
	UFunction* Function = Obj->FindFunctionByName(TEXT("Get_FxQuality"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(int32*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushinteger(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 Get_currentFxCount(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"FxCacheMan",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"FxCacheMan must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		int32 ReturnValue;
	} Params;
#if UE_GAME
	AFxCacheMan * This = (AFxCacheMan *)Obj;
	Params.ReturnValue = This->Get_currentFxCount();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("Get_currentFxCount"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(int32*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushinteger(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 FxQualityToLODLevel(lua_State* InScriptContext)
{
	UClass * Obj = AFxCacheMan::StaticClass(); 
	struct FDispatchParams
	{
		int32 InFxQuality;
		int32 InLODLevelCount;
		int32 ReturnValue;
	} Params;
	Params.InFxQuality = (luaL_checkint(InScriptContext, 1));
	Params.InLODLevelCount = (luaL_checkint(InScriptContext, 2));
#if UE_GAME
	Params.ReturnValue = AFxCacheMan::FxQualityToLODLevel(Params.InFxQuality,Params.InLODLevelCount);
#else
	UFunction* Function = Obj->FindFunctionByName(TEXT("FxQualityToLODLevel"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(int32*)(params.GetStructMemory() + 0) = Params.InFxQuality;
		*(int32*)(params.GetStructMemory() + 4) = Params.InLODLevelCount;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.InFxQuality = *(int32*)(params.GetStructMemory() + 0);
		Params.InLODLevelCount = *(int32*)(params.GetStructMemory() + 4);
		Params.ReturnValue = *(int32*)(params.GetStructMemory() + 8);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushinteger(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 DecreaseCurFxCountWithQualityAndCost(lua_State* InScriptContext)
{
	UClass * Obj = AFxCacheMan::StaticClass(); 
	struct FDispatchParams
	{
		int32 InFxQuality;
		int32 InFxCost;
	} Params;
	Params.InFxQuality = (luaL_checkint(InScriptContext, 1));
	Params.InFxCost = (luaL_checkint(InScriptContext, 2));
#if UE_GAME
	AFxCacheMan::DecreaseCurFxCountWithQualityAndCost(Params.InFxQuality,Params.InFxCost);
#else
	UFunction* Function = Obj->FindFunctionByName(TEXT("DecreaseCurFxCountWithQualityAndCost"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(int32*)(params.GetStructMemory() + 0) = Params.InFxQuality;
		*(int32*)(params.GetStructMemory() + 4) = Params.InFxCost;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.InFxQuality = *(int32*)(params.GetStructMemory() + 0);
		Params.InFxCost = *(int32*)(params.GetStructMemory() + 4);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 New(lua_State* InScriptContext)
{
	UObject* Outer = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Object");
	FName Name = FName(luaL_checkstring(InScriptContext, 2));
	UObject* Obj = NewObject<AFxCacheMan>(Outer, Name);
	wLua::FLuaUtils::ReturnUObject(InScriptContext,Obj);
	return 1;
}

int32 Destroy(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"FxCacheMan",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"FxCacheMan must be non-null"); lua_error(InScriptContext);  return 0;}
		AActor * actor = Cast<AActor>(Obj);
		actor->Destroy();
		userdata->flag |= wLua::LuaObjectFlag::DESTROYED;
		wLua::FLuaUtils::RemoveObjectReference(Obj, userdata->stamp, InScriptContext);
#ifdef AZURE_BUILD_WLUACHECK
		UE_LOG(LogAzure, Warning, TEXT("Destroy FxCacheMan: %x userdata:%x   stamp:%x"),Obj,userdata,userdata->stamp);
#endif
	return 0;
}

int32 Class(lua_State* InScriptContext)
{
	UClass* Class = AFxCacheMan::StaticClass();
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Class);
	return 1;
}

const luaL_Reg Lib_Funcs[] =
{
	{ "New", New },
	{ "Destroy", Destroy },
	{ "Class", Class },
	{ "UnRegisterAzureFxProxy", UnRegisterAzureFxProxy },
	{ "SetMaxFxCountWithQualityAndCost", SetMaxFxCountWithQualityAndCost },
	{ "SetLodCostofQuality", SetLodCostofQuality },
	{ "SetFxCachePolicy", SetFxCachePolicy },
	{ "SetCurrentQuality", SetCurrentQuality },
	{ "SetCurFxCountWithQualityAndCost", SetCurFxCountWithQualityAndCost },
	{ "Set_RenderHide", Set_RenderHide },
	{ "Set_maxUnusedFxCount", Set_maxUnusedFxCount },
	{ "Set_maxFxCount", Set_maxFxCount },
	{ "Set_FxQuality", Set_FxQuality },
	{ "RequestFx", RequestFx },
	{ "RegisterAzureFxProxy", RegisterAzureFxProxy },
	{ "IsExceedingFxLimitWithQualityAndCost", IsExceedingFxLimitWithQualityAndCost },
	{ "IncreaseCurFxCountWithQualityAndCost", IncreaseCurFxCountWithQualityAndCost },
	{ "GetMaxLodofCurrentQuality", GetMaxLodofCurrentQuality },
	{ "GetMaxLodCostofCurrentQuality", GetMaxLodCostofCurrentQuality },
	{ "GetMaxFxCountWithQualityAndCost", GetMaxFxCountWithQualityAndCost },
	{ "GetFxCachePolicy", GetFxCachePolicy },
	{ "GetCurrentTotalCost", GetCurrentTotalCost },
	{ "GetCurrentQuality", GetCurrentQuality },
	{ "GetCurFxCountWithQualityAndCost", GetCurFxCountWithQualityAndCost },
	{ "GetActiveFxOnes", GetActiveFxOnes },
	{ "Get_RenderHide", Get_RenderHide },
	{ "Get_maxUnusedFxCount", Get_maxUnusedFxCount },
	{ "Get_maxFxCount", Get_maxFxCount },
	{ "Get_FxQuality", Get_FxQuality },
	{ "Get_currentFxCount", Get_currentFxCount },
	{ "FxQualityToLODLevel", FxQualityToLODLevel },
	{ "DecreaseCurFxCountWithQualityAndCost", DecreaseCurFxCountWithQualityAndCost },
	{ "CollectActiveFxRestriction", CollectActiveFxRestriction },
	{ "DumpActiveFxProxyInfo", DumpActiveFxProxyInfo },
	{ "StopAllActiveFx", StopAllActiveFx },
	{ "is_nil", wLua::LuaStatic::isnil },
	{ "__gc", wLua::LuaStatic::removeUClassFrameCache },
	{ NULL, NULL }
};

void Register(lua_State *InScriptContext)
{
	lua_newtable(InScriptContext);
	luaL_register(InScriptContext, NULL, Lib_Funcs);
	AzureHelpFuncs::AuxRegister(InScriptContext, "FxCacheMan");
}
void SetMtLink(lua_State *InScriptContext)
{
	AzureHelpFuncs::AuxSetMtLink(InScriptContext, "FxCacheMan", "Actor",USERDATATYPE_UOBJECT);
}

}