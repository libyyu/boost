#include "Azure.h"
#include "Utility/help_funcs.h"
#include "wLua/UObjectHeaders.h"
#include "MediaSource.h"
#include "AzureLuaIntegration.h"

namespace LuaMediaSource
{
int32 Validate(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MediaSource",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MediaSource must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool ReturnValue;
	} Params;
#if UE_GAME
	UMediaSource * This = (UMediaSource *)Obj;
	Params.ReturnValue = This->Validate();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("Validate"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushboolean(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetUrl(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MediaSource",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MediaSource must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FString ReturnValue;
	} Params;
#if UE_GAME
	UMediaSource * This = (UMediaSource *)Obj;
	Params.ReturnValue = This->GetUrl();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetUrl"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(FString*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushstring(InScriptContext, TCHAR_TO_UTF8(*Params.ReturnValue));
	return 1;
}

int32 Class(lua_State* InScriptContext)
{
	UClass* Class = UMediaSource::StaticClass();
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Class);
	return 1;
}

const luaL_Reg Lib_Funcs[] =
{
	{ "Class", Class },
	{ "Validate", Validate },
	{ "GetUrl", GetUrl },
	{ "is_nil", wLua::LuaStatic::isnil },
	{ "__gc", wLua::LuaStatic::removeUClassFrameCache },
	{ NULL, NULL }
};

void Register(lua_State *InScriptContext)
{
	lua_newtable(InScriptContext);
	luaL_register(InScriptContext, NULL, Lib_Funcs);
	AzureHelpFuncs::AuxRegister(InScriptContext, "MediaSource");
}
void SetMtLink(lua_State *InScriptContext)
{
	AzureHelpFuncs::AuxSetMtLink(InScriptContext, "MediaSource", "Object",USERDATATYPE_UOBJECT);
}

}