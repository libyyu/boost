#include "Azure.h"
#include "Utility/help_funcs.h"
#include "wLua/UObjectHeaders.h"
#include "WheeledVehicleMovementComponent.h"
#include "AzureLuaIntegration.h"

namespace LuaWheeledVehicleMovementComponent
{
int32 SetUseAutoGears(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"WheeledVehicleMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"WheeledVehicleMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool bUseAuto;
	} Params;
	Params.bUseAuto = !!(lua_toboolean(InScriptContext, 2));
#if UE_GAME
	UWheeledVehicleMovementComponent * This = (UWheeledVehicleMovementComponent *)Obj;
	This->SetUseAutoGears(Params.bUseAuto);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetUseAutoGears"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(bool*)(params.GetStructMemory() + 0) = Params.bUseAuto;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.bUseAuto = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetThrottleInput(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"WheeledVehicleMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"WheeledVehicleMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float Throttle;
	} Params;
	Params.Throttle = (float)(luaL_checknumber(InScriptContext, 2));
#if UE_GAME
	UWheeledVehicleMovementComponent * This = (UWheeledVehicleMovementComponent *)Obj;
	This->SetThrottleInput(Params.Throttle);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetThrottleInput"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(float*)(params.GetStructMemory() + 0) = Params.Throttle;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.Throttle = *(float*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetTargetGear(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"WheeledVehicleMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"WheeledVehicleMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		int32 GearNum;
		bool bImmediate;
	} Params;
	Params.GearNum = (luaL_checkint(InScriptContext, 2));
	Params.bImmediate = !!(lua_toboolean(InScriptContext, 3));
#if UE_GAME
	UWheeledVehicleMovementComponent * This = (UWheeledVehicleMovementComponent *)Obj;
	This->SetTargetGear(Params.GearNum,Params.bImmediate);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetTargetGear"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(int32*)(params.GetStructMemory() + 0) = Params.GearNum;
		*(bool*)(params.GetStructMemory() + 4) = Params.bImmediate;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.GearNum = *(int32*)(params.GetStructMemory() + 0);
		Params.bImmediate = *(bool*)(params.GetStructMemory() + 4);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetSteeringInput(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"WheeledVehicleMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"WheeledVehicleMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float Steering;
	} Params;
	Params.Steering = (float)(luaL_checknumber(InScriptContext, 2));
#if UE_GAME
	UWheeledVehicleMovementComponent * This = (UWheeledVehicleMovementComponent *)Obj;
	This->SetSteeringInput(Params.Steering);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetSteeringInput"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(float*)(params.GetStructMemory() + 0) = Params.Steering;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.Steering = *(float*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetHandbrakeInput(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"WheeledVehicleMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"WheeledVehicleMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool bNewHandbrake;
	} Params;
	Params.bNewHandbrake = !!(lua_toboolean(InScriptContext, 2));
#if UE_GAME
	UWheeledVehicleMovementComponent * This = (UWheeledVehicleMovementComponent *)Obj;
	This->SetHandbrakeInput(Params.bNewHandbrake);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetHandbrakeInput"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(bool*)(params.GetStructMemory() + 0) = Params.bNewHandbrake;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.bNewHandbrake = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetGearUp(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"WheeledVehicleMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"WheeledVehicleMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool bNewGearUp;
	} Params;
	Params.bNewGearUp = !!(lua_toboolean(InScriptContext, 2));
#if UE_GAME
	UWheeledVehicleMovementComponent * This = (UWheeledVehicleMovementComponent *)Obj;
	This->SetGearUp(Params.bNewGearUp);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetGearUp"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(bool*)(params.GetStructMemory() + 0) = Params.bNewGearUp;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.bNewGearUp = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetGearDown(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"WheeledVehicleMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"WheeledVehicleMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool bNewGearDown;
	} Params;
	Params.bNewGearDown = !!(lua_toboolean(InScriptContext, 2));
#if UE_GAME
	UWheeledVehicleMovementComponent * This = (UWheeledVehicleMovementComponent *)Obj;
	This->SetGearDown(Params.bNewGearDown);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetGearDown"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(bool*)(params.GetStructMemory() + 0) = Params.bNewGearDown;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.bNewGearDown = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetBrakeInput(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"WheeledVehicleMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"WheeledVehicleMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float Brake;
	} Params;
	Params.Brake = (float)(luaL_checknumber(InScriptContext, 2));
#if UE_GAME
	UWheeledVehicleMovementComponent * This = (UWheeledVehicleMovementComponent *)Obj;
	This->SetBrakeInput(Params.Brake);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetBrakeInput"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(float*)(params.GetStructMemory() + 0) = Params.Brake;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.Brake = *(float*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetAvoidanceEnabled(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"WheeledVehicleMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"WheeledVehicleMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool bEnable;
	} Params;
	Params.bEnable = !!(lua_toboolean(InScriptContext, 2));
#if UE_GAME
	UWheeledVehicleMovementComponent * This = (UWheeledVehicleMovementComponent *)Obj;
	This->SetAvoidanceEnabled(Params.bEnable);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetAvoidanceEnabled"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(bool*)(params.GetStructMemory() + 0) = Params.bEnable;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.bEnable = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 ServerUpdateState(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"WheeledVehicleMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"WheeledVehicleMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float InSteeringInput;
		float InThrottleInput;
		float InBrakeInput;
		float InHandbrakeInput;
		int32 CurrentGear;
	} Params;
	Params.InSteeringInput = (float)(luaL_checknumber(InScriptContext, 2));
	Params.InThrottleInput = (float)(luaL_checknumber(InScriptContext, 3));
	Params.InBrakeInput = (float)(luaL_checknumber(InScriptContext, 4));
	Params.InHandbrakeInput = (float)(luaL_checknumber(InScriptContext, 5));
	Params.CurrentGear = (luaL_checkint(InScriptContext, 6));
	UFunction* Function = Obj->FindFunctionChecked(TEXT("ServerUpdateState"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(float*)(params.GetStructMemory() + 0) = Params.InSteeringInput;
		*(float*)(params.GetStructMemory() + 4) = Params.InThrottleInput;
		*(float*)(params.GetStructMemory() + 8) = Params.InBrakeInput;
		*(float*)(params.GetStructMemory() + 12) = Params.InHandbrakeInput;
		*(int32*)(params.GetStructMemory() + 16) = Params.CurrentGear;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.InSteeringInput = *(float*)(params.GetStructMemory() + 0);
		Params.InThrottleInput = *(float*)(params.GetStructMemory() + 4);
		Params.InBrakeInput = *(float*)(params.GetStructMemory() + 8);
		Params.InHandbrakeInput = *(float*)(params.GetStructMemory() + 12);
		Params.CurrentGear = *(int32*)(params.GetStructMemory() + 16);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
	return 0;
}

int32 GetUseAutoGears(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"WheeledVehicleMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"WheeledVehicleMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool ReturnValue;
	} Params;
#if UE_GAME
	UWheeledVehicleMovementComponent * This = (UWheeledVehicleMovementComponent *)Obj;
	Params.ReturnValue = This->GetUseAutoGears();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetUseAutoGears"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushboolean(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetTargetGear(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"WheeledVehicleMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"WheeledVehicleMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		int32 ReturnValue;
	} Params;
#if UE_GAME
	UWheeledVehicleMovementComponent * This = (UWheeledVehicleMovementComponent *)Obj;
	Params.ReturnValue = This->GetTargetGear();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetTargetGear"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(int32*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushinteger(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetForwardSpeed(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"WheeledVehicleMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"WheeledVehicleMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float ReturnValue;
	} Params;
#if UE_GAME
	UWheeledVehicleMovementComponent * This = (UWheeledVehicleMovementComponent *)Obj;
	Params.ReturnValue = This->GetForwardSpeed();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetForwardSpeed"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(float*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushnumber(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetEngineRotationSpeed(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"WheeledVehicleMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"WheeledVehicleMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float ReturnValue;
	} Params;
#if UE_GAME
	UWheeledVehicleMovementComponent * This = (UWheeledVehicleMovementComponent *)Obj;
	Params.ReturnValue = This->GetEngineRotationSpeed();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetEngineRotationSpeed"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(float*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushnumber(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetEngineMaxRotationSpeed(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"WheeledVehicleMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"WheeledVehicleMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float ReturnValue;
	} Params;
#if UE_GAME
	UWheeledVehicleMovementComponent * This = (UWheeledVehicleMovementComponent *)Obj;
	Params.ReturnValue = This->GetEngineMaxRotationSpeed();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetEngineMaxRotationSpeed"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(float*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushnumber(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetCurrentGear(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"WheeledVehicleMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"WheeledVehicleMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		int32 ReturnValue;
	} Params;
#if UE_GAME
	UWheeledVehicleMovementComponent * This = (UWheeledVehicleMovementComponent *)Obj;
	Params.ReturnValue = This->GetCurrentGear();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetCurrentGear"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(int32*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushinteger(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 Get_bDeprecatedSpringOffsetMode(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"WheeledVehicleMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"WheeledVehicleMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UWheeledVehicleMovementComponent::StaticClass(), TEXT("bDeprecatedSpringOffsetMode"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bDeprecatedSpringOffsetMode(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"WheeledVehicleMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"WheeledVehicleMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UWheeledVehicleMovementComponent::StaticClass(), TEXT("bDeprecatedSpringOffsetMode"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bReverseAsBrake(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"WheeledVehicleMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"WheeledVehicleMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UWheeledVehicleMovementComponent::StaticClass(), TEXT("bReverseAsBrake"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bReverseAsBrake(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"WheeledVehicleMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"WheeledVehicleMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UWheeledVehicleMovementComponent::StaticClass(), TEXT("bReverseAsBrake"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bUseRVOAvoidance(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"WheeledVehicleMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"WheeledVehicleMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UWheeledVehicleMovementComponent::StaticClass(), TEXT("bUseRVOAvoidance"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bUseRVOAvoidance(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"WheeledVehicleMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"WheeledVehicleMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UWheeledVehicleMovementComponent::StaticClass(), TEXT("bUseRVOAvoidance"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_Mass(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"WheeledVehicleMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"WheeledVehicleMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UWheeledVehicleMovementComponent::StaticClass(), TEXT("Mass"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_Mass(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"WheeledVehicleMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"WheeledVehicleMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UWheeledVehicleMovementComponent::StaticClass(), TEXT("Mass"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_DragCoefficient(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"WheeledVehicleMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"WheeledVehicleMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UWheeledVehicleMovementComponent::StaticClass(), TEXT("DragCoefficient"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_DragCoefficient(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"WheeledVehicleMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"WheeledVehicleMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UWheeledVehicleMovementComponent::StaticClass(), TEXT("DragCoefficient"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_ChassisWidth(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"WheeledVehicleMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"WheeledVehicleMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UWheeledVehicleMovementComponent::StaticClass(), TEXT("ChassisWidth"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_ChassisWidth(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"WheeledVehicleMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"WheeledVehicleMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UWheeledVehicleMovementComponent::StaticClass(), TEXT("ChassisWidth"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_ChassisHeight(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"WheeledVehicleMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"WheeledVehicleMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UWheeledVehicleMovementComponent::StaticClass(), TEXT("ChassisHeight"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_ChassisHeight(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"WheeledVehicleMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"WheeledVehicleMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UWheeledVehicleMovementComponent::StaticClass(), TEXT("ChassisHeight"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_InertiaTensorScale(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"WheeledVehicleMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"WheeledVehicleMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UWheeledVehicleMovementComponent::StaticClass(), TEXT("InertiaTensorScale"));
	if(!Property) { check(false); return 0;}
	FVector PropertyValue = FVector();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaVector::Return(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_InertiaTensorScale(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"WheeledVehicleMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"WheeledVehicleMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UWheeledVehicleMovementComponent::StaticClass(), TEXT("InertiaTensorScale"));
	if(!Property) { check(false); return 0;}
	FVector PropertyValue = (wLua::FLuaVector::Get(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_MinNormalizedTireLoad(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"WheeledVehicleMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"WheeledVehicleMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UWheeledVehicleMovementComponent::StaticClass(), TEXT("MinNormalizedTireLoad"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_MinNormalizedTireLoad(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"WheeledVehicleMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"WheeledVehicleMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UWheeledVehicleMovementComponent::StaticClass(), TEXT("MinNormalizedTireLoad"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_MinNormalizedTireLoadFiltered(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"WheeledVehicleMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"WheeledVehicleMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UWheeledVehicleMovementComponent::StaticClass(), TEXT("MinNormalizedTireLoadFiltered"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_MinNormalizedTireLoadFiltered(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"WheeledVehicleMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"WheeledVehicleMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UWheeledVehicleMovementComponent::StaticClass(), TEXT("MinNormalizedTireLoadFiltered"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_MaxNormalizedTireLoad(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"WheeledVehicleMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"WheeledVehicleMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UWheeledVehicleMovementComponent::StaticClass(), TEXT("MaxNormalizedTireLoad"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_MaxNormalizedTireLoad(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"WheeledVehicleMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"WheeledVehicleMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UWheeledVehicleMovementComponent::StaticClass(), TEXT("MaxNormalizedTireLoad"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_MaxNormalizedTireLoadFiltered(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"WheeledVehicleMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"WheeledVehicleMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UWheeledVehicleMovementComponent::StaticClass(), TEXT("MaxNormalizedTireLoadFiltered"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_MaxNormalizedTireLoadFiltered(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"WheeledVehicleMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"WheeledVehicleMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UWheeledVehicleMovementComponent::StaticClass(), TEXT("MaxNormalizedTireLoadFiltered"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_ThresholdLongitudinalSpeed(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"WheeledVehicleMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"WheeledVehicleMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UWheeledVehicleMovementComponent::StaticClass(), TEXT("ThresholdLongitudinalSpeed"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_ThresholdLongitudinalSpeed(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"WheeledVehicleMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"WheeledVehicleMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UWheeledVehicleMovementComponent::StaticClass(), TEXT("ThresholdLongitudinalSpeed"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_LowForwardSpeedSubStepCount(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"WheeledVehicleMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"WheeledVehicleMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UWheeledVehicleMovementComponent::StaticClass(), TEXT("LowForwardSpeedSubStepCount"));
	if(!Property) { check(false); return 0;}
	int32 PropertyValue = int32();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushinteger(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_LowForwardSpeedSubStepCount(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"WheeledVehicleMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"WheeledVehicleMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UWheeledVehicleMovementComponent::StaticClass(), TEXT("LowForwardSpeedSubStepCount"));
	if(!Property) { check(false); return 0;}
	int32 PropertyValue = (luaL_checkint(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_HighForwardSpeedSubStepCount(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"WheeledVehicleMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"WheeledVehicleMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UWheeledVehicleMovementComponent::StaticClass(), TEXT("HighForwardSpeedSubStepCount"));
	if(!Property) { check(false); return 0;}
	int32 PropertyValue = int32();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushinteger(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_HighForwardSpeedSubStepCount(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"WheeledVehicleMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"WheeledVehicleMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UWheeledVehicleMovementComponent::StaticClass(), TEXT("HighForwardSpeedSubStepCount"));
	if(!Property) { check(false); return 0;}
	int32 PropertyValue = (luaL_checkint(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_Wheels(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"WheeledVehicleMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"WheeledVehicleMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UWheeledVehicleMovementComponent::StaticClass(), TEXT("Wheels"));
	if(!Property) { check(false); return 0;}
	TArray<UVehicleWheel*> PropertyValue;
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	{lua_newtable(InScriptContext); int i = 1; for(auto It = PropertyValue.CreateConstIterator(); It; ++It,++i) {  wLua::FLuaUtils::ReturnUObject(InScriptContext, (*It)); lua_rawseti(InScriptContext,-2,i);     }  }
	return 1;
}

int32 Get_RVOAvoidanceRadius(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"WheeledVehicleMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"WheeledVehicleMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UWheeledVehicleMovementComponent::StaticClass(), TEXT("RVOAvoidanceRadius"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_RVOAvoidanceRadius(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"WheeledVehicleMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"WheeledVehicleMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UWheeledVehicleMovementComponent::StaticClass(), TEXT("RVOAvoidanceRadius"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_RVOAvoidanceHeight(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"WheeledVehicleMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"WheeledVehicleMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UWheeledVehicleMovementComponent::StaticClass(), TEXT("RVOAvoidanceHeight"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_RVOAvoidanceHeight(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"WheeledVehicleMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"WheeledVehicleMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UWheeledVehicleMovementComponent::StaticClass(), TEXT("RVOAvoidanceHeight"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_AvoidanceConsiderationRadius(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"WheeledVehicleMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"WheeledVehicleMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UWheeledVehicleMovementComponent::StaticClass(), TEXT("AvoidanceConsiderationRadius"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_AvoidanceConsiderationRadius(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"WheeledVehicleMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"WheeledVehicleMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UWheeledVehicleMovementComponent::StaticClass(), TEXT("AvoidanceConsiderationRadius"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_RVOSteeringStep(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"WheeledVehicleMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"WheeledVehicleMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UWheeledVehicleMovementComponent::StaticClass(), TEXT("RVOSteeringStep"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_RVOSteeringStep(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"WheeledVehicleMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"WheeledVehicleMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UWheeledVehicleMovementComponent::StaticClass(), TEXT("RVOSteeringStep"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_RVOThrottleStep(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"WheeledVehicleMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"WheeledVehicleMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UWheeledVehicleMovementComponent::StaticClass(), TEXT("RVOThrottleStep"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_RVOThrottleStep(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"WheeledVehicleMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"WheeledVehicleMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UWheeledVehicleMovementComponent::StaticClass(), TEXT("RVOThrottleStep"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_AvoidanceUID(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"WheeledVehicleMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"WheeledVehicleMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UWheeledVehicleMovementComponent::StaticClass(), TEXT("AvoidanceUID"));
	if(!Property) { check(false); return 0;}
	int32 PropertyValue = int32();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushinteger(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_AvoidanceWeight(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"WheeledVehicleMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"WheeledVehicleMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UWheeledVehicleMovementComponent::StaticClass(), TEXT("AvoidanceWeight"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_IdleBrakeInput(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"WheeledVehicleMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"WheeledVehicleMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UWheeledVehicleMovementComponent::StaticClass(), TEXT("IdleBrakeInput"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_IdleBrakeInput(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"WheeledVehicleMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"WheeledVehicleMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UWheeledVehicleMovementComponent::StaticClass(), TEXT("IdleBrakeInput"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_StopThreshold(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"WheeledVehicleMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"WheeledVehicleMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UWheeledVehicleMovementComponent::StaticClass(), TEXT("StopThreshold"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_StopThreshold(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"WheeledVehicleMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"WheeledVehicleMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UWheeledVehicleMovementComponent::StaticClass(), TEXT("StopThreshold"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_WrongDirectionThreshold(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"WheeledVehicleMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"WheeledVehicleMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UWheeledVehicleMovementComponent::StaticClass(), TEXT("WrongDirectionThreshold"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_WrongDirectionThreshold(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"WheeledVehicleMovementComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"WheeledVehicleMovementComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UWheeledVehicleMovementComponent::StaticClass(), TEXT("WrongDirectionThreshold"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Class(lua_State* InScriptContext)
{
	UClass* Class = UWheeledVehicleMovementComponent::StaticClass();
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Class);
	return 1;
}

const luaL_Reg Lib_Funcs[] =
{
	{ "Class", Class },
	{ "SetUseAutoGears", SetUseAutoGears },
	{ "SetThrottleInput", SetThrottleInput },
	{ "SetTargetGear", SetTargetGear },
	{ "SetSteeringInput", SetSteeringInput },
	{ "SetHandbrakeInput", SetHandbrakeInput },
	{ "SetGearUp", SetGearUp },
	{ "SetGearDown", SetGearDown },
	{ "SetBrakeInput", SetBrakeInput },
	{ "SetAvoidanceEnabled", SetAvoidanceEnabled },
	{ "ServerUpdateState", ServerUpdateState },
	{ "GetUseAutoGears", GetUseAutoGears },
	{ "GetTargetGear", GetTargetGear },
	{ "GetForwardSpeed", GetForwardSpeed },
	{ "GetEngineRotationSpeed", GetEngineRotationSpeed },
	{ "GetEngineMaxRotationSpeed", GetEngineMaxRotationSpeed },
	{ "GetCurrentGear", GetCurrentGear },
	{ "Get_bDeprecatedSpringOffsetMode", Get_bDeprecatedSpringOffsetMode },
	{ "Set_bDeprecatedSpringOffsetMode", Set_bDeprecatedSpringOffsetMode },
	{ "Get_bReverseAsBrake", Get_bReverseAsBrake },
	{ "Set_bReverseAsBrake", Set_bReverseAsBrake },
	{ "Get_bUseRVOAvoidance", Get_bUseRVOAvoidance },
	{ "Set_bUseRVOAvoidance", Set_bUseRVOAvoidance },
	{ "Get_Mass", Get_Mass },
	{ "Set_Mass", Set_Mass },
	{ "Get_DragCoefficient", Get_DragCoefficient },
	{ "Set_DragCoefficient", Set_DragCoefficient },
	{ "Get_ChassisWidth", Get_ChassisWidth },
	{ "Set_ChassisWidth", Set_ChassisWidth },
	{ "Get_ChassisHeight", Get_ChassisHeight },
	{ "Set_ChassisHeight", Set_ChassisHeight },
	{ "Get_InertiaTensorScale", Get_InertiaTensorScale },
	{ "Set_InertiaTensorScale", Set_InertiaTensorScale },
	{ "Get_MinNormalizedTireLoad", Get_MinNormalizedTireLoad },
	{ "Set_MinNormalizedTireLoad", Set_MinNormalizedTireLoad },
	{ "Get_MinNormalizedTireLoadFiltered", Get_MinNormalizedTireLoadFiltered },
	{ "Set_MinNormalizedTireLoadFiltered", Set_MinNormalizedTireLoadFiltered },
	{ "Get_MaxNormalizedTireLoad", Get_MaxNormalizedTireLoad },
	{ "Set_MaxNormalizedTireLoad", Set_MaxNormalizedTireLoad },
	{ "Get_MaxNormalizedTireLoadFiltered", Get_MaxNormalizedTireLoadFiltered },
	{ "Set_MaxNormalizedTireLoadFiltered", Set_MaxNormalizedTireLoadFiltered },
	{ "Get_ThresholdLongitudinalSpeed", Get_ThresholdLongitudinalSpeed },
	{ "Set_ThresholdLongitudinalSpeed", Set_ThresholdLongitudinalSpeed },
	{ "Get_LowForwardSpeedSubStepCount", Get_LowForwardSpeedSubStepCount },
	{ "Set_LowForwardSpeedSubStepCount", Set_LowForwardSpeedSubStepCount },
	{ "Get_HighForwardSpeedSubStepCount", Get_HighForwardSpeedSubStepCount },
	{ "Set_HighForwardSpeedSubStepCount", Set_HighForwardSpeedSubStepCount },
	{ "Get_Wheels", Get_Wheels },
	{ "Get_RVOAvoidanceRadius", Get_RVOAvoidanceRadius },
	{ "Set_RVOAvoidanceRadius", Set_RVOAvoidanceRadius },
	{ "Get_RVOAvoidanceHeight", Get_RVOAvoidanceHeight },
	{ "Set_RVOAvoidanceHeight", Set_RVOAvoidanceHeight },
	{ "Get_AvoidanceConsiderationRadius", Get_AvoidanceConsiderationRadius },
	{ "Set_AvoidanceConsiderationRadius", Set_AvoidanceConsiderationRadius },
	{ "Get_RVOSteeringStep", Get_RVOSteeringStep },
	{ "Set_RVOSteeringStep", Set_RVOSteeringStep },
	{ "Get_RVOThrottleStep", Get_RVOThrottleStep },
	{ "Set_RVOThrottleStep", Set_RVOThrottleStep },
	{ "Get_AvoidanceUID", Get_AvoidanceUID },
	{ "Get_AvoidanceWeight", Get_AvoidanceWeight },
	{ "Get_IdleBrakeInput", Get_IdleBrakeInput },
	{ "Set_IdleBrakeInput", Set_IdleBrakeInput },
	{ "Get_StopThreshold", Get_StopThreshold },
	{ "Set_StopThreshold", Set_StopThreshold },
	{ "Get_WrongDirectionThreshold", Get_WrongDirectionThreshold },
	{ "Set_WrongDirectionThreshold", Set_WrongDirectionThreshold },
	{ "is_nil", wLua::LuaStatic::isnil },
	{ "__gc", wLua::LuaStatic::removeUClassFrameCache },
	{ NULL, NULL }
};

void Register(lua_State *InScriptContext)
{
	lua_newtable(InScriptContext);
	luaL_register(InScriptContext, NULL, Lib_Funcs);
	AzureHelpFuncs::AuxRegister(InScriptContext, "WheeledVehicleMovementComponent");
}
void SetMtLink(lua_State *InScriptContext)
{
	AzureHelpFuncs::AuxSetMtLink(InScriptContext, "WheeledVehicleMovementComponent", "PawnMovementComponent",USERDATATYPE_UOBJECT);
}

}