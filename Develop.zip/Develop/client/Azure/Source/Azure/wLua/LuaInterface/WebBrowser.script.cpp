#include "Azure.h"
#include "Utility/help_funcs.h"
#include "wLua/UObjectHeaders.h"
#include "WebBrowser.h"
#include "AzureLuaIntegration.h"

namespace LuaWebBrowser
{
int32 LoadURL(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"WebBrowser",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"WebBrowser must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FString NewURL;
	} Params;
	Params.NewURL = UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 2));
#if UE_GAME
	UWebBrowser * This = (UWebBrowser *)Obj;
	This->LoadURL(Params.NewURL);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("LoadURL"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FString*)(params.GetStructMemory() + 0) = Params.NewURL;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.NewURL = *(FString*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 LoadString(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"WebBrowser",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"WebBrowser must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FString Contents;
		FString DummyURL;
	} Params;
	Params.Contents = UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 2));
	Params.DummyURL = UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 3));
#if UE_GAME
	UWebBrowser * This = (UWebBrowser *)Obj;
	This->LoadString(Params.Contents,Params.DummyURL);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("LoadString"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FString*)(params.GetStructMemory() + 0) = Params.Contents;
		*(FString*)(params.GetStructMemory() + 16) = Params.DummyURL;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.Contents = *(FString*)(params.GetStructMemory() + 0);
		Params.DummyURL = *(FString*)(params.GetStructMemory() + 16);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 IsLoading(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"WebBrowser",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"WebBrowser must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool ReturnValue;
	} Params;
#if UE_GAME
	UWebBrowser * This = (UWebBrowser *)Obj;
	Params.ReturnValue = This->IsLoading();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("IsLoading"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushboolean(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 IsLoaded(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"WebBrowser",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"WebBrowser must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool ReturnValue;
	} Params;
#if UE_GAME
	UWebBrowser * This = (UWebBrowser *)Obj;
	Params.ReturnValue = This->IsLoaded();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("IsLoaded"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushboolean(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GoForward(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"WebBrowser",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"WebBrowser must be non-null"); lua_error(InScriptContext);  return 0;}
#if UE_GAME
	UWebBrowser * This = (UWebBrowser *)Obj;
	This->GoForward();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GoForward"));
	if(!Function) { check(false); return 0;}
	Obj->ProcessEvent(Function, NULL);
#endif
	return 0;
}

int32 GoBack(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"WebBrowser",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"WebBrowser must be non-null"); lua_error(InScriptContext);  return 0;}
#if UE_GAME
	UWebBrowser * This = (UWebBrowser *)Obj;
	This->GoBack();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GoBack"));
	if(!Function) { check(false); return 0;}
	Obj->ProcessEvent(Function, NULL);
#endif
	return 0;
}

int32 GetUrl(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"WebBrowser",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"WebBrowser must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FString ReturnValue;
	} Params;
#if UE_GAME
	UWebBrowser * This = (UWebBrowser *)Obj;
	Params.ReturnValue = This->GetUrl();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetUrl"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(FString*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushstring(InScriptContext, TCHAR_TO_UTF8(*Params.ReturnValue));
	return 1;
}

int32 GetTitleText(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"WebBrowser",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"WebBrowser must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FText ReturnValue;
	} Params;
#if UE_GAME
	UWebBrowser * This = (UWebBrowser *)Obj;
	Params.ReturnValue = This->GetTitleText();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetTitleText"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(FText*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushstring(InScriptContext, TCHAR_TO_UTF8(*Params.ReturnValue.ToString()));
	return 1;
}

int32 ExecuteJavascript(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"WebBrowser",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"WebBrowser must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FString ScriptText;
	} Params;
	Params.ScriptText = UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 2));
#if UE_GAME
	UWebBrowser * This = (UWebBrowser *)Obj;
	This->ExecuteJavascript(Params.ScriptText);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("ExecuteJavascript"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FString*)(params.GetStructMemory() + 0) = Params.ScriptText;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ScriptText = *(FString*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 CanGoForward(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"WebBrowser",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"WebBrowser must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool ReturnValue;
	} Params;
#if UE_GAME
	UWebBrowser * This = (UWebBrowser *)Obj;
	Params.ReturnValue = This->CanGoForward();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("CanGoForward"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushboolean(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 CanGoBack(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"WebBrowser",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"WebBrowser must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool ReturnValue;
	} Params;
#if UE_GAME
	UWebBrowser * This = (UWebBrowser *)Obj;
	Params.ReturnValue = This->CanGoBack();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("CanGoBack"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushboolean(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 Call_OnUrlChanged(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"WebBrowser",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"WebBrowser must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FText Text;
	} Params;
	Params.Text = FText::FromString(UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 2)));
	UWebBrowser * This = (UWebBrowser *)Obj;
	This->OnUrlChanged.Broadcast(Params.Text);
	return 0;
}

int32 Call_OnBeforePopup(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"WebBrowser",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"WebBrowser must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FString URL;
		FString Frame;
	} Params;
	Params.URL = UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 2));
	Params.Frame = UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 3));
	UWebBrowser * This = (UWebBrowser *)Obj;
	This->OnBeforePopup.Broadcast(Params.URL,Params.Frame);
	return 0;
}

int32 Get_InitialURL(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"WebBrowser",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"WebBrowser must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UWebBrowser::StaticClass(), TEXT("InitialURL"));
	if(!Property) { check(false); return 0;}
	FString PropertyValue;
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushstring(InScriptContext, TCHAR_TO_UTF8(*PropertyValue));
	return 1;
}

int32 Set_InitialURL(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"WebBrowser",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"WebBrowser must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UWebBrowser::StaticClass(), TEXT("InitialURL"));
	if(!Property) { check(false); return 0;}
	FString PropertyValue = UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bSupportsTransparency(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"WebBrowser",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"WebBrowser must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UWebBrowser::StaticClass(), TEXT("bSupportsTransparency"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = bool();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bSupportsTransparency(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"WebBrowser",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"WebBrowser must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UWebBrowser::StaticClass(), TEXT("bSupportsTransparency"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 New(lua_State* InScriptContext)
{
	UObject* Outer = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Object");
	FName Name = FName(luaL_checkstring(InScriptContext, 2));
	UObject* Obj = NewObject<UWebBrowser>(Outer, Name);
	wLua::FLuaUtils::ReturnUObject(InScriptContext,Obj);
	return 1;
}

int32 Destroy(lua_State* InScriptContext)
{
	return 0;
}

int32 Class(lua_State* InScriptContext)
{
	UClass* Class = UWebBrowser::StaticClass();
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Class);
	return 1;
}

const luaL_Reg Lib_Funcs[] =
{
	{ "New", New },
	{ "Destroy", Destroy },
	{ "Class", Class },
	{ "LoadURL", LoadURL },
	{ "LoadString", LoadString },
	{ "IsLoading", IsLoading },
	{ "IsLoaded", IsLoaded },
	{ "GoForward", GoForward },
	{ "GoBack", GoBack },
	{ "GetUrl", GetUrl },
	{ "GetTitleText", GetTitleText },
	{ "ExecuteJavascript", ExecuteJavascript },
	{ "CanGoForward", CanGoForward },
	{ "CanGoBack", CanGoBack },
	{ "Call_OnUrlChanged", Call_OnUrlChanged },
	{ "Call_OnBeforePopup", Call_OnBeforePopup },
	{ "Get_InitialURL", Get_InitialURL },
	{ "Set_InitialURL", Set_InitialURL },
	{ "Get_bSupportsTransparency", Get_bSupportsTransparency },
	{ "Set_bSupportsTransparency", Set_bSupportsTransparency },
	{ "is_nil", wLua::LuaStatic::isnil },
	{ "__gc", wLua::LuaStatic::removeUClassFrameCache },
	{ NULL, NULL }
};

void Register(lua_State *InScriptContext)
{
	lua_newtable(InScriptContext);
	luaL_register(InScriptContext, NULL, Lib_Funcs);
	AzureHelpFuncs::AuxRegister(InScriptContext, "WebBrowser");
}
void SetMtLink(lua_State *InScriptContext)
{
	AzureHelpFuncs::AuxSetMtLink(InScriptContext, "WebBrowser", "Widget",USERDATATYPE_UOBJECT);
}

}