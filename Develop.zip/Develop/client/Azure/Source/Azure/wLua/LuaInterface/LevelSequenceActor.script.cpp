#include "Azure.h"
#include "Utility/help_funcs.h"
#include "wLua/UObjectHeaders.h"
#include "LevelSequenceActor.h"
#include "AzureLuaIntegration.h"

namespace LuaLevelSequenceActor
{
int32 RefreshBurnIn(lua_State*);
int32 InitializePlayer(lua_State*);
int32 Get_PlaybackSetting_LoopCount(lua_State*);
int32 Set_PlaybackSetting_LoopCount(lua_State*);
int32 Get_PlaybackSetting_PlayRate(lua_State*);
int32 Set_PlaybackSetting_PlayRate(lua_State*);
int32 Set_bAutoPlay(lua_State*);

int32 SetSequence(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"LevelSequenceActor",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"LevelSequenceActor must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		ULevelSequence* InSequence = nullptr;
	} Params;
	Params.InSequence = (ULevelSequence*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"LevelSequence");;
#if UE_GAME
	ALevelSequenceActor * This = (ALevelSequenceActor *)Obj;
	This->SetSequence(Params.InSequence);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetSequence"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(ULevelSequence**)(params.GetStructMemory() + 0) = Params.InSequence;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.InSequence = *(ULevelSequence**)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetEventReceivers(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"LevelSequenceActor",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"LevelSequenceActor must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		TArray<AActor*> AdditionalReceivers;
	} Params;
	Params.AdditionalReceivers = [](lua_State * _InScriptContext){ TArray<AActor*> ret; lua_pushnil(_InScriptContext); while(lua_next(_InScriptContext,2)!=0){ AActor* item = (AActor*)wLua::FLuaUtils::GetUObject(_InScriptContext,-1,"Actor");; ret.Add(item); lua_pop(_InScriptContext,1);  } return ret; }(InScriptContext);;
#if UE_GAME
	ALevelSequenceActor * This = (ALevelSequenceActor *)Obj;
	This->SetEventReceivers(Params.AdditionalReceivers);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetEventReceivers"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(TArray<AActor*>*)(params.GetStructMemory() + 0) = Params.AdditionalReceivers;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.AdditionalReceivers = *(TArray<AActor*>*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 ResetBindings(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"LevelSequenceActor",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"LevelSequenceActor must be non-null"); lua_error(InScriptContext);  return 0;}
#if UE_GAME
	ALevelSequenceActor * This = (ALevelSequenceActor *)Obj;
	This->ResetBindings();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("ResetBindings"));
	if(!Function) { check(false); return 0;}
	Obj->ProcessEvent(Function, NULL);
#endif
	return 0;
}

int32 GetSequence(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"LevelSequenceActor",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"LevelSequenceActor must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool bLoad;
		bool bInitializePlayer;
		ULevelSequence* ReturnValue = nullptr;
	} Params;
	Params.bLoad = lua_isnoneornil(InScriptContext,2) ? bool(false) : !!(lua_toboolean(InScriptContext, 2));
	Params.bInitializePlayer = lua_isnoneornil(InScriptContext,3) ? bool(false) : !!(lua_toboolean(InScriptContext, 3));
#if UE_GAME
	ALevelSequenceActor * This = (ALevelSequenceActor *)Obj;
	Params.ReturnValue = This->GetSequence(Params.bLoad,Params.bInitializePlayer);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetSequence"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(bool*)(params.GetStructMemory() + 0) = Params.bLoad;
		*(bool*)(params.GetStructMemory() + 1) = Params.bInitializePlayer;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.bLoad = *(bool*)(params.GetStructMemory() + 0);
		Params.bInitializePlayer = *(bool*)(params.GetStructMemory() + 1);
		Params.ReturnValue = *(ULevelSequence**)(params.GetStructMemory() + 8);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 Get_bAutoPlay(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"LevelSequenceActor",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"LevelSequenceActor must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(ALevelSequenceActor::StaticClass(), TEXT("bAutoPlay"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = bool();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_SequencePlayer(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"LevelSequenceActor",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"LevelSequenceActor must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(ALevelSequenceActor::StaticClass(), TEXT("SequencePlayer"));
	if(!Property) { check(false); return 0;}
	ULevelSequencePlayer* PropertyValue;
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaUtils::ReturnUObject(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_AdditionalEventReceivers(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"LevelSequenceActor",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"LevelSequenceActor must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(ALevelSequenceActor::StaticClass(), TEXT("AdditionalEventReceivers"));
	if(!Property) { check(false); return 0;}
	TArray<AActor*> PropertyValue;
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	{lua_newtable(InScriptContext); int i = 1; for(auto It = PropertyValue.CreateConstIterator(); It; ++It,++i) {  wLua::FLuaUtils::ReturnUObject(InScriptContext, (*It)); lua_rawseti(InScriptContext,-2,i);     }  }
	return 1;
}

int32 Get_BurnInOptions(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"LevelSequenceActor",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"LevelSequenceActor must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(ALevelSequenceActor::StaticClass(), TEXT("BurnInOptions"));
	if(!Property) { check(false); return 0;}
	ULevelSequenceBurnInOptions* PropertyValue;
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaUtils::ReturnUObject(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_BindingOverrides(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"LevelSequenceActor",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"LevelSequenceActor must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(ALevelSequenceActor::StaticClass(), TEXT("BindingOverrides"));
	if(!Property) { check(false); return 0;}
	UMovieSceneBindingOverrides* PropertyValue;
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaUtils::ReturnUObject(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_bOverrideInstanceData(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"LevelSequenceActor",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"LevelSequenceActor must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(ALevelSequenceActor::StaticClass(), TEXT("bOverrideInstanceData"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = bool();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_DefaultInstanceData(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"LevelSequenceActor",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"LevelSequenceActor must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(ALevelSequenceActor::StaticClass(), TEXT("DefaultInstanceData"));
	if(!Property) { check(false); return 0;}
	UObject* PropertyValue;
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaUtils::ReturnUObject(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_DefaultInstanceData(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"LevelSequenceActor",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"LevelSequenceActor must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(ALevelSequenceActor::StaticClass(), TEXT("DefaultInstanceData"));
	if(!Property) { check(false); return 0;}
	UObject* PropertyValue = (UObject*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"Object");;
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 New(lua_State* InScriptContext)
{
	UObject* Outer = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Object");
	FName Name = FName(luaL_checkstring(InScriptContext, 2));
	UObject* Obj = NewObject<ALevelSequenceActor>(Outer, Name);
	wLua::FLuaUtils::ReturnUObject(InScriptContext,Obj);
	return 1;
}

int32 Destroy(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"LevelSequenceActor",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"LevelSequenceActor must be non-null"); lua_error(InScriptContext);  return 0;}
		AActor * actor = Cast<AActor>(Obj);
		actor->Destroy();
		userdata->flag |= wLua::LuaObjectFlag::DESTROYED;
		wLua::FLuaUtils::RemoveObjectReference(Obj, userdata->stamp, InScriptContext);
#ifdef AZURE_BUILD_WLUACHECK
		UE_LOG(LogAzure, Warning, TEXT("Destroy LevelSequenceActor: %x userdata:%x   stamp:%x"),Obj,userdata,userdata->stamp);
#endif
	return 0;
}

int32 Class(lua_State* InScriptContext)
{
	UClass* Class = ALevelSequenceActor::StaticClass();
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Class);
	return 1;
}

const luaL_Reg Lib_Funcs[] =
{
	{ "New", New },
	{ "Destroy", Destroy },
	{ "Class", Class },
	{ "SetSequence", SetSequence },
	{ "SetEventReceivers", SetEventReceivers },
	{ "ResetBindings", ResetBindings },
	{ "GetSequence", GetSequence },
	{ "Get_bAutoPlay", Get_bAutoPlay },
	{ "Get_SequencePlayer", Get_SequencePlayer },
	{ "Get_AdditionalEventReceivers", Get_AdditionalEventReceivers },
	{ "Get_BurnInOptions", Get_BurnInOptions },
	{ "Get_BindingOverrides", Get_BindingOverrides },
	{ "Get_bOverrideInstanceData", Get_bOverrideInstanceData },
	{ "Get_DefaultInstanceData", Get_DefaultInstanceData },
	{ "Set_DefaultInstanceData", Set_DefaultInstanceData },
	{ "RefreshBurnIn", RefreshBurnIn },
	{ "InitializePlayer", InitializePlayer },
	{ "Get_PlaybackSetting_LoopCount", Get_PlaybackSetting_LoopCount },
	{ "Set_PlaybackSetting_LoopCount", Set_PlaybackSetting_LoopCount },
	{ "Get_PlaybackSetting_PlayRate", Get_PlaybackSetting_PlayRate },
	{ "Set_PlaybackSetting_PlayRate", Set_PlaybackSetting_PlayRate },
	{ "Set_bAutoPlay", Set_bAutoPlay },
	{ "is_nil", wLua::LuaStatic::isnil },
	{ "__gc", wLua::LuaStatic::removeUClassFrameCache },
	{ NULL, NULL }
};

void Register(lua_State *InScriptContext)
{
	lua_newtable(InScriptContext);
	luaL_register(InScriptContext, NULL, Lib_Funcs);
	AzureHelpFuncs::AuxRegister(InScriptContext, "LevelSequenceActor");
}
void SetMtLink(lua_State *InScriptContext)
{
	AzureHelpFuncs::AuxSetMtLink(InScriptContext, "LevelSequenceActor", "Actor",USERDATATYPE_UOBJECT);
}

}