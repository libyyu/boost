#include "Azure.h"
#include "Utility/help_funcs.h"
#include "wLua/UObjectHeaders.h"
#include "AzureImage.h"
#include "AzureLuaIntegration.h"

namespace LuaAzureImage
{
int32 SetDoubleClickEnable(lua_State*);

int32 SetUVScale(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureImage",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureImage must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FVector2D InValue;
	} Params;
	Params.InValue = (wLua::FLuaVector2D::Get(InScriptContext, 2));
#if UE_GAME
	UAzureImage * This = (UAzureImage *)Obj;
	This->SetUVScale(Params.InValue);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetUVScale"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FVector2D*)(params.GetStructMemory() + 0) = Params.InValue;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.InValue = *(FVector2D*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetUVOffset(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureImage",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureImage must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FVector2D InValue;
	} Params;
	Params.InValue = (wLua::FLuaVector2D::Get(InScriptContext, 2));
#if UE_GAME
	UAzureImage * This = (UAzureImage *)Obj;
	This->SetUVOffset(Params.InValue);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetUVOffset"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FVector2D*)(params.GetStructMemory() + 0) = Params.InValue;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.InValue = *(FVector2D*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetUVAngle(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureImage",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureImage must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float InValue;
	} Params;
	Params.InValue = (float)(luaL_checknumber(InScriptContext, 2));
#if UE_GAME
	UAzureImage * This = (UAzureImage *)Obj;
	This->SetUVAngle(Params.InValue);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetUVAngle"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(float*)(params.GetStructMemory() + 0) = Params.InValue;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.InValue = *(float*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetTotalFillAmount(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureImage",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureImage must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float InFillAmount;
	} Params;
	Params.InFillAmount = (float)(luaL_checknumber(InScriptContext, 2));
#if UE_GAME
	UAzureImage * This = (UAzureImage *)Obj;
	This->SetTotalFillAmount(Params.InFillAmount);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetTotalFillAmount"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(float*)(params.GetStructMemory() + 0) = Params.InFillAmount;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.InFillAmount = *(float*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetThumbWidget(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureImage",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureImage must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		UWidget* Ptr = nullptr;
	} Params;
	Params.Ptr = (UWidget*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"Widget");;
#if UE_GAME
	UAzureImage * This = (UAzureImage *)Obj;
	This->SetThumbWidget(Params.Ptr);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetThumbWidget"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(UWidget**)(params.GetStructMemory() + 0) = Params.Ptr;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.Ptr = *(UWidget**)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetIsChanging(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureImage",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureImage must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool isChanging;
	} Params;
	Params.isChanging = !!(lua_toboolean(InScriptContext, 2));
#if UE_GAME
	UAzureImage * This = (UAzureImage *)Obj;
	This->SetIsChanging(Params.isChanging);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetIsChanging"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(bool*)(params.GetStructMemory() + 0) = Params.isChanging;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.isChanging = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetFillAmount(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureImage",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureImage must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float InFillAmount;
	} Params;
	Params.InFillAmount = (float)(luaL_checknumber(InScriptContext, 2));
#if UE_GAME
	UAzureImage * This = (UAzureImage *)Obj;
	This->SetFillAmount(Params.InFillAmount);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetFillAmount"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(float*)(params.GetStructMemory() + 0) = Params.InFillAmount;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.InFillAmount = *(float*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetbUseCustomUV(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureImage",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureImage must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool InValue;
	} Params;
	Params.InValue = !!(lua_toboolean(InScriptContext, 2));
#if UE_GAME
	UAzureImage * This = (UAzureImage *)Obj;
	This->SetbUseCustomUV(Params.InValue);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetbUseCustomUV"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(bool*)(params.GetStructMemory() + 0) = Params.InValue;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.InValue = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 PauseProgress(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureImage",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureImage must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool bPause;
	} Params;
	Params.bPause = !!(lua_toboolean(InScriptContext, 2));
#if UE_GAME
	UAzureImage * This = (UAzureImage *)Obj;
	This->PauseProgress(Params.bPause);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("PauseProgress"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(bool*)(params.GetStructMemory() + 0) = Params.bPause;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.bPause = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 GetUVScale(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureImage",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureImage must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FVector2D ReturnValue;
	} Params;
#if UE_GAME
	UAzureImage * This = (UAzureImage *)Obj;
	Params.ReturnValue = This->GetUVScale();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetUVScale"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(FVector2D*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaVector2D::Return(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetUVOffset(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureImage",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureImage must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FVector2D ReturnValue;
	} Params;
#if UE_GAME
	UAzureImage * This = (UAzureImage *)Obj;
	Params.ReturnValue = This->GetUVOffset();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetUVOffset"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(FVector2D*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaVector2D::Return(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetUVAngle(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureImage",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureImage must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float ReturnValue;
	} Params;
#if UE_GAME
	UAzureImage * This = (UAzureImage *)Obj;
	Params.ReturnValue = This->GetUVAngle();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetUVAngle"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(float*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushnumber(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetTotalFillAmount(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureImage",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureImage must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float ReturnValue;
	} Params;
#if UE_GAME
	UAzureImage * This = (UAzureImage *)Obj;
	Params.ReturnValue = This->GetTotalFillAmount();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetTotalFillAmount"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(float*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushnumber(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetFillAmount(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureImage",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureImage must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float ReturnValue;
	} Params;
#if UE_GAME
	UAzureImage * This = (UAzureImage *)Obj;
	Params.ReturnValue = This->GetFillAmount();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetFillAmount"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(float*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushnumber(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetbUseCustomUV(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureImage",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureImage must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool ReturnValue;
	} Params;
#if UE_GAME
	UAzureImage * This = (UAzureImage *)Obj;
	Params.ReturnValue = This->GetbUseCustomUV();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetbUseCustomUV"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushboolean(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 ClearScaleState(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureImage",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureImage must be non-null"); lua_error(InScriptContext);  return 0;}
#if UE_GAME
	UAzureImage * This = (UAzureImage *)Obj;
	This->ClearScaleState();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("ClearScaleState"));
	if(!Function) { check(false); return 0;}
	Obj->ProcessEvent(Function, NULL);
#endif
	return 0;
}

int32 AutoProgress(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureImage",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureImage must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool aut0;
		float start;
		float end;
		float time;
	} Params;
	Params.aut0 = !!(lua_toboolean(InScriptContext, 2));
	Params.start = (float)(luaL_checknumber(InScriptContext, 3));
	Params.end = (float)(luaL_checknumber(InScriptContext, 4));
	Params.time = (float)(luaL_checknumber(InScriptContext, 5));
#if UE_GAME
	UAzureImage * This = (UAzureImage *)Obj;
	This->AutoProgress(Params.aut0,Params.start,Params.end,Params.time);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("AutoProgress"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(bool*)(params.GetStructMemory() + 0) = Params.aut0;
		*(float*)(params.GetStructMemory() + 4) = Params.start;
		*(float*)(params.GetStructMemory() + 8) = Params.end;
		*(float*)(params.GetStructMemory() + 12) = Params.time;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.aut0 = *(bool*)(params.GetStructMemory() + 0);
		Params.start = *(float*)(params.GetStructMemory() + 4);
		Params.end = *(float*)(params.GetStructMemory() + 8);
		Params.time = *(float*)(params.GetStructMemory() + 12);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 Get_bSizeToTarget(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureImage",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureImage must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzureImage::StaticClass(), TEXT("bSizeToTarget"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = bool();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_TargetName(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureImage",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureImage must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzureImage::StaticClass(), TEXT("TargetName"));
	if(!Property) { check(false); return 0;}
	FString PropertyValue;
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushstring(InScriptContext, TCHAR_TO_UTF8(*PropertyValue));
	return 1;
}

int32 Get_bClickEnabled(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureImage",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureImage must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzureImage::StaticClass(), TEXT("bClickEnabled"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = bool();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_bPreciseClick(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureImage",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureImage must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzureImage::StaticClass(), TEXT("bPreciseClick"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = bool();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_bDoubleClick(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureImage",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureImage must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzureImage::StaticClass(), TEXT("bDoubleClick"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = bool();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_bLongPress(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureImage",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureImage must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzureImage::StaticClass(), TEXT("bLongPress"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = bool();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_bFilled(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureImage",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureImage must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzureImage::StaticClass(), TEXT("bFilled"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = bool();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_FillAmount(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureImage",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureImage must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzureImage::StaticClass(), TEXT("FillAmount"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_TotalFillAmount(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureImage",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureImage must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzureImage::StaticClass(), TEXT("TotalFillAmount"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_bClockwise(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureImage",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureImage must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzureImage::StaticClass(), TEXT("bClockwise"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = bool();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_bNoClipping(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureImage",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureImage must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzureImage::StaticClass(), TEXT("bNoClipping"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = bool();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_bRotated(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureImage",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureImage must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzureImage::StaticClass(), TEXT("bRotated"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = bool();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_RotateAmount(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureImage",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureImage must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzureImage::StaticClass(), TEXT("RotateAmount"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_bAnimationCompatible(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureImage",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureImage must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzureImage::StaticClass(), TEXT("bAnimationCompatible"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = bool();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Get_bUseCustomUV(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureImage",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureImage must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzureImage::StaticClass(), TEXT("bUseCustomUV"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = bool();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bUseCustomUV(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureImage",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureImage must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzureImage::StaticClass(), TEXT("bUseCustomUV"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_UVOffset(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureImage",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureImage must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzureImage::StaticClass(), TEXT("UVOffset"));
	if(!Property) { check(false); return 0;}
	FVector2D PropertyValue = FVector2D();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaVector2D::Return(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_UVOffset(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureImage",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureImage must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzureImage::StaticClass(), TEXT("UVOffset"));
	if(!Property) { check(false); return 0;}
	FVector2D PropertyValue = (wLua::FLuaVector2D::Get(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_UVScale(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureImage",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureImage must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzureImage::StaticClass(), TEXT("UVScale"));
	if(!Property) { check(false); return 0;}
	FVector2D PropertyValue = FVector2D();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaVector2D::Return(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_UVScale(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureImage",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureImage must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzureImage::StaticClass(), TEXT("UVScale"));
	if(!Property) { check(false); return 0;}
	FVector2D PropertyValue = (wLua::FLuaVector2D::Get(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_UVAngle(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureImage",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureImage must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzureImage::StaticClass(), TEXT("UVAngle"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_UVAngle(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"AzureImage",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"AzureImage must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UAzureImage::StaticClass(), TEXT("UVAngle"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 New(lua_State* InScriptContext)
{
	UObject* Outer = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Object");
	FName Name = FName(luaL_checkstring(InScriptContext, 2));
	UObject* Obj = NewObject<UAzureImage>(Outer, Name);
	wLua::FLuaUtils::ReturnUObject(InScriptContext,Obj);
	return 1;
}

int32 Destroy(lua_State* InScriptContext)
{
	return 0;
}

int32 Class(lua_State* InScriptContext)
{
	UClass* Class = UAzureImage::StaticClass();
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Class);
	return 1;
}

const luaL_Reg Lib_Funcs[] =
{
	{ "New", New },
	{ "Destroy", Destroy },
	{ "Class", Class },
	{ "SetUVScale", SetUVScale },
	{ "SetUVOffset", SetUVOffset },
	{ "SetUVAngle", SetUVAngle },
	{ "SetTotalFillAmount", SetTotalFillAmount },
	{ "SetThumbWidget", SetThumbWidget },
	{ "SetIsChanging", SetIsChanging },
	{ "SetFillAmount", SetFillAmount },
	{ "SetbUseCustomUV", SetbUseCustomUV },
	{ "PauseProgress", PauseProgress },
	{ "GetUVScale", GetUVScale },
	{ "GetUVOffset", GetUVOffset },
	{ "GetUVAngle", GetUVAngle },
	{ "GetTotalFillAmount", GetTotalFillAmount },
	{ "GetFillAmount", GetFillAmount },
	{ "GetbUseCustomUV", GetbUseCustomUV },
	{ "ClearScaleState", ClearScaleState },
	{ "AutoProgress", AutoProgress },
	{ "Get_bSizeToTarget", Get_bSizeToTarget },
	{ "Get_TargetName", Get_TargetName },
	{ "Get_bClickEnabled", Get_bClickEnabled },
	{ "Get_bPreciseClick", Get_bPreciseClick },
	{ "Get_bDoubleClick", Get_bDoubleClick },
	{ "Get_bLongPress", Get_bLongPress },
	{ "Get_bFilled", Get_bFilled },
	{ "Get_FillAmount", Get_FillAmount },
	{ "Get_TotalFillAmount", Get_TotalFillAmount },
	{ "Get_bClockwise", Get_bClockwise },
	{ "Get_bNoClipping", Get_bNoClipping },
	{ "Get_bRotated", Get_bRotated },
	{ "Get_RotateAmount", Get_RotateAmount },
	{ "Get_bAnimationCompatible", Get_bAnimationCompatible },
	{ "Get_bUseCustomUV", Get_bUseCustomUV },
	{ "Set_bUseCustomUV", Set_bUseCustomUV },
	{ "Get_UVOffset", Get_UVOffset },
	{ "Set_UVOffset", Set_UVOffset },
	{ "Get_UVScale", Get_UVScale },
	{ "Set_UVScale", Set_UVScale },
	{ "Get_UVAngle", Get_UVAngle },
	{ "Set_UVAngle", Set_UVAngle },
	{ "SetDoubleClickEnable", SetDoubleClickEnable },
	{ "is_nil", wLua::LuaStatic::isnil },
	{ "__gc", wLua::LuaStatic::removeUClassFrameCache },
	{ NULL, NULL }
};

void Register(lua_State *InScriptContext)
{
	lua_newtable(InScriptContext);
	luaL_register(InScriptContext, NULL, Lib_Funcs);
	AzureHelpFuncs::AuxRegister(InScriptContext, "AzureImage");
}
void SetMtLink(lua_State *InScriptContext)
{
	AzureHelpFuncs::AuxSetMtLink(InScriptContext, "AzureImage", "Image",USERDATATYPE_UOBJECT);
}

}