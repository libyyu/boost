#include "Azure.h"
#include "Utility/help_funcs.h"
#include "wLua/UObjectHeaders.h"
#include "Utilities/DynamicTextureHelper.h"
#include "AzureLuaIntegration.h"

namespace LuaDynamicTextureHelper
{
int32 CreateDynamicTexture(lua_State*);
int32 WriteTexturePixels(lua_State*);

int32 WritePixels(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"DynamicTextureHelper",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"DynamicTextureHelper must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		TArray<uint8> RawData;
	} Params;
	Params.RawData = [](lua_State * _InScriptContext){ TArray<uint8> ret; lua_pushnil(_InScriptContext); while(lua_next(_InScriptContext,2)!=0){ uint8 item = (uint8)(luaL_checkint(_InScriptContext, -1)); ret.Add(item); lua_pop(_InScriptContext,1);  } return ret; }(InScriptContext);;
#if UE_GAME
	ADynamicTextureHelper * This = (ADynamicTextureHelper *)Obj;
	This->WritePixels(Params.RawData);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("WritePixels"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(TArray<uint8>*)(params.GetStructMemory() + 0) = Params.RawData;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.RawData = *(TArray<uint8>*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 Get_Texture(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"DynamicTextureHelper",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"DynamicTextureHelper must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(ADynamicTextureHelper::StaticClass(), TEXT("Texture"));
	if(!Property) { check(false); return 0;}
	UTexture2DDynamic* PropertyValue;
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaUtils::ReturnUObject(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_Texture(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"DynamicTextureHelper",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"DynamicTextureHelper must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(ADynamicTextureHelper::StaticClass(), TEXT("Texture"));
	if(!Property) { check(false); return 0;}
	UTexture2DDynamic* PropertyValue = (UTexture2DDynamic*)wLua::FLuaUtils::GetUObject(InScriptContext,2,"Texture2DDynamic");;
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 New(lua_State* InScriptContext)
{
	UObject* Outer = wLua::FLuaUtils::GetUObject(InScriptContext,1,"Object");
	FName Name = FName(luaL_checkstring(InScriptContext, 2));
	UObject* Obj = NewObject<ADynamicTextureHelper>(Outer, Name);
	wLua::FLuaUtils::ReturnUObject(InScriptContext,Obj);
	return 1;
}

int32 Destroy(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"DynamicTextureHelper",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"DynamicTextureHelper must be non-null"); lua_error(InScriptContext);  return 0;}
		AActor * actor = Cast<AActor>(Obj);
		actor->Destroy();
		userdata->flag |= wLua::LuaObjectFlag::DESTROYED;
		wLua::FLuaUtils::RemoveObjectReference(Obj, userdata->stamp, InScriptContext);
#ifdef AZURE_BUILD_WLUACHECK
		UE_LOG(LogAzure, Warning, TEXT("Destroy DynamicTextureHelper: %x userdata:%x   stamp:%x"),Obj,userdata,userdata->stamp);
#endif
	return 0;
}

int32 Class(lua_State* InScriptContext)
{
	UClass* Class = ADynamicTextureHelper::StaticClass();
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Class);
	return 1;
}

const luaL_Reg Lib_Funcs[] =
{
	{ "New", New },
	{ "Destroy", Destroy },
	{ "Class", Class },
	{ "WritePixels", WritePixels },
	{ "Get_Texture", Get_Texture },
	{ "Set_Texture", Set_Texture },
	{ "CreateDynamicTexture", CreateDynamicTexture },
	{ "WriteTexturePixels", WriteTexturePixels },
	{ "is_nil", wLua::LuaStatic::isnil },
	{ "__gc", wLua::LuaStatic::removeUClassFrameCache },
	{ NULL, NULL }
};

void Register(lua_State *InScriptContext)
{
	lua_newtable(InScriptContext);
	luaL_register(InScriptContext, NULL, Lib_Funcs);
	AzureHelpFuncs::AuxRegister(InScriptContext, "DynamicTextureHelper");
}
void SetMtLink(lua_State *InScriptContext)
{
	AzureHelpFuncs::AuxSetMtLink(InScriptContext, "DynamicTextureHelper", "Actor",USERDATATYPE_UOBJECT);
}

}