#include "Azure.h"
#include "Utility/help_funcs.h"
#include "wLua/UObjectHeaders.h"
#include "Engine/LevelStreaming.h"
#include "AzureLuaIntegration.h"

namespace LuaLevelStreaming
{
int32 GetLevel(lua_State*);
int32 BindOnLevelLoaded(lua_State*);
int32 UnbindOnLevelLoaded(lua_State*);
int32 BindOnLevelUnloaded(lua_State*);
int32 UnbindOnLevelUnloaded(lua_State*);
int32 BindOnLevelShown(lua_State*);
int32 UnbindOnLevelShow(lua_State*);
int32 BindOnLevelHidden(lua_State*);
int32 UnbindOnLevelHidden(lua_State*);
int32 SetIsRequestingUnloadAndRemoval(lua_State*);

int32 ShouldBeLoaded(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"LevelStreaming",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"LevelStreaming must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool ReturnValue;
	} Params;
#if UE_GAME
	ULevelStreaming * This = (ULevelStreaming *)Obj;
	Params.ReturnValue = This->ShouldBeLoaded();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("ShouldBeLoaded"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushboolean(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 SetShouldBeVisible(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"LevelStreaming",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"LevelStreaming must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool bInShouldBeVisible;
	} Params;
	Params.bInShouldBeVisible = !!(lua_toboolean(InScriptContext, 2));
#if UE_GAME
	ULevelStreaming * This = (ULevelStreaming *)Obj;
	This->SetShouldBeVisible(Params.bInShouldBeVisible);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetShouldBeVisible"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(bool*)(params.GetStructMemory() + 0) = Params.bInShouldBeVisible;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.bInShouldBeVisible = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetShouldBeRemovedOnUnload(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"LevelStreaming",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"LevelStreaming must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool b;
		bool ReturnValue;
	} Params;
	Params.b = !!(lua_toboolean(InScriptContext, 2));
#if UE_GAME
	ULevelStreaming * This = (ULevelStreaming *)Obj;
	Params.ReturnValue = This->SetShouldBeRemovedOnUnload(Params.b);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetShouldBeRemovedOnUnload"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(bool*)(params.GetStructMemory() + 0) = Params.b;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.b = *(bool*)(params.GetStructMemory() + 0);
		Params.ReturnValue = *(bool*)(params.GetStructMemory() + 1);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushboolean(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 SetShouldBeLoaded(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"LevelStreaming",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"LevelStreaming must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool bInShouldBeLoaded;
	} Params;
	Params.bInShouldBeLoaded = !!(lua_toboolean(InScriptContext, 2));
#if UE_GAME
	ULevelStreaming * This = (ULevelStreaming *)Obj;
	This->SetShouldBeLoaded(Params.bInShouldBeLoaded);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetShouldBeLoaded"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(bool*)(params.GetStructMemory() + 0) = Params.bInShouldBeLoaded;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.bInShouldBeLoaded = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetLevelLODIndex(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"LevelStreaming",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"LevelStreaming must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		int32 LODIndex;
	} Params;
	Params.LODIndex = (luaL_checkint(InScriptContext, 2));
#if UE_GAME
	ULevelStreaming * This = (ULevelStreaming *)Obj;
	This->SetLevelLODIndex(Params.LODIndex);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetLevelLODIndex"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(int32*)(params.GetStructMemory() + 0) = Params.LODIndex;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.LODIndex = *(int32*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 IsStreamingStatePending(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"LevelStreaming",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"LevelStreaming must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool ReturnValue;
	} Params;
#if UE_GAME
	ULevelStreaming * This = (ULevelStreaming *)Obj;
	Params.ReturnValue = This->IsStreamingStatePending();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("IsStreamingStatePending"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushboolean(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 IsLevelVisible(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"LevelStreaming",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"LevelStreaming must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool ReturnValue;
	} Params;
#if UE_GAME
	ULevelStreaming * This = (ULevelStreaming *)Obj;
	Params.ReturnValue = This->IsLevelVisible();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("IsLevelVisible"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushboolean(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 IsLevelLoaded(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"LevelStreaming",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"LevelStreaming must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		bool ReturnValue;
	} Params;
#if UE_GAME
	ULevelStreaming * This = (ULevelStreaming *)Obj;
	Params.ReturnValue = This->IsLevelLoaded();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("IsLevelLoaded"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(bool*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushboolean(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetWorldAssetPackageFName(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"LevelStreaming",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"LevelStreaming must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FName ReturnValue;
	} Params;
#if UE_GAME
	ULevelStreaming * This = (ULevelStreaming *)Obj;
	Params.ReturnValue = This->GetWorldAssetPackageFName();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetWorldAssetPackageFName"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(FName*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushstring(InScriptContext, TCHAR_TO_UTF8(*Params.ReturnValue.ToString()));
	return 1;
}

int32 CreateInstance(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"LevelStreaming",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"LevelStreaming must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FString UniqueInstanceName;
		ULevelStreaming* ReturnValue = nullptr;
	} Params;
	Params.UniqueInstanceName = UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 2));
#if UE_GAME
	ULevelStreaming * This = (ULevelStreaming *)Obj;
	Params.ReturnValue = This->CreateInstance(Params.UniqueInstanceName);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("CreateInstance"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FString*)(params.GetStructMemory() + 0) = Params.UniqueInstanceName;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.UniqueInstanceName = *(FString*)(params.GetStructMemory() + 0);
		Params.ReturnValue = *(ULevelStreaming**)(params.GetStructMemory() + 16);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 Get_LevelTransform(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"LevelStreaming",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"LevelStreaming must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(ULevelStreaming::StaticClass(), TEXT("LevelTransform"));
	if(!Property) { check(false); return 0;}
	FTransform PropertyValue = FTransform();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaTransform::Return(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_LevelTransform(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"LevelStreaming",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"LevelStreaming must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(ULevelStreaming::StaticClass(), TEXT("LevelTransform"));
	if(!Property) { check(false); return 0;}
	FTransform PropertyValue = (wLua::FLuaTransform::Get(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_LevelLODIndex(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"LevelStreaming",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"LevelStreaming must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(ULevelStreaming::StaticClass(), TEXT("LevelLODIndex"));
	if(!Property) { check(false); return 0;}
	int32 PropertyValue = int32();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushinteger(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_LevelLODIndex(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"LevelStreaming",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"LevelStreaming must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(ULevelStreaming::StaticClass(), TEXT("LevelLODIndex"));
	if(!Property) { check(false); return 0;}
	int32 PropertyValue = (luaL_checkint(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bShouldBeVisible(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"LevelStreaming",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"LevelStreaming must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(ULevelStreaming::StaticClass(), TEXT("bShouldBeVisible"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bShouldBeVisible(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"LevelStreaming",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"LevelStreaming must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(ULevelStreaming::StaticClass(), TEXT("bShouldBeVisible"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bShouldBeLoaded(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"LevelStreaming",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"LevelStreaming must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(ULevelStreaming::StaticClass(), TEXT("bShouldBeLoaded"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bShouldBeLoaded(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"LevelStreaming",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"LevelStreaming must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(ULevelStreaming::StaticClass(), TEXT("bShouldBeLoaded"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bIsStatic(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"LevelStreaming",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"LevelStreaming must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(ULevelStreaming::StaticClass(), TEXT("bIsStatic"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bIsStatic(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"LevelStreaming",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"LevelStreaming must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(ULevelStreaming::StaticClass(), TEXT("bIsStatic"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bShouldBlockOnLoad(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"LevelStreaming",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"LevelStreaming must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(ULevelStreaming::StaticClass(), TEXT("bShouldBlockOnLoad"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bShouldBlockOnLoad(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"LevelStreaming",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"LevelStreaming must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(ULevelStreaming::StaticClass(), TEXT("bShouldBlockOnLoad"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bShouldBlockOnUnload(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"LevelStreaming",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"LevelStreaming must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(ULevelStreaming::StaticClass(), TEXT("bShouldBlockOnUnload"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bShouldBlockOnUnload(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"LevelStreaming",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"LevelStreaming must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(ULevelStreaming::StaticClass(), TEXT("bShouldBlockOnUnload"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bDisableDistanceStreaming(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"LevelStreaming",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"LevelStreaming must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(ULevelStreaming::StaticClass(), TEXT("bDisableDistanceStreaming"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bDisableDistanceStreaming(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"LevelStreaming",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"LevelStreaming must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(ULevelStreaming::StaticClass(), TEXT("bDisableDistanceStreaming"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_bDrawOnLevelStatusMap(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"LevelStreaming",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"LevelStreaming must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(ULevelStreaming::StaticClass(), TEXT("bDrawOnLevelStatusMap"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = uint8();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bDrawOnLevelStatusMap(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"LevelStreaming",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"LevelStreaming must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(ULevelStreaming::StaticClass(), TEXT("bDrawOnLevelStatusMap"));
	if(!Property) { check(false); return 0;}
	uint8 PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_LevelColor(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"LevelStreaming",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"LevelStreaming must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(ULevelStreaming::StaticClass(), TEXT("LevelColor"));
	if(!Property) { check(false); return 0;}
	FLinearColor PropertyValue = FLinearColor();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	wLua::FLuaLinearColor::Return(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_LevelColor(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"LevelStreaming",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"LevelStreaming must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(ULevelStreaming::StaticClass(), TEXT("LevelColor"));
	if(!Property) { check(false); return 0;}
	FLinearColor PropertyValue = (wLua::FLuaLinearColor::Get(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_EditorStreamingVolumes(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"LevelStreaming",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"LevelStreaming must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(ULevelStreaming::StaticClass(), TEXT("EditorStreamingVolumes"));
	if(!Property) { check(false); return 0;}
	TArray<ALevelStreamingVolume*> PropertyValue;
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	{lua_newtable(InScriptContext); int i = 1; for(auto It = PropertyValue.CreateConstIterator(); It; ++It,++i) {  wLua::FLuaUtils::ReturnUObject(InScriptContext, (*It)); lua_rawseti(InScriptContext,-2,i);     }  }
	return 1;
}

int32 Set_EditorStreamingVolumes(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"LevelStreaming",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"LevelStreaming must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(ULevelStreaming::StaticClass(), TEXT("EditorStreamingVolumes"));
	if(!Property) { check(false); return 0;}
	TArray<ALevelStreamingVolume*> PropertyValue = [](lua_State * _InScriptContext){ TArray<ALevelStreamingVolume*> ret; lua_pushnil(_InScriptContext); while(lua_next(_InScriptContext,2)!=0){ ALevelStreamingVolume* item = (ALevelStreamingVolume*)wLua::FLuaUtils::GetUObject(_InScriptContext,-1,"LevelStreamingVolume");; ret.Add(item); lua_pop(_InScriptContext,1);  } return ret; }(InScriptContext);;
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Get_MinTimeBetweenVolumeUnloadRequests(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"LevelStreaming",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"LevelStreaming must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(ULevelStreaming::StaticClass(), TEXT("MinTimeBetweenVolumeUnloadRequests"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = float();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushnumber(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_MinTimeBetweenVolumeUnloadRequests(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"LevelStreaming",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"LevelStreaming must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(ULevelStreaming::StaticClass(), TEXT("MinTimeBetweenVolumeUnloadRequests"));
	if(!Property) { check(false); return 0;}
	float PropertyValue = (float)(luaL_checknumber(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Call_OnLevelLoaded(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"LevelStreaming",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"LevelStreaming must be non-null"); lua_error(InScriptContext);  return 0;}
	ULevelStreaming * This = (ULevelStreaming *)Obj;
	This->OnLevelLoaded.Broadcast();
	return 0;
}

int32 Call_OnLevelUnloaded(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"LevelStreaming",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"LevelStreaming must be non-null"); lua_error(InScriptContext);  return 0;}
	ULevelStreaming * This = (ULevelStreaming *)Obj;
	This->OnLevelUnloaded.Broadcast();
	return 0;
}

int32 Call_OnLevelShown(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"LevelStreaming",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"LevelStreaming must be non-null"); lua_error(InScriptContext);  return 0;}
	ULevelStreaming * This = (ULevelStreaming *)Obj;
	This->OnLevelShown.Broadcast();
	return 0;
}

int32 Call_OnLevelHidden(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"LevelStreaming",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"LevelStreaming must be non-null"); lua_error(InScriptContext);  return 0;}
	ULevelStreaming * This = (ULevelStreaming *)Obj;
	This->OnLevelHidden.Broadcast();
	return 0;
}

int32 Class(lua_State* InScriptContext)
{
	UClass* Class = ULevelStreaming::StaticClass();
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Class);
	return 1;
}

const luaL_Reg Lib_Funcs[] =
{
	{ "Class", Class },
	{ "ShouldBeLoaded", ShouldBeLoaded },
	{ "SetShouldBeVisible", SetShouldBeVisible },
	{ "SetShouldBeRemovedOnUnload", SetShouldBeRemovedOnUnload },
	{ "SetShouldBeLoaded", SetShouldBeLoaded },
	{ "SetLevelLODIndex", SetLevelLODIndex },
	{ "IsStreamingStatePending", IsStreamingStatePending },
	{ "IsLevelVisible", IsLevelVisible },
	{ "IsLevelLoaded", IsLevelLoaded },
	{ "GetWorldAssetPackageFName", GetWorldAssetPackageFName },
	{ "CreateInstance", CreateInstance },
	{ "Get_LevelTransform", Get_LevelTransform },
	{ "Set_LevelTransform", Set_LevelTransform },
	{ "Get_LevelLODIndex", Get_LevelLODIndex },
	{ "Set_LevelLODIndex", Set_LevelLODIndex },
	{ "Get_bShouldBeVisible", Get_bShouldBeVisible },
	{ "Set_bShouldBeVisible", Set_bShouldBeVisible },
	{ "Get_bShouldBeLoaded", Get_bShouldBeLoaded },
	{ "Set_bShouldBeLoaded", Set_bShouldBeLoaded },
	{ "Get_bIsStatic", Get_bIsStatic },
	{ "Set_bIsStatic", Set_bIsStatic },
	{ "Get_bShouldBlockOnLoad", Get_bShouldBlockOnLoad },
	{ "Set_bShouldBlockOnLoad", Set_bShouldBlockOnLoad },
	{ "Get_bShouldBlockOnUnload", Get_bShouldBlockOnUnload },
	{ "Set_bShouldBlockOnUnload", Set_bShouldBlockOnUnload },
	{ "Get_bDisableDistanceStreaming", Get_bDisableDistanceStreaming },
	{ "Set_bDisableDistanceStreaming", Set_bDisableDistanceStreaming },
	{ "Get_bDrawOnLevelStatusMap", Get_bDrawOnLevelStatusMap },
	{ "Set_bDrawOnLevelStatusMap", Set_bDrawOnLevelStatusMap },
	{ "Get_LevelColor", Get_LevelColor },
	{ "Set_LevelColor", Set_LevelColor },
	{ "Get_EditorStreamingVolumes", Get_EditorStreamingVolumes },
	{ "Set_EditorStreamingVolumes", Set_EditorStreamingVolumes },
	{ "Get_MinTimeBetweenVolumeUnloadRequests", Get_MinTimeBetweenVolumeUnloadRequests },
	{ "Set_MinTimeBetweenVolumeUnloadRequests", Set_MinTimeBetweenVolumeUnloadRequests },
	{ "Call_OnLevelLoaded", Call_OnLevelLoaded },
	{ "Call_OnLevelUnloaded", Call_OnLevelUnloaded },
	{ "Call_OnLevelShown", Call_OnLevelShown },
	{ "Call_OnLevelHidden", Call_OnLevelHidden },
	{ "GetLevel", GetLevel },
	{ "BindOnLevelLoaded", BindOnLevelLoaded },
	{ "UnbindOnLevelLoaded", UnbindOnLevelLoaded },
	{ "BindOnLevelUnloaded", BindOnLevelUnloaded },
	{ "UnbindOnLevelUnloaded", UnbindOnLevelUnloaded },
	{ "BindOnLevelShown", BindOnLevelShown },
	{ "UnbindOnLevelShow", UnbindOnLevelShow },
	{ "BindOnLevelHidden", BindOnLevelHidden },
	{ "UnbindOnLevelHidden", UnbindOnLevelHidden },
	{ "SetIsRequestingUnloadAndRemoval", SetIsRequestingUnloadAndRemoval },
	{ "is_nil", wLua::LuaStatic::isnil },
	{ "__gc", wLua::LuaStatic::removeUClassFrameCache },
	{ NULL, NULL }
};

void Register(lua_State *InScriptContext)
{
	lua_newtable(InScriptContext);
	luaL_register(InScriptContext, NULL, Lib_Funcs);
	AzureHelpFuncs::AuxRegister(InScriptContext, "LevelStreaming");
}
void SetMtLink(lua_State *InScriptContext)
{
	AzureHelpFuncs::AuxSetMtLink(InScriptContext, "LevelStreaming", "Object",USERDATATYPE_UOBJECT);
}

}