#include "Azure.h"
#include "Utility/help_funcs.h"
#include "wLua/UObjectHeaders.h"
#include "Components/MeshComponent.h"
#include "AzureLuaIntegration.h"

namespace LuaMeshComponent
{
int32 SetMaterial(lua_State*);
int32 SetMaterialByName(lua_State*);
int32 EmptyOverrideMaterials(lua_State*);
int32 GetNumMaterials(lua_State*);
int32 GetMaterial(lua_State*);

int32 SetVectorParameterValueOnMaterials(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FName ParameterName;
		FVector ParameterValue;
	} Params;
	Params.ParameterName = FName(UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 2)));
	Params.ParameterValue = (wLua::FLuaVector::Get(InScriptContext, 3));
#if UE_GAME
	UMeshComponent * This = (UMeshComponent *)Obj;
	This->SetVectorParameterValueOnMaterials(Params.ParameterName,Params.ParameterValue);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetVectorParameterValueOnMaterials"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FName*)(params.GetStructMemory() + 0) = Params.ParameterName;
		*(FVector*)(params.GetStructMemory() + 12) = Params.ParameterValue;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ParameterName = *(FName*)(params.GetStructMemory() + 0);
		Params.ParameterValue = *(FVector*)(params.GetStructMemory() + 12);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 SetScalarParameterValueOnMaterials(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FName ParameterName;
		float ParameterValue;
	} Params;
	Params.ParameterName = FName(UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 2)));
	Params.ParameterValue = (float)(luaL_checknumber(InScriptContext, 3));
#if UE_GAME
	UMeshComponent * This = (UMeshComponent *)Obj;
	This->SetScalarParameterValueOnMaterials(Params.ParameterName,Params.ParameterValue);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("SetScalarParameterValueOnMaterials"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FName*)(params.GetStructMemory() + 0) = Params.ParameterName;
		*(float*)(params.GetStructMemory() + 12) = Params.ParameterValue;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ParameterName = *(FName*)(params.GetStructMemory() + 0);
		Params.ParameterValue = *(float*)(params.GetStructMemory() + 12);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 PrestreamTextures(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		float Seconds;
		bool bPrioritizeCharacterTextures;
		int32 CinematicTextureGroups;
	} Params;
	Params.Seconds = (float)(luaL_checknumber(InScriptContext, 2));
	Params.bPrioritizeCharacterTextures = !!(lua_toboolean(InScriptContext, 3));
	Params.CinematicTextureGroups = lua_isnoneornil(InScriptContext,4) ? int32(0) : (luaL_checkint(InScriptContext, 4));
#if UE_GAME
	UMeshComponent * This = (UMeshComponent *)Obj;
	This->PrestreamTextures(Params.Seconds,Params.bPrioritizeCharacterTextures,Params.CinematicTextureGroups);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("PrestreamTextures"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(float*)(params.GetStructMemory() + 0) = Params.Seconds;
		*(bool*)(params.GetStructMemory() + 4) = Params.bPrioritizeCharacterTextures;
		*(int32*)(params.GetStructMemory() + 8) = Params.CinematicTextureGroups;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.Seconds = *(float*)(params.GetStructMemory() + 0);
		Params.bPrioritizeCharacterTextures = *(bool*)(params.GetStructMemory() + 4);
		Params.CinematicTextureGroups = *(int32*)(params.GetStructMemory() + 8);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	return 0;
}

int32 IsMaterialSlotNameValid(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FName MaterialSlotName;
		bool ReturnValue;
	} Params;
	Params.MaterialSlotName = FName(UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 2)));
#if UE_GAME
	UMeshComponent * This = (UMeshComponent *)Obj;
	Params.ReturnValue = This->IsMaterialSlotNameValid(Params.MaterialSlotName);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("IsMaterialSlotNameValid"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FName*)(params.GetStructMemory() + 0) = Params.MaterialSlotName;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.MaterialSlotName = *(FName*)(params.GetStructMemory() + 0);
		Params.ReturnValue = *(bool*)(params.GetStructMemory() + 12);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushboolean(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 GetMaterialSlotNames(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		TArray<FName> ReturnValue;
	} Params;
#if UE_GAME
	UMeshComponent * This = (UMeshComponent *)Obj;
	Params.ReturnValue = This->GetMaterialSlotNames();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetMaterialSlotNames"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(TArray<FName>*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	{lua_newtable(InScriptContext); int i = 1; for(auto It = Params.ReturnValue.CreateConstIterator(); It; ++It,++i) {  lua_pushstring(InScriptContext, TCHAR_TO_UTF8(*(*It).ToString())); lua_rawseti(InScriptContext,-2,i);     }  }
	return 1;
}

int32 GetMaterials(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		TArray<UMaterialInterface*> ReturnValue;
	} Params;
#if UE_GAME
	UMeshComponent * This = (UMeshComponent *)Obj;
	Params.ReturnValue = This->GetMaterials();
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetMaterials"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.ReturnValue = *(TArray<UMaterialInterface*>*)(params.GetStructMemory() + 0);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	{lua_newtable(InScriptContext); int i = 1; for(auto It = Params.ReturnValue.CreateConstIterator(); It; ++It,++i) {  wLua::FLuaUtils::ReturnUObject(InScriptContext, (*It)); lua_rawseti(InScriptContext,-2,i);     }  }
	return 1;
}

int32 GetMaterialIndex(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	struct FDispatchParams
	{
		FName MaterialSlotName;
		int32 ReturnValue;
	} Params;
	Params.MaterialSlotName = FName(UTF8_TO_TCHAR(luaL_checkstring(InScriptContext, 2)));
#if UE_GAME
	UMeshComponent * This = (UMeshComponent *)Obj;
	Params.ReturnValue = This->GetMaterialIndex(Params.MaterialSlotName);
#else
	UFunction* Function = Obj->FindFunctionChecked(TEXT("GetMaterialIndex"));
	if(!Function) { check(false); return 0;}
	if(Function->PropertiesSize != sizeof(FDispatchParams))
	{
		FStructOnScope params(Function);
		*(FName*)(params.GetStructMemory() + 0) = Params.MaterialSlotName;
		Obj->ProcessEvent(Function, params.GetStructMemory());
		Params.MaterialSlotName = *(FName*)(params.GetStructMemory() + 0);
		Params.ReturnValue = *(int32*)(params.GetStructMemory() + 12);
	} else {
		Obj->ProcessEvent(Function, &Params);
	}
#endif
	lua_pushinteger(InScriptContext, Params.ReturnValue);
	return 1;
}

int32 Get_bSetAnimParameterValueOnMaterialsToChild(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UMeshComponent::StaticClass(), TEXT("bSetAnimParameterValueOnMaterialsToChild"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = bool();
	Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Obj));
	lua_pushboolean(InScriptContext, PropertyValue);
	return 1;
}

int32 Set_bSetAnimParameterValueOnMaterialsToChild(lua_State* InScriptContext)
{
	wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(InScriptContext,1,"MeshComponent",&userdata);if(!Obj) { wLua::LuaStatic::traceback(InScriptContext,"MeshComponent must be non-null"); lua_error(InScriptContext);  return 0;}
	static UProperty* Property = wLua::FindScriptPropertyHelper(UMeshComponent::StaticClass(), TEXT("bSetAnimParameterValueOnMaterialsToChild"));
	if(!Property) { check(false); return 0;}
	bool PropertyValue = !!(lua_toboolean(InScriptContext, 2));
	Property->CopyExplicitValue(Property->ContainerPtrToValuePtr<void>(Obj), &PropertyValue);
	return 0;
}

int32 Class(lua_State* InScriptContext)
{
	UClass* Class = UMeshComponent::StaticClass();
	wLua::FLuaUtils::ReturnUObject(InScriptContext, Class);
	return 1;
}

const luaL_Reg Lib_Funcs[] =
{
	{ "Class", Class },
	{ "SetVectorParameterValueOnMaterials", SetVectorParameterValueOnMaterials },
	{ "SetScalarParameterValueOnMaterials", SetScalarParameterValueOnMaterials },
	{ "PrestreamTextures", PrestreamTextures },
	{ "IsMaterialSlotNameValid", IsMaterialSlotNameValid },
	{ "GetMaterialSlotNames", GetMaterialSlotNames },
	{ "GetMaterials", GetMaterials },
	{ "GetMaterialIndex", GetMaterialIndex },
	{ "Get_bSetAnimParameterValueOnMaterialsToChild", Get_bSetAnimParameterValueOnMaterialsToChild },
	{ "Set_bSetAnimParameterValueOnMaterialsToChild", Set_bSetAnimParameterValueOnMaterialsToChild },
	{ "SetMaterial", SetMaterial },
	{ "SetMaterialByName", SetMaterialByName },
	{ "EmptyOverrideMaterials", EmptyOverrideMaterials },
	{ "GetNumMaterials", GetNumMaterials },
	{ "GetMaterial", GetMaterial },
	{ "is_nil", wLua::LuaStatic::isnil },
	{ "__gc", wLua::LuaStatic::removeUClassFrameCache },
	{ NULL, NULL }
};

void Register(lua_State *InScriptContext)
{
	lua_newtable(InScriptContext);
	luaL_register(InScriptContext, NULL, Lib_Funcs);
	AzureHelpFuncs::AuxRegister(InScriptContext, "MeshComponent");
}
void SetMtLink(lua_State *InScriptContext)
{
	AzureHelpFuncs::AuxSetMtLink(InScriptContext, "MeshComponent", "PrimitiveComponent",USERDATATYPE_UOBJECT);
}

}