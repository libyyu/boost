/*
	供 Lua 调用的开发、调试用函数
*/

#include "Azure.h"
#include "LuaInterface.h"
#include "AzureLuaIntegration.h"
#include "help_funcs.h"

namespace wLua
{
	namespace GameLuaInterface
	{
		namespace MaterialShaderMapUtil
		{
			static void PushShader(lua_State* L, FShader* Shader)
			{
				lua_createtable(L, 0, 2);

				lua_pushstring(L, TCHAR_TO_UTF8(Shader->GetType()->GetName()));
				lua_setfield(L, -2, "TypeName");

				lua_pushinteger(L, Shader->GetNumRefs());
				lua_setfield(L, -2, "NumRefs");

				lua_pushstring(L, TCHAR_TO_UTF8(*Shader->GetOutputHash().ToString()));
				lua_setfield(L, -2, "OutputHash");
			}

			template <typename ShaderMetaType>
			static void PushShaders(lua_State* L, TShaderMap<ShaderMetaType> const* ShaderMap)
			{
				TMap<FName, FShader*> Shaders;
				ShaderMap->GetShaderList(Shaders);
				lua_createtable(L, 0, Shaders.Num());
				for (auto&& shaderInfoPair : Shaders)
				{
					PushShader(L, shaderInfoPair.Value);
					lua_rawseti(L, -2, lua_objlen(L, -2)+1);
				}
			}

			static void PushMaterialShaderMap(lua_State* L, FMaterialShaderMap const* ShaderMap)
			{
				lua_newtable(L);	//ShaderMap
							
				//FString shaderMapId;
				//ShaderMap->GetShaderMapId().AppendKeyString(shaderMapId);	//可能崩溃
				//lua_pushstring(L, TCHAR_TO_UTF8(*shaderMapId));
				//lua_setfield(L, -2, "Id");

				lua_pushinteger(L, ShaderMap->GetNumRefs());
				lua_setfield(L, -2, "NumRefs");

				lua_pushinteger(L, ShaderMap->GetNumShaders());
				lua_setfield(L, -2, "NumShaders");

				PushShaders(L, ShaderMap);
				lua_setfield(L, -2, "Shaders");

				lua_newtable(L);	//MeshShaderMaps
				{
					for(TLinkedList<FVertexFactoryType*>::TIterator VertexFactoryTypeIt(FVertexFactoryType::GetTypeList());VertexFactoryTypeIt;VertexFactoryTypeIt.Next())
					{
						FVertexFactoryType* VertexFactoryType = *VertexFactoryTypeIt;
						FMeshMaterialShaderMap const* MeshShaderMap = ShaderMap->GetMeshShaderMap(VertexFactoryType);
						if (MeshShaderMap)
						{
							lua_pushstring(L, TCHAR_TO_UTF8(VertexFactoryType->GetName()));
							lua_newtable(L);	//MeshShaderMap
							{
								lua_pushinteger(L, MeshShaderMap->GetNumShaders());
								lua_setfield(L, -2, "NumShaders");

								PushShaders(L, MeshShaderMap);
								lua_setfield(L, -2, "Shaders");
							}
							lua_settable(L, -3);
						}
					}
				}
				lua_setfield(L, -2, "MeshShaderMaps");

				lua_newtable(L);	//Pipelines
				{
					for (TLinkedList<FShaderPipelineType*>::TIterator ShaderPipelineIt(FShaderPipelineType::GetTypeList());ShaderPipelineIt;ShaderPipelineIt.Next())
					{
						const FShaderPipelineType* PipelineType = *ShaderPipelineIt;
						FShaderPipeline* Pipeline = ShaderMap->GetShaderPipeline(PipelineType);
						if (Pipeline)
						{
							TArray<FShader*> Shaders = Pipeline->GetShaders();
							for (FShader* Shader : Shaders)
							{
								PushShader(L, Shader);
								lua_rawseti(L, -2, lua_objlen(L, -2)+1);
							}
						}
					}
				}
				lua_setfield(L, -2, "Pipelines");
			}

			static void PushMaterial(lua_State* L, UMaterialInterface* Material)
			{
				lua_newtable(L);
				for (int32 FeatureLevelIndex = 0; FeatureLevelIndex < ERHIFeatureLevel::Num; FeatureLevelIndex++)
				{
					lua_newtable(L);
					FMaterialResource* MaterialResourceAllQualities[EMaterialQualityLevel::Num];
					for (int32 QualityLevelIndex = 0; QualityLevelIndex < EMaterialQualityLevel::Num; QualityLevelIndex++)
					{
						//GetMaterialResource 有 fallback 处理，需要去重
						MaterialResourceAllQualities[QualityLevelIndex] = Material->GetMaterialResource((ERHIFeatureLevel::Type)FeatureLevelIndex, (EMaterialQualityLevel::Type)QualityLevelIndex);
					}
					//删除 fallback 到 high 的资源
					if (FMaterialResource* highResource = MaterialResourceAllQualities[EMaterialQualityLevel::High])
					{
						for (int32 QualityLevelIndex = 0; QualityLevelIndex < EMaterialQualityLevel::Num; QualityLevelIndex++)
						{
							if (FMaterialResource*& checkResource = MaterialResourceAllQualities[QualityLevelIndex])
							{
								if (QualityLevelIndex != EMaterialQualityLevel::High && checkResource->GetGameThreadShaderMap() == highResource->GetGameThreadShaderMap())
									checkResource = nullptr;
							}
						}
					}
					//删除其他 fallback 资源
					for (int32 i = 0; i < EMaterialQualityLevel::Num; i++)
					{
						if (FMaterialResource* res = MaterialResourceAllQualities[i])
						{
							for (int32 j = i+1; j < EMaterialQualityLevel::Num; j++)
							{
								if (FMaterialResource* &checkResource = MaterialResourceAllQualities[j])
								{
									if (checkResource->GetGameThreadShaderMap() == res->GetGameThreadShaderMap())
										checkResource = nullptr;
								}
							}
						}
					}

					for (int32 QualityLevelIndex = 0; QualityLevelIndex < EMaterialQualityLevel::Num; QualityLevelIndex++)
					{
						FMaterialResource* MaterialResource = MaterialResourceAllQualities[QualityLevelIndex];
						if (MaterialResource)
						{
							FMaterialShaderMap const* MaterialShaderMap = MaterialResource->GetGameThreadShaderMap();
							if (MaterialShaderMap)
							{
								PushMaterialShaderMap(L, MaterialShaderMap);
								lua_rawseti(L, -2, QualityLevelIndex+1);
							}
						}
					}
					lua_rawseti(L, -2, FeatureLevelIndex+1);
				}
			}

			struct MaterialShaderMapBriefInfo
			{
				int32 NumShaderMaps;
				int32 NumShaders;
				float ProportionNumShaderMaps;
				float ProportionNumShaders;
			};

			void AccumulateShaderBriefInfo(FShader* Shader, int32 outerNumRef, MaterialShaderMapBriefInfo& info)
			{
				info.NumShaders += 1;
				info.ProportionNumShaders += 1.0f/Shader->GetNumRefs()/outerNumRef;
			}

			template <typename ShaderMetaType>
			void AccumulateShadersBriefInfo(TShaderMap<ShaderMetaType> const* ShaderMap, int32 outerNumRef, MaterialShaderMapBriefInfo& info)
			{
				TMap<FName, FShader*> Shaders;
				ShaderMap->GetShaderList(Shaders);
				for (auto&& shaderInfoPair : Shaders)
				{
					AccumulateShaderBriefInfo(shaderInfoPair.Value, outerNumRef, info);
				}
			}

			void AccumulateMaterialShaderMapBriefInfo(FMaterialShaderMap const* ShaderMap, int32 outerNumRef, MaterialShaderMapBriefInfo& info)
			{
				int32 numRefs = outerNumRef * ShaderMap->GetNumRefs();
				info.NumShaderMaps += 1;
				info.ProportionNumShaderMaps += 1.0f/numRefs;

				AccumulateShadersBriefInfo(ShaderMap, numRefs, info);

				for(TLinkedList<FVertexFactoryType*>::TIterator VertexFactoryTypeIt(FVertexFactoryType::GetTypeList());VertexFactoryTypeIt;VertexFactoryTypeIt.Next())
				{
					FVertexFactoryType* VertexFactoryType = *VertexFactoryTypeIt;
					FMeshMaterialShaderMap const* MeshShaderMap = ShaderMap->GetMeshShaderMap(VertexFactoryType);
					if (MeshShaderMap)
					{
						AccumulateShadersBriefInfo(MeshShaderMap, numRefs, info);
					}
				}

				for (TLinkedList<FShaderPipelineType*>::TIterator ShaderPipelineIt(FShaderPipelineType::GetTypeList());ShaderPipelineIt;ShaderPipelineIt.Next())
				{
					const FShaderPipelineType* PipelineType = *ShaderPipelineIt;
					FShaderPipeline* Pipeline = ShaderMap->GetShaderPipeline(PipelineType);
					if (Pipeline)
					{
						TArray<FShader*> Shaders = Pipeline->GetShaders();
						for (FShader* Shader : Shaders)
						{
							AccumulateShaderBriefInfo(Shader, numRefs, info);
						}
					}
				}
			}

			void GetMaterialBriefInfo(UMaterialInterface* Material, bool hasResource, MaterialShaderMapBriefInfo& info)
			{
				info.NumShaderMaps = 0;
				info.NumShaders = 0;
				info.ProportionNumShaderMaps = 0;
				info.ProportionNumShaders = 0;
				if (!hasResource)
					return;

				TArray<FMaterialResource*> MaterialResourceAllQualities;
				for (int32 FeatureLevelIndex = 0; FeatureLevelIndex < ERHIFeatureLevel::Num; FeatureLevelIndex++)
				{
					MaterialResourceAllQualities.Reset();
					for (int32 QualityLevelIndex = 0; QualityLevelIndex < EMaterialQualityLevel::Num; QualityLevelIndex++)
					{
						//GetMaterialResource 有 fallback 处理，需要去重
						FMaterialResource* MaterialResource = Material->GetMaterialResource((ERHIFeatureLevel::Type)FeatureLevelIndex, (EMaterialQualityLevel::Type)QualityLevelIndex);
						if (MaterialResource)
						{
							MaterialResourceAllQualities.AddUnique(MaterialResource);
						}
					}
					for (FMaterialResource* MaterialResource : MaterialResourceAllQualities)
					{
						FMaterialShaderMap const* MaterialShaderMap = MaterialResource->GetGameThreadShaderMap();
						if (MaterialShaderMap)
						{
							AccumulateMaterialShaderMapBriefInfo(MaterialShaderMap, 1, info);
						}
					}
				}

			}
		}

		/*
			返回 shaderMap 详细信息：[FeatureLevel][QualityLevel] = { id=, NewRef=, NumShaders=, Shader=, MeshShaderMaps={NumShaders=, Shader=,} }
			无 StaticPermutation 的 MaterialInstance 返回字符串 "<share_from_parent>"
		*/
		static int GetMaterialShaderMapDetail(lua_State * L)
		{
			int32 oldTop = lua_gettop(L);

			UMaterialInterface* materialInterface = FLuaUtils::CheckUObject<UMaterialInterface>(L, 1);
			if (UMaterial* material = Cast<UMaterial>(materialInterface))
			{
				MaterialShaderMapUtil::PushMaterial(L, material);
			}
			else if (UMaterialInstance* materialInstance = Cast<UMaterialInstance>(materialInterface))
			{
				if (materialInstance->bHasStaticPermutationResource)
				{
					MaterialShaderMapUtil::PushMaterial(L, materialInstance);
				}
				else
				{
					lua_pushstring(L, "<share_from_parent>");
				}
			}
			int32 newTop = lua_gettop(L);
			check(newTop == oldTop + 1);
			return 1;
		}

		/*
			返回 shaderMap 简要信息：NumShaderMaps, NumShaders
			共享的 shaderMap, shader 数量进行了分摊
		*/
		static int GetMaterialShaderMapBrief(lua_State * L)
		{
			MaterialShaderMapUtil::MaterialShaderMapBriefInfo info = {};

			UMaterialInterface* materialInterface = FLuaUtils::CheckUObject<UMaterialInterface>(L, 1);
			if (UMaterial* material = Cast<UMaterial>(materialInterface))
			{
				MaterialShaderMapUtil::GetMaterialBriefInfo(material, true, info);
			}
			else if (UMaterialInstance* materialInstance = Cast<UMaterialInstance>(materialInterface))
			{
				MaterialShaderMapUtil::GetMaterialBriefInfo(materialInstance, materialInstance->bHasStaticPermutationResource, info);
			}
			lua_newtable(L);
			lua_pushinteger(L, info.NumShaderMaps);
			lua_setfield(L, -2, "NumShaderMaps");
			lua_pushinteger(L, info.NumShaders);
			lua_setfield(L, -2, "NumShaders");
			lua_pushnumber(L, info.ProportionNumShaderMaps);
			lua_setfield(L, -2, "ProportionNumShaderMaps");
			lua_pushnumber(L, info.ProportionNumShaders);
			lua_setfield(L, -2, "ProportionNumShaders");
			return 1;
		}

		static int LuaAllocProfilerSnapshot(lua_State* L)
		{
			char const* markName = luaL_checkstring(L, 1);
			FLuaAllocProfiler* profiler = AAzureEntryPoint::Instance->GetWLua()->GetLuaAllocProfiler();
			if (profiler)
				profiler->SnapshotMemory(UTF8_TO_TCHAR(markName));
			return 0;
		}

		static int LuaAllocProfilerEndProfiling(lua_State* L)
		{
			FLuaAllocProfiler* profiler = AAzureEntryPoint::Instance->GetWLua()->GetLuaAllocProfiler();
			if (profiler)
				profiler->EndProfiling(true);
			return 0;
		}

		static int Run(lua_State* L)
		{
			GNET::Octets octets;
			size_t len;
			char const* str = luaL_checklstring(L, 1, &len);
			octets.append(str, len);
			std::string cppStr = AzureHelpFuncs::GetUTF8FromOctets(octets);
			lua_pushlstring(L, cppStr.c_str(), cppStr.size());
			return 1;
		}

		extern const luaL_Reg Lib_GameDebugUtil_Funcs[] =
		{
			{ "GetMaterialShaderMapDetail", GetMaterialShaderMapDetail },
			{ "GetMaterialShaderMapBrief", GetMaterialShaderMapBrief },
			{ "LuaAllocProfilerSnapshot", LuaAllocProfilerSnapshot },
			{ "LuaAllocProfilerEndProfiling", LuaAllocProfilerEndProfiling },
			{ "run", Run },
			{ NULL, NULL }
		};
	}
}