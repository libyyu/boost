#include "LuaRegistryRefWrapper.h"
#include "LuaInterface.h"

extern wLua::Lua* AAzureEntryPoint_GetWLua();

LuaRegistryRefWrapper::LuaRegistryRefWrapper()
{
	wLua::Lua *wLua = AAzureEntryPoint_GetWLua();
	if (wLua)
	{
		lua_State_Wrapper L = wLua->GetL();
		refID = wLua::lua_registry_handle::wlua_ref(L, LUA_REGISTRYINDEX);
	}
}

LuaRegistryRefWrapper::~LuaRegistryRefWrapper()
{
	wLua::Lua *wLua = AAzureEntryPoint_GetWLua();
	if (wLua)
	{
		lua_State_Wrapper L = wLua->GetL();
		wLua::lua_registry_handle::wlua_unref(L, LUA_REGISTRYINDEX, refID);
	}
}

void LuaRegistryRefWrapper::PushToStack()
{
	wLua::Lua *wLua = AAzureEntryPoint_GetWLua();
	if (wLua)
	{
		lua_State_Wrapper L = wLua->GetL();
		lua_rawgeti(L, LUA_REGISTRYINDEX, refID);
	}
}
