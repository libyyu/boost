#pragma once

#include "Misc/OutputDevice.h"

class FAzureErrorOutputDevice : public FOutputDevice
{
public:
	FAzureErrorOutputDevice();
	static FAzureErrorOutputDevice* GetLog();

	virtual void Serialize(const TCHAR* Data, ELogVerbosity::Type Verbosity, const class FName& Category) override;
	virtual bool CanBeUsedOnAnyThread() const override
	{
		return true;
	}

	void HandleError(const TCHAR* Data, ELogVerbosity::Type Verbosity, const class FName& Category);
};

