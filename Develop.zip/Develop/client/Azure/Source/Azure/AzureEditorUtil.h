// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "wLua.h"
#include "ABaseDef.h"

#if UE_EDITOR

// ΪEditorģ���ṩһЩ�ӿ�
class AZURE_API FAzureEditorUtil
{
public:
	static wLua::Lua* InitLuaEnv(const TArray<FString>& tokens, const TArray<FString>& switches, const TMap<FString, FString>& params);
	static void ReleaseEnv();

	static int Compress(const wchar_t *fn, const char* pData, int dataSize);
	static int Compress_LZ4(const wchar_t *fn, const char* pData, int dataSize);
	static int Compress_NoCompress(const wchar_t *fn, const char* pData, int dataSize);
	static int Compress_GetSepFileOriginalSize(const wchar_t *fn, a_int64& dataOriginalSize);
};

#endif