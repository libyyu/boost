// Fill out your copyright notice in the Description page of Project Settings.

#include "FxCache.h"
#include "../ResourceLoader/AzureResourceLoader.h"
#include "FxOne.h"
#include "FxCacheMan.h"
#include "Particles/ParticleSystem.h"
#include "ResourceLoader/AzureResourceInGameUpdateDownload.h"

static float sFxIGULoadDelay = 0.2f;	//������ɺ��һС����ٿ�ʼ���أ������л��ʱ���

static FAutoConsoleVariableRef CVarIGULoadDelay(
	TEXT("fx.IGULoadDelay"),
	sFxIGULoadDelay,
	TEXT("Delay seconds before load resource after InGameUpdate finish download. Minus value will disable delay."),
	ECVF_Default); 


// Sets default values
AFxCache::AFxCache()
{
 	// Set this actor to call Tick() every frame.  You can turn this off to improve performance if you don't need it.
	PrimaryActorTick.bCanEverTick = false;
	RootComponent = CreateDefaultSubobject<USceneComponent>(TEXT("RootComponent"));
	if (RootComponent->IsPendingKill())
	{
		RootComponent->ClearPendingKill();		//	Azure todo : why ?
	}
}

// Called when the game starts or when spawned
void AFxCache::BeginPlay()
{
	Super::BeginPlay();
}

void AFxCache::BeginDestroy()
{
	mDestroy = true;
	Super::BeginDestroy();
}

void AFxCache::SetDestroy()
{
	FXOneList tempFxs(WaitingResourceFxOnes);
	for(auto fxone: tempFxs)
	{
		fxone->Set_CanReplay(false);
		fxone->Stop();
	}
	WaitingResourceFxOnes.Empty();
	mDestroy = true;
}

void AFxCache::InitWithPrefab(const FString& name, const UParticleSystem* InFxTemplate)
{
	mName = name;

	if (InFxTemplate != nullptr)
	{
		this->FxTemplate = InFxTemplate;
		this->mLoading = false;
	}
	else
	{
		TWeakObjectPtr<AFxCache> self = this;
		std::function<void(TArray<UObject*>)> func =
			[this, self](TArray<UObject*> res)
		{
			if (!self.IsValid())
				return;

			UObject* LoadedFxTemplate = nullptr;
			FString obj_type = TEXT("ParticleSystem");
			for (auto ObjIt = res.CreateConstIterator(); ObjIt; ++ObjIt)
			{
				UObject* ob = (*ObjIt);
				UClass* cls = ob->GetClass();

				if (cls->GetName() == obj_type)
				{
					LoadedFxTemplate = ob;
					break;
				}
			}
			this->FxTemplate = static_cast<const UParticleSystem*>(LoadedFxTemplate);
			this->mLoading = false;

			AFxCacheMan::OnLoadFinishToLua(mName, !!LoadedFxTemplate);

			FXOneList tempFxs(this->WaitingResourceFxOnes);
			this->WaitingResourceFxOnes.Empty();

			if (!LoadedFxTemplate || this->mDestroy)
			{
				for (auto fxone : tempFxs)
				{
					fxone->Stop();
				}
				return;
			}

			for (auto fxoneptr : tempFxs)
			{
				AFxOne& fxone = *fxoneptr;
				fxone.SetFxTemplate(this->FxTemplate);
				if (fxone.IsResourceReady())
				{
					fxone.OnResourceReady();
				}
				else
				{

#if  UE_BUILD_SHIPPING
					UE_LOG(LogAzure, Error,
						TEXT("fxone FxTemplate is not nullptr but SetFXTemplate is nullptr. name:%s  LoadedFxTemplate:0x%016llx this->FXTemplate:0x%016llx   FxComponent:0x%016llx   FxComponent->Template:0x%016llx "), 
						*fxone.mName, 
						(int64)(PTRINT)LoadedFxTemplate,
						(int64)(PTRINT)FxTemplate,
						(int64)(PTRINT)(fxone.FxComponent ? fxone.FxComponent : nullptr),
						(int64)(PTRINT)(fxone.FxComponent ? fxone.FxComponent->Template : nullptr));

#else
					UE_LOG(LogAzure, Fatal,
						TEXT("fxone FxTemplate is not nullptr but SetFXTemplate is nullptr. name:%s  LoadedFxTemplate:0x%016llx this->FXTemplate:0x%016llx   FxComponent:0x%016llx   FxComponent->Template:0x%016llx "),
						*fxone.mName,
						(int64)(PTRINT)LoadedFxTemplate,
						(int64)(PTRINT)FxTemplate,
						(int64)(PTRINT)(fxone.FxComponent ? fxone.FxComponent : nullptr),
						(int64)(PTRINT)(fxone.FxComponent ? fxone.FxComponent->Template : nullptr));

#endif

					fxone.Stop();
				}
			}
			
			//��Դ��������ActiveFxOnes��������
			if (FxCacheMan && FxCacheMan->GetFxCachePolicy() == FxCachePolicy::MAX_COST)
			{
				SetLodCosts(FxTemplate->AzureLodCosts);
				SetLodCount(const_cast<UParticleSystem*>(FxTemplate)->GetLODLevelCount());
				SetLoopFlag(FxTemplate->IsLooping());
			}
		};

		if (!af_IsResourceReadyForLoad(TCHAR_TO_UTF8(*mName)))	//��Դ�ļ�δ׼����ʱ������ Lua ��������������С����Դ
		{
			AzureResourceInGameUpdateDownload::DownloadRes(*mName, TEXT("AFxCache::InitWithPrefab"), [this, self, func](AInGameUpdateDownloadResult downloadResult)
			{
				if (!self.IsValid())
					return;

				if (sFxIGULoadDelay >= 0)
				{
					FTimerHandle timer;
					GetWorld()->GetTimerManager().SetTimer(timer, [this, self, func]()
					{
						if (!self.IsValid())
							return;

						AzureResourceLoader::Get().LoadGameResAsync(mName, std::move(func));
					}, sFxIGULoadDelay, false);
				}
				else
				{
					AzureResourceLoader::Get().LoadGameResAsync(mName, std::move(func));
				}
			});
			return;
		}

		//Ĭ��ֱ�ӿ�ʼ����
		AzureResourceLoader::Get().LoadGameResAsync(mName, std::move(func));
	}
}

bool AFxCache::Touch(AFxOne& fxone)
{
	if (!mLoading && !FxTemplate)
	{
		return false;
	}

	++mUsedCount;
	fxone.mName = mName;
	fxone.FxCache = this;
	return true;
}

void AFxCache::Untouch(AFxOne& fxone)
{
	--mUsedCount;
	fxone.ClearFxTemplate();
	fxone.FxCache = nullptr;
	mLastReleaseTime = FPlatformTime::Seconds();
	WaitingResourceFxOnes.Remove(&fxone);
}

void AFxCache::OnPlay(AFxOne& fxone)
{
	if (mLoading)
	{
		WaitingResourceFxOnes.AddUnique(&fxone);
	}
	else
	{
		//	call AFxOne::SetFxTemplate here in case fxone stops (i.e. duration expired) before resource loaded, in which case FxTemplate will not be set
		//	Repeatedly set the same template is avoided within AFxOne::SetFxTemplate
		if (FxTemplate)
		{
			fxone.SetFxTemplate(FxTemplate);
		}
	}
}

void AFxCache::OnStop(AFxOne& fxone)
{
	if (mLoading)
	{
		WaitingResourceFxOnes.Remove(&fxone);
	}
}

uint32 AFxCache::GetMaxLodCost() const
{
	uint32 Result = 0;
	int32 MaxLod = AFxCacheMan::GetMaxLodofCurrentQuality();
	if (LodCosts.IsValidIndex(MaxLod))
	{
		Result = LodCosts[MaxLod];
	}
	
	return Result;
}