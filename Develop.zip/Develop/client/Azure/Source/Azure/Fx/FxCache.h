// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"

#include "FxCache.generated.h"

class AFxOne;
class AFxCacheMan;
class UParticleSystem;

UCLASS()
class AZURE_API AFxCache : public AActor
{
	GENERATED_BODY()

	typedef TArray<AFxOne *>  FXOneList;

public:	
	// Sets default values for this actor's properties
	AFxCache();

	// Called when the game starts or when spawned
	virtual void BeginPlay() override;
	virtual void BeginDestroy() override;

	// Called every frame
	void InitWithPrefab(const FString& name, const UParticleSystem* InFxTemplate);
	void SetDestroy();

	bool Touch(AFxOne& fxone);
	void Untouch(AFxOne& fxone);

	void OnPlay(AFxOne& fxone);
	void OnStop(AFxOne& fxone);

	uint32 GetMaxLodCost() const; //��ȡ��ǰQuality�µ����Lod��Cost

	void SetLodCosts(const TArray<uint32>& InLodCosts) { LodCosts = InLodCosts; }

	TArray<uint32> GetLodCosts() const { return LodCosts; }

	void SetLodCount(int32 InLodCount) { LodCount = InLodCount; }

	int32 GetLodCount() const { return LodCount; }

	void SetLoopFlag(bool InLoopFlag) { IsLoop = InLoopFlag; }

	bool IsLoopPlay() const { return IsLoop; }

public:
	FString mName;
	int	 mUsedCount = 0;

	double mLastReleaseTime = 0.f;
	float mLastInstantiateTime = 0.f;

	UPROPERTY(Transient)
	AFxCacheMan* FxCacheMan = nullptr;

	UPROPERTY(Transient)
	const UParticleSystem* FxTemplate = nullptr;

	bool mLoading = true;
	bool mDestroy = false;

	UPROPERTY(Transient)
	TArray<AFxOne*> WaitingResourceFxOnes;

private:

	TArray<uint32> LodCosts; //ÿ��Lod��Cost

	int32 LodCount;  //Lod������

	bool IsLoop;	//�Ƿ�ѭ������
};
