﻿// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "wLua/LuaInterface.h"
#include "Particles/ParticleSystem.h"
#include "Components/SkeletalMeshComponent.h"
#include "FxRestriction.h"
#include "FxOne.h"
#include "FxCacheMan.generated.h"

class AFxCache;
class AFxOne;
class UAnimNotify_PlayParticleEffect;
class UAnimNotifyState_Trail;
class UAnimNotifyState_TimedParticleEffect;
class USkeletalMeshComponent;
class UAnimSequenceBase;
class UParticleSystem;

typedef TMap<int32, TPair<int32, int32> > AzureQualityLodCostMap; //Quality对应的Lod最大使用等级和cost上限

UENUM()
enum class FxCachePolicy : uint8
{
	COUNT_LIMIT, //基于数量限制
	MAX_COST,   //基于总Cost限制
	NUM,
};

UCLASS()
class AZURE_API AFxCacheMan : public AActor
{
	GENERATED_BODY()
	
public:
	// Sets default values for this actor's properties
	AFxCacheMan();

	// Called when the game starts or when spawned
	virtual void BeginPlay() override;

	/** Overridable function called whenever this actor is being removed from a level */
	virtual void EndPlay(const EEndPlayReason::Type EndPlayReason);
	
	// Called every frame
	virtual void Tick( float DeltaSeconds ) override;

	UFUNCTION(BlueprintCallable, Category = "FxCacheMan")
	bool Get_RenderHide() {
		return mRenderHide;
	}

	UFUNCTION(BlueprintCallable, Category = "FxCacheMan")
	void Set_RenderHide(bool hide);

	UFUNCTION(BlueprintCallable, Category = "FxCacheMan")
	static int Get_maxFxCount() {
		return mMaxFxones;
	}

	UFUNCTION(BlueprintCallable, Category = "FxCacheMan")
	static void Set_maxFxCount(int count) {
		if (count > 0) {
			mMaxFxones = count;
		}
	}

	UFUNCTION(BlueprintCallable, Category = "FxCacheMan")
	static int Get_maxUnusedFxCount() {
		return mMaxUnusedFxs;
	}

	UFUNCTION(BlueprintCallable, Category = "FxCacheMan")
	static void Set_maxUnusedFxCount(int count) {
		if (count > 0)
			mMaxUnusedFxs = count;
	}

	UFUNCTION(BlueprintCallable, Category = "FxCacheMan")
	int Get_currentFxCount() const;

	UFUNCTION(BlueprintCallable, Category = "FxCacheMan")
	static int Get_FxQuality()
	{
		return static_cast<int>(FxQuality);
	}

	UFUNCTION(BlueprintCallable, Category = "FxCacheMan")
	static void Set_FxQuality(int value)
	{
		if (value >= 0 && value < static_cast<int>(EAzureFxQuality::Num))
		{
			FxQuality = static_cast<EAzureFxQuality>(value);
		}
	}

	UFUNCTION(BlueprintCallable, Category = "FxCacheMan")
	static int FxQualityToLODLevel(int InFxQuality, int InLODLevelCount);

	static int LimitLodRange(int InLod, int InLODLevelCount);

	UFUNCTION(BlueprintCallable, Category = "FxCacheMan")
	static int GetMaxFxCountWithQualityAndCost(int InFxQuality, int InFxCost)
	{
		return MaxFxCountWithQualityAndCost[InFxQuality][InFxCost];
	}

	UFUNCTION(BlueprintCallable, Category = "FxCacheMan")
	static void SetMaxFxCountWithQualityAndCost(int InFxQuality, int InFxCost, int count)
	{
		MaxFxCountWithQualityAndCost[InFxQuality][InFxCost] = count;
	}

	UFUNCTION(BlueprintCallable, Category = "FxCacheMan")
	static int GetCurFxCountWithQualityAndCost(int InFxQuality, int InFxCost)
	{
		return CurFxCountWithQualityAndCost[InFxQuality][InFxCost];
	}

	UFUNCTION(BlueprintCallable, Category = "FxCacheMan")
	static void SetCurFxCountWithQualityAndCost(int InFxQuality, int InFxCost, int count)
	{
		CurFxCountWithQualityAndCost[InFxQuality][InFxCost] = count;
	}

	UFUNCTION(BlueprintCallable, Category = "FxCacheMan")
	static void IncreaseCurFxCountWithQualityAndCost(int InFxQuality, int InFxCost)
	{
		++ CurFxCountWithQualityAndCost[InFxQuality][InFxCost];
	}

	UFUNCTION(BlueprintCallable, Category = "FxCacheMan")
	static void DecreaseCurFxCountWithQualityAndCost(int InFxQuality, int InFxCost)
	{
		-- CurFxCountWithQualityAndCost[InFxQuality][InFxCost];
	}

	UFUNCTION(BlueprintCallable, Category = "FxCacheMan")
	static int IsExceedingFxLimitWithQualityAndCost(int InFxQuality, int InFxCost)
	{
		return GetMaxFxCountWithQualityAndCost(InFxQuality, InFxCost) >= 0	//	-1 means there's no limit
			&& GetCurFxCountWithQualityAndCost(InFxQuality, InFxCost) >= GetMaxFxCountWithQualityAndCost(InFxQuality, InFxCost);
	}

	static void OnLoadFinishToLua(const FString& name, bool succ);

	UFUNCTION(BlueprintCallable, Category = "FxCacheMan")
	static void RegLoadFinishFunc(FAzureLuaFunction func);

	UFUNCTION(BlueprintCallable, Category = "FxCacheMan")
	AFxOne* RequestFx(const FString& InName, int32 InPriority=0/*值越大，优先级越大*/, const UParticleSystem* InFxTemplate=nullptr, bool bCanReplay=false, bool bCountLimited=true);

	UFUNCTION(BlueprintCallable, Category = "FxCacheMan")
	TArray<AFxOne*> GetActiveFxOnes() { return ActiveFxOnes; }


	UFUNCTION(BlueprintCallable, Category = "FxCacheMan")
	FxCachePolicy GetFxCachePolicy()
	{
		return CachePolicy;
	}

	UFUNCTION(BlueprintCallable, Category = "FxCacheMan")
	void SetFxCachePolicy(FxCachePolicy Policy)
	{
		CachePolicy = Policy;
	}

	UFUNCTION(BlueprintCallable, Category = "FxCacheMan")
	static int32 GetMaxLodofCurrentQuality()
	{
		TPair<int32, int32> Result(0, 0);
		if (QualityLodCostMap.Contains(CurrentQuality))
		{
			Result = *QualityLodCostMap.Find(CurrentQuality);
		}

		return Result.Key;
	}

	UFUNCTION(BlueprintCallable, Category = "FxCacheMan")
	static int32 GetMaxLodCostofCurrentQuality()
	{
		TPair<int32, int32> Result(0, 0);
		if (QualityLodCostMap.Contains(CurrentQuality))
		{
			Result = *QualityLodCostMap.Find(CurrentQuality);
		}

		return Result.Value;
	}

	UFUNCTION(BlueprintCallable, Category = "FxCacheMan")
	static void SetLodCostofQuality(int32 Quality, int32 MaxLod, int32 MaxCost)
	{
		TPair<int32, int32> LodCost(MaxLod, MaxCost);
		QualityLodCostMap.Emplace(Quality, LodCost);
	}

	UFUNCTION(BlueprintCallable, Category = "FxCacheMan")
	static int32 GetCurrentQuality()
	{
		return CurrentQuality;
	}

	UFUNCTION(BlueprintCallable, Category = "FxCacheMan")
	static void SetCurrentQuality(int32 Quality)
	{
		CurrentQuality = Quality;
	}

	UFUNCTION(BlueprintCallable, Category = "FxCacheMan")
	static int32 GetCurrentTotalCost()
	{
		return TotalCost;
	}

	UFUNCTION(BlueprintCallable, Category = "FxCacheMan")
	static void RegisterAzureFxProxy(UParticleSystemComponent* PSComponent, int32 Priority, int32 Lod = 0);

	UFUNCTION(BlueprintCallable, Category = "FxCacheMan")
	static void UnRegisterAzureFxProxy(UParticleSystemComponent* PSComponent);

	static void SortActiveAzureFxProxy();
	static void ChangeTotalCost(int32 Value);
	static bool IsExceedingCountLimitEx(int32& DiffValue);
	static bool AdjustActiveFxProxy(int32 Tolerance);
	static TArray<AzureFxProxy>& GetActiveAzureFxProxyList() { return ActiveAzureFxProxyList; }

	static EAzureFxCost	GetFxCostFromTemplate(const UParticleSystem* InFxTemplate);
	static EAzureFxQuality CalculateQuality(const AzureFxRestriction& InFxRestriction);

	void GiveBack(AFxOne& fxone);
	void OnFxDestroy(AFxOne& fxone);
	void StopAllActiveFx();

	TArray<AzureFxRestriction> CollectActiveFxRestriction() const;

private:
	bool IsExceedingCountLimit() const;
	int GetLimitedFxCount() const;

	bool IsCanReplaceAnyFxWithPriority(int InPriority)const;
	int GetLimitedFxLowestPriority()const;
	bool StopOneFxWithPrioritySameOrLowerThan(int InPriority);

	AFxOne* GetFxOneFromCache();

	bool OnAnimNotify_PlayParticleEffect(const UAnimNotify_PlayParticleEffect* PlayFxNotify, class USkeletalMeshComponent* MeshComp, class UAnimSequenceBase* Animation);
	bool OnAnimNotifyState_Trail_NotifyBegin(const UAnimNotifyState_Trail* PlayTrailFxNotifyState, class USkeletalMeshComponent* MeshComp, class UAnimSequenceBase* Animation, const UParticleSystem* FxTemplate, bool* bShouldIgnore, int* LODLevel);
	bool OnAnimNotifyState_Trail_NotifyEnd(const UAnimNotifyState_Trail* PlayTrailFxNotifyState, class USkeletalMeshComponent* MeshComp, class UAnimSequenceBase* Animation);
	bool OnAnimNotifyState_TimedParticleEffect_NotifyBegin(const UAnimNotifyState_TimedParticleEffect* PlayTimedFxNotifyState, class USkeletalMeshComponent* MeshComp, class UAnimSequenceBase* Animation, bool* bShouldIgnore, int* LODLevel);
	bool OnAnimNotifyState_TimedParticleEffect_NotifyEnd(const UAnimNotifyState_TimedParticleEffect* PlayTimedFxNotifyState, class USkeletalMeshComponent* MeshComp, class UAnimSequenceBase* Animation);

	
protected:
	UPROPERTY(Transient)
	TMap<FString, AFxCache*> FxCaches;

	UPROPERTY(Transient)
	TArray<AFxOne*> ActiveFxOnes;

	UPROPERTY(Transient)
	TArray<AFxOne*> FreeFxOnes;

	bool mRenderHide = false;
	int mFrameCount = 0;

	template<typename KeyType1, typename KeyType2>
	struct TPairKey
	{
	public:
		TPairKey(const KeyType1& InKey1, const KeyType2& InKey2)
			: Key1(InKey1)
			, Key2(InKey2)
			, KeyHash(0)
		{
			KeyHash = HashCombine(KeyHash, GetTypeHash(Key1));
			KeyHash = HashCombine(KeyHash, GetTypeHash(Key2));
		}

		FORCEINLINE bool operator==(const TPairKey& Other) const
		{
			return Key1 == Other.Key1
				&& Key2 == Other.Key2;
		}

		FORCEINLINE bool operator!=(const TPairKey& Other) const
		{
			return !(*this == Other);
		}

		friend inline uint32 GetTypeHash(const TPairKey& Key)
		{
			return Key.KeyHash;
		}

	private:
		KeyType1 Key1;
		KeyType2 Key2;
		uint32 KeyHash;
	};

	typedef TPairKey<TWeakObjectPtr<const UAnimNotifyState_Trail>, TWeakObjectPtr<USkeletalMeshComponent>> AnimNotifyState_Trail_Key;
	typedef TMap<AnimNotifyState_Trail_Key, AzureFxRestriction> AnimNotifyState_Trail_FxRestriction;
	AnimNotifyState_Trail_FxRestriction Active_AnimNotifyState_Trail_FxRestriction;

	typedef TPairKey<TWeakObjectPtr<const UAnimNotifyState_TimedParticleEffect>, TWeakObjectPtr<USkeletalMeshComponent>> AnimNotifyState_TimedParticleEffect_Key;
	typedef TMap<const AnimNotifyState_TimedParticleEffect_Key, AzureFxRestriction> AnimNotifyState_TimedParticleEffect_FxRestriction;
	AnimNotifyState_TimedParticleEffect_FxRestriction Active_AnimNotifyState_TimedParticleEffect_FxRestriction;

	static int mMaxFxones;			// 最多同时播放的非 Stable fx
	static int mMaxUnusedFxs;		// 回收池内的最大fx数量

	static EAzureFxQuality FxQuality;

    static constexpr int EAzureFxQuality_Num = 4;	//	EAzureFxQuality::Num is not compile-time const in xcode 8.3.2
    static constexpr int EAzureFxCost_Num = 4;		//	EAzureFxCost::Num is not compile-time const in xcode 8.3.2
	static int MaxFxCountWithQualityAndCost[EAzureFxQuality_Num][EAzureFxCost_Num];	//	Azure controlled Fx Count Limit Per Each Quality
	static int CurFxCountWithQualityAndCost[EAzureFxQuality_Num][EAzureFxCost_Num];	//	Accumulated Azure controlled Fx Count Limit Per Each Quality

	static FAzureLuaFunction mOnLoadFinishFunc;

private:

	static AzureQualityLodCostMap QualityLodCostMap; 

	static int32 CurrentQuality; //当前Quality等级

	static int32 TotalCost; //当前ActiveFxOne的Cost

	static TArray<AzureFxProxy> ActiveAzureFxProxyList;

	FxCachePolicy CachePolicy; //FxCache使用的策略

	typedef TMap<AnimNotifyState_TimedParticleEffect_Key, TWeakObjectPtr<AFxOne> > AnimNotifyState_TimedParticleEffect_FxOneMap;
	AnimNotifyState_TimedParticleEffect_FxOneMap Active_AnimNotifyState_TimedParticleEffect_FxOneMap;

	typedef TMap<AnimNotifyState_Trail_Key, TWeakObjectPtr<AFxOne> > AnimNotifyState_Trail_FxOneMap;
	AnimNotifyState_Trail_FxOneMap Active_AnimNotifyState_Trail_FxOneMap;
};
