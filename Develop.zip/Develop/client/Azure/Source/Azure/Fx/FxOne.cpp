﻿// Fill out your copyright notice in the Description page of Project Settings.

#include "FxOne.h"
#include "Particles/ParticleSystemComponent.h"
#include "Azure.h"
#include "FxCacheMan.h"
#include "FxCache.h"
#include "ParticleEmitterInstances.h"
#include "Components/SceneComponent.h"
#include "Curves/CurveFloat.h"
#include "Animation/AnimInstance.h"

// Sets default values
AFxOne::AFxOne() :
	Priority(0),
	MaxLod(0)
{
	// Set this actor to call Tick() every frame.  You can turn this off to improve performance if you don't need it.
	PrimaryActorTick.bCanEverTick = true;

	RootComponent = CreateDefaultSubobject<USceneComponent>(TEXT("RootComponent"));

	//	see CreateParticleSystem in GameplayStatics.cpp
	FxComponent = CreateDefaultSubobject<UParticleSystemComponent>(TEXT("ParticleComponent"));
	FxComponent->bAutoDestroy = false;
	FxComponent->bAllowAnyoneToDestroyMe = false;
	FxComponent->SecondsBeforeInactive = 0.f;
	FxComponent->bAutoActivate = false;				//	bAutoAcitvate=true will cause ParticleSystem to complete within SetFxTemplate 
	FxComponent->bOverrideLODMethod = false;
	FxComponent->AttachToComponent(RootComponent, FAttachmentTransformRules(EAttachmentRule::KeepRelative, false));
	FxComponent->OnSystemFinished.AddUniqueDynamic(this, &AFxOne::OnParticleSystemFinished);

	CurrentLod = AFxCacheMan::GetMaxLodofCurrentQuality();
}

// Called every frame
void AFxOne::Tick( float DeltaTime )
{
	Super::Tick( DeltaTime );
	if (IsInvoking())
	{
		mInvokeTime -= DeltaTime;
		if (mInvokeTime <= 0.f)
		{
			if (!IsDelayStopping())
			{
				Stop();
			}
		}
	}

	if (IsDelayStopping())
	{
		mDelayStopTime -= DeltaTime;
		if (mDelayStopTime <= 0)
		{
			Stop();
		}
	}

	if (IsWaitingReplay())
	{
		mNextPlayTime -= DeltaTime;
		if (mNextPlayTime <= 0.f)
		{
			DoPlayLogically();
		}
	}
	float Width = GetTrailWidth();
	if (TrailOwner.IsValid() && FxComponent && FxComponent->IsActive())
	{
		UParticleSystemComponent::TrailEmitterArray TrailEmitters;
		FxComponent->GetOwnedTrailEmitters(TrailEmitters, TrailOwner.Get(), true);
		for (FParticleAnimTrailEmitterInstance* Trail : TrailEmitters)
		{
			Trail->SetTrailSourceData(FirstSocketName, SecondSocketName, TrailWidthMode, Width);
		}
	}
}

void AFxOne::BeginDestroy()
{
	if (IsLogicallyPlaying())
	{
		StopLogicallyPlay();
	}
	if (IsInvoking())
	{
		CancelInvoke();
	}
	if (IsWaitingReplay())
	{
		CancelReplay();
	}
	if (FxCache)
	{
		FxCache->Untouch(*this);
	}
	if (FxCacheMan)
	{
		FxCacheMan->OnFxDestroy(*this);
	}
	Super::BeginDestroy();
}

void AFxOne::Play(float duration, bool needHighLod)
{
	if (!FxCacheMan)
	{
		UE_LOG(LogAzure, Error, TEXT("Attempt to play free fx."));
		return;
	}
	if (!FxCache)
	{
		UE_LOG(LogAzure, Error, TEXT("Attempt to play untouched fx."));
		return;
	}

	CancelDelayStop();

	if (IsWaitingReplay())
	{
		return;
	}
	if (IsLogicallyPlaying() && !Get_CanReplay())
	{
		return;
	}

	if (IsLogicallyPlaying())
	{
		StopLogicallyPlay();

		SavePlayParameter(duration, needHighLod);
		ReplayAfterSeconds(0.2f);
	}
	else
	{
		SavePlayParameter(duration, needHighLod);
		DoPlayLogically();
	}
}

void AFxOne::SavePlayParameter(float duration, bool needHighLod)
{
	FxRestriction.bNeedHighLod = needHighLod;
	mDuration = duration;
}

void AFxOne::DoPlayLogically()
{
	CancelInvoke();
	CancelReplay();

	mLogicallyPlaying = true;

	mStartTime = FPlatformTime::Seconds();
	SetInvoke(mDuration);

	FxCache->OnPlay(*this);

	if (IsResourceReady())
	{
		DoPlayReally();
	}
}

void AFxOne::StopLogicallyPlay()
{
	CancelInvoke();
	CancelReplay();

	mLogicallyPlaying = false;

	if (IsReallyPlaying())
	{
		StopReallyPlay();
	}

	FxCache->OnStop(*this);
}

bool AFxOne::IsResourceReady()const
{
	return FxComponent != nullptr
		&& FxComponent->Template != nullptr;
}

void AFxOne::OnResourceReady()
{
	if (IsLogicallyPlaying())
	{
		double LeftDuration = GetLeftDuration();
		if (LeftDuration != 0.f)
		{
			DoPlayReally();
			SetInvoke(LeftDuration);
		}
		else
		{
			Stop();
		}
	}
}

void AFxOne::DoPlayReally()
{
	SetFXVisible(true);
	OnAllFxRenderHideFlagChanged();

#if ENABLE_FX_TRACK
	extern bool IsFxTracked(const FString&);
	extern void LogTrackedFxWhenReallyPlayed(const FString& InName);
	if (IsFxTracked(mName))
	{
		LogTrackedFxWhenReallyPlayed(mName);
	}
#endif

	if(FxComponent)
		FxComponent->ActivateSystem(false);

	FxCachePolicy Policy = FxCacheMan ? FxCacheMan->GetFxCachePolicy() : FxCachePolicy::COUNT_LIMIT;

	int32 LODLevel = 0;
	if (Policy == FxCachePolicy::MAX_COST)
	{
		if (!FxComponent || !FxComponent->Template)
		{
			UE_LOG(LogAzure, Error, TEXT("cost Attempt to play null Template fx. name:%s"), *mName);
			return;
		}

		mReallyPlaying = true;
		LODLevel = FMath::Max(MaxLod, AFxCacheMan::GetMaxLodofCurrentQuality());		
		AFxCacheMan::RegisterAzureFxProxy(FxComponent, Priority, LODLevel);
	}
	else if (Policy == FxCachePolicy::COUNT_LIMIT)
	{
		if (!FxComponent || !FxComponent->Template)
		{
			UE_LOG(LogAzure, Error, TEXT("Attempt to play null Template fx. name:%s"), *mName);
			return;
		}

		FxRestriction.FxQuality = CalculateQuality();
		LODLevel = AFxCacheMan::FxQualityToLODLevel(static_cast<int>(FxRestriction.FxQuality), FxComponent->Template->GetLODLevelCount());
		AFxCacheMan::IncreaseCurFxCountWithQualityAndCost(static_cast<int>(FxRestriction.FxQuality), static_cast<int>(FxRestriction.FxCost));
	
		if (FxComponent && LODLevel >= 0)
		{
			FxComponent->SetLODLevel(LODLevel);
		}
	}
	
	
			
	UpdateTickEnable();
	if (TrailOwner.IsValid())
	{
		UParticleSystemComponent::TrailEmitterArray TrailEmitters;
		if (FxComponent)
		{
			FxComponent->AttachToComponent(TrailOwner.Get(), FAttachmentTransformRules::KeepRelativeTransform);
			FxComponent->ActivateSystem(true);
			FxComponent->GetOwnedTrailEmitters(TrailEmitters, TrailOwner.Get(), true);
		}
		for (FParticleAnimTrailEmitterInstance* Trail : TrailEmitters)
		{
			if (Trail)
			{
				Trail->BeginTrail();
				Trail->SetTrailSourceData(FirstSocketName, SecondSocketName, TrailWidthMode, GetTrailWidth());
			}
		}
	}
}

void AFxOne::StopReallyPlay()
{
#if ENABLE_FX_TRACK
	extern bool IsFxTracked(const FString&);
	extern void LogTrackedFxWhenStopped(const FString& InName);
	if (IsFxTracked(mName))
	{
		LogTrackedFxWhenStopped(mName);
	}
#endif
	FxCachePolicy Policy = FxCacheMan ? FxCacheMan->GetFxCachePolicy() : FxCachePolicy::COUNT_LIMIT;

	if (Policy == FxCachePolicy::MAX_COST)
	{		
		SetCurrentLod(AFxCacheMan::GetMaxLodofCurrentQuality());	
		AFxCacheMan::UnRegisterAzureFxProxy(FxComponent);
		mReallyPlaying = false;
	}
	else if (Policy == FxCachePolicy::COUNT_LIMIT)
	{
		AFxCacheMan::DecreaseCurFxCountWithQualityAndCost(static_cast<int>(FxRestriction.FxQuality), static_cast<int>(FxRestriction.FxCost));

		FxRestriction.ClearFxQuality();
		FxRestriction.ClearMaxFxQuality();
	}

	if (!IsBeingDestroyed())
	{
		if(FxComponent)
			FxComponent->DeactivateSystem();
	}

	SetFXVisible(false);
	UpdateTickEnable();
}

void AFxOne::OnAllFxRenderHideFlagChanged()
{
	bool hide = !notEffectByManRenderHide && FxCacheMan->Get_RenderHide();
	SetFXVisibleInner(!hide, FxOneVisibleMask::FxMan);
}

void AFxOne::SetNotEffectByManRenderHide(bool notEffect)
{
	notEffectByManRenderHide = notEffect;
	OnAllFxRenderHideFlagChanged();
}

void AFxOne::SetTrailParam(UMeshComponent* MeshComponent, FName InFirstSocketName, FName InSecondSocketName, ETrailWidthMode Mode, UAnimInstance* Anim, FName CurveName)
{
	TrailOwner = MeshComponent;
	FirstSocketName = InFirstSocketName;
	SecondSocketName = InSecondSocketName;
	TrailWidthMode = Mode;
	AnimInstance = Anim;
	TrailWidthCurveName = CurveName;
}

void AFxOne::SetFXVisible(bool bVisible)
{

	SetFXVisibleInner(bVisible, FxOneVisibleMask::Logic);
}

float AFxOne::GetTrailWidth() const
{
	float Width = 1.0f;
	if (AnimInstance.IsValid() && !TrailWidthCurveName.IsNone())
	{
		if (AnimInstance->GetCurveValue(TrailWidthCurveName, Width))
		{
			return Width;
		}
		else
		{
			UE_LOG(LogTemp, Error, TEXT("Cannot get trail width curve value in curve %s"), *TrailWidthCurveName.ToString());
		}
	}
	return Width;
}

double AFxOne::GetLeftDuration()const
{
	double Result = 0.0;
	if (IsLogicallyPlaying())
	{
		if (mDuration < 0.0)
		{
			Result = -1.0;	//	means has no given duration
		}
		else
		{
			Result = GetStartTime() + mDuration - FPlatformTime::Seconds();
			if (Result < 0.0)
			{
				Result = 0.0;
			}
		}
	}
	return Result;
}

EAzureFxQuality AFxOne::CalculateQuality()const
{
	return AFxCacheMan::CalculateQuality(FxRestriction);
}

void AFxOne::UpdateTickEnable()
{
	if (!IsBeingDestroyed())
	{
		SetActorTickEnabled(IsWaitingReplay() || IsInvoking() || IsReallyPlaying());
	}
}

void AFxOne::SetFXVisibleInner(bool bVisible, FxOneVisibleMask mask)
{
	SetFXVisibleEx(bVisible, (int32)mask);
}

void AFxOne::SetFXVisibleEx(bool bVisible, int32 mask)
{
	if (IsBeingDestroyed()) return;

	uint32 iMask = (uint32)mask;
	if (bVisible) invisibleMask &= ~iMask;
	else invisibleMask |= iMask;

	if (FxComponent) FxComponent->SetVisibility(invisibleMask == 0);
}

bool AFxOne::IsWaitingReplay()const
{
	return mNextPlayTime >= 0.f;
}

void AFxOne::OnParticleSystemFinished(class UParticleSystemComponent* FinishedComponent)
{
	if (IsLogicallyPlaying())
	{
		Stop();
	}
}

void AFxOne::DelayStop(float fDelayTime)
{
	mDelayStopTime = fDelayTime;

	//if (mDelayStopTime == 0)
	//	Stop();
}

void AFxOne::Stop()
{
	CancelDelayStop();

	if (IsLogicallyPlaying())
	{
		StopLogicallyPlay();
	}
	if (IsInvoking())
	{
		CancelInvoke();
	}
	if (IsWaitingReplay())
	{
		CancelReplay();
	}
	if (!Get_CanReplay())
	{
		if (FxCache)
		{
			FxCache->Untouch(*this);
		}
		if (FxCacheMan)
		{
			FxCacheMan->GiveBack(*this);
		}
	}
	if (TrailOwner.IsValid())
	{
		if(FxComponent)
			FxComponent->AttachToComponent(RootComponent, FAttachmentTransformRules(EAttachmentRule::KeepRelative, false));
		TrailOwner = nullptr;
		AnimInstance = nullptr;
	}

	CallOnStopCallback();
}

bool AFxOne::IsReallyPlaying()const
{
	FxCachePolicy Policy = FxCacheMan ? FxCacheMan->GetFxCachePolicy() : FxCachePolicy::COUNT_LIMIT;

	if (Policy == FxCachePolicy::COUNT_LIMIT)
	{
		return FxRestriction.IsFxQualityValid();
	}
	else if (Policy == FxCachePolicy::MAX_COST)
	{
		return mReallyPlaying;
	}
	return true;
}

void AFxOne::SetFxTemplate(const UParticleSystem* InFxTemplate)
{
	if (FxComponent)
	{
		if (FxComponent->Template == InFxTemplate)
		{
			return;
		}
		FxComponent->SetTemplate(const_cast<UParticleSystem*>(InFxTemplate));
	}
	FxRestriction.FxCost = AFxCacheMan::GetFxCostFromTemplate(InFxTemplate);
}

void AFxOne::ClearFxTemplate()
{
	if (!IsBeingDestroyed())
	{
		if(FxComponent)
			FxComponent->SetTemplate(nullptr);
	}
	FxRestriction.ClearFxCost();
}

void AFxOne::AddOnStopCallback(wLua::lua_registry_handle cb, wLua::lua_registry_handle cbparam)
{
	if (cb.IsNoRef())
	{
		assert(false);
		return;
	}

	ClearOnStopCallback();
	OnStopCallback = cb;
	OnStopCallbackParam = cbparam;
}

void AFxOne::ClearOnStopCallback()
{
	if (!AAzureEntryPoint::Instance)
		return;

	lua_State_Wrapper L = AAzureEntryPoint::Instance->GetWLua()->GetL();
	wLua::lua_registry_handle::wlua_unref(L, LUA_REGISTRYINDEX, OnStopCallback);
	wLua::lua_registry_handle::wlua_unref(L, LUA_REGISTRYINDEX, OnStopCallbackParam);
	OnStopCallback.Clear();
	OnStopCallbackParam.Clear();
}

void AFxOne::SetInvoke(float t)
{
	if (t <= 0.f || !IsLogicallyPlaying() || IsInvoking())
	{
		return;
	}
	mInvokeTime = t;
	UpdateTickEnable();
}

void AFxOne::CancelInvoke()
{
	mInvokeTime = -1.f;
	UpdateTickEnable();
}

bool AFxOne::IsInvoking() const
{
	return mInvokeTime >= 0;
}

void AFxOne::ReplayAfterSeconds(float InNextPlayTime)
{
	mNextPlayTime = InNextPlayTime;
	UpdateTickEnable();
}

void AFxOne::CancelReplay()
{
	mNextPlayTime = -1.f;
	UpdateTickEnable();
}

bool AFxOne::IsBeingDestroyed()const
{
	return HasAnyFlags(RF_BeginDestroyed);
}

void AFxOne::CallOnStopCallback()
{
	// 避免循环调用
	if (IsCallOnStopCallBack)
	{
		return;
	}

	// 调用回调函数
	if (OnStopCallback.IsNoRef())
	{
		return;
	}

	if (!AAzureEntryPoint::Instance)
		return;

	wLua::Lua* wlua = AAzureEntryPoint::Instance->GetWLua();
	lua_State_Wrapper L = wlua->GetL();
	lua_rawgeti(L, LUA_REGISTRYINDEX, OnStopCallback); // callback
	lua_pushvalue(L, -1);	//cb, cb

	if (OnStopCallbackParam.IsNoRef())
	{
		lua_pushnil(L);
	}
	else
	{
		lua_rawgeti(L, LUA_REGISTRYINDEX, OnStopCallbackParam); // callback, cbparam
	}

	IsCallOnStopCallBack = true;
	bool bRet = wlua->PCallWithFunctionInfo(1, 0);	//-> cb, [err]
	IsCallOnStopCallBack = false;

	if (bRet)
	{
		lua_pop(L, 1);
	}
	else
	{
		lua_pushvalue(L, -2);
		FString info = wlua->GetFunctionInfo();
		FString errorInfo = FString::Printf(TEXT("@FxOne OnStopCallback:%s@@@@@@@@@"), *info, UTF8_TO_TCHAR(lua_tostring(L, -1)));
		lua_pop(L, 2);
		UE_LOG(LogAzure, Error, TEXT("%s"), *errorInfo);
	}

	// 清理回调引用
	ClearOnStopCallback();
}

bool AFxOne::IsLoopPlay() const
{
	return FxCache ? FxCache->IsLoopPlay() : false;
}

int32 AFxOne::GetLODLevelCount() const
{
	return FxCache ? FxCache->GetLodCount() : 0;
}

void AFxOne::OnGiveBack()
{
	//重置为相对坐标，避免复用时错误
	RootComponent->SetAbsolute(false, false, false);
	notEffectByManRenderHide = false;
	invisibleMask = 0;
}

uint32 AFxOne::GetLodCost(int32 Lod) const
{
	uint32 Cost = 0;
	if (FxCache)
	{
		Lod = Lod < 0 ? CurrentLod : Lod;
		TArray<uint32> LodCosts = FxCache->GetLodCosts();
		if (LodCosts.IsValidIndex(Lod))
		{
			Cost = LodCosts[Lod];
		}
	}
	return Cost;
}


void AFxOne::SetLodLevel(int32 Lod)
{
	SetCurrentLod(Lod);
	if (FxComponent)
	{
		FxComponent->SetLODLevel(Lod);
	}
}

void AFxOne::Destroyed()
{
	
}

