// Fill out your copyright notice in the Description page of Project Settings.

#include "AzureGameViewportClient.h"
#include "Runtime/Engine/Classes/Animation/AnimInstance.h"
#include "AzureEntryPoint.h"
#include "GameLogic/Input/AzureInputCtrl.h"
#include "Widgets/Layout/SConstraintCanvas.h"
#include "GameLogic/Player/GamePlayerManager.h"
#include "Widgets/SViewport.h"
#include "Application/SlateApplication.h"
#include "Slate/SceneViewport.h"

static int32 s_AzureFixRDPMoveCursor = 0;
static FAutoConsoleVariableRef CVarAzureFixRDPMoveCursor(
	TEXT("Azure.FixRDPMoveCursor"),
	s_AzureFixRDPMoveCursor,
	TEXT("when set to non-zero, fix move cursor in remote desktop (for development environment only"),
	ECVF_Default
);

bool UAzureGameViewportClient::InputKey(FViewport* InViewport, int32 ControllerId, FKey Key, EInputEvent EventType, float AmountDepressed, bool bGamepad)
{
	AzureInputCtrl::GetInstance().InputKey(Key, EventType, AmountDepressed, bGamepad);

	return UGameViewportClient::InputKey(InViewport, ControllerId, Key, EventType, AmountDepressed, bGamepad);
}
bool UAzureGameViewportClient::InputAxis(FViewport* InViewport, int32 ControllerId, FKey Key, float Delta, float DeltaTime, int32 NumSamples, bool bGamepad)
{
	AzureInputCtrl::GetInstance().InputAxis(Key, Delta, DeltaTime, NumSamples, bGamepad);

	return UGameViewportClient::InputAxis(InViewport, ControllerId, Key, Delta, DeltaTime, NumSamples, bGamepad);
}
bool UAzureGameViewportClient::InputChar(FViewport* InViewport, int32 ControllerId, TCHAR Character)
{
	return UGameViewportClient::InputChar(InViewport, ControllerId, Character);
}
bool UAzureGameViewportClient::InputTouch(FViewport* InViewport, int32 ControllerId, uint32 Handle, ETouchType::Type Type, const FVector2D& TouchLocation, float Force, FDateTime DeviceTimestamp, uint32 TouchpadIndex)
{
	//	We should capture during touch, otherwise touch events will be processed by underlying UI (if any) and won't get here.
	//	So we'll miss some touch events, among which the most important is touchEnded
	//	without touchEnded to complete previous touchBegan, things will go wrong, i.e. when move camera far and near
	if (Type == ETouchType::Began)
	{
		m_mouseTouchBeginPos = m_mouseTouchPos = m_lastMouseCursorPos = TouchLocation;
		m_mouseTouchMoved = false;
#if PLATFORM_DESKTOP
		FSlateApplication::Get().GetPlatformCursor()->Show(false);
		Viewport->LockMouseToViewport(true);
#endif
		Viewport->CaptureMouse(true);
	}
	else if (Type == ETouchType::Ended)
	{
		if (!m_bAlwaysCaptureMouse)
		{
			Viewport->CaptureMouse(false);
#if PLATFORM_DESKTOP
			FSlateApplication::Get().GetPlatformCursor()->Show(true);
			Viewport->LockMouseToViewport(false);

			if (m_mouseTouchMoved)
			{
				FGeometry const& geometry = GetGameViewportWidget().Get()->GetCachedGeometry();
				FSlateApplication::Get().SetCursorPos(geometry.LocalToAbsolute(m_mouseTouchBeginPos));
			}
#endif
		}
		m_mouseTouchMoved = false;
	}

#if PLATFORM_DESKTOP
	if (Type != ETouchType::Moved)
		AzureInputCtrl::GetInstance().InputTouch(Handle, Type, TouchLocation);
	else
	{
		AzureInputCtrl::GetInstance().InputTouch(Handle, Type, TouchLocation);

		if (FVector2D::DistSquared(TouchLocation, m_mouseTouchBeginPos) > FSlateApplication::Get().GetDragTriggerDistanceSquared())
			m_mouseTouchMoved = true;

		if (m_mouseTouchMoved && Viewport->HasMouseCapture())
		{
			FVector2D delta = TouchLocation - m_lastMouseCursorPos;
			m_mouseTouchPos += delta;
			m_lastMouseCursorPos = TouchLocation;
			AzureInputCtrl::GetInstance().InputTouch(Handle, ETouchType::Moved, m_mouseTouchPos);

			//move cursor to near center of viewport
			{
				FVector2D cursorPos = FSlateApplication::Get().GetCursorPos();

				FVector2D ViewportSize;
				GetViewportSize(ViewportSize);

				FGeometry const& geometry = GetGameViewportWidget().Get()->GetCachedGeometry();
				FVector2D absMinPos = geometry.LocalToAbsolute(FVector2D(0, 0));
				FVector2D absMaxPos = geometry.LocalToAbsolute(ViewportSize);
				FVector2D viewportAbsSize = absMaxPos - absMinPos;
				FVector2D absCenterPos = (absMinPos + absMaxPos) * 0.5f;
				if (FMath::Abs(cursorPos.X - absCenterPos.X) > viewportAbsSize.X * 0.25f || FMath::Abs(cursorPos.Y - absCenterPos.Y) > viewportAbsSize.Y * 0.25f)
				{
					if (s_AzureFixRDPMoveCursor)	//if Game run in Remote Desktop, SetCursorPos will fail when cursor is hidden
					{
						FSlateApplication::Get().GetPlatformCursor()->Show(true);
						FSlateApplication::Get().SetCursorPos(absCenterPos);
						FSlateApplication::Get().GetPlatformCursor()->Show(false);
					}
					else
					{
						FSlateApplication::Get().SetCursorPos(absCenterPos);
					}
					FVector2D centerPos = geometry.AbsoluteToLocal(absCenterPos);
					m_lastMouseCursorPos = centerPos;
				}
			}
		}
	}
#else
	AzureInputCtrl::GetInstance().InputTouch(Handle, Type, TouchLocation);
#endif

	return UGameViewportClient::InputTouch(InViewport, ControllerId, Handle, Type, TouchLocation,Force, DeviceTimestamp, TouchpadIndex);
}

bool UAzureGameViewportClient::InputMotion(FViewport* InViewport, int32 ControllerId, const FVector& Tilt, const FVector& RotationRate, const FVector& Gravity, const FVector& Acceleration)
{
	AzureInputCtrl::GetInstance().InputMotion(Tilt, RotationRate, Gravity, Acceleration);
	return UGameViewportClient::InputMotion(InViewport, ControllerId, Tilt, RotationRate, Gravity, Acceleration);
}

void UAzureGameViewportClient::ReceivedFocus(FViewport* InViewport)
{
	AzureInputCtrl::GetInstance().OnReceivedFocus(InViewport);

	return UGameViewportClient::ReceivedFocus(InViewport);
}

void UAzureGameViewportClient::LostFocus(FViewport* InViewport)
{
	AzureInputCtrl::GetInstance().OnLostFocus(InViewport);

	return UGameViewportClient::LostFocus(InViewport);
}

void UAzureGameViewportClient::Activated(FViewport* InViewport, const FWindowActivateEvent& InActivateEvent)
{
	AzureInputCtrl::GetInstance().OnActivated(InViewport, InActivateEvent);

	return UGameViewportClient::Activated(InViewport, InActivateEvent);
}

void UAzureGameViewportClient::Deactivated(FViewport* InViewport, const FWindowActivateEvent& InActivateEvent)
{
	AzureInputCtrl::GetInstance().OnDeactivated(InViewport, InActivateEvent);

	return UGameViewportClient::Deactivated(InViewport, InActivateEvent);
}

void UAzureGameViewportClient::PreDeactivated(FViewport* InViewport, const FWindowActivateEvent& InActivateEvent)
{
	AzureInputCtrl::GetInstance().OnPreDeactivated(InViewport, InActivateEvent);
#if PLATFORM_DESKTOP
	if (InViewport->HasMouseCapture())
	{
		InViewport->CaptureMouse(false);
		InViewport->LockMouseToViewport(false);
		FSlateApplication::Get().GetPlatformCursor()->Show(true);
		FSlateApplication::Get().ReleaseMouseCapture();
		FSlateApplication::Get().OnMouseUp(EMouseButtons::Left);
	}
#endif
	return UGameViewportClient::PreDeactivated(InViewport, InActivateEvent);
}

void UAzureGameViewportClient::SetIsSimulateInEditorViewport(bool bInIsSimulateInEditorViewport)
{
	AzureInputCtrl::GetInstance().OnSetIsSimulateInEditorViewport(bInIsSimulateInEditorViewport);
	return UGameViewportClient::SetIsSimulateInEditorViewport(bInIsSimulateInEditorViewport);
}

void UAzureGameViewportClient::MouseEnter(FViewport* InViewport, int32 x, int32 y)
{
	return UGameViewportClient::MouseEnter(InViewport, x, y);
}
void UAzureGameViewportClient::MouseLeave(FViewport* InViewport)
{
	return UGameViewportClient::MouseLeave(InViewport);
}
void UAzureGameViewportClient::MouseMove(FViewport* InViewport, int32 X, int32 Y)
{
	return UGameViewportClient::MouseMove(InViewport, X, Y);
}

void UAzureGameViewportClient::AddViewportWidgetContent(TSharedRef<class SWidget> ViewportContent, const int32 ZOrder)
{
/*	// UAzureCanvasPanel
	class SWrapCanvas : public SConstraintCanvas
	{
	public:
		virtual FReply OnMouseButtonDown(const FGeometry& MyGeometry, const FPointerEvent& MouseEvent) override
		{
			return FReply::Handled();
		}
		virtual FReply OnTouchStarted(const FGeometry& MyGeometry, const FPointerEvent& InTouchEvent) override
		{
			return FReply::Handled();
		}
		virtual FReply OnMouseMove(const FGeometry& MyGeometry, const FPointerEvent& MouseEvent) override
		{
			return FReply::Handled();
		}
		virtual FReply OnTouchMoved(const FGeometry& MyGeometry, const FPointerEvent& InTouchEvent) override
		{
			return FReply::Handled();
		}
	};

	SWidget& Widget = ViewportContent.Get();
	if (Widget.GetType() == TEXT("SConstraintCanvas"))
	{
		SConstraintCanvas& ConstraintCanvas = (SConstraintCanvas&)Widget;
		FChildren *Children = ConstraintCanvas.GetChildren();
		if (Children && Children->Num() == 1)
		{
			typedef SConstraintCanvas::FSlot FPanelSlot;
			typedef TPanelChildren<FPanelSlot> FPanelChildren;
			FPanelChildren& PanelChildren = (FPanelChildren&)*Children;
			FPanelSlot& PanelSlot = PanelChildren[0];
			TSharedRef<SWidget> Content = PanelSlot.GetWidget();
			TSharedRef<SWrapCanvas> WrapCanvas = SNew(SWrapCanvas);
			PanelSlot.AttachWidget(WrapCanvas);
			WrapCanvas->AddSlot()
				.Offset(FMargin(0))
				.Anchors(FAnchors(0, 0, 1, 1))
				.Alignment(FVector2D::ZeroVector)
				[
					Content
				];
		}
	}
*/
	UGameViewportClient::AddViewportWidgetContent(ViewportContent, ZOrder);
}

int UAzureGameViewportClient::AddViewportWidgetContentScene3D(TSharedRef<class SWidget> ViewportContent, const int32 ZOrder)
{
	if (AAzureEntryPoint::Instance != nullptr)
		AAzureEntryPoint::Instance->AddScene3DWidget(ViewportContent, ZOrder);
	return 0;
}

void UAzureGameViewportClient::RemoveViewportWidgetContentScene3D(TSharedRef<class SWidget> ViewportContent)
{
	if (AAzureEntryPoint::Instance != nullptr)
		AAzureEntryPoint::Instance->RemoveScene3DWidget(ViewportContent);
}

void UAzureGameViewportClient::Tick(float t)
{
	UGameViewportClient::Tick(t);

	gGamePlayerManager.TickDebug(t);
}

void UAzureGameViewportClient::StartAlwaysCaptureMouse()
{
	m_bAlwaysCaptureMouse = true;
}

void UAzureGameViewportClient::StopAlwaysCaptureMouse()
{
	m_bAlwaysCaptureMouse = false;
}

bool UAzureGameViewportClient::IsAlwaysCaptureMouse()
{
	return m_bAlwaysCaptureMouse;
}

void UAzureGameViewportClient::Viewport_CaptureMouse(bool bCapture)
{
	Viewport->CaptureMouse(bCapture);
}

bool UAzureGameViewportClient::Viewport_HasMouseCapture()
{
	return Viewport->HasMouseCapture();
}

void UAzureGameViewportClient::Viewport_LockMouseToViewport(bool bLock)
{
	Viewport->LockMouseToViewport(bLock);
}

void UAzureGameViewportClient::Viewport_SetUserFocus(bool bFocus)
{
	Viewport->SetUserFocus(bFocus);
}

bool UAzureGameViewportClient::Viewport_HasFocus()
{
	return Viewport->HasFocus();
}

void UAzureGameViewportClient::Viewport_ShowCursor(bool bShow)
{
	Viewport->ShowCursor(bShow);
}

bool UAzureGameViewportClient::Viewport_IsCursorVisible()
{
	return Viewport->IsCursorVisible();
}

