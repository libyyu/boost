﻿#include "AzureResourceInGameUpdateDownload.h"
#include "Utilities/LuaCallback.h"

extern wLua::Lua* AAzureEntryPoint_GetWLua();

void AzureResourceInGameUpdateDownload::DownloadRes(TCHAR const* resName, TCHAR const* tag, AInGameUpdateDownloadCallbackType && onFinish)
{
	wLua::Lua *wLua = AAzureEntryPoint_GetWLua();
	if (wLua)
	{
		lua_State_Wrapper L = wLua->GetL();
		lua_getglobal(L, "InGameUpdateDownloadRes");	//func
		if (lua_isfunction(L, -1))
		{
			lua_pushstring(L, TCHAR_TO_UTF8(resName));
			lua_pushstring(L, TCHAR_TO_UTF8(tag));
			LuaCallback::PushCallback(L, [onFinish](lua_State* L)	//func, resName, tag, onFinish
			{
				AInGameUpdateDownloadResult result = (AInGameUpdateDownloadResult)luaL_checkint(L, 1);
				onFinish(result);
				return 0;
			});
			wLua->Call(3);	//(none)
			return;
		}
		else
		{
			lua_pop(L, 1);	//(none)
		}
	}
	
	onFinish(AInGameUpdateDownloadResult::Failed);
}

void AzureResourceInGameUpdateDownload::DownloadRes(TCHAR const* resName, TCHAR const* tag, AInGameUpdateDownloadCallbackType const& onFinish)
{
	AInGameUpdateDownloadCallbackType tempOnFinish = onFinish;
	DownloadRes(resName, tag, std::move(tempOnFinish));
}

