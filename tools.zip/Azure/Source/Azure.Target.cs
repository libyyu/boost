// Fill out your copyright notice in the Description page of Project Settings.

using UnrealBuildTool;
using System.Collections.Generic;

public class AzureTarget : TargetRules
{
	public AzureTarget(TargetInfo Target) : base(Target)
	{
		Type = TargetType.Game;

		ExtraModuleNames.AddRange( new string[] { "Azure" } );

        //bCompileRecast = false;
        bCompileAPEX = false;
        bCompileSpeedTree = false;
        bForceEnableExceptions = true;

        if (Target.Configuration == UnrealTargetConfiguration.Test)
        {
            GlobalDefinitions.Add("ENABLE_STATNAMEDEVENTS=1");
            GlobalDefinitions.Add("ENABLE_STATNAMEDEVENTS_UOBJECT=1");
            if (Target.Platform==UnrealTargetPlatform.Android || Target.Platform==UnrealTargetPlatform.IOS)
            {
                GlobalDefinitions.Add("FRAMEPRO_ENABLED=1");
            }
        }

        //if (Target.Configuration == UnrealTargetConfiguration.Development)
        //    bUseMallocProfiler = true;

        //if (Target.Platform == UnrealTargetPlatform.Win32 || Target.Platform == UnrealTargetPlatform.Win64)
        //{
        //    if (Target.Configuration == UnrealTargetConfiguration.Debug)
        //    {
        //        bUseIncrementalLinking = true;
        //    }
        //}
        //bAdaptiveUnityDisablesPCH = false;

        if (Target.Configuration == UnrealTargetConfiguration.Development || Target.Configuration == UnrealTargetConfiguration.DebugGame|| Target.Configuration == UnrealTargetConfiguration.Debug)
	    {
	        GlobalDefinitions.Add("UE_GC_TRACK_OBJ_AVAILABLE=1");
	    }
        
        //0:luajit, 1:lua51, 2:lua53, ...
        ProjectDefinitions.Add("LUA_TYPE=0");
    }
}
