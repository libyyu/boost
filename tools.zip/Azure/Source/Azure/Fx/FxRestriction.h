// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Particles/ParticleSystemComponent.h"
#include "FxRestriction.generated.h"

/** A level of quality for azure controlled UParticleSystem. */
UENUM()
enum class EAzureFxQuality : uint8
{
	/** Low Quality. */
	Low,
	/** Medium Quality. */
	Medium,
	/** High Quality. */
	High,
	/** Perfect Quality. */
	Perfect,

	Num,
};

/** An overall efficiency evaluation (with regards to memory/cpu  of azure controlled UParticleSystem. */
enum class EAzureFxCost : uint8
{
	/** Low cost. */
	Low,
	/** Medium cost. */
	Medium,
	/** High cost. */
	High,
	/** High cost. */
	Critical,

	Num,
};

namespace FXPRIO
{
	enum Type
	{
		HIGHEST = 0,
		HIGH = 1,
		MIDDLE = 2,
		LOW = 3,
		LOWEST = 4,
	};
};

/** Used to restrict UParticleSystem count and quality */
struct AzureFxRestriction
{
	int Priority;
	EAzureFxCost FxCost;
	EAzureFxQuality FxQuality;
	EAzureFxQuality MaxFxQuality;

	bool bNeedHighLod = false;		//	�Ƿ񲻽�Quality
	bool bCanReplay = false;		//	�Ƿ���ظ� Play: Ϊ false ʱÿ����Ҫ���� RequestFx �� Play����Ϊ������ɺ�ʱ��������
									//	!!ע�⣬��ֵΪ true ʱ��Stop ����������Դ��Ҫ����ֹͣ����Ҫ�� Set_bCanReplay(false)
	bool bCountLimited = true;		//	�����Ƿ������ƣ����ܸ������Ƶ���Ч���Ȳ��ᱻ������Ч������Ҳ���ἷ��������Ч

	AzureFxRestriction()
		: Priority(FXPRIO::HIGHEST)
		, FxCost(EAzureFxCost::Num)
		, FxQuality(EAzureFxQuality::Num)
		, MaxFxQuality(EAzureFxQuality::Num)
	{
	}

	bool IsFxQualityValid()const
	{
		return FxQuality != EAzureFxQuality::Num;
	}
	void ClearFxQuality()
	{
		FxQuality = EAzureFxQuality::Num;
	}

	bool IsFxCostValid()const
	{
		return FxCost != EAzureFxCost::Num;
	}
	void ClearFxCost()
	{
		FxCost = EAzureFxCost::Num;
	}

	bool IsMaxFxQualityValid()const
	{
		return MaxFxQuality != EAzureFxQuality::Num;
	}
	void ClearMaxFxQuality()
	{
		MaxFxQuality = EAzureFxQuality::Num;
	}
};

struct AzureFxProxy
{

	AzureFxProxy(UParticleSystemComponent* InComponent, int32 InPriority, int32 InLodLevel = 0)
		: Priority(InPriority)
		, LodLevel(InLodLevel)
	{
		PSComponent = InComponent;
		if (InComponent && InComponent->Template)
		{
			LodCosts = InComponent->Template->AzureLodCosts;
		}
	}

	TWeakObjectPtr<UParticleSystemComponent> PSComponent;

	int32 Priority;

	int32 LodLevel;

	TArray<uint32> LodCosts;
};