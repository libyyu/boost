// Fill out your copyright notice in the Description page of Project Settings.

#include "FxCacheMan.h"
#include "FxCache.h"
#include "FxOne.h"
#include "Azure.h"
#include "AzureEntryPoint.h"
#include "wLua/LuaInterface.h"

#include "Animation/AnimNotifies/AnimNotify_PlayParticleEffect.h"
#include "Animation/AnimNotifies/AnimNotifyState_Trail.h"
#include "Animation/AnimNotifies/AnimNotifyState_TimedParticleEffect.h"

#include "Animation/AnimSequenceBase.h"
#include "Engine/BlueprintGeneratedClass.h"

#if ENABLE_FX_TRACK

static TAutoConsoleVariable<FString> TrackFxCVar(
	TEXT("TrackFx"),
	TEXT(""),
	TEXT("Print related log for given single Azure known fx pattern. Used to track bug.\n"),
	ECVF_Default);

bool IsFxTracked(const FString& InName)
{
	FString TrackedName = TrackFxCVar->GetString();
	if (TrackedName.IsEmpty())
	{
		return false;
	}
	else
	{
		return InName.Contains(TrackedName);
	}
}

static float GetFrameTime()
{
	return AAzureEntryPoint::Instance ? AAzureEntryPoint::Instance->GetRealtimeSinceStartup() : 0;
}

static uint64 GetFrameCount()
{
	return AAzureEntryPoint::Instance ? AAzureEntryPoint::Instance->GetCurFrameCount() : 0;
}

static void LogTrackedFxWhenRequested(const FString& InName)
{
	UE_LOG(LogAzure, Log, TEXT("%f[%I64u]: (%s) requested."), GetFrameTime(), GetFrameCount(), *InName);
}

void LogTrackedFxWhenReallyPlayed(const FString& InName)
{
	UE_LOG(LogAzure, Log, TEXT("%f[%I64u]: (%s) in play."), GetFrameTime(), GetFrameCount(), *InName);
}

static void LogTrackedFxWhenIsToPlay(const FString& InName)
{
	UE_LOG(LogAzure, Log, TEXT("%f[%I64u]: (%s) is to play."), GetFrameTime(), GetFrameCount(), *InName);
}

void LogTrackedFxWhenStopped(const FString& InName)
{
	UE_LOG(LogAzure, Log, TEXT("%f[%I64u]: (%s) stopped."), GetFrameTime(), GetFrameCount(), *InName);
}

static void LogTrackedFxWhenMeetCountLimit(const FString& InName)
{
	UE_LOG(LogAzure, Log, TEXT("%f[%I64u]: request (%s) failed cause count limit reached."), GetFrameTime(), GetFrameCount(), *InName);
}

static void LogTrackedFxWhenSkippedBySimpleModel(const FString& InName)
{
	UE_LOG(LogAzure, Log, TEXT("%f[%I64u]: (%s) skipped cause from simple model."), GetFrameTime(), GetFrameCount(), *InName);
}

static void LogTrackedFxWhenReplaced(const AFxOne& fxone, int InPriority)
{
	UE_LOG(LogAzure, Log, TEXT("%f[%I64u]: (%s) replaced cause priority %d less than %d."), GetFrameTime(), GetFrameCount(), *fxone.mName, fxone.FxRestriction.Priority, InPriority);
}

#endif

namespace
{
	bool FindBoolPropertyWithName(AActor* InActor, const FName& InPropertyName, bool* bInPropertyValue)
	{
		bool Result = false;
		if (InActor)
		{
			//	Get Property from BP
			for (TFieldIterator<UProperty> PropertyIt(InActor->GetClass(), EFieldIteratorFlags::ExcludeSuper); PropertyIt; ++PropertyIt)
			{
				UProperty* pProperty = *PropertyIt;
				if (pProperty->GetFName() == InPropertyName)
				{
					uint8 PropertyValue = uint8();
					pProperty->CopyCompleteValue(&PropertyValue, pProperty->ContainerPtrToValuePtr<void>(InActor));
					*bInPropertyValue = !!PropertyValue;
					Result = true;
					break;
				}
			}
		}
		return Result;
	}

	bool IsVisualHighPrioComponent(const USkeletalMeshComponent* MeshComp)
	{
		bool Result = false;
		static FName bHighPrioName = "bVisualHighPrio";
		FindBoolPropertyWithName(MeshComp->GetOwner(), bHighPrioName, &Result);
		return Result;
	}

	int DecideAnimNotifyFxPriority(bool bNeedHighLod, const USkeletalMeshComponent* MeshComp)
	{
		bool bGotProp = false;
		AActor* InActor = MeshComp->GetOwner();
		int priority = FXPRIO::LOWEST;
		if (InActor)
		{
			static FName propName = "FxPriority";
			for (TFieldIterator<UProperty> PropertyIt(InActor->GetClass(), EFieldIteratorFlags::ExcludeSuper); PropertyIt; ++PropertyIt)
			{
				UProperty* pProperty = *PropertyIt;
				if (pProperty->GetFName() == propName)
				{
					bGotProp = true;
					pProperty->CopyCompleteValue(&priority, pProperty->ContainerPtrToValuePtr<void>(InActor));
					break;
				}
			}
		}

		if (!bGotProp)
		{
			priority = bNeedHighLod ? (int)FXPRIO::HIGH : (int)FXPRIO::MIDDLE;
		}
		priority = FMath::Clamp(priority, (int)FXPRIO::HIGH, (int)FXPRIO::LOWEST);
		return priority;
	}

	bool IsSimpleModelComponent(const USkeletalMeshComponent* MeshComp)
	{
		bool Result = false;
		static FName bSimpleModelName = "bSimpleModel";
		FindBoolPropertyWithName(MeshComp->GetOwner(), bSimpleModelName, &Result);
		return Result;
	}
}

int AFxCacheMan::mMaxFxones = 20;
int AFxCacheMan::mMaxUnusedFxs = 20;
EAzureFxQuality AFxCacheMan::FxQuality = EAzureFxQuality::Perfect;
int AFxCacheMan::MaxFxCountWithQualityAndCost[EAzureFxQuality_Num][EAzureFxCost_Num] =
{
	//	EAzureFxCost::Low, EAzureFxCost::Medium, EAzureFxCost::High, EAzureFxCost::Critical
		{-1,						-1,						-1,				-1},		//	when EAzureFxQuality::Low
		{-1,						-1,						-1,				-1 },		//	when EAzureFxQuality::Medium
		{-1,						-1,						-1,				-1 },		//	when EAzureFxQuality::High
		{-1,						-1,						-1,				-1 },		//	when EAzureFxQuality::Perfect
};
int AFxCacheMan::CurFxCountWithQualityAndCost[EAzureFxQuality_Num][EAzureFxCost_Num] = {};
FAzureLuaFunction AFxCacheMan::mOnLoadFinishFunc;

int32 AFxCacheMan::CurrentQuality = 0;
int32 AFxCacheMan::TotalCost = 0;
AzureQualityLodCostMap AFxCacheMan::QualityLodCostMap;
TArray<AzureFxProxy> AFxCacheMan::ActiveAzureFxProxyList;


// Sets default values
AFxCacheMan::AFxCacheMan() :
	CachePolicy(FxCachePolicy::COUNT_LIMIT)
{
 	// Set this actor to call Tick() every frame.  You can turn this off to improve performance if you don't need it.
	PrimaryActorTick.bCanEverTick = true;
	RootComponent = CreateDefaultSubobject<USceneComponent>(TEXT("RootComponent"));
}

// Called when the game starts or when spawned
void AFxCacheMan::BeginPlay()
{
	Super::BeginPlay();
	UAnimNotify_PlayParticleEffect::GetProcessNotifyDelegate().BindUObject(this, &AFxCacheMan::OnAnimNotify_PlayParticleEffect);
	UAnimNotifyState_Trail::GetNotifyBeginDelegate().BindUObject(this, &AFxCacheMan::OnAnimNotifyState_Trail_NotifyBegin);
	UAnimNotifyState_Trail::GetNotifyEndDelegate().BindUObject(this, &AFxCacheMan::OnAnimNotifyState_Trail_NotifyEnd);
	UAnimNotifyState_TimedParticleEffect::GetNotifyBeginDelegate().BindUObject(this, &AFxCacheMan::OnAnimNotifyState_TimedParticleEffect_NotifyBegin);
	UAnimNotifyState_TimedParticleEffect::GetNotifyEndDelegate().BindUObject(this, &AFxCacheMan::OnAnimNotifyState_TimedParticleEffect_NotifyEnd);
}

void AFxCacheMan::EndPlay(const EEndPlayReason::Type EndPlayReason)
{
	UAnimNotify_PlayParticleEffect::GetProcessNotifyDelegate().Unbind();
	UAnimNotifyState_Trail::GetNotifyBeginDelegate().Unbind();
	UAnimNotifyState_Trail::GetNotifyEndDelegate().Unbind();
	UAnimNotifyState_TimedParticleEffect::GetNotifyBeginDelegate().Unbind();
	UAnimNotifyState_TimedParticleEffect::GetNotifyEndDelegate().Unbind();

	//	static member should be cleared(especially AFxCacheMan::CurFxCountWithQualityAndCost), or else next BeginPlay in UE4Editor will be wrong
	auto TempActiveFxOnes = ActiveFxOnes;	//	ActiveFxOnes might change during FxOne->Stop()
	for (AFxOne* FxOne : TempActiveFxOnes)
	{
		FxOne->Set_CanReplay(false);
		FxOne->Stop();
	}

	//	safely reset static members now, cause count increased by UAnimNotify_PlayParticleEffect\UAnimNotifyState_Trail\UAnimNotifyState_TimedParticleEffect would not reset automatically
	memset(CurFxCountWithQualityAndCost, 0, sizeof(CurFxCountWithQualityAndCost));

	//	call parent
	Super::EndPlay(EndPlayReason);
}

// Called every frame
void AFxCacheMan::Tick( float DeltaTime )
{
	Super::Tick( DeltaTime );

	if ( ++mFrameCount % 60 == 0)
	{
		mFrameCount = 0;

		for (auto It = FxCaches.CreateIterator(); It; ++It)
		{
			AFxCache* fxcache = It.Value();
			check(fxcache);
			if (fxcache->mUsedCount == 0 && (FPlatformTime::Seconds() - fxcache->mLastReleaseTime) >= 10.0)
			{
				fxcache->SetDestroy();
				fxcache->Destroy();
				It.RemoveCurrent();
				break;
			}
		}

		while (FreeFxOnes.Num() > mMaxUnusedFxs)
		{
			AFxOne* FxOne = FreeFxOnes.Last();
			FxOne->Destroy();
			FreeFxOnes.RemoveAt(FreeFxOnes.Num() - 1);
		}
	}

}

void AFxCacheMan::RegLoadFinishFunc(FAzureLuaFunction func)
{
	mOnLoadFinishFunc = func;
}

void AFxCacheMan::OnLoadFinishToLua(const FString& name, bool succ)
{
	if (mOnLoadFinishFunc.hasRef() && AAzureEntryPoint::Instance)
	{
		wLua::Lua* wlua = AAzureEntryPoint::Instance->GetWLua();
		if (wlua)
		{
			lua_State_Wrapper luastate = wlua->GetL();
			if (luastate)
			{
				lua_rawgeti(luastate, LUA_REGISTRYINDEX, mOnLoadFinishFunc.ref);
				mOnLoadFinishFunc.unref(luastate);
				lua_pushstring(luastate, TCHAR_TO_ANSI(*name));
				lua_pushboolean(luastate, succ);
				wlua->Call(2);
			}
		}
	}
}

AFxOne* AFxCacheMan::RequestFx(const FString& InName, int32 InPriority/* = 0*/, const UParticleSystem* InFxTemplate/* = nullptr*/, bool bCanReplay/* = false*/, bool bCountLimited/* = true*/)
{
	if (InName.IsEmpty())
	{
		return nullptr;
	}

#if ENABLE_FX_TRACK
	bool bFxTracked = IsFxTracked(InName);
#endif

	if (CachePolicy == FxCachePolicy::COUNT_LIMIT)
	{
		if (bCountLimited)
		{
			if (IsExceedingCountLimit())
			{
				if (!IsCanReplaceAnyFxWithPriority(InPriority) || !StopOneFxWithPrioritySameOrLowerThan(InPriority))
				{
#if ENABLE_FX_TRACK
					if (bFxTracked)
					{
						LogTrackedFxWhenMeetCountLimit(InName);
					}
#endif
					OnLoadFinishToLua(InName, false);
					return nullptr;
				}
			}
		}
	}

	AFxCache* fxcache = nullptr;
	AFxCache** ppfxcache = FxCaches.Find(InName);
	if (!ppfxcache)
	{
		FActorSpawnParameters SpawnParams;
		SpawnParams.Owner = nullptr;
		SpawnParams.Instigator = nullptr;
		SpawnParams.Name = FName(*InName);
		fxcache = GetWorld()->SpawnActor<AFxCache>(AFxCache::StaticClass(), FVector::ZeroVector, FRotator::ZeroRotator, SpawnParams);
		if (!fxcache)
		{
			OnLoadFinishToLua(InName, false);
			return nullptr;
		}
		fxcache->FxCacheMan = this;
		FxCaches.Add(InName, fxcache);
		fxcache->InitWithPrefab(InName, InFxTemplate);
		fxcache->SetActorHiddenInGame(true);
	}
	else
	{
		fxcache = *ppfxcache;
	}
	

	AFxOne* FxOne = GetFxOneFromCache();
	if (!FxOne)
	{
		OnLoadFinishToLua(InName, false);
		return nullptr;
	}
 	FxOne->FxRestriction.Priority = InPriority;
 	FxOne->FxRestriction.bCountLimited = bCountLimited;
	FxOne->SetPriority(InPriority);
	FxOne->Set_CanReplay(bCanReplay);

	if (fxcache->Touch(*FxOne) == false)
	{
		GiveBack(*FxOne);
		OnLoadFinishToLua(InName, false);
		return nullptr;
	}
	if (fxcache->FxTemplate)
	{
		OnLoadFinishToLua(InName, true);
	}
#if ENABLE_FX_TRACK
	if (bFxTracked)
	{
		LogTrackedFxWhenRequested(InName);
	}
#endif
	FxOne->SetActorHiddenInGame(false);
	FxOne->CustomTimeDilation = 1;
	return FxOne;
}

bool AFxCacheMan::IsExceedingCountLimit()const
{
	return GetLimitedFxCount() >= mMaxFxones;
}

int AFxCacheMan::GetLimitedFxCount()const
{
	int Result = 0;

	//	AFxOne
	for (const AFxOne* FxOne : ActiveFxOnes)
	{
		if (FxOne->Get_CountLimited())
		{
			++Result;
		}
	}

	//	Trail Fx from UAnimNotifyState_Trail
	for (const TPair<AnimNotifyState_Trail_Key, AzureFxRestriction>& TrailPair : Active_AnimNotifyState_Trail_FxRestriction)
	{
		if (TrailPair.Value.bCountLimited)
		{
			++Result;
		}
	}

	//	Timed Fx from UAnimNotifyState_TimedParticleEffect
	for (const TPair<const AnimNotifyState_TimedParticleEffect_Key, AzureFxRestriction> & TimedPair : Active_AnimNotifyState_TimedParticleEffect_FxRestriction)
	{
		if (TimedPair.Value.bCountLimited)
		{
			++Result;
		}
	}

	return Result;
}

bool AFxCacheMan::IsCanReplaceAnyFxWithPriority(int InPriority)const
{
	return InPriority <= GetLimitedFxLowestPriority();
}

int AFxCacheMan::GetLimitedFxLowestPriority()const
{
	int Result = -1;

	//	AFxOne
	for (int i = 0; i < ActiveFxOnes.Num(); ++i)
	{
		AFxOne& fxone = *ActiveFxOnes[i];
		if (fxone.Get_CountLimited())
		{
			if (fxone.FxRestriction.Priority > Result)
			{
				Result = fxone.FxRestriction.Priority;
			}
		}
	}

	//	ignore UAnimNotifyState_Trail currently cause it's not suitable to stop it
	//	ignore UAnimNotifyState_TimedParticleEffect currently cause it's not suitable to stop it

	return Result;
}

bool AFxCacheMan::StopOneFxWithPrioritySameOrLowerThan(int InPriority)
{
	bool Result = false;

	//	AFxOne
	for (int i = 0; i < ActiveFxOnes.Num(); ++i)
	{
		AFxOne& fxone = *ActiveFxOnes[i];
		if (fxone.Get_CountLimited() && fxone.FxRestriction.Priority >= InPriority)
		{
#if ENABLE_FX_TRACK
			if (IsFxTracked(fxone.mName))
			{
				LogTrackedFxWhenReplaced(fxone, InPriority);
			}
#endif
			fxone.Set_CanReplay(false);
			fxone.Stop();
			Result = true;
			break;
		}
	}

	//	ignore UAnimNotifyState_Trail currently cause it's not suitable to stop it
	//	ignore UAnimNotifyState_TimedParticleEffect currently cause it's not suitable to stop it

	return Result;
}

AFxOne* AFxCacheMan::GetFxOneFromCache()
{
	AFxOne* fxone = nullptr;
	if (FreeFxOnes.Num() > 0)
	{
		fxone = FreeFxOnes.Last();
		FreeFxOnes.RemoveAt(FreeFxOnes.Num() - 1);

		fxone->SetActorLocation(FVector::ZeroVector);
		fxone->SetActorScale3D(FVector::OneVector);
		fxone->SetActorRotation(FRotator::ZeroRotator);
	}
	else
	{
		static int id = 0;
		FString name = FString::Printf(TEXT("fxone%d"), ++id);
		FActorSpawnParameters SpawnParams;
		SpawnParams.Owner = nullptr;
		SpawnParams.Instigator = nullptr;
		SpawnParams.Name = FName(*name);
		fxone = GetWorld()->SpawnActor<AFxOne>(AFxOne::StaticClass(), FVector::ZeroVector, FRotator::ZeroRotator, SpawnParams);
		if (!fxone)
		{
			return nullptr;
		}
		fxone->SetActorHiddenInGame(true);
		fxone->SetActorTickEnabled(false);
	}
	fxone->FxCacheMan = this;
	fxone->AttachToActor(this, FAttachmentTransformRules(EAttachmentRule::KeepRelative, false));

	ActiveFxOnes.Add(fxone);

	return fxone;
}

void AFxCacheMan::Set_RenderHide(bool bHide)
{
	if (mRenderHide != bHide)
	{
		mRenderHide = bHide;
		for (auto& fxone : ActiveFxOnes)
		{
			fxone->OnAllFxRenderHideFlagChanged();
		}
	}
}

void AFxCacheMan::GiveBack(AFxOne& fxone)
{
	if (ActiveFxOnes.Find(&fxone) == INDEX_NONE)
	{
		UE_LOG(LogAzure, Error, TEXT("Given back Fx %s not found."), *GetNameSafe(&fxone));
		return;
	}
	fxone.SetActorHiddenInGame(true);
	fxone.SetActorTickEnabled(false);
	fxone.Set_CanReplay(false);
	fxone.OnGiveBack();
	ActiveFxOnes.Remove(&fxone);
	FreeFxOnes.Add(&fxone);
	fxone.FxCacheMan = nullptr;
	if (!fxone.IsAttachedTo(this))
	{
		fxone.AttachToActor(this, FAttachmentTransformRules(EAttachmentRule::KeepRelative, false));
	}

	// �Ͽ�lua����Ըö�������ã���ñ��������
	if (AAzureEntryPoint::Instance)
	{
		wLua::Lua* wlua = AAzureEntryPoint::Instance->GetWLua();
		if (wlua)
		{
			lua_State_Wrapper luastate = wlua->GetL();
			if (luastate)
			{
				wLua::FLuaUtils::RemoveObjectReference(&fxone, nullptr, luastate, true);
			}
		}
	}
}

void AFxCacheMan::StopAllActiveFx()
{
	//if (CachePolicy == FxCachePolicy::COUNT_LIMIT)
	{
		auto TempActiveFxOnes = ActiveFxOnes;
		for (AFxOne* FxOne : TempActiveFxOnes)
		{
			FxOne->Set_CanReplay(false);
			FxOne->Stop();
		}
	}
}

void AFxCacheMan::OnFxDestroy(AFxOne& fxone)
{
	ActiveFxOnes.Remove(&fxone);
	FreeFxOnes.Remove(&fxone);
	fxone.FxCacheMan = nullptr;

	if (CachePolicy == FxCachePolicy::MAX_COST)
	{
		AFxCacheMan::UnRegisterAzureFxProxy(fxone.GetParticleSystemComp());
	}
	
}


TArray<AzureFxRestriction> AFxCacheMan::CollectActiveFxRestriction()const
{
	TArray<AzureFxRestriction> Result;

	Result.Reserve(Get_currentFxCount());

	//	AFxOne
	for (const AFxOne* FxOne : ActiveFxOnes)
	{
		Result.Push(FxOne->FxRestriction);
	}

	//	Trail Fx from UAnimNotifyState_Trail
	for (const TPair<AnimNotifyState_Trail_Key, AzureFxRestriction>& TrailPair : Active_AnimNotifyState_Trail_FxRestriction)
	{
		Result.Push(TrailPair.Value);
	}

	//	Timed Fx from UAnimNotifyState_TimedParticleEffect
	for (const TPair<const AnimNotifyState_TimedParticleEffect_Key, AzureFxRestriction> & TimedPair : Active_AnimNotifyState_TimedParticleEffect_FxRestriction)
	{
		Result.Push(TimedPair.Value);
	}

	return Result;
}

int AFxCacheMan::Get_currentFxCount()const
{
	return ActiveFxOnes.Num() + Active_AnimNotifyState_Trail_FxRestriction.Num() + Active_AnimNotifyState_TimedParticleEffect_FxRestriction.Num();
}

static FString GetUObjectGameLoadPath(const UObject* InObject)
{
	//	convert Game/Effects/fx/common/buff/select/fx_select.fx_select to Effects/fx/common/buff/select/fx_select
	FString PathName = InObject->GetPathName();

	FString Prefix = TEXT("/Game/");
	if (!PathName.StartsWith(Prefix))
	{
		return TEXT("");
	}
	FString Postfix = FString::Printf(TEXT(".%s"), *InObject->GetName());
	if (!PathName.EndsWith(Postfix))
	{
		return TEXT("");
	}
	return PathName.Mid(Prefix.Len(), PathName.Len() - Prefix.Len() - Postfix.Len());
}

bool AFxCacheMan::OnAnimNotify_PlayParticleEffect(const UAnimNotify_PlayParticleEffect* PlayFxNotify, class USkeletalMeshComponent* MeshComp, class UAnimSequenceBase* Animation)
{
	FString FxLoadPath = GetUObjectGameLoadPath(PlayFxNotify->PSTemplate);
	if (FxLoadPath.IsEmpty())
	{
		UE_LOG(LogAzure, Error, TEXT("Particle Notify: Anim %s tried to spawn unexpected %s. Spawning suppressed."), *GetNameSafe(Animation), *GetNameSafe(PlayFxNotify->PSTemplate));
		return true;
	}
	if (IsSimpleModelComponent(MeshComp))
	{
		//	SimpleModel: DO NOT Play Fx!
#if ENABLE_FX_TRACK
		if (IsFxTracked(FxLoadPath))
		{
			LogTrackedFxWhenSkippedBySimpleModel(FxLoadPath);
		}
#endif
		return true;
	}

	bool bVisualHighPrio = IsVisualHighPrioComponent(MeshComp);
	bool bNeedHighLod = bVisualHighPrio ? true : false;	//	host need high lod
	int32 Priority = DecideAnimNotifyFxPriority(bNeedHighLod, MeshComp);

	if (CachePolicy == FxCachePolicy::MAX_COST)
	{
		Priority = PlayFxNotify->Priority;
	}

	float Duration = -1.0f;

	if (AFxOne* FxOne = RequestFx(FxLoadPath, Priority, PlayFxNotify->PSTemplate))
	{
		//	refer to UAnimNotify_PlayParticleEffect::Notify

		if (PlayFxNotify->Attached)
		{
			//	refer to UGameplayStatics::SpawnEmitterAttached
			FxOne->AttachToComponent(MeshComp, FAttachmentTransformRules(EAttachmentRule::KeepRelative, false), PlayFxNotify->SocketName);
			FxOne->SetActorRelativeLocation(PlayFxNotify->LocationOffset);
			FxOne->SetActorRelativeRotation(PlayFxNotify->RotationOffset);
			FxOne->SetActorRelativeScale3D(PlayFxNotify->Scale);
		}
		else
		{
			//	refer to UGameplayStatics::SpawnEmitterAtLocation
			const FTransform& MeshTransform = MeshComp->GetSocketTransform(PlayFxNotify->SocketName);
			FVector Location = MeshTransform.TransformPosition(PlayFxNotify->LocationOffset);
			FQuat Rotation = MeshTransform.GetRotation() * PlayFxNotify->RotationOffsetQuat;
			FxOne->SetActorLocation(Location);
			FxOne->SetActorRotation(Rotation.Rotator());
			FxOne->SetActorScale3D(PlayFxNotify->Scale);
		}

		FxOne->Play(Duration, bNeedHighLod);
	}
	return true;
}

bool AFxCacheMan::OnAnimNotifyState_Trail_NotifyBegin(const UAnimNotifyState_Trail* PlayTrailFxNotifyState, class USkeletalMeshComponent* MeshComp, class UAnimSequenceBase* Animation, const UParticleSystem* FxTemplate, bool* bShouldIgnore, int* LODLevel)
{
	//	Set default return
	*bShouldIgnore = false;	//	default to NOT spawn new particle
	*LODLevel = -1;			//	default to not change LODLevel if will apply this notify
	AnimNotifyState_Trail_Key NotifyID(PlayTrailFxNotifyState, MeshComp);
	if (CachePolicy == FxCachePolicy::COUNT_LIMIT)
	{	
		if (const AzureFxRestriction* ExistFxRestriction = Active_AnimNotifyState_Trail_FxRestriction.Find(NotifyID))
		{
			UE_LOG(LogAzure, Error, TEXT("AnimNotifyState_Trail NotifyBegin: Anim %s tried to spawn %s on same UAnimNotifyState_Trail more than once. Spawning suppressed."), *GetNameSafe(Animation), *GetNameSafe(FxTemplate));
		}
		else
		{
			if (IsSimpleModelComponent(MeshComp))
			{
				//	SimpleModel: DO NOT Play Fx!
#if ENABLE_FX_TRACK
				if (IsFxTracked(FxTemplate->GetPathName()))
				{
					LogTrackedFxWhenSkippedBySimpleModel(FxTemplate->GetPathName());
				}
#endif
				return true;
			}

			bool bVisualHighPrio = IsVisualHighPrioComponent(MeshComp);
			bool bNeedHighLod = bVisualHighPrio ? true : false;	//	host need high lod
			bool bCanReplay = false;
			bool bCountLimited = true;
			int  Priority = DecideAnimNotifyFxPriority(bNeedHighLod, MeshComp);

			//	Check for count limit and replace by priority

			if (IsExceedingCountLimit())
			{
				if (!IsCanReplaceAnyFxWithPriority(Priority) ||
					!StopOneFxWithPrioritySameOrLowerThan(Priority))
				{
#if ENABLE_FX_TRACK
					if (IsFxTracked(FxTemplate->GetPathName()))
					{
						LogTrackedFxWhenMeetCountLimit(FxTemplate->GetPathName());
					}
#endif
					return true;
				}
			}


			//	Add AzureFxRestriction and increase counter
			AzureFxRestriction& FxRestriction = Active_AnimNotifyState_Trail_FxRestriction.Add(NotifyID);
			FxRestriction.Priority = Priority;
			FxRestriction.bNeedHighLod = bNeedHighLod;
			FxRestriction.bCanReplay = bCanReplay;
			FxRestriction.bCountLimited = bCountLimited;
			FxRestriction.FxCost = GetFxCostFromTemplate(FxTemplate);
			FxRestriction.FxQuality = CalculateQuality(FxRestriction);

			AFxCacheMan::IncreaseCurFxCountWithQualityAndCost(static_cast<int>(FxRestriction.FxQuality), static_cast<int>(FxRestriction.FxCost));

			//	Fill return value
			*bShouldIgnore = false;
			*LODLevel = FxQualityToLODLevel(static_cast<int>(FxRestriction.FxQuality), const_cast<UParticleSystem*>(FxTemplate)->GetLODLevelCount());
		}
	}
	else if (CachePolicy == FxCachePolicy::MAX_COST)
	{
		if (Active_AnimNotifyState_Trail_FxOneMap.Contains(NotifyID))
		{
			UE_LOG(LogAzure, Error, TEXT("AnimNotifyState_Trail NotifyBegin: Anim %s tried to spawn %s on same UAnimNotifyState_Trail more than once. Spawning suppressed."), *GetNameSafe(Animation), *GetNameSafe(FxTemplate));
		}
		else
		{
			FString FxLoadPath = GetUObjectGameLoadPath(PlayTrailFxNotifyState->PSTemplate);
			int32 Priority = PlayTrailFxNotifyState->Priority;
			float Duration = -1.0f;
			if (AFxOne* FxOne = RequestFx(FxLoadPath, Priority, PlayTrailFxNotifyState->PSTemplate))
			{
				FxOne->AttachToComponent(MeshComp, FAttachmentTransformRules::KeepRelativeTransform);
				FxOne->SetTrailParam(MeshComp, PlayTrailFxNotifyState->FirstSocketName, PlayTrailFxNotifyState->SecondSocketName, PlayTrailFxNotifyState->WidthScaleMode, MeshComp->GetAnimInstance(), PlayTrailFxNotifyState->WidthScaleCurve);
				FxOne->Play(Duration, false);
				
				Active_AnimNotifyState_Trail_FxOneMap.Emplace(NotifyID, FxOne);

				*bShouldIgnore = true;
				*LODLevel = GetMaxLodofCurrentQuality();
			}
		}
	}
#if ENABLE_FX_TRACK
	if (IsFxTracked(FxTemplate->GetPathName()))
	{
		LogTrackedFxWhenIsToPlay(FxTemplate->GetPathName());
	}
#endif
	
	
	return true;
}

bool AFxCacheMan::OnAnimNotifyState_Trail_NotifyEnd(const UAnimNotifyState_Trail* PlayTrailFxNotifyState, class USkeletalMeshComponent* MeshComp, class UAnimSequenceBase* Animation)
{
	bool IsInterestedNotify = false;
	AnimNotifyState_Trail_Key NotifyID(PlayTrailFxNotifyState, MeshComp);
	if (CachePolicy == FxCachePolicy::COUNT_LIMIT)
	{		
		if (const AzureFxRestriction* FxRestriction = Active_AnimNotifyState_Trail_FxRestriction.Find(NotifyID))
		{
#if ENABLE_FX_TRACK
			if (IsFxTracked(PlayTrailFxNotifyState->PSTemplate->GetPathName()))
			{
				LogTrackedFxWhenStopped(PlayTrailFxNotifyState->PSTemplate->GetPathName());
			}
#endif
			AFxCacheMan::DecreaseCurFxCountWithQualityAndCost(static_cast<int>(FxRestriction->FxQuality), static_cast<int>(FxRestriction->FxCost));
			Active_AnimNotifyState_Trail_FxRestriction.Remove(NotifyID);
			IsInterestedNotify = true;
		}
	}
	else if (CachePolicy == FxCachePolicy::MAX_COST)
	{
		if (Active_AnimNotifyState_Trail_FxOneMap.Contains(NotifyID))
		{
#if ENABLE_FX_TRACK
			if (IsFxTracked(PlayTrailFxNotifyState->PSTemplate->GetPathName()))
			{
				LogTrackedFxWhenStopped(PlayTrailFxNotifyState->PSTemplate->GetPathName());
			}
#endif
			TWeakObjectPtr<AFxOne> FxOne = *Active_AnimNotifyState_Trail_FxOneMap.Find(NotifyID);
			if (FxOne.IsValid())
				FxOne->Stop();
			Active_AnimNotifyState_Trail_FxOneMap.Remove(NotifyID);
			IsInterestedNotify = true;
		}
	}
	return IsInterestedNotify;
}

bool AFxCacheMan::OnAnimNotifyState_TimedParticleEffect_NotifyBegin(const UAnimNotifyState_TimedParticleEffect* PlayTimedFxNotifyState, class USkeletalMeshComponent* MeshComp, class UAnimSequenceBase* Animation, bool* bShouldIgnore, int* LODLevel)
{
	*bShouldIgnore = false;
	*LODLevel = -1;
	AnimNotifyState_TimedParticleEffect_Key NotifyID(PlayTimedFxNotifyState, MeshComp);
	if (CachePolicy == FxCachePolicy::COUNT_LIMIT)
	{		
		if (const AzureFxRestriction* ExistFxRestriction = Active_AnimNotifyState_TimedParticleEffect_FxRestriction.Find(NotifyID))
		{
			UE_LOG(LogAzure, Error, TEXT("AnimNotifyState_TimedParticleEffect NotifyBegin: Anim %s tried to spawn Timed fx on same %s more than once. Spawning suppressed."), *GetNameSafe(Animation), *GetNameSafe(PlayTimedFxNotifyState->PSTemplate));
		}
		else
		{
			if (IsSimpleModelComponent(MeshComp))
			{
				//	SimpleModel: DO NOT Play Fx!
#if ENABLE_FX_TRACK
				if (IsFxTracked(PlayTimedFxNotifyState->PSTemplate->GetPathName()))
				{
					LogTrackedFxWhenSkippedBySimpleModel(PlayTimedFxNotifyState->PSTemplate->GetPathName());
				}
#endif
				return true;
			}

			bool bVisualHighPrio = IsVisualHighPrioComponent(MeshComp);
			bool bCanReplay = false;
			bool bCountLimited = true;
			bool bNeedHighLod = bVisualHighPrio ? true : false;	//	host need high lod
			int  Priority = DecideAnimNotifyFxPriority(bNeedHighLod, MeshComp);
			//	Check for count limit and replace by priority

			if (IsExceedingCountLimit())
			{
				if (!IsCanReplaceAnyFxWithPriority(Priority) ||
					!StopOneFxWithPrioritySameOrLowerThan(Priority))
				{
#if ENABLE_FX_TRACK
					if (IsFxTracked(PlayTimedFxNotifyState->PSTemplate->GetPathName()))
					{
						LogTrackedFxWhenMeetCountLimit(PlayTimedFxNotifyState->PSTemplate->GetPathName());
					}
#endif
					return true;
				}
			}


			//	Add AzureFxRestriction and increase counter
			AzureFxRestriction& FxRestriction = Active_AnimNotifyState_TimedParticleEffect_FxRestriction.Add(NotifyID);
			FxRestriction.Priority = Priority;
			FxRestriction.bCanReplay = bCanReplay;
			FxRestriction.bCountLimited = bCountLimited;
			FxRestriction.bNeedHighLod = bNeedHighLod;
			FxRestriction.FxCost = GetFxCostFromTemplate(PlayTimedFxNotifyState->PSTemplate);
			FxRestriction.FxQuality = CalculateQuality(FxRestriction);

			AFxCacheMan::IncreaseCurFxCountWithQualityAndCost(static_cast<int>(FxRestriction.FxQuality), static_cast<int>(FxRestriction.FxCost));

			//	Fill return value
			*bShouldIgnore = false;
			*LODLevel = FxQualityToLODLevel(static_cast<int>(FxRestriction.FxQuality), const_cast<UParticleSystem*>(PlayTimedFxNotifyState->PSTemplate)->GetLODLevelCount());
		}
	}
	else if (CachePolicy == FxCachePolicy::MAX_COST)
	{
		
		if (Active_AnimNotifyState_TimedParticleEffect_FxOneMap.Contains(NotifyID))
		{
			UE_LOG(LogAzure, Error, TEXT("AnimNotifyState_TimedParticleEffect NotifyBegin: Anim %s tried to spawn Timed fx on same %s more than once. Spawning suppressed."), *GetNameSafe(Animation), *GetNameSafe(PlayTimedFxNotifyState->PSTemplate));
		}
		else
		{
			FString FxLoadPath = GetUObjectGameLoadPath(PlayTimedFxNotifyState->PSTemplate);
			int32 Priority = PlayTimedFxNotifyState->Priority;
			float Duration = -1.0f;
			if (AFxOne* FxOne = RequestFx(FxLoadPath, Priority, PlayTimedFxNotifyState->PSTemplate))
			{
				if (PlayTimedFxNotifyState->Attached)
				{
					//	refer to UGameplayStatics::SpawnEmitterAttached
					FxOne->AttachToComponent(MeshComp, FAttachmentTransformRules(EAttachmentRule::KeepRelative, false), PlayTimedFxNotifyState->SocketName);
					FxOne->SetActorRelativeLocation(PlayTimedFxNotifyState->LocationOffset);
					FxOne->SetActorRelativeRotation(PlayTimedFxNotifyState->RotationOffset);
					FxOne->SetActorRelativeScale3D(FVector::OneVector);
				}
				else
				{
					//	refer to UGameplayStatics::SpawnEmitterAtLocation
					const FTransform& MeshTransform = MeshComp->GetSocketTransform(PlayTimedFxNotifyState->SocketName);
					FVector Location = MeshTransform.TransformPosition(PlayTimedFxNotifyState->LocationOffset);
					FQuat Rotation = MeshTransform.GetRotation() * PlayTimedFxNotifyState->RotationOffsetQuat;
					FxOne->SetActorLocation(Location);
					FxOne->SetActorRotation(Rotation.Rotator());
					FxOne->SetActorScale3D(FVector::OneVector);
				}

				FxOne->Play(Duration, false);
				Active_AnimNotifyState_TimedParticleEffect_FxOneMap.Emplace(NotifyID, FxOne);

				*bShouldIgnore = true;
				*LODLevel = GetMaxLodofCurrentQuality();
			}
		}
	}
#if ENABLE_FX_TRACK
	if (IsFxTracked(PlayTimedFxNotifyState->PSTemplate->GetPathName()))
	{
		LogTrackedFxWhenIsToPlay(PlayTimedFxNotifyState->PSTemplate->GetPathName());
	}
#endif
	

	return true;
}

bool AFxCacheMan::OnAnimNotifyState_TimedParticleEffect_NotifyEnd(const UAnimNotifyState_TimedParticleEffect* PlayTimedFxNotifyState, class USkeletalMeshComponent* MeshComp, class UAnimSequenceBase* Animation)
{
	bool IsInterestedNotify = false;
	AnimNotifyState_TimedParticleEffect_Key NotifyID(PlayTimedFxNotifyState, MeshComp);
	if (CachePolicy == FxCachePolicy::COUNT_LIMIT)
	{		
		if (const AzureFxRestriction* FxRestriction = Active_AnimNotifyState_TimedParticleEffect_FxRestriction.Find(NotifyID))
		{
#if ENABLE_FX_TRACK
			if (IsFxTracked(PlayTimedFxNotifyState->PSTemplate->GetPathName()))
			{
				LogTrackedFxWhenStopped(PlayTimedFxNotifyState->PSTemplate->GetPathName());
			}
#endif
			AFxCacheMan::DecreaseCurFxCountWithQualityAndCost(static_cast<int>(FxRestriction->FxQuality), static_cast<int>(FxRestriction->FxCost));
			Active_AnimNotifyState_TimedParticleEffect_FxRestriction.Remove(NotifyID);
			IsInterestedNotify = true;
		}
	}
	else if (CachePolicy == FxCachePolicy::MAX_COST)
	{
		if (Active_AnimNotifyState_TimedParticleEffect_FxOneMap.Contains(NotifyID))
		{		
#if ENABLE_FX_TRACK
			if (IsFxTracked(PlayTimedFxNotifyState->PSTemplate->GetPathName()))
			{
				LogTrackedFxWhenStopped(PlayTimedFxNotifyState->PSTemplate->GetPathName());
			}
#endif
			TWeakObjectPtr<AFxOne> FxOne = *Active_AnimNotifyState_TimedParticleEffect_FxOneMap.Find(NotifyID);
			if (FxOne.IsValid())
				FxOne->Stop();
			Active_AnimNotifyState_TimedParticleEffect_FxOneMap.Remove(NotifyID);
			IsInterestedNotify = true;
		}
	}
	return IsInterestedNotify;
}

EAzureFxCost AFxCacheMan::GetFxCostFromTemplate(const UParticleSystem* InFxTemplate)
{
	EAzureFxCost Result;
	if (InFxTemplate->AzureCostLevel >= static_cast<uint8>(EAzureFxCost::Num))
	{
		UE_LOG(LogAzure, Error, TEXT("fx %s Invalid AzureCostLevel = %d."), *InFxTemplate->GetName(), InFxTemplate->AzureCostLevel);
		Result = EAzureFxCost::Low;
	}
	else
	{
		Result = static_cast<EAzureFxCost>(InFxTemplate->AzureCostLevel);
	}
	return Result;
}

EAzureFxQuality AFxCacheMan::CalculateQuality(const AzureFxRestriction& InFxRestriction)
{
	EAzureFxQuality Result = EAzureFxQuality::Low;
	if (InFxRestriction.bNeedHighLod)
	{
		Result = static_cast<EAzureFxQuality>(Get_FxQuality());	//	Do not apply count limit when need high LOD
	}
	else
	{
		if (IsExceedingFxLimitWithQualityAndCost(Get_FxQuality(), static_cast<int>(InFxRestriction.FxCost)))
		{
			Result = EAzureFxQuality::Low;
		}
		else
		{
			Result = static_cast<EAzureFxQuality>(Get_FxQuality());
		}
	}
	if (Result > InFxRestriction.MaxFxQuality)
	{
		Result = InFxRestriction.MaxFxQuality;
	}
	return Result;
}

int AFxCacheMan::FxQualityToLODLevel(int InFxQuality, int InLODLevelCount)
{
	//	return -1 means do not want to change
	if (InFxQuality < 0 || InFxQuality >= static_cast<int>(EAzureFxQuality::Num))
	{
		return -1;
	}
	if (InLODLevelCount != static_cast<int>(EAzureFxQuality::Num) &&
		InLODLevelCount != static_cast<int>(EAzureFxQuality::Num) - 1)
	{
		return -1;
	}
	static int Quality2LODLevel_WhenMatch[EAzureFxQuality_Num] = { 3, 2, 1, 0 };
	static int Quality2LODLevel_Otherwise[EAzureFxQuality_Num] = { 2, 1, 0, 0 };
	const bool IsExactMatch = (InLODLevelCount == static_cast<int>(EAzureFxQuality::Num));
	return IsExactMatch ? Quality2LODLevel_WhenMatch[InFxQuality] : Quality2LODLevel_Otherwise[InFxQuality];
}

int AFxCacheMan::LimitLodRange(int InLod, int InLODLevelCount)
{
	//	return -1 means do not want to change
	if (InLODLevelCount != static_cast<int>(EAzureFxQuality::Num) &&
		InLODLevelCount != static_cast<int>(EAzureFxQuality::Num) - 1)
	{
		return -1;
	}
	//static int Quality2LODLevel_WhenMatch[EAzureFxQuality_Num] = { 3, 2, 1, 0 };
	//static int Quality2LODLevel_Otherwise[EAzureFxQuality_Num] = { 2, 1, 0, 0 };
	const bool IsExactMatch = (InLODLevelCount == static_cast<int>(EAzureFxQuality::Num));
	if (IsExactMatch) //fxû��ȫ����lod����Ҫ�����������鴦���£����FxQualityToLODLevel���߼�
		return InLod;

	if (InLod == 3)
		return 2;
	if (InLod == 2)
		return 1;
	if (InLod == 1)
		return 0;
	if (InLod == 0)
		return 0;
	return -1;
}

void AFxCacheMan::ChangeTotalCost(int32 Value)
{
	TotalCost += Value;
	TotalCost = FMath::Max(TotalCost, 0);
}

bool AFxCacheMan::IsExceedingCountLimitEx(int32& DiffValue)
{
	int32 MaxCost = GetMaxLodCostofCurrentQuality(); //��ǰQuality�µ�Cost����

	DiffValue = TotalCost - MaxCost;
	return TotalCost > MaxCost;
}

void AFxCacheMan::SortActiveAzureFxProxy()
{
	for (int32 index = ActiveAzureFxProxyList.Num() - 1; index >= 0; index--)
	{
		if (!ActiveAzureFxProxyList[index].PSComponent.IsValid())
		{			
			int32 Lod = ActiveAzureFxProxyList[index].LodLevel;
			TArray<uint32>& LodCosts = ActiveAzureFxProxyList[index].LodCosts;
			int32 Cost = LodCosts.IsValidIndex(Lod) ? LodCosts[Lod] : 0;
			ChangeTotalCost(-Cost);
			ActiveAzureFxProxyList.RemoveAt(index);
		}
	}

	ActiveAzureFxProxyList.StableSort([](const AzureFxProxy& L, const AzureFxProxy& R)
	{
		if (L.Priority != R.Priority)
			return L.Priority > R.Priority;
		else if (L.LodLevel != R.LodLevel)
			return L.LodLevel > R.Priority;
		else if (L.PSComponent.IsValid() && L.PSComponent->Template)
			return L.PSComponent->Template->IsLooping();
		else
			return true;
	});

}

bool AFxCacheMan::AdjustActiveFxProxy(int32 Tolerance)
{
	int32 ActiveFxProxyNum = ActiveAzureFxProxyList.Num();
	if (ActiveFxProxyNum == 0)
	{
		return true;
	}
	int32 MaxCost = GetMaxLodCostofCurrentQuality(); //��ǰQuality�µ�Cost����
	int32 ReleaseTotalCost = 0; //�ͷŵ�Cost��С
	for (int32 Index = ActiveFxProxyNum - 1; Index >= 0; Index--) //���ȵ������ȼ��ϵ͵�Fx
	{
		AzureFxProxy& FxProxy = ActiveAzureFxProxyList[Index];
		UParticleSystemComponent* PSComponent = FxProxy.PSComponent.Get();		
		if (!PSComponent )
		{
			continue;
		}
		UParticleSystem* PSTemplate = PSComponent->Template;

		if (!PSTemplate)
		{
			continue;
		}

		//����ת��ΪFxOne
		AFxOne* FxOne = nullptr;
		AActor* Owner = PSComponent->GetOwner();
		if (Owner && !Owner->IsPendingKill())
		{
			FxOne = Cast<AFxOne>(Owner);
		}

		int32 CurrentLod = FxProxy.LodLevel;
		int32 LodCount = PSTemplate->GetLODLevelCount();
		TArray<uint32>& LodCosts = FxProxy.LodCosts;
		//�ӵ�ǰFx��Lod�ȼ���ʼ�𽥽���
		for (int32 Lod = CurrentLod; Lod < LodCount; Lod++) 
		{
			int32 HighLodCost = LodCosts.IsValidIndex(Lod) ? LodCosts[Lod] : 0;
			int32 LowLodCost = LodCosts.IsValidIndex(Lod + 1) ? LodCosts[Lod + 1] : 0;
			ReleaseTotalCost += (HighLodCost - LowLodCost); //��1���ͷŵ�Cost
			//ͨ������Lod�ȼ�����������
			if (ReleaseTotalCost >= Tolerance && Lod != LodCount - 1)
			{
				ChangeTotalCost(-ReleaseTotalCost);
				FxProxy.LodLevel = Lod + 1;
				if (FxOne) //�����FxOne
				{
					FxOne->SetLodLevel(Lod + 1);
				}
				else //���������ط���������ͼ�
				{
					PSComponent->SetLODLevel(Lod + 1);
				}
				return true;
			}
		}
		//���͵���Lod��Ȼ�����㣬ֹͣ��Fx
		if (FxOne) //�����FxOne
		{					
			FxOne->Set_CanReplay(false);
			FxOne->Stop();
		}
		else //���������ط���������ͼ�
		{
			PSComponent->DeactivateSystem();
			UnRegisterAzureFxProxy(PSComponent);
		}
		//ֹͣ��С��Cost�����򷵻�
		if (TotalCost <= MaxCost) 
		{
			return true;
		}
			
	}

	return ReleaseTotalCost >= Tolerance;
}


void AFxCacheMan::RegisterAzureFxProxy(UParticleSystemComponent* PSComponent, int32 Priority, int32 MaxLod)
{
	if (!PSComponent || !PSComponent->Template || Priority < 0)
	{
		return;
	}
		
	MaxLod = AFxCacheMan::LimitLodRange(MaxLod, PSComponent->Template->GetLODLevelCount());

	//int32 MaxLod = GetMaxLodofCurrentQuality();
	AzureFxProxy Proxy(PSComponent, Priority, MaxLod);
	ActiveAzureFxProxyList.Add(Proxy);
	
	TArray<uint32> LodCosts = PSComponent->Template->AzureLodCosts;
	int32 Cost = LodCosts.IsValidIndex(MaxLod) ? LodCosts[MaxLod] : 0;
	ChangeTotalCost(Cost);

	SortActiveAzureFxProxy();

	//���������ǰquality�����cost����
	int32 DiffValue = 0;
	if (IsExceedingCountLimitEx(DiffValue)) 
	{
		AdjustActiveFxProxy(DiffValue);
	}

	if (PSComponent && MaxLod >= 0)
	{
		PSComponent->SetLODLevel(MaxLod);
	}
}

void AFxCacheMan::UnRegisterAzureFxProxy(UParticleSystemComponent* PSComponent)
{
	if (!PSComponent)
	{
		return;
	}

	for (int32 index = ActiveAzureFxProxyList.Num() - 1; index >= 0 ; index--)
	{
		if (ActiveAzureFxProxyList[index].PSComponent.IsValid() && ActiveAzureFxProxyList[index].PSComponent.Get() == PSComponent)
		{	
			int32 Lod = ActiveAzureFxProxyList[index].LodLevel;
			TArray<uint32>& LodCosts = ActiveAzureFxProxyList[index].LodCosts;
			int32 Cost = LodCosts.IsValidIndex(Lod) ? LodCosts[Lod] : 0;
			ChangeTotalCost(-Cost);
			ActiveAzureFxProxyList.RemoveAt(index);
			break;
			
		}
	}

}