// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"

#include "FxRestriction.h"
#include "wLuaStatic.h"
#include "FxOne.generated.h"

class UParticleSystemComponent;
class AFxCacheMan;
class AFxCache;
class UMeshComponent;
class UCurveFloat;
class UAnimInstance;

enum class  FxOneVisibleMask
{
	Logic = 0x00000001,
	FxMan = 0x00000002
};

UCLASS()
class AZURE_API AFxOne : public AActor
{
	GENERATED_BODY()

public:
	// Sets default values for this actor's properties
	AFxOne();

	// Called every frame
	virtual void Tick(float DeltaSeconds) override;

	virtual void BeginDestroy() override;

	virtual void Destroyed() override;

	double GetStartTime() const { return mStartTime; }

	UFUNCTION(BlueprintCallable, Category = "FxOne")
		void Play(float duration, bool needHighLod);

	UFUNCTION(BlueprintCallable, Category = "FxOne")
		void Stop();

	UFUNCTION(BlueprintCallable, Category = "FxOne")
		void DelayStop(float fDelayTime);

	UFUNCTION(BlueprintCallable, Category = "FxOne")
		bool Get_CanReplay() const { return FxRestriction.bCanReplay; }

	UFUNCTION(BlueprintCallable, Category = "FxOne")
		void Set_CanReplay(bool b) { FxRestriction.bCanReplay = b; }

	UFUNCTION(BlueprintCallable, Category = "FxOne")
		bool Get_CountLimited() const { return FxRestriction.bCountLimited; }

	UFUNCTION()
		void OnParticleSystemFinished(class UParticleSystemComponent* FinishedComponent);

	UFUNCTION(BlueprintCallable, Category = "FxOne")
		void Set_MaxFxQuality(EAzureFxQuality q) { FxRestriction.MaxFxQuality = q; };

	UFUNCTION(BlueprintCallable, Category = "FxOne")
		void Set_MaxFxLod(int32 InMaxLod) { MaxLod = InMaxLod; };

	void SetFxTemplate(const UParticleSystem* InFxTemplate);
	void ClearFxTemplate();

	void AddOnStopCallback(wLua::lua_registry_handle cb, wLua::lua_registry_handle cbparam);
	void ClearOnStopCallback();

	UFUNCTION(BlueprintCallable, Category = "FxOne")
		UParticleSystemComponent* GetParticleSystemComp()
	{
		return FxComponent;
	}
	UFUNCTION(BlueprintCallable, Category = "FxOne")
		float GetLeftDurationFloat()
	{
		return float(GetLeftDuration());
	}

	UFUNCTION()
		void SetNotEffectByManRenderHide(bool notEffect);

	UFUNCTION()
		bool IsLogicallyPlaying() const { return mLogicallyPlaying; }

	UFUNCTION()
		bool IsReallyPlaying() const;

	UFUNCTION()
		void SetTrailParam(UMeshComponent* MeshComponent, FName InFirstSocketName, FName InSecondSocketName, ETrailWidthMode Mode, UAnimInstance* Anim, FName CurveName);

	UFUNCTION()
		void SetFXVisible(bool bVisible);

	UFUNCTION()
		void SetFXVisibleEx(bool bVisible, int32 mask);

	float GetTrailWidth() const;

	double GetLeftDuration() const;

	bool IsResourceReady() const;
	void OnResourceReady();

	void OnAllFxRenderHideFlagChanged();

	void SetCurrentLod(uint32 Lod) { CurrentLod = Lod; }

	uint32 GetCurrentLod() const { return CurrentLod; }

	void SetPriority(uint32 InPriority) { Priority = InPriority; }

	uint32 GetPriority() const { return Priority; }

	bool IsLoopPlay() const;

	float GetLeftTime() const{ return mInvokeTime; }

	uint32 GetLodCost(int32 Lod = -1) const; //���㵱ǰLod�ȼ��µ�Cost

	void SetLodLevel(int32 Lod);

	int32 GetLODLevelCount() const;
	
	void OnGiveBack();
protected:
	void SavePlayParameter(float duration, bool needHighLod);
	void DoPlayLogically();
	void StopLogicallyPlay();

	void DoPlayReally();
	void StopReallyPlay();
	EAzureFxQuality CalculateQuality() const;

	void SetInvoke(float t);
	bool IsInvoking() const;
	void CancelInvoke();

	bool IsDelayStopping() const
	{
		return mDelayStopTime >= 0;
	}
	void CancelDelayStop()
	{
		mDelayStopTime = -1;
	}

	void ReplayAfterSeconds(float InNextPlayTime);
	bool IsWaitingReplay()const;
	void CancelReplay();

	void UpdateTickEnable();
	void SetFXVisibleInner(bool bVisible, FxOneVisibleMask mask);

	bool IsBeingDestroyed()const;

	void CallOnStopCallback();

	TWeakObjectPtr<UMeshComponent> TrailOwner;
	FName FirstSocketName;
	FName SecondSocketName;
	ETrailWidthMode TrailWidthMode;
	TWeakObjectPtr<UAnimInstance> AnimInstance;
	FName TrailWidthCurveName;

	bool IsCallOnStopCallBack = false;
	wLua::lua_registry_handle OnStopCallback;
	wLua::lua_registry_handle OnStopCallbackParam;
public:
	FString mName;
	bool mLogicallyPlaying = false;
	bool mReallyPlaying = false;
	double mStartTime = 0.0;

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly)
	float mDuration = -1.f;
	float mInvokeTime = -1.f;
	float mNextPlayTime = -1.f;
	float mDelayStopTime = -1.f;

	AzureFxRestriction FxRestriction;

	UPROPERTY(Transient)
	AFxCacheMan* FxCacheMan = nullptr;

	UPROPERTY(Transient)
	AFxCache* FxCache = nullptr;

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Transient)
	UParticleSystemComponent* FxComponent = nullptr;

private:

	int32 CurrentLod;

	uint32 Priority; //��Ч���ȼ�

	bool notEffectByManRenderHide = false;

	uint32 invisibleMask = 0;

	int32 MaxLod;
};
