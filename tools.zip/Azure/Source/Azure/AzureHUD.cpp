// Fill out your copyright notice in the Description page of Project Settings.

#include "AzureHUD.h"
#include "AzureEntryPoint.h"
#include "CanvasItem.h"
#include "Engine/Canvas.h"

#include "Kismet/GameplayStatics.h"
#include "AzureLensFlare.h"

void AAzureHUD::DrawHUD()
{
	Super::DrawHUD();

	TArray<AActor*> Actors;
	UGameplayStatics::GetAllActorsOfClass(GetWorld(), AAzureLensFlare::StaticClass(), Actors);
	for (int i = 0; i < Actors.Num(); i++)
	{
		AAzureLensFlare* pActorLensFlare = Cast<AAzureLensFlare>(Actors[i]);
		if (pActorLensFlare)
			pActorLensFlare->RenderFlare(Canvas);
	}

	if (AAzureEntryPoint::Instance)
	{
		AAzureEntryPoint::Instance->OnDrawHUD(this);
	}
		
}

void AAzureHUD::DrawDebugText(FString const& Text, FLinearColor Color, float ScreenX, float ScreenY, UFont* Font, float Scale, bool bScalePosition)
{
	if (DebugCanvas)
	{
		if (bScalePosition)
		{
			ScreenX *= Scale;
			ScreenY *= Scale;
		}
		FCanvasTextItem TextItem(FVector2D(ScreenX, ScreenY), FText::FromString(Text), Font ? Font : GEngine->GetMediumFont(), Color);
		TextItem.Scale = FVector2D(Scale, Scale);
		DebugCanvas->DrawItem(TextItem);
	}
}
