#include "Azure.h"
#include "Misc/CommandLine.h"

#define LUA_LIB

#include <string>
#include "AzureExport.h"
#include "wLua/LuaInterface.h"
#include "wLua/wLuaRuntime.h"

#include "HAL/IConsoleManager.h"
#include "Kismet/GameplayStatics.h"
#include "HAL/PlatformFilemanager.h"
#include "Engine.h"

#include "AzurePlanarReflectionCapture.h"

#include "help_funcs.h"

namespace LuaSystemInfo {
	void RawRegister(lua_State* L);
}
namespace LuaAFile {
    void Register(lua_State* L);
}
namespace LuaTSimuHelper {
	void Register(lua_State *L);
}

extern ENGINE_API void GAzureSetUseBasicQualityLevelsFlag(uint32 InFlag);
extern ENGINE_API uint32 GAzureGetUseBasicQualityLevelsFlag();
extern ENGINE_API void GAzureSetRealQualityLevelsToUse(uint32 InFlag);
extern ENGINE_API uint32 GAzureGetRealQualityLevelsToUse();

static int lua_PauseTrigger(lua_State* L)
{
	if (lua_isnumber(L, 1))
	{
		int param = lua_tonumber(L, 1);
		lua_pushinteger(L, param);
	}
	else if (lua_isstring(L, 1))
	{
		char const* param = lua_tostring(L, 1);
		lua_pushstring(L, param);
	}
	else if (lua_isuserdata(L, 1))
	{
		void* param = lua_touserdata(L, 1);
		lua_pushlightuserdata(L, param);
	}
	return 1;
}

int lua_setUseBasicQualityLevelFlag(lua_State * L)
{
	uint32 flag = uint32(luaL_checkint(L, 1));
	GAzureSetUseBasicQualityLevelsFlag(flag);
	return 0;
}

int lua_getUseBasicQualityLevelFlag(lua_State * L)
{
	uint32 flag = GAzureGetUseBasicQualityLevelsFlag();
	lua_pushinteger(L, int(flag));
	return 1;
}

int lua_setRealQualityLevelsToUse(lua_State * L)
{
	uint32 flag = 0;
	int top = lua_gettop(L);
	for (int i = 1; i <= top; ++i)
	{
		int qualityLevel = lua_tointeger(L, i);
		flag |= (1 << qualityLevel);
	}
	GAzureSetRealQualityLevelsToUse(flag);
	return 0;
}

static int lua_SetEngineDebugFlag(lua_State * L)
{
#if UE_GAME
	bool flag = !!lua_toboolean(L, 1);
	GAzureRuntimeDebugFlag = flag;
	a_SetRuntimeDebugFlag(flag);
#endif
	return 0;
}

int lua_getRealQualityLevelsToUse(lua_State * L)
{
	uint32 flag = GAzureGetRealQualityLevelsToUse();
	lua_pushinteger(L, int(flag));
	return 1;
}

int lua_GetConsoleVariable(lua_State * L)
{
	IConsoleVariable* pVar = nullptr;

	if (lua_isstring(L, 1))
	{
		pVar = IConsoleManager::Get().FindConsoleVariable(UTF8_TO_TCHAR(luaL_checkstring(L, 1)));
	}

	if (pVar == nullptr)
	{
		wLua::LuaStatic::traceback(L, "lua_GetConsoleVariableFloat, Can't find given console variable");
		lua_error(L);
		return 1;
	}

	int paramType = 0;

	if (!lua_isnoneornil(L, 2) && lua_isnumber(L, 2))
	{
		paramType = lua_tointeger(L, 2);
	}

	if (paramType == 0)
		lua_pushnumber(L, pVar->GetFloat());
	else if (paramType == 1)
		lua_pushstring(L, TCHAR_TO_UTF8(*pVar->GetString()));
	else
	{
		wLua::LuaStatic::traceback(L, "lua_GetConsoleVariableFloat, wrong paramType");
		lua_error(L);
		return 1;
	}

	return 1;
}

int lua_SetConsoleVariable(lua_State * L)
{
	IConsoleVariable* pVar = nullptr;

	if (lua_isstring(L, 1))
	{
		pVar = IConsoleManager::Get().FindConsoleVariable(UTF8_TO_TCHAR(luaL_checkstring(L, 1)));
	}

	if (pVar == nullptr)
	{
		FString funcEntry = wLua::LuaStatic::GetTraceBack(L);
		UE_LOG(LogAzure, Warning, TEXT("Can't find given console variable:%s"), *funcEntry);
		return 0;
	}

	//	Flag
	int Flag = 0;
	if (lua_isnoneornil(L, 3))
	{
		Flag = ECVF_SetByCode;
	}
	else if (lua_isnumber(L, 3))
	{
		Flag = lua_tointeger(L, 3);
	}
	else
	{
		astring ErrorInfo = "SetConsoleVariable: variable ";
		ErrorInfo += lua_tostring(L, 1);
		ErrorInfo += " need integer flag.";

		lua_pushstring(L, ErrorInfo.c_str());
		lua_error(L);
		return 1;
	}

	if (lua_isnumber(L, 2))
	{
		float i = (float)luaL_checknumber(L, 2);
		pVar->Set(i, static_cast<EConsoleVariableFlags>(Flag));
	}
	else if (lua_isstring(L, 2))
	{
		pVar->Set(UTF8_TO_TCHAR(luaL_checkstring(L, 2)), static_cast<EConsoleVariableFlags>(Flag));
	}
	else
	{
		wLua::LuaStatic::traceback(L, "SetConsoleVariable, wrong param");
		lua_error(L);
		return 1;
	}

	return 0;
}

int lua_CallAllConsoleVariableSinks(lua_State * L)
{
	IConsoleManager::Get().CallAllConsoleVariableSinks();
	return 0;
}

static int lua_SetMobileContentScaleFactor(lua_State* L)
{
	float scale = luaL_checknumber(L, 1);
	static IConsoleVariable* CVar = IConsoleManager::Get().FindConsoleVariable(TEXT("r.MobileContentScaleFactor"));
	CVar->Set(scale, ECVF_SetByConsole);
	return 0;
}

static int lua_SetMobileHDR(lua_State* L)
{
	int hdr = luaL_checkinteger(L, 1);
	IConsoleVariable* CVar = IConsoleManager::Get().FindConsoleVariable(TEXT("r.MobileHDR"));
	CVar->Set(hdr, ECVF_SetByProjectSetting);
	CVar = IConsoleManager::Get().FindConsoleVariable(TEXT("r.HDR.EnableHDROutput"));
	CVar->Set(hdr, ECVF_SetByGameSetting);
	return 0;
}

static int lua_SetMobileMSAA(lua_State* L)
{
	int msaa = luaL_checkinteger(L, 1);
	if(msaa == 0)
	{
		msaa = 1;
	}
	IConsoleVariable* CVar = IConsoleManager::Get().FindConsoleVariable(TEXT("r.MobileMSAA"));
	CVar->Set(msaa, ECVF_SetByProjectSetting);
	return 0;
}

//we can not access GameUserSetting in ConfingEngine, need use the "default" way
static int lua_GetDesktopResolution(lua_State* L)
{
	FDisplayMetrics DisplayMetrics;
	FDisplayMetrics::RebuildDisplayMetrics(DisplayMetrics);
	lua_pushinteger(L, DisplayMetrics.PrimaryDisplayWidth);
	lua_pushinteger(L, DisplayMetrics.PrimaryDisplayHeight);
	return 2;
}

static int GetPlatformName(lua_State * L)
{
	FString pname = UGameplayStatics::GetPlatformName();
	lua_pushstring(L, TCHAR_TO_UTF8(*pname));
	return 1;
}

static int lua_GetCommandLineText(lua_State * L)
{
	FString commandLineText = FCommandLine::Get();
	lua_pushstring(L, TCHAR_TO_UTF8(*commandLineText));
	return 1;
}

static int lua_SetCommandLineText(lua_State * L)
{
	if (lua_isstring(L, 1))
	{
		FCommandLine::Set(UTF8_TO_TCHAR(luaL_checkstring(L, 1)));
	}

	return 0;
}

static int lua_AppendCommandLineText(lua_State * L)
{
	if (lua_isstring(L, 1))
	{
		FCommandLine::Append(UTF8_TO_TCHAR(luaL_checkstring(L, 1)));
	}

	return 0;
}

int lua_GetCommandLineParam(lua_State * L)
{
	const char* key = luaL_checkstring(L, 1);
	FString param;
	FParse::Value(FCommandLine::Get(), UTF8_TO_TCHAR(key), param);
	lua_pushstring(L, TCHAR_TO_UTF8(*param));
	return 1;
}

int lua_HasCommandLineParam(lua_State * L)
{
	const char* key = luaL_checkstring(L, 1);
	bool b = FParse::Param(FCommandLine::Get(), UTF8_TO_TCHAR(key));
	lua_pushboolean(L, b);
	return 1;
}

int lua_ExecuteCmd(lua_State * L)
{
	FString Cmd = UTF8_TO_TCHAR(luaL_checkstring(L, 1));
	GEngine->DeferredCommands.AddUnique(*Cmd);
	return 0;
}

int lua_ForceSetRHISupportsRHIThread(lua_State * L)
{
#if UE_GAME
	extern RHI_API int32 GForceSetRHISupportsRHIThread;
	GForceSetRHISupportsRHIThread = lua_tointeger(L, 1);
#endif
	return 0;
}

namespace AzureLuaMemFunc
{
	extern void InitLuaAllocator(unsigned int NormalBlockMemReserved, unsigned int BigBlockMemReserved,
		unsigned int NormalBlockMaxAllocSize, unsigned int BigBlockMaxAllocSize,
		float NormalBlockExtraBudgetRatio, float BigBlockExtraBudgetRatio);

	extern void * AnsiLuaAlloc(void *ud, void *ptr, size_t osize, size_t nsize);
}

static int lua_InitWluaCustomAllocFunc(lua_State * L)
{
#if UE_GAME
	wLua::GUseComtomAllocFuncFlag = true;
	unsigned int NormalBlockMemReserved = luaL_checkint(L, 1);
	unsigned int BigBlockMemReserved = luaL_checkint(L, 2);
	unsigned int NormalBlockMaxAllocSize = luaL_checkint(L, 3);
	unsigned int BigBlockMaxAllocSize = luaL_checkint(L, 4);
	float NormalBlockExtraBudgetRatio = (float)luaL_checknumber(L, 5);
	float BigBlockExtraBudgetRatio = (float)luaL_checknumber(L, 6);
	AzureLuaMemFunc::InitLuaAllocator(NormalBlockMemReserved, BigBlockMemReserved, NormalBlockMaxAllocSize, BigBlockMaxAllocSize,
		NormalBlockExtraBudgetRatio, BigBlockExtraBudgetRatio);
#endif
	return 0;
}

int lua_ForceWluaAnsiAllocFunc(lua_State * L)
{
	bool value = lua_toboolean(L, 1);
#if UE_GAME
	wLua::GForceAnsiAllocFuncFlag = value;
	wLua::LuaAnsiAllocFuncPtr = value ? AzureLuaMemFunc::AnsiLuaAlloc : nullptr;
#endif
	return 0;
}

int lua_EnableLuaAllocProfiler(lua_State * L)
{
	bool value = lua_toboolean(L, 1);
#if UE_GAME
	wLua::GEnableLuaAllocProfilerFlag = value;
#endif
	return 0;
}

int lua_SetMapWarnings(lua_State * L)
{
	bool bValue = lua_toboolean(L, 1);
	GEngine->bSuppressMapWarnings = bValue ? 0 : 1;
	return 0;
}

int lua_SetReflectionQuality(lua_State * L)
{
	int32 quality = (int32)lua_tonumber(L, 1);

	AAzurePlanarReflectionCapture::SetQualityLevel(quality);

	return 0;
}

int lua_GetReflectionQuality(lua_State * L)
{
	int32 quality = AAzurePlanarReflectionCapture::GetQualityLevel();
	lua_pushinteger(L, quality);
	return 1;
}

static const luaL_Reg Lib_ConfigEngine_Funcs[] =
{
	{ "PauseTrigger", lua_PauseTrigger },
	{ "GetConsoleVariable", lua_GetConsoleVariable },
	{ "SetConsoleVariable", lua_SetConsoleVariable },
	{ "CallAllConsoleVariableSinks", lua_CallAllConsoleVariableSinks },
	{ "SetMobileContentScaleFactor",  lua_SetMobileContentScaleFactor },
	{ "SetMobileHDR",  lua_SetMobileHDR },
	{ "SetMobileMSAA", lua_SetMobileMSAA },
	{ "GetDesktopResolution", lua_GetDesktopResolution },
	{ "GetPlatformName",  GetPlatformName },
	{ "GetCommandLineText", lua_GetCommandLineText },
	{ "SetCommandLineText", lua_SetCommandLineText },
	{ "AppendCommandLineText", lua_AppendCommandLineText },
	{ "GetCommandLineParam", lua_GetCommandLineParam },
	{ "HasCommandLineParam", lua_HasCommandLineParam },
	{ "ExecuteCmd", lua_ExecuteCmd },
	{ "ForceSetRHISupportsRHIThread", lua_ForceSetRHISupportsRHIThread },
	{ "SetMapWarnings", lua_SetMapWarnings },
	{ "SetReflectionQuality", lua_SetReflectionQuality },
	{ "GetReflectionQuality", lua_GetReflectionQuality },
	{ "InitWluaCustomAllocFunc", lua_InitWluaCustomAllocFunc },
	{ "ForceWluaAnsiAllocFunc", lua_ForceWluaAnsiAllocFunc },
	{ "EnableLuaAllocProfiler", lua_EnableLuaAllocProfiler },
	{ "setUseBasicQualityLevelFlag", lua_setUseBasicQualityLevelFlag},
	{ "getUseBasicQualityLevelFlag", lua_getUseBasicQualityLevelFlag},
	{ "setRealQualityLevelsToUse", lua_setRealQualityLevelsToUse },
	{ "getRealQualityLevelsToUse", lua_getRealQualityLevelsToUse },
	{ "SetEngineDebugFlag", lua_SetEngineDebugFlag },
	{ NULL, NULL }
};

namespace wLua
{
	class AzureLuaConfigEngine : public AzureLuaBase
	{
		virtual void OnInit(lua_State * L) override
		{
			AzureLuaBase::OnInit(L);
			int nTop = lua_gettop(L);
			//ע�ὺˮ����
			LuaSystemInfo::RawRegister(L);
			LuaAFile::Register(L);
			LuaTSimuHelper::Register(L);
			
			exp_setup_configengine_luastate(L);
			luaL_register(L, "ConfigEngine", Lib_ConfigEngine_Funcs);
			lua_settop(L, nTop);
		}
		virtual void OnPreFini(lua_State * L) override
		{
			exp_clear_configengine_luastate(nullptr);
			AzureLuaBase::OnPreFini(L);
		}
	};
}


static wLua::AzureLuaConfigEngine* s_wlua = nullptr;

void a_InitConfigEngine()
{
#if defined(AZURE_UE_TARGET_DEBUG) || defined(AZURE_UE_TARGET_DEBUGGAME)
	const bool debug = true;
#else
	const bool debug = false;
#endif
	s_wlua = new wLua::AzureLuaConfigEngine();
	s_wlua->Init(wLua::Lua::OPENMODEMASK::BASE, debug, false);
	checkf(s_wlua, TEXT("InitConfigEngine LuaEnv Failed."));
	lua_State_Wrapper L = s_wlua->GetL();

	unsigned char * bytes = nullptr;
	ADWORD len = 0;
	int nTop = lua_gettop(L);
	wLua::LuaStatic::load(L, "config_engine_early");
	if (!lua_isfunction(L, -1))
	{
		astring errmsg = lua_tostring(L, -1);
		checkf(false, TEXT("InitConfigEngine: %s"), ANSI_TO_TCHAR(errmsg.c_str()));
	}

	{
		int ret = wLua::LuaStatic::pcallWithTraceback(L, 0, 0);
		if (ret != 0)
		{
			UE_LOG(LogAzure, Error, TEXT("config_engine_early error: %s"), ANSI_TO_TCHAR(lua_tostring(L, -1)));
		}
	}

	lua_settop(L, nTop);
}

void OverrideDeviceProfile()
{
	{
		lua_State_Wrapper L = s_wlua->GetL();
		unsigned char * bytes = nullptr;
		ADWORD len = 0;
		int nTop = lua_gettop(L);
		wLua::LuaStatic::load(L, "config_engine");
		if (!lua_isfunction(L, -1))
		{
			astring errmsg = lua_tostring(L, -1);
			checkf(false, TEXT("ConfigEngine: %s"), ANSI_TO_TCHAR(errmsg.c_str()));
		}

		{
			int ret = wLua::LuaStatic::pcallWithTraceback(L, 0, 0);

			if (ret != 0)
			{
				UE_LOG(LogAzure, Error, TEXT("config_engine error: %s"), UTF8_TO_TCHAR(lua_tostring(L, -1)));
			}
		}

		lua_settop(L, nTop);
	}

	s_wlua->Fini();
	delete s_wlua;
	s_wlua = nullptr;
}

void a_ConfigEngine()
{
	if (!GIsEditor)
		FPlatformFileManager::Get().AzureSetOverrideDeviceProfileFunc(OverrideDeviceProfile);
}
