#pragma once

#include "CoreMinimal.h"
#include "Package.h"
#include "UObjectHash.h"
#include <functional>
#include "Map.h"

DECLARE_LOG_CATEGORY_EXTERN(LogAzureResourceLoader, Log, All);

DECLARE_DELEGATE_OneParam(FResourceLoaderAsyncDelegate, UObject*)


typedef std::function<void(TArray<UObject*>)> AzureResourceCallbackFuncType;

class AZURE_API AzureResourceLoader : public FGCObject
{
	AzureResourceLoader();
	~AzureResourceLoader();

	void InnerLoadCallback(const FName& PackageName, UPackage* ResPackage, EAsyncLoadingResult::Type Result, FName realPckName);

	static void _AsyncLoadCallbackWrapper(const FName& PackageName, UPackage* ResPackage, EAsyncLoadingResult::Type Result, FName realPckName);

	typedef TArray<AzureResourceCallbackFuncType> CallbacksArray;
	TArray<CallbacksArray*> callbacksArrayCache;
	TMap<FName, CallbacksArray*> callbacksMap;

	CallbacksArray* GetOrCreateCallbacksArray()
	{
		if (callbacksArrayCache.Num() > 0)
			return callbacksArrayCache.Pop(false);

		return new CallbacksArray();
	}

	void AddCallbacksArrayToCache(CallbacksArray* callbacks)
	{
		if (callbacksArrayCache.Num() < 64)
		{
			callbacks->Reset();
			callbacksArrayCache.Add(callbacks);
		}
		else
		{
			delete callbacks;
		}
	}

	// Begin FGCObject
	virtual void AddReferencedObjects(FReferenceCollector& Collector) override;
	// End FGCObject

	struct DelayedCallbackInfo
	{
		FName PackageName;
		UPackage* ResPackage;
		EAsyncLoadingResult::Type Result;
		FName realPckName;
	};

	TArray<DelayedCallbackInfo> delayedCallbackInfos;
	TArray<DelayedCallbackInfo> tempCallbackInfos;
	TArray<UObject*> delayedCallbackRes;
	TArray<UObject*> tempCallbackRes;

public:

	static AzureResourceLoader& Get();

	void LoadGameResAsync(const FString& InName, AzureResourceCallbackFuncType&& func, bool IsWorld = false);
	void LoadGameResAsync(const FString& InName, const AzureResourceCallbackFuncType& func, bool IsWorld = false)
	{
		AzureResourceCallbackFuncType tempFunc(func);
		LoadGameResAsync(InName, std::move(tempFunc), IsWorld);
	}

	void LoadGameRes(const FString& InName, TArray<UObject*>& res, bool IsWorld = false);
	bool IsGameResLoaded(const FString& InName);

private:
	bool ConvertResNameToPackagePath(const FString& InName, FString& OutPackagePath, FString& OutErrorInfo);

public:
	void Tick();
	void Shutdown();
};
