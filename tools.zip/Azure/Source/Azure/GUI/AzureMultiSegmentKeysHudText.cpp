#include "AzureMultiSegmentKeysHudText.h"
#include "CanvasPanel.h"
#include "CanvasPanelSlot.h"
#include "GUI/AzureHudTextMan.h"
#include "AzureEntryPoint.h"
#include "Kismet/GameplayStatics.h"
#include "WidgetLayoutLibrary.h"
#include "UE4Related.h"
#include "../AzureCommonDef.h"
#include "Kismet/KismetSystemLibrary.h"
#include "AzureUtility.h"
#include "WidgetAnimation.h"

extern FAnchors hud_anchor;


float UAzureMultiSegmentFloatKeys::Update(float initial_value	// ��ʼֵ
										 , float elapsedTime)	// ��ȥʱ��
{
	// ��һ�ؼ�֡��ʱ��
	// Ĭ�ϴ��㿪ʼ����
	float last_Time		= 0.0f;
	// ��һ�ؼ�֡��ֵ
	// Ĭ��ʹ�ó�ʼ����ֵ
	float last_Value		= initial_value;

	float currValue = last_Value;// Ĭ��ʹ�ó�ʼֵ

	int32 num = segKeys.Num();
	if (num > 0)
	{
		int32 targetIndex = num - 1;// �ٶ�Ŀ��ؼ�֡�����һ�ؼ�֡
		UAzureMultiSegmentFloatKey *theLastSegKey	= &(segKeys.Last());
		if (elapsedTime < theLastSegKey->time)
		{// δ���� ���һ�ؼ�֡��ʱ��
			for (int32 idx = num - 2; idx >= 0 ; --idx)
			{// �������

				UAzureMultiSegmentFloatKey *segKey	= &(segKeys[idx]);
				if (elapsedTime < segKey->time)
				{
					targetIndex = idx;
					break;
				}
			}
		}
		if (targetIndex > 0)
		{// ��ǰĿ��֡ ǰ����һ�ؼ�֡
			UAzureMultiSegmentFloatKey *segKeyPrev	= &(segKeys[targetIndex - 1]);
			last_Time = segKeyPrev->time;	// ��һ�ؼ�֡��ʱ��
			last_Value = segKeyPrev->fValue;// ��һ�ؼ�֡��ֵ
		}

		UAzureMultiSegmentFloatKey *targetKey = &(segKeys[targetIndex]);
		float t = (elapsedTime - last_Time) / (targetKey->time - last_Time);
		t = FMath::Clamp(t , 0.0f , 1.0f);
		currValue = FMath::Lerp<float , float>(last_Value , targetKey->fValue , t);
	}
	//else
	//{// �ؼ�֡�б��ǿյ�
	//	
	//}
	return currValue;
}

int32 UAzureMultiSegmentStringKeys::Update(float last_Time	// ��һ֡��ʱ��
										   , float elapsedTime	// ��ȥʱ��
										   , TArray<FString> &OutEvent)// ������¼�
{
	TArray<FString> msgs;
	int32 num = segKeys.Num();
	if (num > 0)
	{// �븡��ؼ�֡���� ��ͬ
		//�ַ����ؼ�֡���� ֻ�ھ���ʱ�Żᴥ��
		//int32 targetIndex = -1;// �ٶ�Ŀ��ؼ�֡Ϊ��Ч
		for (int32 idx = 0; idx < num; ++idx)
		{// �������
			UAzureMultiSegmentStringKey *segKey	= &(segKeys[idx]);
			//UE_LOG(LogAzure , Warning , TEXT("**************** idx(%d) last_Time(%f) elapsedTime(%f) time(%f)") , idx,last_Time ,elapsedTime , segKey->time);
			//TArray<FStringFormatArg> args;
			//args.Add(idx);
			//args.Add(last_Time);
			//args.Add(elapsedTime);
			//args.Add(segKey->time);

			//FString msg = FString::Format(TEXT("****************0000 idx({0}) last_Time({1}) elapsedTime({2}) time({3})") , args);
			//msgs.Add(msg);

			if (segKey->time >= last_Time && segKey->time < elapsedTime )
			{
				//targetIndex = idx;
				//TArray<FStringFormatArg> args;
				//args.Add(idx);
				////UE_LOG(LogAzure , Warning , TEXT("$$$$$$$$$$$$$$$$ targetIndex(%d)") , targetIndex);
				//FString msg = FString::Format(TEXT("$$$$$$$$$$$$$$$$1111 targetIndex({0})") , args);
				//msgs.Add(msg);
				OutEvent.Add(segKey->strValue);
				//break;
			}
		}
		//if (targetIndex >= 0)
		//{// ��ǰĿ��֡
		//	UAzureMultiSegmentStringKey *targetKey = &(segKeys[targetIndex]);
		//	if (elapsedTime > targetKey->time && last_Time < targetKey->time)
		//	{
		//	return &targetKey->strValue;
		//	}
		//}
	}

	//for (int32 idx = 0; idx < msgs.Num() ; ++idx)
	//{
	//	const FString &msg = msgs[idx];
	//	UE_LOG(LogAzure , Warning , TEXT("%s") , *msg);
	//}

	return OutEvent.Num();
}

UAzureMultiSegmentKeysHudText::~UAzureMultiSegmentKeysHudText()
{
	for (Entry *ent : _EntryArr)
	{
		for (int32 i = 0 ; i < ent->labels.Num() ; ++i)
		{
			LableInfo &label = ent->labels[i];
			if (label.label.IsValid())
			{
				label.label->RemoveFromParent();
			}
		}
		delete ent;
	}
	_EntryArr.Empty();

	for (Entry *ent : _UnusedEntryArr)
	{
		for (int32 i = 0 ; i < ent->labels.Num() ; ++i)
		{
			LableInfo &label = ent->labels[i];
			if (label.label.IsValid())
			{
				label.label->RemoveFromParent();
			}
		}
		delete ent;
	}
	_UnusedEntryArr.Empty();


	for (UAzureBMTextWeakPtr labelPtr : _UnusedLabelArr)
	{
		if (labelPtr.IsValid())
		{
			labelPtr->RemoveFromParent();
		}
	}
	_UnusedLabelArr.Empty();

	//for (UAzureBMTextWeakPtr labelPtr : _LabelArr)
	//{
	//	if (labelPtr.IsValid())
	//	{
	//		labelPtr->RemoveFromParent();
	//	}
	//}
	//_LabelArr.Empty();


	for (UUserWidgetPtr effectPtr : _UnusedEffectArr)
	{
		if (effectPtr.IsValid())
		{
			effectPtr->RemoveFromParent();
		}
	}
	_UnusedEffectArr.Empty();

	_pOwner = nullptr;
}

void UAzureMultiSegmentKeysHudText::Clear()
{
	for (Entry *ent : _EntryArr)
	{
		for (int32 i = 0 ; i < ent->labels.Num() ; ++i)
		{
			LableInfo &label = ent->labels[i];
			if (label.label.IsValid())
			{
				label.label->SetVisibility(ESlateVisibility::Collapsed);
				_UnusedLabelArr.Add(label.label);
			}
		}
		ent->Reset();
		_UnusedEntryArr.Add(ent);

		if (ent->effect.IsValid())
		{
			_UnusedEffectArr.Add(ent->effect);
			ent->effect = nullptr;
		}
	}
	_EntryArr.Empty();
	_pOwner = nullptr;
}

void UAzureMultiSegmentKeysHudText::Update(float dt)
{
	for (int idx = _EntryArr.Num() - 1; idx >= 0; --idx)
	{
		Entry *entry = _EntryArr[idx];

		if (entry->elapsedTime >= entry->timeLine->endingTime)
		{// ��ʱ����
			_EntryArr.RemoveAt(idx);
			for (int32 i = 0 ; i < entry->labels.Num() ; ++i)
			{
				LableInfo &label = entry->labels[i];

				if (label.label.IsValid())
				{
					label.label->SetVisibility(ESlateVisibility::Collapsed);
				}
				_UnusedLabelArr.Add(label.label);
				//UE_LOG(LogAzure , Warning , TEXT("_UnusedLabelArr.Num()=%d") , _UnusedLabelArr.Num());
			}

			if (entry->effect.IsValid())
			{
				entry->effect->SetVisibility(ESlateVisibility::Collapsed);
				_UnusedEffectArr.Add(entry->effect);
				entry->effect = nullptr;
			}

			entry->Reset();
			_UnusedEntryArr.Add(entry);
			continue;
		}
		else
		{
			FVector2D AttachPointScreenPosition;
			APlayerController *PlayerController = UGameplayStatics::GetPlayerController(_pOwner.Get() , 0);
			bool bSuc = PlayerController->ProjectWorldLocationToScreen(entry->worldOffset , AttachPointScreenPosition);
			if (bSuc)
			{
				float ViewportScale = UWidgetLayoutLibrary::GetViewportScale(_pOwner.Get());
				FVector2D unscaledViewportOffset = AttachPointScreenPosition / ViewportScale;

				for (int32 i = 0 ; i < entry->labels.Num() ; ++i)
				{
					LableInfo &label = entry->labels[i];
					float dt_ = i * entry->timeLine->verbatimDeltaTime;	// ��һ��ʱ��
					float elapsedTime = entry->elapsedTime - dt_;
					label.offset.X	= entry->timeLine->FKs_X	.Update(entry->initial_X		, elapsedTime);
					label.offset.Y	= entry->timeLine->FKs_Y	.Update(entry->initial_Y		, elapsedTime);
					label.scale		= entry->timeLine->FKs_Scale.Update(entry->initial_Scale	, elapsedTime);
					label.alpha		= entry->timeLine->FKs_Alpha.Update(entry->initial_Alpha	, elapsedTime);

					label.offset += unscaledViewportOffset;
					if (label.label.IsValid())
					{
						label.label->SetOpacity(label.alpha);
						label.label->SetRenderScale(FVector2D(label.scale , label.scale));
					}
				}
			}
			TArray<FString> events;
			int32 num = entry->timeLine->SKs_Event.Update(entry->lastTime , entry->elapsedTime , events);
			for (FString event : events)
			{// �¼�
				const FString &ev= event;
				FString left;
				FString right;
				ev.Split(TEXT("|") , &left , &right);
				left = left.ToLower();
				//UE_LOG(LogAzure , Warning , TEXT("left(%s) , right(%s)") , *left , *right);
				if (bSuc && left == TEXT("play") && entry->effect != nullptr)
				{
					UUserWidget *UserWidget = entry->effect.Get();
					UWidgetBlueprintGeneratedClass *cls = Cast<UWidgetBlueprintGeneratedClass>(UserWidget->GetClass());

					for (UWidgetAnimation* Animation : cls->Animations)
					{
						if (Animation && (Animation->GetName().StartsWith(right))
							||(Animation->GetMovieScene() && Animation->GetMovieScene()->GetName().StartsWith(right)))
						{
							UserWidget->SetVisibility(ESlateVisibility::HitTestInvisible);
							UserWidget->SetRenderTransformPivot(FVector2D(0.5 , 0.5));
							UserWidget->SetRenderScale(FVector2D(1.0 , 1.0));
							//UserWidget->SetOpacity(1.0);
							UserWidget->PlayAnimation(Animation);
							break;
						}
					}
				}
			}
		}

		entry->ApplyOffset();
		entry->lastTime = entry->elapsedTime;// ��һ֡ʱ�䣬ÿ֡�仯
		entry->elapsedTime += dt;			// ��ȥʱ�䣬ÿ֡�仯
	}
}

void UAzureMultiSegmentKeysHudText::CreateEntryByWorldPos(FString &InText , UAzureBMFont *Font , int fontSize , float scale , float alpha , UAzureMultiSegmentTimeLine *multiSegTimeLine , const FVector &worldPos , const FVector2D &offset , int32 txt_ZOrder, int32 effect_ZOrder)
{
	if (InText.Len() <= 0)
	{
		return;
	}
	if (!_pOwner.IsValid())
	{
		return;
	}
	_CreateEntry(InText , Font , fontSize , scale , alpha , multiSegTimeLine , worldPos , offset, txt_ZOrder, effect_ZOrder);
}

void UAzureMultiSegmentKeysHudText::CreateEntry(const FString &InText , UAzureBMFont *Font , int fontSize , float scale , float alpha , UAzureMultiSegmentTimeLine *multiSegTimeLine , const FVector &Woffset , const FVector2D &offset, int32 txt_ZOrder, int32 effect_ZOrder)
{
	if (InText.Len() <= 0)
	{
		return;
	}
	if (!_pOwner.IsValid())
	{
		return;
	}
	FVector ActorPos = _pOwner->GetActorLocation();

	FVector AttachPointWorldPosition = Woffset + ActorPos;
	_CreateEntry(InText , Font , fontSize , scale , alpha , multiSegTimeLine , AttachPointWorldPosition , offset , txt_ZOrder, effect_ZOrder);
}

void UAzureMultiSegmentKeysHudText::_CreateEntry(const FString &InText , UAzureBMFont *Font , int fontSize , float scale , float alpha , UAzureMultiSegmentTimeLine *multiSegTimeLine , const FVector &worldPos , const FVector2D &offset , int32 txt_ZOrder, int32 effect_ZOrder)
{
	if (!AAzureEntryPoint::Instance)
		return;

	AzureHudTextMan *pMan = AAzureEntryPoint::Instance->GetHudTextMan();
	if (!pMan)
	{
		return;
	}

	UUserWidget *pHud = pMan->GetHudUserWidget();
	UCanvasPanel *parentPanel = pHud ? Cast<UCanvasPanel>(pHud->GetRootWidget()) : NULL;
	if (!parentPanel)
	{
		return;
	}

	FVector2D AttachPointScreenPosition;
	FVector AttachPointWorldPosition = worldPos;
	APlayerController *PlayerController = UGameplayStatics::GetPlayerController(_pOwner.Get(), 0);
	bool bSuc = PlayerController->ProjectWorldLocationToScreen(AttachPointWorldPosition, AttachPointScreenPosition);
	if (!bSuc)
	{
		return;
	}

	Entry *ent = NULL;
	if (_UnusedEntryArr.Num() > 0)
	{
		ent = _UnusedEntryArr.Pop();
		if (ent == nullptr)
		{
			UE_LOG(LogTemp,Log,TEXT("ent == nullptr"));
			ent = new Entry;
		}
	}
	else
	{
		ent = new Entry;
	}

	float ViewportScale = UWidgetLayoutLibrary::GetViewportScale(_pOwner.Get());
	FVector2D unscaledViewportOffset = AttachPointScreenPosition / ViewportScale;

	ent->screenOffset = unscaledViewportOffset + offset;
	int32 UnusedEffectNum = _UnusedEffectArr.Num();
	if (UnusedEffectNum > 0)
	{
		ent->effect = _UnusedEffectArr.Pop();
	}
	else
	{
		UClass * Class = LoadObject<UClass>(0 , TEXT("/Game/UI/UMG/HUD_Effect.HUD_Effect_C")); // TEXT("/Game/UI/UMG/HUDRoot.HUDRoot_C"));
		if (Class)
		{
			//UWidgetBlueprintGeneratedClass *cls = Cast<UWidgetBlueprintGeneratedClass>(pUserWidget->GetClass
			//int32 aniNum = cls->Animations.Num();
			//UE_LOG(LogTemp , Log , TEXT("aniNum = %d"),aniNum);
			//UClass *Class = Obj->GetClass();
			UWorld * world = AAzureEntryPoint::Instance->GetWorld();
			UUserWidget *pUserWidget = ::CreateWidget<UUserWidget>(world , Class);
			if (pUserWidget)
			{
				pUserWidget->Initialize();
				//UWidget *wid = pWidget->FindDirect(*effectUIPath);
				ent->effect = pUserWidget;
			}
		}
	}
	if (ent->effect.IsValid())
	{
		ent->effect->SetVisibility(ESlateVisibility::Collapsed);
		//ent->effect->SetVisibility(ESlateVisibility::HitTestInvisible);
		UCanvasPanelSlot *Slot = parentPanel->AddChildToCanvas(ent->effect.Get());
		if (Slot)
		{
			Slot->SetAnchors(hud_anchor);
			Slot->SetAlignment(FVector2D(0.5 , 0.5));
			Slot->SetOffsets(FMargin(0 , 0));
			Slot->SetAutoSize(true);
			Slot->SetZOrder(effect_ZOrder);
		}
	}


	TArray<FString> texts;
	if (multiSegTimeLine->verbatim)// ����
	{
		int32 txtLen = InText.Len();
		ent->labels.SetNum(txtLen);// �����ַ�������ô��Ŀռ�
		TArray<TCHAR> charArray = InText.GetCharArray();
		for (int32 i = 0 ; i < charArray.Num() - 1 ; ++i)
		{
			TCHAR chr = charArray[i];
			FString tmp(1 , &chr);
			texts.Add(tmp);
		}
	}
	else
	{
		ent->labels.SetNum(1);// ����һ���ռ�
		texts.Add(InText);
	}

	{
		float width = fontSize * 0.5f * InText.Len() + multiSegTimeLine->spacing * (InText.Len() - 1);
		float labelOffsetX = -width * 0.5f;

		//FVector2D lastLabelSize(width * 0.5f , 0.0f);
		for (int32 i = 0 ; i < ent->labels.Num() ; ++i)
		{
			LableInfo &label = ent->labels[i];
			if (!label.label.IsValid())
			{
				if (_UnusedLabelArr.Num() > 0)
				{
					label.label = _UnusedLabelArr.Pop();
					//UE_LOG(LogAzure, Warning, TEXT("_UnusedLabelArr.Pop()=%d"), _UnusedLabelArr.Num());
				}
				else
				{
					label.label = NewObject<UAzureBMText>(parentPanel->GetOuter(), UAzureBMText::StaticClass());
					UCanvasPanelSlot *Slot = parentPanel->AddChildToCanvas(label.label.Get());
					if (Slot)
					{
						Slot->SetAnchors(hud_anchor);
						Slot->SetAlignment(FVector2D(0.5, 0.5));
						Slot->SetOffsets(FMargin(0, 0));
						Slot->SetAutoSize(true);
						Slot->SetZOrder(txt_ZOrder);
					}
				}
			}

			label.label->SetBMFont(Font);
			label.label->SetFontSize(fontSize);
			label.label->SetText(texts[i]);
			label.label->SetVisibility(ESlateVisibility::HitTestInvisible);
			label.label->SetRenderTransformPivot(FVector2D(0.5 , 0.5));
			label.label->SetRenderScale(FVector2D(1.0 , 1.0));
			label.label->SetOpacity(alpha);

			// ����Ƕ�� Label ��Ҫƫ��
			// Ŀǰֻ��Ҫ����
			FVector2D labelSize = label.label->GetDesiredSize();
			label.labelOffset.X = labelOffsetX;
			labelOffsetX += fontSize * 0.5f + multiSegTimeLine->spacing;// labelSize.X;

			label.scale = scale;
			label.alpha = alpha;
			label.offset.X = 0;
			label.offset.Y = 0;
		}
	}
	LableInfo &label = ent->labels[0];
	FVector2D labelsize = label.label->GetDesiredSize();
	FVector2D ViewportSize = UWidgetLayoutLibrary::GetViewportSize(_pOwner.Get());
	float bottom = ViewportSize.Y / ViewportScale;
	if (ent->screenOffset.Y + labelsize.Y> bottom)
	{
		ent->screenOffset.Y = bottom - labelsize.Y;
	}

	//// ���ƫ����
	//FVector2D offsetTemp;
	//FMath::SinCos(&offsetTemp.Y , &offsetTemp.X , direction);// ���ݴ���ķ���
	//offsetTemp *= rand_radius;
	//ent->screenOffset += offsetTemp;
	ent->screenOffset -= unscaledViewportOffset;// ȥ���ӿڵ�ƫ�� ����ΪҪ�������������Ч��

	ent->elapsedTime = 0;
	ent->timeLine = multiSegTimeLine;
	ent->worldOffset = AttachPointWorldPosition;

	ent->initial_X		= 0;
	ent->initial_Y		= 0;
	ent->initial_Scale	= scale;
	ent->initial_Alpha	= alpha;

	_EntryArr.Add(ent);
}

void UAzureMultiSegmentKeysHudText::Entry::ApplyOffset()
{
	FMargin effectMargin(FMargin::ZeroMargin);
	for (int32 i = 0 ; i < labels.Num() ; ++i)
	{
		LableInfo &label = labels[i];
		if (label.label.IsValid())
		{
			UCanvasPanelSlot *CanvasPanelSlot = Cast<UCanvasPanelSlot>(label.label->Slot);
			if (CanvasPanelSlot)
			{
				FMargin Margin = CanvasPanelSlot->GetOffsets();
				Margin.Left = label.offset.X + label.labelOffset.X + screenOffset.X;
				Margin.Top  = label.offset.Y + label.labelOffset.Y + screenOffset.Y;
				CanvasPanelSlot->SetOffsets(Margin);
				effectMargin.Left += label.offset.X + label.labelOffset.X;
				effectMargin.Top  += label.offset.Y + label.labelOffset.Y;
			}
		}
	}

	if (effect.IsValid())
	{
		float num = labels.Num();
		effectMargin.Left /= num;
		effectMargin.Top  /= num;

		effectMargin.Left  += screenOffset.X;
		effectMargin.Top   += screenOffset.Y;
		UCanvasPanelSlot *CanvasPanelSlot = Cast<UCanvasPanelSlot>(effect->Slot);
		CanvasPanelSlot->SetOffsets(effectMargin);
	}

}

void UAzureMultiSegmentKeysHudText::Entry::Reset()
{
	labels.Empty();

	elapsedTime = 0;	// ��ȥʱ�䣬ÿ֡�仯
	lastTime = 0;		// ��һ֡ʱ�䣬ÿ֡�仯
}

