// Fill out your copyright notice in the Description page of Project Settings.

#include "GUIActor.h"
#include "Azure.h"
#include "../wLua/LuaInterface.h"
#include "AzureEntryPoint.h"
#include "Components/WidgetComponent.h"


// Sets default values
AGUIActor::AGUIActor()
{
 	// Set this actor to call Tick() every frame.  You can turn this off to improve performance if you don't need it.
	PrimaryActorTick.bCanEverTick = true;

}

// Called when the game starts or when spawned
void AGUIActor::BeginPlay()
{
	Super::BeginPlay();
	
}

// Called every frame
void AGUIActor::Tick( float DeltaTime )
{
	Super::Tick( DeltaTime );

}

void AGUIActor::BeginDestroy()
{
	Super::BeginDestroy();
}

TMap<int, FString>	AGUIActor::MyTestFunction(const TArray<int>& a, const TMap<FString, int32>& b)
{
	TMap<int, FString> ret;
	return ret;
}


void AGUIActor::MyTestFunction2(FAzureLuaFunction func)
{

}