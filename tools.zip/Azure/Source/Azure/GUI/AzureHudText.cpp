#include "AzureHudText.h"
#include "CanvasPanel.h"
#include "CanvasPanelSlot.h"
#include "GUI/AzureHudTextMan.h"
#include "AzureEntryPoint.h"
#include "Kismet/GameplayStatics.h"
#include "WidgetLayoutLibrary.h"

FAnchors hud_anchor = FAnchors(0, 0, 0, 0);

UAzureHudText::UAzureHudText()
{

}

UAzureHudText::~UAzureHudText()
{
	for (Entry *ent : EntryArr)
	{
		if (ent->label.IsValid())
			ent->label->RemoveFromParent();
		delete ent;
	}
	EntryArr.Empty();
	for (Entry *ent : UnusedEntryArr)
	{
		if (ent->label.IsValid())
			ent->label->RemoveFromParent();
		delete ent;
	}
	UnusedEntryArr.Empty();

	pOwner = nullptr;
	/*
	if (CanvasRoot.IsValid())
		CanvasRoot->RemoveFromParent();
	CanvasRoot = NULL;*/
}

//void UAzureHudText::SetActive(bool active)
//{
//	bActive = active;
	/*
	if (CanvasRoot.IsValid())
	{
		CanvasRoot->SetVisibility(active ? ESlateVisibility::HitTestInvisible : ESlateVisibility::Collapsed);
	}*/
//}

void UAzureHudText::Init(UCanvasPanel *parentPanel)
{
	/*
	if (!parentPanel)
		return;
	if (!CanvasRoot.IsValid())
	{
		UObject *WidgetTree = parentPanel->GetOuter();
		if (!WidgetTree)
			return;
		CanvasRoot = NewObject<UCanvasPanel>(WidgetTree, UCanvasPanel::StaticClass());
		UCanvasPanelSlot *Slot = parentPanel->AddChildToCanvas(CanvasRoot.Get());
		if (Slot)
		{
			Slot->SetAlignment(FVector2D(0.5, 0.5));
			Slot->SetOffsets(FMargin(0, 0));
			Slot->SetSize(FVector2D(4000,4000));
		}
		SetActive(false);
	}*/
}
/*
void UAzureHudText::SetOffset(const FVector2D &offset)
{
	curoffset.Set(offset.X, offset.Y);
	
	if (CanvasRoot.IsValid())
	{
		UCanvasPanelSlot *CanvasPanelSlot = Cast<UCanvasPanelSlot>(CanvasRoot->Slot);
		if (CanvasPanelSlot)
		{
			FMargin Margin = CanvasPanelSlot->GetOffsets();
			Margin.Left = offset.X;
			Margin.Top = offset.Y;
			CanvasPanelSlot->SetOffsets(Margin);
		}
	}
}
*/
void UAzureHudText::Clear()
{
	for (Entry *ent : EntryArr)
	{
		if (ent->label.IsValid())
			ent->label->SetVisibility(ESlateVisibility::Collapsed);
		UnusedEntryArr.Add(ent);
	}
	EntryArr.Empty();
	pOwner = nullptr;
}

void UAzureHudText::Update()
{
	double curTime = FPlatformTime::Seconds();
	for (int i = EntryArr.Num() - 1;i>=0;--i)
	{
		Entry *ent = EntryArr[i];
		float totalEnd = ent->liftTime;
		double currentTime = curTime - ent->bornTime;
		if (currentTime > totalEnd)
		{
			EntryArr.RemoveAt(i);
			if (ent->label.IsValid())
				ent->label->SetVisibility(ESlateVisibility::Collapsed);
			UnusedEntryArr.Add(ent);
			continue;
		}
		
		float moveTime = currentTime;
		if (currentTime > ent->moveTime)
		{
			moveTime = ent->moveTime;
		}
		ent->offset.X = ent->moveSpeed.X * moveTime;
		ent->offset.Y = ent->moveSpeed.Y * moveTime;
		ent->ApplyOffset();

		/*
		float alpha = 1.0;
		float prograss = currentTime / totalEnd;
		if (prograss > 0.8)
		{
			alpha = (1.0 - prograss) / 0.2;
		}*/
		if (ent->label.IsValid())
		{
			//ent->label->SetOpacity(alpha);
			float scale = ent->scaleTo;
			if (currentTime < ent->scaleFromTime)
			{
				scale = ent->scaleFrom + currentTime / ent->scaleFromTime * (1 - ent->scaleFrom);
			}
			else if(currentTime < ent->scaleFromTime + ent->scaleToTime)
			{
				scale = ent->scaleTo + (ent->scaleFromTime + ent->scaleToTime - currentTime) / ent->scaleToTime * (1 - ent->scaleTo);
			}
			ent->label->SetRenderScale(FVector2D(scale, scale));
		}
	}
	/*
	if (EntryArr.Num() == 0)
	{
		SetActive(false);
		return;
	}
		*/
	/*
	float offsetY = 0;

	for (Entry *ent : EntryArr)
	{
		if (ent->canOverlapped)
			ent->ApplyOffset();
		else
		{
			ent->offset.Y = offsetY;
			ent->ApplyOffset();
			if (ent->label.IsValid())
				offsetY += Cast<UCanvasPanelSlot>(ent->label->Slot)->GetOffsets().Bottom;
		}

	}*/
}

void UAzureHudText::CreateEntry(FString &InText, UAzureBMFont *Font, int fontSize, float lifeTime, FVector2D &velocity, float moveTime, float scaleFrom, float scaleFromTime, float scaleTo, float scaleToTime, FVector &Woffset, FVector2D &offset)
{
	if (!AAzureEntryPoint::Instance)
		return;

	AzureHudTextMan *pMan = AAzureEntryPoint::Instance->GetHudTextMan();
	if (!pMan)
		return;

	if (!pOwner.IsValid())
		return;

	UUserWidget *pHud = pMan->GetHudUserWidget();
	UCanvasPanel *parentPanel = pHud ? Cast<UCanvasPanel>(pHud->GetRootWidget()) : NULL;
	if (!parentPanel)
		return;
	FVector AttachPointWorldPosition = Woffset + pOwner->GetActorLocation();
	FVector2D AttachPointScreenPosition;
	APlayerController *PlayerController = UGameplayStatics::GetPlayerController(pOwner.Get(), 0);
	bool bSuc = PlayerController->ProjectWorldLocationToScreen(AttachPointWorldPosition, AttachPointScreenPosition);
	if (!bSuc)
		return;
	Entry *ent = NULL;
	if (UnusedEntryArr.Num() > 0)
	{
		ent = UnusedEntryArr.Pop();
	}
	else
	{
		ent = new Entry;
	}
	ent->bornTime = FPlatformTime::Seconds();
	if (!ent->label.IsValid())
	{
		ent->label = NewObject<UAzureBMText>(parentPanel->GetOuter(), UAzureBMText::StaticClass());
		UCanvasPanelSlot *Slot = parentPanel->AddChildToCanvas(ent->label.Get());
		if (Slot)
		{
			Slot->SetAnchors(hud_anchor);
			Slot->SetAlignment(FVector2D(0.5, 0.5));
			Slot->SetOffsets(FMargin(0, 0));
			Slot->SetAutoSize(true);
		}
	}
	float Scale = UWidgetLayoutLibrary::GetViewportScale(pOwner.Get());
	ent->bornoffset = AttachPointScreenPosition/ Scale + offset;
	
	ent->label->SetBMFont(Font);
	ent->label->SetFontSize(fontSize);
	ent->label->SetText(InText);
	ent->label->SetVisibility(ESlateVisibility::HitTestInvisible);
	ent->label->SetRenderTransformPivot(FVector2D(0.5, 0));

	FVector2D labelsize = ent->label->GetDesiredSize();
	FVector2D ViewportSize = UWidgetLayoutLibrary::GetViewportSize(pOwner.Get());
	float bottom = ViewportSize.Y / Scale;
	if (ent->bornoffset.Y + labelsize.Y> bottom)
		ent->bornoffset.Y = bottom - labelsize.Y;

	ent->liftTime = lifeTime;
	ent->moveSpeed = velocity;
	ent->moveTime = moveTime;
	ent->scaleFrom = scaleFrom;
	ent->scaleFromTime = scaleFromTime;
	ent->scaleTo = scaleTo;
	ent->scaleToTime = scaleToTime;

	EntryArr.Add(ent);
}

void UAzureHudText::Entry::ApplyOffset()
{
	if (label.IsValid())
	{
		UCanvasPanelSlot *CanvasPanelSlot = Cast<UCanvasPanelSlot>(label->Slot);
		if (CanvasPanelSlot)
		{
			FMargin Margin = CanvasPanelSlot->GetOffsets();
			Margin.Left = offset.X + bornoffset.X;
			Margin.Top = offset.Y + bornoffset.Y;
			CanvasPanelSlot->SetOffsets(Margin);
		}
	}
}
