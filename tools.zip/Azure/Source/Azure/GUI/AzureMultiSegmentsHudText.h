#pragma once
#include "CoreMinimal.h"
#include "AzureBMText.h"
class UCanvasPanel;
class UAzureBMFont;
struct UAzureMultiSegments;

class UAzureMultiSegmentsHudText
{
public:
	struct Entry
	{
		float elapsedTime = 0;
		FVector2D offset;
		FVector2D bornoffset;
		TWeakObjectPtr<UAzureBMText> label;
		FVector2D moveSpeed;
		float scale;
		float alpha;
		UAzureMultiSegments *multiSegs;
		int segIndex;

		Entry() { label = nullptr; }
		void ApplyOffset();
	};

	virtual ~UAzureMultiSegmentsHudText();
	void Clear();
	void SetOwner(AActor *pActor) { pOwner = pActor; }

	void Update(float DeltaTime);
	void CreateEntry(FString &InText, UAzureBMFont *Font, int fontSize, float scale, float alpha, FVector2D &velocity, UAzureMultiSegments *multiSegs, FVector &Woffset, FVector2D &offset);

private:
	bool bActive;
	TWeakObjectPtr<AActor> pOwner;

	TArray<Entry *> UnusedEntryArr;
	TArray<Entry *> EntryArr;
};