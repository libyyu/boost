#pragma once
#include "CoreMinimal.h"
#include "AzureBMText.h"
class UCanvasPanel;
class UAzureBMFont;

class UAzureHudText
{
public:

	struct Entry
	{
		double bornTime;
		FVector2D offset;
		FVector2D bornoffset;
		TWeakObjectPtr<UAzureBMText> label;

		float liftTime = 0;
		FVector2D moveSpeed;
		float moveTime = 0;
		float scaleFrom = 0;
		float scaleFromTime = 0;
		float scaleTo = 0;
		float scaleToTime = 0;
		Entry() { label = nullptr; }
		void ApplyOffset();
	};
	UAzureHudText();
	~UAzureHudText();

	//void SetActive(bool active);
	//bool IsActive() { return bActive; }
	bool HasEntry() { return EntryArr.Num() > 0; }
	void SetOwner(AActor *pActor) { pOwner = pActor; }
	void Init(UCanvasPanel *parentPanel);
	//void SetOffset(const FVector2D &offset);
	void Clear();
	void Update();

	void CreateEntry(FString &InText, UAzureBMFont *Font, int fontSize, float lifeTime, FVector2D &velocity, float moveTime, float scaleFrom, float scaleFromTime, float scaleTo, float scaleToTime, FVector &Woffset, FVector2D &offset);

private:
	bool bActive;
	//TWeakObjectPtr<UCanvasPanel> CanvasRoot;
	TWeakObjectPtr<AActor> pOwner;

	TArray<Entry *> UnusedEntryArr;
	TArray<Entry *> EntryArr;
};