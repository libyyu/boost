#include "AzureObjMsgHandler.h"
#include "Widget.h"
#include "AzureEntryPoint.h"
#include "wLua/LuaInterface.h"
#include "UMGcustom/Public/UMGCustomStatics.h"

//����֧�ֵ��¼�����������֤����
const static std::unordered_set<std::string> s_msgNames = {
	"onSubmit",
	"onTextChange",
	"onClick",
	"onPress",
	"onLongPress",
	"onKey",
	"onToggle",
	"onScroll",
	"onScrollBegin",
	"onScrollEnd",
	"onInertialScrollEnd",
	"onSelect",
	"onSpringFinish",
	"onDragStart",
	"onDrag",
	"onDragOver",
	"onDragIn",
	"onDragOut",
	"onDragEnd",
	"onDragCancel",
	"onDoubleClick",
	"onEditBoxFocusReceive",
	"onEditBoxFocusLost",
	"onTweenerFinish",
	"onPlayTweenFinish",
	"ScrollViewOnDragStarted",
	"ScrollViewOnDragFinished",
	"OnClickHTML",
	"onUIParticlePlay",
	"onUIParticleEnd",
	"onScrollListInitFinish",
	"onTouchEvent",
	"onAnimationStarted",
	"onAnimationFinished",
	"onHovered",
	"onVirtualKeyboardShow",
	"onVirtualKeyboardHide",
	"onDynamicBlueprintEvent",
};

//���̰߳�ȫ
std::string& make_std_string(char const* str)
{
	static std::string s_str;
	s_str = str;
	return s_str;
}

class UUserWidget* AzureObjMsgHandler::getUserWidget(class  UWidget* widget)
{
	UUserWidget* userWidget = Cast<UUserWidget>(UUMGCustomStatics::GetOuterUserWidget(widget));
	return userWidget;
}

bool AzureObjMsgHandler::AddHandler(class  UWidget* widget, const char* msgName)
{
	wLua::Lua * wlua = nullptr;
	if (!AAzureEntryPoint::Instance)
		return false;

	wlua = AAzureEntryPoint::Instance->GetWLua();
	if (!wlua)
		return false;

	lua_State_Wrapper L = wlua->GetL();

	//�����ж������Ϣ���Ƿ���Ч
	if (s_msgNames.find(make_std_string(msgName)) == s_msgNames.end())
	{
		lua_pop(L, 1);
		return false;
	}

	CALLBACKLIST* callbackList = requireMsgCallbackList(widget, msgName);
	check(callbackList);

	wLua::lua_registry_handle callbackRef = wLua::lua_registry_handle::wlua_ref(L, LUA_REGISTRYINDEX);
	if (callbackRef.IsNoRef())
	{
		lua_pop(L, 1);
		return false;
	}
	
	callbackList->Add(callbackRef);
	return true;
}
void AzureObjMsgHandler::RemoveAll(class UUserWidget* userWidget, bool bOnlyUnref)
{
	RemoveAll(userWidget, false, bOnlyUnref);
}

void AzureObjMsgHandler::RemoveAll(class UUserWidget* userWidget, bool isRemovingAllOnParent, bool bOnlyUnref)
{
	if (!userWidget) return;

	UserWidget_CallbackInfo* callbackInfo = obj_callbackList.Find(userWidget);
	if (!callbackInfo)
		return;

	if (!bOnlyUnref && !isRemovingAllOnParent)	//��� parent ���� RemoveAll������ҪҲ����ɾ�����¼�� Child Set
	{
		UUserWidget* parentUserWidget = Cast<UUserWidget>(UUMGCustomStatics::GetOuterUserWidget(userWidget));
		if (parentUserWidget)
		{
			UserWidget_CallbackInfo* parentCallbackInfo = obj_callbackList.Find(parentUserWidget);
			parentCallbackInfo->childUserWidgetSet.Remove(userWidget);
		}
	}

	for (UUserWidget* childUserWidget : callbackInfo->childUserWidgetSet)
	{
		RemoveAll(childUserWidget, true, bOnlyUnref);
	}

	bool hasL = false;
	if (AAzureEntryPoint::Instance && AAzureEntryPoint::Instance->GetWLua())
		hasL = true;

	lua_State_Wrapper L = hasL ? AAzureEntryPoint::Instance->GetWLua()->GetL() : nullptr;

	OBJ_MSGCALLBACKLIST* callbacks = &callbackInfo->objMsgCallbackList;

	for (OBJ_MSGCALLBACKLIST::TIterator It(*callbacks); It; ++It)
	{
		MSGCALLBACKLIST& msgcallbacklist = It.Value();

		for (MSGCALLBACKLIST::TIterator It(msgcallbacklist); It; ++It)
		{
			CALLBACKLIST& callbacklist = It.Value();
			for (int i=0; i<callbacklist.Num(); ++i)
			{
				wLua::lua_registry_handle& callbackRef = callbacklist[i];
				if (!callbackRef.IsNoRef() && L)
				{
					wLua::lua_registry_handle::wlua_unref(L, LUA_REGISTRYINDEX, callbackRef);
					callbackRef.Clear();
				}
			}
		}
	}
	
	if (!bOnlyUnref)
		obj_callbackList.Remove(userWidget);
}

void AzureObjMsgHandler::RemoveAllHandlers(class UWidget* widget, bool bOnlyUnref)
{
	UUserWidget* userWidget = Cast<UUserWidget>(UUMGCustomStatics::GetOuterUserWidget(widget));
	UserWidget_CallbackInfo* callbackInfo = obj_callbackList.Find(userWidget);
	if (!callbackInfo)
		return;
	bool hasL = false;
	if (AAzureEntryPoint::Instance && AAzureEntryPoint::Instance->GetWLua())
		hasL = true;
	lua_State_Wrapper L = hasL ? AAzureEntryPoint::Instance->GetWLua()->GetL() : nullptr;
	OBJ_MSGCALLBACKLIST* callbacks = &callbackInfo->objMsgCallbackList;

// 	for (auto& msgName : s_msgNames)
// 	{
// 		RemoveAllHandlers(widget, msgName.c_str());
// 	}
	TArray< TWeakObjectPtr<class  UWidget> > InValidArr;
	for (OBJ_MSGCALLBACKLIST::TIterator It(*callbacks); It; ++It)
	{
		TWeakObjectPtr<class  UWidget>& ObjectPtr = It.Key();
		if (ObjectPtr.IsValid())
		{
			UWidget* pWidget = ObjectPtr.Get();
			if (pWidget == widget)
			{
				for (auto& item : (*callbacks)[ObjectPtr])
				{
					for (auto& handle : item.Value)
					{
						if (!handle.IsNoRef() && L)
						{
							wLua::lua_registry_handle::wlua_unref(L, LUA_REGISTRYINDEX, handle);
							handle.Clear();
						}
					}
				}

				if (!bOnlyUnref)
					(*callbacks).Remove(ObjectPtr);
				break;
			}
		}
		else
		{
			InValidArr.Add(ObjectPtr);
		}
	}
	for (auto& p : InValidArr)
	{
		for (auto& item : (*callbacks)[p])
		{
			for (auto& handle : item.Value)
			{
				if (!handle.IsNoRef() && L)
				{
					wLua::lua_registry_handle::wlua_unref(L, LUA_REGISTRYINDEX, handle);
					handle.Clear();
				}
			}
		}

		if (!bOnlyUnref)
			(*callbacks).Remove(p);
	}
}

void AzureObjMsgHandler::RemoveAllHandlers(class UWidget* widget, const char* msgName, bool bOnlyUnref)
{
	bool hasL = false;
	if (AAzureEntryPoint::Instance && AAzureEntryPoint::Instance->GetWLua())
		hasL = true;

	lua_State_Wrapper	L = hasL ? AAzureEntryPoint::Instance->GetWLua()->GetL() : nullptr;

	CALLBACKLIST* callbackList = getMsgCallbackList(widget, msgName);
	if (callbackList)
	{
		for (int i = 0; i < callbackList->Num(); ++i)
		{
			wLua::lua_registry_handle& callbackRef = (*callbackList)[i];
			if (!callbackRef.IsNoRef() && L)
			{
				wLua::lua_registry_handle::wlua_unref(L, LUA_REGISTRYINDEX, callbackRef);
				callbackRef.Clear();
			}
		}

		if (!bOnlyUnref)
		{
			//���
			callbackList->Empty();
		}
	}
}

void AzureObjMsgHandler::CallLua(class wLua::Lua* wlua, class  UWidget* widget, const char* msgName, int extraParamCount)
{
	ensure(s_msgNames.find(msgName) != s_msgNames.end());	//���� AzureMsg ��Ӧ���� s_msgNames ��
	lua_State_Wrapper L = wlua->GetL();

	//-> ..., extraParams
	CALLBACKLIST* callbackList = getMsgCallbackList(widget, msgName);
	if (callbackList)
	{
		bool NeedRemove = false;

		lua_checkstack(L, extraParamCount + 3);
		wLua::FLuaUtils::ReturnUObject(L, widget);	//-> ..., extraParams, widget

		for (int i=0; i<callbackList->Num(); ++i)
		{
			wLua::lua_registry_handle callbackRef = (*callbackList)[i];
			if (!callbackRef.IsNoRef())
			{
				lua_rawgeti(L, LUA_REGISTRYINDEX, callbackRef);	//-> ..., extraParams, widget, callback
				lua_pushvalue(L, -2);	//-> ..., extraParams, widget, callback, widget
				for (int iExtra=0; iExtra<extraParamCount; ++iExtra)
				{
					lua_pushvalue(L, -extraParamCount-3);
				}
				//-> ..., extraParams, widget, callback, widget, extraParams
				if (!wlua->PCall(1 + extraParamCount, 0))
				{
					lua_pop(L, 1);
				}
				//-> ..., extraParams, widget
			}
			else
			{
				NeedRemove = true;
			}
		}

		lua_pop(L, 1);			//-> ..., extraParams

		if (NeedRemove)
			callbackList->RemoveAll([](wLua::lua_registry_handle& callbackRef) { return callbackRef.IsNoRef(); });
	}
}

AzureObjMsgHandler::UserWidget_CallbackInfo* AzureObjMsgHandler::requireUserWidgetCallbackInfo(UUserWidget* userWidget)
{
	UserWidget_CallbackInfo* callbackInfo = obj_callbackList.Find(userWidget);
	if (!callbackInfo)
	{
		obj_callbackList.Emplace(userWidget);
		
		UUserWidget* parentUserWidget = Cast<UUserWidget>(UUMGCustomStatics::GetOuterUserWidget(userWidget));
		if (parentUserWidget)
		{
			UserWidget_CallbackInfo* parentCallbackInfo = requireUserWidgetCallbackInfo(parentUserWidget);
			parentCallbackInfo->childUserWidgetSet.Add(userWidget);
		}
		callbackInfo = obj_callbackList.Find(userWidget);
	}
	return callbackInfo;
}

AzureObjMsgHandler::CALLBACKLIST* AzureObjMsgHandler::requireMsgCallbackList(class  UWidget* widget, char const* msgName)
{
	UUserWidget* userWidget = getUserWidget(widget);
	UserWidget_CallbackInfo* callbackInfo = requireUserWidgetCallbackInfo(userWidget);
	OBJ_MSGCALLBACKLIST* callbacks = &callbackInfo->objMsgCallbackList;
	MSGCALLBACKLIST* callbacklist = callbacks->Find(widget);
	if (!callbacklist)
	{
		TWeakObjectPtr<class  UWidget> p = widget;
		MSGCALLBACKLIST& cl = callbacks->Add(p, MSGCALLBACKLIST());
		callbacklist = &cl;
	}

	CALLBACKLIST* result = callbacklist->Find(make_std_string(msgName));
	if (!result)
	{
		CALLBACKLIST& cl = callbacklist->Add(make_std_string(msgName), CALLBACKLIST());
		result = &cl;
	}

	return result;
}

AzureObjMsgHandler::CALLBACKLIST* AzureObjMsgHandler::getMsgCallbackList(class  UWidget* widget, const char* msgName)
{
	UUserWidget* userWidget = getUserWidget(widget);
	UserWidget_CallbackInfo* callbackInfo = obj_callbackList.Find(userWidget);
	if (!callbackInfo)
	{
		return nullptr;
	}
	OBJ_MSGCALLBACKLIST* callbacks = &callbackInfo->objMsgCallbackList;

	MSGCALLBACKLIST* callbacklist = callbacks->Find(TWeakObjectPtr<class  UWidget>(widget));
	if (!callbacklist)
	{
		return nullptr;
	}

	CALLBACKLIST* result = callbacklist->Find(make_std_string(msgName));
	if (!result)
	{
		return nullptr;
	}

	return result;
}