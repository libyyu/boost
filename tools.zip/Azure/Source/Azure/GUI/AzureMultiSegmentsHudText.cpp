#include "AzureMultiSegmentsHudText.h"
#include "CanvasPanel.h"
#include "CanvasPanelSlot.h"
#include "GUI/AzureHudTextMan.h"
#include "AzureEntryPoint.h"
#include "Kismet/GameplayStatics.h"
#include "WidgetLayoutLibrary.h"
#include "UE4Related.h"
#include "../AzureCommonDef.h"
#include "Kismet/KismetSystemLibrary.h"
#include "AzureUtility.h"

extern FAnchors hud_anchor;

UAzureMultiSegmentsHudText::~UAzureMultiSegmentsHudText()
{
	for (Entry *ent : EntryArr)
	{
		if (ent->label.IsValid())
			ent->label->RemoveFromParent();
		delete ent;
	}
	EntryArr.Empty();
	for (Entry *ent : UnusedEntryArr)
	{
		if (ent->label.IsValid())
			ent->label->RemoveFromParent();
		delete ent;
	}
	UnusedEntryArr.Empty();

	pOwner = nullptr;
}

void UAzureMultiSegmentsHudText::Clear()
{
	for (Entry *ent : EntryArr)
	{
		if (ent->label.IsValid())
			ent->label->SetVisibility(ESlateVisibility::Collapsed);
		UnusedEntryArr.Add(ent);
	}
	EntryArr.Empty();
	pOwner = nullptr;
}

void UAzureMultiSegmentsHudText::Update(float dt)
{
	for (int i = EntryArr.Num() - 1;i>=0;--i)
	{
		Entry *ent = EntryArr[i];
		UAzureMultiSegment *seg = &(ent->multiSegs->segs[ent->segIndex]);
		ent->elapsedTime = dt + ent->elapsedTime;
		float curFrameInterval = dt;
		if (ent->elapsedTime >= seg->duration)
		{
			float lastPiece = ent->elapsedTime - seg->duration;
			ent->moveSpeed.Y += seg->accelerationY * lastPiece;
			ent->scale += seg->scaleSpd * lastPiece;
			ent->scale = FMath::Max(ent->scale, 0.0f);
			ent->alpha = FMath::Clamp(ent->alpha + seg->alphaSpd * lastPiece, 0.f, 1.0f);

			ent->elapsedTime = 0;
			ent->segIndex += 1;
			if (ent->segIndex >= ent->multiSegs->segs.Num())
			{
				EntryArr.RemoveAt(i);
				if (ent->label.IsValid())
					ent->label->SetVisibility(ESlateVisibility::Collapsed);
				UnusedEntryArr.Add(ent);
				continue;
			}

			curFrameInterval = lastPiece;
			//seg = &(ent->multiSegs->segs[ent->segIndex]);
		}
		else
		{
			ent->moveSpeed.Y += seg->accelerationY * curFrameInterval;
			ent->scale += seg->scaleSpd * curFrameInterval;
			ent->scale = FMath::Max(ent->scale, 0.0f);
			ent->alpha = FMath::Clamp(ent->alpha + seg->alphaSpd * curFrameInterval, 0.0f, 1.0f);
		}

		ent->offset.X += ent->moveSpeed.X * curFrameInterval;
		ent->offset.Y += -ent->moveSpeed.Y * curFrameInterval;
		ent->ApplyOffset();

		if (ent->label.IsValid())
		{
			ent->label->SetOpacity(ent->alpha);
			ent->label->SetRenderScale(FVector2D(ent->scale, ent->scale));
		}
	}
}

void UAzureMultiSegmentsHudText::CreateEntry(FString &InText, UAzureBMFont *Font, int fontSize, float scale, float alpha, FVector2D &velocity, UAzureMultiSegments *multiSegs, FVector &Woffset, FVector2D &offset)
{
	if (!AAzureEntryPoint::Instance)
		return;

	AzureHudTextMan *pMan = AAzureEntryPoint::Instance->GetHudTextMan();
	if (!pMan)
		return;
	if (!pOwner.Get())
		return;
	UUserWidget *pHud = pMan->GetHudUserWidget();
	UCanvasPanel *parentPanel = pHud ? Cast<UCanvasPanel>(pHud->GetRootWidget()) : NULL;
	if (!parentPanel)
		return;
	FVector AttachPointWorldPosition = Woffset + pOwner->GetActorLocation();
	FVector2D AttachPointScreenPosition;
	APlayerController *PlayerController = UGameplayStatics::GetPlayerController(pOwner.Get(), 0);
	bool bSuc = PlayerController->ProjectWorldLocationToScreen(AttachPointWorldPosition, AttachPointScreenPosition);
	if (!bSuc)
		return;
	Entry *ent = NULL;
	if (UnusedEntryArr.Num() > 0)
		ent = UnusedEntryArr.Pop();
	else
		ent = new Entry;
	
	if (!ent->label.IsValid())
	{
		ent->label = NewObject<UAzureBMText>(parentPanel->GetOuter(), UAzureBMText::StaticClass());
		UCanvasPanelSlot *Slot = parentPanel->AddChildToCanvas(ent->label.Get());
		if (Slot)
		{
			Slot->SetAnchors(hud_anchor);
			Slot->SetAlignment(FVector2D(0.5, 0.5));
			Slot->SetOffsets(FMargin(0, 0));
			Slot->SetAutoSize(true);
		}
	}
	float Scale = UWidgetLayoutLibrary::GetViewportScale(pOwner.Get());
	ent->bornoffset = AttachPointScreenPosition/ Scale + offset;
	
	ent->label->SetBMFont(Font);
	ent->label->SetFontSize(fontSize);
	ent->label->SetText(InText);
	ent->label->SetVisibility(ESlateVisibility::HitTestInvisible);
	ent->label->SetRenderTransformPivot(FVector2D(0.5, 0));
	ent->label->SetRenderScale(FVector2D(scale, scale));
	ent->label->SetOpacity(alpha);

	FVector2D labelsize = ent->label->GetDesiredSize();
	FVector2D ViewportSize = UWidgetLayoutLibrary::GetViewportSize(pOwner.Get());
	float bottom = ViewportSize.Y / Scale;
	if (ent->bornoffset.Y + labelsize.Y> bottom)
		ent->bornoffset.Y = bottom - labelsize.Y;

	ent->moveSpeed = velocity;
	ent->elapsedTime = 0;
	ent->segIndex = 0;
	ent->scale = scale;
	ent->alpha = alpha;
	ent->multiSegs = multiSegs;
	ent->offset.X = 0;
	ent->offset.Y = 0;

	EntryArr.Add(ent);
}

void UAzureMultiSegmentsHudText::Entry::ApplyOffset()
{
	if (label.IsValid())
	{
		UCanvasPanelSlot *CanvasPanelSlot = Cast<UCanvasPanelSlot>(label->Slot);
		if (CanvasPanelSlot)
		{
			FMargin Margin = CanvasPanelSlot->GetOffsets();
			Margin.Left = offset.X + bornoffset.X;
			Margin.Top = offset.Y + bornoffset.Y;
			CanvasPanelSlot->SetOffsets(Margin);
		}
	}
}
