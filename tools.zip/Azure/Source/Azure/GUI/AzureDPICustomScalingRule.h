// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Engine/DPICustomScalingRule.h"
#include "AzureDPICustomScalingRule.generated.h"

/**
 * 
 */
UCLASS()
class AZURE_API UAzureDPICustomScalingRule : public UDPICustomScalingRule
{
	GENERATED_BODY()
	
	virtual float GetDPIScaleBasedOnSize(FIntPoint Size) const;
};
