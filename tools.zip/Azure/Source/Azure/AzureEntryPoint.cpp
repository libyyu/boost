// Fill out your copyright notice in the Description page of Project Settings.

#include "AzureEntryPoint.h"
#include "wLua/LuaInterface.h"
#include "wLua/wLuaRuntime.h"
#include "wLuaIntegration.h"
#include "AzureExport.h"
#include "GUI/AzureMsgHandler.h"
#include "AFI.h"
#include "Kismet/GameplayStatics.h"

#include "FileSystem/IPlatformAFileWrapper.h"
#include "ResourceLoader/AzureResourceLoader.h"

#include "GameLogic/Util/AzureTimeManager.h"
#include "GameLogic/Input/AzureInputCtrl.h"
#include "GUI/AzureHudTextMan.h"
#include "GUI/AzureScreenBulletMan.h"
#include "AzureGameSession.h"
#include "DirClient.h"
#include "Utilities/AzureTextureStreaming.h"
#include "PlatformConfig.h"

#include "WidgetInteractionComponent.h"

#include "AzureHUD.h"
#include "Engine/Font.h"

#include "SceneView.h"
#include "Engine/LocalPlayer.h"
#include "Engine/GameViewportClient.h"
#include "Slate/SceneViewport.h"
#include "SlateSceneWidgetManager.h"
#include "Engine/UserInterfaceSettings.h"

#include "GameFramework/WorldSettings.h"
#include "Misc/CoreDelegates.h"
#include "Stats/Stats.h"
#include "ThreadJobForLua.h"
#include "GameLogic/Player/GamePlayer.h"
#include "GameLogic/Player/GamePlayer_Util.h"
#include "GameLogic/PlantMine/InstancedObjManager.h"

#include "Materials/MaterialParameterCollection.h"
#include "AkAudio/Private/MovieSceneAkAudioEventTemplate.h"
#include "AkAudio/Classes/WwiseSlateSoundDevice.h"

#include "Utilities/DeadLockDetector.h"
#include "ECDebug.h"

#ifdef TRACY_ENABLE
#include "tracy/TracyLplus.hpp"
#endif

#if WITH_EDITOR
#include "Editor/UnrealEdEngine.h"
#include "UnrealEdGlobals.h"
#endif

#if PLATFORM_ANDROID
#include "Android/AndroidJNI.h"
#include "AndroidApplication.h"
#include <jni.h>
#endif


#if !PLATFORM_DESKTOP
#include "HAL/PlatformApplicationMisc.h"
#endif

#include "ReportLog/AzureErrorOutputDevice.h"
#include "LuaUtility/LuaDynamicProtobuf.h"
#include "MainThreadTaskManager.h"
#include "AutoMove/AutoMoveExport.h"

#include "PocoLuaHelper.h"

#ifdef USE_LOONGSDK
#include "LoongSDK.h"
#endif

extern ENGINE_API void(*GPostPhysicsCustomFunc)();
extern ENGINE_API void(*GBeforeBeginFrameCustomFunc)();
extern ENGINE_API void(*GPostTickObjectsCustomFunc)();
extern ENGINE_API void(*AzureOnPendingKillPurgeFunc)();
extern ENGINE_API void(*AzurePostUpdateWorkFunc)();
extern ENGINE_API ISlateSoundDevice*(*AzureCreateSlateSoundDevice)(bool);
extern AZUREENGINE_API AFile * (*GGetAFileStreaming)(const char *);
extern AFile * AzureGetAFileStreaming(const char * szName);
extern COREUOBJECT_API void(*GAzureOnObjectCountExceedFuncPtr)();

namespace AzureLuaMemFunc
{
	extern void ReleaseLuaAllocator();
}

namespace HttpLuaWrapper
{
	extern void Clear();
}

void AzureOnObjectCountExceed()
{
	if (!AAzureEntryPoint::Instance)
		return;

	wLua::Lua * wlua = AAzureEntryPoint::Instance->GetWLua();
	lua_State_Wrapper L = AAzureEntryPoint::SafeGetL();
	if (L && wlua)
	{
		lua_getglobal(L, "OnObjectCountExceed");
		if (lua_isfunction(L, -1))
			wlua->Call(0);
		else
			lua_pop(L, 1);
	}
}

//	local function
namespace
{
	void DisableScreensaver()
	{
#if !PLATFORM_DESKTOP
		FPlatformApplicationMisc::ControlScreensaver(FPlatformApplicationMisc::EScreenSaverAction::Disable);
#endif
	}

	void EnableScreensaver()
	{
#if !PLATFORM_DESKTOP
		FPlatformApplicationMisc::ControlScreensaver(FPlatformApplicationMisc::EScreenSaverAction::Enable);
#endif
	}
}

static ISlateSoundDevice* CreateWwiseSlateSoundDevice(bool bUseWwise)
{
	if (bUseWwise)
	{
		return new FWwiseSlateSoundDevice();
	}
	else
	{
		return nullptr;
	}
}

class AzureSetSlateSoundDeviceWrapper
{
public:
	AzureSetSlateSoundDeviceWrapper()
	{
		AzureCreateSlateSoundDevice = CreateWwiseSlateSoundDevice;
	}
};

AzureSetSlateSoundDeviceWrapper tmpAzureSetSlateSoundDeviceWrapper;

AAzureEntryPoint* AAzureEntryPoint::Instance = nullptr;

void AAzureEntryPoint::PostPhysicsFunc()
{
	if (AAzureEntryPoint::Instance)
	{
		AAzureEntryPoint::Instance->LateTick(AAzureEntryPoint::Instance->m_curDeltaTime);
	}
}

void AAzureEntryPoint::BeforeBeginFrameCustomFunc()
{
	auto Inst = ThreadJobForLua::Instance();

	if (Inst != nullptr)
		Inst->WaitForJobFinish();
}

UCameraComponent* AAzureEntryPoint::GetMainCameraComponent()
{
	if (!AAzureEntryPoint::IsInit())
		return nullptr;

	APlayerController * p = AAzureEntryPoint::Instance->GetPlayerController();
	AGamePlayer *player = Cast<AGamePlayer>(p->GetPawn());
	return player ? player->GetFollowCamera() : nullptr;
}

UECCameraSpringArmComponent* AAzureEntryPoint::GetCameraSpringComponent()
{
	if (!AAzureEntryPoint::IsInit())
		return nullptr;

	APlayerController* p = AAzureEntryPoint::Instance->GetPlayerController();
	AGamePlayer* player = Cast<AGamePlayer>(p->GetPawn());
	return player ? player->GetCameraBoom() : nullptr;
}

void AAzureEntryPoint::PostTickObjectsCustomFunc()
{
	auto Inst = ThreadJobForLua::Instance();

	if (Inst != nullptr)
		Inst->StartJob();
}

void AAzureEntryPoint::PostUpdateWorkFunc()
{
	if (AAzureEntryPoint::Instance)
	{
		AAzureEntryPoint::Instance->TickPostUpdate(AAzureEntryPoint::Instance->m_curDeltaTime);
	}
}

void AAzureEntryPoint::OnPendingKillPurgeFunc()
{
	if (AAzureEntryPoint::Instance)
	{
		AAzureEntryPoint::Instance->m_bOnPendingKillPurgeFuncCalled = true;
	}
}

namespace Thread {
	extern void SetupAzureThread();
}

// Sets default values
AAzureEntryPoint::AAzureEntryPoint() :AActor(),wlua(nullptr)
{
 	// Set this actor to call Tick() every frame.  You can turn this off to improve performance if you don't need it.
	PrimaryActorTick.bCanEverTick = true;
	PrimaryActorTick.bHighPriority = true;

	//LateActorTick.InitializeDefaults();
	//LateActorTick.bCanEverTick = true;

	m_HudTextMan = new AzureHudTextMan();
	FMovieSceneAkAudioEventTemplate::AzureMovieSceneAkAudioOnPostEvent.BindStatic(AAzureEntryPoint::OnMovieSceneAKPostEvent);
}

void AAzureEntryPoint::RegisterActorTickFunctions(bool bRegister)
{
	Super::RegisterActorTickFunctions(bRegister);
	//LateActorTick.RegisterActorTickFunctions(this, bRegister);
}

void AAzureEntryPoint::ResetCameraState()
{
	/*if (CameraTarget != nullptr)
		GetPlayerController()->SetViewTarget(CameraTarget);*/
	if (wlua == nullptr)
		return;
	lua_State_Wrapper L = wlua->GetL();
	if (L == nullptr)
		return;
	lua_getglobal(L, "ResetCameraForCG");
	wlua->Call(0);
}

void AAzureEntryPoint::SetupPaths()
{
	LuaPath = "Lua";
}

void AAzureEntryPoint::SetupEntryPointConfig()
{
	lua_State_Wrapper L = wlua->GetL();
	lua_getglobal(L, "package");		//=> package
	lua_getfield(L, -1, "loaded");	//=> package, loaded
	lua_newtable(L);		//=> package, loaded, config

	lua_pushinteger(L, (int32)LuaCheckingLevel);
	lua_setfield(L, -2, "LuaCheckingLevel");

	lua_pushboolean(L, SepFile ? 1 : 0);
	lua_setfield(L, -2, "SepFile");

	lua_pushstring(L, FPlatformAFileWrapper::GetAssetsPath().c_str());
	lua_setfield(L, -2, "AssetsPath");

#if PLATFORM_IOS
	lua_pushstring(L, FPlatformAFileWrapper::GetCachePath().c_str());
#else
	lua_pushstring(L, FPlatformAFileWrapper::GetAssetsPath().c_str());
#endif
	lua_setfield(L, -2, "CachePath");

	lua_pushstring(L, FPlatformAFileWrapper::GetBackupAssetsPath().c_str());
	lua_setfield(L, -2, "BackupAssetsPath");

	lua_pushstring(L, LuaPath.c_str());
	lua_setfield(L, -2, "LuaPath");

	lua_pushstring(L, FPlatformAFileWrapper::GetPckDebugDir().c_str());
	lua_setfield(L, -2, "PckDebugDir");

	lua_pushboolean(L, NoProgramUpdate ? 1 : 0);
	lua_setfield(L, -2, "NoProgramUpdate");

	lua_pushboolean(L, NoResourceUpdate ? 1 : 0);
	lua_setfield(L, -2, "NoResourceUpdate");

	lua_pushstring(L, TCHAR_TO_UTF8(*UserName));
	lua_setfield(L, -2, "UserName");

	lua_pushstring(L, TCHAR_TO_UTF8(*Password));
	lua_setfield(L, -2, "Password");

	lua_pushstring(L, TCHAR_TO_UTF8(*ServerIP));
	lua_setfield(L, -2, "ServerIP");

	lua_pushinteger(L, ServerPort);
	lua_setfield(L, -2, "ServerPort");

	lua_pushboolean(L, ForceGuest ? 1 : 0);
	lua_setfield(L, -2, "ForceGuest");

	lua_pushboolean(L, ForceEvaluation ? 1 : 0);
	lua_setfield(L, -2, "ForceEvaluation");

	lua_pushboolean(L, isiOSOfficial ? 1 : 0);
	lua_setfield(L, -2, "isiOSOfficial");

	lua_pushboolean(L, OfficialEvaluation ? 1 : 0);
	lua_setfield(L, -2, "OfficialEvaluation");

	lua_pushboolean(L, WriteLogFile ? 1 : 0);
	lua_setfield(L, -2, "WriteLogFile");

	lua_pushinteger(L, (int32)WriteLogLevel);
	lua_setfield(L, -2, "WriteLogLevel");

	lua_pushboolean(L, CreateConsole ? 1 : 0);
	lua_setfield(L, -2, "CreateConsole");

	lua_pushboolean(L, EnableLuaPrint ? 1 : 0);
	lua_setfield(L, -2, "EnableLuaPrint");

	lua_pushboolean(L, isEnabledAndroidKeyboard ? 1 : 0);
	lua_setfield(L, -2, "isEnabledAndroidKeyboard");

	lua_pushboolean(L, DebugFlag ? 1 : 0);
	lua_setfield(L, -2, "DebugFlag");

	TMap<FString, FString> EntryPointParams;
	GenExtraEntryPointParams(EntryPointParams);
	if (EntryPointParams.Num() > 0)
	{
		lua_newtable(L);//=> package, loaded, config,t
		for (auto keyValueIt = EntryPointParams.CreateConstIterator(); keyValueIt; ++keyValueIt)
		{
			lua_pushstring(L, TCHAR_TO_UTF8(*keyValueIt.Value()));
			lua_setfield(L, -2, TCHAR_TO_UTF8(*keyValueIt.Key()));
		}
		lua_setfield(L, -2, "ExtraParams");	//=> package, loaded, config
	}

	//=> package, loaded, config
	lua_setfield(L, -2, "_EntryPointConfig");	//=> packages,loaded
	lua_pop(L, 2);
}

void AzureLog(AzureLogType logType, const char* log)
{
	switch (logType)
	{
	case AzureLogType::Log:
		UE_LOG(LogAzure, Log, TEXT("AzureMobile:@%f: %s"), AAzureEntryPoint::Instance ? AAzureEntryPoint::Instance->GetRealtimeSinceStartup() : 0, UTF8_TO_TCHAR(log));
		break;
	case AzureLogType::Warning:
		UE_LOG(LogAzure, Warning, TEXT("AzureMobile:@%f: %s"), AAzureEntryPoint::Instance ? AAzureEntryPoint::Instance->GetRealtimeSinceStartup() : 0, UTF8_TO_TCHAR(log));
		break;
	case AzureLogType::Error:
		UE_LOG(LogAzure, Error, TEXT("AzureMobile:@%f: %s"), AAzureEntryPoint::Instance ? AAzureEntryPoint::Instance->GetRealtimeSinceStartup() : 0, UTF8_TO_TCHAR(log));
		break;
	case AzureLogType::Exception:
		UE_LOG(LogAzure, Error, TEXT("AzureMobile:@%f: %s"), AAzureEntryPoint::Instance ? AAzureEntryPoint::Instance->GetRealtimeSinceStartup() : 0, UTF8_TO_TCHAR(log));
		break;
	case AzureLogType::Assert:
		UE_LOG(LogAzure, Error, TEXT("AzureMobile:@%f: %s"), AAzureEntryPoint::Instance ? AAzureEntryPoint::Instance->GetRealtimeSinceStartup() : 0, UTF8_TO_TCHAR(log));
		break;
	case AzureLogType::Fatal:
		UE_LOG(LogAzure, Fatal, TEXT("LUA:@%f: %s"), AAzureEntryPoint::Instance ? AAzureEntryPoint::Instance->GetRealtimeSinceStartup() : 0, UTF8_TO_TCHAR(log));
		break;
	}
}

void AzureException(const char* log)
{
	UE_LOG(LogAzure, Error, TEXT("AzureMobile:@%f: %s"), AAzureEntryPoint::Instance ? AAzureEntryPoint::Instance->GetRealtimeSinceStartup() : 0, UTF8_TO_TCHAR(log));
}

void a_AzureEngineLogError(const char* log)
{
	UE_LOG(LogAzure, Error, TEXT("AzureMobile:%s"), UTF8_TO_TCHAR(log));
}

void OnHandleSystemError()
{
	//崩溃发生后停止各种检查，以免崩溃处理中进程中止
	AzureDisableAllSafeChecking();

	if (!AAzureEntryPoint::Instance)
	{
		return;
	}
	
	/*
	// 崩溃时不调用Lua虚拟机了，否则可能引发进一步报错。
	wLua::Lua* wlua = AAzureEntryPoint::Instance->GetWLua();
	if (!wlua)
	{
		return;
	}
	lua_State_Wrapper L = wlua->GetL();

	// Lua的Error处理函数
	lua_getglobal(L, "OnHandleError");
	wlua->Call(0);

	// 打印调用栈
	astring stackinfo = wLua::LuaStatic::GetTraceBack(L);
	if (!stackinfo.empty())
	{
		AzureException(stackinfo.c_str());
	}

	GLog->Flush();
	*/
}

extern void StartLogLoadResNames();
extern bool EndLogLoadResNames(const char* szLogFileName);

static bool NeedRecordLoadRes()
{
	astring filepath = FPlatformAFileWrapper::GetAssetsPath() + "/trace_res.txt";
	return af_IsSepFileExist(filepath.c_str());
}

// Called when the game starts or when spawned
void AAzureEntryPoint::BeginPlay()
{
	Super::BeginPlay();

	//提供AzureEngine线程操作接口
	Thread::SetupAzureThread();

	GBeforeBeginFrameCustomFunc = BeforeBeginFrameCustomFunc;
#if UE_GAME
	GGetAFileStreaming = AzureGetAFileStreaming;
#endif
	GAzureOnObjectCountExceedFuncPtr = AzureOnObjectCountExceed;

	// register application events
	FCoreDelegates::ApplicationHasReactivatedDelegate.AddUObject(this, &AAzureEntryPoint::HandleApplicationHasReactivated);
	FCoreDelegates::ApplicationWillDeactivateDelegate.AddUObject(this, &AAzureEntryPoint::HandleApplicationWillDeactivate);
	FCoreDelegates::ApplicationHasEnteredForegroundDelegate.AddUObject(this, &AAzureEntryPoint::HandleApplicationHasEnteredForeground);
	FCoreDelegates::ApplicationWillEnterBackgroundDelegate.AddUObject(this, &AAzureEntryPoint::HandleApplicationWillEnterBackground);
	FCoreDelegates::ApplicationReceivedScreenOrientationChangedNotificationDelegate.AddUObject(this, &AAzureEntryPoint::HandleReceivedScreenOrientationChanged);
	FCoreDelegates::OnHandleSystemError.AddStatic(OnHandleSystemError);
#if UE_GAME
	FCoreDelegates::GetErrorOutputDeviceDelegate().AddRaw(FAzureErrorOutputDevice::GetLog(), &FAzureErrorOutputDevice::HandleError);
#endif
	//	disable screen saver when play game
	DisableScreensaver();

	Instance = this;
	WidgetInteractionComp = nullptr;
	m_realtimeSinceStartup = FPlatformTime::Seconds();
	m_curFrameTime = m_realtimeSinceStartup;
	m_curFrameCount = GFrameCounter;

	if (false)
	{
		FString str = FString::Printf(TEXT("joystick-1 %0.4f %0.4f"), m_curFrameTime, m_realtimeSinceStartup);
		MyPrintString(str);
	}

	ECTimerList::RegisterTimerList(&m_TimerList, this);
	ECTimerList::RegisterTimerList(&m_LateTimerList, this);

	m_PlayerController = UGameplayStatics::GetPlayerController(this, 0);

	//	disable UE4 controller LineTrace UWorld because we do it ourselves
	//	If we don't, unnecessary LineTrace will be wasted whenever a touch event is generated (for example, at frequency of 30 when we continuously move one finger on screen)
	//	see APlayerController::InputTouch and APlayerController::GetHitResultAtScreenPosition
	m_PlayerController->bEnableClickEvents = 0;
	m_PlayerController->bEnableTouchEvents = 0;
	m_PlayerController->bEnableMouseOverEvents = 0;
	m_PlayerController->bEnableTouchOverEvents = 0;

	m_PlayerController->ClientSetHUD(AAzureHUD::StaticClass());

	{
		GameViewport = GetWorld()->GetGameViewport()->GetGameViewport();
	}

	SetupPaths();

	//Init Log to AzureMobile
	if (GIsEditor)
	{
		exp_init_AzureLog((void*)AzureLog);
		exp_init_AzureException((void*)AzureException);
	}

	// Only editor create AFilePackage here, game mode will in engine init
	FPlatformAFileWrapper::Init();

	if (NeedRecordLoadRes())
	{
		StartLogLoadResNames();
	}

	//AzurePlatformConfig::Get().Init();

	AzureInputCtrl::GetInstance().ClearAllMsg();

	//	Create JoyStick after AFileWrapper Inited
	m_PlayerController->CreateTouchInterface();
	m_PlayerController->SetVirtualJoystickVisibility(false); // hide joystick at init, will be shown by game later!
	//主线程任务管理器
	TaskMan::MainThreadTaskManager::instance().init();

#if UE_BUILD_DEBUG && PLATFORM_WINDOWS
	//exp_set_is_debugbuild(true);
#endif

#if defined(AZURE_UE_TARGET_DEBUG) || defined(AZURE_UE_TARGET_DEBUGGAME)
	const bool debug = true;
#else
	const bool debug = false;
#endif
	//Init wLua
	wlua = new wLua::AzureLuaRuntime();
	wlua->Init(wLua::Lua::OPENMODEMASK::ALL, debug);
	lua_State_Wrapper L = wlua->GetL();
	
#ifdef USE_LOONGSDK
	FLoongSDKModule::instance().Init(GetWLua());
#endif
	
	wLua::LuaStatic::setLuaPath(LuaPath.c_str());
	wLua::FLuaUtils::ReturnUObject(L, this);
	lua_setglobal(L, "entryPoint");
	m_ECDebug.RegisterLogCallback(wlua);

	SetupEntryPointConfig();
	m_bInited = true;

#if PLATFORM_DESKTOP
	// show mouse
	m_PlayerController->bShowMouseCursor = 1;
	FInputModeGameAndUI InputMode;
	InputMode.SetHideCursorDuringCapture(false);
	InputMode.SetLockMouseToViewportBehavior(EMouseLockMode::DoNotLock);
	m_PlayerController->SetInputMode(InputMode);
#endif

	int top = lua_gettop(L);
	check(top == 0);
	lua_pushboolean(L, GIsEditor ? 1 : 0);
	lua_setglobal(L, "GIsEditor");

	bool GIsShipping;
#if UE_BUILD_SHIPPING
	GIsShipping = true;
#else
	GIsShipping = false;
#endif
	lua_pushboolean(L, GIsShipping ? 1 : 0);
	lua_setglobal(L, "GIsShipping");

	TMap<FString, bool> ExtraMacros;
	GenExtraGlobalVariables(ExtraMacros);
	for (TMap<FString, bool>::TConstIterator It(ExtraMacros.CreateConstIterator()); It; ++It)
	{
		lua_pushboolean(L, It->Value ? 1 : 0);
		lua_setglobal(L, TCHAR_TO_UTF8(*It->Key));
	}
	
	StartLua();

	lua_settop(L, top);
}

void AAzureEntryPoint::StartLua()
{
	wlua->DoString("require [[initgame]]");
}

wLua::Lua* AAzureEntryPoint_GetWLua()
{
	if (AAzureEntryPoint::Instance)
		return AAzureEntryPoint::Instance->GetWLua();
	return nullptr;
}

DECLARE_CYCLE_STAT(TEXT("TimerListTick"), STAT_TimerListTick, STATGROUP_AzureGroups);
DECLARE_CYCLE_STAT(TEXT("AzureInputCtrlTick"), STAT_AzureInputCtrlTick, STATGROUP_AzureGroups);
DECLARE_CYCLE_STAT(TEXT("AzureTimeManagerTick"), STAT_AzureTimeManagerTick, STATGROUP_AzureGroups);
DECLARE_CYCLE_STAT(TEXT("ScreenBulletManTick"), STAT_ScreenBulletManTick, STATGROUP_AzureGroups);
DECLARE_CYCLE_STAT(TEXT("LuaTickGame"), STAT_LuaTickGame, STATGROUP_AzureGroups);
DECLARE_CYCLE_STAT(TEXT("LuaEarlyTickGame"), STAT_LuaEarlyTickGame, STATGROUP_AzureGroups);
DECLARE_CYCLE_STAT(TEXT("LuaLateTickGame"), STAT_LuaLateTickGame, STATGROUP_AzureGroups);
DECLARE_CYCLE_STAT(TEXT("LateTimerList_Tick"), STAT_LateTimerList_Tick, STATGROUP_AzureGroups);
DECLARE_CYCLE_STAT(TEXT("LuaTickCoroutine"), STAT_LuaTickCoroutine, STATGROUP_AzureGroups);
DECLARE_CYCLE_STAT(TEXT("SlateSceneWidgetManagerTick"), STAT_SlateSceneWidgetManagerTick, STATGROUP_AzureGroups);
DECLARE_CYCLE_STAT(TEXT("InGameUpdateTick"), STAT_InGameUpdateTick, STATGROUP_AzureGroups);

// Called every frame
void AAzureEntryPoint::Tick(float DeltaTime)
{
#ifdef TRACY_ENABLE
	FrameMark
#endif
	Super::Tick(DeltaTime);

	if (DeadLockDetector::instance().IsRunning())
		DeadLockDetector::instance().Update();

	AzureResourceLoader::Get().Tick();

	GPostPhysicsCustomFunc = PostPhysicsFunc;
	GPostTickObjectsCustomFunc = PostTickObjectsCustomFunc;
	AzurePostUpdateWorkFunc = PostUpdateWorkFunc;

	m_curFrameTime = FPlatformTime::Seconds();
	m_curFrameCount = GFrameCounter;
	m_curDeltaTime = DeltaTime;

	float curTimeScale = GetEffectiveTimeDilation();
	float fOrgDeltaTime = curTimeScale > 0 ? DeltaTime / curTimeScale : DeltaTime;

	m_curVPValid = false;

	if (m_bStarted)
	{
		if (m_PlayerController)
		{
			m_PlayerController->GetPlayerViewPoint(m_curVPLocation, m_curVPRotation);
			m_curVPValid = true;
		}


		{
			SCOPE_CYCLE_COUNTER(STAT_LuaEarlyTickGame);
			lua_State_Wrapper L = wlua->GetL();
			lua_getglobal(L, "EarlyTickGame");
			lua_pushnumber(L, fOrgDeltaTime);//DeltaTime);
			wlua->Call(1);
		}
	}

	{
		SCOPE_CYCLE_COUNTER(STAT_InGameUpdateTick);
		af_InGameUpdate_Tick();
	}

	{
		SCOPE_CYCLE_COUNTER(STAT_TimerListTick);
		m_TimerList.Tick(DeltaTime, fOrgDeltaTime);
	}

	if (m_bStarted)
	{
		{
			SCOPE_CYCLE_COUNTER(STAT_AzureInputCtrlTick);
			AzureInputCtrl::GetInstance().Tick(fOrgDeltaTime);
		}

		{
			SCOPE_CYCLE_COUNTER(STAT_AzureTimeManagerTick);
			AzureTimeManager::GetInstance().Tick(fOrgDeltaTime);
		}

		if (m_ScreenBulletMan)
		{
			SCOPE_CYCLE_COUNTER(STAT_ScreenBulletManTick);
			m_ScreenBulletMan->Update(DeltaTime);
		}

		RefreshCurTimeScale(fOrgDeltaTime);

		{
			SCOPE_CYCLE_COUNTER(STAT_LuaTickGame);
			lua_State_Wrapper L = wlua->GetL();
			lua_getglobal(L, "TickGame");
			lua_pushnumber(L, fOrgDeltaTime);//DeltaTime);
			wlua->Call(1);
		}

		{
			if (m_bOnPendingKillPurgeFuncCalled)
			{
				m_bOnPendingKillPurgeFuncCalled = false;
				lua_State_Wrapper L = wlua->GetL();
				lua_getglobal(L, "OnPendingKillPurge");
				wlua->Call(0);
			}
		}
		
		AzureOnPendingKillPurgeFunc = OnPendingKillPurgeFunc;

		//轮训主线程任务
		TaskMan::MainThreadTaskManager::instance().tick();
	}

	if (wlua) {
		wLua::AzureLuaRuntime* pLua = static_cast<wLua::AzureLuaRuntime*>(wlua);
		pLua->Tick(DeltaTime);
	}
}

void AAzureEntryPoint::LateTick(float DeltaTime)
{
	float curTimeScale = GetEffectiveTimeDilation();
	float fOrgDeltaTime = curTimeScale > 0 ? DeltaTime / curTimeScale : DeltaTime;

	if (m_bStarted)
	{
		{
			SCOPE_CYCLE_COUNTER(STAT_LuaLateTickGame);
			lua_State_Wrapper L = wlua->GetL();
			lua_getglobal(L, "LateTickGame");
			lua_pushnumber(L, fOrgDeltaTime);//DeltaTime);
			wlua->Call(1);
		}
	}

	{
		SCOPE_CYCLE_COUNTER(STAT_LateTimerList_Tick);
		m_LateTimerList.Tick(DeltaTime, fOrgDeltaTime);
	}

	if (m_bInited)
	{
		lua_State_Wrapper L = wlua->GetL();
		lua_getglobal(L, "TickCoroutine");
		if (lua_isfunction(L, -1))
		{
			SCOPE_CYCLE_COUNTER(STAT_LuaTickCoroutine);
			lua_pushnumber(L, DeltaTime);
			wlua->Call(1);
		}
		else
		{
			lua_pop(L, 1);
		}
	}
}

void AAzureEntryPoint::TickPostUpdate(float DeltaSeconds)
{
	if (m_bInited)
	{
		if (!SlateSceneWidgetManager.IsValid())
		{
			SlateSceneWidgetManager = MakeShareable(new FSlateSceneWidgetManager());
			SlateSceneWidgetManager->Create(GameViewport->GetSizeXY());
		}

		if (SlateSceneWidgetManager.IsValid())
		{
			SCOPE_CYCLE_COUNTER(STAT_SlateSceneWidgetManagerTick);
			auto sz = GameViewport->GetSizeXY();
			float UserResolutionScale = GetDefault<UUserInterfaceSettings>()->GetDPIScaleBasedOnSize(sz);
			SlateSceneWidgetManager->Tick(DeltaSeconds, GameViewport->GetSizeXY(), UserResolutionScale);
		}
	}
}

ULevel* AAzureEntryPoint::AddLevelToWorld(UWorld* LevelHolder)
{
	ULevel* LevelToAdd = LevelHolder->PersistentLevel;

	if (LevelToAdd == nullptr)
		return nullptr;

	if (LevelToAdd->bIsVisible)
	{
		check(false);
		return nullptr;
	}

	UWorld* curWorld = this->GetWorld();
	if (!curWorld)
		return nullptr;

	FLevelCollection& LC = curWorld->FindOrAddCollectionByType(ELevelCollectionType::DynamicSourceLevels);
	LC.AddLevel(LevelToAdd);
	LevelToAdd->HandleLegacyMapBuildData();

	while (!LevelToAdd->bIsVisible)
	{
		curWorld->AddToWorld(LevelToAdd);
	}

	// For CG
	LevelHolder->WorldType = EWorldType::Game;
	LevelHolder->SetGameInstance(curWorld->GetGameInstance());

	return LevelToAdd;
}

void AAzureEntryPoint::RemoveLevelFromWorld(ULevel* LevelToRemove)
{
	if (!LevelToRemove->bIsVisible)
		return;

	UWorld* curWorld = this->GetWorld();
	if (!curWorld)
		return;

	FLevelCollection& LC = curWorld->FindOrAddCollectionByType(ELevelCollectionType::DynamicSourceLevels);
	LC.RemoveLevel(LevelToRemove);
	curWorld->RemoveFromWorld(LevelToRemove);
}

void AAzureEntryPoint::EndPlay(const EEndPlayReason::Type EndPlayReason)
{
	ThreadJobForLua::Destroy();
	DeadLockDetector::instance().ForceStop();
	FPlatformProcess::Sleep(0.1f); //wait for deadlock thread a moment due to L safety

	FAzureFullMipsManager::Get().Reset();

	if (m_bInited)
	{
		if (m_bStarted)
		{
			lua_State_Wrapper L = wlua->GetL();
			lua_getglobal(L, "ReleaseGame");
			wlua->Call(0);
			m_bStarted = false;
		}

		AzureResourceLoader::Get().Shutdown();

#if UE_GAME //&& !UE_BUILD_SHIPPING
		SetLuaProtobufDebug(true);
#endif
		wlua->Fini();
		delete wlua;
		wlua = nullptr;


		AzureLuaMemFunc::ReleaseLuaAllocator();

		OnEndPlayDelegate.Broadcast();

		HttpLuaWrapper::Clear();
	}

	af_CloseAllFilePackages();
	AzureGameSession::Instance().Close();
	GNET::DirClient::GetInstance().Abort();

	delete m_HudTextMan;
	m_HudTextMan = nullptr;

	delete m_ScreenBulletMan;
	m_ScreenBulletMan = nullptr;

	m_PlayerController = nullptr;

	Instance = nullptr;
	m_bInited = false;
	WidgetInteractionComp = nullptr;

	FInstancedObjManager::GetInstance().Clear();

	if (SlateSceneWidgetManager.IsValid())
	{
		SlateSceneWidgetManager->Destroy();
		SlateSceneWidgetManager.Reset();
	}

	//AzurePlatformConfig::Get().Release();
	GGetAFileStreaming = nullptr;

	// unregister application events
	FCoreDelegates::ApplicationHasReactivatedDelegate.RemoveAll(this);
	FCoreDelegates::ApplicationWillDeactivateDelegate.RemoveAll(this);
	FCoreDelegates::ApplicationReceivedScreenOrientationChangedNotificationDelegate.RemoveAll(this);

	if (NeedRecordLoadRes())
	{
		astring strLogFile = FPlatformAFileWrapper::GetAssetsPath() + "/trace_res.txt";
		EndLogLoadResNames(strLogFile.c_str());
	}

	AzureInputCtrl::GetInstance().ClearAllMsg();
	//确保销毁所有数据
	exp_ReleaseAllData();

	Super::EndPlay(EndPlayReason);
}

/** Callback for when an has been reactivated (i.e. return from sleep on iOS). */
void AAzureEntryPoint::HandleApplicationHasReactivated()
{
	DisableScreensaver();
    
    if (m_bApplicationPaused)
    {
        m_bApplicationPaused = false;
        LuaOnApplicationResume();
    }
}

/** Callback for when the application will be deactivated (i.e. sleep on iOS).*/
void AAzureEntryPoint::HandleApplicationWillDeactivate()
{
	EnableScreensaver();
    
    if (!m_bApplicationPaused)
    {
        m_bApplicationPaused = true;
        LuaOnApplicationPause();
    }
}

void AAzureEntryPoint::HandleApplicationHasEnteredForeground()
{
	//非主线程不能直接调 Lua
	//LuaOnApplicationForeground();
}

void AAzureEntryPoint::HandleApplicationWillEnterBackground()
{
	//非主线程不能直接调 Lua
	//LuaOnApplicationBackground();
}

void AAzureEntryPoint::HandleReceivedScreenOrientationChanged(int32 orientation)
{
	LuaOnScreenOrientationChanged(orientation);
}

void AAzureEntryPoint::LuaOnApplicationResume()
{
    if (m_bStarted)
    {
		lua_State_Wrapper L = wlua->GetL();
        lua_getglobal(L, "OnApplicationPause");
        lua_pushboolean(L, 0);
        wlua->Call(1);
    }
}

void AAzureEntryPoint::LuaOnApplicationPause()
{
    if (m_bStarted)
    {
		lua_State_Wrapper L = wlua->GetL();
        lua_getglobal(L, "OnApplicationPause");
        lua_pushboolean(L, 1);
        wlua->Call(1);
    }
}

void AAzureEntryPoint::LuaOnApplicationBackground()
{
	if (m_bStarted)
	{
		lua_State_Wrapper L = wlua->GetL();
		lua_getglobal(L, "OnApplicationBackground");
		lua_pushboolean(L, 1);
		wlua->Call(1);
	}
}

void AAzureEntryPoint::LuaOnApplicationForeground()
{
	if (m_bStarted)
	{
		lua_State_Wrapper L = wlua->GetL();
		lua_getglobal(L, "OnApplicationBackground");
		lua_pushboolean(L, 0);
		wlua->Call(1);
	}
}

void AAzureEntryPoint::LuaOnScreenOrientationChanged(int32 orientation)
{
	if (m_bStarted)
	{
		lua_State_Wrapper L = wlua->GetL();
		lua_getglobal(L, "OnScreenOrientationChanged");
		lua_pushnumber(L, orientation);
		wlua->Call(1);
	}
}


void AAzureEntryPoint::BeginDestroy()
{
	Super::BeginDestroy();

	m_TimerList.Clear();
	m_LateTimerList.Clear();
}

int32 GAzureStatInfoFontSize = 10;
void AAzureEntryPoint::OnDrawHUD(AHUD *HUD)
{
	if (IsShowHUD)
	{
		int32 LegacyFontSize = 10;
		UFont *LargeFont = GEngine->GetLargeFont();
		if (LargeFont)
		{
			LegacyFontSize = LargeFont->LegacyFontSize;
			LargeFont->LegacyFontSize = GAzureStatInfoFontSize;
		}
		for (auto& info : m_StatInfoList)
		{
			Cast<AAzureHUD>(HUD)->DrawDebugText(info.info, info.color, info.x, info.y, LargeFont);
		}
		if (LargeFont)
			LargeFont->LegacyFontSize = LegacyFontSize;
	}
}

bool AAzureEntryPoint::CallLuaFunctionOI(FString FunctionName, UObject* Param1, int32 Param2)
{
	if (wlua == nullptr)
		return false;
	lua_State_Wrapper L = wlua->GetL();
	if (L == nullptr)
		return false;

	int n = lua_gettop(L);
	lua_getglobal(L, TCHAR_TO_ANSI(*FunctionName));
	wLua::FLuaUtils::ReturnUObject(L, Param1);
	lua_pushnumber(L, int(Param2));
	bool ret = wlua->PCall(2,0);
	lua_settop(L, n);
	return ret;
}

FAutoConsoleVariableSink AAzureEntryPoint::CVarSink(FConsoleCommandDelegate::CreateStatic(&AAzureEntryPoint::OnCVarsChanged));

void AAzureEntryPoint::OnCVarsChanged()
{
	if (!AAzureEntryPoint::Instance) return;
	wLua::Lua * wlua = AAzureEntryPoint::Instance->GetWLua();
	if (wlua == nullptr)
		return;
	lua_State_Wrapper L = wlua->GetL();
	if (L == nullptr)
		return;
	int topBak = lua_gettop(L);
	lua_getglobal(L, "OnCVarsChanged");
	if (lua_isfunction(L, -1))
		wlua->Call(0);
	lua_settop(L, topBak);
}

void AAzureEntryPoint::OnMovieSceneAKPostEvent(AkPlayingID playingId, FString eventName, UObject * objcet)
{
	if (!AAzureEntryPoint::Instance) return;
	wLua::Lua * wlua = AAzureEntryPoint::Instance->GetWLua();
	if (wlua == nullptr)
		return;
	lua_State_Wrapper L = wlua->GetL();
	if (L == nullptr)
		return;
	int n = lua_gettop(L);
	lua_getglobal(L, "CppCall_OnMovieSceneAKPostEvent");
	lua_pushinteger(L, playingId);
	lua_pushstring(L, TCHAR_TO_UTF8(*eventName));
	wLua::FLuaUtils::ReturnUObject(L, objcet);
	wlua->Call(3);
	lua_settop(L, n);
}

AActor* AAzureEntryPoint::FindActor(const FString& name)
{
	return FindObjectFast<AActor>(GetWorld()->PersistentLevel, *name);
}

float AAzureEntryPoint::GetEffectiveTimeDilation() const
{
	if (!m_bInited)
		return 1.f;

	const AWorldSettings* pWorldSetting = GetWorldSettings();
	if (!pWorldSetting)
		return 1.f;

	return pWorldSetting->GetEffectiveTimeDilation();
}

void AAzureEntryPoint::AddScene3DWidget(TSharedRef<class SWidget> Widget, int ZOrder)
{
	if (SlateSceneWidgetManager.IsValid())
	{
		SlateSceneWidgetManager->AddWidget(Widget, ZOrder);
	}
}

void AAzureEntryPoint::RemoveScene3DWidget(TSharedRef<class SWidget> Widget)
{
	if (SlateSceneWidgetManager.IsValid())
	{
		SlateSceneWidgetManager->RemoveWidget(Widget);
	}
}

AActor* AAzureEntryPoint::GetHostModelActor()
{
	if (wlua == nullptr)
		return nullptr;
	lua_State_Wrapper L = wlua->GetL();
	if (L == nullptr)
		return nullptr;

	lua_getglobal(L, "GetHostModelActor");

	AActor* pActor = nullptr;
	bool ret = wlua->PCall(0, 1);
	if (ret)
	{
		void* pUserdata = lua_touserdata(L, -1);

		wLua::LuaUObjectUserData * userdata = (wLua::LuaUObjectUserData*)pUserdata;
		UObject* Obj = userdata != nullptr ? (UObject*)(userdata->uobj) : nullptr;
		if (Obj)
		{
			pActor = Cast<AActor>(Obj);
		}
	}
	lua_pop(L, 1);

	return pActor;
}

AActor* AAzureEntryPoint::GetHostRootActor()
{
	if (wlua == nullptr)
		return nullptr;
	lua_State_Wrapper L = wlua->GetL();
	if (L == nullptr)
		return nullptr;

	AActor* pActor = nullptr;
	lua_getglobal(L, "GetHostRootActor");
	if (wlua->PCall(0, 1))
	{
		void* pUserdata = lua_touserdata(L, -1);

		wLua::LuaUObjectUserData * userdata = (wLua::LuaUObjectUserData*)pUserdata;
		UObject* Obj = userdata != nullptr ? (UObject*)(userdata->uobj) : nullptr;
		if (Obj)
		{
			pActor = Cast<AActor>(Obj);
		}
	}
	lua_pop(L, 1);

	return pActor;
}

void AAzureEntryPoint::ChangeTimeScale(float fDestScale, float fInTime, float fKeepTime, float fOutTime)
{
	AWorldSettings *pWorldSetting = GetWorldSettings();
	if (!pWorldSetting)
		return;
	if (fDestScale < s_fTimeScaleMin) // 不能过小！否则无法反算出RealDeltaTime
		fDestScale = s_fTimeScaleMin;
	m_fDestTimeScale = fDestScale;

	m_fTimeScaleInDur = fInTime;
	m_fTimeScaleKeepDur = fKeepTime;
	m_fTimeScaleOutDur = fOutTime;

	m_fTimeScalePlayedTime = 0;
	m_TimeScaleTransStage = TimeScaleStage::ZoomIn;
	m_fTimeScaleTransDelta = m_fTimeScaleInDur > 0 ? (m_fDestTimeScale - pWorldSetting->TimeDilation) / m_fTimeScaleInDur : 0;

	float fOrgDeltaTime = 0;
	RefreshCurTimeScale(fOrgDeltaTime);
}

void AAzureEntryPoint::RefreshCurTimeScale(float fDeltaTime)
{
	return;
	AWorldSettings *pWorldSetting = GetWorldSettings();
	if (!pWorldSetting)
		return;

	if (m_TimeScaleTransStage == TimeScaleStage::None) {
		if (pWorldSetting->TimeDilation != 1)
			pWorldSetting->SetTimeDilation(1);
		return;
	}

	m_fTimeScalePlayedTime += fDeltaTime;
	if (m_TimeScaleTransStage == TimeScaleStage::ZoomIn)
	{
		if (m_fTimeScalePlayedTime >= m_fTimeScaleInDur) {
			m_TimeScaleTransStage = TimeScaleStage::Keep;

			m_fTimeScaleTransDelta = 0;
			pWorldSetting->SetTimeDilation(m_fDestTimeScale);
			return;
		}
	}
	else if (m_TimeScaleTransStage == TimeScaleStage::Keep)
	{
		float fExtraTime = m_fTimeScalePlayedTime - (m_fTimeScaleInDur + m_fTimeScaleKeepDur);
		if (fExtraTime >= 0) {
			m_TimeScaleTransStage = TimeScaleStage::ZoomOut;

			m_fTimeScaleTransDelta = m_fTimeScaleOutDur > 0 ? (1 - pWorldSetting->TimeDilation) / m_fTimeScaleOutDur : 0;
			if (fExtraTime == 0)
				return;

			fDeltaTime = fExtraTime;
		}
	}
	else if (m_TimeScaleTransStage == TimeScaleStage::ZoomOut)
	{
		if (m_fTimeScalePlayedTime >= m_fTimeScaleInDur + m_fTimeScaleKeepDur + m_fTimeScaleOutDur) {
			m_TimeScaleTransStage = TimeScaleStage::None;

			pWorldSetting->SetTimeDilation(1);
			return;
		}
	}

	float fNewScale = pWorldSetting->TimeDilation + m_fTimeScaleTransDelta * fDeltaTime;
	if (fNewScale < s_fTimeScaleMin) // 不能过小！否则无法反算出RealDeltaTime
		fNewScale = s_fTimeScaleMin;

	pWorldSetting->SetTimeDilation(fNewScale);
}

AzureScreenBulletMan* AAzureEntryPoint::GetScreenBulletMan()
{
	if (m_ScreenBulletMan == nullptr)
		m_ScreenBulletMan = new AzureScreenBulletMan();
	return m_ScreenBulletMan;
}

double AAzureEntryPoint::GetCurFrameTime() const
{
	return m_curFrameTime - m_realtimeSinceStartup;
}

#if WITH_EDITOR
void AAzureEntryPoint::SetPlaySessionPaused(bool pause)
{
	if (pause)
	{
		//FBehaviorTreeDebugger::PausePlaySession();

		if (GUnrealEd->PlayWorld && !GUnrealEd->PlayWorld->bDebugPauseExecution)
		{
			GUnrealEd->PlayWorld->bDebugPauseExecution = true;
			GUnrealEd->PlaySessionPaused();
		}
	}
	else
	{
		//FBehaviorTreeDebugger::ResumePlaySession();
		if (GUnrealEd->PlayWorld && GUnrealEd->PlayWorld->bDebugPauseExecution)
		{
			GUnrealEd->PlayWorld->bDebugPauseExecution = false;
			GUnrealEd->PlaySessionResumed();
		}
	}
}
bool AAzureEntryPoint::IsPlaySessionPaused() const
{
	//return FBehaviorTreeDebugger::IsPlaySessionPaused();
	return GUnrealEd->PlayWorld && GUnrealEd->PlayWorld->bDebugPauseExecution;
}


#endif

