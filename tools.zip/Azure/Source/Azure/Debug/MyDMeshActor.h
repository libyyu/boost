// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "ProceduralMeshComponent.h"
#include "MyDMeshActor.generated.h"

USTRUCT()
struct FVertexColorGroup
{
	GENERATED_USTRUCT_BODY()
public:
	UPROPERTY(EditAnywhere)
	FColor InvalidColor;

	UPROPERTY(EditAnywhere)
	FColor UnReachableColor;

	UPROPERTY(EditAnywhere)
	FColor MoveableColor;

	UPROPERTY(EditAnywhere)
	FColor ReachableColor;

	UPROPERTY(EditAnywhere)
	FColor WaypointColor;
};

UCLASS()
class AZURE_API AMyDMeshActor : public AActor
{
	GENERATED_BODY()
	
public:	
	// Sets default values for this actor's properties
	AMyDMeshActor();
	AMyDMeshActor(const FObjectInitializer& ObjectInitializer);


	void CreateMeshSection(int32 SectionIndex, const TArray<FVector>& Vertices, const TArray<int32>& Triangles, const TArray<FVector>& Normals, const TArray<FVector2D>& UV0, const TArray<FColor>& VertexColors, const TArray<FProcMeshTangent>& Tangents, bool bCreateCollision);
	void UpdateMeshSection(int32 SectionIndex, const TArray<FVector>& Vertices, const TArray<FVector>& Normals, const TArray<FVector2D>& UV0, const TArray<FColor>& VertexColors, const TArray<FProcMeshTangent>& Tangents);
	
	void CreateMeshSection(int32 SectionIndex, const TArray<FVector>& Vertices, const TArray<int32>& Triangles, const TArray<FVector>& Normals, const TArray<FVector2D>& UV0, const TArray<int32>& VertexColorsIndex, const TArray<FProcMeshTangent>& Tangents, bool bCreateCollision);
	void UpdateMeshSection(int32 SectionIndex, const TArray<FVector>& Vertices, const TArray<FVector>& Normals, const TArray<FVector2D>& UV0, const TArray<int32>& VertexColorsIndex, const TArray<FProcMeshTangent>& Tangents);

	UFUNCTION()
	void MarkRenderStateDirty();

	UFUNCTION()
	void SetMeshMaterial(int32 ElementIndex, UMaterialInterface* Material);

	UPROPERTY(EditAnywhere, Category = MapDrawer)
	int32 Segment = 0;

protected:
	// Called when the game starts or when spawned
	virtual void BeginPlay() override;

	virtual void BeginDestroy() override;

	UPROPERTY(EditAnywhere)
	UProceduralMeshComponent* DMesh;

	UPROPERTY(EditAnywhere)
	FVertexColorGroup ColorIndex;

private:
	void ConstructDMesh();
public:	
	// Called every frame
	virtual void Tick(float DeltaTime) override;
};
