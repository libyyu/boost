// Fill out your copyright notice in the Description page of Project Settings.
#include "MyDMeshActor.h"
#include "CoreUObject.h"
#include "Engine.h"

// Sets default values
AMyDMeshActor::AMyDMeshActor() :DMesh(nullptr)
{
	ConstructDMesh();
}

AMyDMeshActor::AMyDMeshActor(const FObjectInitializer& ObjectInitializer) :DMesh(nullptr)
{
	ConstructDMesh();
}

void AMyDMeshActor::ConstructDMesh()
{
	if (!DMesh)
	{
		// UStaticMeshComponent use blocks not work.
		//static ConstructorHelpers::FObjectFinder <UMaterial> Material(TEXT("/Game/Miscs/MapEditMaterial"));

		// Test whether has a good result.
		DMesh = CreateDefaultSubobject<UProceduralMeshComponent>(TEXT("GenerateMesh"));
		//DMesh->SetMaterial(1, Material.Object);
		DMesh->SetCastShadow(true);
		DMesh->SetMobility(EComponentMobility::Static);
		
		
		//DMesh = NewObject<UProceduralMeshComponent>(this, TEXT("GenerateMesh"));
		//RootComponent = DMesh;

		RootComponent = DMesh;
	}
}

void AMyDMeshActor::SetMeshMaterial(int32 ElementIndex, UMaterialInterface* Material)
{
	check(DMesh);
	check(Material);
	DMesh->SetMaterial(ElementIndex, Material);
}

// Called when the game starts or when spawned
void AMyDMeshActor::BeginPlay()
{
	Super::BeginPlay();
}

void AMyDMeshActor::BeginDestroy()
{
	if (DMesh && DMesh->IsRegistered())
		DMesh->UnregisterComponent();

	Super::BeginDestroy();
}

// Called every frame
void AMyDMeshActor::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);

}

void AMyDMeshActor::CreateMeshSection(int32 SectionIndex, const TArray<FVector>& Vertices, const TArray<int32>& Triangles, const TArray<FVector>& Normals, const TArray<FVector2D>& UV0, const TArray<FColor>& VertexColors, const TArray<FProcMeshTangent>& Tangents, bool bCreateCollision)
{
	check(DMesh);
	DMesh->CreateMeshSection(SectionIndex, Vertices, Triangles, Normals, UV0, VertexColors, Tangents, bCreateCollision);

	//ע��Component
	if (GetWorld() && !DMesh->IsRegistered()) {
		DMesh->RegisterComponent();
	}
		

}

void AMyDMeshActor::UpdateMeshSection(int32 SectionIndex, const TArray<FVector>& Vertices, const TArray<FVector>& Normals, const TArray<FVector2D>& UV0, const TArray<FColor>& VertexColors, const TArray<FProcMeshTangent>& Tangents)
{
	check(DMesh);
	DMesh->UpdateMeshSection(SectionIndex, Vertices, Normals, UV0, VertexColors, Tangents);

}

void AMyDMeshActor::MarkRenderStateDirty()
{
	this->MarkComponentsRenderStateDirty();
}

void AMyDMeshActor::CreateMeshSection(int32 SectionIndex, const TArray<FVector>& Vertices, const TArray<int32>& Triangles, const TArray<FVector>& Normals, const TArray<FVector2D>& UV0, const TArray<int32>& VertexColorsIndex, const TArray<FProcMeshTangent>& Tangents, bool bCreateCollision)
{
	TArray<FColor> VertexColors;
	for (int32 i = 0; i < VertexColorsIndex.Num(); ++i)
	{
		int32 color_index = VertexColorsIndex[i];
		if (color_index == 0)
			VertexColors.Add(ColorIndex.InvalidColor);
		else if (color_index == 1)
			VertexColors.Add(ColorIndex.UnReachableColor);
		else if (color_index == 2)
			VertexColors.Add(ColorIndex.MoveableColor);
		else if (color_index == 3)
			VertexColors.Add(ColorIndex.ReachableColor);
		else if (color_index == 4)
			VertexColors.Add(ColorIndex.WaypointColor);
		else
		{
			VertexColors.Add(FColor(255, 0, 0));
		}
	}

	CreateMeshSection(SectionIndex, Vertices, Triangles, Normals, UV0, VertexColors, Tangents, bCreateCollision);
}
void AMyDMeshActor::UpdateMeshSection(int32 SectionIndex, const TArray<FVector>& Vertices, const TArray<FVector>& Normals, const TArray<FVector2D>& UV0, const TArray<int32>& VertexColorsIndex, const TArray<FProcMeshTangent>& Tangents)
{
	TArray<FColor> VertexColors;
	for (int32 i = 0; i < VertexColorsIndex.Num(); ++i)
	{
		int32 color_index = VertexColorsIndex[i];
		if (color_index == 0)
			VertexColors.Add(ColorIndex.InvalidColor);
		else if (color_index == 1)
			VertexColors.Add(ColorIndex.UnReachableColor);
		else if (color_index == 2)
			VertexColors.Add(ColorIndex.MoveableColor);
		else if (color_index == 3)
			VertexColors.Add(ColorIndex.ReachableColor);
		else if (color_index == 4)
			VertexColors.Add(ColorIndex.WaypointColor);
		else
		{
			VertexColors.Add(FColor(255, 0, 0));
		}
	}

	UpdateMeshSection(SectionIndex, Vertices, Normals, UV0, VertexColors, Tangents);
}


