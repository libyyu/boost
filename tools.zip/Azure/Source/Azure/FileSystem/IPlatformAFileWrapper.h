#pragma once

#include "CoreMinimal.h"
#include "GenericPlatformFile.h"
#include "Paths.h"
#include "ALZ4File.h"
#include "ABaseDef.h"

#include <mutex>

DECLARE_LOG_CATEGORY_EXTERN(LogIPlatformAFileWrapper, Log, All);

class AFileWrapper;
class ALZ4File;
class FPlatformAFileWrapper;

class FAFileWrapperHandle : public IFileHandle
{
public:

	FAFileWrapperHandle(AFileWrapper* _FileWrapper, FPlatformAFileWrapper* _Manager, bool _IsCompressed, bool _IsSepFile, int64 _FileOffset, int64 _StreamLen, ASysThreadMutex* _PackageLocker);
	virtual ~FAFileWrapperHandle();

	virtual int64 Tell() override;
	virtual bool Seek(int64 NewPosition) override;
	virtual bool SeekFromEnd(int64 NewPositionRelativeToEnd) override;
	virtual bool Read(uint8* Destination, int64 BytesToRead) override;
	virtual bool Write(const uint8* Source, int64 BytesToWrite) override;
	virtual int64 Size() override
	{
		return StreamLen;
	}

private:

	AFileWrapper* FileWrapper;
	ASysThreadMutex* PackageLocker;
	FPlatformAFileWrapper* Manager;
	bool IsCompressed;
	bool IsSepFile;
	int64 FileOffset;
	int64 StreamLen;
	int64 CurPos;
};

class FALZ4FileWrapperHandle : public IFileHandle
{
public:

	FALZ4FileWrapperHandle(ALZ4File* InLZ4File, FString&& InFileName, FPlatformAFileWrapper* InManager, FCriticalSection* InCS);
	virtual ~FALZ4FileWrapperHandle();

	virtual int64 Tell() override;
	virtual bool Seek(int64 NewPosition) override;
	virtual bool SeekFromEnd(int64 NewPositionRelativeToEnd) override;
	virtual bool Read(uint8* Destination, int64 BytesToRead) override;
	virtual bool Write(const uint8* Source, int64 BytesToWrite) override;
	virtual int64 Size() override { return mSize; }

private:

	ALZ4File* mLZ4File;
	unsigned int mPosition;
	unsigned int mSize;
	FPlatformAFileWrapper* mManager;
	FCriticalSection* mCS;
	FString mFileName;
};

/**
* Platform file wrapper to be able to use AFilePackage
**/
class FPlatformAFileWrapper : public IPlatformFile
{
public:

	FPlatformAFileWrapper();
	virtual ~FPlatformAFileWrapper();

	virtual bool ShouldBeUsed(IPlatformFile* Inner, const TCHAR* CmdLine) const override
	{
		return true;
	}

	virtual bool Initialize(IPlatformFile* Inner, const TCHAR* CommandLineParam) override;

	virtual IPlatformFile* GetLowerLevel() override
	{
		return LowerLevel;
	}

	virtual const TCHAR* GetName() const override
	{
		return FPlatformAFileWrapper::GetTypeName();
	}

	//~ Begin IPlatformFile Interface
	virtual bool FileExists(const TCHAR* Filename) override;
	virtual int64 FileSize(const TCHAR* Filename) override;
	virtual bool DeleteFile(const TCHAR* Filename) override;
	virtual bool IsReadOnly(const TCHAR* Filename) override;
	virtual bool MoveFile(const TCHAR* To, const TCHAR* From) override;
	virtual bool SetReadOnly(const TCHAR* Filename, bool bNewReadOnlyValue) override;
	virtual FDateTime GetTimeStamp(const TCHAR* Filename) override;
	virtual void GetTimeStampPair(const TCHAR* FilenameA, const TCHAR* FilenameB, FDateTime& OutTimeStampA, FDateTime& OutTimeStampB) override;
	virtual void SetTimeStamp(const TCHAR* Filename, FDateTime DateTime) override;
	virtual FDateTime GetAccessTimeStamp(const TCHAR* Filename) override;
	virtual FString GetFilenameOnDisk(const TCHAR* Filename) override;
	virtual IFileHandle* OpenRead(const TCHAR* Filename, bool bAllowWrite = false) override;
	virtual IFileHandle* OpenWrite(const TCHAR* Filename, bool bAppend = false, bool bAllowRead = false) override;
	virtual bool DirectoryExists(const TCHAR* Directory) override;
	virtual bool CreateDirectory(const TCHAR* Directory) override;
	virtual bool DeleteDirectory(const TCHAR* Directory) override;

	virtual FFileStatData GetStatData(const TCHAR* FilenameOrDirectory) override
	{
		FFileStatData FileStatData;
		return FileStatData;
	}

	virtual bool IterateDirectory(const TCHAR* Directory, IPlatformFile::FDirectoryVisitor& Visitor) override;
	virtual bool IterateDirectoryStat(const TCHAR* Directory, IPlatformFile::FDirectoryStatVisitor& Visitor) override;
	virtual void SetLowerLevel(IPlatformFile* NewLowerLevel) override;

	virtual bool ShouldAsyncReadFileUseHandleCaching(const FString& Filename) override;

	virtual FString ConvertToAbsolutePathForExternalAppForRead(const TCHAR* Filename) override;
	virtual FString ConvertToAbsolutePathForExternalAppForWrite(const TCHAR* Filename) override;

protected:

	friend class FAFileWrapperHandle;
	friend class FALZ4FileWrapperHandle;

	/** Wrapped file */
	IPlatformFile* LowerLevel;
	bool IsInit = false;

	/* Debug pck path */
	static astring PckDebugDir;
	static astring AssetsPath;
	static astring BackupAssetsPath;
#if PLATFORM_IOS
	static astring CachePath;
#endif
	static bool SepFile;
	/** Mount point. */
	FString MountPoint;
	int MountPointPathLen = 0;
	/** Engine resource. */
	FString EnginePoint;
	/** Engine config. */
	FString EngineConfigPoint;
	/** Movies point. */
	FString MoviesPoint;
	/** Entry point. */
	FString EntryPoint;
	/** Entry point. */
	FString ProjectDir;
	/** Language*/
	static FString BuiltInLanguage;
	static FString Language;

	struct PACKAGE_FILE_HANDLE
	{
		AFileWrapper* FileWrapper;
		ASysThreadMutex* FileLocker;
	};

	ahash_map<astring, PACKAGE_FILE_HANDLE> PackageFileHandleMap;
	astring TempPackageName;

	struct ACTIVE_STREAM_ENTRY
	{
		ALZ4File* Stream;
		FCriticalSection* CS;
		int RefCount;
	};

	TMap<FString, ACTIVE_STREAM_ENTRY> mActiveFileStreams;
	FCriticalSection mFileStreamLocker;
	FCriticalSection mPackageFileHandleLocker;
	static constexpr int ACTIVE_STTREAM_LOCKER_COUNT = 6;
	int mCurActiveLockerIndex = 0;
	FCriticalSection mActiveSteramLocker[ACTIVE_STTREAM_LOCKER_COUNT];

	volatile bool mToDisable = false;
	volatile int32 mOuterRefCount = 0;

	class AutoRefCounter
	{
	public:

		AutoRefCounter(volatile int32& ref) : mRef(ref)
		{
			FPlatformAtomics::InterlockedIncrement(&mRef);
		}

		~AutoRefCounter()
		{
			FPlatformAtomics::InterlockedDecrement(&mRef);
		}

	private:

		volatile int32& mRef;
	};

protected:

	void InnerClosePackageFileHandle();
	void SetupPaths();

	static bool ShouldOpenAssetPackages();
	static int ShouldLoadObbPackage();		// 0: Not use, 1: One obb, 2: Two obb
	static int ShouldLoadAABPackages(TMap<FString, int32>* AssetPackInfos = nullptr); // 0: Not use, 1: use
	static bool ReadResBaseVersion(int &ResBaseVersion);
	static bool ReadSavedResVersion(int& SavedResVersion, int& SavedResBaseVersion);

public:

	static const TCHAR* GetResBaseRelativePath()
	{
		return TEXT("res_base");
	}

	static const FString& GetResBaseFullPath();

	bool IsRelativeToMountPointStandardFileName(const TCHAR* InStandardFilenamePtr) const
	{
		FString StandardFilename;
		FixFileNameForLanguage(InStandardFilenamePtr, StandardFilename);
		const TCHAR* StandardFilenamePtr = *StandardFilename;

		if (FCString::Strncmp(StandardFilenamePtr, *MountPoint, MountPointPathLen) == 0)
		{
			const TCHAR* subPath = StandardFilenamePtr + MountPointPathLen;

			if (FCString::Strncmp(subPath, *MoviesPoint, MoviesPoint.Len()) == 0)
				return false;

			if (FCString::Strncmp(subPath, *EntryPoint, EntryPoint.Len()) == 0)
				return false;

			static const FString PandoraPoint = TEXT("Pandora/");
			if (FCString::Strncmp(subPath, *PandoraPoint, PandoraPoint.Len()) == 0)
				return false;

			return true;
		}
		else
		{
			return false;
		}
	}

	bool IsRelativeToMountPoint(const TCHAR* Filename) const
	{
		FString StandardFilename(Filename);
		FPaths::MakeStandardFilename(StandardFilename);
		return IsRelativeToMountPointStandardFileName(*StandardFilename);
	}

	bool IsRelativeToMountPoint(const FString& Filename) const
	{
		return IsRelativeToMountPoint(*Filename);
	}

	bool GetRelativeFilenameToMountPoint(const FString& InStandardFilename, FString& RelativeFilename) const
	{
		if (IsRelativeToMountPointStandardFileName(*InStandardFilename))
		{
			FString StandardFilename;
			FixFileNameForLanguage(*InStandardFilename, StandardFilename);

			RelativeFilename = StandardFilename.Mid(MountPointPathLen);
			return true;
		}
		else
		{
			return false;
		}
	}

	bool IsRelativeToEnginePointStandardFileName(const TCHAR* StandardFilenamePtr, const TCHAR** RelativeFilenamePtr = nullptr ) const
	{
		int EnginePointPathLen = EnginePoint.Len();
		static const FString contentPath = TEXT("Content/");
		static const int contentPathLen = contentPath.Len();
		static const FString shaderCachePath = TEXT("GlobalShaderCache-");
		static const int shaderCachePathLen = shaderCachePath.Len();
		static const FString InternationalizationPath = TEXT("Internationalization/");
		static const int InternationalizationPathLen = InternationalizationPath.Len();
	
		if (FCString::Strncmp(StandardFilenamePtr, *EnginePoint, EnginePointPathLen) == 0)
		{
			const TCHAR* subPath = StandardFilenamePtr + EnginePointPathLen;

			if (FCString::Strncmp(subPath, *contentPath, contentPathLen) == 0)
			{
				if (FCString::Strncmp(subPath + contentPathLen, *InternationalizationPath, InternationalizationPathLen) == 0)
					return false;

				if (RelativeFilenamePtr)
					*RelativeFilenamePtr = subPath;

				return true;
			}

			if (FCString::Strncmp(subPath, *shaderCachePath, shaderCachePathLen) == 0)
			{
				if (RelativeFilenamePtr)
					*RelativeFilenamePtr = subPath;

				return true;
			}

			return false;
		}
		else if (FCString::Strncmp(StandardFilenamePtr, *EngineConfigPoint, EngineConfigPoint.Len()) == 0)
		{
			if (RelativeFilenamePtr)
				*RelativeFilenamePtr = StandardFilenamePtr + ProjectDir.Len();

			return true;
		}
		else
		{
			return false;
		}
	}

	bool GetRelativeFilenameToEnginePoint(const FString& StandardFilename, FString& RelativeFilename) const
	{
		static const FString enginePath = TEXT("Engine/");
		const TCHAR* RelativeFilenamePtr;

		if (IsRelativeToEnginePointStandardFileName(*StandardFilename, &RelativeFilenamePtr))
		{
			RelativeFilename = enginePath + RelativeFilenamePtr;
			return true;
		}
		else
		{
			return false;
		}
	}

	void PreInit(IPlatformFile* pf)
	{
		LowerLevel = pf;
		IsInit = false;
	}

	void ReleaseFileStream(const FString& InFileName);

	bool CheckClosePackageFileHandle();

	void SetAFileSystemEnable(bool InEnable)
	{
		mToDisable = !InEnable;
	}

	bool CheckAFileSystemDisabled()
	{
		return mOuterRefCount <= 0;
	}

	static const TCHAR* GetTypeName()
	{
		return TEXT("AFilePackage");
	}

	static void SetPckDebugDir(const char* dir)
	{
		PckDebugDir = dir;
	}
	static const astring& GetPckDebugDir()
	{
		return PckDebugDir;
	}

	static void SetAssetsPath(const char* path)
	{
		AssetsPath = path;
	}
	static const astring& GetAssetsPath()
	{
		return AssetsPath;
	}

#if PLATFORM_IOS
	static const astring& GetCachePath()
	{
		return CachePath;
	}
#endif

	static void SetBackupAssetsPath(const char* path)
	{
		BackupAssetsPath = path;
	}
	static const astring& GetBackupAssetsPath()
	{
		return BackupAssetsPath;
	}

	static void SetSepFile(bool is_sep)
	{
		SepFile = is_sep;
	}
	static bool IsSepFile()
	{
		return SepFile;
	}

	static bool Init();

	bool HasInit() const { return IsInit; }

	// ��ȡ�������ԣ�����Ƕ����԰������ؿ�
	FString GetBuiltInLanguage() const;

	bool FixFileNameForLanguage(const TCHAR* StandardFilenamePtr, FString& OutFilename) const;

	static void SetLocalizationLanguage(const TCHAR* lang)
	{
		Language = lang;
	}
};

extern FPlatformAFileWrapper* GPlatformAFileWrapper;