#ifndef __WLUARUNTIME_H
#define __WLUARUNTIME_H
#pragma once
#include "wLua.h"

namespace wLua
{
	class AzureLuaBase : public LuaImpl
	{
	protected:
		bool inited;
	protected:
		virtual void OnInit(lua_State * L) override;
		virtual void OnPreFini(lua_State * L) override;
		virtual void OnPostFini() override;
		virtual void OnCheckGetL() const override;
	};
	/////////////////////////////////////////////////////////////////////////
	///
	class AzureLuaRuntime : public AzureLuaBase
	{
	protected:
		virtual void OnInit(lua_State * L) override;
		virtual void OnPreFini(lua_State * L) override;

	public:
		void Tick(float DeltaTime);
	};	
}

#endif//__WLUARUNTIME_H