﻿#include "Azure.h"
#include "LuaInterface.h"
#include "ResourceLoader/AzureResourceLoader.h"
#include "AzureEntryPoint.h"
#include "AzureBinaryReader.h"
#include "Protocols/CommonData.h"
#include "AzureGPDataType.h"
#include "AzureGameSession.h"
#include "AzureNetDef.h"
#include "Utility/help_funcs.h"
#include "Utilities/AzureSystemInfo.h"
#include "Utilities/AzureTextureStreaming.h"
#include "Utilities/DrawDebugHelpersExt.h"
#include "DirClient.h"
#include "AzureExport.h"
#include "AzureHelpFunc.h"
#include "AzureTimeManager.h"
#include "GameLogic/Behavior/AzureBehaviorDef.h"
#include "GameLogic/Behavior/AzureMoveBehavior.h"
#include "GameLogic/Behavior/HPBePushBehavior.h"
#include "GameLogic/Main/AzureObjectComponent.h"
#include "GameLogic/Input/AzureInputCtrl.h"
#include "AzureUtility.h"
#include "PlatformConfig.h"
#include "XmlParser.h"
#include "Blueprint/WidgetLayoutLibrary.h"
#include "Blueprint/SlateBlueprintLibrary.h"
#include "GUI/AzureMultiSegmentsHudText.h"
#include "GUI/AzureHudTextMan.h"
#include "GUI/AzureScreenBulletMan.h"
#include "WidgetInteractionComponent.h"
#include "StreamingAssetHelper.h"
#include "Engine.h"
#include "Components/Widget.h"
#include "Components/PanelWidget.h"
#include "Components/CanvasPanelSlot.h"
#include "Components/ScrollBoxSlot.h"
#include "Components/PoseableMeshComponent.h"
#include "SkeletalRenderPublic.h"
#include "LevelSequenceActor.h"
#include "HAL/PlatformFilemanager.h"
#include "ContentStreaming.h"
#include "FileSystem/IPlatformAFileWrapper.h"
#include "UObject/UObjectArray.h"
#include "RenderingThread.h"
#include "Framework/Application/IInputProcessor.h"
#include "Runtime/Online/HTTP/Public/Http.h"
#include "Json.h"
#include "JsonUtilities.h"
//#include "RawMesh.h"
#include "AFI.h"
#include "LevelSequenceActorEx.h"
#include "Components/CustomBoneComponent.h"
#include "CustomCharacterTexture.h"
#include "AzureLinearMotorComponent.h"
#include "AzureParabolicMotorComponent.h"
#include "AzureMissileMotorComponent.h"
#include "AzureHelixMotorComponent.h"
#include "AzureCurvedMotorComponent.h"
#include "AzureLinkMotorComponent.h"
#include "SkeletalMeshRenderData.h"
#include "ImageUtils.h"
#include "ThreadJobForLua.h"
#include "SceneTypes.h"
#include "AssetRegistryModule.h"
#include "GameLogic/Player/GamePlayer.h"
#include "Kismet/KismetSystemLibrary.h"
#include "Kismet/KismetMathLibrary.h"
#include "Internationalization/Internationalization.h"
#include "Kismet/KismetInternationalizationLibrary.h"
#include "Internationalization/TextLocalizationManager.h"
#include "Internationalization/TextLocalizationManagerGlobals.h"
#include "Internationalization/TextLocalizationResource.h"
#include "GameLogic/Player/VehicleCharacter.h"
#include "CalcGradientHelper.h"
#include "UMGCustomStatics.h"
#include "GameLogic/Main/AzureWorldWrap.h"
#include "PlatformApplicationMisc.h"
#include "RegionWallActor.h"
#include "AzureAssetSizeMap.h"
#include "JsonStructDeserializerBackend.h"
#include "StructDeserializer.h"
#include "Serialization/Public/StructSerializer.h"
#include "Serialization/Public/Backends/JsonStructSerializerBackend.h"
#include "OceanMeshActor.h"
#include "PMeshActor.h"
#include "Kismet/KismetRenderingLibrary.h"
#include "GameLogic/Main/AzureScreenRange.h"

#if PLATFORM_WINDOWS
#include "Windows/WindowsHWrapper.h"
#include "Windows/AllowWindowsPlatformTypes.h"
#include <Ole2.h>
#include <oleidl.h>
#include "Windows/HideWindowsPlatformTypes.h"
#endif
#include "GenericPlatformOutputDevices.h"
#include "Utilities/DeadLockDetector.h"
#include "Interfaces/IPluginManager.h"

#if PLATFORM_ANDROID
extern FString GFilePathBase;
#endif

RENDERER_API void AzureReplaceMovableIndirectLighting(bool bReplace, const FVector4* Params);
RENDERER_API void AzureReplaceDirectionalLight(bool bReplace, const FLinearColor& color, const FVector& dir);
RENDERER_API void AzureSetMobileDynamicCSMInUse(bool bFlag);
RENDERER_API void AzureSkipPlanarReflectionPointLight(bool bSkip);
ENGINE_API void AzureSetReplaceShadowCenterFlag(bool bReplace);
ENGINE_API void AzureSetReplaceShadowCenterPos(const FVector& centerPos, float realFarSplitDist);
extern ENGINE_API float GAverageFPS;
extern ENGINE_API TSAN_ATOMIC(uint64) GSavedViewFamilyBufferSize;
extern ENGINE_API bool GAzureIsReplaceShadowCenter;
extern CORE_API bool GIgnoreDebugger;

extern int lua_GetConsoleVariable(lua_State * L);
extern int lua_SetConsoleVariable(lua_State * L);
extern int lua_getUseBasicQualityLevelFlag(lua_State * L);
extern int lua_getRealQualityLevelsToUse(lua_State * L);
extern int lua_ExecuteCmd(lua_State * L);
extern int lua_SetReflectionQuality(lua_State * L);
extern int lua_GetReflectionQuality(lua_State * L);
extern void exp_AutoMove_SetWorldWrapEanbled(bool bEnabled);
extern void exp_AutoMove_SetWorldWrapRect(float min_x, float min_z, float max_x, float max_z);
extern void AddExternalLogResName(const FString& InName);

#if PLATFORM_ANDROID
extern void AndroidThunkCpp_JavaCrash();
#endif

namespace AzureLuaMemFunc
{
	extern void LogStat(bool bClearPeak);
}

namespace LuaUMGCustom { int32 UMGCustomSetup(lua_State* L); }
namespace LuaUMGCustom { int32 AddCoolDownComponent(lua_State* L); }
namespace LuaUMGCustom { int32 AddTimeStampCountDownComponent(lua_State* L); }
namespace LuaUMGCustom { int32 RemoveCountDownComponent(lua_State* L); }
namespace LuaPatcher { void Register(lua_State* L); }
namespace LuaAFile { void Register(lua_State* L); }
namespace LuaUObjectGlobals { void Register(lua_State* L); }
namespace LuaPatcher { int lua_downLoadUrl(lua_State* L); }
namespace LuaPatcher { int lua_downLoadUrlPost(lua_State* L); }
namespace LuaPatcher { int lua_getDiskFreeSpace(lua_State* L); }
namespace LuaPatcher { int lua_HasActiveWiFiConnection(lua_State* L); }
namespace LuaPatcher { int lua_GetNetworkConnectionType(lua_State* L); }
namespace LuaSystemInfo {
	void Register(lua_State* L);
	void SetMtLink(lua_State* L);
}
namespace LuaScreenInfo {
	void Register(lua_State* L);
	void SetMtLink(lua_State* L);
}
namespace LuaGVoice {
 	void Register(lua_State* L);
}
//namespace LuaTApm {
//	void Register(lua_State* L);
//}
namespace LuaTCos {
	void Register(lua_State* L);
}
namespace LuaZLOfflineDownload {
	void Register(lua_State *L);
}
namespace LuaTSimuHelper {
	void Register(lua_State *L);
}
namespace LuaTssSDK {
	void Register(lua_State* L);
}
namespace LuaGSDK {
	void Register(lua_State* L);
}
//namespace LuaPandora {
//	void Register(lua_State* L);
//}
namespace LuaPandoraCustom {
	void Register(lua_State* L);
}
namespace LuaGamePlayerABInterface {
	void Register(lua_State* L);
}
namespace LuaInGameUpdate {
	void Register(lua_State* L);
}
namespace LuaMD5 {
	void Register(lua_State* L);
}
namespace LuaVersionFlags {
	void Register(lua_State* L);
}
namespace LuaAzureWorldTilesLODManager {
	void Register(lua_State* L);
}

namespace LuaInterp {
	void Register(lua_State* L);
	void SetMtLink(lua_State *L);
}

namespace HttpLuaWrapper
{
	extern void Register(lua_State* L);
}

//extern ENGINE_API bool bUIDisableWorldRendering;

extern int32 GAzureStatInfoFontSize;

extern SLATECORE_API int32 GSlateFeathering;

namespace wLua
{
	namespace GameLuaInterface
	{
		//////////////////////////////////////////////////////////////////////////
		//	程序版本控制
		//	1: 初始化
		//	2: 增加 OnJoyStickRelease_NotifyHPBehavior
		//	3: SetPlayerCrossOverCoolTime -> SetPlayerCrossOverMiscParams
		//	4:  (1)MotorEditor: add fly_dissolve_delay
		//		(2)FxOne: add DelayStop(), export lua IsLogicallyPlaying() etc
		//	5:  (1)Add GetHitPosInWorld, JudgeIsInsideTerrBuilding
		//		(2)Add GetObjectResSizeBytes
		//	6: SetPostProcessFilmSaturation, SetPostProcessColorSaturation
		//	7: ReplaceMovableIndirectLighting, ReplaceDirectionalLight
		//	8: PlayerController: GetPlayerViewPoint 导出
		//	9: MeshComponent: SetMaterial, EmptyOverrideMaterials 导出
		//	10: UserWidget增加SetScene3D
		//	12: RemapMaterialQualityLevel, PrimitiveComponent::ShouldChangeMaterialQualityLevel
		//	13: CreateDynamicMaterialForMeshComponent修改：支持用OriginMat
		//	14: GetActorProperty
		//	15: SetRootMotionHoriSpeedLimit
		//	16: GetSupportPlaneHeight_WithWater
		//	17: AzureObj_SetInputSpeed
		//  18: AzurePateComponent Add ExtraPate
		//	19: AzureObj_SetFlying, ROOTMOTION_TYPE_MOVE_HOSTBEH
		//	21: AzureObj_SetRushFallAutoJump
		//	23: SetHPMoveCheckMovableMap, AzureObj_SetSwimming
		//	24: CreateVehicleController, HasVehicleController, VehicleTouchGroundNormal
		//	25: WaterMap: Load/Release/GetPixel
		//	26: TEX_RESOLUTION增加VeryHigh(2048)用于创角捏脸
		//	27: UE4Engine升级到4.20
		//	28: 引擎升到4.20.1; AzureObj_SetJumpFallType
		//	29: AddViewSlaveLocation，CarRace相关
		//	30: AddViewExtraLocation，CarRace相关
		static int CUR_CODE_VERSION = 30;

		static int GetCurCodeVersion(lua_State * L)
		{
			lua_pushnumber(L, CUR_CODE_VERSION);
			return 1;
		}

		static int lua_GetBuildConfiguration(lua_State * L)
		{
			lua_pushstring(L, TCHAR_TO_UTF8(EBuildConfigurations::ToString(FApp::GetBuildConfiguration())));
			return 1;
		}

		bool lua_optboolean(lua_State * L, int idx, bool def)
		{
			if (lua_isboolean(L, idx))
				return !!lua_toboolean(L, idx) ? true : false;
			return def;
		}

		static bool Force_Sync = false; //是否强制使用同步加载

		static int lua_SetForceSync(lua_State* L)
		{
			bool enable = false;
			if (!lua_isnoneornil(L, 1))
			{
				enable = !!lua_toboolean(L, 1);
				Force_Sync = enable;
			}
			return 0;
		}

		static bool s_log_resname_to_load = false;

		int lua_EnableLogResnameToLoad(lua_State * L)
		{
			bool enable = false;
			if (!lua_isnoneornil(L, 1))
			{
				enable = !!lua_toboolean(L, 1);
				s_log_resname_to_load = enable;
			}
			return 0;
		}

		//////////////////////////////////////////////////////////////////////////
		int lua_PauseTrigger(lua_State* L)
		{
			if (lua_isnumber(L, 1))
			{
				int param = lua_tonumber(L, 1);
				lua_pushinteger(L, param);
			}
			else if (lua_isstring(L, 1))
			{
				char const* param = lua_tostring(L, 1);
				lua_pushstring(L, param);
			}
			else if (lua_isuserdata(L, 1))
			{
				void* param = lua_touserdata(L, 1);
				lua_pushlightuserdata(L, param);
			}
			return 1;
		}

		int lua_GetObjectResSizeBytes(lua_State * L)
		{
			UObject* Object = FLuaUtils::GetUObject(L, 1, "Object");
			if (!Object)
			{
				lua_pushstring(L, "lua_GetObjectResSizeBytes: #1 must be Object!");
				lua_error(L);
				return 1;
			}

			EResourceSizeMode::Type Mode = EResourceSizeMode::Exclusive;
			if (lua_isnumber(L, 2))
				Mode = (EResourceSizeMode::Type)lua_touint(L, 2);

			SIZE_T sizeBytes = Object->GetResourceSizeBytes(Mode);
			lua_pushnumber(L, sizeBytes);
			return 1;
		}

		int lua_SpawnActor(lua_State * L)
		{
			const char* packageName = lua_tostring(L, 1);
			AActor* Owner = Cast<AActor>(FLuaUtils::GetUObject(L, 2,"Actor"));
			FVector pos = (wLua::FLuaVector::Get(L, 3));
			FQuat quat = (wLua::FLuaQuat::Get(L, 4));
			lua_pushvalue(L, 5);
			wLua::lua_registry_handle callbackRef = wLua::lua_registry_handle::wlua_ref(L, LUA_REGISTRYINDEX);
			
			if (s_log_resname_to_load)
				UE_LOG(LogAzure, Warning, TEXT("SpawnActor : %s, force_sync:%d"), TEXT("MyActor"), Force_Sync ? 1 : 0);

			auto onFinish = [callbackRef, Owner, pos, quat](TArray<UObject*> res)
			{

				if (!AAzureEntryPoint::Instance)
					return;

				lua_State_Wrapper L = AAzureEntryPoint::Instance->GetL();

				if (!L)
					return;

				AActor* RetVal = nullptr;
				lua_rawgeti(L, LUA_REGISTRYINDEX, callbackRef);
				wLua::lua_registry_handle::wlua_unref(L, LUA_REGISTRYINDEX, callbackRef);
				if (lua_isnil(L, -1) || AAzureEntryPoint::Instance == nullptr)
				{
					lua_pop(L, 1);
					return;
				}
				UWorld* pWorld = AAzureEntryPoint::Instance->GetWorld();
				if (!pWorld)
				{
					lua_pop(L, 1);
					return;
				}

				for (auto ObjIt = res.CreateConstIterator(); ObjIt; ++ObjIt)
				{
					UObject * obj = *ObjIt;
					UClass * cls = Cast<UClass>(obj);
					if (cls != nullptr)
					{
						FActorSpawnParameters SpawnParams;
						SpawnParams.Owner = Owner;
						SpawnParams.Instigator = nullptr;
						RetVal = pWorld->SpawnActor<AActor>(cls, pos, quat.Rotator(), SpawnParams);
						break;
					}
				}
				FLuaUtils::ReturnUObject(L, RetVal);
				AAzureEntryPoint::Instance->GetWLua()->Call(1);

			};
			if (Force_Sync)
			{
				TArray<UObject*> res;
				AzureResourceLoader::Get().LoadGameRes(TEXT("MyActor"), res);
				onFinish(res);
			}
			else
			{
				AzureResourceLoader::Get().LoadGameResAsync(TEXT("MyActor"), onFinish);
			}

			return 0;
		}

		enum PropType
		{
			BOOL = 1,
			INT8 = 2,
			INT16 = 3,
			INT32 = 4,
			FLOAT = 5,
			DOUBLE = 6,
			//STRING = 7, //不安全！
			ACTOR = 8,
			VECTOR = 9,
			Component = 10,
		};
		int lua_SetActorProperty(lua_State * L)
		{
			AActor* Owner = Cast<AActor>(FLuaUtils::GetUObject(L, 1, "Actor"));
			if (!Owner)
			{
				lua_pushstring(L, "lua_SetActorProperty: #1 must be Actor!");
				lua_error(L);
				return 1;
			}

			const char* propName = lua_tostring(L, 2);

			UProperty* Property = nullptr;
			for (TFieldIterator<UProperty> PropertyIt(Owner->GetClass(), EFieldIteratorFlags::IncludeSuper); PropertyIt; ++PropertyIt)
			{
				UProperty* pProperty = *PropertyIt;
				if (pProperty->GetFName() == propName)
				{
					Property = pProperty;
					break;
				}
			}
			if (!Property)
			{
				//UE_LOG(LogAzure, Warning, TEXT("lua_SetActorProperty: Property Not found: %s"), propName);
				return 0;
			}

			PropType type = (PropType)luaL_checkinteger(L, 3);

			switch (type)
			{
			case wLua::GameLuaInterface::BOOL:
			{
				bool b = !!lua_toboolean(L, 4);
				Property->CopyCompleteValue(Property->ContainerPtrToValuePtr<void>(Owner), &b);
			}
			break;
			case wLua::GameLuaInterface::INT8:
			{
				int8 b = (int8)lua_tonumber(L, 4);
				Property->CopyCompleteValue(Property->ContainerPtrToValuePtr<void>(Owner), &b);
			}
			break;
			case wLua::GameLuaInterface::INT16:
			{
				int16 b = (int16)lua_tonumber(L, 4);
				Property->CopyCompleteValue(Property->ContainerPtrToValuePtr<void>(Owner), &b);
			}
			break;
			case wLua::GameLuaInterface::INT32:
			{
				int32 b = (int32)lua_tonumber(L, 4);
				Property->CopyCompleteValue(Property->ContainerPtrToValuePtr<void>(Owner), &b);
			}
			break;
			case wLua::GameLuaInterface::FLOAT:
			{
				float f = (float)lua_tonumber(L, 4);
				Property->CopyCompleteValue(Property->ContainerPtrToValuePtr<void>(Owner), &f);
			}
			break;
			case wLua::GameLuaInterface::DOUBLE:
			{
				double d = lua_tonumber(L, 4);
				Property->CopyCompleteValue(Property->ContainerPtrToValuePtr<void>(Owner), &d);
			}
			break;
			//case wLua::GameLuaInterface::STRING: //不安全！
			//{
			//	const char* propVal = lua_tostring(L, 4);
			//	Property->CopyCompleteValue(Property->ContainerPtrToValuePtr<void>(Owner), &propVal);
			//}
			//break;
			case wLua::GameLuaInterface::ACTOR:
			{
				AActor* pActor = Cast<AActor>(FLuaUtils::GetUObject(L, 4, "Actor"));
				Property->CopyCompleteValue(Property->ContainerPtrToValuePtr<void>(Owner), &pActor);
			}

			case wLua::GameLuaInterface::Component:
			{
				USceneComponent* pCom = Cast<USceneComponent>(FLuaUtils::GetUObject(L, 4, "SceneComponent"));
				Property->CopyCompleteValue(Property->ContainerPtrToValuePtr<void>(Owner), &pCom);
			}

			break;
			case wLua::GameLuaInterface::VECTOR:
			{
				FVector pos = (wLua::FLuaVector::Get(L, 4));
				Property->CopyCompleteValue(Property->ContainerPtrToValuePtr<void>(Owner), &pos);
			}
			break;
			default:
				lua_pushstring(L, "lua_SetActorProperty: type Not valid!");
				lua_error(L);
				return 1;
			}

			return 0;
		}

		int lua_GetActorProperty(lua_State * L)
		{
			AActor* Owner = Cast<AActor>(FLuaUtils::GetUObject(L, 1, "Actor"));
			if (!Owner)
			{
				lua_pushstring(L, "lua_GetActorProperty: #1 must be Actor!");
				lua_error(L);
				return 1;
			}

			const char* propName = lua_tostring(L, 2);

			UProperty* Property = nullptr;
			for (TFieldIterator<UProperty> PropertyIt(Owner->GetClass(), EFieldIteratorFlags::IncludeSuper); PropertyIt; ++PropertyIt)
			{
				UProperty* pProperty = *PropertyIt;
				if (pProperty->GetFName() == propName)
				{
					Property = pProperty;
					break;
				}
			}
			if (!Property)
			{
				UE_LOG(LogAzure, Warning, TEXT("lua_GetActorProperty: Property Not found: %s"), propName);
				return 0;
			}

			PropType type = (PropType)luaL_checkinteger(L, 3);

			switch (type)
			{
			case wLua::GameLuaInterface::BOOL:
			{
				uint8 PropertyValue = uint8();
				Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Owner));
				lua_pushboolean(L, PropertyValue);
				return 1;
			}
			break;
			case wLua::GameLuaInterface::INT8:
			{
				int8 PropertyValue = int8();
				Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Owner));
				lua_pushnumber(L, PropertyValue);
				return 1;
			}
			break;
			case wLua::GameLuaInterface::INT16:
			{
				int16 PropertyValue = int16();
				Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Owner));
				lua_pushnumber(L, PropertyValue);
				return 1;
			}
			break;
			case wLua::GameLuaInterface::INT32:
			{
				int32 PropertyValue = int32();
				Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Owner));
				lua_pushnumber(L, PropertyValue);
				return 1;
			}
			break;
			case wLua::GameLuaInterface::FLOAT:
			{
				float PropertyValue = float();
				Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Owner));
				lua_pushnumber(L, PropertyValue);
				return 1;
			}
			break;
			case wLua::GameLuaInterface::DOUBLE:
			{
				double PropertyValue = double();
				Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Owner));
				lua_pushnumber(L, PropertyValue);
				return 1;
			}
			break;
			//case wLua::GameLuaInterface::STRING: //不安全！
			//{
			//	const char* propVal = lua_tostring(L, 4);
			//	Property->CopyCompleteValue(Property->ContainerPtrToValuePtr<void>(Owner), &propVal);
			//}
			//break;
			case wLua::GameLuaInterface::ACTOR:
			{
				UObject* PropertyValue = nullptr;	// ???
				Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Owner));
				FLuaUtils::ReturnUObject(L, PropertyValue);
				return 1;
			}
			break;
			case wLua::GameLuaInterface::VECTOR:
			{
				FVector PropertyValue = FVector();
				Property->CopyCompleteValue(&PropertyValue, Property->ContainerPtrToValuePtr<void>(Owner));
				FLuaVector::Return(L, PropertyValue);
				return 1;
			}
			break;
			default:
				lua_pushstring(L, "lua_GetActorProperty: type Not valid!");
				lua_error(L);
				return 1;
			}

			return 0;
		}

		int lua_Instantiate(lua_State * L)
		{
			AActor * actor = nullptr;
			UObject* pObj = FLuaUtils::GetUObject(L, 1, "BlueprintGeneratedClass");
			UClass * cls = pObj ? Cast<UClass>(pObj) : nullptr;
			if (cls != nullptr)
			{
				if (!AAzureEntryPoint::Instance)
					return 0;

				UWorld* pWorld = AAzureEntryPoint::Instance->GetWorld();
				if (!pWorld)
				{
					return 0;
				}

				FVector pos = (lua_istable(L, 2) || lua_isuserdata(L, 2)) ? (wLua::FLuaVector::Get(L, 2)) : FVector::ZeroVector;
				FRotator rotator = (lua_istable(L, 3) || lua_isuserdata(L, 3)) ? (wLua::FLuaRotator::Get(L, 3)) : FRotator::ZeroRotator;

				FActorSpawnParameters SpawnParams;
				SpawnParams.Owner = nullptr;
				SpawnParams.Instigator = nullptr;
				SpawnParams.SpawnCollisionHandlingOverride = ESpawnActorCollisionHandlingMethod::AlwaysSpawn;

				if (lua_isstring(L, -1))
				{
					const char* actorName = lua_tostring(L, -1);
					SpawnParams.Name = MakeUniqueObjectName(pWorld->PersistentLevel, cls, actorName);
				}

				actor = pWorld->SpawnActor<AActor>(cls, pos, rotator, SpawnParams);
			}
			else
			{
				lua_pushstring(L, "Instantiate: #1 must be UClass type");
				lua_error(L);
				return 0;
			}
			FLuaUtils::ReturnUObject(L, actor);
			return 1;
		}

		int lua_InstantiateComponent(lua_State * L)
		{
			UActorComponent * actorComponent = nullptr;
			UObject* Obj = wLua::FLuaUtils::GetUObject(L, 1, "Actor");
			AActor * self = Cast<AActor>(Obj);
			if (!self)
			{
				wLua::LuaStatic::traceback(L, "lua_InstantiateComponent #1 must be a Actor");
				lua_error(L);
				return 1;
			}
			UObject* pObj = FLuaUtils::GetUObject(L, 2, "Class");
			UClass * cls = pObj ? Cast<UClass>(pObj) : nullptr;
			if (cls != nullptr)
			{
				actorComponent = NewObject<UActorComponent>(self, cls);
			}
			else
			{
				lua_pushstring(L, "Instantiate: #2 must be UClass type");
				lua_error(L);
				return 0;
			}
			FLuaUtils::ReturnUObject(L, actorComponent);
			return 1;
		}

		int lua_DestroyActor(lua_State * L)
		{
			wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(L, 1, "Actor", &userdata); if (!Obj) { wLua::LuaStatic::traceback(L, "Actor must be non-null"); lua_error(L);  return 0; }
			bool bNetForce = !!(lua_toboolean(L, 2));
			AActor * actor = Cast<AActor>(Obj);
			actor->Destroy(bNetForce);
			userdata->flag |= wLua::LuaObjectFlag::DESTROYED;
			wLua::FLuaUtils::RemoveObjectReference(Obj, userdata->stamp, L);
			return 0;
		}

		int lua_AssetExist(lua_State * L)
		{
			char const* resname = lua_tostring(L, 1);
			if (*resname == 0)
			{
				lua_pushboolean(L, false);
				return 1;
			}

			FString packageName = "/Game/";
			packageName += UTF8_TO_TCHAR(resname);
			bool bExist = FPackageName::DoesPackageExist(packageName);
			lua_pushboolean(L, bExist);
			return 1;
		}

		int lua_AsyncLoadResource(lua_State * L)
		{
			char const* resname = luaL_checkstring(L, 1);
			luaL_checktype(L, 2, LUA_TFUNCTION);
			lua_pushvalue(L, 2);
			wLua::lua_registry_handle callbackRef = wLua::lua_registry_handle::wlua_ref(L, LUA_REGISTRYINDEX);

			bool isWorld = false;
			FString obj_type;
			if (lua_isstring(L, 3))
			{
				const char* n = lua_tostring(L, 3);
				obj_type = UTF8_TO_TCHAR(n);

				if (obj_type == TEXT("World"))
				{
					isWorld = true;
				}
			}
			bool isBaseObjType = false;
			if (!lua_isnoneornil(L, 4))
				isBaseObjType = !!lua_toboolean(L, 4);

			if (resname[0] == '\0')
			{
				wLua::LuaStatic::traceback(L, "lua_AsyncLoadResource, res name is empty");
				const char* traceMsg = lua_tostring(L, -1);
				UE_LOG(LogAzure, Warning, TEXT("%s"), UTF8_TO_TCHAR(traceMsg));
				lua_pop(L, 1);
			}
			FString strResName(UTF8_TO_TCHAR(resname));

			strResName.ReplaceInline(TEXT("\\"), TEXT("/"), ESearchCase::CaseSensitive);

			if (strResName.Contains(TEXT("//"), ESearchCase::CaseSensitive))
			{
				luaL_error(L, "Attempted to create a package with name containing double slashes. PackageName: %s", resname);
			}

			if(s_log_resname_to_load)
				UE_LOG(LogAzure, Warning, TEXT("LuaAsyncLoadResource to load : %s, force_sync:%d"), UTF8_TO_TCHAR(resname), Force_Sync?1:0);

			auto onFinish = [strResName, callbackRef, obj_type, isBaseObjType](const TArray<UObject*>& res) 
			{
				if (!AAzureEntryPoint::IsInit())
					return;

				wLua::Lua* wlua = AAzureEntryPoint::Instance->GetWLua();
				lua_State_Wrapper temp_L = AAzureEntryPoint::Instance->GetL();

				lua_rawgeti(temp_L, LUA_REGISTRYINDEX, callbackRef);
				wLua::lua_registry_handle::wlua_unref(temp_L, LUA_REGISTRYINDEX, callbackRef);
				if (lua_isnil(temp_L, -1))
				{
					lua_pop(temp_L, 1);
					return;
				}

				lua_pushvalue(temp_L, -1);	//-> cb, cb

				UObject* asset = nullptr;

				if (!obj_type.IsEmpty())
				{
					bool bFound = false;
					for (auto ObjIt = res.CreateConstIterator(); ObjIt; ++ObjIt)
					{
						UObject* ob = (*ObjIt);
						UClass* cls = ob->GetClass();

						while (cls)
						{
							if (cls->GetName() == obj_type)
							{
								asset = ob;
								bFound = true;
								break;
							}
							if (!isBaseObjType)
								break;
							cls = cls->GetSuperClass();
						}
						if (bFound)
							break;
					}
				}
				else if (res.Num() == 1)
				{
					asset = res[0];
				}
				else if (res.Num())
				{
					int32 Index = 0;
					if (strResName.FindLastChar(TEXT('/'), Index))
					{
						FString ObjName = strResName.RightChop(Index + 1);
						for (const auto& Obj : res)
						{
							if (Obj->GetName() == ObjName)
							{
								asset = Obj;
								break;
							}
						}
					}
				}

				if (asset != nullptr)
				{
					FLuaUtils::ReturnUObject(temp_L, asset);
				}
				else
				{
					lua_pushvalue(temp_L, -1);	//-> cb, cb, cb
					FString callbackInfo = wlua->GetFunctionInfo();	//-> cb, cb

					FString s = FString::Printf(TEXT("LuaAsyncLoadResource failed to load: %s, type:%s, cb:%s"), *strResName, *obj_type, *callbackInfo);
					UE_LOG(LogAzure, Warning, TEXT("LUA: %s"), *s);
					lua_pushnil(temp_L);
				}

				bool bRet = wlua->PCallWithFunctionInfo(1, 0);	//-> cb, [err]

				if (bRet)
				{
					lua_pop(temp_L, 1);
				}
				else
				{
					lua_pushvalue(temp_L, -2);
					FString info = wlua->GetFunctionInfo();
					FString errorInfo = FString::Printf(TEXT("@LoadCallBack:%s@@@%s"), *info, UTF8_TO_TCHAR(lua_tostring(temp_L, -1)));
					UE_LOG(LogAzure, Error, TEXT("LUA: %s"), *errorInfo);
					lua_pop(temp_L, 2);
				}
			};

			if (Force_Sync)
			{
				TArray<UObject*> res;
				AzureResourceLoader::Get().LoadGameRes(strResName, res, isWorld);
				onFinish(res);
			}
			else
			{
				AzureResourceLoader::Get().LoadGameResAsync(strResName, onFinish, isWorld);
			}

			return 0;
		}

		int lua_SyncLoadResource(lua_State * L)
		{
			if (!lua_isstring(L, 1))
			{
				lua_pushstring(L, "LuaAsyncLoadResource: first param must be string");
				lua_error(L);
				return 1;
			}

			const char* resname = lua_tostring(L, 1);

			bool isWorld = false;
			FString obj_type;
			if (lua_isstring(L, 2))
			{
				const char* n = lua_tostring(L, 2);
				obj_type = UTF8_TO_TCHAR(n);

				if (obj_type == "World")
					isWorld = true;
			}

			if (resname[0] == 0)
			{
				wLua::LuaStatic::traceback(L, "lua_SyncLoadResource, res name is empty");
				const char* traceMsg = lua_tostring(L, -1);
				UE_LOG(LogAzure, Warning, TEXT("%s"), UTF8_TO_TCHAR(traceMsg));
				lua_pop(L, 1);
			}

			FString strResName(UTF8_TO_TCHAR(resname));
			strResName.ReplaceInline(TEXT("\\"), TEXT("/"), ESearchCase::CaseSensitive);

			if (strResName.Contains(TEXT("//"), ESearchCase::CaseSensitive))
			{
				luaL_error(L, "Attempted to create a package with name containing double slashes. PackageName: %s", resname);
			}

			//if (s_log_resname_to_load)
			//	UE_LOG(LogAzure, Log, TEXT("LuaSyncLoadResource to load : %s"), *strResName);

			TArray<UObject*> res;
			AzureResourceLoader::Get().LoadGameRes(strResName, res, isWorld);
			UObject* asset = nullptr;

			if (!obj_type.IsEmpty())
			{
				for (auto ObjIt = res.CreateConstIterator(); ObjIt; ++ObjIt)
				{
					if ((*ObjIt)->GetClass()->GetName() == obj_type)
					{
						asset = (*ObjIt);
						break;
					}
				}
			}
			else if (res.Num() == 1)
			{
				asset = res[0];
			}
			else if (res.Num() > 0)
			{
				int32 Index = 0;
				if (strResName.FindLastChar(TEXT('/'), Index))
				{
					FString ObjName = strResName.RightChop(Index + 1);
					for (const auto& Obj : res)
					{
						if (Obj->GetName() == ObjName)
						{
							asset = Obj;
							break;
						}
					}
				}
			}

			if (asset != nullptr)
			{
				FLuaUtils::ReturnUObject(L, asset);
			}
			else
			{
				UE_LOG(LogAzure, Warning, TEXT("LuaSyncLoadResource failed to load : %s"), *strResName);
				lua_pushnil(L);
			}

			return 1;
		}

		int lua_IsResLoaded(lua_State* L)
		{
			const char* resname = luaL_checkstring(L, 1);
			FString strResName(UTF8_TO_TCHAR(resname));
			bool isLoaded = AzureResourceLoader::Get().IsGameResLoaded(resname);
			lua_pushboolean(L, isLoaded ? 1 : 0);
			return 1;
		}

		int lua_BlockTillAllRequestsFinished(lua_State * L)
		{
			IStreamingManager::Get().UpdateResourceStreaming(0, true);
			// Block till requests are finished.
			IStreamingManager::Get().BlockTillAllRequestsFinished();
			return 0;
		}

		int lua_FlushAsyncLoading(lua_State* L)
		{
			FlushAsyncLoading();
			return 0;
		}

		int lua_IsAsyncLoading(lua_State* L)
		{
			lua_pushboolean(L, IsAsyncLoading());
			return 1;
		}

		int lua_ManuallyReleaseResourcesAndPackage(lua_State* L)
		{
			UObject* obj = wLua::FLuaUtils::GetUObject(L, 1, "Object");

			if (obj == nullptr)
				return 0;

			bool succ = ManuallyReleaseResourcesAndPackage(obj);
			lua_pushboolean(L, succ);
			return 1;
		}

		int lua_ManuallyReleaseResources(lua_State* L)
		{
			UObject* obj = wLua::FLuaUtils::GetUObject(L, 1, "Object");

			if (obj == nullptr)
				return 0;

			bool succ = ManuallyReleaseResources(obj);
			lua_pushboolean(L, succ);
			return 1;
		}

		int lua_CheckClosePackageFileHandle(lua_State * L)
		{
			bool isOk = (GPlatformAFileWrapper == nullptr) || GPlatformAFileWrapper->CheckClosePackageFileHandle();
			lua_pushboolean(L, isOk ? 1 : 0);
			return 1;
		}

		int lua_AFileSystemEnable(lua_State * L)
		{
			bool Enable = !!lua_toboolean(L, 1);
			if (GPlatformAFileWrapper)
				GPlatformAFileWrapper->SetAFileSystemEnable(Enable);
			return 0;
		}

		int lua_CheckAFileSystemDisabled(lua_State * L)
		{
			bool ret = GPlatformAFileWrapper ? GPlatformAFileWrapper->CheckAFileSystemDisabled() : true;
			lua_pushboolean(L, ret);
			return 1;
		}

		int lua_SetAFileLocalizationLanguage(lua_State * L)
		{
			const char* lang = luaL_checkstring(L, 1);
			FString strLang(UTF8_TO_TCHAR(lang));
			FPlatformAFileWrapper::SetLocalizationLanguage(*strLang);
			return 0;
		}

		int lua_FlushRenderingCommands(lua_State * L)
		{
			FlushRenderingCommands();
			return 0;
		}

		int lua_AddLevelToWorld(lua_State * L)
		{
			UWorld* levelHolder = Cast<UWorld>(FLuaUtils::GetUObject(L, 1,"World"));
			ULevel* LevelToAdd = nullptr;

			if (levelHolder != nullptr)
			{
				if (!AAzureEntryPoint::Instance)
					return 0;

				LevelToAdd = AAzureEntryPoint::Instance->AddLevelToWorld(levelHolder);
			}

			if (LevelToAdd != nullptr)
				FLuaUtils::ReturnUObject(L, LevelToAdd);
			else
				lua_pushnil(L);

			return 1;
		}

		int lua_RemoveLevelFromWorld(lua_State * L)
		{
			ULevel* level = Cast<ULevel>(FLuaUtils::GetUObject(L, 1,"Level"));

			if (level != nullptr)
			{
				if (!AAzureEntryPoint::Instance)
					return 0;

				AAzureEntryPoint::Instance->RemoveLevelFromWorld(level);
			}
			return 0;
		}

		int lua_GetWorld(lua_State * L)
		{
			if (!AAzureEntryPoint::Instance)
				return 0;

			FLuaUtils::ReturnUObject(L, AAzureEntryPoint::Instance->GetWorld());
			return 1;
		}


		int lua_GetPlayerController(lua_State * L)
		{
			if (!AAzureEntryPoint::Instance)
				return 0;

			FLuaUtils::ReturnUObject(L, AAzureEntryPoint::Instance->GetPlayerController());
			return 1;
		}

		int lua_GetTransientPackage(lua_State * L)
		{
			if (!AAzureEntryPoint::Instance)
				return 0;

			FLuaUtils::ReturnUObject(L, GetTransientPackage());
			return 1;
		}

		//param 1: viewTargetActor, param 2: blendTime
		int lua_SetViewTarget(lua_State * L)
		{
			AActor* target;
			if (lua_isnoneornil(L, 1))
				target = nullptr;
			else
				target = Cast<AActor>(FLuaUtils::GetUObject(L, 1, "Actor"));

			FViewTargetTransitionParams TransitionParams;
			if (lua_isnumber(L, 2))
			{
				TransitionParams.BlendTime = (float)lua_tonumber(L, 2);
			}

			if (!AAzureEntryPoint::Instance)
				return 0;

			APlayerController* pCtrler = AAzureEntryPoint::Instance->GetPlayerController();
			if (pCtrler)
			{
				pCtrler->SetViewTarget(target, TransitionParams);
			}
			return 0;
		}

		int lua_GetViewTarget(lua_State * L)
		{
			if (!AAzureEntryPoint::Instance)
				return 0;

			APlayerController* pCtrler = AAzureEntryPoint::Instance->GetPlayerController();
			if (pCtrler)
			{
				if (auto&& viewTarget = pCtrler->GetViewTarget())
				{
					FLuaUtils::ReturnUObject(L, viewTarget);
					return 1;
				}
			}
			return 0;
		}

		int lua_FindObject(lua_State * L)
		{
			const char* ObjectName = luaL_checkstring(L, 1);
			UObject* Obj = FindObject<UObject>(ANY_PACKAGE, UTF8_TO_TCHAR(ObjectName));

			if (Obj != nullptr)
				FLuaUtils::ReturnUObject(L, Obj);
			else
				lua_pushnil(L);
			return 1;
		}

		int lua_AddressToObject(lua_State* L)
		{
			const char* address = luaL_checkstring(L, 1);
			void* ptr = reinterpret_cast<void*>(strtoll(address, nullptr, 16));
			UObject* Obj = (UObject*)ptr;

			if (Obj != nullptr)
				FLuaUtils::ReturnUObject(L, Obj);
			else
				lua_pushnil(L);
			return 1;
		}

		int lua_FindActorFast(lua_State * L)
		{
			const char* szName = luaL_checkstring(L, 1);
			ULevel* pLevel;
			if (lua_isnoneornil(L, 2))
			{
				if (!AAzureEntryPoint::Instance)
					return 0;

				UWorld* pWorld = AAzureEntryPoint::Instance->GetWorld();
				pLevel = pWorld ? pWorld->PersistentLevel : nullptr;
			}
			else
				pLevel = Cast<ULevel>(FLuaUtils::GetUObject(L, 2, "Level"));

			AActor* ret = FindObjectFast<AActor>(pLevel, UTF8_TO_TCHAR(szName));
			if (ret != nullptr)
				FLuaUtils::ReturnUObject(L, ret);
			else
				lua_pushnil(L);

			return 1;
		}

		int lua_FindActor(lua_State * L)
		{
			const char* targetName = luaL_checkstring(L, 1);
			FName targetFName = targetName;
			
			if (!AAzureEntryPoint::Instance)
				return 0;

			UWorld* pWorld = AAzureEntryPoint::Instance->GetWorld();
			AActor* ret = nullptr;
			for (TActorIterator<AActor> ActorIt(pWorld); ActorIt; ++ActorIt)
			{
				AActor* pActor = *ActorIt;
				FName actorName = pActor->GetFName();
				if (actorName == targetFName)
				{
					ret = pActor;
					break;
				}
			}
		
			if (ret != nullptr)
				FLuaUtils::ReturnUObject(L, ret);
			else
				lua_pushnil(L);

			return 1;
		}

		//param1: className, param2: outer (optional)
		int lua_FindActorByClass(lua_State* L)
		{
			const char* targetClassName = luaL_checkstring(L, 1);
			UObject* outer = nullptr;
			if (!lua_isnoneornil(L, 2))
			{
				outer = FLuaUtils::GetUObject(L, 2, "Object");
			}
			//需要空间，不然会和wLua中的接口冲突
			UClass* theClass = ::LoadClass<AActor>(nullptr, UTF8_TO_TCHAR(targetClassName));
			AActor* ret = nullptr;
			if (theClass)
			{
				if (!AAzureEntryPoint::Instance)
					return 0;

				UWorld* pWorld = AAzureEntryPoint::Instance->GetWorld();
				for (TActorIterator<AActor> ActorIt(pWorld); ActorIt; ++ActorIt)
				{
					AActor* pActor = *ActorIt;
					if ((!outer || pActor->GetOuter() == outer) && pActor->GetClass()->IsChildOf(theClass))
					{
						ret = pActor;
						break;
					}
				}
			}
		
			if (ret != nullptr)
				FLuaUtils::ReturnUObject(L, ret);
			else
				lua_pushnil(L);

			return 1;
		}

		int lua_RotatorRelativeToWorld(lua_State * L)
		{
			float rp = luaL_checknumber(L, 1);
			float ry = luaL_checknumber(L, 2);
			float rr = luaL_checknumber(L, 3);

			float p = luaL_checknumber(L, 4);
			float y = luaL_checknumber(L, 5);
			float r = luaL_checknumber(L, 6);

			const FQuat relQuat = FRotator(rp, ry, rr).Quaternion();
			const FQuat worldQuat = FRotator(p, y, r).Quaternion();
			FQuat retQuat = worldQuat * relQuat;
			FRotator retRot = retQuat.Rotator();

			lua_pushnumber(L, retRot.Pitch);
			lua_pushnumber(L, retRot.Yaw);
			lua_pushnumber(L, retRot.Roll);
			return 3;
		}

		int lua_RotatorFromVector(lua_State * L)
		{
			float x = luaL_checknumber(L, 1);
			float y = luaL_checknumber(L, 2);
			float z = luaL_checknumber(L, 3);
			FRotator rot = FVector(x, y, z).ToOrientationRotator();
			lua_pushnumber(L, rot.Pitch);
			lua_pushnumber(L, rot.Yaw);
			lua_pushnumber(L, rot.Roll);
			return 3;
		}

		int lua_MakeRotFromX(lua_State * L)
		{
			FVector vecX = wLua::FLuaVector::Get_Split(L, 1, 3);
			FRotator rot = UKismetMathLibrary::MakeRotFromX(vecX);
			lua_pushnumber(L, rot.Pitch);
			lua_pushnumber(L, rot.Yaw);
			lua_pushnumber(L, rot.Roll);
			return 3;
		}

		int lua_MakeRotFromXY(lua_State * L)
		{
			FVector vecX = wLua::FLuaVector::Get_Split(L, 1, 3);
			FVector vecY = wLua::FLuaVector::Get_Split(L, 4, 6);
			FRotator rot = UKismetMathLibrary::MakeRotFromXY(vecX, vecY);
			lua_pushnumber(L, rot.Pitch);
			lua_pushnumber(L, rot.Yaw);
			lua_pushnumber(L, rot.Roll);
			return 3;
		}

		int lua_MakeRotFromXZ(lua_State * L)
		{
			FVector vecX = wLua::FLuaVector::Get_Split(L, 1, 3);
			FVector vecZ = wLua::FLuaVector::Get_Split(L, 4, 6);
			FRotator rot = UKismetMathLibrary::MakeRotFromXZ(vecX, vecZ);
			lua_pushnumber(L, rot.Pitch);
			lua_pushnumber(L, rot.Yaw);
			lua_pushnumber(L, rot.Roll);
			return 3;
		}

		int lua_MakeRotFromY(lua_State * L)
		{
			FVector vecY = wLua::FLuaVector::Get_Split(L, 1, 3);
			FRotator rot = UKismetMathLibrary::MakeRotFromY(vecY);
			lua_pushnumber(L, rot.Pitch);
			lua_pushnumber(L, rot.Yaw);
			lua_pushnumber(L, rot.Roll);
			return 3;
		}

		int lua_MakeRotFromYZ(lua_State * L)
		{
			FVector vecY = wLua::FLuaVector::Get_Split(L, 1, 3);
			FVector vecZ = wLua::FLuaVector::Get_Split(L, 4, 6);
			FRotator rot = UKismetMathLibrary::MakeRotFromYZ(vecY, vecZ);
			lua_pushnumber(L, rot.Pitch);
			lua_pushnumber(L, rot.Yaw);
			lua_pushnumber(L, rot.Roll);
			return 3;
		}

		int lua_MakeRotFromYX(lua_State * L)
		{
			FVector vecY = wLua::FLuaVector::Get_Split(L, 1, 3);
			FVector vecX = wLua::FLuaVector::Get_Split(L, 4, 6);
			FRotator rot = UKismetMathLibrary::MakeRotFromYX(vecY, vecX);
			lua_pushnumber(L, rot.Pitch);
			lua_pushnumber(L, rot.Yaw);
			lua_pushnumber(L, rot.Roll);
			return 3;
		}

		int lua_MakeRotFromZ(lua_State * L)
		{
			FVector vecZ = wLua::FLuaVector::Get_Split(L, 1, 3);
			FRotator rot = UKismetMathLibrary::MakeRotFromZ(vecZ);
			lua_pushnumber(L, rot.Pitch);
			lua_pushnumber(L, rot.Yaw);
			lua_pushnumber(L, rot.Roll);
			return 3;
		}

		int lua_MakeRotFromZX(lua_State * L)
		{
			FVector vecZ = wLua::FLuaVector::Get_Split(L, 1, 3);
			FVector vecX = wLua::FLuaVector::Get_Split(L, 4, 6);
			FRotator rot = UKismetMathLibrary::MakeRotFromZX(vecZ, vecX);
			lua_pushnumber(L, rot.Pitch);
			lua_pushnumber(L, rot.Yaw);
			lua_pushnumber(L, rot.Roll);
			return 3;
		}

		int lua_MakeRotFromZY(lua_State * L)
		{
			FVector vecZ = wLua::FLuaVector::Get_Split(L, 1, 3);
			FVector vecY = wLua::FLuaVector::Get_Split(L, 4, 6);
			FRotator rot = UKismetMathLibrary::MakeRotFromZY(vecZ, vecY);
			lua_pushnumber(L, rot.Pitch);
			lua_pushnumber(L, rot.Yaw);
			lua_pushnumber(L, rot.Roll);
			return 3;
		}

		int lua_MakeRotFromXYZW(lua_State * L)
		{
			FVector vecX = wLua::FLuaVector::Get(L, 1);
			FVector vecY = wLua::FLuaVector::Get(L, 2);
			FVector vecZ = wLua::FLuaVector::Get(L, 3);
			FVector vecW = wLua::FLuaVector::Get(L, 4);
			FRotator rot = FMatrix(vecX, vecY, vecZ, vecW).Rotator();
			lua_pushnumber(L, rot.Pitch);
			lua_pushnumber(L, rot.Yaw);
			lua_pushnumber(L, rot.Roll);
			return 3;
		}

		int lua_RotatorToVector(lua_State * L)
		{
			float Pitch = luaL_checknumber(L, 1);
			float Yaw = luaL_checknumber(L, 2);
			float Roll = luaL_checknumber(L, 3);
			FVector vec = FRotator(Pitch, Yaw, Roll).Vector();
			lua_pushnumber(L, vec.X);
			lua_pushnumber(L, vec.Y);
			lua_pushnumber(L, vec.Z);
			return 3;
		}

		int lua_RotateVector(lua_State * L)
		{
			float Pitch = luaL_checknumber(L, 1);
			float Yaw = luaL_checknumber(L, 2);
			float Roll = luaL_checknumber(L, 3);
			float x = luaL_checknumber(L, 4);
			float y = luaL_checknumber(L, 5);
			float z = luaL_checknumber(L, 6);
			
			const FQuat relQuat = FRotator(Pitch, Yaw, Roll).Quaternion();
			FVector vec(x, y, z);
			vec = relQuat * vec;
			lua_pushnumber(L, vec.X);
			lua_pushnumber(L, vec.Y);
			lua_pushnumber(L, vec.Z);

			return 3;
		}

		int lua_UnrotateVector(lua_State * L)
		{
			float Pitch = luaL_checknumber(L, 1);
			float Yaw = luaL_checknumber(L, 2);
			float Roll = luaL_checknumber(L, 3);
			float x = luaL_checknumber(L, 4);
			float y = luaL_checknumber(L, 5);
			float z = luaL_checknumber(L, 6);

			const FQuat relQuat = FRotator(Pitch, Yaw, Roll).Quaternion();
			FVector vec(x, y, z);
			vec = relQuat.UnrotateVector(vec);
			lua_pushnumber(L, vec.X);
			lua_pushnumber(L, vec.Y);
			lua_pushnumber(L, vec.Z);
			return 3;
		}

		int lua_EulerToQuaternion(lua_State * L)
		{
			float Pitch = luaL_checknumber(L, 1);
			float Yaw = luaL_checknumber(L, 2);
			float Roll = luaL_checknumber(L, 3);

			const FQuat relQuat = FRotator(Pitch, Yaw, Roll).Quaternion();
			lua_pushnumber(L, relQuat.X);
			lua_pushnumber(L, relQuat.Y);
			lua_pushnumber(L, relQuat.Z);
			lua_pushnumber(L, relQuat.W);
			return 4;
		}

		int lua_QuaternionToEuler(lua_State * L)
		{
			float x = luaL_checknumber(L, 1);
			float y = luaL_checknumber(L, 2);
			float z = luaL_checknumber(L, 3);
			float w = luaL_checknumber(L, 4);

			const FQuat relQuat(x, y, z, w);
			const FRotator rotator = relQuat.Rotator();
			lua_pushnumber(L, rotator.Pitch);
			lua_pushnumber(L, rotator.Yaw);
			lua_pushnumber(L, rotator.Roll);
			return 3;
		}

		int lua_QuatLerp(lua_State * L)
		{
			float curX = luaL_checknumber(L, 1);
			float curY = luaL_checknumber(L, 2);
			float curZ = luaL_checknumber(L, 3);
			float curW = luaL_checknumber(L, 4);

			float dstX = luaL_checknumber(L, 5);
			float dstY = luaL_checknumber(L, 6);
			float dstZ = luaL_checknumber(L, 7);
			float dstW = luaL_checknumber(L, 8);

			float slerp = luaL_checknumber(L, 9);

			const FQuat curQuat(curX, curY, curZ, curW);
			const FQuat dstQuat(dstX, dstY, dstZ, dstW);
			const FQuat newQuat = FQuat::Slerp(curQuat, dstQuat, slerp);

			lua_pushnumber(L, newQuat.X);
			lua_pushnumber(L, newQuat.Y);
			lua_pushnumber(L, newQuat.Z);
			lua_pushnumber(L, newQuat.W);
			return 4;
		}

		int lua_QuatFastLerp(lua_State * L)
		{
			float curX = luaL_checknumber(L, 1);
			float curY = luaL_checknumber(L, 2);
			float curZ = luaL_checknumber(L, 3);
			float curW = luaL_checknumber(L, 4);

			float dstX = luaL_checknumber(L, 5);
			float dstY = luaL_checknumber(L, 6);
			float dstZ = luaL_checknumber(L, 7);
			float dstW = luaL_checknumber(L, 8);

			float slerp = luaL_checknumber(L, 9);

			const FQuat curQuat(curX, curY, curZ, curW);
			const FQuat dstQuat(dstX, dstY, dstZ, dstW);
			const FQuat newQuat = FQuat::FastLerp(curQuat, dstQuat, slerp);

			lua_pushnumber(L, newQuat.X);
			lua_pushnumber(L, newQuat.Y);
			lua_pushnumber(L, newQuat.Z);
			lua_pushnumber(L, newQuat.W);
			return 4;
		}

		int lua_GetUpVector(lua_State * L)
		{
			FRotator rot = wLua::FLuaRotator::Get(L, 1);
			FQuat quat = rot.Quaternion();
			FVector upVector = quat.GetUpVector();
			wLua::FLuaVector::Return(L, upVector);
			return 1;
		}

		int lua_GetForwardVector(lua_State * L)
		{
			FRotator rot = wLua::FLuaRotator::Get(L, 1);
			FQuat quat = rot.Quaternion();
			FVector upVector = quat.GetForwardVector();
			wLua::FLuaVector::Return(L, upVector);
			return 1;
		}

		int lua_GetRightVector(lua_State * L)
		{
			FRotator rot = wLua::FLuaRotator::Get(L, 1);
			FQuat quat = rot.Quaternion();
			FVector upVector = quat.GetRightVector();
			wLua::FLuaVector::Return(L, upVector);
			return 1;
		}


		int lua_GetVectorHeadingAngle(lua_State* L)
		{
			FVector v = wLua::FLuaVector::Get(L, 1);
			lua_pushnumber(L, v.HeadingAngle());;
			return 1;
		}

		int lua_ConstrainDirectionToPlane(lua_State* L)
		{
			FVector Dir = wLua::FLuaVector::Get(L, 1);
			FVector PanelNormal = wLua::FLuaVector::Get(L, 2);
			FVector Direction = FVector::VectorPlaneProject(Dir, PanelNormal);
			wLua::FLuaVector::Return(L, Direction);
			return 1;
		}

		int lua_GetAllObjectsQueryFlag(lua_State * L)
		{
			lua_pushnumber(L, (uint32)FCollisionQueryFlag::Get().GetAllObjectsQueryFlag());
			return 1;
		}

		int lua_GetMousePosition(lua_State * L)
		{
			if (!AAzureEntryPoint::Instance)
				return 0;

			ULocalPlayer* const LocalPlayer = AAzureEntryPoint::Instance->GetPlayerController()->GetLocalPlayer();
			if (LocalPlayer && LocalPlayer->ViewportClient)
			{
				FVector2D ScreenPosition;
				if (LocalPlayer->ViewportClient->GetMousePosition(ScreenPosition))
				{
					lua_pushboolean(L, 1);
					lua_pushnumber(L, ScreenPosition.X);
					lua_pushnumber(L, ScreenPosition.Y);
					return 3;
				}
			}

			lua_pushboolean(L, 0);
			return 1;
		}

		int lua_CalAbsPosInfo(lua_State * L)
		{
			float rx = luaL_checknumber(L, 1);
			float ry = luaL_checknumber(L, 2);
			float rz = luaL_checknumber(L, 3);

			float r_dirx = luaL_checknumber(L, 4);
			float r_diry = luaL_checknumber(L, 5);
			float r_dirz = luaL_checknumber(L, 6);

			float cx = luaL_checknumber(L, 7);
			float cy = luaL_checknumber(L, 8);
			float cz = luaL_checknumber(L, 9);

			float c_dirx = luaL_checknumber(L, 10);
			float c_diry = luaL_checknumber(L, 11);
			float c_dirz = luaL_checknumber(L, 12);

			FVector rel_pos(rx,ry,rz);
			FVector rel_dir(r_dirx, r_diry, r_dirz);

			FVector carrier_pos(cx, cy, cz);
			FVector carrier_dir(c_dirx, c_diry, c_dirz);

			FVector abs_pos, abs_dir;
			AzureUtility::CalAbsPosInfo(rel_pos, rel_dir.Rotation(), carrier_pos, carrier_dir.Rotation(), abs_pos, abs_dir);


			lua_pushnumber(L, abs_pos.X);
			lua_pushnumber(L, abs_pos.Y);
			lua_pushnumber(L, abs_pos.Z);
			lua_pushnumber(L, abs_dir.X);
			lua_pushnumber(L, abs_dir.Y);
			lua_pushnumber(L, abs_dir.Z);
			return 6;
		}
#if UE_EDITOR
		static void AzureQueryReflectorWidgets(TArray<TSharedRef<SWidget>>& QueriedWidgets)
		{
			lua_State_Wrapper L = AAzureEntryPoint::SafeGetL();
			if (!L)
			{
				return;
			}

			if (!AAzureEntryPoint::Instance)
				return;

			wLua::Lua* wlua = AAzureEntryPoint::Instance->GetWLua();
			int top = lua_gettop(L);
			lua_getglobal(L, "QueryReflectorWidgets");
			if (lua_isfunction(L, -1))
			{
				wlua->PCall(0, 1);
				if (lua_istable(L, -1))
				{
					lua_pushnil(L);
					while (lua_next(L, -2) != 0)
					{
						UObject* Obj = wLua::FLuaUtils::GetUObject(L, -1, "Widget");
						UWidget * Widget = Cast<UWidget>(Obj);
						if (Widget)
						{
							QueriedWidgets.Add(Widget->TakeWidget());
						}
						else
						{
							break;
						}
						lua_pop(L, 1);
					}
				}
			}

			lua_settop(L, top);
		}
		int lua_EnableSlateReflectorQueryWidgets(lua_State * L)
		{
			if (SlateHierarchy::FGlobalOnSlateReflectorQuery.IsBound())
			{
				return 0;
			}
			SlateHierarchy::FGlobalOnSlateReflectorQuery.BindStatic(&AzureQueryReflectorWidgets);
			return 0;
		}
#endif

		int lua_AddOnScreenDebugMessage(lua_State * L)
		{
			int Key = luaL_checkinteger(L, 1);
			float TimeToDisplay = (float)luaL_checknumber(L, 2);
			uint32 cl = (uint32)luaL_checknumber(L, 3);
			const char* DebugMessage = luaL_checkstring(L, 4);
			static int msg_id = 0;
			FString s = FString::Printf(TEXT("%d Lua: %s"), ++msg_id, UTF8_TO_TCHAR(DebugMessage));
			GEngine->AddOnScreenDebugMessage(Key, TimeToDisplay, FColor(cl), s);
			return 0;
		}

		int lua_GetAllActorsByName(lua_State* L)
		{
			if (!AAzureEntryPoint::Instance)
				return 0;

			UWorld* pWorld = AAzureEntryPoint::Instance->GetWorld();
			if (!pWorld)
				return 0;

			const char* szName = lua_tostring(L, 1);
			FString strName = UTF8_TO_TCHAR(szName);
			lua_newtable(L);
			int i = 1;
			for (TActorIterator<AActor> ActorItr(pWorld); ActorItr; ++ActorItr)
			{
				if (ActorItr->GetName().Find(strName) != INDEX_NONE)
				{
					wLua::FLuaUtils::ReturnUObject(L, (*ActorItr));
					lua_rawseti(L, -2, i);
					i++;
				}
			}
			return 1;
		}

		int lua_GetActorsByClass(lua_State* L)
		{
			if (!AAzureEntryPoint::Instance)
				return 0;

			UWorld* pWorld = AAzureEntryPoint::Instance->GetWorld();
			if (!pWorld)
				return 0;

			UClass* Class = Cast<UClass>(FLuaUtils::GetUObject(L, 1, "Class"));

			lua_newtable(L);
			int i = 1;
			for (TActorIterator<AActor> ActorItr(pWorld); ActorItr; ++ActorItr)
			{
				if (ActorItr->GetClass() == Class)
				{
					wLua::FLuaUtils::ReturnUObject(L, (*ActorItr));
					lua_rawseti(L, -2, i);
					i++;
				}
			}

			return 1;
		}

		int lua_GetActorsByTags(lua_State* L)
		{
			if (!AAzureEntryPoint::Instance)
				return 0;

			UWorld* pWorld = AAzureEntryPoint::Instance->GetWorld();
			if (!pWorld)
				return 0;

			if (!lua_istable(L, 1))
			{
				lua_pushstring(L, "GetActorsByTags: param must be table(tags)");
				lua_error(L);
				return 1;
			}

			TArray<FName> tags;
			{
				lua_pushnil(L);
				while (lua_next(L, 1) != 0)
				{
					FName tag(UTF8_TO_TCHAR(luaL_checkstring(L, -1)));
					tags.Add(tag);
					lua_pop(L, 1);
				}
			}

			int CheckCount = lua_tointeger(L, 2);

			auto checkTags = [CheckCount](const TArray<FName>& tags, const TArray<FName>& tagsB) -> bool
			{
				if (CheckCount > 0)
				{
					if (tags.Num() < CheckCount || tagsB.Num() < CheckCount)
						return false;

					for (int i = 0; i < CheckCount; i++)
					{
						if (tags[i] != tagsB[i])
							return false;
					}

					return true;
				}
				else
				{
					return tags == tagsB;
				}
			};

			lua_newtable(L);
			int i = 1;
			for (TActorIterator<AActor> ActorItr(pWorld); ActorItr; ++ActorItr)
			{
				if (checkTags(ActorItr->Tags, tags))
				{
					wLua::FLuaUtils::ReturnUObject(L, (*ActorItr));
					lua_rawseti(L, -2, i);
					i++;
				}
			}

			return 1;
		}
		
		int lua_GetAllActors(lua_State* L)
		{
			if (!AAzureEntryPoint::Instance)
				return 0;

			UWorld* pWorld = AAzureEntryPoint::Instance->GetWorld();
			if (!pWorld)
				return 0;
	
			const char* szName = lua_tostring(L, 1);
			FString strName = UTF8_TO_TCHAR(szName);
			lua_newtable(L);
			int i = 1;
			for (TActorIterator<AActor> ActorItr(pWorld); ActorItr; ++ActorItr)
			{
				wLua::FLuaUtils::ReturnUObject(L, (*ActorItr));
				lua_rawseti(L, -2, i);
				i++;
			}
			return 1;
		}

		int lua_SetMaterialsQualityLevelByName(lua_State* L)
		{
			if (!AAzureEntryPoint::Instance)
				return 0;

			UWorld* pWorld = AAzureEntryPoint::Instance->GetWorld();
			if (!pWorld)
				return 0;

			int findIndex;
			FString inputStr = UTF8_TO_TCHAR(lua_tostring(L, 1));
			TArray<FString> nameList;
			while (inputStr.FindChar(';', findIndex))
			{
				nameList.Add(inputStr.Left(findIndex));
				inputStr = inputStr.RightChop(findIndex + 1);
			}
			nameList.Add(inputStr);

			int32 qualityLv = (int32)luaL_checknumber(L, 2);
			EMaterialQualityLevel::Type levelEnum = (EMaterialQualityLevel::Type)qualityLv;

			bool force = lua_isnoneornil(L, 3) ? false : !!lua_toboolean(L, 3);
			bool bNoRemap = lua_isnoneornil(L, 4) ? false : !!lua_toboolean(L, 4);;

			TArray<UActorComponent*> compsList;
			TArray<UMaterialInterface*> tempMatsList;
			for (TActorIterator<AActor> ActorItr(pWorld); ActorItr; ++ActorItr)
			{
				compsList.Reset();
				compsList = ActorItr->GetComponentsByClass(UPrimitiveComponent::StaticClass());

				for (UActorComponent *actorComp : compsList)
				{
					if (!IsValid(actorComp)) continue;

					bool isIgnore = !actorComp->IsA(UPrimitiveComponent::StaticClass());
					if (isIgnore) continue;

					isIgnore = !actorComp->IsA(UStaticMeshComponent::StaticClass());
					isIgnore = isIgnore && !actorComp->IsA(USkeletalMeshComponent::StaticClass());
					if (isIgnore) continue;

					UPrimitiveComponent *primitiveComp = Cast<UPrimitiveComponent>(actorComp);
					tempMatsList.Reset();
					primitiveComp->GetUsedMaterials(tempMatsList);

					for (UMaterialInterface *mat : tempMatsList)
					{
						if (!::IsValid(mat)) continue;

						bool isFound = false;
						FString matName = mat->GetMaterial()->GetName();
						for (const FString &oneName : nameList)
						{
							if (matName.Contains(oneName))
							{
								primitiveComp->SetMaterialQualityLevel(levelEnum, force, bNoRemap);
								isFound = true;
								break;
							}
						}

						if (isFound) break;
					}
				}
			}
			return 1;
		}

		int lua_DrawDebugLine(lua_State* L)
		{
			if (!AAzureEntryPoint::Instance)
				return 0;

			UWorld* pWorld = AAzureEntryPoint::Instance->GetWorld();
			if (!pWorld)
				return 0;

			FVector start = wLua::FLuaVector::Get(L, 1);
			start = POS_FROM_SERVER(start);

			FVector end = wLua::FLuaVector::Get(L, 2);
			end = POS_FROM_SERVER(end);

			FColor color(wLua::FLuaLinearColor::GetColor(L, 3));

			float lifetime = lua_isnoneornil(L, 4) ? 10.f : (float)lua_tonumber(L, 4);

			DrawDebugLine(pWorld, start, end, color, true, lifetime);
			return 0;
		}

		int lua_DrawDebugPoint(lua_State* L)
		{
			if (!AAzureEntryPoint::Instance)
				return 0;

			UWorld* pWorld = AAzureEntryPoint::Instance->GetWorld();
			if (!pWorld)
				return 0;

			FVector pos = wLua::FLuaVector::Get(L, 1);
			pos = POS_FROM_SERVER(pos);

			float size = (float)luaL_checknumber(L, 2);
			size *= UE_METRE_TRANS;

			FColor color(wLua::FLuaLinearColor::GetColor(L, 3));

			float lifetime = lua_isnoneornil(L, 4) ? 10.f : (float)lua_tonumber(L, 4);

			DrawDebugPoint(pWorld, pos, size, color, true, lifetime);
			return 0;
		}

		int lua_DrawDebugDirectionalArrow(lua_State* L)
		{
			if (!AAzureEntryPoint::Instance)
				return 0;

			UWorld* pWorld = AAzureEntryPoint::Instance->GetWorld();
			if (!pWorld)
				return 0;

			FVector start = wLua::FLuaVector::Get(L, 1);
			start = POS_FROM_SERVER(start);

			FVector end = wLua::FLuaVector::Get(L, 2);
			end = POS_FROM_SERVER(end);

			float arrowSize = (float)luaL_checknumber(L, 3);
			arrowSize *= UE_METRE_TRANS;

			FColor color(wLua::FLuaLinearColor::GetColor(L, 4));

			float lifetime = lua_isnoneornil(L, 5) ? 10.f : (float)lua_tonumber(L, 5);

			DrawDebugDirectionalArrow(pWorld, start, end, arrowSize, color, true, lifetime);
			return 0;
		}

		int lua_DrawDebugBox(lua_State* L)
		{
			if (!AAzureEntryPoint::Instance)
				return 0;

			UWorld* pWorld = AAzureEntryPoint::Instance->GetWorld();
			if (!pWorld)
				return 0;

			FVector center = wLua::FLuaVector::Get(L, 1);
			center = POS_FROM_SERVER(center);

			FVector extend = wLua::FLuaVector::Get(L, 2);
			extend = POS_FROM_SERVER(extend);

			FRotator rot = wLua::FLuaRotator::Get(L, 3);
			FQuat quat = rot.Quaternion();

			bool bSolid = !!lua_toboolean(L, 4);

			FColor color(wLua::FLuaLinearColor::GetColor(L, 5));

			float lifetime = lua_isnoneornil(L, 6) ? 10.f : (float)lua_tonumber(L, 6);

			if (bSolid)
				DrawDebugSolidBox(pWorld, center, extend, quat, color, true, lifetime);
			else
				DrawDebugBox(pWorld, center, extend, quat, color, true, lifetime);
			return 0;
		}


		int lua_DrawDebugCoordinateSystem(lua_State* L)
		{
			if (!AAzureEntryPoint::Instance)
				return 0;

			UWorld* pWorld = AAzureEntryPoint::Instance->GetWorld();
			if (!pWorld)
				return 0;

			FVector pos = wLua::FLuaVector::Get(L, 1);
			pos = POS_FROM_SERVER(pos);

			FRotator rot = wLua::FLuaRotator::Get(L, 2);

			float scale = (float)luaL_checknumber(L, 3);
			scale *= UE_METRE_TRANS;

			float lifetime = lua_isnoneornil(L, 4) ? 10.f : (float)lua_tonumber(L, 4);

			DrawDebugCoordinateSystem(pWorld, pos, rot, scale, true, lifetime);
			return 0;
		}

		int lua_DrawDebugCircle(lua_State* L)
		{
			if (!AAzureEntryPoint::Instance)
				return 0;

			UWorld* pWorld = AAzureEntryPoint::Instance->GetWorld();
			if (!pWorld)
				return 0;

			FVector Center = wLua::FLuaVector::Get(L, 1);
			Center = POS_FROM_SERVER(Center);

			float radius = (float)luaL_checknumber(L, 2);
			radius *= UE_METRE_TRANS;

			int segments = luaL_checkint(L, 3);

			FColor color(wLua::FLuaLinearColor::GetColor(L, 4));

			float lifetime = lua_isnoneornil(L, 5) ? 10.f : (float)lua_tonumber(L, 5);

			DrawDebugCircle(pWorld, Center, radius, segments, color, true, lifetime);
			return 0;
		}

		int lua_DrawDebugSphere(lua_State* L)
		{
			if (!AAzureEntryPoint::Instance)
				return 0;

			UWorld* pWorld = AAzureEntryPoint::Instance->GetWorld();
			if (!pWorld)
				return 0;

			FVector Center = wLua::FLuaVector::Get(L, 1);
			Center = POS_FROM_SERVER(Center);

			float radius = (float)luaL_checknumber(L, 2);
			radius *= UE_METRE_TRANS;

			int segments = luaL_checkint(L, 3);

			FColor color(wLua::FLuaLinearColor::GetColor(L, 4));

			float lifetime = lua_isnoneornil(L, 5) ? 10.f : (float)lua_tonumber(L, 5);

			DrawDebugSphere(pWorld, Center, radius, segments, color, true, lifetime);
			return 0;
		}

		int lua_DrawDebugCylinder(lua_State* L)
		{
			if (!AAzureEntryPoint::Instance)
				return 0;

			UWorld* pWorld = AAzureEntryPoint::Instance->GetWorld();
			if (!pWorld)
				return 0;

			FVector start = wLua::FLuaVector::Get(L, 1);
			start = POS_FROM_SERVER(start);

			FVector end = wLua::FLuaVector::Get(L, 2);
			end = POS_FROM_SERVER(end);

			float radius = (float)luaL_checknumber(L, 3);
			radius *= UE_METRE_TRANS;

			int segments = luaL_checkint(L, 4);

			FColor color(wLua::FLuaLinearColor::GetColor(L, 5));

			float lifetime = lua_isnoneornil(L, 6) ? 10.f : (float)lua_tonumber(L, 6);

			DrawDebugCylinder(pWorld, start, end, radius, segments, color, true, lifetime);
			return 0;
		}

		int lua_DrawDebugCone(lua_State* L)
		{
			if (!AAzureEntryPoint::Instance)
				return 0;

			UWorld* pWorld = AAzureEntryPoint::Instance->GetWorld();
			if (!pWorld)
				return 0;

			FVector origin = wLua::FLuaVector::Get(L, 1);
			origin = POS_FROM_SERVER(origin);

			FVector direction = wLua::FLuaVector::Get(L, 2);
			direction = DIR_FROM_SERVER(direction);

			float length = (float)luaL_checknumber(L, 3);
			length *= UE_METRE_TRANS;

			float angleWidth = (float)luaL_checknumber(L, 4);
			float angleHeight = (float)luaL_checknumber(L, 5);

			int numSides = luaL_checkint(L, 6);

			FColor color(wLua::FLuaLinearColor::GetColor(L, 7));

			float lifetime = lua_isnoneornil(L, 8) ? 10.f : (float)lua_tonumber(L, 8);

			DrawDebugCone(pWorld, origin, direction, length, angleWidth, angleHeight, numSides, color, true, lifetime);
			return 0;
		}

		int lua_DrawDebugSector(lua_State* L)
		{
			if (!AAzureEntryPoint::Instance)
				return 0;

			UWorld* pWorld = AAzureEntryPoint::Instance->GetWorld();
			if (!pWorld)
				return 0;

			FVector center = wLua::FLuaVector::Get(L, 1);
			center = POS_FROM_SERVER(center);

			FRotator rotator = wLua::FLuaRotator::Get(L, 2);

			float radius = (float)luaL_checknumber(L, 3);
			radius *= UE_METRE_TRANS;

			float angle = (float)luaL_checknumber(L, 4);

			float height = (float)luaL_checknumber(L, 5);
			height *= UE_METRE_TRANS;
			
			int segments = luaL_checkint(L, 6);

			FColor color(wLua::FLuaLinearColor::GetColor(L, 7));

			float lifetime = lua_isnoneornil(L, 8) ? 10.f : (float)lua_tonumber(L, 8);

			DrawDebugSector(pWorld, center, rotator, radius, angle, height, segments, color, true, lifetime);
			return 0;
		}

		int lua_DrawDebug3DDonut(lua_State* L)
		{
			if (!AAzureEntryPoint::Instance)
				return 0;

			UWorld* pWorld = AAzureEntryPoint::Instance->GetWorld();
			if (!pWorld)
				return 0;

			FVector center = wLua::FLuaVector::Get(L, 1);
			center = POS_FROM_SERVER(center);

			FRotator rotator = wLua::FLuaRotator::Get(L, 2);

			float innerRadius = (float)luaL_checknumber(L, 3);
			innerRadius *= UE_METRE_TRANS;

			float outerRadius = (float)luaL_checknumber(L, 4);
			outerRadius *= UE_METRE_TRANS;

			float height = (float)luaL_checknumber(L, 5);
			height *= UE_METRE_TRANS;

			int segments = luaL_checkint(L, 6);

			FColor color(wLua::FLuaLinearColor::GetColor(L, 7));

			float lifetime = lua_isnoneornil(L, 8) ? 10.f : (float)lua_tonumber(L, 8);

			DrawDebug3DDonut(pWorld, center, rotator, innerRadius, outerRadius, height, segments, color, true, lifetime);
			return 0;
		}

		int lua_DrawDebugCapsule(lua_State* L)
		{
			if (!AAzureEntryPoint::Instance)
				return 0;

			UWorld* pWorld = AAzureEntryPoint::Instance->GetWorld();
			if (!pWorld)
				return 0;

			FVector Center = wLua::FLuaVector::Get(L, 1);
			Center = POS_FROM_SERVER(Center);

			float halfhei = (float)luaL_checknumber(L, 2);
			halfhei *= UE_METRE_TRANS;

			float radius = (float)luaL_checknumber(L, 3);
			radius *= UE_METRE_TRANS;

			FRotator rot = wLua::FLuaRotator::Get(L, 4);

			FColor color(wLua::FLuaLinearColor::GetColor(L, 5));

			float lifetime = lua_isnoneornil(L, 6) ? 10.f : (float)lua_tonumber(L, 6);

			DrawDebugCapsule(pWorld, Center, halfhei, radius, rot.Quaternion(), color, true, lifetime);
			return 0;
		}
		
		int lua_DrawDebugString(lua_State* L)
		{
			if (!AAzureEntryPoint::Instance)
				return 0;

			UWorld* pWorld = AAzureEntryPoint::Instance->GetWorld();
			if (!pWorld)
				return 0;

			FVector pos = wLua::FLuaVector::Get(L, 1);
			pos = POS_FROM_SERVER(pos);

			const char* sztext = lua_tostring(L, 2);
			FString text = UTF8_TO_TCHAR(sztext);

			FColor color(FColor::White);
			if (!lua_isnoneornil(L, 3))
				color = wLua::FLuaLinearColor::GetColor(L, 3);

			float lifetime = lua_isnoneornil(L, 4) ? 10.f : (float)lua_tonumber(L, 4);

			DrawDebugString(pWorld, pos, text, NULL, color, lifetime);
			return 0;
		}
		
		//	MipMap
		int lua_CutOffMipMap_SetAtSerialize(lua_State* L)
		{
#if !WITH_EDITOR
			int32 AtSerialize = (int32)luaL_checkinteger(L, 1);

			static auto CutOffMipMapAtSerializeCVar = IConsoleManager::Get().FindConsoleVariable(TEXT("r.CutOffMipMap.AtSerialize"));
			CutOffMipMapAtSerializeCVar->SetWithCurrentPriority(AtSerialize);
#endif
			return 0;
		}

#if !WITH_EDITOR
		static IConsoleVariable* FindCutOffMipMapCountCVarForTextureGroup(int32 TextureGroup)
		{
			FString ConsoleVariableName = FString::Printf(TEXT("r.CutOffMipMap.TEXTUREGROUP_%d.Count"), TextureGroup);
			return IConsoleManager::Get().FindConsoleVariable(*ConsoleVariableName);
		}
		static bool SetCutOffMipCountForTextureGroup(int32 TextureGroup, int32 CutOffMipCount)
		{
			if (auto CVar = FindCutOffMipMapCountCVarForTextureGroup(TextureGroup))
			{
				CVar->SetWithCurrentPriority(CutOffMipCount);
				return true;
			}
			else
			{
				return false;
			}
		}
		static bool GetCutOffMipCountForTextureGroup(int32 TextureGroup, int32& CutOffMipCount)
		{
			if (auto CVar = FindCutOffMipMapCountCVarForTextureGroup(TextureGroup))
			{
				CutOffMipCount = CVar->GetInt();
				return true;
			}
			else
			{
				return false;
			}
		}
#endif	//	#if !WITH_EDITOR

		int lua_CutOffMipMap_SetCount(lua_State* L)
		{
#if !WITH_EDITOR
			int32 TextureGroup = (int32)luaL_checkinteger(L, 1);
			if (TextureGroup < 0 || TextureGroup >= TEXTUREGROUP_MAX)
			{
				char ErrorBuffer[256];
				printf(ErrorBuffer, "CutOffMipMap_SetCount, invalid TextureGroup:%d", TextureGroup);
				wLua::LuaStatic::traceback(L, ErrorBuffer);
				lua_error(L);
				return 1;
			}
			int32 CutOffMipCount = (int32)luaL_checkinteger(L, 2);
			if (CutOffMipCount < 0)
			{
				char ErrorBuffer[256];
				printf(ErrorBuffer, "CutOffMipMap_SetCount(TextureGroup=%d), invalid count:%d", TextureGroup, CutOffMipCount);
				wLua::LuaStatic::traceback(L, ErrorBuffer);
				lua_error(L);
				return 1;
			}
			if (!SetCutOffMipCountForTextureGroup(TextureGroup, CutOffMipCount))
			{
				char ErrorBuffer[256];
				printf(ErrorBuffer, "CutOffMipMap_SetCount(TextureGroup=%d, Count=%d), failed", TextureGroup, CutOffMipCount);
				wLua::LuaStatic::traceback(L, ErrorBuffer);
				lua_error(L);
				return 1;
			}
#endif
			return 0;
		}

		int lua_CutOffMipMap_ClearCount(lua_State* L)
		{
#if !WITH_EDITOR
			int32 TextureGroup = (int32)luaL_checkinteger(L, 1);
			if (TextureGroup < 0 || TextureGroup >= TEXTUREGROUP_MAX)
			{
				char ErrorBuffer[256];
				printf(ErrorBuffer, "CutOffMipMap_ClearCount, invalid TextureGroup:%d", TextureGroup);
				wLua::LuaStatic::traceback(L, ErrorBuffer);
				lua_error(L);
				return 1;
			}
			if (!SetCutOffMipCountForTextureGroup(TextureGroup, 0))
			{
				char ErrorBuffer[256];
				printf(ErrorBuffer, "CutOffMipMap_ClearCount(TextureGroup=%d), failed", TextureGroup);
				wLua::LuaStatic::traceback(L, ErrorBuffer);
				lua_error(L);
				return 1;
			}
#endif
			return 0;
		}

		int lua_CutOffMipMap_GetCount(lua_State* L)
		{
#if !WITH_EDITOR
			int32 TextureGroup = (int32)luaL_checkinteger(L, 1);
			if (TextureGroup < 0 || TextureGroup >= TEXTUREGROUP_MAX)
			{
				char ErrorBuffer[256];
				printf(ErrorBuffer, "CutOffMipMap_GetCount, invalid TextureGroup:%d", TextureGroup);
				wLua::LuaStatic::traceback(L, ErrorBuffer);
				lua_error(L);
				return 1;
			}
			int32 CutOffMipCount = 0;
			if (!GetCutOffMipCountForTextureGroup(TextureGroup, CutOffMipCount))
			{
				char ErrorBuffer[256];
				printf(ErrorBuffer, "CutOffMipMap_GetCount(TextureGroup=%d), failed", TextureGroup);
				wLua::LuaStatic::traceback(L, ErrorBuffer);
				lua_error(L);
				return 1;
			}
			lua_pushnumber(L, CutOffMipCount);
			return 1;
#else
			lua_pushnumber(L, 0);
			return 1;
#endif
		}

		int lua_getSystemTime(lua_State *L)
		{
			int year = 0, month = 0, day = 0, hour = 0, min = 0, sec = 0, dow = 0;

			FDateTime curDateTime = FDateTime::Now();
			year = curDateTime.GetYear();
			month = curDateTime.GetMonth();
			day = curDateTime.GetDay();
			hour = curDateTime.GetHour();
			min = curDateTime.GetMinute();
			sec = curDateTime.GetSecond();
			dow = (int)curDateTime.GetDayOfWeek();
			lua_pushnumber(L, year);
			lua_pushnumber(L, month);
			lua_pushnumber(L, day);
			lua_pushnumber(L, hour);
			lua_pushnumber(L, min);
			lua_pushnumber(L, sec);
			lua_pushnumber(L, dow + 1);
			return 7;
		}

		int lua_getNetInfoStates(lua_State* L)
		{
			int state = 0; // 0 - PC, 1 - Android, 2 - IOS
#if PLATFORM_WINDOWS
#elif PLATFORM_IOS
			bool isWifi = FPlatformMisc::HasActiveWiFiConnection();
			state = isWifi ? 3 : 4;
#else
			bool isWifi = FPlatformMisc::HasActiveWiFiConnection();
			state = isWifi ? 1 : 2;
#endif
			lua_pushnumber(L, state);
			return 1;
		}

		int lua_getBatteryLevel(lua_State* L)
		{
			int level = 0;
			bool isCharging = false;
#if PLATFORM_WINDOWS
			level = 50;
#elif PLATFORM_IOS
			level = FIOSPlatformMisc::GetBatteryLevel();
			isCharging = !FIOSPlatformMisc::IsRunningOnBattery();
#else
			FAndroidMisc::FBatteryState state = FAndroidMisc::GetBatteryState();
			level = state.Level;
			isCharging = (state.State == FAndroidMisc::BATTERY_STATE_CHARGING);
#endif
			lua_pushnumber(L, level);
			lua_pushboolean(L, isCharging);
			return 2;
		}

#if PLATFORM_IOS
		int lua_getMainscreenScale(lua_State* L)
		{
			float scale = [UIScreen mainScreen].scale;
			lua_pushnumber(L, scale);
			return 1;
		}
		int lua_getMainscreenBoundSize(lua_State* L)
		{
			CGSize result = [[UIScreen mainScreen] bounds].size;
			lua_pushnumber(L, result.width);
			lua_pushnumber(L, result.height);
			return 2;
		}
		int lua_getUIUserInterfaceIdiom(lua_State* L)
		{
			lua_pushnumber(L, (int)(UI_USER_INTERFACE_IDIOM()));
			return 1;
		}
#endif
		static int lua_OnHeadPhonePlugin(lua_State* L)
		{
			FCoreDelegates::GetHeadPhonePluginDelegate().BindLambda([](bool isHeadPhonePlugin)
			{
				if (!AAzureEntryPoint::IsInit())
					return;

				wLua::Lua* wlua = AAzureEntryPoint::Instance->GetWLua();
				lua_State_Wrapper L = wlua->GetL();				
				lua_getglobal(L, "OnHeadPhonePlugin");
				lua_pushboolean(L, isHeadPhonePlugin);
				wlua->Call(1, 0);

			});
			return 0;
		}

		int lua_isHeadPhonesPlugin(lua_State* L)
		{
			bool isHeadPhonePlugin = false;
#if PLATFORM_ANDROID
			isHeadPhonePlugin = FAndroidMisc::AreHeadPhonesPluggedIn();
#elif PLATFORM_IOS
			isHeadPhonePlugin = FIOSPlatformMisc::AreHeadphonesPluggedIn();
#endif
			lua_pushboolean(L, isHeadPhonePlugin);
			return 1;
		}

		enum PERFORM_FLAGS
		{
			PERFORM_FLAGS_TARGET_LIST = 0x0001, //击中目标列表
			PERFORM_FLAGS_MOVE = 0x0002, //有发生位移
			PERFORM_FLAGS_DIR = 0x0004, //有朝向变化
			PERFORM_FLAGS_PERSIST_MOVE = 0x0008, //(发生位移但)非瞬移
			PERFORM_FLAGS_DISPLAYE = 0x0010,	//需要广播，有动作
			PERFORM_FLAGS_TIME_CHANGED = 0x0020,	//perform时间有变化
			PERFORM_FLAGS_1ST_PERFORM = 0x0040, //这是第1个Perform
			PERFORM_FLAGS_LIAN_XIE    = 0x0080, //连携技能
			PERFORM_FLAGS_CHAIN       = 0x0100, //闪电链
		};

		static void CreateCacheTable(lua_State *L, const char* tablename)
		{
			lua_getfield(L, LUA_REGISTRYINDEX, tablename);
			if (lua_isnil(L, -1))
			{
				lua_pop(L, 1); // none
				lua_newtable(L); // tablename
				lua_pushvalue(L, -1); // tablename, tablename
				lua_setfield(L, LUA_REGISTRYINDEX, tablename); // tablename
			}
		}

		static bool IsEnableNetworkDebug()
		{
			if (!AAzureEntryPoint::Instance)
				return 0;

			lua_State_Wrapper L = AAzureEntryPoint::Instance->GetWLua()->GetL();
			bool bEnabled = false;
			lua_getglobal(L, "ENABLE_PROTOCOL_DEBUG");
			if (lua_isboolean(L, -1))
				bEnabled = lua_toboolean(L, -1) != 0;
			lua_pop(L, 1);
			return bEnabled;
		}

		static int OnPrtc_GameDataSend(lua_State *L)
		{
			if (!AAzureEntryPoint::Instance)
				return 0;

			//UE_LOG(LogAzure, Log, TEXT("OnPrtc_GameDataSend"));
			wLua::Lua* pLua = AAzureEntryPoint::Instance->GetWLua();
			if (!pLua)
			{
				//assert(pLua);
				return 0;
			}
			
			GNET::CommonData* proto = (GNET::CommonData*)AzureHelpFuncs::GetObject(L, 1, LuaCommonData::mt_name);
			GNET::Marshal::OctetsStream* os = proto->GetStreamData();

			unsigned int data_len = 0;
			const void* data_begin = os->raw_read_octets(data_len);
			AzureBinaryReader br(data_begin, data_len,false);

			uint16 cmd_type = br.ReadUInt16();
			//UE_LOG(LogAzure, Log, TEXT("C++ parse protocol cmd_type: %d"), cmd_type);

			//Profiler.BeginSample("OnPrtc_GameDataSend" + cmd_type.ToString());   // inner protocol type id.
			//double dt = server_send_time - ECTimeManager.GetMillisecondsFromEpoch();
			//ECTimeManager.ServerDeltaTime = dt;
			double dt = 0;
			//int start = DateTime.Now.Millisecond;
			int start = 0;
			bool bHandledInLua = false;
			int offsetBackup = br.get_pos();

			if (AzureGameSession::GameDataSendFilterList.find(cmd_type) != AzureGameSession::GameDataSendFilterList.end())
			{
				lua_getglobal(L, "ProcessGameDataSend");
				lua_pushnumber(L, cmd_type);
				auto brForLua = new AzureBinaryReader(std::move(br));
				AzureHelpFuncs::ReturnObject(L, brForLua, LuaAzureBinaryReader::mt_name);
				lua_pushnumber(L, dt);
				pLua->Call(3);
				return 0;
			}

			switch ((int)cmd_type)
			{
			case (int)S2C::S2C_COMMAND::OBJECT_MOVE:
			{
				int new_who = br.ReadInt32();
				float x = br.ReadSingle();
				float y = br.ReadSingle();
				float z = br.ReadSingle();
				AzureWorldWrap::Instance().UnwrapPosition(x, z);
				uint32 flags = br.ReadUInt32();
				float speed_x = br.ReadSingle();
				float speed_y = br.ReadSingle();
				float speed_z = br.ReadSingle();
				
				uint32 extend_data = br.ReadUInt32(); //扩展
				uint16 face_dir = br.ReadUInt16();
				uint32 extend_data2 = br.ReadUInt32();				

				float use_time = 0.0f;
				//if ((flags & (uint32)GP_MOVE_FLAG::GP_MOVE_CARRIER) != 0)
				{
					use_time = br.ReadUInt16() * 0.001f;
				}
				uint16 face_dir_pitch = 0;
				uint16 face_dir_roll = 0;
				if (flags & (uint32)GP_MOVE_FLAG::GP_MOVE_FACE_DIR_EX)
				{
					face_dir_pitch = br.ReadUInt16();
					face_dir_roll = br.ReadUInt16();
				}

				float time_stamp = 0.0f;
				lua_getglobal(L, "OnObjectMove");
				lua_pushnumber(L, dt);
				lua_pushnumber(L, new_who);
				lua_pushnumber(L, x);
				lua_pushnumber(L, y);
				lua_pushnumber(L, z);
				lua_pushnumber(L, flags);
				lua_pushnumber(L, speed_x);
				lua_pushnumber(L, speed_y);
				lua_pushnumber(L, speed_z);
				lua_pushnumber(L, face_dir);
				lua_pushnumber(L, face_dir_pitch);
				lua_pushnumber(L, face_dir_roll);
				lua_pushnumber(L, use_time);
				lua_pushnumber(L, extend_data);
				lua_pushnumber(L, extend_data2);
				lua_pushnumber(L, time_stamp);
				//UE_LOG(LogAzure, Log, TEXT("OBJECT_MOVE: %d,%d,%d----%d----%d"), x, y, z, flags, move_dir);
				pLua->Call(16);
			}
			break;

			case (int)S2C::S2C_COMMAND::TEAM_FOLLOW_MOVE:
			{
				int new_who = br.ReadInt32();
				float x = br.ReadSingle();
				float y = br.ReadSingle();
				float z = br.ReadSingle();
				AzureWorldWrap::Instance().UnwrapPosition(x, z);
				uint32 flags = br.ReadUInt32();
				float speed_x = br.ReadSingle();
				float speed_y = br.ReadSingle();
				float speed_z = br.ReadSingle();
				//uint16 use_time = br.ReadUInt16();
				//uint16 speed = br.ReadUInt16();
				uint32 extend_data = br.ReadUInt32(); //扩展
				uint16 face_dir = br.ReadUInt16();

				uint32 extend_data2 = br.ReadUInt32();


				float use_time = 0.0f;
				//if ((flags & (uint32)GP_MOVE_FLAG::GP_MOVE_CARRIER) != 0)
				{
					use_time = br.ReadUInt16() * 0.001f;
				}

				int timeStamp = 0;
				uint16 pitch_dir = 0;

				lua_getglobal(L, "OnPlayerTeamFollowMove");
				lua_pushnumber(L, dt);
				lua_pushnumber(L, new_who);
				lua_pushnumber(L, x);
				lua_pushnumber(L, y);
				lua_pushnumber(L, z);
				lua_pushnumber(L, flags);
				lua_pushnumber(L, speed_x);
				lua_pushnumber(L, speed_y);
				lua_pushnumber(L, speed_z);
				lua_pushnumber(L, face_dir);
				lua_pushnumber(L, use_time);
				lua_pushnumber(L, extend_data);
				lua_pushnumber(L, extend_data2);
				lua_pushnumber(L, timeStamp);
				pLua->Call(14);
			}
			break;

			case (int)S2C::S2C_COMMAND::ENTER_TEAM_FOLLOW_MODE:
			{
				int64 who = br.ReadUInt64();
				lua_getglobal(L, "OnPlayerEnterTeamFollow");
				lua_pushnumber(L, dt);
				lua_pushlstring(L, (const char*)&who, 8);
				pLua->Call(2);
			}
			break;

			case (int)S2C::S2C_COMMAND::LEAVE_TEAM_FOLLOW_MODE:
			{
				int64 who = br.ReadUInt64();
				int reason = br.ReadInt32();
				lua_getglobal(L, "OnPlayerLeaveTeamFollow");
				lua_pushnumber(L, dt);
				lua_pushlstring(L, (const char*)&who, 8);
				lua_pushnumber(L, reason);
				pLua->Call(3);
			}
			break;

			case (int)S2C::S2C_COMMAND::OBJECT_TURN:
			{
				int new_who = br.ReadInt32();
				uint16 flags = br.ReadUInt16();
				uint16 dir = br.ReadUInt16();
				// 毫秒
				float use_time = br.ReadUInt16() / 1000.f;
				//FString str = FString::Printf(TEXT("Receive OnObjectTurn"));
				//UKismetSystemLibrary::PrintString(GEngine->GetWorld(), str);
				
				lua_getglobal(L, "OnObjectTurn");
				lua_pushnumber(L, new_who);
				lua_pushnumber(L, flags);
				lua_pushnumber(L, dir);
				lua_pushnumber(L, use_time);
				//lua_pushnumber(L, 0);
				pLua->Call(4);

				
			}
			break;

			case (int)S2C::S2C_COMMAND::OBJECT_NOTIFY_PROP_DELTA:
			{
				int new_who = br.ReadInt32();
				signed char count = br.ReadSByte();

				lua_getglobal(L, "OnObjectNotifyPropDelta");
				lua_pushnumber(L, dt);
				lua_pushinteger(L, new_who);
				lua_pushinteger(L, count * 2);

				CreateCacheTable(L, "ct36");
				int j = 1;

				for (int i = 1; i <= count; ++i)
				{
					signed char index = br.ReadSByte();
					lua_pushnumber(L, index);
					lua_rawseti(L, -2, j++);
					if (index == 0 || index == 4 || index == 5 || index == 6)  //血量、能量盾、壁垒盾为万分比
					{
						short d = br.ReadInt16();
						lua_pushnumber(L, d);
					}
					else if (index == 2)  //64位血量
					{
						int64 d = br.ReadInt64();
						lua_pushlstring(L, (const char*)&d, 8);
					}
					else
					{
						signed char d = br.ReadSByte();
						lua_pushnumber(L, d);
					}
					lua_rawseti(L, -2, j++);
				}

				pLua->Call(4);
			}
			break;

			case (int)S2C::S2C_COMMAND::OBJECT_PERFORM_SKILL:
			{
				lua_getglobal(L, "OnObjectPerformSkill");
				int32 who = br.ReadInt32();
				lua_pushnumber(L, dt);
				char name[16] = {};
				snprintf(name, sizeof name, "ct86_%d", who);
				CreateCacheTable(L, name);
				int self = lua_gettop(L);

				lua_pushnumber(L, who);
				lua_setfield(L, -2, "who");

				uint16 idSkill = br.ReadUInt16();
				lua_pushnumber(L, idSkill);
				lua_setfield(L, -2, "skill");

				uint8 stage = br.ReadByte();
				lua_pushnumber(L, stage);
				lua_setfield(L, -2, "stage");

				//lua_pushnumber(L, br.ReadSingle());
				//lua_setfield(L, -2, "rootmotionScale");

				uint16 extra_flag = br.ReadUInt16();
				lua_pushnumber(L, extra_flag);
				lua_setfield(L, -2, "extra_flag");

				if (stage == 0)
				{
					float x = br.ReadSingle();
					float y = br.ReadSingle();
					float z = br.ReadSingle();
					AzureWorldWrap::Instance().UnwrapPosition(x, z);
					lua_pushnumber(L, x);
					lua_setfield(L, self, "final_self_pos_x");
					lua_pushnumber(L, y);
					lua_setfield(L, self, "final_self_pos_y");
					lua_pushnumber(L, z);
					lua_setfield(L, self, "final_self_pos_z");
				}

				int32 root_motion_scale_count = br.ReadInt32();
				lua_pushnumber(L, root_motion_scale_count);
				lua_setfield(L, self, "root_motion_scale_count");

				CreateCacheTable(L, "ct86_root_motion_scales");
				int root_motion_scales = lua_gettop(L);
				for (int i = 1; i <= root_motion_scale_count; i++) {
					float root_motion_scale = br.ReadSingle();
					lua_pushnumber(L, root_motion_scale);
					lua_rawseti(L, root_motion_scales, i);
				}
				lua_setfield(L, self, "root_motion_scales");

				bool pos_change = false;
				float x = 0;
				float y = 0;
				float z = 0;
				if ((extra_flag & (uint16)PERFORM_FLAGS_MOVE) != 0)
				{
					pos_change = true;
					x = br.ReadSingle();
					y = br.ReadSingle();
					z = br.ReadSingle();
					AzureWorldWrap::Instance().UnwrapPosition(x, z);
				}

				lua_pushboolean(L, pos_change);
				lua_setfield(L, self, "selfpos_change");

				if (pos_change)
				{
					lua_pushnumber(L, x);
					lua_setfield(L, self, "self_pos_x");
					lua_pushnumber(L, y);
					lua_setfield(L, self, "self_pos_y");
					lua_pushnumber(L, z);
					lua_setfield(L, self, "self_pos_z");
				}

				bool selfdir_change = false;
				uint16 skillmove_dir = 0;

				if ((extra_flag & (uint16)PERFORM_FLAGS_DIR) != 0)
				{
					selfdir_change = true;
					skillmove_dir = br.ReadUInt16();
				}

				lua_pushboolean(L, selfdir_change);
				lua_setfield(L, self, "selfdir_change");
				lua_pushnumber(L, skillmove_dir);
				lua_setfield(L, self, "skillmove_dir");

				bool persist_move = false;
				if ((extra_flag & (uint16)PERFORM_FLAGS_PERSIST_MOVE) != 0)
				{
					persist_move = true;
				}
				lua_pushboolean(L, persist_move);
				lua_setfield(L, self, "persist_move");
				
				bool has_firstperformpos = false;
				int perform_target_id = 0;
				if ((extra_flag & (uint16)PERFORM_FLAGS_1ST_PERFORM) != 0)
				{
					has_firstperformpos = true;

					//target pos
					x = br.ReadSingle();
					y = br.ReadSingle();
					z = br.ReadSingle();
					AzureWorldWrap::Instance().UnwrapPosition(x, z);

					lua_pushnumber(L, x);
					lua_setfield(L, self, "target_pos_x");
					lua_pushnumber(L, y);
					lua_setfield(L, self, "target_pos_y");
					lua_pushnumber(L, z);
					lua_setfield(L, self, "target_pos_z");

					//cast pos
					float castX = br.ReadSingle();
					float castY = br.ReadSingle();
					float castZ = br.ReadSingle();
					AzureWorldWrap::Instance().UnwrapPosition(castX, castZ);

					lua_pushnumber(L, castX);
					lua_setfield(L, self, "cast_pos_x");
					lua_pushnumber(L, castY);
					lua_setfield(L, self, "cast_pos_y");
					lua_pushnumber(L, castZ);
					lua_setfield(L, self, "cast_pos_z");

					perform_target_id = br.ReadInt32();
				}
				else
				{
					x = 0;
					y = 0;
					z = 0;
				}

				lua_pushboolean(L, has_firstperformpos);
				lua_setfield(L, self, "has_firstperformpos");
				lua_pushnumber(L, perform_target_id);
				lua_setfield(L, self, "perform_target_id");
				
				bool is_unite_skill = false;
				if ((extra_flag & (uint16)PERFORM_FLAGS_LIAN_XIE) != 0)
                {
                    is_unite_skill = true;
                }
			    lua_pushboolean(L, is_unite_skill);
				lua_setfield(L, self, "is_unite_skill");

				//dodge skill target pos 已废弃
				br.ReadSingle();
				br.ReadSingle();
				br.ReadSingle();
				
				if ((extra_flag & (uint16)PERFORM_FLAGS_TARGET_LIST) != 0 || (extra_flag & (uint16)PERFORM_FLAGS_CHAIN) != 0)
				{
					CreateCacheTable(L, "ct86_target_ids");
					int target_ids = lua_gettop(L);
					int target_count = br.ReadByte();
					lua_pushnumber(L, target_count);
					lua_setfield(L, self, "target_count");

					for (int i = 1; i <= target_count; ++i)
					{
						lua_pushnumber(L, br.ReadInt32());
						lua_rawseti(L, target_ids, i);
					}

					lua_setfield(L, self, "target_ids");
				}
				else
				{
					lua_pushnumber(L, 0);
					lua_setfield(L, self, "target_count");
				}


				pLua->Call(2);
			}
			break;

			case (int)S2C::S2C_COMMAND::BE_HURT:
			{
				int attacker_id = br.ReadInt32();
				int target_id = br.ReadInt32();
				float damage = br.ReadSingle();

				lua_getglobal(L, "OnObjectBeHurt");
				lua_pushnumber(L, dt);
				lua_pushnumber(L, attacker_id);
				lua_pushnumber(L, target_id);
				lua_pushnumber(L, damage);
				pLua->Call(4);
			}
			break;

			case (int)S2C::S2C_COMMAND::OBJECT_BE_ATTACKED:
			{
				lua_getglobal(L, "OnObjectBeAttacked");
				lua_pushnumber(L, dt);
				int32 attacker = br.ReadInt32();
				int32 target = br.ReadInt32();
				lua_newtable(L);
				int self = lua_gettop(L);

				//lua_pushnumber(L, br.ReadUInt16());
				//lua_setfield(L, -2, "tick");

				lua_pushnumber(L, attacker);
				lua_setfield(L, -2, "attacker_id");

				lua_pushnumber(L, target);
				lua_setfield(L, -2, "target_id");

				lua_pushnumber(L, br.ReadSingle());
				lua_setfield(L, -2, "damage");

				lua_pushnumber(L, br.ReadUInt16());
				lua_setfield(L, -2, "skill_id");

				//lua_pushnumber(L, br.ReadSByte());
				//lua_setfield(L, -2, "percentHP");

				lua_pushnumber(L, br.ReadInt32());
				lua_setfield(L, -2, "attack_stage");

				int skill_state_id = br.ReadInt32();
				if (skill_state_id > 4096) {
					skill_state_id -= 4096;
				}
				lua_pushnumber(L, skill_state_id);
				lua_setfield(L, -2, "skill_state_id");
				
				int32 attack_id = br.ReadInt32();
                lua_pushnumber(L, attack_id);
				lua_setfield(L, -2, "attack_id");

				int32 owner_id = br.ReadInt32();
				lua_pushnumber(L, owner_id);
				lua_setfield(L, -2, "owner_id");

				unsigned int flags = br.ReadUInt32();
				lua_pushnumber(L, flags);
				lua_setfield(L, -2, "flags");

				bool be_moved = false;
				if ((flags & 0x00008000) != 0)
					be_moved = true;
				lua_pushboolean(L, be_moved);
				lua_setfield(L, -2, "be_moved");

				bool be_turned = false;
				if ((flags & 0x00080000) != 0)
					be_turned = true;
				lua_pushboolean(L, be_turned);
				lua_setfield(L, -2, "be_turned");

				if ((flags & 0x01000000) != 0)
				{
					lua_pushboolean(L, true);
					lua_setfield(L, -2, "is_child");
				}

				bool has_pos = false;
				if (be_moved || (flags & 0x00040000) != 0)
				{
					has_pos = true;
					float x = br.ReadSingle();
					float y = br.ReadSingle();
					float z = br.ReadSingle();
					AzureWorldWrap::Instance().UnwrapPosition(x, z);
					lua_pushnumber(L, x);
					lua_setfield(L, self, "pos_x");
					lua_pushnumber(L, y);
					lua_setfield(L, self, "pos_y");
					lua_pushnumber(L, z);
					lua_setfield(L, self, "pos_z");
				}

				lua_pushboolean(L, has_pos);
				lua_setfield(L, self, "has_pos");

				bool has_dir = false;
				if (be_moved || be_turned || (flags & 0x00040000) != 0)
				{
					has_dir = true;
					lua_pushnumber(L, br.ReadUInt16());
					lua_setfield(L, self, "dir");
				}
				lua_pushboolean(L, has_dir);
				lua_setfield(L, self, "has_dir");

				bool be_controled = false;
				uint8 pre_ctrl_type = 0;
				uint8 ctrl_type = 0;
				uint16 ctrl_time = 0;
				uint8 move_stamp = 0;
				uint8 ctrl_level = 0;

				if ((flags & 0x00010000) != 0)
				{
					be_controled = true;
					pre_ctrl_type = br.ReadByte();
					ctrl_type = br.ReadByte();
					ctrl_time = br.ReadUInt16();
					move_stamp = br.ReadByte();
					ctrl_level = br.ReadByte();
				}
				lua_pushboolean(L, be_controled);
				lua_setfield(L, self, "be_controled");
				lua_pushnumber(L, pre_ctrl_type);
				lua_setfield(L, self, "pre_ctrl_type");
				lua_pushnumber(L, ctrl_type);
				lua_setfield(L, self, "ctrl_type");
				lua_pushnumber(L, ctrl_time);
				lua_setfield(L, self, "ctrl_time");
				lua_pushnumber(L, move_stamp);
				lua_setfield(L, self, "move_stamp");
				lua_pushnumber(L, ctrl_level);
				lua_setfield(L, self, "ctrl_level");
				/*int32 front_new_id = 0;
				if ((flags & 0x01000000) != 0)
				{
					front_new_id = br.ReadInt32();
				}
				lua_pushnumber(L, front_new_id);
				lua_setfield(L, self , "front_new_id");

				bool be_pofang = false;
				if ((flags & 0x00400000) != 0)
				{
					be_pofang = true;
				}
				lua_pushboolean(L, be_pofang);
				lua_setfield(L, self, "be_pofang");

				bool be_miss = false;
				if ((flags & 0x00000200) != 0)
				{
					be_miss = true;
				}
				lua_pushboolean(L, be_miss);
				lua_setfield(L, self, "be_miss");

				bool be_crit = false;
				if ((flags & 0x00000400) != 0)
				{
					be_crit = true;
				}
				lua_pushboolean(L, be_crit);
				lua_setfield(L, self, "be_crit");

				bool be_parry = false;
				if ((flags & 0x00001000) != 0)
				{
					be_parry = true;
				}
				lua_pushboolean(L, be_parry);
				lua_setfield(L, self, "be_parry");

				bool be_broken_parry = false;
				if ((flags & 0x00002000) != 0)
				{
					be_broken_parry = true;
				}
				lua_pushboolean(L, be_broken_parry);
				lua_setfield(L, self, "be_broken_parry");

				bool be_immune = false;
				if ((flags & 0x00000100) != 0)
				{
					be_immune = true;
				}
				lua_pushboolean(L, be_immune);
				lua_setfield(L, self, "be_immune");

				bool be_absorb = false;
				if ((flags & 0x00000800) != 0)
				{
					be_absorb = true;
				}
				lua_pushboolean(L, be_absorb);
				lua_setfield(L, self, "be_absorb");*/

				pLua->Call(2);
			}
			break;

			case (int)S2C::S2C_COMMAND::OBJECT_STOP_SESSION:
			{
				//uint16 tick = br.ReadUInt16();
				int new_who = br.ReadInt32();
				uint16 type = br.ReadUInt16();
				uint32 param = br.ReadUInt16();
				uint32 param2 = br.ReadUInt16();
				int64 target_id = br.ReadUInt64();

				lua_getglobal(L, "OnObjectStopSession");
				lua_pushnumber(L, dt);
				lua_pushnumber(L, new_who);
				lua_pushlstring(L, (const char*)&target_id, 8);
				lua_pushnumber(L, type);
				lua_pushnumber(L, param);
				lua_pushnumber(L, param2);
				pLua->Call(6);
			}
			break;

			case (int)S2C::S2C_COMMAND::SERVER_TIMESTAMP:
			{
				int time = br.ReadInt32();
				int shutdown_timestamp = br.ReadInt32();
				UE_LOG(LogAzure, Log, TEXT("time and shutdown_timestamp: %d, %d"), time, shutdown_timestamp);
				AzureTimeManager::GetInstance().OnCmd_ServerTimeStamp(proto->Syncinfo.RecvTime, time, shutdown_timestamp);
			}
			break;

			case (int)S2C::S2C_COMMAND::SELF_HIT:
			{
				int hit_count = br.ReadInt32();
				int valid_time = br.ReadInt32();

				lua_getglobal(L, "OnSelfHit");
				lua_pushnumber(L, hit_count);
				lua_pushnumber(L, valid_time);
				pLua->Call(2);
			}
			break;

			default:
			{
				lua_getglobal(L, "ProcessGameDataSend");
				lua_pushnumber(L, cmd_type);
				AzureBinaryReader* brForLua = new AzureBinaryReader(std::move(br));
				AzureHelpFuncs::ReturnObject(L, brForLua, LuaAzureBinaryReader::mt_name);
				lua_pushnumber(L, dt);

				//Debug.Log("----- ProcessGameDataSend: cmd_Type {0}", cmd_type));
				pLua->Call(3);
				bHandledInLua = true;
			}
			break;
			}

			if (!bHandledInLua && IsEnableNetworkDebug())
			{
				br.seek(offsetBackup, AzureBinaryReader::Begin);
				
				// 将C++中处理的协议也过一下ECNetworkDebugger
				lua_getglobal(L, "RecordProtoHandledInCSharp");
				lua_pushnumber(L, cmd_type);
				AzureBinaryReader* brForLua = new AzureBinaryReader(std::move(br));
				if (cmd_type == (int)S2C::S2C_COMMAND::OBJECT_MOVE)
				{
					int a = brForLua->ReadInt32();
					float b = brForLua->ReadSingle();
					float c = brForLua->ReadSingle();
					float d = brForLua->ReadSingle();
					brForLua->seek(offsetBackup, AzureBinaryReader::Begin);
				}
				AzureHelpFuncs::ReturnObject(L, brForLua, LuaAzureBinaryReader::mt_name);
				lua_pushnumber(L, 1);

				pLua->Call(3);
			}

			return 0;
		}

		static int GetProtoStream(lua_State * L)
		{
			GNET::CommonData* proto = (GNET::CommonData*)AzureHelpFuncs::GetObject(L, 1, LuaCommonData::mt_name);
			GNET::Marshal::OctetsStream* os = proto->GetStreamData();
			GNET::Marshal::OctetsStream* ret = new GNET::Marshal::OctetsStream();
			*ret = std::move(*os);
			AzureHelpFuncs::ReturnObject(L, ret, luaOctetsStream::mt_name);
			return 1;
		}

		// 对于34号协议，取S2C command协议号
		// 对于502号协议，取pb协议号
		static int PeekProtoDetailType(lua_State* L)
		{
			unsigned short detail_type = 0;
			GNET::CommonData* proto = (GNET::CommonData*)AzureHelpFuncs::GetObject(L, 1, LuaCommonData::mt_name);
			int protoType = luaL_checkinteger(L, 2);
			GNET::Marshal::OctetsStream* os = proto->GetStreamData();
			*os >> GNET::Marshal::Begin;
			if (protoType == 34)
			{
				unsigned int data_len = 0;
				const void* data_begin = os->raw_read_octets(data_len);
				AzureBinaryReader br(data_begin, data_len, false);
				detail_type = br.ReadInt16();
				lua_pushnumber(L, 1);
			}
			else if (protoType == 502)
			{
				*os >> detail_type;
				lua_pushnumber(L, 2);
			}
			else
			{
				detail_type = protoType;
				lua_pushnumber(L, 3);
			}
			*os >> GNET::Marshal::Rollback;
			lua_pushnumber(L, detail_type);
			return 2;
		}

		static int AddGlobalTimer(lua_State * L)
		{
			if (!AAzureEntryPoint::Instance)
				return 0;

			if (!lua_isnumber(L, 1))
			{
				lua_pushstring(L, "AddGlobalTimer: param 1 must be number(ttl)");
				lua_error(L);
				return 1;
			}
			float ttl = (float)luaL_checknumber(L, 1);

			if (!lua_isboolean(L, 2))
			{
				lua_pushstring(L, "AddGlobalTimer: param 2 must be bool(bOnce)");
				lua_error(L);
				return 1;
			}
			bool bOnce = !!lua_toboolean(L, 2);

			if (!lua_isfunction(L, 3))
			{
				lua_pushstring(L, "AddGlobalTimer: param 3 must be function(callback)");
				lua_error(L);
				return 1;
			}
			lua_pushvalue(L, 3);
			wLua::lua_registry_handle callbackRef = wLua::lua_registry_handle::wlua_ref(L, LUA_REGISTRYINDEX);

			wLua::lua_registry_handle cbparam;
			if (!lua_isnoneornil(L, 4))
			{
				lua_pushvalue(L, 4);
				cbparam = wLua::lua_registry_handle::wlua_ref(L, LUA_REGISTRYINDEX);
			}

			bool bChangeWithTimeDilation = true;
			if (lua_isboolean(L, 5))
			{
				bChangeWithTimeDilation = !!lua_toboolean(L, 5);
			}

			int id = AAzureEntryPoint::Instance->AddTimer(ttl, bOnce, callbackRef, cbparam, false, bChangeWithTimeDilation);

			lua_pushinteger(L, id);
			//UE_LOG(LogAzure, Log, TEXT("AddGlobalTimer[%d]: ttl[%f], bOnce[%d]"), id, ttl, bOnce ? 1 : 0);
			return 1;
		}
		
		static int AddGlobalLateTimer(lua_State * L)
		{
			if (!AAzureEntryPoint::Instance)
				return 0;

			if (!lua_isnumber(L, 1))
			{
				lua_pushstring(L, "AddGlobalLateTimer: param 1 must be number(ttl)");
				lua_error(L);
				return 1;
			}
			float ttl = (float)luaL_checknumber(L, 1);

			if (!lua_isboolean(L, 2))
			{
				lua_pushstring(L, "AddGlobalLateTimer: param 2 must be bool(bOnce)");
				lua_error(L);
				return 1;
			}
			bool bOnce = !!lua_toboolean(L, 2);

			if (!lua_isfunction(L, 3))
			{
				lua_pushstring(L, "AddGlobalLateTimer: param 3 must be function(callback)");
				lua_error(L);
				return 1;
			}
			lua_pushvalue(L, 3);
			wLua::lua_registry_handle callbackRef = wLua::lua_registry_handle::wlua_ref(L, LUA_REGISTRYINDEX);

			wLua::lua_registry_handle cbparam;
			if (!lua_isnoneornil(L, 4))
			{
				lua_pushvalue(L, 4);
				cbparam = wLua::lua_registry_handle::wlua_ref(L, LUA_REGISTRYINDEX);
			}

			bool bChangeWithTimeDilation = true;
			if (lua_isboolean(L, 5))
			{
				bChangeWithTimeDilation = !!lua_toboolean(L, 5);
			}

			int id = AAzureEntryPoint::Instance->AddTimer(ttl, bOnce, callbackRef, cbparam, true, bChangeWithTimeDilation);
			lua_pushinteger(L, id);
			//UE_LOG(LogAzure, Log, TEXT("AddGlobalLateTimer[%d]: ttl[%f], bOnce[%d]"), id, ttl, bOnce?1:0);
			return 1;
		}
	
		static int RemoveGlobalTimer(lua_State * L)
		{
			if (!AAzureEntryPoint::Instance)
				return 0;

			int id = lua_tointeger(L, 1);
			int iRet = AAzureEntryPoint::Instance->RemoveTimer(id);
			//UE_LOG(LogAzure, Log, TEXT("RemoveGlobalTimer[%d]: ret = %d"), id, iRet);
			return 0;
		}
		
		static int ResetGlobalTimer(lua_State * L)
		{
			if (!AAzureEntryPoint::Instance)
				return 0;

			int id = lua_tointeger(L, 1);
			AAzureEntryPoint::Instance->ResetTimer(id);
			return 0;
		}
		
		static int SetGlobalTimer(lua_State * L)
		{
			if (!AAzureEntryPoint::Instance)
				return 0;

			int id = lua_tointeger(L, 1);
			float fNextPlayTime = (float)lua_tonumber(L, 2);
			AAzureEntryPoint::Instance->SetTimer(id, fNextPlayTime);
			return 0;
		}

		static int GetAllTimerDebugInfo(lua_State * L)
		{
			lua_pushstring(L, TCHAR_TO_UTF8(*ECTimerList::GetAllDebugInfo()));
			return 1;
		}

		// AZURE TODO
		static int UnbindUserData(lua_State * L)
		{
			return 0;
		}

		static int GetAssetsPath(lua_State * L)
		{
			lua_pushstring(L, FPlatformAFileWrapper::GetAssetsPath().c_str());
			return 1;
		}

		static int GetProjectDir(lua_State * L)
		{
			lua_pushstring(L, TCHAR_TO_UTF8(*FPaths::ProjectDir()));
			return 1;
		}

		static int GetProjectContentDir(lua_State * L)
		{
			lua_pushstring(L, TCHAR_TO_UTF8(*FPaths::ProjectContentDir()));
			return 1;
		}

		static int PlaySequence(lua_State * L)
		{
			if (!AAzureEntryPoint::Instance)
				return 0;

			UWorld* pWorld = AAzureEntryPoint::Instance->GetWorld();
			if (!pWorld)
			{
				lua_pushboolean(L, 0);
				return 1;
			}

			ALevelSequenceActor* actor = pWorld->SpawnActor<ALevelSequenceActor>();
			//ULevelSequence* sequence = NewObject<ULevelSequence>(actor, TEXT("NewLevelSequence"));
			FStringAssetReference SequenceName("/Game/NewLevelSequence");
			ULevelSequence* sequence = Cast<ULevelSequence>(SequenceName.TryLoad());

			if (sequence == nullptr)
			{
				lua_pushboolean(L, 0);
				return 1;
			}

			actor->SetSequence(sequence);
			actor->bAutoPlay = true;
			actor->InitializePlayer();
		
			lua_pushboolean(L, 0);
			return 1;
		}

		int lua_ExecuteCmdImmediately(lua_State* L)
		{
			if (!AAzureEntryPoint::Instance)
				return 0;
			UWorld* pWorld = AAzureEntryPoint::Instance->GetWorld();
			if (!pWorld)
				return 0;
			const char* szName = lua_tostring(L, 1);
			GEngine->Exec(pWorld, UTF8_TO_TCHAR(szName));
			return 0;
		}

		static int SetWidgetInteractionComponent(lua_State *L)
		{
			wLua::LuaUObjectUserData* userdata = nullptr;
			UWidgetInteractionComponent* obj = Cast<UWidgetInteractionComponent>(wLua::FLuaUtils::GetUObject(L, 1, "WidgetInteractionComponent", &userdata));
			if (!obj)
			{
				astring msg = astring("SetWidgetInteractionComponent: param 1 must be WidgetInteractionComponent ") + astring(userdata ? (userdata->uobj ? "has uobject" : "uobject is null") : "no userdata");
				lua_pushstring(L, msg.c_str());
				lua_error(L);
				return 1;
			}

			if (!AAzureEntryPoint::Instance)
				return 0;

			AAzureEntryPoint::Instance->WidgetInteractionComp = obj;
			return 0;
		}

		static int GenRandomSeed(lua_State * L)
		{
			double time = (FDateTime::UtcNow() - FDateTime(1970, 1, 1)).GetTotalSeconds();
			FString strForHash = FString::Printf(TEXT("%f%s"), time, FAzureSystemInfo::deviceUniqueIdentifier());

			int Digest[4];
			FMD5 Md5Gen;
			Md5Gen.Update((const uint8*)*strForHash, strForHash.Len() * sizeof(TCHAR));
			Md5Gen.Final((uint8*)Digest);
			int seed = Digest[0] ^ Digest[1] ^ Digest[2] ^ Digest[3];

			lua_pushinteger(L, seed & 0x7fffffff);
			return 1;
		}

		static int lua_md5(lua_State * L)
		{
			size_t len;
			const char* data = luaL_checklstring(L, 1, &len);

			//此段代码参考 FMD5::HashAnsiString
			uint8 Digest[16];

			FMD5 Md5Gen;

			Md5Gen.Update((const uint8*)data, int(len));
			Md5Gen.Final(Digest);

			FString MD5;
			for( int32 i=0; i<16; i++ )
			{
				MD5 += FString::Printf(TEXT("%02x"), Digest[i]);
			}

			lua_pushstring(L, TCHAR_TO_UTF8(*MD5));
			return 1;
		}

		static int lua_md5_raw(lua_State * L)
		{
			size_t len;
			const char* data = luaL_checklstring(L, 1, &len);

			uint8 Digest[16];
			FMD5 Md5Gen;
			Md5Gen.Update((const uint8*)data, int(len));
			Md5Gen.Final(Digest);

			lua_pushlstring(L, (const char*)Digest, sizeof(Digest));
			return 1;
		}

		static int lua_SimpleEncryptText(lua_State* L)
		{
			size_t len, pwd_len;
			const char* text = luaL_checklstring(L, 1, &len);
			const char* password = luaL_checklstring(L, 2, &pwd_len);

			GNET::Octets o(text, len);
			uint32 srcSize = (uint32)o.size();
			GNET::ARCFourSecurity sec;
			sec.SetParameter(GNET::Octets(password));
			sec.Update(o);
			uint32 destSize = (uint32)o.size();

			lua_pushlstring(L, (const char*)o.begin(), o.size());
			return 1;
		}

		static int GetPlatformName(lua_State * L)
		{
			FString pname = UGameplayStatics::GetPlatformName();
			lua_pushstring(L, TCHAR_TO_UTF8(*pname));
			return 1;
		}

		static int GetPlatformLocale(lua_State* L)
		{
			FString locale = FPlatformMisc::GetDefaultLocale();
			lua_pushstring(L, TCHAR_TO_UTF8(*locale));
			return 1;
		}

		static int GetServerList(lua_State * L)
		{
			auto content = GNET::DirClient::GetInstance().GetServerList();
			if (content.Num() > 0)
			{
				lua_pushlstring(L, content.GetData(), content.Num());
				return 1;
			}
			else
			{
				lua_pushnil(L);
				return 1;
			}
		}

		static int GetVersionList(lua_State * L)
		{
			auto content = GNET::DirClient::GetInstance().GetVersionList();
			if (content.Num() > 0)
			{
				lua_pushlstring(L, content.GetData(), content.Num());
				return 1;
			}
			else
			{
				lua_pushnil(L);
				return 1;
			}
		}

		static int RequestDirInfo(lua_State * L)
		{
			char const* dir_server_address = luaL_checkstring(L, 1);
			int32 dir_server_port = luaL_checkint(L, 2);
			float timeout = 5000.0f;
			if (lua_isnumber(L, 3)) timeout = (float)lua_tonumber(L, 3);

			//UE_LOG(LogAzure, Log, TEXT("RequestDirInfo(%s,%d)"), UTF8_TO_TCHAR(dir_server_address.c_str()), dir_server_port);
			Session::ID id = GNET::DirClient::RequestInfo(dir_server_address, dir_server_port, timeout);
			lua_pushinteger(L, id);
			return 1;
		}

		static int HasGotDirInfo(lua_State * L)
		{
			bool hasGotInfo = GNET::DirClient::GetInstance().HasGotInfo();
			lua_pushboolean(L, hasGotInfo);
			return 1;
		}

		static int AbortDirRequest(lua_State * L)
		{
			Session::ID id = (Session::ID)luaL_checkinteger(L, 1);
			GNET::DirClient::AbortRequest(id);
			return 0;
		}

		static int GetDirVersion(lua_State * L)
		{
			TArray<char> content = GNET::DirClient::GetInstance().GetVersion();
			if (content.Num() > 0)
			{
				lua_pushlstring(L, content.GetData(), content.Num());
				return 1;
			}
			else
			{
				lua_pushnil(L);
				return 1;
			}
		}

		static int GetObjMapCount(lua_State * L)
		{
			uint32 count = wLua::FLuaUtils::GetObjectCount(L);
			lua_pushinteger(L, count);
			return 1;
		}

		static int LuaObjRefSnapshot(lua_State * L)
		{
			wLua::FLuaUtils::TakeSnapshot(L);
			return 0;
		}

		static int LuaObjRefDiffLastSnapshot(lua_State * L)
		{
			TArray<wLua::StampT> diffVec;
			wLua::FLuaUtils::DiffWithLastSnapshot(L, diffVec);

			FString strBuilder;
			for (auto item : diffVec)
			{
#ifdef AZURE_LUA_OBJECT_TRACEBACK
				strBuilder += FString::Printf(TEXT("Address: %p, Name: %s, Flag: %d, Stack: %s\n"), item->uobj, *item->uobj->GetFullName(), item->flag,
					UTF8_TO_TCHAR(wLua::FLuaObjectReferencer::Get().LUO_TraceMap[item->uobj].c_str()));
#else
				strBuilder += FString::Printf(TEXT("Address: %p, Name: %s, Flag: %d\n"), item->uobj, *item->uobj->GetFullName(), item->flag);
#endif
			}

			lua_pushstring(L, TCHAR_TO_UTF8(*strBuilder));
			return 1;
		}

		static int GetLuaRegistryRefCount(lua_State * L)
		{
			lua_pushinteger(L, wLua::lua_registry_handle::get_lua_registry_count());
			return 1;
		}

		static int DumpLuaRegistryInfo(lua_State * L)
		{
			FString content = wLua::lua_registry_handle::dump_lua_registry();
			lua_pushstring(L, TCHAR_TO_UTF8(*content));
			return 1;
		}

		static int LuaRegistryTakeSnapshot(lua_State * L)
		{
			wLua::lua_registry_handle::registry_take_snapshot();
			return 0;
		}

		static int LuaRegistryDiffWithLastSnapshot(lua_State * L)
		{
			FString strBuilder;
			TArray<TPair<int, FString>> diffVec;
			wLua::lua_registry_handle::registry_diff_with_last_snapshot(diffVec);
			for (auto& item : diffVec)
			{
				strBuilder.Append(FString::FromInt(item.Key));
				strBuilder.Append(item.Value);
				strBuilder.Append(TEXT("\n"));
			}
			lua_pushstring(L, TCHAR_TO_UTF8(*strBuilder));
			return 1;
		}

		static int ReadFileAllContent(lua_State * L)
		{
			const char* path = luaL_checkstring(L, 1);
			ABYTE* pBuffer;
			ADWORD nFileLength;
			if (exp_af_ReadFileAllBytes(path, &pBuffer, &nFileLength))
			{
				lua_pushlstring(L, (const char*)pBuffer, nFileLength);
				exp_af_ReleaseFileBuffer(pBuffer);
				return 1;
			}
			else
			{
				lua_pushnil(L);
				return 1;
			}
		}

		//注意：如果需要长期保持文件内容，应选用 ReadFileAllContentPtrAnsiAlloc + ReleaseFileBufferAnsi
		static int ReadFileAllContentPtr(lua_State * L)
		{
			const char* path = luaL_checkstring(L, 1);
			ABYTE* pBuffer;
			ADWORD nFileLength;
			if (exp_af_ReadFileAllBytes(path, &pBuffer, &nFileLength))
			{
				lua_pushlightuserdata(L, pBuffer);
				lua_pushinteger(L, nFileLength);
				return 2;
			}
			else
			{
				lua_pushnil(L);
				return 1;
			}
		}

		static int ReleaseFileBuffer(lua_State *L)
		{
			if (lua_type(L, 1) != LUA_TLIGHTUSERDATA)
				return 0;
			ABYTE * pBuffer = (ABYTE*)lua_touserdata(L, 1);
			exp_af_ReleaseFileBuffer(pBuffer);
			return 0;
		}

		//读取文件到使用 ansi alloc 函数分配的内存中，而非使用默认的 ASmallMemoryPool
		static int ReadFileAllContentPtrAnsiAlloc(lua_State * L)
		{
			const char* path = luaL_checkstring(L, 1);
			ABYTE* pBuffer;
			ADWORD nFileLength;
			if (exp_af_ReadFileAllBytesAnsiAlloc(path, &pBuffer, &nFileLength))
			{
				lua_pushlightuserdata(L, pBuffer);
				lua_pushinteger(L, nFileLength);
				return 2;
			}
			else
			{
				lua_pushnil(L);
				return 1;
			}
		}

		static int ReleaseFileBufferAnsi(lua_State *L)
		{
			if (lua_type(L, 1) != LUA_TLIGHTUSERDATA)
				return 0;
			ABYTE * pBuffer = (ABYTE*)lua_touserdata(L, 1);
			exp_af_ReleaseFileBufferAnsi(pBuffer);
			return 0;
		}

		static int GetFileInfoInRealPckFile(lua_State * L)
		{
			const char* path = luaL_checkstring(L, 1);
			char realFilePath[1024];
			a_int64 fileOffset;
			a_int64 fileLen;
			a_int64 compressedLen;
			bool isCompressed;
			bool isSepFile;

			if (exp_af_GetFileInfoInRealPckFile(path, realFilePath, sizeof(realFilePath), &fileOffset, &fileLen, &compressedLen, &isCompressed, &isSepFile))
			{
				lua_pushstring(L, realFilePath);
				lua_pushnumber(L, fileOffset);
				lua_pushnumber(L, fileLen);
				lua_pushnumber(L, compressedLen);
				lua_pushboolean(L, isCompressed);
				lua_pushboolean(L, isSepFile);
				return 6;
			}
			else
			{
				lua_pushnil(L);
				return 1;
			}
		}

		static int HasDebugPath(lua_State * L)
		{
			IPlatformFile& PlatformFile = FPlatformFileManager::Get().GetPlatformFile();

			const auto& pckDebugDir = FPlatformAFileWrapper::GetPckDebugDir();
			bool hasPckDebugDir = pckDebugDir.empty() ? false : PlatformFile.DirectoryExists(ANSI_TO_TCHAR(pckDebugDir.c_str()));

			const FString& streamDebugDir = StreamingAssetHelper::GetDebugDir();
			bool hasStreamingAssetsDebugDir = streamDebugDir.IsEmpty() ? false : PlatformFile.DirectoryExists(*streamDebugDir);

			lua_pushboolean(L, hasPckDebugDir || hasStreamingAssetsDebugDir);
			return 1;
		}

		static int CheckIsLinkBroken(lua_State * L)
		{
			AzureGameSession& gs = AzureGameSession::Instance();
			if (gs.NetMan.LastSendAlive != 0 && (gs.NetMan.LastSendAlive > gs.NetMan.LastRecvAlive))
			{
				gs.IsLinkBroken = true;
				gs.LinkBroken(true);

				UE_LOG(LogAzure, Log, TEXT("LinkBroken happened-3: lastsend lastrecv %d %d"), gs.NetMan.LastSendAlive, gs.NetMan.LastRecvAlive);
			}
			else
			{
				gs.SendKeepAliveMsg(cxxstd::GetTimeSeconds());
			}
			return 0;
		}

		static int DirectoryExists(lua_State* L)
		{
			const char* path = luaL_checkstring(L, 1);
			bool ret = FPlatformFileManager::Get().GetPlatformFile().GetPlatformPhysical().DirectoryExists(UTF8_TO_TCHAR(path));
			lua_pushboolean(L, ret ? 1 : 0);
			return 1;
		}

		static int CreateDirectory(lua_State * L)
		{
			const char* path = luaL_checkstring(L, 1);
			FPlatformFileManager::Get().GetPlatformFile().GetPlatformPhysical().CreateDirectoryTree(UTF8_TO_TCHAR(path));
			return 0;
		}

		static int CreateDirectoryForFile(lua_State * L)
		{
			const char* path = luaL_checkstring(L, 1);
			FPlatformFileManager::Get().GetPlatformFile().GetPlatformPhysical().CreateDirectoryTree(*FPaths::GetPath(UTF8_TO_TCHAR(path)));
			return 0;
		}

		static int DeleteDirectoryRecursively(lua_State * L)
		{
			const char* path = luaL_checkstring(L, 1);
			bool ret = FPlatformFileManager::Get().GetPlatformFile().GetPlatformPhysical().DeleteDirectoryRecursively(UTF8_TO_TCHAR(path));
			lua_pushboolean(L, ret ? 1 : 0);
			return 1;
		}

		//params: srcFilePath, destFilePath
		static int lua_CopyFile(lua_State *L)
		{
			FString srcFile = UTF8_TO_TCHAR(luaL_checkstring(L, 1));
			FString destFile = UTF8_TO_TCHAR(luaL_checkstring(L, 2));
			bool succ = IPlatformFile::GetPlatformPhysical().CopyFile(*destFile, *srcFile);
			lua_pushboolean(L, succ ? 1 : 0);
			return 1;
		}

		static bool CopySubFile(char const* srcFile, uint64 offset, uint64 len, char const* destFile)
		{
			FILE* fSrc = fopen(srcFile, "rb");
			if (!fSrc)
				return false;
			FILE* fDest = fopen(destFile, "wb");
			if (!fDest)
			{
				fclose(fSrc);
				return false;
			}

			unsigned char buffer[4096];
			bool hasError = false;

			if (0 != fseek(fSrc, offset, SEEK_SET))
				hasError = true;

			uint64 sizeLeft = len; 
			while (true)
			{
				uint32 sizeToCopy = sizeLeft > sizeof(buffer) ? sizeof(buffer) : sizeLeft;
				long readLen = fread(buffer, 1, sizeToCopy, fSrc);
				long writeLen = fwrite(buffer, 1, sizeToCopy, fDest);
				if (readLen != sizeToCopy || writeLen != sizeToCopy)
					hasError = true;
				sizeLeft -= sizeToCopy;
				if (sizeLeft == 0)
					break;
			}
			fclose(fSrc);
			if (0 != fclose(fDest))
				hasError = true;
			return !hasError;
		}

		//params: srcFilePath, offset, len, destFilePath
		static int lua_CopySubFile(lua_State *L)
		{
			char const* srcFile = luaL_checkstring(L, 1);
			uint64 offset = (uint64)(int64)luaL_checknumber(L, 2);
			uint64 len = (uint64)(int64)luaL_checknumber(L, 3);
			char const* destFile = luaL_checkstring(L, 4);

			bool bSuccess = CopySubFile(srcFile, offset, len, destFile);
			lua_pushboolean(L, bSuccess ? 1 : 0);
			return 1;
		}

		//params: srcFilePath, offset, len, destFilePath, onFinish(bSuccess)
		static int lua_CopySubFileAsync(lua_State *L)
		{
			std::string srcFile = luaL_checkstring(L, 1);
			uint64 offset = (uint64)(int64)luaL_checknumber(L, 2);
			uint64 len = (uint64)(int64)luaL_checknumber(L, 3);
			std::string destFile = luaL_checkstring(L, 4);
			luaL_checktype(L, 5, LUA_TFUNCTION);
			lua_pushvalue(L, 5);
			wLua::lua_registry_handle funcRef = wLua::lua_registry_handle::wlua_ref(L, LUA_REGISTRYINDEX);

			Async<void>(EAsyncExecution::ThreadPool, [funcRef, srcFile, offset, len, destFile]() {
				bool bSuccess = CopySubFile(srcFile.c_str(), offset, len, destFile.c_str());

				AsyncTask(ENamedThreads::GameThread, [funcRef, bSuccess]()
				{
					lua_State_Wrapper L = AAzureEntryPoint_GetWLua()->GetL();
					if (L)
					{
						lua_rawgeti(L, LUA_REGISTRYINDEX, funcRef);
						wLua::lua_registry_handle::wlua_unref(L, LUA_REGISTRYINDEX, funcRef);
						lua_pushboolean(L, bSuccess ? 1 : 0);
						AAzureEntryPoint_GetWLua()->Call(1);
					}
				});
			});
			return 0;
		}

		static int DeleteFileInDirectory(lua_State * L)
		{
			const char* path = luaL_checkstring(L, 1);
			bool ret = FPlatformFileManager::Get().GetPlatformFile().GetPlatformPhysical().DeleteFile(UTF8_TO_TCHAR(path));
			if (ret)
				return 0;
			return 0;
		}

		static int GetFileModifyTime(lua_State* L)
		{
			const char *path = luaL_checkstring(L, 1);
			FDateTime ret = FPlatformFileManager::Get().GetPlatformFile().GetPlatformPhysical().GetTimeStamp(UTF8_TO_TCHAR(path));

			lua_newtable(L);
			lua_pushinteger(L, ret.GetYear());
			lua_setfield(L, -2, "year");
			lua_pushinteger(L, ret.GetMonth());
			lua_setfield(L, -2, "mon");
			lua_pushinteger(L, ret.GetDay());
			lua_setfield(L, -2, "day");
			lua_pushinteger(L, ret.GetHour());
			lua_setfield(L, -2, "hour");
			lua_pushinteger(L, ret.GetMinute());
			lua_setfield(L, -2, "min");
			lua_pushinteger(L, ret.GetSecond());
			lua_setfield(L, -2, "sec");
			lua_pushinteger(L, ret.GetMillisecond());
			lua_setfield(L, -2, "msec");
			lua_pushstring(L, TCHAR_TO_UTF8(*ret.ToHttpDate()));
			lua_setfield(L, -2, "httpdate");
			return 1;
		}

		//2022.07.18 新增
		static int lua_GameThreadAsyncTask(lua_State* L)
		{
			luaL_checktype(L, 1, LUA_TFUNCTION);
			lua_pushvalue(L, 1);
			int funcRef = luaL_ref(L, LUA_REGISTRYINDEX);
			lua_pushvalue(L, 2);
			int paramRef = luaL_ref(L, LUA_REGISTRYINDEX);	//此值可能为 nil，用 lua_registry_handle 的话，下面会崩

			//因为是调用 Lua 只能在 GameThread 调用
			AsyncTask(ENamedThreads::GameThread, [funcRef, paramRef]()
			{
				if (!AAzureEntryPoint::Instance)
					return;

				wLua::Lua* wlua = AAzureEntryPoint::Instance->GetWLua();
				lua_State_Wrapper L = wlua ? wlua->GetL() : nullptr;
				if (!L)
					return;
				
				lua_rawgeti(L, LUA_REGISTRYINDEX, funcRef);
				luaL_unref(L, LUA_REGISTRYINDEX, funcRef);
				lua_rawgeti(L, LUA_REGISTRYINDEX, paramRef);
				luaL_unref(L, LUA_REGISTRYINDEX, paramRef);
				if (!wlua->PCall(1, 0))
					lua_pop(L, 1);
			});

			return 0;
		}

		static int lua_GameThreadAsyncTask_versionFlag_PCallFixed(lua_State* L)
		{
			return 0;
		}

		static int ParseDateFromString(lua_State* L)
		{
			const char *s = luaL_checkstring(L, 1);
			bool fromHttp = false;
			if (lua_isboolean(L, 2))
				fromHttp = !!lua_toboolean(L, 2);

			bool ok;
			FDateTime ret;
			if(fromHttp)
				ok = FDateTime::ParseHttpDate(UTF8_TO_TCHAR(s), ret);
			else
				ok = FDateTime::Parse(UTF8_TO_TCHAR(s), ret);
			if (!ok) {
				return 0;
			}
			lua_newtable(L);
			lua_pushinteger(L, ret.GetYear());
			lua_setfield(L, -2, "year");
			lua_pushinteger(L, ret.GetMonth());
			lua_setfield(L, -2, "mon");
			lua_pushinteger(L, ret.GetDay());
			lua_setfield(L, -2, "day");
			lua_pushinteger(L, ret.GetHour());
			lua_setfield(L, -2, "hour");
			lua_pushinteger(L, ret.GetMinute());
			lua_setfield(L, -2, "min");
			lua_pushinteger(L, ret.GetSecond());
			lua_setfield(L, -2, "sec");
			lua_pushinteger(L, ret.GetMillisecond());
			lua_setfield(L, -2, "msec");
			lua_pushstring(L, TCHAR_TO_UTF8(*ret.ToHttpDate()));
			lua_setfield(L, -2, "httpdate");
			return 1;
		}

		static int CompareDateTime(lua_State* L)
		{
			luaL_checktype(L, 1, LUA_TTABLE);
			luaL_checktype(L, 2, LUA_TTABLE);
#define GET_FIELD(n, x, f) \
			lua_getfield(L, n, #x); \
			int32 f = (float)lua_tonumber(L, -1); \
			lua_pop(L, 1);

#define GET_DATETIME(n, v) \
			GET_FIELD(n, year, year_##v) \
			GET_FIELD(n, mon, mon_##v) \
			GET_FIELD(n, day, day_##v) \
			GET_FIELD(n, hour, hour_##v) \
			GET_FIELD(n, min, min_##v) \
			GET_FIELD(n, sec, sec_##v) \
			GET_FIELD(n, msec, msec_##v) \
			FDateTime v(year_##v, mon_##v, day_##v, hour_##v, min_##v, sec_##v, msec_##v);
		GET_DATETIME(1, t1)
		GET_DATETIME(2, t2)

			if (t1 == t2) 
			{
				lua_pushinteger(L, 0);
			}
			else
			{
				lua_pushinteger(L, t1 > t2 ? 1 : -1);
			}

			return 1;

#undef GET_FIELD	
#undef GET_DATETIME
		}

		static int GBKToUnicode(lua_State* L)
		{
			size_t len;
			auto cstr = luaL_checklstring(L, 1, &len);
			{
				std::string str(cstr);
				if (str.empty())
				{
					lua_pushstring(L, "");
					return 1;
				}
				std::wstring sResult;
				std::string curLocale = setlocale(LC_ALL, NULL);// curLocale = "C";
				setlocale(LC_ALL, "chs");

				size_t size = str.size() + 1;
				wchar_t *p = new wchar_t[size];
				wmemset(p, 0, size);
				mbstowcs(p, str.c_str(), size);
				sResult = p;
				delete[]p;
				setlocale(LC_ALL, curLocale.c_str());

				lua_pushlstring(L, (const char*)sResult.c_str(), sResult.length() * sizeof(wchar_t));
				return 1;
			}
		}

		static int Utf8ToUnicode(lua_State * L)
		{
			size_t len;
			static utf16string ret_str;
			auto str = luaL_checklstring(L, 1, &len);
			ret_str.clear();
			a_UTF8ArrayToUTF16String(str, len, ret_str);
			lua_pushlstring(L, (const char*)ret_str.c_str(), ret_str.length() * sizeof(utf16_char));
			return 1;
		}

		static int UnicodeToUtf8(lua_State * L)
		{
			size_t len;
			static astring ret_str;
			auto str = luaL_checklstring(L, 1, &len);
			ret_str.clear();
			a_UTF16ArrayToUTF8String((const utf16_char*)str, len, ret_str);
			lua_pushstring(L, ret_str.c_str());
			return 1;
		}

		static int GetServerDeltaTime(lua_State * L)
		{
			double server_send_time = lua_tonumber(L, 1);
			double dt = server_send_time - AzureTimeManager::GetMillisecondsFromEpoch();
			AzureTimeManager::ServerDeltaTime = dt;
			lua_pushnumber(L, dt);
			return 1;
		}

		static int SetTimeZoneBias(lua_State * L)
		{
			int biasInMinutes = lua_tointeger(L, 1);
			AzureTimeManager::GetInstance().SetTimeZoneBias(biasInMinutes);
			return 0;
		}

		// param 1: unix-time or nil to use system time, returns: year(1~), month(1~12), day(1~31), dayOfWeek(0~6), hour, minute, second
		static int SystemLocalTime(lua_State * L)
		{
			FDateTime time;
			if (lua_isnumber(L, 1))
			{
				double unixTime = lua_tonumber(L, 1);
				time = AzureTimeManager::Epoch + (FTimespan::FromSeconds(unixTime) + AzureTimeManager::DiffTimeToUTC);
			}
			else
			{
				time = FDateTime::Now();
			}

			lua_pushinteger(L, time.GetYear());
			lua_pushinteger(L, time.GetMonth());
			lua_pushinteger(L, time.GetDay());
			EDayOfWeek wd = time.GetDayOfWeek();
			int day_of_week;
			if (wd == EDayOfWeek::Sunday)
				day_of_week = 0;
			else
				day_of_week = (int)wd + 1;
			lua_pushinteger(L, day_of_week);
			lua_pushinteger(L, time.GetHour());
			lua_pushinteger(L, time.GetMinute());
			lua_pushinteger(L, time.GetSecond());

			return 7;
		}

		static int GetServerGMTTime(lua_State * L)
		{
			lua_pushinteger(L, AzureTimeManager::GetInstance().GetServerGMTTime());
			return 1;
		}

		static int GetServerTimeError(lua_State * L)
		{
			lua_pushinteger(L, AzureTimeManager::GetInstance().GetTimeError());
			return 1;
		}

		static int GetServerTimeThisWeek(lua_State * L)
		{
			if (lua_isnumber(L, 1) == false)
			{
				lua_pushstring(L, "GetServerTimeThisWeek: param 1 must be number");
				lua_error(L);
				return 1;
			}
			if (lua_isnumber(L, 2) == false)
			{
				lua_pushstring(L, "GetServerTimeThisWeek: param 2 must be number");
				lua_error(L);
				return 1;
			}
			if (lua_isnumber(L, 3) == false)
			{
				lua_pushstring(L, "GetServerTimeThisWeek: param 3 must be number");
				lua_error(L);
				return 1;
			}
			if (lua_isboolean(L, 4) == false)
			{
				lua_pushstring(L, "GetServerTimeThisWeek: param 4 must be boolean");
				lua_error(L);
				return 1;
			}

			lua_pushinteger(L, AzureTimeManager::GetInstance().GetServerTimeThisWeek(lua_tointeger(L, 1), lua_tointeger(L, 2), lua_tointeger(L, 3), !!lua_toboolean(L, 4)));
			return 1;
		}
		
		static int GetTimeStampDateTime(lua_State * L)
		{
			if (lua_isnumber(L, 1) == false)
			{
				lua_pushstring(L, "GetTimeStampDateTime: param 1 must be number");
				lua_error(L);
				return 1;
			}

			int timestamp = lua_tointeger(L, 1);
			FDateTime datetime = AzureTimeManager::GetInstance().GetTimeStampDateTime(timestamp);

			lua_pushnumber(L, datetime.GetYear());
			lua_pushnumber(L, datetime.GetMonth());
			lua_pushnumber(L, datetime.GetDay());
			lua_pushnumber(L, datetime.GetHour());
			lua_pushnumber(L, datetime.GetMinute());
			lua_pushnumber(L, datetime.GetSecond());
			int dayofweek = (int)datetime.GetDayOfWeek();
			lua_pushnumber(L, dayofweek + 1);

			return 7;
		}

		static int GetMillisecondsFromEpoch(lua_State * L)
		{
			lua_pushnumber(L, AzureTimeManager::GetInstance().GetMillisecondsFromEpoch());
			return 1;
		}

		static void PushCulture(lua_State* L, FCulture const& culture)
		{
			lua_createtable(L, 0, 3);
			lua_pushstring(L, TCHAR_TO_UTF8(*culture.GetName()));
			lua_setfield(L, -2, "name");
			lua_pushstring(L, TCHAR_TO_UTF8(*culture.GetDisplayName()));
			lua_setfield(L, -2, "displayName");
			lua_pushstring(L, TCHAR_TO_UTF8(*culture.GetEnglishName()));
			lua_setfield(L, -2, "englishName");
		}

		// param 1: cultureName, return: isSuccess
		static int Localization_SetCurrentLanguage(lua_State* L)
		{
			FString culture = UTF8_TO_TCHAR(luaL_checkstring(L, 1));
			bool result = FInternationalization::Get().SetCurrentLanguage(culture);
			lua_pushboolean(L, result ? 1 : 0);
			return 1;
		}
		
		// return: { name=, displayName=, ... }
		static int Localization_GetCurrentLanguage(lua_State* L)
		{
			FCultureRef cultureRef = FInternationalization::Get().GetCurrentLanguage();
			PushCulture(L, cultureRef.Get());
			return 1;
		}

		// param 1: cultureName, return: isSuccess
		static int Localization_SetCurrentLocale(lua_State* L)
		{
			FString culture = UTF8_TO_TCHAR(luaL_checkstring(L, 1));
			bool result = FInternationalization::Get().SetCurrentLocale(culture);
			lua_pushboolean(L, result ? 1 : 0);
			return 1;
		}
		
		// return: { name=, displayName=, ... }
		static int Localization_GetCurrentLocale(lua_State* L)
		{
			FCultureRef cultureRef = FInternationalization::Get().GetCurrentLocale();
			PushCulture(L, cultureRef.Get());
			return 1;
		}

		// param 1: cultureName, return: isSuccess
		static int Localization_SetCurrentCulture(lua_State* L)
		{
			FString culture = UTF8_TO_TCHAR(luaL_checkstring(L, 1));
			bool bForceApply = lua_toboolean(L, 2);
			bool result = FInternationalization::Get().SetCurrentCulture(culture, bForceApply);
			lua_pushboolean(L, result ? 1 : 0);
			return 1;
		}
		
		// return: { name=, displayName=, ... }
		static int Localization_GetCurrentCulture(lua_State* L)
		{
			FCultureRef cultureRef = FInternationalization::Get().GetCurrentCulture();
			PushCulture(L, cultureRef.Get());
			return 1;
		}

		// return: { name=, displayName=, ... }
		static int Localization_GetDefaultCulture(lua_State* L)
		{
			FCultureRef cultureRef = FInternationalization::Get().GetDefaultCulture();
			PushCulture(L, cultureRef.Get());
			return 1;
		}

		// return: { name=, displayName=, ... }
		static int Localization_GetDefaultLanguage(lua_State* L)
		{
			FCultureRef cultureRef = FInternationalization::Get().GetDefaultLanguage();
			PushCulture(L, cultureRef.Get());
			return 1;
		}

		// return: { name=, displayName=, ... }
		static int Localization_GetDefaultLocale(lua_State* L)
		{
			FCultureRef cultureRef = FInternationalization::Get().GetDefaultLocale();
			PushCulture(L, cultureRef.Get());
			return 1;
		}

		static int Localization_InitGameTextLocalization(lua_State* L)
		{
			//刷新 native culture 缓存，见 GetNativeCultureName in ApplyDefaultCultureSettings
			const bool bSkipCache = true;
			TextLocalizationResourceUtil::GetNativeProjectCultureName(bSkipCache);
			
			InitGameTextLocalization();
			return 0;
		}

		static int Localization_RefreshResources(lua_State* L)
		{
			FTextLocalizationManager::Get().RefreshResources();
			return 0;
		}
		
		static int SetMoveStampSn(lua_State * L)
		{
			AzureTimeManager::GetInstance().MoveStampSn = (uint8)lua_tointeger(L, 1);
			return 0;
		}

		static int AddCoolDownData(lua_State * L)
		{
			int idx = lua_tointeger(L, 1);
			int curtime = lua_tointeger(L, 2);
			int maxtime = lua_tointeger(L, 3);

			AzureTimeManager::GetInstance().SetCoolDownData(idx, (float)curtime / 1000, (float)maxtime / 1000);
			return 0;
		}

		static int UpdateCoolDownData(lua_State * L)
		{
			int idx = lua_tointeger(L, 1);
			int curtime = lua_tointeger(L, 2);
			AzureTimeManager::GetInstance().UpdateCoolDownData(idx, (float)curtime / 1000);
			return 0;
		}

		static int GetCoolDownData(lua_State * L)
		{
			int id = lua_tointeger(L, 1);

			const CoolDownItem* item = AzureTimeManager::GetInstance().GetCoolDownData(id);
			if (item == nullptr)
			{
				lua_pushnumber(L, 0);
				lua_pushnumber(L, 0);
			}
			else
			{
				lua_pushnumber(L, item->CurTime);
				lua_pushnumber(L, item->MaxTime);
			}
			return 2;
		}

		static int ClearCoolDownData(lua_State * L)
		{
			AzureTimeManager::GetInstance().ClearCoolDownData();
			return 0;
		}

		static int GetTemporaryCachePath(lua_State * L)
		{
			lua_pushstring(L, TCHAR_TO_UTF8(*FPaths::ProjectIntermediateDir()));
			return 1;
		}
		
		static int SetShadowDistance(lua_State * L)
		{
			int n = 1;
			if (!lua_isnumber(L, n)) {
				lua_pushstring(L, "SetShadowDistance: param 1 must be number");
				lua_error(L);
				return 1;
			}
			float dist = lua_tonumber(L, n);


			AzureUtility::SetShadowDistance(dist);
			return 0;
		}

		static int GetShadowDistance(lua_State * L)
		{
			lua_pushnumber(L, AzureUtility::GetShadowDistance());
			return 1;
		}
		static int SetShadowCascadesNum(lua_State * L)
		{
			int num = lua_tointeger(L, 1);
			AzureUtility::SetShadowCascadesNum(num);
			return 0;
		}

		static int SetShadowBias(lua_State* L)
		{
			float bias = float(luaL_checknumber(L, 1));
			AzureUtility::SetShadowBias(bias);
			return 0;
		}

		//param 1: AzureEnvironmentManager, param 2: bias
		static int SetShadowBiasForEnvManager(lua_State* L)
		{
			wLua::LuaUObjectUserData* userdata = nullptr; UObject* Obj = wLua::FLuaUtils::GetUObject(L,1,"AzureEnvironmentManager",&userdata);if(!Obj) { wLua::LuaStatic::traceback(L,"AzureEnvironmentManager must be non-null"); lua_error(L);  return 0;}
			AAzureEnvironmentManager * envManager = (AAzureEnvironmentManager *)Obj;

			float bias = float(luaL_checknumber(L, 2));
			AzureUtility::SetShadowBiasForEnvManager(envManager, bias);
			return 0;
		}

		static int SetDepthOfField(lua_State * L)
		{
			int pram_count = lua_gettop(L);
			int n = 1;
			if (!lua_isboolean(L, n)) {
				lua_pushstring(L, "SetDepthOfField: param 1 must be boolean (bEnable)");
				lua_error(L);
				return 1;
			}
			bool bEnable = lua_toboolean(L, n)==0?false:true;

			n++;
			if (!lua_isnumber(L, n)) {
				lua_pushstring(L, "SetDepthOfField: param 6 must be number (fFocalRegion)");
				lua_error(L);
				return 1;
			}
			float fFocalRegion = lua_tonumber(L, n);

			n++;
			if (!lua_isnumber(L, n)) {
				lua_pushstring(L, "SetDepthOfField: param 7 must be number (fScale)");
				lua_error(L);
				return 1;
			}
			float fScale = lua_tonumber(L, n);

			n++;
			if (!lua_isboolean(L, n)) {
				lua_pushstring(L, "SetDepthOfField: param 8 must be boolean (bEnableHighQuality)");
				lua_error(L);
				return 1;
			}
			bool bEnableHighQuality = lua_toboolean(L, n) == 0 ? false : true;		
			
			n++;
			if (!lua_isnumber(L, n)) {
				lua_pushstring(L, "SetDepthOfField: param 9 must be number (fFarBlurSize)");
				lua_error(L);
				return 1;
			}
			float fFarBlurSize = lua_tonumber(L, n);

			n++;
			float fSpecifiedDofFactor = -1.0f;
			if (lua_isnumber(L, n))
				fSpecifiedDofFactor = lua_tonumber(L, n);

			AzureUtility::SetDepthOfField(bEnable, fFocalRegion, fScale, bEnableHighQuality, fFarBlurSize, fSpecifiedDofFactor);
			return 0;
		}

		static int AddPostProcessBlendableToCamera(lua_State * L)
		{
			UObject* obj = wLua::FLuaUtils::GetUObject(L, 1, "MaterialInterface");
			UMaterialInterface* mat = obj ? Cast<UMaterialInterface>(obj) : nullptr;
			if (!mat)
			{
				lua_pushstring(L, "AddPostProcessBlendableToCamera: param 1 must be MaterialInstance!");
				lua_error(L);
				return 1;
			}

			obj = wLua::FLuaUtils::GetUObject(L, 2, "CameraComponent");
			UCameraComponent* cam = obj ? Cast<UCameraComponent>(obj) : nullptr;
			if (!cam)
			{
				lua_pushstring(L, "AddPostProcessBlendableToCamera: param 2 must be CameraComponent!");
				lua_error(L);
				return 1;
			}
			float fWeight = (float)luaL_checknumber(L, 3);

			int index = AzureUtility::AddPostProcessBlendableToCamera(mat, cam, fWeight);
			lua_pushnumber(L, index);
			return 1;
		}

		static int RemovePostProcessBlendableFromCamera(lua_State * L)
		{
			UObject* obj = wLua::FLuaUtils::GetUObject(L, 1, "MaterialInterface");
			UMaterialInterface* mat = obj ? Cast<UMaterialInterface>(obj) : nullptr;
			if (!mat)
			{
				lua_pushstring(L, "RemovePostProcessBlendableFromCamera: param 1 must be MaterialInstance!");
				lua_error(L);
				return 1;
			}

			obj = wLua::FLuaUtils::GetUObject(L, 2, "CameraComponent");
			UCameraComponent* cam = obj ? Cast<UCameraComponent>(obj) : nullptr;
			if (!cam)
			{
				lua_pushstring(L, "RemovePostProcessBlendableFromCamera: param 2 must be CameraComponent!");
				lua_error(L);
				return 1;
			}
			AzureUtility::RemovePostProcessBlendableFromCamera(mat, cam);
			return 0;
		}

		static int SetPostProcessBlendWeight(lua_State * L)
		{
			UObject* obj = wLua::FLuaUtils::GetUObject(L, 1, "CameraComponent");
			UCameraComponent* cam = obj ? Cast<UCameraComponent>(obj) : nullptr;
			if (!cam)
			{
				lua_pushstring(L, "SetPostProcessBlendWeight: param 2 must be CameraComponent!");
				lua_error(L);
				return 1;
			}
			int32 index = (float)luaL_checknumber(L, 2);
			float fWeight = (float)luaL_checknumber(L, 3);
			AzureUtility::SetPostProcessBlendWeight(cam, index, fWeight);
			return 0;
		}

		static int AddPostProcessMaterial(lua_State * L)
		{
			UObject* obj = wLua::FLuaUtils::GetUObject(L, 1, "MaterialInterface");
			UMaterialInterface* mat = obj ? Cast<UMaterialInterface>(obj) : nullptr;
			if (!mat)
			{
				lua_pushstring(L, "AddPostProcessMaterial: param 1 must be MaterialInstance!");
				lua_error(L);
				return 1;
			}

			float fWeight = (float)luaL_checknumber(L, 2);

			AzureUtility::AddPostProcessMaterial(mat, fWeight);
			return 0;
		}

		static int RemovePostProcessMaterial(lua_State * L)
		{
			UObject* obj = wLua::FLuaUtils::GetUObject(L, 1, "MaterialInterface");
			UMaterialInterface* mat = obj ? Cast<UMaterialInterface>(obj) : nullptr;
			if (!mat)
			{
				lua_pushstring(L, "RemovePostProcessMaterial: param 1 must be MaterialInstance!");
				lua_error(L);
				return 1;
			}

			AzureUtility::RemovePostProcessMaterial(mat);
			return 0;
		}

		static int AddPostProcessColorLUTTexture(lua_State * L)
		{
			UMaterialInterface* parentMat = Cast<UMaterialInterface>(wLua::FLuaUtils::GetUObject(L, 1, "MaterialInterface"));
			if (!parentMat)
			{
				lua_pushstring(L, "AddPostProcessColorLUTTexture: param 1 must be UMaterialInterface!");
				lua_error(L);
				return 1;
			}

			UObject* obj = wLua::FLuaUtils::GetUObject(L, 2, "Texture");
			UTexture* tex = obj ? Cast<UTexture>(obj) : nullptr;
			if (!tex)
			{
				lua_pushstring(L, "AddPostProcessColorLUTTexture: param 1 must be UTexture!");
				lua_error(L);
				return 1;
			}

			float fWeight = (float)luaL_checknumber(L, 3);

			AzureUtility::AddPostProcessColorLUTTexture(parentMat, tex, fWeight);
			return 0;
		}

		static int RemovePostProcessColorLUTTexture(lua_State * L)
		{
			AzureUtility::RemovePostProcessColorLUTTexture();
			return 0;
		}

		static int SetScreenTint(lua_State * L)
		{
			int pram_count = lua_gettop(L);
			if (!lua_isboolean(L, 1)) {
				lua_pushstring(L, "SetScreenTint: param 1 must be boolean (bEnable)");
				lua_error(L);
				return 1;
			}
			bool bEnable = lua_toboolean(L, 1) == 0 ? false : true;
			FLinearColor lc = wLua::FLuaLinearColor::Get(L, 2);
			float saturation = lua_tonumber(L, 3);
			float contrast = lua_tonumber(L, 4);
			float vignette = lua_tonumber(L, 5);
			UMaterialInterface* mat = Cast<UMaterialInterface>(wLua::FLuaUtils::GetUObject(L, 6, "MaterialInterface"));

			AzureUtility::SetScreenTint(bEnable, lc, saturation, contrast, vignette, mat);
			return 0;
		}

		static int SetScreenFringeIntensity(lua_State * L)
		{
			float fringeIntensity = lua_tonumber(L, 1);
			AzureUtility::SetScreenFringeIntensity(fringeIntensity);
			return 0;
		}

		static int GetCurWorldVignetteIntensity(lua_State *L)
		{
			float ret = AzureUtility::GetCurWorldVignetteIntensity();
			lua_pushnumber(L, ret);
			return 1;
		}

		static int SetPostProcessFilmSaturation(lua_State * L)
		{
			float saturation = lua_tonumber(L, 1);
			AzureUtility::SetPostProcessFilmSaturation(saturation);
			return 0;
		}

		static int SetPostProcessColorSaturation(lua_State * L)
		{
			FVector4 saturation = wLua::FLuaVector4::Get(L, 1);
			AzureUtility::SetPostProcessColorSaturation(saturation);
			return 0;
		}

		static int GetCurWorldPostProcessFilmSaturation(lua_State *L)
		{
			float ret = AzureUtility::GetCurWorldPostProcessFilmSaturation();
			lua_pushnumber(L, ret);
			return 1;
		}

		static int GetCurWorldPostProcessColorSaturation(lua_State *L)
		{
			FVector4 saturation = AzureUtility::GetCurWorldPostProcessColorSaturation();
			wLua::FLuaVector4::Return(L, saturation);
			return 1;
		}

		static int AddActorComponent(lua_State * L)
		{
			wLua::LuaUObjectUserData* userdata = nullptr;
			AActor* obj = Cast<AActor>(wLua::FLuaUtils::GetUObject(L, 1, "Actor", &userdata));
			if (!obj)
			{
				astring msg = astring("AddActorComponent: param 1 must be Actor ") + astring(userdata ? (userdata->uobj ? "has uobject" : "uobject is null") : "no userdata");
				lua_pushstring(L, msg.c_str());
				lua_error(L);
				return 1;
			}

			UActorComponent* comp = Cast<UActorComponent>(wLua::FLuaUtils::GetUObject(L, 2, "ActorComponent"));
			if (!comp)
			{
				astring msg = astring("AddActorComponent: param 2 must be ActorComponent!");
				lua_pushstring(L, msg.c_str());
				lua_error(L);
				return 1;
			}

			bool bSucc = AzureUtility::AddActorComponent(obj, comp);
			lua_pushboolean(L, bSucc);
			return 1;
		}

		static int RemoveActorComponent(lua_State * L)
		{
			wLua::LuaUObjectUserData* userdata = nullptr;
			AActor* obj = Cast<AActor>(wLua::FLuaUtils::GetUObject(L, 1, "Actor", &userdata));
			if (!obj)
			{
				astring msg = astring("RemoveActorComponent: param 1 must be Actor ") + astring(userdata ? (userdata->uobj ? "has uobject" : "uobject is null") : "no userdata");
				lua_pushstring(L, msg.c_str());
				lua_error(L);
				return 1;
			}

			bool bSucc = false;
			UActorComponent* comp = nullptr;
			if (lua_isstring(L, 2))
			{
				const char* compName = lua_tostring(L, 2);
				FString Name = UTF8_TO_TCHAR(compName);
				comp = obj->GetComponentInChildren(Name);
			}
			else
			{
				comp = Cast<UActorComponent>(wLua::FLuaUtils::GetUObject(L, 2, "ActorComponent"));
				if (!comp)
				{
					astring msg = astring("RemoveActorComponent: param 2 must be ActorComponent!");
					lua_pushstring(L, msg.c_str());
					lua_error(L);
					return 1;
				}
			}

			if (comp)
			{
				bSucc = AzureUtility::RemoveActorComponent(obj, comp);
			}

			lua_pushboolean(L, bSucc);
			return 1;
		}

		static int AddAzureObjectComponent(lua_State * L)
		{
			lua_pushvalue(L, 1);
			wLua::lua_registry_handle ObjRef = wLua::lua_registry_handle::wlua_ref(L, LUA_REGISTRYINDEX);

			wLua::LuaUObjectUserData* userdata = nullptr;
			AActor* obj = Cast<AActor>(wLua::FLuaUtils::GetUObject(L, 2, "Actor",&userdata));
			if (!obj)
			{
				wLua::lua_registry_handle::wlua_unref(L, LUA_REGISTRYINDEX, ObjRef);

				astring msg = astring("AddAzureObjectComponent: param 2 must be Actor ") + astring(userdata ? (userdata->uobj ? "has uobject" : "uobject is null") : "no userdata");
				lua_pushstring(L, msg.c_str());
				lua_error(L);
				return 1;
			}
			bool IsHost = !!lua_toboolean(L, 3);

			UAzureObjectComponent::MISCMASK miscmask = UAzureObjectComponent::NONE;
			if (!lua_isnoneornil(L, 4))
				miscmask = UAzureObjectComponent::MISCMASK(luaL_checkinteger(L, 4));

			UAzureObjectComponent* comp = NewObject<UAzureObjectComponent>(obj);
			if (AzureUtility::AddActorComponent(obj, comp))
				comp->InitObjRef(ObjRef, IsHost, miscmask);
			else
			{
				wLua::lua_registry_handle::wlua_unref(L, LUA_REGISTRYINDEX, ObjRef);
			}

			return 0;
		}

		static int UpdateSlaveBoneMap(lua_State *L)
		{
			wLua::LuaUObjectUserData* userdata = nullptr;
			USkinnedMeshComponent* pMasterPoseComponent = Cast<USkinnedMeshComponent>(wLua::FLuaUtils::GetUObject(L, 1, "SkinnedMeshComponent", &userdata));
			if (!pMasterPoseComponent)
			{
				astring msg = astring("UpdateSlaveBoneMap: param 1 must be Non-null SkinnedMeshComponent!");
				lua_pushstring(L, msg.c_str());
				lua_error(L);
				return 1;
			}

			AzureUtility::UpdateAllSlaveBoneMap(pMasterPoseComponent);
			return 0;
		}

#define REUSE_COMP 1

		static int AddModelSkin(lua_State * L)
		{
			wLua::LuaUObjectUserData* userdata = nullptr;
			UMeshComponent* pMeshComponent = Cast<UMeshComponent>(wLua::FLuaUtils::GetUObject(L, 1, "MeshComponent", &userdata));
			if (!pMeshComponent)
			{
				astring msg = astring("AddModelSkin: param 1 must be MeshComponent!");
				lua_pushstring(L, msg.c_str());
				lua_error(L);
				return 1;
			}
			
			UObject* pObject = Cast<UObject>(wLua::FLuaUtils::GetUObject(L, 2, "Object", &userdata));
			if (!pObject)
			{
				astring msg = astring("AddModelSkin: param 2 must be Object") + astring(userdata ? (userdata->uobj ? "has uobject" : "uobject is null") : "no userdata");
				lua_pushstring(L, msg.c_str());
				lua_error(L);
				return 1;
			}
			USkeletalMesh *pSkeletalMesh = Cast<USkeletalMesh>(pObject);
				
			UMeshComponent *pMeshCom = NULL;

			if (!lua_isstring(L, 3))
			{
				lua_pushstring(L, "AddModelSkin: param 3 must be string");
				lua_error(L);
				return 1;
			}
			FName Name = UTF8_TO_TCHAR(luaL_checkstring(L, 3));

			FName SocketName(NAME_None);
			if (lua_isstring(L, 4))
			{
				SocketName = UTF8_TO_TCHAR(luaL_checkstring(L, 4));
			}

			bool bSlave = !!lua_toboolean(L, 5);

			if (!pSkeletalMesh)
			{
				UStaticMesh *pStaticMesh = Cast<UStaticMesh>(pObject);
				if (!pStaticMesh)
				{
					astring msg = astring("AddModelSkin: param 2 must be SkeletalMesh or StaticMesh!");
					lua_pushstring(L, msg.c_str());
					lua_error(L);
					return 1;
				}
				else
				{
					UObject* pOuter = pMeshComponent->GetOuter();

					UStaticMeshComponent* pStaticMeshCom = nullptr;

#if REUSE_COMP
					//	Find exist first
					AActor* pActor = Cast<AActor>(pOuter);
					if (pActor)
					{
						const TSet<UActorComponent*>& comps = pActor->GetComponents();
						for (UActorComponent* Component : comps)
						{
							if (Component && Component->GetFName() == Name)
							{
								UStaticMeshComponent* pCom = Cast<UStaticMeshComponent>(Component);
								if (pCom)
								{
									//	Found and Type match: ReUse
									pStaticMeshCom = pCom;

									UStaticMesh* pExistMesh = pCom->GetStaticMesh();
									if (pExistMesh != pStaticMesh)
									{
										if (pExistMesh)
										{
											//	Need Destroy??
											bool b = true;
										}
										pStaticMeshCom->SetStaticMesh(pStaticMesh);
									}
								}
								else
								{
									//	SameName but Type not match: Destroy
									AzureUtility::RemoveSkinOrStaticMeshComponent(pCom, true);
								}
								break;
							}
						}
					}
#endif

					if (pStaticMeshCom)
					{
						if (SocketName == pStaticMeshCom->GetAttachSocketName())
						{
							//	不用再Add和Register，直接返回
							wLua::FLuaUtils::ReturnUObject(L, pStaticMeshCom);
							return 1;
						}
						else
						{
							pStaticMeshCom->DetachFromComponent(FDetachmentTransformRules::KeepRelativeTransform);
						}
					}
					else
					{
						//	Not Found: Create
						pStaticMeshCom = NewObject<UStaticMeshComponent>(pOuter, Name);
						pStaticMeshCom->SetStaticMesh(pStaticMesh);
					}

					pMeshCom = pStaticMeshCom;
				}
			}
			else
			{
				UObject* pOuter = pMeshComponent->GetOuter();

				USkeletalMeshComponent* pSkelMeshCom = nullptr;

#if REUSE_COMP
				//	Find exist first
				AActor* pActor = Cast<AActor>(pOuter);
				if (pActor)
				{
					const TSet<UActorComponent*>& comps = pActor->GetComponents();
					for (UActorComponent* Component : comps)
					{
						if (Component && Component->GetFName() == Name)
						{
							USkeletalMeshComponent* pCom = Cast<USkeletalMeshComponent>(Component);
							if (pCom)
							{
								//	Found and Type match: ReUse
								pSkelMeshCom = pCom;

								USkeletalMesh* pExistMesh = pCom->SkeletalMesh;
								if (pExistMesh != pSkeletalMesh)
								{
									if (pExistMesh)
									{
										//	Need Destroy??
										bool b = true;
									}
								}
							}
							else
							{
								//	SameName but Type not match: Destroy
								AzureUtility::RemoveSkinOrStaticMeshComponent(pCom, true);
							}
							break;
						}
					}
				}
#endif

				if (pSkelMeshCom)
				{
					pSkelMeshCom->EmptyOverrideMaterials();
					pSkelMeshCom->SetSkeletalMesh(pSkeletalMesh);
					AzureUtility::UpdateAllSlaveBoneMap(pSkelMeshCom);

					if (SocketName == pSkelMeshCom->GetAttachSocketName())
					{
						//	不用再Add和Register，直接返回
						if (bSlave)
							AzureUtility::SetSlaveSkinComponent(pMeshComponent, pSkelMeshCom);
						else
							pSkelMeshCom->SetMasterPoseComponent(nullptr);

						wLua::FLuaUtils::ReturnUObject(L, pSkelMeshCom);
						return 1;
					}
					else
					{
						pSkelMeshCom->DetachFromComponent(FDetachmentTransformRules::KeepRelativeTransform);
					}
				}
				else
				{
					//	Not Found: Create
					pSkelMeshCom = NewObject<USkeletalMeshComponent>(pOuter, Name);
					pSkelMeshCom->SetSkeletalMesh(pSkeletalMesh);
				}

				pMeshCom = pSkelMeshCom;
			}

			bool bRet = AzureUtility::AddModelSkin(pMeshComponent, pMeshCom, SocketName, bSlave);
			
			wLua::FLuaUtils::ReturnUObject(L, pMeshCom);
			return 1;
		}
		
		static int RemoveModelSkin(lua_State * L)
		{
			wLua::LuaUObjectUserData* userdata = nullptr;
			UMeshComponent* pMeshComponent = Cast<UMeshComponent>(wLua::FLuaUtils::GetUObject(L, 1, "MeshComponent", &userdata));
			if (!pMeshComponent)
			{
				astring msg = astring("RemoveModelSkin: param 1 must be NON-null MeshComponent!");
				lua_pushstring(L, msg.c_str());
				lua_error(L);
				return 1;
			}

			if (!lua_isstring(L, 2))
			{
				lua_pushstring(L, "RemoveModelSkin: param 2 must be string");
				lua_error(L);
				return 1;
			}

			FName Name = UTF8_TO_TCHAR(luaL_checkstring(L, 2));
			bool bDestroy = true;
			if (lua_isboolean(L, 3))
				bDestroy = !!lua_toboolean(L, 3);

			bool bRemoved = AzureUtility::RemoveModelSkin(pMeshComponent, Name, bDestroy);
			return 0;
		}

		static int GetModelSkinComponent(lua_State * L)
		{
			wLua::LuaUObjectUserData* userdata = nullptr;
			UMeshComponent* pMeshComponent = Cast<UMeshComponent>(wLua::FLuaUtils::GetUObject(L, 1, "MeshComponent", &userdata));
			if (!pMeshComponent)
			{
				astring msg = astring("GetModelSkinComponent: param 1 must be NON-null MeshComponent!");
				lua_pushstring(L, msg.c_str());
				lua_error(L);
				return 1;
			}

			if (!lua_isstring(L, 2))
			{
				lua_pushstring(L, "GetModelSkinComponent: param 2 must be string");
				lua_error(L);
				return 1;
			}
			FName Name = UTF8_TO_TCHAR(luaL_checkstring(L, 2));

			UObject* pObj = AzureUtility::GetModelSkinComponent(pMeshComponent, Name);

			if (pObj)
				wLua::FLuaUtils::ReturnUObject(L, pObj);
			else
				lua_pushnil(L);

			return 1;
		}

		static int GetMeshByComponent(lua_State * L)
		{
			wLua::LuaUObjectUserData* userdata = nullptr;
			UMeshComponent* MeshComponent = Cast<UMeshComponent>(wLua::FLuaUtils::GetUObject(L, 1, "MeshComponent", &userdata));
			if (!MeshComponent) {
				astring msg = astring("GetMeshByComponent: param 1 must be MeshComponent ");
				lua_pushstring(L, msg.c_str());
				lua_error(L);
				return 1;
			}

			UObject* pObj = nullptr;
			USkinnedMeshComponent* skinnedMeshCom = Cast<USkinnedMeshComponent>(MeshComponent);
			if (skinnedMeshCom)
			{
				pObj = skinnedMeshCom->SkeletalMesh;
			}
			else
			{
				UStaticMeshComponent* staticMeshCom = Cast<UStaticMeshComponent>(MeshComponent);
				if (staticMeshCom)
					pObj = staticMeshCom->GetStaticMesh();
			}

			if (pObj)
				wLua::FLuaUtils::ReturnUObject(L, pObj);
			else
				lua_pushnil(L);
			return 1;
		}

		static int RGB2HSV(lua_State * L)
		{
			if (lua_isnumber(L, 1) == false)
			{
				lua_pushstring(L, "RGB2HSV: param 1 must be int");
				lua_error(L);
				return 1;
			}
			int color = lua_tointeger(L, 1);

			FColor FCo((0xFF << 24) | color);

			FLinearColor ValueColor = FLinearColor::FromSRGBColor(FCo);

			ValueColor = ValueColor.LinearRGBToHSV();

			// In the new color, R = H, G = S, B = V, A = A
			lua_pushnumber(L, ValueColor.R);
			lua_pushnumber(L, ValueColor.G);
			lua_pushnumber(L, ValueColor.B);
			return 3;
		}

		static int HSV2RGB(lua_State * L)
		{
			if (lua_isnumber(L, 1) == false)
			{
				lua_pushstring(L, "HSV2RGB: param 1 must be number");
				lua_error(L);
				return 1;
			}
			float R = lua_tonumber(L, 1);

			if (lua_isnumber(L, 2) == false)
			{
				lua_pushstring(L, "HSV2RGB: param 2 must be number");
				lua_error(L);
				return 2;
			}
			float G = lua_tonumber(L, 2);

			if (lua_isnumber(L, 3) == false)
			{
				lua_pushstring(L, "HSV2RGB: param 3 must be number");
				lua_error(L);
				return 1;
			}
			float B = lua_tonumber(L, 3);

			FLinearColor ValueColor(R,G,B,1.0f);
			ValueColor = ValueColor.HSVToLinearRGB();
			FColor FCo = ValueColor.ToFColor(true);
			lua_pushnumber(L, FCo.DWColor()&0x00ffffff);
			return 1;
		}

		static int SetDynamicMaterial(lua_State * L)
		{
			UMeshComponent* Obj = Cast<UMeshComponent>(wLua::FLuaUtils::GetUObject(L, 1, "MeshComponent"));
			if (!Obj)
			{
				wLua::LuaStatic::traceback(L, "GetDynamicMaterial #1 must be a MeshComponent");
				lua_error(L);
				return 1;
			}
			if (!lua_isstring(L, 2))
			{
				lua_pushstring(L, "GetDynamicMaterial: param 2 must be string");
				lua_error(L);
				return 1;
			}

			FName MaterialSlotName = UTF8_TO_TCHAR(luaL_checkstring(L, 2));
			int32 idx = Obj->GetMaterialIndex(MaterialSlotName);
			if (idx < 0)
				return 0;

			UMaterialInterface* pMaterial = Obj->GetMaterial(idx);
			if (!pMaterial)
				return 0;

			UMaterialInterface* mat = Cast<UMaterialInterface>(wLua::FLuaUtils::GetUObject(L, 3, "MaterialInterface"));
			if (!mat)
			{
				wLua::LuaStatic::traceback(L, "SetDynamicMaterial #3 must be a MaterialInterface");
				lua_error(L);
				return 1;
			}

			UMaterialInstanceDynamic* pInstanceDynamic = Cast<UMaterialInstanceDynamic>(mat);
			if (!pInstanceDynamic)
			{
				pInstanceDynamic = UMaterialInstanceDynamic::Create(mat, pMaterial->GetOuter());
				
			}
			Obj->SetMaterial(idx, pInstanceDynamic);
			return 0;
		}

		static int GetDynamicMaterial(lua_State * L)
		{
			UMeshComponent* Obj = Cast<UMeshComponent>(wLua::FLuaUtils::GetUObject(L, 1, "MeshComponent"));
			if (!Obj)
			{
				wLua::LuaStatic::traceback(L, "GetDynamicMaterial #1 must be a MeshComponent");
				lua_error(L);
				return 1;
			}
			if (!lua_isstring(L, 2))
			{
				lua_pushstring(L, "GetDynamicMaterial: param 2 must be string");
				lua_error(L);
				return 1;
			}

			FName MaterialSlotName = UTF8_TO_TCHAR(luaL_checkstring(L, 2));
			int32 idx = Obj->GetMaterialIndex(MaterialSlotName);
			if (idx < 0)
				return 0;

			UMaterialInterface* pMaterial = Obj->GetMaterial(idx);
			if (!pMaterial)
				return 0;

			UMaterialInstanceDynamic* pInstanceDynamic = Cast<UMaterialInstanceDynamic>(pMaterial);
			if (!pInstanceDynamic)
			{
				pInstanceDynamic = Obj->CreateDynamicMaterialInstance(idx);
			}

			if (pInstanceDynamic)
				wLua::FLuaUtils::ReturnUObject(L, pInstanceDynamic);
			else
				lua_pushnil(L);
			return 1;
		}
		
		static int CutWound(lua_State* L)
		{
			ACharacter* Attacker = Cast<ACharacter>(wLua::FLuaUtils::GetUObject(L, 1, "Character"));
			if (!Attacker)
			{
				wLua::LuaStatic::traceback(L, "CutWound #1 must be a Character");
				lua_error(L);
				return 1;
			}
			ACharacter* Attackee = Cast<ACharacter>(wLua::FLuaUtils::GetUObject(L, 2, "Character"));
			if (!Attackee)
			{
				wLua::LuaStatic::traceback(L, "CutWound #2 must be a Character");
				lua_error(L);
				return 1;
			}
			FName AttackSocket = UTF8_TO_TCHAR(luaL_checkstring(L, 3));

			FName HitBone = UTF8_TO_TCHAR(luaL_checkstring(L, 4));

			if (!lua_isnumber(L, 5))
			{
				lua_pushstring(L, "CutWound: #4 must be float");
				lua_error(L);
				return 1;
			}
			float Roll = lua_tonumber(L, 5);

			wLua::LuaUObjectUserData* userdata = nullptr;
			UTexture* Scar = Cast<UTexture>(wLua::FLuaUtils::GetUObject(L, 6, "Texture", &userdata));
			UDataTable* DataTable = Cast<UDataTable>(wLua::FLuaUtils::GetUObject(L, 7, "DataTable", &userdata));
			FVector Scale = lua_isnoneornil(L, 8) ? FVector::OneVector : FLuaVector::Get(L, 8);
			float duration = lua_isnoneornil(L, 9) ? 2.0f : lua_tonumber(L, 9);
			bool fixedSize = lua_isnoneornil(L, 10) ? false : lua_toboolean(L, 10);
			bool debug = lua_isnoneornil(L, 11) ? false : !!lua_tonumber(L, 11);
			AzureUtility::CutWound(Attacker, Attackee, AttackSocket, HitBone, Roll, Scar, DataTable, Scale, duration, fixedSize, debug);
			return 0;
		}

		static int CutWoundTree(lua_State* L)
		{
			AActor* Attackee = Cast<AActor>(wLua::FLuaUtils::GetUObject(L, 1, "Actor"));
			if (!Attackee)
			{
				wLua::LuaStatic::traceback(L, "CutWoundTree #1 must be a Actor");
				lua_error(L);
				return 1;
			}

			FVector vPos = FLuaVector::Get(L, 2);
			FVector vDir = FLuaVector::Get(L, 3);

			if (!lua_isnumber(L, 4))
			{
				lua_pushstring(L, "CutWoundTree: #4 must be float");
				lua_error(L);
				return 1;
			}
			float Roll = lua_tonumber(L, 4);

			FVector Scale = lua_isnoneornil(L, 5) ? FVector::OneVector : FLuaVector::Get(L, 5);

			wLua::LuaUObjectUserData* userdata = nullptr;
			UTexture* Scar = Cast<UTexture>(wLua::FLuaUtils::GetUObject(L, 6, "Texture", &userdata));
			float duration = lua_isnoneornil(L, 7) ? 2.0f : lua_tonumber(L, 7);
			AzureUtility::CutWoundTree(Attackee, vPos, vDir, Roll, Scale, Scar, duration);
			return 0;
		}

		static int CutPersistentWound(lua_State* L)
		{
			ACharacter* Attacker = Cast<ACharacter>(wLua::FLuaUtils::GetUObject(L, 1, "Character"));
			if (!Attacker)
			{
				wLua::LuaStatic::traceback(L, "CutPersistentWound #1 must be a Character");
				lua_error(L);
				return 1;
			}
			ACharacter* Attackee = Cast<ACharacter>(wLua::FLuaUtils::GetUObject(L, 2, "Character"));
			if (!Attackee)
			{
				wLua::LuaStatic::traceback(L, "CutPersistentWound #2 must be a Character");
				lua_error(L);
				return 1;
			}

			UMaterialInterface* Painter = Cast<UMaterialInterface>(wLua::FLuaUtils::GetUObject(L, 3, "MaterialInterface"));
			if (!Painter)
			{
				wLua::LuaStatic::traceback(L, "CutPersistentWound #3 must be a UMaterialInterface");
				lua_error(L);
				return 1;
			}

			FName AttackSocket = UTF8_TO_TCHAR(luaL_checkstring(L, 4));

			FName HitBone = UTF8_TO_TCHAR(luaL_checkstring(L, 5));

			if (!lua_isnumber(L, 6))
			{
				lua_pushstring(L, "CutPersistentWound: #6 must be float");
				lua_error(L);
				return 1;
			}
			float Roll = lua_tonumber(L, 6);

			wLua::LuaUObjectUserData* userdata = nullptr;
			UTexture* Scar = Cast<UTexture>(wLua::FLuaUtils::GetUObject(L,7, "Texture", &userdata));
			FVector Scale = lua_isnoneornil(L, 8) ? FVector::OneVector : FLuaVector::Get(L, 8);
			float DepthFadeRange = lua_isnoneornil(L, 9) ? 2.0f : lua_tonumber(L, 9);
			float Opacity = lua_isnoneornil(L, 9) ? 2.0f : lua_tonumber(L, 10);
			bool fixedSize = lua_isnoneornil(L, 10) ? false : lua_toboolean(L, 11);
			bool debug = lua_isnoneornil(L, 11) ? false : !!lua_tonumber(L, 12);
			AzureUtility::CutPersistentWound(Attacker, Attackee, Painter, AttackSocket, HitBone, Roll, Scar, Scale, DepthFadeRange, Opacity, fixedSize, debug);
			return 0;
		}

		static int ClearCutPersistentWound(lua_State* L)
		{
			USkeletalMeshComponent* skeletal = Cast<USkeletalMeshComponent>(wLua::FLuaUtils::GetUObject(L, 1, "SkeletalMeshComponent"));
			if (!skeletal)
			{
				wLua::LuaStatic::traceback(L, "CutPersistentWound #1 must be a skeletal");
				lua_error(L);
				return 1;
			}
			
			AzureUtility::ClearCutPersistentWound(skeletal);
			return 0;
		}

		static int SetMaterialColor(lua_State * L)
		{
			wLua::LuaUObjectUserData* userdata = nullptr;
			AActor* pActor = Cast<AActor>(wLua::FLuaUtils::GetUObject(L, 1, "Actor", &userdata));
			if (!pActor)
			{
				astring msg = astring("SetMaterialColor: param 1 must be Actor ") + astring(userdata ? (userdata->uobj ? "has uobject" : "uobject is null") : "no userdata");
				lua_pushstring(L, msg.c_str());
				lua_error(L);
				return 1;
			}

			USkeletalMeshComponent* pSkeletalMeshComponent = pActor->FindComponentByClass<USkeletalMeshComponent>();
			if (!pSkeletalMeshComponent)
			{
				astring msg = astring("SetMaterialColor: pSkeletalMeshComponent is nil ");
				lua_pushstring(L, msg.c_str());
				lua_error(L);
				return 1;
			}

			if (!lua_isstring(L, 2))
			{
				lua_pushstring(L, "SetMaterialColor: param 2 must be string");
				lua_error(L);
				return 1;
			}
			FName Name = UTF8_TO_TCHAR(luaL_checkstring(L, 2));

			USkeletalMeshComponent* pSlavePoseComponent = NULL;
			for (int32 ComponentIdx = pSkeletalMeshComponent->GetAttachChildren().Num() - 1; ComponentIdx >= 0; --ComponentIdx)
			{
				USceneComponent* pChildComponent = pSkeletalMeshComponent->GetAttachChildren()[ComponentIdx];
				USkeletalMeshComponent* pComponent = Cast<USkeletalMeshComponent>(pChildComponent);
				FName subName = pChildComponent->GetFName();
				if (pComponent&&subName == Name)
				{
					pSlavePoseComponent = pComponent;

					break;
				}
			}
			if (!pSlavePoseComponent)
			{
				lua_pushstring(L, "SetMaterialColor:  pSlavePoseComponent is nil");
				lua_error(L);
				return 1;
			}

			if (!lua_isstring(L, 3))
			{
				lua_pushstring(L, "SetMaterialColor: param 3 must be string");
				lua_error(L);
				return 1;
			}

			if (!pSlavePoseComponent->SkeletalMesh)
			{
				lua_pushstring(L, "SetMaterialColor: no SkeletalMesh");
				lua_error(L);
				return 1;
			}

			FName MaterialSlotName = UTF8_TO_TCHAR(luaL_checkstring(L, 3));
			int32 idx = pSlavePoseComponent->GetMaterialIndex(MaterialSlotName);
			if (idx < 0)
			{
				lua_pushstring(L, "SetMaterialColor: can not find material by name");
				lua_error(L);
				return 1;
			}

			UMaterialInterface* pMaterial = pSlavePoseComponent->GetMaterial(idx);
			if (!pMaterial)
				return 0;
			UMaterialInstanceConstant* pInstanceConstant = Cast<UMaterialInstanceConstant>(pMaterial);
			UMaterialInstanceDynamic* pInstanceDynamic = Cast<UMaterialInstanceDynamic>(pMaterial);

			if (!pInstanceDynamic&&pInstanceConstant)
			{
				pInstanceDynamic = pSlavePoseComponent->CreateDynamicMaterialInstance(idx);
			}

			if (!pInstanceDynamic)
				return 0;
			if (!lua_isstring(L, 4))
			{
				lua_pushstring(L, "SetMaterialColor: param 4 must be string");
				lua_error(L);
				return 1;
			}

			FName ParameterName(NAME_None);
			ParameterName = UTF8_TO_TCHAR(luaL_checkstring(L, 4));

			if (lua_isnumber(L, 5) == false)
			{
				lua_pushstring(L, "SetMaterialColor: param 5 must be int");
				lua_error(L);
				return 1;
			}
			int c = lua_tointeger(L, 5);

			FColor FCo((0xFF<<24) | c);
			FLinearColor ValueColor(FCo);
			pInstanceDynamic->SetVectorParameterValue(ParameterName, ValueColor);
			return 0;
		}

		static int RestHostComponentInfo(lua_State * L)
		{
			ECHostComponentInfo::RestHostComponentInfo();
			return 0;
		}

		static OnBehaviorFinish SetBehaviorOnFinishCallback(lua_State * L, int nCallBackIndex)
		{
			lua_pushvalue(L, nCallBackIndex);
			wLua::lua_registry_handle* callback = new wLua::lua_registry_handle;
			*callback = wLua::lua_registry_handle::wlua_ref(L, LUA_REGISTRYINDEX);
			TSharedPtr<wLua::lua_registry_handle> callbackRef(callback);

			return [callbackRef](Azure::BehaviorFinishState FinishState)
			{
				// 回调时候必须判断nullptr
				if (!AAzureEntryPoint::IsInit())
					return;

				wLua::lua_registry_handle* callback = callbackRef.Get();

				if (callback->IsNoRef())
					return;

				lua_State_Wrapper temp_L = AAzureEntryPoint::Instance->GetL();

				if (FinishState == Azure::BehaviorFinishState::Clear)
				{
					wLua::lua_registry_handle::wlua_unref(temp_L, LUA_REGISTRYINDEX, *callback);
					callback->Clear();
				}
				else
				{
					lua_rawgeti(temp_L, LUA_REGISTRYINDEX, *callback);
					//                 if (lua_isfunction(L, -1))
					//                 {
					wLua::lua_registry_handle::wlua_unref(temp_L, LUA_REGISTRYINDEX, *callback);
					callback->Clear();
					lua_pushinteger(temp_L, (int)FinishState);
					AAzureEntryPoint::Instance->GetWLua()->Call(1);
				}
			};
		}

		static int AzureObj_OnMoveStateStopped(lua_State * L)
		{
			///////////
			int n = 1;
			if (lua_isuserdata(L, n) == false)
			{
				lua_pushstring(L, "AzureObj_OnMoveStateStopped: param 1 must be Actor");
				lua_error(L);
				return 1;
			}

			AActor* obj = Cast<AActor>(wLua::FLuaUtils::GetUObject(L, 1, "Actor"));
			UAzureObjectComponent* comp = obj ? Cast<UAzureObjectComponent>(obj->GetComponentByClass(UAzureObjectComponent::StaticClass())) : nullptr;
			if (comp == nullptr)
			{
				LuaStatic::traceback(L);
				lua_error(L);
				return 1;
			}

			comp->OnMoveStateStopped();
			return 0;
		}

		static int AddHPArcMoveBehavior(lua_State * L)
		{
			int nTop = lua_gettop(L);
			///////////
			int n = 1;
			if (lua_isuserdata(L, n) == false)
			{
				lua_pushfstring(L, "AddArcMoveBehavior: param #%d must be Actor", n);
				lua_error(L);
				return 1;
			}

			AActor* obj = Cast<AActor>(wLua::FLuaUtils::GetUObject(L, 1, "Actor"));
			UAzureObjectComponent* comp = obj ? Cast<UAzureObjectComponent>(obj->GetComponentByClass(UAzureObjectComponent::StaticClass())) : nullptr;
			if (comp == nullptr)
			{
				LuaStatic::traceback(L);
				lua_error(L);
				return 1;
			}

			///////////
			++n;
			if (!lua_istable(L, n) && !lua_isuserdata(L, n))
			{
				lua_pushfstring(L, "AddArcMoveBehavior: param #%d must be vector3(destPos)", n);
				lua_error(L);
				return 1;
			}
			FVector vDest = FLuaVector::Get(L, n);
			vDest = POS_FROM_SERVER(vDest);
			if (vDest.ContainsNaN())
			{
				lua_pushfstring(L, "AddArcMoveBehavior: param #%d contains NaN", n);
				lua_error(L);
				return 1;
			}
			///////////
			///////////
			++n;
			if (!lua_istable(L, n) && !lua_isuserdata(L, n))
			{
				lua_pushfstring(L, "AddArcMoveBehavior: param #%d must be vector3(vO)", n);
				lua_error(L);
				return 1;
			}
			FVector vO = FLuaVector::Get(L, n);
			vO = POS_FROM_SERVER(vO);
			if (vO.ContainsNaN())
			{
				lua_pushfstring(L, "AddArcMoveBehavior: param #%d contains NaN", n);
				lua_error(L);
				return 1;
			}
			///////////
			++n;
			if (lua_isnumber(L, n) == false)
			{
				lua_pushfstring(L, "AddArcMoveBehavior: param #%d must be float(speed)", n);
				lua_error(L);
				return 1;
			}
			float fSpeed = lua_tonumber(L, n);
			///////////
			++n;
			
			bool bHasCB = !lua_isnoneornil(L, nTop);
			if (bHasCB && !lua_isfunction(L, nTop))
			{
				lua_pushfstring(L, "AddArcMoveBehavior: param #%d must be function(callback)", nTop);
				lua_error(L);
				return 1;
			}
			OnBehaviorFinish callback = nullptr;
			if (bHasCB)
			{
				callback = SetBehaviorOnFinishCallback(L, nTop);
			}

			bool ret = comp->AddHPArcMoveBehavior(vDest, vO, fSpeed, callback);
			lua_pushboolean(L, ret);
			return 1;
		}

		static int AddMoveBehavior(lua_State * L)
		{
			int nTop = lua_gettop(L);
			///////////
			int n = 1;
			if (lua_isuserdata(L, n) == false)
			{
				lua_pushfstring(L, "AddMoveBehavior: param #%d must be Actor", n);
				lua_error(L);
				return 1;
			}

			AActor* obj = Cast<AActor>(wLua::FLuaUtils::GetUObject(L, 1, "Actor"));
			UAzureObjectComponent* comp = obj ? Cast<UAzureObjectComponent>(obj->GetComponentByClass(UAzureObjectComponent::StaticClass())) : nullptr;
			if (comp == nullptr)
			{
				LuaStatic::traceback(L);
				lua_error(L);
				return 1;
			}


			///////////
			++n;
			if (!lua_istable(L, n) && !lua_isuserdata(L, n))
			{
				lua_pushfstring(L, "AddMoveBehavior: param #%d must be vector3(destPos)", n);
				lua_error(L);
				return 1;
			}
			FVector vDest = FLuaVector::Get(L, n);
			if (vDest.ContainsNaN())
			{
				lua_pushfstring(L, "AddMoveBehavior: param #%d contains NaN", n);
				lua_error(L);
				return 1;
			}
			///////////
			++n;
			if (lua_isnumber(L, n) == false)
			{
				lua_pushfstring(L, "AddMoveBehavior: param #%d must be float(speed)", n);
				lua_error(L);
				return 1;
			}
			float fSpeed = lua_tonumber(L, n);

			if (!FMath::IsFinite(fSpeed))
			{
				lua_pushfstring(L, "AddMoveBehavior: param #%d is NaN", n);
				lua_error(L);
				return 1;
			}
			///////////
			++n;
			AGamePlayer* pCarrier = Cast<AGamePlayer>(wLua::FLuaUtils::GetUObject(L, n, "GamePlayer"));
			//根据是否在船上转换坐标
			if(pCarrier == nullptr)
				vDest = POS_FROM_SERVER(vDest);
			else
				vDest = RELATIVE_POS_FROM_SERVER(vDest);
			
			///////////
			++n;
			int updatePitch = 0;
			if(n < nTop)
			{
				if(lua_isnumber(L, n))
				{
					updatePitch = lua_tonumber(L, n);
				}
				else
				{
					lua_pushfstring(L, "AddMoveBehavior: param %d must be number", n);
					lua_error(L);
					return 1;
				}
			}

			///////////
			++n;
			bool bTraceGround = false;
			if (n < nTop)
			{
				if (lua_isboolean(L, n))
				{
					bTraceGround = lua_toboolean(L, n) != 0;
				}
				else
				{
					lua_pushfstring(L, "AddMoveBehavior: param %d must be boolean", n);
					lua_error(L);
					return 1;
				}
			}

			///////////保证最后一个是回调函数
			bool bHasCB = !lua_isnoneornil(L, nTop);
			if (bHasCB && !lua_isfunction(L, nTop))
			{
				lua_pushfstring(L, "AddMoveBehavior: param #%d must be function(callback)", nTop);
				lua_error(L);
				return 1;
			}
			OnBehaviorFinish callback = nullptr;
			if (bHasCB)
			{
				callback = SetBehaviorOnFinishCallback(L, nTop);
			}

			bool ret = comp->AddMoveBehavior(vDest, fSpeed, bTraceGround, pCarrier, updatePitch, callback);
			lua_pushboolean(L, ret);
			return 1;
		}

		static int AddMoveBehavior_Carrier(lua_State * L)
		{
			int nTop = lua_gettop(L);
			///////////
			int n = 1;
			if (lua_isuserdata(L, n) == false)
			{
				lua_pushfstring(L, "AddMoveBehavior_Carrier: param #%d must be Actor", n);
				lua_error(L);
				return 1;
			}

			AActor* obj = Cast<AActor>(wLua::FLuaUtils::GetUObject(L, 1, "Actor"));
			UAzureObjectComponent* comp = obj ? Cast<UAzureObjectComponent>(obj->GetComponentByClass(UAzureObjectComponent::StaticClass())) : nullptr;
			if (comp == nullptr)
			{
				LuaStatic::traceback(L);
				lua_error(L);
				return 1;
			}

			///////////
			++n;
			if (!lua_istable(L, n) && !lua_isuserdata(L, n))
			{
				lua_pushfstring(L, "AddMoveBehavior_Carrier: param #%d must be vector3(destPos)", n);
				lua_error(L);
				return 1;
			}
			FVector vDest = FLuaVector::Get(L, n);
			if (vDest.ContainsNaN())
			{
				lua_pushfstring(L, "AddMoveBehavior_Carrier: param #%d contains NaN", n);
				lua_error(L);
				return 1;
			}
			///////////
			++n;
			if (lua_isnumber(L, n) == false)
			{
				lua_pushfstring(L, "AddMoveBehavior_Carrier: param #%d must be float(speed)", n);
				lua_error(L);
				return 1;
			}
			float fSpeed = lua_tonumber(L, n);

			if (!FMath::IsFinite(fSpeed))
			{
				lua_pushfstring(L, "AddMoveBehavior_Carrier: param #%d is NaN", n);
				lua_error(L);
				return 1;
			}
			///////////
			++n;
			if (lua_isboolean(L, n) == false)
			{
				lua_pushfstring(L, "AddMoveBehavior_Carrier: param #%d must be boolean(bTraceGround)", n);
				lua_error(L);
				return 1;
			}
			bool bTraceGround = !!lua_toboolean(L, n);
			///////////
			++n;
			AGamePlayer* pCarrier = Cast<AGamePlayer>(wLua::FLuaUtils::GetUObject(L, n, "GamePlayer"));
			//根据是否在船上转换坐标
			if (pCarrier == nullptr)
				vDest = POS_FROM_SERVER(vDest);
			else
				vDest = RELATIVE_POS_FROM_SERVER(vDest);
			///////////
			n++;
			if (lua_isnumber(L, n) == false)
			{
				lua_pushfstring(L, "AddMoveBehavior_Carrier: param #%d must be int(updatePitch)", n);
				lua_error(L);
				return 1;
			}
			int updatePitch = lua_tointeger(L, n);
			///////////
			n++;
			if (lua_isboolean(L, n) == false)
			{
				lua_pushfstring(L, "AddMoveBehavior_Carrier: param #%d must be bool(needTurn)", n);
				lua_error(L);
				return 1;
			}
			bool needTurn = !!lua_toboolean(L, n);
			///////////
			n++;
			if (!lua_istable(L, n) && !lua_isuserdata(L, n))
			{
				lua_pushfstring(L, "AddMoveBehavior_Carrier: param #%d must be vector3(vDirDest)", n);
				lua_error(L);
				return 1;
			}
			FVector vDirDest = FLuaVector::Get(L, n);
			if (vDirDest.ContainsNaN())
			{
				lua_pushfstring(L, "AddMoveBehavior_Carrier: param #%d contains NaN", n);
				lua_error(L);
				return 1;
			}
			//根据是否在船上转换坐标
			if (pCarrier == nullptr)
				vDirDest = DIR_FROM_SERVER(vDirDest);
			else
				vDirDest = RELATIVE_DIR_FROM_SERVER(vDirDest);
			///////////
			n++;
			if (lua_isboolean(L, n) == false)
			{
				lua_pushfstring(L, "AddMoveBehavior_Carrier: param #%d must be bool(limitTime)", n);
				lua_error(L);
				return 1;
			}
			bool limit_time = !!lua_toboolean(L, n);
			///////////
			n++;
			if (lua_isnumber(L, n) == false)
			{
				lua_pushfstring(L, "AddMoveBehavior_Carrier: param #%d must be float(speed)", n);
				lua_error(L);
				return 1;
			}
			float turnParam = lua_tonumber(L, n);
			///////////
			n++;
			if (lua_isnumber(L, n) == false)
			{
				lua_pushfstring(L, "AddMoveBehavior_Carrier: param #%d must be int(turnFlag)", n);
				lua_error(L);
				return 1;
			}
			GP_TURN_FLAG turnflag = (GP_TURN_FLAG)lua_touint(L, n);
			///////////
			n++;
			if (lua_isnumber(L, n) == false)
			{
				lua_pushfstring(L, "AddMoveBehavior_Carrier: param #%d must be int(flag)", n);
				lua_error(L);
				return 1;
			}
			int flag = lua_tointeger(L, n);
			///////////
			n++;
			if (lua_isnumber(L, n) == false)
			{
				lua_pushfstring(L, "AddMoveBehavior_Carrier: param #%d must be int(flag2)", n);
				lua_error(L);
				return 1;
			}
			int flag2 = lua_tointeger(L, n);
			///////////
			n++;
			if (lua_isnumber(L, n) == false)
			{
				lua_pushfstring(L, "AddMoveBehavior_Carrier: param #%d must be uint(extend_data2)", n);
				lua_error(L);
				return 1;
			}
			uint32 extend_data2 = (uint32)lua_touint(L, n);

			///////////保证最后一个是回调函数
			bool bHasCB = !lua_isnoneornil(L, nTop);
			if (bHasCB && !lua_isfunction(L, nTop))
			{
				lua_pushfstring(L, "AddMoveBehavior_Carrier: param #%d must be function(callback)", nTop);
				lua_error(L);
				return 1;
			}
			OnBehaviorFinish callback = nullptr;
			if (bHasCB)
			{
				callback = SetBehaviorOnFinishCallback(L, nTop);
			}

			bool ret = comp->AddMoveBehavior_Carrier(vDest, fSpeed, 
				bTraceGround, pCarrier, updatePitch,
				needTurn, vDirDest, limit_time, turnParam, turnflag, 
				flag, flag2, extend_data2, callback);
			lua_pushboolean(L, ret);
			return 1;
		}

		static int SetMoveBehaviorTraceGround(lua_State * L)
		{
			AActor* obj = Cast<AActor>(wLua::FLuaUtils::GetUObject(L, 1, "Actor"));
			UAzureObjectComponent* comp = obj ? Cast<UAzureObjectComponent>(obj->GetComponentByClass(UAzureObjectComponent::StaticClass())) : nullptr;
			if (comp == nullptr)
			{
				LuaStatic::traceback(L);
				lua_error(L);
				return 1;
			}

			bool bTraceGround = lua_toboolean(L, 2);
			AzureMoveBehavior* moveBehavior = (AzureMoveBehavior*)comp->GetBehavior(Azure::BehaviorType::Move);
			if (moveBehavior)
			{
				moveBehavior->SetTraceGround(bTraceGround);
			}
			return 0;
		}

		static int AddHPBePushBehavior(lua_State * L)
		{
			int nTop = lua_gettop(L);
			///////////
			int n = 1;
			if (lua_isuserdata(L, n) == false)
			{
				lua_pushfstring(L, "AddHPBePushBehavior: param #%d must be Actor", n);
				lua_error(L);
				return 1;
			}

			AActor* obj = Cast<AActor>(wLua::FLuaUtils::GetUObject(L, 1, "Actor"));
			UAzureObjectComponent* comp = obj ? Cast<UAzureObjectComponent>(obj->GetComponentByClass(UAzureObjectComponent::StaticClass())) : nullptr;
			if (comp == nullptr)
			{
				LuaStatic::traceback(L);
				lua_error(L);
				return 1;
			}


			///////////
			++n;
			if (!lua_istable(L, n) && !lua_isuserdata(L, n))
			{
				lua_pushfstring(L, "AddHPBePushBehavior: param #%d must be vector3(destPos)", n);
				lua_error(L);
				return 1;
			}
			FVector vDest = FLuaVector::Get(L, n);

			///////////
			++n;
			if (lua_isnumber(L, n) == false)
			{
				lua_pushfstring(L, "AddHPBePushBehavior: param #%d must be float(speed)", n);
				lua_error(L);
				return 1;
			}
			float fSpeed = lua_tonumber(L, n);

			///////////
			++n;
			AGamePlayer* pCarrier = Cast<AGamePlayer>(wLua::FLuaUtils::GetUObject(L, n, "GamePlayer"));
			//根据是否在船上转换坐标
			if (pCarrier == nullptr)
				vDest = POS_FROM_SERVER(vDest);
			else
				vDest = RELATIVE_POS_FROM_SERVER(vDest);

			///////////保证最后一个是回调函数
			++n;
			bool bHasCB = !lua_isnoneornil(L, n);
			if (bHasCB && !lua_isfunction(L, n))
			{
				lua_pushfstring(L, "AddHPBePushBehavior: param #%d must be function(callback)", nTop);
				lua_error(L);
				return 1;
			}
			OnBehaviorFinish callback = nullptr;
			if (bHasCB)
			{
				callback = SetBehaviorOnFinishCallback(L, n);
			}

			bool ret = comp->AddHPBePushBehavior(vDest, fSpeed, pCarrier, callback);
			lua_pushboolean(L, ret);
			return 1;
		}

		static int AddDecelMoveBehavior(lua_State * L)
		{
			///////////
			int n = 1;
			if (lua_isuserdata(L, n) == false)
			{
				lua_pushstring(L, "AddDecelMoveBehavior: param 1 must be Actor");
				lua_error(L);
				return 1;
			}

			AActor* obj = Cast<AActor>(wLua::FLuaUtils::GetUObject(L, 1, "Actor"));
			UAzureObjectComponent* comp = obj ? Cast<UAzureObjectComponent>(obj->GetComponentByClass(UAzureObjectComponent::StaticClass())) : nullptr;
			if (comp == nullptr)
			{
				LuaStatic::traceback(L);
				lua_error(L);
				return 1;
			}

			///////////
			++n;
			if (!lua_istable(L, n) && !lua_isuserdata(L, n))
			{
				lua_pushstring(L, "AddDecelMoveBehavior: param 2 must be vector3(destPos)");
				lua_error(L);
				return 1;
			}
			FVector vDest = FLuaVector::Get(L, n);

			///////////
			++n;
			if (lua_isnumber(L, n) == false)
			{
				lua_pushstring(L, "AddDecelMoveBehavior: param 3 must be float(duration)");
				lua_error(L);
				return 1;
			}
			float duration = lua_tonumber(L, n);

			///////////
			++n;
			AGamePlayer* pCarrier = Cast<AGamePlayer>(wLua::FLuaUtils::GetUObject(L, n, "GamePlayer"));
			//根据是否在船上转换坐标
			if (pCarrier == nullptr)
				vDest = POS_FROM_SERVER(vDest);
			else
				vDest = RELATIVE_POS_FROM_SERVER(vDest);

			///////////

			++n;
			bool bHasCB = !lua_isnoneornil(L, n);
			if (bHasCB && !lua_isfunction(L, n))
			{
				lua_pushstring(L, "AddDecelMoveBehavior: param 5 must be function(callback)");
				lua_error(L);
				return 1;
			}
			OnBehaviorFinish callback = nullptr;
			if (bHasCB)
			{
				callback = SetBehaviorOnFinishCallback(L, n);
			}

			bool ret = comp->AddDecelMoveBehavior(vDest, duration, pCarrier, callback);
			lua_pushboolean(L, ret);
			return 1;
		}

		static int AddRootMotionBehavior(lua_State * L)
		{
			///////////
			int n = 1;
			if (lua_isuserdata(L, n) == false)
			{
				lua_pushstring(L, "AddRootMotionBehavior: param 1 must be GamePlayer");
				lua_error(L);
				return 1;
			}

			AGamePlayer* obj = Cast<AGamePlayer>(wLua::FLuaUtils::GetUObject(L, n, "GamePlayer"));
			UAzureObjectComponent* comp = obj ? Cast<UAzureObjectComponent>(obj->GetComponentByClass(UAzureObjectComponent::StaticClass())) : nullptr;
			if (comp == nullptr)
			{
				LuaStatic::traceback(L);
				lua_error(L);
				return 1;
			}

			///////////
			++n;
			if (!lua_istable(L, n) && !lua_isuserdata(L, n))
			{
				lua_pushstring(L, "AddRootMotionBehavior: param 2 must be vector3(destPos)");
				lua_error(L);
				return 1;
			}
			FVector vDest = FLuaVector::Get(L, n);

			///////////
			++n;
			if (lua_isnumber(L, n) == false)
			{
				lua_pushstring(L, "AddRootMotionBehavior: param 3 must be float(timeScale)");
				lua_error(L);
				return 1;
			}
			float fTimeScale = lua_tonumber(L, n);

			//////////////////////////////
			++n;
			UAnimMontage* mon = Cast<UAnimMontage>(wLua::FLuaUtils::GetUObject(L, n, "AnimMontage"));
			if (!mon)
			{
				lua_pushstring(L, "AddRootMotionBehavior: param 4 must be AnimMontage");
				lua_error(L);
				return 1;
			}

			///////////
			++n;
			AGamePlayer* pCarrier = Cast<AGamePlayer>(wLua::FLuaUtils::GetUObject(L, n, "GamePlayer"));
			//根据是否在船上转换坐标
			if (pCarrier == nullptr)
				vDest = POS_FROM_SERVER(vDest);
			else
				vDest = RELATIVE_POS_FROM_SERVER(vDest);

			///////////

			++n;
			bool bHasCB = !lua_isnoneornil(L, n);
			if (bHasCB && !lua_isfunction(L, n))
			{
				lua_pushstring(L, "AddRootMotionBehavior: param 6 must be function(callback)");
				lua_error(L);
				return 1;
			}
			OnBehaviorFinish callback = nullptr;
			if (bHasCB)
			{
				callback = SetBehaviorOnFinishCallback(L, n);
			}

			bool ret = comp->AddRootMotionBehavior(vDest, fTimeScale, mon, pCarrier, callback);
			lua_pushboolean(L, ret);
			return 1;
		}

		static int AddObjHurtFlyBehavior(lua_State * L)
		{
			///////////
			int n = 1;
			if (lua_isuserdata(L, n) == false)
			{
				lua_pushstring(L, "AddObjHurtFlyBehavior: param 1 must be Actor");
				lua_error(L);
				return 1;
			}

			AActor* obj = Cast<AActor>(wLua::FLuaUtils::GetUObject(L, 1, "Actor"));
			UAzureObjectComponent* comp = obj ? Cast<UAzureObjectComponent>(obj->GetComponentByClass(UAzureObjectComponent::StaticClass())) : nullptr;
			if (comp == nullptr)
			{
				LuaStatic::traceback(L);
				lua_error(L);
				return 1;
			}


			///////////
			++n;
			if (!lua_istable(L, n) && !lua_isuserdata(L, n))
			{
				lua_pushstring(L, "AddObjHurtFlyBehavior: param 2 must be vector3(destPos)");
				lua_error(L);
				return 1;
			}
			FVector vDest = FLuaVector::Get(L, n);			

			///////////
			++n;
			if (lua_isnumber(L, n) == false)
			{
				lua_pushstring(L, "AddObjHurtFlyBehavior: param 3 must be float(time)");
				lua_error(L);
				return 1;
			}
			float duration = lua_tonumber(L, n);
			
			///////////
			++n;
			if (lua_isnumber(L, n) == false)
			{
				lua_pushstring(L, "AddObjHurtFlyBehavior: param 4 must be float(h)");
				lua_error(L);
				return 1;
			}
			float h = lua_tonumber(L, n);

			///////////
			++n;
			if (lua_isnumber(L, n) == false)
			{
				lua_pushstring(L, "AddObjHurtFlyBehavior: param 5 must be float(x1)");
				lua_error(L);
				return 1;
			}
			float x1 = lua_tonumber(L, n);

			///////////
			++n;
			if (lua_isnumber(L, n) == false)
			{
				lua_pushstring(L, "AddObjHurtFlyBehavior: param 6 must be float(t1)");
				lua_error(L);
				return 1;
			}
			float t1 = lua_tonumber(L, n);

			///////////
			++n;
			if (lua_isnumber(L, n) == false)
			{
				lua_pushstring(L, "AddObjHurtFlyBehavior: param 7 must be float(x2)");
				lua_error(L);
				return 1;
			}
			float x2 = lua_tonumber(L, n);

			///////////
			++n;
			if (lua_isnumber(L, n) == false)
			{
				lua_pushstring(L, "AddObjHurtFlyBehavior: param 8 must be float(t2)");
				lua_error(L);
				return 1;
			}
			float t2 = lua_tonumber(L, n);

			/////
			++n;
			AGamePlayer* pCarrier = Cast<AGamePlayer>(wLua::FLuaUtils::GetUObject(L, n, "GamePlayer"));
			
			///////////
			++n;
			bool bHasCB = !lua_isnoneornil(L, n);
			if (bHasCB && !lua_isfunction(L, n))
			{
				lua_pushstring(L, "AddObjHurtFlyBehavior: param 9 must be function(callback)");
				lua_error(L);
				return 1;
			}

			///////////
			OnBehaviorFinish callback = nullptr;
			if (bHasCB)
			{
				callback = SetBehaviorOnFinishCallback(L, n);
			}

			bool ret = comp->AddObjHurtFlyBehavior(vDest, duration, h, x1, t1, x2, t2, pCarrier,callback);
			lua_pushboolean(L, ret);
			return 1;
		}

		static int AddServerMoveBehavior(lua_State * L)
		{
			///////////
			int n = 1;
			if (lua_isuserdata(L, n) == false)
			{
				lua_pushstring(L, "AddServerMoveBehavior: param 1 must be GamePlayer");
				lua_error(L);
				return 1;
			}

			AActor* obj = Cast<AActor>(wLua::FLuaUtils::GetUObject(L, 1, "Actor"));
			UAzureObjectComponent* comp = obj ? Cast<UAzureObjectComponent>(obj->GetComponentByClass(UAzureObjectComponent::StaticClass())) : nullptr;
			if (comp == nullptr)
			{
				LuaStatic::traceback(L);
				lua_error(L);
				return 1;
			}


			///////////
			++n;
			if (!lua_istable(L, n) && !lua_isuserdata(L, n))
			{
				lua_pushstring(L, "AddServerMoveBehavior: param 2 must be vector3(destPos)");
				lua_error(L);
				return 1;
			}
			FVector vDest = FLuaVector::Get(L, n);
			vDest = POS_FROM_SERVER(vDest);

			///////////
			++n;
			if (!lua_istable(L, n) && !lua_isuserdata(L, n))
			{
				lua_pushstring(L, "AddServerMoveBehavior: param 3 must be vector3(faceDir)");
				lua_error(L);
				return 1;
			}
			FRotator rotator = FLuaRotator::Get(L, n);

			////////////////////////////////
			++n;
			if (lua_isnumber(L, n) == false)
			{
				lua_pushstring(L, "AddServerMoveBehavior: param 4 must be float(use_time)");
				lua_error(L);
				return 1;
			}
			float use_time = lua_tonumber(L, n);

			///////////
			++n;
			if (!lua_istable(L, n) && !lua_isuserdata(L, n))
			{
				lua_pushstring(L, "AddServerMoveBehavior: param 5 must be vector3(moveDir)");
				lua_error(L);
				return 1;
			}
			FVector vVelocity = FLuaVector::Get(L, n);
			vVelocity = POS_FROM_SERVER(vVelocity);

			/////////////////
			++n;
			if (lua_isnumber(L, n) == false)
			{
				lua_pushstring(L, "AddServerMoveBehavior: param 6 must be int");
				lua_error(L);
				return 1;
			}
			int32 flag = lua_tointeger(L, n);

			/////////////////
			++n;
			if (lua_isnumber(L, n) == false)
			{
				lua_pushstring(L, "AddServerMoveBehavior: param 7 must be int");
				lua_error(L);
				return 1;
			}
			int32 flag2 = lua_tointeger(L, n);

			/////////////////
			++n;
			if (lua_isnumber(L, n) == false)
			{
				lua_pushstring(L, "AddServerMoveBehavior: param 8 must be int");
				lua_error(L);
				return 1;
			}
			uint32 extend_data2 = lua_tonumber(L, n);

			/////////////////
			++n;
			if (lua_isnumber(L, n) == false)
			{
				lua_pushstring(L, "AddServerMoveBehavior: param 9 must be int");
				lua_error(L);
				return 1;
			}
			int32 timeStamp = lua_tointeger(L, n);

			/////////////////
			++n;
			if (lua_isnumber(L, n) == false)
			{
				lua_pushstring(L, "AddServerMoveBehavior: param 10 must be int");
				lua_error(L);
				return 1;
			}
			int32 serverMoveType = lua_tointeger(L, n);

			///////////
			++n;
			bool bHasCB = !lua_isnoneornil(L, n);
			if (bHasCB && !lua_isfunction(L, n))
			{
				lua_pushstring(L, "AddServerMoveBehavior: param 11 must be function(callback)");
				lua_error(L);
				return 1;
			}
			OnBehaviorFinish callback = nullptr;
			if (bHasCB)
			{
				callback = SetBehaviorOnFinishCallback(L, n);
			}

			//LuaStatic::traceback(L, "111 AddServerMove: ");
			//LUALOG_WARNING(lua_tostring(L, -1));

			////////////////////
			bool ret = comp->AddServerMoveBehavior(vDest, rotator, use_time, vVelocity, flag, flag2, extend_data2, timeStamp, serverMoveType,callback);
			lua_pushboolean(L, ret);
			return 1;
		}

		static int AddServerSkillMoveBehavior(lua_State * L)
		{
			///////////
			int n = 1;
			if (lua_isuserdata(L, n) == false)
			{
				lua_pushstring(L, "AddServerSkillMoveBehavior: param 1 must be GamePlayer");
				lua_error(L);
				return 1;
			}

			AActor* obj = Cast<AActor>(wLua::FLuaUtils::GetUObject(L, 1, "Actor"));
			UAzureObjectComponent* comp = obj ? Cast<UAzureObjectComponent>(obj->GetComponentByClass(UAzureObjectComponent::StaticClass())) : nullptr;
			if (comp == nullptr)
			{
				LuaStatic::traceback(L);
				lua_error(L);
				return 1;
			}


			///////////
			++n;
			if (!lua_istable(L, n) && !lua_isuserdata(L, n))
			{
				lua_pushstring(L, "AddServerSkillMoveBehavior: param 2 must be vector3(startPos)");
				lua_error(L);
				return 1;
			}
			FVector vStart = FLuaVector::Get(L, n);

			////////////////
			++n;
			if (lua_isnumber(L, n) == false)
			{
				lua_pushstring(L, "AddServerSkillMoveBehavior: param 3 must be float(face rotation yaw)");
				lua_error(L);
				return 1;
			}
			float yaw = lua_tonumber(L, n);

			///////////
			++n;
			if (!lua_istable(L, n) && !lua_isuserdata(L, n))
			{
				lua_pushstring(L, "AddServerSkillMoveBehavior: param 4 must be vector3(destPos)");
				lua_error(L);
				return 1;
			}
			FVector vDest = FLuaVector::Get(L, n);

			/////////////////
			++n;
			if (lua_isnumber(L, n) == false)
			{
				lua_pushstring(L, "AddServerSkillMoveBehavior: param 5 must be int(speed)");
				lua_error(L);
				return 1;
			}
			float speed = lua_tonumber(L, n);

		
			///////////
			++n;
			bool bHasCB = !lua_isnoneornil(L, n);
			if (bHasCB && !lua_isfunction(L, n))
			{
				lua_pushstring(L, "AddServerSkillMoveBehavior: param 6 must be function(callback)");
				lua_error(L);
				return 1;
			}
			OnBehaviorFinish callback = nullptr;
			if (bHasCB)
			{
				callback = SetBehaviorOnFinishCallback(L, n);
			}

			////////////////////
			bool ret = comp->AddServerSkillMoveBehavior(vStart,yaw,vDest,speed, callback);
			lua_pushboolean(L, ret);
			return 1;
		}

		static int AddServerRootMotionMoveBehavior(lua_State * L)
		{
			///////////
			int n = 1;
			if (lua_isuserdata(L, n) == false)
			{
				lua_pushstring(L, "AddServerRootMotionMoveBehavior: param 1 must be GamePlayer");
				lua_error(L);
				return 1;
			}

			AActor* obj = Cast<AActor>(wLua::FLuaUtils::GetUObject(L, n, "Actor"));
			UAzureObjectComponent* comp = obj ? Cast<UAzureObjectComponent>(obj->GetComponentByClass(UAzureObjectComponent::StaticClass())) : nullptr;
			if (comp == nullptr)
			{
				LuaStatic::traceback(L);
				lua_error(L);
				return 1;
			}

			///////////
			++n;
			if (lua_isuserdata(L, n) == false)
			{
				lua_pushstring(L, "AddServerRootMotionMoveBehavior: param 2 must be UAnimMontage(montage)");
				lua_error(L);
				return 1;
			}
			UAnimMontage* montage = Cast<UAnimMontage>(wLua::FLuaUtils::GetUObject(L, n, "AnimMontage"));

			///////////
			++n;
			if (!lua_isboolean(L, n))
			{
				lua_pushstring(L, "AddServerRootMotionMoveBehavior: param 3 must be boolean(bRelativePosition");
				lua_error(L);
				return 1;
			}
			bool bRelativePosition = lua_toboolean(L, n);

			///////////
			++n;
			if (!lua_isboolean(L, n))
			{
				lua_pushstring(L, "AddServerRootMotionMoveBehavior: param 3 must be boolean(bRelativePosition");
				lua_error(L);
				return 1;
			}
			bool bRelativeRotation = lua_toboolean(L, n);

			///////////
			++n;
			if (!lua_istable(L, n) && !lua_isuserdata(L, n))
			{
				lua_pushstring(L, "AddServerMoveBehavior: param 4 must be vector3(location)");
				lua_error(L);
				return 1;
			}
			FVector vLocation = FLuaVector::Get(L, n);
			vLocation = POS_FROM_SERVER(vLocation);

			///////////
			++n;
			if (!lua_istable(L, n) && !lua_isuserdata(L, n))
			{
				lua_pushstring(L, "AddServerMoveBehavior: param 5 must be rotator(rotation)");
				lua_error(L);
				return 1;
			}
			FRotator rotation = FLuaRotator::Get(L, n);

			/////////////////
			++n;
			if (lua_isnumber(L, n) == false)
			{
				lua_pushstring(L, "AddServerMoveBehavior: param 6 must be float(montagePosition)");
				lua_error(L);
				return 1;
			}
			float montagePosition = lua_tonumber(L, n);

			/////////////////
			++n;
			if (lua_isnumber(L, n) == false)
			{
				lua_pushstring(L, "AddServerMoveBehavior: param 6 must be float(smoothLocationTime)");
				lua_error(L);
				return 1;
			}
			float smoothLocationTime = lua_tonumber(L, n);

			////////////////////
			bool ret = comp->AddServerRootMotionMoveBehavior(montage, bRelativePosition, bRelativeRotation, vLocation, rotation, montagePosition, smoothLocationTime);
			lua_pushboolean(L, ret);
			return 1;
		}

		static void g_GetPointList(Azure::VecPoint& ptList, lua_State* L, int curIdx)
		{
			luaL_checktype(L, curIdx, LUA_TTABLE);
			int len = lua_objlen(L, curIdx);

			ptList.Reserve(len);

			for (int i = 0; i < len; ++i)
			{
				lua_rawgeti(L, curIdx, i + 1);
				FVector pt;
				if(wLua::FLuaVector::GetVectorFromLua(L, -1,pt,false))
					ptList.Add(pt);
				lua_pop(L, 1);
			}
		}

		static void g_GetFloatList(Azure::ArrayFloat & ptList, lua_State* L, int curIdx)
		{
			luaL_checktype(L, curIdx, LUA_TTABLE);
			int len = lua_objlen(L, curIdx);

			ptList.Reserve(len);

			for (int i = 0; i < len; ++i)
			{
				lua_rawgeti(L, curIdx, i + 1);
				float pt = luaL_checknumber(L, -1);
				ptList.Add(pt);
				lua_pop(L, 1);
			}
		}

		static int AddBezierMoveBehavior(lua_State * L)
		{
			///////////
			int n = 1;
			if (lua_isuserdata(L, n) == false)
			{
				lua_pushstring(L, "AddBezierMoveBehavior: param 1 must be Actor");
				lua_error(L);
				return 1;
			}
			AActor* obj = Cast<AActor>(wLua::FLuaUtils::GetUObject(L, 1, "Actor"));
			UAzureObjectComponent* comp = obj ? Cast<UAzureObjectComponent>(obj->GetComponentByClass(UAzureObjectComponent::StaticClass())) : nullptr;
			if (comp == nullptr)
			{
				LuaStatic::traceback(L);
				lua_error(L);
				return 1;
			}

			///////////
			++n;
			if (lua_istable(L, n) == false)
			{
				lua_pushstring(L, "AddBezierMoveBehavior: param must be table(vecPoints)");
				lua_error(L);
				return 1;
			}
			Azure::VecPoint points;
			g_GetPointList(points, L, n);

			///////////
			++n;
			if (lua_isnumber(L, n) == false)
			{
				lua_pushstring(L, "AddBezierMoveBehavior: param must be float(speed)");
				lua_error(L);
				return 1;
			}
			float fSpeed = lua_tonumber(L, n) * UE_METRE_TRANS;

			///////////
			++n;
			if (lua_isboolean(L, n) == false)
			{
				lua_pushstring(L, "AddBezierMoveBehavior: param must be bool(bAllowChangeSpeed)");
				lua_error(L);
				return 1;
			}
			bool bAllowChangeSpeed = !!lua_toboolean(L, n);

			///////////
			++n;
			if (lua_isboolean(L, n) == false)
			{
				lua_pushstring(L, "AddBezierMoveBehavior: param must be bool(bFlyMove)");
				lua_error(L);
				return 1;
			}
			bool bFlyMove = !!lua_toboolean(L, n);

			///////////
			++n;
			if (lua_isboolean(L, n) == false)
			{
				lua_pushstring(L, "AddBezierMoveBehavior: param must be bool(bForceTraceToGround)");
				lua_error(L);
				return 1;
			}
			bool bForceTraceToGround = !!lua_toboolean(L, n);

			///////////
			++n;
			if (lua_isboolean(L, n) == false)
			{
				lua_pushstring(L, "AddBezierMoveBehavior: param must be bool(bReachPause)");
				lua_error(L);
				return 1;
			}
			bool bReachPause = !!lua_toboolean(L, n);

			///////////
			++n;
			if (lua_isuserdata(L, n) == false)
			{
				lua_pushstring(L, "AddBezierMoveBehavior: param must be Actor(pFlowActor)");
				lua_error(L);
				return 1;
			}
			AActor* pFlwActor = Cast<AActor>(wLua::FLuaUtils::GetUObject(L, n, "Actor"));

			///////////
			++n;
			if (lua_isnumber(L, n) == false)
			{
				lua_pushstring(L, "AddBezierMoveBehavior: param must be bool(nFlwAdvancePtCount)");
				lua_error(L);
				return 1;
			}
			int nFlwAdvancePtCount = (int)lua_tonumber(L, n);

			OnBehaviorFinish callback = nullptr;

			float fMaxSpeed_Factor = 2.5;
			///////////
			++n;
			if (!lua_isnoneornil(L, n))
			{
				if (!lua_isnumber(L, n))
				{
					lua_pushstring(L, "AddBezierMoveBehavior: param must be float(fMaxSpeed_Factor)");
					lua_error(L);
					return 1;
				}
				fMaxSpeed_Factor = (float)lua_tonumber(L, n);
			}

			float fStiffness = -1, fDamping = -1;
			///////////
			++n;
			if (!lua_isnoneornil(L, n))
			{
				if (!lua_isnumber(L, n))
				{
					lua_pushstring(L, "AddBezierMoveBehavior: param must be float(fStiffness)");
					lua_error(L);
					return 1;
				}
				fStiffness = (float)lua_tonumber(L, n);
			}

			///////////
			++n;
			if (!lua_isnoneornil(L, n))
			{
				if (!lua_isnumber(L, n))
				{
					lua_pushstring(L, "AddBezierMoveBehavior: param must be float(fDamping)");
					lua_error(L);
					return 1;
				}
				fDamping = (float)lua_tonumber(L, n);
			}

			///////////
			int nStartAdvancePtCount = 0;
			++n;
			if (!lua_isnoneornil(L, n))
			{
				if (!lua_isnumber(L, n))
				{
					lua_pushstring(L, "AddBezierMoveBehavior: param must be number(nStartAdvancePtCount)");
					lua_error(L);
					return 1;
				}
				nStartAdvancePtCount = (int)lua_tonumber(L, n);
			}

			///////////
			++n;
			bool bHasCB = !lua_isnoneornil(L, n);
			if (bHasCB && !lua_isfunction(L, n))
			{
				lua_pushstring(L, "AddBezierMoveBehavior: param must be function(callback)");
				lua_error(L);
				return 1;
			}
			if (bHasCB)
			{
				callback = SetBehaviorOnFinishCallback(L, n);
			}

			bool ret = comp->AddBezierMoveBehavior(points, fSpeed, bAllowChangeSpeed,
				bFlyMove, bForceTraceToGround, bReachPause,
				pFlwActor, nFlwAdvancePtCount, nStartAdvancePtCount, callback,
				fMaxSpeed_Factor, fStiffness, fDamping);
			lua_pushboolean(L, ret);
			return 1;
		}

		static int AddHPBezierMoveBehavior(lua_State * L)
		{
			///////////
			int n = 1;
			if (lua_isuserdata(L, n) == false)
			{
				lua_pushstring(L, "AddHPBezierMoveBehavior: param 1 must be Actor");
				lua_error(L);
				return 1;
			}
			AActor* obj = Cast<AActor>(wLua::FLuaUtils::GetUObject(L, 1, "Actor"));
			UAzureObjectComponent* comp = obj ? Cast<UAzureObjectComponent>(obj->GetComponentByClass(UAzureObjectComponent::StaticClass())) : nullptr;
			if (comp == nullptr)
			{
				LuaStatic::traceback(L);
				lua_error(L);
				return 1;
			}

			///////////
			++n;
			if (lua_istable(L, n) == false)
			{
				lua_pushstring(L, "AddHPBezierMoveBehavior: param must be table(vecPoints)");
				lua_error(L);
				return 1;
			}
			Azure::VecPoint points;
			g_GetPointList(points, L, n);

			///////////
			++n;
			if (lua_istable(L, n) == false)
			{
				lua_pushstring(L, "AddHPBezierMoveBehavior: param must be table(dirs 1)");
				lua_error(L);
				return 1;
			}
			Azure::VecPoint arrive_dirs;
			g_GetPointList(arrive_dirs, L, n);

			///////////
			++n;
			if (lua_istable(L, n) == false)
			{
				lua_pushstring(L, "AddHPBezierMoveBehavior: param must be table(dirs 2)");
				lua_error(L);
				return 1;
			}
			Azure::VecPoint leave_dirs;
			g_GetPointList(leave_dirs, L, n);

			///////////
			++n;
			if (lua_istable(L, n) == false)
			{
				lua_pushstring(L, "AddHPBezierMoveBehavior: param must be table(events)");
				lua_error(L);
				return 1;
			}
			Azure::ArrayFloat events;
			g_GetFloatList(events, L, n);

			///////////
			++n;
			if (lua_isnumber(L, n) == false)
			{
				lua_pushstring(L, "AddHPBezierMoveBehavior: param must be float(steps)");
				lua_error(L);
				return 1;
			}
			int fSteps = lua_tointeger(L, n);

			///////////
			++n;
			if (lua_isnumber(L, n) == false)
			{
				lua_pushstring(L, "AddHPBezierMoveBehavior: param must be float(speed)");
				lua_error(L);
				return 1;
			}
			float fSpeed = lua_tonumber(L, n) * UE_METRE_TRANS;		

			///////////
			++n;
			if (lua_isnumber(L, n) == false)
			{
				lua_pushstring(L, "AddHPBezierMoveBehavior: param must be int(move_type)");
				lua_error(L);
				return 1;
			}
			int move_type = lua_tointeger(L, n);

			///////////
			++n;
			if (!lua_isboolean(L, n))
			{
				lua_pushstring(L, "AddHPBezierMoveBehavior: param must be boolean(bGround)");
				LuaStatic::traceback(L);
				lua_error(L);
				return 1;
			}
			bool bGround = !!lua_toboolean(L, n);

			///////////
			++n;
			if (!lua_isboolean(L, n))
			{
				lua_pushstring(L, "AddHPBezierMoveBehavior: param must be boolean(bLoop)");
				LuaStatic::traceback(L);
				lua_error(L);
				return 1;
			}
			bool bLoop = !!lua_toboolean(L, n);
			

			////////////////////////////////////////////////
			++n;
			AGamePlayer* pCarrier = Cast<AGamePlayer>(wLua::FLuaUtils::GetUObject(L, n, "GamePlayer"));

			////////////////////
			OnBehaviorFinish callback = nullptr;		
	
			++n;
			bool bHasCB = !lua_isnoneornil(L, n);
			if (bHasCB && !lua_isfunction(L, n))
			{
				lua_pushstring(L, "AddHPBezierMoveBehavior: param must be function(callback)");
				lua_error(L);
				return 1;
			}
			if (bHasCB)
			{
				callback = SetBehaviorOnFinishCallback(L, n);
			}

			bool ret = comp->AddHPBezierMoveBehavior(points, arrive_dirs, leave_dirs, events, fSteps, fSpeed,move_type,bGround,bLoop, pCarrier, callback);

			lua_pushboolean(L, ret);
			return 1;
		}

		static int AddHPMoveBehavior(lua_State * L)
		{
			int n = 1;

			AActor* obj = Cast<AActor>(wLua::FLuaUtils::GetUObject(L, 1, "Actor"));
			if (!obj)
			{
				LuaStatic::traceback(L, "AddHPMoveBehavior: Obj is null!");
				lua_error(L);
				return 1;
			}
			UAzureObjectComponent* comp = Cast<UAzureObjectComponent>(obj->GetComponentByClass(UAzureObjectComponent::StaticClass()));
			if (comp == nullptr)
			{
				FString log = obj->GetName() + TEXT("has no AzureObjectComponent");
				LuaStatic::traceback(L, TCHAR_TO_UTF8(*log));
				lua_error(L);
				return 1;
			}
			++n;

			///////////
			if (!lua_isboolean(L, n))
			{
				lua_pushstring(L, "AddHPMoveBehavior: param must be boolean(bReUse)");
				LuaStatic::traceback(L);
				lua_error(L);
				return 1;
			}
			bool bReUse = !!lua_toboolean(L, n);
			++n;

			///////////
			if (!lua_istable(L, n) && !lua_isuserdata(L, n))
			{
				lua_pushstring(L, "AddHPMoveBehavior: param must be vector3(destPos)");
				lua_error(L);
				return 1;
			}
			FVector vDest = FLuaVector::Get(L, n);
			vDest = POS_FROM_SERVER(vDest);
			++n;

			///////////
			float fTime = (float)luaL_checknumber(L, n);
			++n;

			///////////
			if (!lua_isnumber(L, n))
			{
				lua_pushstring(L, "AddHPMoveBehavior: param must be number(flag)");
				lua_error(L);
				return 1;
			}
			uint32 flag = lua_tonumber(L, n);
			++n;

			///////////
			OnBehaviorFinish onFinish = nullptr;
			if (!lua_isnoneornil(L, n))
			{
				if (!lua_isfunction(L, n))
				{
					lua_pushstring(L, "AddHPMoveBehavior: param must be function(callback)");
					lua_error(L);
					return 1;
				}
				onFinish = SetBehaviorOnFinishCallback(L, n);
			}
			++n;

			bool ret = comp->AddHPMoveBehavior(bReUse, vDest, fTime, (HPMoveBehaviorFlag)flag, onFinish);
			lua_pushboolean(L, ret);
			return 1;
		}

		//废弃，使用AddHPMoveBehavior
		//static int AddHPAutoMoveBehavior(lua_State * L)
		//{
		//
		//}

		static int ChangeHPMoveBehParam(lua_State* L)
		{
			int n = 1;

			///////////
			AActor* obj = Cast<AActor>(wLua::FLuaUtils::GetUObject(L, 1, "Actor"));
			if (!obj)
			{
				LuaStatic::traceback(L, "ChangeHPMoveBehParam: Obj is null!");
				lua_error(L);
				return 1;
			}
			UAzureObjectComponent* comp = Cast<UAzureObjectComponent>(obj->GetComponentByClass(UAzureObjectComponent::StaticClass()));
			if (comp == nullptr)
			{
				FString log = obj->GetName() + TEXT("has no AzureObjectComponent");
				LuaStatic::traceback(L, TCHAR_TO_UTF8(*log));
				lua_error(L);
				return 1;
			}
			++n;

			///////////
			if (!lua_istable(L, n) && !lua_isuserdata(L, n))
			{
				lua_pushstring(L, "ChangeHPMoveBehParam: param must be vector3(destPos)");
				lua_error(L);
				return 1;
			}
			FVector vDest = FLuaVector::Get(L, n);
			vDest = POS_FROM_SERVER(vDest);
			++n;

			///////////
			float fMoveSpeed = luaL_checknumber(L, n) * UE_METRE_TRANS;
			++n;

			///////////
			if (!lua_isboolean(L, n))
			{
				lua_pushstring(L, "ChangeHPMoveBehParam: param must be bool(bSkillMove)");
				lua_error(L);
				return 1;
			}
			bool bIsSkillMove = !!lua_toboolean(L, n);
			++n;
			
			bool ret = comp->ChangeHPMoveBehParam(vDest, fMoveSpeed, bIsSkillMove);
			lua_pushboolean(L, ret);
			return 1;
		}

		static int AddObjMoveBehavior(lua_State * L)
		{
			int n = 1;

			AActor* obj = Cast<AActor>(wLua::FLuaUtils::GetUObject(L, 1, "Actor"));
			if (!obj)
			{
				LuaStatic::traceback(L, "AddObjMoveBehavior: Obj is null!");
				lua_error(L);
				return 1;
			}
			UAzureObjectComponent* comp = Cast<UAzureObjectComponent>(obj->GetComponentByClass(UAzureObjectComponent::StaticClass()));
			if (comp == nullptr)
			{
				FString log = obj->GetName() + TEXT("has no AzureObjectComponent");
				LuaStatic::traceback(L, TCHAR_TO_UTF8(*log));
				lua_error(L);
				return 1;
			}
			++n;

			///////////
			if (!lua_isboolean(L, n))
			{
				lua_pushstring(L, "AddObjMoveBehavior: param must be boolean(bReUse)");
				LuaStatic::traceback(L);
				lua_error(L);
				return 1;
			}
			bool bReUse = !!lua_toboolean(L, n);
			++n;

			///////////
			if (!lua_istable(L, n) && !lua_isuserdata(L, n))
			{
				lua_pushstring(L, "AddObjMoveBehavior: param must be vector3(destPos)");
				lua_error(L);
				return 1;
			}
			FVector vDest = FLuaVector::Get(L, n);
			vDest = POS_FROM_SERVER(vDest);
			++n;

			///////////
			OnBehaviorFinish onFinish = nullptr;
			if (!lua_isnoneornil(L, n))
			{
				if (!lua_isfunction(L, n))
				{
					lua_pushstring(L, "AddObjMoveBehavior: param must be function(callback)");
					lua_error(L);
					return 1;
				}
				onFinish = SetBehaviorOnFinishCallback(L, n);
			}
			++n;

			bool ret = comp->AddObjMoveBehavior(bReUse, vDest, onFinish);
			lua_pushboolean(L, ret);
			return 1;
		}
		
		static int AddGlideBehavior(lua_State * L)
		{
			int n = 1;

			AActor* obj = Cast<AActor>(wLua::FLuaUtils::GetUObject(L, 1, "Actor"));
			if (!obj)
			{
				LuaStatic::traceback(L, "AddGlideBehavior: Obj is null!");
				lua_error(L);
				return 1;
			}
			UAzureObjectComponent* comp = Cast<UAzureObjectComponent>(obj->GetComponentByClass(UAzureObjectComponent::StaticClass()));
			if (comp == nullptr)
			{
				FString log = obj->GetName() + TEXT("has no AzureObjectComponent");
				LuaStatic::traceback(L, TCHAR_TO_UTF8(*log));
				lua_error(L);
				return 1;
			}
			++n;

			const float fForwardSpeed = luaL_checknumber(L, n) * UE_METRE_TRANS;
			++n;

			const float fFallingSpeed = luaL_checknumber(L, n) * UE_METRE_TRANS;
			++n;

			const float fTurnSpeedInRadian = luaL_checknumber(L, n);
			++n;

			const float fLandDuration = luaL_checknumber(L, n);
			++n;

			const float fFreeFallingSpeed = luaL_checknumber(L, n) * UE_METRE_TRANS;
			++n;

			const float fLandMinSpeed = luaL_checknumber(L, n) * UE_METRE_TRANS;
			++n;

			FVector vLandPos = FLuaVector::Get(L, n);
			vLandPos = POS_FROM_SERVER(vLandPos);
			++n;

			const Azure::GlideCtrlMode eCtrlMode = (Azure::GlideCtrlMode)luaL_checkinteger(L, n);
			++n;

			///////////
			OnBehaviorFinish onFinish = nullptr;
			if (!lua_isnoneornil(L, n))
			{
				if (!lua_isfunction(L, n))
				{
					lua_pushstring(L, "AddObjMoveBehavior: param must be function(callback)");
					lua_error(L);
					return 1;
				}
				onFinish = SetBehaviorOnFinishCallback(L, n);
			}
			++n;

			GlideParam glideParam;
			glideParam.fForwardSpeed = fForwardSpeed;
			glideParam.fFallingSpeed = fFallingSpeed;
			glideParam.fTurnSpeedInRadian = fTurnSpeedInRadian;
			glideParam.fLandDuration = fLandDuration;
			glideParam.eCtrlMode = eCtrlMode;
			glideParam.vLandPos = vLandPos;
			glideParam.fFreeFallingSpeed = fFreeFallingSpeed;
			glideParam.fLandMinSpeed = fLandMinSpeed;
			const bool ret = comp->AddGlideBehavior(glideParam, onFinish);
			lua_pushboolean(L, ret);
			return 1;
		}
		static int AddHPJoystickMoveBehavior(lua_State * L)
		{
			///////////
			int n = 1;
			AActor *obj = Cast<AActor>(wLua::FLuaUtils::GetUObject(L, n, "Actor"));
			
			if (obj == nullptr)
			{
				lua_pushstring(L, "AddHPJoystickMoveBehavior: param must be Actor!");
				lua_error(L);
				return 1;
			}
			UAzureObjectComponent* comp = Cast<UAzureObjectComponent>(obj->GetComponentByClass(UAzureObjectComponent::StaticClass()));
			if (comp == nullptr)
			{
				FString log = obj->GetName() + TEXT("has no AzureObjectComponent");
				LuaStatic::traceback(L, TCHAR_TO_UTF8(*log));
				lua_error(L);
				return 1;
			}
			++n;

			///////////
			if (lua_isboolean(L, n) == false)
			{
				lua_pushstring(L, "AddHPJoystickMoveBehavior: param must be boolean(bReUse)");
				LuaStatic::traceback(L);
				lua_error(L);
				return 1;
			}
			bool bReUse = !!lua_toboolean(L, n);
			++n;

			///////////
			float fMoveSpeed = (float)luaL_checknumber(L, n);
			++n;

			///////////
			float fTurnSpeed = (float)luaL_checknumber(L, n);
			++n;

			///////////
			if (lua_isboolean(L, n) == false)
			{
				lua_pushstring(L, "AddHPJoystickMoveBehavior: param must be bool(bSkillMove)");
				lua_error(L);
				return 1;
			}
			bool bIsSkillMove = !!lua_toboolean(L, n);
			++n;

			
			//////
			bool bHasOnFinish = (!lua_isnoneornil(L, n));
			if (bHasOnFinish && !lua_isfunction(L, n))
			{
				lua_pushstring(L, "AddHPJoystickMoveBehavior: param must be function(callback)");
				lua_error(L);
				return 1;
			}
			OnBehaviorFinish onFinish = nullptr;
			if (bHasOnFinish)
			{
				onFinish = SetBehaviorOnFinishCallback(L, n);
			}
			bool ret = comp->AddHPJoystickMoveBehavior(bReUse, fMoveSpeed, fTurnSpeed, bIsSkillMove, onFinish);
			lua_pushboolean(L, ret);
			return 1;
		}

		static int AddHPVehicleJoystickMoveBehavior(lua_State * L)
		{
			int nTop = lua_gettop(L);
			///////////
			int n = 1;
			AActor *obj = Cast<AActor>(wLua::FLuaUtils::GetUObject(L, n, "Actor"));

			if (obj == nullptr)
			{
				lua_pushfstring(L, "AddHPVehicleJoystickMoveBehavior: param#%d must be Actor!", n);
				lua_error(L);
				return 1;
			}
			UAzureObjectComponent* comp = Cast<UAzureObjectComponent>(obj->GetComponentByClass(UAzureObjectComponent::StaticClass()));
			if (comp == nullptr)
			{
				FString log = obj->GetName() + TEXT("has no AzureObjectComponent");
				LuaStatic::traceback(L, TCHAR_TO_UTF8(*log));
				lua_error(L);
				return 1;
			}
			++n;

			///////////
			if (lua_isboolean(L, n) == false)
			{
				lua_pushfstring(L, "AddHPVehicleJoystickMoveBehavior: param#%d must be boolean(bReUse)", n);
				LuaStatic::traceback(L);
				lua_error(L);
				return 1;
			}
			bool bReUse = !!lua_toboolean(L, n);
			++n;
			//////////
			float fMoveSpeed = 0;
			if (n < nTop)
			{
				if (lua_isnumber(L, n))
				{
					fMoveSpeed = lua_tonumber(L, n);
				}
				else
				{
					lua_pushfstring(L, "AddHPVehicleJoystickMoveBehavior: param %d must be float(fMoveSpeed)", n);
					lua_error(L);
					return 1;
				}
				++n;
			}

			bool onlyAcceptNotManualInput = false;
			if (n < nTop)
			{
				if (lua_isboolean(L, n))
				{
					onlyAcceptNotManualInput = lua_toboolean(L, n);
				}
				else
				{
					lua_pushfstring(L, "AddHPVehicleJoystickMoveBehavior: param %d must be boolean(onlyAcceptNotManualInput)", n);
					lua_error(L);
					return 1;
				}
				++n;
			}
			
			//////确保最后一个是OnFinish
			bool bHasOnFinish = (!lua_isnoneornil(L, nTop));
			if (bHasOnFinish && !lua_isfunction(L, nTop))
			{
				lua_pushfstring(L, "AddHPVehicleJoystickMoveBehavior: param#%d must be function(callback)", nTop);
				lua_error(L);
				return 1;
			}
			OnBehaviorFinish onFinish = nullptr;
			if (bHasOnFinish)
			{
				onFinish = SetBehaviorOnFinishCallback(L, nTop);
			}
			bool ret = comp->AddHPVehicleJoystickMoveBehavior(bReUse, fMoveSpeed, 0, onlyAcceptNotManualInput, onFinish);;
			lua_pushboolean(L, ret);
			return 1;
		}

		static int AddHPJumpBehavior(lua_State * L)
		{
			///////////
			int n = 1;
			AActor* obj = Cast<AActor>(wLua::FLuaUtils::GetUObject(L, n, "Actor"));
			if (obj == nullptr)
			{
				lua_pushstring(L, "AddHPJumpBehavior: param must be Actor!");
				lua_error(L);
				return 1;
			}
			UAzureObjectComponent* comp = Cast<UAzureObjectComponent>(obj->GetComponentByClass(UAzureObjectComponent::StaticClass()));
			if (comp == nullptr)
			{
				FString log = obj->GetName() + TEXT("has no AzureObjectComponent");
				LuaStatic::traceback(L, TCHAR_TO_UTF8(*log));
				lua_error(L);
				return 1;
			}
			++n;

			///////////
			if (lua_isboolean(L, n) == false)
			{
				lua_pushstring(L, "AddHPJumpBehavior: param must be bool(bSkillMove)");
				lua_error(L);
				return 1;
			}
			bool bReUse = !!lua_toboolean(L, n);
			++n;

			///////////
			float gravity_scale_down = (float)luaL_checknumber(L, n);
			++n;

			///////////
			if (lua_isboolean(L, n) == false)
			{
				lua_pushstring(L, "AddHPJumpBehavior: param must be bool(bSkillMove)");
				lua_error(L);
				return 1;
			}
			bool bIsSkillMove = !!lua_toboolean(L, n);
			++n;


			//////
			bool bHasOnFinish = (!lua_isnoneornil(L, n));
			if (bHasOnFinish && !lua_isfunction(L, n))
			{
				lua_pushstring(L, "AddHPJumpBehavior: param must be function(callback)");
				lua_error(L);
				return 1;
			}
			OnBehaviorFinish onFinish = nullptr;
			if (bHasOnFinish)
			{
				onFinish = SetBehaviorOnFinishCallback(L, n);
			}

			bool ret = comp->AddHPJumpBehavior(bReUse, gravity_scale_down, bIsSkillMove, onFinish);
			lua_pushboolean(L, ret);
			return 1;
		}

		static int AddHPRushDownBehavior(lua_State * L)
		{
			int n = 1;

			AActor* obj = Cast<AActor>(wLua::FLuaUtils::GetUObject(L, 1, "Actor"));
			if (!obj)
			{
				LuaStatic::traceback(L, "AddHPRushDownBehavior: Obj is null!");
				lua_error(L);
				return 1;
			}
			UAzureObjectComponent* comp = Cast<UAzureObjectComponent>(obj->GetComponentByClass(UAzureObjectComponent::StaticClass()));
			if (comp == nullptr)
			{
				FString log = obj->GetName() + TEXT("has no AzureObjectComponent");
				LuaStatic::traceback(L, TCHAR_TO_UTF8(*log));
				lua_error(L);
				return 1;
			}
			++n;

			///////////
			if (!lua_isboolean(L, n))
			{
				lua_pushstring(L, "AddHPRushDownBehavior: param must be boolean(bReUse)");
				LuaStatic::traceback(L);
				lua_error(L);
				return 1;
			}
			bool bReUse = !!lua_toboolean(L, n);
			++n;

			///////////
			if (!lua_istable(L, n) && !lua_isuserdata(L, n))
			{
				lua_pushstring(L, "AddHPRushDownBehavior: param must be vector3(dir)");
				lua_error(L);
				return 1;
			}
			FVector vDir = FLuaVector::Get(L, n);
			++n;

			///////////
			float fSpeed = (float)luaL_checknumber(L, n);
			++n;

			///////////
			float fMaxDis = (float)luaL_checknumber(L, n);
			++n;
	
			///////////
			OnBehaviorFinish onFinish = nullptr;
			if (!lua_isnoneornil(L, n))
			{
				if (!lua_isfunction(L, n))
				{
					lua_pushstring(L, "AddHPRushDownBehavior: param must be function(callback)");
					lua_error(L);
					return 1;
				}
				onFinish = SetBehaviorOnFinishCallback(L, n);
			}
			++n;

			bool ret = comp->AddHPRushDownBehavior(bReUse, vDir, fSpeed, fMaxDis, onFinish);
			lua_pushboolean(L, ret);
			return 1;
		}

		static int SetGamePlayerInfo(lua_State * L)
		{
			int n = 1;
			AGamePlayer * obj = Cast<AGamePlayer>(wLua::FLuaUtils::GetUObject(L, n, "GamePlayer"));

			if (obj == nullptr)
			{
				lua_pushstring(L, "SetGamePlayerInfo: param must be GamePlayer!");
				lua_error(L);
				return 0;
			}
			

			///////////
			++n;
			if (lua_isstring(L, n) == false)
			{
				lua_pushstring(L, "SetGamePlayerInfo: param must be string(id)");
				lua_error(L);
				return 0;
			}
			FString str_id = UTF8_TO_TCHAR(lua_tostring(L, n));
			int64 id = FCString::Atoi64(*str_id);
			

			///////////
			++n;
			if (lua_isnumber(L, n) == false)
			{
				lua_pushstring(L, "SetGamePlayerInfo: param must be number(char_type)");
				lua_error(L);
				return 0;
			}
			uint8 char_type = lua_tonumber(L, n);
			
			++n;
			if (lua_isboolean(L, n) == false)
			{
				lua_pushstring(L, "SetGamePlayerInfo: param  must be boolean(isCarrier)");
				lua_error(L);
				return 1;
			}
			bool isCarrier = !!lua_toboolean(L, n);

			uint8 sub_type = luaL_optinteger(L, ++n, 0);
			
			obj->OnSetGamePlayerInfo(id, static_cast<EGamePlayerType>(char_type),isCarrier, static_cast<EDemoPlayerSubType>(sub_type));

/*			if (static_cast<EGamePlayerType>(char_type) == EGamePlayerType::HostPlayer)
			{
				int IsSwimming = obj->GetMovementComponent()->IsSwimming();
				if (AAzureEntryPoint::Instance)
				{
					AAzureEntryPoint::Instance->CallLuaFunctionOI(FString("SwimmingState"), nullptr, IsSwimming);
				}				
			}*/			
			return 0;
		}

		static int SetIsAiming(lua_State* L)
		{
			AGamePlayer* obj = Cast<AGamePlayer>(wLua::FLuaUtils::GetUObject(L, 1, "GamePlayer"));

			if (!obj)
			{
				lua_pushstring(L, "SetIsAiming: #1 must be GamePlayer!");
				lua_error(L);
				return 0;
			}

			if (!lua_isboolean(L, 2))
			{
				lua_pushstring(L, "SetIsAiming: #2 must be boolean");
				lua_error(L);
				return 0;
			}
			bool aiming = lua_toboolean(L, 2);
			obj->SetIsAiming(aiming);
			return 0;
		}

		static int StopMovement(lua_State * L)
		{
			int n = 1;
			AGamePlayer * obj = Cast<AGamePlayer>(wLua::FLuaUtils::GetUObject(L, n, "GamePlayer"));

			if (obj == nullptr)
			{
				lua_pushstring(L, "StopMovement: param must be GamePlayer!");
				lua_error(L);
				return 0;
			}
			++n;

			//////////
			if (lua_isboolean(L, n) == false)
			{
				lua_pushstring(L, "StopMovement: param must be boolean(bHostPlayer)");
				lua_error(L);
				return 0;
			}
			bool bHostPlayer = !!lua_toboolean(L, n);
			++n;

			if (bHostPlayer)
				obj->GetCharacterMovement()->StopActiveMovement();
			else
				obj->StopMyReplicatedMovement();

			return 0;
		}

		static int OnPlayerChangeAnimBP(lua_State * L)
		{
			///////////
			int n = 1;
			AGamePlayer * obj = Cast<AGamePlayer>(wLua::FLuaUtils::GetUObject(L, n, "GamePlayer"));

			if (obj == nullptr)
			{
				lua_pushstring(L, "OnPlayerChangeAnimBP: param must be GamePlayer!");
				lua_error(L);
				return 0;
			}
			++n;

			obj->OnChangeAnimBP();
			return 0;
		}

		static int ChangeChargeTargetPos(lua_State * L)
		{
			AActor* obj = Cast<AActor>(wLua::FLuaUtils::GetUObject(L, 1, "Actor"));
			if (obj == nullptr)
			{
				lua_pushstring(L, "ChangeChargeTargetPos: param must be Actor!");
				lua_error(L);
				return 1;
			}
			UAzureObjectComponent* comp = Cast<UAzureObjectComponent>(obj->GetComponentByClass(UAzureObjectComponent::StaticClass()));
			if (comp == nullptr)
			{
				FString log = obj->GetName() + TEXT("has no AzureObjectComponent");
				LuaStatic::traceback(L, TCHAR_TO_UTF8(*log));
				lua_error(L);
				return 1;
			}

			if (!lua_istable(L, 2) && !lua_isuserdata(L, 2))
			{
				lua_pushstring(L, "ChangeChargeTargetPos: param 2 must be vector3");
				lua_error(L);
				return 1;
			}
			FVector vDest = FLuaVector::Get(L, 2);
			vDest = POS_FROM_SERVER(vDest);

			int ret = comp->ChangeChargeTargetPos(vDest);
			lua_pushinteger(L, ret);
			return 1;
		}

// 		static int AddHPLockTargetBehavior(lua_State * L)
// 		{
// 			AActor* hpobj = Cast<AActor>(wLua::FLuaUtils::GetUObject(L, 1, "Actor"));
// 			if (hpobj == nullptr)
// 			{
// 				lua_pushstring(L, "AddHPLockTargetBehavior: param 1 must be Actor!");
// 				lua_error(L);
// 				return 1;
// 			}
// 			UAzureObjectComponent* comp = Cast<UAzureObjectComponent>(hpobj->GetComponentByClass(UAzureObjectComponent::StaticClass()));
// 			if (comp == nullptr)
// 			{
// 				FString log = hpobj->GetName() + TEXT("has no AzureObjectComponent");
// 				LuaStatic::traceback(L, TCHAR_TO_UTF8(*log));
// 				lua_error(L);
// 				return 1;
// 			}
// 			AActor* tarobj = Cast<AActor>(wLua::FLuaUtils::GetUObject(L, 2, "Actor"));
// 			if (tarobj == nullptr)
// 			{
// 				lua_pushstring(L, "AddHPLockTargetBehavior: param 2 must be Actor!");
// 				lua_error(L);
// 				return 1;
// 			}
// 
// 			bool ret = comp->AddHPLockTargetBehavior(tarobj);
// 			lua_pushboolean(L, ret);
// 			return 1;
// 		}

		
		static int AddTurnBehaviorInner(lua_State * L, bool limit_time)
		{
			if (lua_isuserdata(L, 1) == false)
			{
				lua_pushstring(L, "AddTurnBehavior: param 1 must be gameobject");
				lua_error(L);
				return 1;
			}
			AActor* obj = Cast<AActor>(wLua::FLuaUtils::GetUObject(L, 1, "Actor"));
			UAzureObjectComponent* comp = obj ? Cast<UAzureObjectComponent>(obj->GetComponentByClass(UAzureObjectComponent::StaticClass())) : nullptr;
			if (comp == nullptr)
			{
				LuaStatic::traceback(L);
				lua_error(L);
				return 1;
			}

			if (!lua_istable(L, 2))
			{
				lua_pushstring(L, "AddTurnBehavior: param 2 must be vector3");
				lua_error(L);
				return 1;
			}

			if (lua_isnumber(L, 3) == false)
			{
				lua_pushstring(L, "AddTurnBehavior: param 3 must be float");
				lua_error(L);
				return 1;
			}

			if (lua_isnumber(L, 4) == false)
			{
				lua_pushstring(L, "AddTurnBehavior: param 4 must be float");
				lua_error(L);
				return 1;
			}

			bool bHasCB = !lua_isnoneornil(L, 6);
			if (bHasCB && !lua_isfunction(L, 6))
			{
				lua_pushstring(L, "AddTurnBehavior: param 6 must be function");
				lua_error(L);
				return 1;
			}

			FVector vDest = FLuaVector::Get(L, 2);

			float param = lua_tonumber(L, 3);

			GP_TURN_FLAG flag = (GP_TURN_FLAG)lua_touint(L, 4);

			AGamePlayer* pCarrier = Cast<AGamePlayer>(wLua::FLuaUtils::GetUObject(L, 5, "GamePlayer"));

			OnBehaviorFinish callback = nullptr;
			if (bHasCB)
			{
				callback = SetBehaviorOnFinishCallback(L, 6);
			}

			bool ret = comp->AddTurnBehavior(vDest, limit_time, param, flag, pCarrier,callback);
			lua_pushboolean(L, ret);
			return 1;
		}

		static int AddTurnBehavior(lua_State * L)
		{
			return AddTurnBehaviorInner(L, false);
		}
		static int AddTurnBehaviorLimitTime(lua_State * L)
		{
			return AddTurnBehaviorInner(L, true);
		}

		static int FindChargeBehavior(lua_State* L)
		{
			//////////
			if (lua_isuserdata(L, 1) == false)
			{
				lua_pushstring(L, "FindChargeBehavior: param 1 must be gameobject");
				lua_error(L);
				return 1;
			}
			AActor* obj = Cast<AActor>(wLua::FLuaUtils::GetUObject(L, 1, "Actor"));
			UAzureObjectComponent* comp = obj ? Cast<UAzureObjectComponent>(obj->GetComponentByClass(UAzureObjectComponent::StaticClass())) : nullptr;
			if (comp == nullptr)
			{
				LuaStatic::traceback(L);
				lua_error(L);
				return 1;
			}

			//////////
			if (lua_isnumber(L, 2) == false)
			{
				lua_pushstring(L, "FindChargeBehavior: param 2 must be number(idSkill)");
				lua_error(L);
				return 1;
			}
			int idSkill = lua_tointeger(L, 2); // <0: all idSkill!=0, else: idSkill match

			//////////
			bool bFind = comp->FindChargeBehavior(idSkill);
			lua_pushboolean(L, bFind);
			return 1;
		}

		static int RemoveChargeBehavior(lua_State* L)
		{
			//////////
			if (lua_isuserdata(L, 1) == false)
			{
				lua_pushstring(L, "RemoveChargeBehavior: param 1 must be gameobject");
				lua_error(L);
				return 1;
			}
			AActor* obj = Cast<AActor>(wLua::FLuaUtils::GetUObject(L, 1, "Actor"));
			UAzureObjectComponent* comp = obj ? Cast<UAzureObjectComponent>(obj->GetComponentByClass(UAzureObjectComponent::StaticClass())) : nullptr;
			if (comp == nullptr)
			{
				LuaStatic::traceback(L);
				lua_error(L);
				return 1;
			}

			//////////
			if (lua_isnumber(L, 2) == false)
			{
				lua_pushstring(L, "RemoveChargeBehavior: param 2 must be number(idSkill)");
				lua_error(L);
				return 1;
			}
			int idSkill = lua_tointeger(L, 2);

			//////////
			if (lua_isboolean(L, 3) == false)
			{
				lua_pushstring(L, "RemoveChargeBehavior: param 3 must be boolean(bDragToDest)");
				lua_error(L);
				return 1;
			}
			bool bDragToDest = !!lua_toboolean(L, 3);

			//////////
			comp->RemoveChargeBehavior(idSkill, bDragToDest);
			return 0;
		}

		

		static int RemoveBehavior(lua_State * L)
		{
			if (lua_isuserdata(L, 1) == false)
			{
				lua_pushstring(L, "RemoveBehavior: param 1 must be gameobject");
				lua_error(L);
				return 1;
			}
			AActor* obj = Cast<AActor>(wLua::FLuaUtils::GetUObject(L, 1, "Actor"));
			UAzureObjectComponent* comp = obj ? Cast<UAzureObjectComponent>(obj->GetComponentByClass(UAzureObjectComponent::StaticClass())) : nullptr;
			if (comp == nullptr)
			{
				LuaStatic::traceback(L);
				lua_error(L);
				return 1;
			}

			if (!lua_isnumber(L, 2))
			{
				lua_pushstring(L, "RemoveBehavior: param 2 must be number(type)");
				lua_error(L);
				return 1;
			}
			int type = lua_tointeger(L, 2);

			comp->RemoveBehavior((Azure::BehaviorType)type);
			return 0;
		}

		static int GetPositionAfterTimeByBehavior(lua_State * L) {
			if (lua_isuserdata(L, 1) == false)
			{
				lua_pushstring(L, "GetPositionAfterTimeByBehavior: param 1 must be gameobject");
				lua_error(L);
				return 1;
			}
			AActor* obj = Cast<AActor>(wLua::FLuaUtils::GetUObject(L, 1, "Actor"));
			UAzureObjectComponent* comp = obj ? Cast<UAzureObjectComponent>(obj->GetComponentByClass(UAzureObjectComponent::StaticClass())) : nullptr;
			if (comp == nullptr)
			{
				LuaStatic::traceback(L);
				lua_error(L);
				return 1;
			}

			if (!lua_isnumber(L, 2))
			{
				lua_pushstring(L, "GetPositionAfterTimeByBehavior: param 2 must be number");
				lua_error(L);
				return 1;
			}
			float time = lua_tonumber(L, 2);

			if (!lua_isnumber(L, 3))
			{
				FVector position = comp->GetPositionAfterTimeByAllBehavior(time);
				FLuaVector::Return(L, position);
				lua_pushboolean(L, !position.IsZero());
				return 2;
			}
			else {
				int type = lua_tointeger(L, 3);
				FVector position = comp->GetPositionAfterTimeByBehavior((Azure::BehaviorType)type, time);
				FLuaVector::Return(L, position);
				lua_pushboolean(L, !position.IsZero());
				return 2;
			}
		}

		static int AddTimer(lua_State * L)
		{
			AActor* obj = Cast<AActor>(wLua::FLuaUtils::GetUObject(L, 1, "Actor"));
			UAzureObjectComponent* comp = obj ? Cast<UAzureObjectComponent>(obj->GetComponentByClass(UAzureObjectComponent::StaticClass())) : nullptr;
			if (comp == nullptr)
			{
				FString log;
				if (obj)
					log = obj->GetName() + TEXT("has no AzureObjectComponent");
				else
					log = TEXT("Actor is nil!");
				LuaStatic::traceback(L, TCHAR_TO_UTF8(*log));
				lua_error(L);
				return 1;
			}

			if (!lua_isnumber(L, 2))
			{
				lua_pushstring(L, "AddTimer: param 2 must be number(ttl)");
				lua_error(L);
				return 1;
			}
			float ttl = (float)lua_tonumber(L, 2);

			if (!lua_isboolean(L, 3))
			{
				lua_pushstring(L, "AddTimer: param 3 must be bool(bOnce)");
				lua_error(L);
				return 1;
			}
			bool bOnce = !!lua_toboolean(L, 3);

			if (!lua_isfunction(L, 4))
			{
				lua_pushstring(L, "AddTimer: param 4 must be function(callback)");
				lua_error(L);
				return 1;
			}
			lua_pushvalue(L, 4);
			wLua::lua_registry_handle callbackRef = wLua::lua_registry_handle::wlua_ref(L, LUA_REGISTRYINDEX);

			wLua::lua_registry_handle cbparam;
			if (!lua_isnoneornil(L, 5))
			{
				lua_pushvalue(L, 5);
				cbparam = wLua::lua_registry_handle::wlua_ref(L, LUA_REGISTRYINDEX);
			}

			bool bChangeWithTimeDilation = true;
			if (lua_isboolean(L, 6))
			{
				bChangeWithTimeDilation = !!lua_toboolean(L, 6);
			}

			int id = comp->AddTimer(ttl, bOnce, callbackRef, cbparam, bChangeWithTimeDilation);
			lua_pushinteger(L, id);
			return 1;
		}

		static int DelayTimer(lua_State * L)
		{
			AActor* obj = Cast<AActor>(wLua::FLuaUtils::GetUObject(L, 1, "Actor"));
			UAzureObjectComponent* comp = obj ? Cast<UAzureObjectComponent>(obj->GetComponentByClass(UAzureObjectComponent::StaticClass())) : nullptr;
			if (comp == nullptr)
			{
				FString log;
				if (obj)
					log = obj->GetName() + TEXT("has no UAzureObjectComponent");
				else
					log = TEXT("Actor is nil!");

				LuaStatic::traceback(L, TCHAR_TO_UTF8(*log));
				lua_error(L);
				return 1;
			}

			if (!lua_isnumber(L, 2))
			{
				lua_pushstring(L, "DelayTimer: param 2 must be number(id)");
				lua_error(L);
				return 1;
			}
			int id = lua_tointeger(L, 2);

			if (!lua_isnumber(L, 3))
			{
				lua_pushstring(L, "DelayTimer: param 3 must be number(ttl)");
				lua_error(L);
				return 1;
			}
			float ttl = (float)lua_tonumber(L, 3);

			float maxDurationToRemove = -1;
			if (lua_gettop(L) >= 4)
			{
				maxDurationToRemove = (float)lua_tonumber(L, 4);
			}

			int ret = comp->DelayTimer(id, ttl, maxDurationToRemove);
			//	-2: found but reach maxDuration and Removed
			//	-1: ticking
			//	0: not found
			//	> 0: found and delayed
			lua_pushinteger(L, ret);
			return 1;
		}

		static int RemoveTimer(lua_State * L)
		{
			AActor* obj = Cast<AActor>(wLua::FLuaUtils::GetUObject(L, 1, "Actor"));
			UAzureObjectComponent* comp = obj ? Cast<UAzureObjectComponent>(obj->GetComponentByClass(UAzureObjectComponent::StaticClass())) : nullptr;
			if (comp == nullptr)
			{
				LuaStatic::traceback(L);
				lua_error(L);
				return 1;
			}

			if (!lua_isnumber(L, 2))
			{
				lua_pushstring(L, "RemoveTimer: param 2 must be number(id)");
				lua_error(L);
				return 1;
			}
			int id = lua_tointeger(L, 2);
			comp->RemoveTimer(id);
			return 0;
		}

		static int ResetTimer(lua_State * L)
		{
			AActor* obj = Cast<AActor>(wLua::FLuaUtils::GetUObject(L, 1, "Actor"));
			UAzureObjectComponent* comp = obj ? Cast<UAzureObjectComponent>(obj->GetComponentByClass(UAzureObjectComponent::StaticClass())) : nullptr;
			if (comp == nullptr)
			{
				LuaStatic::traceback(L);
				lua_error(L);
				return 1;
			}

			if (!lua_isnumber(L, 2))
			{
				lua_pushstring(L, "ResetTimer: param 2 must be number(id)");
				lua_error(L);
				return 1;
			}
			int id = lua_tointeger(L, 2);

			float ttl_new = -1; // < 0 means not change
			if (lua_gettop(L) >= 3)
			{
				if (!lua_isnumber(L, 3))
				{
					lua_pushstring(L, "ResetTimer: param 3 must be float(ttl_new)");
					lua_error(L);
					return 1;
				}
				ttl_new = (float)lua_tonumber(L, 3);
			}

			comp->ResetTimer(id, ttl_new);
			return 0;
		}

		static int GetCurrentJoyStickValue(lua_State * L)
		{
			FVector2D v = AzureInputCtrl::GetInstance().GetJoyStickValue();
			lua_pushnumber(L, v.X);
			lua_pushnumber(L, v.Y);
			return 2;
		}

		static int EnableInputMotion(lua_State * L)
		{
			if (!lua_isboolean(L, 1))
			{
				lua_pushstring(L, "EnableInputMotion: param 1 must be bool(bEnable)");
				lua_error(L);
				return 1;
			}
			bool bEnable = !!lua_toboolean(L, 1);
			AzureInputCtrl::GetInstance().SetEnableInputMotion(bEnable);
			return 0;
		}

		static int GetEnableInputMotion(lua_State * L)
		{
			lua_pushboolean(L, AzureInputCtrl::GetInstance().GetEnableInputMotion());
			return 1;
		}


		static int SetShakeParam(lua_State * L)
		{
			float shakeAccelerationThreshold = (float)luaL_checknumber(L, 1);
			float shakeSampleTime = (float)luaL_checknumber(L, 2);
			int shakeCount = (int)luaL_checknumber(L, 3);
			AzureInputCtrl::GetInstance().SetShakeParam( shakeAccelerationThreshold, shakeSampleTime, shakeCount);
			return 0;
		}

		static int GetCurrentJoyStickDir(lua_State * L)
		{
			if (!lua_isboolean(L, 1))
			{
				lua_pushstring(L, "GetCurrentJoyStickDir: param 1 must be bool(bDir3D)");
				lua_error(L);
				return 1;
			}
			bool bDir3D = !!lua_toboolean(L, 1);

			FVector vDir(ForceInitToZero);
			bool bGot = AzureUtility::GetCurrentJoyStickDir(vDir, bDir3D, false);
			lua_pushboolean(L, bGot);
			lua_pushnumber(L, vDir.X);
			lua_pushnumber(L, vDir.Y);
			lua_pushnumber(L, vDir.Z);
			return 4;
		}

		static int SetPlayerMoveRaiseHei(lua_State * L)
		{
			float f1 = (float)luaL_checknumber(L, 1);
			Azure::s_fPlayerMoveRaiseHei_Ground = f1 * UE_METRE_TRANS;

			if (lua_isnumber(L, 2))
			{
				float f2 = (float)luaL_checknumber(L, 2);
				Azure::s_fPlayerMoveRaiseHei_Air = f2 * UE_METRE_TRANS;
			}
			return 0;
		}
		static int SetPlayerMoveExt(lua_State * L)
		{
			float f = (float)luaL_checknumber(L, 1);
			Azure::s_fPlayerMoveExt = f;
			return 0;
		}
		static int SetPlayerMoveHalfHei(lua_State * L)
		{
			float f = (float)luaL_checknumber(L, 1);
			Azure::s_fPlayerMoveHalfHei = f * UE_METRE_TRANS;
			return 0;
		}

		static int SetElsePlayerJumpGravityScale(lua_State * L)
		{
			float f = (float)luaL_checknumber(L, 1);
			Azure::s_jump_up_gravityScale[0] = f;

			f = (float)luaL_checknumber(L, 2);
			Azure::s_jump_up_gravityScale[1] = f;

			f = (float)luaL_checknumber(L, 3);
			Azure::s_jump_up_gravityScale[2] = f;

			f = (float)luaL_checknumber(L, 4);
			Azure::s_jump_down_gravityScale = f;
			return 0;
		}
		
		static int SetPlayerDashParam(lua_State * L)
		{
			float f;		
			int n = 0;

			n++;
			f = (float)luaL_checknumber(L, n);
			Azure::s_dash_time = f;

			n++;
			f = (float)luaL_checknumber(L, n);
			Azure::s_dash_time_move_input = f;
			
			n++;
			f = (float)luaL_checknumber(L, n);
			Azure::s_dash_angle = f;

			n++;
			f = (float)luaL_checknumber(L, n);
			Azure::s_dash_angle_dodge = f;

			n++;
			f = (float)luaL_checknumber(L, n);
			Azure::s_dash_stop_force_time = f;

			n++;
			f = (float)luaL_checknumber(L, n);
			Azure::s_dash_stop_turn180_force_time = f;

			n++;
			f = (float)luaL_checknumber(L, n);
			Azure::s_dash_braking_friction_factor = f;

			return 0;
		}

		static int SetPlayerGlobalParams(lua_State * L)
		{
			float f;
			int n = 1;

			if (lua_isstring(L, n) == false)
			{
				lua_pushstring(L, "SetPlayerGlobalParams: param must be string");
				lua_error(L);
				return 1;
			}

			FString param_type = UTF8_TO_TCHAR(lua_tostring(L, n));
			++n;

			if (param_type == "waitNextSync")
			{
				f = (float)luaL_checknumber(L, n);
				Azure::s_waitNextSyncScale = f;
				n++;
			}
			else if (param_type == "aim_walk_angle")
			{
				f = (float)luaL_checknumber(L, n);
				Azure::aim_walk_backward_angle_limit = f;
				n++;
			}
			else if (param_type == "start_walk_duration")
			{
				f = (float)luaL_checknumber(L, n);
				Azure::start_walk_duration = f;
				n++;
			}
			else if (param_type == "start_walk_inpterrupt_time")
			{
				f = (float)luaL_checknumber(L, n);
				Azure::start_walk_inpterrupt_time = f;
				n++;
			}
			else if (param_type == "move_rot_speed")
			{
				f = (float)luaL_checknumber(L, n);
				Azure::move_rot_speed = f;
				n++;
			}
			else if (param_type == "turn_at_rate_angle")
			{
				f = (float)luaL_checknumber(L, n);
				Azure::turn_at_rate_angle = f;
				n++;
			}
			else if (param_type == "turn_speed_minus_angle")
			{
				f = (float)luaL_checknumber(L, n);
				Azure::turn_speed_minus_angle = f;
				n++;
			}
			else if (param_type == "turn_speed_minus_scale")
			{
				f = (float)luaL_checknumber(L, n);
				Azure::turn_speed_minus_scale = f;
				n++;
			}
			else if (param_type == "run_stop_force_time")
			{
				f = (float)luaL_checknumber(L, n);
				Azure::s_run_stop_force_time = f;
				n++;
			}
			else if (param_type == "run_stop_turn180_force_time")
			{
				f = (float)luaL_checknumber(L, n);
				Azure::s_run_stop_turn180_force_time = f;
				n++;
			}
			else if (param_type == "run_stop_speed_limit")
			{
				f = (float)luaL_checknumber(L, n);
				Azure::s_run_stop_speed_limit = f;
				n++;
			}
			else if (param_type == "run_stop_limit_time")
			{
				f = (float)luaL_checknumber(L, n);
				Azure::run_stop_limit_time = f;
				n++;
			}
			else if (param_type == "run_turn180_speed_limit")
			{
				f = (float)luaL_checknumber(L, n);
				Azure::run_turn180_speed_limit = f;
				n++;
			}
			else if (param_type == "turn180_angle_limit")
			{
				f = (float)luaL_checknumber(L, n);
				Azure::s_turn180_angle_limit = f;
				n++;
			}
			else if (param_type == "capsule_to_floor_dis")
			{
				f = (float)luaL_checknumber(L, n);
				Azure::capsule_to_floor_dis = f;
				n++;
			}
			else if (param_type == "joystick_scale")
			{
				f = (float)luaL_checknumber(L, n);
				Azure::joystick_scale = f;
				n++;
			}
			else if (param_type == "default_walk")
			{
				f = (float)luaL_checknumber(L, n);
				Azure::default_walk_speed = f;
				n++;

				f = (float)luaL_checknumber(L, n);
				Azure::default_walk_time_limit = f;
				n++;

				f = (float)luaL_checknumber(L, n);
				Azure::default_walk_input_limit = f;
				n++;
			}
			else if (param_type == "max_speed")
			{
				f = (float)luaL_checknumber(L, n);
				Azure::config_runSpeed = f;
				n++;

				f = (float)luaL_checknumber(L, n);
				Azure::config_dashSpeed = f;
				n++;
			}
			else if (param_type == "elsePlayer_info")
			{
				int v = (int)luaL_checknumber(L, n);
				if (v > 0)
					Azure::bElsePlayerMoveSweep = true;
				else
					Azure::bElsePlayerMoveSweep = false;
				n++;

				v = (int)luaL_checknumber(L, n);
				if (v > 0)
					Azure::bPlayerServerMovePredict = true;
				else
					Azure::bPlayerServerMovePredict = false;
				n++;
			}
			else if (param_type == "sync_info")
			{
				f = (float)luaL_checknumber(L, n);
				Azure::server_move_wait_sync_time = f;
				n++;

				f = (float)luaL_checknumber(L, n);
				Azure::host_send_sync_info_interval = f;
				n++;

				f = (float)luaL_checknumber(L, n);
				Azure::player_receive_sync_info_interval = f;
				n++;

				f = (float)luaL_checknumber(L, n);
				Azure::npc_server_move_delay_rate = f;
				n++;

				f = (float)luaL_checknumber(L, n);
				Azure::npc_min_sync_time = f;
				n++;

				f = (float)luaL_checknumber(L, n);
				Azure::host_jump_sync_interval = f;
				n++;

				f = (float)luaL_checknumber(L, n);
				Azure::npc_sync_rotate_smooth = f;
				n++;

				f = (float)luaL_checknumber(L, n);
				Azure::host_turn_angle_limit = f;
				n++;

				f = (float)luaL_checknumber(L, n);
				Azure::host_turn_force_sync_time = f;
				n++;
			}
			else if (param_type == "run_walk_gear_scale")
			{
				f = (float)luaL_checknumber(L, n);
				Azure::run_walk_gear_scale = f;
				n++;
			}
			
		

			return 0;
		}

		static int GetHitPosInWorld(lua_State* L)
		{
			FVector Start = wLua::FLuaVector::Get(L, 1);
			Start = POS_FROM_SERVER(Start);

			FVector End = wLua::FLuaVector::Get(L, 2);
			End = POS_FROM_SERVER(End);

			ECollisionChannel channel = (ECollisionChannel)lua_touint(L, 3);

			bool bRetAzureObjComp = false;
			if (lua_isboolean(L, 4))
				bRetAzureObjComp = !!lua_toboolean(L, 4);

			float fRadius = 0;
			if (lua_isnumber(L, 5))
				fRadius = lua_tonumber(L, 5) * UE_METRE_TRANS;

			float fHalfHeight = 0;
			if (lua_isnumber(L, 6))
				fHalfHeight = lua_tonumber(L, 6) * UE_METRE_TRANS;

			bool bBlockMoveIgnoreCapsuleOverlap = false;
			if (lua_isboolean(L, 7))
				bBlockMoveIgnoreCapsuleOverlap = !!lua_toboolean(L, 7);

			FHitResult result;
			bool ret = AzureUtility::GetHitPosInWorld(Start, End, channel, result, fRadius, fHalfHeight, bBlockMoveIgnoreCapsuleOverlap);
			if (ret)
				return AzureUtility::pushFHitResult2Lua(L, result, bRetAzureObjComp && AzureUtility::isTraceAzureObjectChannel(channel));
			else
				return 0;
		}

		static int GetFloorGradient(lua_State* L)
		{
			CalcGradientParams params;

			params.pos = wLua::FLuaVector::Get(L, 1);
			params.forward = wLua::FLuaVector::Get(L, 2);

			if (lua_isnumber(L, 3))
				params.length = lua_tonumber(L, 3);

			if (lua_isnumber(L, 4))
				params.width = lua_tonumber(L, 4);

			if (lua_isnumber(L, 5))
				params.channel = (ECollisionChannel)lua_touint(L, 5);

			float ret;
			if (FCalcGradientHelper::GetFloorGradient(ret, params))
			{
				lua_pushnumber(L, ret);
				return 1;
			}
			return 0;
		}

		//params: pos, forward, length, width, channel
		static int GetFloorNormal(lua_State* L)
		{
			CalcGradientParams params;

			params.pos = wLua::FLuaVector::Get(L, 1);
			params.forward = wLua::FLuaVector::Get(L, 2);

			if (lua_isnumber(L, 3))
				params.length = lua_tonumber(L, 3);

			if (lua_isnumber(L, 4))
				params.width = lua_tonumber(L, 4);

			if (lua_isnumber(L, 5))
				params.channel = (ECollisionChannel)lua_touint(L, 5);

			if (lua_isnumber(L, 6))
				params.traceBeginUp = lua_tonumber(L, 6);

			if (lua_isnumber(L, 7))
				params.traceLength = lua_tonumber(L, 7);

			if (lua_istable(L, 8))
			{
				lua_pushnil(L);
				while (lua_next(L, -2) != 0)
				{
					AActor* Obj = Cast<AActor>(wLua::FLuaUtils::GetUObject(L, -1, "Actor"));
					if (Obj) params.IngoreActors.Add(Obj);
					lua_pop(L, 1);
				}
			}
			
			FVector ret;
			if (FCalcGradientHelper::GetFloorNormal(ret, params))
			{
				wLua::FLuaVector::Return(L, ret);
				return 1;
			}
			return 0;
		}

		static int lua_GetPlaneNormal(lua_State* L)
		{
			FVector pos1 = wLua::FLuaVector::Get(L, 1);
			FVector pos2 = wLua::FLuaVector::Get(L, 2);
			FVector pos3 = wLua::FLuaVector::Get(L, 3);
			FVector normal = FCalcGradientHelper::GetPlaneNormal(pos1, pos2, pos3);
			wLua::FLuaVector::Return(L, normal);
			return 1;
		}

		static int CreateWorldWrap(lua_State* L)
		{
			//AzureWorldWrap 为 pov 类型，所以可行
			AzureWorldWrap* p = (AzureWorldWrap*)lua_newuserdata(L, sizeof(AzureWorldWrap));
			return 1;
		}

		static AzureWorldWrap* GetWorldWrapPtr(lua_State* L, int& iParam)
		{
			AzureWorldWrap* pWorldWrap;
			if (lua_isuserdata(L, iParam))
				pWorldWrap = (AzureWorldWrap*)lua_touserdata(L, iParam++);
			else
				pWorldWrap = &AzureWorldWrap::Instance();
			return pWorldWrap;
		}

		//[pWorldMap], bEnabled
		static int SetWorldWrapEnabled(lua_State* L)
		{
			int iParam = 1;
			AzureWorldWrap* pWorldWrap = GetWorldWrapPtr(L, iParam);
			bool bEnabled = lua_toboolean(L, iParam++);
			pWorldWrap->SetEnabled(bEnabled);
			exp_AutoMove_SetWorldWrapEanbled(bEnabled);
			return 0;
		}

		//[pWorldMap], minX, minZ, maxX, maxZ
		static int SetWorldWrapRect(lua_State* L)
		{
			int iParam = 1;
			AzureWorldWrap* pWorldWrap = GetWorldWrapPtr(L, iParam);
			float minX = luaL_checknumber(L, iParam++);
			float minZ = luaL_checknumber(L, iParam++);
			float maxX = luaL_checknumber(L, iParam++);
			float maxZ = luaL_checknumber(L, iParam++);
			pWorldWrap->SetWrapRect(FVector2D(minX, minZ), FVector2D(maxX, maxZ));
			exp_AutoMove_SetWorldWrapRect(minX, minZ, maxX, maxZ);
			return 0;
		}

		//[pWorldMap], x, z (server 坐标)
		static int SetWorldUnwrapCenter(lua_State* L)
		{
			int iParam = 1;
			AzureWorldWrap* pWorldWrap = GetWorldWrapPtr(L, iParam);
			float x = luaL_checknumber(L, iParam++);
			float z = luaL_checknumber(L, iParam++);
			pWorldWrap->SetUnwrapCenter(FVector2D(x, z));
			return 0;
		}

		//[pWorldMap]
		static int GetWorldUnwrapCenter(lua_State* L)
		{
			int iParam = 1;
			AzureWorldWrap* pWorldWrap = GetWorldWrapPtr(L, iParam);
			FVector2D unwrapCenter = pWorldWrap->GetUnwrapCenter();
			lua_pushnumber(L, unwrapCenter.X);
			lua_pushnumber(L, unwrapCenter.Y);
			return 2;
		}

		//[pWorldMap], x, z => x, z (server 坐标)
		static int WorldWrapPosition(lua_State* L)
		{
			int iParam = 1;
			AzureWorldWrap* pWorldWrap = GetWorldWrapPtr(L, iParam);
			float x = luaL_checknumber(L, iParam++);
			float z = luaL_checknumber(L, iParam++);
			FVector2D wrappedPos = pWorldWrap->WrapPosition(FVector2D(x, z));
			lua_pushnumber(L, wrappedPos.X);
			lua_pushnumber(L, wrappedPos.Y);
			return 2;
		}

		//[pWorldMap], x, z => x, z (server 坐标)
		static int WorldWrapDistance(lua_State* L)
		{
			int iParam = 1;
			AzureWorldWrap* pWorldWrap = GetWorldWrapPtr(L, iParam);
			float x = luaL_checknumber(L, iParam++);
			float z = luaL_checknumber(L, iParam++);
			FVector2D wrappedPos = pWorldWrap->WrapDistance(FVector2D(x, z));
			lua_pushnumber(L, wrappedPos.X);
			lua_pushnumber(L, wrappedPos.Y);
			return 2;
		}

		//[pWorldMap], x, z => x, z (server 坐标)
		static int WorldUnwrapPosition(lua_State* L)
		{
			int iParam = 1;
			AzureWorldWrap* pWorldWrap = GetWorldWrapPtr(L, iParam);
			float x = luaL_checknumber(L, iParam++);
			float z = luaL_checknumber(L, iParam++);
			FVector2D wrappedPos = pWorldWrap->UnwrapPosition(FVector2D(x, z));
			lua_pushnumber(L, wrappedPos.X);
			lua_pushnumber(L, wrappedPos.Y);
			return 2;
		}

		//[pWorldMap], x, z => x, z (server 坐标), xOffset, zOffset
		static int WorldUnwrapPositionAndGetOffset(lua_State* L)
		{
			int iParam = 1;
			AzureWorldWrap* pWorldWrap = GetWorldWrapPtr(L, iParam);
			float x = luaL_checknumber(L, iParam++);
			float z = luaL_checknumber(L, iParam++);
			int xOffset, zOffset;
			FVector2D wrappedPos = pWorldWrap->UnwrapPosition(FVector2D(x, z), xOffset, zOffset);
			lua_pushnumber(L, wrappedPos.X);
			lua_pushnumber(L, wrappedPos.Y);
			lua_pushnumber(L, xOffset);
			lua_pushnumber(L, zOffset);

			return 4;
		}

		static int JudgeIsInsideTerrBuilding(lua_State * L)
		{
			if (!lua_istable(L, 1) && !lua_isuserdata(L, 1)) {
				lua_pushstring(L, "JudgeIsInsideTerrBuilding: param 1 must be vector3(curPos)");
				lua_error(L);
				return 1;
			}
			FVector vCurPos = FLuaVector::Get(L, 1);
			vCurPos = POS_FROM_SERVER(vCurPos);

			if (!lua_isnumber(L, 2)) {
				lua_pushstring(L, "JudgeIsInsideTerrBuilding: param 2 must be float(fJudgeRadius)");
				lua_error(L);
				return 1;
			}
			float fJudgeRadius = (float)lua_tonumber(L, 2) * UE_METRE_TRANS;

			if (!lua_isnumber(L, 3)) {
				lua_pushstring(L, "JudgeIsInsideTerrBuilding: param 3 must be number(fTestUpHei)");
				lua_error(L);
				return 1;
			}
			float fTestUpHei = (float)lua_tonumber(L, 3) * UE_METRE_TRANS;

			if (!lua_isnumber(L, 4)) {
				lua_pushstring(L, "JudgeIsInsideTerrBuilding: param 4 must be number(fYawDeg)");
				lua_error(L);
				return 1;
			}
			float fYawDeg = (float)lua_tonumber(L, 4);

			if (!lua_isnumber(L, 5)) {
				lua_pushstring(L, "JudgeIsInsideTerrBuilding: param 5 must be number(numCollisionSides)");
				lua_error(L);
				return 1;
			}
			int nCollisionSides = (int)lua_tonumber(L, 5);

			if (!lua_isnumber(L, 6)) {
				lua_pushstring(L, "JudgeIsInsideTerrBuilding: param 6 must be number(fTestSidesLen)");
				lua_error(L);
				return 1;
			}
			float fTestSidesLen = (float)lua_tonumber(L, 6) * UE_METRE_TRANS;

			bool bInsideTerrBuilding = AzureUtility::JudgeIsInsideTerrBuilding(vCurPos, fJudgeRadius, fTestUpHei, fYawDeg, nCollisionSides, fTestSidesLen);
			lua_pushboolean(L, bInsideTerrBuilding);
			return 1;
		}

		static int GetSupportPlaneHeight(lua_State * L)
		{
			if (!lua_istable(L, 1) && !lua_isuserdata(L, 1))
			{
				lua_pushstring(L, "GetSupportPlaneHeight: param 1 must be vector3(pos)");
				lua_error(L);
				return 1;
			}
			FVector vPos = FLuaVector::Get(L, 1);
			vPos = POS_FROM_SERVER(vPos);

			if (!lua_isnumber(L, 2))
			{
				lua_pushstring(L, "GetSupportPlaneHeight: param 2 must be float(extraUp)");
				lua_error(L);
				return 1;
			}
			float fExtraUp = (float)lua_tonumber(L, 2);

			float fOrgHei = VEC_UP(vPos);
			VEC_UP(vPos) += fExtraUp * UE_METRE_TRANS;

			if (!lua_isnumber(L, 3))
			{
				lua_pushstring(L, "GetSupportPlaneHeight: param 3 must be number(radius)");
				lua_error(L);
				return 1;
			}
			float fRadius = (float)lua_tonumber(L, 3) * UE_METRE_TRANS;

			float fTraceDownDist = -1.f;
			if (lua_isnumber(L, 4))
			{
				fTraceDownDist = (float)lua_tonumber(L, 4) * UE_METRE_TRANS;
			}

			bool bReturnNormal = false;
			if (lua_isboolean(L, 5))
			{
				bReturnNormal = !!lua_toboolean(L, 5);
			}

			float Height = fOrgHei;

			FHitResult hitInfo;
			bool bRet = AzureUtility::GetSupportPlaneHeight(Height, vPos, fRadius, fTraceDownDist, &hitInfo);

			lua_pushnumber(L, Height / UE_METRE_TRANS);
			lua_pushboolean(L, bRet);

			if (bRet && bReturnNormal)
			{
				FRotator rot = hitInfo.ImpactNormal.ToOrientationRotator();
				//	pitch, yaw, roll
				lua_pushnumber(L, rot.Pitch);
				lua_pushnumber(L, rot.Yaw);
				lua_pushnumber(L, rot.Roll);
				return 5;
			}
			else
				return 2;
		}

		static int GetPreciseSupportHeiByPos(lua_State * L)
		{
			if (!lua_istable(L, 1) && !lua_isuserdata(L, 1)) {
				lua_pushstring(L, "GetPreciseSupportHeiByPos: param 1 must be vector3(curPos)");
				lua_error(L);
				return 1;
			}
			FVector vCurPos = FLuaVector::Get(L, 1);
			vCurPos = POS_FROM_SERVER(vCurPos);

			if (!lua_isnumber(L, 2)) {
				lua_pushstring(L, "GetPreciseSupportHeiByPos: param 2 must be float(ext)");
				lua_error(L);
				return 1;
			}
			float ext = (float)lua_tonumber(L, 2) * UE_METRE_TRANS;

			if (!lua_isnumber(L, 3)) {
				lua_pushstring(L, "GetPreciseSupportHeiByPos: param 3 must be number(fAboveH1)");
				lua_error(L);
				return 1;
			}
			float fAboveH1 = (float)lua_tonumber(L, 3) * UE_METRE_TRANS;

			if (!lua_isnumber(L, 4)) {
				lua_pushstring(L, "GetPreciseSupportHeiByPos: param 4 must be number(fAboveH2)");
				lua_error(L);
				return 1;
			}
			float fAboveH2 = (float)lua_tonumber(L, 4) * UE_METRE_TRANS;

			if (!lua_isnumber(L, 5)) {
				lua_pushstring(L, "GetPreciseSupportHeiByPos: param 5 must be number(fAboveFinale)");
				lua_error(L);
				return 1;
			}
			float fAboveFinal = (float)lua_tonumber(L, 5) * UE_METRE_TRANS;

			float Height = AzureUtility::GetPreciseSupportHeiByPos(vCurPos, ext, fAboveH1, fAboveH2, fAboveFinal) / UE_METRE_TRANS;
			lua_pushnumber(L, Height);
			return 1;
		}

		static int CheckLinePointAvailable(lua_State * L)
		{
			if (!lua_isboolean(L, 1))
			{
				lua_pushstring(L, "CheckLinePointAvailable: param 1 must be bool(bRealReachable)");
				lua_error(L);
				return 1;
			}
			bool bRealReachable = !!lua_toboolean(L, 1);

			if (!lua_istable(L, 2) && !lua_isuserdata(L, 2))
			{
				lua_pushstring(L, "CheckLinePointAvailable: param 2 must be vector3");
				lua_error(L);
				return 1;
			}
			FVector vStart = FLuaVector::Get(L, 2);
			vStart = POS_FROM_SERVER(vStart);

			if (!lua_istable(L, 3) && !lua_isuserdata(L, 3))
			{
				lua_pushstring(L, "CheckLinePointAvailable: param 3 must be vector3");
				lua_error(L);
				return 1;
			}
			FVector vEnd = FLuaVector::Get(L, 3);
			vEnd = POS_FROM_SERVER(vEnd);

			FVector vStop = vStart;

			bool ret = AzureUtility::CheckLinePointAvailable(bRealReachable, vStart, vEnd, vStop);
			vStop = POS_TO_SERVER(vStop);
			lua_pushboolean(L, ret);
			lua_pushnumber(L, vStop.X);
			lua_pushnumber(L, vStop.Z);
			return 3;
		}

		static int CheckArcPointAvailable(lua_State * L)
		{
			if (!lua_istable(L, 1) && !lua_isuserdata(L, 1))
			{
				lua_pushstring(L, "CheckArcPointAvailable: param 1 must be vector3");
				lua_error(L);
				return 1;
			}
			FVector vStart = FLuaVector::Get(L, 1);
			vStart = POS_FROM_SERVER(vStart);
			
			if (!lua_istable(L, 2) && !lua_isuserdata(L, 2))
			{
				lua_pushstring(L, "CheckArcPointAvailable: param 2 must be vector3");
				lua_error(L);
				return 1;
			}
			FVector vEnd = FLuaVector::Get(L, 2);
			vEnd = POS_FROM_SERVER(vEnd);


			if (!lua_istable(L, 3) && !lua_isuserdata(L, 3))
			{
				lua_pushstring(L, "CheckArcPointAvailable: param 3 must be vector3");
				lua_error(L);
				return 1;
			}
			FVector vAxis = FLuaVector::Get(L, 3);
			vAxis = POS_FROM_SERVER(vAxis);

			
			FVector firstInvalidePos;
			bool ret = AzureUtility::CheckArcPointAvailable(vStart, vEnd, vAxis, firstInvalidePos);
			lua_pushboolean(L, ret);
			lua_pushnumber(L, firstInvalidePos.X);
			lua_pushnumber(L, firstInvalidePos.Z);
			return 3;
		}

		static int GetDestJumpPos(lua_State * L)
		{
			if (!lua_istable(L, 1) && !lua_isuserdata(L, 1))
			{
				lua_pushstring(L, "GetDestJumpPos: param 1 must be vector3(vCurPos)");
				lua_error(L);
				return 1;
			}

			if (!lua_istable(L, 2) && !lua_isuserdata(L, 2))
			{
				lua_pushstring(L, "GetDestJumpPos: param 2 must be vector3(vSpeedH)");
				lua_error(L);
				return 1;
			}

			if (!lua_isnumber(L, 3))
			{
				lua_pushstring(L, "GetDestJumpPos: param 3 must be float(total_time)");
				lua_error(L);
				return 1;
			}

			if (!lua_isnumber(L, 4))
			{
				lua_pushstring(L, "GetDestJumpPos: param 4 must be float(upward_time)");
				lua_error(L);
				return 1;
			}

			if (!lua_isnumber(L, 5))
			{
				lua_pushstring(L, "GetDestJumpPos: param 5 must be float(up_height)");
				lua_error(L);
				return 1;
			}

			if (!lua_isnumber(L, 6)) {
				lua_pushstring(L, "GetDestJumpPos: param 6 must be float(down_height)");
				lua_error(L);
				return 1;
			}

			if (!lua_isnumber(L, 7)) {
				lua_pushstring(L, "GetDestJumpPos: param 7 must be float(fSplitTime)");
				lua_error(L);
				return 1;
			}

			FVector vCurPos = FLuaVector::Get(L, 1);
			vCurPos = POS_FROM_SERVER(vCurPos);
			FVector vSpeedH = FLuaVector::Get(L, 2);
			vSpeedH = POS_FROM_SERVER(vSpeedH);
			float total_time = (float)lua_tonumber(L, 3);
			float upward_time = (float)lua_tonumber(L, 4);
			float up_height = (float)lua_tonumber(L, 5) * UE_METRE_TRANS;
			float down_height = (float)lua_tonumber(L, 6) * UE_METRE_TRANS;
			float fSplitTime = (float)lua_tonumber(L, 7);

			float retUpHei = up_height;
			float retUpTime = upward_time;
			float retTotalTime = total_time;
			FVector vDestPos = AzureUtility::GetDestJumpPos(vCurPos, vSpeedH, total_time, upward_time, up_height, down_height, fSplitTime, retUpHei, retUpTime, retTotalTime);
			vDestPos = POS_TO_SERVER(vDestPos);
			lua_pushnumber(L, vDestPos.X);
			lua_pushnumber(L, vDestPos.Y);
			lua_pushnumber(L, vDestPos.Z);
			lua_pushnumber(L, retUpHei / UE_METRE_TRANS);
			lua_pushnumber(L, retUpTime);
			lua_pushnumber(L, retTotalTime);
			return 6;
		}

		static int GetDestPosHeightFromCurPos(lua_State * L)
		{
			int pram_count = lua_gettop(L);
			//	GetDestPosHeightFromCurPos(Vector3 vDestPos, Vector3 vCurPos, float fSplitDistH, float ext = 0, float fAboveH1 = 1.8f, float fAboveH2 = 3.8f, float fAboveFinal = 50.0f)

			if (!lua_istable(L, 1) && !lua_isuserdata(L, 1)) {
				lua_pushstring(L, "GetDestPosHeightFromCurPos: param 1 must be vector3(vDestPos)");
				lua_error(L);
				return 1;
			}
			FVector vDestPos = FLuaVector::Get(L, 1);
			vDestPos = POS_FROM_SERVER(vDestPos);
			if (!lua_istable(L, 2) && !lua_isuserdata(L, 2)) {
				lua_pushstring(L, "GetDestPosHeightFromCurPos: param 2 must be vector3(vCurPos)");
				lua_error(L);
				return 1;
			}
			FVector vCurPos = FLuaVector::Get(L, 2);
			vCurPos = POS_FROM_SERVER(vCurPos);
			if (!lua_isnumber(L, 3)) {
				lua_pushstring(L, "GetDestPosHeightFromCurPos: param 3 must be float(fSplitDistH)");
				lua_error(L);
				return 1;
			}
			float fSplitDistH = (float)lua_tonumber(L, 3) * UE_METRE_TRANS;

			float ext = 0;
			if (pram_count >= 4) {
				if (!lua_isnumber(L, 4)) {
					lua_pushstring(L, "GetDestPosHeightFromCurPos: param 4 must be float(ext)");
					lua_error(L);
					return 1;
				}
				ext = (float)lua_tonumber(L, 4) * UE_METRE_TRANS;
			}

			float fAboveH1 = 1.8f * UE_METRE_TRANS;
			if (pram_count >= 5) {
				if (!lua_isnumber(L, 5)) {
					lua_pushstring(L, "GetDestPosHeightFromCurPos: param 5 must be number(fAboveH1)");
					lua_error(L);
					return 1;
				}
				fAboveH1 = (float)lua_tonumber(L, 5);
			}

			float fAboveH2 = 3.8f * UE_METRE_TRANS;
			if (pram_count >= 6) {
				if (!lua_isnumber(L, 6)) {
					lua_pushstring(L, "GetDestPosHeightFromCurPos: param 6 must be number(fAboveH2)");
					lua_error(L);
					return 1;
				}
				fAboveH2 = (float)lua_tonumber(L, 6);
			}

			float fAboveFinal = 50.0f * UE_METRE_TRANS;
			if (pram_count >= 7) {
				if (!lua_isnumber(L, 7)) {
					lua_pushstring(L, "GetDestPosHeightFromCurPos: param 7 must be number(fAboveFinale)");
					lua_error(L);
					return 1;
				}
				fAboveFinal = (float)lua_tonumber(L, 7);
			}

			float Height = AzureUtility::GetDestPosHeightFromCurPos(vDestPos, vCurPos, fSplitDistH, ext, fAboveH1, fAboveH2, fAboveFinal) / UE_METRE_TRANS;
			lua_pushnumber(L, Height);
			return 1;
		}

		static int FlashMoveOnDir(lua_State * L)
		{
			if (!lua_istable(L, 1) && !lua_isuserdata(L, 1))
			{
				lua_pushstring(L, "FlashMoveOnDir: param 1 must be vector3(vOrigStart)");
				lua_error(L);
				return 1;
			}
			FVector vOrigStart = FLuaVector::Get(L, 1);
			vOrigStart = POS_FROM_SERVER(vOrigStart);

			if (!lua_isboolean(L, 2))
			{
				lua_pushstring(L, "FlashMoveOnDir: param 2 must be boolean(bForceDestOnGround)");
				lua_error(L);
				return 1;
			}
			bool bForceDestOnGround = !!lua_toboolean(L, 2);

			if (!lua_isboolean(L, 3))
			{
				lua_pushstring(L, "FlashMoveOnDir: param 3 must be boolean(bCheckReachableOrMovable)");
				lua_error(L);
				return 1;
			}
			bool bCheckReachableOrMovable = !!lua_toboolean(L, 3);

			if (!lua_istable(L, 4) && !lua_isuserdata(L, 4))
			{
				lua_pushstring(L, "FlashMoveOnDir: param 4 must be vector3(vDir)");
				lua_error(L);
				return 1;
			}
			FVector vDir = FLuaVector::Get(L, 4);
			vDir = DIR_FROM_SERVER(vDir);

			if (!lua_isnumber(L, 5))
			{
				lua_pushstring(L, "FlashMoveOnDir: param 5 must be float(fDist)");
				lua_error(L);
				return 1;
			}
			float fDist = lua_tonumber(L, 5) * UE_METRE_TRANS;

			if (!lua_isboolean(L, 6))
			{
				lua_pushstring(L, "FlashMoveOnDir: param 6 must be boolean(bDist3D)");
				lua_error(L);
				return 1;
			}
			bool bDist3D = !!lua_toboolean(L, 6);

			if (!lua_isnumber(L, 7))
			{
				lua_pushstring(L, "FlashMoveOnDir: param 7 must be float(fStepDistH)");
				lua_error(L);
				return 1;
			}
			float fStepDistH = lua_tonumber(L, 7) * UE_METRE_TRANS;

			if (!lua_isnumber(L, 8))
			{
				lua_pushstring(L, "FlashMoveOnDir: param 8 must be float(fStepRaiseHei)");
				lua_error(L);
				return 1;
			}
			float fStepRaiseHei = lua_tonumber(L, 8) * UE_METRE_TRANS;

			if (!lua_isnumber(L, 9))
			{
				lua_pushstring(L, "FlashMoveOnDir: param 9 must be float(fMaxTotalRaiseHei)");
				lua_error(L);
				return 1;
			}
			float fMaxTotalRaiseHei = lua_tonumber(L, 9) * UE_METRE_TRANS;

			if (!lua_isnumber(L, 10))
			{
				lua_pushstring(L, "FlashMoveOnDir: param 10 must be float(fTraceDownDist)");
				lua_error(L);
				return 1;
			}
			float fTraceDownDist = lua_tonumber(L, 10) * UE_METRE_TRANS;

			if (!lua_isnumber(L, 11))
			{
				lua_pushstring(L, "FlashMoveOnDir: param 11 must be float(fStepFallHeight)");
				lua_error(L);
				return 1;
			}
			float fStepFallHeight = lua_tonumber(L, 11) * UE_METRE_TRANS;

			FVector vDestPos;
			float fMoveDist = AzureUtility::FlashMoveOnDir(vDestPos, vOrigStart,
				bForceDestOnGround, bCheckReachableOrMovable,
				vDir, fDist, bDist3D,
				fStepDistH, fStepRaiseHei, fMaxTotalRaiseHei, fTraceDownDist, fStepFallHeight);
			
			lua_pushnumber(L, fMoveDist/UE_METRE_TRANS);

			vDestPos = POS_TO_SERVER(vDestPos);
			lua_pushnumber(L, vDestPos.X);
			lua_pushnumber(L, vDestPos.Y);
			lua_pushnumber(L, vDestPos.Z);
			return 4;
		}
		
		static int SetHudTextSegments(lua_State * L)
		{
			if (!AAzureEntryPoint::Instance)
				return 0;

			AzureHudTextMan *pMan = AAzureEntryPoint::Instance->GetHudTextMan();
			if (!pMan)
			{
				lua_pushstring(L, "SetHudTextSegments: ERROR!!");
				lua_error(L);
				return 1;
			}
			if (!lua_istable(L, 2))
			{
				lua_pushstring(L, "SetHudTextSegments: Sencond Parameter is not table!!");
				lua_error(L);
				return 1;
			}
			FString moveType = UTF8_TO_TCHAR(luaL_checkstring(L, 1));

			UAzureMultiSegments *segs = new UAzureMultiSegments();
			lua_pushnil(L);
			while (lua_next(L, 2) != 0)
			{
				if (lua_istable(L, -1))
				{
					UAzureMultiSegment seg;

					lua_getfield(L, -1, "duration");
					seg.duration = (float)lua_tonumber(L, -1);
					lua_pop(L, 1);

					lua_getfield(L, -1, "accelerationY");
					seg.accelerationY = (float)lua_tonumber(L, -1);
					lua_pop(L, 1);

					lua_getfield(L, -1, "scaleSpd");
					seg.scaleSpd = (float)lua_tonumber(L, -1);
					lua_pop(L, 1);

					lua_getfield(L, -1, "alphaSpd");
					seg.alphaSpd = (float)lua_tonumber(L, -1);
					lua_pop(L, 1);

					segs->segs.Add(seg);
				}
				lua_pop(L, 1);
			}

			if (!pMan->AddTextSegments(moveType, segs))
			{
				delete segs;
			}
			return 0;
		}

		static void _GetHudTextSegmentFloatKeys(lua_State * L , TArray<UAzureMultiSegmentFloatKey>	&segKeys)
		{
			lua_pushnil(L);
			while (lua_next(L , -2) != 0)
			{
				if (lua_istable(L , -1))
				{
					UAzureMultiSegmentFloatKey key;
					lua_getfield(L , -1 , "time");
					if (lua_isnumber(L , -1))
					{
						key.time = (float)lua_tonumber(L , -1);
					}
					lua_pop(L , 1);

					lua_getfield(L , -1 , "value");
					if (lua_isnumber(L , -1))
					{
						key.fValue = (float)lua_tonumber(L , -1);
					}
					lua_pop(L , 1);

					segKeys.Add(key);
				}
				lua_pop(L , 1);
			}

		}
		static void _GetHudTextSegmentStringKeys(lua_State * L , TArray<UAzureMultiSegmentStringKey>	&segKeys)
		{
			lua_pushnil(L);
			while (lua_next(L , -2) != 0)
			{
				if (lua_istable(L , -1))
				{
					UAzureMultiSegmentStringKey key;
					lua_getfield(L , -1 , "time");
					if (lua_isnumber(L , -1))
					{
						key.time = (float)lua_tonumber(L , -1);
					}
					lua_pop(L , 1);

					lua_getfield(L , -1 , "value");
					if (lua_isstring(L , -1))
					{
						key.strValue = lua_tostring(L , -1);
					}
					lua_pop(L , 1);

					segKeys.Add(key);
				}
				lua_pop(L , 1);
			}
		}
		static int SetHudTextSegmentKeys(lua_State * L)
		{
			if (!AAzureEntryPoint::Instance)
				return 0;

			AzureHudTextMan *pMan = AAzureEntryPoint::Instance->GetHudTextMan();
			if (!pMan)
			{
				lua_pushstring(L , "SetHudTextSegmentKeys: ERROR!!");
				lua_error(L);
				return 1;
			}
			if (!lua_istable(L , 2))
			{
				lua_pushstring(L , "SetHudTextSegmentKeys: Sencond Parameter is not table!!");
				lua_error(L);
				return 1;
			}
			FString moveType = UTF8_TO_TCHAR(luaL_checkstring(L , 1));

			UAzureMultiSegmentTimeLine *timeLine = new UAzureMultiSegmentTimeLine();

			//------------------------------------------------------------------------------
			lua_getfield(L , 2 , "duration");
			if (lua_isnumber(L , -1))
			{
				timeLine->endingTime = lua_tonumber(L,-1);
			}
			lua_pop(L , 1);
			lua_getfield(L , 2 , "verbatim");
			if (lua_isboolean(L , -1))
			{
				timeLine->verbatim = lua_toboolean(L , -1);
			}
			lua_pop(L , 1);
			lua_getfield(L , 2 , "verbatimDeltaTime");
			if (lua_isnumber(L , -1))
			{
				timeLine->verbatimDeltaTime = lua_tonumber(L , -1);
			}
			lua_pop(L , 1);
			lua_getfield(L , 2 , "spacing");
			if (lua_isnumber(L , -1))
			{
				timeLine->spacing = lua_tonumber(L , -1);
			}
			lua_pop(L , 1);
			//------------------------------------------------------------------------------
			//------------------------------------------------------------------------------
			//------------------------------------------------------------------------------
			lua_getfield(L , 2 , "keys");
			if (lua_istable(L , -1))
			{
				lua_getfield(L , -1 , "offset_x");
				if (lua_istable(L , -1))
				{
					_GetHudTextSegmentFloatKeys(L , timeLine->FKs_X.segKeys);
				}
				lua_pop(L , 1);
				//------------------------------------------------------------------------------
				lua_getfield(L , -1 , "offset_y");
				if (lua_istable(L , -1))
				{
					_GetHudTextSegmentFloatKeys(L , timeLine->FKs_Y.segKeys);
				}
				lua_pop(L , 1);
				//------------------------------------------------------------------------------
				lua_getfield(L , -1 , "scale");
				if (lua_istable(L , -1))
				{
					_GetHudTextSegmentFloatKeys(L , timeLine->FKs_Scale.segKeys);
				}
				lua_pop(L , 1);
				//------------------------------------------------------------------------------
				lua_getfield(L , -1 , "alpha");
				if (lua_istable(L , -1))
				{
					_GetHudTextSegmentFloatKeys(L , timeLine->FKs_Alpha.segKeys);
				}
				lua_pop(L , 1);
				//------------------------------------------------------------------------------
				lua_getfield(L , -1 , "event");
				if (lua_istable(L , -1))
				{
					_GetHudTextSegmentStringKeys(L , timeLine->SKs_Event.segKeys);
				}
				lua_pop(L , 1);
				
			}
			lua_pop(L , 1);

			//------------------------------------------------------------------------------
			//------------------------------------------------------------------------------
			//------------------------------------------------------------------------------

			if (!pMan->AddTextSegmentTimeLine(moveType , timeLine))
			{
				delete timeLine;
			}
			return 0;
		}

		static int SetMultiSegKeysHudText(lua_State * L)
		{
			if (!AAzureEntryPoint::Instance)
				return 0;

			AActor* obj = Cast<AActor>(wLua::FLuaUtils::GetUObject(L , 1 , "Actor"));
			AzureHudTextMan *pMan = AAzureEntryPoint::Instance->GetHudTextMan();
			if (obj == nullptr)
			{
				lua_pushstring(L , "SetMultiSegKeysHudText: obj == NULL!!!");
				lua_error(L);
				return 1;
			}
			if (pMan == nullptr)
			{
				lua_pushstring(L , "SetMultiSegKeysHudText: pMan == NULL!!!");
				lua_error(L);
				return 1;
			}

			FString moveType		= UTF8_TO_TCHAR(luaL_checkstring(L , 2));
			FString InText			= UTF8_TO_TCHAR(luaL_checkstring(L , 3));
			FString fontName		= UTF8_TO_TCHAR(luaL_checkstring(L , 4));
			int fontSize			= (int)(luaL_checkinteger(L , 5));
			float scale				= (float)(luaL_checknumber(L , 6));
			float alpha				= (float)(luaL_checknumber(L , 7));
			int txt_ZOrder			= (int)(luaL_checkinteger(L, 8));
			int effect_ZOrder		= (int)(luaL_checkinteger(L, 9));

			FVector worldOffset		= (wLua::FLuaVector::Get(L , 10));
			FVector2D screenOffset	= (wLua::FLuaVector2D::Get(L , 11));
			pMan->SetMultiSegmentKeysHudText(obj , InText , moveType , fontName , fontSize , scale , alpha , worldOffset , screenOffset
				, txt_ZOrder , effect_ZOrder);
			return 0;
		}


		static int SetMultiSegsHudText(lua_State * L)
		{
			if (!AAzureEntryPoint::Instance)
				return 0;

			AActor* obj = Cast<AActor>(wLua::FLuaUtils::GetUObject(L, 1, "Actor"));
			AzureHudTextMan *pMan = AAzureEntryPoint::Instance->GetHudTextMan();
			if (!obj || !pMan)
			{
				lua_pushstring(L, "SetMultiSegsHudText: ERROR!!");
				lua_error(L);
				return 1;
			}
			FString moveType = UTF8_TO_TCHAR(luaL_checkstring(L, 2));
			FString InText = UTF8_TO_TCHAR(luaL_checkstring(L, 3));
			FString fontName = UTF8_TO_TCHAR(luaL_checkstring(L, 4));
			int fontSize = (int)(luaL_checkinteger(L, 5));
			float scale = (float)(luaL_checknumber(L, 6));
			float alpha = (float)(luaL_checknumber(L, 7));
			FVector2D velocity = (wLua::FLuaVector2D::Get(L, 8));
			FVector worldOffset = (wLua::FLuaVector::Get(L, 9));
			FVector2D screenOffset = (wLua::FLuaVector2D::Get(L, 10));
			pMan->SetMultiSegmentsHudText(obj, InText, moveType, fontName, fontSize, scale, alpha, velocity, worldOffset, screenOffset);
			return 0;
		}
		
		static int SetHudText(lua_State * L)
		{
			if (!AAzureEntryPoint::Instance)
				return 0;

			AActor* obj = Cast<AActor>(wLua::FLuaUtils::GetUObject(L, 1, "Actor"));
			AzureHudTextMan *pMan = AAzureEntryPoint::Instance->GetHudTextMan();
			if (!obj || !pMan)
			{
				lua_pushstring(L, "SetHudText: ERROR!!");
				lua_error(L);
				return 1;
			}
			FString InText = UTF8_TO_TCHAR(luaL_checkstring(L, 2));
			FString fontName = UTF8_TO_TCHAR(luaL_checkstring(L, 3));
			int fontSize = (int)(luaL_checkinteger(L, 4));
			float lifeTime = (float)(luaL_checknumber(L, 5));
			FVector2D velocity = (wLua::FLuaVector2D::Get(L, 6));
			float moveTime = (float)(luaL_checknumber(L, 7));
			float scaleFrom = (float)(luaL_checknumber(L, 8));
			float scaleFromTime = (float)(luaL_checknumber(L, 9));
			float scaleTo = (float)(luaL_checknumber(L, 10));
			float scaleToTime = (float)(luaL_checknumber(L, 11));
			FVector worldOffset = (wLua::FLuaVector::Get(L, 12));
			FVector2D screenOffset = (wLua::FLuaVector2D::Get(L, 13));
			pMan->SetHudText(obj, InText, fontName, fontSize, lifeTime, velocity, moveTime, scaleFrom, scaleFromTime, scaleTo, scaleToTime, worldOffset, screenOffset);
			return 0;
		}

		static int ActiveHudText(lua_State * L)
		{
			if (!AAzureEntryPoint::Instance)
				return 0;

			AzureHudTextMan *pMan = AAzureEntryPoint::Instance->GetHudTextMan();
			if (!pMan)
			{
				lua_pushstring(L, "ActiveHudText: ERROR!!");
				lua_error(L);
				return 1;
			}

			bool bAcitve = !!lua_toboolean(L, 1);
			pMan->SetActive(bAcitve);
			return 0;
		}

		static int AddOneScreenBullet(lua_State * L)
		{
			if (!AAzureEntryPoint::Instance)
				return 0;

			AzureScreenBulletMan *pMan = AAzureEntryPoint::Instance->GetScreenBulletMan();
			if (!pMan)
			{
				lua_pushstring(L, "AddOneScreenBullet: ERROR!!");
				lua_error(L);
				return 1;
			}
			FText InText = FText::FromString(UTF8_TO_TCHAR(luaL_checkstring(L, 1)));
			int fontSize = (int)(luaL_checkinteger(L, 2));
			AzureScreenBulletMan::BULLET_TYPE bullettype = (AzureScreenBulletMan::BULLET_TYPE)(luaL_checkinteger(L, 3));
			float lifeTime = (float)(luaL_checknumber(L, 4)); //0 代表根据文字长度自动确定从右移动到左的时间
			FVector2D velocity = (wLua::FLuaVector2D::Get(L, 5));
			int tracklimit = (int)(luaL_checkinteger(L, 6));
			bool bForce = !!lua_toboolean(L, 7);
			pMan->AddOneScreenBulletText(InText, fontSize, bullettype, lifeTime, velocity, tracklimit, bForce);
			return 0;
		}

		static int AddOneCGBulletText(lua_State * L)
		{
			if (!AAzureEntryPoint::Instance)
				return 0;

			AzureScreenBulletMan *pMan = AAzureEntryPoint::Instance->GetScreenBulletMan();
			if (!pMan)
			{
				lua_pushstring(L, "AddOneCGBulletText: ERROR!!");
				lua_error(L);
				return 1;
			}
			FText InText = FText::FromString(UTF8_TO_TCHAR(luaL_checkstring(L, 1)));
			int fontSize = (int)(luaL_checkinteger(L, 2));
			AzureScreenBulletMan::BULLET_TYPE bullettype = (AzureScreenBulletMan::BULLET_TYPE)(luaL_checkinteger(L, 3));
			float lifeTime = (float)(luaL_checknumber(L, 4)); //0 代表根据文字长度自动确定从右移动到左的时间
			FVector2D velocity = (wLua::FLuaVector2D::Get(L, 5));
			float startTime = (float)(luaL_checknumber(L, 6));
			bool bForceShow = !!lua_toboolean(L, 7);
			pMan->AddOneCGBulletText(InText, fontSize, bullettype, lifeTime, velocity, startTime, bForceShow);
			return 0;
		}

		static int StartCGBullet(lua_State * L)
		{
			if (!AAzureEntryPoint::Instance)
				return 0;

			AzureScreenBulletMan *pMan = AAzureEntryPoint::Instance->GetScreenBulletMan();
			if (!pMan)
			{
				lua_pushstring(L, "StartCGBullet: ERROR!!");
				lua_error(L);
				return 1;
			}
			float interval = (float)(luaL_checknumber(L, 1));
			float startTime = (float)(luaL_checknumber(L, 2));
			pMan->StartCG(interval, startTime);
			return 0;
		}

		static int StopCGBullet(lua_State * L)
		{
			if (!AAzureEntryPoint::Instance)
				return 0;

			AzureScreenBulletMan *pMan = AAzureEntryPoint::Instance->GetScreenBulletMan();
			if (!pMan)
			{
				lua_pushstring(L, "StopCGBullet: ERROR!!");
				lua_error(L);
				return 1;
			}
			bool bRemove = !!lua_toboolean(L, 1);
			pMan->StopCG(bRemove);
			return 0;
		}
		static int SetCGTrackLimit(lua_State * L)
		{
			if (!AAzureEntryPoint::Instance)
				return 0;

			AzureScreenBulletMan *pMan = AAzureEntryPoint::Instance->GetScreenBulletMan();
			if (!pMan)
			{
				lua_pushstring(L, "SetCGTrackLimit: ERROR!!");
				lua_error(L);
				return 1;
			}
			int limit = (int)(luaL_checkinteger(L, 1));
			pMan->SetCGTrackLimit(limit);
			return 0;
		}


		static int ActiveCGBullet(lua_State * L)
		{
			if (!AAzureEntryPoint::Instance)
				return 0;

			AzureScreenBulletMan *pMan = AAzureEntryPoint::Instance->GetScreenBulletMan();
			if (!pMan)
			{
				lua_pushstring(L, "ActiveCGBullet: ERROR!!");
				lua_error(L);
				return 1;
			}
			bool bAcitve = !!lua_toboolean(L, 1);
			pMan->SetCGActive(bAcitve);
			return 0;
		}

		static int ActiveScreenBullet(lua_State * L)
		{
			if (!AAzureEntryPoint::Instance)
				return 0;

			AzureScreenBulletMan *pMan = AAzureEntryPoint::Instance->GetScreenBulletMan();
			if (!pMan)
			{
				lua_pushstring(L, "ActiveScreenBullet: ERROR!!");
				lua_error(L);
				return 1;
			}
			bool bAcitve = !!lua_toboolean(L, 1);
			pMan->SetActive(bAcitve);
			return 0;
		}

		static int GetCGPassTime(lua_State * L)
		{
			if (!AAzureEntryPoint::Instance)
				return 0;

			AzureScreenBulletMan *pMan = AAzureEntryPoint::Instance->GetScreenBulletMan();
			if (!pMan)
			{
				lua_pushstring(L, "ActiveCGBullet: ERROR!!");
				lua_error(L);
				return 1;
			}

			lua_pushnumber(L, pMan->GetCGPassTime());
			return 1;
		}

		static int EnableParticleEmitter(lua_State *L)
		{
			wLua::LuaUObjectUserData* userdata = nullptr;
			UParticleSystemComponent* obj = Cast<UParticleSystemComponent>(wLua::FLuaUtils::GetUObject(L, 1, "ParticleSystemComponent", &userdata));
			if (!obj)
			{
				astring msg = astring("EnableParticleEmitter: param 1 must be UParticleSystemComponent ") + astring(userdata ? (userdata->uobj ? "has uobject" : "uobject is null") : "no userdata");
				lua_pushstring(L, msg.c_str());
				lua_error(L);
				return 1;
			}
			FName EmitterName = FName(UTF8_TO_TCHAR(luaL_checkstring(L, 2)));
			bool bNewEnableState = !!(lua_toboolean(L, 3));

			obj->ForceAsyncWorkCompletion(UParticleSystemComponent::EForceAsyncWorkCompletion::ENSURE_AND_STALL);

			for (int32 EmitterIndex = 0; EmitterIndex < obj->EmitterInstances.Num(); ++EmitterIndex)
			{
				FParticleEmitterInstance* EmitterInst = obj->EmitterInstances[EmitterIndex];
				if (EmitterInst && EmitterInst->SpriteTemplate)
				{
					if (EmitterInst->SpriteTemplate->EmitterName == EmitterName)
					{
						EmitterInst->bEnabled = bNewEnableState;
					}
				}
			}
			return 0;
		}

		static int RemapMaterialQualityLevel(lua_State *L)
		{
			EMaterialQualityLevel::Type matQualityLevel = (EMaterialQualityLevel::Type)lua_tointeger(L, 1);
			EMaterialQualityLevel::Type type = UPrimitiveComponent::RemapQualityLevel(matQualityLevel);
			lua_pushnumber(L, type);
			return 1;
		}

		/*static int CopyPoseFromOther(lua_State* L)
		{
			UObject* ObjDst = wLua::FLuaUtils::GetUObject(L, 1, "SkeletalMeshComponent");
			USkeletalMeshComponent* pSkeletalMeshComponenDst = Cast<USkeletalMeshComponent>(ObjDst);
			UObject* ObjSrc = wLua::FLuaUtils::GetUObject(L, 2, "SkeletalMeshComponent");
			USkeletalMeshComponent* pSkeletalMeshComponenSrc = Cast<USkeletalMeshComponent>(ObjSrc);

			FPoseSnapshot Snapshot;
			pSkeletalMeshComponenSrc->SnapshotPose(Snapshot);
		}*/

		static int DisableRootMotion(lua_State* L)
		{
			UAnimInstance* obj = Cast<UAnimInstance>(wLua::FLuaUtils::GetUObject(L, 1, "AnimInstance"));
			if (!obj)
			{
				LuaStatic::traceback(L, "DisableRootMotion: param #1 is null or not type of AnimInstance!");
				lua_error(L);
				return 1;
			}

			UAnimMontage* mon = Cast<UAnimMontage>(wLua::FLuaUtils::GetUObject(L, 2, "AnimMontage"));
			if (!mon)
			{
				LuaStatic::traceback(L, "DisableRootMotion: param #2 is null or not type of AnimMontage!");
				lua_error(L);
				return 1;
			}

			FAnimMontageInstance *animMon = obj->GetActiveInstanceForMontage(mon);
			if(animMon)
				animMon->PushDisableRootMotion();
			return 0;
		}

		static int EnableRootMotion(lua_State* L)
		{
			UAnimInstance* obj = Cast<UAnimInstance>(wLua::FLuaUtils::GetUObject(L, 1, "AnimInstance"));
			if (!obj)
			{
				LuaStatic::traceback(L, "EnableRootMotion: param #1 is null or not type of AnimInstance!");
				lua_error(L);
				return 1;
			}

			UAnimMontage* mon = Cast<UAnimMontage>(wLua::FLuaUtils::GetUObject(L, 2, "AnimMontage"));
			if (!mon)
			{
				LuaStatic::traceback(L, "EnableRootMotion: param #2 is null or not type of AnimMontage!");
				lua_error(L);
				return 1;
			}

			FAnimMontageInstance *animMon = obj->GetActiveInstanceForMontage(mon);
			if (animMon) {
				while (animMon->IsRootMotionDisabled()) {
					animMon->PopDisableRootMotion();
				}
			}
			return 0;
		}

		static int POSEABLE_MESH_ID = 0;
		static int GenerateGhostMesh(lua_State* L)
		{
			int curIdx = 1;
			AActor* obj = Cast<AActor>(wLua::FLuaUtils::GetUObject(L, curIdx, "Actor"));
			if (!obj)
			{
				LuaStatic::traceback(L);
				lua_error(L);
				return 1;
			}

			++curIdx;
			luaL_checktype(L, curIdx, LUA_TTABLE);
			int len = lua_objlen(L, curIdx);

			TArray<USkeletalMeshComponent*> meshCompArr;
			meshCompArr.Reserve(len);

			for (int i = 0; i < len; ++i)
			{
				lua_rawgeti(L, curIdx, i + 1);
				USkeletalMeshComponent* skel = Cast<USkeletalMeshComponent>(wLua::FLuaUtils::GetUObject(L, -1, "SkeletalMeshComponent"));
				if (skel)
					meshCompArr.Add(skel);
				lua_pop(L, 1);
			}
			
			if (meshCompArr.Num() <= 0)
				return 0;

			++curIdx;
			int minLOD = 0;
			if (lua_isnumber(L, curIdx))
				minLOD = (int)lua_tonumber(L, curIdx);

			TArray<UPoseableMeshComponent*> ghostCompArr;
			for (int i = 0; i < meshCompArr.Num(); ++i)
			{
				FString strName = TEXT("GhostPoseMesh_") + FString::FormatAsNumber(++POSEABLE_MESH_ID);
				UPoseableMeshComponent * newPose = NewObject<UPoseableMeshComponent>(obj, *strName);
				newPose->CopyPropertiesFromSkeletalComponent(meshCompArr[i]);
				newPose->SetMinLOD(minLOD);
				newPose->SetCastShadow(false);
				newPose->SetSingleSampleShadowFromStationaryLights(false);
				newPose->RegisterComponent();

				USkeletalMeshComponent * MasterCom = Cast<USkeletalMeshComponent>(meshCompArr[i]->MasterPoseComponent);
				if (MasterCom)
				{
					//	Slave: 
					newPose->SetWorldTransform(meshCompArr[i]->GetComponentTransform());
					newPose->SetSkeletalMesh(meshCompArr[i]->SkeletalMesh, false);
					newPose->CopyPoseFromSkeletalComponent(MasterCom);

#if 0
					if (!AAzureEntryPoint::Instance)
						return 0;

					UWorld* pWorld = AAzureEntryPoint::Instance->GetWorld();
					const FBoxSphereBounds& orgBounds = meshCompArr[i]->Bounds;
					DrawDebugSphere(pWorld, orgBounds.Origin, orgBounds.SphereRadius, 10, FColor::White, true, 10);

					const FBoxSphereBounds& newBounds = newPose->Bounds;
					DrawDebugSphere(pWorld, newBounds.Origin, newBounds.SphereRadius, 20, FColor::Red, true, 10);
#endif
				}
				else
				{
					//	Not Slave: 不要设置WorldTrans(不准)，由客户端进行Attach
					//	但第一个默认是主Skel，需要设置WorldTrans
					if (i == 0)
					{
						AzureUtility::AddActorComponent(obj, newPose);
						newPose->SetWorldTransform(meshCompArr[i]->GetComponentTransform());
					}

					newPose->SetSkeletalMesh(meshCompArr[i]->SkeletalMesh, false);
					newPose->CopyPoseFromSkeletalComponent(meshCompArr[i]);
				}

				ghostCompArr.Add(newPose);
			}

			//	return
			lua_newtable(L);
			for (int i=0; i<ghostCompArr.Num(); ++i)
			{
				wLua::FLuaUtils::ReturnUObject(L, ghostCompArr[i]);
				lua_rawseti(L, -2, i+1);
			}
			return 1;
		}

		static int ExportTextureRenderTargetToPNG(lua_State* L)
		{
			const FString strPath = UTF8_TO_TCHAR(lua_tostring(L, 1));
			UTextureRenderTarget2D* TextureRenderTarget = Cast<UTextureRenderTarget2D>(wLua::FLuaUtils::GetUObject(L, 2, "TextureRenderTarget2D"));
			if (!TextureRenderTarget)
				return 0;
			FArchive* Ar = IFileManager::Get().CreateFileWriter(*strPath);

			if (Ar)
			{
				FBufferArchive Buffer;

				bool bSuccess = false;
				if (TextureRenderTarget->RenderTargetFormat == RTF_RGBA16f)
				{
					bSuccess = FImageUtils::ExportRenderTarget2DAsHDR(TextureRenderTarget, Buffer);
				}
				else
				{
					bSuccess = FImageUtils::ExportRenderTarget2DAsPNG(TextureRenderTarget, Buffer);
				}

				if (bSuccess)
				{
					Ar->Serialize(const_cast<uint8*>(Buffer.GetData()), Buffer.Num());
				}

				delete Ar;
			}
			else
			{
				UE_LOG(LogAzure, Error, TEXT("ExportTextureToTGA Error exporting %s"), *strPath);
			}
			return 0;
		}

#pragma pack(push,1)
		struct _FTGAFileHeader
		{
			uint8 IdFieldLength;
			uint8 ColorMapType;
			uint8 ImageTypeCode;		// 2 for uncompressed RGB format
			uint16 ColorMapOrigin;
			uint16 ColorMapLength;
			uint8 ColorMapEntrySize;
			uint16 XOrigin;
			uint16 YOrigin;
			uint16 Width;
			uint16 Height;
			uint8 BitsPerPixel;
			uint8 ImageDescriptor;
			friend FArchive& operator<<(FArchive& Ar, _FTGAFileHeader& H)
			{
			Ar << H.IdFieldLength << H.ColorMapType << H.ImageTypeCode;
			Ar << H.ColorMapOrigin << H.ColorMapLength << H.ColorMapEntrySize;
			Ar << H.XOrigin << H.YOrigin << H.Width << H.Height << H.BitsPerPixel;
			Ar << H.ImageDescriptor;
			return Ar;
			}
		};

		struct _FTGAFileFooter
		{
			uint32 ExtensionAreaOffset;
			uint32 DeveloperDirectoryOffset;
			uint8 Signature[16];
			uint8 TrailingPeriod;
			uint8 NullTerminator;
		};

#pragma pack(pop)

		static int ExportTextureRenderTargetTGA(lua_State* L)
		{
			const FString strPath = UTF8_TO_TCHAR(lua_tostring(L, 1));
			UTextureRenderTarget2D* TextureRenderTarget = Cast<UTextureRenderTarget2D>(wLua::FLuaUtils::GetUObject(L, 2, "TextureRenderTarget2D"));
			if (!TextureRenderTarget|| TextureRenderTarget->GetFormat() != PF_B8G8R8A8)
				return 0;

			const int32 BytesPerPixel = 4;

			int32 SizeX = TextureRenderTarget->SizeX;
			int32 SizeY = TextureRenderTarget->SizeY;
			TArray<uint8> RawData;

			EPixelFormat Format = TextureRenderTarget->GetFormat();
			int32 ImageBytes = (SizeX / GPixelFormats[Format].BlockSizeX) * (SizeY / GPixelFormats[Format].BlockSizeY) * GPixelFormats[Format].BlockBytes;
			RawData.AddUninitialized(ImageBytes);
			FRenderTarget* RenderTarget = TextureRenderTarget->GameThread_GetRenderTargetResource();
			//auto readSurfaceDataFlags = FReadSurfaceDataFlags();
			//readSurfaceDataFlags.SetLinearToGamma(false);
			RenderTarget->ReadPixelsPtr((FColor*)RawData.GetData());// , readSurfaceDataFlags);

			// If we should export the file with no alpha info.  
			// If the texture is compressed with no alpha we should definitely not export an alpha channel
			bool bExportWithAlpha = true;
			if (bExportWithAlpha)
			{
				// If the texture isn't compressed with no alpha scan the texture to see if the alpha values are all 255 which means we can skip exporting it.
				// This is a relatively slow process but we are just exporting textures 
				bExportWithAlpha = false;
				const int32 AlphaOffset = 3;
				for (int32 Y = SizeY - 1; Y >= 0; --Y)
				{
					uint8* Color = &RawData[Y * SizeX * BytesPerPixel];
					for (int32 X = SizeX; X > 0; --X)
					{
						// Skip color info
						Color += AlphaOffset;
						// Get Alpha value then increment the pointer past it for the next pixel
						uint8 Alpha = *Color++;
						if (Alpha != 255)
						{
							// When a texture is imported with no alpha, the alpha bits are set to 255
							// So if the texture has non 255 alpha values, the texture is a valid alpha channel
							bExportWithAlpha = true;
							break;
						}
					}
					if (bExportWithAlpha)
					{
						break;
					}
				}
			}

			const int32 OriginalWidth = SizeX;
			const int32 OriginalHeight = SizeY;

			

			FBufferArchive Ar;
			_FTGAFileHeader TGA;
			FMemory::Memzero(&TGA, sizeof(TGA));
			TGA.ImageTypeCode = 2;
			TGA.BitsPerPixel = bExportWithAlpha ? 32 : 24;
			TGA.Height = OriginalHeight;
			TGA.Width = OriginalWidth;
			Ar.Serialize(&TGA, sizeof(TGA));

			if (bExportWithAlpha)
			{
				for (int32 Y = 0; Y < OriginalHeight; Y++)
				{
					// If we aren't skipping alpha channels we can serialize each line
					Ar.Serialize(&RawData[(OriginalHeight - Y - 1) * OriginalWidth * 4], OriginalWidth * 4);
				}
			}
			else
			{
				// Serialize each pixel
				for (int32 Y = OriginalHeight - 1; Y >= 0; --Y)
				{
					uint8* Color = &RawData[Y * OriginalWidth * BytesPerPixel];
					for (int32 X = OriginalWidth; X > 0; --X)
					{
						Ar << *Color++;
						Ar << *Color++;
						Ar << *Color++;
						// Skip alpha channel since we are exporting with no alpha
						Color++;
					}
				}
			}

			

			_FTGAFileFooter Ftr;
			FMemory::Memzero(&Ftr, sizeof(Ftr));
			FMemory::Memcpy(Ftr.Signature, "TRUEVISION-XFILE", 16);
			Ftr.TrailingPeriod = '.';
			Ar.Serialize(&Ftr, sizeof(Ftr));

			if (!FFileHelper::SaveArrayToFile(Ar, *strPath))
			{
				UE_LOG(LogAzure, Error, TEXT("ExportTextureRenderTargetTGA Error exporting %s"), *strPath);
			}
			return 0;
		}

		//static int ExportTextureToTGA(lua_State* L)
		//{
		//	const FString strPath = UTF8_TO_TCHAR(lua_tostring(L, 1));
		//	UTexture2D* Texture = Cast<UTexture2D>(wLua::FLuaUtils::GetUObject(L, 2, "Texture2D"));
		//	if (!Texture ||!Texture->Source.IsValid() || (Texture->Source.GetFormat() != TSF_BGRA8 && Texture->Source.GetFormat() != TSF_RGBA16))
		//		return 0;

		//	const bool bIsRGBA16 = Texture->Source.GetFormat() == TSF_RGBA16;

		//	if (bIsRGBA16)
		//	{
		//		/*	FMessageLog ExportWarning("EditorErrors");
		//			FFormatNamedArguments Arguments;
		//			Arguments.Add(TEXT("Name"), FText::FromString(Texture->GetName()));
		//			ExportWarning.Warning(FText::Format(LOCTEXT("BitDepthTGAWarning", "{Name}: Texture is RGBA16 and cannot be represented at such high bit depth in .tga. Color will be scaled to RGBA8."), Arguments));
		//			ExportWarning.Open(EMessageSeverity::Warning);*/
		//	}

		//	const int32 BytesPerPixel = bIsRGBA16 ? 8 : 4;

		//	int32 SizeX = Texture->Source.GetSizeX();
		//	int32 SizeY = Texture->Source.GetSizeY();
		//	TArray<uint8> RawData;
		//	Texture->Source.GetMipData(RawData, 0);

		//	// If we should export the file with no alpha info.  
		//	// If the texture is compressed with no alpha we should definitely not export an alpha channel
		//	bool bExportWithAlpha = !Texture->CompressionNoAlpha;
		//	if (bExportWithAlpha)
		//	{
		//		// If the texture isn't compressed with no alpha scan the texture to see if the alpha values are all 255 which means we can skip exporting it.
		//		// This is a relatively slow process but we are just exporting textures 
		//		bExportWithAlpha = false;
		//		const int32 AlphaOffset = bIsRGBA16 ? 7 : 3;
		//		for (int32 Y = SizeY - 1; Y >= 0; --Y)
		//		{
		//			uint8* Color = &RawData[Y * SizeX * BytesPerPixel];
		//			for (int32 X = SizeX; X > 0; --X)
		//			{
		//				// Skip color info
		//				Color += AlphaOffset;
		//				// Get Alpha value then increment the pointer past it for the next pixel
		//				uint8 Alpha = *Color++;
		//				if (Alpha != 255)
		//				{
		//					// When a texture is imported with no alpha, the alpha bits are set to 255
		//					// So if the texture has non 255 alpha values, the texture is a valid alpha channel
		//					bExportWithAlpha = true;
		//					break;
		//				}
		//			}
		//			if (bExportWithAlpha)
		//			{
		//				break;
		//			}
		//		}
		//	}

		//	const int32 OriginalWidth = SizeX;
		//	const int32 OriginalHeight = SizeY;
		//	FBufferArchive Ar;
		//	_FTGAFileHeader TGA;
		//	FMemory::Memzero(&TGA, sizeof(TGA));
		//	TGA.ImageTypeCode = 2;
		//	TGA.BitsPerPixel = bExportWithAlpha ? 32 : 24;
		//	TGA.Height = OriginalHeight;
		//	TGA.Width = OriginalWidth;
		//	Ar.Serialize(&TGA, sizeof(TGA));

		//	if (bExportWithAlpha && !bIsRGBA16)
		//	{
		//		for (int32 Y = 0; Y < OriginalHeight; Y++)
		//		{
		//			// If we aren't skipping alpha channels we can serialize each line
		//			Ar.Serialize(&RawData[(OriginalHeight - Y - 1) * OriginalWidth * 4], OriginalWidth * 4);
		//		}
		//	}
		//	else
		//	{
		//		// Serialize each pixel
		//		for (int32 Y = OriginalHeight - 1; Y >= 0; --Y)
		//		{
		//			uint8* Color = &RawData[Y * OriginalWidth * BytesPerPixel];
		//			for (int32 X = OriginalWidth; X > 0; --X)
		//			{
		//				if (bIsRGBA16)
		//				{
		//					Ar << Color[1];
		//					Ar << Color[3];
		//					Ar << Color[5];
		//					if (bExportWithAlpha)
		//					{
		//						Ar << Color[7];
		//					}
		//					Color += 8;
		//				}
		//				else
		//				{
		//					Ar << *Color++;
		//					Ar << *Color++;
		//					Ar << *Color++;
		//					// Skip alpha channel since we are exporting with no alpha
		//					Color++;
		//				}
		//			}
		//		}
		//	}

		//	_FTGAFileFooter Ftr;
		//	FMemory::Memzero(&Ftr, sizeof(Ftr));
		//	FMemory::Memcpy(Ftr.Signature, "TRUEVISION-XFILE", 16);
		//	Ftr.TrailingPeriod = '.';
		//	Ar.Serialize(&Ftr, sizeof(Ftr));

		//	if (!FFileHelper::SaveArrayToFile(Ar, *strPath))
		//	{
		//		UE_LOG(LogAzure, Error, TEXT("ExportTextureToTGA Error exporting %s"), *strPath);
		//	}
		//	return 0;
		//}

// 		static int ChangeTransObject(lua_State* L)
// 		{
// 			AActor* obj = Cast<AActor>(wLua::FLuaUtils::GetUObject(L, 1, "Actor"));
// 			UAzureObjectComponent* comp = obj ? Cast<UAzureObjectComponent>(obj->GetComponentByClass(UAzureObjectComponent::StaticClass())) : nullptr;
// 			if (comp == nullptr)
// 			{
// 				LuaStatic::traceback(L);
// 				lua_error(L);
// 				return 1;
// 			}
// 
// 			AActor* transObj = Cast<AActor>(wLua::FLuaUtils::GetUObject(L, 2, "Actor"));
// 			bool bRaceCar = !!lua_toboolean(L, 3);
// 			comp->ChangeTransObject(transObj, bRaceCar);
// 			return 0;
// 		}

		static int AddRegion(lua_State * L)
		{
			AActor* obj = Cast<AActor>(wLua::FLuaUtils::GetUObject(L, 1, "Actor"));
			UAzureObjectComponent* comp = obj ? Cast<UAzureObjectComponent>(obj->GetComponentByClass(UAzureObjectComponent::StaticClass())) : nullptr;
			if (comp == nullptr)
			{
				LuaStatic::traceback(L);
				lua_error(L);
				return 1;
			}

			int id = lua_tointeger(L, 2);
			float t = (float)lua_tonumber(L, 3)* UE_METRE_TRANS;
			float l = (float)lua_tonumber(L, 4)* UE_METRE_TRANS;
			float b = (float)lua_tonumber(L, 5)* UE_METRE_TRANS;
			float r = (float)lua_tonumber(L, 6)* UE_METRE_TRANS;
			bool enableh = !!lua_toboolean(L, 7);
			float minh = (float)lua_tonumber(L, 8)* UE_METRE_TRANS; 
			float maxh = (float)lua_tonumber(L, 9)* UE_METRE_TRANS;

			int task_a_id = lua_tonumber(L, 10);
			int task_b_id = lua_tonumber(L, 11);
			comp->AddRegion(id, l, t, r, b, enableh, minh, maxh, task_a_id, task_b_id);

			return 0;
		}

		static int ClearRegions(lua_State * L)
		{
			AActor* obj = Cast<AActor>(wLua::FLuaUtils::GetUObject(L, 1, "Actor"));
			UAzureObjectComponent* comp = obj ? Cast<UAzureObjectComponent>(obj->GetComponentByClass(UAzureObjectComponent::StaticClass())) : nullptr;
			if (comp == nullptr)
			{
				LuaStatic::traceback(L);
				lua_error(L);
				return 1;
			}

			comp->ClearRegions();
			return 0;
		}

// 		static int AzureObj_SetCanbeCullHideByMainCamera(lua_State * L)
// 		{
// 			AActor* obj = Cast<AActor>(wLua::FLuaUtils::GetUObject(L, 1, "Actor"));
// 			UAzureObjectComponent* comp = obj ? Cast<UAzureObjectComponent>(obj->GetComponentByClass(UAzureObjectComponent::StaticClass())) : nullptr;
// 			if (comp == nullptr)
// 			{
// 				LuaStatic::traceback(L);
// 				lua_error(L);
// 				return 1;
// 			}
// 
// 			bool b = !!lua_toboolean(L, 2);
// 			comp->SetCanbeCullHideByMainCamera(b);
// 			return 0;
// 		}

		static int RegionWallSpwanActor(lua_State * L)
		{// 早期代码 逐渐替换不再用了
			FString bluePrintSrc;
			int32 sceneID	= 0;
			int32 regionID	= 0;
			bool isCheckHeight = false;
			float minHeight	= 0.0f;
			float maxHeight	= 0.0f;

			if (lua_isstring(L , 1))
			{
				bluePrintSrc = lua_tostring(L , 1);
			}
			else
			{
				lua_pushstring(L , "RegionWallSpwanActor(bluePrintSrc , sceneID , regionID , checkHeight , minHeight , maxHeight {{x1,y1,z1},{x2,y2,z2}, ... ,{xn,yn,zn}}) 1");
				lua_error(L);
				return 1;
			}


			if (lua_isnumber(L , 2))
			{
				sceneID	= lua_tointeger(L , 2);
			}
			else
			{
				lua_pushstring(L , "RegionWallSpwanActor(bluePrintSrc , sceneID , regionID , checkHeight , minHeight , maxHeight,{{x1,y1,z1},{x2,y2,z2}, ... ,{xn,yn,zn}}) 2");
				lua_error(L);
				return 1;
			}

			if (lua_isnumber(L , 3))
			{
				regionID	= lua_tointeger(L , 3);
			}
			else
			{
				lua_pushstring(L , "RegionWallSpwanActor(bluePrintSrc , sceneID , regionID , checkHeight , minHeight , maxHeight,{{x1,y1,z1},{x2,y2,z2}, ... ,{xn,yn,zn}}) 3");
				lua_error(L);
				return 1;
			}

			if (lua_isboolean(L , 4))
			{
				isCheckHeight	= lua_toboolean(L , 4);
			}
			else
			{
				lua_pushstring(L , "RegionWallSpwanActor(bluePrintSrc , sceneID , regionID , checkHeight , minHeight , maxHeight,{{x1,y1,z1},{x2,y2,z2}, ... ,{xn,yn,zn}}) 3");
				lua_error(L);
				return 1;
			}

			if (lua_isnumber(L , 5))
			{
				minHeight = lua_tonumber(L , 5);
				minHeight = minHeight * UE_METRE_TRANS;
			}
			else
			{
				lua_pushstring(L , "RegionWallSpwanActor(bluePrintSrc , sceneID , regionID , checkHeight , minHeight , maxHeight,{{x1,y1,z1},{x2,y2,z2}, ... ,{xn,yn,zn}}) 3");
				lua_error(L);
				return 1;
			}

			if (lua_isnumber(L , 6))
			{
				maxHeight	= lua_tonumber(L , 6);
				maxHeight = maxHeight * UE_METRE_TRANS;
			}
			else
			{
				lua_pushstring(L , "RegionWallSpwanActor(bluePrintSrc , sceneID , regionID , checkHeight , minHeight , maxHeight,{{x1,y1,z1},{x2,y2,z2}, ... ,{xn,yn,zn}}) 3");
				lua_error(L);
				return 1;
			}

			FVector avgPoint(FVector::ZeroVector);

			TArray<FVector> points;

			if (lua_istable(L , 7))
			{
				lua_pushnil(L);
				while (lua_next(L , 7) != 0)
				{
					FVector point;
					if (wLua::FLuaVector::GetVectorFromLua(L, -1, point, false))
					{
						point = POS_FROM_SERVER(point);
						points.Add(point);
						avgPoint += point;
					}
					lua_pop(L , 1);
				}

			}else
			{
				lua_pushstring(L , "RegionWallSpwanActor(bluePrintSrc , sceneID , regionID , checkHeight , minHeight , maxHeight,{{x1,y1,z1},{x2,y2,z2}, ... ,{xn,yn,zn}}) 4");
				lua_error(L);
				return 1;
			}

			if (!AAzureEntryPoint::Instance)
				return 0;

			UWorld* pWorld = AAzureEntryPoint::Instance->GetWorld();
			if (pWorld == nullptr)
			{
				lua_pushstring(L , "RegionWallSpwanActor() pWorld == nullptr");
				lua_error(L);
				return 1;
			}

			//FActorSpawnParameters SpawnInfo;
			//SpawnInfo.Owner = this;
			//SpawnInfo.Instigator = Instigator;
			//SpawnInfo.SpawnCollisionHandlingOverride = ESpawnActorCollisionHandlingMethod::AlwaysSpawn;
			//FTransform TF = FTransform();
			//GetWorld()->SpawnActor<AActor>(BlueprintClass , TF , SpawnInfo);

			avgPoint /= points.Num();
		
			UClass* BlueprintClass = StaticLoadClass(ARegionWallActor::StaticClass() , nullptr , *bluePrintSrc);
			if (BlueprintClass == nullptr)
			{
				lua_pushstring(L , "RegionWallSpwanActor() BlueprintClass == nullptr");
				lua_error(L);
				return 1;
			}

			FActorSpawnParameters SpawnParams;
			SpawnParams.Owner = nullptr;
			SpawnParams.Instigator = nullptr;
			ARegionWallActor * pkRegionWallActor = pWorld->SpawnActor<ARegionWallActor>(BlueprintClass , FTransform(),SpawnParams);
			pkRegionWallActor->SetActorLocation(avgPoint);

			pkRegionWallActor->SetSceneIDRegionID(sceneID,regionID);

			if(isCheckHeight == false)
			{
				int32 count = points.Num() - 1;
				for (int32 i = 0 ; i < count ; ++i)
				{
					const FVector &p1 = points[i];
					const FVector &p2 = points[i + 1];
					pkRegionWallActor->AddWall(p1 , p2);
				}
				if (count > 2)
				{
					const FVector &p1 = points[count];
					const FVector &p2 = points[0];
					pkRegionWallActor->AddWall(p1 , p2);
				}
			}
			else
			{
				float height = maxHeight - minHeight;
				int32 iHeight = int32(height / 300.0f);
				int32 HSegNum = FMath::Clamp( iHeight ,1 ,3);
				float deltaHeight = height / HSegNum;
				float h = minHeight;
				for (int32 j = 0 ; j < HSegNum ; ++j)
				{
					int32 count = points.Num() - 1;
					for (int32 i = 0 ; i < count ; ++i)
					{
						FVector p1 = points[i];
						FVector p2 = points[i + 1];
						p1.Z = h;
						p2.Z = h;
						pkRegionWallActor->AddWall(p1 , p2 , pkRegionWallActor->GetDefaultWallThickness() , deltaHeight);
					}
					if (count > 2)
					{
						FVector p1 = points[count];
						FVector p2 = points[0];
						p1.Z = h;
						p2.Z = h;
						pkRegionWallActor->AddWall(p1 , p2 , pkRegionWallActor->GetDefaultWallThickness() , deltaHeight);
					}
					h = h + deltaHeight;
				}
			}

			//pkRegionWallActor->SetDrawDebugLine(true);

			return 0;
		}

		static int RegionWallSpwanPolygonActor(lua_State * L)
		{
			FString bluePrintSrc;
			int32 sceneID	= 0;
			int32 regionID	= 0;
			bool isCheckHeight = false;
			float upperOffset = 0.0f;
			float bottomOffset	= 0.0f;
			FVector location(FVector::ZeroVector);
			float tileX = 0.0f;
			float upupV = 0.0f;
			float upboV = 0.0f;
			float boupV = 0.0f;
			float boboV = 0.0f;

			const char* msgFmt = "RegionWallSpwanPolygonActor(bluePrintSrc , sceneID , regionID , upperOffset , bottomOffset , locationX , locationY , locationZ , TileU , TileV , TileB, {{x1,y1,z1},{x2,y2,z2}, ... ,{xn,yn,zn}}) ) #%d";

			auto GetLuaString = [&](int32 idx,FString &strValue,int32 &res)->bool
			{
				if (lua_isstring(L, idx))
				{
					strValue = lua_tostring(L, idx);
				} else
				{
					char buff[2048];
					sprintf(buff,msgFmt,idx);
					lua_pushstring(L, buff);
					lua_error(L);
					res = 1;
					return false;
				}
				return true;
			};
			auto GetLuaInteger = [&](int32 idx,int32 &intValue,int32 &res)->bool
			{
				if (lua_isnumber(L, idx))
				{
					intValue = lua_tointeger(L, idx);
				} else
				{
					char buff[2048];
					sprintf(buff,msgFmt,idx);
					lua_pushstring(L, buff);
					lua_error(L);
					res = 1;
					return false;
				}
				return true;
			};
			auto GetLuaFloat = [&](int32 idx,float &fValue,float coefficent,int32 &res)->bool
			{
				if (lua_isnumber(L, idx))
				{
					fValue = lua_tonumber(L, idx);
					fValue *= coefficent;
				} else
				{
					char buff[2048];
					sprintf(buff,msgFmt,idx);
					lua_pushstring(L, buff);
					lua_error(L);
					res = 1;
					return false;
				}
					return true;
			};

			int32 res = 0;
			if (!GetLuaString(1,bluePrintSrc,res))
			{
				return res;
			}
			if (!GetLuaInteger(2,sceneID,res))
			{
				return res;
			}
			if (!GetLuaInteger(3,regionID,res))
			{
				return res;
			}

			if (!GetLuaFloat(4, upperOffset, UE_METRE_TRANS, res))
			{
				return res;
			}
			if (!GetLuaFloat(5, bottomOffset, UE_METRE_TRANS, res))
			{
				return res;
			}

			if (!GetLuaFloat(6, location.X, 1, res))
			{
				return res;
			}
			if (!GetLuaFloat(7, location.Y, 1, res))
			{
				return res;
			}
			if (!GetLuaFloat(8, location.Z, 1, res))
			{
				return res;
			}

			if (!GetLuaFloat(9, tileX, 1, res))
			{
				return res;
			}

			if (!GetLuaFloat(10, upupV, 1, res))
			{
				return res;
			}
			if (!GetLuaFloat(11, upboV, 1, res))
			{
				return res;
			}

			if (!GetLuaFloat(12, boupV, 1, res))
			{
				return res;
			}
			if (!GetLuaFloat(13, boboV, 1, res))
			{
				return res;
			}

			TArray<FVector> points;

			if (lua_istable(L , 14))
			{
				lua_pushnil(L);
				while (lua_next(L , 14) != 0)
				{
					if (lua_istable(L , -1))
					{
						FVector point;
						lua_getfield(L , -1 , "x");
						point.X = (float)lua_tonumber(L , -1);
						lua_pop(L , 1);

						lua_getfield(L , -1 , "y");
						point.Y = (float)lua_tonumber(L , -1);
						lua_pop(L , 1);

						lua_getfield(L , -1 , "z");
						point.Z = (float)lua_tonumber(L , -1);
						lua_pop(L , 1);

						point = POS_FROM_SERVER(point);
						points.Add(point);
					}
					lua_pop(L , 1);
				}
			}
			else
			{
				char buff[2048];
				sprintf(buff,msgFmt,14);
				lua_pushstring(L, buff);
				lua_error(L);
				return 1;
			}

			if (!AAzureEntryPoint::Instance)
				return 0;

			UWorld* pWorld = AAzureEntryPoint::Instance->GetWorld();
			if (pWorld == nullptr)
			{
				lua_pushstring(L , "RegionWallSpwanPolygonActor() pWorld == nullptr");
				lua_error(L);
				return 1;
			}

			ARegionWallActor * pkRegionWallActor = nullptr;
			UClass* BlueprintClass = StaticLoadClass(ARegionWallActor::StaticClass() , nullptr , *bluePrintSrc);
			if (BlueprintClass == nullptr)
			{
				lua_pushstring(L , "RegionWallSpwanPolygonActor() BlueprintClass == nullptr");
				pkRegionWallActor = pWorld->SpawnActor<ARegionWallActor>();
				pkRegionWallActor->SetOutterSideEnabled(true);
			}else
			{
				FActorSpawnParameters SpawnParams;
				SpawnParams.Owner = nullptr;
				SpawnParams.Instigator = nullptr;
				pkRegionWallActor = pWorld->SpawnActor<ARegionWallActor>(BlueprintClass, FTransform(), SpawnParams);
			}
			location = POS_FROM_SERVER(location);

			int32 count = points.Num();
			for (int32 i = 0; i < count; ++i)
			{
				FVector &pt = points[i];
				pt -= location;
			}

			pkRegionWallActor->InitPolygon(location, points
				, sceneID , regionID
				, upperOffset, bottomOffset
				, tileX, upupV, upboV, boupV, boboV);

			//pkRegionWallActor->SetDrawDebugLine(true);

			wLua::FLuaUtils::ReturnUObject(L, pkRegionWallActor);
			return 1;
		}

		static int RegionWallSpwanCircleActor(lua_State * L)
		{
			FString bluePrintSrc;
			int32 sceneID	= 0;
			int32 regionID	= 0;
			float upperOffset = 0.0f;
			float bottomOffset = 0.0f;
			FVector center(FVector::ZeroVector);
			int32 segNum = 5;
			float radius = 30;
			float tileX = 1.0f;
			float upupV = 1.0f;
			float upboV = 0.0f;
			float boupV = 0.0f;
			float boboV = 0.0f;

			const char* msgFmt = "RegionWallSpwanCircleActor(bluePrintSrc , sceneID , regionID , upperOffset , bottomOffset , radius , centerX , centerY , centerZ , TileU , TileV , TileB , segNum) #%d";

			auto GetLuaString = [&](int32 idx,FString &strValue,int32 &res)->bool
			{
				if (lua_isstring(L, idx))
				{
					strValue = lua_tostring(L, idx);
				} else
				{
					char buff[2048];
					sprintf(buff,msgFmt,idx);
					lua_pushstring(L, buff);
					lua_error(L);
					res = 1;
					return false;
				}
				return true;
			};
			auto GetLuaInteger = [&](int32 idx,int32 &intValue,int32 &res)->bool
			{
				if (lua_isnumber(L, idx))
				{
					intValue = lua_tointeger(L, idx);
				} else
				{
					char buff[2048];
					sprintf(buff,msgFmt,idx);
					lua_pushstring(L, buff);
					lua_error(L);
					res = 1;
					return false;
				}
				return true;
			};
			auto GetLuaFloat = [&](int32 idx,float &fValue,float coefficent,int32 &res)->bool
			{
				if (lua_isnumber(L, idx))
				{
					fValue = lua_tonumber(L, idx);
					fValue *= coefficent;
				} else
				{
					char buff[2048];
					sprintf(buff,msgFmt,idx);
					lua_pushstring(L, buff);
					lua_error(L);
					res = 1;
					return false;
				}
				return true;
			};
			int32 res = 0;
			
			if (!GetLuaString(1, bluePrintSrc, res))
			{
				return res;
			}
			
			if (!GetLuaInteger(2, sceneID, res))
			{
				return res;
			}
			
			if (!GetLuaInteger(3, regionID, res))
			{
				return res;
			}
			
			if (!GetLuaFloat(4, upperOffset, UE_METRE_TRANS, res))
			{
				return res;
			}
			
			if (!GetLuaFloat(5, bottomOffset, UE_METRE_TRANS, res))
			{
				return res;
			}

			if (!GetLuaFloat(6, radius, UE_METRE_TRANS, res))
			{
				return res;
			}
			
			if (!GetLuaFloat(7, center.X, 1, res))
			{
				return res;
			} 
			if (!GetLuaFloat(8, center.Y, 1, res))
			{
				return res;
			}
			if (!GetLuaFloat(9, center.Z, 1, res))
			{
				return res;
			} 

			if (!GetLuaFloat(10, tileX, 1, res))
			{
				return res;
			}

			if (!GetLuaFloat(11, upupV, 1, res))
			{
				return res;
			}

			if (!GetLuaFloat(12, upboV, 1, res))
			{
				return res;
			}

			if (!GetLuaFloat(13, boupV, 1, res))
			{
				return res;
			}

			if (!GetLuaFloat(14, boboV, 1, res))
			{
				return res;
			}
			
			if (!GetLuaInteger(15, segNum, res))
			{
				return res;
			}
			
			if (!AAzureEntryPoint::Instance)
				return 0;

			UWorld* pWorld = AAzureEntryPoint::Instance->GetWorld();
			if (pWorld == nullptr)
			{
				lua_pushstring(L , "RegionWallSpwanCircleActor() pWorld == nullptr");
				lua_error(L);
				return 1;
			}

			//FActorSpawnParameters SpawnInfo;
			//SpawnInfo.Owner = this;
			//SpawnInfo.Instigator = Instigator;
			//SpawnInfo.SpawnCollisionHandlingOverride = ESpawnActorCollisionHandlingMethod::AlwaysSpawn;
			//FTransform TF = FTransform();
			//GetWorld()->SpawnActor<AActor>(BlueprintClass , TF , SpawnInfo);


			ARegionWallActor * pkRegionWallActor = nullptr;
			UClass* BlueprintClass = StaticLoadClass(ARegionWallActor::StaticClass() , nullptr , *bluePrintSrc);
			if (BlueprintClass != nullptr)
			{
				FActorSpawnParameters SpawnParams;
				SpawnParams.Owner = nullptr;
				SpawnParams.Instigator = nullptr;
				pkRegionWallActor = pWorld->SpawnActor<ARegionWallActor>(BlueprintClass, FTransform(), SpawnParams);
				//pkRegionWallActor->SetOutterSideEnabled(true);

			}
			if(pkRegionWallActor == nullptr)
			{
				lua_pushstring(L, "RegionWallSpwanCircleActor() BlueprintClass == nullptr");
				pkRegionWallActor = pWorld->SpawnActor<ARegionWallActor>();
				pkRegionWallActor->SetOutterSideEnabled(true);
			}

			center = POS_FROM_SERVER(center);
			pkRegionWallActor->InitCircle(center , sceneID , regionID , radius
				, upperOffset, bottomOffset
				, tileX, upupV, upboV, boupV, boboV
				, segNum);

			//pkRegionWallActor->SetDrawDebugLine(true);

			wLua::FLuaUtils::ReturnUObject(L, pkRegionWallActor);
			return 1;
		}

		static int RegionWallFindActor(lua_State * L)
		{
			if (!AAzureEntryPoint::IsInit())
				return 0;

			int32 sceneID	= 0;
			int32 regionID	= 0;
			UWorld* pWorld = AAzureEntryPoint::Instance->GetWorld();

			if (lua_isnumber(L , 1))
			{
				sceneID	= lua_tointeger(L , 1);
			}
			else
			{
				lua_pushstring(L , "RegionWallGetActorEnable(sceneID,regionID) 1");
				lua_error(L);
				return 1;
			}

			if (lua_isnumber(L , 2))
			{
				regionID= lua_tointeger(L , 2);
			}
			else
			{
				lua_pushstring(L , "RegionWallGetActorEnable(sceneID,regionID) 2");
				lua_error(L);
				return 1;
			}

			TArray<AActor*> Actors;
			UGameplayStatics::GetAllActorsOfClass(pWorld , ARegionWallActor::StaticClass() , Actors);
			for (AActor* Actor : Actors)
			{
				ARegionWallActor *pWallActor = Cast<ARegionWallActor>(Actor);
				if (pWallActor && pWallActor->GetSceneID() == sceneID && pWallActor->GetRegionID() == regionID)
				{
					wLua::FLuaUtils::ReturnUObject(L, pWallActor);
					return 1;
				}
			}
			lua_pushnil(L);
			return 1;
		}

		
		static int RegionWallGetActorEnable(lua_State * L)
		{
			if (!AAzureEntryPoint::IsInit())
				return 0;

			int32 sceneID	= 0;
			int32 regionID	= 0;
			UWorld* pWorld = AAzureEntryPoint::Instance->GetWorld();

			if (lua_isnumber(L , 1))
			{
				sceneID	= lua_tointeger(L , 1);
			}
			else
			{
				lua_pushstring(L , "RegionWallGetActorEnable(sceneID,regionID) 1");
				lua_error(L);
				return 1;
			}

			if (lua_isnumber(L , 2))
			{
				regionID= lua_tointeger(L , 2);
			}
			else
			{
				lua_pushstring(L , "RegionWallGetActorEnable(sceneID,regionID) 2");
				lua_error(L);
				return 1;
			}

			TArray<AActor*> Actors;
			UGameplayStatics::GetAllActorsOfClass(pWorld , ARegionWallActor::StaticClass() , Actors);
			for (AActor* Actor : Actors)
			{
				ARegionWallActor *pWallActor = Cast<ARegionWallActor>(Actor);

				if (pWallActor && pWallActor->GetSceneID() == sceneID && pWallActor->GetRegionID() == regionID)
				{
					bool enableCollision = pWallActor->GetCollisionEnabled();
					//bool enableCollision = Actor->GetActorEnableCollision();
					lua_pushboolean(L,enableCollision);
					return 1;
				}
			}
			lua_pushnil(L);
			return 1;
		}
		static int RegionWallSetActorEnable(lua_State * L)
		{
			if (!AAzureEntryPoint::IsInit())
				return 0;

			int32 sceneID	= 0;
			int32 regionID	= 0;
			bool enableCollision = false;
			UWorld* pWorld = AAzureEntryPoint::Instance->GetWorld();

			if (lua_isnumber(L , 1))
			{
				sceneID	= lua_tointeger(L , 1);
			}
			else
			{
				lua_pushstring(L , "RegionWallSetActorEnable(sceneID,regionID,enableCollision) 1");
				lua_error(L);
				return 1;
			}

			if (lua_isnumber(L , 2))
			{
				regionID = lua_tointeger(L , 2);
			}
			else
			{
				lua_pushstring(L , "RegionWallSetActorEnable(sceneID,regionID,enableCollision) 2");
				lua_error(L);
				return 1;
			}

			if (lua_isboolean(L , 3))
			{
				enableCollision = lua_toboolean(L , 3);
			}
			else
			{
				lua_pushstring(L , "RegionWallSetActorEnable(sceneID,regionID,enableCollision) 3");
				lua_error(L);
				return 1;
			}

			TArray<AActor*> Actors;
			UGameplayStatics::GetAllActorsOfClass(pWorld , ARegionWallActor::StaticClass() , Actors);
			for (AActor* Actor : Actors)
			{
				ARegionWallActor *pRegionWallActor = Cast<ARegionWallActor>(Actor);
				if (pRegionWallActor && pRegionWallActor->GetSceneID() == sceneID && pRegionWallActor->GetRegionID() == regionID)
				{
					pRegionWallActor->SetCollisionEnabled(enableCollision);
					//pRegionWallActor->SetActorEnableCollision(enableCollision);
					lua_pushboolean(L , enableCollision);
					return 0;
				}
			}
			lua_pushnil(L);
			return 1;
		}
		static int RegionWallGetActorDrawDebugLine(lua_State * L)
		{
			if (!AAzureEntryPoint::IsInit())
				return 0;

			int32 sceneID	= 0;
			int32 regionID	= 0;
			UWorld* pWorld = AAzureEntryPoint::Instance->GetWorld();

			if (lua_isnumber(L , 1))
			{
				sceneID	= lua_tointeger(L , 1);
			}
			else
			{
				lua_pushstring(L , "RegionWallSetActorEnable(sceneID,regionID,enableCollision) 1");
				lua_error(L);
				return 1;
			}

			if (lua_isnumber(L , 2))
			{
				regionID = lua_tointeger(L , 2);
			}
			else
			{
				lua_pushstring(L , "RegionWallSetActorEnable(sceneID,regionID,enableCollision) 2");
				lua_error(L);
				return 1;
			}

			TArray<AActor*> Actors;
			UGameplayStatics::GetAllActorsOfClass(pWorld , ARegionWallActor::StaticClass() , Actors);
			for (AActor* Actor : Actors)
			{
				ARegionWallActor *pRegionWallActor = Cast<ARegionWallActor>(Actor);
				if (pRegionWallActor && pRegionWallActor->GetSceneID() == sceneID && pRegionWallActor->GetRegionID() == regionID)
				{
					bool DrawDebugLine = pRegionWallActor->GetDrawDebugLine();
					lua_pushboolean(L , DrawDebugLine);
					return 1;
				}
			}
			lua_pushnil(L);
			return 1;
		}
		static int RegionWallSetActorDrawDebugLine(lua_State * L)
		{
			if (!AAzureEntryPoint::IsInit())
				return 0;

			int32 sceneID	= 0;
			int32 regionID	= 0;
			bool drawDebugLine = false;
			UWorld* pWorld = AAzureEntryPoint::Instance->GetWorld();

			if (lua_isnumber(L , 1))
			{
				sceneID	= lua_tointeger(L , 1);
			}
			else
			{
				lua_pushstring(L , "RegionWallSetActorEnable(sceneID,regionID,drawDebugLine) 1");
				lua_error(L);
				return 1;
			}

			if (lua_isnumber(L , 2))
			{
				regionID = lua_tointeger(L , 2);
			}
			else
			{
				lua_pushstring(L , "RegionWallSetActorEnable(sceneID,regionID,drawDebugLine) 2");
				lua_error(L);
				return 1;
			}

			if (lua_isboolean(L , 3))
			{
				drawDebugLine = lua_toboolean(L , 3);
			}
			else
			{
				lua_pushstring(L , "RegionWallSetActorEnable(sceneID,regionID,drawDebugLine) 3");
				lua_error(L);
				return 1;
			}

			TArray<AActor*> Actors;
			UGameplayStatics::GetAllActorsOfClass(pWorld , ARegionWallActor::StaticClass() , Actors);
			for (AActor* Actor : Actors)
			{
				ARegionWallActor *pRegionWallActor = Cast<ARegionWallActor>(Actor);
				if (pRegionWallActor && pRegionWallActor->GetSceneID() == sceneID && pRegionWallActor->GetRegionID() == regionID)
				{
					pRegionWallActor->SetDrawDebugLine(drawDebugLine);
					return 0;
				}
			}
			lua_pushnil(L);
			return 1;
		}
		static int RegionWallGetActorVisible(lua_State * L)
		{
			if (!AAzureEntryPoint::IsInit())
				return 0;

			int32 sceneID	= 0;
			int32 regionID	= 0;
			UWorld* pWorld = AAzureEntryPoint::Instance->GetWorld();

			if (lua_isnumber(L , 1))
			{
				sceneID	= lua_tointeger(L , 1);
			}
			else
			{
				lua_pushstring(L , "RegionWallSetActorEnable(sceneID,regionID) 1");
				lua_error(L);
				return 1;
			}

			if (lua_isnumber(L , 2))
			{
				regionID = lua_tointeger(L , 2);
			}
			else
			{
				lua_pushstring(L , "RegionWallSetActorEnable(sceneID,regionID) 2");
				lua_error(L);
				return 1;
			}

			TArray<AActor*> Actors;
			UGameplayStatics::GetAllActorsOfClass(pWorld , ARegionWallActor::StaticClass() , Actors);
			for (AActor* Actor : Actors)
			{
				ARegionWallActor *pRegionWallActor = Cast<ARegionWallActor>(Actor);
				if (pRegionWallActor && pRegionWallActor->GetSceneID() == sceneID && pRegionWallActor->GetRegionID() == regionID)
				{
					bool WallVisible = pRegionWallActor->GetWallVisible();
					lua_pushboolean(L , WallVisible);
					return 1;
				}
			}
			lua_pushnil(L);
			return 1;

		}
		static int RegionWallSetActorVisible(lua_State * L)
		{
			if (!AAzureEntryPoint::IsInit())
				return 0;

			int32 sceneID	= 0;
			int32 regionID	= 0;
			bool wallVisible = false;
			UWorld* pWorld = AAzureEntryPoint::Instance->GetWorld();
			if (lua_isnumber(L , 1))
			{
				sceneID	= lua_tointeger(L , 1);
			}
			else
			{
				lua_pushstring(L , "RegionWallSetActorEnable(sceneID,regionID,WallVisible) 1");
				lua_error(L);
				return 1;
			}
			if (lua_isnumber(L , 2))
			{
				regionID = lua_tointeger(L , 2);
			}
			else
			{
				lua_pushstring(L , "RegionWallSetActorEnable(sceneID,regionID,WallVisible) 2");
				lua_error(L);
				return 1;
			}
			if (lua_isboolean(L , 3))
			{
				wallVisible = lua_toboolean(L , 3);
			}
			else
			{
				lua_pushstring(L , "RegionWallSetActorEnable(sceneID,regionID,WallVisible) 3");
				lua_error(L);
				return 1;
			}

			TArray<AActor*> Actors;
			UGameplayStatics::GetAllActorsOfClass(pWorld , ARegionWallActor::StaticClass() , Actors);
			for (AActor* Actor : Actors)
			{
				ARegionWallActor *pRegionWallActor = Cast<ARegionWallActor>(Actor);
				if (pRegionWallActor && pRegionWallActor->GetSceneID() == sceneID && pRegionWallActor->GetRegionID() == regionID)
				{
					pRegionWallActor->SetWallVisible(wallVisible);
					return 0;
				}
			}
			lua_pushnil(L);
			return 1;
		}
		static int RegionWallDestroyActor(lua_State * L)
		{
			if (!AAzureEntryPoint::IsInit())
				return 0;

			int32 sceneID	= 0;
			int32 regionID	= 0;
			bool wallVisible	= false;
			UWorld* pWorld = AAzureEntryPoint::Instance->GetWorld();

			if (lua_isnumber(L , 1))
			{
				sceneID	= lua_tointeger(L , 1);
			}
			else
			{
				lua_pushstring(L , "RegionWallSetActorEnable(sceneID,regionID) 1");
				lua_error(L);
				return 1;
			}

			if (lua_isnumber(L , 2))
			{
				regionID = lua_tointeger(L , 2);
			}
			else
			{
				lua_pushstring(L , "RegionWallSetActorEnable(sceneID,regionID) 2");
				lua_error(L);
				return 1;
			}

			TArray<AActor*> Actors;
			UGameplayStatics::GetAllActorsOfClass(pWorld , ARegionWallActor::StaticClass() , Actors);
			for (AActor* Actor : Actors)
			{
				ARegionWallActor *pRegionWallActor = Cast<ARegionWallActor>(Actor);
				if (pRegionWallActor && pRegionWallActor->GetSceneID() == sceneID && pRegionWallActor->GetRegionID() == regionID)
				{
					pRegionWallActor->Destroy();
					lua_pushboolean(L,true);
					return 1;
				}
			}
			lua_pushboolean(L , false);
			return 1;
		}
		static int RegionWallDestroyAllActor(lua_State * L)
		{
			if (!AAzureEntryPoint::IsInit())
				return 0;

			UWorld* pWorld = AAzureEntryPoint::Instance->GetWorld();
			TArray<AActor*> Actors;
			UGameplayStatics::GetAllActorsOfClass(pWorld , ARegionWallActor::StaticClass() , Actors);
			for (AActor* Actor : Actors)
			{
				ARegionWallActor *pRegionWallActor = Cast<ARegionWallActor>(Actor);
				if (pRegionWallActor)
				{
					pRegionWallActor->Destroy();
				}
			}
			return 0;
		}

		static int AddStatInfo(lua_State * L)
		{
			if (AAzureEntryPoint::Instance)
			{
				int32 top = lua_gettop(L);
				int32 x = luaL_checkint(L, 1);
				int32 y = luaL_checkint(L, 2);
				FLinearColor color = FLinearColor::Green;
				if (top >3 && (lua_istable(L, 3) || lua_isnumber(L, 3)))
				{
					color = FLuaLinearColor::Get(L, 3);
				}
				FString info = UTF8_TO_TCHAR(luaL_checkstring(L, top));
				
				AAzureEntryPoint::Instance->AddStatInfo(x, y, info, color);
			}
			return 0;
		}

		static int ShowStat(lua_State * L)
		{
			if (AAzureEntryPoint::Instance)
			{
				luaL_checktype(L, 1, LUA_TBOOLEAN);
				AAzureEntryPoint::Instance->ShowStat(!!lua_toboolean(L, 1));
			}
			return 0;
		}
		
		static int RemoveAllStatInfo(lua_State * L)
		{
			if (AAzureEntryPoint::Instance)
				AAzureEntryPoint::Instance->RemoveAllStatInfo();
			return 0;
		}

		static int GetTotalTimerCount(lua_State * L)
		{
			lua_pushinteger(L, ECTimerList::total_count);
			return 1;
		}

		static int CanOpenURL(lua_State * L)
		{
			const char *url = luaL_checkstring(L, 1);
			bool ret = FPlatformProcess::CanLaunchURL(UTF8_TO_TCHAR(url));
			lua_pushboolean(L, 1);
			return 1;
		}
		
		static int OpenURL(lua_State * L)
		{
			const char *url = luaL_checkstring(L, 1);
			if (url)
				FPlatformProcess::LaunchURL(UTF8_TO_TCHAR(url), nullptr, nullptr);
			return 0;
		}
		
		static int GC(lua_State * L)
		{
			bool bPerformFullPurge = lua_optboolean(L, 1, false);
			GEngine->ForceGarbageCollection(bPerformFullPurge);
			return 0;
		}

		float GetViewportScale()
		{
			if (AAzureEntryPoint::Instance)
				return UWidgetLayoutLibrary::GetViewportScale(AAzureEntryPoint::Instance);
			return 1.0f;
		}
		static int UEGetViewportScale(lua_State * L)
		{
			lua_pushnumber(L, GetViewportScale());
			return 1;
		}
		void ViewportToAbsolute(const FVector2D& Viewport, FVector2D& Absolute)
		{
			if (AAzureEntryPoint::Instance)
			{
				USlateBlueprintLibrary::ScreenToWidgetAbsolute(AAzureEntryPoint::Instance, Viewport, Absolute);
			}
		}
		void AbsoluteToViewport(const FVector2D& Absolute, FVector2D& Viewport, FVector2D& ViewportDPI)
		{
			if (AAzureEntryPoint::Instance)
			{
				USlateBlueprintLibrary::AbsoluteToViewport(AAzureEntryPoint::Instance, Absolute, Viewport, ViewportDPI);
			}
		}
		static int UEViewportToAbsolute(lua_State * L)
		{
			float x = luaL_checknumber(L, 1);
			float y = luaL_checknumber(L, 2);
			FVector2D Absolute;
			ViewportToAbsolute(FVector2D(x, y), Absolute);
			lua_pushnumber(L, Absolute.X);
			lua_pushnumber(L, Absolute.Y);
			return 2;
		}
		static int UEAbsoluteToViewport(lua_State * L)
		{
			float x = luaL_checknumber(L, 1);
			float y = luaL_checknumber(L, 2);
			bool dpi = lua_optboolean(L, 3, false);
			FVector2D Viewport, ViewportDPI;
			AbsoluteToViewport(FVector2D(x, y), Viewport, ViewportDPI);
			if (dpi)
			{
				lua_pushnumber(L, ViewportDPI.X);
				lua_pushnumber(L, ViewportDPI.Y);
			}
			else
			{
				lua_pushnumber(L, Viewport.X);
				lua_pushnumber(L, Viewport.Y);
			}
			return 2;
		}

		static int InitCustomComponent(lua_State * L)
		{
			UObject* Obj = wLua::FLuaUtils::GetUObject(L, 1, "Actor");
			AActor * actor = Cast<AActor>(Obj);
			UCustomBoneComponent* pCustomBoneComponent = actor ? actor->FindComponentByClass<UCustomBoneComponent>() : NULL;
			if (!pCustomBoneComponent)
				return 0;
			pCustomBoneComponent->m_BoneTrans.Empty();
			pCustomBoneComponent->m_BoneNames.Empty();

			int t = 2;
			if (!lua_istable(L, t))
			{
				return 0;
			}
		
			lua_pushnil(L);
			while (lua_next(L, t) != 0)
			{
				// 'key' is at index -2 and  value at index -1
				int t1 = lua_gettop(L);
				if (lua_isnumber(L, -2))
				{
					int id = (int)lua_tonumber(L, -2);

					FName Name(NAME_None);
					FONEBONE_TRANSTORM tran;
					

					if (lua_istable(L, -1))
					{
						lua_pushnil(L);
						int idx = 0;
						FString strParam;
						UProperty* pParam = NULL;
						while (lua_next(L, t1) != 0)
						{
							FString strKey = UTF8_TO_TCHAR(luaL_checkstring(L, -2));
							if (strKey == TEXT("name"))
							{
								if (lua_isstring(L, -1))
								{
									Name = UTF8_TO_TCHAR(luaL_checkstring(L, -1));
									
								}
									
							}
							else if (strKey == TEXT("tran"))
							{
								if (lua_istable(L, -1))
								{
									tran.Translation = FLuaVector::Get(L, -1);
									if (!tran.Translation.IsNearlyZero(0.01f))
										tran.bTranslation = true;
								}
								
							}
							else if (strKey == TEXT("rot"))
							{
								if (lua_istable(L, -1))
								{
									FVector temp = FLuaVector::Get(L, -1);
									tran.Rotation.Roll = temp.X;
									tran.Rotation.Pitch = temp.Y;
									tran.Rotation.Yaw = temp.Z;
									if (!tran.Rotation.IsNearlyZero(0.1f))
										tran.bRotation = true;
								}

							}
							else if (strKey == TEXT("scale"))
							{
								if (lua_istable(L, -1))
								{
									tran.Scale = FLuaVector::Get(L, -1);
									if (FMath::Abs(tran.Scale.X-1.0f) > 0.001f  //此误差值轻易不要改 否则会造成腰部一起误差造成脖子接缝
										|| FMath::Abs(tran.Scale.Y - 1.0f) > 0.001f
										|| FMath::Abs(tran.Scale.Z - 1.0f) > 0.001f)
										tran.bScale = true;
								}

							}
							else if (strKey == TEXT("alpha_rot"))
							{
								tran.AlphaRot = (float)(luaL_checknumber(L, -1));
								if (FMath::Abs(tran.AlphaRot - 1.0f) > 0.01f)
									tran.bAlphaRot = true;
							}
								
							idx++;
							lua_pop(L, 1);
						}
					}
					
					pCustomBoneComponent->m_BoneTrans.Add(tran);
					pCustomBoneComponent->m_BoneNames.Add(Name);

				}
				lua_pop(L, 1);
			}

			pCustomBoneComponent->m_bResetChange = true;

			return 0;
		}
		static int SetCustomComponentValue(lua_State * L)
		{
			UObject* Obj = wLua::FLuaUtils::GetUObject(L, 1, "Actor");
			AActor * actor = Cast<AActor>(Obj);
			UCustomBoneComponent* pCustomBoneComponent = actor ? actor->FindComponentByClass<UCustomBoneComponent>() : NULL;
			if (!pCustomBoneComponent)
				return 0;

			if (!lua_isnumber(L, 2))
				return 0;

			int idx = (int)lua_tonumber(L, 2)-1;
			if (idx<0 || idx>=pCustomBoneComponent->m_BoneTrans.Num())
				return 0;

			int t = 3;
			if (!lua_istable(L, t))
				return 0;

			lua_pushnil(L);
			while (lua_next(L, t) != 0)
			{
				// 'key' is at index -2 and  value at index -1
				int t1 = lua_gettop(L);
				if (lua_isstring(L, -2))
				{
					FString strKey = UTF8_TO_TCHAR(luaL_checkstring(L, -2));

					if (strKey == TEXT("tran"))
					{
						if (lua_istable(L, -1))
						{
							pCustomBoneComponent->m_BoneTrans[idx].Translation = FLuaVector::Get(L, -1);
							if (!pCustomBoneComponent->m_BoneTrans[idx].Translation.IsNearlyZero(0.01f))
								pCustomBoneComponent->m_BoneTrans[idx].bTranslation = true;
							else
								pCustomBoneComponent->m_BoneTrans[idx].bTranslation = false;
						}

					}
					else if (strKey == TEXT("rot"))
					{
						if (lua_istable(L, -1))
						{
							FVector temp = FLuaVector::Get(L, -1);
							pCustomBoneComponent->m_BoneTrans[idx].Rotation.Roll = temp.X;
							pCustomBoneComponent->m_BoneTrans[idx].Rotation.Pitch = temp.Y;
							pCustomBoneComponent->m_BoneTrans[idx].Rotation.Yaw = temp.Z;
							if (!pCustomBoneComponent->m_BoneTrans[idx].Rotation.IsNearlyZero(0.1f))
								pCustomBoneComponent->m_BoneTrans[idx].bRotation = true;
							else
								pCustomBoneComponent->m_BoneTrans[idx].bRotation = false;
						}

					}
					else if (strKey == TEXT("scale"))
					{
						if (lua_istable(L, -1))
						{
							pCustomBoneComponent->m_BoneTrans[idx].Scale = FLuaVector::Get(L, -1);
							if (FMath::Abs(pCustomBoneComponent->m_BoneTrans[idx].Scale.X - 1.0f) > 0.001f//此误差值轻易不要改 否则会造成腰部一起误差造成脖子接缝
								|| FMath::Abs(pCustomBoneComponent->m_BoneTrans[idx].Scale.Y - 1.0f) > 0.001f
								|| FMath::Abs(pCustomBoneComponent->m_BoneTrans[idx].Scale.Z - 1.0f) > 0.001f)
								pCustomBoneComponent->m_BoneTrans[idx].bScale = true;
							else
								pCustomBoneComponent->m_BoneTrans[idx].bScale = false;
						}

					}
					else if (strKey == TEXT("alpha_rot"))
					{
						pCustomBoneComponent->m_BoneTrans[idx].AlphaRot = (float)(luaL_checknumber(L, -1));
						if (FMath::Abs(pCustomBoneComponent->m_BoneTrans[idx].AlphaRot - 1.0f) > 0.01f)
							pCustomBoneComponent->m_BoneTrans[idx].bAlphaRot = true;
						else
							pCustomBoneComponent->m_BoneTrans[idx].bAlphaRot = false;
					}

				}
				lua_pop(L, 1);
			}
			pCustomBoneComponent->m_bResetChange = true;
			return 0;
		}

		/*
			在头的 AnimBlueprint 上调用 ApplyFaceData 函数
			param 1: AnimBlueprint 对象
			param 2: ApplyFaceData 函数名，对应函数有一个参数，类型为 CustomFaceData_Struct
			param 3: Custom Face 数据 (详见 CustomFaceData_Struct asset)，格式为 { [iField] = value }，其中 value 为 float
				字段顺序、数量与 CustomFaceData_Struct 一致，可只包含部分字段
				注：虽可利用反射访问结构中的字段，但 CustomFaceData_Struct 的字段名有随机后缀，因此只能依靠序号访问
		*/
		static int ApplyFaceDataOnHeadAnimBlueprint(lua_State * L)
		{
			UAnimInstance* obj = Cast<UAnimInstance>(wLua::FLuaUtils::GetUObject(L, 1, "AnimInstance"));
			if (!obj)
			{
				luaL_error(L, "ApplyFaceDataOnHeadAnimBlueprint: param #1 is null or not type of AnimInstance!");
				return 0;
			}

			char const* funcNameStr = luaL_checkstring(L, 2);
			FName funcName = UTF8_TO_TCHAR(funcNameStr);
			UClass const* theClass = obj->GetClass();
			UFunction* func = theClass->FindFunctionByName(funcName);
			if (!func)
			{
				luaL_error(L, "ApplyFaceDataOnHeadAnimBlueprint: function '%s' not found", funcNameStr);
				return 0;
			}

			luaL_checktype(L, 3, LUA_TTABLE);

			checkSlow(func->Children);
			UField const* faceDataField = func->Children;
			UStructProperty const* faceDataStructProp = CastChecked<UStructProperty>(faceDataField);
			uint8* params = (uint8*)FMemory_Alloca(func->PropertiesSize);
			FMemory::Memzero(params, func->PropertiesSize);
			uint8* pFaceData = faceDataStructProp->ContainerPtrToValuePtr<uint8>(params);
			faceDataStructProp->Struct->InitializeDefaultValue(pFaceData);

			UField const* pField = faceDataStructProp->Struct->Children;
			FString fieldName;
			int iField = 0;
			while (pField)
			{
				lua_rawgeti(L, 3, iField+1);
				if (!lua_isnil(L, -1))
				{
					float fieldValue = luaL_checknumber(L, -1);
					UFloatProperty const* pFieldAsFloat = CastChecked<UFloatProperty>(pField);
					pFieldAsFloat->SetFloatingPointPropertyValue(pFieldAsFloat->ContainerPtrToValuePtr<uint8>(pFaceData), fieldValue);
				}

				lua_pop(L, 1);
				pField = pField->Next;
				++iField;
			}
			obj->ProcessEvent(func, params);
			return 0;
		}

		static int g_iDuplicateHeadCount = 1;

		//static int lua_VertexFromOtherMesh(lua_State * L)
		//{
		//	UObject* ObjDst = wLua::FLuaUtils::GetUObject(L, 1, "SkeletalMeshComponent");
		//	USkeletalMeshComponent* pSkeletalMeshComponenDst = Cast<USkeletalMeshComponent>(ObjDst);
		//	UObject* ObjSrc = wLua::FLuaUtils::GetUObject(L, 2, "SkeletalMeshComponent");
		//	USkeletalMeshComponent* pSkeletalMeshComponenSrc = Cast<USkeletalMeshComponent>(ObjSrc);
		//	USkeletalMesh* pSkelMeshDst = pSkeletalMeshComponenDst? pSkeletalMeshComponenDst->SkeletalMesh:NULL;
		//	USkeletalMesh* pSkelMeshSrc = pSkeletalMeshComponenSrc? pSkeletalMeshComponenSrc->SkeletalMesh:NULL;
		//	if (!pSkelMeshDst||!pSkelMeshSrc)
		//	{
		//		lua_pushboolean(L, false);
		//		return 1;
		//	}

		//	//先Tick一下
		//	if (pSkeletalMeshComponenSrc->MasterPoseComponent.IsValid())
		//	{
		//		USkeletalMeshComponent* pSkeletalMesh = Cast<USkeletalMeshComponent>(pSkeletalMeshComponenSrc->MasterPoseComponent.Get());
		//		if(pSkeletalMesh)
		//			pSkeletalMesh->TickComponent(0.001f, ELevelTick::LEVELTICK_All, NULL);
		//	}
		//	else
		//		pSkeletalMeshComponenSrc->TickComponent(0.001f, ELevelTick::LEVELTICK_All, NULL);

		//	ERHIFeatureLevel::Type SceneFeatureLevel = pSkeletalMeshComponenSrc->GetWorld()->FeatureLevel;
		//	FSkeletalMeshResource* SkelMeshResource = pSkelMeshSrc->GetResourceForRendering();

		//	FSkeletalMeshResource* pResourceDst = pSkelMeshDst->GetImportedResource();
		//	FSkeletalMeshResource* pResourceSrc = pSkelMeshSrc->GetImportedResource();
		//	// rebuild vertex buffers
		//	uint32 VertexFlags = pSkelMeshSrc->GetVertexBufferFlags();
		//	for (int32 LODIndex = 0; LODIndex < pResourceSrc->LODModels.Num(); LODIndex++)
		//	{
		//		TArray<FFinalSkinVertex> FinalVertices;
		//		//pSkeletalMeshComponenSrc->GetCPUSkinnedVertices(FinalVertices, LODIndex);

		//		pSkeletalMeshComponenSrc->ForcedLodModel = LODIndex + 1;
		//		pSkeletalMeshComponenSrc->UpdateLODStatus();
		//		pSkeletalMeshComponenSrc->RefreshBoneTransforms(nullptr);

		//		FSkeletalMeshObjectCPUSkin* MeshObject = ::new FSkeletalMeshObjectCPUSkin(pSkeletalMeshComponenSrc, SkelMeshResource, SceneFeatureLevel);
		//		if (MeshObject)
		//		{
		//			const int32 UseLOD = FMath::Clamp(pSkeletalMeshComponenSrc->PredictedLODLevel, 0, MeshObject->GetSkeletalMeshResource().LODModels.Num() - 1);
		//			if (pSkelMeshSrc->LODInfo.IsValidIndex(UseLOD))
		//			{
		//				MeshObject->Update(UseLOD, pSkeletalMeshComponenSrc, pSkeletalMeshComponenSrc->ActiveMorphTargets, pSkeletalMeshComponenSrc->MorphTargetWeights);  // send to rendering thread
		//			}
		//		}
		//		FlushRenderingCommands();

		//		FinalVertices = MeshObject->GetCachedFinalVertices();

		//		MeshObject->ReleaseResources();
		//		BeginCleanup(MeshObject);
		//		MeshObject = NULL;

		//		FStaticLODModel& DstLODModel = pResourceDst->LODModels[LODIndex];
		//		FStaticLODModel& SrcLODModel = pResourceSrc->LODModels[LODIndex];

		//		for (int32 SectionIndex = 0; FinalVertices.Num() > 0 && SectionIndex < SrcLODModel.Sections.Num(); SectionIndex++)
		//		{
		//			FSkelMeshSection& SectionDst = DstLODModel.Sections[SectionIndex];
		//			FSkelMeshSection& SectionSrc = SrcLODModel.Sections[SectionIndex];

		//			int32 iNum = SectionDst.NumVertices;//DstLODModel.VertexBufferGPUSkin.GetNumVertices();
		//			SectionDst.SoftVertices.Empty(iNum);//editor模式下才有SoftVertices数据 
		//			SectionDst.SoftVertices.AddUninitialized(iNum);
		//			ensure((int32)SectionDst.BaseVertexIndex + iNum <= FinalVertices.Num());

		//			for (int32 iIndex = 0;  iIndex < iNum; ++iIndex)
		//			{						
		//				FSoftSkinVertex& SoftVertDst = SectionDst.SoftVertices[iIndex];
		//				int32 idx = (int32)SectionDst.BaseVertexIndex + iIndex;
		//				if (idx < 0 || idx >= FinalVertices.Num())
		//				{
		//					break;
		//				}

		//				const FFinalSkinVertex& finalVert = FinalVertices[idx];
		//				SoftVertDst.Position = finalVert.Position;
		//				SoftVertDst.TangentX = finalVert.TangentX;
		//				SoftVertDst.TangentZ = finalVert.TangentZ;

		//				const FVector4 UnpackedTangentZ = SoftVertDst.TangentZ;
		//				FVector vTangentX = SoftVertDst.TangentX;
		//				FVector vTangentZ = SoftVertDst.TangentZ;
		//				FVector vTangentY = ((vTangentX ^ vTangentZ)* (-UnpackedTangentZ.W)).GetSafeNormal();
		//				SoftVertDst.TangentY = vTangentY;
		//		
		//				SoftVertDst.Color = FColor::White;

		//				auto* VertBase = (TSkinWeightInfo<false>*)DstLODModel.SkinWeightVertexBuffer.GetSkinWeightPtr<true>(SectionDst.BaseVertexIndex + iIndex);
		//				FMemory::Memcpy(SoftVertDst.InfluenceBones, VertBase->InfluenceBones, TSkinWeightInfo<false>::NumInfluences);
		//				FMemory::Memcpy(SoftVertDst.InfluenceWeights, VertBase->InfluenceWeights, TSkinWeightInfo<false>::NumInfluences);

		//				SoftVertDst.UVs[0] = DstLODModel.VertexBufferGPUSkin.GetVertexUV(SectionDst.BaseVertexIndex + iIndex, 0);
		//				SoftVertDst.UVs[1] = DstLODModel.VertexBufferGPUSkin.GetVertexUV(SectionDst.BaseVertexIndex + iIndex, 1);
		//				//因为就用了0,1层 为提高效率 先注释掉下面
		//				//SoftVertDst.UVs[2] = DstLODModel.VertexBufferGPUSkin.GetVertexUV(SectionDst.BaseVertexIndex + iIndex, 2);
		//				//SoftVertDst.UVs[3] = DstLODModel.VertexBufferGPUSkin.GetVertexUV(SectionDst.BaseVertexIndex + iIndex, 3);
		//			}
		//		}
		//		DstLODModel.BuildVertexBuffers(VertexFlags);
		//	}

		//	UObject *Outer = pSkelMeshDst->GetOuter();

		//	FString strName = TEXT("DuplicateSkelMesh") + FString::FormatAsNumber(g_iDuplicateHeadCount++);
		//	UObject *DupObj = DuplicateObject(pSkelMeshDst, Outer, *strName);
		//	pSkeletalMeshComponenDst->SetSkeletalMesh(Cast<USkeletalMesh>(DupObj));

		//	lua_pushboolean(L, true);
		//	return 1;
		//}

		static int lua_VertexFromOtherMesh(lua_State * L)
		{
			UObject* ObjDst = wLua::FLuaUtils::GetUObject(L, 1, "SkeletalMeshComponent");
			USkeletalMeshComponent* pSkeletalMeshComponenDst = Cast<USkeletalMeshComponent>(ObjDst);
			UObject* ObjSrc = wLua::FLuaUtils::GetUObject(L, 2, "SkeletalMeshComponent");
			USkeletalMeshComponent* pSkeletalMeshComponenSrc = Cast<USkeletalMeshComponent>(ObjSrc);

			USkeletalMesh* tempMesh;
			if (lua_isuserdata(L, 3))
				tempMesh = Cast<USkeletalMesh>(wLua::FLuaUtils::GetUObject(L, 3, "SkeletalMesh"));
			else
				tempMesh = nullptr;

			if (!pSkeletalMeshComponenDst || !pSkeletalMeshComponenSrc || !tempMesh)
			{
				wLua::LuaStatic::traceback(L, "VertexFromOtherMesh invalid params");
				lua_error(L);
				return 1;
			}

			USkeletalMesh* pSkelMeshDst = tempMesh ? tempMesh : pSkeletalMeshComponenDst->SkeletalMesh;
			USkeletalMesh* pSkelMeshSrc = pSkeletalMeshComponenSrc->SkeletalMesh;

			if (!pSkelMeshDst || !pSkelMeshSrc)
			{
				wLua::LuaStatic::traceback(L, "VertexFromOtherMesh invalid params");
				lua_error(L);
				return 1;
			}

			//先Tick一下
			if (pSkeletalMeshComponenSrc->MasterPoseComponent.IsValid())
			{
				USkeletalMeshComponent* pSkeletalMesh = Cast<USkeletalMeshComponent>(pSkeletalMeshComponenSrc->MasterPoseComponent.Get());
				if (pSkeletalMesh)
					pSkeletalMesh->TickComponent(0.001f, ELevelTick::LEVELTICK_All, NULL);
			}
			else
				pSkeletalMeshComponenSrc->TickComponent(0.001f, ELevelTick::LEVELTICK_All, NULL);

			// UObject *Outer = pSkelMeshDst->GetOuter();

			FString strName = TEXT("DuplicateSkelMesh") + FString::FormatAsNumber(g_iDuplicateHeadCount++);
			USkeletalMesh *DupObj = Cast<USkeletalMesh>(DuplicateObject(pSkelMeshDst, nullptr, *strName, true));
			USkeletalMeshComponent::UpdateVertexBuffersFromOther(DupObj, pSkeletalMeshComponenSrc);
			DupObj->InitResources();

			pSkeletalMeshComponenDst->SetSkeletalMesh(Cast<USkeletalMesh>(DupObj));

			lua_pushboolean(L, true);
			return 1;
		}

		static int GetCurWorldPostProcessVolumes(lua_State * L)
		{
			if (!AAzureEntryPoint::Instance)
				return 0;
			UWorld* pWorld = AAzureEntryPoint::Instance->GetWorld();
			if (!pWorld)
				return 0;

			lua_newtable(L);
			int i = 1;
			for (auto VolumeIt = pWorld->PostProcessVolumes.CreateIterator(); VolumeIt; ++VolumeIt)
			{
				APostProcessVolume* pVolume = Cast<APostProcessVolume>(*VolumeIt);
				if (!pVolume)
					continue;
				wLua::FLuaUtils::ReturnUObject(L, pVolume);
				lua_rawseti(L, -2, i);
				i++;
			}
			return 1;
		}

		static int GetCurWorldCullDistanceVolumes(lua_State * L)
		{
			if (!AAzureEntryPoint::Instance)
				return 0;
			UWorld* pWorld = AAzureEntryPoint::Instance->GetWorld();
			if (!pWorld)
				return 0;

			lua_newtable(L);
			int i = 1;
			FActorIterator AllActorsItr = FActorIterator(pWorld);
			while (AllActorsItr)
			{
				ACullDistanceVolume* pVolume = Cast<ACullDistanceVolume>(*AllActorsItr);
				if (pVolume)
				{
					wLua::FLuaUtils::ReturnUObject(L, pVolume);
					lua_rawseti(L, -2, i);
					i++;
				}
				++AllActorsItr;
			}
			return 1;
		}

		static int UEDuplicateObject(lua_State * L)
		{
			UObject* Obj = wLua::FLuaUtils::GetUObject(L, 1, "Object");

			if (!Obj)
			{
				wLua::LuaStatic::traceback(L, "DuplicateObject #1 must be a Object");
				lua_error(L);
				return 1;
			}

			UObject *Outer = Obj->GetOuter();
			if (lua_isuserdata(L, 2))
			{
				Outer = wLua::FLuaUtils::GetUObject(L, 2, "Object");
				if (!Outer)
				{
					wLua::LuaStatic::traceback(L, "DuplicateObject #2 must be a Object");
					lua_error(L);
					return 1;
				}
			}

			FName Name(NAME_None);
			if (lua_isstring(L, 3))
			{
				Name = UTF8_TO_TCHAR(luaL_checkstring(L, 3));
			}

			UObject *DupObj = DuplicateObject(Obj, Outer, Name);

			if (DupObj)
				wLua::FLuaUtils::ReturnUObject(L, DupObj);
			else
				lua_pushnil(L);

			return 1;
		}

		static int DuplicateActor(lua_State * L)
		{
			AActor* TempalteActor = (AActor*)wLua::FLuaUtils::GetUObject(L, 1, "Actor");

			if (!TempalteActor)
			{
				wLua::LuaStatic::traceback(L, "DuplicateActor #1 must be a Actor");
				lua_error(L);
				return 1;
			}

			FName Name(NAME_None);
			if (lua_isstring(L, 2))
			{
				Name = UTF8_TO_TCHAR(luaL_checkstring(L, 2));
			}

			AActor *Owner = TempalteActor->GetOwner();
			if (lua_isuserdata(L, 3))
			{
				Owner = (AActor *)wLua::FLuaUtils::GetUObject(L, 3, "Actor");
				if (!Owner)
				{
					wLua::LuaStatic::traceback(L, "DuplicateObject #3 must be a AActor");
					lua_error(L);
					return 1;
				}
			}

			ULevel *OverrideLevel = nullptr;
			if (lua_isuserdata(L, 4))
			{
				OverrideLevel = (ULevel *)wLua::FLuaUtils::GetUObject(L, 4, "Level");
				if (!OverrideLevel)
				{
					wLua::LuaStatic::traceback(L, "DuplicateObject #4 must be a ULevel");
					lua_error(L);
					return 1;
				}
			}

			UWorld* World = TempalteActor->GetWorld();
			FActorSpawnParameters params;
			params.Template = TempalteActor;
			params.Name = Name;
			params.Owner = Owner;
			params.OverrideLevel = OverrideLevel;

			AActor* DuplicatedActor = World->SpawnActor<AActor>(TempalteActor->GetClass(), params);
			DuplicatedActor->GetRootComponent()->ResetAttachChildren();

			if (DuplicatedActor)
				wLua::FLuaUtils::ReturnUObject(L, DuplicatedActor);
			else
				lua_pushnil(L);

			return 1;
		}

		static int DuplicateWidget(lua_State * L)
		{
			UObject* Obj = wLua::FLuaUtils::GetUObject(L, 1, "Widget");
			UWidget * Widget = Cast<UWidget>(Obj);

			if (!Widget)
			{
				wLua::LuaStatic::traceback(L, "DuplicateWidget #1 must be a Widget");
				lua_error(L);
				return 1;
			}

			FName Name(NAME_None);
			if (lua_isstring(L, 2))
			{
				Name = UTF8_TO_TCHAR(luaL_checkstring(L, 2));
				if (Widget->GetFName() == Name)
				{
					wLua::LuaStatic::traceback(L, "DuplicateWidget Widget->GetFName() == Name");
					lua_error(L);
					return 1;
				}
			}

			UWidget *DupWidget = UUMGCustomStatics::StaticDuplicateWidget(Widget, Name);

			if (DupWidget)
				wLua::FLuaUtils::ReturnUObject(L, DupWidget);
			else
				lua_pushnil(L);

			return 1;
		}
		static int DuplicateWidgetReparent(lua_State * L)
		{
			UObject* Obj = wLua::FLuaUtils::GetUObject(L, 1, "Widget");
			UWidget * Widget = Cast<UWidget>(Obj);

			if (!Widget)
			{
				wLua::LuaStatic::traceback(L, "DuplicateWidgetReparent #1 must be a Widget");
				lua_error(L);
				return 1;
			}

			UObject* Obj2 = wLua::FLuaUtils::GetUObject(L, 2, "PanelWidget");
			UPanelWidget * NewParentWidget = Cast<UPanelWidget>(Obj2);

			if (!NewParentWidget)
			{
				wLua::LuaStatic::traceback(L, "DuplicateWidgetReparent #2 must be a UPanelWidget");
				lua_error(L);
				return 1;
			}

			FName Name(NAME_None);
			if (lua_isstring(L, 3))
			{
				Name = UTF8_TO_TCHAR(luaL_checkstring(L, 3));
				if (Widget->GetFName() == Name)
				{
					wLua::LuaStatic::traceback(L, "DuplicateWidgetReparent Widget->GetFName() == Name");
					lua_error(L);
					return 1;
				}
			}

			UWidget *DupWidget = UUMGCustomStatics::StaticDuplicateWidget(Widget, NewParentWidget, Name);

			if (DupWidget)
				wLua::FLuaUtils::ReturnUObject(L, DupWidget);
			else
				lua_pushnil(L);

			return 1;
		}
		static int GameStarted(lua_State * L)
		{
			if (!AAzureEntryPoint::Instance)
				return 0;

			if (lua_isboolean(L, 1))
			{
				bool bStarted = !!lua_toboolean(L, 1);
				AAzureEntryPoint::Instance->m_bStarted = bStarted;
				return 0;
			}

			lua_pushboolean(L, AAzureEntryPoint::Instance->m_bStarted ? 1 : 0);
			return 1;
		}
		static int StreamingAssetReadFileText(lua_State *L)
		{
			const char *name = luaL_checkstring(L, 1);
			if (name)
			{
				auto ansiContent = StreamingAssetHelper::ReadFileText(UTF8_TO_TCHAR(name));
				if (ansiContent.size() > 0)
				{
					lua_pushlstring(L, &ansiContent[0], ansiContent.size());
					return 1;
				}
			}
			return 0;
		}

		static int GetStreamingAssetsPath(lua_State *L)
		{
			auto path = StreamingAssetHelper::GetStreamingAssetsPath();
			lua_pushstring(L, TCHAR_TO_UTF8(*path));
			return 1;
		}

		UMaterialParameterCollectionInstance* GetParameterCollectionInstance(FString& CollectionName)
		{
			if (!AAzureEntryPoint::IsInit())
				return nullptr;

			for (UMaterialParameterCollection* CurrentCollection : TObjectRange<UMaterialParameterCollection>())
			{
				if (CurrentCollection->GetName()== CollectionName)
				{
					UWorld* pCurWorld = AAzureEntryPoint::Instance->GetWorld();
					//UWorld* pSceneWorld = nullptr;
					//// 0为EntryPoint  1为加载的图  2~n 为sub图（相位）
					//ULevel* pLevel = pCurWorld->GetNumLevels() > 1 ? pCurWorld->GetLevel(1) : nullptr;
					//if (pLevel)
					//	pSceneWorld = Cast<UWorld>(pLevel->GetOuter());

					UMaterialParameterCollectionInstance* pInstance = nullptr;
					/*if (pSceneWorld)
						pInstance = pSceneWorld->GetParameterCollectionInstance(CurrentCollection);
					else*/
						pInstance = pCurWorld->GetParameterCollectionInstance(CurrentCollection);
					return pInstance;
				}
			}
			return nullptr;
		}

		inline bool ReadFloatArray(lua_State *L, int curIdx, float* buf, int count)
		{
			luaL_checktype(L, curIdx, LUA_TTABLE);
			int len = lua_objlen(L, curIdx);

			if (len != count)
			{
				return false;
			}

			for (int i = 0; i < len; ++i)
			{
				lua_rawgeti(L, curIdx, i + 1);
				buf[i] = (float)luaL_checknumber(L, -1);
				lua_pop(L, 1);
			}

			return true;
		}

		static int GetTimeSeconds(lua_State *L)
		{
			if (!AAzureEntryPoint::IsInit())
				return 0;

			UWorld* World = AAzureEntryPoint::Instance->GetWorld();
			lua_pushnumber(L, World ? World->GetTimeSeconds() : 0.f);
			return 1;
		}

		static int SetVectorParameterCollection(lua_State *L)
		{
			FString CollectionName = UTF8_TO_TCHAR(lua_tostring(L, 1));
			FName ParameterName(NAME_None);
			ParameterName = UTF8_TO_TCHAR(luaL_checkstring(L, 2));
			FLinearColor ParameterValue;
			ReadFloatArray(L, 3, (float*)&ParameterValue, 4);
			
			UMaterialParameterCollectionInstance* pInstance = GetParameterCollectionInstance(CollectionName);
			
			if (pInstance)
				pInstance->SetVectorParameterValue(ParameterName, ParameterValue);
			return 0;
		}

		static int GetVectorParameterCollection(lua_State *L)
		{
			FString CollectionName = UTF8_TO_TCHAR(lua_tostring(L, 1));
			FName ParameterName(NAME_None);
			ParameterName = UTF8_TO_TCHAR(luaL_checkstring(L, 2));
			
			UMaterialParameterCollectionInstance* pInstance = GetParameterCollectionInstance(CollectionName);
			
			if (pInstance)
			{
				FLinearColor result;
				if (pInstance->GetVectorParameterValue(ParameterName, result))
				{
					wLua::FLuaLinearColor::Return(L, result);
					return 1;
				}
			}
			return 0;
		}

		static int SetScalarParameterCollection(lua_State *L)
		{
			FString CollectionName = UTF8_TO_TCHAR(lua_tostring(L, 1));
			FName ParameterName(NAME_None);
			ParameterName = UTF8_TO_TCHAR(luaL_checkstring(L, 2));
			float ParameterValue = (float)(luaL_checknumber(L, 3));

			UMaterialParameterCollectionInstance* pInstance = GetParameterCollectionInstance(CollectionName);

			if (pInstance)
				pInstance->SetScalarParameterValue(ParameterName, ParameterValue);
			return 0;
		}

		static int GetScalarParameterCollection(lua_State *L)
		{
			FString CollectionName = UTF8_TO_TCHAR(lua_tostring(L, 1));
			FName ParameterName(NAME_None);
			ParameterName = UTF8_TO_TCHAR(luaL_checkstring(L, 2));

			UMaterialParameterCollectionInstance* pInstance = GetParameterCollectionInstance(CollectionName);

			if (pInstance)
			{
				float result;
				if (pInstance->GetScalarParameterValue(ParameterName, result))
				{
					lua_pushnumber(L, result);
					return 1;
				}
			}
			return 0;
		}

		static int CreateDynamicMaterial(lua_State* L)
		{
			UMaterialInstance* Material = Cast<UMaterialInstance>(wLua::FLuaUtils::GetUObject(L, 1, "MaterialInterface"));
			if (!Material)
			{
				wLua::LuaStatic::traceback(L, "CreateDynamicMaterial #1 must be a MaterialInstance");
				lua_error(L);
				return 1;
			}
			UMaterialInstanceDynamic* MID = Cast<UMaterialInstanceDynamic>(Material);
			if (!MID)
			{
				MID = UMaterialInstanceDynamic::Create(Material, nullptr);
			}
			FLuaUtils::ReturnUObject(L, MID);
			return 1;
		}

		static int CreateDynamicMaterialForMeshComponent(lua_State *L)
		{
			UMeshComponent* Obj = Cast<UMeshComponent>(wLua::FLuaUtils::GetUObject(L, 1, "MeshComponent"));
			if (!Obj)
			{
				wLua::LuaStatic::traceback(L, "CreateDynamicMaterialForMeshComponent #1 must be a MeshComponent");
				lua_error(L);
				return 1;
			}

			TArray<UMaterialInterface*> ReturnValue;

			UMaterialInterface* mat = nullptr;
			if (lua_isnoneornil(L, 2))
			{
				//	NO mat specified: Use Origin Material!
				int32 NumMaterials = Obj->GetNumMaterials();
				ReturnValue.AddZeroed(NumMaterials);

				for (int32 i = 0; i < NumMaterials; ++i)
				{
					UMaterialInstanceDynamic* MID = Obj->CreateDynamicMaterialInstance(i);
					ReturnValue[i] = MID;
				}
			}
			else
			{
				mat = Cast<UMaterialInterface>(wLua::FLuaUtils::GetUObject(L, 2, "MaterialInterface"));
				if (!mat)
				{
					wLua::LuaStatic::traceback(L, "CreateDynamicMaterialForMeshComponent #2 must be a MaterialInterface");
					lua_error(L);
					return 1;
				}

				ReturnValue = AzureUtility::CreateDynamicMaterialForMeshComponent(Obj, mat);
			}
			 
			lua_newtable(L);
			int i = 1;
			for (auto It = ReturnValue.CreateConstIterator();It; ++It, ++i)
			{
				wLua::FLuaUtils::ReturnUObject(L, (*It)); 
				lua_rawseti(L, -2, i);
			}
			return 1;
		}

		static int PlayWorldCameraShake(lua_State *L)
		{
			UObject* uObj = Cast<UObject>(wLua::FLuaUtils::GetUObject(L, 1, "Object"));
			if (!uObj)
			{
				wLua::LuaStatic::traceback(L, "PlayWorldCameraShake #1 must be a UObject");
				lua_error(L);
				return 1;
			}

			UObject* cls = wLua::FLuaUtils::GetUObject(L, 2, "BlueprintGeneratedClass");
			UClass* pBP = Cast<UClass>(cls);
			if (!pBP)
			{
				wLua::LuaStatic::traceback(L, "PlayWorldCameraShake #2 must be a Blueprint(UCameraShake)");
				lua_error(L);
				return 1;
			}
			TSubclassOf<UCameraShake> shake(pBP);
			if (!*shake)
			{
				wLua::LuaStatic::traceback(L, "PlayWorldCameraShake #2 must be a UCameraShake class");
				lua_error(L);
				return 1;
			}

			FVector Epicenter = wLua::FLuaVector::Get(L, 3);
			float InnerRadius = (float)(luaL_checknumber(L, 4));
			float OuterRadius = (float)(luaL_checknumber(L, 5));
			float Falloff = lua_isnoneornil(L, 6) ? float(1.000000) : (float)(luaL_checknumber(L, 6));
			bool bOrientShakeTowardsEpicenter = lua_isnoneornil(L, 7) ? bool(false) : !!(lua_toboolean(L, 7));

			UGameplayStatics::PlayWorldCameraShake(uObj, shake, Epicenter, InnerRadius, OuterRadius, Falloff, bOrientShakeTowardsEpicenter);

			return 0;
		}

		static int EnableLightOfLevel(lua_State *L)
		{
			ULevel* pLevel = Cast<ULevel>(wLua::FLuaUtils::GetUObject(L, 1, "Level"));
			if (!pLevel)
			{
				wLua::LuaStatic::traceback(L, "EnableLightOfLevel #1 must be a Level");
				lua_error(L);
				return 1;
			}
			bool bEnable = !!lua_toboolean(L, 2);
			AzureUtility::EnableLightOfLevel(pLevel, bEnable);

			return 0;
		}

		static int RaiseEventForUObject(lua_State *L)
		{
			UObject* uObj = Cast<UObject>(wLua::FLuaUtils::GetUObject(L, 1, "Object"));
			if (!uObj)
			{
				wLua::LuaStatic::traceback(L, "RaiseEventForUObject #1 must be a UObject");
				lua_error(L);
				return 1;
			}
			FName Name = UTF8_TO_TCHAR(luaL_checkstring(L, 2));
			UFunction* Function = uObj->FindFunction(Name);
			if (!Function)
			{
				return 0;
			}

			if (lua_isboolean(L, 3))
			{
				struct FDispatchParams
				{
					bool bEnable;
				} Params;
				Params.bEnable = !!(lua_toboolean(L, 3));

				if (Function->NumParms != 1 || Function->ParmsSize != sizeof(FDispatchParams))
				{
					wLua::LuaStatic::traceback(L, "RaiseEventForUObject: boolean, Function->NumParms != 1 || Function->ParmsSize != sizeof(FDispatchParams)");
					lua_error(L);
					return 1;
				}
				AzureUtility::RaiseEventForUObject(uObj, Name, &Params);
			}
			else if (lua_isnumber(L, 3))
			{
				struct FDispatchParams
				{
					int32 input_number;
				} Params;
				Params.input_number = lua_tonumber(L, 3);

				if (Function->NumParms != 1 || Function->ParmsSize != sizeof(FDispatchParams))
				{
					wLua::LuaStatic::traceback(L, "RaiseEventForUObject: number, Function->NumParms != 1 || Function->ParmsSize != sizeof(FDispatchParams)");
					lua_error(L);
					return 1;
				}
				AzureUtility::RaiseEventForUObject(uObj, Name, &Params);
			}
			else
			{
				AzureUtility::RaiseEventForUObject(uObj, Name);
			}
			return 0;
		}

		static int ChangeTimeScale(lua_State *L)
		{
			if (!AAzureEntryPoint::IsInit())
				return 0;

			float fDestScale = luaL_checknumber(L, 1);
			float fInTime = luaL_checknumber(L, 2);
			float fKeepTime = luaL_checknumber(L, 3);
			float fOutTime = luaL_checknumber(L, 4);
			AAzureEntryPoint::Instance->ChangeTimeScale(fDestScale, fInTime, fKeepTime, fOutTime);
			return 0;
		}

		static int GetSkyBoxActor(lua_State *L)
		{
			AActor *pSkyBox = AAzureEntryPoint::Instance != nullptr ? AAzureEntryPoint::Instance->GetSkyBoxActor() : nullptr;
			if (pSkyBox != nullptr)
			{
				FLuaUtils::ReturnUObject(L, pSkyBox);
			}
			else
			{
				lua_pushnil(L);
			}
			return 1;
		}

		static int GetEnvironmentManager(lua_State *L)
		{
			AActor *pEnvironmentManager = AAzureEntryPoint::Instance != nullptr ? AAzureEntryPoint::Instance->GetEnvironmentManager() : nullptr;
			if (pEnvironmentManager != nullptr)
			{
				FLuaUtils::ReturnUObject(L, pEnvironmentManager);
			}
			else
			{
				lua_pushnil(L);
			}
			return 1;
		}

		static int GetStackBackTrace(lua_State* L)
		{
			int maxDepth = luaL_optint(L, 1, 32);
			TArray<uint64, TInlineAllocator<128>> callstack;
			callstack.SetNum(maxDepth);
			uint32 depth = FPlatformStackWalk::CaptureStackBackTrace(callstack.GetData(), maxDepth);
			lua_newtable(L);
			for (int i=0; i<depth; ++i)
			{
				lua_pushlightuserdata(L, (void*)callstack[i]);
				lua_rawseti(L, -2, i+1);
			}
			return 1;
		}

		static int AddressToLine(lua_State* L)
		{
			luaL_checktype(L, 1, LUA_TLIGHTUSERDATA);
			void* address = lua_touserdata(L, 1);
			FProgramCounterSymbolInfo symbolInfo;
			FPlatformStackWalk::ProgramCounterToSymbolInfo((uint64)address, symbolInfo);
			ANSICHAR stringBuffer[4096] = {};
			if (FPlatformStackWalk::SymbolInfoToHumanReadableString(symbolInfo, stringBuffer, sizeof(stringBuffer)/sizeof(stringBuffer[0])))
			{
				lua_pushstring(L, TCHAR_TO_UTF8(ANSI_TO_TCHAR(stringBuffer)));
				return 1;
			}
			return 0;
		}

		static int lua_GetGameDataSendFilter(lua_State * L)
		{
			int len = lua_objlen(L, -1);
			for (int i = 1; i <= len; i++)
			{
				lua_rawgeti(L, -1, i);
				int id = lua_tointeger(L, -1);
				AzureGameSession::GameDataSendFilterList.insert(id);
				lua_pop(L, 1);
			}

			return 0;
		}

		static int lua_AddUObjectDeleteListener(lua_State * L)
		{
			class FLuaUObjectDeleteListener : public FUObjectArray::FUObjectDeleteListener
			{
				struct FObjInfo
				{
					wLua::lua_registry_handle refID;
					FString name;
					FString type;
				};
				TMap<UObjectBase*, FObjInfo> ObjToListen;
			public:
				FLuaUObjectDeleteListener()
				{
					GUObjectArray.AddUObjectDeleteListener(this);
				}
				virtual ~FLuaUObjectDeleteListener()
				{
					GUObjectArray.RemoveUObjectDeleteListener(this);
				}

				void ref(UObject* Obj, lua_State* InL)
				{
					if (AAzureEntryPoint::Instance && Obj)
					{
						const FObjInfo *pInfo = ObjToListen.Find(Obj);
						if (pInfo == nullptr)
						{
							FObjInfo& Info = ObjToListen.Add(Obj);
							Info.name = Obj->GetName();
							Info.type = (Obj->GetClass() == nullptr ? TEXT("") : Obj->GetClass()->GetName());
							Info.refID = wLua::lua_registry_handle::wlua_ref(InL, LUA_REGISTRYINDEX);
						}
					}
				}
				void unref(UObject* Obj)
				{
					if (AAzureEntryPoint::Instance && Obj)
					{
						const FObjInfo *pInfo = ObjToListen.Find(Obj);
						if (pInfo != nullptr && !pInfo->refID.IsNoRef())
						{
							lua_State_Wrapper wL = AAzureEntryPoint::Instance->GetWLua()->GetL();
							wLua::lua_registry_handle::wlua_unref(wL, LUA_REGISTRYINDEX, pInfo->refID);
							ObjToListen.Remove(Obj);
						}
					}
				}
				virtual void NotifyUObjectDeleted(const class UObjectBase *Object, int32 Index)
				{
					wLua::Lua* WL = AAzureEntryPoint::Instance ? AAzureEntryPoint::Instance->GetWLua() : nullptr;
					if (WL)
					{
						const FObjInfo *pInfo = ObjToListen.Find(Object);
						if (pInfo != nullptr && !pInfo->refID.IsNoRef())
						{
							lua_State_Wrapper LL = WL->GetL();
							lua_rawgeti(LL, LUA_REGISTRYINDEX, pInfo->refID);
							lua_pushstring(LL, TCHAR_TO_UTF8(*pInfo->name));
							lua_pushstring(LL, TCHAR_TO_UTF8(*pInfo->type));
							WL->Call(2);
							ObjToListen.Remove(Object);
						}
					}
				}
			};
			static FLuaUObjectDeleteListener Listener;

			UObject* Obj = wLua::FLuaUtils::GetUObject(L, 1, "Object");
			if (lua_isfunction(L, 2))
			{
				Listener.ref(Obj, L);
				lua_pushboolean(L, 1);
			}
			else
			{
				Listener.unref(Obj);
				lua_pushboolean(L, 0);
			}
			return 1;
		}

		static int lua_GetGameLogDir(lua_State * L)
		{
			bool IsAbsPath = lua_toboolean(L, 1);

			if (IsAbsPath)
			{
#if PLATFORM_ANDROID
				FString ProjectLogDir = FPaths::ProjectLogDir();
				ProjectLogDir.ReplaceInline(TEXT("../"), TEXT(""));
				ProjectLogDir.ReplaceInline(TEXT(".."), TEXT(""));
				ProjectLogDir.ReplaceInline(FPlatformProcess::BaseDir(), TEXT(""));
				FString ProjectLogAbsDir = GFilePathBase + FString("/UE4Game/") + FApp::GetProjectName() + FString("/") + ProjectLogDir;
#elif PLATFORM_IOS
				FString ProjectLogDir = FPaths::ProjectLogDir();
				ProjectLogDir.ReplaceInline(TEXT("../"), TEXT(""));
				ProjectLogDir.ReplaceInline(TEXT(".."), TEXT(""));
				ProjectLogDir.ReplaceInline(FPlatformProcess::BaseDir(), TEXT(""));
				//FString DownloadPath = FString([NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) objectAtIndex:0]) + TEXT("/");
				FString ProjectLogAbsDir = ProjectLogDir;
#else
				FString ProjectLogDir = FPaths::ProjectLogDir();
				FString ProjectLogAbsDir = IFileManager::Get().ConvertToAbsolutePathForExternalAppForRead(*ProjectLogDir);
#endif
				lua_pushstring(L, TCHAR_TO_UTF8(*ProjectLogAbsDir));
				return 1;
			}
			else {
				FString ProjectLogDir = FPaths::ProjectLogDir();
				lua_pushstring(L, TCHAR_TO_UTF8(*ProjectLogDir));
				return 1;
			}
		}

		static int lua_EnableInputPreProcessor(lua_State * L)
		{
			class FAzureInputProcessor : public IInputProcessor
			{
			public:
				virtual void Tick(const float, FSlateApplication&, TSharedRef<ICursor>) {}
				virtual bool HandleMouseButtonDownEvent(FSlateApplication& SlateApp, const FPointerEvent& MouseEvent)
				{
					if (AAzureEntryPoint::Instance)
					{
						if (MouseEvent.GetPointerIndex() == 0)
						{
							wLua::Lua *wLua = AAzureEntryPoint::Instance->GetWLua();
							lua_State_Wrapper L = wLua->GetL();
							lua_getglobal(L, "OnClickScreen");
							FLuaVector2D::Return(L, MouseEvent.GetScreenSpacePosition());
							wLua->Call(1);
						}
					}
					return false;
				}
			};
			FSlateApplication::Get().UnregisterAllInputPreProcessors();
			if (lua_toboolean(L, 1))
				FSlateApplication::Get().RegisterInputPreProcessor(MakeShareable(new FAzureInputProcessor()));
			return 0;
		}

		static int GetQualityLevels(lua_State *L)
		{
			Scalability::FQualityLevels ret = Scalability::GetQualityLevels();
			lua_pushnumber(L, ret.ViewDistanceQuality);
			lua_pushnumber(L, ret.AntiAliasingQuality);
			lua_pushnumber(L, ret.PostProcessQuality);
			lua_pushnumber(L, ret.ShadowQuality);
			lua_pushnumber(L, ret.TextureQuality);
			lua_pushnumber(L, ret.EffectsQuality);
			lua_pushnumber(L, ret.FoliageQuality);
			return 7;
		}
		static int SetQualityLevel(lua_State *L)
		{
			Scalability::FQualityLevels ret = Scalability::GetQualityLevels();
			TCHAR* InGroupName = UTF8_TO_TCHAR(lua_tostring(L, 1));
			if (!InGroupName)
				return 0;

			int InQualityLevel = lua_tointeger(L, 2);
			if (FCString::Strcmp(InGroupName, TEXT("ResolutionQuality")) == 0) ret.ResolutionQuality = InQualityLevel;
			else if (FCString::Strcmp(InGroupName, TEXT("ViewDistanceQuality")) == 0) ret.ViewDistanceQuality = InQualityLevel;
			else if (FCString::Strcmp(InGroupName, TEXT("AntiAliasingQuality")) == 0) ret.AntiAliasingQuality = InQualityLevel;
			else if (FCString::Strcmp(InGroupName, TEXT("PostProcessQuality")) == 0) ret.PostProcessQuality = InQualityLevel;
			else if (FCString::Strcmp(InGroupName, TEXT("ShadowQuality")) == 0) ret.ShadowQuality = InQualityLevel;
			else if (FCString::Strcmp(InGroupName, TEXT("TextureQuality")) == 0) ret.TextureQuality = InQualityLevel;
			else if (FCString::Strcmp(InGroupName, TEXT("EffectsQuality")) == 0) ret.EffectsQuality = InQualityLevel;
			else if (FCString::Strcmp(InGroupName, TEXT("FoliageQuality")) == 0) ret.FoliageQuality = InQualityLevel;

			Scalability::SetQualityLevels(ret);
			return 0;
		}

		//////////////////////////////////////////////////////////////////////////
		static int lua_LoadStreamLevel(lua_State * L)
		{
			UObject * WorldContextObject = wLua::FLuaUtils::GetUObject(L, 1, "Object");
			bool bOutSuccess;
			const FString LevelName2 = UTF8_TO_TCHAR(lua_tostring(L, 2));
			ULevelStreaming * stream =  ULevelStreamingKismet::LoadLevelInstance(WorldContextObject, LevelName2, FVector::ZeroVector, FRotator::ZeroRotator, bOutSuccess);
			AddExternalLogResName(LevelName2);
			wLua::FLuaUtils::ReturnUObject(L, stream);
			return 1;
		}
		//

		static int lua_CreateWorldTileLevelStreaming(lua_State * L)
		{
			UObject* WorldContextObject = wLua::FLuaUtils::GetUObject(L, 1, "Object");
			ULevelStreamingDynamic *LevelStreaming = nullptr;

			UWorld* const World = GEngine->GetWorldFromContextObject(WorldContextObject, EGetWorldErrorMode::LogAndReturnNull);
			if (World)
			{
				TArray<FName> LevelPackageNames;
				if (lua_istable(L, 2))
				{
					lua_pushnil(L);
					while (lua_next(L, -2) != 0)
					{
						FString PackageName = UTF8_TO_TCHAR(luaL_checkstring(L, -1));
						if (PackageName.Len() > 0)
						{
							LevelPackageNames.Add(*PackageName);
						}
						lua_pop(L, 1);
					}
				}
				
				if (LevelPackageNames.Num() > 0)
				{
					LevelStreaming = NewObject<ULevelStreamingDynamic>(World, NAME_None, RF_Transient);

					FName LevelPackageName = LevelPackageNames[0];
					LevelStreaming->PackageNameToLoad = LevelPackageName;

					//AddExternalLogResName(LevelPackageName.ToString());

#if WITH_EDITOR				
					if (World->IsPlayInEditor())
					{
						FString PIELevelPackageName = LevelPackageName.ToString();
						const FString ShortPackageName = FPackageName::GetShortName(PIELevelPackageName);
						const FString PackagePath = FPackageName::GetLongPackagePath(PIELevelPackageName);
						PIELevelPackageName = PackagePath + TEXT("/") + World->StreamingLevelsPrefix + ShortPackageName;
						LevelPackageName = FName(*PIELevelPackageName);
					}
#endif
					LevelStreaming->SetWorldAssetByPackageName(LevelPackageName);

					if (LevelPackageNames.Num() > 1)
					{
						LevelStreaming->LODPackageNames.Empty();
						for (int32 Index = 1; Index < LevelPackageNames.Num(); Index++)
						{
							LevelStreaming->LODPackageNames.Add(LevelPackageNames[Index]);

							//AddExternalLogResName(LevelPackageNames[Index].ToString());
						}
					}
				}

			}

			wLua::FLuaUtils::ReturnUObject(L, LevelStreaming);
			return 1;
		}

		static int lua_SetWorldUseGlobalSHIndirectLighting(lua_State * L)
		{
			UObject* WorldContextObject = wLua::FLuaUtils::GetUObject(L, 1, "Object");
			UWorld*  World = GEngine->GetWorldFromContextObject(WorldContextObject, EGetWorldErrorMode::LogAndReturnNull);
			bool bUse = lua_toboolean(L, 2);

			if (World)
			{
				World->GetWorldSettings()->bAzureUseGlobalSHIndirectLighting = bUse;
			}
			
			return 0;
		}

		static int lua_GetWorldUseGlobalSHIndirectLighting(lua_State * L)
		{
			UObject* WorldContextObject = wLua::FLuaUtils::GetUObject(L, 1, "Object");
			UWorld*  World = GEngine->GetWorldFromContextObject(WorldContextObject, EGetWorldErrorMode::LogAndReturnNull);

			if (World)
			{
				bool result = World->GetWorldSettings()->bAzureUseGlobalSHIndirectLighting;
				lua_pushboolean(L, result);
				return 1;
			}
			
			return 0;
		}

		static int lua_SetWorldStreamingLevels(lua_State* L)
		{
			UObject* WorldContextObject = wLua::FLuaUtils::GetUObject(L, 1, "Object");
			UWorld*  World = GEngine->GetWorldFromContextObject(WorldContextObject, EGetWorldErrorMode::LogAndReturnNull);

			TArray<ULevelStreaming*> LevelStreamings; 
			if (lua_istable(L, 2))
			{
				lua_pushnil(L);
				while (lua_next(L, -2) != 0)
				{
					ULevelStreaming* LevelStreaming = Cast<ULevelStreaming>(wLua::FLuaUtils::GetUObject(L, -1, "LevelStreaming"));
					if (LevelStreaming)
					{
						LevelStreamings.Add(LevelStreaming);
					}
					lua_pop(L, 1);
				}
			}
			if (LevelStreamings.Num() > 0)
			{
				World->SetStreamingLevels(LevelStreamings);
			}
			else
			{
				World->ClearStreamingLevels();
			}
			return 0;
		}

		static int lua_AddWorldStreamingLevels(lua_State* L)
		{
			UObject* WorldContextObject = wLua::FLuaUtils::GetUObject(L, 1, "Object");
			UWorld*  World = GEngine->GetWorldFromContextObject(WorldContextObject, EGetWorldErrorMode::LogAndReturnNull);

			TArray<ULevelStreaming*> LevelStreamings;
			if (lua_istable(L, 2))
			{
				lua_pushnil(L);
				while (lua_next(L, -2) != 0)
				{
					ULevelStreaming* LevelStreaming = Cast<ULevelStreaming>(wLua::FLuaUtils::GetUObject(L, -1, "LevelStreaming"));
					if (LevelStreaming)
					{
						LevelStreamings.Add(LevelStreaming);
					}
					lua_pop(L, 1);
				}
			}
			if (LevelStreamings.Num() > 0)
			{
				World->AddStreamingLevels(LevelStreamings);
			}

			return 0;
		}

		static int lua_RemoveWorldStreamingLevels(lua_State* L)
		{
			UObject* WorldContextObject = wLua::FLuaUtils::GetUObject(L, 1, "Object");
			UWorld*  World = GEngine->GetWorldFromContextObject(WorldContextObject, EGetWorldErrorMode::LogAndReturnNull);

			TArray<ULevelStreaming*> LevelStreamings;
			if (lua_istable(L, 2))
			{
				lua_pushnil(L);
				while (lua_next(L, -2) != 0)
				{
					ULevelStreaming* LevelStreaming = Cast<ULevelStreaming>(wLua::FLuaUtils::GetUObject(L, -1, "LevelStreaming"));
					if (LevelStreaming)
					{
						LevelStreamings.Add(LevelStreaming);
					}
					lua_pop(L, 1);
				}
			}
			if (LevelStreamings.Num() > 0)
			{
				World->RemoveStreamingLevels(LevelStreamings);
			}

			return 0;
		}

		static int lua_GetAverageFPS(lua_State *L)
		{
			lua_pushnumber(L, GAverageFPS);
			return 1;
		}

		static int lua_SetSceneViewScaleFactor(lua_State *L)
		{
			float Factor = luaL_checknumber(L, 1); // [0.1f, 4.0f]
			static IConsoleVariable* CVar = IConsoleManager::Get().FindConsoleVariable(TEXT("r.ScreenPercentage"));
			CVar->Set(FMath::Clamp(Factor, 0.1f, 4.0f) * 100, ECVF_SetByConsole);
			return 0;
		}
		static int lua_GetSceneViewScaleFactor(lua_State *L)
		{
			static const auto ScreenPercentageCVar = IConsoleManager::Get().FindTConsoleVariableDataFloat(TEXT("r.ScreenPercentage"));
			float Factor = FMath::Clamp(ScreenPercentageCVar->GetValueOnGameThread() / 100.0f, 0.1f, 4.0f);
			lua_pushnumber(L, Factor);
			return 1;
		}

		static int lua_ReplaceMovableIndirectLighting(lua_State *L)
		{
			FVector4 params[8];
			float* paramsPtr = (float*)params;
			bool bReplace = !!lua_toboolean(L, 1);

			if (bReplace)
			{
				int curIdx = 2;
				luaL_checktype(L, curIdx, LUA_TTABLE);
				int len = lua_objlen(L, curIdx);
				check(len == 32);

				for (int i = 0; i < len; ++i)
				{
					lua_rawgeti(L, curIdx, i + 1);
					*paramsPtr = (float)luaL_checknumber(L, -1);
					paramsPtr++;
					lua_pop(L, 1);
				}
			}

			AzureReplaceMovableIndirectLighting(bReplace, params);
			return 0;
		}

		static int lua_ReplaceDirectionalLight(lua_State *L)
		{
			bool bReplace = !!lua_toboolean(L, 1);
			FLinearColor color;
			FVector dir;

			if (bReplace)
			{
				int curIdx = 2;
				ReadFloatArray(L, curIdx++, (float*)&color, 4);
				ReadFloatArray(L, curIdx++, (float*)&dir, 3);
			}

			AzureReplaceDirectionalLight(bReplace, color, dir);
			return 0;
		}

		static int lua_SetReplaceShadowCenterFlag(lua_State *L)
		{
			bool bReplace = !!lua_toboolean(L, 1);
			AzureSetReplaceShadowCenterFlag(bReplace);
			return 0;
		}

		static int lua_SetReplaceShadowCenterPos(lua_State *L)
		{
			FVector pos;
			pos.X = (float)luaL_checknumber(L, 1);
			pos.Y = (float)luaL_checknumber(L, 2);
			pos.Z = (float)luaL_checknumber(L, 3);
			float realFarSplitDist = (float)luaL_checknumber(L, 4);
			AzureSetReplaceShadowCenterPos(pos, realFarSplitDist);
			return 0;
		}

		static int lua_IsReplaceShadowCenter(lua_State * L)
		{
			lua_pushboolean(L, GAzureIsReplaceShadowCenter);
			return 1;
		}

		static int lua_SetMobileDynamicCSMInUse(lua_State *L)
		{
			bool bFlag = !!lua_toboolean(L, 1);
			AzureSetMobileDynamicCSMInUse(bFlag);
			return 0;
		}

		static int lua_SkipPlanarReflectionPointLight(lua_State *L)
		{
			bool bFlag = !!lua_toboolean(L, 1);
			AzureSkipPlanarReflectionPointLight(bFlag);
			return 0;
		}

		static int lua_SetStatInfoFontSize(lua_State *L)
		{
			GAzureStatInfoFontSize = luaL_checkint(L, 1);
			return 0;
		}

		static int lua_SetLevelUseOwnMapBuildData(lua_State *L)
		{
			ULevel* Level = Cast<ULevel>(FLuaUtils::GetUObject(L, 1, "Level"));
			bool bFlag = !!lua_toboolean(L, 2);

			if (Level)
				Level->bUseOwnMapBuildData = bFlag;

			return 0;
		}
		
		//--------------------------   Debug Module ----------------------------------------
		static int lua_Debug_LogError(lua_State * L)
		{
			if (lua_isstring(L, 1))
			{
				LUALOG_ERROR(lua_tostring(L, 1));
			}
			return 0;
		}

		static int lua_Debug_LogWarning(lua_State * L)
		{
			if (lua_isstring(L, 1))
			{
				LUALOG_WARNING(lua_tostring(L, 1));
			}
			return 0;
		}

		static int lua_Debug_LogInfo(lua_State * L)
		{
			if (lua_isstring(L, 1))
			{
				LUALOG(lua_tostring(L, 1));
			}
			return 0;
		}
		

		static int lua_AzureLuaAllocStat(lua_State * L)
		{
			bool bClearPeak = false;

			if (lua_isboolean(L, 1))
				bClearPeak = !!lua_toboolean(L, 1);

			AzureLuaMemFunc::LogStat(bClearPeak);
			return 0;
		}

		//------------------------------------------------------------------------------------

		static int lua_realtimeSinceStartup(lua_State * L)
		{
			if (!AAzureEntryPoint::IsInit())
				return 0;

			double dt = AAzureEntryPoint::Instance->GetRealtimeSinceStartup();
			lua_pushnumber(L, dt);
			return 1;
		}

		static int lua_GetCurFrameTime(lua_State * L)
		{
			if (!AAzureEntryPoint::IsInit())
				return 0;

			double dt = AAzureEntryPoint::Instance->GetCurFrameTime();
			lua_pushnumber(L, dt);
			return 1;
		}

		static int lua_GetCurFrameCount(lua_State* L)
		{
			if (!AAzureEntryPoint::IsInit())
				return 0;

			uint64 fc = AAzureEntryPoint::Instance->GetCurFrameCount();
			lua_pushnumber(L, (uint32)fc);
			return 1;
		}

		static int lua_RemoveRef(lua_State * L)
		{
			wLua::LuaUObjectUserData* userdata = nullptr;
			UObject* Obj = wLua::FLuaUtils::GetUObject(L, 1, "Object",&userdata );
			if (Obj)
			{
				wLua::FLuaUtils::RemoveObjectReference(Obj, userdata->stamp, L);
			}
#ifdef AZURE_BUILD_WLUACHECK
			UE_LOG(LogAzure, Warning, TEXT("lua_RemoveRef: %x  userdata:%x  stamp:%x"), Obj, userdata, userdata ? userdata->stamp : 0);
#endif
			return 0;
		}

		static int lua_GetCursorPos(lua_State * L)
		{
			FVector2D pos = FSlateApplication::Get().GetCursorPos();
			lua_pushnumber(L, pos.X);
			lua_pushnumber(L, pos.Y);
			return 2;
		}

		//2022.07.18 新增
		static int lua_SetCursorPos(lua_State * L)
		{
			float x = float(luaL_checknumber(L, 1));
			float y = float(luaL_checknumber(L, 2));
			FSlateApplication::Get().SetCursorPos(FVector2D(x, y));
			return 0;
		}

		//2022.07.18 新增
		static int lua_ShowCursor(lua_State * L)
		{
			bool bShow = lua_optboolean(L, 1, false);
			FSlateApplication::Get().GetPlatformCursor()->Show(bShow);
			return 0;
		}

		static int lua_GetSceneBufferSize(lua_State *L)
		{
			uint64 saveSize = GSavedViewFamilyBufferSize;
			uint32 sizeX = uint32(saveSize >> 32);
			uint32 sizeY = uint32(GSavedViewFamilyBufferSize);
			lua_pushinteger(L, sizeX);
			lua_pushinteger(L, sizeY);
			return 2;
		}

		static int lua_GetViewportSize(lua_State *L)
		{
			FVector2D size = UWidgetLayoutLibrary::GetViewportSize(AAzureEntryPoint::Instance);
			FLuaVector2D::Return(L,size);
			return 1;
		}

		static int lua_GetViewportSize_Expand(lua_State *L)
		{
			FVector2D size = UWidgetLayoutLibrary::GetViewportSize(AAzureEntryPoint::Instance);
			lua_pushnumber(L, size.X);
			lua_pushnumber(L, size.Y);
			return 2;
		}

		static int lua_GetViewportScale(lua_State *L)
		{
			float scale = UWidgetLayoutLibrary::GetViewportScale(AAzureEntryPoint::Instance);
			lua_pushnumber(L, scale);
			return 1;
		}

		//2022.07.18 新增
		static int lua_GetGameViewport(lua_State *L)
		{
			UGameViewportClient* gameViewport = GEngine->GameViewport;
			wLua::FLuaUtils::ReturnUObject(L, gameViewport);
			return 1;
		}

		//有意违反 Lua 线程限制，测试检查代码的效果
		//param 1: 测试方式，可为 1: Async 调用 Lua 接口;2: 直接改错线程 id
		static int lua_TestThreadChecking(lua_State* L)
		{
			int way = luaL_optint(L, 1, 1);
			if (way == 1)
			{
				Async<void>(EAsyncExecution::Thread, [&, L](){ lua_settop(L, lua_gettop(L)); });
			}
			else if (way == 2)
			{
				g_SetLuaThreadId(1);
			}
			return 0;
		}

		static int lua_EnableThreadChecking(lua_State* L)
		{
			int enabled = lua_toboolean(L, 1);
			g_EnableLuaThreadChecking(enabled);
			return 0;
		}

		static int lua_EnableLuaStateWrapperChecking(lua_State* L)
		{
			bool enabled = lua_toboolean(L, 1) != 0;
			lua_State_Wrapper::EnableChecking(enabled);
			return 0;
		}

		//------------------------------------------------------------------------------------
		static int lua_FullMips_Enable(lua_State* L)
		{
			FAzureFullMipsManager::Get().Enable();
			return 0;
		}

		static int lua_FullMips_Disable(lua_State* L)
		{
			FAzureFullMipsManager::Get().Disable();
			return 0;
		}

		static int lua_FullMips_IsEnabled(lua_State* L)
		{
			lua_pushboolean(L, FAzureFullMipsManager::Get().IsEnabled() ? 1 : 0);
			return 1;
		}

		static int lua_FullMips_Reset(lua_State* L)
		{
			FAzureFullMipsManager::Get().Reset();
			return 0;
		}

		static int lua_FullMips_AddActor(lua_State* L)
		{
			AActor* obj = Cast<AActor>(wLua::FLuaUtils::GetUObject(L, 1, "Actor"));
			if (obj == nullptr)
			{
				LuaStatic::traceback(L);
				lua_error(L);
				return 0;
			}
			FString Tag;
			if (!lua_isnoneornil(L, 2))
			{
				Tag = UTF8_TO_TCHAR(lua_tostring(L, 2));
			}
			FAzureFullMipsManager::Get().AddActor(obj, FName(*Tag));
			return 0;
		}

		static int lua_FullMips_RemoveActor(lua_State* L)
		{
			AActor* obj = Cast<AActor>(wLua::FLuaUtils::GetUObject(L, 1, "Actor"));
			if (obj == nullptr)
			{
				LuaStatic::traceback(L);
				lua_error(L);
				return 0;
			}
			FAzureFullMipsManager::Get().RemoveActor(obj);
			return 0;
		}

		static int lua_FullMips_RemoveActorByTag(lua_State* L)
		{
			if (lua_isnoneornil(L, 1))
			{
				LuaStatic::traceback(L);
				lua_error(L);
				return 0;
			}
			FString Tag = UTF8_TO_TCHAR(lua_tostring(L, 1));
			FAzureFullMipsManager::Get().RemoveActorByTag(FName(*Tag));
			return 0;
		}

		static int lua_FullMips_ListActors(lua_State* L)
		{
			FAzureFullMipsManager::Get().ListActors();
			return 0;
		}

		static int lua_FullMips_ListTextures(lua_State* L)
		{
			FAzureFullMipsManager::Get().ListTextures();
			return 0;
		}

		static int lua_FullMips_Update(lua_State* L)
		{
			FAzureFullMipsManager::Get().Update();
			return 0;
		}

		static int lua_ThreadJobForLua_Init(lua_State* L)
		{
			bool inMainThread = !!lua_toboolean(L, 1);
			ThreadJobForLua::ExplicitInit(inMainThread);
			return 0;
		}

		static int lua_ThreadJobForLua_Destroy(lua_State* L)
		{
			ThreadJobForLua::Destroy();
			return 0;
		}

		static int lua_ThreadJobForLua_SetHasPendingJob(lua_State* L)
		{
			ThreadJobForLua::SetHasPendingJob();
			return 0;
		}

		static int lua_ThreadJobForLua_JobTimeLimitReached(lua_State* L)
		{
			bool flag = ThreadJobForLua::JobTimeLimitReached();
			lua_pushboolean(L, flag);
			return 1;
		}

		//Http

		struct AzureByteArray
		{
			TArray<uint8> data;
			~AzureByteArray() {}
		};

#define BYTEARRAYID  "_byteArray"

		AzureByteArray * getByteArray(lua_State * L, int index)
		{
			AzureByteArray * byteArray = (AzureByteArray *)luaL_checkudata(L, index, BYTEARRAYID);
			return byteArray;
		}

		int lua_byteArrayGc(lua_State* L)
		{
			AzureByteArray * byteArray = getByteArray(L, 1);
			if (byteArray)
			{
				byteArray->~AzureByteArray();
			}
			return 0;
		}


		static int lua_byteArray2Str(lua_State * L)
		{
			AzureByteArray * byteArray = getByteArray(L, 1);
			if (!byteArray)
				lua_pushstring(L, "");
			else
			{
				lua_pushlstring(L, (const char*)(byteArray->data.GetData()), byteArray->data.Num());
			}
			return 1;
		}

		//[GET/POST],url,[id],[head=table],[byteArray/string],[callback]
		static int lua_httpRequest(lua_State * L)
		{
			struct FHttpResponse
			{
				FString requestId;
				FString url;
				wLua::lua_registry_handle callbackRef;	//success,code,url,requestId,content

				FHttpResponse()
				{
				}
				void RequestComplete(FHttpRequestPtr HttpRequest, FHttpResponsePtr HttpResponse, bool bSucceeded)
				{
					if (!callbackRef.IsNoRef() && AAzureEntryPoint::Instance)
					{
						lua_State_Wrapper sL = AAzureEntryPoint::Instance->GetL();

						if (sL != nullptr)
						{
							lua_rawgeti(sL, LUA_REGISTRYINDEX, callbackRef);
							wLua::lua_registry_handle::wlua_unref(sL, LUA_REGISTRYINDEX, callbackRef);
							if (lua_isnil(sL, -1))
							{
								lua_pop(sL, 1);
							}
							else
							{
								if (!HttpResponse.IsValid())
								{
									lua_pushboolean(sL, false);
									lua_pushinteger(sL, -1);
									lua_pushstring(sL, TCHAR_TO_UTF8(*url));
									lua_pushstring(sL, TCHAR_TO_UTF8(*requestId));
									lua_pushnil(sL);
								}
								else
								{
									lua_pushboolean(sL, true);
									lua_pushinteger(sL, HttpResponse->GetResponseCode());
									lua_pushstring(sL, TCHAR_TO_UTF8(*url));
									lua_pushstring(sL, TCHAR_TO_UTF8(*requestId));
									const TArray<uint8>& content = HttpResponse->GetContent();
									if (content.Num() == 0)
									{
										lua_pushnil(sL);
									}
									else
									{
										void  * rawData = lua_newuserdata(sL, sizeof(AzureByteArray));
										AzureByteArray * byteArray = new(rawData) AzureByteArray;
										if (luaL_newmetatable(sL, BYTEARRAYID))
										{
											lua_pushcfunction(sL, lua_byteArrayGc);
											lua_setfield(sL, -2, "__gc");
										}
										lua_setmetatable(sL, -2);
										byteArray->data = content;
									}
								}
								HttpRequest->OnProcessRequestComplete().Unbind();
								delete this;
								AAzureEntryPoint::Instance->GetWLua()->Call(5);
								return;
							}
						}
					}
					HttpRequest->OnProcessRequestComplete().Unbind();
					delete this;
				}
			};

			TSharedPtr<IHttpRequest> Request = FHttpModule::Get().CreateRequest();
			int top = lua_gettop(L);

			//POST/GET
			astring averb = lua_tostring(L, 1);
			FString verb(UTF8_TO_TCHAR(averb.c_str()));

			//url
			astring aurl = lua_tostring(L, 2);
			FString url(UTF8_TO_TCHAR(aurl.c_str()));

			//id
			const char* id = nullptr;
			if (top >= 3 && lua_isstring(L, 3))
				id = lua_tostring(L, 3);

			//head
			if (top >= 4)
			{
				if (!lua_istable(L, 4) && !lua_isnil(L, 4))
				{
					lua_pushstring(L, "httpRequest: #4 param must be table or nil");
					lua_error(L);
					return 0;
				}

				if (lua_istable(L, 4))
				{
					lua_pushvalue(L, 4);  //popped below
					lua_pushnil(L);

					while (lua_next(L, -2) != 0)
					{
						const char* value = lua_tostring(L, -1);
						const char* key = lua_tostring(L, -2);
						Request->SetHeader(UTF8_TO_TCHAR(key), UTF8_TO_TCHAR(value));
						lua_pop(L, 1);
					}
					lua_pop(L, 1);  //popped
				}
			}

			//body
			if (top >= 5)
			{
				TArray<uint8> Payload;
				if(lua_isstring(L, 5))
				{
					size_t strlen = 0;
					const char* data = lua_tolstring(L, 5, &strlen);
					if (data)
						Payload.Append((const uint8*)data, (int32)strlen);
				}
				else if (lua_isuserdata(L, 5))
				{
					AzureByteArray * byteArray = getByteArray(L, 5);
					if (byteArray)
						Payload = byteArray->data;
				}
				Request->SetContent(Payload);
			}

			//callback
			wLua::lua_registry_handle callbackRef;
			if (top >= 6)
			{
				if (!lua_isfunction(L, 6) && !lua_isnil(L,6))
				{
					lua_pushstring(L, "httpPost: #6 param must be function or nil");
					lua_error(L);
					return 0;
				}
				if (lua_isfunction(L, 6))
				{
					lua_pushvalue(L, 6);
					callbackRef = wLua::lua_registry_handle::wlua_ref(L, LUA_REGISTRYINDEX);
					if (callbackRef.IsRefNil())
						callbackRef.Clear();
					if (!callbackRef.IsNoRef())
					{
						FHttpResponse * response = new FHttpResponse();
						response->callbackRef = callbackRef;
						if (id)
							response->requestId = UTF8_TO_TCHAR(id);
						response->url = url;
						Request->OnProcessRequestComplete().BindRaw(response, &FHttpResponse::RequestComplete);
					}
				}
			}

			if (top >= 8)
			{
				const char* fieldName = lua_tostring(L, 7);
				const char* fieldVal = lua_tostring(L, 8);
				Request->SetHeader(fieldName, fieldVal);
			}

			Request->SetVerb(verb);
			Request->SetURL(url);
			Request->ProcessRequest();
			return 0;
		}

		static int lua_screenShot_init(lua_State * L)
		{
			struct ScreenShotHelper
			{
				wLua::lua_registry_handle callbackRef;

				FDelegateHandle	delegateGrab;
				FDelegateHandle delegateRelease;

				ScreenShotHelper()
				{
				}

				void GrabScreenShot(int32 InSizeX, int32 InSizeY, const TArray<FColor>& InImageData)
				{
					if (!AAzureEntryPoint::IsInit())
						return;

					wLua::Lua* wlua = AAzureEntryPoint::Instance->GetWLua();
					lua_State_Wrapper temp_L = AAzureEntryPoint::Instance->GetL();
					if (!wlua || !temp_L)
						return;

					lua_rawgeti(temp_L, LUA_REGISTRYINDEX, callbackRef);

					int32 countInBytes = InImageData.Num()*InImageData.GetTypeSize();
					uint8 * data = new uint8[countInBytes];
					memcpy(data, InImageData.GetData(),countInBytes);
					lua_pushinteger(temp_L, InSizeX);
					lua_pushinteger(temp_L, InSizeY);
					lua_pushlightuserdata(temp_L, data);
					lua_pushinteger(temp_L, countInBytes);
					wlua->Call(4);

					FString ScreenShotName = FScreenshotRequest::GetFilename();
					if (!FPaths::GetExtension(ScreenShotName).IsEmpty())
					{
						ScreenShotName = FPaths::GetBaseFilename(ScreenShotName, false);
						ScreenShotName += TEXT(".png");
					}

					// Save the contents of the array to a png file.
					TArray<uint8> CompressedBitmap;
					FImageUtils::CompressImageArray(InSizeX, InSizeY, InImageData, CompressedBitmap);
					FFileHelper::SaveArrayToFile(CompressedBitmap, *ScreenShotName);
				}

				void AddRef(lua_State* LL, int index)
				{
					if (delegateGrab.IsValid())
					{
						GEngine->GameViewport->OnScreenshotCaptured().Remove(delegateGrab);
						delegateGrab.Reset();
					}

					if (delegateRelease.IsValid())
					{
						if (AAzureEntryPoint::Instance)
							AAzureEntryPoint::Instance->OnEndPlayDelegate.Remove(delegateRelease);
						delegateRelease.Reset();
					}

					if (callbackRef.IsValid())
					{
						wLua::lua_registry_handle::wlua_unref(LL, LUA_REGISTRYINDEX, callbackRef);
						callbackRef.Clear();
					}

					if (!lua_isnoneornil(LL, index))
					{
						lua_pushvalue(LL, index);
						callbackRef = wLua::lua_registry_handle::wlua_ref(LL, LUA_REGISTRYINDEX);
						delegateGrab = GEngine->GameViewport->OnScreenshotCaptured().AddRaw(this, &ScreenShotHelper::GrabScreenShot);

						if (!AAzureEntryPoint::IsInit())
							return;

						delegateRelease = AAzureEntryPoint::Instance->OnEndPlayDelegate.AddRaw(this, &ScreenShotHelper::OnLuaRelease);
					}
				}

				void OnLuaRelease()
				{
					callbackRef.Clear();
				}
			};
			static ScreenShotHelper s_helper;
			if (!lua_isnoneornil(L, 1) && !lua_isfunction(L, 1)) //this function is like: function(width,height,dataptr)  ... end
			{
				lua_pushstring(L, "lua_screenShot_init: first param must be function");
				lua_error(L);
				return 0;
			}
			s_helper.AddRef(L,1);

			return 0;
		}

		static int lua_screenShot_releaseData(lua_State * L)
		{
			uint8 * data = static_cast<uint8 *>(lua_touserdata(L, 1));
			delete[] data;
			return 0;
		}

		//dataptr,length,width,height,[newwidth,newheight,]
		static int lua_screenShot_createTexture(lua_State * L)
		{
			uint8 * pSrc = static_cast<uint8 *>(lua_touserdata(L, 1));
			int count = lua_tointeger(L, 2);
			int width = lua_tointeger(L, 3);
			int height = lua_tointeger(L, 4);
			char * filename = nullptr;
			UObject * outer;
			int destw = -1;
			int desth = -1;
			if (lua_gettop(L) == 7)
			{
				destw = lua_tointeger(L, 5);
				desth = lua_tointeger(L, 6);
				outer = wLua::FLuaUtils::GetUObject(L, 7, "Object");
			}
			else
			{
				outer = wLua::FLuaUtils::GetUObject(L, 5, "Object");
			}

			UTexture2D * tex = nullptr;
			TArray<FColor> srcData(reinterpret_cast<FColor*>(pSrc), count/sizeof(FColor));
			if (destw > 0 && desth > 0)
			{
				TArray<FColor> destData;
				FImageUtils::CropAndScaleImage(width, height, destw, desth, srcData, destData);

				tex = UTexture2D::CreateTransient(destw, desth);
				FTexture2DMipMap& Mip = tex->PlatformData->Mips[0];
				void * data = Mip.BulkData.Lock(LOCK_READ_WRITE);
				FMemory::Memcpy(data, destData.GetData(), destData.GetTypeSize() * destData.Num());
				Mip.BulkData.Unlock();
				tex->UpdateResource();
			}
			else
			{
				tex = UTexture2D::CreateTransient(width, height);
				FTexture2DMipMap& Mip = tex->PlatformData->Mips[0];
				void * data = Mip.BulkData.Lock(LOCK_READ_WRITE);
				FMemory::Memcpy(data, srcData.GetData(), srcData.GetTypeSize() * srcData.Num());
				Mip.BulkData.Unlock();
				tex->UpdateResource();

			}
			tex ? wLua::FLuaUtils::ReturnUObject(L, tex) : lua_pushnil(L);
			return 1;
		}

		//dataptr,length,width,height,[newwidth,newheight,]filename,[bVerticalOrientation]
		static int lua_screenShot_saveToFile(lua_State * L)
		{
			uint8 * data = static_cast<uint8 *>(lua_touserdata(L, 1));
			int count = lua_tointeger(L, 2);
			int width = lua_tointeger(L, 3);
			int height = lua_tointeger(L, 4);
			char * filename = nullptr;
			int destw = -1;
			int desth = -1;
			bool bVerticalOrientation = false;
			if (lua_isnumber(L, 5) && lua_isnumber(L, 6))
			{
				destw = luaL_checkinteger(L, 5);
				desth = luaL_checkinteger(L, 6);
				filename = const_cast<char*>(lua_tostring(L, 7));
				bVerticalOrientation = !!lua_toboolean(L, 8);
			}
			else
			{
				filename = const_cast<char*>(lua_tostring(L, 5));
				bVerticalOrientation = !!lua_toboolean(L, 6);
			}

			bool ret = false;
			TArray<FColor> srcData(reinterpret_cast<FColor*>(data), count / sizeof(FColor));

			if (bVerticalOrientation)
			{
				int prev_idx = 0;
				int cur_idx = 0;

				for (int prev_x = 0; prev_x < width; prev_x++)
				{
					for (int prev_y = 0; prev_y < height; prev_y++)
					{
						prev_idx = prev_x + prev_y * width;
						cur_idx = (height - 1 - prev_y) + prev_x * height;
						srcData[cur_idx] = reinterpret_cast<FColor*>(data)[prev_idx];
					}
				}

				int temp;
				if (width > height)
				{
					temp = width;
					width = height;
					height = temp;
				}

				if (destw > desth)
				{
					temp = destw;
					destw = desth;
					desth = temp;
				}
			}

			if (destw > 0 && desth > 0)
			{
				TArray<FColor> destData;
				FImageUtils::CropAndScaleImage(width, height, destw, desth, srcData, destData);

				TArray<uint8> CompressedBitmap;
				FImageUtils::CompressImageArray(destw, desth, destData, CompressedBitmap);
				ret = FFileHelper::SaveArrayToFile(CompressedBitmap, UTF8_TO_TCHAR(filename));
			}
			else
			{
				TArray<uint8> CompressedBitmap;
				FImageUtils::CompressImageArray(width, height, srcData, CompressedBitmap);
				ret = FFileHelper::SaveArrayToFile(CompressedBitmap, UTF8_TO_TCHAR(filename));
			}
			lua_pushboolean(L, ret);
			return 1;
		}

		//dataptr,length,width,height,[newwidth,newheight,]filename
		static int lua_screenShot_cropAndSaveToFile(lua_State * L)
		{
			uint8 * data = static_cast<uint8 *>(lua_touserdata(L, 1));
			int count = luaL_checkinteger(L, 2);
			int width = luaL_checkinteger(L, 3);
			int height = luaL_checkinteger(L, 4);
			char * filename = nullptr;
			int destw = 0;
			int desth = 0;
			int destOffsetX = 0;
			int destOffsetY = 0;
			if (lua_gettop(L) == 9)
			{
				destw = luaL_checkinteger(L, 5);
				desth = luaL_checkinteger(L, 6);
				destOffsetX = luaL_checkinteger(L, 7);
				destOffsetY = luaL_checkinteger(L, 8);
				filename = const_cast<char*>(lua_tostring(L, 9));
			}
			else if (lua_gettop(L) == 7)
			{
				destw = luaL_checkinteger(L, 5);
				desth = luaL_checkinteger(L, 6);
				filename = const_cast<char*>(lua_tostring(L, 7));
			}
			else
			{
				filename = const_cast<char*>(lua_tostring(L, 5));
			}

			bool ret = false;
			TArray<FColor> srcData(reinterpret_cast<FColor*>(data), count / sizeof(FColor));
			if (destw > 0 && desth > 0)
			{
				TArray<FColor> destData;
				FImageUtils::CropImageRaw(width, height, destw, desth, destOffsetX, destOffsetY, srcData, destData);

				TArray<uint8> CompressedBitmap;
				FImageUtils::CompressImageArray(destw, desth, destData, CompressedBitmap);
				ret = FFileHelper::SaveArrayToFile(CompressedBitmap, UTF8_TO_TCHAR(filename));
			}
			else
			{
				TArray<uint8> CompressedBitmap;
				FImageUtils::CompressImageArray(width, height, srcData, CompressedBitmap);
				ret = FFileHelper::SaveArrayToFile(CompressedBitmap, UTF8_TO_TCHAR(filename));
			}
			lua_pushboolean(L, ret);
			return 1;
		}

		static int lua_screentShot(lua_State * L)
		{
			UE_LOG(LogAzure, Log, TEXT("lua_screentShot"));
			bool bShowUI = lua_toboolean(L, 1);
			FString filename;
			bool bAddFilenameSuffix = true;
			if (!lua_isnoneornil(L, 2))
			{
				const char* filestr = lua_tostring(L, 2);
				if (filestr)
					filename = UTF8_TO_TCHAR(filestr);
			}
			if (!lua_isnoneornil(L, 3))
			{
				bAddFilenameSuffix = lua_toboolean(L, 3);
			}
			FScreenshotRequest::RequestScreenshot(filename, bShowUI, bAddFilenameSuffix);
			return 0;
		}

		static int lua_getObjects(lua_State * L)
		{
			int32 result = 0;
#if UE_GC_TRACK_OBJ_AVAILABLE
			result = GUObjectArray.GetObjectArrayNumMinusAvailable();
#endif
			lua_pushinteger(L, result);
			return 1;
		}

		static int lua_OctetsBase64Decode(lua_State * L)
		{
			size_t size;
			const char* data = luaL_checklstring(L, -1, &size);
			if (data != nullptr)
			{
				//uint8 * decodeBase64Str;
				//FBase64::Decode(data, size, decodeBase64Str);
				const FString srcStr = UTF8_TO_TCHAR(data);
				TArray<uint8> base64Str;
				FBase64::Decode(srcStr, base64Str);
				GNET::Octets* oct;
				oct = new GNET::Octets((const char*)base64Str.GetData(), (size_t)base64Str.Num());
				AzureHelpFuncs::ReturnObject(L, oct, "Octets");
			}
			else
			{
				AzureHelpFuncs::traceback(L, "null string");
				lua_error(L);
			}
			return 1;
		}

		static int lua_Base64Encode(lua_State * L)
		{
			size_t size;
			const char* data = luaL_checklstring(L, -1, &size);
			if (data != nullptr)
			{
				//const FString srcStr = UTF8_TO_TCHAR(data);
				FString base64Str = FBase64::Encode((uint8*)data, size);
				lua_pushstring(L, TCHAR_TO_UTF8(*base64Str));
			}
			else
			{
				lua_pushnil(L);
			}
			return 1;
		}

		static int lua_Base64Decode(lua_State * L)
		{
			const char* data = lua_tostring(L, 1);
			if (data != nullptr)
			{
				const FString srcStr = UTF8_TO_TCHAR(data);
				TArray<uint8> base64Str;
				FBase64::Decode(srcStr, base64Str);
				lua_pushlstring(L, (const char*)base64Str.GetData(), (size_t)base64Str.Num());
				//lua_pushlstring(L, TCHAR_TO_UTF8(*base64Str));
			}
			else
			{
				lua_pushnil(L);
			}
			return 1;
		}

		static void ConvertToTCHAR(const TArray<uint8>& InUTF8Payload, TArray<uint8>& OutTCHARPayload)
		{
			int32 StartIndex = OutTCHARPayload.Num();
			OutTCHARPayload.AddUninitialized(FUTF8ToTCHAR_Convert::ConvertedLength((ANSICHAR*)InUTF8Payload.GetData(), InUTF8Payload.Num() / sizeof(ANSICHAR)) * sizeof(TCHAR));
			FUTF8ToTCHAR_Convert::Convert((TCHAR*)(OutTCHARPayload.GetData() + StartIndex), (OutTCHARPayload.Num() - StartIndex) / sizeof(TCHAR), (ANSICHAR*)InUTF8Payload.GetData(), InUTF8Payload.Num() / sizeof(ANSICHAR));
		}

		static void ConvertToUTF8(const TArray<uint8>& InTCHARPayload, TArray<uint8>& OutUTF8Payload)
		{
			int32 StartIndex = OutUTF8Payload.Num();
			OutUTF8Payload.AddUninitialized(FTCHARToUTF8_Convert::ConvertedLength((TCHAR*)InTCHARPayload.GetData(), InTCHARPayload.Num() / sizeof(TCHAR)) * sizeof(ANSICHAR));
			FTCHARToUTF8_Convert::Convert((ANSICHAR*)(OutUTF8Payload.GetData() + StartIndex), (OutUTF8Payload.Num() - StartIndex) / sizeof(ANSICHAR), (TCHAR*)InTCHARPayload.GetData(), InTCHARPayload.Num() / sizeof(TCHAR));
		}

		static int lua_SerializeUObjectToJson(lua_State * L)
		{
			UObject* Object = FLuaUtils::GetUObject(L, 1, "Object");
			UClass*  Class = Cast<UClass>(FLuaUtils::GetUObject(L, 2, "Class"));
			if (!Object || !Class || !Object->IsA(Class))
			{
				lua_pushnil(L);
			}
			else
			{
				TArray<uint8> WriterBuffer;
                FMemoryWriter Writer(WriterBuffer);
                FJsonStructSerializerBackend SerializerBackend(Writer);
                FStructSerializerPolicies Policies;
				Policies.PropertyFilter = [](const UProperty* CurrentProp, const UProperty* ParentProp)
				{
					return !CurrentProp->HasAnyPropertyFlags(CPF_NativeAccessSpecifierProtected | CPF_NativeAccessSpecifierPrivate) || ParentProp != nullptr;
				};
                FStructSerializer::Serialize((void*)Object, *Class, SerializerBackend, Policies);
				TArray<uint8> SerializeBuffer;
				TCHAR StringEnd = TCHAR('\0');
				Writer.Serialize(&StringEnd, sizeof(TCHAR));
				ConvertToUTF8(WriterBuffer, SerializeBuffer);
				lua_pushstring(L, (char*)SerializeBuffer.GetData());
			}
			return 1;
		}

		static int lua_DeserializeUObjectFromJson(lua_State* L)
		{
			UObject* Object = FLuaUtils::GetUObject(L, 1, "Object");
			UClass*  Class = Cast<UClass>(FLuaUtils::GetUObject(L, 2, "Class"));
			size_t size;
            TCHAR* JsonData = UTF8_TO_TCHAR(luaL_checklstring(L, 3, &size));
			if (JsonData && Object && Class && Object->IsA(Class))
			{
				TArray<uint8> ReaderBuffer;
				FMemoryWriter Writer(ReaderBuffer);
				FString JsonString(JsonData);

				Writer.Serialize(JsonString.GetCharArray().GetData(), JsonString.GetCharArray().Num() * JsonString.GetCharArray().GetTypeSize());
				FMemoryReader Reader(ReaderBuffer);
				FJsonStructDeserializerBackend DeserializerBackend(Reader);
				
				FStructDeserializerPolicies Policies;
				Policies.PropertyFilter = [](const UProperty* CurrentProp, const UProperty* ParentProp)
				{
					return !CurrentProp->HasAnyPropertyFlags(CPF_NativeAccessSpecifierProtected | CPF_NativeAccessSpecifierPrivate) || ParentProp != nullptr;
				};
				FStructDeserializer::Deserialize((void*)Object, *Class, DeserializerBackend, Policies);
				//Object->PostEditChange();
			}
			return 0;			
		}

		static int lua_NewRenderTarget(lua_State* L)
		{
			ETextureRenderTargetFormat format = ETextureRenderTargetFormat::RTF_RGBA8;
			if (lua_isnumber(L, 1))
				format = (ETextureRenderTargetFormat)lua_tointeger(L, 1);

			bool bAutoGenerateMips = false;
			if (lua_isboolean(L, 2))
				bAutoGenerateMips = !!lua_toboolean(L, 2);

			int32 size = 1;
			if (lua_isnumber(L, 3))
				size = lua_tointeger(L, 3);

			bool bForceLinearGamma = true;
			if (lua_isboolean(L, 4))
				bForceLinearGamma = !!lua_toboolean(L, 4);

			UTextureRenderTarget2D* TextureRenderTarget = NewObject<UTextureRenderTarget2D>();
			if (TextureRenderTarget)
			{
				TextureRenderTarget->RenderTargetFormat = format;
				TextureRenderTarget->bAutoGenerateMips = bAutoGenerateMips;
				TextureRenderTarget->bForceLinearGamma = bForceLinearGamma ? 1 : 0;
				TextureRenderTarget->InitAutoFormat(size, size);
				TextureRenderTarget->UpdateResourceImmediate(true);
				wLua::FLuaUtils::ReturnUObject(L, TextureRenderTarget);
			}
			else
			{
				lua_pushnil(L);
			}

			
			return 1;
		}

		static int lua_ReadRTData(lua_State* L)
		{
			
			UWorld* pWorld = AAzureEntryPoint::Instance->GetWorld();
			if (!pWorld)
				return 0;
			UTextureRenderTarget2D* TextureRenderTarget = Cast<UTextureRenderTarget2D>(wLua::FLuaUtils::GetUObject(L, 1, "TextureRenderTarget2D"));
			if (!TextureRenderTarget)
				return 0;

			EPixelFormat format = TextureRenderTarget->GetFormat();

			TArray<FVector4> Result;
			if (format == PF_FloatRGBA)
			{
				UKismetRenderingLibrary::ReadRenderTargetPixelFloat16Value(pWorld, TextureRenderTarget, Result);
				
			}
			else
			{
				UKismetRenderingLibrary::ReadRenderTargetAllRawPixel(pWorld, TextureRenderTarget, Result);
			}
			lua_newtable(L);
			int i = 1;
			for (auto& v : Result)
			{
				wLua::FLuaVector4::Return(L, v);
				lua_rawseti(L, -2, i);
				i++;

			}
			return 1;
		}

		static int lua_GetAllOceanMeshProxy(lua_State* L)
		{
			TArray<UStaticMeshComponent*> Result;
			TSet<AOceanMeshActor *>& OceanMeshActors = AOceanMeshActor::GetAllOceanMeshInstances();
			for (auto& OceanMeshActor : OceanMeshActors)
			{
				TArray<AActor*> SubActors;
				OceanMeshActor->GetAttachedActors(SubActors);
				for (AActor* Actor : SubActors)
				{
					APMeshActor* PMeshActor = Cast<APMeshActor>(Actor);
					if (PMeshActor && PMeshActor->OceanMeshProxy)
					{
						Result.Emplace(PMeshActor->OceanMeshProxy);
					}
				}
			}

			lua_newtable(L);
			int i = 1;
			for (auto& CO : Result)
			{
				wLua::FLuaUtils::ReturnUObject(L, CO);
				lua_rawseti(L, -2, i);
				i++;
				
			}
			return 1;
		}

		static int lua_HideOceanMeshProxy(lua_State* L)
		{
			APlayerController* pCtrler = AAzureEntryPoint::Instance->GetPlayerController();

			if (!pCtrler)
				return 0;

			TSet<AOceanMeshActor *>& OceanMeshActors = AOceanMeshActor::GetAllOceanMeshInstances();
			for(auto& OceanMeshActor : OceanMeshActors)
			{
				TArray<AActor*> SubActors;
				OceanMeshActor->GetAttachedActors(SubActors);
				for (AActor* Actor : SubActors)
				{
					APMeshActor* PMeshActor = Cast<APMeshActor>(Actor);
					if (PMeshActor && PMeshActor->OceanMeshProxy)
					{
						PMeshActor->OceanMeshProxy->SetVisibility(true);
						pCtrler->HiddenPrimitiveComponents.Emplace(PMeshActor->OceanMeshProxy);
					}
				}
			}
			return 0;
		}

		static int lua_AddSceneCaptureToActor(lua_State* L)
		{
			AActor* Owner = Cast<AActor>(FLuaUtils::GetUObject(L, 1, "Actor"));

			if (!Owner)
			{
				lua_pushstring(L, "lua_AddSceneCaptureToActor: #1 must be Actor!");
				lua_error(L);
				return 1;
			}

			USceneCaptureComponent2D* CaptureComponent = NewObject<USceneCaptureComponent2D>(Owner, TEXT("CaptureComponent"));
			if (CaptureComponent)
			{
				float OrthWidth = (float)lua_tonumber(L, 2);
				float HeightOffset = (float)lua_tonumber(L, 3);
				ECameraProjectionMode::Type ProjectType = ECameraProjectionMode::Orthographic;
				if (lua_isnumber(L, 4))
					ProjectType = (ECameraProjectionMode::Type)lua_tointeger(L, 4);
				ESceneCaptureSource CaptureSource = ESceneCaptureSource::SCS_SceneColorHDRNoAlpha;
				if (lua_isnumber(L, 5))
					CaptureSource = (ESceneCaptureSource)lua_tointeger(L, 5);
				Owner->AddOwnedComponent(CaptureComponent);
				Owner->AddInstanceComponent(CaptureComponent);
				CaptureComponent->ProjectionType = ProjectType;
				CaptureComponent->OrthoWidth = OrthWidth;
				CaptureComponent->CaptureSource = CaptureSource;
				FRotator Rotation(-90.0f, 0.0f, 0.0f); //默认垂直向下观察
				FVector Position(0, 0, HeightOffset);
				CaptureComponent->SetWorldLocationAndRotation(Position, Rotation);

				TArray<FEngineShowFlagsSetting> ShowFlagSettings;
				if (lua_istable(L, 6))
				{
					lua_pushnil(L);

					while (lua_next(L, -2) != 0)
					{
						FEngineShowFlagsSetting Setting;
						Setting.ShowFlagName = UTF8_TO_TCHAR(luaL_checkstring(L, -2));
						Setting.Enabled = lua_toboolean(L, -1);
						ShowFlagSettings.Add(Setting);
						lua_pop(L, 1);
					}
					lua_pop(L, 1);  //popped			
				}
				CaptureComponent->ShowFlagSettings = ShowFlagSettings;

				CaptureComponent->AttachToComponent(Owner->GetRootComponent(), FAttachmentTransformRules::KeepRelativeTransform);
				
				if (!CaptureComponent->IsRegistered())
					CaptureComponent->RegisterComponent();
				
				wLua::FLuaUtils::ReturnUObject(L, CaptureComponent);
			}
			else
			{
				lua_pushnil(L);
			}
			
			return 1;
		}

		static int lua_EnumToTable(lua_State * L)
		{
			UObject* Object = FLuaUtils::GetUObject(L, 1, "Object");
			if (Object->IsA<UEnumProperty>()) 
			{
				Object = Cast<UEnumProperty>(Object)->GetEnum();
			}
			UEnum* Enum = Cast<UEnum>(Object);
			if (!Enum)
			{
				lua_pushnil(L);
			}
			else
			{
				int32 NameNums = Enum->NumEnums();
				if (Enum->ContainsExistingMax())
				{
					NameNums--;
				}
				FString EnumNamePrefix = Enum->GetName() + TEXT("::");
				lua_newtable(L);
				for (int32 i = 0; i < NameNums; i++)
				{
					lua_pushnumber(L, Enum->GetValueByIndex(i));
					FString EnumName = Enum->GetNameByIndex(i).ToString();
					EnumName.RemoveFromStart(EnumNamePrefix);
					lua_setfield(L, -2, TCHAR_TO_UTF8(*EnumName));
				}
			}
			return 1;
		}

		static int lua_AddViewSlaveLocation(lua_State * L)
		{
			FVector SlaveLocation = FLuaVector::Get(L, 1);
			int top = lua_gettop(L);
			if (top == 1)
			{
				IStreamingManager::Get().AddViewSlaveLocation(SlaveLocation);
			}
			else if (top == 2)
			{
				float BoostFactor = (float)lua_tonumber(L, 2);
				IStreamingManager::Get().AddViewSlaveLocation(SlaveLocation,BoostFactor);
			}
			else if (top == 3)
			{
				float BoostFactor = (float)lua_tonumber(L, 2);
				bool bOverrideLocation = lua_toboolean(L, 3);
				IStreamingManager::Get().AddViewSlaveLocation(SlaveLocation,BoostFactor,bOverrideLocation);
			}
			else if (top == 4)
			{
				float BoostFactor = (float)lua_tonumber(L, 2);
				bool bOverrideLocation = lua_toboolean(L, 3);
				float Duration = (float)lua_tonumber(L, 4);
				IStreamingManager::Get().AddViewSlaveLocation(SlaveLocation, BoostFactor, bOverrideLocation, Duration);
			}
			return 0;
		}

		static int lua_AddViewExtraLocation(lua_State * L)
		{
			FVector ExtraLocation = FLuaVector::Get(L, 1);
			int id = 0;
			int top = lua_gettop(L);
			if (top == 1)
			{
				id = IStreamingManager::AddViewExtraLocation(ExtraLocation);
			}
			else if (top == 2)
			{
				float BoostFactor = (float)lua_tonumber(L, 2);
				id = IStreamingManager::AddViewExtraLocation(ExtraLocation, BoostFactor);
			}
			else if (top >= 3)
			{
				float BoostFactor = (float)lua_tonumber(L, 2);
				bool bOverrideLocation = lua_toboolean(L, 3);
				id = IStreamingManager::AddViewExtraLocation(ExtraLocation, BoostFactor, bOverrideLocation);
			}
			lua_pushinteger(L, id);
			return 1;
		}

		static int lua_RemoveViewExtraLocation(lua_State * L)
		{
			int index = lua_tointeger(L, 1);
			IStreamingManager::RemoveViewExtraLocation(index);
			return 0;
		}

		static int lua_GetBlueprintProperty(lua_State* L)
		{
			UObject* Object = FLuaUtils::GetUObject(L, 1, "Object");
			if (!Object)
			{
				luaL_error(L, "lua_GetBlueprintProperty: #1 must be Object!");
				return 0;
			}

			FString Name = UTF8_TO_TCHAR(luaL_checkstring(L, 2)); // 属性名
			if (Name.Len() == 0)
			{
				luaL_error(L, "lua_GetBlueprintProperty: #2 PropertyName Invalid!");
				return 0;
			}

			UProperty* Property = wLua::FindScriptPropertyHelper(Object->GetClass(), *Name);
			if (!Property)
			{
				luaL_error(L, "lua_GetBlueprintProperty: Cannot find the property!");
				return 0;
			}

			if (Property->IsA<UFloatProperty>())
			{
				float prop_value;
				Property->CopyCompleteValue(&prop_value, Property->ContainerPtrToValuePtr<void>(Object));
				lua_pushnumber(L, prop_value);
			}
			else if (Property->IsA<UIntProperty>())
			{
				int prop_value;
				Property->CopyCompleteValue(&prop_value, Property->ContainerPtrToValuePtr<void>(Object));
				lua_pushnumber(L, prop_value);
			}
			else if (Property->IsA<UStrProperty>())
			{
				FString prop_value;
				Property->CopyCompleteValue(&prop_value, Property->ContainerPtrToValuePtr<void>(Object));
				lua_pushstring(L, TCHAR_TO_UTF8(*prop_value));
			}
			else if (Property->IsA<UTextProperty>())
			{
				FText prop_value;
				Property->CopyCompleteValue(&prop_value, Property->ContainerPtrToValuePtr<void>(Object));
				lua_pushstring(L, TCHAR_TO_UTF8(*prop_value.ToString()));
			}
			else if (Property->IsA<UBoolProperty>())
			{
				bool prop_value;
				Property->CopyCompleteValue(&prop_value, Property->ContainerPtrToValuePtr<void>(Object));
				lua_pushboolean(L, prop_value);
			}
			else if (Property->IsA<UObjectProperty>())
			{
				UObject* obj = NULL;
				Property->CopyCompleteValue(&obj, Property->ContainerPtrToValuePtr<void>(Object));
				wLua::FLuaUtils::ReturnUObject(L, obj);
			}
			else if (Property->IsA<UStructProperty>())
			{
				FString cppType = Property->GetCPPType();
				if (cppType == "FVector")
				{
					FVector prop_value;
					Property->CopyCompleteValue(&prop_value, Property->ContainerPtrToValuePtr<void>(Object));
					wLua::FLuaVector::Return(L, prop_value);
				}
				else if (cppType == "FVector4")
				{
					FVector4 prop_value;
					Property->CopyCompleteValue(&prop_value, Property->ContainerPtrToValuePtr<void>(Object));
 					wLua::FLuaVector4::Return(L, prop_value);
				}
				else if (cppType == "FVector2D")
				{
					FVector2D prop_value;
					Property->CopyCompleteValue(&prop_value, Property->ContainerPtrToValuePtr<void>(Object));
					wLua::FLuaVector2D::Return(L, prop_value);
				}
				else
				{
					luaL_error(L, "lua_GetBlueprintProperty: property unsupported struct type:%s.", TCHAR_TO_UTF8(*cppType));
					return 0;
				}
			}
			else
			{
				FString cppType = Property->GetCPPType(); cppType.GetCharArray();
				luaL_error(L, "lua_GetBlueprintProperty: property unsupported type:%s.", TCHAR_TO_UTF8(*cppType));
				return 0;
			}

			return 1;
		}

		//if !errorIfNoFunction, returns: <is_success>, [returns]
		static int lua_RunBlueprintFunc_inner(lua_State* L, bool errorIfNoFunction)
		{
			UObject* Object = FLuaUtils::GetUObject(L, 1, "Object");
			if (!Object)
			{
				lua_pushstring(L, "lua_TryRunBlueprintFunc: #1 must be Object!");
				lua_error(L);
				return 1;
			}

			FString Name = UTF8_TO_TCHAR(luaL_checkstring(L, 2)); // 1：函数名
			UFunction* Function = Object->FindFunction(FName(*Name));
			if (!Function)
			{
				if (errorIfNoFunction)
				{
					luaL_error(L, "lua_RunBlueprintFunc: #2 Function not found: %s", TCHAR_TO_UTF8(*Name));
				}
				else
				{
					lua_pushboolean(L, false);
				}
				return 1;
			}

			uint8* paramBuffer = Function->PropertiesSize == 0 ? nullptr : new uint8[Function->PropertiesSize];
			if (Function->PropertiesSize != 0)
			{
				memset(paramBuffer, 0, Function->PropertiesSize);
			}

			int n = 3;
			TArray<FString> stringBuffer;
			TArray<FText> textBuffer;
			TArray<UProperty*> outPropBuffer;
			TArray<int32> intArrayBuffer; //注：只能支持一个int数组的传参，两个int数组传参就有问题了
			for (TFieldIterator<UProperty> it(Function); it && (it->PropertyFlags&CPF_Parm); ++it, ++n) {
				UProperty* prop = *it;
				uint64 propflag = prop->GetPropertyFlags();
				if (((propflag&CPF_ReturnParm) || (propflag&CPF_OutParm)) && !(propflag&CPF_BlueprintVisible)) //蓝图可读就代表是参数不是返回值
				{
					outPropBuffer.Add(prop);
					continue;
				}

				if (prop->IsA<UFloatProperty>())
				{
					float prop_value = (float)luaL_checknumber(L, n);
					memcpy(paramBuffer + prop->GetOffset_ForInternal(), &prop_value, sizeof(float));
				}
				else if (prop->IsA<UIntProperty>())
				{
					int prop_value = (int)luaL_checknumber(L, n);
					memcpy(paramBuffer + prop->GetOffset_ForInternal(), &prop_value, sizeof(int));
				}
				else if (prop->IsA<UByteProperty>())  // Enum
				{
					uint8 prop_value = (uint8)luaL_checknumber(L, n);
					memcpy(paramBuffer + prop->GetOffset_ForInternal(), &prop_value, sizeof(uint8));
				}
				else if (prop->IsA<UStrProperty>())
				{
					stringBuffer.Add(FString(UTF8_TO_TCHAR(luaL_checkstring(L, n))));
					memcpy(paramBuffer + prop->GetOffset_ForInternal(), &stringBuffer[stringBuffer.Num() - 1], sizeof(FString));
				}
				else if (prop->IsA<UTextProperty>())
				{
					textBuffer.Add(FText::FromString(FString(UTF8_TO_TCHAR(luaL_checkstring(L, n)))));
					memcpy(paramBuffer + prop->GetOffset_ForInternal(), &textBuffer[textBuffer.Num() - 1], sizeof(FText));
				}
				else if (prop->IsA<UBoolProperty>())
				{
					bool prop_value = !!(lua_toboolean(L, n));
					memcpy(paramBuffer + prop->GetOffset_ForInternal(), &prop_value, sizeof(bool));
				}
				else if (prop->IsA<UStructProperty>())
				{
					FString cppType = prop->GetCPPType();
					if (lua_istable(L, n))
					{	
						if (cppType == "FVector")
						{
							FVector prop_value = wLua::FLuaVector::Get(L, n);
							memcpy(paramBuffer + prop->GetOffset_ForInternal(), &prop_value, sizeof(FVector));
						}
						else if (cppType == "FVector4")
						{
							FVector4 prop_value = wLua::FLuaVector4::Get(L, n);
							memcpy(paramBuffer + prop->GetOffset_ForInternal(), &prop_value, sizeof(FVector4));
						}
						else if (cppType == "FVector2D")
						{
							FVector2D prop_value = wLua::FLuaVector2D::Get(L, n);
							memcpy(paramBuffer + prop->GetOffset_ForInternal(), &prop_value, sizeof(FVector2D));
						}
						else
						{
							luaL_error(L, "lua_TryRunBlueprintFunc: param #%d  unsupported struct table type: %s", n, TCHAR_TO_UTF8(*cppType));
							return 0;
						}
					}
					else
					{
						luaL_error(L, "lua_TryRunBlueprintFunc: param #%d  invalid struct type: %s", n, TCHAR_TO_UTF8(*cppType));
						return 0;
					}
				}
				else if (prop->IsA<UArrayProperty>())
				{
					UArrayProperty* arrayProp = CastChecked<UArrayProperty>(prop);
					UProperty* item = arrayProp->Inner;
					if (item->IsA<UIntProperty>())
					{
						if(intArrayBuffer.Num() > 0)
						{
							luaL_error(L, "lua_TryRunBlueprintFunc: param #%d  unsupported more than one int array params", n);
							return 0;
						}
						if (lua_istable(L, n))
						{
							lua_pushnil(L);
							while (lua_next(L, -2) != 0)
							{
								int32 prop_value = (int32)luaL_checknumber(L, -1);
								intArrayBuffer.Add(prop_value);
								lua_pop(L, 1);
							}
						}
						memcpy(paramBuffer + prop->GetOffset_ForInternal(), &intArrayBuffer, sizeof(TArray<int32>));
					}
					else
					{
						luaL_error(L, "lua_TryRunBlueprintFunc: param #%d  unsupported array item type: %s", n,
                               TCHAR_TO_UTF8(*item->GetCPPType()));
						return 0;
					}
				}
				else
				{
					luaL_error(L, "lua_TryRunBlueprintFunc: param #%d  unsupported type: %s", n,
					           TCHAR_TO_UTF8(*prop->GetCPPType()));
					return 0;
				}
			}

			Object->ProcessEvent(Function, paramBuffer);
			
			n = 0;
			if (!errorIfNoFunction)
			{
				lua_pushboolean(L, true);
				++n;
			}

			for (auto it = outPropBuffer.CreateIterator(); it; ++it)
			{
				UProperty* prop = (*it);
				bool bAddedReturn = false;
				if (prop->IsA<UFloatProperty>()) // jj
				{
					float prop_value = *reinterpret_cast<float*>(paramBuffer + prop->GetOffset_ForInternal());
					lua_pushnumber(L, prop_value);
					bAddedReturn = true;
				}
				else if (prop->IsA<UIntProperty>())
				{
					int prop_value = *reinterpret_cast<int*>(paramBuffer + prop->GetOffset_ForInternal());
					lua_pushnumber(L, prop_value);
					bAddedReturn = true;
				}
				else if (prop->IsA<UStrProperty>())
				{
					stringBuffer.Add(FString(*reinterpret_cast<FString*>(paramBuffer + prop->GetOffset_ForInternal())));
					lua_pushstring(L, TCHAR_TO_UTF8(*stringBuffer[stringBuffer.Num() - 1]));
					bAddedReturn = true;
				}
				else if (prop->IsA<UTextProperty>())
				{
					stringBuffer.Add(reinterpret_cast<FText*>(paramBuffer + prop->GetOffset_ForInternal())->ToString());
					lua_pushstring(L, TCHAR_TO_UTF8(*stringBuffer[stringBuffer.Num() - 1]));
					bAddedReturn = true;
				}
				else if (prop->IsA<UBoolProperty>())
				{
					bool prop_value = *reinterpret_cast<bool*>(paramBuffer + prop->GetOffset_ForInternal());
					lua_pushboolean(L, prop_value);
					bAddedReturn = true;
				}
				else if (prop->IsA<UStructProperty>())
				{
					FString cppType = prop->GetCPPType();
					if (cppType == "FVector")
					{
						FVector prop_value = *reinterpret_cast<FVector*>(paramBuffer + prop->GetOffset_ForInternal());
						wLua::FLuaVector::Return(L, prop_value);
						bAddedReturn = true;
					}
					else if (cppType == "FVector4")
					{
						FVector4 prop_value = *reinterpret_cast<FVector4*>(paramBuffer + prop->GetOffset_ForInternal());
						wLua::FLuaVector4::Return(L, prop_value);
						bAddedReturn = true;
					}
					else if (cppType == "FVector2D")
					{
						FVector2D prop_value = *reinterpret_cast<FVector2D*>(paramBuffer + prop->GetOffset_ForInternal());
						wLua::FLuaVector2D::Return(L, prop_value);
						bAddedReturn = true;
					}
					else
					{
						luaL_error(L, "lua_TryRunBlueprintFunc: return value #%d unsupported struct type:%s.", n, *cppType);
						return 0;
					}
				}
				else if (prop->IsA<UArrayProperty>())
				{
					// 参数传入的数组都会触发输出
					UArrayProperty* arrayProp = CastChecked<UArrayProperty>(prop);
					UProperty* item = arrayProp->Inner;
					if (item->IsA<UIntProperty>())
					{
						uint64 propflag = prop->GetPropertyFlags();
						// 当前对数组的处理是为了军团远征中六边形格子容器加的，数组总量超过40000且传入数组不需要再传回Lua，所以这里做了一步隔离
						// 仅处理Return中的参数
						if ((propflag & CPF_ReturnParm))
						{
							TArray<int32> prop_value = *reinterpret_cast<TArray<int32>*>(paramBuffer + prop->GetOffset_ForInternal());
							lua_newtable(L);
							for(int i = 0; i < prop_value.Num(); i++)
							{
								int32 value = prop_value[i];
								lua_pushnumber(L, value);
								lua_rawseti(L,-2,i+1);
							}
							bAddedReturn = true;
						}
					}
					else
					{
						luaL_error(L, "lua_TryRunBlueprintFunc: return value #%d unsupported array item type:%s.", n, *item->GetCPPType());
						return 0;
					}
				}
				else if (prop->IsA<UObjectProperty>())
				{
					UObjectProperty* objProp = Cast<UObjectProperty>(prop);
					UObject* obj = objProp->GetObjectPropertyValue(paramBuffer + prop->GetOffset_ForInternal());
					wLua::FLuaUtils::ReturnUObject(L, obj);
					bAddedReturn = true;
				}
				else
				{
					luaL_error(L, "lua_TryRunBlueprintFunc: return value #%d unsupported type:%s.", n, *prop->GetCPPType());
					return 0;
				}
				if (bAddedReturn) ++n;
			}

			delete[] paramBuffer;
			//wLua::FLuaUtils::ReturnUObject(InScriptContext, PropertyValue);
			return n;
		}

		//returns: has_function, [returns]
		static int lua_RunBlueprintFunc(lua_State* L)
		{
			return lua_RunBlueprintFunc_inner(L, true);
		}

		//returns: has_function, [returns]
		static int lua_TryRunBlueprintFunc(lua_State* L)
		{
			return lua_RunBlueprintFunc_inner(L, false);
		}

		static int lua_ClipboardCopy(lua_State * L)
		{
			size_t size;
			const char* data = luaL_checklstring(L, -1, &size);
			if (data != nullptr)
			{
				const FString srcStr = UTF8_TO_TCHAR(data);
				FPlatformApplicationMisc::ClipboardCopy(*srcStr);
			}
			return 0;
		}

		static int lua_ClipboardPaste(lua_State * L)
		{
			FString destStr = TEXT("");
			FPlatformApplicationMisc::ClipboardPaste(destStr);
			lua_pushstring(L, TCHAR_TO_UTF8(*destStr));
			return 1;
		}

		static int lua_MemCrc32(lua_State* L)
		{
			size_t len = 0;
			const char* str = luaL_checklstring(L, -1, &len);
			uint32 result = FCrc::MemCrc32(str, len);
			lua_pushnumber(L, result);
			return 1;
		}
		static int lua_StrCrc32(lua_State* L)
		{
			const char* str = luaL_checkstring(L, -1);
			uint32 result = FCrc::StrCrc32(str);
			lua_pushnumber(L, result);
			return 1;
		}

		static int lua_IterateDirectory(lua_State* L)
		{
			class FFileMatch : public IPlatformFile::FDirectoryVisitor
			{
			public:
				TArray<FString>& Result;
				FString WildCard;
				bool bFiles;
				bool bDirectories;
				bool bCleanFilename;

				FFileMatch(TArray<FString>& InResult, const FString& InWildCard, bool bInFiles, bool bInDirectories, bool bCleanName)
					: Result(InResult)
					, WildCard(InWildCard)
					, bFiles(bInFiles)
					, bDirectories(bInDirectories)
					, bCleanFilename(bCleanName)
				{
				}
				virtual bool Visit(const TCHAR* FilenameOrDirectory, bool bIsDirectory)
				{
					if (((bIsDirectory && bDirectories) || (!bIsDirectory && bFiles))
						&& FPaths::GetCleanFilename(FilenameOrDirectory).MatchesWildcard(WildCard))
					{
						if (bCleanFilename)
							new(Result) FString(FPaths::GetCleanFilename(FilenameOrDirectory));
						else
							new(Result) FString(FilenameOrDirectory);
					}

					return true;
				}
			};

			FString DirPath = UTF8_TO_TCHAR(lua_tostring(L, 1));
			FString Wildcard = UTF8_TO_TCHAR(lua_tostring(L, 2));
			bool bFiles = lua_toboolean(L, 3);
			bool bDirectories = lua_toboolean(L, 4);
			bool bRecurse = lua_toboolean(L, 5);
			bool bCleanName = lua_toboolean(L, 6);

			TArray<FString> Results;
			const bool bFindAllFiles = Wildcard.IsEmpty();
			FFileMatch FileMatch(Results, bFindAllFiles ? TEXT("*") : Wildcard, bFiles, bDirectories, bCleanName);
			if (bRecurse)
				FPlatformFileManager::Get().GetPlatformFile().IterateDirectoryRecursively(*DirPath, FileMatch);
			else
				FPlatformFileManager::Get().GetPlatformFile().IterateDirectory(*DirPath, FileMatch);

			int i = 1;
			lua_newtable(L);
			for (auto& name : Results)
			{
				lua_pushstring(L, TCHAR_TO_UTF8(*name));
				lua_rawseti(L, -2, i);
				i++;
			}
			return 1;
		}

		static int lua_DebugJoystickInput(lua_State* L)
		{
			int paramsIndex = 0;
			FString keyStr = UTF8_TO_TCHAR(lua_tostring(L, ++paramsIndex));
			float value = lua_tonumber(L, ++paramsIndex);
			FKey key(*keyStr);
			AzureInputCtrl::GetInstance().InputAxis(key, value, 0.0f, 0, false);
			return 1;
		}

		static int lua_GetCookedAssetSize(lua_State* L)
		{
			FName assetPath(UTF8_TO_TCHAR(lua_tostring(L, 1)));
			lua_pushnumber(L, FAzureAssetSizeMap::GetInstance().GetAssetSize(assetPath));
			return 1;
		}

		static int lua_GetCookedAssetListSize(lua_State* L)
		{
			if (!lua_istable(L, 1))
			{
				lua_pushstring(L, "GetCookedAssetListSize: param must be table(assetList)");
				lua_error(L);
				return 1;
			}

			TArray<FName> assetList;
			{
				lua_pushnil(L);
				while (lua_next(L, 1) != 0)
				{
					FName assetPath(UTF8_TO_TCHAR(luaL_checkstring(L, -1)));
					assetList.Add(assetPath);
					lua_pop(L, 1);
				}
			}

			lua_pushnumber(L, FAzureAssetSizeMap::GetInstance().GetAssetListSize(assetList));
			return 1;
		}

		static int lua_GetCookedAssetListSizeDetail(lua_State* L)
		{
			if (!lua_istable(L, 1))
			{
				lua_pushstring(L, "GetCookedAssetListSize: param must be table(assetList)");
				lua_error(L);
				return 1;
			}

			TArray<FName> assetList;
			{
				lua_pushnil(L);
				while (lua_next(L, 1) != 0)
				{
					FName assetPath(UTF8_TO_TCHAR(luaL_checkstring(L, -1)));
					assetList.Add(assetPath);
					lua_pop(L, 1);
				}
			}

			TMap<FName, uint32> fileInfo;
			FAzureAssetSizeMap::GetInstance().GetAssetListSizeDetail(assetList, fileInfo);

			lua_newtable(L);
			for (auto& item : fileInfo)
			{
				lua_pushinteger(L, item.Value);
				lua_setfield(L, -2, TCHAR_TO_UTF8(*item.Key.ToString()));
			}
			return 1;
		}

		static int lua_GetCookedAssetDepends(lua_State* L)
		{
			FName assetPath(UTF8_TO_TCHAR(lua_tostring(L, 1)));

			FString pattern;
			if (lua_isstring(L, 2))
				pattern = UTF8_TO_TCHAR(lua_tostring(L, 2));
			else
				pattern = TEXT("*");

			TSet<FName> depends;
			bool bOK = FAzureAssetSizeMap::GetInstance().GetAssetDependencies(assetPath, pattern, depends);

			if (bOK)
			{
				int i = 1;
				lua_newtable(L);
				for (auto& name : depends)
				{
					lua_pushstring(L, TCHAR_TO_UTF8(*name.ToString().ToLower()));
					lua_rawseti(L, -2, i);
					i++;
				}
			}
			else
			{
				lua_pushnil(L);
			}

			return 1;
		}

		static int lua_DeadLock_Start(lua_State * L)
		{
			float deadlock_threshhold = (float)luaL_checknumber(L, 1);
			float tick_interval = (float)luaL_checknumber(L, 2);
			bool crashOnDeadLock = lua_toboolean(L, 3);
			bool enableANRCheck = !!lua_toboolean(L, 4);
			DeadLockDetector::instance().Start(deadlock_threshhold, tick_interval, crashOnDeadLock, enableANRCheck);
			return 0;
		}
		static int lua_DeadLock_Stop(lua_State * L)
		{
			DeadLockDetector::instance().ForceStop();
			return 0;
		}

		static int lua_DeadLock_SetActive(lua_State * L)
		{
			bool bActive = lua_toboolean(L, 1);
			DeadLockDetector::instance().SetActive(bActive);
			return 0;
		}

		static int lua_DeadLock_TestSleep(lua_State * L)
		{
			int seconds = lua_tointeger(L, 1);
			FPlatformProcess::Sleep((float)seconds);
			return 0;
		}
		
		static int lua_EnableSlateFeathering(lua_State * L)
		{
			GSlateFeathering = luaL_checkinteger(L, 1);
			return 0;
		}

		static int lua_IsApplicationActive(lua_State * L)
		{
			bool bActive = FSlateApplication::Get().IsActive();
			lua_pushboolean(L, bActive);
			return 1;
		}

		static int lua_SlateApplicationRebuildDisplayMetrics(lua_State * L)
		{
			FDisplayMetrics dummy;
			FSlateApplication::Get().GetDisplayMetrics(dummy);
			return 0;
		}

		static int lua_BroadcastSafeFrameChangedEvent(lua_State * L)
		{
			FCoreDelegates::OnSafeFrameChangedEvent.Broadcast();
			return 0;
		}

		static int lua_GetSafeZoneSize(lua_State * L)
		{
			float overrideSizeX = float(luaL_optnumber(L, 1, 0.0f));
			float overrideSizeY = float(luaL_optnumber(L, 2, 0.0f));
			FVector2D overrideSize(overrideSizeX, overrideSizeY);
			FMargin safeZone;
			FSlateApplication::Get().GetSafeZoneSize(safeZone, overrideSize);
			lua_pushnumber(L, safeZone.Left);
			lua_pushnumber(L, safeZone.Top);
			lua_pushnumber(L, safeZone.Right);
			lua_pushnumber(L, safeZone.Bottom);
			return 4;
		}

		static int lua_GetDocumentPath(lua_State * L)
		{
#if PLATFORM_IOS
			FString docPath = FString([NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) objectAtIndex:0]);
			FPaths::MakeStandardFilename(docPath);
			docPath.RemoveFromEnd(FString(TEXT("/")), ESearchCase::CaseSensitive);
			astring path = TCHAR_TO_UTF8(*docPath);
			lua_pushstring(L, path.c_str());			
#else
			lua_pushstring(L, FPlatformAFileWrapper::GetAssetsPath().c_str());
#endif
			return 1;
		}

#if !UE_BUILD_SHIPPING
		static int lua_ConsoleCommand(lua_State * L)
		{
			if (!AAzureEntryPoint::IsInit())
				return 0;

			const char * command = lua_tostring(L, 1);
			APlayerController* pCtrler = AAzureEntryPoint::Instance->GetPlayerController();
			pCtrler->ConsoleCommand(UTF8_TO_TCHAR(command));
			return 0;
		}
#endif

		static int lua_buglyCrash(lua_State * L)
		{
#if PLATFORM_ANDROID
			//AndroidThunkCpp_BuglyCrash();
#endif
			return 0;
		}

		static int lua_ueCrash(lua_State * L)
		{
#if PLATFORM_ANDROID
			AndroidThunkCpp_JavaCrash();
#endif
			return 0;
		}

#if STATS
		static TMap<FName, FDynamicCycleCounter<FStatGroup_STATGROUP_AzureGroups>> s_luaStatNameToCounter;
		static TArray<FName> s_luaStatStack;

		static int lua_BeginProfiler(lua_State * L)
		{
			if (!lua_isstring(L, 1))
			{
				luaL_error(L, "BeginProfiler: Profiler stat name must be string");
				return 0;
			}

			const FName& StatName = UTF8_TO_TCHAR(lua_tostring(L, 1));
			if (!s_luaStatNameToCounter.Contains(StatName))
			{
				FDynamicCycleCounter<FStatGroup_STATGROUP_AzureGroups> NewCounter(StatName);
				s_luaStatNameToCounter.Add(StatName, std::move(NewCounter));
			}


			FDynamicCycleCounter<FStatGroup_STATGROUP_AzureGroups>& Counter = s_luaStatNameToCounter[StatName];
			Counter.Begin();

			s_luaStatStack.Push(StatName);

			return 0;
		}

		static int lua_EndProfiler(lua_State * L)
		{
			if (s_luaStatStack.Num() == 0)
			{
				luaL_error(L, "EndProfiler: Unexpected EndProfiler() call. No profiler to end.");
				return 0;
			}

			const FName& StatName = s_luaStatStack.Last();
			if (!s_luaStatNameToCounter.Find(StatName))
			{
				luaL_error(L, "EndProfiler: Can not find stat name %s, profiler stack broken. Stack size: %d", TCHAR_TO_UTF8(*StatName.ToString()), s_luaStatStack.Num());
				return 0;
			}

			FDynamicCycleCounter<FStatGroup_STATGROUP_AzureGroups>& Counter = s_luaStatNameToCounter[StatName];
			Counter.End();

			s_luaStatStack.Pop();

			return 0;
		}

		static int lua_ClearUpProfilers(lua_State * L)
		{
			if (s_luaStatStack.Num() != 0 )
			{
				const FName& LastUnstoppedStatName = s_luaStatStack.Last();
				luaL_error(L, "ClearUpProfilers: Failed to clean up profilers, profiler Begin-End pairs unmatch. Last Stat: %s ", TCHAR_TO_UTF8(*LastUnstoppedStatName.ToString()) );
			}

			s_luaStatStack.Empty();
			s_luaStatNameToCounter.Empty();

			return 0;
		}
#else
		static int lua_BeginProfiler(lua_State * L) { return 0; }
		static int lua_EndProfiler(lua_State * L) { return 0; }
		static int lua_ClearUpProfilers(lua_State * L) { return 0;}
#endif

		//param 1: (可选) statsTable，提供时向此表写入
		static int lua_GetPlatformMemoryStats(lua_State* L)
		{
			const FPlatformMemoryStats MemStats = FPlatformMemory::GetStats();
			if (lua_istable(L, 1))
				lua_pushvalue(L, 1);
			else
				lua_newtable(L);
			lua_pushnumber(L, MemStats.AvailablePhysical);
			lua_setfield(L, -2, "AvailablePhysical");
			lua_pushnumber(L, MemStats.AvailableVirtual);
			lua_setfield(L, -2, "AvailableVirtual");
			lua_pushnumber(L, MemStats.UsedPhysical);
			lua_setfield(L, -2, "UsedPhysical");
			lua_pushnumber(L, MemStats.PeakUsedPhysical);
			lua_setfield(L, -2, "PeakUsedPhysical");
			lua_pushnumber(L, MemStats.UsedVirtual);
			lua_setfield(L, -2, "UsedVirtual");
			lua_pushnumber(L, MemStats.PeakUsedVirtual);
			lua_setfield(L, -2, "PeakUsedVirtual");
			return 1;
		}

		static int lua_UELog(lua_State* L)
		{
			char const* verbosity = luaL_checkstring(L, 1);
			char const* msg = luaL_checkstring(L, 2);
			if (strcmp(verbosity, "Log") == 0)
			{
				UE_LOG(LogAzure, Log, TEXT("%s"), UTF8_TO_TCHAR(msg));
			}
			else if (strcmp(verbosity, "Display") == 0)
			{
				UE_LOG(LogAzure, Display, TEXT("%s"), UTF8_TO_TCHAR(msg));
			}
			else if (strcmp(verbosity, "Warning") == 0)
			{
				UE_LOG(LogAzure, Warning, TEXT("%s"), UTF8_TO_TCHAR(msg));
			}
			else if (strcmp(verbosity, "Error") == 0)
			{
				UE_LOG(LogAzure, Error, TEXT("%s"), UTF8_TO_TCHAR(msg));
			}
			else if (strcmp(verbosity, "Fatal") == 0)
			{
				UE_LOG(LogAzure, Fatal, TEXT("%s"), UTF8_TO_TCHAR(msg));
			}
			return 0;
		}

		static int lua_UEAssert(lua_State* L)
		{
			char const* assertType = luaL_checkstring(L, 1);
			bool value = lua_toboolean(L, 2);
			char const* msg = luaL_optstring(L, 3, "");
			if (strcmp(assertType, "verifyf") == 0)
			{
				verifyf(value, TEXT("%s"), UTF8_TO_TCHAR(msg));
			}
			else if (strcmp(assertType, "verifySlow") == 0)
			{
				verifySlow(value);
			}
			else if (strcmp(assertType, "check") == 0)
			{
				check(value);
			}
			else if (strcmp(assertType, "checkf") == 0)
			{
				checkf(value, TEXT("%s"), UTF8_TO_TCHAR(msg));
			}
			else if (strcmp(assertType, "checkSlow") == 0)
			{
				checkSlow(value);
			}
			else if (strcmp(assertType, "checkfSlow") == 0)
			{
				checkfSlow(value, TEXT("%s"), UTF8_TO_TCHAR(msg));
			}
			else if (strcmp(assertType, "verify") == 0)
			{
				verify(value);
			}
			else if (strcmp(assertType, "ensure") == 0)
			{
				ensure(value);
			}
			else if (strcmp(assertType, "ensureMsgf") == 0)
			{
				ensureMsgf(value, TEXT("%s"), UTF8_TO_TCHAR(msg));
			}
			else if (strcmp(assertType, "ensureAlways") == 0)
			{
				ensureAlways(value);
			}
			else if (strcmp(assertType, "ensureAlwaysMsgf") == 0)
			{
				ensureAlwaysMsgf(value, TEXT("%s"), UTF8_TO_TCHAR(msg));
			}
			return 0;
		}

		//设置 GIgnoreDebugger，返回旧值
		static int lua_SetUEIgnoreDebugger(lua_State* L)
		{
			bool value = lua_toboolean(L, 1);
			bool oldValue = GIgnoreDebugger;
			GIgnoreDebugger = value;
			lua_pushboolean(L, oldValue);
			return 1;
		}

		class SimuBuglyCrash {
		public:
			void SimuCrash(int _id) {
				this->myId = _id;
			}
		private:
			int myId;
		};

		static int lua_SimuCrash(lua_State * L)
		{
			SimuBuglyCrash * mySimuCrash = nullptr;
			mySimuCrash->SimuCrash(2);
			
			return 0;
		}

		static int lua_SimuCheckCrash(lua_State * L)
		{
			check(false);
			return 0;
		}

		static int lua_CreateScreenRange(lua_State* L)
		{
			int iParam = 1;
			ScreenRangeScaleMode scaleMode = (ScreenRangeScaleMode)luaL_checkinteger(L, iParam);
			float width = (float)lua_tonumber(L, ++iParam);
			float height = (float)lua_tonumber(L, ++iParam);
			float offsetX = (float)lua_tonumber(L, ++iParam);
			float offsetY = (float)lua_tonumber(L, ++iParam);
			
			AzureScreenRange* p = (AzureScreenRange*)lua_newuserdata(L, sizeof(AzureScreenRange));
			p->Init(scaleMode, width, height, offsetX, offsetY);
			return 1;
		}
		static int lua_IsInScreenRange(lua_State* L)
		{
			int iParam = 1;
			AzureScreenRange* pRange = NULL;
			if (lua_isuserdata(L, iParam))
			{
				pRange = (AzureScreenRange*)lua_touserdata(L, iParam);
			}
				
			if (!pRange)
			{
				lua_pushboolean(L, false);
				lua_pushnumber(L, -1.0f);
				return 2;
			}

			FVector position = wLua::FLuaVector::Get(L, ++iParam);
			float dist = -1.0f;
			bool ok = pRange->IsInRange(position, dist);
			lua_pushboolean(L, ok);
			lua_pushnumber(L, dist);
			return 2;
		}

		static int lua_GetCommandLineText(lua_State * L)
		{
			FString commandLineText = FCommandLine::Get();
			lua_pushstring(L, TCHAR_TO_UTF8(*commandLineText));
			return 1;
		}

		static int lua_IsPluginEnable(lua_State * L)
		{
			TSharedPtr<IPlugin> Plugin = IPluginManager::Get().FindPlugin(UTF8_TO_TCHAR(lua_tostring(L, 1)));
			if (Plugin.IsValid() && Plugin->IsEnabled()) {
				lua_pushboolean(L, 1);
			}
			else {
				lua_pushboolean(L, 0);
			}
			return 1;
		}
		
		const luaL_Reg Lib_GameUtil_Funcs[] =
		{
			{"buglyCrash", lua_buglyCrash},
			{"ueCrash", lua_ueCrash},
			{ "GetCurCodeVersion", GetCurCodeVersion },
			{ "GetBuildConfiguration", lua_GetBuildConfiguration },
			{ "Base64Encode", lua_Base64Encode},
			{ "Base64Decode", lua_Base64Decode},
			{ "OctetsBase64Decode", lua_OctetsBase64Decode},
			{ "PauseTrigger", lua_PauseTrigger },
			{ "GetObjectResSizeBytes", lua_GetObjectResSizeBytes },
			{ "SpawnActor", lua_SpawnActor },
			{ "SetActorProperty", lua_SetActorProperty },
			{ "GetActorProperty", lua_GetActorProperty },
			{ "Instantiate", lua_Instantiate },
			{ "InstantiateComponent", lua_InstantiateComponent },
			{ "DestroyActor", lua_DestroyActor},
			{ "AssetExist", lua_AssetExist },
			{ "EnableLogRes", lua_EnableLogResnameToLoad},
			{ "AsyncLoad", lua_AsyncLoadResource },
			{ "SyncLoad", lua_SyncLoadResource },
			{ "IsResLoaded", lua_IsResLoaded },
			{ "BlockTillAllRequestsFinished", lua_BlockTillAllRequestsFinished },
			{ "FlushAsyncLoading", lua_FlushAsyncLoading },
			{ "IsAsyncLoading", lua_IsAsyncLoading },
			{ "ManuallyReleaseResourcesAndPackage", lua_ManuallyReleaseResourcesAndPackage },
			{ "CheckClosePackageFileHandle", lua_CheckClosePackageFileHandle },
			{ "AFileSystemEnable", lua_AFileSystemEnable },
			{ "CheckAFileSystemDisabled", lua_CheckAFileSystemDisabled },
			{ "SetAFileLocalizationLanguage", lua_SetAFileLocalizationLanguage },
			{ "FlushRenderingCommands", lua_FlushRenderingCommands },
			{ "AddLevelToWorld", lua_AddLevelToWorld },
			{ "RemoveLevelFromWorld", lua_RemoveLevelFromWorld },
			{ "GetWorld", lua_GetWorld },
			{ "GetPlayerController", lua_GetPlayerController },
			{ "GetTransientPackage", lua_GetTransientPackage },
			{ "SetViewTarget", lua_SetViewTarget },
			{ "GetViewTarget", lua_GetViewTarget },
			{ "FindObject", lua_FindObject },
			{ "FindActorFast", lua_FindActorFast },
			{ "FindActor", lua_FindActor },
			{ "FindActorByClass", lua_FindActorByClass },
			{ "AddressToObject", lua_AddressToObject },
			{ "RotatorFromVector", lua_RotatorFromVector },
			{ "CalAbsPosInfo", lua_CalAbsPosInfo },			
			{ "MakeRotFromX", lua_MakeRotFromX },
			{ "MakeRotFromXY", lua_MakeRotFromXY },
			{ "MakeRotFromXZ", lua_MakeRotFromXZ },
			{ "MakeRotFromY", lua_MakeRotFromY },
			{ "MakeRotFromYZ", lua_MakeRotFromYZ },
			{ "MakeRotFromYX", lua_MakeRotFromYX },
			{ "MakeRotFromZ", lua_MakeRotFromZ },
			{ "MakeRotFromZX", lua_MakeRotFromZX },
			{ "MakeRotFromZY", lua_MakeRotFromZY },
			{ "MakeRotFromXYZW", lua_MakeRotFromXYZW },
			{ "RotatorRelativeToWorld", lua_RotatorRelativeToWorld },
			{ "RotatorToVector", lua_RotatorToVector },
			{ "RotateVector", lua_RotateVector },
			{ "UnrotateVector", lua_UnrotateVector },
			{ "EulerToQuaternion", lua_EulerToQuaternion },
			{ "QuaternionToEuler", lua_QuaternionToEuler },
			{ "QuatLerp", lua_QuatLerp },
			{ "QuatFastLerp", lua_QuatFastLerp },
			{ "GetUpVector", lua_GetUpVector },
			{ "GetForwardVector", lua_GetForwardVector },
			{ "GetRightVector", lua_GetRightVector },
			{ "GetVectorHeadingAngle", lua_GetVectorHeadingAngle },
			{ "ConstrainDirectionToPlane", lua_ConstrainDirectionToPlane },
			{ "GetAllObjectsQueryFlag", lua_GetAllObjectsQueryFlag },
			{ "GetMousePosition", lua_GetMousePosition },
			{ "OnPrtc_GameDataSend", OnPrtc_GameDataSend },
			{ "GetProtoStream", GetProtoStream },
			{ "PeekProtoDetailType", PeekProtoDetailType },

			{ "AddGlobalTimer", AddGlobalTimer },
			{ "AddGlobalLateTimer", AddGlobalLateTimer },
			{ "RemoveGlobalTimer", RemoveGlobalTimer },
			{ "ResetGlobalTimer", ResetGlobalTimer },
			{ "SetGlobalTimer", SetGlobalTimer },
			{ "GetAllTimerDebugInfo", GetAllTimerDebugInfo },

			{ "UnbindUserData", UnbindUserData },
			{ "GetAssetsPath", GetAssetsPath },
			{ "GetProjectDir", GetProjectDir },
			{ "GetProjectContentDir", GetProjectContentDir },
			{ "GetPlatformName", GetPlatformName },
			{ "GetPlatformLocale", GetPlatformLocale },
			{ "GenRandomSeed", GenRandomSeed },
			{ "GetServerList", GetServerList },
			{ "GetVersionList", GetVersionList },
			{ "GetDirVersion", GetDirVersion },
			{ "RequestDirInfo", RequestDirInfo },
			{ "HasGotDirInfo", HasGotDirInfo },
			{ "AbortDirRequest", AbortDirRequest },
			{ "GetObjMapCount", GetObjMapCount },
			{ "LuaObjRefSnapshot", LuaObjRefSnapshot },
			{ "LuaObjRefDiffLastSnapshot", LuaObjRefDiffLastSnapshot },
			{ "GetLuaRegistryRefCount", GetLuaRegistryRefCount },
			{ "DumpLuaRegistryInfo", DumpLuaRegistryInfo },
			{ "LuaRegistryTakeSnapshot", LuaRegistryTakeSnapshot },
			{ "LuaRegistryDiffWithLastSnapshot", LuaRegistryDiffWithLastSnapshot },
			{ "ReadFileAllContent", ReadFileAllContent },
			{ "ReadFileAllContentPtr", ReadFileAllContentPtr },
			{ "ReleaseFileBuffer", ReleaseFileBuffer },
			{ "ReadFileAllContentPtrAnsiAlloc", ReadFileAllContentPtrAnsiAlloc },
			{ "ReleaseFileBufferAnsi", ReleaseFileBufferAnsi },
			{ "GetFileInfoInRealPckFile", GetFileInfoInRealPckFile },
			{ "HasDebugPath", HasDebugPath },
			{ "DirectoryExists", DirectoryExists },
			{ "CreateDirectory", CreateDirectory },
			{ "CreateDirectoryForFile", CreateDirectoryForFile },
			{ "DeleteDirectoryRecursively", DeleteDirectoryRecursively },
			{ "CopyFile", lua_CopyFile },
			{ "CopySubFile", lua_CopySubFile },
			{ "CopySubFileAsync", lua_CopySubFileAsync },
			{ "DeleteFileInDirectory", DeleteFileInDirectory },
			{ "GetFileModifyTime", GetFileModifyTime },
			{ "GameThreadAsyncTask", lua_GameThreadAsyncTask },
			{ "GameThreadAsyncTask_versionFlag_PCallFixed", lua_GameThreadAsyncTask_versionFlag_PCallFixed },
			{ "ParseDateFromString", ParseDateFromString },
			{ "CompareDateTime", CompareDateTime },
			{ "Utf8ToUnicode", Utf8ToUnicode },
			{ "UnicodeToUtf8", UnicodeToUtf8 },
			{ "GBKToUnicode", GBKToUnicode },
			{ "GetServerDeltaTime", GetServerDeltaTime },
			{ "SetTimeZoneBias", SetTimeZoneBias },
			{ "SystemLocalTime", SystemLocalTime },
			{ "GetServerGMTTime", GetServerGMTTime },
			{ "GetServerTimeError", GetServerTimeError },
			{ "GetServerTimeThisWeek", GetServerTimeThisWeek },
			{ "GetTimeStampDateTime", GetTimeStampDateTime },
			{ "AddCoolDownData", AddCoolDownData },
			{ "UpdateCoolDownData", UpdateCoolDownData },
			{ "GetCoolDownData", GetCoolDownData },
			{ "ClearCoolDownData", ClearCoolDownData },
			{ "GetMillisecondsFromEpoch", GetMillisecondsFromEpoch },
			{ "Localization_SetCurrentLanguage", Localization_SetCurrentLanguage },
			{ "Localization_GetCurrentLanguage", Localization_GetCurrentLanguage },
			{ "Localization_SetCurrentLocale", Localization_SetCurrentLocale },
			{ "Localization_GetCurrentLocale", Localization_GetCurrentLocale },
			{ "Localization_SetCurrentCulture", Localization_SetCurrentCulture },
			{ "Localization_GetCurrentCulture", Localization_GetCurrentCulture },
			{ "Localization_GetDefaultCulture", Localization_GetDefaultCulture },
			{ "Localization_GetDefaultLanguage", Localization_GetDefaultLanguage },
			{ "Localization_GetDefaultLocale", Localization_GetDefaultLocale },
			{ "Localization_InitGameTextLocalization", Localization_InitGameTextLocalization },
			{ "Localization_RefreshResources", Localization_RefreshResources },
			{ "SetMoveStampSn", SetMoveStampSn },
			{ "GetTemporaryCachePath", GetTemporaryCachePath },
			{ "SetDepthOfField", SetDepthOfField },
			{ "SetShadowDistance", SetShadowDistance },
			{ "GetShadowDistance", GetShadowDistance },
			{ "SetShadowCascadesNum", SetShadowCascadesNum },
			{ "SetShadowBias", SetShadowBias },
			{ "SetShadowBiasForEnvManager", SetShadowBiasForEnvManager },
			{ "AddPostProcessBlendableToCamera", AddPostProcessBlendableToCamera },
			{ "RemovePostProcessBlendableFromCamera", RemovePostProcessBlendableFromCamera },
			{ "SetPostProcessBlendWeight", SetPostProcessBlendWeight },
			{ "AddPostProcessMaterial", AddPostProcessMaterial },
			{ "RemovePostProcessMaterial", RemovePostProcessMaterial },
			{ "AddPostProcessColorLUTTexture", AddPostProcessColorLUTTexture },
			{ "RemovePostProcessColorLUTTexture", RemovePostProcessColorLUTTexture },
			{ "SetScreenTint", SetScreenTint },
			{ "SetScreenFringeIntensity", SetScreenFringeIntensity },
			{ "GetCurWorldVignetteIntensity", GetCurWorldVignetteIntensity },
			{ "SetPostProcessFilmSaturation", SetPostProcessFilmSaturation },
			{ "SetPostProcessColorSaturation", SetPostProcessColorSaturation },
			{ "GetCurWorldPostProcessFilmSaturation", GetCurWorldPostProcessFilmSaturation },
			{ "GetCurWorldPostProcessColorSaturation", GetCurWorldPostProcessColorSaturation },
			{ "UpdateSlaveBoneMap", UpdateSlaveBoneMap },
			{ "AddModelSkin", AddModelSkin },
			{ "RemoveModelSkin", RemoveModelSkin },
			{ "GetMeshByComponent", GetMeshByComponent },
			{ "GetModelSkinComponent", GetModelSkinComponent },
			{ "SetMaterialColor", SetMaterialColor },
			{ "GetDynamicMaterial", GetDynamicMaterial },
			{ "CutWound", CutWound },
			{ "CutWoundTree", CutWoundTree },
			{ "CutPersistentWound", CutPersistentWound },
			{ "ClearCutPersistentWound", ClearCutPersistentWound },
			{ "SetDynamicMaterial", SetDynamicMaterial },
			{ "HSV2RGB", HSV2RGB },
			{ "RGB2HSV", RGB2HSV },
			{ "RestHostComponentInfo", RestHostComponentInfo },
			{ "RemapMaterialQualityLevel", RemapMaterialQualityLevel },
			{ "GenerateGhostMesh", GenerateGhostMesh },
			{ "DisableRootMotion", DisableRootMotion },
			{ "EnableRootMotion", EnableRootMotion },

			{ "ExportTextureRenderTargetTGA", ExportTextureRenderTargetTGA },
			{ "ExportTextureRenderTargetToPNG", ExportTextureRenderTargetToPNG },

			{ "AddActorComponent", AddActorComponent },
			{ "RemoveActorComponent", RemoveActorComponent },

			{ "SetReflectionQuality", lua_SetReflectionQuality },
			{ "GetReflectionQuality", lua_GetReflectionQuality },

			//	AzureObjectComponet
			{ "AddAzureObjectComponent", AddAzureObjectComponent },
			{ "AddRegion", AddRegion },
			{ "ClearRegions", ClearRegions },

			//{ "AzureObj_SetCanbeCullHideByMainCamera", AzureObj_SetCanbeCullHideByMainCamera },

			{ "AzureObj_OnMoveStateStopped", AzureObj_OnMoveStateStopped },
			{ "AddMoveBehavior", AddMoveBehavior },
			{ "AddMoveBehavior_Carrier", AddMoveBehavior_Carrier },
			{ "AddHPBePushBehavior", AddHPBePushBehavior },
			{ "SetMoveBehaviorTraceGround", SetMoveBehaviorTraceGround },
			{ "AddDecelMoveBehavior", AddDecelMoveBehavior },
			{ "AddRootMotionBehavior", AddRootMotionBehavior },
			{ "AddObjHurtFlyBehavior", AddObjHurtFlyBehavior },
			{ "AddServerMoveBehavior", AddServerMoveBehavior },
			{ "AddServerSkillMoveBehavior", AddServerSkillMoveBehavior },
			{ "AddServerRootMotionMoveBehavior", AddServerRootMotionMoveBehavior },
			{ "AddBezierMoveBehavior", AddBezierMoveBehavior },
			{ "AddHPBezierMoveBehavior", AddHPBezierMoveBehavior },
			{ "AddHPArcMoveBehavior", AddHPArcMoveBehavior },

			{ "AddHPMoveBehavior", AddHPMoveBehavior },
			{ "ChangeHPMoveBehParam", ChangeHPMoveBehParam },
			{ "AddObjMoveBehavior", AddObjMoveBehavior },
			{ "AddHPJoystickMoveBehavior", AddHPJoystickMoveBehavior },
			{ "AddHPVehicleJoystickMoveBehavior", AddHPVehicleJoystickMoveBehavior },
			{ "AddHPJumpBehavior", AddHPJumpBehavior }, 
			{ "AddHPRushDownBehavior", AddHPRushDownBehavior },
			{ "AddGlideBehavior", AddGlideBehavior },
			{ "SetIsAiming", SetIsAiming },
			{ "OnPlayerChangeAnimBP", OnPlayerChangeAnimBP },
			{ "StopMovement", StopMovement },
				
			{ "ChangeChargeTargetPos", ChangeChargeTargetPos }, 
			{ "SetGamePlayerInfo", SetGamePlayerInfo },
			
			{ "AddTurnBehavior", AddTurnBehavior },
			{ "AddTurnBehaviorLimitTime", AddTurnBehaviorLimitTime },

			{ "FindChargeBehavior", FindChargeBehavior },
			{ "RemoveChargeBehavior", RemoveChargeBehavior },
			{ "ChangeChargeTargetPos", ChangeChargeTargetPos },

			{ "RemoveBehavior", RemoveBehavior },
			{ "GetPositionAfterTimeByBehavior", GetPositionAfterTimeByBehavior },

			{ "AddTimer", AddTimer },
			{ "DelayTimer", DelayTimer },
			{ "RemoveTimer", RemoveTimer },
			{ "ResetTimer", ResetTimer },

				//	Util
			{ "GetCurrentJoyStickValue", GetCurrentJoyStickValue },
			{ "GetCurrentJoyStickDir", GetCurrentJoyStickDir },
			{ "EnableInputMotion", EnableInputMotion },
			{ "GetEnableInputMotion", GetEnableInputMotion },
			{ "SetShakeParam", SetShakeParam },

			{ "SetPlayerMoveRaiseHei", SetPlayerMoveRaiseHei },
			{ "SetPlayerMoveExt", SetPlayerMoveExt },
			{ "SetPlayerMoveHalfHei", SetPlayerMoveHalfHei },
			{ "SetElsePlayerJumpGravityScale", SetElsePlayerJumpGravityScale },
			{ "SetPlayerDashParam", SetPlayerDashParam },
			{ "SetPlayerGlobalParams", SetPlayerGlobalParams },
				

			{ "GetHitPosInWorld", GetHitPosInWorld },
			{ "GetSupportPlaneHeight", GetSupportPlaneHeight },
			{"GetFloorGradient", GetFloorGradient },
			{"GetFloorNormal", GetFloorNormal },
			{ "GetPlaneNormal", lua_GetPlaneNormal },

			{"CreateWorldWrap", CreateWorldWrap },
			{"SetWorldWrapEnabled", SetWorldWrapEnabled },
			{"SetWorldWrapRect", SetWorldWrapRect },
			{"SetWorldUnwrapCenter", SetWorldUnwrapCenter },
			{"GetWorldUnwrapCenter", GetWorldUnwrapCenter },
			{"WorldWrapPosition", WorldWrapPosition },
			{"WorldWrapDistance", WorldWrapDistance },
			{"WorldUnwrapPosition", WorldUnwrapPosition },
			{"WorldUnwrapPositionAndGetOffset", WorldUnwrapPositionAndGetOffset },

			{ "GetPreciseSupportHeiByPos", GetPreciseSupportHeiByPos },
			{ "JudgeIsInsideTerrBuilding", JudgeIsInsideTerrBuilding },
			{ "CheckLinePointAvailable", CheckLinePointAvailable },
			{ "CheckArcPointAvailable", CheckArcPointAvailable },
			{ "GetDestJumpPos", GetDestJumpPos },
			{ "GetDestPosHeightFromCurPos", GetDestPosHeightFromCurPos },
			{ "FlashMoveOnDir", FlashMoveOnDir },
			{ "SetHudText", SetHudText },
			{ "SetHudTextSegments", SetHudTextSegments },
			{ "SetMultiSegsHudText", SetMultiSegsHudText },
			{ "SetHudTextSegmentKeys", SetHudTextSegmentKeys },
			{ "SetMultiSegKeysHudText", SetMultiSegKeysHudText } ,
			{ "ActiveHudText", ActiveHudText },
			{ "AddOneScreenBullet", AddOneScreenBullet },
			{ "ActiveScreenBullet", ActiveScreenBullet },
			{ "AddOneCGBulletText", AddOneCGBulletText },
			{ "StartCGBullet", StartCGBullet },
			{ "StopCGBullet", StopCGBullet },
			{ "GetCGPassTime", GetCGPassTime },
			{ "ActiveCGBullet", ActiveCGBullet },
			{ "SetCGTrackLimit", SetCGTrackLimit },
			{ "EnableParticleEmitter", EnableParticleEmitter },
			{ "SerializeUObjectToJson", lua_SerializeUObjectToJson},
			{ "DeserializeUObjectFromJson", lua_DeserializeUObjectFromJson},
			{ "EnumToTable", lua_EnumToTable},
			{ "HideOceanMeshProxy", lua_HideOceanMeshProxy},
			{ "AddSceneCaptureToActor", lua_AddSceneCaptureToActor },
			{ "GetAllOceanMeshProxy", lua_GetAllOceanMeshProxy },
			{ "ReadRTData", lua_ReadRTData },
			{ "NewRenderTarget", lua_NewRenderTarget},

			// 区域墙相关
			{ "RegionWallSpwanActor"			, RegionWallSpwanActor } ,// 早期代码 应该不再用了
			{ "RegionWallSpwanPolygonActor"		, RegionWallSpwanPolygonActor } ,
			{ "RegionWallSpwanCircleActor"		, RegionWallSpwanCircleActor } ,
			{ "RegionWallFindActor"				, RegionWallFindActor } ,
			{ "RegionWallGetActorEnable"		, RegionWallGetActorEnable } ,
			{ "RegionWallSetActorEnable"		, RegionWallSetActorEnable } ,
			{ "RegionWallGetActorDrawDebugLine"	, RegionWallGetActorDrawDebugLine } ,
			{ "RegionWallSetActorDrawDebugLine"	, RegionWallSetActorDrawDebugLine } ,
			{ "RegionWallGetActorVisible"		, RegionWallGetActorVisible } ,
			{ "RegionWallSetActorVisible"		, RegionWallSetActorVisible } ,
			{ "RegionWallDestroyActor"			, RegionWallDestroyActor } ,
			{ "RegionWallDestroyAllActor"		, RegionWallDestroyAllActor } ,


			{ "UMGCustomSetup", LuaUMGCustom::UMGCustomSetup },
			{ "AddCoolDownComponent", LuaUMGCustom::AddCoolDownComponent },
			{ "AddTimeStampCountDownComponent", LuaUMGCustom::AddTimeStampCountDownComponent },
			{ "RemoveCountDownComponent", LuaUMGCustom::RemoveCountDownComponent },
			{ "GetViewportScale", UEGetViewportScale },
			{ "GetCursorPos", lua_GetCursorPos },
			{ "SetCursorPos", lua_SetCursorPos },
			{ "ShowCursor", lua_ShowCursor },
			{ "GetSceneBufferSize", lua_GetSceneBufferSize },
			{ "GetViewportSize", lua_GetViewportSize },
			{ "GetViewportSize_Expand", lua_GetViewportSize_Expand },
			{ "GetViewportScale",lua_GetViewportScale },
			{ "GetGameViewport",lua_GetGameViewport },
			{ "TestThreadChecking",lua_TestThreadChecking },
			{ "EnableThreadChecking",lua_EnableThreadChecking },
			{ "EnableLuaStateWrapperChecking",lua_EnableLuaStateWrapperChecking },
			{ "GetCurWorldPostProcessVolumes",GetCurWorldPostProcessVolumes },
			{ "GetCurWorldCullDistanceVolumes",GetCurWorldCullDistanceVolumes },
			{ "DuplicateObject", UEDuplicateObject },
			{ "DuplicateActor", DuplicateActor },
			{ "DuplicateWidget", DuplicateWidget },
			{ "DuplicateWidgetReparent", DuplicateWidgetReparent },
			{ "ViewportToAbsolute", UEViewportToAbsolute },
			{ "AbsoluteToViewport", UEAbsoluteToViewport },
			{ "PlaySequence", PlaySequence },
			{ "VertexFromOtherMesh", lua_VertexFromOtherMesh },
			{ "InitCustomComponent", InitCustomComponent },
			{ "SetCustomComponentValue", SetCustomComponentValue },
			{ "ApplyFaceDataOnHeadAnimBlueprint", ApplyFaceDataOnHeadAnimBlueprint },
			{ "GetConsoleVariable", lua_GetConsoleVariable },
			{ "SetConsoleVariable", lua_SetConsoleVariable },
			{ "getUseBasicQualityLevelFlag", lua_getUseBasicQualityLevelFlag},
			{ "getRealQualityLevelsToUse", lua_getRealQualityLevelsToUse },
			{ "ExecuteCmd", lua_ExecuteCmd },
			{ "ExecuteCmdImmediately", lua_ExecuteCmdImmediately },
			{ "SetWidgetInteractionComponent", SetWidgetInteractionComponent },
			{ "GameStarted", GameStarted },
			{ "StreamingAssetReadFileText", StreamingAssetReadFileText },
			{ "GetStreamingAssetsPath", GetStreamingAssetsPath },
			{ "GetGameDataSendFilter", lua_GetGameDataSendFilter }, 
			{ "GetTimeSeconds", GetTimeSeconds },
			{ "SetVectorParameterCollection", SetVectorParameterCollection },
			{ "GetVectorParameterCollection", GetVectorParameterCollection },
			{ "SetScalarParameterCollection", SetScalarParameterCollection },
			{ "GetScalarParameterCollection", GetScalarParameterCollection },
			{ "CreateDynamicMaterial", CreateDynamicMaterial },
			{ "CreateDynamicMaterialForMeshComponent", CreateDynamicMaterialForMeshComponent },
			{ "AddUObjectDeleteListener", lua_AddUObjectDeleteListener },
			{ "GetGameLogDir", lua_GetGameLogDir },
			{ "downLoadUrl", LuaPatcher::lua_downLoadUrl },
			{ "downLoadUrlPost", LuaPatcher::lua_downLoadUrlPost },
			{ "ChangeTimeScale", ChangeTimeScale },
			{ "PlayWorldCameraShake", PlayWorldCameraShake },
			{ "EnableLightOfLevel", EnableLightOfLevel },
			{ "RaiseEventForUObject", RaiseEventForUObject },
			{ "EnableInputPreProcessor", lua_EnableInputPreProcessor },
			{ "GetQualityLevels", GetQualityLevels },
			{ "SetQualityLevel", SetQualityLevel },
			{ "getDiskFreeSpace", LuaPatcher::lua_getDiskFreeSpace },
			{ "HasActiveWiFiConnection", LuaPatcher::lua_HasActiveWiFiConnection },
			{ "GetNetworkConnectionType", LuaPatcher::lua_GetNetworkConnectionType },
			{ "GetSkyBoxActor", GetSkyBoxActor },
			{ "GetEnvironmentManager", GetEnvironmentManager },
			{ "GetStackBackTrace", GetStackBackTrace },
			{ "AddressToLine", AddressToLine },
			{ "LoadStreamLevel", lua_LoadStreamLevel },
			{ "CreateWorldTileLevelStreaming", lua_CreateWorldTileLevelStreaming },
			{ "SetWorldStreamingLevels", lua_SetWorldStreamingLevels },
			{ "AddWorldStreamingLevels", lua_AddWorldStreamingLevels },
			{ "RemoveWorldStreamingLevels", lua_RemoveWorldStreamingLevels },	
			{ "SetWorldUseGlobalSHIndirectLighting", lua_SetWorldUseGlobalSHIndirectLighting },	
			{ "GetWorldUseGlobalSHIndirectLighting", lua_GetWorldUseGlobalSHIndirectLighting },	
			{ "GetAverageFPS", lua_GetAverageFPS },
			{ "SetSceneViewScaleFactor", lua_SetSceneViewScaleFactor },
			{ "GetSceneViewScaleFactor", lua_GetSceneViewScaleFactor },
			{ "ReplaceMovableIndirectLighting", lua_ReplaceMovableIndirectLighting },
			{ "ReplaceDirectionalLight", lua_ReplaceDirectionalLight },
			{ "SetReplaceShadowCenterFlag", lua_SetReplaceShadowCenterFlag },
			{ "SetReplaceShadowCenterPos", lua_SetReplaceShadowCenterPos },
			{ "IsReplaceShadowCenter", lua_IsReplaceShadowCenter },
			{ "SetMobileDynamicCSMInUse", lua_SetMobileDynamicCSMInUse },
			{ "SkipPlanarReflectionPointLight", lua_SkipPlanarReflectionPointLight },
			{ "SetStatInfoFontSize", lua_SetStatInfoFontSize },
			{ "SetLevelUseOwnMapBuildData", lua_SetLevelUseOwnMapBuildData },
			{ "GetAllActorsByName", lua_GetAllActorsByName },
			{ "GetAllActors", lua_GetAllActors},
			{ "GetActorsByTags", lua_GetActorsByTags },
			{ "GetActorsByClass", lua_GetActorsByClass },
			{ "SetMaterialsQualityLevelByName", lua_SetMaterialsQualityLevelByName },
			{ "md5", lua_md5 },
			{ "md5_raw", lua_md5_raw },
			{ "SimpleEncryptText", lua_SimpleEncryptText },
		    { "IsInScreenRange", lua_IsInScreenRange},
		    { "CreateScreenRange", lua_CreateScreenRange },

			//	DebugHelper
			{ "AddOnScreenDebugMessage", lua_AddOnScreenDebugMessage },
			{ "DrawDebugLine", lua_DrawDebugLine },
			{ "DrawDebugPoint", lua_DrawDebugPoint },
			{ "DrawDebugDirectionalArrow", lua_DrawDebugDirectionalArrow },
			{ "DrawDebugBox", lua_DrawDebugBox },
			{ "DrawDebugCoordinateSystem", lua_DrawDebugCoordinateSystem },
			{ "DrawDebugCircle", lua_DrawDebugCircle },
			{ "DrawDebugSphere", lua_DrawDebugSphere },
			{ "DrawDebugCylinder", lua_DrawDebugCylinder },
			{ "DrawDebugCone", lua_DrawDebugCone },
			{ "DrawDebugSector", lua_DrawDebugSector },
			{ "DrawDebug3DDonut", lua_DrawDebug3DDonut },
			{ "DrawDebugCapsule", lua_DrawDebugCapsule },
			{ "DrawDebugString", lua_DrawDebugString },
#if UE_EDITOR			
			{"EnableSlateReflectorQueryWidgets", lua_EnableSlateReflectorQueryWidgets},
#endif
			//	MipMap
			{ "CutOffMipMap_SetAtSerialize", lua_CutOffMipMap_SetAtSerialize },
			{ "CutOffMipMap_SetCount", lua_CutOffMipMap_SetCount },
			{ "CutOffMipMap_ClearCount", lua_CutOffMipMap_ClearCount },
			{ "CutOffMipMap_GetCount", lua_CutOffMipMap_GetCount },

			// SUSDK
			{ "getSystemTime", lua_getSystemTime },
			{ "getBatteryLevel", lua_getBatteryLevel },
#if PLATFORM_IOS
			{ "getMainscreenScale", lua_getMainscreenScale },
			{ "getMainscreenBoundSize", lua_getMainscreenBoundSize },
			{ "getUIUserInterfaceIdiom", lua_getUIUserInterfaceIdiom },
#endif
			{ "getNetInfoStates", lua_getNetInfoStates },
			{ "isHeadPhonesPlugin", lua_isHeadPhonesPlugin },
			{ "ListenHeadPhonePlugin", lua_OnHeadPhonePlugin },

			// stats, gc, etc
			{ "AddStatInfo", AddStatInfo },
			{ "ShowStat", ShowStat },
			{ "RemoveAllStatInfo", RemoveAllStatInfo },
			{ "GetTotalTimerCount", GetTotalTimerCount },
			{ "getObjects", lua_getObjects },
			{ "RemoveRef", lua_RemoveRef },
			{ "GC", GC },

			//	http
			{ "CanOpenURL", CanOpenURL },
			{ "OpenURL", OpenURL },
			{ "httpRequest", lua_httpRequest },
			{ "byteArray2Str", lua_byteArray2Str },

			//TextureStreaming
			{ "AddViewSlaveLocation", lua_AddViewSlaveLocation },
			{ "AddViewExtraLocation", lua_AddViewExtraLocation },
			{ "RemoveViewExtraLocation", lua_RemoveViewExtraLocation },

			// 调用蓝图函数
			{ "RunBlueprintFunc", lua_RunBlueprintFunc },
			{ "TryRunBlueprintFunc", lua_TryRunBlueprintFunc },
			{ "GetBlueprintProperty", lua_GetBlueprintProperty },

			{ "MemCrc32", lua_MemCrc32 },
			{ "StrCrc32", lua_StrCrc32 },

			{ "DebugJoystickInput", lua_DebugJoystickInput },

			{ "IterateDirectory", lua_IterateDirectory },
			{ "GetCookedAssetSize", lua_GetCookedAssetSize },
			{ "GetCookedAssetListSize", lua_GetCookedAssetListSize },
			{ "GetCookedAssetListSizeDetail", lua_GetCookedAssetListSizeDetail },
			{ "GetCookedAssetDepends", lua_GetCookedAssetDepends },

			{ "EnableSlateFeathering", lua_EnableSlateFeathering },
			{ "IsApplicationActive", lua_IsApplicationActive },
			{ "SlateApplicationRebuildDisplayMetrics", lua_SlateApplicationRebuildDisplayMetrics },
			{ "BroadcastSafeFrameChangedEvent", lua_BroadcastSafeFrameChangedEvent },
			{ "GetSafeZoneSize", lua_GetSafeZoneSize },
			{ "SetForceSync", lua_SetForceSync },
			{ "ClipboardCopy", lua_ClipboardCopy },
			{ "ClipboardPaste", lua_ClipboardPaste },
			{ "GetDocumentPath", lua_GetDocumentPath },
			{ "GetCommandLineText", lua_GetCommandLineText },
			{ "IsPluginEnable", lua_IsPluginEnable },

#if !UE_BUILD_SHIPPING
			{ "cmd", lua_ConsoleCommand },
#endif

			{ "BeginProfiler", lua_BeginProfiler },
			{ "EndProfiler", lua_EndProfiler },
			{ "CleanUpProfilers", lua_ClearUpProfilers },

			{ "GetPlatformMemoryStats", lua_GetPlatformMemoryStats },
			{ "UELog", lua_UELog },
			{ "UEAssert", lua_UEAssert },
			{ "SetUEIgnoreDebugger", lua_SetUEIgnoreDebugger },

			{ "SimuCrash", lua_SimuCrash },
			{ "SimuCheckCrash", lua_SimuCheckCrash },

			{ NULL, NULL }
		};

		const luaL_Reg Lib_Debug_Funcs[] =
		{
			{ "LogError", lua_Debug_LogError },
			{ "LogWarning", lua_Debug_LogWarning },
			{ "LogInfo", lua_Debug_LogInfo },
			{ "AzureLuaAllocStat", lua_AzureLuaAllocStat },
			{ NULL, NULL }

		};

		const luaL_Reg Lib_Time_Funcs[] =
		{
			{ "get_realtimeSinceStartup", lua_realtimeSinceStartup },
			{ "get_frameCount", lua_GetCurFrameCount },
			{ "GetCurFrameTime", lua_GetCurFrameTime },
			{ NULL, NULL }
		};

		const luaL_Reg Lib_FullMips_Funcs[] =
		{
			{ "Enable", lua_FullMips_Enable },
			{ "Disable", lua_FullMips_Disable },
			{ "IsEnabled", lua_FullMips_IsEnabled },
			{ "Reset", lua_FullMips_Reset },
			{ "AddActor", lua_FullMips_AddActor },
			{ "RemoveActor", lua_FullMips_RemoveActor },
			{ "RemoveActorByTag", lua_FullMips_RemoveActorByTag },
			{ "ListActors", lua_FullMips_ListActors },
			{ "ListTextures", lua_FullMips_ListTextures },
			{ "Update", lua_FullMips_Update },
			{ NULL, NULL }
		};

		const luaL_Reg Lib_ScreenShot_Funcs[] =
		{
			{ "init", lua_screenShot_init },
			{ "ReleaseData", lua_screenShot_releaseData },
			{ "createTexture", lua_screenShot_createTexture },
			{ "saveToFile", lua_screenShot_saveToFile },
			{ "cropAndSaveToFile", lua_screenShot_cropAndSaveToFile },
			{ "shot", lua_screentShot },
			{ NULL, NULL }
		};

		const luaL_Reg Lib_ThreadJobForLua_Funcs[] =
		{
			{ "Init", lua_ThreadJobForLua_Init },
			{ "Destroy", lua_ThreadJobForLua_Destroy },
			{ "SetHasPendingJob", lua_ThreadJobForLua_SetHasPendingJob },
			{ "get_JobTimeLimitReached", lua_ThreadJobForLua_JobTimeLimitReached },
			{ NULL, NULL }
		};

		extern luaL_Reg const Lib_GameUtil2_Funcs[];

		extern luaL_Reg const Lib_GameDebugUtil_Funcs[];

#if PLATFORM_WINDOWS
		extern luaL_Reg const Lib_WindowsUtil_Funcs[];
#endif

#if WITH_EDITOR
		extern luaL_Reg const Lib_EditorUtil_Funcs[];
#endif

		const luaL_Reg Lib_DeadLock_Funcs[] =
		{
			{ "Start", lua_DeadLock_Start },
			{ "Stop", lua_DeadLock_Stop },
			{ "SetActive", lua_DeadLock_SetActive },
			{ "Sleep", lua_DeadLock_TestSleep },

			{ NULL, NULL }
		};


		void Register(lua_State *L)
		{
			luaL_register(L, "GameUtil",	Lib_GameUtil_Funcs);
			lua_pop(L, 1);
			luaL_register(L, "GameUtil2", Lib_GameUtil2_Funcs);
			lua_pop(L, 1);
			luaL_register(L, "GameDebugUtil", Lib_GameDebugUtil_Funcs);
			lua_pop(L, 1);
#if PLATFORM_WINDOWS
			luaL_register(L, "WindowsUtil", Lib_WindowsUtil_Funcs);
			lua_pop(L, 1);
#endif
#if WITH_EDITOR
			luaL_register(L, "EditorUtil", Lib_EditorUtil_Funcs);
			lua_pop(L, 1);
#endif
			luaL_register(L, "Debug",		Lib_Debug_Funcs);
			lua_pop(L, 1);
			luaL_register(L, "FullMips", Lib_FullMips_Funcs);
			lua_pop(L, 1);
			luaL_register(L, "ScreenShot", Lib_ScreenShot_Funcs);
			lua_pop(L, 1);
			luaL_register(L, "ThreadJobForLua", Lib_ThreadJobForLua_Funcs);
			lua_pop(L, 1);

			luaL_register(L, "DeadLockDetector", Lib_DeadLock_Funcs);
			lua_pop(L, 1);

			lua_newtable(L);
			luaL_register(L, NULL,		Lib_Time_Funcs);
			AzureHelpFuncs::AuxRegister(L, "Time");

			LuaSystemInfo::Register(L);
			LuaScreenInfo::Register(L);

			LuaAzureInputCtrl::Register(L);
			LuaAzureObjectComponent::Register(L);
			LuaColor::Register(L);
			LuaTransform::Register(L);
			LuaCommonData::Register(L);
			LuaAzureGameSession::Register(L);
			LuaInterp::Register(L);

			AzureHelpFuncs::AuxSetMtLink(L, "Time");
			LuaSystemInfo::SetMtLink(L);
			LuaScreenInfo::SetMtLink(L);

			LuaAzureInputCtrl::SetMtLink(L);
			LuaAzureObjectComponent::SetMtLink(L);
			LuaColor::SetMtLink(L);
			LuaCommonData::SetMtLink(L);
			LuaAzureGameSession::SetMtLink(L);
			LuaInterp::SetMtLink(L);

			LuaPatcher::Register(L);
			LuaAFile::Register(L);
			LuaUObjectGlobals::Register(L);

			//LuaGVoice::Register(L);
			//LuaTApm::Register(L);
			LuaTCos::Register(L);
			LuaZLOfflineDownload::Register(L);
			LuaTSimuHelper::Register(L);
			//LuaTssSDK::Register(L);
			//LuaGSDK::Register(L);
			//LuaPandora::Register(L);
			LuaPandoraCustom::Register(L);

			LuaGamePlayerABInterface::Register(L);

			LuaInGameUpdate::Register(L);
			LuaMD5::Register(L);
			LuaVersionFlags::Register(L);
			LuaAzureWorldTilesLODManager::Register(L);

			HttpLuaWrapper::Register(L);
		}
	}
}
