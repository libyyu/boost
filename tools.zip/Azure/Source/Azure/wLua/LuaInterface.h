#pragma once

#include "AzureLuaIntegration.h"

#ifdef UE_BUILD_DEBUG
#define  LUASTACKCHECK   check
#endif

#include "Utility/LuaStackGuard.h"

class UObject;

namespace wLua
{
	void Register(lua_State * L);
	void SetMtLink(lua_State * L);

	namespace GameLuaInterface
	{
		void Register(lua_State *L);
	}
}

namespace LuaAzureGameSession
{
	static const char* mt_name = "ECGameSession";
	void Register(lua_State *L);
	void SetMtLink(lua_State *L);
}

namespace LuaCommonData
{
	static const char* mt_name = "LuaCommonData";
	void Register(lua_State *L);
	void SetMtLink(lua_State *L);
}

namespace LuaAzureObjectComponent
{
	static const char* mt_name = "AzureObjectComponent";
	void Register(lua_State *L);
	void SetMtLink(lua_State *L);
}

namespace LuaColor
{
	static const char* mt_name = "Color";
	void Register(lua_State *L);
	void SetMtLink(lua_State *L);
}

namespace LuaAzureInputCtrl
{
	static const char* mt_name = "AzureInputCtrl";
	void Register(lua_State *L);
	void SetMtLink(lua_State *L);
}

namespace LuaAzureTaskInterface
{
	static const char* mt_name = "TaskInterface";
	void Register(lua_State *L);
	void SetMtLink(lua_State *L);
}

namespace LuaLevelSequenceActorEx
{
	static const char* mt_name = "LevelSequenceActorEx";
	void Register(lua_State *L);
	void SetMtLink(lua_State *L);
}

namespace LuaTransform
{
	static const char* mt_name = "Transform";
	void Register(lua_State *L);
}