#include "Azure.h"
#include "LuaInterface.h"
#include "ResourceLoader/AzureResourceLoader.h"
#include "AzureEntryPoint.h"
#include "AzureBinaryReader.h"
#include "AzureUtility.h"
#include "PlatformConfig.h"
#include "StreamingAssetHelper.h"
#include "Engine.h"
#include "FileSystem/IPlatformAFileWrapper.h"
#include "Runtime/Online/HTTP/Public/Http.h"
#include "AFI.h"
#include <fstream>
#include <string>

/*
	�������ݸ�ʽ�����ش���ʱ����ɾ�������ݡ������˰汾����Ϊ�ж�����
	�޸ļ�¼��
	v1: ����ǰ�޸��˲���С������ bug
*/
static int InGameUpdate_DataVersion = 1;

extern wLua::Lua* AAzureEntryPoint_GetWLua();
extern void AzureInGameUpdateDownloadFile(const char* szFile, uint64_t fileOffset, uint64_t downloadSize, int bytesPerSecond, void* UserData, AInGameUpdateDownloadCompleteFuncType callbackFunc, AInGameUpdateDownloadReceiveDataFuncType receiveDataFunc, bool bStartAll);
extern void StartLogLoadResNames();
extern bool EndLogLoadResNames(const char* szLogFileName);
extern void AddExternalLogResName(const FString& PackageName);
extern void AzureInGameUpdateDownloadFile_http2(const char* szFile, uint64_t fileOffset, uint64_t downloadSize, int bytesPerSecond, void* InUserData,
	AInGameUpdateDownloadCompleteFuncType callbackFunc, AInGameUpdateDownloadReceiveDataFuncType receiveDataFunc, bool bStartAll);

namespace LuaInGameUpdate
{
	static int lua_InGameUpdate_GetDataVersion(lua_State * L)
	{
		lua_pushinteger(L, InGameUpdate_DataVersion);
		return 1;
	}

	static int lua_InGameUpdate_IsResourceReadyForLoad(lua_State * L)
	{
		const char* szFileName = lua_tostring(L, 1);
		bool bRet = af_IsResourceReadyForLoad(szFileName);
		lua_pushboolean(L, bRet ? 1 : 0);
		return 1;
	}

	static int lua_InGameUpdate_IsResourcesInConfigAllReady(lua_State* L) {
		bool bAllReady = true;
		const char* szConfigPath = luaL_checkstring(L, 1);
		ABYTE* pBuffer;
		ADWORD nFileLength;
		if (exp_af_ReadFileAllBytes(szConfigPath, &pBuffer, &nFileLength))
		{
			std::istringstream contentStream(std::string((const char*)pBuffer, (const char*)pBuffer+ nFileLength));
			std::string line;
			while (std::getline(contentStream, line))
			{
				if (line.size() > 0 && line.back() == '\r')
					line.pop_back();

				char const* path = line.c_str();
				size_t fileSize = 0;
				bool bRet = af_IsResourceReadyForLoad(path);
				if (!bRet) {
					bAllReady = false;
					break;
				}
			}
			exp_af_ReleaseFileBuffer(pBuffer);
		}
		lua_pushboolean(L, bAllReady ? 1 : 0);
		return 1;
	}

	static int lua_InGameUpdate_GetFileInfoInRealPckFile(lua_State * L)
	{
		const char* path = luaL_checkstring(L, 1);
		char realFilePath[1024];
		a_int64 fileOffset;
		a_int64 fileLen;
		a_int64 compressedLen;
		bool isCompressed;
		bool isSepFile;

		if (af_InGameUpdate_GetFileInfoInRealPckFile(path, realFilePath, sizeof(realFilePath), fileOffset, fileLen, compressedLen, isCompressed, isSepFile))
		{
			lua_pushstring(L, realFilePath);
			lua_pushnumber(L, fileOffset);
			lua_pushnumber(L, fileLen);
			lua_pushnumber(L, compressedLen);
			lua_pushboolean(L, isCompressed);
			lua_pushboolean(L, isSepFile);
			return 6;
		}
		else
		{
			lua_pushnil(L);
			return 1;
		}
	}

	static int lua_InGameUpdate_IsFileSelfComplete(lua_State * L)
	{
		const char* path = luaL_checkstring(L, 1);
		bool ret = af_InGameUpdate_IsFileSelfComplete(path);
		lua_pushboolean(L, ret);
		return 1;
	}

	static int lua_InGameUpdate_DownloadResourceFileAndDependencies(lua_State * L)
	{
		int nTop = lua_gettop(L);
		const char* szFileName = lua_tostring(L, 1);

		wLua::lua_registry_handle callbackRef;

		// �ص����������ǿ�
		if (nTop >= 2 && lua_isfunction(L, 2))
		{
			lua_pushvalue(L, 2);
			callbackRef = wLua::lua_registry_handle::wlua_ref(L, LUA_REGISTRYINDEX);
		}

		int Priority;
		int UserData;

		// ���ȼ�����ֵԽ��Խ����
		if (nTop >= 3 && lua_isnumber(L, 3))
			Priority = lua_tointeger(L, 3);
		else
			Priority = 0;

		if (nTop >= 4 && lua_isnumber(L, 4))
			UserData = lua_tointeger(L, 4);
		else
			UserData = 0;

		af_DownloadResourceFileAndDependencies(szFileName, [callbackRef](AInGameUpdateDownloadResult result)
		{
			if (!AAzureEntryPoint::IsInit())
				return;

			wLua::Lua* wlua = AAzureEntryPoint::Instance->GetWLua();

			if (!wlua)
				return;

			if (!callbackRef.IsValid())
				return;

			lua_State_Wrapper temp_L = wlua->GetL();

			if (!temp_L)
				return;

			lua_rawgeti(temp_L, LUA_REGISTRYINDEX, callbackRef);
			wLua::lua_registry_handle::wlua_unref(temp_L, LUA_REGISTRYINDEX, callbackRef);

			if (!lua_isfunction(temp_L, -1))
			{
				lua_pop(temp_L, 1);
				return;
			}

			lua_pushvalue(temp_L, -1);	//-> cb, cb
			lua_pushinteger(temp_L, (int)result); //-> cb, cb, result

			bool bRet = wlua->PCallWithFunctionInfo(1, 0);	//-> cb, [err]

			if (bRet)
			{
				lua_pop(temp_L, 1);
			}
			else
			{
				lua_pushvalue(temp_L, -2);
				FString info = wlua->GetFunctionInfo();

				FString errorInfo = FString::Printf(TEXT("@InGameUpdateCallBack:%s@@@"), *info);
				if (lua_isstring(temp_L, -1))
					errorInfo += UTF8_TO_TCHAR(lua_tostring(temp_L, -1));

				UE_LOG(LogAzure, Error, TEXT("LUA: %s"), *errorInfo);
				lua_pop(temp_L, 2);
			}
		}, Priority, UserData);

		return 0;
	}

	static int lua_InGameUpdate_CancelDownloadResourceFile(lua_State * L)
	{
		const char* szFileName = lua_tostring(L, 1);
		int MaxPriority = lua_tointeger(L, 2);
		af_CancelDownloadResourceFile(szFileName, MaxPriority);
		return 0;
	}

	static int lua_InGameUpdate_GetDownloadResourceFileTotalSize(lua_State * L)
	{
		uint32_t TotalSize;
		uint32_t CurDownloadedSize;
		const char* szFileName = lua_tostring(L, 1);
		bool bOk = af_GetDownloadResourceFileTotalSize(szFileName, TotalSize, CurDownloadedSize);
		lua_pushboolean(L, bOk ? 1 : 0);
		lua_pushnumber(L, TotalSize);
		lua_pushnumber(L, CurDownloadedSize);
		return 3;
	}

	static int lua_InGameUpdate_GetDownloadResourceListTotalSize(lua_State * L)
	{
		uint64_t TotalSize;
		uint64_t CurDownloadedSize;

		if (!lua_istable(L, 1))
		{
			lua_pushstring(L, "GetDownloadResourceListTotalSize: param must be table(assetList)");
			lua_error(L);
			return 1;
		}

		std::vector<const char*> assetList;
		{
			lua_pushnil(L);
			while (lua_next(L, 1) != 0)
			{
				const char* assetPath = luaL_checkstring(L, -1);
				assetList.push_back(assetPath);
				lua_pop(L, 1);
			}
		}

		bool bOk = af_GetDownloadResourceListTotalSize(assetList, TotalSize, CurDownloadedSize);
		lua_pushboolean(L, bOk ? 1 : 0);
		lua_pushnumber(L, (lua_Number)TotalSize);
		lua_pushnumber(L, (lua_Number)CurDownloadedSize);
		return 3;
	}

	static int lua_InGameUpdate_GetAllSize(lua_State * L)
	{
		uint64_t TotalSize;
		uint64_t CurDownloadedSize;
		bool bOk = af_InGameUpdate_GetAllSize(TotalSize, CurDownloadedSize);
		lua_pushboolean(L, bOk ? 1 : 0);
		lua_pushnumber(L, (lua_Number)TotalSize);
		lua_pushnumber(L, (lua_Number)CurDownloadedSize);
		return 3;
	}

	static int lua_InGameUpdate_GetAccumulativeDownloadSize(lua_State* L)
	{
		uint64_t downloadSize = af_InGameUpdate_GetAccumulativeDownloadSize();
		lua_pushnumber(L, (lua_Number)downloadSize);
		return 1;
	}

	static int lua_InGameUpdate_SetDownloadResourcePriority(lua_State * L)
	{
		const char* szFileName = lua_tostring(L, 1);
		int Priority = lua_tointeger(L, 2);
		af_SetDownloadResourcePriority(szFileName, Priority);
		return 0;
	}

	static int lua_InGameUpdate_ResumeOrSuspendDownload(lua_State * L)
	{
		bool bResume = !!lua_toboolean(L, 1);
		af_InGameUpdate_ResumeOrSuspendDownload(bResume);
		return 0;
	}

	static int lua_InGameUpdate_SetDownloadSpeedBytesPerSecond(lua_State * L)
	{
		unsigned int speed = lua_tointeger(L, 1);
		af_InGameUpdate_SetDownloadSpeedBytesPerSecond(speed);
		return 0;
	}

	static int lua_InGameUpdate_GetDownloadSpeedBytesPerSecond(lua_State* L)
	{
		lua_pushnumber(L, (lua_Number)af_InGameUpdate_GetDownloadSpeedBytesPerSecond());
		return 1;
	}

	static int lua_InGameUpdate_GetRealDownloadSpeedBytesPerSecond(lua_State * L)
	{
		unsigned int speed = af_GetRealDownloadSpeedBytesPerSecond();
		lua_pushnumber(L, speed);
		return 1;
	}

	static int lua_InGameUpdate_SetHttpRetryTimeInterval(lua_State * L)
	{
		unsigned int interval = lua_tointeger(L, 1);
		af_InGameUpdatge_SetHttpRetryTimeInterval(interval);
		return 0;
	}

	static int lua_InGameUpdate_SetDownloadCallbackTimeLimit(lua_State * L)
	{
		float limit = (float)lua_tonumber(L, 1);
		af_InGameUpdatge_SetDownloadCallbackTimeLimit(limit);
		return 0;
	}

	static int lua_InGameUpdate_SetMaxDownloadSizeSimultaneously(lua_State * L)
	{
		unsigned int size = lua_tointeger(L, 1);
		af_InGameUpdate_SetMaxDownloadSizeSimultaneously(size);
		return 0;
	}

	static int lua_InGameUpdate_SetMaxDownloadCountSimultaneously(lua_State * L)
	{
		unsigned int count = lua_tointeger(L, 1);
		af_InGameUpdate_SetMaxDownloadCountSimultaneously(count);
		return 0;
	}

	static int lua_InGameUpdate_GetMinFreeDiskSpaceToFail(lua_State * L)
	{
		unsigned int count = af_InGameUpdate_GetMinFreeDiskSpaceToFail();
		lua_pushnumber(L, (lua_Number)count);
		return 1;
	}

	static int lua_InGameUpdate_SetMinFreeDiskSpaceToFail(lua_State * L)
	{
		unsigned int count = lua_tointeger(L, 1);
		af_InGameUpdate_SetMinFreeDiskSpaceToFail(count);
		return 0;
	}

	// For test purpose
	static int lua_InGameUpdate_DownloadAllResourceFiles(lua_State * L)
	{
		af_InGameUpdate_DownloadAllResourceFiles();
		return 0;
	}

	static int lua_InGameUpdate_IsAllResourceDownloaded(lua_State* L)
	{
		lua_pushboolean(L, af_InGameUpdate_IsAllResourceDownloaded() ? 1 : 0);
		return 1;
	}

	static int lua_InGameUpdate_GetCurUrlIndex(lua_State* L)
	{
		lua_pushinteger(L, af_InGameUpdate_GetCurUrlIndex());
		return 1;
	}

	static int lua_InGameUpdate_GetResourceDownloadUrl(lua_State* L)
	{
		const char* szPackageName = lua_tostring(L, 1);
		int urlIndex = lua_tointeger(L, 2);

		std::vector<std::string> urls;
		if (!af_InGameUpdate_GetResourceDownloadUrl(szPackageName, urlIndex, urls))
		{
			lua_pushboolean(L, 0);
			return 1;
		}

		lua_pushboolean(L, 1);
		lua_newtable(L);
		int i = 1;
		for (auto& url : urls)
		{
			lua_pushstring(L, url.c_str());
			lua_rawseti(L, -2, i++);
		}
		return 2;
	}

	static int lua_InGameUpdate_DumpEntries(lua_State * L)
	{
		const char* outputPath = lua_tostring(L, 1);
		af_InGameUpdate_DumpEntries(outputPath);
		return 0;
	}

	static int lua_InGameUpdate_ValidateEntries(lua_State * L)
	{
		bool ret = af_InGameUpdate_ValidateEntries();
		lua_pushboolean(L, ret ? 1 : 0);
		return 1;
	}


	static int lua_InGameUpdate_StartLogLoadResNames(lua_State * L)
	{
		StartLogLoadResNames();
		return 0;
	}

	static int lua_InGameUpdate_EndLogLoadResNames(lua_State * L)
	{
		const char* szLogName = lua_tostring(L, 1);
		lua_pushboolean(L, EndLogLoadResNames(szLogName) ? 1 : 0);
		return 1;
	}

	static int lua_InGameUpdate_AddExternalLogResName(lua_State * L)
	{
		const char* szPackageName = lua_tostring(L, 1);
		AddExternalLogResName(UTF8_TO_TCHAR(szPackageName));
		return 0;
	}

	bool AzureInGameUpdateCreateDirectory(const char* szDir)
	{
		return FPlatformFileManager::Get().GetPlatformFile().GetPlatformPhysical().CreateDirectoryTree(*FPaths::GetPath(UTF8_TO_TCHAR(szDir)));
	}

	bool AzureInGameUpdateDeleteFile(const char* szFile)
	{
		return FPlatformFileManager::Get().GetPlatformFile().GetPlatformPhysical().DeleteFile(UTF8_TO_TCHAR(szFile));
	}

	uint64_t AzureInGameUpdateGetDiskFreeSpace(const char* szDir)
	{
		const FString path = UTF8_TO_TCHAR(szDir);
		uint64 TotalDiskSpace = 0;
		uint64 FreeDiskSpace = 0;
		if (!FPlatformMisc::GetDiskTotalAndFreeSpace(path, TotalDiskSpace, FreeDiskSpace))
		{
			return 0;
		}
		return (uint64_t)FreeDiskSpace;
	}

	// In game thread
	bool AzureInGameUpdateGetPreDownloadPackageDir(const char* FileName, char* DirPath, unsigned int DirPathLen)
	{
		if (!AAzureEntryPoint::IsInit())
			return false;

		auto* wlua = AAzureEntryPoint::Instance->GetWLua();

		if (!wlua)
			return false;

		lua_State_Wrapper L = wlua->GetL();
		lua_getglobal(L, "GetPreDownloadPackageDir");
		if (lua_isfunction(L, -1))
		{
			lua_pushstring(L, FileName);
			wlua->PCall(1, 1);

			const char* ret = lua_tostring(L, -1);
			strncpy(DirPath, ret, DirPathLen);
			lua_pop(L, 1);
		}
		else
		{
			lua_pop(L, 1);
			return false;
		}
		return true;
	}

	// In download thread
	void AzureInGameUpdateNotifyPreDownloadPackage(const char* InFileName, bool BeforeReadyForUseStage, bool StartToProcess, unsigned int PackageSize, unsigned int PackageIndex)
	{
		FString fileName = FString(UTF8_TO_TCHAR(InFileName));
		AsyncTask(ENamedThreads::GameThread, [fileName, BeforeReadyForUseStage, StartToProcess, PackageSize, PackageIndex]() {
			if (!AAzureEntryPoint::IsInit())
				return;

			auto* wlua = AAzureEntryPoint::Instance->GetWLua();

			if (!wlua)
				return;

			lua_State_Wrapper L = wlua->GetL();
			lua_getglobal(L, "NotifyPredownloadPackage");
			lua_pushstring(L, TCHAR_TO_UTF8(*fileName));
			lua_pushboolean(L, BeforeReadyForUseStage ? 1 : 0);
			lua_pushboolean(L, StartToProcess ? 1 : 0);
			lua_pushnumber(L, (lua_Number)PackageSize);
			lua_pushinteger(L, PackageIndex);
			wlua->Call(5);
		});
	}

	// In download thread
	void AzureInGameUpdateNotifyPreDownloadPackageFirstIndex(unsigned int Index)
	{
		AsyncTask(ENamedThreads::GameThread, [Index]() {
			if (!AAzureEntryPoint::IsInit())
				return;

			auto* wlua = AAzureEntryPoint::Instance->GetWLua();

			if (!wlua)
				return;

			lua_State_Wrapper L = wlua->GetL();
			lua_getglobal(L, "NotifyPredownloadVersion");
			lua_pushinteger(L, (int)Index);
			wlua->Call(1);
		});
	}

	void AzureInGameUpdateOnFatalError(AInGameUpdateErrorFlag ErrorFlag, bool NeedExitGameFlag)
	{
		AsyncTask(ENamedThreads::GameThread, [ErrorFlag, NeedExitGameFlag]()
		{
			if (!AAzureEntryPoint::IsInit())
				return;

			auto* wlua = AAzureEntryPoint::Instance->GetWLua();

			if (!wlua)
				return;

			lua_State_Wrapper L = wlua->GetL();
			lua_getglobal(L, "OnInGameUpdateFatalError");
			lua_pushinteger(L, (int)ErrorFlag);
			lua_pushboolean(L, NeedExitGameFlag ? 1 : 0);
			wlua->Call(2);
		});
	}

	void AzureInGameUpdateDepFileDownloadedNotify(int UserData, unsigned int DownloadedSize)
	{
		if (!AAzureEntryPoint::IsInit())
			return;

		auto* wlua = AAzureEntryPoint::Instance->GetWLua();

		if (!wlua)
			return;

		lua_State_Wrapper L = wlua->GetL();
		lua_getglobal(L, "OnInGameUpdateDepFileDownloaded");
		lua_pushinteger(L, UserData);
		lua_pushnumber(L, (lua_Number)DownloadedSize);
		wlua->Call(2);
	}

	static int lua_InGameUpdate_Init(lua_State * L)
	{
#if UE_GAME
		static const char* fileExts[] = {
			".uasset",
			".umap",
		};

		InGameUpdateExternalFuncs funcs;
		funcs.CreateDirectoryFunc = AzureInGameUpdateCreateDirectory;
		funcs.DeleteFileFunc = AzureInGameUpdateDeleteFile;
		funcs.GetDiskFreeSpaceFunc = AzureInGameUpdateGetDiskFreeSpace;
		funcs.OnFatalErrorFunc = AzureInGameUpdateOnFatalError;
		funcs.DepFileDownloadedNotifyFunc = AzureInGameUpdateDepFileDownloadedNotify;
		funcs.GetPreDownloadPackageDirFunc = AzureInGameUpdateGetPreDownloadPackageDir;
		funcs.NotifyPreDownloadPackageFunc = AzureInGameUpdateNotifyPreDownloadPackage;
		funcs.NotifyPreDownloadPackageFirstIndexFunc = AzureInGameUpdateNotifyPreDownloadPackageFirstIndex;

		int paramCount = lua_gettop(L);
		const char* szFileEntryListPath = lua_tostring(L, 1);
		const char* szBaseUrl = lua_tostring(L, 2);
		bool PreCreatePackage = !!lua_toboolean(L, 3);
		const char* szBaseUrlBackup1 = nullptr;
		const char* szBaseUrlBackup2 = nullptr;
		bool bUseHttp2 = false;

		if (paramCount >= 4 && lua_isboolean(L, 4))
			bUseHttp2 = !!lua_toboolean(L, 4);

		if (paramCount >= 5 && lua_isstring(L, 5))
			szBaseUrlBackup1 = lua_tostring(L, 5);

		if (paramCount >= 6 && lua_isstring(L, 6))
			szBaseUrlBackup2 = lua_tostring(L, 6);

		if (bUseHttp2)
			funcs.DownloadFileFunc = AzureInGameUpdateDownloadFile_http2;
		else
			funcs.DownloadFileFunc = AzureInGameUpdateDownloadFile;

		// must call this to init HttpModule
		FHttpModule::Get();

		const char* szPackagesInfoFilePath = nullptr;

		if (paramCount >= 7 && lua_isstring(L, 7))
			szPackagesInfoFilePath = lua_tostring(L, 7);

		bool bDisablePrerequisitePackages = false;

		if (paramCount >= 8 && lua_isboolean(L, 8))
			bDisablePrerequisitePackages = !!lua_toboolean(L, 8);

		const char* szBaseDir;

		if (paramCount >= 9 && lua_isstring(L, 9))
			szBaseDir = lua_tostring(L, 9);
		else
			szBaseDir = FPlatformAFileWrapper::GetAssetsPath().c_str();
		

		const char* fileListUrlPrefix = "b_file_list/";
		if (paramCount >= 10 && lua_isstring(L, 10))
			fileListUrlPrefix = lua_tostring(L, 10);


		bool bOk = af_InGameUpdate_Init(szBaseDir, szFileEntryListPath, szBaseUrl, szBaseUrlBackup1, szBaseUrlBackup2,
			funcs, fileExts, sizeof(fileExts) / sizeof(fileExts[0]), PreCreatePackage, szPackagesInfoFilePath, bDisablePrerequisitePackages,
			fileListUrlPrefix);
		lua_pushboolean(L, bOk ? 1 : 0);
#else
		lua_pushboolean(L, 1);
#endif
		return 1;
	}

	static int lua_InGameUpdate_InitForResUpdate(lua_State * L)
	{
#if UE_GAME
		int paramCount = lua_gettop(L);

		const char* szBaseDir = luaL_optstring(L, 1, FPlatformAFileWrapper::GetAssetsPath().c_str());

		InGameUpdateExternalFuncs funcs = {};
		funcs.CreateDirectoryFunc = AzureInGameUpdateCreateDirectory;
		funcs.DeleteFileFunc = AzureInGameUpdateDeleteFile;
		funcs.GetDiskFreeSpaceFunc = AzureInGameUpdateGetDiskFreeSpace;
		funcs.OnFatalErrorFunc = AzureInGameUpdateOnFatalError;

		bool bOk = af_InGameUpdate_InitForResUpdate(szBaseDir, funcs);
		lua_pushboolean(L, bOk ? 1 : 0);
#else
		lua_pushboolean(L, 1);
#endif
		return 1;
	}

	//ע�⣺�����ڳ�ʼ��ǰ����
	static int lua_InGameUpdate_RepairAllSavedDownloadEntryListAsync(lua_State* L)
	{
		const char* szBaseDir = luaL_optstring(L, 1, FPlatformAFileWrapper::GetAssetsPath().c_str());
		std::string baseDirStr = szBaseDir;
		luaL_checktype(L, 2, LUA_TFUNCTION);
		lua_pushvalue(L, 2);
		wLua::lua_registry_handle funcRef = wLua::lua_registry_handle::wlua_ref(L, LUA_REGISTRYINDEX);

		Async<void>(EAsyncExecution::ThreadPool, [baseDirStr, funcRef]() {
			bool anyEntryRepaired = false;
			InGameUpdateExternalFuncs funcs = {};
			funcs.CreateDirectoryFunc = AzureInGameUpdateCreateDirectory;
			funcs.DeleteFileFunc = AzureInGameUpdateDeleteFile;
			funcs.GetDiskFreeSpaceFunc = AzureInGameUpdateGetDiskFreeSpace;
			funcs.OnFatalErrorFunc = AzureInGameUpdateOnFatalError;

			AInGameUpdateErrorFlag errorFlag = af_InGameUpdate_RepairAllSavedDownloadFileEntry(baseDirStr.c_str(), funcs, anyEntryRepaired);

			AsyncTask(ENamedThreads::GameThread, [errorFlag, anyEntryRepaired, funcRef]()
			{
				lua_State_Wrapper L = AAzureEntryPoint_GetWLua()->GetL();
				if (L)
				{
					lua_rawgeti(L, LUA_REGISTRYINDEX, funcRef);
					wLua::lua_registry_handle::wlua_unref(L, LUA_REGISTRYINDEX, funcRef);
					lua_pushinteger(L, int(errorFlag));
					lua_pushinteger(L, anyEntryRepaired);
					AAzureEntryPoint_GetWLua()->Call(2);
				}
			});
		});
		return 0;
	}

	static int lua_InGameUpdate_Release(lua_State * L)
	{
		af_InGameUpdate_Release();
		return 0;
	}

	static int lua_InGameUpdate_ReleaseForResUpdate(lua_State * L)
	{
		af_InGameUpdate_ReleaseForResUpdate();
		return 0;
	}

	static int lua_InGameUpdate_GetFatalFailState(lua_State * L)
	{
		bool ret = af_InGameUpdate_GetFatalFailState();
		lua_pushboolean(L, ret ? 1 : 0);
		return 1;
	}

	static int lua_InGameUpdate_ClearFatalFailState(lua_State * L)
	{
		af_InGameUpdate_ClearFatalFailState();
		return 0;
	}

	static int lua_InGameUpdate_IsInit(lua_State * L)
	{
		lua_pushboolean(L, af_InGameUpdate_IsInit() ? 1 : 0);
		return 1;
	}

	static int lua_InGameUpdate_IsReadyForUse(lua_State * L)
	{
		lua_pushboolean(L, af_InGameUpdate_IsReadyForUse() ? 1 : 0);
		return 1;
	}

	static int lua_InGameUpdate_GetStatusStr(lua_State * L)
	{
		lua_pushstring(L, (const char*)af_InGameUpdate_GetStatusStr());
		return 1;
	}

	static int lua_InGameUpdate_GetCurPreDownloadPackageSizeInfo(lua_State * L)
	{
		uint32_t TotalSize, ProcessedSize, DownloadedSize, PackageIndex, PackageCount, needCount, remainCount;
		bool bOk = af_GetCurPreDownloadPackageSizeInfo(TotalSize, ProcessedSize, DownloadedSize, PackageIndex, PackageCount, needCount, remainCount);
		lua_pushboolean(L, bOk ? 1 : 0);
		lua_pushnumber(L, (lua_Number)TotalSize);
		lua_pushnumber(L, (lua_Number)ProcessedSize);
		lua_pushnumber(L, (lua_Number)DownloadedSize);
		lua_pushnumber(L, (lua_Number)PackageIndex);
		lua_pushnumber(L, (lua_Number)PackageCount);
		lua_pushnumber(L, (lua_Number)needCount);
		lua_pushnumber(L, (lua_Number)remainCount);
		return 8;
	}

	static int lua_InGameUpdate_GetPreDownloadProgress(lua_State* L)
	{
		uint64_t DownloadedSize, TotalSize;
		bool bOk = af_InGameUpdate_GetPreDownloadProgress(DownloadedSize, TotalSize);
		lua_pushboolean(L, bOk ? 1 : 0);
		lua_pushnumber(L, (lua_Number)DownloadedSize);
		lua_pushnumber(L, (lua_Number)TotalSize);
		return 3;
	}

	static int lua_InGameUpdate_ProcessDownloadedPackageAsync(lua_State* L)
	{
		std::string packageName = luaL_checkstring(L, 1);
		luaL_checktype(L, 2, LUA_TFUNCTION);
		lua_pushvalue(L, 2);
		wLua::lua_registry_handle funcRef = wLua::lua_registry_handle::wlua_ref(L, LUA_REGISTRYINDEX);

		Async<void>(EAsyncExecution::ThreadPool, [packageName, funcRef]() {
			int retCode = 0;
			int processedSize = af_InGameUpdate_ProcessOuterDownloadedPackage(packageName.c_str());

			AsyncTask(ENamedThreads::GameThread, [retCode, processedSize, funcRef]()
			{
				lua_State_Wrapper L = AAzureEntryPoint_GetWLua()->GetL();
				if (L)
				{
					lua_rawgeti(L, LUA_REGISTRYINDEX, funcRef);
					wLua::lua_registry_handle::wlua_unref(L, LUA_REGISTRYINDEX, funcRef);
					lua_pushinteger(L, retCode);
					lua_pushinteger(L, processedSize);
					AAzureEntryPoint_GetWLua()->Call(2);
				}
			});
		});
		return 0;
	}

	static int lua_InGameUpdate_GetPackageDownloadStatus(lua_State* L) 
	{
		//packageFilePath��һ��StreamingAssets·�����ļ�����Ϊÿ��һ����Դ�ļ�·��
		const char* packageFilePath = luaL_checkstring(L, 1);
		uint64_t needDownloadSize = 0;
		uint64_t totalSize = 0;
		int needDownloadCount = 0;
		int totalCount = 0;

		auto ansiContent = StreamingAssetHelper::ReadFileText(UTF8_TO_TCHAR(packageFilePath));
		if (ansiContent.size() == 0)
			return 0;
		std::string contentStr((char const*)&ansiContent[0], (char const*)&ansiContent[0] + ansiContent.size());
		std::istringstream contentStream(contentStr);
		std::string line;
		while (std::getline(contentStream, line))
		{
			if (line.size() > 0 && line.back() == '\r')
				line.pop_back();

			char const* path = line.c_str();
			size_t fileSize = 0;
			bool bFinished = af_InGameUpdate_GetFileDownloadStatus(path, fileSize, false);
			if (fileSize != 0)
			{
				totalSize += fileSize;
				++totalCount;
				if (!bFinished)
				{
					needDownloadCount++;
					needDownloadSize += fileSize;
				}
			}
		}

		lua_pushnumber(L, (lua_Number)needDownloadSize);
		lua_pushnumber(L, (lua_Number)totalSize);
		lua_pushnumber(L, (lua_Number)needDownloadCount);
		lua_pushnumber(L, (lua_Number)totalCount);
		return 4;
	}

	static int lua_InGameUpdate_VersionFlag(lua_State* L) 
	{
		lua_pushboolean(L, 1);
		return 1;
	}

	const luaL_Reg Lib_InGameUpdate_Funcs[] =
	{
		{ "GetDataVersion", lua_InGameUpdate_GetDataVersion },

		{ "IsResourceReadyForLoad", lua_InGameUpdate_IsResourceReadyForLoad },
		{ "IsResourcesInConfigAllReady", lua_InGameUpdate_IsResourcesInConfigAllReady },
		{ "GetFileInfoInRealPckFile", lua_InGameUpdate_GetFileInfoInRealPckFile },
		{ "IsFileSelfComplete", lua_InGameUpdate_IsFileSelfComplete },
		{ "DownloadResourceFileAndDependencies", lua_InGameUpdate_DownloadResourceFileAndDependencies },
		{ "CancelDownloadResourceFile", lua_InGameUpdate_CancelDownloadResourceFile },
		{ "GetDownloadResourceFileTotalSize", lua_InGameUpdate_GetDownloadResourceFileTotalSize },
		{ "GetDownloadResourceListTotalSize", lua_InGameUpdate_GetDownloadResourceListTotalSize },
		{ "GetAllSize", lua_InGameUpdate_GetAllSize },
		{ "GetAccumulativeDownloadSize", lua_InGameUpdate_GetAccumulativeDownloadSize },
		{ "SetDownloadResourcePriority", lua_InGameUpdate_SetDownloadResourcePriority },
		{ "ResumeOrSuspendDownload", lua_InGameUpdate_ResumeOrSuspendDownload },
		{ "SetDownloadSpeedBytesPerSecond", lua_InGameUpdate_SetDownloadSpeedBytesPerSecond },
		{ "GetDownloadSpeedBytesPerSecond", lua_InGameUpdate_GetDownloadSpeedBytesPerSecond },
		{ "GetRealDownloadSpeedBytesPerSecond", lua_InGameUpdate_GetRealDownloadSpeedBytesPerSecond },
		{ "SetHttpRetryTimeInterval", lua_InGameUpdate_SetHttpRetryTimeInterval },
		{ "SetDownloadCallbackTimeLimit", lua_InGameUpdate_SetDownloadCallbackTimeLimit },
		{ "SetMaxDownloadSizeSimultaneously", lua_InGameUpdate_SetMaxDownloadSizeSimultaneously },
		{ "SetMaxDownloadCountSimultaneously", lua_InGameUpdate_SetMaxDownloadCountSimultaneously },
		{ "GetMinFreeDiskSpaceToFail", lua_InGameUpdate_GetMinFreeDiskSpaceToFail },
		{ "SetMinFreeDiskSpaceToFail", lua_InGameUpdate_SetMinFreeDiskSpaceToFail },
		{ "DownloadAllResourceFiles", lua_InGameUpdate_DownloadAllResourceFiles },
		{ "IsAllResourceDownloaded", lua_InGameUpdate_IsAllResourceDownloaded },
		{ "GetResourceDownloadUrl", lua_InGameUpdate_GetResourceDownloadUrl },
		{ "GetCurUrlIndex", lua_InGameUpdate_GetCurUrlIndex },

		{ "Init", lua_InGameUpdate_Init },
		{ "InitForResUpdate", lua_InGameUpdate_InitForResUpdate },
		{ "RepairAllSavedDownloadEntryListAsync", lua_InGameUpdate_RepairAllSavedDownloadEntryListAsync },
		{ "Release", lua_InGameUpdate_Release },
		{ "ReleaseForResUpdate", lua_InGameUpdate_ReleaseForResUpdate },
		{ "GetFatalFailState", lua_InGameUpdate_GetFatalFailState },
		{ "ClearFatalFailState", lua_InGameUpdate_ClearFatalFailState },
		{ "IsInit", lua_InGameUpdate_IsInit },
		{ "IsReadyForUse", lua_InGameUpdate_IsReadyForUse },
		{ "GetStatusStr", lua_InGameUpdate_GetStatusStr },
		{ "GetCurPreDownloadPackageSizeInfo", lua_InGameUpdate_GetCurPreDownloadPackageSizeInfo },
		{ "GetPreDownloadProgress", lua_InGameUpdate_GetPreDownloadProgress },
		{ "ProcessDownloadedPackageAsync", lua_InGameUpdate_ProcessDownloadedPackageAsync },
		{ "GetPackageDownloadStatus", lua_InGameUpdate_GetPackageDownloadStatus },
		{ "DumpEntries", lua_InGameUpdate_DumpEntries },
		{ "ValidateEntries", lua_InGameUpdate_ValidateEntries },

		{ "StartLogLoadResNames", lua_InGameUpdate_StartLogLoadResNames },
		{ "EndLogLoadResNames", lua_InGameUpdate_EndLogLoadResNames },
		{ "AddExternalLogResName", lua_InGameUpdate_AddExternalLogResName },

		{ "VersionFlag_ShareFileHandleFixed", lua_InGameUpdate_VersionFlag },

		{ NULL, NULL }
	};

	void Register(lua_State* L)
	{
		luaL_register(L, "InGameUpdate", Lib_InGameUpdate_Funcs);
		lua_pop(L, 1);
	}
}