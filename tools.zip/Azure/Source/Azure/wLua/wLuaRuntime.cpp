#include "wLuaRuntime.h"
#include "wLua/LuaInterface.h"
#include "wLuaIntegration.h"
#include "AzureExport.h"
#ifdef USE_DAIZONG
#include "Daizong.h"
#endif
#ifdef TRACY_ENABLE
#include "tracy/TracyLplus.hpp"
#endif
#include "ThreadJobForLua.h"
#ifdef USE_ZULONGGCLOUD
#include "ZLCloudExport.h"
#endif
#ifdef USE_ZLSDKPLUGIN
#include "LuaZLUniSDK.h"
#endif
#ifdef ENABLE_GVOICE
#include "GVoice.h"
#endif
#ifdef USE_LOONGSDK
#include "LoongSDK.h"
#endif
#ifdef USE_DZOSDK
#include "UnrealSdk.h"
#endif

#include "LuaUserdataAsTable.h"
#include "GUI/AzureMsgHandler.h"



namespace wLua
{
	static uint8_t* MakeLuaUserdataAndMark_Impl(lua_State* L, size_t rawSize)
	{
		size_t len = LuaUserdataAsTable::CalcUserdataSizeWithMagic(rawSize);
		uint8_t* userdata = (uint8_t*)lua_newuserdata(L, len);
		LuaUserdataAsTable::MarkUserdata(L);
		return userdata;
	}

	//lua�������������Ҫ��ʼ��
	void AzureLuaBase::OnInit(lua_State * L)
	{
		//һЩ���������ʱ�ӿ�
		wLua::MakeLuaUserdataAndMark = MakeLuaUserdataAndMark_Impl;
		wLua::ReadFileAllBytesFunc = exp_af_ReadFileAllBytes;
		wLua::ReleaseFileBufferFunc = exp_af_ReleaseFileBuffer;
		wLua::IsFileExistFunc = exp_af_IsFileExist;
		AzureHelpFuncs::AzureTryGetUserdataFromWeakTable = AzureHelpFuncs::tryGetUserdataFromWeakTable;
		AzureHelpFuncs::AzureRemoveUserdataFromWeakTable = AzureHelpFuncs::removeUserdataFromWeakTable;
		AzureHelpFuncs::AzureAuxRegister = AzureHelpFuncs::AuxRegister;
		AzureHelpFuncs::AzureAuxSetMtLink = AzureHelpFuncs::AuxSetMtLink;
		//��ʼ��
		LuaImpl::OnInit(L);
		//ע��AzureEngine�����һЩ��ˮ����
		exp_setup_luastate(L);

		inited = true;
	}
	//lua������ر�ǰ����Ҫ����
	void AzureLuaBase::OnPreFini(lua_State * L)
	{
		inited = false;
		
		LuaImpl::OnPreFini(L);
	}
	//lua������رպ�ı�Ҫ����
	void AzureLuaBase::OnPostFini()
	{
		//����AzureEngine�������
		exp_clear_luastate();

		//����registry��
		wLua::lua_registry_handle::clear_registry_info();

		LuaImpl::OnPostFini();
	}

	void AzureLuaBase::OnCheckGetL() const
	{
		if (ThreadJobForLua::Processing)
		{
			uint32 tid = FPlatformTLS::GetCurrentThreadId();
			auto inst = ThreadJobForLua::Instance();

			if (tid != inst->ThreadId)
				inst->WaitForJobFinish();
		}
	}

	/////////////////////////////////////////////////////////////////////////
	///
	//lua�������������Ҫ��ʼ��
	void AzureLuaRuntime::OnInit(lua_State * L)
	{
		//��ʼ��
		AzureLuaBase::OnInit(L);
		//ע����Ŀ��ˮ����
		wLua::Register(L);
		wLua::SetMtLink(L);
		//ע��GameUtil
		GameLuaInterface::Register(L);

		int nTop = lua_gettop(L);
		//ע��tracy
#ifdef TRACY_ENABLE
		tracy::LuaRegisterTracy(L);
		lua_settop(L, nTop);
#endif
		//ע�����
#ifdef USE_DAIZONG
		luaopen_daizong(L);
		lua_settop(L, nTop);
#endif
#ifdef ENABLE_GVOICE
		RegisterGVoice(L);
		lua_settop(L, nTop);
#endif
		//ע��ZLCloud�Լ�msdk
#ifdef USE_ZULONGGCLOUD
		ZLCloud::luaopen_msdk(L);
		ZLCloud::init();
		lua_settop(L, nTop);
#endif

#ifdef USE_ZLSDKPLUGIN
		luaopen_ZLUniSDK(L);
		lua_settop(L, nTop);
#endif
		// PCSDKע��
#ifdef USE_LOONGSDK
		FLoongSDKModule::RegisterLoongSDKFuncs(L);
		FLoongSDKModule::SetMtLinkLoongSDKFuncs(L);
#endif
#ifdef USE_DZOSDK
		FUnrealSdkModule::Setup(this);
#endif
		//Init GUI
		AzureMsgHandler::Init();
	}
	//lua������ر�ǰ����Ҫ����
	void AzureLuaRuntime::OnPreFini(lua_State * L)
	{
		AzureLuaBase::OnPreFini(L);
#ifdef USE_DZOSDK
		FUnrealSdkModule::Fini();
#endif
		//����ZLCloud
#ifdef USE_ZULONGGCLOUD
		ZLCloud::fini();
#endif
	}

	void AzureLuaRuntime::Tick(float DeltaTime)
	{
#ifdef USE_ZULONGGCLOUD
		if (inited) {
			ZLCloud::tick();
		}
#endif
	}


}