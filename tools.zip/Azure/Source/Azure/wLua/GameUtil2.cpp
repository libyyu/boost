#include "Azure.h"
#include "LuaInterface.h"
#include "ResourceLoader/AzureResourceLoader.h"
#include "AzureEntryPoint.h"
#include "AzureBinaryReader.h"
#include "Protocols/CommonData.h"
#include "AzureGPDataType.h"
#include "AzureGameSession.h"
#include "AzureNetDef.h"
#include "Utility/help_funcs.h"
#include "Utilities/AzureSystemInfo.h"
#include "Utilities/AzureTextureStreaming.h"
#include "DirClient.h"
#include "AzureExport.h"
#include "AzureHelpFunc.h"
#include "AzureTimeManager.h"
#include "GameLogic/Behavior/AzureBehaviorDef.h"
#include "GameLogic/Main/AzureObjectComponent.h"
#include "GameLogic/Input/AzureInputCtrl.h"
#include "AzureUtility.h"
#include "PlatformConfig.h"
#include "XmlParser.h"
#include "Blueprint/WidgetLayoutLibrary.h"
#include "Blueprint/SlateBlueprintLibrary.h"
#include "GUI/AzureHudTextMan.h"
#include "GUI/AzureScreenBulletMan.h"
#include "WidgetInteractionComponent.h"
#include "StreamingAssetHelper.h"
#include "Engine.h"
#include "Components/Widget.h"
#include "Components/PanelWidget.h"
#include "Components/CanvasPanelSlot.h"
#include "Components/ScrollBoxSlot.h"
#include "Components/PoseableMeshComponent.h"
#include "SkeletalRenderPublic.h"
#include "LevelSequenceActor.h"
#include "HAL/PlatformFilemanager.h"
#include "ContentStreaming.h"
#include "FileSystem/IPlatformAFileWrapper.h"
#include "UObject/UObjectArray.h"
#include "RenderingThread.h"
#include "Framework/Application/IInputProcessor.h"
#include "Runtime/Online/HTTP/Public/Http.h"
#include "Json.h"
#include "JsonUtilities.h"
//#include "RawMesh.h"
#include "AFI.h"
#include "LevelSequenceActorEx.h"
#include "Components/CustomBoneComponent.h"
#include "CustomCharacterTexture.h"
#include "AzureLinearMotorComponent.h"
#include "AzureCircleMotorComponent.h"
#include "AzureParabolicMotorComponent.h"
#include "AzureMissileMotorComponent.h"
#include "AzureHelixMotorComponent.h"
#include "AzureCurvedMotorComponent.h"
#include "AzureLinkMotorComponent.h"
#include "SkeletalMeshRenderData.h"
#include "ImageUtils.h"
#include "ThreadJobForLua.h"
#include "SceneTypes.h"
#include "AssetRegistryModule.h"
#include "GameLogic/Player/GamePlayer.h"
#include "Kismet/KismetSystemLibrary.h"
#include "Kismet/KismetMathLibrary.h"
#include "GameLogic/Player/GamePlayerManager.h"
#include "GameLogic/Player/MyAnimInstance.h"
#include "AzureImage.h"
#include "GameLogic/Behavior/HPMoveBase.h"
#include "GameLogic/Player/MyMovementComponent.h"
#include "GameLogic/Behavior/HPJoystickMoveBehavior.h"
#include "GameLogic/PlantMine/InstancedObjManager.h"
#include "Classes/Materials/MaterialInstanceDynamic.h"
#include "PipelineFileCache.h"
#include "ShaderPipelineCache.h"
#include "GameLogic/Player/CarrierCharacter.h"
#include "GameLogic/Main/AzureWorldWrap.h"
#include "AutoMove/AutoMoveExport.h"
#include "Engine/LevelScriptBlueprint.h"
#include "Engine/Level.h"

#include "LandscapeInfo.h"
#include "Landscape.h"
#include "LandscapeInfoMap.h"
#include "LandscapeStreamingProxy.h"
#include "Stats/Stats.h"

#include "GameLogic/Player/GamePlayer_Util.h"
#include "GameLogic/AnimRelated/SkinnedAnimationUpdateRateSignificance.h"
#include "Kismet/KismetSystemLibrary.h"
#include "Kismet/KismetMathLibrary.h"
#if PLATFORM_IOS
#include "IOSAppDelegate.h"
#endif

#if PLATFORM_ANDROID
#include "Android/AndroidJNI.h"
#include "AndroidApplication.h"
#include <jni.h>
extern void AndroidThunkCpp_RestartApplication();
#endif


#if !PLATFORM_DESKTOP
#include "HAL/PlatformApplicationMisc.h"
#endif

DECLARE_CYCLE_STAT(TEXT("ParallelInstanceAFileImage"), STAT_ParallelInstanceAFileImage, STATGROUP_AzureGroups);
DECLARE_CYCLE_STAT(TEXT("ParallelInstanceUserWidgetInLua"), STAT_ParallelInstanceAFileImageInLua, STATGROUP_AzureGroups);

extern FPlatformAFileWrapper* GPlatformAFileWrapper;

extern int lua_GetCommandLineParam(lua_State * L);
extern int lua_HasCommandLineParam(lua_State * L);

class AzureStreamingFile : public AFile
{
	IFileHandle * file;
public:
	AzureStreamingFile() : file(nullptr) { }
	virtual ~AzureStreamingFile()
	{
		Close();
	}

	virtual bool Open(const char* szPath, ADWORD dwFlags)
	{
		file = GPlatformAFileWrapper->OpenRead(UTF8_TO_TCHAR(szPath));
		return !!file;
	}

	virtual bool Close()
	{
		if (file)
		{
			delete file;
			file = nullptr;
		}
		return true;
	}

	virtual bool Read(void* pBuffer, ADWORD dwBufferLength, ADWORD * pReadLength)
	{
		bool ret = file->Read((uint8*)pBuffer, dwBufferLength);
		if (ret)
			*pReadLength = dwBufferLength;
		else
			*pReadLength = 0;
		return ret;
	}

	virtual bool Write(const void* pBuffer, ADWORD dwBufferLength, ADWORD * pWriteLength)
	{
		assert(false);
		return false;
	}

	virtual bool ReadLine(char * szLineBuffer, ADWORD dwBufferLength, ADWORD * pdwReadLength)
	{
		assert(false);
		return false;
	}

	virtual bool ReadString(char * szLineBuffer, ADWORD dwBufferLength, ADWORD * pdwReadLength)
	{
		assert(false);
		return false;
	}

	virtual bool WriteLine(const char * szLineBuffer)
	{
		assert(false);
		return false;
	}

	virtual bool WriteString(const AString& str)
	{
		assert(false);
		return false;
	}

	virtual bool ReadString(AString& str)
	{
		assert(false);
		return false;
	}

	virtual ADWORD GetPos()
	{
		return (ADWORD)(file->Tell());
	}

	virtual bool Seek(int iOffset, AFILE_SEEK origin)
	{
		switch (origin)
		{
		case AFILE_SEEK_SET:
			return file->Seek(iOffset);
		case AFILE_SEEK_CUR:
			return file->Seek(file->Tell() + iOffset);
		default:
			return file->SeekFromEnd(iOffset);
		}
		return false;
	}

	virtual bool ResetPointer()
	{
		file->Seek(0);
		return true;
	}

	//	Get file length
	virtual ADWORD GetFileLength()
	{
		return (ADWORD)(file->Size());
	}

	bool IsValid() const
	{
		return !!file;
	}

};



AFile * AzureGetAFileStreaming(const char * szName)
{
	FString fileName = FPaths::ProjectContentDir() + UTF8_TO_TCHAR(szName);
	AFile * pAFile = new AzureStreamingFile();
	if (!pAFile->Open(TCHAR_TO_ANSI(*fileName), AFILE_BINARY | AFILE_OPENEXIST))
	{
		delete pAFile;
		pAFile = nullptr;
	}
	return pAFile;
}


namespace wLua
{
	namespace GameLuaInterface
	{
		static int SetNPC_SiegeInfo(lua_State * L)
		{			
			int n = 1;

			////////////////////
			AGamePlayer * obj = Cast<AGamePlayer>(wLua::FLuaUtils::GetUObject(L, n, "GamePlayer"));
			if (obj == nullptr)
			{
				lua_pushstring(L, "SetNPC_SiegeInfo: param must be GamePlayer!");
				lua_error(L);
				return 0;
			}
			++n;

			///////////
			if (!lua_isboolean(L, n))
			{
				lua_pushstring(L, "SetNPC_SiegeInfo: param must be bool(bSiege)");
				lua_error(L);
				return 0;
			}
			bool bSiege = !!lua_toboolean(L, n);
			++n;

			///////////
			if (lua_isstring(L, n) == false)
			{
				lua_pushstring(L, "SetNPC_SiegeInfo: param must be string(id)");
				lua_error(L);
				return 0;
			}

			FString str_id = UTF8_TO_TCHAR(lua_tostring(L, n));
			int64 id = FCString::Atoi64(*str_id);
			++n;

			///////////
			if (!lua_istable(L, n) && !lua_isuserdata(L,n))
			{
				lua_pushstring(L, "SetNPC_SiegeInfo: param must be vector3(destPos)");
				lua_error(L);
				return 0;
			}
			FVector vDest = FLuaVector::Get(L, n);
			vDest = POS_FROM_SERVER(vDest);
			++n;
			
			obj->SetSiegeInfo(bSiege, id, vDest);
			return 0;
		}

		static int SetNPC_StareInfo(lua_State * L)
		{
			int n = 1;

			////////////////////
			AGamePlayer * obj = Cast<AGamePlayer>(wLua::FLuaUtils::GetUObject(L, n, "GamePlayer"));
			if (obj == nullptr)
			{
				lua_pushstring(L, "SetNPC_StareInfo: param must be GamePlayer!");
				lua_error(L);
				return 0;
			}
			++n;

			///////////
			if (!lua_isboolean(L, n))
			{
				lua_pushstring(L, "SetNPC_StareInfo: param must be bool(bSiege)");
				lua_error(L);
				return 0;
			}
			bool bSiege = !!lua_toboolean(L, n);
			++n;

			///////////
			if (lua_isstring(L, n) == false)
			{
				lua_pushstring(L, "SetNPC_StareInfo: param must be string(id)");
				lua_error(L);
				return 0;
			}

			FString str_id = UTF8_TO_TCHAR(lua_tostring(L, n));
			int64 id = FCString::Atoi64(*str_id);
			++n;

			///////////
			if (!lua_istable(L, n) && !lua_isuserdata(L,n))
			{
				lua_pushstring(L, "SetNPC_StareInfo: param must be vector3(destPos)");
				lua_error(L);
				return 0;
			}
			FVector vDest = FLuaVector::Get(L, n);
			vDest = POS_FROM_SERVER(vDest);
			++n;

			obj->SetStareInfo(bSiege, id, vDest);
			return 0;
		}

		static int ReplaceAnim(lua_State * L)
		{
			int n = 1;

			////////////////////
			AGamePlayer * obj = Cast<AGamePlayer>(wLua::FLuaUtils::GetUObject(L, n, "GamePlayer"));
			if (obj == nullptr)
			{
				lua_pushstring(L, "ReplaceAnim: param must be GamePlayer!");
				lua_error(L);
				return 1;
			}
			++n;

			///////////
			if (lua_isstring(L, n) == false)
			{
				lua_pushstring(L, "ReplaceAnim: param must be string(machine name)");
				lua_error(L);
				return 1;
			}

			FString machine_name = UTF8_TO_TCHAR(lua_tostring(L, n));
			++n;

			///////////
			if (lua_isstring(L, n) == false)
			{
				lua_pushstring(L, "ReplaceAnim: param must be string(state name)");
				lua_error(L);
				return 1;
			}

			FString state_name = UTF8_TO_TCHAR(lua_tostring(L, n));
			++n;

			///////////////
			UAnimationAsset* anim_asset = Cast<UAnimationAsset>(wLua::FLuaUtils::GetUObject(L, n, "AnimationAsset"));
			if (!anim_asset)
			{
				lua_pushstring(L, "ReplaceAnim: anim_asset nil");
				LuaStatic::traceback(L);
				lua_error(L);
				return 1;
			}		

			bool hr = obj->ReplaceAnim(machine_name, state_name, anim_asset);
			lua_pushboolean(L, hr);
			return 1;
		}

		static int CreateDebugSphereActor(lua_State * L)
		{
			if (!AAzureEntryPoint::IsInit())
				return 0;

			UWorld* pWorld = AAzureEntryPoint::Instance->GetWorld();
			if (!pWorld)
			{
				return 0;
			}
			
			AStaticMeshActor* MeshActor = pWorld->SpawnActor<AStaticMeshActor>(AStaticMeshActor::StaticClass());
			UStaticMesh *StaticMesh = LoadObject<UStaticMesh>(nullptr, TEXT("/Engine/EngineMeshes/Sphere.Sphere"), nullptr, LOAD_None, nullptr);
			MeshActor->GetStaticMeshComponent()->SetMobility(EComponentMobility::Movable);
			MeshActor->GetStaticMeshComponent()->SetCollisionProfileName("NoCollision");
			MeshActor->GetStaticMeshComponent()->SetStaticMesh(StaticMesh);
			FLuaUtils::ReturnUObject(L, MeshActor);
			return 1;
		}

		static int CreateMotorComponent(lua_State * L)
		{
			int type = lua_tonumber(L, 1);
			if (type < 0 || type >= (int)MotorMoveMode::MMM_Count)
			{
				astring msg = astring("CreateMotorComponent: param 1 (MotorType) must be in range!");
				lua_pushstring(L, msg.c_str());
				lua_error(L);
				return 1;
			}

			wLua::LuaUObjectUserData* userdata = nullptr;
			AActor* obj = Cast<AActor>(wLua::FLuaUtils::GetUObject(L, 2, "Actor", &userdata));
			if (!obj)
			{
				astring msg = astring("CreateMotorComponent: param 2 must be Actor ");
				lua_pushstring(L, msg.c_str());
				lua_error(L);
				return 1;
			}

			UAzureMotorComponent* comp = nullptr;
			MotorMoveMode eType = (MotorMoveMode)type;
			switch (type)
			{
			case MotorMoveMode::MMM_LinearMove:
				comp = NewObject<UAzureLinearMotorComponent>(obj);
				break;
			case MotorMoveMode::MMM_ParabolicMove:
				comp = NewObject<UAzureParabolicMotorComponent>(obj);
				break;
			case MotorMoveMode::MMM_MissileMove:
				comp = NewObject<UAzureMissileMotorComponent>(obj);
				break;
			case MotorMoveMode::MMM_HelixMove:
				comp = NewObject<UAzureHelixMotorComponent>(obj);
				break;
			case MotorMoveMode::MMM_CurvedMove:
				comp = NewObject<UAzureCurvedMotorComponent>(obj);
				break;
			case MotorMoveMode::MMM_Link:
				comp = NewObject<UAzureLinkMotorComponent>(obj);
				break;
			case MotorMoveMode::MMM_Circle:
				comp = NewObject<UAzureCircleMotorComponent>(obj);
				break;
			default:
				break;
			}

			wLua::FLuaUtils::ReturnUObject(L, comp);
			return 1;
		}

		static int ShowDebugInfo(lua_State * L)
		{
			int n = 1;
			///////////
			if (!lua_isnumber(L, n))
			{
				lua_pushstring(L, "ShowDebugInfo: param must be number");
				lua_error(L);
				return 1;
			}
			int type = lua_tonumber(L, n);
			++n;

			///////////
			if (!lua_isboolean(L, n))
			{
				lua_pushstring(L, "ShowDebugInfo: param must be bool");
				lua_error(L);
				return 1;
			}
			bool bShow = !!lua_toboolean(L, n);
			++n;

			///////////
			if (!lua_isboolean(L, n))
			{
				lua_pushstring(L, "ShowDebugInfo: param must be bool");
				lua_error(L);
				return 1;
			}
			bool bShip = !!lua_toboolean(L, n);
			++n;

			gGamePlayerManager.ShowDebugInfo(type, bShow,bShip);

			return 0;
		}

		static int lua_GetImageBrushSize(lua_State * L)
		{
			int n = 1;

			////////////////////
			UImage * obj = Cast<UImage>(wLua::FLuaUtils::GetUObject(L, n, "Image"));
			if (obj == nullptr)
			{
				lua_pushstring(L, "GetImageBrushSize: param #1 must be Image!");
				lua_error(L);
				return 1;
			}
			++n;

			wLua::FLuaVector2D::Return(L, obj->Brush.ImageSize);
			return 1;
		}

		static int lua_SetAzureImageAutoSize(lua_State * L)
		{
			int n = 1;

			////////////////////
			UAzureImage * obj = Cast<UAzureImage>(wLua::FLuaUtils::GetUObject(L, n, "AzureImage"));
			if (obj == nullptr)
			{
				lua_pushstring(L, "SetAzureImageAutoSize: param #1 must be Image!");
				lua_error(L);
				return 1;
			}
			++n;

			///////////
			if (!lua_isboolean(L, n))
			{
				lua_pushstring(L, "GetImageBrushSize: param #2 must be bool");
				lua_error(L);
				return 0;
			}
			bool bAutoSize = !!lua_toboolean(L, n);
			++n;

			obj->bSizeToTarget = bAutoSize;
			return 0;
		}

		static int lua_RegisterHotKey(lua_State * L)
		{
			if (lua_istable(L, 1))
			{
				lua_pushvalue(L, 1);
				lua_pushnil(L);
				while (lua_next(L, -2))
				{
					const char* keyName = lua_tostring(L, -1);
					FString Name = UTF8_TO_TCHAR(keyName);
					FKey key(*Name);
					lua_pop(L, 1);

					AzureInputCtrl::GetInstance().RegisterKey(key);
				}
				lua_pop(L, 1);
			}
			else if (lua_isstring(L, 1))
			{
				const char* keyName = lua_tostring(L, 1);
				FString Name = UTF8_TO_TCHAR(keyName);
				FKey key(*Name);

				AzureInputCtrl::GetInstance().RegisterKey(key);
			}
			else
			{
				lua_pushstring(L, "RegisterHotKey: param #1 must be table or string");
				lua_error(L);
				return 0;
			}
			
			return 0;
		}

		static int lua_UnRegisterHotKey(lua_State * L)
		{
			if (lua_istable(L, 1))
			{
				lua_pushvalue(L, 1);
				lua_pushnil(L);
				while (lua_next(L, -2))
				{
					const char* keyName = lua_tostring(L, -1);
					FString Name = UTF8_TO_TCHAR(keyName);
					FKey key(*Name);
					lua_pop(L, 1);

					AzureInputCtrl::GetInstance().UnregisterKey(key);
				}
				lua_pop(L, 1);
			}
			else if (lua_isstring(L, 1))
			{
				const char* keyName = lua_tostring(L, 1);
				FString Name = UTF8_TO_TCHAR(keyName);
				FKey key(*Name);

				AzureInputCtrl::GetInstance().UnregisterKey(key);
			}
			else
			{
				lua_pushstring(L, "UnRegisterHotKey: param #1 must be table or string");
				lua_error(L);
				return 0;
			}

			return 0;
		}

		static int lua_UnRegisterAllKey(lua_State * L)
		{
			AzureInputCtrl::GetInstance().UnregisterAll();
			return 0;
		}

		
		static int GetGlobalParam(lua_State * L)
		{
			int n = 1;
			FString param_type = UTF8_TO_TCHAR(lua_tostring(L, n));
			++n;

			if (param_type == "JoyStickPress")
			{
				float px = AzureInputCtrl::GetInstance().GetJoystickX();
				float py = AzureInputCtrl::GetInstance().GetJoystickY();
				lua_pushnumber(L, px);
				lua_pushnumber(L, py);
				return 2;
			}

			return 0;
		}

		static int GetGamePlayerParam(lua_State * L)
		{
			int n = 1;

			AGamePlayer * obj = Cast<AGamePlayer>(wLua::FLuaUtils::GetUObject(L, n, "GamePlayer"));
			if (obj == nullptr)
			{
				lua_pushstring(L, "GetGamePlayerParam: param must be GamePlayer!");
				lua_error(L);
				return 1;
			}
			n++;

			/////
			if (lua_isstring(L, n) == false)
			{
				lua_pushstring(L, "GetGamePlayerParam: param must be string(param name)");
				lua_error(L);
				return 1;
			}

			FString param_type = UTF8_TO_TCHAR(lua_tostring(L, n));
			++n;

			if (param_type == "DashState")
			{
				bool hr = obj->IsInDashState();
				lua_pushboolean(L, hr);
				return 1;
			}
			else if (param_type == "IsFalling")
			{
				bool hr = obj->GetCharacterMovement()->IsFalling();
				lua_pushboolean(L, hr);
				return 1;
			}
			else if (param_type == "jump_run_limit")
			{
				float v = obj->jump_run_limit;
				lua_pushnumber(L, v);
				return 1;
			}
			else if (param_type == "HostPlayer_TeamFollow")
			{
				lua_pushboolean(L, obj->m_isHostFollowServerMove);
				return 1;
			}
			else if (param_type == "Role")
			{
				ENetRole r = obj->Role;
				lua_pushnumber(L, (int8)r);
				return 1;
			}
			else if (param_type == "TimerListID")
			{
				FString str;
				UAzureObjectComponent* comp = Cast<UAzureObjectComponent>(obj->GetComponentByClass(UAzureObjectComponent::StaticClass()));
				if (comp != nullptr && comp->GetTimerList() != nullptr)
					str = comp->GetTimerList()->GetTimerListIDs();

				lua_pushstring(L, TCHAR_TO_UTF8(*str));
				return 1;
			}
			else if (param_type == "IsInBehavior")
			{
				UAzureObjectComponent* comp = obj ? Cast<UAzureObjectComponent>(obj->GetComponentByClass(UAzureObjectComponent::StaticClass())) : nullptr;
				if (comp == nullptr)
				{
					LuaStatic::traceback(L);
					lua_error(L);
					return 1;
				}

				int beh_type = lua_tonumber(L, n);
				n++;

				AzureBehavior * beh = comp->GetBehavior((Azure::BehaviorType)beh_type);
				bool hr = (beh != nullptr);

				lua_pushboolean(L, hr);
				return 1;
			}

			lua_pushnil(L);
			return 1;
		}

		static int SetGamePlayerParam(lua_State * L)
		{
			int n = 1;

			AGamePlayer * obj = Cast<AGamePlayer>(wLua::FLuaUtils::GetUObject(L, n, "GamePlayer"));
			if (obj == nullptr)
			{
				lua_pushstring(L, "SetGamePlayerParam: param must be GamePlayer!");
				lua_error(L);
				return 1;
			}
			n++;

			/////
			if (lua_isstring(L, n) == false)
			{
				lua_pushstring(L, "SetGamePlayerParam: param must be string(state name)");
				lua_error(L);
				return 1;
			}

			FString param_type = UTF8_TO_TCHAR(lua_tostring(L, n));
			++n;

			//////
			if (param_type == "BattleState")
			{
				if (!lua_isboolean(L, n))
				{
					lua_pushstring(L, "SetGamePlayerParam: BattleState must be bool");
					lua_error(L);
					return 1;
				}
				bool b = !!lua_toboolean(L, n);
				++n;

				obj->SetBattleState(b);
			}
			else if (param_type == "MoveDebug")
			{
				if (!lua_isboolean(L, n))
				{
					lua_pushstring(L, "SetGamePlayerParam: MoveDebug must be bool");
					lua_error(L);
					return 1;
				}
				bool b = !!lua_toboolean(L, n);
				++n;

				obj->move_sync_debug = b;
				obj->turn_debug = b;
				obj->dodge_debug = b;
			}
			else if (param_type == "HostPlayer_FollowServerMove")
			{
				if (!lua_isboolean(L, n))
				{
					lua_pushstring(L, "SetGamePlayerParam: HostPlayer_TeamFollow must be bool");
					lua_error(L);
					return 1;
				}
				bool b = !!lua_toboolean(L, n);
				++n;

				obj->SetHostFollowServerMove(b);
			}
			else if (param_type == "HostPlayer_DirectDashMove")
			{
				obj->SetHostDirectDashMove();
			}
			else if (param_type == "HostPlayer_SetEnterDashType")
			{
				int32 _type = lua_tointeger(L, n);
				++n;

				if (_type == 1)//闪避进入
				{
					obj->m_bIsDashReady = true;
					obj->m_bIsDashReadyMoveInput = false;
				}
				else//摇杆键盘输入进入
				{
					obj->m_bIsDashReady = false;
					obj->m_bIsDashReadyMoveInput = true;
				}
			}
			else if (param_type == "GamePlayer_SetDashState")
			{
				if (!lua_isboolean(L, n))
				{
					lua_pushstring(L, "SetGamePlayerParam: SetDashState must be bool");
					lua_error(L);
					return 1;
				}
				bool b = !!lua_toboolean(L, n);
				++n;

				obj->SetDashState(b);
			}
			else if (param_type == "HostPlayer_RequestVelocity")
			{
				///////////
				if (!lua_istable(L, n) && !lua_isuserdata(L, n))
				{
					lua_pushstring(L, "HostPlayer_RequestVelocity: param must be vector3(velocity)");
					lua_error(L);
					return 0;
				}
				FVector velocity = FLuaVector::Get(L, n);
				++n;

				obj->GetCharacterMovement()->bRequestedMoveUseAcceleration = false;
				obj->GetCharacterMovement()->RequestDirectMove(velocity, false);
			}
			else if (param_type == "HostPlayer_SyncPos")
			{
				float use_time = lua_tonumber(L, n);
				++n;
				obj->SyncPushMoveToServer("LuaSyncPos", ESyncMoveSendType::LuaSyncPos, true,false, use_time);
			}
			else if (param_type == "HostPlayer_SyncHook")
			{
				float use_time = lua_tonumber(L, n);
				++n;
				obj->m_fSyncPushMoveTimer = use_time;
				obj->SyncPushMoveToServer("LuaSyncHook", ESyncMoveSendType::Hook, true, false, use_time);
			}
			else if (param_type == "SetName")
			{
				/////
				if (lua_isstring(L, n) == false)
				{
					lua_pushstring(L, "SetGamePlayerParam: param must be string(state name)");
					lua_error(L);
					return 1;
				}

				FString new_name = UTF8_TO_TCHAR(lua_tostring(L, n));
				++n;

				obj->Rename(*new_name);
			}
			else if (param_type == "GamePlayer_SetVelocity")
			{
				///////////
				if (!lua_istable(L, n) && !lua_isuserdata(L, n))
				{
					lua_pushstring(L, "GamePlayer_SetVelocity: param must be vector3(Velocity)");
					lua_error(L);
					return 0;
				}
				FVector velocity = FLuaVector::Get(L, n);
				++n;

				if (!lua_isboolean(L, n))
				{
					lua_pushstring(L, "GamePlayer_SetVelocity: param must be bool");
					lua_error(L);
					return 1;
				}
				bool bRemoveAcceleration = !!lua_toboolean(L, n);
				++n;

				obj->GetMyMovementComponent()->SetVelocity(velocity);
				if (bRemoveAcceleration)
					obj->SetInputVector(FVector::ZeroVector);
			}
			else if (param_type == "AnimBP_Param")
			{
				/////
				if (lua_isstring(L, n) == false)
				{
					lua_pushstring(L, "AnimBP_Param: param must be string(param name)");
					lua_error(L);
					return 1;
				}

				FString param_name = UTF8_TO_TCHAR(lua_tostring(L, n));
				++n;

				if (param_name == "prepare_jump")
				{
					if (!lua_isnumber(L, n))
					{
						lua_pushstring(L, "AnimBP_Param: prepare_jump must be bool");
						lua_error(L);
						return 1;
					}
					int32 i = lua_tointeger(L, n);
					++n;

					obj->SetPrepareJump(i);
				}
				else if (param_name == "jump_type")
				{
					if (!lua_isnumber(L, n))
					{
						lua_pushstring(L, "AnimBP_Param: jump_type must be integer");
						lua_error(L);
						return 1;
					}
					int32 i = lua_tointeger(L, n);
					++n;

					obj->SetJumpType(i);
				}
				else if (param_name == "block_type")
				{
					if (!lua_isnumber(L, n))
					{
						lua_pushstring(L, "AnimBP_Param: block_type must be integer");
						lua_error(L);
						return 1;
					}
					int32 i = lua_tointeger(L, n);
					++n;

					obj->SetBlockType(i);
				}
				else if (param_name == "MovementDirection")
				{
					if (!lua_istable(L, n) && !lua_isuserdata(L, n))
					{
						lua_pushstring(L, "AnimBP_Param: param must be vector3");
						lua_error(L);
						return 0;
					}
					FVector direction = FLuaVector::Get(L, n);
					++n;

					obj->SetMovementDirection(direction);
				}
				else if (param_name == "CarryType")
				{
					if (!lua_isnumber(L, n))
					{
						lua_pushstring(L, "AnimBP_Param: IsCarrying must be number");
						lua_error(L);
						return 1;
					}
					int carryType = lua_tointeger(L, n);
					++n;

					obj->SetCarryType(carryType);
				}

			}
			else if (param_type == "NPCBlendSpaceInterTime")
			{
				if (!lua_isnumber(L, n))
				{
					lua_pushstring(L, "NPCBlendSpaceInterTime: param must be number");
					lua_error(L);
					return 1;
				}

				float t = lua_tonumber(L, n);
				++n;

				if (t > 0.0f)
					obj->blendspace_inter_time = t;
			}
			else if (param_type == "Host_SetMaxSpeed")
			{
				if (!lua_isnumber(L, n))
				{
					lua_pushstring(L, "Host_SetMaxSpeed: param 1 must be number");
					lua_error(L);
					return 1;
				}

				float runSpeed = lua_tonumber(L, n);
				++n;

				if (!lua_isnumber(L, n))
				{
					lua_pushstring(L, "Host_SetMaxSpeed: param 2 must be number");
					lua_error(L);
					return 1;
				}

				float dashSpeed = lua_tonumber(L, n);
				++n;

				if (runSpeed > 0.0f)
					obj->m_run_speed = runSpeed;

				if (dashSpeed > 0.0f)
					obj->m_dash_speed = dashSpeed;

				obj->OnHostSpeedChange();
			}
			else if (param_type == "jump_run_limit")
			{
				if (!lua_isnumber(L, n))
				{
					lua_pushstring(L, "jump_run_limit: param must be number");
					lua_error(L);
					return 1;
				}

				float value = lua_tonumber(L, n);
				++n;

				if (value > 0.0f)
					obj->SetJumpRunLimit(value);
			}
			else if (param_type == "BP_SetValue")
			{
				if (lua_isstring(L, n) == false)
				{
					lua_pushstring(L, "BP_SetValue: param must be string(param type)");
					lua_error(L);
					return 1;
				}

				FString paramtype = UTF8_TO_TCHAR(lua_tostring(L, n));
				++n;

				if (lua_isstring(L, n) == false)
				{
					lua_pushstring(L, "BP_SetValue: param must be string(param name)");
					lua_error(L);
					return 1;
				}

				FString param_name = UTF8_TO_TCHAR(lua_tostring(L, n));
				++n;

				if (paramtype == "float")
				{
					if (!lua_isnumber(L, n))
					{
						lua_pushstring(L, "BP_SetValue: param must be number");
						lua_error(L);
						return 1;
					}

					float value = lua_tonumber(L, n);
					++n;

					UKismetSystemLibrary::SetFloatPropertyByName((UObject*)obj, *param_name, value);
				}					
				else if (paramtype == "int")
				{
					if (!lua_isnumber(L, n))
					{
						lua_pushstring(L, "BP_SetValue: param must be int");
						lua_error(L);
						return 1;
					}

					int value = lua_tointeger(L, n);
					++n;

					UKismetSystemLibrary::SetIntPropertyByName((UObject*)obj, *param_name, value);
				}
				else if (paramtype == "bool")
				{
					if (!lua_isboolean(L, n))
					{
						lua_pushstring(L, "BP_SetValue: param must be bool");
						lua_error(L);
						return 1;
					}
					bool b = !!lua_toboolean(L, n);
					++n;

					UKismetSystemLibrary::SetBoolPropertyByName((UObject*)obj, *param_name, b);
				}
			}
			else if (param_type == "AddPostProcessMaterial")
			{
				if (lua_isstring(L, n) == false)
				{
					lua_pushstring(L, "AddPostProcessMaterial: param must be string(mat_type)");
					lua_error(L);
					return 1;
				}

				FString mat_type = UTF8_TO_TCHAR(lua_tostring(L, n));
				++n;

				UObject* asset = wLua::FLuaUtils::GetUObject(L, n, "MaterialInterface");
				UMaterialInterface* mat = obj ? Cast<UMaterialInterface>(asset) : nullptr;
				if (!mat)
				{
					lua_pushstring(L, "AddPostProcessMaterial: param 1 must be MaterialInstance!");
					lua_error(L);
					return 1;
				}
				++n;

				float fWeight = (float)luaL_checknumber(L, n);
				++n;

				if (mat_type == "RadialBlur")
				{
					if (obj)
						obj->AddPostProcessMaterial_RadialBlur(mat, fWeight);
				}
			}
			else if (param_type == "RemoveProcessMaterial")
			{
				if (lua_isstring(L, n) == false)
				{
					lua_pushstring(L, "RemoveProcessMaterial: param must be string(mat_type)");
					lua_error(L);
					return 1;
				}

				FString mat_type = UTF8_TO_TCHAR(lua_tostring(L, n));
				++n;

				UObject* asset = wLua::FLuaUtils::GetUObject(L, n, "MaterialInterface");
				UMaterialInterface* mat = obj ? Cast<UMaterialInterface>(asset) : nullptr;
				if (!mat)
				{
					lua_pushstring(L, "AddPostProcessMaterial: param 1 must be MaterialInstance!");
					lua_error(L);
					return 1;
				}
				++n;

				if (obj)
					obj->RemoveProcessMaterial(mat, mat_type);
			}	

			if (param_type == "NeedCheckMoveBlock")
			{
				if (!lua_isboolean(L, n))
				{
					lua_pushstring(L, "BP_SetValue: param must be bool");
					lua_error(L);
					return 1;
				}
				bool b = !!lua_toboolean(L, n);
				++n;

				if (obj)
					obj->m_NeedCheckMoveBlock = b;
			}
			else if (param_type == "TakeFarWeapon")
			{
				if (!lua_isboolean(L, n))
				{
					lua_pushstring(L, "TakeFarWeapon: param must be bool");
					lua_error(L);
					return 1;
				}
				bool b = !!lua_toboolean(L, n);
				++n;

				if (obj)
					obj->SetIsTakeFarWeapon(b);
			}

			if (param_type == "AutoMove")
			{
				if (!lua_isboolean(L, n))
				{
					lua_pushstring(L, "AutoMove: param must be bool");
					lua_error(L);
					return 1;
				}
				bool b = !!lua_toboolean(L, n);
				++n;

				if (obj)
					obj->SetAutoMove(b);
			}
			else if (param_type == "HostPlayer_VehiclePosType")
			{
				if (!lua_isnumber(L, n)) {
					lua_pushstring(L, "HostPlayer_VehiclePosType: param must be int");
					lua_error(L);
					return 1;
				}
				int type = lua_tointeger(L, n);
				++n;

				if (obj)
					obj->SetVehiclePosType(type);
			}
			else if (param_type == "SetReceiveInputWhenJump")
			{
				if (!lua_isboolean(L, n))
				{
					lua_pushstring(L, "SetReceiveInputWhenJump: param must be bool");
					lua_error(L);
					return 1;
				}
				bool b = !!lua_toboolean(L, n);
				++n;

				if (obj)
					obj->SetReceiveInputWhenJump(b);
			}
			if (param_type == "AimOffsetType")
			{
				if (!lua_isnumber(L, n)) {
					lua_pushstring(L, "AimOffsetType: param must be int");
					lua_error(L);
					return 1;
				}
				int type = lua_tointeger(L, n);
				++n;

				if (obj)
					obj->SetAimOffsetType(type);
			}

			return 0;
		}

		static int SetGamePlayerParam2(lua_State * L)
		{
			int n = 1;

			AGamePlayer * obj = Cast<AGamePlayer>(wLua::FLuaUtils::GetUObject(L, n, "GamePlayer"));
			if (obj == nullptr)
			{
				lua_pushstring(L, "SetGamePlayerParam2: param must be GamePlayer!");
				lua_error(L);
				return 1;
			}
			n++;

			/////
			if (lua_isstring(L, n) == false)
			{
				lua_pushstring(L, "SetGamePlayerParam2: param must be string(state name)");
				lua_error(L);
				return 1;
			}

			FString param_type = UTF8_TO_TCHAR(lua_tostring(L, n));
			++n;

			//////
			if (param_type == "Dash_Rot")
			{
				if (!lua_isboolean(L, n))
				{
					lua_pushstring(L, "Dash_Rot: param must be bool");
					lua_error(L);
					return 1;
				}
				bool b = !!lua_toboolean(L, n);
				++n;

				if (obj)
					obj->m_bIsDashUseControlDir = b;
			}
			else if (param_type == "StopDash")
			{
				UAzureObjectComponent* comp = obj ? Cast<UAzureObjectComponent>(obj->GetComponentByClass(UAzureObjectComponent::StaticClass())) : nullptr;
				if (comp == nullptr)
				{
					LuaStatic::traceback(L);
					lua_error(L);
					return 1;
				}

				HPJoystickMoveBehavior* beh = (HPJoystickMoveBehavior*)comp->GetBehavior(Azure::BehaviorType::HPJoystickMove);
				if (beh)
					beh->StopDash();
			}
			else if (param_type == "StopDashDirect")
			{
				if (obj)
					obj->StopDashDirect();
			}
			else if (param_type == "SummonPeopleWait")
			{
				if (!lua_isboolean(L, n))
				{
					lua_pushstring(L, "Dash_Rot: param must be bool");
					lua_error(L);
					return 1;
				}
				bool b = !!lua_toboolean(L, n);
				++n;

				if (obj)
					obj->SetSummonPeopleWait(b);
			}
			else if (param_type == "IsHostPlayer")
			{
				bool b = lua_toboolean(L, n) != 0;
				UAzureObjectComponent* comp = Cast<UAzureObjectComponent>(obj->GetComponentByClass(UAzureObjectComponent::StaticClass()));
				if (comp != nullptr)
					comp->SetIsHostPlayer(b);
			}
			else if (param_type == "AimWalkOffsetAngle")
			{
				if (obj)
				{
					if (!lua_isnumber(L, n))
					{
						lua_pushstring(L, "AimWalkOffsetAngle: param1 must be float");
						lua_error(L);
						return 1;
					}
					float value = lua_tonumber(L, n);
					++n;
					obj->SetAimYawFromAnim(value);
				}
			}
			else if (param_type == "AimHandToSplineDisXY")
			{
				if (obj)
				{
					if (!lua_isnumber(L, n))
					{
						lua_pushstring(L, "AimHandToSplineDisXY: param1 must be float");
						lua_error(L);
						return 1;
					}
					float value = lua_tonumber(L, n);
					++n;
					obj->SetAimHandToSplineDisXY(value);
				}
			}
			else if (param_type == "AimHandToSplineDisZ")
			{
				if (obj)
				{
					if (!lua_isnumber(L, n))
					{
						lua_pushstring(L, "AimHandToSplineDisZ: param1 must be float");
						lua_error(L);
						return 1;
					}
					float value = lua_tonumber(L, n);
					++n;
					obj->SetAimHandToSplineDisZ(value);
				}
			}
			else if (param_type == "AimLeftRightOffset")
			{
				if (obj)
				{
					if (!lua_isnumber(L, n))
					{
						lua_pushstring(L, "AimLeftRightOffset: param1 must be float");
						lua_error(L);
						return 1;
					}
					float value = lua_tonumber(L, n);
					++n;
					obj->SetAimLeftRightOffset(value);
				}
			}
			else if (param_type == "AimLeftHand")
			{
				if (!lua_isboolean(L, n))
				{
					lua_pushstring(L, "AimLeftHand: param must be bool");
					lua_error(L);
					return 1;
				}
				bool b = !!lua_toboolean(L, n);
				++n;

				if (obj)
					obj->SetAimLeftHand(b);
			}
			else if (param_type == "AimPitch")
			{
				if (!lua_isnumber(L, n))
				{
					lua_pushstring(L, "AimPitch: param must be float");
					lua_error(L);
					return 1;
				}

				if (obj)
				{
					float value = lua_tonumber(L, n);
					++n;
					obj->aim_pitch = value;
				}
			}
			else if (param_type == "AimEnableIK")
			{
				if (!lua_isboolean(L, n))
				{
					lua_pushstring(L, "AimEnableIK: param must be bool");
					lua_error(L);
					return 1;
				}
				bool b = !!lua_toboolean(L, n);
				++n;

				if (obj)
					obj->SetAimEnableIK(b);
			}
			else if (param_type == "CameraMode")
			{
				if (!lua_isnumber(L, n))
				{
					lua_pushstring(L, "CameraMode: param must be number");
					lua_error(L);
					return 1;
				}

				if (obj)
				{
					int value = lua_tointeger(L, n);
					++n;
					obj->m_cameraMode = (EGamePlayerCameraType)value;
				}
			}
			else if (param_type == "EnableFootIK")
			{
				if (!lua_isboolean(L, n))
				{
					lua_pushstring(L, "EnableFootIK: param must be bool");
					lua_error(L);
					return 1;
				}
				bool b = !!lua_toboolean(L, n);
				++n;

				if (obj)
					obj->enableFootIK = b;
			}
			else if (param_type == "WaitEnterDash")
			{
				if (!lua_isboolean(L, n))
				{
					lua_pushstring(L, "WaitEnterDash: param must be bool");
					lua_error(L);
					return 1;
				}
				bool b = !!lua_toboolean(L, n);
				++n;

				if (obj)
					obj->m_isWaitEnterDash = b;
			}
			else if (param_type == "AimWalkFrontBackLimitValue")
			{
				if (obj)
				{
					if (!lua_isnumber(L, n))
					{
						lua_pushstring(L, "AimWalkFrontBackLimitValue: param must be float");
						lua_error(L);
						return 1;
					}
					float value = lua_tonumber(L, n);
					++n;
					obj->aim_walk_front_v1 = value;

					if (!lua_isnumber(L, n))
					{
						lua_pushstring(L, "AimWalkFrontBackLimitValue: param must be float");
						lua_error(L);
						return 1;
					}
					value = lua_tonumber(L, n);
					++n;
					obj->aim_walk_front_v2 = value;

					if (!lua_isnumber(L, n))
					{
						lua_pushstring(L, "AimWalkFrontBackLimitValue: param must be float");
						lua_error(L);
						return 1;
					}
					value = lua_tonumber(L, n);
					++n;
					obj->aim_walk_back_v1 = value;

					if (!lua_isnumber(L, n))
					{
						lua_pushstring(L, "AimWalkFrontBackLimitValue: param must be float");
						lua_error(L);
						return 1;
					}
					value = lua_tonumber(L, n);
					++n;
					obj->aim_walk_back_v2 = value;
				}
			}

			if (param_type == "StopShaChe")
			{
				if (obj)
					obj->EndPlayStopAnim();
			}
			else if (param_type == "NPC_Reset_Mesh")
			{
				if (!lua_isboolean(L, n))
				{
					lua_pushstring(L, "NPC_Reset_Mesh: param must be bool");
					lua_error(L);
					return 1;
				}
				bool b = !!lua_toboolean(L, n);
				++n;	

				if (!lua_isnumber(L, n))
				{
					lua_pushstring(L, "NPC_Reset_Mesh: param must be float");
					lua_error(L);
					return 1;
				}
				float angle = lua_tonumber(L, n);
				++n;

				if (obj)
				{					
					obj->SetNPCAimRootRotationForAnim(b,angle);
				}
							
			}
			else if (param_type == "EnableDefaultWalk")
			{
				if (!lua_isboolean(L, n))
				{
					lua_pushstring(L, "NPC_Reset_Mesh: param must be bool");
					lua_error(L);
					return 1;
				}
				bool b = !!lua_toboolean(L, n);
				++n;

				if (obj)
					obj->m_isDefaultWalk = b;
			}
			else if (param_type == "Tool_Type")
			{
				if (!lua_isnumber(L, n))
				{
					lua_pushstring(L, "NPC_Reset_Mesh: param must be float");
					lua_error(L);
					return 1;
				}

				int tool_anim_type = lua_tointeger(L, n);
				++n;

				if (obj)
				{
					obj->SetToolAnimType(tool_anim_type);
				}
			}
			else if (param_type == "Carrier_Set")
			{
				AGamePlayer * newCarrier = Cast<AGamePlayer>(wLua::FLuaUtils::GetUObject(L, n, "GamePlayer"));
				n++;
				obj->SetCarrierDirect(newCarrier);
			}
			else if (param_type == "swim_in_water_height")
			{
				float f = (float)luaL_checknumber(L, n);
				obj->m_swim_in_water_height = f;
				n++;
			}
			else if (param_type == "special_aimoffset_type")
			{
				int vtype = (float)luaL_checknumber(L, n);
				obj->SetSpecialAimOffsetType(vtype);
				n++;
			}
			else if (param_type == "IsLoadingScene") {
				if (!lua_isboolean(L, n)){
					lua_pushstring(L, "IsLoadingScene: param must be bool");
					lua_error(L);
					return 1;
				}
				bool b = !!lua_toboolean(L, n);
				++n;

				if (obj) {
					obj->m_isLoadingScene = b;
				}
			}
			else if (param_type == "Tid")
			{
				if (!lua_isnumber(L, n))
				{
					lua_pushstring(L, "Tid: param must be int");
					lua_error(L);
					return 1;
				}

				int tid = lua_tointeger(L, n);
				obj->m_tid = tid;

				n++;
			}

			if (param_type == "force_move")
			{
				if (!lua_isboolean(L, n))
				{
					lua_pushstring(L, "force_move: param must be bool");
					lua_error(L);
					return 1;
				}
				bool b = !!lua_toboolean(L, n);
				++n;

				if (obj)
					obj->SetForceMove(b);
			}
			else if (param_type == "force_move_stop")
			{
				if (obj)
					obj->StopForceMove();
			}
			else if (param_type == "force_move_speed")
			{
				float speed = (float)luaL_checknumber(L, n);
				speed *= UE_METRE_TRANS;
				n++;

				if (obj)
					obj->ChangeForceMoveSpeed(speed);
			}
			else if (param_type == "force_move_param")
			{
				float rotSpeed = (float)luaL_checknumber(L, n);
				n++;

				float rotSpeed2 = (float)luaL_checknumber(L, n);
				n++;

				float limitDis = (float)luaL_checknumber(L, n);
				n++;

				float turnMaxAngle = (float)luaL_checknumber(L, n);
				n++;
				
				if (obj)
				{
					obj->m_forceMoveRotSpeed = rotSpeed;
					obj->m_forceMoveAngleScale = rotSpeed2;
					obj->m_forceMoveLimitDis = limitDis;
					obj->m_forceMoveTurnMaxAngle = turnMaxAngle;
				}
			}
			else if (param_type == "bounce_scale")
			{
				float scale = (float)luaL_checknumber(L, n);
				n++;

				float z_speed_limit = (float)luaL_checknumber(L, n);
				n++;

				if (obj)
				{
					if(scale >= 0.0f)
						obj->m_bounce_scale = scale;

					if (z_speed_limit >= 0.0f)
						obj->m_bounce_speed_limit = z_speed_limit;
				}					
			}
			else if (param_type == "EnableSwim")
			{
				if (!lua_isboolean(L, n))
				{
					lua_pushstring(L, "EnableSwim: param must be bool");
					lua_error(L);
					return 1;
				}
				bool b = !!lua_toboolean(L, n);
				++n;

				if (obj)
				{
					UCharacterMovementComponent* movementCom = obj->GetCharacterMovement();
					if (movementCom)
					{
						movementCom->NavAgentProps.bCanSwim = b;
					}
				}
			}
			else if (param_type == "elsePlayer_DealGravity_notInMove")
			{
				if (!lua_isboolean(L, n))
				{
					lua_pushstring(L, "EnableSwim: param must be bool");
					lua_error(L);
					return 1;
				}
				bool b = !!lua_toboolean(L, n);
				++n;

				if (obj)
					obj->m_canElsePlayerDealGravity_notInMove = b;
			}
			else if (param_type == "transform_type")
			{
				int vtype = (float)luaL_checknumber(L, n);
				obj->m_transform_type = vtype;
				n++;
			}

			return 0;
		}

		static int CheckPosInWater(lua_State * L)
		{
			int n = 1;

			if (!lua_isnumber(L, n))
			{
				lua_pushstring(L, "CheckPosInWater: param 1 must be number");
				lua_error(L);
				return 1;
			}

			float x = lua_tonumber(L, n);
			++n;


			if (!lua_isnumber(L, n))
			{
				lua_pushstring(L, "CheckPosInWater: param 2 must be number");
				lua_error(L);
				return 1;
			}

			float y = lua_tonumber(L, n);
			++n;

			if (!lua_isnumber(L, n))
			{
				lua_pushstring(L, "CheckPosInWater: param 3 must be number");
				lua_error(L);
				return 1;
			}

			float z = lua_tonumber(L, n);
			++n;

			FVector uePos(x,y,z);
			bool isInWater = AzureUtility::CheckIsInWater(uePos);
			lua_pushboolean(L, isInWater);
			return 1;
		}

		static int CheckPosInWaterMap(lua_State * L)
		{
			int n = 1;

			if (!lua_isnumber(L, n))
			{
				lua_pushstring(L, "CheckPosInWaterMap: param 1 must be number");
				lua_error(L);
				return 1;
			}

			float x = lua_tonumber(L, n);
			++n;


			if (!lua_isnumber(L, n))
			{
				lua_pushstring(L, "CheckPosInWaterMap: param 2 must be number");
				lua_error(L);
				return 1;
			}

			float y = lua_tonumber(L, n);
			++n;

			AzureWorldWrap::Instance().WrapPosition(x, y);
			bool isInWaterMap = exp_GetPixel_Water(x, y);
			lua_pushboolean(L, isInWaterMap);
			return 1;
		}

		//向 8 个方向检查
		FVector2D FindNearestWaterEdge_detectDirections[] =
		{
			{1.0f, 0.0f}, {0.707f, 0.707f}, {0.0f, 1.0f}, {-0.707f, 0.707f},
			{-1.0f, 0.0f}, {-0.707f, -0.707f}, {0.0f, -1.0f}, {0.707f, -0.707f},
		};

		//(估算)最近的水边界, param 1: 找水或非水(true 找水, false 找非水)，param 1: x, param 2: z, param 3 最大距离, param 4: 检查步长 (默认为 4)
		//return 1: 是否找到边界, return 2: 距离, return 3: x, return 4: z
		static int FindNearestWaterEdge(lua_State * L)
		{
			bool findType = lua_toboolean(L, 1);
			float centerX = luaL_checknumber(L, 2);
			float centerZ = luaL_checknumber(L, 3);
			float maxDistance = luaL_checknumber(L, 4);
			float checkStepLength = luaL_optnumber(L, 5, 4.0f);
			int checkSteps = (int)ceilf(maxDistance / checkStepLength);

			for (int iStep=0; iStep<checkSteps; ++iStep)
			{
				for (int iDirection=0; iDirection<sizeof(FindNearestWaterEdge_detectDirections)/sizeof(FindNearestWaterEdge_detectDirections[0]); ++iDirection)
				{
					float distance = checkStepLength * (iStep+1);
					float x = centerX + FindNearestWaterEdge_detectDirections[iDirection].X * distance;
					float z = centerZ + FindNearestWaterEdge_detectDirections[iDirection].Y * distance;
					float xWrapped = x;
					float zWrapped = z;
					AzureWorldWrap::Instance().WrapPosition(xWrapped, zWrapped);
					if (exp_GetPixel_Water(xWrapped, zWrapped) == findType)
					{
						lua_pushboolean(L, true);
						lua_pushnumber(L, distance);
						lua_pushnumber(L, x);
						lua_pushnumber(L, z);
						return 4;
					}
				}
			}

			//未找到
			lua_pushboolean(L, false);
			return 1;
		}

		int32 CallPanelEvent(lua_State * L)
		{
			UObject* Obj = wLua::FLuaUtils::GetUObject(L, 1, "UserWidget");
			UUserWidget * ui = Cast<UUserWidget>(Obj);

			if (!ui)
			{
				wLua::LuaStatic::traceback(L, "CallDlgEvent #1 must be a UserWidget");
				lua_error(L);
				return 1;
			}

			if (!lua_isstring(L, 2))
			{
				lua_pushstring(L, "CallDlgEvent: param #2 must be string");
				lua_error(L);
				return 1;
			}
			const char* str = lua_tostring(L, 2);
			FString event_name = UTF8_TO_TCHAR(str);

			UFunction* Function = ui->FindFunctionChecked(*event_name);
			if (Function)
				ui->ProcessEvent(Function, NULL);

			return 0;
		}

		int32 CallObjectEvent(lua_State * L)
		{
			UObject* Obj = wLua::FLuaUtils::GetUObject(L, 1, "UObject");

			
			if (!lua_isstring(L, 2))
			{
				lua_pushstring(L, "CallDlgEvent: param #2 must be string");
				lua_error(L);
				return 1;
			}
			const char* str = lua_tostring(L, 2);
			FString event_name = UTF8_TO_TCHAR(str);

			UFunction* Function = Obj->FindFunctionChecked(*event_name);
			if (Function)
				Obj->ProcessEvent(Function, NULL);

			return 0;
		}

	
		int lua_SetMapWarnings(lua_State * L)
		{
			bool bValue = lua_toboolean(L, 1);
			if (GEngine) {
				GEngine->bSuppressMapWarnings = bValue ? 0 : 1;
			}
			return 0;
		}

		static int SetGlobalParam(lua_State * L)
		{
			int n = 1;

			/////
			if (lua_isstring(L, n) == false)
			{
				lua_pushstring(L, "SetGlobalParam: param must be string(state name)");
				lua_error(L);
				return 1;
			}

			FString param_type = UTF8_TO_TCHAR(lua_tostring(L, n));
			++n;

			//////
			if (param_type == "JumpSendRate")
			{
				if (!lua_isnumber(L, n))
				{
					lua_pushstring(L, "JumpSendRate: param must be number");
					lua_error(L);
					return 1;
				}
				float rate = lua_tonumber(L, n);
				++n;

				if(rate > 0.0f)
					Azure::host_jump_sync_interval = rate;
			}
			else if (param_type == "InputAxisMaxValue")
			{
				if (!lua_isnumber(L, n))
				{
					lua_pushstring(L, "InputAxisMaxValue: param must be number");
					lua_error(L);
					return 1;
				}
				float v = lua_tonumber(L, n);
				++n;

				if (v > 0.0f)
					Azure::s_inputAxisMaxValue = v;
			}
			else if (param_type == "MoveRightTurnControllYawScale")
			{
				if (!lua_isnumber(L, n))
				{
					lua_pushstring(L, "MoveRightTurnControllYawScale: param must be number");
					lua_error(L);
					return 1;
				}
				float v = lua_tonumber(L, n);
				++n;

				Azure::s_moveRightTurnControllYawScale = v;
			}
			else if (param_type == "NPC_LookAt")
			{
				float value = lua_tonumber(L, n);
				++n;
				Azure::npc_lookat_angle_stop = value;

				value = lua_tonumber(L, n);
				++n;
				Azure::npc_lookat_return_origin_time = value;

				value = lua_tonumber(L, n);
				++n;
				Azure::npc_lookat_near_dis = value;

				value = lua_tonumber(L, n);
				++n;
				Azure::npc_lookat_near_angle = value;

				value = lua_tonumber(L, n);
				++n;
				Azure::npc_lookat_dis_delta = value;

				value = lua_tonumber(L, n);
				++n;
				Azure::npc_lookat_angle_delta = value;
			}
			else if (param_type == "Host_LookAt_NPC")
			{
				float value = lua_tonumber(L, n);
				++n;
				Azure::host_lookat_npc_dis_limit = value;

				value = lua_tonumber(L, n);
				++n;
				Azure::host_lookat_npc_angle_limit = value;
			}
			else if (param_type == "Swim")
			{
				float value = lua_tonumber(L, n);
				++n;
				Azure::trace_water_up_dis = value;

				value = lua_tonumber(L, n);
				++n;
				Azure::trace_water_dis = value;

				value = lua_tonumber(L, n);
				++n;
				Azure::trace_water_max_dis = value;
			}
			else if (param_type == "SeaTraceDist")
			{
				float value = lua_tonumber(L, n);
				++n;
				Azure::trace_sea_dis = value;
			}
			else if (param_type == "MoveRightNotTurn")
			{
				bool b = !!lua_toboolean(L, n);
				++n;

				Azure::s_moveRightNotTurn = b;
			}
			else if (param_type == "PlayerMoveLog")
			{
				bool b = !!lua_toboolean(L, n);
				++n;

				Azure::b_player_move_show = b;
			}
			else if (param_type == "BezierShow")
			{
				bool b = !!lua_toboolean(L, n);
				++n;

				gGamePlayerManager.debug_bezier = b;
				gGamePlayerManager.debug_move = b;
			}
			else if (param_type == "camdebug")
			{
				bool b = !!lua_toboolean(L, n);
				++n;

				Azure::print_camera_debug = b;
			}
			else if (param_type == "ai_move_interval")
			{
				float f = lua_tonumber(L, n);
				++n;

				Azure::ai_move_interval = f;
			}
			else if (param_type == "aim_bp_value")
			{
				float f = lua_tonumber(L, n);
				++n;
				Azure::aim_pitch_anim_angle = f;

				f = lua_tonumber(L, n);
				++n;
				Azure::aim_factor_blend_time = f;
			}
			else if (param_type == "facetarget_delay")
			{
				float f = lua_tonumber(L, n);
				++n;
				Azure::facetarget_delay = f;
			}

			if (param_type == "ArmAlphaStr")
			{
				const char* str = lua_tostring(L, n);
				FString fstr = UTF8_TO_TCHAR(str);
				++n;
				Azure::ArmAlphaStr = fstr;
			}
			else if (param_type == "bp_bodyturn")
			{
				float f = lua_tonumber(L, n);
				++n;
				Azure::bodyTurnMinAngle = f;

				f = lua_tonumber(L, n);
				++n;
				Azure::bodyTurnLimitAngle = f;
			}
			else if (param_type == "bp_lean")
			{
				float f = lua_tonumber(L, n);
				++n;
				Azure::leanAdjustAngle = f;

				f = lua_tonumber(L, n);
				++n;
				Azure::leanSpeedGait_1 = f;

				f = lua_tonumber(L, n);
				++n;
				Azure::leanAnimAngle = f;
			}
			else if (param_type == "bp_blockforward")
			{
				float f = lua_tonumber(L, n);
				++n;
				Azure::blockforward_angle = f;

				f = lua_tonumber(L, n);
				++n;
				Azure::blockbackward_angle = f;
			}
			else if (param_type == "tag_update_aim")
			{
				const char* str = lua_tostring(L, n);
				FString fstr = UTF8_TO_TCHAR(str);
				++n;
				Azure::tag_update_aim = fstr;
			}
			else if (param_type == "JoystickPressSendInterval")
			{
				float f = lua_tonumber(L, n);
				++n;
				Azure::JoystickPressSendInterval = f;
			}
			else if (param_type == "start_move_key_time")
			{
				float f = lua_tonumber(L, n);
				++n;
				Azure::start_move_key_time = f;
			}
			else if (param_type == "cam_locktarget_follow_target_only")
			{
				bool b = !!lua_toboolean(L, n);
				++n;

				Azure::cam_locktarget_follow_target_only = b;
			}
			else if (param_type == "cam_protect")
			{
				const char* str = lua_tostring(L, n);
				FString fstr = UTF8_TO_TCHAR(str);
				++n;
				Azure::CamProtectBoneName1 = fstr;

				str = lua_tostring(L, n);
				fstr = UTF8_TO_TCHAR(str);
				++n;
				Azure::CamProtectBoneName2 = fstr;

				float f = lua_tonumber(L, n);
				++n;
				Azure::CamProtect_AngleIn = f;

				f = lua_tonumber(L, n);
				++n;
				Azure::CamProtect_AngleOut = f;

				str = lua_tostring(L, n);
				fstr = UTF8_TO_TCHAR(str);
				++n;
				Azure::CamProtectMatParamName1 = fstr;

				str = lua_tostring(L, n);
				fstr = UTF8_TO_TCHAR(str);
				++n;
				Azure::CamProtectMatParamName2 = fstr;

				str = lua_tostring(L, n);
				fstr = UTF8_TO_TCHAR(str);
				++n;
				Azure::CamProtectMatParamName3 = fstr;

				f = lua_tonumber(L, n);
				++n;
				Azure::CamProtect_Param1_Min = f;

				f = lua_tonumber(L, n);
				++n;
				Azure::CamProtect_Param1_Max = f;

				f = lua_tonumber(L, n);
				++n;
				Azure::CamProtect_Param2_Min = f;

				f = lua_tonumber(L, n);
				++n;
				Azure::CamProtect_Param2_Max = f;

				f = lua_tonumber(L, n);
				++n;
				Azure::CamProtect_Param3_Min = f;

				f = lua_tonumber(L, n);
				++n;
				Azure::CamProtect_Param3_Max = f;
			}
			else if (param_type == "cam_protect_open")
			{
				bool b = !!lua_toboolean(L, n);
				++n;
				Azure::bTickCamAngleForTransparentMaterial = b;
			}
			else if (param_type == "turn_log")
			{
				bool b = !!lua_toboolean(L, n);
				++n;

				Azure::TurnLog	= b;
			}
			else if (param_type == "SwimWaterSurfaceAngle")
			{
				float f = lua_tonumber(L, n);
				++n;

				Azure::SwimWaterSurfaceAngle = f;
			}
			else if (param_type == "SwimInWaterSocketZOffset")
			{
				float f = lua_tonumber(L, n);
				++n;

				Azure::SwimInWaterSocketZOffset = f;
			}
			
			return 0;
		}

		static int GetActorParam(lua_State * L)
		{
			int n = 1;

			AActor * obj = Cast<AActor>(wLua::FLuaUtils::GetUObject(L, n, "Actor"));
			if (obj == nullptr)
			{
				lua_pushstring(L, "GetActorParam: param must be Actor!");
				lua_error(L);
				return 1;
			}
			n++;

			/////
			if (lua_isstring(L, n) == false)
			{
				lua_pushstring(L, "GetActorParam: param must be string(param name)");
				lua_error(L);
				return 1;
			}

			FString param_type = UTF8_TO_TCHAR(lua_tostring(L, n));
			++n;

			if (param_type == "ECObject")
			{
				UAzureObjectComponent* comp = Cast<UAzureObjectComponent>(obj->GetComponentByClass(UAzureObjectComponent::StaticClass()));
				if (comp)
				{
					lua_rawgeti(L, LUA_REGISTRYINDEX, comp->GetLuaECObject());
				}
				else
				{
					lua_pushnil(L);
				}
				return 1;
			}

			lua_pushnil(L);
			return 1;
		}

		static int SetActorParam(lua_State * L)
		{
			int n = 1;

			AActor * obj = Cast<AActor>(wLua::FLuaUtils::GetUObject(L, n, "Actor"));
			if (obj == nullptr)
			{
				lua_pushstring(L, "SetActorParam: param must be GamePlayer!");
				lua_error(L);
				return 1;
			}
			n++;

			/////
			if (lua_isstring(L, n) == false)
			{
				lua_pushstring(L, "SetActorParam: param must be string(param_type)");
				lua_error(L);
				return 1;
			}

			FString param_type = UTF8_TO_TCHAR(lua_tostring(L, n));
			++n;

			//////
			if (param_type == "SetName")
			{
				if (lua_isstring(L, n) == false)
				{
					lua_pushstring(L, "SetActorParam: param must be string(new_name)");
					lua_error(L);
					return 1;
				}

				FString new_name = UTF8_TO_TCHAR(lua_tostring(L, n));
				++n;

				obj->Rename(*new_name);
			}
			else if (param_type == "SetTickEnable")
			{
				if (!lua_isboolean(L, n))
				{
					lua_pushstring(L, "SetTickEnable: param must be bool");
					lua_error(L);
					return 1;
				}
				bool b = !!lua_toboolean(L, n);
				++n;

				obj->PrimaryActorTick.bCanEverTick = b;
			}
			else if (param_type == "DebugUObject")
			{
				AzureUtility::DebugUObject(obj);
			}

			return 0;
		}


		static int SetNPC_FaceTargetInfo(lua_State * L)//monster¶¢ÈË
		{
			int n = 1;

			////////////////////
			AGamePlayer * obj = Cast<AGamePlayer>(wLua::FLuaUtils::GetUObject(L, n, "GamePlayer"));
			if (obj == nullptr)
			{
				lua_pushstring(L, "SetNPC_FaceTargetInfo: param must be GamePlayer!");
				lua_error(L);
				return 0;
			}
			++n;

			///////////
			if (!lua_isboolean(L, n))
			{
				lua_pushstring(L, "SetNPC_FaceTargetInfo: param must be bool(bFaceTarget)");
				lua_error(L);
				return 0;
			}
			bool bFaceTarget = !!lua_toboolean(L, n);
			++n;

			///////////
			if (lua_isstring(L, n) == false)
			{
				lua_pushstring(L, "SetNPC_SiegeInfo: param must be string(id)");
				lua_error(L);
				return 0;
			}

			FString str_id = UTF8_TO_TCHAR(lua_tostring(L, n));
			int64 target_id = FCString::Atoi64(*str_id);
			++n;

			/////////////////
			if (lua_isstring(L, n) == false)
			{
				lua_pushstring(L, "SetNPC_FaceTargetInfo: param must be string(socket_name)");
				lua_error(L);
				return 1;
			}

			FString socket_name = UTF8_TO_TCHAR(lua_tostring(L, n));
			++n;

			///////////
			if (!lua_istable(L, n) && !lua_isuserdata(L, n))
			{
				lua_pushstring(L, "SetNPC_FaceTargetInfo: param must be vector3(targetPos)");
				lua_error(L);
				return 0;
			}
			FVector vDest = FLuaVector::Get(L, n);
			vDest = POS_FROM_SERVER(vDest);
			++n;

			/////////////////
			USceneComponent* pCom = Cast<USceneComponent>(FLuaUtils::GetUObject(L, n, "SceneComponent"));
			++n;

			obj->SetFaceTarget(bFaceTarget, target_id, *socket_name, vDest, pCom);
			return 0;
		}

		static int SetNPC_LookAt(lua_State * L)//ÆÕÍ¨NPC¶¢ÈË
		{
			int n = 1;

			////////////////////
			AGamePlayer * obj = Cast<AGamePlayer>(wLua::FLuaUtils::GetUObject(L, n, "GamePlayer"));
			if (obj == nullptr)
			{
				lua_pushstring(L, "SetNPC_LookAt: param must be GamePlayer!");
				lua_error(L);
				return 0;
			}
			++n;

			///////////
			if (!lua_isnumber(L, n))
			{
				lua_pushstring(L, "SetNPC_LookAt: param must be int(type)");
				lua_error(L);
				return 0;
			}
			int type = lua_tointeger(L, n);
			++n;

			///////////
			if (!lua_isnumber(L, n))
			{
				lua_pushstring(L, "SetNPC_LookAt: param must be float(original_yaw)");
				lua_error(L);
				return 0;
			}
			float original_yaw = lua_tonumber(L, n);
			++n;

			///////////
			if (!lua_isnumber(L, n))
			{
				lua_pushstring(L, "SetNPC_LookAt: param must be float(dis_limit)");
				lua_error(L);
				return 0;
			}
			float dis_limit = lua_tonumber(L, n);
			++n;

			///////////
			if (!lua_isnumber(L, n))
			{
				lua_pushstring(L, "SetNPC_LookAt: param must be float(angle_limit)");
				lua_error(L);
				return 0;
			}
			float angle_limit = lua_tonumber(L, n);
			++n;

			///////////
			if (!lua_isnumber(L, n))
			{
				lua_pushstring(L, "SetNPC_LookAt: param must be float(turn_speed)");
				lua_error(L);
				return 0;
			}
			float turn_speed = lua_tonumber(L, n);
			++n;

			/////////////////
			if (lua_isstring(L, n) == false)
			{
				lua_pushstring(L, "SetNPC_LookAt: param must be string(socket_name)");
				lua_error(L);
				return 1;
			}

			FString face_socket_name = UTF8_TO_TCHAR(lua_tostring(L, n));
			++n;
			
			///////////
			if (lua_isstring(L, n) == false)
			{
				lua_pushstring(L, "SetNPC_LookAt: param must be string(id)");
				lua_error(L);
				return 0;
			}

			FString str_id = UTF8_TO_TCHAR(lua_tostring(L, n));
			int64 target_id = FCString::Atoi64(*str_id);
			++n;

			/////////////////
			USceneComponent* pCom = Cast<USceneComponent>(FLuaUtils::GetUObject(L, n, "SceneComponent"));
			++n;

			/////////////////
			if (lua_isstring(L, n) == false)
			{
				lua_pushstring(L, "SetNPC_LookAt: param must be string(face_target_socket_name)");
				lua_error(L);
				return 1;
			}

			FString face_target_socket_name = UTF8_TO_TCHAR(lua_tostring(L, n));
			++n;

			/////////////////
			if (lua_isnumber(L, n) == false)
			{
				lua_pushstring(L, "SetNPC_LookAt: param must be number(face_target_duration)");
				lua_error(L);
				return 1;
			}

			float face_target_duration = (float)lua_tonumber(L, n);
			++n;

			obj->SetNPCLookAt(type,original_yaw, angle_limit, dis_limit, turn_speed, target_id, *face_socket_name, pCom, *face_target_socket_name, face_target_duration);
			return 0;
		}

		static int SetHostLookAtNPC(lua_State * L)//Ö÷½Ç¶¢NPC
		{
			int n = 1;

			////////////////////
			AGamePlayer * obj = Cast<AGamePlayer>(wLua::FLuaUtils::GetUObject(L, n, "GamePlayer"));
			if (obj == nullptr)
			{
				lua_pushstring(L, "SetHostLookAtNPC: param must be GamePlayer!");
				lua_error(L);
				return 0;
			}
			++n;

			///////////
			if (!lua_isboolean(L, n))
			{
				lua_pushstring(L, "SetHostLookAtNPC: param must be bool(bLookAt)");
				lua_error(L);
				return 0;
			}
			bool bLookAt = !!lua_toboolean(L, n);
			++n;

			///////////
			if (!lua_isnumber(L, n))
			{
				lua_pushstring(L, "SetHostLookAtNPC: param must be number(look type)");
				lua_error(L);
				return 0;
			}
			int look_type = lua_tonumber(L, n);
			++n;

			///////////
			if (!lua_isnumber(L, n))
			{
				lua_pushstring(L, "SetHostLookAtNPC: param must be float(duration)");
				lua_error(L);
				return 0;
			}
			float duration = lua_tonumber(L, n);
			++n;

			/////////////////
			if (lua_isstring(L, n) == false)
			{
				lua_pushstring(L, "SetHostLookAtNPC: param must be string(socket_name)");
				lua_error(L);
				return 1;
			}

			FString face_socket_name = UTF8_TO_TCHAR(lua_tostring(L, n));
			++n;

			/////////////////
			USceneComponent* pCom = Cast<USceneComponent>(FLuaUtils::GetUObject(L, n, "SceneComponent"));
			++n;

			/////////////////
			if (lua_isstring(L, n) == false)
			{
				lua_pushstring(L, "SetHostLookAtNPC: param must be string(face_target_socket_name)");
				lua_error(L);
				return 1;
			}

			FString face_target_socket_name = UTF8_TO_TCHAR(lua_tostring(L, n));
			++n;

			/////////////////
			obj->SetHostLookAtNPC(bLookAt, look_type, duration, *face_socket_name, pCom, *face_target_socket_name);
			return 0;
		}

		int32 SweepSingleByChannel(lua_State *L)
		{
			if (!AAzureEntryPoint::IsInit())
				return 0;

			UWorld * pWorld = AAzureEntryPoint::Instance->GetWorld();
			int n = 1;

			FVector Start = wLua::FLuaVector::Get(L, n);
			n++;

			FVector End = wLua::FLuaVector::Get(L, n);
			n++;

			FRotator rotator = wLua::FLuaRotator::Get(L, n);
			n++;

			FQuat quat = rotator.Quaternion();
			ECollisionChannel channel = (ECollisionChannel)lua_touint(L, n);
			n++;

			int shapeType = lua_tointeger(L, n);
			n++;

			float shapeArg1 = lua_tonumber(L, n);
			n++;

			float shapeArg2 = lua_tonumber(L, n);
			n++;
			
			float shapeArg3 = lua_tonumber(L, n);
			n++;
			
			FCollisionShape shape;
			if (shapeType == ECollisionShape::Capsule)
				shape.SetCapsule(shapeArg1, shapeArg2);
			else if (shapeType == ECollisionShape::Box)
				shape.SetBox(FVector(shapeArg1, shapeArg2, shapeArg3));
			else if (shapeType == ECollisionShape::Sphere)
				shape.SetSphere(shapeArg1);

			//×îºóÒ»¸ö²ÎÊýÊÇ ignore actors
			TArray<AActor *> ignores;
			if (lua_istable(L, n))
			{
				lua_pushnil(L);
				while (lua_next(L, -2) != 0)
				{
					AActor* Obj = Cast<AActor>(wLua::FLuaUtils::GetUObject(L, -1, "Actor"));
					if (Obj) ignores.Add(Obj);
					lua_pop(L, 1);
				}
			}
			n++;

			FHitResult thisHitInfo;
			FCollisionQueryParams Params("SweepSingleByChannel", false); // Not Trace Complex!
			Params.AddIgnoredActors(ignores);
			//Params.bIgnoreTouches = true;
			bool ret = pWorld->SweepSingleByChannel(thisHitInfo, Start, End, quat, channel, shape, Params);

			lua_newtable(L);

			if (ret)
			{
				int index = 1;
				AzureUtility::pushFHitResult2Lua(L, thisHitInfo, AzureUtility::isTraceAzureObjectChannel(channel));
				lua_rawseti(L, -2, index);
			}			
			
			return 1;
		}

		int lua_CalRelativePosInfo(lua_State * L)
		{
			float absx = luaL_checknumber(L, 1);
			float absy = luaL_checknumber(L, 2);
			float absz = luaL_checknumber(L, 3);

			float r_dirx = luaL_checknumber(L, 4);
			float r_diry = luaL_checknumber(L, 5);
			float r_dirz = luaL_checknumber(L, 6);

			float cx = luaL_checknumber(L, 7);
			float cy = luaL_checknumber(L, 8);
			float cz = luaL_checknumber(L, 9);

			float c_dirx = luaL_checknumber(L, 10);
			float c_diry = luaL_checknumber(L, 11);
			float c_dirz = luaL_checknumber(L, 12);

			FVector abs_pos(absx, absy, absz);
			FVector abs_dir(r_dirx, r_diry, r_dirz);

			FVector carrier_pos(cx, cy, cz);
			FVector carrier_dir(c_dirx, c_diry, c_dirz);

			FVector rel_pos, rel_dir;
			AzureUtility::CalRelativePosInfo(abs_pos, abs_dir.Rotation(), carrier_pos, carrier_dir.Rotation(), rel_pos, rel_dir);


			lua_pushnumber(L, rel_pos.X);
			lua_pushnumber(L, rel_pos.Y);
			lua_pushnumber(L, rel_pos.Z);
			lua_pushnumber(L, rel_dir.X);
			lua_pushnumber(L, rel_dir.Y);
			lua_pushnumber(L, rel_dir.Z);
			return 6;
		}

		int lua_CalcWorldTransformByRelative(lua_State* L)
		{
			int n = 1;
			if (!lua_istable(L, n) && !lua_isuserdata(L,n))
			{
				lua_pushfstring(L, "CalcWorldTransformByRelative: param #%d must be Vector(rel_pos)", n);
				lua_error(L);
				return 1;
			}
			FVector vRelPos = FLuaVector::Get(L, n);
			n++;

			if (!lua_istable(L, n) && !lua_isuserdata(L, n))
			{
				lua_pushfstring(L, "CalcWorldTransformByRelative: param #%d must be Rotator(rel_rot)", n);
				lua_error(L);
				return 1;
			}
			FVector vRelRot = FLuaVector::Get(L, n);
			n++;

			if (!lua_istable(L, n) && !lua_isuserdata(L, n))
			{
				lua_pushfstring(L, "CalcWorldTransformByRelative: param #%d must be Vector(rel_scale)", n);
				lua_error(L);
				return 1;
			}
			FVector vRelScale = FLuaVector::Get(L, n);
			n++;

			if (!lua_istable(L, n) && !lua_isuserdata(L, n))
			{
				lua_pushfstring(L, "CalcWorldTransformByRelative: param #%d must be Vector(parent_pos)", n);
				lua_error(L);
				return 1;
			}
			FVector vParentPos = FLuaVector::Get(L, n);
			n++;

			if (!lua_istable(L, n) && !lua_isuserdata(L, n))
			{
				lua_pushfstring(L, "CalcWorldTransformByRelative: param #%d must be Rotator(parent_rot)", n);
				lua_error(L);
				return 1;
			}
			FVector vParentRot = FLuaVector::Get(L, n);
			n++;

			if (!lua_istable(L, n) && !lua_isuserdata(L, n))
			{
				lua_pushfstring(L, "CalcWorldTransformByRelative: param #%d must be Vector(parent_scale)", n);
				lua_error(L);
				return 1;
			}
			FVector vParentScale = FLuaVector::Get(L, n);
			n++;

			FVector vOutPos;
			FVector vOutRot;
			FVector vOutScale;
			AzureUtility::CalcWorldTransformByRelative(vRelPos, vRelRot, vRelScale, vParentPos, vParentRot, vParentScale, vOutPos, vOutRot, vOutScale);
			FLuaVector::Return(L, vOutPos);
			FLuaVector::Return(L, vOutRot);
			FLuaVector::Return(L, vOutScale);
			return 3;
		}

		int lua_CalcRelativeTransform(lua_State* L)
		{
			int n = 1;
			if (!lua_istable(L, n) && !lua_isuserdata(L, n))
			{
				lua_pushfstring(L, "lua_CalcRelativeTransform: param #%d must be Vector(rel_pos)", n);
				lua_error(L);
				return 1;
			}
			FVector vAbsPos = FLuaVector::Get(L, n);
			n++;

			if (!lua_istable(L, n) && !lua_isuserdata(L, n))
			{
				lua_pushfstring(L, "lua_CalcRelativeTransform: param #%d must be Rotator(rel_rot)", n);
				lua_error(L);
				return 1;
			}
			FVector vAbsRot = FLuaVector::Get(L, n);
			n++;

			if (!lua_istable(L, n) && !lua_isuserdata(L, n))
			{
				lua_pushfstring(L, "lua_CalcRelativeTransform: param #%d must be Vector(rel_scale)", n);
				lua_error(L);
				return 1;
			}
			FVector vAbsScale = FLuaVector::Get(L, n);
			n++;

			if (!lua_istable(L, n) && !lua_isuserdata(L, n))
			{
				lua_pushfstring(L, "lua_CalcRelativeTransform: param #%d must be Vector(parent_pos)", n);
				lua_error(L);
				return 1;
			}
			FVector vParentPos = FLuaVector::Get(L, n);
			n++;

			if (!lua_istable(L, n) && !lua_isuserdata(L, n))
			{
				lua_pushfstring(L, "lua_CalcRelativeTransform: param #%d must be Rotator(parent_rot)", n);
				lua_error(L);
				return 1;
			}
			FVector vParentRot = FLuaVector::Get(L, n);
			n++;

			if (!lua_istable(L, n) && !lua_isuserdata(L, n))
			{
				lua_pushfstring(L, "lua_CalcRelativeTransform: param #%d must be Vector(parent_scale)", n);
				lua_error(L);
				return 1;
			}
			FVector vParentScale = FLuaVector::Get(L, n);
			n++;

			FVector vOutPos;
			FVector vOutRot;
			FVector vOutScale;
			AzureUtility::CalcRelativeTransform(vAbsPos, vAbsRot, vAbsScale, vParentPos, vParentRot, vParentScale, vOutPos, vOutRot, vOutScale);
			FLuaVector::Return(L, vOutPos);
			FLuaVector::Return(L, vOutRot);
			FLuaVector::Return(L, vOutScale);
			return 3;
		}

		int lua_CalAngleByTwoUEDir(lua_State * L)
		{
			float vx1 = luaL_checknumber(L, 1);
			float vy1 = luaL_checknumber(L, 2);
			float vz1 = luaL_checknumber(L, 3);

			float vx2 = luaL_checknumber(L, 4);
			float vy2 = luaL_checknumber(L, 5);
			float vz2 = luaL_checknumber(L, 6);

			FVector v1(vx1, vy1, vz1);
			FVector v2(vx2, vy2, vz2);

			float angle = AzureUtility::Angle2(v1,v2);
			lua_pushnumber(L, angle);

			return 1;
		}

		int lua_GetLevelScriptObject(lua_State * L)
		{
			if (!AAzureEntryPoint::IsInit())
				return 0;

			UWorld* World = AAzureEntryPoint::Instance->GetWorld();
			FString levelName = UTF8_TO_TCHAR(luaL_checkstring(L, 1));
			const TArray<ULevelStreaming*>  levels = World->GetStreamingLevels();
			ALevelScriptActor *levelBp = nullptr;
			for (const ULevelStreaming *slevel : levels)
			{
				ULevel* level = slevel->GetLoadedLevel();
				if (level && (levelName == slevel->PackageNameToLoad.ToString()))
				{
					levelBp = level->GetLevelScriptActor();
					break;
				}
			}

			if (levelBp != nullptr)
			{
				wLua::FLuaUtils::ReturnUObject(L, levelBp);
				return 1;
			}
			return 0;
		}

		int lua_GetLandscapeInfo(lua_State * L)
		{
			if (!AAzureEntryPoint::IsInit())
				return 0;

			UWorld* pWorld = AAzureEntryPoint::Instance->GetWorld();
			if (!pWorld)
			{
				lua_pushstring(L, "GetLandscapeInfo: Can't not GetWorld!!!");
				lua_error(L);
				return 0;
			}

			int retNum = 0;
			bool needCreateTable = true;

#if WITH_EDITORONLY_DATA
			auto& LandscapeInfoMap = ULandscapeInfoMap::GetLandscapeInfoMap(pWorld);	
			for (auto It = LandscapeInfoMap.Map.CreateIterator(); It; ++It)
			{
				ULandscapeInfo* LandscapeInfo = It.Value();
				if (LandscapeInfo && !LandscapeInfo->IsPendingKill())
				{
					ALandscapeProxy* LandscapeProxy = LandscapeInfo->GetLandscapeProxy();
					if (LandscapeProxy)
					{
						int32 MinX, MinY, MaxX, MaxY;
						int32 Width = 0, Height = 0;
						if (LandscapeInfo->GetLandscapeExtent(MinX, MinY, MaxX, MaxY))
						{
							Width = MaxX - MinX;  // original add one , here is cal the grid num, no need. TileSize+1 size, TileSize grid for total
							Height = MaxY - MinY;
						}
						FVector Pos = LandscapeProxy->GetLandscapeActor()->GetActorLocation();
						retNum = 1;
						needCreateTable = false;
						lua_newtable(L);
						lua_pushnumber(L, Width);
						lua_setfield(L, -2, "Width");

						lua_pushnumber(L, Height);
						lua_setfield(L, -2, "Height");

						wLua::FLuaVector::Return(L, Pos);
						lua_setfield(L, -2, "Pos");

						break;
					}
				}
			}
#else
			//TODO:
#endif
			TActorIterator<AActor> actorItr = TActorIterator<AActor>(pWorld);
			for (; actorItr; ++actorItr)
			{
				if (actorItr->GetName() == TEXT("_F"))
				{
					retNum = 1;
					FVector scale = actorItr->GetActorScale();
					int32 Width = scale.X;
					int32 Height = scale.Y;
					if(needCreateTable)
						lua_newtable(L);
					lua_pushnumber(L, Width);
					lua_setfield(L, -2, "Width_F");

					lua_pushnumber(L, Height);
					lua_setfield(L, -2, "Height_F");

					break;
				}
			}

			return retNum;
		}

		static int lua_GetAllSocketsByName(lua_State* L)
		{
			if (!AAzureEntryPoint::IsInit())
				return 0;

			UWorld* pWorld = AAzureEntryPoint::Instance->GetWorld();
			if (!pWorld)
				return 0;

			const char* szName = lua_tostring(L, 1);
			FString strName = UTF8_TO_TCHAR(szName);

			TArray<UStaticMeshComponent*> StaticMeshArray;
			TArray<UInstancedStaticMeshComponent*> InstancedStaticMeshArray;

			for (TActorIterator<AActor> ActorItr(pWorld); ActorItr; ++ActorItr)
			{
				TArray<UActorComponent*> Components = ActorItr->GetComponentsByClass(UStaticMeshComponent::StaticClass());
				for (UActorComponent* Comp : Components)
				{
					StaticMeshArray.Add(Cast<UStaticMeshComponent>(Comp));
				}
				
				TArray<UActorComponent*> InstancedComponenets = ActorItr->GetComponentsByClass(UInstancedStaticMeshComponent::StaticClass());
				for (UActorComponent* Comp : InstancedComponenets)
				{
					InstancedStaticMeshArray.Add(Cast<UInstancedStaticMeshComponent>(Comp));
				}
			}

			TArray<FString> Results;
			TArray<FTransform> Results2;
			
			for (UStaticMeshComponent* StaticMesh : StaticMeshArray)
			{
				TArray<FComponentSocketDescription> Sockets;
				StaticMesh->QuerySupportedSockets(Sockets);
				for (FComponentSocketDescription& sock : Sockets)
				{
					if (sock.Type == EComponentSocketType::Type::Socket && sock.Name.ToString().Find(strName) != INDEX_NONE)
					{
						FTransform trans = StaticMesh->GetSocketTransform(sock.Name);
						Results.Add(sock.Name.ToString());
						Results2.Add(trans);
					}
				}
			}

			for (UInstancedStaticMeshComponent* InstancedStaticMesh : InstancedStaticMeshArray)
			{
				TArray<FComponentSocketDescription> Sockets;
				InstancedStaticMesh->QuerySupportedSockets(Sockets);

				for (FComponentSocketDescription& sock : Sockets)
				{
					if (sock.Type == EComponentSocketType::Type::Socket && sock.Name.ToString().Find(strName) != INDEX_NONE)
					{
						FTransform trans = InstancedStaticMesh->GetSocketTransform(sock.Name, ERelativeTransformSpace::RTS_Component);
						for (FInstancedStaticMeshInstanceData& instData : InstancedStaticMesh->PerInstanceSMData)
						{
							FTransform instTransform(instData.Transform);
							FTransform outTransform = trans * instTransform;
							outTransform = outTransform * InstancedStaticMesh->GetComponentTransform();
							Results.Add(sock.Name.ToString());
							Results2.Add(outTransform);
						}
					}
				}
			}

			lua_newtable(L);
			int i = 1;
			int count = Results.Num();
			for (int index = 0; index < count; index++)
			{
				FString& name = Results[index];
				FTransform& trans = Results2[index];
				lua_newtable(L);
				lua_pushstring(L, TCHAR_TO_UTF8(*name));
				lua_rawseti(L, -2, 1);
				wLua::FLuaTransform::ReturnUseRotator(L, trans);
				lua_rawseti(L, -2, 2);
				lua_rawseti(L, -2, i);
				i++;
			}

			return 1;
		}

		static int lua_ShowInstancedStaticMesh(lua_State* L)
		{
			AActor* Obj = Cast<AActor>(wLua::FLuaUtils::GetUObject(L, 1, "Actor"));
			if (Obj == nullptr)
			{
				lua_pushfstring(L, "lua_ShowInstancedStaticMesh: param #%d must be AActor", 1);
				lua_error(L);
				return 1;
			}

			FVector vAbsPos = Obj->GetActorLocation();
			bool bShow = lua_toboolean(L, 2) ? true : false;

			FInstancedObjManager::InstancedObj* inst = FInstancedObjManager::GetInstance().Find(vAbsPos);
			if (inst && inst->StaticMesh.IsValid())
				inst->StaticMesh->SetActorHiddenInGame(!bShow);

			if (inst && inst->Component.IsValid())
			{
				FTransform trans;
				FInstancedStaticMeshInstanceData& instData = inst->Component->PerInstanceSMData[inst->InstanceIndex];
				inst->Component->GetInstanceTransform(inst->InstanceIndex, trans, true);

				if (bShow)
				{
					if (instData.dummy1 != 0.0f && instData.dummy2 != 0.0f && instData.dummy3 != 0.0f)
					{
						trans = FTransform(inst->Rotator, inst->Position, FVector(instData.dummy1, instData.dummy2, instData.dummy3));
						inst->Component->UpdateInstanceTransform(inst->InstanceIndex, trans, -1.0f, true, true, true);
						instData.dummy1 = instData.dummy2 = instData.dummy3 = 0.0f;
					}
				}
				else
				{
					if (instData.dummy1 == 0.0f && instData.dummy2 == 0.0f && instData.dummy3 == 0.0f)
					{
						FVector OldPosition = trans.GetLocation();
						FVector OldScale = trans.GetScale3D();
						FRotator OldRotator = trans.GetRotation().Rotator();
						instData.dummy1 = OldScale.X;
						instData.dummy2 = OldScale.Y;
						instData.dummy3 = OldScale.Z;
						trans.SetScale3D(FVector::ZeroVector);
						inst->Rotator = OldRotator;
						inst->Position = OldPosition;
						inst->Component->UpdateInstanceTransform(inst->InstanceIndex, trans, -1.0f, true, true, true);
					}
				}
			}

			return 0;
		}

		static int lua_PlayDynamicForceFeedback(lua_State * L)
		{
			float Intensity = (float)luaL_checknumber(L, 1);
			float Duration = (float)luaL_checknumber(L, 2);
			bool bAffectsLeftLarge = true;
			bool bAffectsLeftSmall = true;
			bool bAffectsRightLarge = true;
			bool bAffectsRightSmall = true;
			if (lua_gettop(L) > 2)
			{
				bAffectsLeftLarge = lua_toboolean(L, 3) ? true : false;
				bAffectsLeftSmall = lua_toboolean(L, 4) ? true : false;
				bAffectsRightLarge = lua_toboolean(L, 5) ? true : false;
				bAffectsRightSmall = lua_toboolean(L, 6) ? true : false;
			}

			if (!AAzureEntryPoint::IsInit())
				return 0;

			APlayerController* pCtrler = AAzureEntryPoint::Instance->GetPlayerController();
			if (!pCtrler)
				return 0;
			pCtrler->PlayDynamicForceFeedback(Intensity, Duration, bAffectsLeftLarge, bAffectsLeftSmall, bAffectsRightLarge, bAffectsRightSmall);
			return 0;
		}

		static int lua_BuildCurveFloat(lua_State* L) {
			int n = 1;

			// parameter 1: key table
			if (!lua_istable(L, n))
			{
				lua_pushstring(L, "BuildCurveFloat: param #1 must be table");
				lua_error(L);
				return 0;
			}
			FRichCurve * richCurve = new FRichCurve();
			lua_pushnil(L);
			while (lua_next(L, -2) != 0)
			{
				if (lua_istable(L, -1)) {
					lua_getfield(L, -1, "time");
					float time = (float)lua_tonumber(L, -1);
					lua_pop(L, 1);

					lua_getfield(L, -1, "value");
					float value = (float)lua_tonumber(L, -1);
					lua_pop(L, 1);

					lua_getfield(L, -1, "inerp_mode");
					ERichCurveInterpMode interpMode = (ERichCurveInterpMode)(int)lua_tonumber(L, -1);
					lua_pop(L, 1);

					FKeyHandle key = richCurve->AddKey(time, value);
					richCurve->SetKeyInterpMode(key, interpMode);
				}
				lua_pop(L, 1);
			}
			n++;

			UCurveFloat* curve = NewObject<UCurveFloat>();
			curve->FloatCurve = *richCurve;
			wLua::FLuaUtils::ReturnUObject(L, curve);
			return 1;
		}

		int32 CallMyAnimInstanceMethod(lua_State * L)
		{
			int n = 1;
			UMyAnimInstance* Obj = Cast<UMyAnimInstance>(wLua::FLuaUtils::GetUObject(L, n, "MyAnimInstance"));
			if (Obj == nullptr)
			{
				lua_pushstring(L, "CallMyAnimInstanceMethod: param 1 must be UMyAnimInstance");
				lua_error(L);
				return 1;
			}
			++n;
			
			if (lua_isstring(L, n) == false)
			{
				lua_pushstring(L, "CallMyAnimInstanceMethod: param 2 must be string");
				lua_error(L);
				return 1;
			}

			FString param_type = UTF8_TO_TCHAR(lua_tostring(L, n));
			++n;

			//////
			if (param_type == "StopSlotAnim")
			{
				if (!lua_isnumber(L, n))
				{
					lua_pushstring(L, "StopSlotAnim: param 1 must be number");
					lua_error(L);
					return 1;
				}
				float blendTime = lua_tonumber(L, n);
				++n;

				if (lua_isstring(L, n) == false)
				{
					lua_pushstring(L, "StopSlotAnim: param 2 must be string");
					lua_error(L);
					return 1;
				}

				FString SlotName = UTF8_TO_TCHAR(lua_tostring(L, n));
				++n;

				if (Obj)
					Obj->StopSlotAnimation2(blendTime,*SlotName);
			}

			return 0;
		}

		static int GetShaderPlatformName(lua_State * L)
		{
			lua_pushstring(L, TCHAR_TO_UTF8(*LegacyShaderPlatformToShaderFormat(GMaxRHIShaderPlatform).ToString()));
			return 1;
		}

		static int GetShaderCacheMD5(lua_State * L)
		{
			FString MD5;
			astring resname = lua_tostring(L, 1);
			FString InName(UTF8_TO_TCHAR(resname.c_str()));
			FString GamePath = FPaths::ProjectContentDir() / InName;

			FArchive* FileReader = IFileManager::Get().CreateFileReader(*GamePath);
			if (FileReader)
			{
				FMD5Hash Result = FMD5Hash::HashFileFromArchive(FileReader);
				MD5 = LexToString(Result);
				delete FileReader;
			}
			lua_pushstring(L, TCHAR_TO_UTF8(*MD5));
			return 1;
		}

		static int IsShaderCacheExist(lua_State * L)
		{
			astring resname = lua_tostring(L, 1);
			FString InName(UTF8_TO_TCHAR(resname.c_str()));
			FString GamePath = FPaths::ProjectContentDir() / InName;

			FArchive* FileReader = IFileManager::Get().CreateFileReader(*GamePath);
			bool bExit = false;
			if (FileReader)
			{
				bExit = true;
				delete FileReader;
			}
			lua_pushboolean(L, bExit ? 1 : 0);
			return 1;
		}

		//用于判断 shader cache 是否还在读取中
		static int GetNumPrecompileShaderRemaining(lua_State * L)
		{
			int num = FShaderPipelineCache::NumPrecompilesRemaining();
			lua_pushnumber(L, num);
			return 1;
		}

		static int GetShaderCacheSaveDir(lua_State* L)
		{
			//see FPipelineFileCache::SavePipelineFileCache
			lua_pushstring(L, TCHAR_TO_UTF8(*FPaths::ProjectPersistentDownloadDir()));
			return 1;
		}

		static int MergePipelineFileCaches(lua_State* L)
		{
			FString PathA(UTF8_TO_TCHAR(luaL_checkstring(L, 1)));
			FString PathB(UTF8_TO_TCHAR(luaL_checkstring(L, 2)));
			FPipelineFileCache::PSOOrder Order = FPipelineFileCache::PSOOrder(luaL_checkint(L, 3));
			FString OutputPath(UTF8_TO_TCHAR(luaL_checkstring(L, 4)));

			bool ret = FPipelineFileCache::MergePipelineFileCaches(PathA, PathB, Order, OutputPath);
			lua_pushboolean(L, ret);
			return 1;
		}

		static int  SetLevelActorsVisible(lua_State * L)
		{
			ULevel * level = Cast<ULevel>(wLua::FLuaUtils::GetUObject(L, 1, "Level"));
			if (level == nullptr)
			{
				lua_pushstring(L, "SetLevelVisible: param 1 must be ULevel");
				lua_error(L);
				return 0;
			}
			if (!lua_isboolean(L, 2))
			{
				lua_pushstring(L, "SetLevelVisible: param 2 must be bool");
				lua_error(L);
				return 0;
			}
			bool bActive = !!lua_toboolean(L, 2);

			for (AActor* Actor : level->Actors)
			{
				if (!IsValid(Actor)) continue;

				Actor->SetActorHiddenInGame(!bActive);
				Actor->SetActorTickEnabled(bActive);
			}
			return 0;
		}

		static int PredictProjectilePath_ByTraceChannel(lua_State * L)
		{
			if (!AAzureEntryPoint::IsInit())
				return 0;

			UWorld * pWorld = AAzureEntryPoint::Instance->GetWorld();
			if (!pWorld)
				return 0;

			int n = 1;
			if (!lua_istable(L, n) && !lua_isuserdata(L, n))
			{
				lua_pushstring(L, "PredictProjectilePath_ByTraceChannel: param 1 must be vector3(StartPos)");
				lua_error(L);
				return 0;
			}
			FVector start = wLua::FLuaVector::Get(L, n);
			n++;
			start = POS_FROM_SERVER(start);

			if (!lua_istable(L, n) && !lua_isuserdata(L, n))
			{
				lua_pushstring(L, "PredictProjectilePath_ByTraceChannel: param 2 must be vector3(LaunchVelocity)");
				lua_error(L);
				return 0;
			}
			FVector velocity = wLua::FLuaVector::Get(L, n);
			n++;
			velocity = POS_FROM_SERVER(velocity);

			if (!lua_isboolean(L, n)) {
				lua_pushstring(L, "PredictProjectilePath_ByTraceChannel: param 3 must be boolean(IsTracePath)");
				lua_error(L);
				return 0;
			}
			bool isTracePath = !!lua_toboolean(L, n);
			n++;

			if (!lua_isnumber(L, n)) {
				lua_pushstring(L, "PredictProjectilePath_ByTraceChannel: param 4 must be number(ProjectileRadius)");
				lua_error(L);
				return 0;
			}
			float projectilRadius = lua_tonumber(L, n);
			n++;

			if (!lua_isnumber(L, n)) {
				lua_pushstring(L, "PredictProjectilePath_ByTraceChannel: param 5 must be number(TraceChannel)");
				lua_error(L);
				return 0;
			}
			ECollisionChannel channel = (ECollisionChannel)lua_touint(L, n);
			n++;

			if (!lua_isboolean(L, n)) {
				lua_pushstring(L, "PredictProjectilePath_ByTraceChannel: param 6 must be boolean(IsTraceComplex)");
				lua_error(L);
				return 0;
			}
			bool isTraceComplex = !!lua_toboolean(L, n);
			n++;

			if (!lua_isnumber(L, n)) {
				lua_pushstring(L, "PredictProjectilePath_ByTraceChannel: param 7 must be number(SimFrequency)");
				lua_error(L);
				return 0;
			}
			float simFrequency = lua_tonumber(L, n);
			n++;

			if (!lua_isnumber(L, n)) {
				lua_pushstring(L, "PredictProjectilePath_ByTraceChannel: param 8 must be number(MaxSimTime)");
				lua_error(L);
				return 0;
			}
			float maxSimTime = lua_tonumber(L, n);
			n++;

			if (!lua_isnumber(L, n)) {
				lua_pushstring(L, "PredictProjectilePath_ByTraceChannel: param 9 must be number(OverrideGravityZ)");
				lua_error(L);
				return 0;
			}
			float overrideGravityZ = lua_tonumber(L, n) * 100;
			n++;

			if (!lua_istable(L, n)) {
				lua_pushstring(L, "PredictProjectilePath_ByTraceChannel: param 6 must be table(IgnoreActors)");
				lua_error(L);
				return 0;
			}
			TArray<AActor *> ignores;
			if (lua_istable(L, n))
			{
				lua_pushnil(L);
				while (lua_next(L, -2) != 0)
				{
					AActor* Obj = Cast<AActor>(wLua::FLuaUtils::GetUObject(L, -1, "Actor"));
					if (Obj) ignores.Add(Obj);
					lua_pop(L, 1);
				}
			}

			FHitResult OutHit;
			TArray<FVector> OutPathPositions;
			FVector OutLastTraceDestination;
			bool ret = UGameplayStatics::Blueprint_PredictProjectilePath_ByTraceChannel(
				pWorld, OutHit, OutPathPositions, OutLastTraceDestination, 
				start, velocity, isTracePath, projectilRadius, channel,isTraceComplex,
				ignores, EDrawDebugTrace::None, 0, 
				simFrequency, maxSimTime, overrideGravityZ
				);

			AzureUtility::pushFHitResult2Lua(L, OutHit, AzureUtility::isTraceAzureObjectChannel(channel));
			wLua::FLuaVector::Return(L, OutLastTraceDestination);

			lua_newtable(L);
			int index = 1;
			for (FVector &position : OutPathPositions)
			{
				wLua::FLuaVector::Return(L, position);
				lua_rawseti(L, -2, index);
				index++;
			}

			return 3;
		}

		static int lua_QuitGame(lua_State * L)
		{
#if PLATFORM_IOS
			[[IOSAppDelegate GetDelegate] RequestExit];
#else
			if (!AAzureEntryPoint::IsInit())
				return 0;

			UKismetSystemLibrary::QuitGame(AAzureEntryPoint::Instance->GetWorld(), NULL, EQuitPreference::Quit, true);
#endif
			return 0;
		}

#if PLATFORM_ANDROID
		static int lua_getDataDir(lua_State * L)
		{
			JNIEnv* env = FAndroidApplication::GetJavaEnv();
			jmethodID method = env->GetMethodID(FJavaWrapper::GameActivityClassID, "getDataDir", "()Ljava/lang/String;");
			jstring jdataPath = (jstring)env->CallObjectMethod(FJavaWrapper::GameActivityThis, method);
			const char* dataPathstr = env->GetStringUTFChars(jdataPath, 0);
			astring dataPath = dataPathstr;
			env->ReleaseStringUTFChars(jdataPath, dataPathstr);
			UE_LOG(LogAzure, Warning, TEXT("DataDir: %s"), ANSI_TO_TCHAR(dataPath.c_str()));
			
			lua_pushstring(L, dataPath.c_str());
			return 1;
		}

		static int lua_AndroidRestart(lua_State *L)
		{
			AndroidThunkCpp_RestartApplication();
			return 0;
		}
#endif

		static int lua_GetProjectSvnInfo(lua_State * L)
		{

#if WITH_EDITOR
			FString MyExe = TEXT("svn");
			FString projPath = FPaths::ConvertRelativePathToFull(FPaths::ProjectDir());
			FString MyCommand = FString::Printf(TEXT("info %s"), *projPath);
			int32 ReturnCode;
			FString RoStdOut;
			FPlatformProcess::ExecProcess(TEXT("svn"), *MyCommand, &ReturnCode, &RoStdOut, nullptr);
			lua_pushstring(L, TCHAR_TO_UTF8(*RoStdOut));
			return 1;
#else
			return 0; 
#endif
		}

		static int lua_ExecProcess(lua_State * L)
		{
			FString Cmd = UTF8_TO_TCHAR(luaL_checkstring(L, 1));
			FString Params = UTF8_TO_TCHAR(luaL_checkstring(L, 2));
			int32 ReturnCode;
			FString RoStdOut;
			FString RoStdErr;

			FPlatformProcess::ExecProcess(*Cmd, *Params, &ReturnCode, &RoStdOut, &RoStdErr);
			lua_pushinteger(L, ReturnCode);
			lua_pushstring(L, TCHAR_TO_UTF8(*RoStdOut));
			lua_pushstring(L, TCHAR_TO_UTF8(*RoStdErr));
			return 3;
		}

		static int lua_CloseAFile(lua_State* L)
		{
			AFile* pAFile = (AFile*)lua_touserdata(L, 1);
			if (pAFile) {
				delete pAFile;
			}
			return 0;
		}

		static int lua_AsyncLoadAFile(lua_State * L)
		{
			const char * resName = luaL_checkstring(L, 1);
			if (!lua_isfunction(L, 2))
			{
				lua_pushstring(L, "lua_AsyncLoadAFile: second param must be function");
				lua_error(L);
				return 1;
			}

			bool isStreaming = lua_isnoneornil(L, 3) ? false : !!lua_toboolean(L, 3);



			struct InstanceResult
			{
				AFile* pAFile;
				bool isStreaming;
				InstanceResult() : pAFile(nullptr), isStreaming(false)
				{

				}
			};

			class FParallelAFileImageInstanceTask
			{
				InstanceResult * pResult;
				FString fileName;
			public:
				FParallelAFileImageInstanceTask(InstanceResult * InpResult,TCHAR * InfileName)  : pResult(InpResult), fileName(InfileName)
				{
					if(pResult->isStreaming)
						fileName = FPaths::ProjectContentDir() + fileName;
				}

				TStatId GetStatId() const
				{
					RETURN_QUICK_DECLARE_CYCLE_STAT(FParallelAFileImageInstanceTask, STATGROUP_TaskGraphTasks);
				}
				static ENamedThreads::Type GetDesiredThread()
				{
					return ENamedThreads::AnyHiPriThreadHiPriTask;
				}
				static ESubsequentsMode::Type GetSubsequentsMode()
				{
					return ESubsequentsMode::TrackSubsequents;
				}

				void DoTask(ENamedThreads::Type CurrentThread, const FGraphEventRef& MyCompletionGraphEvent)
				{
					AFile * pAFile = nullptr;
					if(!pResult->isStreaming)
						pAFile = new AFileImage();
					else
						pAFile = new AzureStreamingFile();
					if (!pAFile->Open(TCHAR_TO_ANSI(*fileName), AFILE_BINARY | AFILE_OPENEXIST))
					{
						delete pAFile;
						pAFile = nullptr;
					}
					pResult->pAFile = pAFile;
				}
			};

			class FParallelAFileImageInstanceCompletionTask
			{
				InstanceResult * pResult;
				wLua::lua_registry_handle callbackRef;

			public:
				FParallelAFileImageInstanceCompletionTask(wLua::lua_registry_handle callback, InstanceResult * InResult) : callbackRef(callback), pResult(InResult)
				{
				}

				TStatId GetStatId() const
				{
					RETURN_QUICK_DECLARE_CYCLE_STAT(FParallelAFileImageInstanceCompletionTask, STATGROUP_TaskGraphTasks);
				}
				static ENamedThreads::Type GetDesiredThread()
				{
					return ENamedThreads::GameThread;
				}
				static ESubsequentsMode::Type GetSubsequentsMode()
				{
					return ESubsequentsMode::TrackSubsequents;
				}

				void DoTask(ENamedThreads::Type CurrentThread, const FGraphEventRef& MyCompletionGraphEvent)
				{
					AFile* pAFile = pResult->pAFile;
					bool isStreaming = pResult->isStreaming;
					delete pResult; 

					if (!AAzureEntryPoint::Instance)
						return;

					wLua::Lua* wlua = AAzureEntryPoint::Instance->GetWLua();
					lua_State_Wrapper temp_L = AAzureEntryPoint::Instance->GetL();
					if (!wlua || !temp_L)
						return;

					lua_rawgeti(temp_L, LUA_REGISTRYINDEX, callbackRef);
					wLua::lua_registry_handle::wlua_unref(temp_L, LUA_REGISTRYINDEX, callbackRef);
					if (lua_isnil(temp_L, -1))
					{
						lua_pop(temp_L, 1);
						return;
					}

					lua_pushvalue(temp_L, -1);	//-> cb, cb
					if (pAFile)
						lua_pushlightuserdata(temp_L, pAFile); //cb,cb,ret
					else
						lua_pushnil(temp_L);

					lua_pushboolean(temp_L, isStreaming ? 1 : 0);//cb,cb,ret,isStreaming

					bool bRet = false;
					{
#if STATS
						lua_pushvalue(temp_L, -3);//cb,cb,ret,isStreaming,cb
						lua_Debug ar;
						lua_getinfo(temp_L, ">S", &ar);//cb,cb,ret,isStreaming
						FString StatName = FString::Printf(TEXT("%s:%d"), UTF8_TO_TCHAR(ar.source), ar.linedefined);
						TStatId StatID = FDynamicStats::CreateStatId<FStatGroup_STATGROUP_AzureGroups>(StatName);
#endif
						SCOPE_CYCLE_COUNTER(STAT_ParallelInstanceAFileImageInLua);
#if STATS
						FScopeCycleCounter CycleCounter(StatID);
#endif

						bRet = wlua->PCallWithFunctionInfo(2, 0);	//-> cb, [err]
					}
					
					if(!isStreaming)
						delete pAFile;

					if (bRet)
					{
						lua_pop(temp_L, 1);
					}
					else
					{
						lua_pushvalue(temp_L, -2);
						FString info = wlua->GetFunctionInfo();
						FString errorInfo = FString::Printf(TEXT("@LoadCallBack:%s@@@%s"), *info, UTF8_TO_TCHAR(lua_tostring(temp_L, -1)));
						UE_LOG(LogAzure, Error, TEXT("LUA: %s"), *errorInfo);
						lua_pop(temp_L, 2);
					}
				}
			};

			lua_pushvalue(L, 2);//res,cb,cb
			wLua::lua_registry_handle callbackRefInner = wLua::lua_registry_handle::wlua_ref(L, LUA_REGISTRYINDEX); //res,cb
			InstanceResult * pResult = new InstanceResult();
			pResult->isStreaming = isStreaming;
			FGraphEventRef UserWidgetInstanceTask = TGraphTask<FParallelAFileImageInstanceTask>::CreateTask().ConstructAndDispatchWhenReady(pResult,ANSI_TO_TCHAR(resName));
			// set up a task to run on the game thread to accept the results
			FGraphEventArray Prerequistes;
			Prerequistes.Add(UserWidgetInstanceTask);
			FGraphEventRef TickCompletionEvent = TGraphTask<FParallelAFileImageInstanceCompletionTask>::CreateTask(&Prerequistes).ConstructAndDispatchWhenReady(callbackRefInner, pResult);

			return 0;
		}

		static int lua_AsyncLoadFileContent(lua_State * L)
		{
			const char * resName = luaL_checkstring(L, 1);
			if (!lua_isfunction(L, 2))
			{
				lua_pushstring(L, "lua_AsyncLoadAFile: second param must be function");
				lua_error(L);
				return 1;
			}

			struct InstanceResult
			{
				ABYTE * pBuffer;
				ADWORD len;
				InstanceResult() : pBuffer(nullptr),len(0)
				{
				}
			};

			class FParallelAFileImageInstanceTask
			{
				InstanceResult * pResult;
				FString fileName;
			public:
				FParallelAFileImageInstanceTask(InstanceResult * InpResult, TCHAR * InfileName) : pResult(InpResult), fileName(InfileName)
				{
				}

				TStatId GetStatId() const
				{
					RETURN_QUICK_DECLARE_CYCLE_STAT(FParallelAFileImageInstanceTask, STATGROUP_TaskGraphTasks);
				}
				static ENamedThreads::Type GetDesiredThread()
				{
					return ENamedThreads::AnyHiPriThreadHiPriTask;
				}
				static ESubsequentsMode::Type GetSubsequentsMode()
				{
					return ESubsequentsMode::TrackSubsequents;
				}

				void DoTask(ENamedThreads::Type CurrentThread, const FGraphEventRef& MyCompletionGraphEvent)
				{
					ABYTE* pBuffer;
					ADWORD nFileLength;
					if (exp_af_ReadFileAllBytes( TCHAR_TO_UTF8(*fileName), &pBuffer, &nFileLength))
					{
						pResult->pBuffer = pBuffer;
						pResult->len = nFileLength;
					}
				}
			};

			class FParallelAFileImageInstanceCompletionTask
			{
				InstanceResult * pResult;
				wLua::lua_registry_handle callbackRef;

			public:
				FParallelAFileImageInstanceCompletionTask(wLua::lua_registry_handle callback, InstanceResult * InResult) : callbackRef(callback), pResult(InResult)
				{
				}

				TStatId GetStatId() const
				{
					RETURN_QUICK_DECLARE_CYCLE_STAT(FParallelAFileImageInstanceCompletionTask, STATGROUP_TaskGraphTasks);
				}
				static ENamedThreads::Type GetDesiredThread()
				{
					return ENamedThreads::GameThread;
				}
				static ESubsequentsMode::Type GetSubsequentsMode()
				{
					return ESubsequentsMode::TrackSubsequents;
				}

				void DoTask(ENamedThreads::Type CurrentThread, const FGraphEventRef& MyCompletionGraphEvent)
				{
					ABYTE * pBuffer = pResult->pBuffer;
					AWORD len = pResult->len;
					delete pResult;

					struct _Holder
					{
						ABYTE * data;
						_Holder(ABYTE * _data) : data(_data) {}
						~_Holder() {
							if (data) exp_af_ReleaseFileBuffer(data);
						}
					}holder(pBuffer);

					if (!AAzureEntryPoint::Instance)
					{
						return;
					}

					wLua::Lua* wlua = AAzureEntryPoint::Instance->GetWLua();
					lua_State_Wrapper temp_L = AAzureEntryPoint::Instance->GetL();
					if (!wlua || !temp_L)
					{
						return;
					}

					lua_rawgeti(temp_L, LUA_REGISTRYINDEX, callbackRef);
					wLua::lua_registry_handle::wlua_unref(temp_L, LUA_REGISTRYINDEX, callbackRef);
					if (lua_isnil(temp_L, -1))
					{
						lua_pop(temp_L, 1);
						return;
					}

					lua_pushvalue(temp_L, -1);	//-> cb, cb
					if (!pBuffer)
						lua_pushnil(temp_L);
					else
					{
						lua_pushlstring(temp_L, (const char*)pBuffer, len);
					}

					bool bRet = false;
					{
#if STATS
						lua_pushvalue(temp_L, -3);//cb,cb,ret,isStreaming,cb
						lua_Debug ar;
						lua_getinfo(temp_L, ">S", &ar);//cb,cb,ret,isStreaming
						FString StatName = FString::Printf(TEXT("%s:%d"), UTF8_TO_TCHAR(ar.source), ar.linedefined);
						TStatId StatID = FDynamicStats::CreateStatId<FStatGroup_STATGROUP_AzureGroups>(StatName);
#endif
						SCOPE_CYCLE_COUNTER(STAT_ParallelInstanceAFileImageInLua);
#if STATS
						FScopeCycleCounter CycleCounter(StatID);
#endif

						bRet = wlua->PCallWithFunctionInfo(1, 0);	//-> cb, [err]
					}

					if (bRet)
					{
						lua_pop(temp_L, 1);
					}
					else
					{
						lua_pushvalue(temp_L, -2);
						FString info = wlua->GetFunctionInfo();
						FString errorInfo = FString::Printf(TEXT("@LoadCallBack:%s@@@%s"), *info, UTF8_TO_TCHAR(lua_tostring(temp_L, -1)));
						UE_LOG(LogAzure, Error, TEXT("LUA: %s"), *errorInfo);
						lua_pop(temp_L, 2);
					}
				}
			};

			lua_pushvalue(L, 2);//res,cb,cb
			wLua::lua_registry_handle callbackRefInner = wLua::lua_registry_handle::wlua_ref(L, LUA_REGISTRYINDEX); //res,cb
			InstanceResult * pResult = new InstanceResult();
			FGraphEventRef UserWidgetInstanceTask = TGraphTask<FParallelAFileImageInstanceTask>::CreateTask().ConstructAndDispatchWhenReady(pResult, ANSI_TO_TCHAR(resName));
			// set up a task to run on the game thread to accept the results
			FGraphEventArray Prerequistes;
			Prerequistes.Add(UserWidgetInstanceTask);
			FGraphEventRef TickCompletionEvent = TGraphTask<FParallelAFileImageInstanceCompletionTask>::CreateTask(&Prerequistes).ConstructAndDispatchWhenReady(callbackRefInner, pResult);

			return 0;
		}

		static int lua_GetFileModificationTimeStamp(lua_State * L)
		{
			FString FilePath = UTF8_TO_TCHAR(lua_tostring(L, 1));
			FDateTime modificationTime = IFileManager::Get().GetTimeStamp(*FilePath);
			int64 timeStamp = modificationTime.ToUnixTimestamp();
			lua_pushlstring(L, (const char*)&timeStamp, 8);
			return 1;
		}

		static int lua_GetCurrentTimeStamp(lua_State * L)
		{
			int64 timeStamp = FDateTime::UtcNow().ToUnixTimestamp();
			lua_pushlstring(L, (const char*)&timeStamp, 8);
			return 1;
		}

		static int lua_SetLevelMaterialQualityLevel(lua_State * L)
		{
			if (!AAzureEntryPoint::IsInit())
				return 0;

			UWorld* pWorld = AAzureEntryPoint::Instance->GetWorld();
			if (!pWorld)
				return 0;

			int32 qualityLv = (int32)luaL_checknumber(L, 1);
			EMaterialQualityLevel::Type levelEnum = (EMaterialQualityLevel::Type)qualityLv;
			bool force = lua_isnoneornil(L, 3) ? false : !!lua_toboolean(L, 2);
			bool bNoRemap = lua_isnoneornil(L, 4) ? false : !!lua_toboolean(L, 3);

			TArray<UActorComponent*> compsList;
			TArray<UMaterialInterface*> tempMatsList;
			for (TActorIterator<AActor> ActorItr(pWorld); ActorItr; ++ActorItr)
			{
				compsList.Reset();
				compsList = ActorItr->GetComponentsByClass(UPrimitiveComponent::StaticClass());

				for (UActorComponent *actorComp : compsList)
				{
					if (!IsValid(actorComp)) continue;

					UStaticMeshComponent *staticCom = Cast<UStaticMeshComponent>(actorComp);
					if (staticCom)
						staticCom->SetMaterialQualityLevel(levelEnum,force,bNoRemap);
					else
					{
						USkeletalMeshComponent * skeletalCom = Cast<USkeletalMeshComponent>(actorComp);
						if (skeletalCom)
							skeletalCom->SetMaterialQualityLevel(levelEnum, force, bNoRemap);
					}
				}
			}
			return 0;
		}

		int lua_AnimationUpdateRateInit(lua_State * L)
		{
			SkinnedAnimationUpdateRateSignificance::Instance().Init();
			return 0;
		}

		int lua_AnimationUpdateRateFini(lua_State * L)
		{

			SkinnedAnimationUpdateRateSignificance::Instance().Fini();
			return 0;
		}

		int lua_SetAnimationUpdateRateParams(lua_State * L)
		{
			if (!lua_istable(L, 1))
			{
				lua_pushstring(L, "SetAnimationUpdateRateParams #1 must be a table");
				lua_error(L);
				return 0;
			}

			TArray<float> params;
			lua_pushnil(L);
			while (lua_next(L, 1) != 0)
			{
				float value = (float)luaL_checknumber(L, -1);
				if (params.Num() % 2 == 0)
					value *= value;
				params.Add(value);
				lua_pop(L, 1);
			}
			if (params.Num() % 2)
			{
				lua_pushstring(L, "GAnimationUpdateRateDistanceParams must 2 multiply");
				lua_error(L);
			}
			SkinnedAnimationUpdateRateSignificance::Instance().SetDistanceParams(MoveTemp(params));
			return 0;
		}

		int lua_UpdateSignificance(lua_State * L)
		{
			AzureSignificance::Update();
			return 0;
		}

		int lua_GetHudRootUserWidget(lua_State * L)
		{
			if (!AAzureEntryPoint::IsInit())
				return 0;

			AzureHudTextMan *pMan = AAzureEntryPoint::Instance->GetHudTextMan();
			if (!pMan) {
				return 0;
			}
			UUserWidget *pHud = pMan->GetHudUserWidget();
			if (pHud != nullptr) {
				FLuaUtils::ReturnUObject(L, pHud);
				return 1;
			}

			return 0;
		}
		int lua_ManualJoystickCtrlInput(lua_State * L)
		{
			int n = 1;
			if (!lua_isnumber(L, n))
			{
				lua_pushstring(L, "lua_ManualCtrlInput: param 1 must be number");
				lua_error(L);
				return 0;
			}
			float horizontalInput = lua_tonumber(L, n++);

			if (!lua_isnumber(L, n))
			{
				lua_pushstring(L, "lua_ManualCtrlInput: param 2 must be number");
				lua_error(L);
				return 0;
			}
			float verticalInput = lua_tonumber(L, n++);

			AzureInputCtrl::GetInstance().InputAxis(EKeys::A, horizontalInput, 0.0f, 0, false);
			AzureInputCtrl::GetInstance().InputAxis(EKeys::W, verticalInput, 0.0f, 0, false);
			return 0;
		}

		int lua_BoxTraceSingle(lua_State* L)
		{
			UObject* WorldContextObject = wLua::FLuaUtils::GetUObject(L, 1, "Object");
			FVector Start = wLua::FLuaVector::Get(L, 2);
			FVector End = wLua::FLuaVector::Get(L, 3);
			FVector HalfSize = wLua::FLuaVector::Get(L, 4);
			FRotator Orientation = wLua::FLuaRotator::Get(L, 5);
			ECollisionChannel CollisionChannel = (ECollisionChannel)lua_touint(L, 6);
			ETraceTypeQuery TraceChannel = UCollisionProfile::Get()->ConvertToTraceType(CollisionChannel);
			bool bTraceComplex = !!lua_toboolean(L, 7);
			TArray<AActor*> ActorsToIgnore;
			if (lua_istable(L, 8))
			{
				lua_pushnil(L);
				while (lua_next(L, 8) != 0)
				{
					AActor* Obj = Cast<AActor>(wLua::FLuaUtils::GetUObject(L, -1, "Actor"));
					if (Obj) ActorsToIgnore.Add(Obj);
					lua_pop(L, 1);
				}
			}
			uint32 v = lua_touint(L, 9);
			EDrawDebugTrace::Type DrawDebugType = EDrawDebugTrace::None;
			switch (v) {
			case 3:
				DrawDebugType = EDrawDebugTrace::Persistent;
				break;
			case 2:
				DrawDebugType = EDrawDebugTrace::ForDuration;
				break;
			case 1:
				DrawDebugType = EDrawDebugTrace::ForOneFrame;
				break;
			default:
				DrawDebugType = EDrawDebugTrace::None;
				break;
			}
			bool bIgnoreSelf = !!lua_toboolean(L, 10);
			FLinearColor TraceColor = FLinearColor::Red;
			if(!lua_isnoneornil(L, 11)) wLua::FLuaLinearColor::Get(L, 11);
			FLinearColor TraceHitColor = FLinearColor::Green; 
			if (!lua_isnoneornil(L, 12)) TraceHitColor = wLua::FLuaLinearColor::Get(L, 12);
			float DrawTime = 5.0f;
			if(lua_isnumber(L, 13)) DrawTime = lua_tonumber(L, 13);

			FHitResult OutHit;
			bool ret = UKismetSystemLibrary::BoxTraceSingle(WorldContextObject, Start, End, HalfSize, Orientation,
				TraceChannel, bTraceComplex, ActorsToIgnore, 
				DrawDebugType, OutHit, bIgnoreSelf, TraceColor, TraceHitColor, DrawTime);
			
			if (ret) {
				return AzureUtility::pushFHitResult2Lua(L, OutHit, AzureUtility::isTraceAzureObjectChannel(CollisionChannel));
			}

			return 0;
		}

		int lua_BoxTraceMulti(lua_State* L)
		{
			UObject* WorldContextObject = wLua::FLuaUtils::GetUObject(L, 1, "Object");
			FVector Start = wLua::FLuaVector::Get(L, 2);
			FVector End = wLua::FLuaVector::Get(L, 3);
			FVector HalfSize = wLua::FLuaVector::Get(L, 4);
			FRotator Orientation = wLua::FLuaRotator::Get(L, 5);
			ECollisionChannel CollisionChannel = (ECollisionChannel)lua_touint(L, 6);
			ETraceTypeQuery TraceChannel = UCollisionProfile::Get()->ConvertToTraceType(CollisionChannel);
			bool bTraceComplex = !!lua_toboolean(L, 7);
			TArray<AActor*> ActorsToIgnore;
			if (lua_istable(L, 8))
			{
				lua_pushnil(L);
				while (lua_next(L, 8) != 0)
				{
					AActor* Obj = Cast<AActor>(wLua::FLuaUtils::GetUObject(L, -1, "Actor"));
					if (Obj) ActorsToIgnore.Add(Obj);
					lua_pop(L, 1);
				}
			}
			uint32 v = lua_touint(L, 9);
			EDrawDebugTrace::Type DrawDebugType = EDrawDebugTrace::None;
			switch (v) {
			case 3:
				DrawDebugType = EDrawDebugTrace::Persistent;
				break;
			case 2:
				DrawDebugType = EDrawDebugTrace::ForDuration;
				break;
			case 1:
				DrawDebugType = EDrawDebugTrace::ForOneFrame;
				break;
			default:
				DrawDebugType = EDrawDebugTrace::None;
				break;
			}
			bool bIgnoreSelf = !!lua_toboolean(L, 10);
			FLinearColor TraceColor = FLinearColor::Red;
			if (!lua_isnoneornil(L, 11)) wLua::FLuaLinearColor::Get(L, 11);
			FLinearColor TraceHitColor = FLinearColor::Green;
			if (!lua_isnoneornil(L, 12)) TraceHitColor = wLua::FLuaLinearColor::Get(L, 12);
			float DrawTime = 5.0f;
			if (lua_isnumber(L, 13)) DrawTime = lua_tonumber(L, 13);

			TArray<struct FHitResult> OutHits;
			UKismetSystemLibrary::BoxTraceMulti(WorldContextObject, Start, End, HalfSize, Orientation,
				TraceChannel, bTraceComplex, ActorsToIgnore,
				DrawDebugType, OutHits, bIgnoreSelf, TraceColor, TraceHitColor, DrawTime);

			lua_newtable(L);
			int index = 1;
			for (FHitResult &hit : OutHits)
			{
				AzureUtility::pushFHitResult2Lua(L, hit, AzureUtility::isTraceAzureObjectChannel(CollisionChannel));
				lua_rawseti(L, -2, index);
				index++;
			}
			return 1;
		}

		int lua_CapsuleTraceSingle(lua_State* L)
		{
			UObject* WorldContextObject = wLua::FLuaUtils::GetUObject(L, 1, "Object");
			FVector Start = wLua::FLuaVector::Get(L, 2);
			FVector End = wLua::FLuaVector::Get(L, 3);
			float Radius = (float)lua_tonumber(L, 4);
			float HalfHeight = (float)lua_tonumber(L, 5);
			ECollisionChannel CollisionChannel = (ECollisionChannel)lua_touint(L, 6);
			ETraceTypeQuery TraceChannel = UCollisionProfile::Get()->ConvertToTraceType(CollisionChannel);
			bool bTraceComplex = !!lua_toboolean(L, 7);
			TArray<AActor*> ActorsToIgnore;
			if (lua_istable(L, 8))
			{
				lua_pushnil(L);
				while (lua_next(L, 8) != 0)
				{
					AActor* Obj = Cast<AActor>(wLua::FLuaUtils::GetUObject(L, -1, "Actor"));
					if (Obj) ActorsToIgnore.Add(Obj);
					lua_pop(L, 1);
				}
			}
			uint32 v = lua_touint(L, 9);
			EDrawDebugTrace::Type DrawDebugType = EDrawDebugTrace::None;
			switch (v) {
			case 3:
				DrawDebugType = EDrawDebugTrace::Persistent;
				break;
			case 2:
				DrawDebugType = EDrawDebugTrace::ForDuration;
				break;
			case 1:
				DrawDebugType = EDrawDebugTrace::ForOneFrame;
				break;
			default:
				DrawDebugType = EDrawDebugTrace::None;
				break;
			}
			bool bIgnoreSelf = !!lua_toboolean(L, 10);
			FLinearColor TraceColor = FLinearColor::Red;
			if (!lua_isnoneornil(L, 11)) wLua::FLuaLinearColor::Get(L, 11);
			FLinearColor TraceHitColor = FLinearColor::Green;
			if (!lua_isnoneornil(L, 12)) TraceHitColor = wLua::FLuaLinearColor::Get(L, 12);
			float DrawTime = 5.0f;
			if (lua_isnumber(L, 13)) DrawTime = lua_tonumber(L, 13);

			FHitResult OutHit;
			bool ret = UKismetSystemLibrary::CapsuleTraceSingle(WorldContextObject, Start, End, Radius, HalfHeight,
				TraceChannel, bTraceComplex, ActorsToIgnore,
				DrawDebugType, OutHit, bIgnoreSelf, TraceColor, TraceHitColor, DrawTime);

			if (ret) {
				return AzureUtility::pushFHitResult2Lua(L, OutHit, AzureUtility::isTraceAzureObjectChannel(CollisionChannel));
			}

			return 0;
		}

		int lua_CapsuleTraceMulti(lua_State* L)
		{
			UObject* WorldContextObject = wLua::FLuaUtils::GetUObject(L, 1, "Object");
			FVector Start = wLua::FLuaVector::Get(L, 2);
			FVector End = wLua::FLuaVector::Get(L, 3);
			float Radius = (float)lua_tonumber(L, 4);
			float HalfHeight = (float)lua_tonumber(L, 5);
			ECollisionChannel CollisionChannel = (ECollisionChannel)lua_touint(L, 6);
			ETraceTypeQuery TraceChannel = UCollisionProfile::Get()->ConvertToTraceType(CollisionChannel);
			bool bTraceComplex = !!lua_toboolean(L, 7);
			TArray<AActor*> ActorsToIgnore;
			if (lua_istable(L, 8))
			{
				lua_pushnil(L);
				while (lua_next(L, 8) != 0)
				{
					AActor* Obj = Cast<AActor>(wLua::FLuaUtils::GetUObject(L, -1, "Actor"));
					if (Obj) ActorsToIgnore.Add(Obj);
					lua_pop(L, 1);
				}
			}
			uint32 v = lua_touint(L, 9);
			EDrawDebugTrace::Type DrawDebugType = EDrawDebugTrace::None;
			switch (v) {
			case 3:
				DrawDebugType = EDrawDebugTrace::Persistent;
				break;
			case 2:
				DrawDebugType = EDrawDebugTrace::ForDuration;
				break;
			case 1:
				DrawDebugType = EDrawDebugTrace::ForOneFrame;
				break;
			default:
				DrawDebugType = EDrawDebugTrace::None;
				break;
			}
			bool bIgnoreSelf = !!lua_toboolean(L, 10);
			FLinearColor TraceColor = FLinearColor::Red;
			if (!lua_isnoneornil(L, 11)) wLua::FLuaLinearColor::Get(L, 11);
			FLinearColor TraceHitColor = FLinearColor::Green;
			if (!lua_isnoneornil(L, 12)) TraceHitColor = wLua::FLuaLinearColor::Get(L, 12);
			float DrawTime = 5.0f;
			if (lua_isnumber(L, 13)) DrawTime = lua_tonumber(L, 13);

			TArray<struct FHitResult> OutHits;
			UKismetSystemLibrary::CapsuleTraceMulti(WorldContextObject, Start, End, Radius, HalfHeight,
				TraceChannel, bTraceComplex, ActorsToIgnore,
				DrawDebugType, OutHits, bIgnoreSelf, TraceColor, TraceHitColor, DrawTime);

			lua_newtable(L);
			int index = 1;
			for (FHitResult &hit : OutHits)
			{
				AzureUtility::pushFHitResult2Lua(L, hit, AzureUtility::isTraceAzureObjectChannel(CollisionChannel));
				lua_rawseti(L, -2, index);
				index++;
			}
			return 1;
		}

		int lua_SphereTraceSingle(lua_State* L)
		{
			UObject* WorldContextObject = wLua::FLuaUtils::GetUObject(L, 1, "Object");
			FVector Start = wLua::FLuaVector::Get(L, 2);
			FVector End = wLua::FLuaVector::Get(L, 3);
			float Radius = (float)lua_tonumber(L, 4);
			ECollisionChannel CollisionChannel = (ECollisionChannel)lua_touint(L, 5);
			ETraceTypeQuery TraceChannel = UCollisionProfile::Get()->ConvertToTraceType(CollisionChannel);
			bool bTraceComplex = !!lua_toboolean(L, 6);
			TArray<AActor*> ActorsToIgnore;
			if (lua_istable(L, 7))
			{
				lua_pushnil(L);
				while (lua_next(L, 7) != 0)
				{
					AActor* Obj = Cast<AActor>(wLua::FLuaUtils::GetUObject(L, -1, "Actor"));
					if (Obj) ActorsToIgnore.Add(Obj);
					lua_pop(L, 1);
				}
			}
			uint32 v = lua_touint(L, 8);
			EDrawDebugTrace::Type DrawDebugType = EDrawDebugTrace::None;
			switch (v) {
			case 3:
				DrawDebugType = EDrawDebugTrace::Persistent;
				break;
			case 2:
				DrawDebugType = EDrawDebugTrace::ForDuration;
				break;
			case 1:
				DrawDebugType = EDrawDebugTrace::ForOneFrame;
				break;
			default:
				DrawDebugType = EDrawDebugTrace::None;
				break;
			}
			bool bIgnoreSelf = !!lua_toboolean(L, 9);
			FLinearColor TraceColor = FLinearColor::Red;
			if (!lua_isnoneornil(L, 10)) wLua::FLuaLinearColor::Get(L, 10);
			FLinearColor TraceHitColor = FLinearColor::Green;
			if (!lua_isnoneornil(L, 11)) TraceHitColor = wLua::FLuaLinearColor::Get(L, 11);
			float DrawTime = 5.0f;
			if (lua_isnumber(L, 12)) DrawTime = lua_tonumber(L, 12);

			FHitResult OutHit;
			bool ret = UKismetSystemLibrary::SphereTraceSingle(WorldContextObject, Start, End, Radius,
				TraceChannel, bTraceComplex, ActorsToIgnore,
				DrawDebugType, OutHit, bIgnoreSelf, TraceColor, TraceHitColor, DrawTime);

			if (ret) {
				return AzureUtility::pushFHitResult2Lua(L, OutHit, AzureUtility::isTraceAzureObjectChannel(CollisionChannel));
			}

			return 0;
		}

		int lua_SphereTraceMulti(lua_State* L)
		{
			UObject* WorldContextObject = wLua::FLuaUtils::GetUObject(L, 1, "Object");
			FVector Start = wLua::FLuaVector::Get(L, 2);
			FVector End = wLua::FLuaVector::Get(L, 3);
			float Radius = (float)lua_tonumber(L, 4);
			ECollisionChannel CollisionChannel = (ECollisionChannel)lua_touint(L, 5);
			ETraceTypeQuery TraceChannel = UCollisionProfile::Get()->ConvertToTraceType(CollisionChannel);
			bool bTraceComplex = !!lua_toboolean(L, 6);
			TArray<AActor*> ActorsToIgnore;
			if (lua_istable(L, 7))
			{
				lua_pushnil(L);
				while (lua_next(L, 7) != 0)
				{
					AActor* Obj = Cast<AActor>(wLua::FLuaUtils::GetUObject(L, -1, "Actor"));
					if (Obj) ActorsToIgnore.Add(Obj);
					lua_pop(L, 1);
				}
			}
			uint32 v = lua_touint(L, 8);
			EDrawDebugTrace::Type DrawDebugType = EDrawDebugTrace::None;
			switch (v) {
			case 3:
				DrawDebugType = EDrawDebugTrace::Persistent;
				break;
			case 2:
				DrawDebugType = EDrawDebugTrace::ForDuration;
				break;
			case 1:
				DrawDebugType = EDrawDebugTrace::ForOneFrame;
				break;
			default:
				DrawDebugType = EDrawDebugTrace::None;
				break;
			}
			bool bIgnoreSelf = !!lua_toboolean(L, 9);
			FLinearColor TraceColor = FLinearColor::Red;
			if (!lua_isnoneornil(L, 10)) wLua::FLuaLinearColor::Get(L, 10);
			FLinearColor TraceHitColor = FLinearColor::Green;
			if (!lua_isnoneornil(L, 11)) TraceHitColor = wLua::FLuaLinearColor::Get(L, 11);
			float DrawTime = 5.0f;
			if (lua_isnumber(L, 12)) DrawTime = lua_tonumber(L, 12);

			TArray<struct FHitResult> OutHits;
			UKismetSystemLibrary::SphereTraceMulti(WorldContextObject, Start, End, Radius,
				TraceChannel, bTraceComplex, ActorsToIgnore,
				DrawDebugType, OutHits, bIgnoreSelf, TraceColor, TraceHitColor, DrawTime);

			lua_newtable(L);
			int index = 1;
			for (FHitResult &hit : OutHits)
			{
				AzureUtility::pushFHitResult2Lua(L, hit, AzureUtility::isTraceAzureObjectChannel(CollisionChannel));
				lua_rawseti(L, -2, index);
				index++;
			}
			return 1;
		}

		int lua_CapsuleTraceSingleWithQuat(lua_State* L)
		{
			UObject* WorldContextObject = wLua::FLuaUtils::GetUObject(L, 1, "Object");
			UWorld* pWorld = Cast<UWorld>(WorldContextObject);
			FVector Start = wLua::FLuaVector::Get(L, 2);
			FVector End = wLua::FLuaVector::Get(L, 3);
			FRotator Rot = wLua::FLuaRotator::Get(L, 4);
			float Radius = (float)lua_tonumber(L, 5);
			float HalfHeight = (float)lua_tonumber(L, 6);
			ECollisionChannel CollisionChannel = (ECollisionChannel)lua_touint(L, 7);
			bool bTraceComplex = !!lua_toboolean(L, 8);
			TArray<AActor*> ActorsToIgnore;
			if (lua_istable(L, 9))
			{
				lua_pushnil(L);
				while (lua_next(L, 9) != 0)
				{
					AActor* Obj = Cast<AActor>(wLua::FLuaUtils::GetUObject(L, -1, "Actor"));
					if (Obj) ActorsToIgnore.Add(Obj);
					lua_pop(L, 1);
				}
			}
			EDrawDebugTrace::Type DrawDebugType = EDrawDebugTrace::None;
			if (lua_isnumber(L, 10))
			{
				uint32 v = lua_touint(L, 10);
				switch (v) {
				case 3:
					DrawDebugType = EDrawDebugTrace::Persistent;
					break;
				case 2:
					DrawDebugType = EDrawDebugTrace::ForDuration;
					break;
				case 1:
					DrawDebugType = EDrawDebugTrace::ForOneFrame;
					break;
				default:
					DrawDebugType = EDrawDebugTrace::None;
					break;
				}
			}

			bool bIgnoreSelf = false;
			if(lua_isboolean(L, 11)) bIgnoreSelf = !!lua_toboolean(L, 11);

			FLinearColor TraceColor = FLinearColor::Red;
			if (!lua_isnoneornil(L, 12)) wLua::FLuaLinearColor::Get(L, 12);
			FLinearColor TraceHitColor = FLinearColor::Green;
			if (!lua_isnoneornil(L, 13)) TraceHitColor = wLua::FLuaLinearColor::Get(L, 13);
			float DrawTime = 5.0f;
			if (lua_isnumber(L, 14)) DrawTime = lua_tonumber(L, 14);

			FHitResult OutHit;
			bool ret = AzureUtility::CapsuleTraceSingle(pWorld, Start, End, Rot.Quaternion(), Radius, HalfHeight,
				CollisionChannel, bTraceComplex, ActorsToIgnore,
				DrawDebugType, OutHit, bIgnoreSelf, TraceColor, TraceHitColor, DrawTime);

			if (ret) {
				return AzureUtility::pushFHitResult2Lua(L, OutHit, AzureUtility::isTraceAzureObjectChannel(CollisionChannel));
			}

			return 0;
		}

		int lua_CapsuleTraceMultiWithQuat(lua_State* L)
		{
			UObject* WorldContextObject = wLua::FLuaUtils::GetUObject(L, 1, "Object");
			UWorld* pWorld = Cast<UWorld>(WorldContextObject);
			FVector Start = wLua::FLuaVector::Get(L, 2);
			FVector End = wLua::FLuaVector::Get(L, 3);
			FRotator Rot = wLua::FLuaRotator::Get(L, 4);
			float Radius = (float)lua_tonumber(L, 5);
			float HalfHeight = (float)lua_tonumber(L, 6);
			ECollisionChannel CollisionChannel = (ECollisionChannel)lua_touint(L, 7);
			bool bTraceComplex = !!lua_toboolean(L, 8);
			TArray<AActor*> ActorsToIgnore;
			if (lua_istable(L, 9))
			{
				lua_pushnil(L);
				while (lua_next(L, 9) != 0)
				{
					AActor* Obj = Cast<AActor>(wLua::FLuaUtils::GetUObject(L, -1, "Actor"));
					if (Obj) ActorsToIgnore.Add(Obj);
					lua_pop(L, 1);
				}
			}
			EDrawDebugTrace::Type DrawDebugType = EDrawDebugTrace::None;
			if (lua_isnumber(L, 10))
			{
				uint32 v = lua_touint(L, 10);
				switch (v) {
				case 3:
					DrawDebugType = EDrawDebugTrace::Persistent;
					break;
				case 2:
					DrawDebugType = EDrawDebugTrace::ForDuration;
					break;
				case 1:
					DrawDebugType = EDrawDebugTrace::ForOneFrame;
					break;
				default:
					DrawDebugType = EDrawDebugTrace::None;
					break;
				}
			}
			bool bIgnoreSelf = false;
			if (lua_isboolean(L, 11)) bIgnoreSelf = !!lua_toboolean(L, 11);

			FLinearColor TraceColor = FLinearColor::Red;
			if (!lua_isnoneornil(L, 12)) wLua::FLuaLinearColor::Get(L, 12);
			FLinearColor TraceHitColor = FLinearColor::Green;
			if (!lua_isnoneornil(L, 13)) TraceHitColor = wLua::FLuaLinearColor::Get(L, 13);
			float DrawTime = 5.0f;
			if (lua_isnumber(L, 14)) DrawTime = lua_tonumber(L, 14);

			TArray<struct FHitResult> OutHits;
			AzureUtility::CapsuleTraceMulti(pWorld, Start, End, Rot.Quaternion(), Radius, HalfHeight,
				CollisionChannel, bTraceComplex, ActorsToIgnore,
				DrawDebugType, OutHits, bIgnoreSelf, TraceColor, TraceHitColor, DrawTime);

			lua_newtable(L);
			int index = 1;
			for (FHitResult &hit : OutHits)
			{
				AzureUtility::pushFHitResult2Lua(L, hit, AzureUtility::isTraceAzureObjectChannel(CollisionChannel));
				lua_rawseti(L, -2, index);
				index++;
			}
			return 1;
		}

		int lua_FlushLog(lua_State* L)
		{
			GLog->Flush();
			return 0;
		}

		int lua_zlib_compress(lua_State* L)
		{
			size_t nLen = 0;
			const char* src = luaL_checklstring(L, 1, &nLen);

			TArray<char> arr;
			int nBufSize = exp_zlib_compressBound(nLen);
			arr.AddUninitialized(nBufSize + 1);

			if (exp_zlib_compress(src, (int)nLen, (unsigned char*)arr.GetData(), nBufSize))
			{
				lua_pushlstring(L, (const char*)arr.GetData(), nBufSize);
				return 1;
			}

			return 0;
		}

		int lua_zlib_uncompress(lua_State* L)
		{
			size_t nLen = 0;
			const char* pData = luaL_checklstring(L, 1, &nLen);
			int nOrigLen = luaL_checkinteger(L, 2);

			TArray<char> arr;
			arr.AddUninitialized(nOrigLen + 1);

			if (exp_zlib_uncompress(pData, (int)nLen, (unsigned char*)arr.GetData(), nOrigLen))
			{
				lua_pushlstring(L, (const char*)arr.GetData(), nOrigLen);
				return 1;
			}

			return 0;
		}

		static int lua_SetShipNeedCheckMoveBlock(lua_State* L)
		{
			bool b = !!lua_toboolean(L, 1);
			ACarrierCharacter::SetNeedCheckMoveBlock(b);
			return 0;
		}

		static int lua_SetScreenMovieSkippable(lua_State* L)
		{
			bool b = !!lua_toboolean(L, 1);
			GConfig->SetBool(TEXT("/Script/MoviePlayer.MoviePlayerSettings"), TEXT("bMoviesAreSkippable"), b, GGameIni);
			return 0;
		}

		static int lua_GetDefaultLocale(lua_State* L)
		{
			FString loc = UKismetSystemLibrary::GetDefaultLocale();
			lua_pushstring(L, TCHAR_TO_UTF8(*loc));
			return 1;
		}

		
		static int lua_GetLocalCurrencyCode(lua_State* L)
		{
			FString loc = UKismetSystemLibrary::GetLocalCurrencyCode();
			lua_pushstring(L, TCHAR_TO_UTF8(*loc));
			return 1;
		}

		static int AddInstanceComp(lua_State* L)
		{
			wLua::LuaUObjectUserData* userdata = nullptr;
			AActor* obj = Cast<AActor>(wLua::FLuaUtils::GetUObject(L, 1, "Actor", &userdata));
			if (!obj)
			{
				astring msg = astring("AddActorComponent: param 1 must be Actor ") + astring(userdata ? (userdata->uobj ? "has uobject" : "uobject is null") : "no userdata");
				lua_pushstring(L, msg.c_str());
				lua_error(L);
				return 1;
			}

			UActorComponent* comp = Cast<UActorComponent>(wLua::FLuaUtils::GetUObject(L, 2, "ActorComponent"));
			if (!comp)
			{
				astring msg = astring("AddActorComponent: param 2 must be ActorComponent!");
				lua_pushstring(L, msg.c_str());
				lua_error(L);
				return 1;
			}

			obj->AddInstanceComponent(comp);			
			return 0;
		}

		static int SetSimpleShadowComp(lua_State* L)
		{
			wLua::LuaUObjectUserData* userdata = nullptr;
			AGamePlayer* obj = Cast<AGamePlayer>(wLua::FLuaUtils::GetUObject(L, 1, "Actor", &userdata));
			if (!obj)
			{
				astring msg = astring("SetSimpleShadowComp: param 1 must be GamePlayer ") + astring(userdata ? (userdata->uobj ? "has uobject" : "uobject is null") : "no userdata");
				lua_pushstring(L, msg.c_str());
				lua_error(L);
				return 1;
			}

			USceneComponent* comp = Cast<USceneComponent>(wLua::FLuaUtils::GetUObject(L, 2, "SceneComponent"));
			if (!comp)
			{
				astring msg = astring("SetSimpleShadowComp: param 2 must be USceneComponent!");
				lua_pushstring(L, msg.c_str());
				lua_error(L);
				return 1;
			}

			if(obj)
				obj->SetSimpleShadow(comp);
			return 0;
		}
		static int GetCurrentTickGroup(lua_State* L)
		{
			if (!AAzureEntryPoint::IsInit())
				return 0;

			UWorld* World = AAzureEntryPoint::Instance->GetWorld();
			if (World)
			{
				lua_pushnumber(L, (int)World->TickGroup);
				return 1;
			}
			return 0;
		}


#if !UE_BUILD_SHIPPING
		int lua_dumpStaticMesh(lua_State * L)
		{		
			if (!AAzureEntryPoint::IsInit())
				return 0;

			UWorld* World = AAzureEntryPoint::Instance->GetWorld();
			if (World)
			{
				TSet<UStaticMeshComponent*> Comps;
				for (TActorIterator<AActor> ActorIt(World); ActorIt; ++ActorIt)
				{
					AActor* Actor = *ActorIt;
					UStaticMeshComponent* Comp = (UStaticMeshComponent*)( Actor->GetComponentByClass(UStaticMeshComponent::StaticClass()));
					if (Comp)
					{
						Comps.Add(Comp);
					}
				}

				TMap<FString, int32> filenamesRec;

				for (auto & com : Comps)
				{
					UStaticMesh * mesh = com->GetStaticMesh();
					if (mesh)
					{
						UObject * outer = mesh->GetOuter();
						if (outer)
						{
							FString s = outer->GetName();

							int32 * pValue = filenamesRec.Find(s);
							if (!pValue)
								filenamesRec.Add(s, 1);
							else
								filenamesRec.Emplace(s, *pValue + 1);
						}
					}
				}


				UE_LOG(LogAzure, Warning, TEXT("StaticMesh Count:%d  StaticMeshComponent Count:%d"), filenamesRec.Num(), Comps.Num());
				for (auto & pair : filenamesRec)
				{
					UE_LOG(LogAzure, Warning, TEXT("StaticMesh Filename: %s \t count:%d"), *pair.Key, pair.Value);
				}

			}


			return 0;
		}

		int lua_dumpMatDynamic(lua_State *L)
		{
			UClass * cls = UMaterialInstanceDynamic::StaticClass();
			TMap<FString, int32> filenamesRec;
			int total, caretotal;
			total = caretotal = 0;

			for (FObjectIterator It; It; ++It)
			{
				if (It->IsTemplate(RF_ClassDefaultObject))
				{
					continue;
				}

				if (GUObjectArray.IsDisregardForGC(*It))
				{
					continue;
				}

				if (It->IsRooted())
					continue;

				if (!It->IsA(cls))
					continue;

				UMaterialInstanceDynamic * matInst = Cast< UMaterialInstanceDynamic>(*It);
				++total;

				UMaterial * mat = matInst->GetMaterial();
				if (mat)
				{
					UObject * outer = mat->GetOuter();
					if (outer)
					{
						FString s = outer->GetName();
						++caretotal;

						int32 * pValue = filenamesRec.Find(s);
						if (!pValue)
							filenamesRec.Add(s, 1);
						else
							filenamesRec.Emplace(s, *pValue + 1);
					}
				}

			}

			UE_LOG(LogAzure, Warning, TEXT("InstanceDynamic Count:%d  total:%d"), caretotal, total);

			TArray<FString> keys;

			for (auto & pair : filenamesRec)
			{
				keys.Add(pair.Key);
			}
			keys.StableSort();

			for (auto& key : keys)
			{
				UE_LOG(LogAzure, Warning, TEXT("Material Filename: %s \t count:%d"), *key, filenamesRec[key] );

			}
			
			return 0;
		}
#endif

		extern const luaL_Reg Lib_GameUtil2_Funcs[] =
		{
#if !UE_BUILD_SHIPPING
			{ "dumpMatDynamic", lua_dumpMatDynamic},
			{ "dumpStaticMesh",lua_dumpStaticMesh},
#endif
			{ "SetLevelMQL", lua_SetLevelMaterialQualityLevel },
			{ "SetNPC_SiegeInfo", SetNPC_SiegeInfo },
			{ "SetNPC_StareInfo", SetNPC_StareInfo },
			{ "ReplaceAnim", ReplaceAnim },
			{ "CreateDebugSphereActor", CreateDebugSphereActor },
			{ "ShowDebugInfo", ShowDebugInfo },
			{ "GetImageBrushSize", lua_GetImageBrushSize },
			{ "SetAzureImageAutoSize", lua_SetAzureImageAutoSize },
			{ "CreateMotorComponent", CreateMotorComponent },
			{ "RegisterHotKey", lua_RegisterHotKey },
			{ "UnRegisterHotKey", lua_UnRegisterHotKey },
			{ "UnRegisterAllKey", lua_UnRegisterAllKey },
			{ "GetGamePlayerParam", GetGamePlayerParam },
			{ "SetGamePlayerParam", SetGamePlayerParam },
			{ "SetGamePlayerParam2", SetGamePlayerParam2 },
			{ "GetCommandLineParam", lua_GetCommandLineParam },
			{ "HasCommandLineParam", lua_HasCommandLineParam },
			{ "ExecProcess", lua_ExecProcess },
			{ "CallPanelEvent", CallPanelEvent },
			{ "SetMapWarnings", lua_SetMapWarnings },
			{ "SetGlobalParam", SetGlobalParam },
			{ "GetGlobalParam", GetGlobalParam },
			{ "CallObjectEvent", CallObjectEvent },
			{ "GetActorParam", GetActorParam },
			{ "SetActorParam", SetActorParam },
			{ "SetNPC_FaceTargetInfo", SetNPC_FaceTargetInfo },		
			{ "SetNPC_LookAt", SetNPC_LookAt }, 
			{ "SetHostLookAtNPC", SetHostLookAtNPC },
			{ "SweepSingleByChannel", SweepSingleByChannel },
			{ "CalRelativePosInfo", lua_CalRelativePosInfo },
			{ "CalcWorldTransformByRelative", lua_CalcWorldTransformByRelative },
			{ "CalcRelativeTransform", lua_CalcRelativeTransform },
			{ "GetLevelScriptObject", lua_GetLevelScriptObject },
			{ "GetLandscapeInfo", lua_GetLandscapeInfo },
			{ "BuildCurveFloat", lua_BuildCurveFloat },
			{ "CallMyAnimInstanceMethod", CallMyAnimInstanceMethod },
			
			{ "GetShaderPlatformName", GetShaderPlatformName },
			{ "GetShaderCacheMD5", GetShaderCacheMD5 },
			{ "IsShaderCacheExist", IsShaderCacheExist },
			{ "GetNumPrecompileShaderRemaining", GetNumPrecompileShaderRemaining },
			{ "GetShaderCacheSaveDir", GetShaderCacheSaveDir },
			{ "MergePipelineFileCaches", MergePipelineFileCaches },
			{ "ShowInstancedStaticMesh", lua_ShowInstancedStaticMesh },
			{ "GetAllSocketsByName", lua_GetAllSocketsByName },
			{ "PlayDynamicForceFeedback", lua_PlayDynamicForceFeedback },

			{"SetLevelActorsVisible", SetLevelActorsVisible},
			{"PredictProjectilePath_ByTraceChannel", PredictProjectilePath_ByTraceChannel},
			{"CalAngleByTwoUEDir", lua_CalAngleByTwoUEDir},		
			{"QuitGame", lua_QuitGame},		
#if PLATFORM_ANDROID		
			{"getDataDir", lua_getDataDir},
			{"AndroidRestart", lua_AndroidRestart },
#endif
			{"GetProjectSvnInfo", lua_GetProjectSvnInfo},
			{"CloseAFile", lua_CloseAFile},
			{"AsyncLoadAFile", lua_AsyncLoadAFile},
			{"AsyncLoadFileContent", lua_AsyncLoadFileContent},
			{"GetFileModificationTimeStamp", lua_GetFileModificationTimeStamp},
			{"GetCurrentTimeStamp", lua_GetCurrentTimeStamp},
			{"SetAnimationUpdateRateParams", lua_SetAnimationUpdateRateParams},
			{"UpdateSignificance",lua_UpdateSignificance},
			{"AnimationUpdateRateInit",lua_AnimationUpdateRateInit},
			{"AnimationUpdateRateFini",lua_AnimationUpdateRateFini},
			{"GetHudRootUserWidget", lua_GetHudRootUserWidget},
			{"ManualJoystickCtrlInput", lua_ManualJoystickCtrlInput},
			{"BoxTraceSingle", lua_BoxTraceSingle },
			{"BoxTraceMulti", lua_BoxTraceMulti },
			{"SphereTraceSingle", lua_SphereTraceSingle },
			{"SphereTraceMulti", lua_SphereTraceMulti },
			{"CapsuleTraceSingle", lua_CapsuleTraceSingle },
			{"CapsuleTraceMulti", lua_CapsuleTraceMulti },
			{"CapsuleTraceSingleWithQuat", lua_CapsuleTraceSingleWithQuat },
			{"CapsuleTraceMultiWithQuat", lua_CapsuleTraceMultiWithQuat },
			{"FlushLog", lua_FlushLog },
			{"CheckPosInWater", CheckPosInWater },
			{"CheckPosInWaterMap", CheckPosInWaterMap},
			{"FindNearestWaterEdge", FindNearestWaterEdge},
			{"zlib_compress", lua_zlib_compress},
			{"zlib_uncompress", lua_zlib_uncompress},
			{"SetShipNeedCheckMoveBlock", lua_SetShipNeedCheckMoveBlock },
			{"SetScreenMovieSkippable", lua_SetScreenMovieSkippable },
			{"GetDefaultLocale", lua_GetDefaultLocale },
			{"GetLocalCurrencyCode", lua_GetLocalCurrencyCode },
			{"AddInstanceComp", AddInstanceComp },
			{"SetSimpleShadowComp", SetSimpleShadowComp },
			{"GetCurrentTickGroup", GetCurrentTickGroup },
			{ NULL, NULL }
		};
	}
}