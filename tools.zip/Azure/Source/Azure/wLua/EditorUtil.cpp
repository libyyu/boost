/*
	编辑器中 (主要是 PIE 模式) 供 Lua 调用的编辑器函数
*/

#if WITH_EDITOR

#include "LuaInterface.h"
#include "Editor/EditorEngine.h"
#include "Engine/Selection.h"
#include "Framework/Application/SlateApplication.h"
#include "Kismet2/BlueprintEditorUtils.h"
#include "Kismet2/KismetEditorUtilities.h"
#include "AssetRegistryModule.h"
#include "FileHelpers.h"
#include "WidgetBlueprint.h"
#include "Blueprint/WidgetTree.h"
#include "AssetEditorManager.h"
#include "Engine/AssetManager.h"
#include "Kismet2/DebuggerCommands.h"
#include "UnrealEd/Public/UnrealEd.h"
#include "SlateHierarchy.h"
#include "LevelSequence.h"
#include "Sections/MovieSceneEventSection.h"
#include "CGTrackStruct.h"
#include "IDirectoryWatcher.h"
#include "DirectoryWatcherModule.h"
#include "Utilities/LevelSequenceActorEx.h"
#include "MovieSceneMediaTrack.h"
#include "MovieSceneMediaSection.h"
#include "MediaSource.h"
#include "FileMediaSource.h"
extern UNREALED_API UEditorEngine* GEditor;

namespace wLua
{
	namespace GameLuaInterface
	{
		static int lua_GetSelectedActors(lua_State* L)
		{
			lua_newtable(L);

			USelection* selectedActors = GEditor->GetSelectedActors();
			int iActor = 0;
			for (FSelectionIterator it(*selectedActors); it; ++it)
			{
				AActor* actor = Cast<AActor>(*it);
				if (actor)
				{
					++iActor;
					FLuaUtils::ReturnUObject(L, actor);
					lua_rawseti(L, -2, iActor);
				}
			}

			return 1;
		}

		static int lua_SelectActor(lua_State* L)
		{
			wLua::LuaUObjectUserData* userdata = nullptr;
			UObject* Obj = wLua::FLuaUtils::GetUObject(L,1,"Actor",&userdata);
			if(!Obj)
			{ wLua::LuaStatic::traceback(L,"Actor must be non-null"); lua_error(L);  return 0;}

			AActor * actor = (AActor *)Obj;

			bool bInSelect = lua_toboolean(L, 2) != 0;
			GEditor->SelectActor(actor, bInSelect, true);

			return 0;
		}

		static int lua_GetSelectedComponents(lua_State* L)
		{
			lua_newtable(L);

			USelection* selectedComponents = GEditor->GetSelectedComponents();
			int iComponent = 0;
			for (FSelectionIterator it(*selectedComponents); it; ++it)
			{
				UActorComponent* component = Cast<UActorComponent>(*it);
				if (component)
				{
					++iComponent;
					FLuaUtils::ReturnUObject(L, component);
					lua_rawseti(L, -2, iComponent);
				}
			}

			return 1;
		}

		static int lua_SelectComponent(lua_State* L)
		{
			wLua::LuaUObjectUserData* userdata = nullptr;
			UObject* Obj = wLua::FLuaUtils::GetUObject(L,1,"ActorComponent",&userdata);
			if(!Obj)
			{ wLua::LuaStatic::traceback(L,"ActorComponent must be non-null"); lua_error(L);  return 0;}

			UActorComponent * component = (UActorComponent *)Obj;

			bool bInSelect = lua_toboolean(L, 2) != 0;
			GEditor->SelectComponent(component, bInSelect, true);

			return 0;
		}

		static int lua_SelectNone(lua_State* L)
		{
			GEditor->SelectNone(true, true);
			return 0;
		}


		static int lua_GetSelectedObjects(lua_State* L)
		{
			lua_newtable(L);

			USelection* selectedObjects = GEditor->GetSelectedObjects();
			int iObject = 0;
			for (FSelectionIterator it(*selectedObjects); it; ++it)
			{
				UObject* obj = Cast<UObject>(*it);
				if (obj)
				{
					++iObject;
					FLuaUtils::ReturnUObject(L, obj);
					lua_rawseti(L, -2, iObject);
				}
			}

			return 1;
		}

		static int lua_EditObject(lua_State* L)
		{
			wLua::LuaUObjectUserData* userdata = nullptr;
			UObject* Obj = wLua::FLuaUtils::GetUObject(L,1,"Object",&userdata);
			if(!Obj)
			{ wLua::LuaStatic::traceback(L,"Param #1 must be non-null UObject"); lua_error(L);  return 0;}
			GEditor->EditObject(Obj);
			return 0;
		}

		static int lua_StopPIE(lua_State* L)
		{
			if (GEditor->PlayWorld != NULL)
			{
				GEditor->RequestEndPlayMap();
				FSlateApplication::Get().LeaveDebuggingMode();
			}

			return 0;
		}

		static int lua_CreatePackage(lua_State* L)
		{
			int n = 1;
			FString PackageName;
			const char* name = luaL_checkstring(L, n);
			PackageName = UTF8_TO_TCHAR(name);

			n++;
			UObject* InOuter = nullptr;
			if (lua_isuserdata(L, n))
			{
				InOuter = FLuaUtils::GetUObject(L, 1, "Object");
			}

			UPackage* Package = CreatePackage(InOuter, *PackageName);
			if (Package) {
				Package->MarkAsFullyLoaded();
				Package->FileName = FName(*PackageName);
			}

			FLuaUtils::ReturnUObject(L, Package);
			
			return 1;
		}

		static int lua_StaticDuplicateObject(lua_State* L)
		{
			int n = 1;
			UObject* SrcObject = nullptr;
			if (lua_isstring(L, n))
			{
				FString SrcPackageName;
				const char* name = luaL_checkstring(L, n);
				SrcPackageName = UTF8_TO_TCHAR(name);
				SrcObject = Cast<UObject>(LoadObject<UBlueprint>(nullptr, *SrcPackageName));
			}
			else
				SrcObject = FLuaUtils::GetUObject(L, n, "Object");

			ensure(SrcObject);
			n++;

			UObject* Package = FLuaUtils::GetUObject(L, n, "Object");
			ensure(Package);
			n++;

			FString BlueprintName = UTF8_TO_TCHAR(luaL_checkstring(L, n));
			n++;


			if (UObject* NewBP = StaticDuplicateObject(SrcObject, Package, FName(*BlueprintName)))
			{
				if (NewBP->IsA<UBlueprint>())
				{
					FKismetEditorUtilities::CompileBlueprint(Cast<UBlueprint>(NewBP));
				}

				//// Notify the asset registry
				FAssetRegistryModule::AssetCreated(NewBP);

				//FAssetEditorManager::Get().OpenEditorForAsset(NewBP);

				// Mark the package dirty...
				Package->MarkPackageDirty();

				FLuaUtils::ReturnUObject(L, NewBP);
			}

			return 1;
		}

		static int lua_SavePackage(lua_State* L)
		{
			UPackage* InPackage = Cast<UPackage>(FLuaUtils::GetUObject(L, 1, "Object"));
			ensure(InPackage);
			TArray<UPackage*> PackagesToSave;
			PackagesToSave.Add(InPackage);
			FEditorFileUtils::EPromptReturnCode code = FEditorFileUtils::PromptForCheckoutAndSave(PackagesToSave, true, /*bPromptToSave=*/ false);
			lua_pushinteger(L, (int)code);

			//bool b = UEditorLoadingAndSavingUtils::SavePackages(PackagesToSave, false);
			//lua_pushinteger(L, b ? 0 : 1);
			return 1;
		}

		static int lua_CheckoutPackage(lua_State* L)
		{
			UPackage* InPackage = Cast<UPackage>(FLuaUtils::GetUObject(L, 1, "Object"));
			ensure(InPackage);
			TArray<UPackage*> PackagesToCheckout;
			PackagesToCheckout.Add(InPackage);
			ECommandResult::Type code = FEditorFileUtils::CheckoutPackages(PackagesToCheckout, NULL, false);
			lua_pushinteger(L, (int)code);
			return 1;
		}

		static int lua_CompileBlueprint(lua_State* L)
		{
			UBlueprint* InBlueprint = Cast<UBlueprint>(FLuaUtils::GetUObject(L, 1, "Object"));
			ensure(InBlueprint);
			FKismetEditorUtilities::CompileBlueprint(InBlueprint);

			return 0;
		}

		static int lua_GetObjectAssetPath(lua_State* L)
		{
			UObject* Obj = Cast< UObject >(FLuaUtils::GetUObject(L, 1, "Object"));
			ensure(Obj);
			FAssetData Data;
			UObject *WidgetTree = Obj->GetOuter();
			UUserWidget *UserWidget = WidgetTree ? Cast<UUserWidget>(WidgetTree->GetOuter()) : nullptr;
			UObject* ClassObj = UserWidget ? UserWidget->GetClass()->ClassGeneratedBy : nullptr;
			UPackage* Package = ClassObj ? Cast<UPackage>(ClassObj->GetOuter()) : nullptr;
			lua_pushstring(L, Package ? TCHAR_TO_UTF8(*Package->FileName.ToString()) : "");
			return 1;
		}


		static int lua_GetWidgetBlueprintRootWidget(lua_State* L)
		{
			UWidgetBlueprint* Blueprint = Cast< UWidgetBlueprint >(FLuaUtils::GetUObject(L, 1, "Object"));
			ensure(Blueprint);

			UWidget* RootWidget = Blueprint->WidgetTree->RootWidget;
			FLuaUtils::ReturnUObject(L, RootWidget);
			return 1;
		}

		static int lua_SetWidgetBlueprintRootWidget(lua_State* L)
		{
			UWidgetBlueprint* Blueprint = Cast< UWidgetBlueprint >(FLuaUtils::GetUObject(L, 1, "Object"));
			ensure(Blueprint);

			UWidget* RootWidget = Cast< UWidget >(FLuaUtils::GetUObject(L, 2, "Widget"));
			ensure(RootWidget);

			Blueprint->WidgetTree->RootWidget = RootWidget;

			return 0;
		}

		static int lua_SetWidgetDisplayName(lua_State* L)
		{
			UWidget* Widget = Cast< UWidget >(FLuaUtils::GetUObject(L, 1, "Widget"));
			ensure(Widget);

			FString DisplayName;
			const char* name = luaL_checkstring(L, 2);
			DisplayName = UTF8_TO_TCHAR(name);

			Widget->SetDisplayLabel(DisplayName);

			return 0;
		}

		static int lua_SetHiddenInDesigner(lua_State* L)
		{
			UWidget* Widget = Cast< UWidget >(FLuaUtils::GetUObject(L, 1, "Widget"));
			ensure(Widget);

			bool hidden = lua_toboolean(L, 2);

			Widget->bHiddenInDesigner = hidden ? 1 : 0;

			return 0;
		}

		static int lua_OpenEditorForAsset(lua_State* L)
		{
			int n = 1;
			UObject* InObject = nullptr;
			if (lua_isstring(L, n))
			{
				FString SrcPackageName;
				const char* name = luaL_checkstring(L, n);
				SrcPackageName = UTF8_TO_TCHAR(name);
				InObject = Cast<UObject>(LoadObject<UBlueprint>(nullptr, *SrcPackageName));
			}
			else
				InObject = FLuaUtils::GetUObject(L, n, "Object");

			ensure(InObject);

			FAssetEditorManager::Get().OpenEditorForAsset(InObject);


			return 0;
		}

		static int lua_ReplaceBlueprint(lua_State* L)
		{
			UBlueprint* Blueprint = Cast< UBlueprint >(FLuaUtils::GetUObject(L, 1, "Object"));
			ensure(Blueprint);

			UBlueprint* Replacement = Cast< UBlueprint >(FLuaUtils::GetUObject(L, 2, "Object"));
			ensure(Replacement);

			UBlueprint* ReturnBlueprint = FKismetEditorUtilities::ReplaceBlueprint(Blueprint, Replacement);
			FLuaUtils::ReturnUObject(L, ReturnBlueprint);
			return 1;
		}

		static int lua_ReloadBlueprint(lua_State* L)
		{
			UBlueprint* Blueprint = Cast< UBlueprint >(FLuaUtils::GetUObject(L, 1, "Object"));
			ensure(Blueprint);
			
			UBlueprint* ReturnBlueprint = FKismetEditorUtilities::ReloadBlueprint(Blueprint);
			FLuaUtils::ReturnUObject(L, ReturnBlueprint);
			return 1;
		}

		static int lua_PausePlayInEditor(lua_State* L)
		{
			FPlayWorldCommandCallbacks::PausePlaySession_Clicked();
			return 0;
		}

		static int lua_IsEditorPaused(lua_State* L)
		{

			bool isPaused = GUnrealEd->PlayWorld ? GUnrealEd->PlayWorld->bDebugPauseExecution : false;

			lua_pushboolean(L, isPaused);
			return 1;
		}

		static int lua_SetPlaySessionPaused(lua_State* L)
		{
			bool b = !!lua_toboolean(L, 1);
			AAzureEntryPoint::Instance->SetPlaySessionPaused(b);
			return 0;
		}

		static void FindTextureDepends_Recursively(const IAssetRegistry& AssetRegistry, const FName& InPackageName, TArray<FName>& OutTextures, TSet<FName>& AlreadyProcessed)
		{
			auto IsTexturePackage = [&AssetRegistry](const FName& PackageName)
			{
				TArray<FAssetData> PackageAssetData;
				if (!AssetRegistry.GetAssetsByPackageName(PackageName, PackageAssetData, true))
				{
					UE_LOG(LogAzure, Fatal, TEXT("Failed to GetAssetByPackageName(%s)."), *PackageName.ToString());
				}

				for (const FAssetData& AssetData : PackageAssetData)
				{
					UClass* AssetClass = AssetData.GetClass();
					if (AssetClass && AssetClass->IsChildOf(UTexture::StaticClass()))
					{
						return true;
					}
				}
				return false;
			};

			if (AlreadyProcessed.Contains(InPackageName))
				return;

			AlreadyProcessed.Add(InPackageName);

			if (IsTexturePackage(InPackageName))
				OutTextures.Add(InPackageName);

			TArray<FName> dependencies;
			if (AssetRegistry.GetDependencies(InPackageName, dependencies, EAssetRegistryDependencyType::Packages))
			{
				for (FName& dependName : dependencies)
				{
					FindTextureDepends_Recursively(AssetRegistry, dependName, OutTextures, AlreadyProcessed);
				}
			}
		}

		static void FindTextureDepends(const IAssetRegistry& AssetRegistry, const FName& InPackageName, TArray<FName>& OutTextures)
		{
			TSet<FName> alreadyProcessed;
			FindTextureDepends_Recursively(AssetRegistry, InPackageName, OutTextures, alreadyProcessed);
		}

		static void FindAndroidMultiFormatTextures(const FName& packageName, TArray<FString>& OutTextures)
		{
			//	Initialize AssetRegister
			FAssetRegistryModule& AssetRegistryModule = FModuleManager::LoadModuleChecked<FAssetRegistryModule>(TEXT("AssetRegistry"));
			IAssetRegistry& AssetRegistry = AssetRegistryModule.Get();
			{
				AssetRegistry.SearchAllAssets(true);

				// Force directory watcher tick to register paths
				FDirectoryWatcherModule& DirectoryWatcherModule = FModuleManager::Get().LoadModuleChecked<FDirectoryWatcherModule>(TEXT("DirectoryWatcher"));
				DirectoryWatcherModule.Get()->Tick(-1.0f);
			}

			TArray<FName> Textures;
			FindTextureDepends(AssetRegistry, packageName, Textures);
			for (FName& packageNameTmp : Textures)
			{
				OutTextures.Add(packageNameTmp.ToString());
			}
		}

		static int lua_FindAndroidMultiFormatTextures(lua_State* L)
		{
			TArray<FString> OutTextures;
			FString packageName = UTF8_TO_TCHAR(luaL_checkstring(L, 1));
			FindAndroidMultiFormatTextures(FName(*packageName), OutTextures);
			lua_newtable(L);
			for (int i = 0; i < OutTextures.Num(); ++i)
			{
				lua_pushstring(L, TCHAR_TO_UTF8(*OutTextures[i]));
				lua_rawseti(L, -2, i + 1);
			}
			return 1;
		}

		static int lua_GetDefaultTouchInterface(lua_State* L)
		{
			FConfigFile InputIni;
			FString InterfaceFile;
			FConfigCacheIni::LoadLocalIniFile(InputIni, TEXT("Input"), true);
			if (InputIni.GetString(TEXT("/Script/Engine.InputSettings"), TEXT("DefaultTouchInterface"), InterfaceFile))
			{
				if (InterfaceFile != TEXT("None") && InterfaceFile != TEXT(""))
				{
					FString packageName = FPackageName::ObjectPathToPackageName(InterfaceFile);
					lua_pushstring(L, TCHAR_TO_UTF8(*packageName));
					return 1;
				}
			}
			return 0;
		}

		static int lua_GetLevelSequenceEvents(lua_State* L)
		{
			ULevelSequence* InSequence = (ULevelSequence*)wLua::FLuaUtils::GetUObject(L, 1, "LevelSequence");
			if (!InSequence)
			{
				wLua::LuaStatic::traceback(L, "LevelSequence must be non-null");
				lua_error(L);
				return 0;
			}
			UMovieScene* pMovieScene = InSequence->GetMovieScene();
			if (!pMovieScene)
			{
				wLua::LuaStatic::traceback(L, "MovieScene must be non-null");
				lua_error(L);
				return 0;
			}

			lua_newtable(L);

			int32 EventCount = 0;

			TArray<UMovieSceneSection*> AllSections = pMovieScene->GetAllSections();
			for (UMovieSceneSection* CurSection : AllSections)
			{
				UMovieSceneEventSection* EventSection = Cast<UMovieSceneEventSection>(CurSection);
				if (!EventSection)
				{
					continue;
				}
				TArrayView<const FEventPayload> Events = EventSection->GetEventData().GetKeyValues();
				for (const FEventPayload& Event : Events)
				{
					const FString& EventNameString = Event.EventName.ToString();
					if (!EventNameString.StartsWith(TEXT("CGEvent")))
					{
						continue;
					}

					FStructOnScope ParameterStruct(nullptr);
					Event.Parameters.GetInstance(ParameterStruct);
					const UStruct* EventParameterStruct = ParameterStruct.GetStruct();
					if (!EventParameterStruct)
					{
						continue;
					}

					uint8* EventParameterData = ParameterStruct.GetStructMemory();

					lua_newtable(L);

					const FString& StructName = EventParameterStruct->GetName();
					lua_pushstring(L, TCHAR_TO_UTF8(*StructName));
					lua_setfield(L, -2, "StructType");

					ALevelSequenceActorEx::lua_PushEventDataToLua(Cast<UProperty>(EventParameterStruct->Children), EventParameterData, L);
					lua_setfield(L, -2, "StructData");

					lua_rawseti(L, -2, ++EventCount);
				}
			}

			return 1;
		}

		static int lua_GetLevelSequenceHasProcessTrack(lua_State* L)
		{
			ULevelSequence* InSequence = (ULevelSequence*)wLua::FLuaUtils::GetUObject(L, 1, "LevelSequence");
			if (!InSequence)
			{
				wLua::LuaStatic::traceback(L, "LevelSequence must be non-null");
				lua_error(L);
				return 0;
			}

			AzureSequenceNodeHierarchy sequenceNodeHierarchy;
			sequenceNodeHierarchy.Init(InSequence);

			bool hasProssessableTrack = false;
			for (ShotSequenceNode &itemNode : sequenceNodeHierarchy.GetSequenceNodeArray())
			{
				if (!itemNode.movieScene.IsValid()) continue;

				int count = itemNode.movieScene->GetPossessableCount();
				for (int i = 0; i < count; ++i)
				{
					FMovieScenePossessable possessable = itemNode.movieScene->GetPossessable(i);
					// 需要是顶层轨道
					if (!possessable.GetParent().IsValid())
					{
						bool hasActiveTrack = false;
						for (const FMovieSceneBinding &binding : itemNode.movieScene->GetBindings())
						{
							if (binding.GetObjectGuid() != possessable.GetGuid()) continue;

							for (const auto& Track : binding.GetTracks())
							{
								for (const auto &section : Track->GetAllSections())
								{
									if (section->IsActive())
									{
										hasActiveTrack = true;
										break;
									}
									
								}
							}
							break;
						}
							
						if (hasActiveTrack)
						{
							hasProssessableTrack = true;
							break;
						}
					}
				}
				
			}


			lua_pushboolean(L, hasProssessableTrack);
			return 1;
		}

		struct MediaSourceInfo
		{
			FString className;
			FString url;
			FString filePath;	//only for UFileMediaSource

			void Init(UMediaSource* mediaSource)
			{
				className = mediaSource->GetClass()->GetName();
				url = mediaSource->GetUrl();
				if (UFileMediaSource* fileMediaSource = Cast<UFileMediaSource>(mediaSource))
				{
					filePath = fileMediaSource->GetFilePath();
				}
			}
		};

		static int lua_GetLevelSequenceReferenceMediaFileList(lua_State* L)
		{
			ULevelSequence* InSequence = (ULevelSequence*)wLua::FLuaUtils::GetUObject(L, 1, "LevelSequence");
			if (!InSequence)
			{
				wLua::LuaStatic::traceback(L, "LevelSequence must be non-null");
				lua_error(L);
				return 0;
			}

			AzureSequenceNodeHierarchy sequenceNodeHierarchy;
			sequenceNodeHierarchy.Init(InSequence);
			TArray<MediaSourceInfo> sourceList;
			bool hasProssessableTrack = false;
			for (ShotSequenceNode &itemNode : sequenceNodeHierarchy.GetSequenceNodeArray())
			{
				if (!itemNode.movieScene.IsValid()) continue;

				for ( UMovieSceneTrack * const track : itemNode.movieScene->GetMasterTracks())
				{
					UMovieSceneMediaTrack *mediaTrack = Cast<UMovieSceneMediaTrack>(track);
					if (!mediaTrack) continue;
					for (UMovieSceneSection *section : mediaTrack->GetAllSections())
					{
						UMovieSceneMediaSection *mediaSection = static_cast<UMovieSceneMediaSection *>(section);
						MediaSourceInfo& info = sourceList.AddDefaulted_GetRef();
						info.Init(mediaSection->MediaSource);
					}
				}
			}

			{
				lua_newtable(L); 
				int i = 1; 
				for (MediaSourceInfo const& sourceInfo : sourceList)
				{ 
					lua_newtable(L);
					lua_pushstring(L, TCHAR_TO_UTF8(*sourceInfo.className));
					lua_setfield(L, -2, "className");
					lua_pushstring(L, TCHAR_TO_UTF8(*sourceInfo.url));
					lua_setfield(L, -2, "url");
					lua_pushstring(L, TCHAR_TO_UTF8(*sourceInfo.filePath));
					lua_setfield(L, -2, "filePath");

					lua_rawseti(L, -2, i); 
					++i;
				}  
			}

			
			return 1;
		}

		extern const luaL_Reg Lib_EditorUtil_Funcs[] =
		{
			{ "GetSelectedActors", lua_GetSelectedActors },
			{ "SelectActor", lua_SelectActor },
			{ "GetSelectedComponents", lua_GetSelectedComponents },
			{ "SelectComponent", lua_SelectComponent },
			{ "SelectNone", lua_SelectNone },
			{ "GetSelectedObjects", lua_GetSelectedObjects },
			{ "EditObject", lua_EditObject },
			{ "StopPIE", lua_StopPIE },
			{ "CreatePackage", lua_CreatePackage },
			{ "StaticDuplicateObject", lua_StaticDuplicateObject },
			{ "SavePackage", lua_SavePackage },
			{ "CheckoutPackage", lua_CheckoutPackage },
			{ "GetWidgetBlueprintRootWidget", lua_GetWidgetBlueprintRootWidget },
			{ "SetWidgetBlueprintRootWidget", lua_SetWidgetBlueprintRootWidget },
			{ "CompileBlueprint", lua_CompileBlueprint },
			{ "SetWidgetDisplayName", lua_SetWidgetDisplayName },
			{ "SetHiddenInDesigner", lua_SetHiddenInDesigner },
			{ "OpenEditorForAsset", lua_OpenEditorForAsset },
			{ "GetObjectAssetPath", lua_GetObjectAssetPath },
			{ "ReplaceBlueprint", lua_ReplaceBlueprint },
			{ "ReloadBlueprint", lua_ReloadBlueprint },
			{ "PausePlayInEditor", lua_PausePlayInEditor },
			{ "IsEditorPaused", lua_IsEditorPaused },
			{ "SetPlaySessionPaused", lua_SetPlaySessionPaused },
			{ "FindAndroidMultiFormatTextures", lua_FindAndroidMultiFormatTextures },
			{ "GetDefaultTouchInterface", lua_GetDefaultTouchInterface },
			{ "GetLevelSequenceEvents", lua_GetLevelSequenceEvents },
			{ "GetLevelSequenceHasProcessTrack", lua_GetLevelSequenceHasProcessTrack },
			{ "GetLevelSequenceReferenceMediaFileList", lua_GetLevelSequenceReferenceMediaFileList },

			{ NULL, NULL }
		};
	}
}

#endif	//end #if WITH_EDITOR
