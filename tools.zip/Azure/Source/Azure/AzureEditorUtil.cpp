// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#if UE_EDITOR

#include "AzureEditorUtil.h"
#include "AzureEntryPoint.h"
#include "AzureExport.h"
#include "FileSystem/IPlatformAFileWrapper.h"
#include "Utilities/ECDebug.h"
#include "AFI.h"

#include "AssetRegistryModule.h"
#include "IDirectoryWatcher.h"
#include "DirectoryWatcherModule.h"
#include "Misc/ConfigCacheIni.h"

#include "LevelSequence.h"
#include "Sections/MovieSceneEventSection.h"
#include "CGTrackStruct.h"
#include "wLua/LuaInterface.h"
#include "wLua/wLuaRuntime.h"
#include "Utilities/ThreadJobForLua.h"
#include "Patcher/PackDLL.h"

static wLua::Lua* wlua = nullptr;
static ECDebug s_ECDebug;

extern void AzureLog(AzureLogType logType, const char* log);
extern void AzureException(const char* log);

static void SetupEntryPointConfig(const TArray<FString>& Tokens, const TArray<FString>& Switches, const TMap<FString, FString>& MapParams)
{
	lua_State_Wrapper L = wlua->GetL();
	lua_getglobal(L, "package");		//=> package
	lua_getfield(L, -1, "loaded");	//=> package, loaded
	lua_newtable(L);		//=> package, loaded, _EntryPointParams

	if (Tokens.Num() > 0)
	{
		lua_newtable(L);
		int i = 1;
		for (auto& token : Tokens)
		{
			lua_pushstring(L, TCHAR_TO_UTF8(*token));
			lua_rawseti(L, -2, i);
			i++;
		}
		lua_setfield(L, -2, "tokens");
	}

	if (Switches.Num() > 0)
	{
		lua_newtable(L);
		for (auto& s : Switches)
		{
			lua_pushboolean(L, 1);
			lua_setfield(L, -2, TCHAR_TO_UTF8(*s));
		}
		lua_setfield(L, -2, "switches");
	}

	if (MapParams.Num() > 0)
	{
		lua_newtable(L);
		for (auto keyValueIt = MapParams.CreateConstIterator(); keyValueIt; ++keyValueIt)
		{
			lua_pushstring(L, TCHAR_TO_UTF8(*keyValueIt.Value()));
			lua_setfield(L, -2, TCHAR_TO_UTF8(*keyValueIt.Key()));
		}
		lua_setfield(L, -2, "params");
	}

	//=> package, loaded, t
	lua_setfield(L, -2, "_EntryPointParams");	//=> packages
	lua_pop(L, 2);
}

namespace wLua
{
	class AzureLuaEditor : public AzureLuaBase
	{
		virtual void OnInit(lua_State * L) override
		{
			AzureLuaBase::OnInit(L);
			int nTop = lua_gettop(L);
			//ע�ὺˮ����
			wLua::Register(L);
			wLua::SetMtLink(L);
			GameLuaInterface::Register(L);

			lua_settop(L, nTop);
		}
		virtual void OnPreFini(lua_State * L) override
		{
			AzureLuaBase::OnPreFini(L);
		}
	};
}

wLua::Lua* FAzureEditorUtil::InitLuaEnv(const TArray<FString>& tokens, const TArray<FString>& switches, const TMap<FString, FString>& params)
{
	if (wlua != NULL)
		return wlua;

	exp_init_AzureLog((void*)AzureLog);
	exp_init_AzureException((void*)AzureException);

	// Only editor create AFilePackage here, game mode will in engine init
	FPlatformAFileWrapper::Init();
#if defined(AZURE_UE_TARGET_DEBUG) || defined(AZURE_UE_TARGET_DEBUGGAME)
	const bool debug = true;
#else
	const bool debug = false;
#endif
	wlua = new wLua::AzureLuaEditor();
	wlua->Init(wLua::Lua::OPENMODEMASK::ALL, debug, true);

	lua_State_Wrapper L = wlua->GetL();

	wLua::LuaStatic::setLuaPath("Lua");
	s_ECDebug.RegisterLogCallback(wlua);

	SetupEntryPointConfig(tokens, switches, params);

	int top = lua_gettop(L);
	check(top == 0);
	lua_pushboolean(L, 1);
	lua_setglobal(L, "GIsLuaCommandlet");
	top = lua_gettop(L);
	return wlua;
}

void FAzureEditorUtil::ReleaseEnv()
{
	if (wlua != NULL)
	{
		wlua->Fini();
		delete wlua;
		wlua = nullptr;
	}
}

int FAzureEditorUtil::Compress(const wchar_t *fn, const char* pData, int dataSize)
{
#if PLATFORM_WINDOWS
	return AFilePackage_CompressToFile(AFilePackage_CompressMethod::Zlib, fn, pData, dataSize);
#else
	return 0;
#endif
}

int FAzureEditorUtil::Compress_LZ4(const wchar_t *fn, const char* pData, int dataSize)
{
#if PLATFORM_WINDOWS
	return AFilePackage_CompressToFile(AFilePackage_CompressMethod::Lz4, fn, pData, dataSize);
#else
	return 0;
#endif
}

int FAzureEditorUtil::Compress_NoCompress(const wchar_t *fn, const char* pData, int dataSize)
{
#if PLATFORM_WINDOWS
	return AFilePackage_CompressToFile(AFilePackage_CompressMethod::None, fn, pData, dataSize);
#else
	return 0;
#endif
}

int FAzureEditorUtil::Compress_GetSepFileOriginalSize(const wchar_t *fn, a_int64& dataOriginalSize)
{
#if PLATFORM_WINDOWS
	return AFilePackage_Compress_GetSepFileOriginalSize(fn, dataOriginalSize);
#else
	return 0;
#endif
}

#endif