﻿// Fill out your copyright notice in the Description page of Project Settings.

using UnrealBuildTool;
using System;
using System.IO;    //  for System.IO.Path
using Tools.DotNETCommon;
public class Azure : ModuleRules
{
	public Azure(ReadOnlyTargetRules Target) : base(Target)
	{
        PCHUsage = PCHUsageMode.UseExplicitOrSharedPCHs;
        PublicDependencyModuleNames.AddRange(
            new string[] {
                "Core",
                "CoreUObject",
                "Engine",
                "InputCore",
                "UMG",
                "XmlParser",
                "UMGCustom",
                "MovieScene",
                "LevelSequence",
                "MovieSceneTracks",
                "CinematicCamera",
                "HTTP",
                "SlateRHIRenderer",
                "AIModule",
                "Renderer",
                "RenderCore",
                "RHI",
                "UtilityShaders",
                "Motor",
                "ApplicationCore",
                "Http",
                "Json",
                "JsonUtilities",
                "PhysXVehicles",
                "AkAudio",
                "OceanMeshRuntime",
                "NavigationSystem",
                "OVRLipSync",
                "Foliage",
                "OVRLipSync",
                "CableComponent",
                "WaterWave",
                "SignificanceManager",
                "ShaderCore",
				"ZLOfflineDownload",
				"AzureSlateFontMapping",
                "WebBrowserWidget",
                "MediaCompositing",
            }
            );

        if (Target.Configuration == UnrealTargetConfiguration.Debug)
        {
            PublicDefinitions.Add("AZURE_UE_TARGET_DEBUG");
        }

        if (Target.Configuration == UnrealTargetConfiguration.DebugGame)
        {
            PublicDefinitions.Add("AZURE_UE_TARGET_DEBUGGAME");
        }

        if (Target.Configuration == UnrealTargetConfiguration.Development)
        {
            PublicDefinitions.Add("AZURE_UE_TARGET_DEVELOPMENT");
        }

        if (Target.Configuration == UnrealTargetConfiguration.Shipping)
        {
            PublicDefinitions.Add("AZURE_UE_TARGET_SHIPPING");
        }

        if (Target.Type == TargetRules.TargetType.Editor)
        {
            PublicDependencyModuleNames.Add("UnrealEd");
            PublicDependencyModuleNames.Add("UMGEditor");
            PublicDependencyModuleNames.Add("SlateHierarchy");
        }

        if (Target.Platform == UnrealBuildTool.UnrealTargetPlatform.Win64 || Target.Platform == UnrealBuildTool.UnrealTargetPlatform.Win32)
        {
			PrivateDependencyModuleNames.Add("OpenGLDrv");
            AddEngineThirdPartyPrivateStaticDependencies(Target, new string[] { "OpenGL" });
		}

        if (Target.Platform == UnrealBuildTool.UnrealTargetPlatform.Android)
        {
            PublicDependencyModuleNames.Add("Launch");

            //  For visit FOpenGL::*** i.e. in AzureSystemInfo
            PrivateDependencyModuleNames.Add("OpenGLDrv");
            AddEngineThirdPartyPrivateStaticDependencies(Target, new string[] { "OpenGL" });
            PrivateDependencyModuleNames.Add("Azure3rdPlugin");
            var EngineDir = Path.GetFullPath(Target.RelativeEnginePath);
            PrivateIncludePaths.AddRange(
                new string[] {
                    Path.Combine(EngineDir, "Source/Runtime/OpenGLDrv/Private"),
                }
                );

            JsonObject jsonObj = null;
            bool PADDownloaderDisable = IsPluginDisable(ref jsonObj, "PADDownloader");
            bool GooglePADDisable = IsPluginDisable(ref jsonObj, "GooglePAD");

            if (!PADDownloaderDisable && !GooglePADDisable)
            {
                PublicDefinitions.Add("ENABLE_AAB=1");

                string PlayCoreIncludePath = Path.Combine(EngineDir, "Plugins/Runtime/GooglePAD/Source/ThirdParty/play-core-native-sdk/include");
                PrivateIncludePaths.Add(PlayCoreIncludePath);
                PublicIncludePaths.Add(PlayCoreIncludePath);

                PrivateDependencyModuleNames.Add("GooglePAD");

                System.Console.WriteLine(">>>> Plugin PADDownloader: Activated");
                System.Console.WriteLine(">>>> Plugin GooglePAD: Activated");
            }
            else
            {
                if (PADDownloaderDisable && GooglePADDisable)
                {
                    PublicDefinitions.Add("ENABLE_AAB=0");

                    System.Console.WriteLine(">>>> Plugin PADDownloader: Deactivated");
                    System.Console.WriteLine(">>>> Plugin GooglePAD: Deactivated");                    
                }
                else
                {
                    throw new System.Exception("PADDownloader and GooglePAD plugins must be deactivated.");
                }
            }
            jsonObj = null;
        }

        if( Target.Platform == UnrealBuildTool.UnrealTargetPlatform.IOS)
        {
            PrivateDependencyModuleNames.Add("AvfMedia");
        }
        
        PublicDefinitions.Add("ENABLE_FX_TRACK=1");
        PublicDefinitions.Add("ZLMSDK_GCLOUD");

        //PublicDefinitions.Add("AZURE_BUILD_WLUACHECK");
        //PublicDefinitions.Add("AZURE_LUA_OBJECT_TRACEBACK");

        PrivateDependencyModuleNames.AddRange(
            new string[] {
                "Slate",
                "SlateCore",
                "CGRuntimeX",
                "Engine",
                "AndroidPermission",
                //"GEM",
                "AkAudio",
                "UIParticle",
                "ProceduralMeshComponent",
                "Landscape",
                "MediaAssets",
				"TextAsset",
                "SignificanceManager",
                "Serialization",
                "UIParticleSystem",
                //"PandoraComponent",
                //"LiveVideoPlugin",
				"LuaAllocProfiler",
                "Projects"
            }
            );

        //tracy
        if (Target.Platform == UnrealBuildTool.UnrealTargetPlatform.Win64)
        {
            if (Target.Configuration == UnrealTargetConfiguration.Development && !Target.bUseMallocProfiler)
            {
                PrivateDependencyModuleNames.Add("Tracy");
                PrivateDefinitions.Add("TRACY_ENABLE");
            }
        }

        //luajit or lua51, ...
        var luaModule = GetLuaModuleType(Target);
        PublicDependencyModuleNames.Add(luaModule);
        System.Console.WriteLine("Module {0} Configuration {1} Platform {2} UseLuaType = {3}", Name, Target.Configuration, Target.Platform, luaModule);
        if(luaModule == "AzureLuaJIT")
        {
            linkLuaJIT();
        }

        //lua plugin
        PublicDependencyModuleNames.Add("wLuaCore");
        PublicDependencyModuleNames.Add("wLuaPlugin");
        //azure
        PublicDependencyModuleNames.Add("AzureCore");
        PublicDependencyModuleNames.Add("AzureEngine");
        PublicDependencyModuleNames.Add("AzureNetwork");
        PublicDependencyModuleNames.Add("AzureProfiler");
        //MainThreadTaskManager
        PrivateDependencyModuleNames.Add("MainThreadTaskManager");
        linkAzureEngine(Target);
        
        JsonObject jObj = null;

        //daizong
        if (!IsPluginDisable(ref jObj, "Daizong"))
        {
            PrivateDependencyModuleNames.Add("Daizong");
            System.Console.WriteLine(">>>> Plugin Daizong: Actived");
        }

        //GVoice
        if (!IsPluginDisable(ref jObj, "GVoice"))
        {
            PrivateDependencyModuleNames.Add("GVoice");
            System.Console.WriteLine(">>>> Plugin GVoice: Actived");
        }

        //msdk
        if (!IsPluginDisable(ref jObj, "ZulongGCloud"))
        {
            PrivateDependencyModuleNames.Add("ZulongGCloud");
            System.Console.WriteLine(">>>> Plugin ZulongGCloud: Actived");
        }

		//TCos
		if (!IsPluginDisable(ref jObj, "TCos"))
		{
            PrivateDependencyModuleNames.Add("TCos");
            System.Console.WriteLine(">>>> Plugin TCos: Actived");
		}

		//TSimuHelper
		if (!IsPluginDisable(ref jObj, "TSimuHelper"))
		{
            PrivateDependencyModuleNames.Add("TSimuHelper");
            System.Console.WriteLine(">>>> Plugin TSimuHelper: Actived");
		}

		//Pandora
		if (!IsPluginDisable(ref jObj, "Pandora"))
		{
            PrivateDependencyModuleNames.Add("Pandora");
            System.Console.WriteLine(">>>> Plugin Pandora: Actived");
		}

        //海外uni sdk
        if (!IsPluginDisable(ref jObj, "ZLSDKPlugin"))
        {
			PrivateDependencyModuleNames.Add("ZLSDKPlugin");
            System.Console.WriteLine(">>>> Plugin ZLSDKPlugin: Actived");
        }

		//海外pc sdk
        if (Target.Platform == UnrealBuildTool.UnrealTargetPlatform.Win32 || Target.Platform == UnrealBuildTool.UnrealTargetPlatform.Win64)
        {
            if (!IsPluginDisable(ref jObj, "LoongSDK"))
            {
				AddEngineThirdPartyPrivateStaticDependencies(Target, "OpenSSL");
                PrivateDependencyModuleNames.Add("LoongSDK");
				System.Console.WriteLine(">>>> Plugin LoongSDK: Actived");
            }
        }

        //海外Dzo sdk
        if (!IsPluginDisable(ref jObj, "UnrealSdk"))
        {
            PrivateDependencyModuleNames.Add("UnrealSdk");

            if (Target.Platform == UnrealTargetPlatform.Android)
            {
                PrivateDependencyModuleNames.AddRange(new string[] { "OnlineSubsystem" });
                DynamicallyLoadedModuleNames.AddRange(new string[] { "OnlineSubsystemGooglePlay", "OnlineSubsystemFacebook" });
            }

            System.Console.WriteLine(">>>> Plugin UnrealSdk(DzoSdk): Actived");
        }

        jObj = null;
    }

    public static string GetLuaModuleType(ReadOnlyTargetRules Target)
    {
        string luaprefix = "LUA_TYPE=";
        foreach (string Definition in Target.ProjectDefinitions)
        {
            if (Definition.StartsWith(luaprefix))
            {
                System.Console.WriteLine("  Project Definition: {0}", Definition);
                string luatype = Definition.Substring(luaprefix.Length);
                if ("0" == luatype)
                    return "AzureLuaJIT";
                else if ("1" == luatype)
                    return "AzureLua51";
                else
                {
                    throw new System.Exception("luatype:" + luatype + "not valid.");
                }
            }
        }
        return "AzureLuaJIT";
    }

    public bool linkAzureEngine(ReadOnlyTargetRules Target)
    {
        if (Target.Platform == UnrealBuildTool.UnrealTargetPlatform.Win64)
        {         
            PublicDefinitions.Add("_CRT_SECURE_NO_WARNINGS");
        }
        else if (Target.Platform == UnrealBuildTool.UnrealTargetPlatform.Win32)
        {
            PublicDefinitions.Add("_CRT_SECURE_NO_WARNINGS");
        }
        else if (Target.Platform == UnrealBuildTool.UnrealTargetPlatform.Android)
        {
            PublicDefinitions.Add("_ANDROID");

            // toolchain will filter
            PublicAdditionalLibraries.Add("jnigraphics");
            PublicAdditionalLibraries.Add("android");
        }
        else if (Target.Platform == UnrealBuildTool.UnrealTargetPlatform.IOS)
        {
            PublicDefinitions.Add("_IOS");
            PublicFrameworks.AddRange(new string[] { "CoreTelephony"});
        }
        else if (Target.Platform == UnrealBuildTool.UnrealTargetPlatform.Mac)
        {
            PublicDefinitions.Add("_IOS");
            PublicDefinitions.Add("_MACOSX");
            PublicDefinitions.Add("__MACOSX");
        }

        PublicIncludePaths.Add(ModuleDirectory + "/GameLogic/Network");
        PublicIncludePaths.Add(ModuleDirectory + "/GameLogic/Network/Protocols");
        PublicIncludePaths.Add(ModuleDirectory + "/GameLogic/Util");
        PublicIncludePaths.Add(ModuleDirectory + "/GameLogic/Main");
        PublicIncludePaths.Add(ModuleDirectory + "/Utilities");

        var EngineDir = Path.GetFullPath(Target.RelativeEnginePath);
        PublicIncludePaths.Add(Path.Combine(EngineDir, "Source/Runtime/Engine"));


        return true;
    }

    public void linkLuaJIT()
    {
        var ThirdPartyDirectory = ModuleDirectory + "/../../Plugins/LuaSrc/ThirdParty";
        if (Target.Platform == UnrealBuildTool.UnrealTargetPlatform.Win64)
        {
            if (Target.Configuration == UnrealTargetConfiguration.Debug ||
                Target.Configuration == UnrealTargetConfiguration.DebugGame)
            {
                var lib_path = Path.Combine(ThirdPartyDirectory, "bin/windows/x64/debug");
                PublicDelayLoadDLLs.Add("luajit.dll");
                RuntimeDependencies.Add(Path.Combine(lib_path, "luajit.dll"));
            }
            else
            {
                var lib_path = Path.Combine(ThirdPartyDirectory, "bin/windows/x64/release");
                PublicDelayLoadDLLs.Add("luajit.dll");
                RuntimeDependencies.Add(Path.Combine(lib_path, "luajit.dll"));
            }
        }
        else if (Target.Platform == UnrealBuildTool.UnrealTargetPlatform.Win32)
        {
            if (Target.Configuration == UnrealTargetConfiguration.Debug ||
                Target.Configuration == UnrealTargetConfiguration.DebugGame)
            {
                var lib_path = Path.Combine(ThirdPartyDirectory, "bin/windows/x86/debug");
                PublicDelayLoadDLLs.Add("luajit.dll");
                RuntimeDependencies.Add(Path.Combine(lib_path, "luajit.dll"));
            }
            else
            {
                var lib_path = Path.Combine(ThirdPartyDirectory, "bin/windows/x86/release");
                PublicDelayLoadDLLs.Add("luajit.dll");
                RuntimeDependencies.Add(Path.Combine(lib_path, "luajit.dll"));
            }
        }
    }

    //check if the plugin is disable only by Azure.uproject
    public bool IsPluginDisable(ref JsonObject jObj, string plugin_name)
    {
        if(jObj == null)
        {
            string filepath = System.IO.Path.Combine(ModuleDirectory, "../../Azure.uproject");
            jObj = JsonObject.Read(new FileReference(filepath));
        }
       
        JsonObject[] Plugins;
        if (jObj.TryGetObjectArrayField("Plugins", out Plugins))
        {
            for (int i = 0; i < Plugins.Length; ++i)
            {
                if (Plugins[i].GetStringField("Name") == plugin_name)
                {
                    return Plugins[i].GetBoolField("Enabled") == false;
                }
            }
        }

        //在Azure.uproject里面没有配置的，默认当做启用了
        {
            DirectoryReference dir = new DirectoryReference(System.IO.Path.Combine(ModuleDirectory, "../../Plugins/"));
            foreach (FileReference FileInfo in DirectoryReference.EnumerateFiles(dir, "*.uplugin", SearchOption.AllDirectories))
            {
                if (FileInfo.GetFileNameWithoutExtension() == plugin_name)
                {
                    string fpath = FileInfo.FullName;
                    JsonObject jPlugin = JsonObject.Read(new FileReference(fpath));
                    bool EnabledByDefault = true;
                    if (jPlugin.TryGetBoolField("EnabledByDefault", out EnabledByDefault) && !EnabledByDefault)
                    {//默认被禁用了
                        return true;
                    }

                    //uplugin里面没有禁用
                    return false;
                }
            }
        }

        { // 引擎的Plugins
            var EngineDir = Path.GetFullPath(Target.RelativeEnginePath);
            DirectoryReference dir = new DirectoryReference(System.IO.Path.Combine(EngineDir, "Plugins"));
            foreach (FileReference FileInfo in DirectoryReference.EnumerateFiles(dir, "*.uplugin", SearchOption.AllDirectories))
            {
                if (FileInfo.GetFileNameWithoutExtension() == plugin_name)
                {
                    string fpath = FileInfo.FullName;
                    JsonObject jPlugin = JsonObject.Read(new FileReference(fpath));
                    bool EnabledByDefault = true;
                    if (jPlugin.TryGetBoolField("EnabledByDefault", out EnabledByDefault) && !EnabledByDefault)
                    {//默认被禁用了
                        return true;
                    }

                    //uplugin里面没有禁用
                    return false;
                }
            }
        }

        //默认启用了
        return false;
    }
}
