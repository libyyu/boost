// Fill out your copyright notice in the Description page of Project Settings.

#include "DynamicTextureHelper.h"
#include "Materials/MaterialInstanceDynamic.h"
#include "ClearQuad.h"
#include "CanvasTypes.h"
#include "Engine/Canvas.h"
#include "SceneUtils.h"
#include "Kismet/KismetRenderingLibrary.h"
#include "Engine/Texture2DDynamic.h"
#include "Azure.h"

const int TEXTURE_SIZE = 16;

// Sets default values
ADynamicTextureHelper::ADynamicTextureHelper()
{
	// Set this actor to call Tick() every frame.  You can turn this off to improve performance if you don't need it.
	PrimaryActorTick.bCanEverTick = false;

	Texture = UTexture2DDynamic::Create(TEXTURE_SIZE, TEXTURE_SIZE, FTexture2DDynamicCreateInfo(PF_B8G8R8A8, false, true, TF_Nearest));
	Texture->UpdateResource();
}

// Called when the game starts or when spawned
void ADynamicTextureHelper::BeginPlay()
{
	Super::BeginPlay();

}

// Called every frame
void ADynamicTextureHelper::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);

}

static void WriteRawToTexture_RenderThread(FTexture2DDynamicResource* TextureResource, const TArray<uint8>& RawData, int32 PixelSize)
{
	check(IsInRenderingThread());

	FTexture2DRHIParamRef TextureRHI = TextureResource->GetTexture2DRHI();

	int32 Width = TextureRHI->GetSizeX();
	int32 Height = TextureRHI->GetSizeY();

	uint32 DestStride = 0;
	uint8* DestData = reinterpret_cast<uint8*>(RHILockTexture2D(TextureRHI, 0, RLM_WriteOnly, DestStride, false, false));

	for (int32 y = 0; y < Height; y++)
	{
		uint8* DestPtr = &DestData[(Height - 1 - y) * DestStride];

		const uint8* SrcPtr = &(RawData.GetData())[(Height - 1 - y) * Width * PixelSize];
		for (int32 x = 0; x < Width; x++)
		{
			for (int32 i = 0; i < PixelSize; i++)
				*DestPtr++ = *SrcPtr++;
		}
	}

	RHIUnlockTexture2D(TextureRHI, 0, false, false);
}

void ADynamicTextureHelper::WritePixels(const TArray<uint8>& RawData)
{
	int32 PixelSize = 4;
	ENQUEUE_UNIQUE_RENDER_COMMAND_THREEPARAMETER(
		FWriteRawDataToTexture,
		FTexture2DDynamicResource*, TextureResource, static_cast<FTexture2DDynamicResource*>(Texture->Resource),
		TArray<uint8>, RawData, RawData, int32, PixelSize, PixelSize,
		{
			WriteRawToTexture_RenderThread(TextureResource, RawData, PixelSize);
		});
}

UTexture2DDynamic* ADynamicTextureHelper::CreateDynamicTexture(uint32 nWidth, uint32 nHeight, EPixelFormat format)
{
	if (!GPixelFormats[format].Supported)
	{
		UE_LOG(LogAzure, Error, TEXT("Failed to create dynamic texture, format(%s) unsupported!"), GPixelFormats[format].Name);
		return nullptr;
	}

	UTexture2DDynamic* Texture = UTexture2DDynamic::Create(nWidth, nHeight, FTexture2DDynamicCreateInfo(format, false, true, TF_Nearest));
	Texture->UpdateResource();
	return Texture;
}

void ADynamicTextureHelper::WriteTexturePixels(UTexture2DDynamic* pTexture, const TArray<uint8>& RawData, uint32 PixelSize)
{
	ENQUEUE_UNIQUE_RENDER_COMMAND_THREEPARAMETER(
		FWriteRawDataToTexture,
		FTexture2DDynamicResource*, TextureResource, static_cast<FTexture2DDynamicResource*>(pTexture->Resource),
		TArray<uint8>, RawData, RawData, int32, PixelSize, PixelSize,
		{
			WriteRawToTexture_RenderThread(TextureResource, RawData, PixelSize);
		});
}