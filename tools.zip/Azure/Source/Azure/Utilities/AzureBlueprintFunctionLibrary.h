// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Public/SceneTypes.h"
#include "Kismet/BlueprintFunctionLibrary.h"
#include "Kismet/KismetSystemLibrary.h"
#include "AzureBlueprintFunctionLibrary.generated.h"

class FAnimationRuntime;


extern ENGINE_API void GAzureSetMaterialsQualityLevel(UWorld*, EMaterialQualityLevel::Type, bool, bool);
/**
 * 
 */
UCLASS()
class AZURE_API UAzureBlueprintFunctionLibrary : public UBlueprintFunctionLibrary
{
	GENERATED_BODY()

public:
	UFUNCTION(BlueprintCallable, Category = "Azure")
	static float ApproachTargetFloat(float curValue, float tarValue, float speed);

	UFUNCTION(BlueprintCallable, Category = "Azure")
	static void DecideFootIKOffset(float rawRightFootOffset, float rawLeftFootOffset, float &outCompZOffset, float &outRightFootOffset, float &outLeftFootOffset);

	UFUNCTION(BlueprintCallable, Category = "Azure")
	static void SetSkyBox(AActor *pSkyBox);

	UFUNCTION(BlueprintCallable, Category = "Azure")
	static AActor* GetSkyBox();

	UFUNCTION(BlueprintCallable, Category = "Azure")
	static int32 GetConsoleCommandValueInt(FString ConsoleCommand);

	UFUNCTION(BlueprintCallable, Category = "Azure")
	static bool CallLuaFunctionOI(FString FunctionName, UObject* Param1, int32 Param2);

	UFUNCTION(BlueprintCallable, Category = "Azure")
	static UCameraComponent* GetMainCameraComponent();

	UFUNCTION(BlueprintCallable, Category = "Azure")
	static AActor* GetHostModelActor();

	UFUNCTION(BlueprintCallable, Category = "Azure")
	static AActor* GetHostRootActor();

	UFUNCTION(BlueprintCallable, Category = "Azure")
	static FTransform GetComponentSpaceTransformRefPose(USkeletalMeshComponent* SkeletalMeshComponent, const int32 BoneIndex);


	UFUNCTION(BlueprintCallable, Category = "Azure", meta = (WorldContext = "WorldContextObject") )
	static void SetMaterialsQualityLevel(UObject* WorldContextObject, EMaterialQualityLevel::Type level, bool bForce, bool bExcludeInputWorld);

	UFUNCTION(BlueprintCallable, Category = "Azure")
	static void ExportRenderTextureToPNG(UTextureRenderTarget2D* RT, const FString& FilePath);

	UFUNCTION(BlueprintCallable, Category = "Azure")
	static void UpdateVertexBuffersFromOther(USkinnedMeshComponent* pSkeletalMeshComponenDest, USkinnedMeshComponent* pSkeletalMeshComponenSrc);

	UFUNCTION(BlueprintCallable, Category = "Azure")
	static void ClipboardCopy( const FString Str);

	UFUNCTION(BlueprintCallable, Category = "Azure")
	static void ClipboardPaste(FString& Dest);


	UFUNCTION(BlueprintPure, meta = (DisplayName = "Append With Tab(\t)", CommutativeAssociativeBinaryOperator = "true"), Category = "Utilities|String")
	static FString Concat_StrTabStr(const FString& A, const FString& B);

	UFUNCTION(BlueprintPure, meta = (DisplayName = "String Greater Than"), Category = "Utilities|String")
	static bool StringGreaterThan(const FString& A, const FString& B);
	/**
	 * Sweeps a capsule along the given line and returns the first blocking hit encountered.
	 * This trace finds the objects that RESPOND to the given TraceChannel
	 *
	 * @param WorldContext	World context
	 * @param Start			Start of line segment.
	 * @param End			End of line segment.
	 * @param Radius		Radius of the capsule to sweep
	 * @param HalfHeight	Distance from center of capsule to tip of hemisphere endcap.
	 * @param TraceChannel
	 * @param bTraceComplex	True to test against complex collision, false to test against simplified collision.
	 * @param OutHit		Properties of the trace hit.
	 * @return				True if there was a hit, false otherwise.
	 */
	UFUNCTION(BlueprintCallable, Category = "Azure", meta = (bIgnoreSelf = "true", WorldContext = "WorldContextObject", AutoCreateRefTerm = "ActorsToIgnore", DisplayName = "CapsuleTraceByChannelAndRotation", AdvancedDisplay = "TraceColor,TraceHitColor,DrawTime", Keywords = "sweep"))
	static bool CapsuleTraceSingle(UObject* WorldContextObject, const FVector Start, const FVector End, float Radius, float HalfHeight, ETraceTypeQuery TraceChannel, bool bTraceComplex, const TArray<AActor*>& ActorsToIgnore, EDrawDebugTrace::Type DrawDebugType, FHitResult& OutHit, bool bIgnoreSelf, FRotator Rot = FRotator::ZeroRotator, FLinearColor TraceColor = FLinearColor::Red, FLinearColor TraceHitColor = FLinearColor::Green, float DrawTime = 5.0f);

	UFUNCTION(BlueprintCallable, Category = "Debug")
	static FString EntryPointLuaTraceBack();

	UFUNCTION(BlueprintCallable, Category = "Azure")
	static bool GameInfo_GetBoolean(FString strExpression);

	UFUNCTION(BlueprintCallable, Category = "Azure")
	static int GameInfo_GetInt(FString strExpression);

	UFUNCTION(BlueprintCallable, Category = "Azure")
	static float GameInfo_GetFloat(FString strExpression);

	UFUNCTION(BlueprintCallable, Category = "Azure")
	static FString GameInfo_GetString(FString strExpression);

	/** Is world wrap enabled */
	UFUNCTION(BlueprintCallable, Category = "Azure")
	static bool IsWorldWrapEnabled();

	/** get world wrap center */
	UFUNCTION(BlueprintCallable, Category = "Azure")
	static FVector WorldGetUnwrapCenter();

	/** world wrap, wrap input position into WrapRect */
	UFUNCTION(BlueprintCallable, Category = "Azure")
	static FVector WorldWrapPosition(FVector const& position);

	/** world wrap, wrap input distance into WrapRect.Extend */
	UFUNCTION(BlueprintCallable, Category = "Azure")
	static FVector WorldWrapDistance(FVector const& distance);

	/** world wrap, unwrap input position to around UnwrapCenter */
	UFUNCTION(BlueprintCallable, Category = "Azure")
	static FVector WorldUnwrapPosition(FVector const& position);

	/** world wrap, calculate offset (multiplier of WrapRect size) when unwrap input position to around UnwrapCenter */
	UFUNCTION(BlueprintCallable, Category = "Azure")
	static void WorldGetUnwrapOffset(FVector const& position, int& xOffset, int&yOffset);

	UFUNCTION(BlueprintCallable, Category = "Azure")
	static void EnableSlateNavigation(bool bKeyNavigation, bool bTabNavigation, bool bAnalogNavigation);

};
