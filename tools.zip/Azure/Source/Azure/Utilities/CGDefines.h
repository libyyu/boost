// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "CGDefines.generated.h"

UENUM(BlueprintType)
enum class ECCGCameraTranstionType : uint8
{
	None = 0,
	Tween,
	//only use in transtion out, set end cg camera transform to game transform
	SetToGameCamera,
};

UENUM(BlueprintType)
enum class ECCGEventOp : uint8
{
	Begin = 0,
	End = 1,
};

UENUM(BlueprintType)
enum class ECCGQTEType : uint8
{
	None = 0,
	Dodge,
	Parachute,
	Jump,
	Jetpack,
	Hook,
	Getup,
};