#include "LuaCallback.h"

typedef LuaCallback::Callback LuaCallback_Callback;

static LuaCallback_Callback* ToCallback(lua_State* L, int index)
{
	void* callbackUd = lua_touserdata(L, index);
	LuaCallback_Callback* callback = reinterpret_cast<LuaCallback_Callback*>(callbackUd);
	return callback;
}

static int CallbackWrapper(lua_State* L)
{
	LuaCallback_Callback* callback = ToCallback(L, lua_upvalueindex(1));
	return (*callback)(L);
}

static int CallbackUd__gc(lua_State* L)
{
	LuaCallback_Callback* callback = ToCallback(L, 1);
	callback->~LuaCallback_Callback();
	return 0;
}

void LuaCallback::PushCallback(lua_State* L, Callback && callback)
{
	void* callbackUd = lua_newuserdata(L, sizeof(Callback));	//ud
	new(callbackUd) Callback(std::move(callback));	//replacement ��������
	lua_createtable(L, 0, 1);	//ud, meta
	lua_pushcfunction(L, CallbackUd__gc);	//ud, meta, gcFunc
	lua_setfield(L, -2, "__gc");	//ud, meta (meta.__gc = gcFunc)
	lua_setmetatable(L, -2);	//ud (ud.meta = meta)
	lua_pushcclosure(L, CallbackWrapper, 1);	//callback (up[1] = ud)
}

void LuaCallback::PushCallback(lua_State* L, Callback const& callback)
{
	Callback tempCallback = callback;
	PushCallback(L, std::move(tempCallback));
}

