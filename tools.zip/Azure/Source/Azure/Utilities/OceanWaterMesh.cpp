// Fill out your copyright notice in the Description page of Project Settings.

#include "OceanWaterMesh.h"

TSet< AOceanWaterMesh * > AOceanWaterMesh::s_insts;
// Sets default values
AOceanWaterMesh::AOceanWaterMesh()
{
 	// Set this actor to call Tick() every frame.  You can turn this off to improve performance if you don't need it.
	PrimaryActorTick.bCanEverTick = false;

}

// Called when the game starts or when spawned
void AOceanWaterMesh::BeginPlay()
{
	Super::BeginPlay();
	s_insts.Add(this);
}

void AOceanWaterMesh::EndPlay(const EEndPlayReason::Type EndPlayReason)
{
	s_insts.Remove(this);
	Super::EndPlay(EndPlayReason);
}


