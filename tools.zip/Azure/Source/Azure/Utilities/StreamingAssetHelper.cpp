#include "StreamingAssetHelper.h"
#include "Azure.h"
#include "AFI.h"

FString StreamingAssetHelper::m_DebugDir;
FString StreamingAssetHelper::m_StreamingAssetsPath;

avector<char> StreamingAssetHelper::ReadFileText(const TCHAR* filePath)
{
	avector<char> str;

	//UE_LOG(LogAzure, Log, TEXT("DebugDir:%s"), *m_DebugDir);


	if (!m_DebugDir.IsEmpty())
	{
		FString debugPath = m_DebugDir / filePath;
		const char* ansiPath = TCHAR_TO_UTF8(*debugPath);

		if (af_GetSepFileInfo(ansiPath) >= 0)
		{
			af_RawReadFileAllText(ansiPath, str);
			return str;
		}
	}

	FString fullPath = MakePath(filePath);

	//UE_LOG(LogAzure, Log, TEXT("MakePath2:%s"), *fullPath);

	af_RawReadFileAllText(TCHAR_TO_UTF8(*fullPath), str);
	return str;
}
