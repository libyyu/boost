// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "Engine/TextureRenderTarget2D.h"
#include "DynamicTextureHelper.generated.h"

class UTexture2DDynamic;

UCLASS()
class AZURE_API ADynamicTextureHelper : public AActor
{
	GENERATED_BODY()

public:
	// Sets default values for this actor's properties
	ADynamicTextureHelper();

protected:
	// Called when the game starts or when spawned
	virtual void BeginPlay() override;

public:
	// Called every frame
	virtual void Tick(float DeltaTime) override;

	static UTexture2DDynamic* CreateDynamicTexture(uint32 nWidth, uint32 nHeight, EPixelFormat format);
	static void WriteTexturePixels(UTexture2DDynamic* pTexture, const TArray<uint8>& RawData, uint32 PixelSize);

public:
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Texture")
	UTexture2DDynamic* Texture;

	UFUNCTION(BlueprintCallable, Category = "Azure")
	void WritePixels(const TArray<uint8>& RawData);
};
