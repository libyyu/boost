// Fill out your copyright notice in the Description page of Project Settings.

#include "CustomCharacterTexture.h"
#include "Materials/MaterialInstanceDynamic.h"
#include "ClearQuad.h"
#include "CanvasTypes.h"
#include "Engine/Canvas.h"
#include "SceneUtils.h"
#include "Kismet/KismetRenderingLibrary.h"


// Sets default values
ACustomCharacterTexture::ACustomCharacterTexture()
{
	// Set this actor to call Tick() every frame.  You can turn this off to improve performance if you don't need it.
	PrimaryActorTick.bCanEverTick = false;


}

// Called when the game starts or when spawned
void ACustomCharacterTexture::BeginPlay()
{
	Super::BeginPlay();
}

// Called every frame
void ACustomCharacterTexture::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);

}

UTextureRenderTarget2D* ACustomCharacterTexture::CreateCustomRenderTarget(bool bAutoGenerateMips, bool bHDR, int32 Resolution, bool bForceLinearGamma, UObject* InOuter)
{
	//renderTarget = UKismetRenderingLibrary::CreateRenderTarget2D(this, RTSize, RTSize);
	int RTSize = Resolution;

	UObject* outer = InOuter ? InOuter : GetTransientPackage();
	UTextureRenderTarget2D* renderTarget = NewObject<UTextureRenderTarget2D>(outer, MakeUniqueObjectName(outer, UTextureRenderTarget2D::StaticClass(), TEXT("CustomFaceRenderTarget")));
	check(renderTarget);
	renderTarget->RenderTargetFormat = ETextureRenderTargetFormat::RTF_RGBA8;
	renderTarget->bAutoGenerateMips = bAutoGenerateMips;
	renderTarget->bForceLinearGamma = bForceLinearGamma?1:0;
	renderTarget->InitAutoFormat(RTSize, RTSize);
	renderTarget->UpdateResourceImmediate(true);
	return renderTarget;
}

void ACustomCharacterTexture::DrawCustomTexture(UTextureRenderTarget2D* renderTarget, bool needClear)
{
	auto pWorld = GetWorld();

	//UKismetRenderingLibrary::DrawMaterialToRenderTarget(this, renderTarget, MaterialRT);
	if (pWorld && renderTarget && renderTarget->Resource && Material)
	{
		UCanvas* Canvas = pWorld->GetCanvasForDrawMaterialToRenderTarget();

		FCanvas RenderCanvas(
			renderTarget->GameThread_GetRenderTargetResource(),
			nullptr,
			pWorld,
			pWorld->FeatureLevel);

		Canvas->Init(renderTarget->SizeX, renderTarget->SizeY, nullptr, &RenderCanvas);
		Canvas->Update();



		TDrawEvent<FRHICommandList>* DrawMaterialToTargetEvent = new TDrawEvent<FRHICommandList>();

		FName RTName = renderTarget->GetFName();
		FTextureRenderTargetResource* RenderTargetResource = renderTarget->GameThread_GetRenderTargetResource();
		FLinearColor ClearColor = renderTarget->ClearColor;

		if (needClear)
		{
			ENQUEUE_RENDER_COMMAND(ClearRTCommand)(
				[RenderTargetResource, ClearColor](FRHICommandList& RHICmdList)
				{
					SetRenderTarget(RHICmdList, RenderTargetResource->GetRenderTargetTexture(), FTextureRHIRef(), true);
					DrawClearQuad(RHICmdList, ClearColor);
				});
		}

		ENQUEUE_RENDER_COMMAND(BeginDrawEventCommand)(
			[RTName, DrawMaterialToTargetEvent](FRHICommandList& RHICmdList)
		{
			BEGIN_DRAW_EVENTF(
				RHICmdList,
				DrawCanvasToTarget,
				(*DrawMaterialToTargetEvent),
				*RTName.ToString());
		});

		Canvas->K2_DrawMaterial(Material, FVector2D(0, 0), FVector2D(renderTarget->SizeX, renderTarget->SizeY), FVector2D(0, 0));

		RenderCanvas.Flush_GameThread();
		Canvas->Canvas = NULL;

		ENQUEUE_RENDER_COMMAND(CanvasRenderTargetResolveCommand)(
			[RenderTargetResource, DrawMaterialToTargetEvent](FRHICommandList& RHICmdList)
		{
			RHICmdList.CopyToResolveTarget(RenderTargetResource->GetRenderTargetTexture(), RenderTargetResource->TextureRHI, FResolveParams());
			STOP_DRAW_EVENT((*DrawMaterialToTargetEvent));
			delete DrawMaterialToTargetEvent;
		}
		);

		renderTarget->UpdateResourceImmediate(false);
	}
}
