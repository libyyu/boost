// 
// @author chenshilei
// @date 2020/1/13 18:17
//

#pragma once

#include "CoreMinimal.h"
#include "Kismet/BlueprintFunctionLibrary.h"
#include "SkeletalMeshHelper.generated.h"

/**
 * 
 */
UCLASS()
class AZURE_API USkeletalMeshHelper : public UBlueprintFunctionLibrary
{
	GENERATED_BODY()
	
public:
	// Get current vertex positions on mesh
	UFUNCTION(BlueprintCallable, Category = "SkeletalMesh")
	static bool GetAnimatedVertexLocations(USkeletalMeshComponent * Mesh, bool isWorldSpace, TArray<FVector>& Locations, bool IsUseHighLODModel);

	// Get vertext indices of triangles on mesh
	static bool GetTriangleIndices(USkeletalMeshComponent * Mesh, TArray<uint32>& TriangleIndices, bool IsUseHighLODModel);

	// Trace line to skeletal mesh and return hit position on mesh's triangle
	UFUNCTION(BlueprintCallable, Category = "SkeletalMesh")
	static bool LineTraceOnSkeletalMesh(USkeletalMeshComponent * Mesh, const FVector& StartPoint, const FVector& EndPoint, const FBox& InBoxBound, bool IsUseHighLODModel, FVector& OutHitPoint);

	// Intersct point of line and plane
	UFUNCTION(BlueprintCallable, Category = "SkeletalMesh")
	static bool GetPlaneLineIntersectPoint(const FVector& PlaneNormal, const FVector& PlanePoint, const FVector& LineVector, const FVector& LinePoint, FVector& OutPoint);

	// Determine whether point P in triangle ABC
	UFUNCTION(BlueprintCallable, Category = "SkeletalMesh")
	static bool IsPointinTriangle(const FVector& A, const FVector& B, const FVector& C, const FVector& P);

};
