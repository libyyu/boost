#pragma once

#include "CoreMinimal.h"

#if PLATFORM_WINDOWS || PLATFORM_ANDROID
#define HAS_AZURE_OPENGL_PBO 1
#else
#define HAS_AZURE_OPENGL_PBO 0
#endif

#if HAS_AZURE_OPENGL_PBO
#include "RHIResources.h"
#include "RenderResource.h"
#include "OpenGLDrv.h"

/** OpenGL PBO as RHI resource */
class FRHIAzureOpenGLPBO : public FRHIResource
{
public:
	//the pixel frame buffer for texture readback
	GLuint PboId;
	//Framebuffer id, frame buffer is needed as OpenGL ES has no glGetTexImage
	GLuint FboId;
	int32 DataSize;
	GLenum Usage;

	FRHIAzureOpenGLPBO()
		: PboId(0)
		, FboId(0)
		, DataSize(0)
		, Usage(0)
	{}

	FRHIAzureOpenGLPBO(int32 dataSize, GLenum usage, bool needFbo);

	~FRHIAzureOpenGLPBO();
};

typedef TRefCountPtr<FRHIAzureOpenGLPBO> FAzureOpenGLPBORef;

/** OpenGL PBO as render resource */
class FAzureOpenGLPBO : public FRenderResource
{
public:
	FAzureOpenGLPBORef PboRHI;

	FAzureOpenGLPBO() : PboRHI(nullptr)
	{}
	void ReleaseRHI() override
	{
		PboRHI.SafeRelease();
	}
};

//copy from OpenGLDrv RunOnGLRenderContextThread, fix link issue
void AzureRunOnGLRenderContextThread(TFunction<void(void)> GLFunc, bool bWaitForCompletion = false);

#endif	//HAS_AZURE_OPENGL_PBO
