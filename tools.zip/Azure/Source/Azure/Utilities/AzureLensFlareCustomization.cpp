// Copyright 1998-2017 Epic Games, Inc. All Rights Reserved.

#include "AzureLensFlareCustomization.h"
#if WITH_EDITOR
#include "Widgets/DeclarativeSyntaxSupport.h"
#include "PropertyHandle.h"
#include "Widgets/Input/SComboBox.h"
#include "Widgets/Input/SButton.h"
#include "DetailWidgetRow.h"
#include "AzureLensFlare.h"
#include "Engine/Texture2D.h"
#include "Widgets/Layout/SBorder.h"
#include "Widgets/Layout/SSpacer.h"
#include "Widgets/Images/SImage.h"
#include "Widgets/Text/STextBlock.h"
#include "Widgets/Layout/SBox.h"
#include "Widgets/Layout/SUniformGridPanel.h"
#include "Widgets/Input/SComboBox.h"
#include "UObject/UnrealType.h"
#include "IDetailGroup.h"
#include "IDetailPropertyRow.h"
#include "DetailLayoutBuilder.h"
#include "IDetailChildrenBuilder.h"
/* IPropertyTypeCustomization interface
*****************************************************************************/

void AzureLensFlareCustomization::CustomizeHeader(TSharedRef<class IPropertyHandle> StructPropertyHandle, class FDetailWidgetRow& HeaderRow, IPropertyTypeCustomizationUtils& StructCustomizationUtils)
{
	
}


static void SetupAtlasPicker(AAzureLensFlare *Flare, TSharedRef<IPropertyHandle> StructPropertyHandle, IDetailChildrenBuilder& StructBuilder)
{
	
	class FAtlasPicker
	{
	public:
		TSharedPtr<IPropertyHandle> StructPropertyHandle;
		int32 TextureWidth;
		int32 TextureHeight;
		TSharedPtr<SBox> ComboBoxContent;
		TArray<TSharedPtr<FString>> Options;
		TMap<FName, FSlateBrush> SlateBrushs;
		AAzureLensFlare *Flare;
		TArray<FAZURE_FLARE_TEXTURE_TYPE> ElementTypes;
		void SetUV(int sub_idx)
		{
			if (sub_idx >= 0 && sub_idx < ElementTypes.Num())
			{

				TSharedPtr<IPropertyHandle> uProperty = StructPropertyHandle->GetChildHandle(TEXT("u"));
				uProperty->SetValue(ElementTypes[sub_idx].uv[0]);
				TSharedPtr<IPropertyHandle> vProperty = StructPropertyHandle->GetChildHandle(TEXT("v"));
				vProperty->SetValue(ElementTypes[sub_idx].uv[1]);
				TSharedPtr<IPropertyHandle> usProperty = StructPropertyHandle->GetChildHandle(TEXT("us"));
				usProperty->SetValue(ElementTypes[sub_idx].uvs[0]);
				TSharedPtr<IPropertyHandle> vsProperty = StructPropertyHandle->GetChildHandle(TEXT("vs"));
				vsProperty->SetValue(ElementTypes[sub_idx].uvs[1]);
			}
			StructPropertyHandle->NotifyPreChange();
			StructPropertyHandle->NotifyPostChange(EPropertyChangeType::ValueSet);
		}
		void OnSelectionChanged(TSharedPtr<FString> InItem, ESelectInfo::Type InSelectionType)
		{
			if (!InItem.IsValid())
				return;
			if (!StructPropertyHandle.IsValid())
				return;

			TArray<void*> RawData;
			StructPropertyHandle->AccessRawData(RawData);
			if (RawData.Num() == 0)
				return;

			FSlateBrush *SlateBrush = (FSlateBrush*)RawData[0];
			if (SlateBrush == nullptr)
				return;
			/*	StructPropertyHandle->NotifyPreChange();
				SlateBrush->SetAtlasName(**InItem);
				StructPropertyHandle->NotifyPostChange(EPropertyChangeType::ValueSet);*/

			if (!ComboBoxContent.IsValid())
				return;

			ComboBoxContent->SetContent(OnGenerateWidget(InItem));
			TSharedPtr<IPropertyHandle> sub_idxProperty = StructPropertyHandle->GetChildHandle(TEXT("sub_idx"));
			int sub_idx = FCString::Atoi(**InItem.Get());
			sub_idxProperty->SetValue(sub_idx);
			SetUV(sub_idx);
		}
		TSharedRef<SWidget> OnGenerateWidget(TSharedPtr<FString> InItem)
		{
			if (!InItem.IsValid())
				return SNullWidget::NullWidget;
			return OnGenerateWidget(*InItem);
		}
		TSharedRef<SWidget> OnGenerateWidget(const FString& InItem)
		{
			if (SlateBrushs.Num() == 0)
				return SNullWidget::NullWidget;

			const FSlateBrush *SlateBrush = SlateBrushs.Find(*InItem);
			if (SlateBrush == nullptr)
				return SNullWidget::NullWidget;

			return SNew(SHorizontalBox)
				+ SHorizontalBox::Slot()
				.AutoWidth()
				.HAlign(HAlign_Center)
				.VAlign(VAlign_Center)
				[
					SNew(SImage)
					.Image(SlateBrush)
				]
			+ SHorizontalBox::Slot()
				//.AutoWidth()
				.HAlign(HAlign_Center)
				.VAlign(VAlign_Center)
				[
					SNew(SBox)
					.HAlign(HAlign_Center)
				.VAlign(VAlign_Center)
				[
					SNew(STextBlock)
					.Text(FText::FromString(InItem))
				.Justification(ETextJustify::Center)
				]
				];
		}
		void Init(AAzureLensFlare *_Flare)
		{
			Flare = _Flare;

			UTexture2D* InTexture2D = Cast<UTexture2D>(Flare->LensFlareBokehShape);
			if (InTexture2D == nullptr)
				return;

			
			ElementTypes.Empty();
			switch (Flare->ElementType)
			{
			case EAZURE_FLARE_ELEMENT_TYPE::Default:
				ElementTypes.Add(FAZURE_FLARE_TEXTURE_TYPE(0.75f, 0.25f, 0.25f, 0.25f));

				ElementTypes.Add(FAZURE_FLARE_TEXTURE_TYPE(0.25f, 0.5f, 0.25f, 0.25f));
				ElementTypes.Add(FAZURE_FLARE_TEXTURE_TYPE(0.5f, 0.5f, 0.5f, 0.5f));

				ElementTypes.Add(FAZURE_FLARE_TEXTURE_TYPE(0.0f, 0.0f, 0.25f, 0.25f));
				ElementTypes.Add(FAZURE_FLARE_TEXTURE_TYPE(0.25f, 0.0f, 0.25f, 0.25f));
				ElementTypes.Add(FAZURE_FLARE_TEXTURE_TYPE(0.0f, 0.0f, 0.25f, 0.25f));
				ElementTypes.Add(FAZURE_FLARE_TEXTURE_TYPE(0.5f, 0.0f, 0.25f, 0.25f));
				ElementTypes.Add(FAZURE_FLARE_TEXTURE_TYPE(0.75f, 0.0f, 0.25f, 0.25f));

				ElementTypes.Add(FAZURE_FLARE_TEXTURE_TYPE(0.75f, 0.0f, 0.25f, 0.25f));
				ElementTypes.Add(FAZURE_FLARE_TEXTURE_TYPE(0.5f, 0.0f, 0.25f, 0.25f));
				ElementTypes.Add(FAZURE_FLARE_TEXTURE_TYPE(0.5f, 0.0f, 0.25f, 0.25f));
				ElementTypes.Add(FAZURE_FLARE_TEXTURE_TYPE(0.5f, 0.0f, 0.25f, 0.25f));

				ElementTypes.Add(FAZURE_FLARE_TEXTURE_TYPE(0.0f, 0.5f, 0.25f, 0.25f));
				ElementTypes.Add(FAZURE_FLARE_TEXTURE_TYPE(0.25f, 0.25f, 0.25f, 0.25f));
				ElementTypes.Add(FAZURE_FLARE_TEXTURE_TYPE(0.5f, 0.25f, 0.25f, 0.25f));
		
				break;
			case EAZURE_FLARE_ELEMENT_TYPE::Element4:
				ElementTypes.Add(FAZURE_FLARE_TEXTURE_TYPE(0.0f, 0.0f, 0.5f, 0.5f));
				ElementTypes.Add(FAZURE_FLARE_TEXTURE_TYPE(0.5f, 0.0f, 0.5f, 0.5f));
				ElementTypes.Add(FAZURE_FLARE_TEXTURE_TYPE(0.0f, 0.5f, 0.5f, 0.5f));
				ElementTypes.Add(FAZURE_FLARE_TEXTURE_TYPE(0.5f, 0.5f, 0.5f, 0.5f));
			
				break;
			case EAZURE_FLARE_ELEMENT_TYPE::Element5:
				ElementTypes.Add(FAZURE_FLARE_TEXTURE_TYPE(0.0f, 0.0f, 1.0f, 0.5f));

				ElementTypes.Add(FAZURE_FLARE_TEXTURE_TYPE(0.0f, 0.5f, 0.5f, 0.25f));
				ElementTypes.Add(FAZURE_FLARE_TEXTURE_TYPE(0.0f, 0.75f, 0.5f, 0.25f));
				ElementTypes.Add(FAZURE_FLARE_TEXTURE_TYPE(0.5f, 0.5f, 0.5f, 0.25f));
				ElementTypes.Add(FAZURE_FLARE_TEXTURE_TYPE(0.5f, 0.75f, 0.5f, 0.25f));
			
				break;
			case EAZURE_FLARE_ELEMENT_TYPE::Element11:
				
				ElementTypes.Add(FAZURE_FLARE_TEXTURE_TYPE(0.0f, 0.0f, 1.0f, 0.5f));

				ElementTypes.Add(FAZURE_FLARE_TEXTURE_TYPE(0.5f, 0.5f, 0.25f, 0.125f));
				ElementTypes.Add(FAZURE_FLARE_TEXTURE_TYPE(0.5f, 0.625f, 0.25f, 0.125f));
				ElementTypes.Add(FAZURE_FLARE_TEXTURE_TYPE(0.5f, 0.75f, 0.25f, 0.125f));
				ElementTypes.Add(FAZURE_FLARE_TEXTURE_TYPE(0.5f, 0.875f, 0.25f, 0.125f));
				ElementTypes.Add(FAZURE_FLARE_TEXTURE_TYPE(0.75f, 0.5f, 0.25f, 0.125f));
				ElementTypes.Add(FAZURE_FLARE_TEXTURE_TYPE(0.75f, 0.625f, 0.25f, 0.125f));
				ElementTypes.Add(FAZURE_FLARE_TEXTURE_TYPE(0.75f, 0.75f, 0.25f, 0.125f));
				ElementTypes.Add(FAZURE_FLARE_TEXTURE_TYPE(0.75f, 0.875f, 0.25f, 0.125f));

				ElementTypes.Add(FAZURE_FLARE_TEXTURE_TYPE(0.0f, 0.5f, 0.5f, 0.25f));
				ElementTypes.Add(FAZURE_FLARE_TEXTURE_TYPE(0.0f, 0.75f, 0.5f, 0.25f));

			
				break;
			}

			SlateBrushs.Empty();
			Options.Empty();
			for (int i=0; i<ElementTypes.Num();i++)
			{
				Options.Add(MakeShareable(new FString(FString::Printf(TEXT("%d"), i))));
				FSlateBrush& SlateBrush = SlateBrushs.Add(*FString::Printf(TEXT("%d"), i));
				SlateBrush.SetResourceObject(InTexture2D);
				FBox2D box;
				box.Min.X = ElementTypes[i].uv[0];
				box.Min.Y = ElementTypes[i].uv[1];
				box.Max.X = box.Min.X+ElementTypes[i].uvs[0];
				box.Max.Y = box.Min.Y+ElementTypes[i].uvs[1];
				box.bIsValid = 1;
				SlateBrush.SetUVRegion(box);
			}			
		}
		void SetDefault(int sub_idx)
		{
			ComboBoxContent->SetContent(OnGenerateWidget(FString::Printf(TEXT("%d"), sub_idx)));
			SetUV(sub_idx);
		}
	};

	TSharedPtr<FAtlasPicker> AtlasPicker = MakeShareable(new FAtlasPicker());

	AtlasPicker->StructPropertyHandle = StructPropertyHandle;
	AtlasPicker->Init(Flare);

	FDetailWidgetRow& ResourceObjectRow = StructBuilder.AddCustomRow(FText::FromString(TEXT("Atlas")));

	typedef SComboBox< TSharedPtr<FString> > SComboBoxString;

	{
		ResourceObjectRow
			.NameContent()
			[
				SNew(STextBlock)
				.Text(FText::FromString(TEXT("Atlas")))
			]
		.ValueContent()
			.MinDesiredWidth(250.0f)
			.MaxDesiredWidth(0.0f)
			[
				SNew(SComboBoxString)
				.OptionsSource(&AtlasPicker->Options)
			.OnGenerateWidget(SComboBoxString::FOnGenerateWidget::CreateLambda(
				[](TSharedPtr<FString> InItem, TSharedPtr<FAtlasPicker> InAtlasPicker) {
			return InAtlasPicker->OnGenerateWidget(InItem);
		}, AtlasPicker))
			.OnSelectionChanged(SComboBoxString::FOnSelectionChanged::CreateLambda(
				[](TSharedPtr<FString> InItem, ESelectInfo::Type InSelectionType, TSharedPtr<FAtlasPicker> InAtlasPicker) {
			InAtlasPicker->OnSelectionChanged(InItem, InSelectionType);
		}, AtlasPicker))
			[
				SAssignNew(AtlasPicker->ComboBoxContent, SBox)
			]
			];
	}

	TSharedPtr<IPropertyHandle> sub_idxProperty = StructPropertyHandle->GetChildHandle(TEXT("sub_idx"));
	int sub_idx = 0;
	if (!sub_idxProperty.IsValid())
		return;
	if (sub_idxProperty->GetValue(sub_idx) != FPropertyAccess::Success)
		return;

	AtlasPicker->SetDefault(sub_idx);



}
//----------------------------------------------------------------------------------------------------------------------

void AzureLensFlareCustomization::CustomizeChildren(TSharedRef<class IPropertyHandle> StructPropertyHandle, class IDetailChildrenBuilder& StructBuilder, IPropertyTypeCustomizationUtils& StructCustomizationUtils)
{
	PropertyHandle = StructPropertyHandle;

	TSharedPtr<IPropertyHandle> scaleProperty = StructPropertyHandle->GetChildHandle(TEXT("scale"));
	StructBuilder.AddProperty(scaleProperty.ToSharedRef());

	TSharedPtr<IPropertyHandle> FlareProperty = StructPropertyHandle->GetChildHandle(TEXT("Flare"));
	UObject *pObject = nullptr;
	if (!FlareProperty.IsValid())
		return;
	if (FlareProperty->GetValue(pObject) != FPropertyAccess::Success)
		return;
	if (pObject == nullptr)
		return;
	FString strClass = pObject->GetClass()->GetName();
	AAzureLensFlare *Flare = Cast<AAzureLensFlare>(pObject);
	if (Flare == nullptr)
		return;

	if (Flare->ElementType== EAZURE_FLARE_ELEMENT_TYPE::Custom)
	{ 
		TSharedPtr<IPropertyHandle> uColorProperty = StructPropertyHandle->GetChildHandle(TEXT("u"));
		StructBuilder.AddProperty(uColorProperty.ToSharedRef());
		TSharedPtr<IPropertyHandle> vColorProperty = StructPropertyHandle->GetChildHandle(TEXT("v"));
		StructBuilder.AddProperty(uColorProperty.ToSharedRef());
		TSharedPtr<IPropertyHandle> usColorProperty = StructPropertyHandle->GetChildHandle(TEXT("us"));
		StructBuilder.AddProperty(usColorProperty.ToSharedRef());
		TSharedPtr<IPropertyHandle> vsColorProperty = StructPropertyHandle->GetChildHandle(TEXT("vs"));
		StructBuilder.AddProperty(vsColorProperty.ToSharedRef());
	}
	else
	{
		SetupAtlasPicker(Flare, StructPropertyHandle, StructBuilder);
	}
	

	TSharedPtr<IPropertyHandle> TintColorProperty = StructPropertyHandle->GetChildHandle(TEXT("TintColor"));
	StructBuilder.AddProperty(TintColorProperty.ToSharedRef());
}




#endif
