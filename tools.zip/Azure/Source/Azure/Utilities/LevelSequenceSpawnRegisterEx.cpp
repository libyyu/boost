// Copyright 1998-2018 Epic Games, Inc. All Rights Reserved.

#include "LevelSequenceSpawnRegisterEx.h"
#include "Engine/EngineTypes.h"
#include "MovieScene.h"
#include "MovieSceneSequence.h"
#include "IMovieSceneObjectSpawner.h"

FLevelSequenceSpawnRegisterEx::FLevelSequenceSpawnRegisterEx()
{
	
}

