#pragma once

#include "Engine/Engine.h"
#include "wLua.h"

class ECDebugImp;
class ECDebug
{
	TSharedPtr<ECDebugImp> m_DebugImp;
public:
	void RegisterLogCallback(wLua::Lua *wlua);
};

//get lua stack in debugger
char const* luastack();
char const* luastack(lua_State* L);

void AzureDisableLuaThreadChecking();
void AzureDisableDeadLockDetector();

void AzureDisableAllSafeChecking();
