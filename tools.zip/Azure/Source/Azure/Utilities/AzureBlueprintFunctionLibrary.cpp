﻿// Fill out your copyright notice in the Description page of Project Settings.

#include "AzureBlueprintFunctionLibrary.h"
#include "../AzureEntryPoint.h"
#include "IConsoleManager.h"
#include "GameLogic/Player/GamePlayer.h"
#include "GameFramework/PlayerController.h"
#include "AnimationRuntime.h"
#include "ImageUtils.h"
#include "Serialization/BufferArchive.h"
#include "Engine/TextureRenderTarget2D.h"
#include "Components/SkinnedMeshComponent.h"
#include "Azure.h"
#include "PhysicsEngine/PhysicsSettings.h"
#include "DrawDebugHelpers.h"
#include "wLua/LuaInterface.h"
#include "HAL/PlatformApplicationMisc.h"
#include "Utilities/ECDebug.h"
#include "GameLogic/Main/AzureWorldWrap.h"
#include "Framework/Application/NavigationConfig.h"



float UAzureBlueprintFunctionLibrary::ApproachTargetFloat(float curValue, float tarValue, float speed)
{
	if (curValue > tarValue)
	{
		curValue = curValue - speed;
		if (curValue < tarValue)
			curValue = tarValue;
	}
	else if (curValue < tarValue)
	{
		curValue = curValue + speed;
		if (curValue > tarValue)
			curValue = tarValue;
	}
	return curValue;
}

void UAzureBlueprintFunctionLibrary::DecideFootIKOffset(float rawRightFootOffset, float rawLeftFootOffset, float &outCompZOffset, float &outRightFootOffset, float &outLeftFootOffset)
{
	bool bRightAir = rawRightFootOffset < -5.0f;
	bool bLeftAir = rawLeftFootOffset < -5.0f;

	if (!bLeftAir && !bRightAir)
	{
		bool bRightUD = rawRightFootOffset > 5.0f;
		bool bLeftUD = rawLeftFootOffset > 5.0f;
		if (bLeftUD && bRightUD)
		{
			//	俩脚都在地底下：往上抬
			bool bRightHigh = rawRightFootOffset > rawLeftFootOffset;
			outCompZOffset = bRightHigh ? rawRightFootOffset : rawLeftFootOffset;

			outRightFootOffset = bRightHigh ? 0 : (rawLeftFootOffset - rawRightFootOffset);
			outLeftFootOffset = bRightHigh ? (rawRightFootOffset - rawLeftFootOffset) : 0;
		}
		else
		{
			outCompZOffset = 0;
			outRightFootOffset = rawRightFootOffset * -1;
			outLeftFootOffset = rawLeftFootOffset * -1;
		}
	}
	else if(bLeftAir && !bRightAir)	//左脚在空中
	{
		outCompZOffset = rawLeftFootOffset;
		outRightFootOffset = rawLeftFootOffset;
		outLeftFootOffset = 0;
	}
	else if (!bLeftAir && bRightAir)	//右脚在空中
	{
		outCompZOffset = rawRightFootOffset;
		outRightFootOffset = 0;
		outLeftFootOffset = rawRightFootOffset;
	}
	else //双脚都在空中
	{
		bool bRightLow = rawRightFootOffset < rawLeftFootOffset;
		outCompZOffset = bRightLow ? rawRightFootOffset : rawLeftFootOffset;

		outRightFootOffset = bRightLow ? 0 : (rawLeftFootOffset - rawRightFootOffset);
		outLeftFootOffset = bRightLow ? (rawRightFootOffset - rawLeftFootOffset) : 0;
	}
}

void UAzureBlueprintFunctionLibrary::SetSkyBox(AActor *pSkyBox)
{
	if (AAzureEntryPoint::Instance != nullptr)
	{
		AAzureEntryPoint::Instance->SetSkyBoxActor(pSkyBox);
	}
}

AActor* UAzureBlueprintFunctionLibrary::GetSkyBox()
{
	if (AAzureEntryPoint::Instance != nullptr)
	{
		return AAzureEntryPoint::Instance->GetSkyBoxActor();
	}
	return nullptr;
}

int32 UAzureBlueprintFunctionLibrary::GetConsoleCommandValueInt(FString ConsoleCommand)
{
	static const auto ConsoleVariable = IConsoleManager::Get().FindTConsoleVariableDataInt(*ConsoleCommand);
	return ConsoleVariable->GetValueOnGameThread();
}

bool UAzureBlueprintFunctionLibrary::CallLuaFunctionOI(FString FunctionName, UObject* Param1, int Param2)
{
	if (AAzureEntryPoint::Instance != nullptr)
	{
		return AAzureEntryPoint::Instance->CallLuaFunctionOI(FunctionName,Param1,Param2);
	}
	return false;
}

UCameraComponent* UAzureBlueprintFunctionLibrary::GetMainCameraComponent()
{
	if (AAzureEntryPoint::Instance)
	{
		return AAzureEntryPoint::Instance->GetMainCameraComponent();
	}
	return nullptr;
}

AActor* UAzureBlueprintFunctionLibrary::GetHostModelActor()
{
	return AAzureEntryPoint::Instance ? AAzureEntryPoint::Instance->GetHostModelActor() : nullptr;
}

AActor* UAzureBlueprintFunctionLibrary::GetHostRootActor()
{
	return AAzureEntryPoint::Instance ? AAzureEntryPoint::Instance->GetHostRootActor() : nullptr;
}

FTransform UAzureBlueprintFunctionLibrary::GetComponentSpaceTransformRefPose(USkeletalMeshComponent* SkeletalMeshComponent, const int32 BoneIndex)
{
	if (SkeletalMeshComponent)
	{
		const FReferenceSkeleton& RefSkeleton = SkeletalMeshComponent->SkeletalMesh->RefSkeleton;
		if (BoneIndex != INDEX_NONE)
		{
			return FAnimationRuntime::GetComponentSpaceTransformRefPose(RefSkeleton, BoneIndex);
		}
	}
	return FTransform::Identity;
}


void UAzureBlueprintFunctionLibrary::SetMaterialsQualityLevel(UObject* WorldContextObject, EMaterialQualityLevel::Type level, bool bForce, bool bExcludeInputWorld)
{

	UWorld* World = GEngine->GetWorldFromContextObject(WorldContextObject, EGetWorldErrorMode::LogAndReturnNull);
	if (World) 
	{
		GAzureSetMaterialsQualityLevel(World, level, bForce, bExcludeInputWorld);
	}
	else {
		UE_LOG(LogTemp, Warning, TEXT("World null"));
	}

}

void UAzureBlueprintFunctionLibrary::ExportRenderTextureToPNG(UTextureRenderTarget2D* TextureRenderTarget, const FString& strPath)
{
	
	if (!TextureRenderTarget)
		return;
	FArchive* Ar = IFileManager::Get().CreateFileWriter(*strPath);

	if (Ar)
	{
		FBufferArchive Buffer;

		bool bSuccess = false;
		if (TextureRenderTarget->RenderTargetFormat == RTF_RGBA16f)
		{
			bSuccess = FImageUtils::ExportRenderTarget2DAsHDR(TextureRenderTarget, Buffer);
		}
		else
		{
			bSuccess = FImageUtils::ExportRenderTarget2DAsPNG(TextureRenderTarget, Buffer);
		}

		if (bSuccess)
		{
			Ar->Serialize(const_cast<uint8*>(Buffer.GetData()), Buffer.Num());
		}

		delete Ar;
	}
	else
	{
		UE_LOG(LogAzure, Error, TEXT("ExportTextureToPNG Error exporting %s"), *strPath);
	}
	
}

void UAzureBlueprintFunctionLibrary::UpdateVertexBuffersFromOther(USkinnedMeshComponent* pSkeletalMeshComponenDest, USkinnedMeshComponent* pSkeletalMeshComponenSrc)
{
	if (pSkeletalMeshComponenDest != nullptr) 
	{
		USkinnedMeshComponent::UpdateVertexBuffersFromOther(pSkeletalMeshComponenDest->SkeletalMesh, pSkeletalMeshComponenSrc);
	}
	
}

void UAzureBlueprintFunctionLibrary::ClipboardCopy(const FString Str)
{
	FPlatformApplicationMisc::ClipboardCopy(*Str);
}

void UAzureBlueprintFunctionLibrary::ClipboardPaste(class FString& Dest)
{
	FPlatformApplicationMisc::ClipboardPaste(Dest);
}

FString UAzureBlueprintFunctionLibrary::Concat_StrTabStr(const FString& A, const FString& B)
{
	return FString::Printf(TEXT("%s\t%s"), *A, *B);
}

bool UAzureBlueprintFunctionLibrary::StringGreaterThan(const FString& A, const FString& B)
{
	return FCString::Strcmp(*A, *B) > 0;

}


namespace
{
	FCollisionQueryParams ConfigureCollisionParams(FName TraceTag, bool bTraceComplex, const TArray<AActor*>& ActorsToIgnore, bool bIgnoreSelf, UObject* WorldContextObject)
	{
		FCollisionQueryParams Params(TraceTag, SCENE_QUERY_STAT_ONLY(KismetTraceUtils), bTraceComplex);
		Params.bReturnPhysicalMaterial = true;
		Params.bReturnFaceIndex = !UPhysicsSettings::Get()->bSuppressFaceRemapTable; // Ask for face index, as long as we didn't disable globally
		Params.bTraceAsyncScene = true;
		Params.AddIgnoredActors(ActorsToIgnore);
		if (bIgnoreSelf)
		{
			AActor* IgnoreActor = Cast<AActor>(WorldContextObject);
			if (IgnoreActor)
			{
				Params.AddIgnoredActor(IgnoreActor);
			}
			else
			{
				// find owner
				UObject* CurrentObject = WorldContextObject;
				while (CurrentObject)
				{
					CurrentObject = CurrentObject->GetOuter();
					IgnoreActor = Cast<AActor>(CurrentObject);
					if (IgnoreActor)
					{
						Params.AddIgnoredActor(IgnoreActor);
						break;
					}
				}
			}
		}

		return Params;
	}
}

bool UAzureBlueprintFunctionLibrary::CapsuleTraceSingle(UObject* WorldContextObject, const FVector Start, const FVector End, float Radius, float HalfHeight, ETraceTypeQuery TraceChannel, bool bTraceComplex, const TArray<AActor*>& ActorsToIgnore, EDrawDebugTrace::Type DrawDebugType, FHitResult& OutHit, bool bIgnoreSelf, FRotator Rot, FLinearColor TraceColor, FLinearColor TraceHitColor, float DrawTime)
{
	ECollisionChannel CollisionChannel = UEngineTypes::ConvertToCollisionChannel(TraceChannel);

	static const FName CapsuleTraceSingleName(TEXT("CapsuleTraceSingle"));
	FCollisionQueryParams Params = ConfigureCollisionParams(CapsuleTraceSingleName, bTraceComplex, ActorsToIgnore, bIgnoreSelf, WorldContextObject);

	UWorld* World = GEngine->GetWorldFromContextObject(WorldContextObject, EGetWorldErrorMode::LogAndReturnNull);
	bool const bHit = World ? World->SweepSingleByChannel(OutHit, Start, End, Rot.Quaternion(), CollisionChannel, FCollisionShape::MakeCapsule(Radius, HalfHeight), Params) : false;

#if ENABLE_DRAW_DEBUG
	if (DrawDebugType != EDrawDebugTrace::None)
	{
		bool bPersistent = DrawDebugType == EDrawDebugTrace::Persistent;
		float LifeTime = (DrawDebugType == EDrawDebugTrace::ForDuration) ? DrawTime : 0.f;

		FQuat QuatRot = Rot.Quaternion();
		if (bHit && OutHit.bBlockingHit)
		{			
			// Red up to the blocking hit, green thereafter
			::DrawDebugCapsule(World, Start, HalfHeight, Radius, QuatRot, TraceColor.ToFColor(true), bPersistent, LifeTime);
			::DrawDebugCapsule(World, OutHit.Location, HalfHeight, Radius, QuatRot, TraceColor.ToFColor(true), bPersistent, LifeTime);
			::DrawDebugLine(World, Start, OutHit.Location, TraceColor.ToFColor(true), bPersistent, LifeTime);
			::DrawDebugPoint(World, OutHit.ImpactPoint, 16.f, TraceColor.ToFColor(true), bPersistent, LifeTime);

			::DrawDebugCapsule(World, End, HalfHeight, Radius, QuatRot, TraceHitColor.ToFColor(true), bPersistent, LifeTime);
			::DrawDebugLine(World, OutHit.Location, End, TraceHitColor.ToFColor(true), bPersistent, LifeTime);
		}
		else
		{
			// no hit means all red
			::DrawDebugCapsule(World, Start, HalfHeight, Radius, QuatRot, TraceColor.ToFColor(true), bPersistent, LifeTime);
			::DrawDebugCapsule(World, End, HalfHeight, Radius, QuatRot, TraceColor.ToFColor(true), bPersistent, LifeTime);
			::DrawDebugLine(World, Start, End, TraceColor.ToFColor(true), bPersistent, LifeTime);
		}
	}
#endif

	return bHit;
}

FString UAzureBlueprintFunctionLibrary::EntryPointLuaTraceBack()
{
	return FString(luastack());
}


bool UAzureBlueprintFunctionLibrary::GameInfo_GetBoolean(FString strExpression)
{
	if (!AAzureEntryPoint::Instance)
		return false;

	wLua::Lua * wlua = AAzureEntryPoint::Instance->GetWLua();
	if (wlua == nullptr)
		return false;

	lua_State_Wrapper L = wlua->GetL();
	if (L == nullptr)
		return false;

	if (strExpression.IsEmpty())
		return false;

	bool result = false;
	int n = lua_gettop(L);
	lua_getglobal(L, "GameInfo_GetValue");
	lua_pushstring(L, TCHAR_TO_UTF8(*strExpression));
	bool ret = wlua->PCall(1, 1);
	if (ret)
	{
		if (lua_isboolean(L, -1))
			result = lua_toboolean(L, -1) ? true : false;
	}

	lua_settop(L, n);
	return result;
}

int UAzureBlueprintFunctionLibrary::GameInfo_GetInt(FString strExpression)
{
	if (!AAzureEntryPoint::Instance)
		return 0;

	wLua::Lua * wlua = AAzureEntryPoint::Instance->GetWLua();
	if (wlua == nullptr)
		return 0;
	lua_State_Wrapper L = wlua->GetL();
	if (L == nullptr)
		return 0;

	if (strExpression.IsEmpty())
		return 0;

	int result = 0;
	int n = lua_gettop(L);
	lua_getglobal(L, "GameInfo_GetValue");
	lua_pushstring(L, TCHAR_TO_UTF8(*strExpression));
	bool ret = wlua->PCall(1, 1);
	if (ret)
	{
		if (lua_isnumber(L, -1))
			result = lua_tointeger(L, -1);
	}

	lua_settop(L, n);
	return result;
}

float UAzureBlueprintFunctionLibrary::GameInfo_GetFloat(FString strExpression)
{
	if (!AAzureEntryPoint::Instance)
		return 0.0f;

	wLua::Lua * wlua = AAzureEntryPoint::Instance->GetWLua();
	if (wlua == nullptr)
		return 0.0f;

	lua_State_Wrapper L = wlua->GetL();
	if (L == nullptr)
		return 0.0f;

	if (strExpression.IsEmpty())
		return 0.0f;

	int result = 0;
	int n = lua_gettop(L);
	lua_getglobal(L, "GameInfo_GetValue");
	lua_pushstring(L, TCHAR_TO_UTF8(*strExpression));
	bool ret = wlua->PCall(1, 1);
	if (ret)
	{
		if (lua_isnumber(L, -1))
			result = (float)lua_tonumber(L, -1);
	}

	lua_settop(L, n);
	return result;
}

FString UAzureBlueprintFunctionLibrary::GameInfo_GetString(FString strExpression)
{
	FString result;
	if (!AAzureEntryPoint::Instance)
		return result;
	
	wLua::Lua * wlua = AAzureEntryPoint::Instance->GetWLua();
	if (wlua == nullptr)
		return result;
	lua_State_Wrapper L = wlua->GetL();
	if (L == nullptr)
		return result;

	if (strExpression.IsEmpty())
		return result;

	int n = lua_gettop(L);
	lua_getglobal(L, "GameInfo_GetValue");
	lua_pushstring(L, TCHAR_TO_UTF8(*strExpression));
	bool ret = wlua->PCall(1, 1);
	if (ret)
	{
		if (lua_isstring(L, -1))
			result = UTF8_TO_TCHAR(lua_tostring(L, -1));
	}

	lua_settop(L, n);
	return result;
}

bool UAzureBlueprintFunctionLibrary::IsWorldWrapEnabled()
{
	return AzureWorldWrap::Instance().IsEnabled();
}

FVector UAzureBlueprintFunctionLibrary::WorldGetUnwrapCenter()
{
	FVector2D pos2DServer = AzureWorldWrap::Instance().GetUnwrapCenter();
	return POS_FROM_SERVER(FVector(pos2DServer.X, 0, pos2DServer.Y));
}

FVector UAzureBlueprintFunctionLibrary::WorldWrapPosition(FVector const& position)
{
	return POS_FROM_SERVER(AzureWorldWrap::Instance().Wrap3DPosition(POS_TO_SERVER(position)));
}

FVector UAzureBlueprintFunctionLibrary::WorldWrapDistance(FVector const& position)
{
	return POS_FROM_SERVER(AzureWorldWrap::Instance().Wrap3DDistance(POS_TO_SERVER(position)));
}

FVector UAzureBlueprintFunctionLibrary::WorldUnwrapPosition(FVector const& position)
{
	return POS_FROM_SERVER(AzureWorldWrap::Instance().Unwrap3DPosition(POS_TO_SERVER(position)));
}

void UAzureBlueprintFunctionLibrary::WorldGetUnwrapOffset(FVector const& position, int& xOffset, int&yOffset)
{
	FVector serverPos = POS_TO_SERVER(position);
	AzureWorldWrap::Instance().UnwrapPosition(FVector2D(serverPos.X, serverPos.Z), yOffset, xOffset);
}

void UAzureBlueprintFunctionLibrary::EnableSlateNavigation(bool bKeyNavigation, bool bTabNavigation, bool bAnalogNavigation)
{
	TSharedRef<FNavigationConfig> Navigation = MakeShared<FNavigationConfig>();
	Navigation->bKeyNavigation = bKeyNavigation;
	Navigation->bTabNavigation = bTabNavigation;
	Navigation->bAnalogNavigation = bAnalogNavigation;
	FSlateApplication::Get().SetNavigationConfig(Navigation);
}
