// Fill out your copyright notice in the Description page of Project Settings.
#include "WeaponPositionTest.h"
#include "Components/SkeletalMeshComponent.h"
#include "Engine/StaticMesh.h"
#include "BonePose.h"
#include "BoneContainer.h"
#include "Animation/AnimInstance.h"
#include "Animation/SkeletalMeshActor.h"
#include "kismet/GameplayStatics.h"
#include <fstream>

static const int32 COLLIDER_FRAME_RATE = 120;

// Sets default values
AWeaponPositionTest::AWeaponPositionTest()
{
	// Set this actor to call Tick() every frame.  You can turn this off to improve performance if you don't need it.
	PrimaryActorTick.bCanEverTick = true;
	datas.Empty();
	Length = 0.f;
	CollisionContainer.Empty();

	/*FString newMeshName = "/Game/Models/Players/Female/Body/Femle_Body01/Female_Body01";
	FemaleMesh = LoadObject<USkeletalMesh>(NULL, *newMeshName);
	newMeshName = "/Game/Models/Characters/NeroNew/nero";
	maleMesh = LoadObject<USkeletalMesh>(NULL, *newMeshName);*/


}

// Called when the game starts or when spawned
void AWeaponPositionTest::BeginPlay()
{
	if (data)
	{
		FString text = "";
		data->GetAllRows(text, datas);
	}

	TArray<AActor*> actors;
	UGameplayStatics::GetAllActorsOfClass(GetWorld(), AActor::StaticClass(), actors);
	for (size_t i = 0,N = actors.Num();i<N;i++)
	{
		if (actors[i]->GetName() == "Male_AnimBP_2")
		{
			MaleActor = actors[i];
		}
		else if (actors[i]->GetName() == "Female_AnimBP_2")
		{
			FemaleActor = actors[i];
		}
		else if (actors[i]->GetName() == "Female_BP_4")
		{
			FemalePersonActor = actors[i];
		}
		else if (actors[i]->GetName() == "Male_BP")
		{
			MalePersonActor = actors[i];
		}
	}
	//TArray<AActor*> actorss;
	//UGameplayStatics::GetAllActorsWithTag(GetWorld(), TEXT("animActor"), actorss);
	Super::BeginPlay();
}

// Called every frame
void AWeaponPositionTest::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);
}

void AWeaponPositionTest::PushCollision(const int type, const float var1, const float var2, const float var3)
{
	FCollisionShape Collision;
	Collision.ShapeType = ECollisionShape::Type(type);
	Collision.Box.HalfExtentX = var1;
	Collision.Box.HalfExtentY = var2;
	Collision.Box.HalfExtentZ = var3;	
	Collisions.Add(Collision);
}

float AWeaponPositionTest::GetLength(const USkeletalMeshComponent* MeshCom, const UStaticMesh* StaticMesh, FString& OutPath)
{
	if (!MeshCom)
	{
		return false;
	}
	UAnimInstance* AnimInstance = MeshCom->GetAnimInstance();
	if (!AnimInstance)
	{
		return false;
	}
	UAnimMontage* AnimMontage = AnimInstance->GetCurrentActiveMontage();
	if (!AnimMontage)
	{
		return false;
	}	
	OutPath = FPaths::ProjectDir() + FString("Output/Configs/anim/") + AnimMontage->GetName() + FString(".txt");
	Path = OutPath;
	//FString MontageName = AnimMontage->GetName();


	return AnimMontage->GetPlayLength();
}

float AWeaponPositionTest::SetOutPath(UAnimMontage* AnimMontage, const FString& InPath)
{
	if (!AnimMontage ||!InPath.Len())
	{
		return 0.0f;
	}
	Path = FPaths::ProjectDir() + InPath + AnimMontage->GetName() + FString(".txt");
	return AnimMontage->GetPlayLength();
}

void AWeaponPositionTest::PushData(const FTransform& T1, const FTransform& T2, const int FrameNum)
{
	FTransform T3 = T1 * T2.Inverse();
	FVector Translation = T3.GetTranslation();
	FVector Rotation = T3.GetRotation().Euler();
	FVector Scal3D = T3.GetScale3D();
	TransformVariable TV = { {(float)FrameNum, Translation[0],Translation[1] ,Translation[2],
		Rotation[0], Rotation[1],Rotation[2], Scal3D[0], Scal3D[1], Scal3D[2]} };
	WeaPonTransform.Push(TV);
}

void AWeaponPositionTest::initCollisionObjects(USceneComponent* obj, const int WeaponIndex)
{
	if (NULL==obj)
	{
		return;
	}
	CollisionContainer.Push(obj);

	CollisionObjInfo info;
	info.object = obj;
	info.WeaponIndex = WeaponIndex;
	info.defalutTransform = obj->GetRelativeTransform();
	collisionObjInfos.Push(info);
}

void AWeaponPositionTest::PushCollisionData(const int FrameNum, const int WeaponIndex, const FVector4 CollisionInfo, const FTransform& T1, const FTransform& T2)
{
	CollisionInformation TempCollision;
	TempCollision.FrameNum = FrameNum;
	TempCollision.WeaponIndex = WeaponIndex;
	TempCollision.CollisionShape.ShapeType= ECollisionShape::Type(int(CollisionInfo.X));
	TempCollision.CollisionShape.Box.HalfExtentX = CollisionInfo.Y;
	TempCollision.CollisionShape.Box.HalfExtentY = CollisionInfo.Z;
	TempCollision.CollisionShape.Box.HalfExtentZ = CollisionInfo.W;
	FTransform T3 = T1 * T2.Inverse();
	FVector Translation = T3.GetTranslation();
	FVector Rotation = T3.GetRotation().Euler();
	FVector Scal3D = T3.GetScale3D();
	float a[9] = { Translation.X ,Translation.Y ,Translation.Z ,Rotation.X ,Rotation.Y ,Rotation.Z ,Scal3D.X ,Scal3D.Y ,Scal3D.Z };
	memcpy(TempCollision.var, a, sizeof(a));
	CollisionInfos.Add(TempCollision);
}

void AWeaponPositionTest::SaveWeaponTransform()
{

	std::ofstream f(TCHAR_TO_ANSI(*Path));
	if (!f)
	{
		goto end;
	}
	f << Collisions.Num() << std::endl;
	for (int i = 0; i < Collisions.Num(); i++)
	{
		FCollisionShape& Ishape = Collisions[i];
		f << int(Ishape.ShapeType) << " " << Ishape.Box.HalfExtentX << " " << Ishape.Box.HalfExtentY << " " << Ishape.Box.HalfExtentZ << std::endl;
	}

	for (int i = 0; i < WeaPonTransform.Num(); i++)
	{
		for (int j = 0; j < 10; j++)
		{
			f << WeaPonTransform[i][j] << " ";
		}
		f << std::endl;
	}
end:
	f.close();
}

void AWeaponPositionTest::SaveCollisionInfos()
{
	std::ofstream f(TCHAR_TO_ANSI(*Path));
	if (!f)
	{
		goto end;
	}
	f << Collisions.Num() << std::endl;
	for (int i = 0; i < Collisions.Num(); i++)
	{
		FCollisionShape& Ishape = Collisions[i];
		f << int(Ishape.ShapeType) << " " << Ishape.Box.HalfExtentX << " " << Ishape.Box.HalfExtentY << " " << Ishape.Box.HalfExtentZ << std::endl;
	}

	for (int i = 0; i < CollisionInfos.Num(); i++)
	{
		auto& InfoI = CollisionInfos[i];
		f << InfoI.FrameNum * COLLIDER_FRAME_RATE / FrameRate << " " << InfoI.WeaponIndex << " ";
		FCollisionShape& Ishape = InfoI.CollisionShape;
		if (InfoI.WeaponIndex == weaponData.index1 && weaponData.size1.size() == 3)
		{
			f << int(Ishape.ShapeType) << " " << weaponData.size1[0] << " " << weaponData.size1[1] << " " << weaponData.size1[2] << " ";
		}
		else if (InfoI.WeaponIndex == weaponData.index2 && weaponData.size2.size() == 3)
		{
			f << int(Ishape.ShapeType) << " " << weaponData.size2[0] << " " << weaponData.size2[1] << " " << weaponData.size2[2] << " ";
		}
		else
		{
			f << int(Ishape.ShapeType) << " " << Ishape.Box.HalfExtentX << " " << Ishape.Box.HalfExtentY << " " << Ishape.Box.HalfExtentZ << " ";
		}
		for (int j = 0; j < 9; j++)
		{
			f << InfoI.var[j] << " ";
		}
		f << std::endl;
	}
end:
	f.close();
	CollisionInfos.Empty();
}

bool AWeaponPositionTest::checkDoNext()
{
	if (datas.Num() <= 0)
	{
		return false;
	}
	FWeaponPositionData* info = datas.Pop();

	if (info)
	{
		initWeaponPositionData(info);

		if (weaponData.sex == "Female")
		{
			Person = dynamic_cast<ASkeletalMeshActor *>(FemaleActor);
			PersonActor = dynamic_cast<AActor *>(FemalePersonActor);
		}
		else
		{
			Person = dynamic_cast<ASkeletalMeshActor *>(MaleActor);
			PersonActor = dynamic_cast<AActor *>(MalePersonActor);
		}
		if (NULL == Person || NULL == PersonActor)
		{
			return false;
		}
		FrameRate = weaponData.frameRate;
		for (size_t i = 0, N = Weapons.Num(); i < N; i++)
		{
			AActor* weapon = Weapons[i];
			if (weapon && weapon->GetRootComponent())
			{
				weapon->AttachToActor(Person, FAttachmentTransformRules(EAttachmentRule::KeepRelative, EAttachmentRule::KeepRelative, EAttachmentRule::KeepRelative, false), weapon->GetRootComponent()->GetAttachSocketName());
			}
		}
		for (size_t i = 0, N = collisionObjInfos.Num(); i < N; i++)
		{
			CollisionObjInfo info2 = collisionObjInfos[i];
			if (info2.WeaponIndex == weaponData.index1 && weaponData.offset1.size() == 3)
			{
				FTransform newTrans = info2.defalutTransform;
				FVector newLocation(weaponData.offset1[0], weaponData.offset1[1], weaponData.offset1[2]);
				//newTrans.SetLocation(newLocation);
				info2.object->SetRelativeLocation(newLocation);
			}
			else if (info2.WeaponIndex == weaponData.index2 && weaponData.offset2.size() == 3)
			{
				FTransform newTrans = info2.defalutTransform;
				FVector newLocation(weaponData.offset2[0], weaponData.offset2[1], weaponData.offset2[2]);
				//newTrans.SetLocation(newLocation);
				info2.object->SetRelativeLocation(newLocation);
			}
			else
			{
				info2.object->SetRelativeTransform(info2.defalutTransform);
			}
		}

		USkeletalMeshComponent* MeshCom = Person->GetSkeletalMeshComponent();
		if (MeshCom)
		{
			UAnimMontage* temp = LoadObject<UAnimMontage>(NULL, *weaponData.animname);
			if (temp)
			{
				Path = FPaths::ProjectDir() + FString("Output/Configs/anim/") + temp->GetName() + FString(".txt");
				MeshCom->OverrideAnimationData(temp);
				UAnimInstance* AnimInstance = MeshCom->GetAnimInstance();
				if (AnimInstance)
				{
					Length = AnimInstance->Montage_Play(temp);
					//AnimInstance->Montage_Stop(0);
					MeshCom->Stop();
					//UAnimMontage* AnimMontage = AnimInstance->GetCurrentActiveMontage();
					return true;
				}
			}
		}
	}
	return false;
}

void AWeaponPositionTest::initWeaponPositionData(FWeaponPositionData* info)
{
	weaponData.reset();
	if (info == NULL)
	{
		return;
	}
	if (info->sex == "Female")
	{
		weaponData.animname = "/Game/Models/Players/Female/Animations/" + info->sex + "_" + info->animname;
	} 
	else
	{
		weaponData.animname = "/Game/Models/Players/Male/Animations/" + info->sex + "_" + info->animname;
	}
	weaponData.sex = info->sex;
	weaponData.frameRate = info->frameRate <= 0 ? 120 : info->frameRate;
	weaponData.index1 = info->index1;
	weaponData.index2 = info->index2;
	if (!info->size1.IsEmpty())
	{
		TArray<FString> OutArray;
		FString pchDelim = ",";
		info->size1.ParseIntoArray(OutArray, *pchDelim);
		if (OutArray.Num() > 0)
		{
			for (size_t i = 0; i < OutArray.Num(); i++)
			{
				weaponData.size1.push_back(FCString::Atof(*OutArray[i]));
			}
		}
	}
	if (!info->size2.IsEmpty())
	{
		TArray<FString> OutArray;
		FString pchDelim = ",";
		info->size2.ParseIntoArray(OutArray, *pchDelim);
		if (OutArray.Num() > 0)
		{
			for (size_t i = 0; i < OutArray.Num(); i++)
			{
				weaponData.size2.push_back(FCString::Atof(*OutArray[i]));
			}
		}
	}
	if (!info->offset1.IsEmpty())
	{
		TArray<FString> OutArray;
		FString pchDelim = ",";
		info->offset1.ParseIntoArray(OutArray, *pchDelim);
		if (OutArray.Num() > 0)
		{
			for (size_t i = 0; i < OutArray.Num(); i++)
			{
				weaponData.offset1.push_back(FCString::Atof(*OutArray[i]));
			}
		}
	}
	if (!info->offset2.IsEmpty())
	{
		TArray<FString> OutArray;
		FString pchDelim = ",";
		info->offset2.ParseIntoArray(OutArray, *pchDelim);
		if (OutArray.Num() > 0)
		{
			for (size_t i = 0; i < OutArray.Num(); i++)
			{
				weaponData.offset2.push_back(FCString::Atof(*OutArray[i]));
			}
		}
	}
}

