// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "Engine/TextureRenderTarget2D.h"
#include "CustomCharacterTexture.generated.h"

UCLASS()
class AZURE_API ACustomCharacterTexture : public AActor
{
	GENERATED_BODY()

public:
	// Sets default values for this actor's properties
	ACustomCharacterTexture();

protected:
	// Called when the game starts or when spawned
	virtual void BeginPlay() override;

public:
	// Called every frame
	virtual void Tick(float DeltaTime) override;

public:

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Material")
	class UMaterialInterface* Material;

	UFUNCTION(BlueprintCallable, Category = "Azure")
	static UTextureRenderTarget2D* CreateCustomRenderTarget(bool bAutoGenerateMips, bool bHDR, int32 Resolution, bool bForceLinearGamma, UObject* InOuter);

	UFUNCTION(BlueprintCallable, Category = "Azure")
	void DrawCustomTexture(UTextureRenderTarget2D* renderTarget, bool needClear);
};
