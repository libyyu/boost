// Fill out your copyright notice in the Description page of Project Settings.

#include "RegionWallActor.h"
#include <Components/SceneComponent.h>
#include <Components/StaticMeshComponent.h>
#include "ProceduralMeshComponent.h"
#include "DrawDebugHelpers.h"
#include "Utilities/AzureUtility.h"

// Sets default values
ARegionWallActor::ARegionWallActor()
{
 	// Set this character to call Tick() every frame.  You can turn this off to improve performance if you don't need it.
	PrimaryActorTick.bCanEverTick = true;

	//GetCapsuleComponent()->
	_SceneComp = CreateDefaultSubobject<USceneComponent>(TEXT("SceneComp"));
	RootComponent = _SceneComp;
	SetWallVisible(true);
	_WallVisibleLast	= true;
	SetDrawDebugLine(false);
	_LineColor = FColor(255 , 0 , 255 , 255);
}

void ARegionWallActor::InitPolygon(const FVector &location , const TArray<FVector> &points , int32 sceneID , int32 regionID , float upperOffset, float bottomOffset, float tileU , float upupV, float upboV, float boupV, float boboV)
{
	SetActorLocation(location);
	SetSceneIDRegionID(sceneID , regionID);

	struct MyRectangle//  һ���ķ�Ƭ
	{
		//	0---2
		//	|\  |
		//	| \ |
		//	|  \|
		//	1---3

		FVector vertices[4];	// �ĸ���������
		FVector normals[4];		// ��Ӧ����
		FProcMeshTangent tangents[4]; // ��Ӧ����
		FVector2D UV0[4];		// UV
		FVector2D UV1[4];		// UV1[0~3] = (vertices[1].x * 0.01, vertices[1].y * 0.01) (UV1[0~3]��һ��)
		FVector2D UV2[4];		// UV2[0~3] = UV0[1]  (UV2[0~3]��һ��)

		int32 indices[6];

		float length;

		void SetVertex(const FVector &pt1, const FVector &pt2, float height, float VUpper, float VBottom)
		{
			_SetVertex(pt1, pt2, height, VUpper , VBottom , 1.0f);
			indices[0] = 0;
			indices[1] = 1;
			indices[2] = 3;
			indices[3] = 0;
			indices[4] = 3;
			indices[5] = 2;

		}
		void SetVertexOutterSide(const FVector &pt1, const FVector &pt2, float height, float VUpper, float VBottom)
		{
			_SetVertex(pt1, pt2, height, VUpper, VBottom , -1.0f);
			indices[0] = 0;
			indices[1] = 3;
			indices[2] = 1;
			indices[3] = 0;
			indices[4] = 2;
			indices[5] = 3;
		}

		void _SetVertex(const FVector &pt1, const FVector &pt2, float height, float VUpper , float VBottom , float normalSign)
		{
			if (height > 0)
			{
				vertices[0] = FVector(pt1.X, pt1.Y, pt1.Z + height);
				vertices[1] = FVector(pt1.X, pt1.Y, pt1.Z);

				vertices[2] = FVector(pt2.X, pt2.Y, pt2.Z + height);
				vertices[3] = FVector(pt2.X, pt2.Y, pt2.Z);
			}
			else
			{
				vertices[0] = FVector(pt1.X, pt1.Y, pt1.Z);
				vertices[1] = FVector(pt1.X, pt1.Y, pt1.Z + height);

				vertices[2] = FVector(pt2.X, pt2.Y, pt2.Z);
				vertices[3] = FVector(pt2.X, pt2.Y, pt2.Z + height);
			}
			{
				FVector dd = pt1 - pt2;
				FVector normal;
				dd.ToDirectionAndLength(normal, length);
				FRotator rot;
				rot.Pitch = 0.0f;
				rot.Roll = 0.0f;
				rot.Yaw = 90.0f;
				normal = rot.RotateVector(normal);
				normal = normal * normalSign;
				normals[0] = normals[1] = normals[2] = normals[3] = -normal;	// ��Ӧ����// �ĸ���һ��

				FProcMeshTangent tangent(rot.RotateVector(normal), false);
				tangents[0] = tangents[1] = tangents[2] = tangents[3] = tangent;// ����
			}
			{
				//	UVx[0]--2
				//		|\  |
				//		| \ |
				//		|  \|
				//	UVx[1]--3
				UV0[0] = FVector2D(0, VUpper);
				UV0[1] = FVector2D(0, VBottom);
				UV0[2] = FVector2D(length, VUpper);
				UV0[3] = FVector2D(length, VBottom);

				UV1[0] = UV1[1] = UV1[2] = UV1[3] = FVector2D(pt1.X * 0.01f, pt1.Y * 0.01f);

				UV2[0] = UV2[1] = UV2[2] = UV2[3] = FVector2D(UV0[1].X, 0.0f);// UV0[1];
			}
		}

		float SetUV(float sumLength, float totalLength, float ftileU)
		{
			UV0[0].X = UV0[1].X = ((0 + sumLength) / totalLength) * ftileU;
			UV0[2].X = UV0[3].X = ((length + sumLength) / totalLength) * ftileU;

			UV2[0] = UV2[1] = UV2[2] = UV2[3] = FVector2D(UV0[1].X, 0.0f);// UV0[1];

			//UE_LOG(LogTemp, Warning, TEXT("sumLength , totalLength %f , %f "), sumLength , totalLength);
			//UE_LOG(LogTemp, Warning, TEXT("UV0[0].X = UV0[1].X = %f "), UV0[0].X);
			//UE_LOG(LogTemp, Warning, TEXT("UV0[2].X = UV0[3].X = %f "), UV0[2].X);
			//UE_LOG(LogTemp, Warning, TEXT("UV0[2].X - UV0[0].X = %f , length = %f"), UV0[2].X - UV0[0].X , length);
			//float d = (UV0[2].X - UV0[0].X) * 100.0 - length;
			//UE_LOG(LogTemp, Warning, TEXT("UV0[2].X - UV0[0].X - length = %f , %s") , d , abs(d) > 0.1f ? TEXT("true") : TEXT("false") );

			return sumLength + length;
		}

	};//struct MyRectangle

	TArray<MyRectangle> MyRectangles;
	float totalLength = 0.0f; // ������ͼ�����Uֵ �ۼ�
	_WallDatas.Reset();
	float absBottomOffset = FMath::Abs(bottomOffset);
	bool bottom = absBottomOffset > 9.999f;
	{
		int32 count = points.Num();

		//float ra = FMath::Abs(bottomOffset / upperOffset);
		//float bottomV = baseLineV;
		//float bottomV2 = (-upperV + 1.0f) * ra + 1.0f;// ��������ǽ�Ĳ��ʼ���

		{
			for (int32 i = 1; i < count; ++i)
			{
				const FVector &pt1 = points[i - 1];
				const FVector &pt2 = points[i];
				MyRectangle myrect;
				myrect.SetVertex(pt1, pt2, upperOffset, upupV, upboV);
				totalLength += myrect.length;
				MyRectangles.Add(myrect);

				FRegionWallData WallData;
				WallData.Begin = pt1 + location;
				WallData.End = pt2 + location;
				WallData.Normal = myrect.normals[0];
				//WallData.Yaw = yaw;
				_WallDatas.Add(WallData);

			}
		}
		if (bottom)
		{
			for (int32 i = 1; i < count; ++i)
			{
				const FVector &pt1 = points[i - 1];
				const FVector &pt2 = points[i];
				MyRectangle myrect;
				myrect.SetVertex(pt1, pt2, -absBottomOffset, boupV, boboV);
				MyRectangles.Add(myrect);
			}
		}
		if (_outterSide)
		{
			{
				for (int32 i = 1; i < count; ++i)
				{
					const FVector &pt1 = points[i - 1];
					const FVector &pt2 = points[i];
					MyRectangle myrect;
					myrect.SetVertexOutterSide(pt1, pt2, upperOffset, upupV, upboV);
					MyRectangles.Add(myrect);
				}
			}
			if (bottom)
			{

				for (int32 i = 1; i < count; ++i)
				{
					const FVector &pt1 = points[i - 1];
					const FVector &pt2 = points[i];
					MyRectangle myrect;
					myrect.SetVertexOutterSide(pt1, pt2, -absBottomOffset, boupV, boboV);
					MyRectangles.Add(myrect);
				}
			}
		}
	}
	{
		TArray<FVector> vertices;
		TArray<int32> triangle;
		TArray<FVector> normals;
		TArray<FProcMeshTangent> tangents;
		TArray<FVector2D> nUV0;
		TArray<FVector2D> nUV1;
		TArray<FVector2D> nUV2;
		TArray<FLinearColor> colors;
		TArray<FVector2D> empty2d;

		int32 rectCount = MyRectangles.Num();
		int32 upperCount = rectCount >> 1;
		int32 innerCount = rectCount >> 1;// ��� ��������
		if (_outterSide)
		{
			upperCount = rectCount >> 2;// ��� ��������
		}
		int32 upperSum = 0;
		double sumLength = 0;
		for (int32 idx = 0; idx < rectCount; ++idx)
		{
			MyRectangle &ver = MyRectangles[idx];
			vertices.Add(ver.vertices[0]);
			vertices.Add(ver.vertices[1]);
			vertices.Add(ver.vertices[2]);
			vertices.Add(ver.vertices[3]);

			normals.Add(ver.normals[0]);
			normals.Add(ver.normals[1]);
			normals.Add(ver.normals[2]);
			normals.Add(ver.normals[3]);

			tangents.Add(ver.tangents[0]);
			tangents.Add(ver.tangents[1]);
			tangents.Add(ver.tangents[2]);
			tangents.Add(ver.tangents[3]);
			
			sumLength = ver.SetUV(sumLength , totalLength , tileU);

			nUV0.Add(ver.UV0[0]);
			nUV0.Add(ver.UV0[1]);
			nUV0.Add(ver.UV0[2]);
			nUV0.Add(ver.UV0[3]);

			nUV1.Add(ver.UV1[0]);
			nUV1.Add(ver.UV1[1]);
			nUV1.Add(ver.UV1[2]);
			nUV1.Add(ver.UV1[3]);

			nUV2.Add(ver.UV2[0]);
			nUV2.Add(ver.UV2[1]);
			nUV2.Add(ver.UV2[2]);
			nUV2.Add(ver.UV2[3]);

			int32 index = idx << 2;// ÿ�����η�Ƭ ��4����

			triangle.Add(ver.indices[0] + index);
			triangle.Add(ver.indices[1] + index);
			triangle.Add(ver.indices[2] + index);

			triangle.Add(ver.indices[3] + index);
			triangle.Add(ver.indices[4] + index);
			triangle.Add(ver.indices[5] + index);

			++upperSum;
			if ((bottom || _outterSide) && upperSum >= upperCount)// ���°벿�� ��������
			{//
				sumLength = 0;
				upperSum = 0;
			}
		}
		if (_wallProceduralMeshComp != nullptr)
		{
			_wallProceduralMeshComp->UnregisterComponent();
			_wallProceduralMeshComp->DestroyComponent();
		}
		UProceduralMeshComponent *meshComp = NewObject<UProceduralMeshComponent>(this, TEXT("WallProceduralMeshComp"));
		_wallProceduralMeshComp = meshComp;
		_wallProceduralMeshComp->SetVisibility(GetWallVisible());

		meshComp->SetupAttachment(RootComponent);
		meshComp->RegisterComponent();
		if (_WallMaterial != nullptr)
		{
			meshComp->SetMaterial(0, _WallMaterial);
		}
		meshComp->TranslucencySortPriority = TranslucencySortPriority;
		meshComp->CreateMeshSection_LinearColor(0, vertices, triangle, normals, nUV0, nUV1, nUV2, empty2d, colors, tangents, true);

		meshComp->SetCollisionObjectType(ECollisionChannel::ECC_WorldStatic);
		meshComp->SetCollisionResponseToChannel(ECollisionChannel::ECC_Camera, ECollisionResponse::ECR_Ignore);
		meshComp->SetCollisionResponseToChannel(AzureUtility::TRACE_CHN_TERRAIN_BUILDING, ECollisionResponse::ECR_Block);
	}
}

void ARegionWallActor::InitCircle(const FVector &location , int32 sceneID , int32 regionID , float radius , float upperOffset, float bottomOffset, float tileU , float upupV, float upboV, float boupV, float boboV, int segNum)
{// ���ɻ���Բ�� �ĵ� ���� ����

	SetActorLocation(location);
	SetSceneIDRegionID(sceneID , regionID);

	struct MyRectangle//  һ���ķ�Ƭ
	{
		//	0---2
		//	|\  |
		//	| \ |
		//	|  \|
		//	1---3

		FVector vertices[4];	// �ĸ���������
		FVector normals[4];		// ��Ӧ����
		FProcMeshTangent tangents[4]; // ��Ӧ����
		FVector2D UV0[4];		// UV
		FVector2D UV1[4];		// UV1[0~3] = (vertices[1].x * 0.01, vertices[1].y * 0.01) (UV1[0~3]��һ��)
		FVector2D UV2[4];		// UV2[0~3] = UV0[1]  (UV2[0~3]��һ��)

		int32 indices[6];

		void SetVertex(const FVector &pt1, const FVector &pt2, float height, float U0a , float U0b , float VUpper , float VBottom)
		{
			_SetVertex(pt1, pt2, height, U0a, U0b, VUpper, VBottom, 1.0f);
			indices[0] = 0;
			indices[1] = 1;
			indices[2] = 3;
			indices[3] = 0;
			indices[4] = 3;
			indices[5] = 2;

		}
		void SetVertexOutterSide(const FVector &pt1, const FVector &pt2, float height, float U0a, float U0b, float VUpper, float VBottom)
		{
			_SetVertex(pt1, pt2, height, U0a, U0b, VUpper, VBottom, -1.0f);
			indices[0] = 0;
			indices[1] = 3;
			indices[2] = 1;
			indices[3] = 0;
			indices[4] = 2;
			indices[5] = 3;
		}

		void _SetVertex(const FVector &pt1, const FVector &pt2, float height, float U0a, float U0b, float VUpper, float VBottom, float normalSign)
		{
			if (height > 0)
			{
				vertices[0] = FVector(pt1.X, pt1.Y, pt1.Z + height);
				vertices[1] = FVector(pt1.X, pt1.Y, pt1.Z);

				vertices[2] = FVector(pt2.X, pt2.Y, pt2.Z + height);
				vertices[3] = FVector(pt2.X, pt2.Y, pt2.Z);
			}
			else
			{
				vertices[0] = FVector(pt1.X, pt1.Y, pt1.Z);
				vertices[1] = FVector(pt1.X, pt1.Y, pt1.Z + height);

				vertices[2] = FVector(pt2.X, pt2.Y, pt2.Z);
				vertices[3] = FVector(pt2.X, pt2.Y, pt2.Z + height);
			}
			{
				FVector dd1 = pt1;
				FVector normal1;
				float length1;
				dd1.ToDirectionAndLength(normal1, length1);
				normal1 = normal1 * normalSign;
				normals[0] = normals[1] = -normal1;		// ��Ӧ����// ָ��Բ��

				FVector dd2 = pt2;
				FVector normal2;
				float length2;
				dd2.ToDirectionAndLength(normal2, length2);
				normal2 = normal2 * normalSign;
				normals[2] = normals[3] = -normal2;		// ��Ӧ����// ָ��Բ��

				FRotator rot;
				rot.Pitch = 0.0f;
				rot.Roll = 90.0f;
				rot.Yaw = 0.0f;
				FProcMeshTangent tangent1(rot.RotateVector(normal1), false);
				tangents[0] = tangents[1] = tangent1;// ����
				FProcMeshTangent tangent2(rot.RotateVector(normal2), false);
				tangents[2] = tangents[3] = tangent2;// ����
			}
			{
				//	UVx[0]--2
				//		|\  |
				//		| \ |
				//		|  \|
				//	UVx[1]--3
				UV0[0] = FVector2D(U0a , VUpper);
				UV0[1] = FVector2D(U0a , VBottom);
				UV0[2] = FVector2D(U0b , VUpper);
				UV0[3] = FVector2D(U0b , VBottom);

				UV1[0] = UV1[1] = UV1[2] = UV1[3] = FVector2D(pt1.X * 0.01f, pt1.Y * 0.01f);

				UV2[0] = UV2[1] = UV2[2] = UV2[3] = FVector2D(UV0[1].X , 0.0f);
			}
		}

	};


	TArray<MyRectangle> MyRectangles;
	TArray<float> U0;
	_WallDatas.Reset();

	{
		int32 count = segNum;
		TArray<FVector> points;
		float arcPerSeg = 2.0f * PI / segNum;
		float arc = 0.0f;

		float UValue = 0.0f; // ������ͼ�����Uֵ �ۼ�
		float UValuePerSeg = tileU / segNum;
				
		++count;
		for (int32 i = 0; i < count; ++i)
		{// ����Բ�ϵĵ�
			FVector pt;
			pt.Z = 0;
			float fsin(0), fcos(0);
			FMath::SinCos(&fsin, &fcos, arc);
			pt.X = fcos * radius;
			pt.Y = fsin * radius;
			
			points.Add(pt);
			arc += arcPerSeg;

			U0.Add(UValue);
			UValue += UValuePerSeg;
		}

		float absBottomOffset = FMath::Abs(bottomOffset);
		bool bottom = absBottomOffset > 30.00001f;

		//float ra = FMath::Abs(bottomOffset / upperOffset);
		//float bottomV = baseLineV;
		//float bottomV2 = (-upperV + 1.0f) * ra + 1.0f;


		for (int32 i = 1; i < count; ++i)
		{
			const FVector &pt1 = points[i - 1];
			const FVector &pt2 = points[i];

			MyRectangle myrect;
			float U0a = U0[i - 1];
			float U0b = U0[i];
			myrect.SetVertex(pt1, pt2 , upperOffset , U0a , U0b , upupV, upboV);
			MyRectangles.Add(myrect);

			FRegionWallData WallData;
			WallData.Begin = pt1 + location;
			WallData.End = pt2 + location;
			WallData.Normal = myrect.normals[0];
			//WallData.Yaw = yaw;
			_WallDatas.Add(WallData);

		}
		if (bottom)
		{
			for (int32 i = 1; i < count; ++i)
			{
				const FVector &pt1 = points[i - 1];
				const FVector &pt2 = points[i];
				MyRectangle myrect;
				float U0a = U0[i - 1];
				float U0b = U0[i];
				myrect.SetVertex(pt1, pt2, -absBottomOffset, U0a, U0b, boupV, boboV);
				MyRectangles.Add(myrect);
			}
		}

		if (_outterSide)
		{
			for (int32 i = 1; i < count; ++i)
			{
				const FVector &pt1 = points[i - 1];
				const FVector &pt2 = points[i];
				MyRectangle myrect;
				float U0a = U0[i - 1];
				float U0b = U0[i];
				myrect.SetVertexOutterSide(pt1, pt2, upperOffset, U0a, U0b, upupV, upboV);
				MyRectangles.Add(myrect);
			}
			if (bottom)
			{
				for (int32 i = 1; i < count; ++i)
				{
					const FVector &pt1 = points[i - 1];
					const FVector &pt2 = points[i];
					MyRectangle myrect;
					float U0a = U0[i - 1];
					float U0b = U0[i];
					myrect.SetVertexOutterSide(pt1, pt2, -absBottomOffset, U0a, U0b, upupV, boboV);
					MyRectangles.Add(myrect);
				}
			}
		}
	}

	{
		TArray<FVector> vertices;
		TArray<int32> triangle;
		TArray<FVector> normals;
		TArray<FProcMeshTangent> tangents;
		TArray<FVector2D> nUV0;
		TArray<FVector2D> nUV1;
		TArray<FVector2D> nUV2;
		TArray<FLinearColor> colors;
		TArray<FVector2D> empty2d;

		int32 count = MyRectangles.Num();
		for (int32 idx = 0 ; idx < count ; ++idx)
		{
			const MyRectangle &ver = MyRectangles[idx];
			vertices.Add(ver.vertices[0]);
			vertices.Add(ver.vertices[1]);
			vertices.Add(ver.vertices[2]);
			vertices.Add(ver.vertices[3]);

			normals.Add(ver.normals[0]);
			normals.Add(ver.normals[1]);
			normals.Add(ver.normals[2]);
			normals.Add(ver.normals[3]);

			tangents.Add(ver.tangents[0]);
			tangents.Add(ver.tangents[1]);
			tangents.Add(ver.tangents[2]);
			tangents.Add(ver.tangents[3]);

			nUV0.Add(ver.UV0[0]);
			nUV0.Add(ver.UV0[1]);
			nUV0.Add(ver.UV0[2]);
			nUV0.Add(ver.UV0[3]);

			nUV1.Add(ver.UV1[0]);
			nUV1.Add(ver.UV1[1]);
			nUV1.Add(ver.UV1[2]);
			nUV1.Add(ver.UV1[3]);

			nUV2.Add(ver.UV2[0]);
			nUV2.Add(ver.UV2[1]);
			nUV2.Add(ver.UV2[2]);
			nUV2.Add(ver.UV2[3]);

			int32 index = idx << 2;// ÿ�����η�Ƭ ��4����

			triangle.Add(ver.indices[0] + index);
			triangle.Add(ver.indices[1] + index);
			triangle.Add(ver.indices[2] + index);

			triangle.Add(ver.indices[3] + index);
			triangle.Add(ver.indices[4] + index);
			triangle.Add(ver.indices[5] + index);

		}
		if (_wallProceduralMeshComp != nullptr)
		{
			_wallProceduralMeshComp->UnregisterComponent();
			_wallProceduralMeshComp->DestroyComponent();
		}
		UProceduralMeshComponent *meshComp = NewObject<UProceduralMeshComponent>(this, TEXT("WallProceduralMeshComp"));
		_wallProceduralMeshComp = meshComp;
		_wallProceduralMeshComp->SetVisibility(GetWallVisible());

		meshComp->SetupAttachment(RootComponent);
		meshComp->RegisterComponent();
		if (_WallMaterial != nullptr)
		{
			meshComp->SetMaterial(0, _WallMaterial);
		}
		meshComp->TranslucencySortPriority = TranslucencySortPriority;
		meshComp->CreateMeshSection_LinearColor(0, vertices, triangle, normals, nUV0, nUV1, nUV2, empty2d, colors, tangents, true);

		meshComp->SetCollisionObjectType(ECollisionChannel::ECC_WorldStatic);
		meshComp->SetCollisionResponseToChannel(ECollisionChannel::ECC_Camera, ECollisionResponse::ECR_Ignore);
		meshComp->SetCollisionResponseToChannel(AzureUtility::TRACE_CHN_TERRAIN_BUILDING, ECollisionResponse::ECR_Block);
	}

}

UMaterialInterface* ARegionWallActor::GetWallMaterial_Implementation()
{
	UE_LOG(LogTemp, Warning, TEXT("GetWallMaterial"));
	return _WallMaterial;
}

UMaterialInterface* ARegionWallActor::GetWallMaterial2_Implementation(int32 p1,int32 p2 ,float p3)
{
	UE_LOG(LogTemp, Warning, TEXT("GetWallMaterial2 %d,%d,%f"), p1, p2 , p3);
	return _WallMaterial;
}
// Called when the game starts or when spawned
void ARegionWallActor::BeginPlay()
{
	Super::BeginPlay();
	
}

// Called every frame
void ARegionWallActor::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);
	if (_WallVisibleLast != GetWallVisible())
	{
		bool visble = GetWallVisible();
		for (UStaticMeshComponent* Comp : _StaticMeshComps)
		{
			Comp->SetVisibility(visble);
		}
		if (_wallProceduralMeshComp)
		{
			_wallProceduralMeshComp->SetVisibility(visble);
		}
		_WallVisibleLast = visble;
	}
	if (_EnableCollisionLast != GetCollisionEnabled())
	{
		//if (_ColiisionProceduralMeshComp)
		//{
		//	ECollisionEnabled::Type type = _ColiisionProceduralMeshComp->GetCollisionEnabled();
		//	UE_LOG(LogTemp , Warning , TEXT("type = (%d) %s(%d):") ,type, TEXT(__FILE__) , __LINE__);
		//	type = GetCollisionEnabled() ? ECollisionEnabled::Type::QueryAndPhysics : ECollisionEnabled::Type::NoCollision;
		//	UE_LOG(LogTemp , Warning , TEXT("type = (%d) %s(%d):") , type , TEXT(__FILE__) , __LINE__);
		//	_ColiisionProceduralMeshComp->SetCollisionEnabled(type);
		//}
		if (_wallProceduralMeshComp)
		{
			ECollisionEnabled::Type type = _wallProceduralMeshComp->GetCollisionEnabled();
			//UE_LOG(LogTemp, Warning, TEXT("type = (%d) %s(%d):"), type, TEXT(__FILE__), __LINE__);
			type = GetCollisionEnabled() ? ECollisionEnabled::Type::QueryAndPhysics : ECollisionEnabled::Type::NoCollision;
			//UE_LOG(LogTemp, Warning, TEXT("type = (%d) %s(%d):"), type, TEXT(__FILE__), __LINE__);
			_wallProceduralMeshComp->SetCollisionEnabled(type);
		}
		_EnableCollisionLast = GetCollisionEnabled();
	}
	if (GetDrawDebugLine())
	{
		FColor wallColor = FColor::Green;
		//if (_StaticMeshComp_1 != nullptr && _StaticMeshComp_1->GetCollisionEnabled())
		//{
		//	wallColor = FColor::Red;
		//}
		//if (_ColiisionProceduralMeshComp != nullptr && _ColiisionProceduralMeshComp->GetCollisionEnabled())
		if(GetCollisionEnabled())
		{
			wallColor = FColor::Red;
		}

		for (const FRegionWallData& wallData : _WallDatas)
		{
			DrawDebugLine(GetWorld() , wallData.Begin , wallData.End , _LineColor,false,-1.0f,0,LineThickness);
			FVector ll = wallData.End - wallData.Begin;
			FVector dir;
			float len;
			ll.ToDirectionAndLength(dir , len);
			int32 segs = (int32)(len * 0.02f); // ��� ÿ�γ��� 50 ���ּ���
			segs = FMath::Max(segs , 1);
			float segLen = len / segs;// ÿ��ƽ������

			for (int32 i = 0; i < segs; ++i)
			{// ������ ����ǽ
				FVector pt = wallData.Begin + dir * segLen * i;
				FVector pt2 = pt;
				pt2.Z += _DrawDebugLineLength;
				DrawDebugLine(GetWorld() , pt , pt2 , wallColor);
				//DrawDebugLine(GetWorld() , pt , pt2 , _LineColor , false , -1.0f , 0 , LineThickness);

			}
			if(wallData.DispNormal)
			{// �� ǽ����
				FVector middle = (wallData.Begin + wallData.End) * 0.5f;
				//FRotator rot(0.0f , wallData.Yaw , 0.0f);
				//FVector normal = rot.RotateVector(FVector::ForwardVector);
				middle.Z += 50.0f;
				FVector ptM = middle + wallData.Normal * 150;
				DrawDebugLine(GetWorld() , middle , ptM , FColor(0,0,255),false,-1.0f,0,10.0f);
			}

		}
	}
	
}

#if WITH_EDITOR

void ARegionWallActor::PostEditChangeProperty(FPropertyChangedEvent& PropertyChangedEvent)
{
	Super::PostEditChangeProperty(PropertyChangedEvent);

	FString propertyName = (PropertyChangedEvent.Property != NULL) ? PropertyChangedEvent.Property->GetName() : "";

	if (!propertyName.IsEmpty())
	{
		if (propertyName.Equals("_EnableCollision"))
		{
			this->SetActorEnableCollision(_EnableCollision);
		}
		//else if (propertyName.Equals("Width") || propertyName.Equals("Height"))
		//{
		//	ABezierSpline::ResizeBuffWidgets();
		//}
	}
}

void ARegionWallActor::PostEditChangeChainProperty(FPropertyChangedChainEvent& PropertyChangedEvent)
{
	Super::PostEditChangeChainProperty(PropertyChangedEvent);

	FString propertyName = (PropertyChangedEvent.Property != NULL) ? PropertyChangedEvent.Property->GetName() : "";
	FString MemberPropertyName = (PropertyChangedEvent.Property != NULL) ? PropertyChangedEvent.MemberProperty->GetName() : "";

	if (!MemberPropertyName.IsEmpty())
	{
		if (MemberPropertyName == "_EnableCollision")
		{
			this->SetActorEnableCollision(_EnableCollision);
		}
		//else if (MemberPropertyName.Equals("Width") || MemberPropertyName.Equals("Height"))
		//{
		//	ABezierSpline::ResizeBuffWidgets();
		//}
	}
}
#endif

void ARegionWallActor::AddWall(const FVector &begin , const FVector &end)
{
	AddWall(begin , end , DefaultWallThickness , DefaultWallHeight);
}

void ARegionWallActor::AddWall(const FVector &begin , const FVector &end ,float wallThickness,float wallHeight)
{
	if (_WallStaticMesh == nullptr)
	{
		UE_LOG(LogTemp , Warning , TEXT(" %s(%d): WallStaticMesh == nullptr!! The static mesh must be specified!!! ARegionActor::AddWall()") , TEXT(__FILE__) , __LINE__);
		return;
	}
	FRegionWallData WallData;
	WallData.Begin = begin;
	WallData.End = end;
	int32 count = _StaticMeshComps.Num();

	TArray<FStringFormatArg> args;
	args.Add(FStringFormatArg(count));
	FString name = FString::Format(TEXT("StaticMeshComp_{0}") , args);
	UStaticMeshComponent *StaticMeshComp = NewObject<UStaticMeshComponent>(this,*name);
	StaticMeshComp->SetStaticMesh(_WallStaticMesh);
	StaticMeshComp->SetupAttachment(RootComponent);
	//StaticMeshComp->AttachTo(RootComponent);
	StaticMeshComp->RegisterComponent();
	if (_WallMaterial != nullptr)
	{
		StaticMeshComp->SetMaterial(0,_WallMaterial);
	}
	FVector ll = end - begin;
	FVector dir;
	float len;
	ll.ToDirectionAndLength(dir,len);
	dir.Normalize();
	FRotator rotYaw(0.0f,90.0f,0.0f);
	FVector normal = rotYaw.RotateVector(dir);
	WallData.Normal = normal;
	float cosValue = FVector::ForwardVector.CosineAngle2D(normal);
	float yaw = FMath::Acos(cosValue);
	yaw = FMath::RadiansToDegrees(yaw);
	FVector cross = FVector::CrossProduct(FVector::ForwardVector, normal);
	FVector pos((end + begin) * 0.5f);// λ��ȡ��
	float xx = wallThickness / MeshSize.X;
	float yy = 1 / MeshSize.Y;
	float zz = wallHeight / MeshSize.Z;
	// 0.05f ,len * 0.01f , 5
	StaticMeshComp->SetWorldScale3D(FVector( xx ,len * yy , zz));// ԭʼ mesh�� 100*100*100
																 //		��   ��   ��
																 // Ŀ�� 5,   100, 500
	FVector actorLoc = GetActorLocation();
	pos.Z += wallHeight * 0.5f;
	if (cross.Z < 0.0f)
	{
		yaw = -yaw;
	}

	/*if (cross.Z < 0.0f)
	{
	yaw = -yaw + 90;
	}
	else
	{
	yaw -= 90;
	}*/
	WallData.Yaw = yaw;
	_WallDatas.Add(WallData);
	FRotator rotMesh(0.0f , yaw , 0.0f);
	StaticMeshComp->SetWorldLocationAndRotation(pos,rotMesh);
	//UE_LOG(LogTemp , Warning , TEXT(" %s") , *(rotMesh.ToString()));
	StaticMeshComp->SetCollisionObjectType(ECollisionChannel::ECC_WorldStatic);
	StaticMeshComp->SetCollisionResponseToChannel(ECollisionChannel::ECC_Camera,ECollisionResponse::ECR_Ignore);

	//if (_StaticMeshComp_1 == nullptr)
	//{
	//	_StaticMeshComp_1 = StaticMeshComp;
	//}
	//else if (_StaticMeshComp_2 == nullptr)
	//{
	//	_StaticMeshComp_2 = StaticMeshComp;
	//}
	//else if (_StaticMeshComp_3 == nullptr)
	//{
	//	_StaticMeshComp_3 = StaticMeshComp;
	//}
	//else if (_StaticMeshComp_4 == nullptr)
	//{
	//	_StaticMeshComp_4 = StaticMeshComp;
	//}
	//else if (_StaticMeshComp_5 == nullptr)
	//{
	//	_StaticMeshComp_5 = StaticMeshComp;
	//}
	//else if (_StaticMeshComp_6 == nullptr)
	//{
	//	_StaticMeshComp_6 = StaticMeshComp;
	//}
	//else if (_StaticMeshComp_7 == nullptr)
	//{
	//	_StaticMeshComp_7 = StaticMeshComp;
	//}
	//else if (_StaticMeshComp_8 == nullptr)
	//{
	//	_StaticMeshComp_8 = StaticMeshComp;
	//}
	//else if (_StaticMeshComp_9 == nullptr)
	//{
	//	_StaticMeshComp_9 = StaticMeshComp;
	//}
	//else if (_StaticMeshComp_10 == nullptr)
	//{
	//	_StaticMeshComp_10 = StaticMeshComp;
	//}

	_StaticMeshComps.Add(StaticMeshComp);
}


void ARegionWallActor::SetSceneIDRegionID(int32 SceneID , int32 RegionID)
{
	_SceneID	= SceneID;
	_RegionID	= RegionID;

#if WITH_EDITOR
	// Editor specific

	TArray<FStringFormatArg> args;
	args.Add(FStringFormatArg(SceneID));
	args.Add(FStringFormatArg(RegionID));
	FString name = FString::Format(TEXT("RegionWall_{0}_{1}") , args);

	SetActorLabel(name);
	SetFolderPath(TEXT("RegionWall"));
#endif // #if WITH_EDITOR

}
