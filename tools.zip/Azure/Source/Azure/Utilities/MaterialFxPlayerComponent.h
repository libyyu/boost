﻿// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Components/ActorComponent.h"
#include "MaterialFxPlayerComponent.generated.h"

class UPrimitiveComponent;
class UMaterialInterface;
class UMaterialInstanceDynamic;

UCLASS(Blueprintable, ClassGroup=(Custom), meta=(BlueprintSpawnableComponent) )
class AZURE_API UMaterialFxPlayerComponent : public UActorComponent
{
	GENERATED_BODY()

public:	
	// Sets default values for this component's properties
	UMaterialFxPlayerComponent();

protected:
	// Called when the game starts
	virtual void BeginPlay() override;

public:	
	// Called every frame
	virtual void TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction) override;

	UFUNCTION(BlueprintImplementableEvent, BlueprintCallable, Category = "MaterialFx")
		void PlayFx(UDataTable* Fx);
	UFUNCTION(BlueprintImplementableEvent, BlueprintCallable, Category = "MaterialFx")
		void PlayFxWithDurationScale(UDataTable* Fx, float DurationScale = 1);	/*cg用*/
	UFUNCTION(BlueprintImplementableEvent, BlueprintCallable, Category = "MaterialFx")
		void StopFx(UDataTable* Fx, bool SkipExit = false);
	UFUNCTION(BlueprintImplementableEvent, BlueprintCallable, Category = "MaterialFx")
		void Stop(bool SkipExit = false);
	UFUNCTION(BlueprintImplementableEvent, BlueprintCallable, Category = "MaterialFx")
		void CleanUp();
	UFUNCTION(BlueprintImplementableEvent, BlueprintCallable, Category = "MaterialFx")
		void OnModelChanged();
	UFUNCTION(BlueprintImplementableEvent, BlueprintCallable, Category = "MaterialFx")
		void ApplyBodyPart(int Mask);
	
	UFUNCTION(BlueprintImplementableEvent, BlueprintCallable, Category = "MaterialFx")
		bool IsPlaying();
	
	//给定一个材质，找出对应的原始材质，如果原始材质不是动态材质，会替换为动态材质
	UFUNCTION(BlueprintImplementableEvent, BlueprintCallable, Category = "MaterialFx")
		UMaterialInstanceDynamic* GetCorrespondingOriDynamicMaterial(UPrimitiveComponent* comp, UMaterialInterface *mat);
};
