#pragma once

#include "CoreMinimal.h"
#include "Engine/EngineTypes.h"

#if !defined(ENABLE_DRAW_DEBUG)
#define ENABLE_DRAW_DEBUG  !(UE_BUILD_SHIPPING || UE_BUILD_TEST)
#endif

#if ENABLE_DRAW_DEBUG

void DrawDebugSector(const UWorld* InWorld, const FVector& Center, const FRotator& Rotator, float Radius, float Angle, float Height, int32 Segments, const FColor& Color, bool bPersistentLines = false, float LifeTime = -1.f, uint8 DepthPriority = 0, float Thickness = 0.f);

void DrawDebug3DDonut(const UWorld* InWorld, const FVector& Center, const FRotator& Rotator, float InnerRadius, float OuterRadius, float Height, int32 Segments, const FColor& Color, bool bPersistentLines = false, float LifeTime = -1.f, uint8 DepthPriority = 0, float Thickness = 0.f);

#elif !defined(SHIPPING_DRAW_DEBUG_ERROR) || !SHIPPING_DRAW_DEBUG_ERROR

FORCEINLINE void DrawDebugSector(const UWorld* InWorld, const FVector& Center, const FRotator& Rotator, float Radius, float Angle, float Height, int32 Segments, const FColor& Color, bool bPersistentLines = false, float LifeTime = -1.f, uint8 DepthPriority = 0, float Thickness = 0.f) {}

FORCEINLINE void DrawDebug3DDonut(const UWorld* InWorld, const FVector& Center, const FRotator& Rotator, float InnerRadius, float OuterRadius, float Height, int32 Segments, const FColor& Color, bool bPersistentLines = false, float LifeTime = -1.f, uint8 DepthPriority = 0, float Thickness = 0.f) {}

#else

// Remove 'no-op' debug draw commands, users need to make sure they are not calling these functions in Shipping/Test builds or it will generate a compile error

#endif // ENABLE_DRAW_DEBUG
