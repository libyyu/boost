// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "HAL/PlatformTime.h"

#include <vector>
#include <assert.h>
#include "ABaseDef.h"

#include "wLuaCoreInterface.h"

/**
 * 
 */
DECLARE_STATS_GROUP(TEXT("AzureGroups"), STATGROUP_AzureGroups, STATCAT_Advanced);

class ECTimerList
{
public:

	struct Timer
	{
		int id;
		float ttl;
		float total_played;
		double begin_time;
		//double end_time;
		wLua::lua_registry_handle callback;
		wLua::lua_registry_handle cbparam;
		bool bOnce;
		bool bChangeWithTimeDilation;

#if STATS
		TStatId	StatID;
		void CreateStatID();
#endif
	};

	static int _uniqueid;

protected:

	avector<Timer> m_List;
	avector<Timer> m_TempList;
	avector<Timer> m_TickingList; //Tick ��֡���е�Timer
	avector<int> m_TempDelList;
	bool m_bTick = false;
	int m_iLastFrameTimerId; //��һ֡���µ�id����һִֻ֡�е������ڸ�id��timer
	uint64 m_iLastFrame;//��һ������timer��֡��

public:
	ECTimerList();
	~ECTimerList();

	static int total_count;

	FString GetTimerListIDs();
	

	int AddTimer(float ttl, bool bOnce, wLua::lua_registry_handle cb, wLua::lua_registry_handle cbparam, bool bChangeWithTimeDilation = false)
	{
		if (cb.IsNoRef())
		{
			assert(false);
			return 0;
		}

		Timer tm;
		tm.id = _uniqueid++;
		tm.ttl = ttl;
		tm.total_played = 0;

		double cur = FPlatformTime::Seconds();
		tm.begin_time = cur;
		//tm.end_time = cur + ttl;

		tm.callback = cb;
		tm.cbparam = cbparam;
		tm.bOnce = bOnce;
		tm.bChangeWithTimeDilation = bChangeWithTimeDilation;

#if STATS
		tm.CreateStatID();
#endif
		int id = tm.id;
		if (m_bTick)
			m_TempList.push_back(std::move(tm));
		else
		{
			m_List.push_back(std::move(tm));
			total_count++;
		}
		//���±�֡�����id��ע����Tick����ǰ��m_iLastFrameС�ڵ�ǰ֡����Tick������m_iLastFrame���ڵ�ǰ֡��
		//����ǰ֡��Tick�Ժ����ӵ�timerҲ����һִ֡�У�����֡Tick����ǰ���ӵ�Timer������ִ�У�
		if (GFrameCounter == m_iLastFrame) 
		{
			m_iLastFrameTimerId = _uniqueid;
		}
		return id;
	}

	//	-2: found but reach maxDuration and Removed
	//	-1: ticking
	//	0: not found
	//	> 0: found and delayed
	int DelayTimer(int id, float ttl, float maxDurationToRemove = -1);

	//	-1: Not Found..
	//	0: Removed
	//	1: to m_TempDelList
	int RemoveTimer(int id);

	void SetTimer(int id, float fNextPlayTime)
	{
		for (size_t i = 0; i < m_List.size(); i++)
		{
			Timer& tm = m_List[i];

			if (tm.id == id)
			{
				tm.total_played = 0;
				tm.begin_time = FPlatformTime::Seconds();

				tm.ttl = fNextPlayTime;
				return;
			}
		}

		for (size_t i = 0; i < m_TickingList.size(); i++) {
			Timer& tm = m_TickingList[i];

			if (tm.id == id)
			{
				tm.total_played = 0;
				tm.begin_time = FPlatformTime::Seconds();

				tm.ttl = fNextPlayTime;
				return;
			}
		}
	}

	void ResetTimer(int id, float ttl_new = -1)
	{
		for (size_t i = 0; i < m_List.size(); i++)
		{
			Timer& tm = m_List[i];

			if (tm.id == id)
			{
				if (ttl_new >= 0)
					tm.ttl = ttl_new;

				tm.total_played = 0;
				tm.begin_time = FPlatformTime::Seconds();
				return;
			}
		}
		for (size_t i = 0; i < m_TickingList.size(); i++) {
			Timer& tm = m_TickingList[i];

			if (tm.id == id)
			{
				if (ttl_new >= 0)
					tm.ttl = ttl_new;

				tm.total_played = 0;
				tm.begin_time = FPlatformTime::Seconds();
				return;
			}
		}
	}



	void Tick(float DeltaTime, float fOrgDeltaTime);

	void Clear();

	FString GetDebugInfo(TWeakObjectPtr<AActor> pObj, TMap<FString, int>& callbackCountMap);
	static FString GetAllDebugInfo();

	static TMap<ECTimerList*, TWeakObjectPtr<AActor>> s_instanceMap;
	static void RegisterTimerList(ECTimerList* timerList, AActor* pObj);
	static void UnregisterTimerList(ECTimerList* timerList);

protected:
	bool TickWithTimeDilation(const Timer& timer, float DeltaTime);
	bool TickWithAbsoluteTime(const Timer& timer, float DeltaTime);

	bool IsRemoved(int id);
};
