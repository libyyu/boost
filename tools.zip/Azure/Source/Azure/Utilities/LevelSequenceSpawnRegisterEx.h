// Copyright 1998-2018 Epic Games, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "LevelSequenceSpawnRegister.h"
#include "UObject/Class.h"


/** Movie scene spawn register that knows how to handle spawning objects (actors) for a level sequence  */
class FLevelSequenceSpawnRegisterEx : public FLevelSequenceSpawnRegister
{
public:
	FLevelSequenceSpawnRegisterEx();

	using FLevelSequenceSpawnRegister::SpawnObject;
	using FLevelSequenceSpawnRegister::DestroySpawnedObject;
};
