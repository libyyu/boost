// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Serialization/JsonSerializerMacros.h"
#include "Misc/SecureHash.h"

class FAzureAssetSizeMap : public FJsonSerializable
{
public:
	static FAzureAssetSizeMap& GetInstance()
	{
		static FAzureAssetSizeMap obj;
		return obj;
	}

	//  Interfaces
	bool LoadFromFile(const FString& filePath);
	uint32 GetAssetSize(const FName& assetName);
	uint64 GetAssetListSize(const TArray<FName>& assetList);
	void GetAssetListSizeDetail(const TArray<FName>& assetList, TMap<FName, uint32>& fileInfo);
	bool GetAssetDependencies(const FName& assetName, const FString& pattern, TSet<FName>& depends);
	bool IsInited() const { return Inited; }

	virtual void Serialize(FJsonSerializerBase& Serializer, bool bFlatObject) override;

protected:
	using FileInfo = TTuple<FMD5Hash, int64, int64, TArray<FName>>;	//	corresponding to <FileMD5, OrigFileSize, CompressedFileSize, DepFileNames>

	bool Inited = false;
	TMap<FName, uint32> InGameAssetSize;
	TMap<FName, FileInfo> InGameUpdateFiles;

	static const FMD5Hash& GetFileMD5(const FileInfo& InFileInfo);
	static int64 GetOrigFileSize(const FileInfo& InFileInfo);
	static int64 GetCompressedFileSize(const FileInfo& InFileInfo);
	static const TArray<FName>& GetDepFileNames(const FileInfo& InFileInfo);

	static bool IsFileInfoValid(const FileInfo& InFileInfo);

	//	Helpers
	static void SerializeMap(FJsonSerializerBase& Serializer, const TCHAR* Name, TMap<FName, FileInfo>& Value);

	bool Init();
	void CalcAssetSizeRecursively(const FName& fileName, const FileInfo& fileInfo, TSet<FName>& alreadyAdded, uint32& size);
	void AddFileInfoToMap(const FName& fileName, const FileInfo& fileInfo, TMap<FName, uint32>& sizeMap);
	void CollectDepends(const FName& assetName, const FString& pattern, const FileInfo& fileInfo, TSet<FName>& depends);
	const FileInfo* FindFileInfo(const FName& assetName, FName& fileName);

public:
	//	Helpers
	template <typename TValue>
	static void SerializeMap(FJsonSerializerBase& Serializer, const TCHAR* Name, TMap<FName, TValue>& Value)
	{
		if (Serializer.IsSaving())
		{
			Serializer.StartObject(Name);
			for (auto KeyValueIt = Value.CreateIterator(); KeyValueIt; ++KeyValueIt)
			{
				const FName& FieldName = KeyValueIt.Key();
				TValue FieldValue = KeyValueIt.Value();
				Serializer.Serialize(*FieldName.ToString(), FieldValue);
			}
			Serializer.EndObject();
		}
		else
		{
			Value.Empty();

			TSharedPtr<FJsonObject> JsonObject = Serializer.GetObject();
			if (JsonObject->HasTypedField<EJson::Object>(Name))
			{
				const TSharedPtr<FJsonObject>& JsonMap = JsonObject->GetObjectField(Name);
				for (auto KeyValueIt = JsonMap->Values.CreateConstIterator(); KeyValueIt; ++KeyValueIt)
				{
					const FString& FieldName = KeyValueIt.Key();
					TValue FieldValue;
					bool bRet = JsonMap->TryGetNumberField(FieldName, FieldValue);
					check(bRet);

					Value.Emplace(FName(*FieldName), FieldValue);
				}
			}
		}
	}

	static void SerializeMap(FJsonSerializerBase& Serializer, const TCHAR* Name, TMap<FName, TArray<FName>>& Value);
	static void SerializeArray(FJsonSerializerBase& Serializer, const TCHAR* Name, TArray<FName>& Value);
	static TArray<FString> NameArray2StringArray(const TArray<FName>& NameArray);
	static TArray<FName> StringArray2NameArray(const TArray<FString>& StringArray);
};