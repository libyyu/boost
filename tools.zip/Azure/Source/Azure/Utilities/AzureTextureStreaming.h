// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "UObject/WeakObjectPtr.h"

class AActor;
class UTexture2D;

/**
* Force streaming all mip levels of given actors
*/
class AZURE_API FAzureFullMipsManager
{
public:
	static FAzureFullMipsManager& Get();

	void Enable();
	void Disable();
	bool IsEnabled()const;

	void Reset();

	void AddActor(AActor* InActor, FName InTag=NAME_None);
	void RemoveActor(AActor* InActor);
	void RemoveActorByTag(FName InTag);
	void ListActors()const;
	void ListTextures()const;

	void Update();

private:
	typedef TMap<TWeakObjectPtr<AActor>, FName> Actors;
	typedef TArray<TWeakObjectPtr<UTexture2D>> Textures;

	void CollectTextures(Textures& OutTextures)const;
	void CollectActorsIncludingAttached(TArray<const AActor*>& OutActors)const;
	void CollectTexturesInActor(const AActor* InActor, Textures& OutTextures)const;

	void ClearTexturesWhenTextureStreamingClosed();
	void UpdateTexturesWhenTextureStreamingOpen();

	void ClearTextureReserveMemory();
	void ClearTextureClearMemory();
	void ClearForceMiplevelsToBeResident(Textures& InTextures);
	void ForceMiplevelsToBeResident(Textures& InTextures);
	void SetTextureForceResidentFlag(Textures& InTextures, bool bForceMiplevelsToBeResident);

private:
	mutable Actors   RegisteredActors;
	Textures FullMipTextures;
	bool     bSavedTextureStreamingEnabled = false;
	bool	 bEnabled = true;
};
