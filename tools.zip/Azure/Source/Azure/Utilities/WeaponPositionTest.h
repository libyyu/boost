// Fill out your copyright notice in the Description page of Project Settings.

#pragma once
//�ǳ������ƣ�������
#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "Animation/SkeletalMeshActor.h"
#include "Engine/DataTable.h"
#include "WorldCollision.h"
#include <vector>
#include "WeaponPositionTest.generated.h"

USTRUCT(Blueprintable)
struct FWeaponPositionData:public FTableRowBase
{
	GENERATED_USTRUCT_BODY()

		UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "TableSetting")
		FString sex;

		UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "TableSetting")
		FString animname;

		UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "TableSetting")
		int32 frameRate;

		UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "TableSetting")
		int32 index1;

		UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "TableSetting", meta = (DisplayName = "size1 (1,1,1)"))
			FString size1;

		UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "TableSetting", meta = (DisplayName = "offset1 (1,1,1)"))
			FString offset1;

		UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "TableSetting")
			int32 index2;

		UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "TableSetting", meta = (DisplayName = "size2 (1,1,1)"))
			FString size2;

		UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "TableSetting", meta = (DisplayName = "offset2 (1,1,1)"))
			FString offset2;
};

UCLASS(Blueprintable)
class AZURE_API AWeaponPositionTest : public AActor
{
	GENERATED_BODY()
	
public:	
	// Sets default values for this actor's properties
	AWeaponPositionTest();

protected:
	// Called when the game starts or when spawned
	virtual void BeginPlay() override;

public:	
	struct WeaponPositionData
	{
			FString sex;
			FString animname;
			int32 frameRate;
			int32 index1;
			std::vector<float> size1;
			std::vector<float> offset1;
			int32 index2;
			std::vector<float> size2;
			std::vector<float> offset2;
			WeaponPositionData()
			{
				reset();
			}
			void reset()
			{
				frameRate = 120;
				index1 = -1;
				index2 = -1;
				size1.clear();
				offset1.clear();
				size2.clear();
				offset2.clear();
			}
	};

	struct CollisionObjInfo
	{
		TWeakObjectPtr<USceneComponent> object;
		FTransform defalutTransform;
		int	WeaponIndex;
		CollisionObjInfo()
		{
			object = NULL;
			WeaponIndex = -1;
		}
	};
	// Called every frame
	virtual void Tick(float DeltaTime) override;

	UFUNCTION(BlueprintCallable, Category = "WeaponTrans")
	void PushCollision(const int type, const float var1, const float var2, const float var3);

	UFUNCTION(BlueprintCallable, Category = "WeaponTrans")
	float GetLength(const USkeletalMeshComponent* MeshCom, const UStaticMesh* StaticMesh, FString& OutPath);

	UFUNCTION(BlueprintCallable, Category = "WeaponTrans")
	float SetOutPath(UAnimMontage* AnimMontage, const FString& InPath);

	struct TransformVariable
	{
		float a[10];
		float& operator[](int i)    //���ܴ���9��
		{
			return a[i];
		}
	};

	TArray<TransformVariable> WeaPonTransform;
	TArray<FCollisionShape> Collisions;
	UFUNCTION(BlueprintCallable, Category = "WeaponTrans")
	void PushData(const FTransform& T1, const FTransform& T2, const int FrameNum);

	struct CollisionInformation
	{
		int FrameNum;
		int WeaponIndex;
		FCollisionShape CollisionShape;
		float var[9];
	};
	TArray<CollisionInformation> CollisionInfos;
	UFUNCTION(BlueprintCallable, Category = "WeaponTrans")
	void PushCollisionData(const int FrameNum, const int WeaponIndex, const FVector4 CollisionInfo, const FTransform& T1, const FTransform& T2);

	FString Path;
	UFUNCTION(BlueprintCallable, Category = "WeaponTrans")
	void SaveWeaponTransform();

	UFUNCTION(BlueprintCallable, Category = "WeaponTrans")
	void SaveCollisionInfos();

	UFUNCTION(BlueprintCallable, Category = "WeaponTrans")
	bool checkDoNext();

	UFUNCTION(BlueprintCallable, Category = "WeaponTrans")
	void initCollisionObjects(USceneComponent* obj, const int WeaponIndex);

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "WeaponTrans")
	int32 FrameRate = 120;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "WeaponTrans")
	ASkeletalMeshActor* Person;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "WeaponTrans")
	AActor* PersonActor;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "WeaponTrans")
	TArray < AActor*> Weapons;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "WeaponTrans")
	UDataTable* data;

	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "WeaponTrans")
	float Length;

	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "WeaponTrans")
	TArray < UActorComponent*> CollisionContainer;

private:
	virtual void initWeaponPositionData(FWeaponPositionData* info);

protected:
	TArray<FWeaponPositionData*> datas;

	WeaponPositionData weaponData;

	TArray <CollisionObjInfo> collisionObjInfos;

	UPROPERTY(Transient)
	AActor* FemaleActor;
	UPROPERTY(Transient)
	AActor* MaleActor;
	UPROPERTY(Transient)
	AActor* FemalePersonActor;
	UPROPERTY(Transient)
	AActor* MalePersonActor;
};
