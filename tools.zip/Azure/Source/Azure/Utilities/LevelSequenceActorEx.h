﻿// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "UObject/ObjectMacros.h"
#include "Misc/Guid.h"
#include "LevelSequenceActor.h"
#include "Curves/RichCurve.h"
#include "Materials/MaterialInstance.h"
#include "Channels/MovieSceneFloatChannel.h"
#include "Tracks/MovieScene3DTransformTrack.h"
#include "MovieScene.h"
#include "Utilities/CGDefines.h"
#include "wLua/LuaInterface.h"
#include "Camera/CameraComponent.h"
#include "Components/SceneCaptureComponent2D.h"
#include "Engine/TextureRenderTarget2D.h"
#include "Utilities/LevelSequencePlayerEx.h"
#include "Sections/MovieSceneEventSection.h"
#include "LevelSequenceActorEx.generated.h"

/**
 * 
 */
USTRUCT()
struct FCAMERA_OFFSET_EX
{
public:
	GENERATED_USTRUCT_BODY()

	FGuid guid;
	float z;
	float PitchOffset;
	uint32 sequenceID;
	FCAMERA_OFFSET_EX():guid(),z(0), PitchOffset(0), sequenceID(0)
	{

	}

};

struct FAzureSequenceIDStack
{
	/** Get the current accumulated sequence ID */
	FMovieSceneSequenceID GetCurrent() const;
	/** Push a sequence ID onto the stack */
	void Push(FMovieSceneSequenceID InSequenceID) { IDs.Add(InSequenceID); }

	/** Pop the last sequence ID off the stack */
	void Pop() { IDs.RemoveAt(IDs.Num() - 1, 1, false); }

private:
	TArray<FMovieSceneSequenceID> IDs;
};

struct ShotSequenceNode
{
	TWeakObjectPtr<UMovieScene> movieScene;
	TWeakObjectPtr<UMovieSceneSequence> msSequence;
	FMovieSceneSequenceID id;
	FMovieSceneSequenceTransform RootToSequenceTransform;
	uint32 parentNodeIndex;

	ShotSequenceNode(UMovieScene* _movieScene, UMovieSceneSequence* _msSequence, FMovieSceneSequenceID _id)
		:movieScene(_movieScene), msSequence(_msSequence), id(_id), parentNodeIndex(-1){};
};

struct AzureSequenceNodeHierarchy
{
public:
	void Init(ULevelSequence* rootLevelSequence);

	ShotSequenceNode* FindNode(FMovieSceneSequenceID id);

	TArray <ShotSequenceNode> GetSequenceNodeArray() { return allMoviScenes; };
private:
	void CollectAllMovieScene(ULevelSequence* rootLevelSequence);

	void CollectAllMovieScene(int parentNodeIndex, FAzureSequenceIDStack &idStack);

private:
	TArray<ShotSequenceNode> allMoviScenes;
};

struct CGEventInfo
{
	FEventPayload eventPayload;
	FFrameNumber frameNumber;
	
	CGEventInfo(FEventPayload _eventPayload, FFrameNumber _frameNumber) :eventPayload(_eventPayload), frameNumber(_frameNumber)
	{
	};

	CGEventInfo()
	{
	};
};


UCLASS()
class AZURE_API ALevelSequenceActorEx : public ALevelSequenceActor
{
	GENERATED_BODY()


	
public:
	ALevelSequenceActorEx(const FObjectInitializer& Init);

	virtual void BeginPlay() ;
	virtual void EndPlay(const EEndPlayReason::Type EndPlayReason) override;

	UFUNCTION(BlueprintCallable, Category = "Game|Cinematic")
	void SetSequenceEx(ULevelSequence* InSequence, int cgid);

	void InitializePlayerEx();

	UFUNCTION()
	void AddBindingSceneObj(AActor* actor, const FString& strCGTrackDisplayName, const FString& strCGTrackGUID, const uint32 sequenceID);

	UFUNCTION()
	void RemoveBindingSceneObj(AActor* actor, const FString& strCGTrackDisplayName, const FString& strCGTrackGUID, const uint32 sequenceID);

	UFUNCTION()
	UObject* FindSpawnedObject(const FString& strCGTrackDisplayName, const FString& strCGTrackGUID, const uint32 sequenceID);

	UObject* FindSpawnedObject(const FGuid& cgTrackGUID, const uint32 sequenceID);

	UFUNCTION()
	UObject* FindBindingObject(const FString& strCGTrackDisplayName, const FString& strCGTrackGUID, const uint32 sequenceID);

	UObject* FindBindingObject(const FString& strCGTrackDisplayName, const FGuid& cgTrackGUID, const uint32 sequenceID, const bool warningWhenNotFind = true);

	UFUNCTION()//从游戏相机混入/混出cg相机
	bool FadeGameCamera(const FString& strCGTrackGUID, uint32 sequenceID, bool bReplaceFirstKey, bool bReplaceEndKey, bool bSetCameraByEndKey);

	UFUNCTION()
	void CreateCameraOffset(const FString& strCameraTrackGUID, uint32 sequenceID, float z, float PitchOffset);
	UFUNCTION()
	void RemoveCameraOffset(const FString& strCameraTrackGUID, uint32 sequenceID);
	
	UFUNCTION()
	void SetCurWorld(FString strWorld) { m_strWorld = strWorld;  }

	UFUNCTION()
	ULevelSequencePlayerEx* GetSequencePlayerEx()
	{
		return Cast<ULevelSequencePlayerEx>(SequencePlayer);
	}

	void CheckLevelSequenceEx();
	void OnStartedPlaying();
	void OnStopped();
	void OnPaused();

	virtual void ProcessEvent(UFunction* Function, void* Parameters) override;
	virtual void Tick(float DeltaSeconds) override;
	
	void RotationUpdateOrAddKey(FMovieSceneFloatChannel& curve, int frame, float v, float key_value);

	UWorld* GetWorldEx(); 
	FString m_strWorld;

	int m_cgid = 0;

	
	UPROPERTY()
	TArray<FCAMERA_OFFSET_EX> m_aCamerOffset;

	TMap <TWeakObjectPtr<ULevel>, TArray<TWeakObjectPtr<AActor>>> m_notHideByCGActorMap;
	//除cg控制对象外，隐藏关卡中固有的所有物体
	UFUNCTION()
	void SetLevelVisibleExcludeCG(ULevel* level, bool bActive);

	//除cg控制对象外，隐藏大世界中固有的所有物体
	UFUNCTION()
	void SetWorldStreamingVisibleExcludeCG(bool bActive);

	UFUNCTION()
	UObject* SpawnObjectByTrack(const FString & strCGTrackDisplayName, const FString& strCGTrackGUID, const FString &sequenceIDStr);
	UObject* SpawnObjectByTrack(const FGuid trackGUID, const FMovieSceneSequenceID sequenceID);

	UFUNCTION()
	void DestroySpawnObjectByTrack(UObject *Obj);

public:
	UPROPERTY(EditAnywhere)
	bool enableFadeCameraCollisionCheck = false;

private:
	void SetLevelVisibleExclude(ULevel* level, bool bActive, const TSet<UObject*> & excludeActors);

	TSet<UObject*> GetLevelSequenceContrlActors();

	//此处假设不会有重复的subSequnence，否则找出来的id不对
	FMovieSceneSequenceID FindObjectGUIDOwnerSequnenceID(FGuid guid);
	FMovieSceneSequenceID FindObjectGUIDOwnerSequnenceID(UMovieScene *movieScene, FGuid guid, FMovieSceneRootOverridePath& overridePath);
	bool IsObjectGUIDBeContryBy(UMovieScene *movieScene, FGuid guid);

public:
	// 主角平滑过渡相关
	UFUNCTION()
	bool GetHostBeginTransform(FTransform &outTrans);

	UFUNCTION()
	bool lua_GetTransformTrackValue(const FString & strCGTrackDisplayName, const FString& strCGTrackGUID, const FString &sequenceIDStr, bool isEndKey, FTransform &outTrans);

	void lua_GetEventsDataByName(FString eventName, lua_State * L);

	static bool lua_PushEventDataToLua(UProperty* HeadProperty, void* Parameters, lua_State * L);

private:
	bool GetTransformTrackValue(FGuid trackId, FMovieSceneSequenceID seqId, FTransform &outTrans, bool isEndKey = false);
	CGEventInfo FindEventByName(UMovieScene* pMovieScene, FString eventName);
	TArray<CGEventInfo>  FindEventsByName(UMovieScene* pMovieScene, FString eventName, bool justFindOne = false);

	// 混入/出cg相机
	void UpdateFadeInOutCamera();

	// 应用相机轨道的offset
	void ApplyCameraTrackOffset(IMovieScenePlayer* pPlayer);

	// 更新播放速度
	void UpdateTimeDilation(IMovieScenePlayer* pPlayer);

	// 运行时绑定的actor是否还生成
	void SetRuntimeBindingSpawnEnable(bool enable);
	void SetRuntimeBindingSpawnEnable(UMovieSceneSequence* msSequence, bool enable);
	//找出子cg
	ShotSequenceNode* FindMovieScenesNode(const FMovieSceneSequenceID &seID);
	AzureSequenceNodeHierarchy sequenceNodeHierarchy;


private:
	// 相机由当前平滑过渡
	bool m_bEnableFadeCamera = false;
	FGuid m_AdjustCameraGuid;
	FMovieSceneSequenceID m_AdjustCameraSequenceID;
	FMovieSceneFloatChannel m_TranslationCurve[3];
	FMovieSceneFloatChannel m_RotationCurve[3];
	bool m_bHasFovTrack = false;
	FMovieSceneFloatChannel m_FovCurve;

	FVector m_cgCameraEndKeyLocation;
	FRotator m_cgCameraEndKeyRotation;
	FVector m_gameCamLocationFirst;
	FRotator m_gameCamRotationFirst;

	bool m_bReplaceEndKey;
	bool m_bReplaceFirstKey;
	bool m_bSetCameraByEndKey;
	
	FVector m_previousTranslationOffset = FVector::ZeroVector;
	FRotator m_previousRotationOffset = FRotator::ZeroRotator;

	//rendertexture
public:
	UFUNCTION(BlueprintCallable)
	void DissolveCameraScreenShot(UCameraComponent *cameraComp, UTextureRenderTarget2D* rtTexture, float dissolveTime);

private:
	UPROPERTY(EditAnywhere)
	USceneCaptureComponent2D *captureComp;

#if UE_EDITOR
	TWeakObjectPtr<ULevelSequence> editorLevelSequencePtr;
#endif

	//杂项
public:
	UFUNCTION(BlueprintCallable)
	void SetPlaybackSettingStartOffset(float startOffset);

	UFUNCTION(BlueprintCallable)
	void SetPlaybackSettingLoopCount(int loopCount);

private:
	static void lua_PushCGTrackStructToLua(const struct FCGTrackStruct* CGTrack, lua_State * L);
	static const FString InvalideTrackGUIDStr;
};
