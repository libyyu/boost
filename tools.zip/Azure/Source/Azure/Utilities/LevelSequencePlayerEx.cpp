// Fill out your copyright notice in the Description page of Project Settings.

#include "LevelSequencePlayerEx.h"
#include "Azure.h"
#include "LevelSequenceActorEx.h"
#include "GameFramework/WorldSettings.h"
#include "Evaluation/MovieScenePlayback.h"
#include "AzureEntryPoint.h"
#include "LevelSequenceSpawnRegisterEx.h"
#include "Tracks/IMovieSceneTransformOrigin.h"

ULevelSequencePlayerEx::ULevelSequencePlayerEx(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
	SpawnRegister = MakeShareable(new FLevelSequenceSpawnRegisterEx);
}


void ULevelSequencePlayerEx::UpdateOffset(const float DeltaSeconds)
{
	if (IsPlaying())
	{
		if (TranslationOffsetFollowObj.IsValid())
		{
			TranslationOffset = TranslationOffsetFollowObj->GetActorLocation();
			RotationOffset = TranslationOffsetFollowObj->GetActorRotation();
			bEnableOffset = true;
		}
	}
}

void ULevelSequencePlayerEx::OnStartedPlaying()
{
	LastCameraObject = nullptr;
	Super::OnStartedPlaying();
	ALevelSequenceActorEx* pLevelSequenceActorEx = Cast<ALevelSequenceActorEx>(GetOuter());
	if (pLevelSequenceActorEx)
		pLevelSequenceActorEx->OnStartedPlaying();
}

void ULevelSequencePlayerEx::OnStopped()
{
	Super::OnStopped();
	ALevelSequenceActorEx* pLevelSequenceActorEx = Cast<ALevelSequenceActorEx>(GetOuter());
	if (pLevelSequenceActorEx)
		pLevelSequenceActorEx->OnStopped();
}

void ULevelSequencePlayerEx::OnPaused()
{
	Super::OnPaused();

	ALevelSequenceActorEx* pLevelSequenceActorEx = Cast<ALevelSequenceActorEx>(GetOuter());
	if (pLevelSequenceActorEx)
		pLevelSequenceActorEx->OnPaused();
}

bool ULevelSequencePlayerEx::GetTransformOffset(FVector &translation, FRotator &rotation)
{
	if (bEnableOffset)
	{
		translation = TranslationOffset;
		rotation = RotationOffset;
	}
	return bEnableOffset;
}

bool ULevelSequencePlayerEx::GetTransformOrigin(FTransform &TransformOrigin)
{
	const UObject* InstanceData = GetInstanceData();
	const IMovieSceneTransformOrigin* RawInterface = Cast<IMovieSceneTransformOrigin>(InstanceData);
	const bool bHasInterface = RawInterface || (InstanceData && InstanceData->GetClass()->ImplementsInterface(UMovieSceneTransformOrigin::StaticClass()));

	if (RawInterface)
	{
		TransformOrigin = RawInterface ? RawInterface->GetTransformOrigin() : IMovieSceneTransformOrigin::Execute_BP_GetTransformOrigin(InstanceData);
		return true;
	}
	return false;
}

void ULevelSequencePlayerEx::SetTransformOffset(FVector &translation, FRotator &rotation)
{
	TranslationOffset = translation;
	RotationOffset = rotation;
	bEnableOffset = true;
}

void ULevelSequencePlayerEx::SetTransformOffsetFollowObj(AActor *pActor)
{
	TranslationOffsetFollowObj = pActor;
}

//
//UObject* ULevelSequencePlayerEx::GetPlaybackContext() const
//{
//	ALevelSequenceActorEx* pLevelSequenceActorEx = Cast<ALevelSequenceActorEx>(GetOuter());
//	if (pLevelSequenceActorEx&&pLevelSequenceActorEx->GetCurWorld())
//		return pLevelSequenceActorEx->GetCurWorld();
//	return AAzureEntryPoint::Instance->GetWorld();
//}

int32 ULevelSequencePlayerEx::GetCurrentFrameTime()
{
	FFrameTime Time = PlayPosition.GetCurrentPosition();

	return Time.GetFrame().Value;
}

float ULevelSequencePlayerEx::GetCurrentTimeAsSeconds()
{
	float curTime = GetCurrentTime().AsSeconds();
	float startTime = GetStartTime().AsSeconds();
	return  curTime - startTime;
}

float ULevelSequencePlayerEx::TranslateFrameToSeconds(int32 frameNumber)
{
	FFrameTime time(frameNumber);
	return (float) FQualifiedFrameTime(time, PlayPosition.GetInputRate()).AsSeconds();
}

FFrameTime ULevelSequencePlayerEx::GetNewTime()
{
	FMovieSceneEvaluationRange CurrentTimeRange = PlayPosition.GetCurrentPositionAsRange();
	const FMovieSceneContext Context(CurrentTimeRange, EMovieScenePlayerStatus::Playing);
	return Context.GetTime();
}

UObject * ULevelSequencePlayerEx::SpawnObjectByTrack(const FGuid trackGUID, UMovieSceneSequence* Sequence, const FMovieSceneSequenceID sequenceID)
{
	if (Sequence)
	{
		UMovieScene& MovieScene = *Sequence->GetMovieScene();
		FMovieSceneSpawnable* Spawnable = MovieScene.FindSpawnable(trackGUID);
		if (Spawnable)
		{
			FMovieSceneSpawnRegister& spawnRegister = GetSpawnRegister();
			FLevelSequenceSpawnRegisterEx* spawnRegisterEx = static_cast<FLevelSequenceSpawnRegisterEx*>(&spawnRegister);
			UObject* SpawnedActor = spawnRegisterEx->SpawnObject(*Spawnable, sequenceID, *this);
			return SpawnedActor;
		}
	}
	return nullptr;
}


void ULevelSequencePlayerEx::DestroySpawnObjectByTrack(UObject *Obj)
{
	if (!Obj) return;

	FMovieSceneSpawnRegister& spawnRegister = GetSpawnRegister();
	FLevelSequenceSpawnRegisterEx* spawnRegisterEx = (FLevelSequenceSpawnRegisterEx*)&spawnRegister;
	spawnRegisterEx->DestroySpawnedObject(*Obj);
}
