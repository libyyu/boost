#include "AzureOpenGLPBO.h"

#if HAS_AZURE_OPENGL_PBO
#include "OpenGLUtil.h"

FRHIAzureOpenGLPBO::FRHIAzureOpenGLPBO(int32 dataSize, GLenum usage, bool needFbo)
	: FRHIAzureOpenGLPBO()
{
	DataSize = dataSize;
	Usage = usage;

	if (GIsRHIInitialized)
	{
		AzureRunOnGLRenderContextThread([this, dataSize, usage, needFbo]()
		{
			glGenBuffers(1, &PboId);
			glBindBuffer(GL_PIXEL_PACK_BUFFER, PboId);
			glBufferData(GL_PIXEL_PACK_BUFFER, dataSize, nullptr, GL_STREAM_READ);
			glBindBuffer(GL_PIXEL_PACK_BUFFER, 0);

			if (needFbo)
				glGenFramebuffers(1, &FboId);
		});
	}
}

FRHIAzureOpenGLPBO::~FRHIAzureOpenGLPBO()
{
	if (GIsRHIInitialized)
	{
		GLuint pboId = PboId;
		GLuint fboId = FboId;
		AzureRunOnGLRenderContextThread([pboId, fboId]()
		{
			if (pboId != 0)
			{
				glDeleteBuffers(1, &pboId);
			}
			if (fboId != 0)
			{
				glDeleteFramebuffers(1, &fboId);
			}
		});
	}
}

void AzureRunOnGLRenderContextThread(TFunction<void(void)> GLFunc, bool bWaitForCompletion)
{
	FRHICommandListImmediate& RHICmdList = FRHICommandListExecutor::GetImmediateCommandList();
	if (ShouldRunGLRenderContextOpOnThisThread(RHICmdList))
	{
		GLFunc();
	}
	else
	{
		new (RHICmdList.AllocCommand<FRHICommandGLCommand>()) FRHICommandGLCommand(MoveTemp(GLFunc));
		if (bWaitForCompletion)
		{
			RHITHREAD_GLTRACE_BLOCKING;
			RHICmdList.ImmediateFlush(EImmediateFlushType::FlushRHIThread);
		}
	}
}

#endif
