﻿#include "AzureSystemInfo.h"
#include "HAL/PlatformProcess.h"
#include "DynamicRHI.h"
#include <algorithm>

#if PLATFORM_DESKTOP
#include "Engine.h"

#elif PLATFORM_IOS
#import <UIKit/UIKit.h>
#include "IOS/IOSSystemIncludes.h"
#include "IOSView.h"
#include "IOSAppDelegate.h"
#include "IOSApplication.h"
#include <Metal/Metal.h>
namespace
{
	FString GetIOSDeviceModel()
	{
		//	copied from FIOSPlatformMisc::GetIOSDeviceType()

		// get the device hardware type string length
		size_t DeviceIDLen;
		sysctlbyname("hw.machine", NULL, &DeviceIDLen, NULL, 0);

		// get the device hardware type
		char* DeviceID = (char*)malloc(DeviceIDLen);
		sysctlbyname("hw.machine", DeviceID, &DeviceIDLen, NULL, 0);

		// convert to NSString
		NSString *DeviceIDString = [NSString stringWithCString : DeviceID encoding : NSUTF8StringEncoding];
		FString DeviceIDFstring = FString(DeviceIDString);
		free(DeviceID);

		return DeviceIDFstring;
	}
	bool GetIOSSupportASTC()
	{
#if HAS_METAL
		FIOSView* IOSView = [IOSAppDelegate GetDelegate].IOSView;
		if (IOSView && IOSView->bIsUsingMetal)
		{
			id<MTLDevice> Device = IOSView->MetalDevice;
			return[Device supportsFeatureSet : MTLFeatureSet_iOS_GPUFamily2_v1];	//	see FMetalDynamicRHI::FMetalDynamicRHI
		}
#endif
		return false;
	}
}

bool IOS_SupportsFeatureSet(int gpuFamily)
{
#if HAS_METAL
	FIOSView* IOSView = [IOSAppDelegate GetDelegate].IOSView;
	if (IOSView && IOSView->bIsUsingMetal)
	{
		id<MTLDevice> Device = IOSView->MetalDevice;
		return[Device supportsFeatureSet : (MTLFeatureSet)gpuFamily];	//	see FMetalDynamicRHI::FMetalDynamicRHI
	}
#endif
	return false;
}

#elif PLATFORM_ANDROID
#include "AndroidWindow.h"
#include "AndroidJNI.h"
#include "AndroidApplication.h"
#include "Misc/SecureHash.h"
namespace
{
	FString GetAndroidID()
	{
		FString Result;
		while (JNIEnv* Env = FAndroidApplication::GetJavaEnv())
		{
			//	import android.provider.Settings
			//	String ANDROID_ID = Settings.System.getString(getContentResolver(), Settings.System.ANDROID_ID);

			//	retrieve getContentResolver() result
			jclass ContextClass = FJavaWrapper::FindClass(Env, "android/content/Context", true);
			if (ContextClass == 0)
			{
				break;
			}
			jmethodID getContentResolverMethod = FJavaWrapper::FindMethod(Env, ContextClass, "getContentResolver", "()Landroid/content/ContentResolver;", true);
			if (getContentResolverMethod == 0)
			{
				break;
			}
			jobject ContentResolver = FJavaWrapper::CallObjectMethod(Env, FJavaWrapper::GameActivityThis, getContentResolverMethod);
			if (ContentResolver == 0)
			{
				break;
			}

			jclass SettingsSecureClass = FJavaWrapper::FindClass(Env, "android/provider/Settings$Secure", true);
			if (SettingsSecureClass == 0)
			{
				break;
			}

			//	retrieve Settings.System.getString method, it's static
			jmethodID getStringMethod = FJavaWrapper::FindStaticMethod(Env, SettingsSecureClass, "getString", "(Landroid/content/ContentResolver;Ljava/lang/String;)Ljava/lang/String;", true);
			if (getStringMethod == 0)
			{
				break;
			}

			//	retrieve Settings.System.ANDROID_ID, it's static
			jstring Settings_System_ANDROID_ID = (jstring)FJavaWrapper::GetStaticObjectField(Env, SettingsSecureClass, "ANDROID_ID", "Ljava/lang/String;", true);
			if (Settings_System_ANDROID_ID == 0)
			{
				break;
			}

			//	retrieve Settings.System.getString(getContentResolver(), Settings.System.ANDROID_ID);
			jstring ANDROID_ID = (jstring)FJavaWrapper::CallStaticObjectMethod(Env, SettingsSecureClass, getStringMethod, ContentResolver, Settings_System_ANDROID_ID);
			if (ANDROID_ID == 0)
			{
				break;
			}
			Result = FJavaWrapper::GetStringUTFChars(Env, ANDROID_ID);
			break;
		}
		return Result;
	}
}

#include "OpenGLDrv.h"

namespace
{
	//	code copied from PlatformInitOpenGL() within AndroidOpenGL.cpp, please update this function when engine upgraded
	//	Init FAndroidOpenGL::CurrentFeatureLevelSupport before create FOpenGLDynamicRHI,
	//	so than we can use FAndroidOpenGL::GetFeatureLevel() within config_engine.lua
	void InitAndroidOpenGLFeatureLevelSupportBeforeCreateOpenGLDynamicRHI()
	{
		if (!FAndroidMisc::ShouldUseVulkan())
		{
			FString FullVersionString, VersionString, SubVersionString;
			FString GLVersion = ANSI_TO_TCHAR((const ANSICHAR*)glGetString(GL_VERSION));
			GLVersion.Split(TEXT("OpenGL ES "), nullptr, &FullVersionString);
			FullVersionString.Split(TEXT(" "), &FullVersionString, nullptr);
			FullVersionString.Split(TEXT("."), &VersionString, &SubVersionString);
			int32 GLMajorVerion = FCString::Atoi(*VersionString);
			int32 GLMinorVersion = FCString::Atoi(*SubVersionString);

			bool bES31Supported = GLMajorVerion == 3 && GLMinorVersion >= 1;
			static const auto CVarDisableES31 = IConsoleManager::Get().FindTConsoleVariableDataInt(TEXT("r.Android.DisableOpenGLES31Support"));

			bool bBuildForES31 = false;
			GConfig->GetBool(TEXT("/Script/AndroidRuntimeSettings.AndroidRuntimeSettings"), TEXT("bBuildForES31"), bBuildForES31, GEngineIni);

			const bool bSupportsFloatingPointRTs = FAndroidMisc::SupportsFloatingPointRenderTargets();
			const bool bES20Fallback = !bSupportsFloatingPointRTs || !!CVarDisableES31->GetValueOnAnyThread();

			if (bBuildForES31 && bES31Supported && !bES20Fallback)
			{
				FAndroidOpenGL::CurrentFeatureLevelSupport = FAndroidOpenGL::GLMinorVersion >= 2 ? FAndroidOpenGL::EFeatureLevelSupport::ES32 : FAndroidOpenGL::EFeatureLevelSupport::ES31;
			}
			else
			{
				FAndroidOpenGL::CurrentFeatureLevelSupport = FAndroidOpenGL::EFeatureLevelSupport::ES2;
			}
		}
	}
}

#endif

namespace
{
	struct SystemInfo
	{
		FString DeviceModel;
		FAzureSystemInfo::DeviceType DeviceType;
		int32 IOSDeviceType; // FIOSPlatformMisc::EIOSDevice
		FString DeviceTypeName;
		FString DeviceName;
		FString DeviceUniqueIdentifier;
		FString cpuVendor;
		FString cpuBrand;
		FString OperatingSystem;
		int32 ProcessorCount;
		float processorFrequency;	//	MHz
		int32 SystemMemorySize;		//	MB

		SystemInfo()
		{
#if PLATFORM_ANDROID
			if (!GDynamicRHI)
			{
				InitAndroidOpenGLFeatureLevelSupportBeforeCreateOpenGLDynamicRHI();
			}
#endif
			InitDeviceModel();
			InitDeviceType();
			InitDeviceTypeName();
			InitDeviceName();
			InitDeviceUniqueIdentifier();
			InitCPUInfo();
			InitOperatingSystem();
			InitSystemMemorySize();
		}

		void InitDeviceModel()
		{
#if PLATFORM_DESKTOP
			DeviceModel = FPlatformMisc::GetCPUBrand();
#elif PLATFORM_IOS
			DeviceModel = GetIOSDeviceModel();
#elif PLATFORM_ANDROID
			DeviceModel = FAndroidMisc::GetDeviceModel();
#endif
			DeviceModel.TrimStartAndEndInline();
		}

		void InitDeviceType()
		{
#if PLATFORM_DESKTOP
			DeviceType = FAzureSystemInfo::DeviceType::Desktop;
#elif (PLATFORM_IOS|PLATFORM_ANDROID)
			DeviceType = FAzureSystemInfo::DeviceType::Handheld;
#elif (PLATFORM_XBOXONE|PLATFORM_PS4)
			DeviceType = FAzureSystemInfo::DeviceType::Console;
#else
			DeviceType = FAzureSystemInfo::DeviceType::Unknown;
#endif

#if PLATFORM_IOS
			IOSDeviceType = (int32)FIOSPlatformMisc::GetIOSDeviceType();
#else
			IOSDeviceType = -1;
#endif
		}

		void InitDeviceTypeName()
		{
			static const TCHAR* TypeName[] =
			{
				TEXT("Unknown"),
				TEXT("Handheld"),
				TEXT("Console"),
				TEXT("Desktop"),
			};
			static_assert((sizeof(TypeName) / sizeof(TypeName[0])) == ((int32)FAzureSystemInfo::DeviceType::Desktop + 1), "Mismatched TypeName and DeviceType.");

			DeviceTypeName = TypeName[(int32)DeviceType];
		}

		void InitDeviceName()
		{
			DeviceName = FPlatformProcess::ComputerName();
			DeviceName.TrimStartAndEndInline();
		}

		void InitDeviceUniqueIdentifier()
		{
#if PLATFORM_ANDROID
			FString ANDROID_ID = GetAndroidID();
			if (!ANDROID_ID.IsEmpty())
			{
				DeviceUniqueIdentifier = FMD5::HashAnsiString(*ANDROID_ID);
			}
#elif PLATFORM_DESKTOP
			DeviceUniqueIdentifier = FGenericPlatformMisc::GetMacAddressString();
#else
			DeviceUniqueIdentifier = FPlatformMisc::GetDeviceId();
#endif
		}

		void InitOperatingSystem()
		{
#if PLATFORM_DESKTOP
				FString out_OSVersionLabel, out_OSSubVersionLabel;
				FPlatformMisc::GetOSVersions(out_OSVersionLabel, out_OSSubVersionLabel);
				OperatingSystem = out_OSVersionLabel + out_OSSubVersionLabel;
#elif PLATFORM_IOS
				FString systemName = [[UIDevice currentDevice] systemName];
				FString systemVersion = [[UIDevice currentDevice] systemVersion];
				OperatingSystem = systemName + TEXT(" ") + systemVersion;
#elif PLATFORM_ANDROID
				OperatingSystem = TEXT("Android ") + FAndroidMisc::GetAndroidVersion();
#endif
		}

		void InitCPUInfo()
		{
			cpuVendor = FPlatformMisc::GetCPUVendor();
			cpuVendor.TrimStartAndEndInline();
			cpuBrand = FPlatformMisc::GetCPUBrand();
			cpuBrand.TrimStartAndEndInline();

			ProcessorCount = FPlatformMisc::NumberOfCores();

			//	这个函数返回的不准（比如win7或以上的系统，会差3个数量级。。手机还没试）
			double secsPerCycle = FPlatformTime::GetSecondsPerCycle();
			
			processorFrequency = secsPerCycle > 0 ? 0.000001 / secsPerCycle : 1;
		}

		void InitSystemMemorySize()
		{
			const FPlatformMemoryConstants& MemoryConstants = FPlatformMemory::GetConstants();
			SystemMemorySize = (int32)(MemoryConstants.TotalPhysical >> 20); // Byte -> MB
		}

		static SystemInfo& Instance()
		{
			static SystemInfo LocalInstance;
			return LocalInstance;
		}
	};
}

//	Example:
//			PC:					   "Intel(R) Core(TM) i7-6700K CPU @ 4.00GHz"
//			iPhone 7 Plus:         "iPhone9,2"
//			Redmi Note 4X(3GB):    "Redmi Note 4X"
const TCHAR* FAzureSystemInfo::deviceModel()
{
	return *SystemInfo::Instance().DeviceModel;
}

//	Example:
//			PC:					   "Desktop"
//			iPhone 7 Plus:         "Handheld"
//			Redmi Note 4X(3GB):    "Handheld"
FAzureSystemInfo::DeviceType FAzureSystemInfo::deviceType()
{
	return SystemInfo::Instance().DeviceType;
}

int32 FAzureSystemInfo::iosDeviceType()
{
	return SystemInfo::Instance().IOSDeviceType;
}

//	Example:
//			PC:					   "Desktop"
//			iPhone 7 Plus:         "Handheld"
//			Redmi Note 4X(3GB):    "Handheld"
const TCHAR* FAzureSystemInfo::deviceTypeName()
{
	return *SystemInfo::Instance().DeviceTypeName;
}

//	Example:
//			PC:					   "DESKTOP-2OU3AM1"
//			iPhone 7 Plus:         "******-iPhone7P"
//			Redmi Note 4X(3GB):    "Redmi Note 4X"
const TCHAR* FAzureSystemInfo::deviceName()
{
	return *SystemInfo::Instance().DeviceName;
}

//	Example:
//			PC(hashed Mac Address):	 "b8e8237fe22afccae9cc8aa3138b555d"
//			iPhone 7 Plus(IDFV):     "********-****-****-****-************"
//			Redmi Note 4X(3GB):      "6a270dfa1dd962968c2438443665aced"
const TCHAR* FAzureSystemInfo::deviceUniqueIdentifier()
{
	return *SystemInfo::Instance().DeviceUniqueIdentifier;
}

const TCHAR* FAzureSystemInfo::cpuVendor()
{
	return *SystemInfo::Instance().cpuVendor;
}

const TCHAR* FAzureSystemInfo::cpuBrand()
{
	return *SystemInfo::Instance().cpuBrand;
}

//	Example:
//			PC:					   "NVIDIA GeForce GTX 1070"
//			iPhone 7 Plus:         "Apple A10 GPU"
//			Redmi Note 4X(3GB):    "Adreno (TM) 506"
const TCHAR* FAzureSystemInfo::graphicsDeviceName()
{
	if (!GDynamicRHI)
	{
#if PLATFORM_ANDROID
		static FString GraphicsDeviceName = FOpenGL::GetAdapterName();
#else
		static FString GraphicsDeviceName;
#endif
		return *GraphicsDeviceName;
	}
	else
	{
		return *GRHIAdapterName;
	}
}

bool FAzureSystemInfo::SupportsASTC()
{
#if (PLATFORM_WINDOWS)
	return true;
#elif (PLATFORM_ANDROID)
	if (!FAndroidMisc::ShouldUseVulkan())
	{
		return FOpenGL::SupportsASTC();
	}
	return true;
#elif (PLATFORM_IOS)
	return GetIOSSupportASTC();
#else
	return false;
#endif
}

void FAzureSystemInfo::graphicsMemoryStatus(FTextureMemoryStats& out)
{
	RHIGetTextureMemoryStats(out);
}

int32 FAzureSystemInfo::maxRHIFeatureLevel()
{
	if (!GDynamicRHI)
	{
#if PLATFORM_ANDROID
		if (!FAndroidMisc::ShouldUseVulkan())
		{
			return (int32)FOpenGL::GetFeatureLevel();
		}
		return (int32)ERHIFeatureLevel::Num;
#else
		return (int32)ERHIFeatureLevel::Num;
#endif
	}
	else
	{
		return (int32)GMaxRHIFeatureLevel;
	}
}
int32 FAzureSystemInfo::maxRHIShaderPlatform()
{
	if (!GDynamicRHI)
	{
#if PLATFORM_ANDROID
		if (!FAndroidMisc::ShouldUseVulkan())
		{
			return (int32)FOpenGL::GetShaderPlatform();
		}
		return (int32)EShaderPlatform::SP_NumPlatforms;
#else
		return (int32)EShaderPlatform::SP_NumPlatforms;
#endif
	}
	else
	{
		return (int32)GMaxRHIShaderPlatform;
	}
}

//	Example:
//			Windows 10 Profession: "Windows 10"
//			iPhone 7 Plus:         "iOS 10.3.2"
//			Redmi Note 4X(3GB):	   "Android 6.0.1"
const TCHAR* FAzureSystemInfo::operatingSystem()
{
	return *SystemInfo::Instance().OperatingSystem;
}

//	Example:
//			Windows 10(i7-6700K): 4
//			iPhone 7 Plus:        2
//			Redmi Note 4X(3GB):   8
int32 FAzureSystemInfo::processorCount()
{
	return SystemInfo::Instance().ProcessorCount;
}

//	Example:
//			Windows 10(i7-6700K): 2000MHz
//			iPhone 7 Plus:        2000MHz
//			Redmi Note 4X(3GB):   2000MHz
float FAzureSystemInfo::processorFrequency()
{
	return SystemInfo::Instance().processorFrequency;
}


//	return MegaBytes(MB) for all physical memory
//	Example:
//			Windows 10(16GB):   16316
//			iPhone 7 Plus:      2223
//			Redmi Note 4X(3GB): 2846
int32 FAzureSystemInfo::systemMemorySize()
{
	return SystemInfo::Instance().SystemMemorySize;
}

//	provide screen physical size (regarding android and ios, but client size for windows) regarding orientation(portrait or landscape)
//	Example:
//			PC:						  1280 * 720 
//			iPhone 7 Plus(Lancscape): 1920 * 1080
//			Redmi Note 4X(Landscape): 1920 * 1080
//	Note:	For iOS and Android, native api is used, so it's safe to use almost anytime
//			but for windows, currently I cannot find a perfect solution regarding play in editor or for standalone mode, so it's only safe after GameViewport is initialized
FIntPoint FAzureSystemInfo::screenSize()
{
	static FIntPoint DefaultSize(1, 1);
#if PLATFORM_DESKTOP
	{
		FVector2D ViewportSize = FVector2D(DefaultSize.X, DefaultSize.Y);
		if (GEngine && GEngine->GameViewport)
		{
			GEngine->GameViewport->GetViewportSize(ViewportSize);
		}
		return FIntPoint(static_cast<int32>(ViewportSize.X), static_cast<int32>(ViewportSize.Y));
	}
#elif PLATFORM_IOS
	{
		static CGRect NativeBounds = [[UIScreen mainScreen] nativeBounds];
		static FIntPoint PortraitSize = FIntPoint(static_cast<int32>(NativeBounds.size.width), static_cast<int32>(NativeBounds.size.height));
		static FIntPoint LandscapeSize = FIntPoint(static_cast<int32>(NativeBounds.size.height), static_cast<int32>(NativeBounds.size.width));
		bool IsPortrait = UIInterfaceOrientationIsPortrait([[UIApplication sharedApplication] statusBarOrientation]);
		return IsPortrait ? PortraitSize : LandscapeSize;
	}
#elif PLATFORM_ANDROID
	{
		int32_t Width = 0;
		int32_t Height = 0;
		FAndroidWindow::CalculateSurfaceSize(FAndroidWindow::GetHardwareWindow(), Width, Height);
		return FIntPoint(Width, Height);
	}
#else
	return DefaultSize;
#endif
}

//	return [[UIScreen mainScreen] bounds], which already takes into account orientation(portrait or landscape)
//	r.MobileContentScaleFactor is based on this size
//	Example:
//			iPad Air 2(Lancscape): 1024 * 768 (while screenSize() is 2048*1536)
FIntPoint FAzureSystemInfo::iosScreenBounds()
{
#if PLATFORM_IOS
	static CGRect Bounds = [[UIScreen mainScreen] bounds];
	return FIntPoint(static_cast<int32>(Bounds.size.width), static_cast<int32>(Bounds.size.height));
#else
	return FIntPoint(1, 1);
#endif
}

const TCHAR* FAzureSystemInfo::gDynamicRHIName()
{
	return GDynamicRHI->GetName();
}

//left,top,right,bottom
FIntRect FAzureSystemInfo::safeAreaInsets()
{
#if PLATFORM_IOS
	if ([[UIDevice currentDevice].systemVersion intValue] >= 11)
	{
		FIOSView* v = [IOSAppDelegate GetDelegate].IOSView;
		UIEdgeInsets insets = v.safeAreaInsets;
		CGFloat scale = [[UIScreen mainScreen] scale];
		return FIntRect(insets.left*scale, insets.top*scale, insets.right*scale, insets.bottom*scale);
	}
	else 
	{
		return FIntRect(0, 0, 0, 0);
	}
#else
	return FIntRect(0, 0, 0, 0);
#endif
}

FAzureSystemInfo::UIOrientation FAzureSystemInfo::getUIOrientation()
{
#if PLATFORM_IOS
	UIInterfaceOrientation orientation = [[UIApplication sharedApplication] statusBarOrientation];
	switch (orientation)
	{
	case UIInterfaceOrientationUnknown:
		return UIOrientation_Unknown;
	case UIInterfaceOrientationPortrait:
		return UIOrientation_Portrait;
	case UIInterfaceOrientationPortraitUpsideDown:
		return UIOrientation_PortraitUpsideDown;
	case UIInterfaceOrientationLandscapeLeft:
		return UIOrientation_LandscapeLeft;
	case UIInterfaceOrientationLandscapeRight:
		return UIOrientation_LandscapeRight;
	default:
		return UIOrientation_Unknown;
	}
#else
	return UIOrientation_LandscapeLeft;
#endif

}
