// Fill out your copyright notice in the Description page of Project Settings.

#include "CalcGradientHelper.h"
#include "Engine/World.h"


bool FCalcGradientHelper::debug = false;

bool FCalcGradientHelper::ProjectionPosToFloor(FVector &pos, const CalcGradientParams &params)
{
	FHitResult hitIn;
	if (!AAzureEntryPoint::Instance) return false;
	UWorld* pWorld = AAzureEntryPoint::Instance->GetWorld();
	if (!pWorld) return false;
	auto start = pos + FVector::UpVector*params.traceBeginUp;
	auto end = pos - FVector::UpVector*params.traceLength;
	FCollisionQueryParams QParams = FCollisionQueryParams::DefaultQueryParam;
	QParams.AddIgnoredActors(params.IngoreActors);
	bool Success = pWorld->LineTraceSingleByChannel(hitIn, start, end, params.channel, QParams);
	if (Success)
	{
		pos = hitIn.ImpactPoint;
		if (debug)
		{
			UKismetSystemLibrary::DrawDebugSphere(pWorld, pos, 20, 12, FLinearColor::Red);
		}
	}

	return Success;
}


/*
	0 -- 1
	|    |
	2 -- 3
*/
bool FCalcGradientHelper::GetFloorNormal(FVector &normal, CalcGradientParams const &params)
{
	FVector right = FVector::CrossProduct(params.forward, FVector::UpVector);
	FVector center = params.pos;

	
	FVector pos0 = center - right * params.width / 2 + params.forward*params.length / 2;
	FVector pos1 = pos0 + right * params.width;
	FVector pos2 = pos0 - params.forward*params.length;
	FVector pos3 = pos2 + right * params.width;

	bool posValid = false;
	if (ProjectionPosToFloor(pos0, params)
		&& ProjectionPosToFloor(pos1, params)
		&& ProjectionPosToFloor(pos2, params)
		&& ProjectionPosToFloor(pos3, params)
		)
	{
		posValid = true;
	}
	if (!posValid) return false;



	FVector n1 = GetPlaneNormal(pos0, pos2, pos3);
	FVector n2 = GetPlaneNormal(pos3, pos1, pos0);
	normal = n1 + n2;
	normal.Normalize();

	if (debug)
	{
		FVector center = (pos0 + pos1 + pos2 + pos3) / 4;

		if (!AAzureEntryPoint::Instance)
			return false;

		UWorld* pWorld = AAzureEntryPoint::Instance->GetWorld();
		if (pWorld)
			UKismetSystemLibrary::DrawDebugArrow(pWorld, center, center + normal * 200, 20, FLinearColor::Blue, 0, 1);
	}
	return true;
}

FVector FCalcGradientHelper::GetPlaneNormal(FVector p1, FVector p2, FVector p3)
{
	auto line1 = p2 - p1;
	auto line2 = p3 - p1;
	auto result = FVector::CrossProduct(line1, line2);
	result.Normalize();
	return result;
}

bool FCalcGradientHelper::GetFloorGradient(float &gradient, const CalcGradientParams &params)
{
	FVector normal;
	if (GetFloorNormal(normal, params))
	{
		FVector tangent = FVector::CrossProduct(params.forward, normal);
		FVector tagentForward = FVector::CrossProduct(normal, tangent);
		tagentForward.Normalize();
		
		if (debug)
		{
			FVector center = params.pos;

			if (!AAzureEntryPoint::Instance)
				return false;

			UWorld* pWorld = AAzureEntryPoint::Instance->GetWorld();
			if (pWorld)
				UKismetSystemLibrary::DrawDebugArrow(pWorld, center, center + tagentForward * 200, 20, FLinearColor::Yellow, 0, 1);
		}

		gradient = FMath::Acos(FVector::DotProduct(FVector::UpVector, tagentForward));
		if(gradient < 0) gradient = -PI / 2 + gradient;
		else gradient = PI / 2 - gradient;

		return true;
	}
	return false;
}

float FCalcGradientHelper::CalcGradientAngleByForwardDir(const FVector & forward)
{
	float gradient = FMath::Acos(FVector::DotProduct(FVector::UpVector, forward));
	if (gradient < 0) gradient = -PI / 2 + gradient;
	else gradient = PI / 2 - gradient;
	float angle = FMath::RadiansToDegrees(gradient);
	return angle;
}

