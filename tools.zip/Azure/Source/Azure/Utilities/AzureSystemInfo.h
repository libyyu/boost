#pragma once

#include "CoreMinimal.h"
#include "RHI.h"

class FAzureSystemInfo
{
public:
	enum DeviceType
	{
		Unknown = 0,
		Handheld = 1,
		Console = 2,
		Desktop = 3,
	};

	enum UIOrientation
	{
		UIOrientation_Unknown = 0,
		UIOrientation_Portrait,
		UIOrientation_PortraitUpsideDown,
		UIOrientation_LandscapeLeft,	//home button in right
		UIOrientation_LandscapeRight,	//home button in left
	};

	static const TCHAR* deviceModel();
	static DeviceType deviceType();
	static int32 iosDeviceType();
	static const TCHAR* deviceTypeName();
	static const TCHAR* deviceName();
	static const TCHAR* deviceUniqueIdentifier();
	static const TCHAR* cpuVendor();
	static const TCHAR* cpuBrand();
	static const TCHAR* graphicsDeviceName();
	static bool SupportsASTC();
	static void graphicsMemoryStatus(FTextureMemoryStats& out);
	static int32 maxRHIFeatureLevel();
	static int32 maxRHIShaderPlatform();
	static const TCHAR* operatingSystem();
	static int32 processorCount();
	static float processorFrequency();
	static int32 systemMemorySize();

	static FIntPoint screenSize();
	static FIntPoint iosScreenBounds();
	static const TCHAR* gDynamicRHIName();
	static FIntRect safeAreaInsets();
	static UIOrientation getUIOrientation();
};