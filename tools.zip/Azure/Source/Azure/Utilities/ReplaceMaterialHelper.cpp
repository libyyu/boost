#include "ReplaceMaterialHelper.h"
#include "GameFramework/Actor.h"
#include "Materials/Material.h"
#include "Components/MeshComponent.h"
#include "Materials/MaterialInstanceDynamic.h"
#include "Containers/Array.h"

void FActorReplaceMaterialState::Init(AActor* actor)
{
	check(actor);
	this->actor = actor;
	CollectOriginalMaterial(false);
}

void FActorReplaceMaterialState::InitWithChildren(AActor* actor)
{
	check(actor);
	this->actor = actor;
	CollectOriginalMaterial(true);
}

void FActorReplaceMaterialState::ReplaceMaterial(UMaterialInterface* newMaterial) const
{
	AActor* pActor = actor;
	if (!pActor || pActor->IsPendingKill())
		return;

	for (auto&& meshInfo : originals)
	{
		if (!meshInfo.mesh || meshInfo.mesh->IsPendingKill())
			continue;

		for (int iMat=0; iMat<meshInfo.originalMaterials.Num(); ++iMat)
		{
			UMaterialInterface* originalMat = meshInfo.originalMaterials[iMat];
			if (!originalMat || originalMat->IsPendingKill())
				continue;

			UMaterialInstanceDynamic* newMatDynamic = UMaterialInstanceDynamic::Create(newMaterial, originalMat->GetOuter());
			newMatDynamic->K2_CopyMaterialInstanceParameters(originalMat);

			meshInfo.mesh->SetMaterial(iMat, newMatDynamic);
		}
	}
}

void FActorReplaceMaterialState::RecoverMaterial() const
{
	AActor* pActor = actor;
	if (!pActor || pActor->IsPendingKill())
		return;

	for (auto&& meshInfo : originals)
	{
		if (!meshInfo.mesh || meshInfo.mesh->IsPendingKill())
			continue;

		for (int iMat=0; iMat<meshInfo.originalMaterials.Num(); ++iMat)
		{
			UMaterialInterface* mat = meshInfo.originalMaterials[iMat];
			if (!mat || mat->IsPendingKill())
				continue;

			meshInfo.mesh->SetMaterial(iMat, mat);
		}
	}
}

void FActorReplaceMaterialState::CollectOriginalMaterial(bool withChildren)
{
	AActor* pActor = actor;
	if (!pActor || pActor->IsPendingKill())
		return;

	if (withChildren)
		CollectOriginalMaterialRecursively(pActor);
	else
		CollectOriginalMaterialForSingleActor(pActor);
}

void FActorReplaceMaterialState::CollectOriginalMaterialRecursively(AActor* pActor)
{
	CollectOriginalMaterialForSingleActor(pActor);

	TArray<AActor*> childActors;
	pActor->GetAttachedActors(childActors);
	for (AActor* pChildActor : childActors)
	{
		if (pChildActor && !pChildActor->IsPendingKill())
			CollectOriginalMaterialRecursively(pChildActor);
	}
}

void FActorReplaceMaterialState::CollectOriginalMaterialForSingleActor(AActor* singleActor)
{
	TArray<UMeshComponent*> meshSet;
	singleActor->GetComponents<UMeshComponent>(meshSet, true);
	for (UMeshComponent* mesh : meshSet)
	{
		FActorReplaceMaterialState_MeshInfo& meshInfo = originals.Emplace_GetRef();
		meshInfo.mesh = mesh;
		int matCount = mesh->GetNumMaterials();
		meshInfo.originalMaterials.Reserve(matCount);
		for (int iMat=0; iMat<matCount; ++iMat)
		{
			meshInfo.originalMaterials.Add(mesh->GetMaterial(iMat));
		}
	}
}
