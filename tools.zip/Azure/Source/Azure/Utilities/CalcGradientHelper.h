// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "AzureEntryPoint.h"
#include "Azure/Utilities/AzureUtility.h"
struct CalcGradientParams
{
	FVector pos;
	FVector forward;
	float length = 100;
	float width = 100;
	float traceBeginUp = 200;
	float traceLength = 1000;
	ECollisionChannel channel = AzureUtility::TRACE_CHN_TERRAIN_BUILDING;
	TArray<AActor*> IngoreActors;
};

class AZURE_API FCalcGradientHelper
{

	static bool debug;
	// ��õ�ǰ��ĵ���߶�
	static bool ProjectionPosToFloor(FVector &pos, const CalcGradientParams &params);
	
public:	
	static FVector GetPlaneNormal(FVector p1, FVector p2, FVector p3);

	// ��õ���ķ���
	static bool GetFloorNormal(FVector &normal, const CalcGradientParams  &params);
	
	// ��ý����¶ȣ���ˮƽ��нǻ��ȣ�
	static bool GetFloorGradient(float &gradient, const CalcGradientParams &params);

	// ��ǰ�����򣬵ó��¶ȽǶ�
	static float CalcGradientAngleByForwardDir(const FVector &forward);
};


