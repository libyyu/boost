#pragma once

#include "CoreMinimal.h"
#include "GameFramework/GameUserSettings.h"

class FScreenInfo
{
public:
	static EWindowMode::Type GetFullScreenMode();
	static float dpi();
	static int32 width();
	static int32 height();
	static void SetResolutionAndFullscreenMode(int32 width, int32 height, EWindowMode::Type fullscreenMode);
	static FIntPoint GetDesktopResolution();
	static void SetAspectRatioLimit(FFloatInterval const& value);
	static FFloatInterval GetAspectRatioLimit();
};