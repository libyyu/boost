// Fill out your copyright notice in the Description page of Project Settings.

#include "AzureLensFlare.h"
#include "AzureHUD.h"
#include "Engine.h"
#include "Math/Color.h"
#include "Materials/MaterialInstanceDynamic.h"
#include "AzureUtility.h"
#include "../ResourceLoader/AzureResourceLoader.h"
#include "AzureEntryPoint.h"

#if WITH_EDITOR
#include "PropertyEditorModule.h"
#include "AzureLensFlareCustomization.h"
#endif

// Sets default values
AAzureLensFlare::AAzureLensFlare()
{
 	// Set this actor to call Tick() every frame.  You can turn this off to improve performance if you don't need it.
	PrimaryActorTick.bCanEverTick = true;

	if (!RootComponent)
	{
		USceneComponent* SceneComponent = CreateDefaultSubobject<USceneComponent>(TEXT("AzureLensFlareRootComponent"));
		SetRootComponent(SceneComponent);
	}

	ElementType = EAZURE_FLARE_ELEMENT_TYPE::Default;
	ElementTypeLast = EAZURE_FLARE_ELEMENT_TYPE::Default;

	fDestAlpha = .0f;
	fCurAlpha = .0f;
	fInterval = .0f;
	fCurveTime = .0f;
	fTimeOfDay = .0f;

	CurveColor = FLinearColor::White;
	CurveTimeColor = FLinearColor::White;
	ElementDefault();

#if WITH_EDITOR
	RegisterCustomPropertyTypeLayout("AZURE_FLARE_TEXTURE_PARAM", FOnGetPropertyTypeCustomizationInstance::CreateStatic(&AzureLensFlareCustomization::MakeInstance));
#endif
	
}
// Called when the game starts or when spawned
void AAzureLensFlare::BeginPlay()
{
	Super::BeginPlay();
	
	if (!bInit)
	{
		TArray<UObject*> res;
		AzureResourceLoader::Get().LoadGameRes(TEXT("Miscs/FlareMaterialInstance"), res);
		UObject* asset = nullptr;

		for (auto ObjIt = res.CreateConstIterator(); ObjIt; ++ObjIt)
		{
			if ((*ObjIt)->GetClass() == UMaterialInstanceConstant::StaticClass())
			{
				asset = (*ObjIt);
				break;
			}
		}


		//	static ConstructorHelpers::FObjectFinder<UMaterialInstance> FObjectFinder(TEXT("/Game/Miscs/FlareMaterialInstance.FlareMaterialInstance"));
		if (asset)
		{
			DefaultMaterialInstance = UMaterialInstanceDynamic::Create(Cast<UMaterialInstance>(asset), asset->GetOuter());
			UMaterialInstanceDynamic* pMaterialInstanceDynamic = Cast<UMaterialInstanceDynamic>(DefaultMaterialInstance);
			if (pMaterialInstanceDynamic&&LensFlareBokehShape)
				pMaterialInstanceDynamic->SetTextureParameterValue(TEXT("flares"), LensFlareBokehShape);
		}
			
		bInit = true;

		// Check HUD support 
		APlayerController* pController = GetWorld()->GetFirstPlayerController();
		if (pController&&pController->MyHUD&&pController->MyHUD->GetClass()->GetFName() != AAzureHUD::StaticClass()->GetFName())
		{
			pController->ClientSetHUD(AAzureHUD::StaticClass());
		}
			
	}
}

void AAzureLensFlare::PostInitProperties()
{
	Super::PostInitProperties();
	for (int i = 0; i < Elements.Num(); i++)
	{
		Elements[i].Flare = this;
	}
}

void AAzureLensFlare::PostLoad()
{
	Super::PostLoad();
	for (int i = 0; i < Elements.Num(); i++)
	{
		Elements[i].Flare = this;
	}
}

void AAzureLensFlare::ElementDefault()
{
	Elements.Empty();
	Elements.Add(FAZURE_FLARE_TEXTURE_PARAM(0.15f, 0.75f, 0.25f, 0.25f, 0.25f, FLinearColor(1, 1, 1, 1),this));

	Elements.Add(FAZURE_FLARE_TEXTURE_PARAM(1.125f, 0.25f, 0.5f, 0.25f, 0.25f, FLinearColor(1, 1, 1, 1), this));
	Elements.Add(FAZURE_FLARE_TEXTURE_PARAM(0.875f, 0.5f, 0.5f, 0.5f, 0.5f, FLinearColor(1, 1, 1, 1), this));

	Elements.Add(FAZURE_FLARE_TEXTURE_PARAM(0.1f, 0.0f, 0.0f, 0.25f, 0.25f, FLinearColor(1, 1, 1, 1), this));
	Elements.Add(FAZURE_FLARE_TEXTURE_PARAM(0.225f, 0.25f, 0.0f, 0.25f, 0.25f, FLinearColor(1, 1, 1, 1), this));
	Elements.Add(FAZURE_FLARE_TEXTURE_PARAM(0.125f, 0.0f, 0.0f, 0.25f, 0.25f, FLinearColor(1, 1, 1, 1), this));
	Elements.Add(FAZURE_FLARE_TEXTURE_PARAM(0.1f, 0.5f, 0.0f, 0.25f, 0.25f, FLinearColor(1, 1, 1, 1), this));
	Elements.Add(FAZURE_FLARE_TEXTURE_PARAM(0.0375f, 0.75f, 0.0f, 0.25f, 0.25f, FLinearColor(1, 1, 1, 1), this));

	Elements.Add(FAZURE_FLARE_TEXTURE_PARAM(0.05f, 0.75f, 0.0f, 0.25f, 0.25f, FLinearColor(1, 1, 1, 1), this));
	Elements.Add(FAZURE_FLARE_TEXTURE_PARAM(0.175f, 0.5f, 0.0f, 0.25f, 0.25f, FLinearColor(1, 1, 1, 1), this));
	Elements.Add(FAZURE_FLARE_TEXTURE_PARAM(0.3f, 0.5f, 0.0f, 0.25f, 0.25f, FLinearColor(1, 1, 1, 1), this));
	Elements.Add(FAZURE_FLARE_TEXTURE_PARAM(0.075f, 0.5f, 0.0f, 0.25f, 0.25f, FLinearColor(1, 1, 1, 1), this));

	Elements.Add(FAZURE_FLARE_TEXTURE_PARAM(0.075f, 0.0f, 0.5f, 0.25f, 0.25f, FLinearColor(1, 1, 1, 1), this));
	Elements.Add(FAZURE_FLARE_TEXTURE_PARAM(0.375f, 0.25f, 0.25f, 0.25f, 0.25f, FLinearColor(1, 1, 1, 1), this));
	Elements.Add(FAZURE_FLARE_TEXTURE_PARAM(0.75f, 0.5f, 0.25f, 0.25f, 0.25f, FLinearColor(1, 1, 1, 1), this));

}

#if WITH_EDITOR
void AAzureLensFlare::PostEditChangeProperty(FPropertyChangedEvent& PropertyChangedEvent)
{
	Super::PostEditChangeProperty(PropertyChangedEvent);

	// Look for changed properties
	const FName PropertyName = (PropertyChangedEvent.Property != nullptr) ? PropertyChangedEvent.Property->GetFName() : NAME_None;
	const FName MemberPropertyName = (PropertyChangedEvent.MemberProperty != nullptr) ? PropertyChangedEvent.MemberProperty->GetFName() : NAME_None;

	if (PropertyName== "ElementType")
	{
		
		switch (ElementType)
		{
		case EAZURE_FLARE_ELEMENT_TYPE::Default:
			ElementDefault();
			fScale = 1.0f;
			break;
		case EAZURE_FLARE_ELEMENT_TYPE::Element4:
			fScale = 0.3f;
			break;
		case EAZURE_FLARE_ELEMENT_TYPE::Element5:
			fScale = 0.3f;
			break;
		case EAZURE_FLARE_ELEMENT_TYPE::Element11:
		
			fScale = 0.3f;
			fAlpha = 0.7f;
			break;
		case EAZURE_FLARE_ELEMENT_TYPE::Custom:
			fScale = 0.3f;
			break;
			

		}
	}
	else if (PropertyName == "LensFlareBokehShape")
	{
		UMaterialInstanceDynamic* pMaterialInstanceDynamic = Cast<UMaterialInstanceDynamic>(DefaultMaterialInstance);
		if (pMaterialInstanceDynamic&&LensFlareBokehShape)
			pMaterialInstanceDynamic->SetTextureParameterValue(TEXT("flares"), LensFlareBokehShape);

		for (int i = 0; i < Elements.Num(); i++)
		{
			Elements[i].Flare = this;
		}
	}
	else if (PropertyName == "Elements")
	{
		for (int i = 0; i < Elements.Num(); i++)
		{
			Elements[i].Flare = this;
		}
	}
}

void AAzureLensFlare::RegisterCustomPropertyTypeLayout(FName PropertyTypeName, FOnGetPropertyTypeCustomizationInstance PropertyTypeLayoutDelegate)
{
	check(PropertyTypeName != NAME_None);


	static FName PropertyEditor("PropertyEditor");
	FPropertyEditorModule& PropertyModule = FModuleManager::GetModuleChecked<FPropertyEditorModule>(PropertyEditor);
	//FPropertyTypeLayoutCallback PropertyTypeLayoutCallback = PropertyModule.FindPropertyTypeLayoutCallback(PropertyTypeName,)
	PropertyModule.RegisterCustomPropertyTypeLayout(PropertyTypeName, PropertyTypeLayoutDelegate);
}

#endif

// Called every frame
void AAzureLensFlare::Tick( float DeltaTime )
{
	Super::Tick( DeltaTime );
	AzureUtility::InterpFloat(fCurAlpha, fDestAlpha, fFadeSpeed, DeltaTime, 0.05f);
	fInterval += DeltaTime;

	if (CurveLinearColor)
	{
		fCurveTime += DeltaTime;
		if (fCurveTime > CurveCycleTime)
			fCurveTime = 0;
		CurveColor = CurveLinearColor->GetLinearColorValue(fCurveTime);
	}
	else
	{
		fCurveTime = 0;
		CurveColor = FLinearColor::White;
	}

	if (CurveTimeOfDayColor)
	{
		AActor *pSkyBox = AAzureEntryPoint::Instance != nullptr ? AAzureEntryPoint::Instance->GetSkyBoxActor() : nullptr;
		if (pSkyBox != nullptr)
		{
			UFloatProperty * pProperty = FindField<UFloatProperty>(pSkyBox->GetClass(), TEXT("TimeOfDay"));
			if (pProperty)
			{
				fTimeOfDay = pProperty->GetPropertyValue_InContainer(pSkyBox);
			}	
		}
		CurveTimeColor = CurveTimeOfDayColor->GetLinearColorValue(fTimeOfDay);
	}
	else
		CurveTimeColor = FLinearColor::White;

	
		
}

void AAzureLensFlare::RenderFlare(UCanvas* Canvas)
{
	if (!bEnable||!DefaultMaterialInstance|| Elements.Num()<1)
		return;

	UMaterialInstanceDynamic* pMaterialInstanceDynamic = Cast<UMaterialInstanceDynamic>(DefaultMaterialInstance);

	bool bUseDefaultTexture = false;
	FTexture* RenderTextureResource = (LensFlareBokehShape) ? LensFlareBokehShape->Resource : nullptr;
	if (!RenderTextureResource&&pMaterialInstanceDynamic)
		bUseDefaultTexture = true;

	FSceneView* SceneView = Canvas->SceneView;
	if (!RenderTextureResource&&!bUseDefaultTexture)
		return;
	FVector WorldPosition = GetActorLocation();
	FVector CameraPos = SceneView->ViewMatrices.GetViewOrigin();
	// Set Alpha
	if (SceneView->ViewFrustum.IntersectSphere(WorldPosition, 1.0f))
	{
		if (fInterval > fTraceInterval)
		{
			FVector vTemp = WorldPosition - CameraPos;
			if (fActiveRange==0||(fActiveRange > 0 && vTemp.SizeSquared() < (fActiveRange*fActiveRange)))
			{
				FHitResult Hit;
				FCollisionQueryParams Param(TEXT("flaretrace"), true);
				Param.bTraceAsyncScene = true;
				APlayerController* pController = GetWorld()->GetFirstPlayerController();
				if (pController&&pController->GetPawn())
					Param.AddIgnoredActor(pController->GetPawn());
				/*if (IgnoreActors)
				{
				Param.AddIgnoredActors(*IgnoreActors);
				}*/
				FVector RayStart = CameraPos;
				FVector RayEnd = WorldPosition;
				if (GetWorld()->LineTraceSingleByObjectType(Hit, RayStart, RayEnd, FCollisionObjectQueryParams(FCollisionObjectQueryParams::InitType::AllObjects), Param))
				{
					fDestAlpha = .0f;
				}
				else
					fDestAlpha = 1.0f;
			}
			else
				fDestAlpha = .0f;
			
			fInterval = .0f;
		}
	}
	else
	{
		fDestAlpha = .0f;
	}

	if (fCurAlpha < 0.0001f)
		return;

	if (fLastAlpha != fCurAlpha * fAlpha)
	{
		fLastAlpha = fCurAlpha * fAlpha;
		pMaterialInstanceDynamic->SetScalarParameterValue("Alpha", fLastAlpha);
	}

	FVector2D ScreenPosition;
	bool bSuc = SceneView->ProjectWorldToScreen(WorldPosition, SceneView->UnscaledViewRect, SceneView->ViewMatrices.GetViewProjectionMatrix(), ScreenPosition);

	float factor = 1.0f / Elements.Num();
	for (int i=0;i<Elements.Num();i++)
	{
		float u = Elements[i].u;
		float v = Elements[i].v;

		float x = ScreenPosition.X;
		float y = ScreenPosition.Y;

		float w = SceneView->UnscaledViewRect.Width()*0.5f;
		float h = SceneView->UnscaledViewRect.Height()*0.5f;

		x = x + (w - x) * i * 2 * factor;
		y = y + (h - y) * i * 2 * factor;

		h = Elements[i].scale * SceneView->UnscaledViewRect.Height()*fScale;
		w = h;

		FCanvasTileItem TileItem(FVector2D(x - 0.5f*w, y - 0.5f*h), pMaterialInstanceDynamic->GetRenderProxy(0), FVector2D(w, h), FVector2D(u, v), FVector2D(u + Elements[i].us, v + Elements[i].vs));
		TileItem.SetColor(Elements[i].TintColor*CurveColor*CurveTimeColor);
		Canvas->Canvas->DrawItem(TileItem);
		
		
	}

	
	/*FCanvasTileItem TileItem(FVector2D(x - 0.5f*w, y - 0.5f*h), RenderTextureResource, FVector2D(w, h), FVector2D(0, 0), FVector2D(1, 1), FColor(255, 255, 255, 255 * fCurAlpha));
	TileItem.BlendMode = SE_BLEND_Translucent;
	Canvas->Canvas->DrawItem(TileItem);*/
	/*if (bSuc)
	{
		Canvas->Canvas->DrawTile(ScreenPosition.X, ScreenPosition.Y, 60, 60, 0.f, 0.f, 1.f, 1.f, FColor(255, 255, 255), RenderTextureResource);
	}
	else
		Canvas->Canvas->DrawTile(0,0, 60, 60, 0.f, 0.f, 1.f, 1.f, FColor(100, 200, 100));*/
		
}