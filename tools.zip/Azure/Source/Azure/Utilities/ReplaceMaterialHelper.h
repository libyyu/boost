//替换 Actor 等对象材质的工具

#pragma once

#include "CoreMinimal.h"
#include "ReplaceMaterialHelper.generated.h"

class UMaterial;
class UMeshComponent;
class UMaterialInterface;

USTRUCT()
struct FActorReplaceMaterialState_MeshInfo
{
	GENERATED_BODY()

	UPROPERTY(VisibleAnywhere, Transient)
	UMeshComponent* mesh;
	UPROPERTY(VisibleAnywhere, Transient)
	TArray<UMaterialInterface*> originalMaterials;
};

/** 替换和恢复一个 actor 上的材质，并记录原始材质引用 */
USTRUCT()
struct FActorReplaceMaterialState
{
	GENERATED_BODY()

	UPROPERTY(VisibleAnywhere, Transient)
	AActor* actor;

	UPROPERTY(VisibleAnywhere, Transient)
	TArray<FActorReplaceMaterialState_MeshInfo> originals;

public:
	/** 初始化一个“替换状态”，记录 actor 上的原始材质 */
	void Init(AActor* actor);
	/** 初始化一个“替换状态”，记录 actor 及其子 actor 上的原始材质 */
	void InitWithChildren(AActor* actor);
	/** 用 newMaterial 替换 actor 上的材质 */
	void ReplaceMaterial(UMaterialInterface* newMaterial) const;
	void RecoverMaterial() const;

private:
	void CollectOriginalMaterial(bool withChildren);
	void CollectOriginalMaterialRecursively(AActor* pActor);
	//不取子 actor
	void CollectOriginalMaterialForSingleActor(AActor* singleActor);
};

