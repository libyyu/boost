﻿// Fill out your copyright notice in the Description page of Project Settings.

#include "LevelSequenceActorEx.h"
#include "Azure.h"
#include "LevelSequencePlayerEx.h"
#include "MovieSceneSpawnable.h"
#include "Tracks/MovieSceneSpawnTrack.h"
#include "MovieSceneTrack.h"
#include "Engine/World.h"
#include "Engine/Level.h"
#include "Animation/AnimInstance.h"
#include "AzureEntryPoint.h"
#define LUA_LIB
#include "UObject/TextProperty.h"
#include "UObject/UObjectGlobals.h"
#include "Tracks/MovieSceneFloatTrack.h"
#include "Tracks/MovieScene3DTransformTrack.h"
#include "Tracks/MovieSceneSpawnTrack.h"
#include "Tracks/MovieSceneEventTrack.h"
#include "Tracks/MovieScene3DAttachTrack.h"
#include "MovieSceneSection.h"
#include "Sections/MovieSceneFloatSection.h"
#include "Sections/MovieScene3DTransformSection.h"
#include "Sections/MovieSceneEventSection.h"
#include "Materials/MaterialInstanceConstant.h"
#include "Materials/MaterialInstanceDynamic.h"
#include "GameFramework/WorldSettings.h"
#include "wLua/LuaInterface.h"
#include "Channels/MovieSceneChannelProxy.h"
#include "Tracks/MovieSceneSpawnTrack.h"
#include "Sections/MovieSceneBoolSection.h"
#include "Sections/MovieSceneSpawnSection.h"
#include "Evaluation/MovieSceneSpawnTemplate.h"
#include "CineCameraComponent.h"
#include "Utilities/AzureUtility.h"
#include "Blueprint/WidgetLayoutLibrary.h"
#include "Tracks/MovieSceneSubTrack.h"
#include "Tracks/MovieSceneCinematicShotTrack.h"
#include "Sections/MovieSceneSubSection.h"
#include "Sections/MovieSceneCinematicShotSection.h"
#include "Engine/PointLight.h"
#include "Engine/DirectionalLight.h"
#include "Engine/LevelStreaming.h"
#include "CGTrackStruct.h"
#include "CGMultiTrackStruct.h"
#include "LevelSequenceSpawnRegisterEx.h"

const FString ALevelSequenceActorEx::InvalideTrackGUIDStr = FGuid().ToString(EGuidFormats::DigitsWithHyphensInBraces);
FMovieSceneSequenceID FAzureSequenceIDStack::GetCurrent() const
{
	FMovieSceneSequenceID ID = MovieSceneSequenceID::Root;
	for (int32 Index = IDs.Num() - 1; Index >= 0; --Index)
	{
		ID = ID.AccumulateParentID(IDs[Index]);
	}
	return ID;
}


static const FString BindingTrackEventPrefix = "CGBindingTrack";
static const FString BindingTrackEventCheckExclude = "CGBindingTrackParam";


ALevelSequenceActorEx::ALevelSequenceActorEx(const FObjectInitializer& Init)
	: Super(Init)
{
	// 可能运行时修改Offset，Override才能在播放时设置进去
	bOverrideInstanceData = true;
}

void ALevelSequenceActorEx::BeginPlay()
{
	m_bEnableFadeCamera = false;
	m_aCamerOffset.Empty();

	if (!SequencePlayer)
	{
		InitializePlayerEx();
	}
	//cg有设置整体偏移跟随某个acotr功能，需要在actor更新位置后再更新
	SetTickGroup(ETickingGroup::TG_StartPhysics);
	Super::BeginPlay();
}

//创建主角和NPC的SpawnTrack默认值检查（由于防止轨道在cook时被优化掉，默认值是true，但是这样逻辑是不对的需要此刻改成false）
void ALevelSequenceActorEx::CheckLevelSequenceEx()
{
	SetRuntimeBindingSpawnEnable(false);
}

void ALevelSequenceActorEx::EndPlay(const EEndPlayReason::Type EndPlayReason)
{
	Super::EndPlay(EndPlayReason);
#if UE_EDITOR
	// editor模式下，设置回来，否则会导致这条轨道cook时被删除
	SetRuntimeBindingSpawnEnable(true);
#endif
}

void ALevelSequenceActorEx::SetSequenceEx(ULevelSequence* InSequence, int cgid)
{
	m_cgid = cgid;
	if (!SequencePlayer || !SequencePlayer->IsPlaying())
	{
		LevelSequence = InSequence;
#if UE_EDITOR
		editorLevelSequencePtr = InSequence;
#endif
		InitializePlayerEx();
	}

	//设置自己接收Event
	TArray<AActor*> AdditionalReceivers;
	AdditionalReceivers.Add(this);
	SetEventReceivers(AdditionalReceivers);
	sequenceNodeHierarchy.Init(InSequence);
	CheckLevelSequenceEx();
}


UWorld* ALevelSequenceActorEx::GetWorldEx()
{
	UWorld* pCurWorld = GetWorld();
	UWorld* pCGWorld = NULL;
	
	if (m_strWorld.Len())//相位副本的时候需要特殊指定World
	{
		for (int i = 0; i < pCurWorld->GetNumLevels(); i++)
		{
			ULevel* pLevel = pCurWorld->GetLevel(i);
			UWorld* pOuter = Cast<UWorld>(pLevel->GetOuter());
			FString strOuter = pOuter->GetName();
			if (m_strWorld.Len() && !pCGWorld&&strOuter == m_strWorld)
			{
				pCGWorld = pOuter;
				break;
			}
		}
	}
	else
	{
		// 这么写不够鲁棒，需要设置world的主要原因是为了配合这行代码FLevelSequenceBindingReference:56
		// 考虑能否记录下当前加载了的level，如果找到前缀一样的就加上_Instance后缀
		// 0为EntryPoint  1为UIScene  2~n 为StreamingLevel
		ULevel* pLevel = pCurWorld->GetNumLevels()>2?pCurWorld->GetLevel(2):nullptr;
		if (pLevel)
			pCGWorld = Cast<UWorld>(pLevel->GetOuter());
	}

	// For CG
	if (pCGWorld)
	{
		pCGWorld->WorldType = pCurWorld->WorldType;
		pCGWorld->SetGameInstance(pCurWorld->GetGameInstance());
		return pCGWorld;
	}
	else
		return pCurWorld;
}



void ALevelSequenceActorEx::InitializePlayerEx()
{
	ULevelSequence* LevelSequenceAsset = GetSequence(true, true);

	UWorld* pWorld = GetWorldEx();

	if (pWorld->IsGameWorld() && (LevelSequenceAsset != nullptr))
	{
		FMovieSceneSequencePlaybackSettings PlaybackSettingsCopy = PlaybackSettings;

		PlaybackSettingsCopy.BindingOverrides = BindingOverrides;
		if (bOverrideInstanceData)
		{
			PlaybackSettingsCopy.InstanceData = DefaultInstanceData;
		}

		SequencePlayer = NewObject<ULevelSequencePlayerEx>(this, "AnimationPlayerEx");
		SequencePlayer->Initialize(LevelSequenceAsset, pWorld, PlaybackSettingsCopy);
		SequencePlayer->SetEventReceivers(TArray<UObject*>(AdditionalEventReceivers));

		RefreshBurnIn();

		if (bAutoPlay)
		{
			SequencePlayer->Play();
		}
	}
}

void ALevelSequenceActorEx::ProcessEvent(UFunction* Function, void* Parameters)
{
	FString strFun = Function->GetName();
	if (strFun.Find(TEXT("CGEvent")) == INDEX_NONE)
		return Super::ProcessEvent(Function, Parameters);

	if (AAzureEntryPoint::Instance)
	{
		wLua::Lua * wlua = AAzureEntryPoint::Instance->GetWLua();
		if (wlua == nullptr)
			return;
		lua_State_Wrapper L = wlua->GetL();
		if (L == nullptr)
			return;
#if STATS
		FScopeCycleCounter CycleCounter(FDynamicStats::CreateStatId<FStatGroup_STATGROUP_AzureGroups>(FString::Printf(TEXT("CGEventNotify:%s"), *strFun)));
#endif

		UProperty* property = Cast<UProperty>(Function->Children);
		ALevelSequenceActorEx::lua_PushEventDataToLua(property, Parameters, L); //t

		lua_getglobal(L, "CGEventNotify");//t f
		lua_pushstring(L, TCHAR_TO_UTF8(*strFun));//t f s
		lua_pushinteger(L, m_cgid);//t f s n
		lua_pushvalue(L, -4); //t f s n t
		wlua->Call(3);//t
		lua_pop(L, 1);//
	}
}

void ALevelSequenceActorEx::CreateCameraOffset(const FString& strCameraTrackGUID, uint32 sequenceID, float z, float PitchOffset)
{
	FGuid cameraTrackGUID;
	if (!FGuid::ParseExact(strCameraTrackGUID, EGuidFormats::DigitsWithHyphensInBraces, cameraTrackGUID) || !cameraTrackGUID.IsValid())
		return;

	for (int i = 0; i < m_aCamerOffset.Num(); i++)
	{
		if (m_aCamerOffset[i].guid == cameraTrackGUID && m_aCamerOffset[i].sequenceID == sequenceID)
		{
			m_aCamerOffset[i].z = z;
			m_aCamerOffset[i].PitchOffset = PitchOffset;
			m_aCamerOffset[i].sequenceID = sequenceID;
			return;
		}
	}

	FCAMERA_OFFSET_EX NewCameraOffset;
	NewCameraOffset.guid = cameraTrackGUID;
	NewCameraOffset.sequenceID = sequenceID;
	NewCameraOffset.z = z;
	NewCameraOffset.PitchOffset = PitchOffset;
	m_aCamerOffset.Add(NewCameraOffset);
}

void ALevelSequenceActorEx::RemoveCameraOffset(const FString& strCameraTrackGUID, uint32 sequenceID)
{
	FGuid cameraTrackGUID;
	if (!FGuid::ParseExact(strCameraTrackGUID, EGuidFormats::DigitsWithHyphensInBraces, cameraTrackGUID) || !cameraTrackGUID.IsValid())
		return;

	for (int i = 0; i < m_aCamerOffset.Num(); i++)
	{
		if (m_aCamerOffset[i].guid == cameraTrackGUID && m_aCamerOffset[i].sequenceID == sequenceID)
		{
			m_aCamerOffset.RemoveAt(i);
			return;
		}
	}
}


void ALevelSequenceActorEx::RotationUpdateOrAddKey(FMovieSceneFloatChannel& curve, int frame, float v, float key_value)
{
	float cur_v = v;
	if(key_value-v>180) 
		cur_v =  v+360;
	else if(key_value - v<-180)		
		cur_v = v-360;
	curve.GetData().GetValues()[frame].Value = cur_v;
}

void ALevelSequenceActorEx::Tick(float DeltaSeconds)
{
	ULevelSequencePlayerEx* SequencePlayerEx = GetSequencePlayerEx();
	if (!SequencePlayerEx) return;
	//cg会依赖offset，在cg更新前更新offset
	SequencePlayerEx->UpdateOffset(DeltaSeconds);

	Super::Tick(DeltaSeconds);

	ULevelSequence* pLevelSequence = GetSequence();
	if (!pLevelSequence || pLevelSequence->IsPendingKill())
	{
		return;
	}
	
	if (!SequencePlayer || SequencePlayer->IsPendingKill())
	{
		return;
	}


	UpdateFadeInOutCamera();

	IMovieScenePlayer* pPlayer = SequencePlayer;

	if (SequencePlayer->IsPlaying())
	{
		ApplyCameraTrackOffset(pPlayer);
	}

	UpdateTimeDilation(pPlayer);
}

void ALevelSequenceActorEx::UpdateFadeInOutCamera()
{
	if (!m_bEnableFadeCamera) return;

	ULevelSequence* pLevelSequence = GetSequence();
	if (!pLevelSequence || pLevelSequence->IsPendingKill())
	{
		return;
	}

	if (!SequencePlayer || SequencePlayer->IsPendingKill())
	{
		return;
	}

	ULevelSequencePlayerEx* SequencePlayerEx = Cast<ULevelSequencePlayerEx>(SequencePlayer);
	if (!SequencePlayerEx)
	{
		return;
	}

	ShotSequenceNode *cameraSequenceNode = FindMovieScenesNode(m_AdjustCameraSequenceID);
	if (!cameraSequenceNode) return;

	IMovieScenePlayer* pPlayer = SequencePlayer; //用这个基类指针来调用ProtectedFunctioni GetSpawnRegister
	auto objcetArray = SequencePlayer->FindBoundObjects(m_AdjustCameraGuid, m_AdjustCameraSequenceID);
	if (objcetArray.Num() <= 0) return;

	UObject* SpawnedObject = objcetArray[0].Get();
	if (SpawnedObject == nullptr) return;

	AActor* pCineCameraActor = Cast<AActor>(SpawnedObject);
	if (pCineCameraActor == nullptr) return;

	if (!pCineCameraActor->GetRootComponent()) return;

	if (!AAzureEntryPoint::Instance)
		return;
	
	USceneComponent* cgCameraSceneComponent = pCineCameraActor->GetRootComponent();

	FFrameTime curPlayTime = SequencePlayerEx->GetNewTime();
	curPlayTime *= cameraSequenceNode->RootToSequenceTransform;

	// 检查是否在过渡区域，不在就不处理
	int keyCount = m_TranslationCurve[0].GetNumKeys();
	FFrameNumber fadeInEndFrameNumber = m_TranslationCurve[0].GetData().GetTimes()[1];
	bool inFadeInRange = m_bReplaceFirstKey && curPlayTime <= fadeInEndFrameNumber;

	FFrameNumber fadeOutStartFrameNumber = m_TranslationCurve[0].GetData().GetTimes()[keyCount - 2];
	bool inFadeOutRange = m_bReplaceEndKey && curPlayTime >= fadeOutStartFrameNumber;
	
	UCameraComponent* pGameCamera = AAzureEntryPoint::Instance->GetMainCameraComponent();

	if (inFadeInRange || inFadeOutRange)
	{
		FTransform cgTransformOrigin;
		bool bCgHasTransformOffset = SequencePlayerEx->GetTransformOrigin(cgTransformOrigin);
	
		FRotator cgRotationOffset = cgTransformOrigin.GetRotation().Rotator();
		FVector cgTranslationOffset = cgTransformOrigin.GetLocation();

		UCineCameraComponent* pCineCameraComponent = nullptr;
		UCameraComponent* pCGCameraComponent = Cast<UCameraComponent>(pCineCameraActor->GetComponentByClass(UCameraComponent::StaticClass()));
		if (pCGCameraComponent)
		{
			pCineCameraComponent = Cast<UCineCameraComponent>(pCGCameraComponent);

			if (!m_bHasFovTrack)
			{
				float fieldOfView = pCineCameraComponent ? pCineCameraComponent->GetHorizontalFieldOfView() : pCGCameraComponent->FieldOfView;

				// 如果相机本身没有fov轨道，可能由其他参数控制fov，所以可能每一帧fov都在变化，需要每一帧都构建曲线
				for (int i = 0; i < m_FovCurve.GetData().GetValues().Num(); i++)
				{
					m_FovCurve.GetData().GetValues()[i].Value = fieldOfView;
					m_FovCurve.GetData().GetValues()[i].InterpMode = ERichCurveInterpMode::RCIM_Linear;
				}
			}


			if (m_bReplaceFirstKey && pGameCamera)
				m_FovCurve.GetData().GetValues()[0].Value = pGameCamera->FieldOfView;

			if (m_bReplaceEndKey && pGameCamera)
			{
				int NumKeys = m_FovCurve.GetNumKeys();
				if (NumKeys > 0)m_FovCurve.GetData().GetValues()[NumKeys - 1].Value = pGameCamera->FieldOfView;
			}
		}


		// 如果需要先把cg最后一帧设置到游戏相机上
		if (m_bSetCameraByEndKey)
		{
			FVector  endKeyLocation = m_cgCameraEndKeyLocation;
			FRotator  endKeyRotation = m_cgCameraEndKeyRotation;
			if (bCgHasTransformOffset)
			{
				FQuat relQuat = endKeyRotation.Quaternion();
				const FQuat worldQuat = cgRotationOffset.Quaternion();
				endKeyLocation = worldQuat * endKeyLocation + cgTranslationOffset;
				relQuat = worldQuat * relQuat;
				endKeyRotation = relQuat.Rotator();
			}
			//UE_LOG(LogTemp, Warning, TEXT("Set Game Camera Pos:%s"), *endKeyLocation.ToString())
			AzureUtility::CallLuaSetCameraToTargetPos(endKeyLocation, true);
		}

		FVector gameCamRelativeLocation;
		FRotator gameCamRelativeRotation;
		FVector cgCamRelativeLocationFirst = m_gameCamLocationFirst;
		FRotator cgCamRelativeRotationFirst = m_gameCamRotationFirst;
		if (pGameCamera)
		{
			gameCamRelativeLocation = pGameCamera->GetComponentLocation();
			gameCamRelativeRotation = pGameCamera->GetComponentRotation();
			//UE_LOG(LogTemp, Warning, TEXT("After Set Game Camera Pos:%s Rotation:%s"), *gameCamRelativeLocation.ToString(), *gameCamRelativeRotation.ToString());
		}

		// 再根据实际游戏中的相机位置，替换cg中的相机位置
		if (m_bReplaceFirstKey || m_bReplaceEndKey)
		{
			//cg offset可能不断变化，导致cg整体的绝对坐标不断变化， 反算回cg的相对坐标系
			if (bCgHasTransformOffset)
			{
				const FQuat worldQuat = cgRotationOffset.Quaternion();
				gameCamRelativeLocation -= cgTranslationOffset;
				gameCamRelativeLocation = worldQuat.UnrotateVector(gameCamRelativeLocation);
				gameCamRelativeRotation -= cgRotationOffset;
				gameCamRelativeRotation.Clamp();

				cgCamRelativeLocationFirst -= cgTranslationOffset;
				cgCamRelativeLocationFirst = worldQuat.UnrotateVector(cgCamRelativeLocationFirst);
				cgCamRelativeRotationFirst -= cgRotationOffset;
				cgCamRelativeRotationFirst.Clamp();

			}
		}

		// 如果有偏移变化,设置到曲线第一帧
		if (m_bReplaceFirstKey && pGameCamera)
		{
			m_TranslationCurve[0].GetData().GetValues()[0].Value = cgCamRelativeLocationFirst.X;
			m_TranslationCurve[1].GetData().GetValues()[0].Value = cgCamRelativeLocationFirst.Y;
			m_TranslationCurve[2].GetData().GetValues()[0].Value = cgCamRelativeLocationFirst.Z;

			RotationUpdateOrAddKey(m_RotationCurve[0], 0, cgCamRelativeRotationFirst.Roll, m_RotationCurve[0].GetData().GetValues()[1].Value);
			RotationUpdateOrAddKey(m_RotationCurve[1], 0, cgCamRelativeRotationFirst.Pitch, m_RotationCurve[1].GetData().GetValues()[1].Value);
			RotationUpdateOrAddKey(m_RotationCurve[2], 0, cgCamRelativeRotationFirst.Yaw, m_RotationCurve[2].GetData().GetValues()[1].Value);

		}

		// 更新曲线最后一帧
		int NumKeys;
		if (m_bReplaceEndKey && pGameCamera)
		{
			FVector camPos = gameCamRelativeLocation;
			NumKeys = m_TranslationCurve[0].GetNumKeys();
			if (NumKeys > 0)m_TranslationCurve[0].GetData().GetValues()[NumKeys - 1].Value = camPos.X;
			NumKeys = m_TranslationCurve[1].GetNumKeys();
			if (NumKeys > 0)m_TranslationCurve[1].GetData().GetValues()[NumKeys - 1].Value = camPos.Y;
			NumKeys = m_TranslationCurve[2].GetNumKeys();
			if (NumKeys > 0)m_TranslationCurve[2].GetData().GetValues()[NumKeys - 1].Value = camPos.Z;


			FRotator camRot = gameCamRelativeRotation;
			NumKeys = m_RotationCurve[0].GetNumKeys();
			if (NumKeys > 1) RotationUpdateOrAddKey(m_RotationCurve[0], NumKeys - 1, camRot.Roll, m_RotationCurve[0].GetData().GetValues()[NumKeys - 2].Value);
			NumKeys = m_RotationCurve[1].GetNumKeys();
			if (NumKeys > 1) RotationUpdateOrAddKey(m_RotationCurve[1], NumKeys - 1, camRot.Pitch, m_RotationCurve[1].GetData().GetValues()[NumKeys - 2].Value);
			NumKeys = m_RotationCurve[2].GetNumKeys();
			if (NumKeys > 1) RotationUpdateOrAddKey(m_RotationCurve[2], NumKeys - 1, camRot.Yaw, m_RotationCurve[2].GetData().GetValues()[NumKeys - 2].Value);

		}

		USceneComponent* SceneComponent = nullptr;
		SceneComponent = pCineCameraActor->GetRootComponent();
		FVector RelativeLocation = SceneComponent->RelativeLocation;

		m_TranslationCurve[0].Evaluate(curPlayTime, RelativeLocation.X);
		m_TranslationCurve[1].Evaluate(curPlayTime, RelativeLocation.Y);
		m_TranslationCurve[2].Evaluate(curPlayTime, RelativeLocation.Z);

		FRotator RelativeRotation = SceneComponent->RelativeRotation;
		m_RotationCurve[0].Evaluate(curPlayTime, RelativeRotation.Roll);
		m_RotationCurve[1].Evaluate(curPlayTime, RelativeRotation.Pitch);
		m_RotationCurve[2].Evaluate(curPlayTime, RelativeRotation.Yaw);


		if (bCgHasTransformOffset)
		{
			FQuat relQuat = RelativeRotation.Quaternion();
			const FQuat worldQuat = cgRotationOffset.Quaternion();
			RelativeLocation = worldQuat * RelativeLocation + cgTranslationOffset;
			relQuat = worldQuat * relQuat;
			RelativeRotation = relQuat.Rotator();
		}

		cgCameraSceneComponent->SetRelativeLocationAndRotation(RelativeLocation, RelativeRotation);
		cgCameraSceneComponent->RelativeLocation = RelativeLocation;
		cgCameraSceneComponent->RelativeRotation = RelativeRotation;


		float camFov = 0;
		m_FovCurve.Evaluate(curPlayTime, camFov);
		NumKeys = m_FovCurve.GetNumKeys();
		if (pCGCameraComponent &&
			((m_bReplaceFirstKey && NumKeys > 1 && curPlayTime.GetFrame().Value < m_FovCurve.GetData().GetTimes()[1].Value) || (m_bReplaceEndKey && NumKeys > 1 && curPlayTime.GetFrame().Value > m_FovCurve.GetData().GetTimes()[NumKeys - 2].Value)))
		{
			pCGCameraComponent->SetFieldOfView(camFov);
			if (pCineCameraComponent) //如果是专业相机需要修改焦距
			{
				pCineCameraComponent->CurrentFocalLength = 0.5f*pCineCameraComponent->FilmbackSettings.SensorWidth / FMath::Tan(FMath::DegreesToRadians(camFov*0.5f));
			}
		}
	}



	// 相机碰撞
	if (enableFadeCameraCollisionCheck)
	{
		FHitResult hitInfo;
		static float fRadius = 10;
		ECollisionChannel chn = ECollisionChannel::ECC_Camera;
		bool bRet = AzureUtility::GetHitPosInWorld(pGameCamera->GetComponentLocation(), cgCameraSceneComponent->GetComponentLocation(), chn, hitInfo, fRadius, 0, true, FQuat::Identity, "SequenceCamera");
		if (bRet /* && !hitInfo.bStartPenetrating*/)
		{
			cgCameraSceneComponent->SetWorldLocation(hitInfo.Location);
		}
	}

}

void ALevelSequenceActorEx::AddBindingSceneObj(AActor* actor, const FString& strCGTrackDisplayName, const FString& strCGTrackGUID, const uint32 sequenceID)
{
	FGuid CGTrackGUID;
	if (FGuid::ParseExact(strCGTrackGUID, EGuidFormats::DigitsWithHyphensInBraces, CGTrackGUID) && CGTrackGUID.IsValid() )
	{
		AddBinding(FMovieSceneObjectBindingID(CGTrackGUID, FMovieSceneSequenceID(sequenceID)), actor);
	}
	else
	{
		UE_LOG(LogAzure, Warning, TEXT("strCGTrackDisplayName%s strCGTrackGUID=%s parse failed!"), *strCGTrackDisplayName, *strCGTrackGUID);
	}
}

void ALevelSequenceActorEx::RemoveBindingSceneObj(AActor * actor, const FString& strCGTrackDisplayName, const FString& strCGTrackGUID, const uint32 sequenceID)
{
	FGuid CGTrackGUID;
	if (FGuid::ParseExact(strCGTrackGUID, EGuidFormats::DigitsWithHyphensInBraces, CGTrackGUID) && CGTrackGUID.IsValid())
	{
		FMovieSceneSequenceID seID = FMovieSceneSequenceID(sequenceID);
		RemoveBinding(FMovieSceneObjectBindingID(CGTrackGUID, seID), actor);
	}
	else
	{
		UE_LOG(LogAzure, Warning, TEXT("strCGTrackGUID=%s parse failed!"), *strCGTrackGUID);
	}
}



UObject * ALevelSequenceActorEx::FindSpawnedObject(const FString& strCGTrackDisplayName, const FString& strCGTrackGUID, const uint32 sequenceID)
{
	UObject* OutVal = nullptr;
	FGuid CGTrackGUID;
	if (FGuid::ParseExact(strCGTrackGUID, EGuidFormats::DigitsWithHyphensInBraces, CGTrackGUID) && CGTrackGUID.IsValid())
	{
		OutVal = FindSpawnedObject(CGTrackGUID, sequenceID);
	}
	else
	{
		UE_LOG(LogAzure, Warning, TEXT("strCGTrackGUID=%s parse failed!"), *strCGTrackGUID);
	}
	return OutVal;
}

UObject * ALevelSequenceActorEx::FindSpawnedObject(const FGuid & cgTrackGUID, const uint32 sequenceID)
{
	UObject* OutVal = nullptr;
	if (cgTrackGUID.IsValid())
	{
		IMovieScenePlayer* pPlayer = SequencePlayer;
		FMovieSceneSequenceID seID = FMovieSceneSequenceID(sequenceID);
		OutVal = pPlayer->GetSpawnRegister().FindSpawnedObject(cgTrackGUID, seID);
	}
	return OutVal;
}

UObject * ALevelSequenceActorEx::FindBindingObject(const FString & strCGTrackDisplayName, const FString & strCGTrackGUID, const uint32 sequenceID)
{
	UObject* OutVal = nullptr;
	FGuid CGTrackGUID;
	if (FGuid::ParseExact(strCGTrackGUID, EGuidFormats::DigitsWithHyphensInBraces, CGTrackGUID) && CGTrackGUID.IsValid())
	{
		OutVal = FindBindingObject(strCGTrackDisplayName, CGTrackGUID, sequenceID);
	}
	else
	{
		UE_LOG(LogAzure, Warning, TEXT("ALevelSequenceActorEx::FindBindingObject: GUID=%s parse failed! track name(%s)"), *strCGTrackGUID, *strCGTrackDisplayName);
	}
	return OutVal;
}

UObject * ALevelSequenceActorEx::FindBindingObject(const FString & strCGTrackDisplayName, const FGuid & cgTrackGUID, const uint32 sequenceID, const bool warningWhenNotFind)
{
	UObject* OutVal = nullptr;
	FMovieSceneSequenceID seID = FMovieSceneSequenceID(sequenceID);
	auto objcetArray = SequencePlayer->FindBoundObjects(cgTrackGUID, seID);
	if (objcetArray.Num() == 1)
	{
		OutVal = objcetArray[0].Get();
	}
	else
	{
		if(warningWhenNotFind) UE_LOG(LogAzure, Warning, TEXT("ALevelSequenceActorEx::FindBindingObject Failed, track name(%s), find objcet count(%d)"), *strCGTrackDisplayName, objcetArray.Num());
	}
	return OutVal;
}

bool ALevelSequenceActorEx::FadeGameCamera(const FString& strCGTrackGUID, uint32 sequenceID, bool bReplaceFirstKey, bool bReplaceEndKey, bool bSetCameraByEndKey)
{
	FString strCameraTrack;
	ULevelSequence* pLevelSequence = GetSequence();
	if (!pLevelSequence)
		return false;

	if (!SequencePlayer)
		return false;

	if (!AAzureEntryPoint::Instance)
		return false;

	UCameraComponent* pCamera = AAzureEntryPoint::Instance->GetMainCameraComponent();
	if (!pCamera)
		return false;
	

	FGuid CGTrackGUID;
	if (FGuid::ParseExact(strCGTrackGUID, EGuidFormats::DigitsWithHyphensInBraces, CGTrackGUID))
	{
		FMovieSceneSequenceID sid(sequenceID);
		ShotSequenceNode *pSequnceNode = FindMovieScenesNode(sid);
		if (pSequnceNode == nullptr)
		{
			UE_LOG(LogAzure, Warning, TEXT("ALevelSequenceActorEx::FadeGameCamera Cant find Track"));
			return false;
		}
		UMovieScene* pMovieScene = pSequnceNode->movieScene.Get();
		if (!pMovieScene) return false;
		
		UMovieScene3DTransformTrack* Track = nullptr;
		if (CGTrackGUID.IsValid())
			Track = pMovieScene->FindTrack<UMovieScene3DTransformTrack>(CGTrackGUID, NAME_None);
		else
		{
			UE_LOG(LogAzure, Warning, TEXT("ALevelSequenceActorEx::FadeGameCamera CGTrackGUID is not valid:%%s"), *strCGTrackGUID);
		}

		if (Track)
		{
			//寻找cg中的fov轨道
			for (const FMovieSceneBinding& MovieSceneBinding : pMovieScene->GetBindings())
			{
				UMovieSceneFloatTrack* FovTrack = pMovieScene->FindTrack<UMovieSceneFloatTrack>(MovieSceneBinding.GetObjectGuid(), TEXT("FieldOfView"));
				if (FovTrack)
				{
					TArray<UMovieSceneSection*> OutSections = FovTrack->GetAllSections();
					UMovieSceneFloatSection* pSection = Cast<UMovieSceneFloatSection>(OutSections[0]);
					TArrayView<FMovieSceneFloatChannel*> FovFloatChannels = pSection->GetChannelProxy().GetChannels<FMovieSceneFloatChannel>();
					if (FovFloatChannels[0]->GetNumKeys())
					{
						m_FovCurve = *FovFloatChannels[0];
						m_bHasFovTrack = true;
					}
					break;
				}
			}

			TArray<UMovieSceneSection*> OutSections = Track->GetAllSections();
			if (OutSections.Num())
			{
				UMovieScene3DTransformSection* pSection = Cast<UMovieScene3DTransformSection>(OutSections[0]);
				TArrayView<FMovieSceneFloatChannel*> FloatChannels = pSection->GetChannelProxy().GetChannels<FMovieSceneFloatChannel>();

				if (FloatChannels[0]->GetNumKeys()&& FloatChannels[1]->GetNumKeys() && FloatChannels[2]->GetNumKeys()
					&& FloatChannels[3]->GetNumKeys()>1 && FloatChannels[4]->GetNumKeys()>1 && FloatChannels[5]->GetNumKeys()>1)
				{
					m_TranslationCurve[0] = *FloatChannels[0];
					m_TranslationCurve[1] = *FloatChannels[1];
					m_TranslationCurve[2] = *FloatChannels[2];

					m_RotationCurve[0] = *FloatChannels[3];
					m_RotationCurve[1] = *FloatChannels[4];
					m_RotationCurve[2] = *FloatChannels[5];

					//fov没有单独的轨道 复制一条相机的z值轨道
					if(!m_bHasFovTrack)
						m_FovCurve = *FloatChannels[2];

					m_AdjustCameraSequenceID = sid;
					m_AdjustCameraGuid = CGTrackGUID;
					m_bEnableFadeCamera = true;
					m_bReplaceEndKey = bReplaceEndKey;
					m_bReplaceFirstKey = bReplaceFirstKey;
					m_bSetCameraByEndKey = bSetCameraByEndKey;

					if (m_bReplaceFirstKey)
					{
						m_gameCamLocationFirst = pCamera->GetComponentLocation();
						m_gameCamRotationFirst = pCamera->GetComponentRotation();
					}

					if (m_bSetCameraByEndKey)
					{
						m_bReplaceEndKey = true; // 游戏相机的方位，有约束条件，无法准确设置方位，设置后需要将cg最后一帧替换为游戏相机

						int32 NumKeys = m_TranslationCurve[0].GetNumKeys();
						if (NumKeys > 0) m_cgCameraEndKeyLocation.X = m_TranslationCurve[0].GetData().GetValues()[NumKeys - 1].Value;
						NumKeys = m_TranslationCurve[1].GetNumKeys();
						if (NumKeys > 0) m_cgCameraEndKeyLocation.Y = m_TranslationCurve[1].GetData().GetValues()[NumKeys - 1].Value;
						NumKeys = m_TranslationCurve[2].GetNumKeys();
						if (NumKeys > 0) m_cgCameraEndKeyLocation.Z = m_TranslationCurve[2].GetData().GetValues()[NumKeys - 1].Value;


						NumKeys = m_RotationCurve[0].GetNumKeys();
						if (NumKeys > 1) m_cgCameraEndKeyRotation.Roll= m_RotationCurve[0].GetData().GetValues()[NumKeys - 1].Value;
						NumKeys = m_RotationCurve[1].GetNumKeys();
						if (NumKeys > 1) m_cgCameraEndKeyRotation.Pitch=m_RotationCurve[1].GetData().GetValues()[NumKeys - 1].Value;
						NumKeys = m_RotationCurve[2].GetNumKeys();
						if (NumKeys > 1) m_cgCameraEndKeyRotation.Yaw=m_RotationCurve[2].GetData().GetValues()[NumKeys - 1].Value;
					}
					
					if (m_bReplaceFirstKey)
					{
						UpdateFadeInOutCamera();
					}

				}
				else
				{
					UE_LOG(LogAzure, Error, TEXT("CG相机过渡事件失败,需要相机拥有位置旋转6条轨道，且不少于2个key"));
				}
			}
		}
	}

	return true;
}


void ALevelSequenceActorEx::OnStartedPlaying()
{
	if (!AAzureEntryPoint::Instance)
		return;

	wLua::Lua * wlua = AAzureEntryPoint::Instance->GetWLua();
	if (wlua == nullptr)
		return;
	lua_State_Wrapper L = wlua->GetL();
	if (L == nullptr)
		return;

	lua_getglobal(L, "OnLevelSequenceStartedPlaying");
	lua_pushinteger(L, m_cgid);
	wlua->Call(1);
}

void ALevelSequenceActorEx::OnStopped()
{
	if (!AAzureEntryPoint::Instance)
		return;

	wLua::Lua * wlua = AAzureEntryPoint::Instance->GetWLua();
	if (wlua == nullptr)
		return;
	lua_State_Wrapper L = wlua->GetL();
	if (L == nullptr)
		return;

	lua_getglobal(L, "OnLevelSequenceStopped");
	lua_pushinteger(L, m_cgid);
	wlua->Call(1);

	AWorldSettings* CurWorldSettings = GetWorld()->GetWorldSettings();
	if (CurWorldSettings)
	{
		CurWorldSettings->MatineeTimeDilation = 1;
		CurWorldSettings->ForceNetUpdate();
	}

	m_notHideByCGActorMap.Empty();
}

void ALevelSequenceActorEx::OnPaused()
{
	if (!AAzureEntryPoint::Instance)
		return;

	wLua::Lua * wlua = AAzureEntryPoint::Instance->GetWLua();
	if (wlua == nullptr)
		return;
	lua_State_Wrapper L = wlua->GetL();
	if (L == nullptr)
		return;

	lua_getglobal(L, "OnLevelSequencePaused");
	lua_pushinteger(L, m_cgid);
	wlua->Call(1);

	if (SequencePlayer && !SequencePlayer->IsPendingKill())
	{
		IMovieScenePlayer* pPlayer = SequencePlayer;
		ApplyCameraTrackOffset(pPlayer);
	}
}

void ALevelSequenceActorEx::SetLevelVisibleExcludeCG(ULevel * level, bool bActive)
{
	TSet<UObject*> cgActorSet = GetLevelSequenceContrlActors();
	SetLevelVisibleExclude(level, bActive, cgActorSet);
}

void ALevelSequenceActorEx::SetWorldStreamingVisibleExcludeCG(bool bActive)
{
	UWorld* world = GetWorld();
	if (!world) return;
	TSet<UObject*> cgActorSet = GetLevelSequenceContrlActors();

	const TArray<ULevelStreaming*>& levels = world->GetStreamingLevels();
	for (ULevelStreaming* stmLevel : levels)
	{
		if (!stmLevel->HasLoadedLevel()) continue;
		ULevel *level = stmLevel->GetLoadedLevel();
		SetLevelVisibleExclude(level, bActive, cgActorSet);
	}
}

void ALevelSequenceActorEx::SetLevelVisibleExclude(ULevel * level, bool bActive, const TSet<UObject*> &excludeActors)
{
	if (!level) return;
	
	TArray<TWeakObjectPtr<AActor>>& notHidelist = m_notHideByCGActorMap.FindOrAdd(level);
	for (AActor* Actor : level->Actors)
	{
		if (excludeActors.Contains(Actor)) continue;
		if (Actor&&Actor->GetClass() != APointLight::StaticClass() && Actor->GetClass() != ADirectionalLight::StaticClass())
		{
			
			bool excute = true;

			// 本来就隐藏的加到列表里，显示时跳过
			if (! bActive && Actor->bHidden)
			{
				notHidelist.Add(Actor);
				excute = false;
			}
			if(bActive && notHidelist.Find(Actor)!= INDEX_NONE)
			{
				excute = false;
			}
			
			if (excute)
			{
				Actor->SetActorHiddenInGame(!bActive);
				Actor->SetActorTickEnabled(bActive);
			}
		}

	}

	if (bActive)
	{
		notHidelist.Empty();
	}
}

TSet<UObject*> ALevelSequenceActorEx::GetLevelSequenceContrlActors()
{
	TSet<UObject*> cgActorSet;
	ULevelSequence* pLevelSequence = GetSequence();
	if (!pLevelSequence) return cgActorSet;

	UMovieScene* pMovieScene = pLevelSequence->GetMovieScene();
	if (!pMovieScene) return cgActorSet;

	for (int32 Index = 0; Index < pMovieScene->GetSpawnableCount(); ++Index)
	{
		FGuid ThisGuid = pMovieScene->GetSpawnable(Index).GetGuid();
		IMovieScenePlayer* pPlayer = SequencePlayer;
		UObject* SpawnedObject = pPlayer->GetSpawnRegister().FindSpawnedObject(ThisGuid, MovieSceneSequenceID::Root);
		cgActorSet.Add(SpawnedObject);
	}

	for (int32 Index = 0; Index < pMovieScene->GetPossessableCount(); ++Index)
	{
		FGuid ThisGuid = pMovieScene->GetPossessable(Index).GetGuid();
		TArray<UObject*, TInlineAllocator<1>> OutObjects;
		pLevelSequence->LocateBoundObjects(ThisGuid, SequencePlayer->GetPlaybackContext(), OutObjects);
		for (UObject* object: OutObjects)
		{
			cgActorSet.Add(object);
		}
	}

	return cgActorSet;
}

FMovieSceneSequenceID ALevelSequenceActorEx::FindObjectGUIDOwnerSequnenceID(FGuid guid)
{
	FMovieSceneSequenceID result;
	ULevelSequence* pLevelSequence = GetSequence();
	if (!pLevelSequence) return result;

	UMovieScene* pMovieScene = pLevelSequence->GetMovieScene();
	if (!pMovieScene) return result;
	FMovieSceneRootOverridePath overridePath;
	result = FindObjectGUIDOwnerSequnenceID(pMovieScene, guid, overridePath);
	if (!result.IsValid())
	{
		UE_LOG(LogAzure, Warning, TEXT("ALevelSequenceActorEx can not find owner sequnence  %s"), *guid.ToString());
	}
	return result;
}

FMovieSceneSequenceID ALevelSequenceActorEx::FindObjectGUIDOwnerSequnenceID(UMovieScene * pMovieScene, FGuid guid, FMovieSceneRootOverridePath& overridePath)
{
	if (!pMovieScene) return MovieSceneSequenceID::Invalid;

	if (IsObjectGUIDBeContryBy(pMovieScene, guid))
	{
		return overridePath.Remap(MovieSceneSequenceID::Root);
	}

	for (const UMovieSceneTrack* MasterTrack : pMovieScene->GetMasterTracks())
	{
		const UMovieSceneSubTrack* SubTrack = Cast<const UMovieSceneSubTrack>(MasterTrack);
		if (SubTrack)
		{
			for (UMovieSceneSection* Section : SubTrack->GetAllSections())
			{
				UMovieSceneSubSection* SubSection = Cast<UMovieSceneSubSection>(Section);
				UMovieSceneSequence* SubSequence = SubSection ? SubSection->GetSequence() : nullptr;
				if (!SubSection) continue;
				FMovieSceneSequenceID sId = SubSection->GetSequenceID();
				overridePath.Push(sId);
				FMovieSceneSequenceID result = FindObjectGUIDOwnerSequnenceID(SubSequence->GetMovieScene(), guid, overridePath);
				if (result.IsValid())
				{
					return result;
				}
				overridePath.Pop();
			}
		}
	}

	return MovieSceneSequenceID::Invalid;
}

bool ALevelSequenceActorEx::IsObjectGUIDBeContryBy(UMovieScene * pMovieScene, FGuid guid)
{
	if (!pMovieScene) return false;
	int findCount = 0;
	for (int32 Index = 0; Index < pMovieScene->GetSpawnableCount(); ++Index)
	{
		FMovieSceneSpawnable spawn = pMovieScene->GetSpawnable(Index);
		FGuid ThisGuid = spawn.GetGuid();
		if (ThisGuid == guid)
		{
			if (findCount > 0) UE_LOG(LogAzure, Warning, TEXT("repeat guid"), *spawn.GetName());
			++findCount;
		}
	}

	for (int32 Index = 0; Index < pMovieScene->GetPossessableCount(); ++Index)
	{
		FMovieScenePossessable possessable = pMovieScene->GetPossessable(Index);
		FGuid ThisGuid = possessable.GetGuid();
		if (ThisGuid == guid)
		{
			if(findCount>0) UE_LOG(LogAzure, Warning, TEXT("repeat guid"), *possessable.GetName());
			++findCount;
		}
	}
	

	return findCount > 0;
}



bool ALevelSequenceActorEx::GetHostBeginTransform(FTransform &outTrans)
{
	ULevelSequence* pLevelSequence = GetSequence();
	if (!pLevelSequence)
		return false;
	UMovieScene* pMovieScene = pLevelSequence->GetMovieScene();

	// 找到替换host的event
	auto eventInfo = FindEventByName(pMovieScene, TEXT("CGEventBindingHostPlayer"));
	auto eventHostPlayer = eventInfo.eventPayload;
	FStructOnScope ParameterStruct(nullptr);
	eventHostPlayer.Parameters.GetInstance(ParameterStruct);
	if (!ParameterStruct.IsValid()) return false;

	const UStruct* param = ParameterStruct.GetStruct();
	uint8* parameters = ParameterStruct.GetStructMemory();

	const FCGTrackStruct* CGTrack = nullptr;

	if (UStructProperty* StructProperty = AzureUtility::FindBluepintStructFiledByName<UStructProperty>(param, TEXT("CGBindingTrackBody")))
	{
		CGTrack = StructProperty->ContainerPtrToValuePtr<FCGTrackStruct>(parameters);
	}
	if (!CGTrack || CGTrack->TrackGUID == InvalideTrackGUIDStr)
	{
		if (UStructProperty* StructProperty = AzureUtility::FindBluepintStructFiledByName<UStructProperty>(param, TEXT("CGBindingTrackBodyList")))
		{
			FCGMultiTrackStruct* multiTrack = StructProperty->ContainerPtrToValuePtr<FCGMultiTrackStruct>(parameters);
			if (multiTrack)
			{
				CGTrack = multiTrack->CGTrackList.Num() > 0 ? &multiTrack->CGTrackList[0] : nullptr;
			}
		}
		
	}

	if (!CGTrack) return false;

	// 取得host的位移轨道
	FGuid CGTrackGUID;
	UMovieScene3DTransformTrack* transfromTrack = nullptr;
	if (FGuid::ParseExact(CGTrack->TrackGUID, EGuidFormats::DigitsWithHyphensInBraces, CGTrackGUID) && CGTrackGUID.IsValid())
	{
		FMovieSceneSequenceID sid(CGTrack->SequenceID);
		return GetTransformTrackValue(CGTrackGUID, FMovieSceneSequenceID(CGTrack->SequenceID), outTrans, false);
	}
	return false;
}

bool ALevelSequenceActorEx::lua_GetTransformTrackValue(const FString & strCGTrackDisplayName, const FString & strCGTrackGUID, const FString & sequenceIDStr, bool isEndKey, FTransform & outTrans)
{
	FGuid CGTrackGUID;

	uint32 uintSequenceID = (uint32)FCString::Atod(*sequenceIDStr);
	if (FGuid::ParseExact(strCGTrackGUID, EGuidFormats::DigitsWithHyphensInBraces, CGTrackGUID) && CGTrackGUID.IsValid())
	{
		return GetTransformTrackValue(CGTrackGUID, FMovieSceneSequenceID(uintSequenceID), outTrans, isEndKey);
	}
	return false;
}

void ALevelSequenceActorEx::lua_GetEventsDataByName(FString eventName, lua_State * L)
{
	ULevelSequence* pLevelSequence = GetSequence();
	if (!pLevelSequence)
		return ;
	UMovieScene* pMovieScene = pLevelSequence->GetMovieScene();
	TArray<CGEventInfo> eventsArray = FindEventsByName(pMovieScene, eventName);
	
	//eventList
	lua_newtable(L);
	int i = 1; 
	for (const CGEventInfo &itemEvent : eventsArray)
	{
		FStructOnScope ParameterStruct(nullptr);
		itemEvent.eventPayload.Parameters.GetInstance(ParameterStruct);
		if (!ParameterStruct.IsValid()) continue;

		//eventList event
		lua_newtable(L);
		const UStruct* param = ParameterStruct.GetStruct();
		UProperty* property = Cast<UProperty>(param->Children);
		ALevelSequenceActorEx::lua_PushEventDataToLua(property, ParameterStruct.GetStructMemory(), L);
		//eventList event eventTable
		lua_setfield(L, -2, "eventTable");

		lua_pushnumber(L, itemEvent.frameNumber.Value);
		lua_setfield(L, -2, "frameNumber");

		//eventList event
		lua_rawseti(L, -2, i);
		++i;
	} 
}


// 获取TransformTrack第一帧的位置
bool ALevelSequenceActorEx::GetTransformTrackValue(FGuid trackId, FMovieSceneSequenceID seqId, FTransform &outTrans, bool isEndKey)
{
	ShotSequenceNode *pSequnceNode = FindMovieScenesNode(seqId);
	if (pSequnceNode == nullptr) return false;

	UMovieScene3DTransformTrack *transfromTrack = pSequnceNode->movieScene->FindTrack<UMovieScene3DTransformTrack>(trackId, NAME_None);
	if (!transfromTrack) return false;

	ULevelSequence* pLevelSequence = GetSequence();
	UMovieScene* pRootMovieScene = pLevelSequence->GetMovieScene();

	const TArray<UMovieSceneSection*> sections = transfromTrack->GetAllSections();
	if (sections.Num() <= 0) return false;
	
	TRange<FFrameNumber> range = pRootMovieScene->GetPlaybackRange() * pSequnceNode->RootToSequenceTransform;
	FFrameNumber frame = isEndKey ? range.GetUpperBoundValue() : range.GetLowerBoundValue();
	//考虑多个section的情况
	UMovieSceneSection *targetSection = nullptr;
	for (UMovieSceneSection *section : sections)
	{
		if (!section) continue;
		
		if (section->GetRange().Contains(frame))
		{
			targetSection = section;
		}
	}

	if (!targetSection) return false;

	UMovieScene3DTransformSection * pTransfromSection = Cast<UMovieScene3DTransformSection>(targetSection);
	TArrayView<FMovieSceneFloatChannel*> FloatChannels = pTransfromSection->GetChannelProxy().GetChannels<FMovieSceneFloatChannel>();

	FFrameTime time(frame);
	FVector location;
	FloatChannels[0]->Evaluate(time, location.X);
	FloatChannels[1]->Evaluate(time, location.Y);
	FloatChannels[2]->Evaluate(time, location.Z);
	outTrans.SetLocation(location);

	FRotator rotator;
	FloatChannels[3]->Evaluate(time, rotator.Roll);
	FloatChannels[4]->Evaluate(time, rotator.Pitch);
	FloatChannels[5]->Evaluate(time, rotator.Yaw);

	outTrans.SetRotation(FQuat(rotator));
	
	return true;
}

CGEventInfo ALevelSequenceActorEx::FindEventByName(UMovieScene * pMovieScene, FString eventName)
{
	TArray<CGEventInfo> eventsArray = FindEventsByName(pMovieScene, eventName, true);;
	

	return eventsArray.Num() > 0 ? eventsArray[0]: CGEventInfo();
}

TArray<CGEventInfo> ALevelSequenceActorEx::FindEventsByName(UMovieScene * pMovieScene, FString eventName, bool justFindOne)
{
	TArray<CGEventInfo> eventsArray;
	
	auto tickResolution = pMovieScene->GetTickResolution();
	auto displayResolution = pMovieScene->GetDisplayRate();

	for (UMovieSceneTrack* pTrack : pMovieScene->GetMasterTracks())
	{
		UMovieSceneEventTrack* pEventTrack = Cast<UMovieSceneEventTrack>(pTrack);
		if (!pEventTrack) continue;

		TArray<UMovieSceneSection*> OutSections = pEventTrack->GetAllSections();
		for (int i = 0; i < OutSections.Num(); i++)
		{
			UMovieSceneEventSection* pSection = Cast<UMovieSceneEventSection>(OutSections[i]);
			if (!pSection) continue;

			TArrayView<const FEventPayload> KeyValues = pSection->GetEventData().GetKeyValues();
			TArrayView<const FFrameNumber> keyTimes = pSection->GetEventData().GetKeyTimes();
			int32 valueCount = KeyValues.Num();
			for (int32 i = 0; i < valueCount; ++i)
			{
				auto keyValue = KeyValues[i];
				auto keyTime = keyTimes[i];
				if (keyValue.EventName == *eventName)
				{
					FFrameTime time(keyTime);
					time = ConvertFrameTime(time, tickResolution, displayResolution);
					eventsArray.Emplace(CGEventInfo(keyValue, time.GetFrame()));
					if (justFindOne)
					{
						return eventsArray;
					}
				}
			}

		}
	}
	return eventsArray;
}

bool ALevelSequenceActorEx::lua_PushEventDataToLua(UProperty * HeadProperty, void* Parameters, lua_State * L)
{
	lua_newtable(L);	//table
	if (!HeadProperty || !Parameters || !L) return false;

	for (UProperty* Property = HeadProperty; Property; Property = Cast<UProperty>(Property->Next))
	{
		FString strName = Property->GetName();
		int iCut = strName.Find(TEXT("_"));
		if (iCut != INDEX_NONE)
		{
			strName = strName.Left(iCut);
		}

		if (Property->IsA(UByteProperty::StaticClass()))
		{
			uint8* var = Property->ContainerPtrToValuePtr<uint8>(Parameters);
			lua_pushinteger(L, *var);
			lua_setfield(L, -2, TCHAR_TO_UTF8(*strName));
		}
		else if (Property->IsA(UIntProperty::StaticClass()))
		{
			int32* var = Property->ContainerPtrToValuePtr<int32>(Parameters);
			lua_pushinteger(L, *var);
			lua_setfield(L, -2, TCHAR_TO_UTF8(*strName));
		}
		else if (Property->IsA(UFloatProperty::StaticClass()))
		{
			float* var = Property->ContainerPtrToValuePtr<float>(Parameters);
			lua_pushnumber(L, *var);
			lua_setfield(L, -2, TCHAR_TO_UTF8(*strName));
		}
		else if (Property->IsA(UStrProperty::StaticClass()))
		{
			FString* var = Property->ContainerPtrToValuePtr<FString>(Parameters);
			lua_pushstring(L, TCHAR_TO_UTF8(**var));
			lua_setfield(L, -2, TCHAR_TO_UTF8(*strName));
		}
		else if (Property->IsA(UNameProperty::StaticClass()))
		{
			FString var = Property->ContainerPtrToValuePtr<FName>(Parameters)->ToString();
			lua_pushstring(L, TCHAR_TO_UTF8(*var));
			lua_setfield(L, -2, TCHAR_TO_UTF8(*strName));
		}
		else if (Property->IsA(UTextProperty::StaticClass()))
		{
			FString var = Property->ContainerPtrToValuePtr<FText>(Parameters)->ToString();
			lua_pushstring(L, TCHAR_TO_UTF8(*var));
			lua_setfield(L, -2, TCHAR_TO_UTF8(*strName));
		}
		else if (Property->IsA(UBoolProperty::StaticClass()))
		{
			bool* var = Property->ContainerPtrToValuePtr<bool>(Parameters);
			lua_pushboolean(L, *var);
			lua_setfield(L, -2, TCHAR_TO_UTF8(*strName));
		}
		else if (Property->IsA(UStructProperty::StaticClass()))
		{
			UStructProperty* StructProperty = Cast<UStructProperty>(Property);
			if (StructProperty->Struct == FCGTrackStruct::StaticStruct())
			{
				FCGTrackStruct* CGTrack = StructProperty->ContainerPtrToValuePtr<FCGTrackStruct>(Parameters);
				lua_PushCGTrackStructToLua(CGTrack, L);
				lua_setfield(L, -2, TCHAR_TO_UTF8(*strName));
			}
			else if (StructProperty->Struct == FCGMultiTrackStruct::StaticStruct())
			{
				FCGMultiTrackStruct* CGMultiTrack = StructProperty->ContainerPtrToValuePtr<FCGMultiTrackStruct>(Parameters);
				lua_newtable(L);// t
				{
					lua_pushstring(L, TCHAR_TO_UTF8(*CGMultiTrack->MatchTrackName));//t s
					lua_setfield(L, -2, TCHAR_TO_UTF8(TEXT("MatchTrackName")));//t

					lua_newtable(L);// t t
					int i = 1;
					for (auto& CGTrack : CGMultiTrack->CGTrackList)
					{
						lua_PushCGTrackStructToLua(&CGTrack, L);// t t t
						lua_rawseti(L, -2, i);//t t
						++i;
					}
					lua_setfield(L, -2, TCHAR_TO_UTF8(TEXT("CGTrackList")));//t
				}
				lua_setfield(L, -2, TCHAR_TO_UTF8(*strName));//
			}
			else
			{
				FString structName = StructProperty->Struct->GetName();
				UE_LOG(LogAzure, Warning, TEXT("Not support, StructProperty %s"),*structName);
			}
		}
		else if (Property->IsA(UObjectProperty::StaticClass()))
		{
			UObject** ppObj = Property->ContainerPtrToValuePtr<UObject*>(Parameters);
			UObject* Obj = ppObj ? *ppObj : nullptr;
			lua_pushlightuserdata(L, Obj);

			lua_setfield(L, -2, TCHAR_TO_UTF8(*strName));
		}
		else if (Property->IsA(UEnumProperty::StaticClass()))
		{
			int32* var = Property->ContainerPtrToValuePtr<int32>(Parameters);
			lua_pushinteger(L, *var);
			lua_setfield(L, -2, TCHAR_TO_UTF8(*strName));
		}
		else
		{
			UE_LOG(LogAzure, Warning, TEXT("Not support, property %s"), *strName);
		}
	}
	return true;
}

void ALevelSequenceActorEx::ApplyCameraTrackOffset(IMovieScenePlayer * pPlayer)
{
	if (pPlayer == nullptr) return;

	// 镜头根据高度做偏移
	for (const FCAMERA_OFFSET_EX& CameraOffset : m_aCamerOffset)
	{
		UObject* SpawnedObject = FindBindingObject("ApplyCameraTrackOffset", CameraOffset.guid, CameraOffset.sequenceID, false);
		if (SpawnedObject)
		{
			AActor* pSpawnedActor = Cast<AActor>(SpawnedObject);
			if (pSpawnedActor)
			{
				USceneComponent* SceneComponent = nullptr;
				if (pSpawnedActor->GetRootComponent())
				{
					// If there is an actor, modify its root component
					SceneComponent = pSpawnedActor->GetRootComponent();
					FVector RelativeLocation = SceneComponent->RelativeLocation;
					RelativeLocation.Z += CameraOffset.z;
					SceneComponent->SetRelativeLocationAndRotation(RelativeLocation, SceneComponent->RelativeRotation);
					SceneComponent->RelativeLocation = RelativeLocation;
				}
			}
		}
	}
}

void ALevelSequenceActorEx::UpdateTimeDilation(IMovieScenePlayer* pPlayer)
{
	if (pPlayer == nullptr) return;

	// PlayRate
	UObject* PlaybackContext = pPlayer->GetPlaybackContext();
	UWorld* World = PlaybackContext ? PlaybackContext->GetWorld() : nullptr;
	if (World)
	{
		AWorldSettings* WorldSettings = World->GetWorldSettings();
		if (WorldSettings)
		{
			AWorldSettings* CurWorldSettings = GetWorld()->GetWorldSettings();
			if (CurWorldSettings)
			{
				if (CurWorldSettings->MatineeTimeDilation != WorldSettings->MatineeTimeDilation)
				{
					CurWorldSettings->MatineeTimeDilation = WorldSettings->MatineeTimeDilation;
					CurWorldSettings->ForceNetUpdate();
				}
			}

		}
	}
}

void ALevelSequenceActorEx::SetRuntimeBindingSpawnEnable(UMovieSceneSequence* msSequence, bool enable)
{
	if (!msSequence) return;
	UMovieScene *pMovieScene = msSequence->GetMovieScene();
	if (!pMovieScene) return;


	for (UMovieSceneTrack* pTrack : pMovieScene->GetMasterTracks())
	{
		UMovieSceneEventTrack* pEventTrack = Cast<UMovieSceneEventTrack>(pTrack);
		if (!pEventTrack) continue;


		TArray<UMovieSceneSection*> OutSections = pEventTrack->GetAllSections();
		for (int i = 0; i < OutSections.Num(); i++)
		{
			UMovieSceneEventSection* pSection = Cast<UMovieSceneEventSection>(OutSections[i]);
			if (!pSection) continue;

			if (!pSection->IsActive()) continue;

			TArrayView<const FEventPayload> KeyValues = pSection->GetEventData().GetKeyValues();
			for (int32 KeyIndex = KeyValues.Num() - 1; KeyIndex >= 0; --KeyIndex)
			{
				FString eventName = KeyValues[KeyIndex].EventName.ToString();

				UFunction* EventFunction = FindFunction(KeyValues[KeyIndex].EventName);
				if (!EventFunction) continue;

				FStructOnScope ParameterStruct(nullptr);
				KeyValues[KeyIndex].Parameters.GetInstance(ParameterStruct);
				if (!ParameterStruct.IsValid()) continue;

				uint8* Parameters = ParameterStruct.GetStructMemory();

				const UStruct* Struct = ParameterStruct.GetStruct();
				if (EventFunction->ReturnValueOffset != MAX_uint16) continue;

				TFieldIterator<UProperty> ParamIt(EventFunction);
				TFieldIterator<UProperty> ParamInstanceIt(Struct);
				for (int32 NumParams = 0; ParamIt || ParamInstanceIt; ++NumParams, ++ParamIt, ++ParamInstanceIt)
				{
					if (!ParamInstanceIt)
					{
						break;
					}
					else if (!ParamIt)
					{
						break;
					}
					else if (!ParamInstanceIt->SameType(*ParamIt) || ParamInstanceIt->GetOffset_ForUFunction() != ParamIt->GetOffset_ForUFunction() || ParamInstanceIt->GetSize() != ParamIt->GetSize())
					{
						break;
					}
					UProperty *Property = *ParamIt;
					if (Property->IsA(UStructProperty::StaticClass()))
					{
						FString strName = Property->GetName();
						int iCut = strName.Find(TEXT("_"));
						if (iCut != INDEX_NONE)
						{
							strName = strName.Left(iCut);
						}
						//通过track名来决定是否绑定
						if (!strName.StartsWith(BindingTrackEventPrefix)) continue;
						TArray<FCGTrackStruct*> cgTrackStructList;
						UStructProperty* StructProperty = Cast<UStructProperty>(Property);

						if (StructProperty->Struct == FCGTrackStruct::StaticStruct())
						{
							FCGTrackStruct* CGTrack = StructProperty->ContainerPtrToValuePtr<FCGTrackStruct>(Parameters);
							// 当有list类型的track时，就不检查单个的track了
							if (CGTrack && CGTrack->TrackGUID != InvalideTrackGUIDStr)
							{
								cgTrackStructList.Add(CGTrack);
							}
						}
						else if (StructProperty->Struct == FCGMultiTrackStruct::StaticStruct())
						{

							FCGMultiTrackStruct* CGMultiTrack = StructProperty->ContainerPtrToValuePtr<FCGMultiTrackStruct>(Parameters);
							if (CGMultiTrack)
							{
								for (auto &cgTrack : CGMultiTrack->CGTrackList)
								{
									cgTrackStructList.Add(&cgTrack);
								}
							}
						}

						for (auto CGTrack : cgTrackStructList)
						{
							FGuid CGTrackGUID;
							if (!FGuid::ParseExact(CGTrack->TrackGUID, EGuidFormats::DigitsWithHyphensInBraces, CGTrackGUID)) continue;

							if (!CGTrackGUID.IsValid())
							{
								//有些参数是可为空的，不提示
								if (!strName.StartsWith(BindingTrackEventCheckExclude))
								{
									UE_LOG(LogAzure, Warning, TEXT("ALevelSequenceActorEx::CheckLevelSequenceEx CGTrackGUID is not valid: %s    %s"), *CGTrack->TrackGUID, *strName);
								}
								continue;
							}

							FMovieSceneSequenceID sid(CGTrack->SequenceID);
							ShotSequenceNode *pSequnceNode = FindMovieScenesNode(sid);
							if (pSequnceNode == nullptr)
							{
#if WITH_EDITORONLY_DATA
								FString trackName = pEventTrack->GetDisplayName().ToString();
#else
								FString trackName = "Unkown";
#endif
								UE_LOG(LogAzure, Error, TEXT("ALevelSequenceActorEx::CheckLevelSequenceEx can not find sub sequence, trackName:%s eventName:%s eventIndex:%d filedName:%s"), *trackName, *eventName, KeyIndex, *strName);
								continue;
							}

							UMovieSceneSpawnTrack* SpawnTrack = pSequnceNode->movieScene->FindTrack<UMovieSceneSpawnTrack>(CGTrackGUID, NAME_None);
							if (!SpawnTrack) continue;

							const TArray<UMovieSceneSection*> Sections = SpawnTrack->GetAllSections();
							if (Sections.Num() <= 0) continue;

							UMovieSceneSpawnSection* pSpawnSection = Cast<UMovieSceneSpawnSection>(Sections[0]);
							if (!pSpawnSection) continue;

							pSpawnSection->GetChannel().Reset(); //这个通道不许有帧 只可用默认值 否则如果第一帧为true有可能看到裸模
							pSpawnSection->GetChannel().SetDefault(enable); //由于cook,把值改回来

							//editor版改了default会即时刷template，而发布版是用的预先编译过的template,故要有下面逻辑
							UMovieSceneSequence* Sequence = pSequnceNode->msSequence.Get();
							if (!Sequence) continue;

							for (TTuple<FMovieSceneTrackIdentifier, FMovieSceneEvaluationTrack>& Pair : Sequence->PrecompiledEvaluationTemplate.GetTracks())// Iterate tracks within this template
							{
								if (Pair.Value.GetObjectBindingID() == CGTrackGUID && Pair.Value.HasChildTemplate(0))
								{
									const FMovieSceneEvalTemplate* pChild = &Pair.Value.GetChildTemplate(0);
									UScriptStruct& _struct = pChild->GetScriptStruct();
									if (_struct.GetName() == TEXT("MovieSceneSpawnSectionTemplate"))
									{
										FMovieSceneEvalTemplatePtr NewTemplate = SpawnTrack->CreateTemplateForSection(*pSpawnSection);
										Pair.Value.DefineAsSingleTemplate(MoveTemp(NewTemplate));
									}
								}
							}



						}
					}


				}



			}
		}
	}

}

ShotSequenceNode * ALevelSequenceActorEx::FindMovieScenesNode(const FMovieSceneSequenceID & seID)
{
	return sequenceNodeHierarchy.FindNode(seID);
}

void ALevelSequenceActorEx::SetRuntimeBindingSpawnEnable(bool enable)
{
	//在PIE模式下停止的时候，会GC，不能执行FindObject，使用单独的指针
#if UE_EDITOR
	ULevelSequence* pLevelSequence = editorLevelSequencePtr.Get();
#else
	ULevelSequence* pLevelSequence = GetSequence();
#endif
	if (!pLevelSequence)
		return;
	UMovieSceneSequence* msSequence = Cast<UMovieSceneSequence>(pLevelSequence);
	SetRuntimeBindingSpawnEnable(msSequence, enable);
}

void ALevelSequenceActorEx::DissolveCameraScreenShot(UCameraComponent * cameraComp, UTextureRenderTarget2D * rtTexture, float dissolveTime)
{
	if (!cameraComp || !rtTexture) return;

	if (captureComp == nullptr)
	{
		captureComp = NewObject<USceneCaptureComponent2D>(this, TEXT("SceneCaptureComponent2DForCG"));

		captureComp->RegisterComponent();
		captureComp->AttachToComponent(RootComponent, FAttachmentTransformRules::KeepRelativeTransform);
		captureComp->bCaptureEveryFrame = false;
		captureComp->bCaptureOnMovement = false;
	}
	captureComp->TextureTarget = rtTexture;
	
	FVector2D size = UWidgetLayoutLibrary::GetViewportSize(this);
	rtTexture->ResizeTarget(size.X, size.Y);

	captureComp->SetWorldTransform(cameraComp->GetComponentTransform());

	captureComp->FOVAngle = cameraComp->FieldOfView;
	captureComp->OrthoWidth = cameraComp->OrthoWidth;
	captureComp->PostProcessSettings = cameraComp->PostProcessSettings;
	captureComp->PostProcessBlendWeight = cameraComp->PostProcessBlendWeight;

	captureComp->CaptureSceneDeferred();
}

void ALevelSequenceActorEx::SetPlaybackSettingStartOffset(float startOffset)
{
	PlaybackSettings.StartTime = startOffset;
}

void ALevelSequenceActorEx::SetPlaybackSettingLoopCount(int loopCount)
{
	PlaybackSettings.LoopCount = loopCount;
}

void ALevelSequenceActorEx::lua_PushCGTrackStructToLua(const FCGTrackStruct* CGTrack, lua_State * L)
{
	if (!CGTrack) return;
	lua_newtable(L);
	lua_pushstring(L, TCHAR_TO_UTF8(*CGTrack->TrackDisplayName));
	lua_setfield(L, -2, TCHAR_TO_UTF8(TEXT("TrackDisplayName")));

	lua_pushstring(L, TCHAR_TO_UTF8(*CGTrack->TrackGUID));
	lua_setfield(L, -2, TCHAR_TO_UTF8(TEXT("TrackGUID")));

	lua_pushnumber(L, CGTrack->SequenceID);
	lua_setfield(L, -2, TCHAR_TO_UTF8(TEXT("SequenceID")));	
}

UObject * ALevelSequenceActorEx::SpawnObjectByTrack(const FString & strCGTrackDisplayName, const FString & strCGTrackGUID, const FString &sequenceIDStr)
{
	UObject* OutVal = nullptr;
	FGuid CGTrackGUID;
	
	uint32 uintSequenceID = (uint32)FCString::Atod(*sequenceIDStr);
	if (FGuid::ParseExact(strCGTrackGUID, EGuidFormats::DigitsWithHyphensInBraces, CGTrackGUID) && CGTrackGUID.IsValid())
	{
		OutVal = SpawnObjectByTrack(CGTrackGUID, FMovieSceneSequenceID(uintSequenceID));
	}
	else
	{
		UE_LOG(LogAzure, Warning, TEXT("ULevelSequencePlayerEx::SpawnObjectByTrack: GUID=%s parse failed! track name(%s)"), *strCGTrackGUID, *strCGTrackDisplayName);
	}
	return OutVal;
}

UObject * ALevelSequenceActorEx::SpawnObjectByTrack(const FGuid trackGUID, const FMovieSceneSequenceID sequenceID)
{
	ULevelSequencePlayerEx* SequencePlayerEx = GetSequencePlayerEx();
	if (!ensure(SequencePlayerEx)) return nullptr;
	
	UMovieSceneSequence* Sequence = SequencePlayerEx->State.FindSequence(sequenceID);
	if (!Sequence)
	{
		ShotSequenceNode * node = FindMovieScenesNode(sequenceID);
		if (node) Sequence = node->msSequence.Get();
	}
	if (Sequence)
	{
		return SequencePlayerEx->SpawnObjectByTrack(trackGUID, Sequence, sequenceID);
	}
	
	return nullptr;
}

void ALevelSequenceActorEx::DestroySpawnObjectByTrack(UObject *Obj)
{
	if (!Obj) return;
	ULevelSequencePlayerEx* SequencePlayerEx = GetSequencePlayerEx();
	if (!ensure(SequencePlayerEx)) return;

	SequencePlayerEx->DestroySpawnObjectByTrack(Obj);
}

void AzureSequenceNodeHierarchy::Init(ULevelSequence * rootLevelSequence)
{
	CollectAllMovieScene(rootLevelSequence);
}

ShotSequenceNode * AzureSequenceNodeHierarchy::FindNode(FMovieSceneSequenceID id)
{
	for (ShotSequenceNode &itemMovieScene : allMoviScenes)
	{
		if (itemMovieScene.id == id)
			return &itemMovieScene;
	}
	return nullptr;
}

void AzureSequenceNodeHierarchy::CollectAllMovieScene(ULevelSequence* rootLevelSequence)
{
	allMoviScenes.Empty();
	if (!rootLevelSequence) return;

	UMovieSceneSequence* msSequence = Cast<UMovieSceneSequence>(rootLevelSequence);
	if (!msSequence) return;

	UMovieScene *pMovieScene = msSequence->GetMovieScene();
	if (!pMovieScene) return;

	FAzureSequenceIDStack idStack;
	ShotSequenceNode node(pMovieScene, msSequence, idStack.GetCurrent());

	int index = allMoviScenes.Add(node);
	CollectAllMovieScene(index, idStack);
}

void AzureSequenceNodeHierarchy::CollectAllMovieScene(int parentNodeIndex, FAzureSequenceIDStack & idStack)
{
	if (allMoviScenes.Num() <= parentNodeIndex) return;
	ShotSequenceNode parentNode = allMoviScenes[parentNodeIndex];
	UMovieScene* parentMovieScene = parentNode.movieScene.Get();
	if (parentMovieScene == nullptr) return;

	//递归处理子shot
	TArray<UMovieSceneTrack*> tracks = parentMovieScene->GetMasterTracks();
	for (UMovieSceneTrack * track : tracks)
	{
		if (!Cast<UMovieSceneCinematicShotTrack>(track)) continue;
		TArray<UMovieSceneSection*> sections = track->GetAllSections();
		for (UMovieSceneSection* section : sections)
		{
			UMovieSceneCinematicShotSection *ssSection = Cast<UMovieSceneCinematicShotSection>(section);
			if (!ssSection) continue;
			UMovieSceneSequence *msSequence = ssSection->GetSequence();
			if (!msSequence) continue;
			UMovieScene * mvScene = msSequence->GetMovieScene();
			if (!mvScene) continue;

			FMovieSceneSequenceID id = ssSection->GetSequenceID();
			idStack.Push(id);
			ShotSequenceNode node(mvScene, msSequence, idStack.GetCurrent());
			node.parentNodeIndex = parentNodeIndex;
			node.RootToSequenceTransform = ssSection->OuterToInnerTransform() * parentNode.RootToSequenceTransform;
			int index = allMoviScenes.Add(node);
			CollectAllMovieScene(index, idStack);
			idStack.Pop();
		}
	}
}


