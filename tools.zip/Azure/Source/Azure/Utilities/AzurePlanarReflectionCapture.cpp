// Fill out your copyright notice in the Description page of Project Settings.

#include "AzurePlanarReflectionCapture.h"
#include "AzureEntryPoint.h"
#include "GameFramework/PlayerController.h"
#include "components/PrimitiveComponent.h"
#include "components/PlanarReflectionComponent.h"
#include "kismet/GameplayStatics.h"

AAzurePlanarReflectionCapture* AAzurePlanarReflectionCapture::captureInstance = nullptr;
int32 AAzurePlanarReflectionCapture::reflectionQuality = 2;

AAzurePlanarReflectionCapture::AAzurePlanarReflectionCapture(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer) , isReflectHostPlayer( true )
{
	PrimaryActorTick.bCanEverTick = true;
}

// Called when the game starts or when spawned
void AAzurePlanarReflectionCapture::BeginPlay()
{
	Super::BeginPlay();

	if (captureInstance)
	{
		check(captureInstance == nullptr);
	}
	else
	{
		captureInstance = this;
	}
	
	multiReflectionHeights.Sort( []( const float& A , const float& B ) { return A < B; } );

	UPlanarReflectionComponent *captureComp = GetPlanarReflectionComponent();
	//ignore login_map
	if ( captureComp && captureComp->PrimitiveRenderMode == ESceneCapturePrimitiveRenderMode::PRM_UseShowOnlyList )
	{
		this->SetActorTickEnabled( reflectionQuality > 0 );
		this->SetActorHiddenInGame( reflectionQuality <= 0 );
	}
}

// Called every frame
void AAzurePlanarReflectionCapture::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);

	AutoSelectReflectionHeight();
}

void AAzurePlanarReflectionCapture::EndPlay( const EEndPlayReason::Type EndPlayReason )
{
	Super::EndPlay( EndPlayReason );

	if ( captureInstance == this )
	{
		captureInstance = nullptr;
	}
	else
	{
		check(captureInstance == nullptr || captureInstance == this);
	}
}

void AAzurePlanarReflectionCapture::AddComponentInShowList( UPrimitiveComponent *compToShow )
{
	if ( !isReflectHostPlayer ) return;
	if ( reflectionQuality <= 1 ) return;
	if ( !::IsValid( compToShow ) ) return;
	if ( !::IsValid( GetPlanarReflectionComponent() ) ) return;

	TArray<TWeakObjectPtr<UPrimitiveComponent>> &showComponents = GetPlanarReflectionComponent()->ShowOnlyComponents;
	showComponents.AddUnique( compToShow );
}

void AAzurePlanarReflectionCapture::RemoveComponentFromShowList( UPrimitiveComponent *compToHide )
{
	if ( !isReflectHostPlayer ) return;
	if ( reflectionQuality <= 1 ) return;
	if ( !::IsValid( compToHide ) ) return;
	if ( !::IsValid( GetPlanarReflectionComponent() ) ) return;

	TArray<TWeakObjectPtr<UPrimitiveComponent>> &showComponents = GetPlanarReflectionComponent()->ShowOnlyComponents;
	if ( showComponents.Contains( compToHide ) )
	{
		showComponents.Remove( compToHide );
	}
}

void AAzurePlanarReflectionCapture::AutoSelectReflectionHeight()
{
	if ( !::IsValid( GetPlanarReflectionComponent() ) ) return;
	int32 len = multiReflectionHeights.Num();
	if ( len <= 0 ) return;

	bool bValidCameraPosition = false;
	FVector CameraPosition;
	if ( !savedPlayerCtrl.IsValid() )
	{
		savedPlayerCtrl = UGameplayStatics::GetPlayerController( this , 0 );
	}

	if ( savedPlayerCtrl.IsValid() )
	{
		FRotator vpRotation;
		savedPlayerCtrl->GetPlayerViewPoint( CameraPosition , vpRotation );

		bValidCameraPosition = true;
	}
	if ( !bValidCameraPosition ) return;
	
	float curHeight = CameraPosition.Z;
	float selectedHeight = 0.0f;
	for ( int32 i = 0; i < len - 1; ++i )
	{
		float low = multiReflectionHeights[i];
		float high = multiReflectionHeights[i + 1];
		
		if ( curHeight < low )
		{
			selectedHeight = low;
			break;
		}
		else if ( curHeight >= low && curHeight < high )
		{
			selectedHeight = low;
			break;
		}
		else if ( i == len - 2 ) // last one
		{
			selectedHeight = high;
		}
	}
	
	FVector curWorldLoc = GetPlanarReflectionComponent()->GetComponentLocation();
	if ( curWorldLoc.Z != selectedHeight )
	{
		curWorldLoc.Z = selectedHeight;
		GetPlanarReflectionComponent()->SetWorldLocation( curWorldLoc );
	}
}
