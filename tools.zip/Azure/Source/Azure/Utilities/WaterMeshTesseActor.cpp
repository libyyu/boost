// Fill out your copyright notice in the Description page of Project Settings.

#include "WaterMeshTesseActor.h"
#include "Azure.h"
#include "StaticMeshResources.h"
#include "ProceduralMeshComponent.h"
#include "Camera/CameraComponent.h"
#include "AzureEntryPoint.h"
#include "OceanWaterMesh.h"
#include "Engine/StaticMesh.h"
#include "GameFramework/PlayerController.h"
#include "EngineUtils.h"

// Sets default values
AWaterMeshTesseActor::AWaterMeshTesseActor() : 
	TesseUpdateInterval(5),
	TesseUpdateTimer(0),
	TesseDistance(1000)
{
 	// Set this actor to call Tick() every frame.  You can turn this off to improve performance if you don't need it.
	PrimaryActorTick.bCanEverTick = true;

	CameraPos.X = 99999999;
	CameraPos.Y = 99999999;
	FTesseLevel tl;
	tl.DistCamera = 1000.0f;
	tl.TesseMinEdge = 100.0f;
	TesseParam.Add(tl);
	tl.DistCamera = 5000.0f;
	tl.TesseMinEdge = 200.0f;
	TesseParam.Add(tl);
	tl.DistCamera = 10000.0f;
	tl.TesseMinEdge = 500.0f;
	TesseParam.Add(tl);
	BorderSize = 20000.0f;

	Root = CreateDefaultSubobject<USceneComponent>("Root");

	for (int32 i = 0; i < MAX_MAPBLOCK; i++)
	{
		auto DMesh = CreateDefaultSubobject<UProceduralMeshComponent>(*FString::Printf(TEXT("Tesse%d"), i));
		//DMesh->SetMobility(EComponentMobility::Static);
		DMesh->SetCastShadow(false);
		DMesh->AttachToComponent(Root, FAttachmentTransformRules::KeepRelativeTransform);
		DMeshes.Add(DMesh);
	}
	DMeshBound = CreateDefaultSubobject<UProceduralMeshComponent>(TEXT("TesseBound"));
	//DMesh->SetMobility(EComponentMobility::Static);
	DMeshBound->SetCastShadow(false);
	DMeshBound->AttachToComponent(Root, FAttachmentTransformRules::KeepRelativeTransform);
}

// Called when the game starts or when spawned
void AWaterMeshTesseActor::BeginPlay()
{
	Super::BeginPlay();
	MapBlockChanged();
}

// Called every frame
void AWaterMeshTesseActor::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);
	if (TesseUpdateInterval <= 0)
		return;

	TesseUpdateTimer += DeltaTime;
	if (TesseUpdateTimer >= TesseUpdateInterval)
	{
		TesseUpdateTimer = 0;
		FVector CameraPos;
		if (AAzureEntryPoint::Instance)
		{
			UCameraComponent* pGameCamera = AAzureEntryPoint::Instance->GetMainCameraComponent();
		}
		else
			CameraPos = GetWorld()->GetFirstPlayerController()->PlayerCameraManager->GetCameraLocation();
		UpdateTesseMesh(CameraPos);
	}
}

#define NEXT(i) (((i)+1)%3)
#define PREV(i) (((i)+2)%3)

void AWaterMeshTesseActor::AddMapBlock(int x, int y, UStaticMesh* StaticMesh)
{
	for (int i = 0; i < MapBlockRawData.Num(); i++)
	{
		if (MapBlockRawData[i].PosX == x && MapBlockRawData[i].PosY == y)
		{
			return;
		}
	}

	FBox2D BoxBlock;
	BoxBlock.Min = FVector2D(x*MapBlockSize, y*MapBlockSize);
	BoxBlock.Max = FVector2D((x + 1)*MapBlockSize, (y + 1)*MapBlockSize);
	if (MapBlockRawData.Num() == 0)
	{
		MapBlockBox2D = BoxBlock;
	}
	else
	{
		MapBlockBox2D += BoxBlock;
	}

	FMapBlock mb(x, y);

	int NumLODs = StaticMesh->RenderData->LODResources.Num();
	if (NumLODs < 1)
	{
		UE_LOG(LogAzure, Error, TEXT("AWaterMeshTesseActor mesh no data"));
		return;
	}

	const FStaticMeshLODResources& LODResource = StaticMesh->RenderData->LODResources[0];

	for (int32 VertIndex = 0; VertIndex < LODResource.GetNumVertices(); ++VertIndex)
	{
		mb.OrigVertexes.Add(SDVertex(LODResource.VertexBuffers.PositionVertexBuffer.VertexPosition((uint32)VertIndex)));
	}

	const FIndexArrayView IndexArrayView = LODResource.IndexBuffer.GetArrayView();
	const FStaticMeshVertexBuffer& StaticMeshVertexBuffer = LODResource.VertexBuffers.StaticMeshVertexBuffer;
	const int32 NumTexCoords = StaticMeshVertexBuffer.GetNumTexCoords();
	const int32 NumSections = LODResource.Sections.Num();

	for (int32 SectionIndex = 0; SectionIndex < NumSections; SectionIndex++)
	{
		const FStaticMeshSection& StaticMeshSection = LODResource.Sections[SectionIndex];

		const int32 NumIndices = StaticMeshSection.NumTriangles * 3;
		for (int32 IndexIndex = 0; IndexIndex < NumIndices / 3; IndexIndex++)
		{
			SDFace sdf;
			for (int32 FaceIndex = 0; FaceIndex < 3; FaceIndex++)
			{
				int Index = IndexArrayView[StaticMeshSection.FirstIndex + IndexIndex * 3 + FaceIndex];;
				sdf.index[FaceIndex] = Index;
				if (NumTexCoords > 0)
					mb.OrigVertexes[Index].Uv0 = StaticMeshVertexBuffer.GetVertexUV(Index, 0);
				if (NumTexCoords > 1)
					mb.OrigVertexes[Index].Uv1 = StaticMeshVertexBuffer.GetVertexUV(Index, 1);
				if (LODResource.VertexBuffers.ColorVertexBuffer.IsInitialized())
					mb.OrigVertexes[Index].C = LODResource.VertexBuffers.ColorVertexBuffer.VertexColor(Index);
			}
			mb.OrigFaces.Add(sdf);
		}
	}

	mb.Material = StaticMesh->GetMaterial(0);

	MapBlockRawData.Add(mb);
}

void AWaterMeshTesseActor::RemoveMapBlock(int x, int y)
{
	for (int i = 0; i < MapBlockRawData.Num(); i++)
	{
		if (MapBlockRawData[i].PosX == x && MapBlockRawData[i].PosY == y)
		{
			MapBlockRawData.RemoveAt(i);
			break;
		}
	}
}

void AWaterMeshTesseActor::TesseDataDirty()
{
	CameraPos.X = CameraPos.X + 99999.0f;
	TesseUpdateTimer = TesseUpdateInterval;
}

void AWaterMeshTesseActor::MapBlockChanged()
{
	MapBlockRawData.Empty();

#if UE_EDITOR
	for (TActorIterator<AOceanWaterMesh> ActorIt(GetWorld()); ActorIt; ++ActorIt)
	{
		AOceanWaterMesh* owm = *ActorIt;
		AddMapBlock(owm->x, owm->y, owm->BlockMesh);
	}
#else
	for (auto owm : AOceanWaterMesh::GetAllInstances())
	{
		AddMapBlock(owm->x, owm->y, owm->BlockMesh);
	}
#endif

	for (int i = 0; i < MapBlockRawData.Num(); i++)
	{
		MapBlockRawData[i].DMesh = DMeshes[i];
	}
	for (int i = MapBlockRawData.Num(); i < MAX_MAPBLOCK; i++)
	{
		DMeshes[i]->ClearAllMeshSections();
	}

	TesseDataDirty();
}

int AWaterMeshTesseActor::PointTesseLevel(FVector PosCenter, FVector PosTest)
{
	int TesseLevel = TesseParam.Num();
	float dist = (PosCenter - PosTest).SizeSquared2D();
	for (int i = 0; i < TesseParam.Num(); i++)
	{
		if (dist < TesseParam[i].DistCamera*TesseParam[i].DistCamera)
		{
			TesseLevel = i;
			break;
		}
	}
	return TesseLevel;
}

bool AWaterMeshTesseActor::NeedTesse(const SDVertex& v0, const SDVertex& v1)
{
	if (v0.TesseLevel >= TesseParam.Num() && v1.TesseLevel >= TesseParam.Num())
		return false;
	int tl = FMath::Min(v0.TesseLevel, v1.TesseLevel);
	float dist = (v0.P - v1.P).SizeSquared2D();
	return dist > TesseParam[tl].TesseMinEdge*TesseParam[tl].TesseMinEdge;
}

void AWaterMeshTesseActor::Tessellate(FVector pos)
{
	CameraPos = pos;

	for (int ii = 0; ii < MapBlockRawData.Num(); ii++)
	{
		MapBlockRawData[ii].TesseVertexes = MapBlockRawData[ii].OrigVertexes;
		MapBlockRawData[ii].TesseFaces = MapBlockRawData[ii].OrigFaces;
	}

	bool TesseTri = true;
	for (int ii = 0; ii < MapBlockRawData.Num(); ii++)
	{
		FVector TessePos = pos - MapBlockRawData[ii].Pos;
		// Init
		int counterSafe = 0;
		TesseTri = true;
		while (TesseTri && counterSafe++ < IterCountMax)
		{
			TesseTri = false;
			TArray<SDVertex> newVertices = MapBlockRawData[ii].TesseVertexes;
			TArray<SDFace> newFaces = MapBlockRawData[ii].TesseFaces;

			for (int i = 0; i < newVertices.Num(); i++)
			{
				newVertices[i].TesseLevel = PointTesseLevel(TessePos, newVertices[i].P);
			}
			for (int i = 0; i < newFaces.Num(); i++)
			{
				newFaces[i].ClearChildren();
			}

			// �¼ӽڵ�ı�
			TMap<int, int> edgeVerts;
			for (int i = 0; i < newFaces.Num(); i++)
			{
				SDFace& face = newFaces[i];
				// �ж��Ƿ���ҪTesse
				bool IsTesse = false;
				if (newVertices[face.index[0]].edge && newVertices[face.index[1]].edge)
					IsTesse = NeedTesse(newVertices[face.index[0]], newVertices[face.index[1]]);
				else if (newVertices[face.index[1]].edge && newVertices[face.index[2]].edge)
					IsTesse = NeedTesse(newVertices[face.index[1]], newVertices[face.index[2]]);
				else if (newVertices[face.index[0]].edge && newVertices[face.index[2]].edge)
					IsTesse = NeedTesse(newVertices[face.index[0]], newVertices[face.index[2]]);
				else
					IsTesse = NeedTesse(newVertices[face.index[0]], newVertices[face.index[1]]) ||
					NeedTesse(newVertices[face.index[1]], newVertices[face.index[2]]) ||
					NeedTesse(newVertices[face.index[2]], newVertices[face.index[0]]);
				if (IsTesse)
				{
					// ���Ӷ���
					for (int k = 0; k < 3; k++)
					{
						int index1 = face.index[k];
						int index2 = face.index[NEXT(k)];
						if (index1 > index2)
						{
							int temp = index1;
							index1 = index2;
							index2 = temp;
						}
						int edgeKey = (index1 << 16) + index2;
						if (!edgeVerts.Contains(edgeKey))
						{
							SDVertex newVert;
							newVert.P = (newVertices[index1].P + newVertices[index2].P) / 2;
							FColor newColor((newVertices[index1].C.R + newVertices[index2].C.R) / 2,
								(newVertices[index1].C.G + newVertices[index2].C.G) / 2,
								(newVertices[index1].C.B + newVertices[index2].C.B) / 2,
								255
							);
							newVert.C = newColor;
							newVert.Uv0 = (newVertices[index1].Uv0 + newVertices[index2].Uv0) / 2;
							newVert.Uv1 = (newVertices[index1].Uv1 + newVertices[index2].Uv1) / 2;
							newVert.edge = newVertices[index1].edge && newVertices[index2].edge;
							newVertices.Add(newVert);
							edgeVerts.Add(edgeKey, newVertices.Num() - 1);
						}
					}
					for (int k = 0; k < 4; k++)
					{
						face.children[k] = new SDFace();
					}
					// ��������
					for (int k = 0; k < 3; k++)
					{
						int index1 = face.index[k];
						int index2 = face.index[NEXT(k)];
						if (index1 > index2)
						{
							int temp = index1;
							index1 = index2;
							index2 = temp;
						}
						face.children[k]->index[k] = face.index[k];
						int vertIndex = edgeVerts[(index1 << 16) + index2];
						face.children[k]->index[NEXT(k)] = vertIndex;
						face.children[NEXT(k)]->index[k] = vertIndex;
						face.children[3]->index[k] = vertIndex;
					}
					TesseTri = true;
				}
			}

			if (!TesseTri)
				break;
			// �����ٽ��Ľӷ�
			// �������Ѿ�ϸ���������ΰ����淽ʽϸ��
			for (int i = 0; i < newFaces.Num(); i++)
			{
				SDFace& face = newFaces[i];
				if (face.children[0] != nullptr)
					continue;
				int TesseVertNum = 0;
				int TesseVertIndex = -1;
				int newVertIndex = -1;
				for (int k = 0; k < 3; k++)
				{
					int index1 = face.index[k];
					int index2 = face.index[NEXT(k)];
					if (index1 > index2)
					{
						int temp = index1;
						index1 = index2;
						index2 = temp;
					}
					if (edgeVerts.Find((index1 << 16) + index2))
					{
						TesseVertNum++;
						TesseVertIndex = k;
						newVertIndex = edgeVerts[(index1 << 16) + index2];
					}
				}
				if (TesseVertNum == 3)	// error
				{
					UE_LOG(LogAzure, Error, TEXT("Tessellate error1: TesseVertNum == 3"));
				}
				else if (TesseVertNum == 2) //Tesse Face
				{
					// ���Ӷ���
					for (int k = 0; k < 3; k++)
					{
						int index1 = face.index[k];
						int index2 = face.index[NEXT(k)];
						if (index1 > index2)
						{
							int temp = index1;
							index1 = index2;
							index2 = temp;
						}
						int edgeKey = (index1 << 16) + index2;
						if (!edgeVerts.Contains(edgeKey))
						{
							SDVertex newVert;
							newVert.P = (newVertices[index1].P + newVertices[index2].P) / 2;
							FColor newColor((newVertices[index1].C.R + newVertices[index2].C.R) / 2,
								(newVertices[index1].C.G + newVertices[index2].C.G) / 2,
								(newVertices[index1].C.B + newVertices[index2].C.B) / 2,
								255
							);
							newVert.C = newColor;
							newVert.Uv0 = (newVertices[index1].Uv0 + newVertices[index2].Uv0) / 2;
							newVert.Uv1 = (newVertices[index1].Uv1 + newVertices[index2].Uv1) / 2;
							newVertices.Add(newVert);
							edgeVerts.Add(edgeKey, newVertices.Num() - 1);
						}
					}
					for (int k = 0; k < 4; k++)
					{
						face.children[k] = new SDFace();
					}
					// ��������
					for (int k = 0; k < 3; k++)
					{
						int index1 = face.index[k];
						int index2 = face.index[NEXT(k)];
						if (index1 > index2)
						{
							int temp = index1;
							index1 = index2;
							index2 = temp;
						}
						face.children[k]->index[k] = face.index[k];
						int vertIndex = edgeVerts[(index1 << 16) + index2];
						face.children[k]->index[NEXT(k)] = vertIndex;
						face.children[NEXT(k)]->index[k] = vertIndex;
						face.children[3]->index[k] = vertIndex;
					}
				}
			}

			// һ����ϸ����������ϸ����2��������
			for (int i = 0; i < newFaces.Num(); i++)
			{
				SDFace& face = newFaces[i];
				if (face.children[0] != nullptr)
					continue;
				int TesseVertNum = 0;
				int TesseVertIndex = -1;
				int newVertIndex = -1;
				for (int k = 0; k < 3; k++)
				{
					int index1 = face.index[k];
					int index2 = face.index[NEXT(k)];
					if (index1 > index2)
					{
						int temp = index1;
						index1 = index2;
						index2 = temp;
					}
					if (edgeVerts.Find((index1 << 16) + index2))
					{
						TesseVertNum++;
						TesseVertIndex = k;
						newVertIndex = edgeVerts[(index1 << 16) + index2];
					}
				}
				if (TesseVertNum == 3)	// error
				{
					UE_LOG(LogAzure, Error, TEXT("Tessellate error2: TesseVertNum == 3"));
				}
				else if (TesseVertNum == 2) //Tesse Face
				{
					UE_LOG(LogAzure, Error, TEXT("Tessellate error3: TesseVertNum == 2"));
				}
				else if (TesseVertNum == 1) // �����ӷ�
				{
					face.children[0] = new SDFace();
					face.children[0]->index[0] = face.index[PREV(TesseVertIndex)];
					face.children[0]->index[1] = face.index[TesseVertIndex];
					face.children[0]->index[2] = newVertIndex;

					face.children[1] = new SDFace();
					face.children[1]->index[0] = newVertIndex;
					face.children[1]->index[1] = face.index[NEXT(TesseVertIndex)];
					face.children[1]->index[2] = face.index[PREV(TesseVertIndex)];
				}
			}

			MapBlockRawData[ii].TesseVertexes = newVertices;
			MapBlockRawData[ii].TesseFaces.Empty();
			for (int i = 0; i < newFaces.Num(); i++)
			{
				SDFace& face = newFaces[i];
				if (face.children[0])
				{
					MapBlockRawData[ii].TesseFaces.Add(*face.children[0]);
					MapBlockRawData[ii].TesseFaces.Add(*face.children[1]);
					if (face.children[2])
					{
						MapBlockRawData[ii].TesseFaces.Add(*face.children[2]);
						MapBlockRawData[ii].TesseFaces.Add(*face.children[3]);
					}
					face.ClearChildren();
				}
				else
					MapBlockRawData[ii].TesseFaces.Add(face);
			}
		}
	}

	// ����proceduremesh
	for (int i = 0; i < MapBlockRawData.Num(); i++)
	{
		FMapBlock& mb = MapBlockRawData[i];

		TArray<FVector> Vertices;
		for (int j = 0; j < mb.TesseVertexes.Num(); j++)
		{
			Vertices.Add(mb.TesseVertexes[j].P);
		}

		TArray<int32> Triangles;
		TArray<FColor> Colors;
		TArray<FVector2D> Uv0;
		TArray<FVector2D> Uv1;
		for (int j = 0; j < mb.TesseFaces.Num(); j++)
		{
			for (int k = 0; k < 3; k++)
			{
				int index = mb.TesseFaces[j].index[k];
				Triangles.Add(index);
				Colors.Add(mb.TesseVertexes[index].C);
				Uv0.Add(mb.TesseVertexes[index].Uv0);
				Uv1.Add(mb.TesseVertexes[index].Uv1);
			}
		}

		TArray<FVector> Rnormals;
		TArray<FProcMeshTangent> Rtangs;
		TArray<FVector2D> EmptyArray;
		mb.DMesh->SetRelativeLocation(mb.Pos);
		mb.DMesh->CreateMeshSection(0, Vertices, Triangles, Rnormals,
			Uv0, Uv1, EmptyArray, EmptyArray, Colors, Rtangs, false);
		if(mb.Material.IsValid())
			mb.DMesh->SetMaterial(0, mb.Material.Get());
		mb.DMesh->SetCastShadow(false);
	}

	// ���ɱ߽�����
	TArray<FVector> VerticesLeft;
	TArray<FVector> VerticesUp;
	TArray<FVector> VerticesRight;
	TArray<FVector> VerticesDown;
	float TestLeft = MapBlockBox2D.Min.X + 0.1f;
	float TestUp = MapBlockBox2D.Min.Y + 0.1f;
	float TestRight = MapBlockBox2D.Max.X - 0.1f;
	float TestDown = MapBlockBox2D.Max.Y - 0.1f;
	bool LUCorner = false;
	bool RUCorner = false;
	bool LDCorner = false;
	bool RDCorner = false;
	for (int i = 0; i < MapBlockRawData.Num(); i++)
	{
		for (int j = 0; j < MapBlockRawData[i].TesseVertexes.Num(); j++)
		{
			FVector Pos = MapBlockRawData[i].TesseVertexes[j].P + MapBlockRawData[i].Pos;
			if (Pos.X < TestLeft)
			{
				VerticesLeft.Add(Pos);
				if (Pos.Y < TestUp)
					LUCorner = true;
				else if (Pos.Y > TestDown)
					LDCorner = true;
			}
			if (Pos.X > TestRight)
			{
				VerticesRight.Add(Pos);
				if (Pos.Y < TestUp)
					RUCorner = true;
				else if (Pos.Y > TestDown)
					RDCorner = true;
			}
			if (Pos.Y < TestUp)
				VerticesUp.Add(Pos);
			if (Pos.Y > TestDown)
				VerticesDown.Add(Pos);
		}
	}

	TArray<FVector> Vertices;
	TArray<int32> Triangles;
	TArray<FColor> Colors;
	TArray<FVector2D> Uv0;
	TArray<FVector2D> Uv1;
	int IndexStart = 0;

	if (VerticesLeft.Num() > 0)
	{
		IndexStart = Vertices.Num();
		VerticesLeft.Sort([&](const FVector& A, const FVector& B)
		{
			return A.Y < B.Y;
		});
		FVector Pos1(MapBlockBox2D.Min.X - BorderSize, MapBlockBox2D.Min.Y, 0);
		FVector Pos2(MapBlockBox2D.Min.X - BorderSize, MapBlockBox2D.Max.Y, 0);
		Vertices.Add(Pos2);
		Vertices.Add(Pos1);
		Triangles.Add(IndexStart + 0);
		Triangles.Add(IndexStart + 1);
		Triangles.Add(IndexStart + 2);
		Vertices.Add(VerticesLeft[0]);
		for (int i = 1; i < VerticesLeft.Num(); i++)
		{
			Vertices.Add(VerticesLeft[i]);
			Triangles.Add(IndexStart + 1);
			Triangles.Add(IndexStart + 2 + i);
			Triangles.Add(IndexStart + 1 + i);
		}
	}

	if (VerticesRight.Num() > 0)
	{
		IndexStart = Vertices.Num();
		VerticesRight.Sort([&](const FVector& A, const FVector& B)
		{
			return A.Y < B.Y;
		});
		FVector Pos1(MapBlockBox2D.Max.X + BorderSize, MapBlockBox2D.Min.Y, 0);
		FVector Pos2(MapBlockBox2D.Max.X + BorderSize, MapBlockBox2D.Max.Y, 0);
		Vertices.Add(Pos1);
		Vertices.Add(Pos2);
		Triangles.Add(IndexStart + 1);
		Triangles.Add(IndexStart + 0);
		Triangles.Add(IndexStart + 2);
		Vertices.Add(VerticesRight[0]);
		for (int i = 1; i < VerticesRight.Num(); i++)
		{
			Vertices.Add(VerticesRight[i]);
			Triangles.Add(IndexStart + 1 + i);
			Triangles.Add(IndexStart + 2 + i);
			Triangles.Add(IndexStart + 1);
		}
	}

	if (VerticesUp.Num() > 0)
	{
		IndexStart = Vertices.Num();
		VerticesUp.Sort([&](const FVector& A, const FVector& B)
		{
			return A.X < B.X;
		});
		FVector Pos1(MapBlockBox2D.Min.X, MapBlockBox2D.Min.Y - BorderSize, 0);
		FVector Pos2(MapBlockBox2D.Max.X, MapBlockBox2D.Min.Y - BorderSize, 0);
		Vertices.Add(Pos1);
		Vertices.Add(Pos2);
		Triangles.Add(IndexStart + 2);
		Triangles.Add(IndexStart + 1);
		Triangles.Add(IndexStart + 0);
		Vertices.Add(VerticesUp[0]);
		for (int i = 1; i < VerticesUp.Num(); i++)
		{
			Vertices.Add(VerticesUp[i]);
			Triangles.Add(IndexStart + 1 + i);
			Triangles.Add(IndexStart + 2 + i);
			Triangles.Add(IndexStart + 1);
		}
	}

	if (VerticesDown.Num() > 0)
	{
		IndexStart = Vertices.Num();
		VerticesDown.Sort([&](const FVector& A, const FVector& B)
		{
			return A.X < B.X;
		});
		FVector Pos1(MapBlockBox2D.Min.X, MapBlockBox2D.Max.Y + BorderSize, 0);
		FVector Pos2(MapBlockBox2D.Max.X, MapBlockBox2D.Max.Y + BorderSize, 0);
		Vertices.Add(Pos1);
		Vertices.Add(Pos2);
		Triangles.Add(IndexStart + 0);
		Triangles.Add(IndexStart + 1);
		Triangles.Add(IndexStart + 2);
		Vertices.Add(VerticesDown[0]);
		for (int i = 1; i < VerticesDown.Num(); i++)
		{
			Vertices.Add(VerticesDown[i]);
			Triangles.Add(IndexStart + 1);
			Triangles.Add(IndexStart + 2 + i);
			Triangles.Add(IndexStart + 1 + i);
		}
	}
	if (LUCorner)
	{
		IndexStart = Vertices.Num();
		Vertices.Add(FVector(MapBlockBox2D.Min.X - BorderSize, MapBlockBox2D.Min.Y - BorderSize, 0));
		Vertices.Add(FVector(MapBlockBox2D.Min.X, MapBlockBox2D.Min.Y - BorderSize, 0));
		Vertices.Add(FVector(MapBlockBox2D.Min.X - BorderSize, MapBlockBox2D.Min.Y, 0));
		Vertices.Add(FVector(MapBlockBox2D.Min.X, MapBlockBox2D.Min.Y, 0));
		Triangles.Add(IndexStart + 0);
		Triangles.Add(IndexStart + 2);
		Triangles.Add(IndexStart + 1);
		Triangles.Add(IndexStart + 1);
		Triangles.Add(IndexStart + 2);
		Triangles.Add(IndexStart + 3);
	}
	if (RUCorner)
	{
		IndexStart = Vertices.Num();
		Vertices.Add(FVector(MapBlockBox2D.Max.X, MapBlockBox2D.Min.Y - BorderSize, 0));
		Vertices.Add(FVector(MapBlockBox2D.Max.X + BorderSize, MapBlockBox2D.Min.Y - BorderSize, 0));
		Vertices.Add(FVector(MapBlockBox2D.Max.X, MapBlockBox2D.Min.Y, 0));
		Vertices.Add(FVector(MapBlockBox2D.Max.X + BorderSize, MapBlockBox2D.Min.Y, 0));
		Triangles.Add(IndexStart + 0);
		Triangles.Add(IndexStart + 2);
		Triangles.Add(IndexStart + 1);
		Triangles.Add(IndexStart + 1);
		Triangles.Add(IndexStart + 2);
		Triangles.Add(IndexStart + 3);
	}
	if (LDCorner)
	{
		IndexStart = Vertices.Num();
		Vertices.Add(FVector(MapBlockBox2D.Min.X - BorderSize, MapBlockBox2D.Max.Y, 0));
		Vertices.Add(FVector(MapBlockBox2D.Min.X, MapBlockBox2D.Max.Y, 0));
		Vertices.Add(FVector(MapBlockBox2D.Min.X - BorderSize, MapBlockBox2D.Max.Y + BorderSize, 0));
		Vertices.Add(FVector(MapBlockBox2D.Min.X, MapBlockBox2D.Max.Y + BorderSize, 0));
		Triangles.Add(IndexStart + 0);
		Triangles.Add(IndexStart + 2);
		Triangles.Add(IndexStart + 1);
		Triangles.Add(IndexStart + 1);
		Triangles.Add(IndexStart + 2);
		Triangles.Add(IndexStart + 3);
	}
	if (RDCorner)
	{
		IndexStart = Vertices.Num();
		Vertices.Add(FVector(MapBlockBox2D.Max.X, MapBlockBox2D.Max.Y, 0));
		Vertices.Add(FVector(MapBlockBox2D.Max.X + BorderSize, MapBlockBox2D.Max.Y, 0));
		Vertices.Add(FVector(MapBlockBox2D.Max.X, MapBlockBox2D.Max.Y + BorderSize, 0));
		Vertices.Add(FVector(MapBlockBox2D.Max.X + BorderSize, MapBlockBox2D.Max.Y + BorderSize, 0));
		Triangles.Add(IndexStart + 0);
		Triangles.Add(IndexStart + 2);
		Triangles.Add(IndexStart + 1);
		Triangles.Add(IndexStart + 1);
		Triangles.Add(IndexStart + 2);
		Triangles.Add(IndexStart + 3);
	}

	TArray<FVector> Rnormals;
	TArray<FProcMeshTangent> Rtangs;
	TArray<FVector2D> EmptyArray;
	//DMeshBound->SetRelativeLocation(mb.Pos);
	DMeshBound->CreateMeshSection(0, Vertices, Triangles, Rnormals,
		Uv0, Uv1, EmptyArray, EmptyArray, Colors, Rtangs, false);
	if (MaterialBound)
		DMeshBound->SetMaterial(0, MaterialBound);
	DMeshBound->SetCastShadow(false);
}

int AWaterMeshTesseActor::UpdateTesseMesh(FVector pos)
{
	FVector VecDelta = CameraPos - pos;	
	if (VecDelta.SizeSquared2D() < TesseDistance*TesseDistance)
	{
		return 0;
	}

	UE_LOG(LogAzure, Warning, TEXT("UpdateTesseMesh before: %lf"), FPlatformTime::Seconds());
	Tessellate(pos);
	UE_LOG(LogAzure, Warning, TEXT("UpdateTesseMesh after: %lf"), FPlatformTime::Seconds());
	//DMesh->SetMobility(EComponentMobility::Movable);
	MarkComponentsRenderStateDirty();
	return 0;
}