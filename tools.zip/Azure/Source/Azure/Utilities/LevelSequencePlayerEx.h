// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "LevelSequencePlayer.h"
#include "LevelSequencePlayerEx.generated.h"

/**
 * 
 */
UCLASS()
class AZURE_API ULevelSequencePlayerEx : public ULevelSequencePlayer
{
	GENERATED_BODY()
	
public:

	ULevelSequencePlayerEx(const FObjectInitializer&);

	void UpdateOffset(const float DeltaSeconds);

	virtual void OnStartedPlaying() override;
	virtual void OnPaused() override;
	virtual void OnStopped() override;

	virtual bool GetTransformOffset(FVector &translation, FRotator &rotation);

	bool GetTransformOrigin(FTransform &TransformOrigin);
	//virtual UObject* GetPlaybackContext() const override;

	void SetTransformOffset(FVector &translation, FRotator &rotation);
	UFUNCTION()
	void SetTransformOffsetFollowObj(AActor *pActor);
	void SetEvaluating(bool b) { bIsEvaluating = b; }
	bool GetEvaluating() {  return bIsEvaluating; }
	virtual FMovieSceneRootEvaluationTemplateInstance& GetEvaluationTemplate() override { return RootTemplateInstance; }

	UFUNCTION()
	int32 GetCurrentFrameTime();

	UFUNCTION()
	float GetCurrentTimeAsSeconds();

	UFUNCTION()
	float TranslateFrameToSeconds(int32 frameNumber);

	FFrameTime GetNewTime();

	UObject* SpawnObjectByTrack(const FGuid trackGUID, UMovieSceneSequence* Sequence, const FMovieSceneSequenceID sequenceID);

	void DestroySpawnObjectByTrack(UObject *Obj);
public:
	// Ϊ��
	using UMovieSceneSequencePlayer::GetSpawnRegister;


protected:
	TWeakObjectPtr<AActor> TranslationOffsetFollowObj;
	FVector TranslationOffset;
	FRotator RotationOffset;
	bool bEnableOffset = false;
	TWeakObjectPtr<UObject> LastCameraObject = nullptr;
};
