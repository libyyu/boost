﻿// Fill out your copyright notice in the Description page of Project Settings.

#include "ECTimerList.h"
#include "Azure.h"
#include "AzureEntryPoint.h"
#include "wLua/LuaInterface.h"
#include <algorithm>

int ECTimerList::_uniqueid = 1;
int ECTimerList::total_count = 0;
TMap<ECTimerList*, TWeakObjectPtr<AActor>> ECTimerList::s_instanceMap;

static bool timer_comparator(const ECTimerList::Timer &lhs, const ECTimerList::Timer &rhs) {
	double lhs_end_time = (lhs.begin_time + lhs.ttl);
	double rhs_end_time = (rhs.begin_time + rhs.ttl);
	double diff_time = lhs_end_time - rhs_end_time;
	if (diff_time >= 0.000001) { //控制精度
		return false;
	}
	else if (diff_time <= -0.000001) {
		return true;
	}
	return lhs.id < rhs.id;
}
#if STATS
void ECTimerList::Timer::CreateStatID()
{
	if (!AAzureEntryPoint::Instance)
		return;

	wLua::Lua* wlua = AAzureEntryPoint::Instance->GetWLua();
	lua_State_Wrapper L = wlua->GetL();
	lua_rawgeti(L, LUA_REGISTRYINDEX, callback); // callback

	lua_Debug ar;
	lua_getinfo(L, ">S", &ar);
	FString StatName= FString::Printf(TEXT("AzureTimer%s:%d"), UTF8_TO_TCHAR(ar.source), ar.linedefined);

	StatID = FDynamicStats::CreateStatId<FStatGroup_STATGROUP_AzureGroups>(StatName);
}
#endif

ECTimerList::ECTimerList() : m_bTick(false)
{
}

ECTimerList::~ECTimerList()
{
	UnregisterTimerList(this);
}

//	-2: found but reach maxDuration and Removed
//	-1: ticking
//	0: not found
//	> 0: found and delayed
int ECTimerList::DelayTimer(int id, float ttl, float maxDurationToRemove)
{
	if (m_bTick)
		return -1; // Be in Timer self ticking..

	if (!AAzureEntryPoint::Instance)
		return -1;

	lua_State_Wrapper L = AAzureEntryPoint::Instance->GetWLua()->GetL();
	auto curTime = FPlatformTime::Seconds();

	for (size_t i = 0; i < m_List.size(); i++)
	{
		Timer& tm = m_List[i];

		if (tm.id == id)
		{
			if (maxDurationToRemove >= 0)
			{
				if (tm.total_played > 0 && tm.total_played >= maxDurationToRemove)
				{
					wLua::lua_registry_handle::wlua_unref(L, LUA_REGISTRYINDEX, tm.callback);
					wLua::lua_registry_handle::wlua_unref(L, LUA_REGISTRYINDEX, tm.cbparam);
					m_List.erase(m_List.begin() + i);
					total_count--;
					return -2; // found but reach maxDuration and Removed
				}

				if (tm.total_played + ttl > maxDurationToRemove)
					ttl = maxDurationToRemove - tm.total_played;
			}

			tm.ttl = ttl;
			return id; // found and delayed
		}
	}

	return 0; // not found
}

bool ECTimerList::IsRemoved(int id)
{
	for (size_t i = 0; i < m_TempDelList.size(); i++)
	{
		if (m_TempDelList[i] == id)
		{
			return true;
		}
	}

	return false;
}

int ECTimerList::RemoveTimer(int id)
{
	if (m_bTick)
	{
		m_TempDelList.push_back(id);
		return 1;
	}


	if (!AAzureEntryPoint::Instance)
		return -1;

	lua_State_Wrapper L = AAzureEntryPoint::Instance->GetWLua()->GetL();

	for (size_t i = 0; i < m_List.size(); i++)
	{
		Timer& tm = m_List[i];

		if (tm.id == id)
		{
			wLua::lua_registry_handle::wlua_unref(L, LUA_REGISTRYINDEX, tm.callback);
			wLua::lua_registry_handle::wlua_unref(L, LUA_REGISTRYINDEX, tm.cbparam);
			m_List.erase(m_List.begin() + i);
			total_count--;
			return 0;
		}
	}

	return -1;
}

//fOrgDeltaTime的值在修改TimeDilation的当前帧不准确，弃用
void ECTimerList::Tick(float DeltaTime, float fOrgDeltaTime)
{
	if (m_List.size() > 0)
	{
		m_bTick = true;

		auto curTime = FPlatformTime::Seconds();
		size_t i = 0;

		if (!AAzureEntryPoint::Instance)
			return;

		wLua::Lua* wlua = AAzureEntryPoint::Instance->GetWLua();
		lua_State_Wrapper L = wlua->GetL();

		m_TickingList.clear();
		while (i < m_List.size())
		{
			Timer& tm = m_List[i];

			if (!tm.bChangeWithTimeDilation) {
				tm.total_played = curTime - tm.begin_time;
			}
			else {
				tm.total_played += DeltaTime;
			}

			if (!IsRemoved(tm.id) && tm.total_played >= tm.ttl && tm.id < m_iLastFrameTimerId)
			{
				//移动到Tick队列
				m_TickingList.push_back(std::move(tm));
				m_List.erase(m_List.begin() + i);
			}
			else
			{
				i++;
			}
		}
		size_t iTimer = 0;
		if (m_TickingList.size() > 1) {
			//按到到达时间排序
			std::sort(m_TickingList.begin(), m_TickingList.end(), timer_comparator);
		}
		//执行Tick队列的Timer
		while (iTimer < m_TickingList.size())
		{
			Timer& tm = m_TickingList[iTimer];
			float oldTotal = tm.total_played;
			//需要重新判断避免在Timer中发生变化
			if (!IsRemoved(tm.id) && tm.total_played >= tm.ttl)
			{
				//	this timer end:
				float dtLeft = tm.total_played - tm.ttl; // calc here, otherwise tm.xxx may be changed after PCall

				lua_rawgeti(L, LUA_REGISTRYINDEX, tm.callback); // callback
				lua_pushvalue(L, -1);	//cb, cb

				if (!tm.cbparam.IsNoRef())
				{
					lua_rawgeti(L, LUA_REGISTRYINDEX, tm.cbparam); // callback, cbparam
				}
				else
					lua_pushnil(L);

				bool bRet;
				{
#if STATS
					FScopeCycleCounter CycleCounter(tm.StatID);
#endif
					bRet = wlua->PCallWithFunctionInfo(1, 0);	//-> cb, [err]
				}

				if (bRet)
				{
					lua_pop(L, 1);
				}
				else
				{
					lua_pushvalue(L, -2);
					FString info = wlua->GetFunctionInfo();
					FString errorInfo = FString::Printf(TEXT("@TimerFunc:%s@%s"), *info, UTF8_TO_TCHAR(lua_tostring(L, -1)));
					lua_pop(L, 2);
					UE_LOG(LogAzure, Error, TEXT("%s"), *errorInfo);
				}

				if (tm.bOnce)
				{
					//	只调用一次：
					wLua::lua_registry_handle::wlua_unref(L, LUA_REGISTRYINDEX, tm.callback);
					wLua::lua_registry_handle::wlua_unref(L, LUA_REGISTRYINDEX, tm.cbparam);
					//一处一次性Timer
					m_TickingList.erase(m_TickingList.begin() + iTimer);
					total_count--;
				}
				else
				{
					//	进入下次循环：

					//	tm.xxx 可能在PCall中改变了，此时不要设置dtLeft
					if (oldTotal == tm.total_played && dtLeft >= 0) {
						tm.total_played = dtLeft;
						tm.begin_time = curTime - dtLeft;
					}
					else {
						tm.total_played = 0;
						tm.begin_time = curTime;
					}
					iTimer++;
				}
			}
			else 
			{
				iTimer++;
			}
			
		}
	}

	m_bTick = false;
	m_iLastFrame = GFrameCounter;//记录当前帧号
	m_iLastFrameTimerId = _uniqueid;//记录当前的最大id

	if (m_TempList.size() > 0)
	{
		for (size_t n = 0; n < m_TempList.size(); ++n)
			m_List.push_back(std::move(m_TempList[n]));

		total_count += (int)m_TempList.size();
		m_TempList.clear();
	}
	//将Ticking中剩余的Timer回放到List
	if (m_TickingList.size() > 0)
	{
		for (size_t n = 0; n < m_TickingList.size(); ++n)
			m_List.push_back(std::move(m_TickingList[n]));
		m_TickingList.clear();
	}
	//检查运行过程中移除的Timer
	if (m_TempDelList.size() > 0)
	{
		for (size_t n = 0; n < m_TempDelList.size(); ++n)
		{
			int iRet = RemoveTimer(m_TempDelList[n]);
			assert(iRet != 1);
		}

		m_TempDelList.clear();
	}

}

void ECTimerList::Clear()
{
	if (m_List.size() > 0)
	{
		total_count -= (int)m_List.size();

		if (!AAzureEntryPoint::IsInit())
		{
			m_List.clear();
		}
		else
		{
			wLua::Lua* wlua = AAzureEntryPoint::Instance->GetWLua();
			lua_State_Wrapper L = wlua->GetL();

			for (size_t i = 0; i < m_List.size(); ++i)
			{
				wLua::lua_registry_handle::wlua_unref(L, LUA_REGISTRYINDEX, m_List[i].callback);
				wLua::lua_registry_handle::wlua_unref(L, LUA_REGISTRYINDEX, m_List[i].cbparam);
			}

			m_List.clear();
		}
	}
	m_TickingList.clear();
	m_TempList.clear();
	m_TempDelList.clear();
}

FString ECTimerList::GetDebugInfo(TWeakObjectPtr<AActor> pObj, TMap<FString, int>& callbackCountMap)
{
	wLua::Lua* wlua = AAzureEntryPoint::Instance ? AAzureEntryPoint::Instance->GetWLua() : nullptr;

	FString strBuilder;
	strBuilder += pObj.IsValid() ? pObj->GetName() : TEXT("Unknown");
	strBuilder += TEXT(": \n");

	for (Timer& timer : m_List)
	{
		FString callback = wlua ? wlua->GetRegistryFunctionInfo(timer.callback) : TEXT("");
		if (callbackCountMap.Contains(callback))
			callbackCountMap[callback]++;
		else
			callbackCountMap.Add(callback, 1);

		strBuilder += TEXT("  ");

		FString info = FString::Printf(TEXT("id: %d, ttl %f, total_played %f, once %s, cb: %s\n"),
			timer.id, timer.ttl, timer.total_played, timer.bOnce ? TEXT("true") : TEXT("false"), *callback);

		strBuilder += info;
	}

	return strBuilder;
}

FString ECTimerList::GetAllDebugInfo()
{
	FString strBuilder;
	TMap<FString, int> callbackCountMap;

	for (auto& item : s_instanceMap)
	{
		if (item.Value.IsValid())
			strBuilder += item.Key->GetDebugInfo(item.Value, callbackCountMap);
	}

	strBuilder += TEXT("------------------------------\n");
	strBuilder += TEXT("-- duplicated callbacks: \n");

	for (auto& item : callbackCountMap)
	{
		if (item.Value >= 2)
			strBuilder += FString::Printf(TEXT("  %s = %d\n"), *item.Key, item.Value);
	}

	return strBuilder;
}

void ECTimerList::RegisterTimerList(ECTimerList* timerList, AActor* pObj)
{
	s_instanceMap.Add(timerList, pObj);
}

void ECTimerList::UnregisterTimerList(ECTimerList* timerList)
{
	s_instanceMap.Remove(timerList);
}

FString ECTimerList::GetTimerListIDs()
{
	FString str = "--";
	for (size_t i = 0; i < m_List.size(); i++)
	{
		Timer& tm = m_List[i];

		str += FString::FromInt(tm.id);
		str += " ";
	}

	return str;
}