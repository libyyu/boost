// Fill out your copyright notice in the Description page of Project Settings.

#include "Azure.h"
#include "Engine.h"

IMPLEMENT_PRIMARY_GAME_MODULE( FDefaultGameModuleImpl, Azure, "Azure" );
DEFINE_LOG_CATEGORY(LogAzure);
