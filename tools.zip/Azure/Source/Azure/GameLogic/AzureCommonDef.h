#pragma once

#include "Math/Vector.h"
#include "Array.h"
#include "NameTypes.h"

namespace Azure
{
	static FName s_szBPFieldName_TargetSpeed = "targetspeed";
	static FName s_szBPFieldName_TargetDir = "targetdirection";
	static FName s_szBPFieldName_ClimbMoveDegree = "ClimbMoveDegree";
	static FName s_szBPFieldName_DivePitch = "divepitch";

	typedef TArray<FVector> VecPoint;

	typedef TArray<float> ArrayFloat;

	struct SPRINGPHY_PARAM
	{
		// Physics coefficient which controls the influence of the camera's position
		// over the spring force. The stiffer the spring, the closer it will stay to
		// the chased object.
		float		fStiffness;

		// Physics coefficient which approximates internal friction of the spring.
		// Sufficient damping will prevent the spring from oscillating infinitely.
		float		fDamping;

		// Mass of the camera body. Heaver objects require stiffer springs with less
		// damping to move at the same rate as lighter objects.
		float		fMass;
	};

	struct SPRINTPHY_SPEED
	{
		SPRINTPHY_SPEED()
		{
			SetDefaultSpringParam();
		}

		void SetDefaultSpringParam();

		void Reset()
		{
			m_fDesiredSpeed = 0;
			m_fAcceleration = 0;
			m_fVelocity = 0;
		}

		void InterpSpeed(float& fSpeed, float fDestSpeed, float fDeltaTime);

		float m_fDesiredSpeed = 0;	//	Desired speed
		float m_fAcceleration = 0;	//	Acceleration
		float m_fVelocity = 0;		//	Velocity

		SPRINGPHY_PARAM param;		//	Spring param
	};

	struct SPRINTPHY_POS
	{
		SPRINTPHY_POS()
			: vDesiredPos(ForceInit)
			, vAcceleration(ForceInit)
			, vVelocity(ForceInit)
			, bEnabled(true)
		{
			SetDefaultSpringParam();
		}

		void SetDefaultSpringParam();

		void Reset()
		{
			vDesiredPos.Set(0, 0, 0);
			vAcceleration.Set(0, 0, 0);
			vVelocity.Set(0, 0, 0);
		}

		void InterpPos(FVector& vCurPos, const FVector& vDestPos, float fDeltaTime, float* pfOutSpeed = nullptr, const float* pfMaxSpeed = nullptr);

		FVector	vDesiredPos;	//	Desired position
		FVector	vAcceleration;	//	Acceleration
		FVector	vVelocity;		//	Velocity

		Azure::SPRINGPHY_PARAM param; //	Spring param

		bool bEnabled;
	};

};
