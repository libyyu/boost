#pragma once

#include "AzureCommonDef.h"

namespace Azure
{
	void SPRINTPHY_SPEED::SetDefaultSpringParam()
	{
		param.fMass = 1.f;

		param.fStiffness = 50.f;
		param.fDamping = 20.f;
	}

	void SPRINTPHY_SPEED::InterpSpeed(float& fSpeed, float fDestSpeed, float dt)
	{
		m_fDesiredSpeed = fDestSpeed;

		float stretch = m_fDesiredSpeed - fSpeed;
		float fMagStretch = FMath::Abs(stretch);
		float vDirStretch = stretch > 0 ? 1 : -1;

		float force = param.fStiffness * stretch - param.fDamping * m_fVelocity;
		float vDirForce = force > 0 ? 1 : -1;
		float fMagForce = FMath::Abs(force);

		//AString strDbg;

		if (vDirStretch * vDirForce < 0.f)
		{
			//	λ�Ʒ�������ķ����෴��Clamp��
			force = 0;
			vDirForce = 0;
			fMagForce = 0;
			m_fVelocity = param.fStiffness * stretch / param.fDamping;
		}

		m_fAcceleration = force / param.fMass;

		m_fVelocity += m_fAcceleration * dt;

		float vDeltaMove = m_fVelocity * dt;

		float fDistMove = FMath::Abs(vDeltaMove);
		if (fDistMove + 1e-3f > fMagStretch)
		{
			//	Ų�����ࣺClamp!
			fSpeed = m_fDesiredSpeed;
			m_fVelocity = 0;
			m_fAcceleration = 0;
		}
		else
			fSpeed += vDeltaMove;
	}

	void SPRINTPHY_POS::SetDefaultSpringParam()
	{
		param.fMass = 1.f;

		param.fStiffness = 200.f;
		param.fDamping = 30.f;
	}

	void SPRINTPHY_POS::InterpPos(FVector& vCurPos, const FVector& vDestPos, float dt, float* pfOutSpeed/* = nullptr*/, const float* pfMaxSpeed/* = nullptr*/)
	{
		vDesiredPos = vDestPos;

		FVector stretch = vDesiredPos - vCurPos;
		FVector vDirStretch;
		float fMagStretch;
		stretch.ToDirectionAndLength(vDirStretch, fMagStretch);

		FVector force = param.fStiffness * stretch - param.fDamping * vVelocity;
		FVector vDirForce = force;
		float fMagForce = vDirForce.Normalize();

		//AString strDbg;

		if (FVector::DotProduct(vDirStretch, vDirForce) < 0.f)
		{
			//	λ�Ʒ�������ķ����෴��Clamp��
			//strDbg.Format("@%d: Stretch [%.3f](%.3f %.3f %.3f) dot Force [%.3f](%.3f %.3f %.3f) < 0 ! Force -> 0\n",
			//	a_GetTime(), fMagStretch, vDirStretch.x, vDirStretch.y, vDirStretch.z,
			//	fMagForce, vDirForce.x, vDirForce.y, vDirForce.z);
			//OutputDebugStringA(strDbg);

			//	force = 0
			force.Set(0, 0, 0);
			vDirForce.Set(0, 0, 0);
			fMagForce = 0.f;
			vVelocity = param.fStiffness * stretch / param.fDamping;
		}

		vAcceleration = force / param.fMass;

		vVelocity += vAcceleration * dt;

		float fSpeed;
		FVector vDirMove;
		vVelocity.ToDirectionAndLength(vDirMove, fSpeed);

		if (pfOutSpeed || pfMaxSpeed)
		{
			if (pfMaxSpeed && fSpeed > *pfMaxSpeed)
			{
				fSpeed = *pfMaxSpeed;

				vVelocity = vDirMove * fSpeed;
			}

			if (pfOutSpeed)
				*pfOutSpeed = fSpeed;
		}

		float fDistMove = fSpeed * dt;
		if (fDistMove + 1e-3f > fMagStretch)
		{
			//	Ų�����ࣺClamp!
			vCurPos = vDesiredPos;
			vVelocity.Set(0, 0, 0);
			vAcceleration.Set(0, 0, 0);

			//if (fMagStretch > 1e-3f)
			//{
			//	strDbg.Format("@%d: fDistMove %.3f + 1e-3f > fMagStretch %.3f! RealLook->DestLook, Vel->0, Acc->0\n",
			//		a_GetTime(), fDistMove, fMagStretch);
			//	OutputDebugStringA(strDbg);
			//}
		}
		else
			vCurPos += vVelocity * dt;
	}

};
