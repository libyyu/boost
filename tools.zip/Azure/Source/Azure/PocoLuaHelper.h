#pragma once

#include "CoreMinimal.h"
#include "AzureEntryPoint.h"
#include "PocoLuaHelper.generated.h"

UCLASS()
class UPocoLuaHelper : public UObject
{
	GENERATED_BODY()
public:
	UFUNCTION()
	static FString DoLuaString(FString& LuaCode)
	{
		lua_State_Wrapper L = AAzureEntryPoint::Instance->GetWLua()->GetL();

		FString result;
		auto top = lua_gettop(L);
		auto code = TCHAR_TO_ANSI(*LuaCode);
		auto ret = luaL_loadbuffer(L, code, strlen(code), "luastring");
		if (ret == 0) { ret = lua_pcall(L, 0, 1, 0); }
		result.AppendInt(ret == 0 ? 1 : 0);
		if (lua_isstring(L, -1)) { result.Append(ANSI_TO_TCHAR(lua_tostring(L, -1))); }
		lua_settop(L, top);

		return result;
	}
};