// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Components/ActorComponent.h"
#include "GUI/AzureHudText.h"
#include "GUI/AzureMultiSegmentsHudText.h"
#include "GUI/AzureMultiSegmentKeysHudText.h"
#include "wLuaStatic.h"
#include "AzurePateComponent.generated.h"

struct UAzureMultiSegments;
struct UAzureMultiSegmentFloatKeys;
class UAzureBMFont;
UCLASS( ClassGroup=(Custom), meta=(BlueprintSpawnableComponent) )
class AZURE_API UAzurePateComponent : public UActorComponent
{
	GENERATED_BODY()

public:	

	// Sets default values for this component's properties
	UAzurePateComponent();

	// Called when the game starts
	virtual void BeginPlay() override;
	
	// Called every frame
	virtual void TickComponent( float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction ) override;

	virtual void OnComponentDestroyed(bool bDestroyingHierarchy) override;

	UFUNCTION()
	void SetHudTextString(FString &InText, UAzureBMFont *Font, int fontSize, float lifeTime,
		FVector2D &velocity, float moveTime, float scaleFrom, float scaleFromTime, float scaleTo, float scaleToTime, FVector &Woffset, FVector2D &offset);

	void SetMultiSegsHudTextString(FString &InText, UAzureBMFont *Font, int fontSize, float scale, float alpha, FVector2D &velocity, UAzureMultiSegments *multiSegs, FVector &Woffset, FVector2D &offset);

	void SetMultiSegKeysHudTextString(const FString &InText , UAzureBMFont *Font , int fontSize , float scale , float alpha , UAzureMultiSegmentTimeLine *multiSegTimeLine , const FVector &Woffset , const FVector2D &offset , int32 txt_ZOrder, int32 effect_ZOrder);
	void SetMultiSegKeysHudTextStringWorldPos(FString &InText , UAzureBMFont *Font , int fontSize , float scale , float alpha , UAzureMultiSegmentTimeLine *multiSegTimeLine , const FVector &WorldPos , const FVector2D &offset , int32 txt_ZOrder, int32 effect_ZOrder);

	UFUNCTION()
	void SetPateWidget(UUserWidget * NewUserWidget);

	UFUNCTION()
	void SetExtraPateWidget(UUserWidget * NewUserWidget);

	//For Preview in Editor 
	UPROPERTY( EditAnywhere, BlueprintReadWrite )
	TSubclassOf<UUserWidget> UserWidgetClass; 

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	FVector WorldOffset;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	FVector2D ScreenOffset;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	FVector ExtraWorldOffset;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	FVector2D ExtraScreenOffset;

	UPROPERTY(EditAnywhere)
	TWeakObjectPtr<USceneComponent> targetComponent;
	
	UPROPERTY(EditAnywhere)
	FName targetSocket;

	UPROPERTY(EditAnywhere)
	FName baseSocket;

	UPROPERTY(EditAnywhere)
	bool IsLimitScreenPosition = false;

	UPROPERTY(EditAnywhere)
	float LimitDistToTopScreen = 0;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	float keepZSquaredDisThreshold = 25.f;

	UFUNCTION()
	UUserWidget* GetUserWidget();

	UFUNCTION()
	UUserWidget* GetExtraUserWidget();

	UFUNCTION()
	void SetAttachComponent(USceneComponent *component, const FString& socket, const FString& socket2);

	UFUNCTION()
	void SetFixedZ(bool useFixedz,float fixedZ);

	UFUNCTION()
	void SetViewOffset(FVector offset);

	// ��ȡʵ�ʻ���ռ����Ļ�ռ��Widget
	UFUNCTION()
	UWidget* GetPaintingWidget(UUserWidget* pWidget);

	void AdjustPointScreenPosition(UUserWidget* pWidget, FVector2D& Position);

	FVector AdjustWorldOffset(const FVector& worldOffset);
	
	void TickUserWidget(float DeltaTime, bool bExtra);
public:
	void AttachLuaObject();
	void SetUseScaleTime(bool bUse) { UseScaleTime = bUse; }
protected:
	void DetachLuaObject();
private:
	void ApplyViewOffset(FVector& orignalWorldPos);

	TWeakObjectPtr<APlayerController> PlayerController;
	TWeakObjectPtr<UUserWidget > UserWidget;
	TWeakObjectPtr<UUserWidget > ExtraUserWidget;

	UAzureHudText *HudText = NULL;
	UAzureMultiSegmentsHudText *MultiSegHudText = NULL;
	UAzureMultiSegmentKeysHudText *MultiSegKeysHudText = NULL;

	bool UseScaleTime = false;

	double CurrentTime;

	/** Last absolute real time that we ticked */
	double LastTickTime;
	
	wLua::lua_registry_handle mLuaObjRef;

	float mFixedZ;
	bool mUseFixedZ;
	FVector mLastWorldPosition;

	FVector mLastRootSocketPos;

	FVector mViewOffset;
};
