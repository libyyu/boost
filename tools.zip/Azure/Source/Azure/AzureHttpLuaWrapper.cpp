#define LUA_LIB
#include "lua.hpp"
#include "Http.h"
#include <thread>
#include <mutex>
#include <condition_variable>
#include <string>
#include <functional>
#include "wLua/LuaInterface.h"
#include "HAL/Runnable.h"
#include "HAL/RunnableThread.h"
#include "Patcher/patcher.h"
#include "Patcher/Launcher.h"

extern wLua::Lua* AAzureEntryPoint_GetWLua();

class AzureHttpLuaWrapper
{
	TMap<IHttpRequest*, TSharedPtr<IHttpRequest> > HttpRequests;
public:
	~AzureHttpLuaWrapper()
	{
		Clear();
	}
	
	IHttpRequest* Create()
	{
		FHttpModule& Http = FHttpModule::Get();
		TSharedRef<IHttpRequest> HttpRequest = Http.CreateRequest();
		IHttpRequest *httpRequest = &HttpRequest.Get();
		HttpRequests.Add(httpRequest, HttpRequest);
		return httpRequest;
	}

	bool Find(IHttpRequest *httpRequest)
	{
		if (!httpRequest)
			return false;

		return !!HttpRequests.Find(httpRequest);
	}

	int32 Remove(IHttpRequest *httpRequest)
	{
		if (!httpRequest)
			return -1;

		return HttpRequests.Remove(httpRequest);
	}

	void Clear()
	{
		for (TMap<IHttpRequest*, TSharedPtr<IHttpRequest> >::TIterator It(HttpRequests); It; ++It)
		{
			TSharedPtr<IHttpRequest> h = It.Value();
			h.Reset();
		}
		HttpRequests.Empty();
	}
};

static AzureHttpLuaWrapper s_httpLuaWrapper;

#define HTTP_LUA_WRAPPER_IMPL(method) static int lua_HttpLuaWrapper_##method(lua_State* L)
#define HTTP_LUA_LIB_REG(method) { #method,  lua_HttpLuaWrapper_##method }

HTTP_LUA_WRAPPER_IMPL(CreateRequest)
{
	IHttpRequest *httpRequest = s_httpLuaWrapper.Create();
	lua_pushlightuserdata(L, httpRequest);
	return 1;
}
HTTP_LUA_WRAPPER_IMPL(DestroyRequest)
{
	IHttpRequest *HttpRequest = (IHttpRequest*)lua_touserdata(L, 1);
	if (!HttpRequest)
		return 0;

	int32 num = s_httpLuaWrapper.Remove(HttpRequest);

	lua_pushboolean(L, num > 0 ? 1 : 0);
	return 1;
}
HTTP_LUA_WRAPPER_IMPL(CancelRequest)
{
	IHttpRequest *HttpRequest = (IHttpRequest*)lua_touserdata(L, 1);
	if (!HttpRequest)
		return 0;

	if (!s_httpLuaWrapper.Find(HttpRequest))
		return 0;

	HttpRequest->CancelRequest();

	return 0;
}
HTTP_LUA_WRAPPER_IMPL(ProcessRequest)
{
	IHttpRequest *HttpRequest = (IHttpRequest*)lua_touserdata(L, 1);
	if (!HttpRequest)
		return 0;

	if (!s_httpLuaWrapper.Find(HttpRequest))
		return 0;

	bool ret = HttpRequest->ProcessRequest();

	lua_pushboolean(L, ret ? 1 : 0);
	return 1;
}
HTTP_LUA_WRAPPER_IMPL(GetRequestStatus)
{
	IHttpRequest *HttpRequest = (IHttpRequest*)lua_touserdata(L, 1);
	if (!HttpRequest)
		return 0;

	if (!s_httpLuaWrapper.Find(HttpRequest))
		return 0;

	int32 status = (int32)HttpRequest->GetStatus();

	lua_pushinteger(L, status);
	return 1;
}
HTTP_LUA_WRAPPER_IMPL(SetTimeout)
{
	int32 oldTimeout = FHttpModule::Get().GetHttpTimeout();
	lua_Integer timeout = luaL_checkinteger(L, 1);
	FHttpModule::Get().SetHttpTimeout(timeout / 1000.0f);
	lua_pushnumber(L, oldTimeout * 1000.0f);
	return 1;
}
HTTP_LUA_WRAPPER_IMPL(GetTimeout)
{
	lua_pushnumber(L, FHttpModule::Get().GetHttpTimeout() * 1000.0f);
	return 1;
}
HTTP_LUA_WRAPPER_IMPL(SetOnComplete)
{
	IHttpRequest *HttpRequest = (IHttpRequest*)lua_touserdata(L, 1);
	if (!HttpRequest)
		return 0;

	if (!s_httpLuaWrapper.Find(HttpRequest))
		return 0;

	class FuncHolder
	{
		wLua::lua_registry_handle refID;

	public:
		FuncHolder(lua_State* InL)
		{
			lua_pushvalue(InL, 2);
			refID = wLua::lua_registry_handle::wlua_ref(InL, LUA_REGISTRYINDEX);
		}
		~FuncHolder()
		{
			wLua::Lua *wLua = AAzureEntryPoint_GetWLua();
			if (wLua)
			{
				lua_State_Wrapper wL = wLua->GetL();
				wLua::lua_registry_handle::wlua_unref(wL, LUA_REGISTRYINDEX, refID);
			}
		}
		void OnComplete(FHttpRequestPtr InRequest, FHttpResponsePtr InResponse, bool bSucceeded)
		{
			wLua::Lua *wLua = AAzureEntryPoint_GetWLua();
			if (wLua)
			{
				lua_State_Wrapper wL = wLua->GetL();
				lua_rawgeti(wL, LUA_REGISTRYINDEX, refID);
				lua_pushlightuserdata(wL, InRequest.Get());
				lua_pushlightuserdata(wL, InResponse.Get());
				lua_pushboolean(wL, bSucceeded ? 1 : 0);
				wLua->Call(3);
			}
		}
	};

	TSharedPtr<FuncHolder> Holder = MakeShareable(new FuncHolder(L));
	HttpRequest->OnProcessRequestComplete().BindLambda([](FHttpRequestPtr InRequest,
		FHttpResponsePtr InResponse, bool bSucceeded, TSharedPtr<FuncHolder> InHolder) {
		InHolder->OnComplete(InRequest, InResponse, bSucceeded); }, Holder);

	lua_pushboolean(L, 1);
	return 1;
}
HTTP_LUA_WRAPPER_IMPL(SetOnProgress)
{
	IHttpRequest *HttpRequest = (IHttpRequest*)lua_touserdata(L, 1);
	if (!HttpRequest)
		return 0;

	if (!s_httpLuaWrapper.Find(HttpRequest))
		return 0;

	class FuncHolder
	{
		wLua::lua_registry_handle refID;
	public:
		FuncHolder(lua_State* InL)
		{
			lua_pushvalue(InL, 2);
			refID = wLua::lua_registry_handle::wlua_ref(InL, LUA_REGISTRYINDEX);
		}
		~FuncHolder()
		{
			wLua::Lua *wLua = AAzureEntryPoint_GetWLua();
			if (wLua)
			{
				lua_State_Wrapper wL = wLua->GetL();
				wLua::lua_registry_handle::wlua_unref(wL, LUA_REGISTRYINDEX, refID);
			}
		}
		void OnProgress(FHttpRequestPtr InRequest, int32 BytesSent, int32 BytesRcv)
		{
			wLua::Lua *wLua = AAzureEntryPoint_GetWLua();
			if (wLua)
			{
				lua_State_Wrapper wL = wLua->GetL();
				lua_rawgeti(wL, LUA_REGISTRYINDEX, refID);
				lua_pushlightuserdata(wL, InRequest.Get());
				lua_pushinteger(wL, BytesSent);
				lua_pushinteger(wL, BytesRcv);
				wLua->Call(3);
			}
		}
	};

	TSharedPtr<FuncHolder> Holder = MakeShareable(new FuncHolder(L));
	HttpRequest->OnRequestProgress().BindLambda([](FHttpRequestPtr InRequest,
		int32 BytesSent, int32 BytesRcv, TSharedPtr<FuncHolder> InHolder) {
		InHolder->OnProgress(InRequest, BytesSent, BytesRcv); }, Holder);

	lua_pushboolean(L, 1);
	return 1;
}
HTTP_LUA_WRAPPER_IMPL(SetOnHeaderReceived)
{
	IHttpRequest *HttpRequest = (IHttpRequest*)lua_touserdata(L, 1);
	if (!HttpRequest)
		return 0;

	if (!s_httpLuaWrapper.Find(HttpRequest))
		return 0;

	class FuncHolder
	{
		wLua::lua_registry_handle refID;
	public:
		FuncHolder(lua_State* InL)
		{
			lua_pushvalue(InL, 2);
			refID = wLua::lua_registry_handle::wlua_ref(InL, LUA_REGISTRYINDEX);
		}
		~FuncHolder()
		{
			wLua::Lua *wLua = AAzureEntryPoint_GetWLua();
			if (wLua)
			{
				lua_State_Wrapper wL = wLua->GetL();
				wLua::lua_registry_handle::wlua_unref(wL, LUA_REGISTRYINDEX, refID);
			}
		}
		void OnHeaderReceived(FHttpRequestPtr InRequest, const FString& HeaderName, const FString& NewHeaderValue)
		{
			wLua::Lua *wLua = AAzureEntryPoint_GetWLua();
			if (wLua)
			{
				lua_State_Wrapper wL = wLua->GetL();
				lua_rawgeti(wL, LUA_REGISTRYINDEX, refID);
				lua_pushlightuserdata(wL, InRequest.Get());
				lua_pushstring(wL, TCHAR_TO_UTF8(*HeaderName));
				lua_pushstring(wL, TCHAR_TO_UTF8(*NewHeaderValue));
				wLua->Call(3);
			}
		}
	};

	TSharedPtr<FuncHolder> Holder = MakeShareable(new FuncHolder(L));
	HttpRequest->OnHeaderReceived().BindLambda([](FHttpRequestPtr InRequest,
		const FString& HeaderName, const FString& NewHeaderValue, TSharedPtr<FuncHolder> InHolder) {
		InHolder->OnHeaderReceived(InRequest, HeaderName, NewHeaderValue); }, Holder);

	lua_pushboolean(L, 1);
	return 1;
}
HTTP_LUA_WRAPPER_IMPL(SetURL)
{
	IHttpRequest *HttpRequest = (IHttpRequest*)lua_touserdata(L, 1);
	if (!HttpRequest)
		return 0;

	if (!s_httpLuaWrapper.Find(HttpRequest))
		return 0;

	const char *url = luaL_checkstring(L, 2);
	HttpRequest->SetURL(UTF8_TO_TCHAR(url));

	return 0;
}
HTTP_LUA_WRAPPER_IMPL(SetVerb)
{
	IHttpRequest *HttpRequest = (IHttpRequest*)lua_touserdata(L, 1);
	if (!HttpRequest)
		return 0;

	if (!s_httpLuaWrapper.Find(HttpRequest))
		return 0;

	const char *verb = luaL_checkstring(L, 2);
	HttpRequest->SetVerb(UTF8_TO_TCHAR(verb));

	return 0;
}
HTTP_LUA_WRAPPER_IMPL(SetHeader)
{
	IHttpRequest *HttpRequest = (IHttpRequest*)lua_touserdata(L, 1);
	if (!HttpRequest)
		return 0;

	if (!s_httpLuaWrapper.Find(HttpRequest))
		return 0;

	const char *name = luaL_checkstring(L, 2);
	const char *value = luaL_checkstring(L, 3);
	HttpRequest->SetHeader(UTF8_TO_TCHAR(name), UTF8_TO_TCHAR(value));

	return 0;
}
HTTP_LUA_WRAPPER_IMPL(GetResponseCode)
{
	IHttpRequest *HttpRequest = (IHttpRequest*)lua_touserdata(L, 1);
	if (!HttpRequest)
		return 0;

	if (!s_httpLuaWrapper.Find(HttpRequest))
		return 0;

	FHttpResponsePtr Response = HttpRequest->GetResponse();
	if (!Response.IsValid())
		return 0;

	int32 code = Response->GetResponseCode();

	lua_pushinteger(L, code);
	return 1;
}
HTTP_LUA_WRAPPER_IMPL(GetResponseHeader)
{
	IHttpRequest *HttpRequest = (IHttpRequest*)lua_touserdata(L, 1);
	if (!HttpRequest)
		return 0;

	if (!s_httpLuaWrapper.Find(HttpRequest))
		return 0;

	FHttpResponsePtr Response = HttpRequest->GetResponse();
	if (!Response.IsValid())
		return 0;

	const FString key = UTF8_TO_TCHAR(luaL_checkstring(L, 2));
	const FString value = Response->GetHeader(key);

	lua_pushstring(L, TCHAR_TO_UTF8(*value));
	return 1;
}
HTTP_LUA_WRAPPER_IMPL(GetContentLength)
{
	IHttpRequest *HttpRequest = (IHttpRequest*)lua_touserdata(L, 1);
	if (!HttpRequest)
		return 0;

	if (!s_httpLuaWrapper.Find(HttpRequest))
		return 0;

	FHttpResponsePtr Response = HttpRequest->GetResponse();
	if (!Response.IsValid())
		return 0;

	int32 length = Response->GetContentLength();

	lua_pushinteger(L, length);
	return 1;
}
HTTP_LUA_WRAPPER_IMPL(SaveContent)
{
	IHttpRequest *HttpRequest = (IHttpRequest*)lua_touserdata(L, 1);
	if (!HttpRequest)
		return 0;

	if (!s_httpLuaWrapper.Find(HttpRequest))
		return 0;

	FHttpResponsePtr Response = HttpRequest->GetResponse();
	if (!Response.IsValid())
		return 0;

	IHttpResponse *response = (IHttpResponse*)lua_touserdata(L, 2);
	if (Response.Get() != response)
		return 0;

	const char *path = luaL_checkstring(L, 3);

	const TArray<uint8>& content = response->GetContent();
	bool ret = PatcherSpace::writeToFileUTF8(path, (const char*)content.GetData(), (size_t)content.Num());

	lua_pushboolean(L, ret ? 1 : 0);
	return 1;
}
HTTP_LUA_WRAPPER_IMPL(SaveContentAppend)
{
	IHttpRequest *HttpRequest = (IHttpRequest*)lua_touserdata(L, 1);
	if (!HttpRequest)
		return 0;

	if (!s_httpLuaWrapper.Find(HttpRequest))
		return 0;

	FHttpResponsePtr Response = HttpRequest->GetResponse();
	if (!Response.IsValid())
		return 0;

	IHttpResponse *response = (IHttpResponse*)lua_touserdata(L, 2);
	if (Response.Get() != response)
		return 0;

	const char *path = luaL_checkstring(L, 3);

	const TArray<uint8>& content = response->GetContent();
	int32 ret = 0;
	FILE *p = fopen(path, "ab");
	if (p != nullptr)
	{
		size_t nforwrite = (size_t)content.Num();
		size_t nwrite = fwrite((const char*)content.GetData(), (size_t)content.Num(), 1, p);
		fflush(p);
		fclose(p);
		ret = nwrite > 0;
	}
	lua_pushboolean(L, ret);
	return 1;
}

static const luaL_Reg Lib_AzureHttpLuaWrapper_Funcs[] =
{
	HTTP_LUA_LIB_REG(CreateRequest),
	HTTP_LUA_LIB_REG(DestroyRequest),
	HTTP_LUA_LIB_REG(CancelRequest),
	HTTP_LUA_LIB_REG(ProcessRequest),
	HTTP_LUA_LIB_REG(GetRequestStatus),
	HTTP_LUA_LIB_REG(SetTimeout),
	HTTP_LUA_LIB_REG(GetTimeout),
	HTTP_LUA_LIB_REG(SetOnComplete),
	HTTP_LUA_LIB_REG(SetOnProgress),
	HTTP_LUA_LIB_REG(SetOnHeaderReceived),
	HTTP_LUA_LIB_REG(SetURL),
	HTTP_LUA_LIB_REG(SetVerb),
	HTTP_LUA_LIB_REG(SetHeader),
	HTTP_LUA_LIB_REG(GetResponseCode),
	HTTP_LUA_LIB_REG(GetResponseHeader),
	HTTP_LUA_LIB_REG(GetContentLength),
	HTTP_LUA_LIB_REG(SaveContent),
	HTTP_LUA_LIB_REG(SaveContentAppend),
	{ NULL, NULL }
};
namespace HttpLuaWrapper
{
	void Register(lua_State* L)
	{
		luaL_register(L, "HttpLuaWrapper", Lib_AzureHttpLuaWrapper_Funcs);
		lua_pop(L, 1);
	}

	void Clear()
	{
		s_httpLuaWrapper.Clear();
	}
}