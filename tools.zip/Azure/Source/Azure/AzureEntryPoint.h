// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "Camera/CameraComponent.h"

#include "wLua.h"
#include "Utilities/ECTimerList.h"
#include "Utilities/ECDebug.h"

#include <vector>
#include <AK/SoundEngine/Common/AkTypes.h>

#include "AzureEntryPoint.generated.h"

class SWidget;
class FSlateSceneWidgetManager;
class FSceneViewport;

UENUM()
enum LuaCheckLevelEnum
{
	CL_None = 0 UMETA(DisplayName = "None"),
	CL_Limited = 1 UMETA(DisplayName = "Limited"),
	CL_Strict = 2 UMETA(DisplayName = "Strict"),
};

UENUM()
enum ECLogLevel
{
	LL_None = 0 UMETA(DisplayName = "None"),
	LL_Exception = 1 UMETA(DisplayName = "Exception"),
	LL_Error = 2 UMETA(DisplayName = "Error"),
	LL_Warning = 3 UMETA(DisplayName = "Warning"),
	LL_Log = 4 UMETA(DisplayName = "Log"),
	LL_All = 5 UMETA(DisplayName = "All"),
};

enum class AzureLogType
{
	Error = 0,
	Assert = 1,
	Warning = 2,
	Log = 3,
	Exception = 4,
	Fatal = 5,
	Other = 10,
};

class AzureHudTextMan;
class AzureScreenBulletMan;
class UWidgetInteractionComponent;
class AHUD;
class UECCameraSpringArmComponent;

template<typename TargetType>
struct FActorLateTickFunction : public FTickFunction
{
	/**  AActor  that is the target of this tick **/
	TargetType*	Target;

	/**
	* Abstract function actually execute the tick.
	* @param DeltaTime - frame time to advance, in seconds
	* @param TickType - kind of tick for this frame
	* @param CurrentThread - thread we are executing on, useful to pass along as new tasks are created
	* @param MyCompletionGraphEvent - completion event for this task. Useful for holding the completetion of this task until certain child tasks are complete.
	**/
	virtual void ExecuteTick(float DeltaTime, ELevelTick TickType, ENamedThreads::Type CurrentThread, const FGraphEventRef& MyCompletionGraphEvent) override
	{
		if (Target != nullptr && !Target->IsPendingKillOrUnreachable())
		{
			FScopeCycleCounterUObject ActorScope(Target);

			//root of tick hierarchy

			// Non-player update.
			const bool bShouldTick = ((TickType != LEVELTICK_ViewportsOnly) || Target->ShouldTickIfViewportsOnly());
			if (bShouldTick)
			{
				// If an Actor has been Destroyed or its level has been unloaded don't execute any queued ticks
				if (!Target->IsPendingKill() && Target->GetWorld())
				{
					Target->LateTick(DeltaTime*Target->CustomTimeDilation);	// perform any tick functions unique to an actor subclass
				}
			}
		}
	}
	/** Abstract function to describe this tick. Used to print messages about illegal cycles in the dependency graph **/
	virtual FString DiagnosticMessage() override
	{
		return Target->GetFullName() + TEXT("[LateTickActor]");
	}

	void RegisterActorTickFunctions(TargetType*	InTarget, bool bRegister)
	{
		if (bRegister)
		{
			if (bCanEverTick)
			{
				Target = InTarget;
				SetTickFunctionEnable(bStartWithTickEnabled || IsTickFunctionEnabled());
				RegisterTickFunction(Target->GetLevel());
			}
		}
		else
		{
			if (IsTickFunctionRegistered())
			{
				UnRegisterTickFunction();
			}
		}
	}

	void InitializeDefaults()
	{
		TickGroup = TG_PostPhysics;
		EndTickGroup = TG_PostPhysics;
		// Default to no tick function, but if we set 'never ticks' to false (so there is a tick function) it is enabled by default
		bCanEverTick = false;
		bStartWithTickEnabled = true;
		SetTickFunctionEnable(false);
	}
};

UCLASS()
class AZURE_API AAzureEntryPoint : public AActor
{
	GENERATED_BODY()

public:
	double m_realtimeSinceStartup = 0;
	double m_curFrameTime = 0;


protected:
	bool m_bInited = false;
	bool m_bOnPendingKillPurgeFuncCalled = false;
	wLua::Lua * wlua;

	ECTimerList m_TimerList;
	ECTimerList m_LateTimerList;
	AzureHudTextMan* m_HudTextMan = nullptr;
	AzureScreenBulletMan* m_ScreenBulletMan = nullptr;
	UPROPERTY(Transient)
	APlayerController* m_PlayerController = nullptr;
	TWeakObjectPtr<AActor> m_pSkyBoxActor = nullptr;
	TWeakObjectPtr<AActor> m_pEnvironmentManager = nullptr;

	uint64 m_curFrameCount = 0;
	float m_curDeltaTime = 0;

	FVector m_curVPLocation;	//	Cur ViewPoint Location
	FRotator m_curVPRotation;	//	Cur ViewPoint Rotation
	bool m_curVPValid = false;

	// Use PostPhysicsFunc instead
	// struct FActorLateTickFunction<AAzureEntryPoint> LateActorTick;

	ECDebug m_ECDebug;

	enum TimeScaleStage
	{
		None = 0,
		ZoomIn = 1,
		Keep = 2,
		ZoomOut = 3,
	};

	TimeScaleStage m_TimeScaleTransStage = TimeScaleStage::None;
	float m_fTimeScaleTransDelta = 0;
	float m_fTimeScalePlayedTime = 0;

	float m_fDestTimeScale = 1;
	float m_fTimeScaleInDur = 0;
	float m_fTimeScaleKeepDur = 0;
	float m_fTimeScaleOutDur = 0;

	const float s_fTimeScaleMin = 0.001f;

protected:

	/**
	* Virtual call chain to register all tick functions for the actor class hierarchy
	* @param bRegister - true to register, false, to unregister
	*/
	virtual void RegisterActorTickFunctions(bool bRegister);

	void SetupPaths();
	void SetupEntryPointConfig();

	void HandleApplicationHasReactivated();
	void HandleApplicationWillDeactivate();
	void HandleApplicationHasEnteredForeground();
	void HandleApplicationWillEnterBackground();
	void HandleReceivedScreenOrientationChanged(int32 orientation);
	
	void LuaOnApplicationResume();
	void LuaOnApplicationPause();
	void LuaOnApplicationBackground();
	void LuaOnApplicationForeground();
	void LuaOnScreenOrientationChanged(int32 orientation);

public:	
	
	static AAzureEntryPoint* Instance;

	//astring AssetsPath;
	//astring BackupAssetsPath;
	//astring PckDebugDir;
	astring LuaPath;
	UPROPERTY(Transient)
	UWidgetInteractionComponent* WidgetInteractionComp;

	UFUNCTION()
	void ResetCameraState();

	static bool IsInit() { return Instance != nullptr && Instance->m_bInited; }
	static bool IsStarted() { return Instance != nullptr && Instance->m_bStarted; }
	static void PostPhysicsFunc();
	static void BeforeBeginFrameCustomFunc();
	static void PostTickObjectsCustomFunc();
	static void PostUpdateWorkFunc();
	static void OnPendingKillPurgeFunc();

	wLua::Lua * GetWLua() { return wlua; }

	lua_State_Wrapper_Private GetL()
	{
		if (wlua == nullptr)
			return nullptr;

		return wlua->GetL();
	}

	static lua_State_Wrapper_Private SafeGetL()
	{
		if (Instance && Instance->wlua)
			return Instance->wlua->GetL();

		return nullptr;
	}


	UCameraComponent* GetMainCameraComponent();
	UECCameraSpringArmComponent* GetCameraSpringComponent();
	
	AzureHudTextMan* GetHudTextMan() { return m_HudTextMan; }
	AzureScreenBulletMan* GetScreenBulletMan();

	APlayerController* GetPlayerController() { return m_PlayerController;  }

	double GetRealtimeSinceStartup() const
	{
		return FPlatformTime::Seconds() - m_realtimeSinceStartup;
	}

	double GetCurFrameTime() const;

	uint64 GetCurFrameCount() const
	{
		return m_curFrameCount;
	}

	bool GetCurViewPointLocRot(FVector& loc, FRotator& rot) const
	{
		if (!m_curVPValid)
			return false;

		loc = m_curVPLocation;
		rot = m_curVPRotation;
		return true;
	}

	// Sets default values for this actor's properties
	AAzureEntryPoint();

	// Called when the game starts or when spawned
	virtual void BeginPlay() override;
	virtual void EndPlay(const EEndPlayReason::Type EndPlayReason) override;

	
	// Called every frame
	virtual void Tick( float DeltaSeconds ) override;
	virtual void BeginDestroy() override;

	void LateTick(float DeltaSeconds);

	void TickPostUpdate(float DeltaSeconds);
	
	ULevel* AddLevelToWorld(UWorld* LevelHolder);
	void RemoveLevelFromWorld(ULevel* LevelToRemove);
	AActor* FindActor(const FString& name);

	float GetEffectiveTimeDilation() const;

	int AddTimer(float ttl, bool bOnce, wLua::lua_registry_handle cb, wLua::lua_registry_handle cbparam, bool bLateUpdate, bool bChangeWithTimeDilation = false)
	{
		if (bLateUpdate)
		{
			return m_LateTimerList.AddTimer(ttl, bOnce, cb, cbparam, bChangeWithTimeDilation);
		}
		else
		{
			return m_TimerList.AddTimer(ttl, bOnce, cb, cbparam, bChangeWithTimeDilation);
		}
	}

	int RemoveTimer(int id)
	{
		int iRet1 = m_TimerList.RemoveTimer(id);
		int iRet2 = m_LateTimerList.RemoveTimer(id);
		return iRet1 >= 0 ? iRet1 : iRet2;
	}

	void ResetTimer(int id)
	{
		m_TimerList.ResetTimer(id);
		m_LateTimerList.ResetTimer(id);
	}

	void SetTimer(int id, float fNextPlayTime)
	{
		m_TimerList.SetTimer(id, fNextPlayTime);
		m_LateTimerList.SetTimer(id, fNextPlayTime);
	}

	void AddScene3DWidget(TSharedRef<class SWidget> Widget, int ZOrder);
	void RemoveScene3DWidget(TSharedRef<class SWidget> Widget);
	AActor* GetHostModelActor();
	AActor* GetHostRootActor();

	void ChangeTimeScale(float fDestScale, float fInTime, float fKeepTime, float fOutTime);
	void RefreshCurTimeScale(float fInDeltaTime);

	void SetSkyBoxActor(AActor *pSkyBox) { m_pSkyBoxActor = pSkyBox; }
	AActor* GetSkyBoxActor() { return m_pSkyBoxActor.Get(); }

	void SetEnvironmentManager(AActor *pEnvironmentManager) { m_pEnvironmentManager = pEnvironmentManager; }
	AActor* GetEnvironmentManager() { return m_pEnvironmentManager.Get(); }

	bool CallLuaFunctionOI(FString FunctionName, UObject* Param1, int32 Param2);

	virtual void GenExtraGlobalVariables(TMap<FString, bool>& params) {}
	virtual void GenExtraEntryPointParams(TMap<FString, FString>& params) {}
	virtual void StartLua();

	static void OnCVarsChanged();

	static void OnMovieSceneAKPostEvent(AkPlayingID playingId, FString eventName, UObject* objcet);

	DECLARE_MULTICAST_DELEGATE(FEndPlayDelegate);
	FEndPlayDelegate OnEndPlayDelegate;

#if WITH_EDITOR
	void SetPlaySessionPaused(bool pause);
	bool IsPlaySessionPaused() const;
#endif
public:
	void OnDrawHUD(AHUD *HUD);

private:
	struct Stat_Info
	{
		int32 x, y;
		FString info;
		FLinearColor color;
	};
	avector<Stat_Info> m_StatInfoList;
	bool IsShowStat = false;
	bool IsShowMemAlloc = false;
	bool IsShowHUD = false;

	TSharedPtr<FSlateSceneWidgetManager> SlateSceneWidgetManager;
	FSceneViewport* GameViewport = nullptr;

	// Sink for when CVars are changed to notify lua
	static FAutoConsoleVariableSink CVarSink;

public:
	void ShowMemAlloc(bool bShow)
	{
		IsShowMemAlloc = bShow;
		IsShowHUD = bShow;
	}

	void ShowStat(bool bShow)
	{
		IsShowStat = bShow;
		IsShowHUD = bShow;
		m_StatInfoList.clear();
	}

	void AddStatInfo(int32 x, int32 y, const FString& info, FLinearColor color = FLinearColor::Green)
	{
		m_StatInfoList.push_back(Stat_Info());
		Stat_Info& s = m_StatInfoList.back();
		s.x = x; s.y = y;
		s.info = info;
		s.color = color;
	}

	void RemoveAllStatInfo()
	{
		m_StatInfoList.clear();
	}

public:
	bool m_bStarted = false;
	bool m_bApplicationPaused = false;

public:
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = Azure)
	bool NoProgramUpdate = false;
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = Azure)
	bool NoResourceUpdate = false;
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = Azure)
	FString UserName;
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = Azure)
	FString Password;
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = Azure)
	FString ServerIP;
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = Azure)
	int32 ServerPort;
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = Azure)
	bool SepFile = false;
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = Azure)
	bool ForceGuest = false;
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = Azure)
	bool ForceEvaluation = false;
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = Azure)
	bool isiOSOfficial = false;
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = Azure)
	bool OfficialEvaluation = false;
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = Azure)
	bool WriteLogFile;
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = Azure)
	TEnumAsByte<enum ECLogLevel> WriteLogLevel = ECLogLevel::LL_Log;
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = Azure)
	bool CreateConsole;
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = Azure)
	bool EnableLuaPrint;
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = Azure)
	bool isEnabledAndroidKeyboard = false;
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = Azure)
	TEnumAsByte<enum LuaCheckLevelEnum> LuaCheckingLevel = LuaCheckLevelEnum::CL_None; // C# default CL_Strict
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = Azure)
	bool DebugFlag = false;
};
