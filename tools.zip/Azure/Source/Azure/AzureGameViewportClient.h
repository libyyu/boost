// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Engine/GameViewportClient.h"
#include "AzureGameViewportClient.generated.h"

/**
 * 
 */
UCLASS()
class AZURE_API UAzureGameViewportClient : public UGameViewportClient
{
	GENERATED_BODY()
	
public:
	//~ Begin FViewportClient Interface.
	virtual bool InputKey(FViewport* Viewport, int32 ControllerId, FKey Key, EInputEvent EventType, float AmountDepressed = 1.f, bool bGamepad = false) override;
	virtual bool InputAxis(FViewport* Viewport, int32 ControllerId, FKey Key, float Delta, float DeltaTime, int32 NumSamples = 1, bool bGamepad = false) override;
	virtual bool InputChar(FViewport* Viewport, int32 ControllerId, TCHAR Character) override;
	virtual bool InputTouch(FViewport* Viewport, int32 ControllerId, uint32 Handle, ETouchType::Type Type, const FVector2D& TouchLocation, float Force, FDateTime DeviceTimestamp, uint32 TouchpadIndex) override;
	virtual bool InputMotion(FViewport* Viewport, int32 ControllerId, const FVector& Tilt, const FVector& RotationRate, const FVector& Gravity, const FVector& Acceleration) override;
	virtual void MouseEnter(FViewport* Viewport, int32 x, int32 y) override;
	virtual void MouseLeave(FViewport* Viewport) override;
	//~ End FViewportClient Interface.	

	virtual void MouseMove(FViewport* Viewport, int32 X, int32 Y) override;
	virtual void AddViewportWidgetContent(TSharedRef<class SWidget> ViewportContent, const int32 ZOrder = 0) override;
	virtual int AddViewportWidgetContentScene3D(TSharedRef<class SWidget> ViewportContent, const int32 ZOrder = 0) override;
	virtual void RemoveViewportWidgetContentScene3D(TSharedRef<class SWidget> ViewportContent) override;

	virtual void Tick(float t) override;

	virtual void ReceivedFocus(FViewport* Viewport) override;
	virtual void LostFocus(FViewport* Viewport) override;
	virtual void Activated(FViewport* Viewport, const FWindowActivateEvent& InActivateEvent) override;
	virtual void Deactivated(FViewport* Viewport, const FWindowActivateEvent& InActivateEvent) override;
	virtual void PreDeactivated(FViewport* Viewport, const FWindowActivateEvent& InActivateEvent) override;
	virtual void SetIsSimulateInEditorViewport(bool bInIsSimulateInEditorViewport) override;

	UFUNCTION(BlueprintCallable)
	void StartAlwaysCaptureMouse();

	UFUNCTION(BlueprintCallable)
	void StopAlwaysCaptureMouse();

	UFUNCTION(BlueprintCallable)
	bool IsAlwaysCaptureMouse();

	//Viewport functions
	UFUNCTION(BlueprintCallable)
	void Viewport_CaptureMouse(bool bCapture);

	UFUNCTION(BlueprintCallable)
	bool Viewport_HasMouseCapture();

	UFUNCTION(BlueprintCallable)
	void Viewport_LockMouseToViewport(bool bLock);

	UFUNCTION(BlueprintCallable)
	void Viewport_SetUserFocus(bool bFocus);

	UFUNCTION(BlueprintCallable)
	bool Viewport_HasFocus();

	UFUNCTION(BlueprintCallable)
	void Viewport_ShowCursor(bool bShow);

	UFUNCTION(BlueprintCallable)
	bool Viewport_IsCursorVisible();

private:
	FVector2D m_mouseTouchBeginPos;
	bool m_mouseTouchMoved = false;
	FVector2D m_mouseTouchPos;
	FVector2D m_lastMouseCursorPos;

	bool m_bAlwaysCaptureMouse = false;
};
