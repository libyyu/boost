﻿// Fill out your copyright notice in the Description page of Project Settings.

#include "AzurePateComponent.h"
#include "WidgetLayoutLibrary.h"
#include "AzureEntryPoint.h"
#include "GameLogic/Player/GamePlayer.h"
#include "GUI/AzureHudTextMan.h"
#include "UserWidget.h"
#include "Kismet/GameplayStatics.h"
#include "HAL/IConsoleManager.h"
#include "wLua/LuaInterface.h"
#include "Kismet/KismetSystemLibrary.h"
#include "PanelWidget.h"

// Sets default values for this component's properties
UAzurePateComponent::UAzurePateComponent()
{
	PrimaryComponentTick.bCanEverTick = true;
	PrimaryComponentTick.bStartWithTickEnabled = true;
	PrimaryComponentTick.TickGroup = TG_PostUpdateWork;
	PrimaryComponentTick.EndTickGroup = TG_PostUpdateWork;

	CurrentTime = FPlatformTime::Seconds();
	LastTickTime = CurrentTime;
}

// Called when the game starts
void UAzurePateComponent::BeginPlay()
{
	Super::BeginPlay();
	PlayerController  = UGameplayStatics::GetPlayerController(this->GetOwner(), 0);

#if WITH_EDITOR
	if (UserWidgetClass)
	{
		UserWidget = CreateWidget<UUserWidget>(GetWorld(), UserWidgetClass);
		if (UserWidget.IsValid())
		{
			UserWidget->AddToViewport();
		}
	}
#endif
}

// Called every frame
void UAzurePateComponent::TickComponent( float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction )
{
	CurrentTime = FPlatformTime::Seconds();
	if (!UseScaleTime)
	{
		DeltaTime = CurrentTime - LastTickTime;
	}
	LastTickTime = CurrentTime;

	Super::TickComponent( DeltaTime, TickType, ThisTickFunction );

	if (PlayerController.IsValid())
	{
		TickUserWidget(DeltaTime, false);
		TickUserWidget(DeltaTime, true);

		if (HudText)// && HudText->HasEntry())
		{
			//FVector2D ViewportSize = UWidgetLayoutLibrary::GetViewportSize(this);
			//bool isVisible = bSuc && AttachPointScreenPosition.X > 0 && AttachPointScreenPosition.X < ViewportSize.X
			//	&& AttachPointScreenPosition.Y >0 && AttachPointScreenPosition.Y < ViewportSize.Y;
			//if (isVisible != HudText->IsActive())
			//{
			//	HudText->SetActive(isVisible);
			//}
			//if (isVisible)
			//{
				HudText->Update();
			//}
		}

		if(MultiSegHudText)
			MultiSegHudText->Update(DeltaTime);

		if (MultiSegKeysHudText)
			MultiSegKeysHudText->Update(DeltaTime);

	}
}


void UAzurePateComponent::OnComponentDestroyed(bool bDestroyingHierarchy)
{
	UActorComponent::OnComponentDestroyed(bDestroyingHierarchy);
	if (HudText)
	{
		AzureHudTextMan *pMan = AAzureEntryPoint::Instance ? AAzureEntryPoint::Instance->GetHudTextMan() : nullptr;
		if (!pMan)
			return;
		pMan->GiveBackHudText(HudText);
		HudText = NULL;
	}

	if (MultiSegHudText)
	{
		AzureHudTextMan *pMan = AAzureEntryPoint::Instance ? AAzureEntryPoint::Instance->GetHudTextMan() : nullptr;
		if (!pMan)
			return;
		pMan->GiveBackMultiSegsHudText(MultiSegHudText);
		MultiSegHudText = NULL;
	}

	if (MultiSegKeysHudText)
	{
		AzureHudTextMan *pMan = AAzureEntryPoint::Instance ? AAzureEntryPoint::Instance->GetHudTextMan() : nullptr;
		if (!pMan)
			return;
		pMan->GiveBackMultiSegKeysHudText(MultiSegKeysHudText);
		MultiSegKeysHudText = NULL;
	}

	DetachLuaObject();
}

void UAzurePateComponent::SetHudTextString(FString &InText, UAzureBMFont *Font, int fontSize, float lifeTime, FVector2D &velocity, float moveTime, float scaleFrom, float scaleFromTime, float scaleTo, float scaleToTime, FVector &Woffset, FVector2D &offset)
{
	if (!AAzureEntryPoint::IsInit())
		return;

	AzureHudTextMan *pMan = AAzureEntryPoint::Instance->GetHudTextMan();
	if (!pMan)
		return;

	if (!HudText)
	{
		HudText = pMan->GetHudTextFromCache();
		HudText->SetOwner(GetOwner());
	}
		
	if (HudText)
		HudText->CreateEntry(InText, Font, fontSize, lifeTime, velocity, moveTime, scaleFrom, scaleFromTime, scaleTo, scaleToTime, Woffset, offset);
}

void UAzurePateComponent::SetMultiSegsHudTextString(FString &InText, UAzureBMFont *Font, int fontSize, float scale, float alpha, FVector2D &velocity, UAzureMultiSegments *multiSegs, FVector &Woffset, FVector2D &offset)
{
	if (!AAzureEntryPoint::IsInit())
		return;

	AzureHudTextMan *pMan = AAzureEntryPoint::Instance->GetHudTextMan();
	if (!pMan)
		return;

	if (!MultiSegHudText)
	{
		MultiSegHudText = pMan->GetMultiSegsHudTextFromCache();
		if (MultiSegHudText)
			MultiSegHudText->SetOwner(GetOwner());
	}

	if (MultiSegHudText)
		MultiSegHudText->CreateEntry(InText, Font, fontSize, scale, alpha, velocity, multiSegs, Woffset, offset);
}

void UAzurePateComponent::SetMultiSegKeysHudTextString(const FString &InText , UAzureBMFont *Font , int fontSize , float scale , float alpha , UAzureMultiSegmentTimeLine *multiSegTimeLine , const FVector &Woffset , const FVector2D &offset , int32 txt_ZOrder, int32 effect_ZOrder)
{
	if (!AAzureEntryPoint::IsInit())
		return;

	AzureHudTextMan *pMan = AAzureEntryPoint::Instance->GetHudTextMan();
	if (!pMan)
		return;

	if (!MultiSegKeysHudText)
	{
		MultiSegKeysHudText = pMan->GetMultiSegKeysHudTextFromCache();
		if (MultiSegKeysHudText)
			MultiSegKeysHudText->SetOwner(GetOwner());
	}

	if (MultiSegKeysHudText)
	{
		MultiSegKeysHudText->CreateEntry(InText , Font , fontSize , scale , alpha , multiSegTimeLine , Woffset , offset, txt_ZOrder, effect_ZOrder);
	}
}

void UAzurePateComponent::SetMultiSegKeysHudTextStringWorldPos(FString &InText , UAzureBMFont *Font , int fontSize , float scale , float alpha , UAzureMultiSegmentTimeLine *multiSegTimeLine , const FVector &WorldPos , const FVector2D &offset, int32 txt_ZOrder, int32 effect_ZOrder)
{
	if (!AAzureEntryPoint::IsInit())
		return;

	AzureHudTextMan *pMan = AAzureEntryPoint::Instance->GetHudTextMan();
	if (!pMan)
		return;

	if (!MultiSegKeysHudText)
	{
		MultiSegKeysHudText = pMan->GetMultiSegKeysHudTextFromCache();
		MultiSegKeysHudText->SetOwner(GetOwner());
	}

	if (MultiSegKeysHudText)
	{
		MultiSegKeysHudText->CreateEntryByWorldPos(InText , Font , fontSize , scale , alpha , multiSegTimeLine , WorldPos , offset , txt_ZOrder, effect_ZOrder);
	}
}

void UAzurePateComponent::SetPateWidget(UUserWidget * NewUserWidget)
{
	UserWidget = NewUserWidget;
}

void UAzurePateComponent::SetExtraPateWidget(UUserWidget * NewUserWidget)
{
	ExtraUserWidget = NewUserWidget;
}

UUserWidget* UAzurePateComponent::GetUserWidget()
{
	return UserWidget.Get(false);
}

UUserWidget* UAzurePateComponent::GetExtraUserWidget()
{
	return ExtraUserWidget.Get(false);
}

UWidget* UAzurePateComponent::GetPaintingWidget(UUserWidget* pWidget)
{
	UWidget* pRootWidget = pWidget->GetRootWidget();
	if (UPanelWidget* pPanelWidget = Cast<UPanelWidget>(pRootWidget))
	{
		if (UWidget* pPaintingWidget = pPanelWidget->GetChildAt(0))
		{
			return pPaintingWidget;
		}
	}
	return pWidget;
}

void UAzurePateComponent::AdjustPointScreenPosition(UUserWidget* pWidget, FVector2D& Position)
{
	// 血条位置限制在屏幕范围内（上边缘）
	if (IsLimitScreenPosition) {
		UWidget* pPaintingWidget = GetPaintingWidget(pWidget);
		if (pPaintingWidget != nullptr)
		{
			FGeometry WidgetGeometry = pPaintingWidget->GetCachedGeometry();
			FVector2D WidgetSize = WidgetGeometry.GetAbsoluteSize();
			if (Position.Y <= WidgetSize.Y + LimitDistToTopScreen) {
				Position.Y = WidgetSize.Y + LimitDistToTopScreen;
			}
		}
	}
}

void UAzurePateComponent::SetFixedZ(bool useFixedz, float fixedZ)
{
	mFixedZ = fixedZ;
	mUseFixedZ = useFixedz;
}

void UAzurePateComponent::SetAttachComponent(USceneComponent * component, const FString& socket, const FString& socket2)
{
	targetComponent = component;
	targetSocket = FName(*socket);
	baseSocket = FName(*socket2);
}

FVector UAzurePateComponent::AdjustWorldOffset(const FVector& worldOffset)
{
	FVector adjustWorldOffset = worldOffset;
	float yoffset = adjustWorldOffset.Y;
	if (yoffset != 0) //镜头左右方向偏移
	{
		UCameraComponent *pCamera = AAzureEntryPoint::Instance ? AAzureEntryPoint::Instance->GetMainCameraComponent() : nullptr;
		if (pCamera)
		{
			adjustWorldOffset.Y = 0;
			adjustWorldOffset += yoffset * pCamera->GetRightVector();
		}
	}
	return adjustWorldOffset;
}

void UAzurePateComponent::SetViewOffset(FVector offset)
{
	mViewOffset = offset;
}

void UAzurePateComponent::ApplyViewOffset(FVector& orignalWorldPos)
{
	UCameraComponent *pCamera = AAzureEntryPoint::Instance ? AAzureEntryPoint::Instance->GetMainCameraComponent() : nullptr;
	if (pCamera)
	{
		if (pCamera->ProjectionMode == ECameraProjectionMode::Orthographic) 
		{
			FVector worldOffset = pCamera->GetComponentTransform().TransformVector(mViewOffset);
			orignalWorldPos += worldOffset;
		}
		else if (pCamera->ProjectionMode == ECameraProjectionMode::Perspective)
		{
			FVector worldCameraPos = pCamera->GetComponentLocation();
			FVector dirToPatePos = orignalWorldPos - worldCameraPos;
			dirToPatePos.Normalize();

			//透视相机的情况下，x轴的偏移方向取目标点到相机的方向
			FVector viewOffsetYZ = FVector(0.0f, mViewOffset.Y, mViewOffset.Z);
			FVector worldOffset = pCamera->GetComponentTransform().TransformVector(viewOffsetYZ);
			worldOffset += dirToPatePos * mViewOffset.X;

			orignalWorldPos += worldOffset;
		}
	}
}

FString LuaRefToString(wLua::lua_registry_handle r)
{
	if (!r.IsNoRef() && AAzureEntryPoint::IsInit())
	{
		lua_State_Wrapper L = AAzureEntryPoint::Instance->GetL();
		int nTop = lua_gettop(L);
		lua_getglobal(L, "tostring"); //func
		lua_rawgeti(L, LUA_REGISTRYINDEX, r); //func, t
		AAzureEntryPoint::Instance->GetWLua()->PCall(1, 1); //s
		astring s = lua_tostring(L, -1);
		lua_settop(L, nTop);
		return UTF8_TO_TCHAR(s.c_str());
	}
	else {
		return TEXT("");
	}
}

void UAzurePateComponent::TickUserWidget(float DeltaTime, bool bExtra)
{
	static float maxCameraSpaceDepth = IConsoleManager::Get().FindConsoleVariable(TEXT("Slate.CameraSpaceDepth"))->GetFloat();

	UUserWidget *pUserWidget = bExtra ? ExtraUserWidget.Get() : UserWidget.Get();
	if (pUserWidget)
	{
		FVector frameWorldOffset = AdjustWorldOffset(bExtra ? ExtraWorldOffset : WorldOffset);

		FVector vCurPos = GetOwner()->GetActorLocation();
		bool isPlayingRootMotion = false;
		if (GetOwner()->IsA<AGamePlayer>())
		{
			AGamePlayer * p = Cast<AGamePlayer>(GetOwner());
			isPlayingRootMotion = p->IsPlayingRootMotion();
			vCurPos = p->GetFeetLocation();
			if (p->GetMesh())
			{
				vCurPos = p->GetMeshCenterPos();
			}
		}
		FVector RootSocketPos = vCurPos;
		if (targetComponent.IsValid())
		{
			vCurPos = targetComponent->GetSocketLocation(targetSocket);
			RootSocketPos = targetComponent->GetSocketLocation(baseSocket);
			if (mUseFixedZ)
			{
				float deltaZ = vCurPos.Z - RootSocketPos.Z;
				if (deltaZ < mFixedZ)
				{
					deltaZ = mFixedZ;
				}
				vCurPos.Z = RootSocketPos.Z + deltaZ;
			}
		}
		else
		{
			if (mUseFixedZ)
			{
				vCurPos.Z = vCurPos.Z + mFixedZ;
			}
		}

		AActor * pOwner = GetOwner();
			

		FVector AttachPointWorldPosition = frameWorldOffset + vCurPos;

		// Init mLastWorldPosition
		if (mLastWorldPosition.IsNearlyZero())
		{
			mLastWorldPosition = AttachPointWorldPosition;
		}

		bool bUpdateRootSocketPos = true;

		if (mUseFixedZ)
		{
			FVector deltaPos = RootSocketPos - AttachPointWorldPosition;
			deltaPos.Z = 0;
			float deltaSquaredDisWithLastFrame = (RootSocketPos - mLastRootSocketPos).SizeSquared();
			
			if (deltaPos.SizeSquared() <= 225.f && deltaSquaredDisWithLastFrame <= keepZSquaredDisThreshold && !isPlayingRootMotion)
			{
				bUpdateRootSocketPos = false;
				AttachPointWorldPosition.X = RootSocketPos.X;
				AttachPointWorldPosition.Y = RootSocketPos.Y;
				AttachPointWorldPosition.Z = mLastWorldPosition.Z;
			}
		}

		mLastWorldPosition = AttachPointWorldPosition;
		if (bUpdateRootSocketPos)
		{
			mLastRootSocketPos = RootSocketPos;
		}

		//最后添加view下的偏移(不作用到保存的值)
		ApplyViewOffset(AttachPointWorldPosition);

		FVector2D AttachPointScreenPosition;
		FVector4 NDCSpacePos;
		bool bSuc = PlayerController->ProjectWorldLocationToScreen(AttachPointWorldPosition, AttachPointScreenPosition, false, &NDCSpacePos);

		float Scale = UWidgetLayoutLibrary::GetViewportScale(this);

		bool bVis = pUserWidget->GetVisibility() == ESlateVisibility::SelfHitTestInvisible;
		if (bSuc != bVis)
		{
			if (!bExtra && !mLuaObjRef.IsNoRef() && AAzureEntryPoint::IsInit())
			{
				lua_State_Wrapper L = AAzureEntryPoint::Instance->GetL();
				int nTop = lua_gettop(L);
				lua_rawgeti(L, LUA_REGISTRYINDEX, mLuaObjRef); // t
				lua_getfield(L, -1, "SetVisible"); // t, func
				lua_pushvalue(L, -2); // t, func, t
				lua_pushboolean(L, bSuc); // t, func, t, b
				lua_pushboolean(L, true); // t, func, t, b, b
				AAzureEntryPoint::Instance->GetWLua()->Call(3); // t
				lua_settop(L, nTop);

				//UE_LOG(LogTemp, Log, TEXT("C++ SetVisible %s, %s"), *(GetOwner()->GetName()), *LuaRefToString(mLuaObjRef));
			}
			else
			{
				pUserWidget->SetVisibility(bSuc ? ESlateVisibility::SelfHitTestInvisible : ESlateVisibility::Collapsed);
				//UE_LOG(LogTemp, Log, TEXT("C++ Change Pate Widget To Visible: %d, %s"), bSuc ? 1 : 0, *(GetOwner()->GetName()));
			}
		}
		if (bSuc) {
			AttachPointScreenPosition =	AttachPointScreenPosition + (bExtra ? ExtraScreenOffset : ScreenOffset) * Scale;
			AdjustPointScreenPosition(pUserWidget, AttachPointScreenPosition);
			pUserWidget->SetPositionInViewport(AttachPointScreenPosition);

			if (maxCameraSpaceDepth > 0)
			{
				pUserWidget->SetDepth(FMath::Clamp(1.0f - NDCSpacePos.W / maxCameraSpaceDepth, 0.0f, 1.0f));
			}
			else
			{
				pUserWidget->SetDepth(NDCSpacePos.Z);
			}
		}
	}
}


void UAzurePateComponent::AttachLuaObject()
{
	DetachLuaObject();
	if (AAzureEntryPoint::IsInit())
	{
		lua_State_Wrapper L = AAzureEntryPoint::Instance->GetL();
		lua_pushvalue(L, -1);
		mLuaObjRef = wLua::lua_registry_handle::wlua_ref(L, LUA_REGISTRYINDEX);

		//UE_LOG(LogTemp, Log, TEXT("C++ AttachLuaObject %s, %s"), *(GetOwner()->GetName()), *LuaRefToString(mLuaObjRef));
	}
}

void UAzurePateComponent::DetachLuaObject()
{
	if (!mLuaObjRef.IsNoRef())
	{
		if (AAzureEntryPoint::IsInit())
		{
			lua_State_Wrapper L = AAzureEntryPoint::Instance->GetL();
			wLua::lua_registry_handle::wlua_unref(L, LUA_REGISTRYINDEX, mLuaObjRef);
		}
		//UE_LOG(LogTemp, Log, TEXT("C++ DetachLuaObject %s"), *(GetOwner()->GetName()));
		mLuaObjRef.Clear();
	}
}


