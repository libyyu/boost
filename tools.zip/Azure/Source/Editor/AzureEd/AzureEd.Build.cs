﻿// Fill out your copyright notice in the Description page of Project Settings.

using UnrealBuildTool;
using System.IO;    //  for System.IO.Path

public class AzureEd : ModuleRules
{
	public AzureEd(ReadOnlyTargetRules Target) : base(Target)
	{
        PCHUsage = PCHUsageMode.UseExplicitOrSharedPCHs;

        if(Target.Type == TargetRules.TargetType.Editor)
        {
            PrivateDependencyModuleNames.AddRange(
                new string[]
                {
                    "Core",
                    "CoreUObject",
                    "Engine",
                    "UnrealEd",
                    "Json",
					"Azure",
                    "wLuaCore",
                    "wLuaPlugin",
                    "AzureCore",
                    "AzureEngine",
                    "AzureNetwork",
                    "AzureProfiler"
                });
            
            PublicDependencyModuleNames.AddRange(
                new string[]
                {
                    
                });

            //luajit or lua51, ...
            var luatype = GetLuaModuleType(Target);
            PrivateDependencyModuleNames.Add(luatype);
            System.Console.WriteLine("Module {0} Configuration {1} Platform {2} UseLuaType = {3}", Name, Target.Configuration, Target.Platform, luatype);
        }
	}

    public static string GetLuaModuleType(ReadOnlyTargetRules Target)
    {
        string luaprefix = "LUA_TYPE=";
        foreach (string Definition in Target.ProjectDefinitions)
        {
            if (Definition.StartsWith(luaprefix))
            {
                System.Console.WriteLine("  Project Definition: {0}", Definition);
                string luatype = Definition.Substring(luaprefix.Length);
                if ("0" == luatype)
                    return "AzureLuaJIT";
                else if ("1" == luatype)
                    return "AzureLua51";
                else
                {
                    throw new System.Exception("luatype:" + luatype + "not valid.");
                }
            }
        }
        return "AzureLuaJIT";
    }
}
