﻿// Fill out your copyright notice in the Description page of Project Settings.

#include "AzureEditor.h"
#include "Engine.h"
#include "PropertyEditorModule.h"
#include "IPlacementModeModule.h"

#include "AzureFaceSkeletalMeshActorDetails.h"

#include "GameLogic/Environment/AzureEnvironmentVolume.h"

#include "AzureEnvironmentPresetDetails.h"
#include "GameLogic/Environment/AzureEnvironmentPreset.h"

#include "AzureEnvironmentManagerDetails.h"
#include "GameLogic/Environment/AzureEnvironmentManager.h"

#include "AzureSHAmbientCaptureDetails.h"
#include "AzureSHAmbientCapture.h"
#include "FileHelper.h"

#include"TileCommand.h"
#include"BigWorldCommander.h"

#include "Framework/Notifications/NotificationManager.h"
#include "Widgets/Notifications/SNotificationList.h"
#include "Toolkits/AssetEditorManager.h"
#include <time.h>
#include <string>
#include <locale.h>

void FAzureEditorModule::StartupModule()
{
	IPlacementModeModule::Get().RegisterPlaceableItem("Volume",
		MakeShareable(new FPlaceableItem(nullptr, FAssetData(AAzureEnvironmentVolume::StaticClass()))));

	FPropertyEditorModule& PropertyModule = FModuleManager::LoadModuleChecked<FPropertyEditorModule>("PropertyEditor");
	PropertyModule.RegisterCustomClassLayout(UAzureEnvironmentPreset::StaticClass()->GetFName(),
		FOnGetDetailCustomizationInstance::CreateStatic(&FAzureEnvironmentPresetDetails::MakeInstance));
	PropertyModule.RegisterCustomClassLayout(AAzureEnvironmentManager::StaticClass()->GetFName(),
		FOnGetDetailCustomizationInstance::CreateStatic(&FAzureEnvironmentManagerDetails::MakeInstance));
	PropertyModule.RegisterCustomClassLayout(AAzureSHAmbientCapture::StaticClass()->GetFName(),
		FOnGetDetailCustomizationInstance::CreateStatic(&FAzureSHAmbientCaptureDetails::MakeInstance));


	PropertyModule.RegisterCustomClassLayout(FName(TEXT("Female_Head_Custom_BP_C")),
		FOnGetDetailCustomizationInstance::CreateStatic(&FAzureFaceSkeletalMeshActorDetails::MakeInstance));
	PropertyModule.RegisterCustomClassLayout(FName(TEXT("Male_Head_Custom_BP_C")),
		FOnGetDetailCustomizationInstance::CreateStatic(&FAzureFaceSkeletalMeshActorDetails::MakeInstance));

//	TSharedPtr< FTileLevelCommand> c = MakeShareable(new FTileLevelCommand("Update Spt ShadowFlag",
//	[&](FTileLevelCommand* Command) 
//	{
//		ULevel* Level = Command->PTLevel;
//		UWorld* World = Level ? Level->GetWorld() : nullptr;
//		AAzureEnvironmentManager::UpdateSptShadowFlag(World, Level);
//	}));
//	FTileCommandsManager::Get()->AddCommand("Level", c);
//	FTileCommandsManager::Get()->AddReleasingLevelCommand(c);

// 不检查提示版本了
//	CheckEngineVersion();
}

void FAzureEditorModule::ShutdownModule()
{
	FPropertyEditorModule& PropertyModule = FModuleManager::LoadModuleChecked<FPropertyEditorModule>("PropertyEditor");
	PropertyModule.UnregisterCustomClassLayout(UAzureEnvironmentPreset::StaticClass()->GetFName());
	PropertyModule.UnregisterCustomClassLayout(AAzureEnvironmentManager::StaticClass()->GetFName());
}

enum USER_IDENTITY
{
	User_Unknow = 0,
	User_Programer = 1,
	User_CehuaAndArts = 2,
};

static bool GetWorkingCopyInfo(const FString& url, TMap<FString, FString>& TargetInfo)
{
	FString MyExe = TEXT("svn");
	FString SVNURL;
	FString MyCommand = FString::Printf(TEXT("info %s"), *url);
	int32 ReturnCode;
	FString RoStdOut;
	FPlatformProcess::ExecProcess(*MyExe, *MyCommand, &ReturnCode, &RoStdOut, nullptr);
	if (ReturnCode != 0)
	{
		//UE_LOG(LogAzure, Error, TEXT("Failed to get svn info."));
		return false;
	}
	// separate out each line
	TArray<FString> OutStrings;
	RoStdOut = RoStdOut.Replace(TEXT("\r\n"), TEXT("\n"));
	RoStdOut.ParseIntoArray(OutStrings, TEXT("\n"), true);
	for (TArray<FString>::TConstIterator It(OutStrings); It; ++It)
	{
		TArray<FString> LineStrings;
		It->ParseIntoArray(LineStrings, TEXT(": "), true);
		if (LineStrings.Num() > 0)
		{
			TargetInfo.Add(LineStrings[0], LineStrings.Num() > 1 ? LineStrings[1] : TEXT(""));
		}
	}

	return true;
}

static USER_IDENTITY GetUserIdentity()
{
	TMap<FString, FString> TargetInfo;
	if (GetWorkingCopyInfo(FPaths::GetProjectFilePath(), TargetInfo))
	{
		const FString key = TEXT("Repository Root");
		FString* pRepositoryRoot = TargetInfo.Find(key);
		if (pRepositoryRoot)
		{
			if (-1 != pRepositoryRoot->Find(TEXT("client")))
			{
				return User_Programer;
			}
			else if (-1 != pRepositoryRoot->Find(TEXT("art")))
			{
				return User_CehuaAndArts;
			}
		}
	}

	return User_Unknow;
}

void GetTimeNow(int& year, int& month, int& day)
{
	time_t t = time(NULL);
	struct tm* tnow = localtime(&t);
	year = tnow->tm_year; //n+1900
	month = tnow->tm_mon; //0-11
	day = tnow->tm_mday;//1-31
}
static TSharedPtr<SNotificationItem> EditorVersionUpdateNotification;
static void RunUpdateEditorNotification(const FString& text, const FString& batchFile)
{
	/** Utility functions for the notification which don't rely on the state from FAssetEditorManager */
	struct Local
	{
		static ECheckBoxState GetDontAskAgainCheckBoxState()
		{
			bool bSuppressNotification = false;
			FString sValue;
			if (!GConfig->GetString(TEXT("EditorVersionUpdate"), TEXT("SuppressRestorePreviouslyEditorVersionUpdateNotification"), sValue, GEditorPerProjectIni))
				return ECheckBoxState::Unchecked;
			
			if (!sValue.IsEmpty())
			{
				TArray<FString> OutArr;
				sValue.ParseIntoArray(OutArr, TEXT("."), true);

				if (OutArr.Num() >= 3)
				{
					int year = FCString::Atoi(*(OutArr[0]));
					int month = FCString::Atoi(*(OutArr[1]));
					int day = FCString::Atoi(*(OutArr[2]));

					int t_year, t_monty, t_day;
					GetTimeNow(t_year, t_monty, t_day);
					if (t_year == year && t_monty == month && t_day == day)
					{
						return ECheckBoxState::Checked;
					}
				}	
			}
			
			return ECheckBoxState::Unchecked;
		}

		static void OnDontAskAgainCheckBoxStateChanged(ECheckBoxState NewState)
		{
			const bool bSuppressNotification = (NewState == ECheckBoxState::Checked);
			if (bSuppressNotification)
			{
				int t_year, t_monty, t_day;
				GetTimeNow(t_year, t_monty, t_day);
				FString sValue = FString::Printf(TEXT("%d.%d.%d"), t_year, t_monty, t_day);
				GConfig->SetString(TEXT("EditorVersionUpdate"), TEXT("SuppressRestorePreviouslyEditorVersionUpdateNotification"), *sValue, GEditorPerProjectIni);
			}
			else
			{
				GConfig->SetString(TEXT("EditorVersionUpdate"), TEXT("SuppressRestorePreviouslyEditorVersionUpdateNotification"), TEXT(""), GEditorPerProjectIni);
			}
		}

		static void OnOk(FString batchFile)
		{
			//先关闭
			if (EditorVersionUpdateNotification.IsValid())
			{
				EditorVersionUpdateNotification->SetExpireDuration(0.0f);
				EditorVersionUpdateNotification->SetFadeOutDuration(0.5f);
				EditorVersionUpdateNotification->ExpireAndFadeout();
			}

			//FString rootPath = FPaths::RootDir();
			//if (FMessageDialog::Open(EAppMsgType::YesNo, FText::FromString(text)) == EAppReturnType::Yes)
			{
				putenv("RUN_BY_UE4EDITOR=true");
				putenv("RUN_BY_UE4EDITOR_LAUNCH=true");
				uint32 processId = FPlatformProcess::GetCurrentProcessId();
				std::string pids = std::string("UE_PID=") + std::to_string(processId);
				putenv(pids.c_str());
				FString fprojPath = FPaths::GetProjectFilePath();

				FString rootPath = FPaths::ConvertRelativePathToFull(FPaths::RootDir());
				//FString batchFile = FPaths::ConvertRelativePathToFull(FPaths::ProjectDir()) / TEXT("svn-dll.bat");
				FString ue4Editor = rootPath / TEXT("Engine\\Binaries\\Win64\\UE4Editor.exe");
				TArray<FString> InParameters;
				InParameters.Add(TEXT("/c"));
				InParameters.Add(batchFile);
				InParameters.Add(ue4Editor);
				InParameters.Add(fprojPath);

				FString FullParameters;
				for (int32 Index = 0; Index < InParameters.Num(); Index++)
				{
					FullParameters += InParameters[Index];
					if (Index < InParameters.Num() - 1)
						FullParameters += TEXT(" ");
				}

				uint32 ProcessID = 0;
				uint32* ProcessIDPoint = &ProcessID;
				int32 PriotyModify = 0;
				FProcHandle ProcessHandle = FWindowsPlatformProcess::CreateProc(TEXT("cmd.exe"), *FullParameters, true, false, false, ProcessIDPoint, PriotyModify, nullptr, nullptr, nullptr);

				//FPlatformMisc::RequestExit(1);
			}
		}

		static void OnCancle()
		{
			if (EditorVersionUpdateNotification.IsValid())
			{
				EditorVersionUpdateNotification->SetExpireDuration(0.0f);
				EditorVersionUpdateNotification->SetFadeOutDuration(0.5f);
				EditorVersionUpdateNotification->ExpireAndFadeout();
			}
		}
	};

	//今日不再提示
	if (Local::GetDontAskAgainCheckBoxState() == ECheckBoxState::Checked)
	{
		return;
	}

	FNotificationInfo Info(FText::FromString(text));

	// Add the buttons
	Info.ButtonDetails.Add(FNotificationButtonInfo(
		FText::FromString(TEXT("立即更新")),
		FText::FromString(TEXT("退出编辑器，更新到最新， 请注意保存数据")),
		FSimpleDelegate::CreateStatic(&Local::OnOk, batchFile),
		SNotificationItem::CS_None
	));
	Info.ButtonDetails.Add(FNotificationButtonInfo(
		FText::FromString(TEXT("暂不更新")),
		FText(),
		FSimpleDelegate::CreateStatic(&Local::OnCancle),
		SNotificationItem::CS_None
	));

	// We will let the notification expire automatically after 10 seconds
	Info.bFireAndForget = false;
	Info.ExpireDuration = 10.0f;

	// We want the auto-save to be subtle
	Info.bUseLargeFont = false;
	Info.bUseThrobber = false;
	Info.bUseSuccessFailIcons = false;

	// Only let the user suppress the non-crash version
	{
		Info.CheckBoxState = TAttribute<ECheckBoxState>::Create(&Local::GetDontAskAgainCheckBoxState);
		Info.CheckBoxStateChanged = FOnCheckStateChanged::CreateStatic(&Local::OnDontAskAgainCheckBoxStateChanged);
		Info.CheckBoxText = FText::FromString(TEXT("今日不再提示"));
	}

	EditorVersionUpdateNotification = FSlateNotificationManager::Get().AddNotification(Info);
}


void FAzureEditorModule::CheckEngineVersion()
{
	FString rootPath = FPaths::RootDir();
	UE_LOG(LogTemp, Log, TEXT("UE4Engine Root Path Is %s"), *rootPath);
	//FString localVersionFile = FPaths::Combine(rootPath, TEXT("ue4.version"));
	//if (!FPaths::FileExists(localVersionFile))
	//{
	//	return;
	//}
	//FString OutFileContents;
	//if (!FFileHelper::LoadFileToString(OutFileContents, *localVersionFile))
	//{
	//	UE_LOG(LogTemp, Log, TEXT("Failed Load File %s"), *localVersionFile);
	//	return;
	//}
	//OutFileContents.TrimStartAndEndInline();
	//int32 localVersion = FCString::Atoi(*OutFileContents);

	//FString remotePath = TEXT("//10.236.100.65/CommonShare/software/UE4_Editor/Editor");
	//UE_LOG(LogTemp, Log, TEXT("Remote UE4Engine Root Path Is %s"), *remotePath);
	//FString remoteVersionFile = FPaths::Combine(remotePath, TEXT("ue4.version"));
	//if (!FPaths::FileExists(remoteVersionFile))
	//{
	//	return;
	//}
	//FString OutFileContents2;
	//if (!FFileHelper::LoadFileToString(OutFileContents2, *remoteVersionFile))
	//{
	//	UE_LOG(LogTemp, Log, TEXT("Failed Load File %s"), *remoteVersionFile);
	//	return;
	//}
	//OutFileContents2.TrimStartAndEndInline();
	//int32 remoteVersion = FCString::Atoi(*OutFileContents2);

	int32 localVersion = -1;
	int32 remoteVersion = -1;
	TMap<FString, FString> TargetInfo;
	if (GetWorkingCopyInfo(rootPath, TargetInfo))
	{
		const FString* pRev = TargetInfo.Find(TEXT("Last Changed Rev"));
		if (pRev)
		{
			FString v = *pRev;
			v.TrimStartAndEndInline();
			localVersion = FCString::Atoi(*v);

			FString* pURL = TargetInfo.Find(TEXT("URL"));
			if (pURL)
			{
				FString HostUrl = *pURL;
				TargetInfo.Empty();
				if (GetWorkingCopyInfo(HostUrl, TargetInfo))
				{
					const FString* pRev2 = TargetInfo.Find(TEXT("Last Changed Rev"));
					if (pRev2)
					{
						FString v2 = *pRev2;
						v2.TrimStartAndEndInline();
						remoteVersion = FCString::Atoi(*v2);
					}
				}
			}
		}
	}


	if (localVersion < remoteVersion)
	{
		USER_IDENTITY role = GetUserIdentity();
		FString programerBatchFile = FPaths::Combine(rootPath, TEXT("开发人员更新（带PDB）.bat"));
		FString artBatchFile = FPaths::Combine(rootPath, TEXT("策划美术人员更新（无PDB）.bat"));
		FString batchFile;
		if (role == User_Programer)
		{
			if (FPaths::FileExists(programerBatchFile))
				batchFile = programerBatchFile;
		}
		else if (role == User_CehuaAndArts)
		{
			if (FPaths::FileExists(artBatchFile))
				batchFile = artBatchFile;
		}
		
		FString text; 
		if(!batchFile.IsEmpty())
			text = FString::Printf(TEXT("UE4Engine版本不匹配，当前本地版本%d, 服务器版本%d。\n是否更到最新？"), localVersion, remoteVersion);
		else
			text = FString::Printf(TEXT("UE4Engine版本不匹配，当前本地版本%d, 服务器版本%d。"), localVersion, remoteVersion);
		//提示
		if (!batchFile.IsEmpty())
		{
			RunUpdateEditorNotification(text, batchFile);
		}
	}
}

IMPLEMENT_MODULE(FAzureEditorModule, AzureEditor);
DEFINE_LOG_CATEGORY(LogAzure);
