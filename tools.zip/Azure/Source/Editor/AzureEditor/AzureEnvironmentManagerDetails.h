﻿// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Input/Reply.h"
#include "IDetailCustomization.h"

class IDetailLayoutBuilder;
class UAzureEnvironmentPreset;

class FAzureEnvironmentManagerDetails : public IDetailCustomization
{
public:
	/** Makes a new instance of this detail layout class for a specific detail view requesting it */
	static TSharedRef<IDetailCustomization> MakeInstance();

	/** IDetailCustomization interface */
	virtual void CustomizeDetails(IDetailLayoutBuilder& DetailBuilder) override;

	/** Handle clicking the load button */
	FReply ClickedOnApplyPresetButton();

	/** Handle clicking the load button */
	FReply ClickedOnDumpEnvironmentButton();

	/** Handle clicking the load button */
	FReply ClickedOnUpdateSptShadowFlagButton();

	/** Handle clicking the load button */
	FReply ClickedOnClearSptShadowFlagButton();

	/** Cached array of selected objects */
	TArray< TWeakObjectPtr<UObject> > SelectedObjectsList;
};
