// Fill out your copyright notice in the Description page of Project Settings.

using UnrealBuildTool;
using System.IO;    //  for System.IO.Path

public class AzureEditor : ModuleRules
{
	public AzureEditor(ReadOnlyTargetRules Target) : base(Target)
	{
        PCHUsage = PCHUsageMode.UseExplicitOrSharedPCHs;
		
		PrivateIncludePaths.AddRange(
			new string[] {
				"Azure"
			}
		    );
		
        PublicDependencyModuleNames.AddRange(
			new string[] {
				"Core",
				"CoreUObject",
				"Engine",
				"InputCore",
				"UMG",
				"XmlParser",
				"UMGCustom",
				"MovieScene",
				"LevelSequence",
				"MovieSceneTracks",
				"HTTP",
				"SlateRHIRenderer",
				"AIModule",
				"Renderer",
				"RenderCore",
				"RHI",
				"UtilityShaders",
				"Motor",
				"ApplicationCore",
				"Http",
				"Json",
				"JsonUtilities",
				"PhysXVehicles",
				"AkAudio",
                "UnrealEd",
                "Azure"
            }
			);
			
		PrivateDependencyModuleNames.AddRange(
			new string[] {
				"Slate",
				"SlateCore",
				"CGRuntimeX",
                "Engine", 
				"AndroidPermission",
				"TCos",
				//"GEM",
				"AkAudio",
				"PlacementMode",
                "BigWorldCommander"
            }
			);
	}
}
