#pragma once

#include "CoreMinimal.h"
#include "Input/Reply.h"
#include "SSlider.h"
#include "IDetailCustomization.h"

class IDetailLayoutBuilder;
struct FSlateMaterialBrush;

class SAzureNonThrottledSlider :public SSlider
{
	virtual FReply OnMouseButtonDown(const FGeometry& MyGeometry, const FPointerEvent& MouseEvent) override
	{
		FReply Reply = SSlider::OnMouseButtonDown(MyGeometry, MouseEvent);
		if (Reply.IsEventHandled())
		{
			Reply.PreventThrottling();
		}
		return Reply;
	}

public:
	void SetValueAndUpdate(float NewValue) 
	{
		CommitValue(NewValue);
	}
};

class FAzureFaceSkeletalMeshActorDetails : public IDetailCustomization
{
public:
	/** Makes a new instance of this detail layout class for a specific detail view requesting it */
	static TSharedRef<IDetailCustomization> MakeInstance();

	/** IDetailCustomization interface */
	virtual void CustomizeDetails(IDetailLayoutBuilder& DetailBuilder) override;

	~FAzureFaceSkeletalMeshActorDetails();


private: 
	TArray< TWeakObjectPtr<UObject> > SelectedObjectsList;

	TArray<FSlateMaterialBrush*> AllBrushes;
	TArray<UMaterialInstanceDynamic*> AllMats;

	
};