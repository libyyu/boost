// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "AzureLightParamsReplace.generated.h"

UCLASS()
class AAzureLightParamReplace : public AActor
{
	GENERATED_BODY()

public:

	AAzureLightParamReplace();

	virtual void Tick(float DeltaTime) override;

	virtual bool ShouldTickIfViewportsOnly() const;

	virtual void BeginDestroy() override;

	UPROPERTY(EditAnywhere, Category = "Directional Light")
	bool bReplaceDirectionalLight;

	UPROPERTY(EditAnywhere, Category = "Directional Light")
	FVector DirectionalLightDir;

	UPROPERTY(EditAnywhere, Category = "Directional Light")
	FLinearColor DirectionalLightColor;

	UPROPERTY(EditAnywhere, Category = "Indirect Light")
	bool bReplaceIndirectLight;

	UPROPERTY(EditAnywhere, Category = "Indirect Light")
	FVector4 IndirectLightSHCoefficients[8];

private:

	void ApplySettings(bool bInReplaceDirectionalLight, bool bInReplaceIndirectLight, bool bForce = false);
};
