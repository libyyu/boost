﻿// Fill out your copyright notice in the Description page of Project Settings.

// #include "AzureEnvironmentPresetFactory.h"
// #include "GameLogic/DynamicSky/AzureEnvironmentManager.h"
// 
// 
// UAzureEnvironmentPresetFactory::UAzureEnvironmentPresetFactory(const FObjectInitializer& ObjectInitializer)
// 	: Super(ObjectInitializer)
// {
// 	bCreateNew = true;
// 	bEditAfterNew = true;
// 	SupportedClass = UAzureEnvironmentPreset::StaticClass();
// }
// 
// UObject* UAzureEnvironmentPresetFactory::FactoryCreateNew(UClass* InClass, UObject* InParent, FName InName, EObjectFlags Flags, UObject* Context, FFeedbackContext* Warn)
// {
// 	return NewObject<UAzureEnvironmentPreset>(InParent, InClass, InName, Flags);
// }
