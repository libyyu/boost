﻿// Fill out your copyright notice in the Description page of Project Settings.

#include "AzureEnvironmentPresetDetails.h"
#include "GameLogic/Environment/AzureEnvironmentPreset.h"

#include "AssetRegistryModule.h"
#include "DetailLayoutBuilder.h"
#include "DetailWidgetRow.h"
#include "DetailCategoryBuilder.h"
#include "IDetailsView.h"
#include "EditorSupportDelegates.h"

#define LOCTEXT_NAMESPACE "AzureEnvironmentPresetDetails"

TSharedRef<IDetailCustomization> FAzureEnvironmentPresetDetails::MakeInstance()
{
	return MakeShareable(new FAzureEnvironmentPresetDetails);
}

void FAzureEnvironmentPresetDetails::CustomizeDetails(IDetailLayoutBuilder& DetailBuilder)
{
	IDetailCategoryBuilder& Category = DetailBuilder.EditCategory("Edit");

	// Cache set of selected things
	SelectedObjectsList = DetailBuilder.GetSelectedObjects();

	Category.AddProperty("ResourceDirectory");

	Category.AddCustomRow(LOCTEXT("AutoFill", "AutoFill"), false)
		.NameContent()
		[
			SNullWidget::NullWidget
		]
		.ValueContent()
		.VAlign(VAlign_Center)
		.MaxDesiredWidth(250)
		[
			SNew(SButton)
			.VAlign(VAlign_Center)
			.OnClicked(this, &FAzureEnvironmentPresetDetails::ClickedOnAutoFillButton)
			.Content()
			[
				SNew(STextBlock)
				.Text(LOCTEXT("AutoFill", "AutoFill"))
			]
		];
}

FReply FAzureEnvironmentPresetDetails::ClickedOnAutoFillButton()
{
	UAzureEnvironmentPreset* Preset = nullptr;
	for (const TWeakObjectPtr<UObject>& Object : SelectedObjectsList)
	{
		Preset = Cast<UAzureEnvironmentPreset>(Object.Get());
		break;
	}

	if (Preset == nullptr)
		return FReply::Handled();

	FString FilePath = Preset->ResourceDirectory;
	if (FilePath.Len() == 0)
	{
		FMessageDialog::Open(EAppMsgType::Ok, FText::FromString(TEXT("Invalid resource directory!")));
		return FReply::Handled();
	}

	if (FilePath[0] != '/')
		FilePath = FString("/").Append(FilePath);

	if (FilePath[FilePath.Len() - 1] == '/')
		FilePath = FilePath.Left(FilePath.Len() - 1);

	FAssetRegistryModule& AssetRegistryModule = FModuleManager::LoadModuleChecked<FAssetRegistryModule>("AssetRegistry");
	TArray<FAssetData> AssetDataList;
	AssetRegistryModule.Get().GetAssetsByPath(*FilePath, AssetDataList, true);
	
	if (AssetDataList.Num() == 0)
	{
		FMessageDialog::Open(EAppMsgType::Ok, FText::FromString(TEXT("Target directory is empty!")));
		return FReply::Handled();
	}

	for (TFieldIterator<UProperty> PropIt(Preset->GetClass()); PropIt; ++PropIt)
	{
		if (PropIt->IsA(UBoolProperty::StaticClass()))
		{
			UBoolProperty* BoolProp = Cast<UBoolProperty>(*PropIt);
			BoolProp->SetPropertyValue_InContainer(Preset, false);
		}
		else if (PropIt->IsA(UObjectProperty::StaticClass()))
		{
			UObjectProperty* ObjectProp = Cast<UObjectProperty>(*PropIt);
			ObjectProp->SetPropertyValue_InContainer(Preset, nullptr);
		}
	}

	bool bError = false;
	FString Message = TEXT("Invalid resource name!\n");

	for (int32 AssetIdx = 0; AssetIdx < AssetDataList.Num(); AssetIdx++)
	{
		FAssetData& AssetData = AssetDataList[AssetIdx];
		FString AssetName;
		AssetData.AssetName.ToString(AssetName);

		int32 BeginIndex = -1;
		int32 EndIndex = -1;
		if (!AssetName.FindChar('_', BeginIndex) || !AssetName.FindLastChar('_', EndIndex) || BeginIndex == EndIndex)
		{
			bError = true;
			TArray<FStringFormatArg> FormatArgList;
			FormatArgList.Add(AssetName);
			Message += FString::Format(TEXT("\t{0}\n"), FormatArgList);
			continue;
		}

		FString PropertyName = AssetName.Mid(BeginIndex + 1, EndIndex - BeginIndex - 1);
		FString BoolName = "b" + PropertyName;
		FString CurveName = PropertyName + "Curve";

		bool bFoundProperty = false;
		for (TFieldIterator<UProperty> PropIt(Preset->GetClass()); PropIt; ++PropIt)
		{
			if (PropIt->IsA(UBoolProperty::StaticClass()) && PropIt->GetName() == BoolName)
			{
				bFoundProperty = true;
				UBoolProperty* BoolProp = Cast<UBoolProperty>(*PropIt);
				BoolProp->SetPropertyValue_InContainer(Preset, true);
			}
			else if (PropIt->IsA(UObjectProperty::StaticClass()) && PropIt->GetName() == CurveName)
			{
				UObjectProperty* ObjectProp = Cast<UObjectProperty>(*PropIt);
				UObject* Resource = AssetData.GetAsset();
				ObjectProp->SetPropertyValue_InContainer(Preset, Resource);
			}
		}

		if (!bFoundProperty)
		{
			bError = true;
			TArray<FStringFormatArg> FormatArgList;
			FormatArgList.Add(AssetName);
			Message += FString::Format(TEXT("\t{0}\n"), FormatArgList);
			continue;
		}
	}

	if (bError)
	{
		FMessageDialog::Open(EAppMsgType::Ok, FText::FromString(Message));
		return FReply::Handled();
	}

	FEditorSupportDelegates::RedrawAllViewports.Broadcast();

	return FReply::Handled();
}

#undef LOCTEXT_NAMESPACE
