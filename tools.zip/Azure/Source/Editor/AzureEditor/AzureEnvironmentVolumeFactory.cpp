﻿// Fill out your copyright notice in the Description page of Project Settings.

// #include "AzureEnvironmentVolumeFactory.h"
// #include "GameLogic/DynamicSky/AzureEnvironmentVolume.h"
// 
// 
// UAzureEnvironmentVolumeFactory::UAzureEnvironmentVolumeFactory(const FObjectInitializer& ObjectInitializer)
// 	: Super(ObjectInitializer)
// {
// 	bCreateNew = true;
// 	bEditAfterNew = true;
// 	SupportedClass = AAzureEnvironmentVolume::StaticClass();
// }
// 
// UObject* UAzureEnvironmentVolumeFactory::FactoryCreateNew(UClass* InClass, UObject* InParent, FName InName, EObjectFlags Flags, UObject* Context, FFeedbackContext* Warn)
// {
// 	return NewObject<AAzureEnvironmentVolume>(InParent, InClass, InName, Flags);
// }
