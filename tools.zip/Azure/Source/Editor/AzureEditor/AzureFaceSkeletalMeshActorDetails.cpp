#include "AzureFaceSkeletalMeshActorDetails.h"

#include "AssetRegistryModule.h"
#include "DetailLayoutBuilder.h"
#include "DetailCategoryBuilder.h"
#include "DetailWidgetRow.h"
#include "SButton.h"
#include "SBox.h"
#include "SImage.h"
#include "STextBlock.h"
#include "SNumericDropDown.h"
#include "SlateMaterialBrush.h"
#include "Materials/MaterialInstanceDynamic.h"
#include "UnrealType.h"
#include "WeakObjectPtrTemplates.h"
#include "Engine/UserDefinedStruct.h"
#include "Editor.h"
#include "Engine/Classes/Engine/DataTable.h"
#include "SSpinBox.h"
#include "EditorSupportDelegates.h"

#define LOCTEXT_NAMESPACE "AzureFaceSkeletalMeshActorDetails"

TSharedRef<IDetailCustomization> FAzureFaceSkeletalMeshActorDetails::MakeInstance()
{
	return MakeShareable(new FAzureFaceSkeletalMeshActorDetails);
}

//MID;
bool isMouseButtonDown;

void FAzureFaceSkeletalMeshActorDetails::CustomizeDetails(IDetailLayoutBuilder& DetailBuilder)
{
	SelectedObjectsList=DetailBuilder.GetSelectedObjects();
	UClass* FaceClass = SelectedObjectsList[0]->GetClass();
	void* StructAddress=nullptr;//first obj param address
	UStructProperty* FaceProp=nullptr;
	TMap<FString,FString> AllName;
	TMap<FString,TArray<FString>> SingleName;
	UDataTable* LocalData=nullptr;
	for (UProperty* Property=FaceClass->PropertyLink;Property;Property=Property->PropertyLinkNext)
	{
		if (Property->GetName() == TEXT("FaceData")) {
			FaceProp=Cast<UStructProperty>(Property);
			StructAddress = Property->ContainerPtrToValuePtr<void>(SelectedObjectsList[0].Get());
			for (UProperty* SProperty = FaceProp->Struct->PropertyLink; SProperty; SProperty = SProperty->PropertyLinkNext) {
				FString PropShotName;
				FString NotUse;
				SProperty->GetName().Split(TEXT("_"), &PropShotName, &NotUse);
				AllName.Add(PropShotName,SProperty->GetName());
			}
			for(auto CurName : AllName)
			{
				FString FullName = CurName.Value;
				FString ShowName = CurName.Key;
				ShowName.RemoveAt(ShowName.Len() - 1, 1);
				bool cp = (CurName.Key.EndsWith(TEXT("H"), ESearchCase::CaseSensitive) && AllName.Contains(ShowName + TEXT("V"))) ||
					(CurName.Key.EndsWith(TEXT("V"), ESearchCase::CaseSensitive) && AllName.Contains(ShowName + TEXT("H")));
				if(cp)
				{
					FString NameHead = ShowName;
					ShowName.Append(TEXT("_C"));
					if(!SingleName.Contains(ShowName))
						SingleName.Add(ShowName, { AllName[NameHead + TEXT("H")],
							AllName[NameHead +TEXT("V")]});
				}
				else
				{
					SingleName.Add(CurName.Key, { FullName });
				}
			}
			//break;
		}
		else if (Property->GetName() == TEXT("FaceLocalData"))
		{
			UObjectProperty* prop = Cast<UObjectProperty>(Property);
			void* UObjAddress = prop->ContainerPtrToValuePtr<void>(SelectedObjectsList[0].Get());
			UObject* dt = prop->GetPropertyValue(UObjAddress);
			if (dt) {
				LocalData = Cast<UDataTable>(dt);
			//	UE_LOG(LogTemp, Log, TEXT("Localdata:%s"), *LocalData->GetRowStruct()->GetFName().ToString());
			}
			else
			{
				UE_LOG(LogTemp, Warning, TEXT("no cumstom data, all will be zero!"));
			}
		}
	}
	IDetailCategoryBuilder& Category = DetailBuilder.EditCategory("CustomFace");
	UMaterialInterface* mat = LoadObject<UMaterialInterface>(nullptr, TEXT("/Game/TA/Materials/Tools/M_XYSlider.M_XYSlider"));

	struct SSenderData
	{
		SWidget* MyWidegt;
		float* BlueprintData;
		UMaterialInstanceDynamic* Mat;
		bool Hor;

		SSenderData(SWidget* wid, float* data, UMaterialInstanceDynamic* mat,bool hor) {
			MyWidegt = wid;
			BlueprintData = data;
			Mat = mat;
			Hor = hor;
		}
	};
	TMap<FString, SSenderData> AllPropWidgets;
	for (auto PropName : SingleName) {
		if (PropName.Key.EndsWith("_C")) 
		{
			FString ShowName = PropName.Key;
			ShowName.RemoveAt(PropName.Key.Len() - 2, 2);
			UProperty* ph = FaceProp->Struct->FindPropertyByName(FName(*(PropName.Value[0])));
			void* floatptrh = ph->ContainerPtrToValuePtr<void>(StructAddress);
			float* curvalueh = (float*)floatptrh;
			UProperty* pv = FaceProp->Struct->FindPropertyByName(FName(*(PropName.Value[1])));
			void* floatptrv = pv->ContainerPtrToValuePtr<void>(StructAddress);
			float* curvaluev = (float*)floatptrv;
			UMaterialInstanceDynamic* MID = UMaterialInstanceDynamic::Create(mat, nullptr);
			FSlateMaterialBrush* brush =new FSlateMaterialBrush(*MID, FVector2D(300, 300));
			//mat->AddToRoot();
			MID->AddToRoot();
			AllBrushes.Add(brush);
			AllMats.Add(MID);
			MID->SetVectorParameterValue("PosScale", FLinearColor((*curvalueh +1)/2, 1-(*curvaluev +1)/2, 0.1, 0.1));
			TSharedRef<SWidget> valueUI = SNew(SBorder).BorderImage(brush)
				.OnMouseMove_Lambda([MID, curvalueh, curvaluev](const FGeometry& geo, const FPointerEvent& po)->FReply {
				if (po.IsMouseButtonDown(EKeys::LeftMouseButton)) {
					FVector2D CursorPos = po.GetScreenSpacePosition();
					CursorPos = geo.AbsoluteToLocal(CursorPos);
					CursorPos /= geo.Size;
					MID->SetVectorParameterValue("PosScale", FLinearColor(CursorPos.X, CursorPos.Y, 0.1, 0.1));
					*curvalueh = (CursorPos.X - 0.5) * 2;
					*curvaluev = (0.5 - CursorPos.Y) * 2;
				}
				FReply rep = FReply::Handled();
				rep.PreventThrottling();
				return rep;
			}).OnMouseButtonDown_Lambda([](const FGeometry& geo, const FPointerEvent& po)->FReply {
				FReply rep = FReply::Handled();
				rep.PreventThrottling();
				return rep;
			});
			Category.AddCustomRow(FText::FromString(ShowName), false)
				.NameContent()
				[
					SNew(STextBlock).Text(FText::FromString(ShowName))
				]
				.ValueContent()
				.VAlign(VAlign_Center)
				.MinDesiredWidth(80)
				[
					SNew(SBox).HeightOverride(80).WidthOverride(80)[
						valueUI
					]
				];
			AllPropWidgets.Add(PropName.Value[0], SSenderData(&valueUI.Get(), curvalueh,MID,true));
			AllPropWidgets.Add(PropName.Value[1], SSenderData(&valueUI.Get(), curvaluev, MID,false));
		}
		else
		{
			UProperty* p = FaceProp->Struct->FindPropertyByName(FName(*(PropName.Value[0])));
			void* floatptr = p->ContainerPtrToValuePtr<void>(StructAddress);
			float* curvalue = (float*)floatptr;
			TSharedRef<SWidget> valueUI = SNew(SAzureNonThrottledSlider).Value((*curvalue + 1) / 2).OnValueChanged_Lambda([curvalue, StructAddress](float newvalue) {
				*curvalue = (newvalue - 0.5) * 2;
			});
			Category.AddCustomRow(FText::FromString(PropName.Key),false)
			.NameContent()
			[
				SNew(STextBlock).Text(FText::FromString(PropName.Key))
			]
			.ValueContent()
			.VAlign(VAlign_Center)
			.MaxDesiredWidth(250)
			[
				valueUI
			];
			AllPropWidgets.Add(PropName.Value[0], SSenderData(&valueUI.Get(), curvalue, nullptr,false));
		}
	}
	TSharedRef<SEditableTextBox> configname = SNew(SEditableTextBox).Text(FText::FromString(TEXT("Default")));
	Category.AddCustomRow(FText::FromString(TEXT("LocalData")), false)
	.NameContent()
	[
		SNew(STextBlock).Text(FText::FromString(TEXT("ConfigName")))
	].ValueContent()
	[
		configname
	];
	Category.AddCustomRow(FText::FromString(TEXT("LocalDataButton")), false)
	.NameContent()
	[
		SNew(SButton).Text(FText::FromString(TEXT("Load"))).OnClicked_Lambda([AllPropWidgets,LocalData, configname]() {
		if (LocalData) {
			uint8* const* RowDataPtr = LocalData->GetRowMap().Find(FName(*configname->GetText().ToString()));
			
			if (RowDataPtr) {
				uint8* RowData = *RowDataPtr;
				const UScriptStruct* stt = LocalData->GetRowStruct();
				for (UProperty* Property = stt->PropertyLink; Property; Property = Property->PropertyLinkNext) {
					void* floatptrh = Property->ContainerPtrToValuePtr<void>((void*)RowData);
					float* curvalueh = (float*)floatptrh;
					if (AllPropWidgets.Contains(Property->GetName()))
					{
						//UE_LOG(LogTemp, Log, TEXT("%s"), *AllPropWidgets[Property->GetName()]->GetType().ToString());
						SSenderData MyData = AllPropWidgets[Property->GetName()];
						if (MyData.MyWidegt->GetType() == FName("SBorder"))
						{
							*MyData.BlueprintData = *curvalueh;
							FMaterialParameterInfo info;
							info.Name = "PosScale";
							FLinearColor CurData;
							MyData.Mat->GetVectorParameterValue(info, CurData);
							if (MyData.Hor) 
							{
								CurData.R = (*curvalueh + 1) / 2;
							}
							else 
							{
								CurData.G = 1 - (*curvalueh + 1) / 2;
							}
							MyData.Mat->SetVectorParameterValue("PosScale", CurData);
						}
						else if (MyData.MyWidegt->GetType() == FName("SAzureNonThrottledSlider"))
						{
							SAzureNonThrottledSlider* slider = (SAzureNonThrottledSlider*)MyData.MyWidegt;
							slider->SetValueAndUpdate((*curvalueh + 1) / 2);
						}
					}
					else
					{
						UE_LOG(LogTemp, Error, TEXT("given datatable is not march struct please check!!!"));
						break;
					}
				}
			}
			else 
			{
				UE_LOG(LogTemp, Error, TEXT("cant find row named: %s"),*configname->GetText().ToString());
			}
		}
		else
		{
			UE_LOG(LogTemp, Error, TEXT("DataTable is null ,so nothing will be load!"));
		}
		return FReply::Handled();
		})
	].ValueContent()
	[
		SNew(SButton).Text(FText::FromString(TEXT("Save"))).OnClicked_Lambda([AllPropWidgets, LocalData, configname]() {
			if (LocalData) 
			{
				uint8* const* RowDataPtr = LocalData->GetRowMap().Find(FName(*configname->GetText().ToString()));
				
				if (RowDataPtr) {
					uint8* RowData = *RowDataPtr;
					const UScriptStruct* stt = LocalData->GetRowStruct();
					bool success=true;
					for (UProperty* Property = stt->PropertyLink; Property; Property = Property->PropertyLinkNext) {
						void* floatptrh = Property->ContainerPtrToValuePtr<void>((void*)RowData);
						float* curvalueh = (float*)floatptrh;
						if (AllPropWidgets.Contains(Property->GetName()))
						{
							//UE_LOG(LogTemp, Log, TEXT("%s"), *AllPropWidgets[Property->GetName()]->GetType().ToString());
							SSenderData MyData = AllPropWidgets[Property->GetName()];
							*curvalueh = *MyData.BlueprintData;
						}
						else
						{
							success = false;
							UE_LOG(LogTemp, Error, TEXT("given datatable is not march struct please check!!!"));
							break;
						}
					}
					if (success)
					{
						UPackage* dataPack = LocalData->GetOutermost();
						FString packagePath = dataPack->GetFName().ToString();
						packagePath.RemoveAt(0, 6);
						FString savename = FPaths::ProjectContentDir() / packagePath + TEXT(".uasset");
						UPackage::SavePackage(dataPack, nullptr, EObjectFlags::RF_Public | EObjectFlags::RF_Standalone,*savename);
						FEditorSupportDelegates::RedrawAllViewports.Broadcast();
					}
				}
				else
				{
					UE_LOG(LogTemp, Error, TEXT("cant find row named: %s"), *configname->GetText().ToString());
				}
			}
			else
			{
				UE_LOG(LogTemp, Error, TEXT("DataTable is null ,so nothing will be save!"));
			}
			return FReply::Handled();
		})
	];
}

FAzureFaceSkeletalMeshActorDetails::~FAzureFaceSkeletalMeshActorDetails()
{
	for (auto brush : AllBrushes) {
		delete brush;
	}
	for (UMaterialInstanceDynamic* mat : AllMats) {
		if (mat) {
			//mat->ConditionalBeginDestroy();
			mat->RemoveFromRoot();
			mat = nullptr;
		}
	}
}



#undef LOCTEXT_NAMESPACE