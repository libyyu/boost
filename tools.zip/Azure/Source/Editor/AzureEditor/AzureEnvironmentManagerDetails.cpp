﻿// Fill out your copyright notice in the Description page of Project Settings.

#include "AzureEnvironmentManagerDetails.h"
#include "GameLogic/Environment/AzureEnvironmentManager.h"

#include "DetailLayoutBuilder.h"
#include "DetailWidgetRow.h"
#include "DetailCategoryBuilder.h"
#include "IDetailsView.h"
#include "EditorSupportDelegates.h"

#define LOCTEXT_NAMESPACE "AzureEnvironmentManagerDetails"

TSharedRef<IDetailCustomization> FAzureEnvironmentManagerDetails::MakeInstance()
{
	return MakeShareable(new FAzureEnvironmentManagerDetails);
}

void FAzureEnvironmentManagerDetails::CustomizeDetails(IDetailLayoutBuilder& DetailBuilder)
{
	IDetailCategoryBuilder& Category = DetailBuilder.EditCategory("Edit");

	// Cache set of selected things
	SelectedObjectsList = DetailBuilder.GetSelectedObjects();

	Category.AddProperty("EditingPreset");

	Category.AddCustomRow(LOCTEXT("Apply Preset", "Apply Preset"), false)
		.NameContent()
		[
			SNullWidget::NullWidget
		]
		.ValueContent()
		.VAlign(VAlign_Center)
		.MaxDesiredWidth(250)
		[
			SNew(SButton)
			.VAlign(VAlign_Center)
			.OnClicked(this, &FAzureEnvironmentManagerDetails::ClickedOnApplyPresetButton)
			.Content()
			[
				SNew(STextBlock)
				.Text(LOCTEXT("Apply Preset", "Apply Preset"))
			]
		];

	Category.AddCustomRow(LOCTEXT("Dump Environment", "Dump Environment"), false)
		.NameContent()
		[
			SNullWidget::NullWidget
		]
		.ValueContent()
		.VAlign(VAlign_Center)
		.MaxDesiredWidth(250)
		[
			SNew(SButton)
			.VAlign(VAlign_Center)
			.OnClicked(this, &FAzureEnvironmentManagerDetails::ClickedOnDumpEnvironmentButton)
			.Content()
			[
				SNew(STextBlock)
				.Text(LOCTEXT("Dump Environment", "Dump Environment"))
			]
		];

	Category.AddCustomRow(LOCTEXT("Update Spt Shadow Flag", "Update Spt Shadow Flag"), false)
		.NameContent()
		[
			SNullWidget::NullWidget
		]
		.ValueContent()
		.VAlign(VAlign_Center)
		.MaxDesiredWidth(250)
		[
			SNew(SButton)
			.VAlign(VAlign_Center)
			.OnClicked(this, &FAzureEnvironmentManagerDetails::ClickedOnUpdateSptShadowFlagButton)
			.Content()
			[
				SNew(STextBlock)
				.Text(LOCTEXT("Update Spt Shadow Flag", "Update Spt Shadow Flag"))
			]
		];

		Category.AddCustomRow(LOCTEXT("Clear Spt Shadow Flag", "Clear Spt Shadow Flag"), false)
			.NameContent()
			[
				SNullWidget::NullWidget
			]
		.ValueContent()
			.VAlign(VAlign_Center)
			.MaxDesiredWidth(250)
			[
				SNew(SButton)
				.VAlign(VAlign_Center)
			.OnClicked(this, &FAzureEnvironmentManagerDetails::ClickedOnClearSptShadowFlagButton)
			.Content()
			[
				SNew(STextBlock)
				.Text(LOCTEXT("Clear Spt Shadow Flag", "Clear Spt Shadow Flag"))
			]
			];
}

FReply FAzureEnvironmentManagerDetails::ClickedOnApplyPresetButton()
{
	AAzureEnvironmentManager* Manager = nullptr;
	for (const TWeakObjectPtr<UObject>& Object : SelectedObjectsList)
	{
		Manager = Cast<AAzureEnvironmentManager>(Object.Get());
		break;
	}

	UAzureEnvironmentPreset* Preset = nullptr;
	if (Manager != nullptr && !Manager->IsTemplate() && Manager->EditingPreset.Get())
	{
		Preset = Cast<UAzureEnvironmentPreset>(Manager->EditingPreset->GetDefaultObject());
	}

	if (Preset != nullptr)
	{
		Manager->LoadFromPreset(Preset);
	}

	if (Manager != nullptr)
	{
		Manager->Update(0);
		Manager->Apply(0);
	}

	FEditorSupportDelegates::RedrawAllViewports.Broadcast();

	return FReply::Handled();
}

FReply FAzureEnvironmentManagerDetails::ClickedOnDumpEnvironmentButton()
{
	AAzureEnvironmentManager* Manager = nullptr;
	for (const TWeakObjectPtr<UObject>& Object : SelectedObjectsList)
	{
		Manager = Cast<AAzureEnvironmentManager>(Object.Get());
		break;
	}

	if (Manager != nullptr)
	{
		Manager->Dump();
	}
	
	FEditorSupportDelegates::RedrawAllViewports.Broadcast();

	return FReply::Handled();
}

FReply FAzureEnvironmentManagerDetails::ClickedOnUpdateSptShadowFlagButton()
{
	AAzureEnvironmentManager* Manager = nullptr;
	for (const TWeakObjectPtr<UObject>& Object : SelectedObjectsList)
	{
		Manager = Cast<AAzureEnvironmentManager>(Object.Get());
		break;
	}

	if (Manager != nullptr)
	{
		AAzureEnvironmentManager::UpdateSptShadowFlag(Manager->GetWorld(), Manager->GetLevel());
	}

	FEditorSupportDelegates::RedrawAllViewports.Broadcast();

	return FReply::Handled();
}

FReply FAzureEnvironmentManagerDetails::ClickedOnClearSptShadowFlagButton()
{
	AAzureEnvironmentManager* Manager = nullptr;
	for (const TWeakObjectPtr<UObject>& Object : SelectedObjectsList)
	{
		Manager = Cast<AAzureEnvironmentManager>(Object.Get());
		break;
	}

	if (Manager != nullptr)
	{
		AAzureEnvironmentManager::ClearSptShadowFlag(Manager->GetWorld(), Manager->GetLevel());
	}

	FEditorSupportDelegates::RedrawAllViewports.Broadcast();

	return FReply::Handled();
}

#undef LOCTEXT_NAMESPACE
