#pragma once

#include "CoreMinimal.h"
#include "UObject/ObjectMacros.h"
#include "AzureEditorUtils.generated.h"

class ULevel;

UCLASS()
class UAzureEditorUtils : public UObject
{
	GENERATED_BODY()
public:

	UFUNCTION(BlueprintCallable, Category = "Azure Editor")
	static void TranslateLevel(ULevel* Level, const FVector& Translation);


	UFUNCTION(BlueprintCallable, Category = "Azure Editor")
	static bool TranslateMap(const FString& PackageName, const FVector& Translation);
};

