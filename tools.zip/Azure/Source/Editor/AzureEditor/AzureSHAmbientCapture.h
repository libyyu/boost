// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "GameLogic/Environment/AzureEnvironmentDefine.h"
#include "AzureSHAmbientCapture.generated.h"

class UAzureEnvironmentPreset;

UCLASS()
class AAzureSHAmbientCapture : public AActor
{
	GENERATED_BODY()
	
public:	

	AAzureSHAmbientCapture();

	virtual void Tick(float DeltaTime) override;

	virtual bool ShouldTickIfViewportsOnly() const;

	void CaptureData();

	void SaveDataToPreset();

	UPROPERTY(Transient, EditAnywhere, Category = "Ambient SH", meta = (DisplayName = "Current SH Data"))
	FAzureAmbientSHCoefficientsTimeofDay CurrentSHData;

	UPROPERTY(Transient, EditAnywhere, Category = "Ambient SH")
	TSubclassOf<UAzureEnvironmentPreset> TargetPresetClass;

	UPROPERTY(Transient, EditAnywhere, Category = "Ambient SH", meta = (DisplayName = "Target Preset SH Data"))
	TArray<FAzureAmbientSHCoefficientsTimeofDay> TargetPresetSHData;

#if WITH_EDITOR
	virtual void PostEditChangeProperty(FPropertyChangedEvent& PropertyChangedEvent) override;
#endif //WITH_EDITOR

protected:

	virtual void BeginPlay() override;

private:

	UPROPERTY(VisibleAnywhere)
	class UStaticMeshComponent* LightingPreviewer;

	UPROPERTY(Transient)
	UAzureEnvironmentPreset* TargetPreset;

	void UpdateAmbientSHCoefficients();

	void ApplyAmbient();

	void LoadDataFromPreset();
};
