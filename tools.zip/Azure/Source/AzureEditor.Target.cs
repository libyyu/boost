// Fill out your copyright notice in the Description page of Project Settings.

using UnrealBuildTool;
using System.Collections.Generic;

public class AzureEditorTarget : TargetRules
{
	public AzureEditorTarget(TargetInfo Target) : base(Target)
	{
		Type = TargetType.Editor;

		ExtraModuleNames.AddRange( new string[] { "AzureEditor", "AzureEd" } );

        //0:luajit, 1:lua51, ...
        ProjectDefinitions.Add("LUA_TYPE=0");
    }
}
