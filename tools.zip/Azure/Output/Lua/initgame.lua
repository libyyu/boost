if jit and jit.off then
	jit.off() --关闭luajit（速度更快）
end
--13.2.1版的xcode在iPad上返回iPadOS, 以前是ios。改写SystemInfo.get_operatingSystem
--TODO:后面服务器改C++也可以，这里就不用重载了
if SystemInfo and GameUtil and GameUtil.GetPlatformName() == "IOS" then
	local operating_system = SystemInfo.get_operatingSystem()
	local temp_operating_system = operating_system:lower()
	local p, n = temp_operating_system:find("ipados")
	if p == 1 and n == 6 then
		operating_system = "iOS" .. temp_operating_system:sub(n+1)
	end
	SystemInfo.get_operatingSystem = function()
		return operating_system
	end
end

local initgame_util = require "initgame_util"
require "Utility.MemoryMark"

local SafeExec = initgame_util.SafeExec
require "coro"
require "Data.LocalFlag"

-- 更新后重载无意义，不重载
if _G.MarkNotReloadAfterUpdate then _G.MarkNotReloadAfterUpdate() end

function _G.require_config(path)
	local ret = {dofile(path)}
	return unpack(ret)
end

local callbacksAfterEULA
local function WrapSafeExec(func)
	callbacksAfterEULA = callbacksAfterEULA or {}
	table.insert(callbacksAfterEULA, func)
end

local function InvokeEULAFinishCallbacks()
	if not callbacksAfterEULA then
		return
	end
	for _, func in ipairs(callbacksAfterEULA) do
		SafeExec(func)
	end
	callbacksAfterEULA = nil
end

---初始化戴宗需要在隐私弹窗之后
WrapSafeExec(function()
	-- 初始化daizong SDK，必须要在lua代码入口点，避免漏Log
	local DaizongSDK = require "Daizong.DaizongSDK"
	local isSuccess = DaizongSDK.Init()
	if not isSuccess then
		warn("[Daizong] Init failed!")
	end

	if isSuccess and DaizongSDK.IsValid() then
		-- 记录设备启动
		DaizongSDK.LogDeviceActive(1)
		DaizongSDK.LogStepLogReport(DAIZONG_STEPCODE.INIT)

		-- 海外版获取用户相册权限 (获取deviceId用)
		if GameUtil.GetPlatformName() == "Android" then
			local timerID = 0
			timerID = GameUtil.AddGlobalTimer(1, false, function()
				if DaizongSDK.DeviceIdReSet() then
					DaizongSDK.LogDeviceActive(2, DaizongSDK.GetCacheDeviceId())
					DaizongSDK.LogStepLogReport(DAIZONG_STEPCODE.INIT_SDK_GET_ALBUM_PERMISSION)
					if timerID ~= 0 then
						GameUtil.RemoveGlobalTimer(timerID)
						timerID = 0
					end
				end
			end)
		else
			DaizongSDK.LogDeviceActive(2)
			DaizongSDK.LogStepLogReport(DAIZONG_STEPCODE.INIT_SDK_GET_ALBUM_PERMISSION)
		end
	end

	local GEMLogin = require "MSDK.MSDKGPMGEMLoginPost"
	GEMLogin.PostLoginStepEvent(GEMLogin.LoginStep.GAME_INIT)

	if UniSDK then
		UniSDK.action("sendAppsFlyerEvent", {eventName="initializing", eventValue=""})
	end
end)

SafeExec(function()
	if not _G.GIsShipping then
		-- 启动 Lua Tracy Profiler/Lua UE Profiler 性能分析器
		local LuaTracyProfiler = require "Utility.LuaTracyProfiler"
		local LuaUEProfiler = require "Utility.LuaUEProfiler"
		local start_tracy_profiler = GameUtil2.GetCommandLineParam and GameUtil2.GetCommandLineParam("--tracy_profiler=") == "1"
		local start_ue_profiler = GameUtil2.GetCommandLineParam and GameUtil2.GetCommandLineParam("--lua_ue_profiler=") == "1"
		if LuaTracyProfiler.IsProfilerEnabled() or start_tracy_profiler then	--只能启动一个
			LuaTracyProfiler.Init()
		elseif LuaUEProfiler.IsProfilerEnabled() or start_ue_profiler then
			LuaUEProfiler.Init()
		end
	end
end)

SafeExec(function()
	-- 输出AzureMobile的版本号
	local AMVersion = AzureMobileUtility and AzureMobileUtility.GetAzureMobileVersion() or "unknown"
	print(("AzureMobile Version = [%s]"):format(AMVersion))
end)

if GameUtil.EnableSlateReflectorQueryWidgets then
	_G.QueryReflectorWidgets = function()
		local ECGame = require "Main.ECGame"
		local FEPateMan = require "Pate.FEPateMan"
		local host = ECGame.Instance():GetHostPlayer()
		local hostPate = host and host.Pate and host.Pate.m_pate or nil
		local hostExtraPate = host and host.Pate and host.Pate.m_extraPate or nil
		local allPates = {}
		if hostPate then
			table.insert(allPates, hostPate)
		end
		if hostExtraPate then
			table.insert(allPates, hostExtraPate)
		end
		if FEPateMan.Instance().m_allPate then
			for _, pate in pairs(FEPateMan.Instance().m_allPate) do
				if pate.m_pate and pate.m_pate ~= hostPate and pate.m_pate ~= hostExtraPate then
					table.insert(allPates, pate.m_pate)
				end
				if pate.m_extraPate and pate.m_extraPate ~= hostPate and pate.m_extraPate ~= hostExtraPate  then
					table.insert(allPates, pate.m_extraPate)
				end
			end
		end
		return allPates
	end
	GameUtil.EnableSlateReflectorQueryWidgets()
end

-- Start Remote Debug
--[[
local debug = require("mobdebug")
if debug then
	debug.start()
end
]]

local GSDK_EVENT_STARTGAME = 0
local GSDK_EVENT_PLAYCG = 1
_G.GSDKSetEvent = function ( event, status, msg, authorize, finish )
	--print("gsdk event ", event, status, msg, authorize, finish)
	if GSDKWrapper ~= nil then
		GSDKWrapper.SetEvent(event, status, msg, authorize, finish)
	end
end

local movie_panel
local intro_movie_end = false

_G.on_intro_movie_end = function ( p1, p2 )
	intro_movie_end = true
	print("play intro movie end ", p1, p2)
end

local function play_intro_movie()
	if _G.GIsEditor then
		return
	end
	print("play intro movie")
	local obj = GameUtil.SyncLoad("UI/UMG/Panel_StartupMovie", "WidgetBlueprintGeneratedClass")
	coro.yield()
	movie_panel = UserWidget.CreateWidget(obj)
	movie_panel:AddToViewport(10)
	
	while not intro_movie_end do
		coro.yield()
	end
	movie_panel:RemoveFromParent()
	GameUtil.RemoveRef(movie_panel)
	movie_panel = nil
end

--检查用户许可协议，如果用户没有同意，需要弹出许可界面
local function check_end_user_license_agreement()
	--海外没有隐私弹窗
	if require "Utility.BranchUtil".IsOversea() then
		return
	end

	local EndUserLicenseAgreement = require "EndUserLicenseAgreement"
	EndUserLicenseAgreement.check_end_user_license_agreement()
	package.loaded["EndUserLicenseAgreement"] = nil
end

local update = require "update"

--:修改PC的名字
if GameUtil.GetPlatformName() == "Windows" and not _G.GIsEditor then
	local window_handle = WindowsUtil.GetTopLevelWindowHandle()
	if window_handle then
		local BranchUtil = require "Utility.BranchUtil"
		local branch_config = dofile("Configs/branch_config.lua")
		local branch = BranchUtil.GetBranch()
		if branch_config.get_appname then --做兼容处理，避免旧包启动期间读取不到该函数
			local name = branch_config.get_appname(branch, "win")
			WindowsUtil.SetWindowTextByHandle(window_handle, name)
		end
	end
end

coro.start(function()
	--直接初始化umg事件
	GameUtil.UMGCustomSetup()

	require "Utility.VersionUtil".GetResBaseVersion()	--用这个函数读取一下配置

	--在更新界面显示前加载本地化数据，以便更新界面本身显示正确的语言，此数据来自初始资源包
	require "Main.ECLocalizationManager".Init()
	_G.MemoryMark"ECGame.Init, ECLocalizationManager"

	--根据系统界面设置
	--增加是否多语言判断，避免其他包没有gameinit模块而启动卡死
	if require "Utility.VersionUtil".Lang.HasAppBuildinLang() and not _G.g_ResBaseIsPrecreateApp then
		
		require "gameinit.Language".Init(function(bChooseLang)
			if bChooseLang then
				--个人隐私弹窗(海外没有这个逻辑)
				check_end_user_license_agreement()

				--给选择语言界面预先加载一个背景
				if update and update[4] then update[4]() end
			end
		end)
		package.loaded["gameinit.Language"] = nil
	end

	--个人隐私弹窗（国内有）
	check_end_user_license_agreement()

	--初始化Daizong
	InvokeEULAFinishCallbacks()

	--初始化GSDKWrapper， 好像没用了
	if GSDKWrapper ~= nil then
		GSDKWrapper.Init("1106940691", false, 1)
	end
	_G.GSDKSetEvent(GSDK_EVENT_STARTGAME, true, "success", false, false)
	print("app info: ", GameUtil.StreamingAssetReadFileText("res_base/app_info.xml"))

	--预先设置shadercode加载标记，避免update[1]都走完了，还没走到shadercode加载
	_G.StartLoadShaderCacheWhenInit = 1

	--play_intro_movie()
	_G.GSDKSetEvent(GSDK_EVENT_PLAYCG, true, "success", false, false)
	--进入更新
	if update then update[1]() end
	-- do return end

	_G.MemoryMark"initgame2, beg"
	local initStage2 = require "initgame2"
	initStage2(update)
	_G.MemoryMark"initgame2, end"	--在协程中运行，此处无法匹配 begin-end
	if update then update[2]() end
	update = nil

	package.loaded["update"] = nil
	collectgarbage("collect")
	GameUtil.GC(true)

	if not _G.GIsEditor then
		local FStabletrunk = require "Utility.FStabletrunk"
		FStabletrunk.Get()
		if GameUtil2.SetMapWarnings then
			GameUtil2.SetMapWarnings(false)
		end
		local remote_log = GameUtil2.GetCommandLineParam and GameUtil2.GetCommandLineParam("--remote_log=")
		if tonumber(remote_log) then
			local RemoteTools = require("Utility.RemoteTools")
			local rt = RemoteTools.Instance()
			rt:ListenOnPort(tonumber(remote_log))
		end
	end

	if _G.IsWindowsSimuMobile() then
		local FClientCollect = require "Utility.FClientCollect"
		FClientCollect.ReportClientInfo()
	end
end)
