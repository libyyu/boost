---
--- Created by chenshilei.
--- DateTime: 2021/1/9 11:27
---

--注意：require要在定义MarkReloadAfterUpdate之后，否则不能调用MarkReloadAfterUpdate函数

local ReloadAfterUpdateMods = {}

--- 模块标记为更新后重载
---@param modName string @nullable
_G.MarkReloadAfterUpdate = function(modName)
    -- 获取调用模块的模块名
    if not modName then
        local debugInfo = debug.getinfo(2, "S")
        local sourceName = debugInfo.short_src
        modName = string.gsub(sourceName, "/", ".")
        modName = string.gsub(modName, "\\", ".")

        if string.sub(modName, string.len(modName) - 3) == ".lua" then
            modName = string.sub(modName, 1, string.len(modName) - 4)
        end
    end

    -- 标记为待重载
    if not ReloadAfterUpdateMods[modName] then
        print("MarkReloadAfterUpdate:", modName, true)
        ReloadAfterUpdateMods[modName] = true
    end
end

--- 模块标记为更新后不重载
---@param modName string @nullable
_G.MarkNotReloadAfterUpdate = function(modName)
    -- 获取调用模块的模块名
    if not modName then
        local debugInfo = debug.getinfo(2, "S")
        local sourceName = debugInfo.short_src
        modName = string.gsub(sourceName, "/", ".")
        modName = string.gsub(modName, "\\", ".")

        if string.sub(modName, string.len(modName) - 3) == ".lua" then
            modName = string.sub(modName, 1, string.len(modName) - 4)
        end
    end

    -- 标记为待重载
    if not ReloadAfterUpdateMods[modName] then
        print("MarkReloadAfterUpdate:", modName, false)
        ReloadAfterUpdateMods[modName] = false
    end
end

-- 调用ReloadModuleAfterUpdate后手动重载自己
_G.MarkNotReloadAfterUpdate()

--- 重载被标记为更新后重载的模块
_G.ReloadModuleAfterUpdate = function()
    print("ReloadModuleAfterUpdate")
    
    --标记 module name 判断失败的 bug 已经修正了
    --不能在函数外打标记，否则此文本重新加载后会错误加上标记
    _G.versionFlag_InitGameReloadModuleNameFixed = true
    
    if package.loaded["Utility.InitGameReloader"] then
        Debug.LogError("Utility.InitGameReloader is loaded before ReloadModule")
    end
    
    require "Utility.InitGameReloader".ReloadModule(ReloadAfterUpdateMods)
end

-- require
require "Core.try"

-- 安全执行函数，catch报错但不阻止运行。
-- 负责运行必须在initgame执行，但失败也不影响逻辑的代码。
local function SafeExec(func)
    try {
        function()
            func()
        end,
        catch {
            function(errors)
                Debug.LogError("Initgame Error: " .. errors)
            end
        }
    }
end

return {
    SafeExec = SafeExec,
}