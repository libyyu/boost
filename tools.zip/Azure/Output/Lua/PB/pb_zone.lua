local Lplus = require "Lplus"
local pb_helper = require "PB.pb_helper"
---@type ECGame
local ECGame = Lplus.ForwardDeclare("ECGame")
local ECZoneMan = require "Main.ECZoneMan"

-- 跨服
---@param msg pb.Message.PB.npt_change_zone_response
local function npt_change_zone_response(sender, msg)
	local ECRoguelikeMan = require "Roguelike.ECRoguelikeMan"
	print_hsh("npt_change_zone_response msg.retcode =", tostring(msg))
	local CHANGE_ZONE_TYPE = CONSTANT_DEFINE.CHANGE_ZONE_TYPE
	--跨服失败
	if msg.retcode ~= 0 then 
		local detail = ""	
		if msg.retcode == 740 then -- "漫游目标服务器无法连接"
			detail = StringTable.Get(26924)
		elseif msg.retcode == 741 then -- "当前服务器没有注册"
			detail = StringTable.Get(26925)
		elseif msg.retcode == 742 then -- "漫游目标服务器无法连接HUB服务器"
			detail = StringTable.Get(26926)
		elseif msg.retcode == 743 then -- "目标服务器错误"
			detail = StringTable.Get(26927)
		elseif msg.retcode == 744 then -- "漫游超时"
			detail = StringTable.Get(26928)
		elseif msg.retcode == 745 then -- "漫游角色数据查找失败"
			detail = StringTable.Get(26929)
		elseif msg.retcode == 746 then -- "错误的角色状态"
			detail = StringTable.Get(26930)
		elseif msg.retcode == 747 then -- "漫游角色数据加载错误"
			detail = StringTable.Get(26931)
		elseif msg.retcode == 748 then -- "漫游错误"
			detail = StringTable.Get(26932)
		elseif msg.retcode == 749 then -- "漫游状态错误"
			detail = StringTable.Get(26933)
		elseif msg.retcode == 752 then -- "网络错误"
			detail = StringTable.Get(26934)
		elseif msg.retcode == 753 then -- "玩家正在漫游状态"
			detail = StringTable.Get(26935)
		elseif msg.retcode == 754 then -- "选择了错误的服务器"
			detail = StringTable.Get(26936)
		elseif msg.retcode == 755 then -- "错误的跨服协议"
			detail = StringTable.Get(26937)
		elseif msg.retcode == 756 then -- "玩家数据错误"
			detail = StringTable.Get(26938)
		elseif msg.retcode == 757 then -- "跨服转发数据超时"
			detail = StringTable.Get(26939)
		elseif msg.retcode == 758 then -- "跨服连接断开重连"
			detail = StringTable.Get(26940)
		elseif msg.retcode == 759 then -- "登陆了其他角色"
			detail = StringTable.Get(26941)
		elseif msg.retcode == 760 then -- "排队尚未完成"
			detail = StringTable.Get(26942)
		elseif msg.retcode == 761 then -- "角色重复登录"
			detail = StringTable.Get(26947)
		elseif msg.retcode == 11 then -- "无法重复登陆跨服幻境，请稍等后再尝试登陆！"
			detail = StringTable.Get(26943)
		end

		if msg.login_type == CHANGE_ZONE_TYPE.CZT_ROGUELIKE then
			FlashTipMan.FlashTipByStrID(66523)
		elseif #detail > 0 then
			FlashTipMan.FlashTip(StringTable.Get(26920) .. detail)
		else
			FlashTipMan.FlashTip(StringTable.Get(26920) .. "(" .. msg.retcode .. ")")
		end
		return 
	end

	if ECZoneMan.Instance():ReconnectToCenterServer(msg.dst_zone, msg.login_token) then
		ECZoneMan.Instance():SaveCenterServerFlag(ECGame.Instance().m_HostPlayer.ID, true)
		ECZoneMan.Instance():SetWaitingServerQueue(true)
		ECZoneMan.Instance():SetLoginType(msg.login_type)
	end
	if msg.login_type == CHANGE_ZONE_TYPE.CZT_ROGUELIKE then
		ECRoguelikeMan.Instance():ShowFakeLoading(true)
	end
end
pb_helper.AddHandler("npt_change_zone_response", npt_change_zone_response)

--zone id 查询列表
local function npt_notify_zoneid_list(sender,msg)
	ECZoneMan.Instance():UpdateZoneList(msg)
end
pb_helper.AddHandler("npt_notify_zoneid_list", npt_notify_zoneid_list)

---@param msg pb.Message.PB.gp_roam_roleinfo
local function on_gp_roam_roleinfo(sender, msg)
	local RomeRoleInfoEvent = require "Event.RoamRoleInfoEvent"
	---@param host ECHostPlayer
	globalGame:OnHostPlayerCreate(function(host)
		host.Faction:SetFactionId(msg.mafia_uuid)
		host:SetOriginalID(msg.real_roleid)
	end)
	ECGame.EventManager:raiseEvent(nil, RomeRoleInfoEvent())
end
pb_helper.AddHandler("gp_roam_roleinfo", on_gp_roam_roleinfo)