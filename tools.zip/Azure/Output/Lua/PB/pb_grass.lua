---------------------------------------------------------------
--
-- FileName : pb_grass.lua
-- Creator : lvliang
-- Date : 2020-03-20
-- Comment : 
--
---------------------------------------------------------------
local pb_helper = require "PB.pb_helper"

---@param msg pb.Message.PB.gp_grass_stamp
local function on_gp_grass_stamp(sender, msg)
	local ECGrassMan = require "Grass.ECGrassMan"
	ECGrassMan.Instance():OnGetGrassData(msg)
end

pb_helper.AddHandler("gp_grass_stamp", on_gp_grass_stamp)

