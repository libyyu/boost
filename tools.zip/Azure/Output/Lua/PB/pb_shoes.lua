--飞鞋

--
-- gp_task_shoes_notify
-- 
local pb_helper = require "PB.pb_helper"
local client_msg = require "PB.client_msg"
local function on_task_shoes_notify( sender,msg )
	-- local Lplus = require "Lplus"
	-- local ECGame = Lplus.ForwardDeclare("ECGame")
	-- local ECTaskUtility = require "Task.ECTaskUtility"
	-- if msg.error ~= 0 then
	-- 	ECGame.Instance().canAutoMove = false
	-- 	ECGame.Instance().m_after_automve_call = nil
	-- elseif msg.task_id and msg.task_id ~= 0 then
	-- 	if ECTaskUtility.PreCheckTask(msg.task_id) then
	-- 		ECGame.Instance().m_after_automve_call = nil
	-- 		ECTaskUtility.BeginTaskAutomove(msg.task_id)
	-- 	end
	-- end
end

local function on_task_notify(sender,msg)
	local gp_task_notify = client_msg.gp_task_notify
	local ECTaskInterface = require "Task.ECTaskInterface"
	local taskView = ECTaskInterface.Instance():GetTaskView(msg.task_id)
	local taskName = taskView.name.. taskView.nameSubfix()
	local taskid = msg.task_id
	if msg.task_type == gp_task_notify.TeamTask then
		-- 屏蔽提示文字
		local HideTaskHintUtils = require "Utility.HideTaskHintUtils"
		if not HideTaskHintUtils.Contains(22165, taskid) then
			FlashTipMan.FlashTip(StringTable.Get(22165):format(taskName))
		end
	elseif msg.task_type == gp_task_notify.TeamBroadSharedFromLeader then
		if ECTaskInterface.CanTryDeliverTask(msg.task_id) then
			MsgBox.ShowMsgBox(self, StringTable.Get(22303):format(taskView.name), nil, MsgBox.MsgBoxType.MBBT_OKCANCEL, function(sender,ret)
				if ret == MsgBox.MsgBoxRetT.MBRT_OK then
					local client_msg = require "PB.client_msg"
					local gp_clan_match_task = client_msg.gp_clan_match_task
					local _msg = gp_clan_match_task()

					_msg.task_id = taskid
					pb_helper.Send(_msg)
				end
			end)
		end
	end
end

pb_helper.AddHandler("gp_task_notify",on_task_notify)
-- pb_helper.AddHandler("gp_task_shoes_notify",on_task_shoes_notify)