local Lplus = require "Lplus"
---@type ECGame
local ECGame = Lplus.ForwardDeclare("ECGame")
local pb_helper = require "PB.pb_helper"
local EC = require "Types.Vector3"

local function on_gp_drag_point( sender,msg )
	local theGame = ECGame.Instance()
	local hp = theGame.m_HostPlayer
	if not hp then return end

	hp:SetMoveVelField_Circle(msg.pos, msg.speed, msg.dis_min, msg.dis_max)
end
pb_helper.AddHandler("gp_drag_point", on_gp_drag_point)


local l_DragDir = EC.Vector3.new()
local function on_gp_drag_line( sender,msg )
	local theGame = ECGame.Instance()
	local hp = theGame.m_HostPlayer
	if not hp then return end

	DecompressDirH2(msg.dir, l_DragDir)
	hp:SetMoveVelField_Rect(msg.pos, msg.speed, dir, msg.dis_min, msg.dis_max, msg.width/2)
end
pb_helper.AddHandler("gp_drag_line", on_gp_drag_line)


local function on_gp_drag_remove( sender,msg )
	local theGame = ECGame.Instance()
	local hp = theGame.m_HostPlayer
	if not hp then return end

	hp:ClearMoveVelField()
end
pb_helper.AddHandler("gp_drag_remove", on_gp_drag_remove)