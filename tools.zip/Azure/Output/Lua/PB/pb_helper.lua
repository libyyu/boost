--[[
	收发用 protocol buffers 定义的协议
]]
local Lplus = require "Lplus"

local client_msg = require "PB.client_msg"

local S2CManager = require "S2C.S2CManager"
local S2CCommand = require "S2C.S2CCommand"

local C2SCommand = require "C2S.C2SCommand"

local ProtocolManager = require "Protocol.ProtocolManager"
local GProtocNet = require "Protocol.GProtocNet"
local GProtocNet_Re = require "Protocol.GProtocNet_Re"
local GProtocMulti = require "Protocol.GProtocMulti"
local GProtocNetEarly = require "Protocol.GProtocNetEarly"

local AnonymousEventManager = require "Utility.AnonymousEvent" .AnonymousEventManager
local GcCallbacks = require "Utility.GcCallbacks"

local ECNetworkDebugger = require "Main.ECNetworkDebugger"
local DynamicProtobufWrapper = require "Utility.DynamicProtobufWrapper"
local DynamicProtobuf = require "DynamicProtobuf"

local pairs = pairs
local require = require
local type = type
local warn = warn
local error = error
local tostring = tostring
local math = math
local string = string
local LuaUInt64 = LuaUInt64
local _G = _G
local Octets = Octets

do 
	PBFastAccessor.SetPBArenaAllocatorInitParam(0, 512, 1024) -- 256
	PBFastAccessor.SetPBArenaAllocatorInitParam(1, 256, 512) -- 512
	PBFastAccessor.SetPBArenaAllocatorInitParam(2, 256, 512) -- 1024
	PBFastAccessor.SetPBArenaAllocatorInitParam(3, 256, 256) -- 2048
	PBFastAccessor.SetPBArenaAllocatorInitParam(4, 256, 256) -- 4096
	PBFastAccessor.SetPBArenaAllocatorInitParam(5, 128, 192) -- 8192
	PBFastAccessor.InitPBArenaAllocator()
end

require "Utility.global".disable()

local l_nameToInfo = {}		--name => {type=type, name=name, pb_class=pb_class, id=id}
local l_pbClassToInfo = {}		--pb_class => {type=type, name=name, pb_class=pb_class, id=id}

local function addPbInfo (type, name, pb_class, id)
	local info = {type=type, name=name, pb_class=pb_class, id=id}
	l_nameToInfo[name] = info
	l_pbClassToInfo[pb_class] = info
end

local l_s2cIdToS2cClass = {}
local l_s2cHandlerMap = {}	-- originHandler => realHandler

local l_dsIdToDsClass = {}
local l_dsIdToPbClass = {}
local l_dsHandlerMap = {}	-- realHandler => originHandler

-- 注册 S2C 子类
local function registerS2C (name, id, pb_class)
	--定义用 protocol buffers 解析的S2C协议
	---@class s2c_class:S2CCommand
	---@field public msg table
	---@field public Commit fun():s2c_class @notnull
	---@field public Unmarshal fun(self:s2c_class, br:userdata)
	local s2c_class = Lplus.Extend(S2CCommand, "PB.S2C_CMD." .. name)
	do
		local def = s2c_class.define

		---@type table
		def.field("table").msg = nil

		---@param self s2c_class
		---@param br userdata
		---@return void
		def.override("userdata").Unmarshal = function (self, br)
			local msg = pb_class()
			local allBytes = br:ReadAllBytes()
			msg:ParseFromString(allBytes)
			self.msg = msg
		end
	end
	s2c_class.Commit()
	S2CManager.Register(id, s2c_class)

	addPbInfo("S2C", name, pb_class, id)
	l_s2cIdToS2cClass[id] = s2c_class
end

--定义用 protocol buffers 解析的C2S协议
---@class PB.C2SProtocCommand:C2S.C2SCommand
---@field protected m_id number
---@field protected m_msg table
---@field public Commit fun():PB.C2SProtocCommand @notnull
---@field public new fun(id:number, msg:table):PB.C2SProtocCommand
---@field public GetType fun(self:PB.C2SProtocCommand):number
---@field public Marshal fun(self:PB.C2SProtocCommand, bw:userdata)
local C2SProtocCommand = Lplus.Extend(C2SCommand, "PB.C2SProtocCommand")
do
	local def = C2SProtocCommand.define

	---@param id number
	---@param msg table
	---@return PB.C2SProtocCommand
	def.final("number", "table", "=>", C2SProtocCommand).new = function (id, msg)
		local obj = C2SProtocCommand()
		obj.m_id = id
		obj.m_msg = msg
		return obj
	end

	---@param self PB.C2SProtocCommand
	---@return number
	def.override("=>", "number").GetType = function (self)
		return self.m_id
	end

	---@param self PB.C2SProtocCommand
	---@param bw userdata
	---@return void
	def.override("userdata").Marshal = function (self, bw)
		--local str = self.m_msg:SerializeToString()
		--_G.print("send", #str, ": ", self.m_msg:SerializeToString():byte(1, #str))
		bw:WriteBytes(self.m_msg:SerializeToString())
	end

	---@type number
	def.field("number").m_id = 0

	---@type table
	def.field("table").m_msg = nil
end
C2SProtocCommand.Commit()

-- 注册 C2S 子类
local function registerC2S (name, id, pb_class)
	addPbInfo("C2S", name, pb_class, id)
end

-- DS 协议监听器
local l_dsProtocolManager = AnonymousEventManager()
do
	local function gprotocNetHandler (sender, cmd)
		local pb_helper = require "PB.pb_helper"
		local cmdId = cmd.dtype
		local content = cmd.datainfo:getBytes()
		local ds_class = l_dsIdToDsClass[cmdId]
		
		if ds_class then
			local event = ds_class.new(content)
			if not ECNetworkDebugger.Instance():OnRecvProtocol(ECNetworkDebugger.PROTO_TYPE.PB_S2C, event.msg, cmdId) then
				warn("gprotocNetHandler, protocol(id="..cmdId.." name="..pb_helper.GetProtoName(event.msg)..") is hooked!")
				--cmd.datainfo:unbind()
				return
			end
			l_dsProtocolManager:raiseEvent(sender, event)
		else
			warn("unhandled ds protocol buffer type " .. cmdId)
		end
		--cmd.datainfo:unbind()
	end
	ProtocolManager.AddHandler(GProtocNet_Re, gprotocNetHandler)
	------------------------------------------------------------
	--pb_helper
	local CommonInvite = require "Protocol.CommonInvite"
	ProtocolManager.Register(580, "CommonInvite")
	local function gcommonInviteHandler (sender, cmd)
		local cmdId = cmd.dtype
		local content = cmd.datainfo:getBytes()
		local ds_class = l_dsIdToDsClass[cmdId]
		
		if ds_class then
			--local event = ds_class.new2(cmd.xid, content)
			local event = ds_class.new3(cmd.xid, cmd.isinvite, cmd.roleid, content)
			l_dsProtocolManager:raiseEvent(sender, event)
		else
			warn("unhandled ds protocol buffer type " .. cmdId)
		end
	end
	ProtocolManager.AddHandler(CommonInvite, gcommonInviteHandler)
end

-- do
-- 	local  function gprotocMultiHandler(sender,cmd)
-- 		local cmdId = cmd.dtype
-- 		local content = cmd.datainfo:getBytes()
-- 		local ds_class = l_dsIdToDsClass[cmdId]
-- 		if ds_class then
-- 			local event = ds_class.new(content)
-- 			l_dsProtocolManager:raiseEvent(sender, event)
-- 		else
-- 			warn("unhandled ds protocol buffer type " .. cmdId)
-- 		end
-- 		cmd.datainfo:unbind()
-- 	end
-- 	ProtocolManager.AddHandler(GProtocMulti, gprotocMultiHandler)
-- end
-- 注册 DS 子类
local function registerDS (name, id, pb_class)
	--定义用 protocol buffers 解析的DS协议
	---@class ds_class:System.Object
	---@field public msg table
	---@field public xid any
	---@field public isinvite table
	---@field public Commit fun():ds_class @notnull
	---@field public new fun(content:string):ds_class
	---@field public new2 fun(xid:number, content:string):ds_class
	---@field public new3 fun(xid:number, isinvite:number, roleid:string, content:string):ds_class
	local ds_class = Lplus.Class("PB.DS_CMD." .. name)
	do
		local def = ds_class.define

		---@type table
		def.field("table").msg = nil

		---@type any
		def.field("dynamic").xid = nil

		---@type table
		def.field("table").isinvite = nil

		---@param content string
		---@return ds_class
		def.final("string", "=>", ds_class).new = function (content)
			local obj = ds_class()
			local msg = pb_class()
			msg:ParseFromString(content)
			obj.msg = msg
			return obj
		end

		---@param xid number
		---@param content string
		---@return ds_class
		def.final("number", "string", "=>", ds_class).new2 = function (xid, content)
			local obj = ds_class()
			local msg = pb_class()
			obj.xid = xid
			msg:ParseFromString(content)
			obj.msg = msg
			return obj
		end

		---@param xid number
		---@param isinvite number
		---@param roleid string
		---@param content string
		---@return ds_class
		def.final("number", "number", "string", "string", "=>", ds_class).new3 = function (xid, isinvite, roleid, content)
			local obj = ds_class()
			local msg = pb_class()
			obj.xid = xid
			msg:ParseFromString(content)
			obj.msg = msg
			obj.isinvite = { isinvite = isinvite, roleid = roleid }
			return obj
		end
	end
	ds_class.Commit()

	addPbInfo("DS", name, pb_class, id)
	
	l_dsIdToDsClass[id] = ds_class
	l_dsIdToPbClass[id] = pb_class
end
--[[--此为proto2的方式
local NET_PROTOCBUF_TYPE = client_msg.NET_PROTOCBUF_TYPE	--DS协议编号
local C2S_GS_PROTOC_TYPE = client_msg.C2S_GS_PROTOC_TYPE	--C2S协议编号
local S2C_GS_PROTOC_TYPE = client_msg.S2C_GS_PROTOC_TYPE	--S2C协议编号

for MsgName, MsgType in pairs(client_msg) do
	if type(MsgType) == "table" and MsgType.FindFieldDescriptor then	--是一个 protocol buffer 消息
		local field = MsgType:FindFieldDescriptor("type")
		if field and DynamicProtobuf.FieldDescriptor.has_default_value(field) then	--是个协议 (有 type 字段)
			local enumType = DynamicProtobuf.FieldDescriptor.enum_type(field)
			if enumType then
				local enumTypeName = DynamicProtobuf.EnumDescriptor.name(enumType)
				
				local MsgID = DynamicProtobuf.FieldDescriptor.GetDefaultValue(field)
				
				if enumTypeName == "NET_PROTOCBUF_TYPE" then
					registerDS(MsgName, MsgID, MsgType)
				elseif enumTypeName == "C2S_GS_PROTOC_TYPE" then
					registerC2S(MsgName, MsgID, MsgType)
				elseif enumTypeName == "S2C_GS_PROTOC_TYPE" then
					registerS2C(MsgName, MsgID, MsgType)
				end
			end
		end
	end
end]]

local npt_type		= 64001
local s2c_type 		= 64002
local c2s_type 		= 64003

for MsgName, MsgType in pairs(client_msg) do
	if type(MsgType) == "table" and MsgType.__pDescriptor then
		if DynamicProtobuf.Descriptor.unknow_field_count(MsgType.__pDescriptor) > 0 then --有option扩展
			local count = DynamicProtobuf.Descriptor.unknow_field_count(MsgType.__pDescriptor)
			for i=1, count do
				local unknow_field = DynamicProtobuf.Descriptor.unknow_field(MsgType.__pDescriptor, i-1)
				if unknow_field then
					local mt = DynamicProtobuf.UnknownField.number(unknow_field)
					local ty = DynamicProtobuf.UnknownField.type(unknow_field)
					if ty == DynamicProtobufWrapper.UnknownFieldType.TYPE_VARINT then
						local MsgID = DynamicProtobuf.UnknownField.varint(unknow_field)
						MsgID = math.floor(LuaUInt64.ToDouble(MsgID))
						if mt == npt_type then
							registerDS(MsgName, MsgID, MsgType)
						elseif mt == s2c_type then
							registerS2C(MsgName, MsgID, MsgType)
						elseif mt == c2s_type then
							registerC2S(MsgName, MsgID, MsgType)
						end
					end
				end
			end
		end
	end
end

---@class PB.pb_helper:System.Object
---@field public Commit fun():PB.pb_helper @notnull
---@field public GetCmdClass fun(cmdName:string):table
---@field public NewCmd fun(cmdName:string):table
---@field public AddHandler fun(cmdName:string, handler:function)
---@field public AddHandlerWithCleaner fun(cmdName:string, handler:function, cleaner:GcCallbacks)
---@field public RemoveHandler fun(cmdName:string, handler:function)
---@field public Send fun(msg:table):boolean,boolean
---@field public GenPBProto fun(msg:table):table,boolean
---@field public MakeDSCmd fun(id:number, data:userdata):table
---@field public GetProtoName fun(msg:table):string
---@field public GetProtoNameByID fun(cmdId:number):string
---@field public IsS2CPB fun(cmdId:number):boolean
---@field public ResumePBProto fun(cmdId:number, proto:table)
---@field public ResumePBProtoByName fun(cmdName:string, proto:table)
local pb_helper = Lplus.Class("PB.pb_helper")
do
	local def = pb_helper.define
	
	local function requireCmdInfoByName (cmdName)
		local info = l_nameToInfo[cmdName]
		if info == nil then
			error("bad protocol buffers command name: " .. tostring(cmdName))
		end
		return info.type, info.pb_class, info.id
	end
	
	--[[
		取得协议定义类
		param cmdName: 协议名
		return: 协议定义类
	]]

	---@param cmdName string
	---@return table
	def.static("string", "=>", "table").GetCmdClass = function (cmdName)
		local info = l_nameToInfo[cmdName]
		if info then
			return info.pb_class
		else
			return nil
		end
	end
	
	--[[
		创建出空的 protocol bufffers 消息
		param cmdName: 协议名
		return: 空的 protocol bufffers 消息。如果协议未找到，返回 nil
	]]

	---@param cmdName string
	---@return table
	def.static("string", "=>", "table").NewCmd = function (cmdName)
		local info = l_nameToInfo[cmdName]
		if info then
			return info.pb_class()
		else
			return nil
		end
	end
	
	--[[
		开始监听用 protocol buffers 定义的协议
		param cmdName: 协议名
		param handler: 收到协议的回调函数，其接口为:
			function onCmd (sender, msg)
				其中 sender 为发送者，msg 为 protocol buffers 消息
	]]

	---@param cmdName string
	---@param handler function
	---@return void
	def.static("string", "function").AddHandler = function (cmdName, handler)
		local type, pb_class, id = requireCmdInfoByName(cmdName)
		if type == "S2C" then
			local s2c_class = l_s2cIdToS2cClass[id]
			local function realHandler (sender, cmd)
				handler(sender, cmd.msg)
			end
			l_s2cHandlerMap[handler] = realHandler
			S2CManager.AddHandler(s2c_class, realHandler)
		elseif type == "DS" then
			local ds_class = l_dsIdToDsClass[id]
			local function realHandler (sender, cmd)
				if cmd.xid then
					if cmd.isinvite then
						handler(sender, cmd.xid, cmd.msg, cmd.isinvite.isinvite, cmd.isinvite.roleid)
					else
						handler(sender, cmd.xid, cmd.msg)
					end
				else
					handler(sender, cmd.msg)
				end
			end
			l_dsHandlerMap[handler] = realHandler
			l_dsProtocolManager:addHandler(ds_class, realHandler)
		else
			error(("bad protocol type to receive, got type: %s, name: %s"):format(type, cmdName))
		end
	end
	
	--[[
		开始监听用 protocol buffers 定义的协议，并自动停止监听
		param cmdName: 协议名
		param handler: 收到协议的回调函数，其接口为:
			function onCmd (sender, msg)
				其中 sender 为发送者，msg 为 protocol buffers 消息
		param cleaner: 用于自动停止监听的 GcCallbacks 对象
	]]

	---@param cmdName string
	---@param handler function
	---@param cleaner GcCallbacks
	---@return void
	def.static("string", "function", GcCallbacks).AddHandlerWithCleaner = function (cmdName, handler, cleaner)
		pb_helper.AddHandler(cmdName, handler)
		cleaner:add(function ()
			pb_helper.RemoveHandler(cmdName, handler)
		end)
	end	

	--[[
		停止监听用 protocol buffers 定义的协议
		param cmdName: 协议名
		param handler: AddHandler 传入的回调函数
	]]

	---@param cmdName string
	---@param handler function
	---@return void
	def.static("string", "function").RemoveHandler = function (cmdName, handler)
		local type, pb_class, id = requireCmdInfoByName(cmdName)
		
		if type == "S2C" then
			local s2c_class = l_s2cIdToS2cClass[id]
			local realHandler = l_s2cHandlerMap[handler]
			if realHandler then
				S2CManager.RemoveHandler(s2c_class, realHandler)
				l_s2cHandlerMap[handler] = nil
			end
		elseif type == "DS" then
			local ds_class = l_dsIdToDsClass[id]
			local realHandler = l_dsHandlerMap[handler]
			if realHandler then
				l_dsProtocolManager:removeHandler(ds_class, realHandler)
				l_dsHandlerMap[handler] = nil
			end
		else
			error(("bad protocol type to receive, got type: %s, name: %s"):format(type, cmdName))
		end
	end
	
	--[[
		发送一个用 Protocol buffers 定义的协议
		param msg: Protocol buffers 消息
	]]

	---@param msg table
	---@return boolean,boolean
	def.static("table", "=>", "boolean", "boolean").Send = function (msg)
		local pb_class = DynamicProtobufWrapper.GetMessageClass(msg)
		local info = l_pbClassToInfo[pb_class]
		local type, id = info.type, info.id
		
		if not ECNetworkDebugger.Instance():OnSendProtocol(ECNetworkDebugger.PROTO_TYPE.PB, msg, id) then
			warn("pb_helper.Send, protocol(id="..id.." name="..info.name..") is hooked")
			return true, false
		end

		if type == "C2S" then
			local cmd = C2SProtocCommand.new(id, msg)
			
			local ECGame = require "Main.ECGame"
			return ECGame.Instance().m_Network:SendGameData(cmd)
		elseif type == "DS" then
			local ECGame = require "Main.ECGame"
			
			local cmd
			local hostPlayer = ECGame.Instance().m_HostPlayer
			if hostPlayer then
				cmd = GProtocNet()
				cmd.dtype = id
				cmd.roleid = hostPlayer and hostPlayer.ID or _G.ZeroUInt64
				cmd.datainfo = Octets.Octets()
				cmd.datainfo:replace(msg:SerializeToString())
			else
				cmd = GProtocNetEarly()
				cmd.dtype = id
				cmd.account = _G.globalGame.m_Network.account
				cmd.datainfo = Octets.Octets()
				cmd.datainfo:replace(msg:SerializeToString())
				if not cmd.account then
					warn("pb_helper, not have account, Send protocol(id="..id.." name="..info.name..") failed")
					return false, false
				end
			end
			
			return ECGame.Instance().m_Network:SendProtocol(cmd)
		else
			error(("bad protocol type to send, got type: %s"):format(type))
			return false, false
		end
	end

	--[[
		构造一个PB协议
	]]

	---@param msg table
	---@return table,boolean
	def.static("table", "=>", "table", "boolean").GenPBProto = function(msg)
		local pb_class = DynamicProtobufWrapper.GetMessageClass(msg)
		local info = l_pbClassToInfo[pb_class]
		local type, id = info.type, info.id

		local proto
		local is_ds = false
		if type == "C2S" then
			proto = C2SProtocCommand.new(id, msg)
			is_ds = false
		elseif type == "DS" then
			local ECGame = require "Main.ECGame"
			proto = GProtocNet()
			proto.dtype = id
			proto.roleid = ECGame.Instance().m_HostPlayer.ID
			proto.datainfo = Octets.Octets()
			proto.datainfo:replace(msg:SerializeToString())
			is_ds = true
		else
			error(("bad protocol type to generate, got type: %s"):format(type))
		end
		return proto, is_ds
	end
	
	--[[
		创建出 DS 子类 protocol bufffers 消息
		param id: 协议id
		param data: 协议内容 (Octets)
		return: 创造出的 Protocol buffers 消息
	]]
	
	---@param id number
	---@param data userdata
	---@return table
	def.static("number", "userdata", "=>", "table").MakeDSCmd = function (id, data)
		local pb_class = l_dsIdToPbClass(id)
		local msg = pb_class()
		local content = data:getBytes()
		msg:ParseFromString(content)
		return msg
	end

	--[[
		根据协议包获取其名字
	]]

	---@param msg table
	---@return string
	def.static("table", "=>", "string").GetProtoName = function(msg)
		local pb_class = DynamicProtobufWrapper.GetMessageClass(msg)
		local info = l_pbClassToInfo[pb_class]
		return info.name
	end

	--[[
		根据协议号获取其名字
	]]
	---@param cmdId number
	---@return string
	def.static("number", "=>", "string").GetProtoNameByID = function(cmdId)
		if pb_helper.IsS2CPB(cmdId) then
			local s2c_class = l_s2cIdToS2cClass[cmdId]
			local class_name = Lplus.typename(s2c_class)
			return string.match(class_name, "PB.S2C_CMD.(.+)")
		else
			local ds_class = l_dsIdToDsClass[cmdId]
			local class_name = Lplus.typename(ds_class)
			return string.match(class_name, "PB.DS_CMD.(.+)")
		end
	end

	--[[
		判断S2C协议是否一个PB协议
	]]

	---@param cmdId number
	---@return boolean
	def.static("number", "=>", "boolean").IsS2CPB = function(cmdId)
		if l_s2cIdToS2cClass[cmdId] then
			return true
		else
			return false
		end
	end

	--[[
		续传PB的DS类协议，供ECNetworkDebugger使用
	]]

	---@param cmdId number
	---@param proto table
	---@return void
	def.static("number", "table").ResumePBProto = function(cmdId, proto)
		if proto then
			if pb_helper.IsS2CPB(cmdId) then
				local s2c_class = l_s2cIdToS2cClass[cmdId]
				if s2c_class then
					local event = s2c_class()
					event.msg = proto
					S2CManager.ResumeReceiveS2CCommandData(event)
				else
					warn("unhandled s2c protocol buffer type " .. cmdId)
				end
			else
				local ds_class = l_dsIdToDsClass[cmdId]
				if ds_class then
					local event = ds_class()
					event.msg = proto
					l_dsProtocolManager:raiseEvent(ProtocolManager, event)
				else
					warn("unhandled ds protocol buffer type " .. cmdId)
				end
			end
		end
	end

	---@param cmdName string
	---@param proto table
	---@return void
	def.static("string", "table").ResumePBProtoByName = function(cmdName, proto)
		local info = l_nameToInfo[cmdName]
		if info then
			pb_helper.ResumePBProto(info.id, proto)
		end
	end
	
end

return pb_helper.Commit()

