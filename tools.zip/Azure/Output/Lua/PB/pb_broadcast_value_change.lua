
--2015年2月2日
--Wang Yinliang
--
-- 广播 数据更改信息（暂时只广播官职等级变化）
-- gp_broadcast_value_change
-- 
local pb_helper = require "PB.pb_helper"
local ECGame = require "Main.ECGame"	


--[[
	message gp_broadcast_value_change{
	optional S2C_GS_PROTOC_TYPE type                = 1     [ default = type_gp_broadcast_value_change ];
	required int64 roleid				= 2;
	enum VALUE_TYPE {
		VT_DUKE_LEVEL	=  1;
	}
	required VALUE_TYPE value_type			= 3;
	required int32 new_value			= 4;
}

--]]
local function on_broadcast_value_change( sender,msg )
	--print("gp_broadcast_value_change")
	
	if msg.value_type == 1 then	--爵位等级变化
		local roleid = msg.roleid
		local new_value = msg.new_value

		local game = ECGame.Instance()
		local world = game.m_CurWorld
		local host = game.m_HostPlayer
		if msg.roleid == host.ID then
			if host.InfoData then
				host.InfoData.DukeLv = new_value
				--print("自己的官职等级变化了111111", new_value)
			end
		else
			local player = ECGame.Instance().m_CurWorld.m_PlayerMan:GetElsePlayer(msg.roleid)
			if player and player.InfoData then
				player.InfoData.DukeLv = new_value
				--print("其它的官职等级变化了222222222", new_value)
			end
		end

	end
end

pb_helper.AddHandler("gp_broadcast_value_change", on_broadcast_value_change)
