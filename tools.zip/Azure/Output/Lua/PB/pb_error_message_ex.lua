local Lplus = require "Lplus"
local pb_helper = require "PB.pb_helper"
---@type ECGame
local ECGame = Lplus.ForwardDeclare("ECGame")

local function OnErrorMsgHandler(sender, msg)
    local ElementData = require "Data.ElementData"
    ---@type pb.Enum.ERROR.ERROR_CODE
    local ERROR_CODE = require "PB.error_code".ERROR_CODE
	local errorCode = msg.err_code
    local roleId = msg.roleid
    local instanceId = msg.instance_tid
    local param = msg.param1
    --warn("msg ===========",msg)
    if errorCode == 458 then
        local tooltip = StringTable.Get(74008)
        FlashTipMan.FlashTip(tooltip)
    elseif errorCode == 525  then
        local tooltip = StringTable.Get(74019)
        FlashTipMan.FlashTip(tooltip)
    elseif errorCode == 572 then
        local tooltip = StringTable.Get(74010)
        FlashTipMan.FlashTip(tooltip)
    elseif errorCode == 332 then
        local team = ECGame.Instance().m_HostPlayer.Team
        local member = team:GetMemberByID(roleId)

        if member then
            param = tonumber(param)
            local instanceCfg = ElementData.getDataByName("InstanceConfig", instanceId)
            if instanceCfg then
                local instanceDifDesc = StringTable.Get(66299 + param)
                local desc = StringTable.Get(74018):format(member.Name, instanceCfg.name, instanceDifDesc)
                FlashTipMan.FlashTip(desc)
            else
                warn("can not find InstanceConfig tid = ", instanceId)
            end
        else
            warn("can not find team member with roleId = ", LuaInt64.ToString(roleId))
        end
    elseif errorCode == ERROR_CODE.HD_NOT_EQUIP_HDP then
        local tooltip = StringTable.Get(1525)
        FlashTipMan.FlashTip(tooltip)

    elseif errorCode == ERROR_CODE.AUTO_LEARN_OFFICIAL then
        local tooltip = StringTable.Get(104052)
        FlashTipMan.FlashTip(tooltip)

    elseif errorCode == ERROR_CODE.SKILL_PLAN_AUTO_APPLY_PRESET then --技能方案自动切换为预设 param1:plan_id
        local planName = require "Skill.ECSkillTreeManager".Instance():GetCurPlanName(param)
        --print_wyl("-------planName--param-------", param, planName)
        local tooltip = string.format(StringTable.Get(104056), planName)
        FlashTipMan.FlashTip(tooltip)
    elseif errorCode == ERROR_CODE.ERROR_COMMON_USE_LIMIT_PROMPT then --通用使用限次 param1:通用使用限次模板
        ---@type pb.Message.PB.CommonUseLimit
        local cfg = ElementData.getDataByName("CommonUseLimit", param)
        if cfg then
            FlashTipMan.FlashTip(cfg.error_prompt)
        else
            warn("OnErrorMsgHandler: not found CommonUseLimit.", msg)
        end
    else
        if FlashTipMan.FlashTipByPBErrorCode(errorCode) then
        else
            warn("OnErrorMsgHandler", msg)
        end
    end
end

pb_helper.AddHandler("gp_error_message_ex", OnErrorMsgHandler)