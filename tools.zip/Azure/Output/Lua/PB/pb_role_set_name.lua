--[[
	取名
]]
local pb_helper = require "PB.pb_helper"
---@param msg pb.Message.PB.gp_role_set_name_result
pb_helper.AddHandler("gp_role_set_name_result", function (sender, msg)
	local StringTable = require "Data.StringTable"
	local ECPanelCreateRoleName = require "GUI.LoginRole.ECPanelCreateRoleName"
	local hp = globalGame:GetHostPlayer()
	local name = GameUtil.UnicodeToUtf8(msg.name)
	if hp and hp.ID == msg.role_id then
		if msg.errcode == 0 then
			hp:SetName(name)
			ECPanelCreateRoleName.Instance():OnNameChangeSuccess(name)
		else
			local errorCode = msg.errcode
			local pb_error_code = _G.require_config("Configs/pb_error_code.lua")
			local errMsg = pb_error_code[errorCode] or StringTable.Get(2623)
			FlashTipMan.FlashTip(errMsg)
			ECPanelCreateRoleName.Instance():OnNameChangeFail()
			warn("gp_role_set_name_result error", msg)
		end
	else
		local player = globalGame:FindObject(msg.role_id)
		if player then
			player:SetName(name)
		end
	end
end)
