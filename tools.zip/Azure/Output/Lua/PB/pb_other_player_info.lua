local Lplus = require "Lplus"

local pb_helper = require "PB.pb_helper"
local ECGame = require "Main.ECGame"

--
-- npt_get_player_profile
-- 查看玩家具体数据
local function on_get_player_profile(sender, msg)
	--print("on_get_player_profile", LuaUInt64.ToDouble(msg.data.roleid), msg)
	--print_jzw("on_get_player_profile",msg)
	if msg.ret_code == 2801 then
		FlashTipMan.FlashTip(StringTable.Get(75019))
		return
	end
	
	local ECPlayerProfileCache = require "Main.ECPlayerProfileCache"
	ECPlayerProfileCache.Instance():SetRoleInfo(msg)
	--ECPlayerProfileCache.Instance():AddBriefCache(msg.data)

	if ClientCfg.IsMSDK() then
		local account = msg.data.property.open_id
		local openid = account:match("^(.*)%$") or account
		print("account", account, "openid", openid)
		local MSDKInfo = require "MSDK.MSDKInfo"
		MSDKInfo.Instance():RecordUserOpenID(msg.data.roleid, openid)
	end

	local OtherPlayerInfo = require "Event.OtherPlayerInfo"
	local p = OtherPlayerInfo()
	p.msg = msg.data

	ECGame.EventManager:raiseEvent(nil, p)
end
pb_helper.AddHandler("npt_get_player_profile", on_get_player_profile)
