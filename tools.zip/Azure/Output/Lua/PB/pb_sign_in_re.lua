local pb_helper = require "PB.pb_helper"


local on_gp_sign_in_re =  function(_, msg)
	print_ygao("on_gp_sign_in_re", msg)

	if msg.retcode ~= 0 then
		warn(("sign_in_re retcode=%d reward_tid=%d times_reward_tid=%d"):format(msg.retcode , msg.reward_tid , msg.times_reward_tid))
	end

	-- msg.retcode
	-- msg.items
	-- msg.reward_tid
	-- msg.times_reward_tid
	local welfareStarlight = require "GUI.Welfare.UISubPanelWelfareStarlight".Instance()
	welfareStarlight:SetRewards(msg.items,msg.reward_tid,msg.times_reward_tid)
	if msg.retcode == 0 then
		require "Tlog.TLogHelper".SendLogWithWelfareName("12","Starlight","reward_tid="..msg.reward_tid)

		welfareStarlight:IncDays()
		local UIPanelWelfareMain = require("GUI.Welfare.UIPanelWelfareMain")
		local panelWelfareMain = UIPanelWelfareMain.Instance()
		if panelWelfareMain:IsValid() then
			panelWelfareMain:RefreshUI()
		end
		panelWelfareMain:ShowWithTargetTabName("Starlight")
	end
end
pb_helper.AddHandler("gp_sign_in_re", on_gp_sign_in_re)