
--
-- 招募组队平台
-- npt_team_recruit_operate_reply
-- 
local pb_helper = require "PB.pb_helper"
local ECGame = require "Main.ECGame"
local TeamRecruitEvent = require "Event.TeamRecruitEvent"



local function on_team_recruit( sender,msg )
	--warn("npt_team_recruit_operate_reply ========================", msg)

	--local ECGame = Lplus.ForwardDeclare("ECGame")
	local client_msg = require "PB.client_msg"
	if msg.operate_type ==  client_msg.npt_team_recruit_operate.CLAN_INVITE then
		ECGame.Instance().m_ClanMan:OnClanRecurit(msg)
	else
		local TeamMan = require "Social.ECTeam".ECTeamMan.Instance()
		local ECTeamPlatFormManager = require "TeamPlatform.ECTeamPlatFormManager"

		if msg.operate_type == 1 or msg.operate_type == 6 then --创建 or 修改
			if msg.operate_result == 1 then 
				FlashTipMan.FlashTip(StringTable.Get(13002)) --超过最大数
				return
			elseif msg.operate_result == 2 then 
				FlashTipMan.FlashTip(StringTable.Get(13003)) --小于最低等级
				return
			elseif msg.operate_result == 0 then				 --成功
				-- TeamMan:OnCmd_TeamRecruit_Operate( msg ) --下面已经处理了
			end
		elseif msg.operate_type == 2 then --搜索
		elseif msg.operate_type == 3 then --发布
		elseif msg.operate_type == 4 then --取消

		end

		ECTeamPlatFormManager.Instance():OnCmd_TeamRecruit_Operate( msg )

		 local event = TeamRecruitEvent()
		 event.operateType = msg.operate_type
		 event.resultType = msg.operate_result
		 ECGame.EventManager:raiseEvent(nil, event)
	end
end

pb_helper.AddHandler("npt_team_recruit_operate_reply", on_team_recruit)
