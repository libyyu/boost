local Lplus = require "Lplus"

local pb_helper = require "PB.pb_helper"

--
-- gp_secure_idip
-- 
--
--1 零收益
--2 上线消息
--3 封禁排行榜
--4 封禁某个游戏玩法
--5 封禁所有玩法
--
local function on_gp_secure_idip( sender,msg )
	--print("on_gp_secure_idip:",msg,msg.content)
	local ECGame = require "Main.ECGame"
	local function func()

		ECGame.Instance().m_HostPlayer:OnSecureIdipMsg(msg)
	end
	--确保 m_HostPlayer创建完成
	ECGame.Instance():OnHostPlayerCreate(func)
end

pb_helper.AddHandler("gp_secure_idip", on_gp_secure_idip)