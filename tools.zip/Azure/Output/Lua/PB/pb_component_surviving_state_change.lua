local Lplus = require "Lplus"
local pb_helper = require "PB.pb_helper"

local function on_component_surviving_state_change(sender, msg)
    local ECGame = require "Main.ECGame"
    ---@type ECNPC
    local npc = ECGame.Instance():FindObject(msg.npc_id)
    if npc then
        npc:SetComponentNpcSurvivingState(msg.surviving_state)
    end

end
pb_helper.AddHandler("gp_component_surviving_state_change", on_component_surviving_state_change)
