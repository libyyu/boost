local pb_helper = require "PB.pb_helper"

-- --最开始转盘数据推送 
-- local function on_gp_notify_activity_plate( sender,msg )
-- 	--warn("->on_gp_activity_plate_notify", msg)
-- --	local ECTurntableData = require "Data.ECTurntableData"
-- --	ECTurntableData.Instance():StorageData(msg)
-- end
-- pb_helper.AddHandler("gp_notify_activity_plate", on_gp_notify_activity_plate)

-- --获取转盘id
-- local function on_gp_activity_plate_result( sender,msg )
-- 	--warn("->gp_activity_plate_result", msg)
-- --	local ECTurntableData = require "Data.ECTurntableData"
-- --	ECTurntableData.Instance():StorageGetPlateTidData(msg)
-- end
-- pb_helper.AddHandler("gp_activity_plate_result", on_gp_activity_plate_result)

-- --转盘结果
-- local function on_gp_activity_plate_notify( sender,msg )
-- 	--warn("->on_gp_activity_plate_notify", msg)
-- --	local ECTurntableData = require "Data.ECTurntableData"
-- ---	ECTurntableData.Instance():StorageResultData(msg)
-- end
-- pb_helper.AddHandler("gp_activity_plate_notify", on_gp_activity_plate_notify)


-- --换个转盘 
-- local function on_gp_activity_plate_new( sender,msg )
-- 	--warn("->on_gp_activity_plate_new", msg)
-- --	local ECTurntableData = require "Data.ECTurntableData"
-- --	ECTurntableData.Instance():StorageNewData(msg)
-- end
-- pb_helper.AddHandler("gp_activity_plate_new", on_gp_activity_plate_new)