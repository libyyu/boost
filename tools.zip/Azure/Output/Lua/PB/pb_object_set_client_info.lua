local pb_helper = require "PB.pb_helper"
local client_msg = require "PB.client_msg"
local ECPanelBloodManager = require "GUI.Main.ECPanelBloodManager"
local Lplus = require "Lplus"
---@type ECGame
local ECGame = Lplus.ForwardDeclare("ECGame")

local function on_object_set_client_info(sender, msg)
    if msg.client_typ == 1 then--boss进入暴怒
        ---@deprecated 暴怒状态改为BKStateChange协议通知
        --ECPanelBloodManager.Instance():showAngryBreak(msg.client_num)
    end
end

pb_helper.AddHandler("gp_object_set_client_info", on_object_set_client_info)