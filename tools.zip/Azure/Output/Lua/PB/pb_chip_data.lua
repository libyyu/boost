local Lplus = require "Lplus"
local pb_helper = require "PB.pb_helper"

---@type ECGame
local ECGame = Lplus.ForwardDeclare("ECGame")
local ChipDataInfoChangedEvent = require "Event.ChipDataInfoChangedEvent"

local function on_chip_data(sender, msg)
	local ECChipData = require "GUI.AutoFightChip.ECChipData"
	-- db_player_chip data
	-- -- map<int32, chip_info> chips
	local chipData = ECChipData.Instance()

	--print_ygao("*** on_chip_data msg.have_all_chips",ToBoolean(msg.have_all_chips ~= 0))
	if(msg.have_all_chips == 1)then
		chipData:ResetChip()
	end

	for key , va in pairs(msg.data.chips) do
		local ID				= key
		local chip_info			= va
		--local equipped			= chip_info.is_equiped
		local basic_addon_data	= chip_info.prop.basic_addon_data
		local random_addon_data = chip_info.prop.random_addon_data
		--print_ygao("*** on_chip_data ID", ID)
		--chipData:SetCode(ID,equipped,basic_addon_data,random_addon_data)
		chipData:SetCode(ID , basic_addon_data , random_addon_data , msg.have_all_chips == 1)
	end

	--print_ygao("*** on_chip_data msg.data.unlock_plan_num" , msg.data.unlock_plan_num)
	local old_unlock_plan_num = chipData:GetPlanCount()
	if(msg.data.unlock_plan_num > 0)then
		chipData._planCount = msg.data.unlock_plan_num
	end

	local needRefresh = false

	local planChanged = false
	for key , va in pairs(msg.data.plans) do
		local idx = key + 1
		local name = GameUtil.UnicodeToUtf8(va.name)
		local tids = va.tids
		--print_ygao(string.format("*** on_chip_data idx=\"%d\" name=\"%s\" #tids=\"%d\" tids=\"%s\"", idx , name , #tids,tostring_r(tids)))
		--for asd , sdf in pairs(tids) do
		--	print_ygao("*** on_chip_data idx name asd , sdf", asd , sdf)
		--end
		planChanged = true
		chipData:SetPlan(idx,name , tids)
		if(idx == chipData:GetCurrPlanID())then
			needRefresh = true
			--print_ygao(string.format("*** on_chip_data idx=\"%d\"" , idx), idx == chipData:GetCurrPlanID())
		end
	end

	local oldPlanID = chipData:GetCurrPlanID()
	local newPlanID = msg.data.cur_plan_id + 1 -- 服务器 从0开始

	--print_ygao("*** on_chip_data SetCurrPlanID 1111 oldPlanID , newPlanID", oldPlanID , newPlanID)
	if(oldPlanID ~= newPlanID or msg.have_all_plans)then
		--print_ygao("*** on_chip_data SetCurrPlanID 2222 oldPlanID , newPlanID", oldPlanID , newPlanID)
		chipData:SetCurrPlanID(newPlanID)
		needRefresh = true

		local ChipDataCurrPlanChangedEvent = require("Event.ChipDataCurrPlanChangedEvent")
		local event = ChipDataCurrPlanChangedEvent()
		event._oldPlanID = oldPlanID
		event._newPlanID = newPlanID
		ECGame.EventManager:raiseEvent(nil, event)
	end

    if planChanged then
        chipData:RefreshCurrPlan()
    end

	chipData:RefreshCurrPlanScheme()

	local event = ChipDataInfoChangedEvent()
	event.planChanged = planChanged
	event.unlockPlanNumChanged = old_unlock_plan_num > 0 and old_unlock_plan_num ~= chipData:GetPlanCount()
	ECGame.EventManager:raiseEvent(nil, event)
end
pb_helper.AddHandler("gp_chip_data", on_chip_data)