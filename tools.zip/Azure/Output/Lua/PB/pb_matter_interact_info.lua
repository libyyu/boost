local Lplus = require "Lplus"

local pb_helper = require "PB.pb_helper"

local ECGame = require "Main.ECGame"
local EC = require "Types.Vector3"
local ECFxMan = require "Fx.ECFxMan"
local AttData = require "Data.AttData"

local ZERO_VEC = EC.Vector3.zero
local ONE_VEC = EC.Vector3.one

local tmpvec = EC.Vector3.new()
local tmpvec2 = EC.Vector3.new()
local tmpvec3 = EC.Vector3.new()

local function on_matter_interact_info( sender, msg )
	--warn("--------- on_matter_interact_info ---------", msg.op_type,LuaUInt64.ToString(msg.matter_id))

	local curWorld = ECGame.Instance().m_CurWorld
	if not curWorld then return end

	local ECInteractBehaviorMan = require "Interact.ECInteractBehaviorMan"
	ECInteractBehaviorMan.Instance():NotifyInteract(msg)

	--if msg.op_type == 1 then
	--	ECInteractBehaviorMan.Instance():OnInteractStart(msg)
	--end
end
pb_helper.AddHandler("gp_matter_interact_info", on_matter_interact_info)



--local function on_gp_buff_box_fx( sender, msg )
--	local curWorld = ECGame.Instance().m_CurWorld
--	if not curWorld or not curWorld.m_MatterMan then return end
--
--	local matter = curWorld.m_MatterMan:GetMatter(msg.matter_id)
--	if not matter or not matter.Essence then return end
--
--	matter:SetLogicalVisible(false,false)
--
--	local att_id = matter.Essence.fx_path
--	if not att_id or att_id == 0 then
--		warn("__on_gp_buff_box_fx: att_id == 0! matter_tid = ", matter.Essence.id)
--		return
--	end
--
--	local attInstance = AttData.Instance()
--
--	local attdata = attInstance:GetAttData(att_id)
--	if not attdata then
--		warn("__on_gp_buff_box_fx: NO attData for att_id, matter_tid:", att_id, matter.Essence.id)
--		return
--	end
--
--	local startpos = tmpvec3
--	AttData.FillAttStartPos(startpos, matter, attdata)
--
--	local fxPrio = FXPRIO.MIDDLE
--	AttData.PlayBornEffects(attdata, startpos, false, fxPrio)
--
--	local matterPos = matter:GetPos()
--
--	for k,v in pairs(msg.fx_info) do
--		if v.roleid then
--			local target = curWorld:FindObjectOrHost(v.roleid)
--			if target then
--				local needHighLod = target._isHost
--
--				if v.cost_time > 0 then
--					local fx_path = attdata.path
--					if fx_path ~= "" then
--						tmpvec:subRaw(matterPos, target:GetPos())
--						local dist = tmpvec:get_Length()
--						local dur = v.cost_time/1000
--						--local speed = dist/(dur > 0.1 and dur or 0.1)
--
--						local duration = dur + 1.5
--
--						local num = (attdata.num and attdata.num > 0) and attdata.num or 1
--
--						for i = 1,num do
--							attInstance:PlayFlyAndBoomEffect(att_id, attdata, startpos, matter, target, needHighLod, fxPrio, duration, nil, matter:GetDir())
--						end
--					end
--				else --瞬发
--					if attdata.boompath and attdata.boompath ~= "" then
--
--						local tarPos = AttData.FillAttEndPos(target, attdata)
--
--						local SkillGfxParam = require"Fx.SkillGfxParam"
--						local skillGfmParam = SkillGfxParam.new()
--
--						local fx
--						if attdata.boomattach then
--							skillGfmParam.resName = attdata.boompath
--							skillGfmParam.transform = {}
--							skillGfmParam.prio = fxPrio
--							skillGfmParam.lifetime = attdata.boomduration
--							skillGfmParam.needHighLod = false
--							skillGfmParam.extendParam = {}
--							skillGfmParam.extendParam.parent = target.m_RootObj
--							skillGfmParam.extendParam.socketname = attdata.tarsocket
--							fx = ECFxMan.Instance():PlayAsChild(skillGfmParam)
--						else
--							skillGfmParam.resName = attdata.boompath
--							skillGfmParam.transform = { translation = tarPos }
--							skillGfmParam.prio = fxPrio
--							skillGfmParam.lifetime = attdata.boomduration
--							skillGfmParam.needHighLod = false
--							fx = ECFxMan.Instance():Play(skillGfmParam)
--						end
--						if fx then
--							local scale = attdata.boomscale and attdata.boomscale or 1
--							fx:SetActorLocalScale(scale,scale,scale)
--						end
--						if attdata.boomsound and attdata.boomsound > 0 then
--							--ECSoundMan.Instance():Play3DSoundByID(not target._isHost, attdata.boomsound, tarPos)
--						end
--					end
--				end
--			end
--		end
--	end
--end
--
--pb_helper.AddHandler("gp_buff_box_fx", on_gp_buff_box_fx)