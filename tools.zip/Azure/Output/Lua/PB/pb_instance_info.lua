local pb_helper = require "PB.pb_helper"
local client_msg = require "PB.client_msg"
local FEInstanceMan = require "Instance.FEInstanceMan"
local ECGame = require "Main.ECGame"

local function on_instance_info(sender, msg)
    FEInstanceMan.Instance():OnInstanceInfo(msg)
end
pb_helper.AddHandler("gp_instance_info", on_instance_info)

local function temporary_storage_notify(sender, msg)
    FEInstanceMan.Instance():OnTemporaryStorageNotify(msg)
end
pb_helper.AddHandler("gp_temporary_storage_notify", temporary_storage_notify)

local function no_vit_state_notify(sender, msg)
    local hp = ECGame.Instance():GetHostPlayer()
    if hp then
        hp:UpdateIsInstanceNoRepuMode(msg.no_vit)
    end
end
pb_helper.AddHandler("gp_no_vit_state_notify", no_vit_state_notify)

local function notify_ts_show_button(sender, msg)
    FEInstanceMan.Instance():ShowExtraBagBtn()
end
pb_helper.AddHandler("gp_notify_ts_show_button", notify_ts_show_button)

local function on_level_client_param(sender, msg)
    FEInstanceMan.Instance():UpdateLevelParams(msg)
end
pb_helper.AddHandler("gp_level_client_param", on_level_client_param)

local function on_gp_instance_ban_pick_s2c(sender, msg)
    --warn("on_gp_instance_ban_pick_s2c ", msg)
    local ECTeamPvPWithBanBuildMan = require "Instance.ECTeamPvPWithBanBuildMan" 
    ECTeamPvPWithBanBuildMan.Instance():OnInstanceBanPickInfo(msg)
end
pb_helper.AddHandler("gp_instance_ban_pick_s2c", on_gp_instance_ban_pick_s2c)

local function SetNoVitMode(state)
    if type(state) ~= "boolean" then
        return
    end
    local msg = client_msg.gp_no_vit_state()
    msg.no_vit = state
    pb_helper.Send(msg)
end

local function RequestTSReward()
    local msg = client_msg.gp_vit_reward()
    pb_helper.Send(msg)
end

return {
    SetNoVitMode = SetNoVitMode,
    RequestTSReward = RequestTSReward
}