local Lplus = require "Lplus"
local pb_helper = require "PB.pb_helper"

local function OnTeamExpAddResponse(sender, msg)
	local data = ElementData.getDataByName("TeamAddonExp", 1)
	local exp = math.floor(data.exp_ratio * 100)
	FlashTipMan.FlashTip(string.format(StringTable.Get(13039), exp))
end
pb_helper.AddHandler("gp_team_addon_exp", OnTeamExpAddResponse)

