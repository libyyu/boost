local Lplus = require "Lplus"

local pb_helper = require "PB.pb_helper"
local CommonInvite = require "Protocol.CommonInvite"
local FriendMan = require "Friends.FriendMan"
local bit = require "bit"
local band = bit.band
--
-- on_friend_invite
--
--[[
local function isDisCard(name, msg)
    if name == "" then
        return false
    end
    local ECGame = require "Main.ECGame"
    if name == ECGame.Instance().m_HostInfo.name:getStringUnicode() then
        return false
    end
    local FriendMan = require "Friends.FriendMan"
    if msg.detail and FriendMan.Instance():GetBlacklist(msg.detail.roleid) then
    	return true
    end

    local isBlack = FriendMan.Instance():GetBlacklistByName(name)
    return not not isBlack
end

local function make_apply_info(msg)
	local client_msg = require "PB.client_msg"
	local apply_info = client_msg.apply_info()
	apply_info.roleid = msg.detail.roleid
	--apply_info.photo_id
	apply_info.level = msg.level
	apply_info.profession = msg.profession
	apply_info.name = msg.name
	apply_info.apply_message = msg.content
	apply_info.gender = msg.detail.gender

	return apply_info
end
]]--
--[[
message npt_friend_invite {
	option (npt_type) = NPT_FRIEND_INVITE;
	bytes name			= 2;
	int32 level			= 3;
	int32 profession		= 4;
	int32 group			= 5;
	roamer_ds_info detail		= 6;
	string content			= 7;
}]]
local function on_friend_invite( sender,xid,msg, isinvite_ )
	print_Friend("on_friend_invite",xid, isinvite_, msg)
	--print_xf("on_friend_invite",xid, isinvite_, msg)
	--for i,v in  pairs(msg.detail.ext_info.uuid_list.uuid_lists) do
	--	if v.oss_type == 3 then
	--		print_xf("v.name",v.name)
	--
	--	end
	--end
	--print_hsh("xid,msg, isinvite_   ",xid,msg, isinvite_)
	--for i,v in pairs(msg) do
	--	print_hsh("msg  ",i,v)
	--end
	--[[
	local UserData = require "Data.UserData".Instance()
	if not UserData:GetSystemCfg("FriendInviteToggle") then --接受加好友声请
		return
	end
	if isDisCard(GameUtil.UnicodeToUtf8(msg.name), msg) then
		return
	end
	local ECGame = require "Main.ECGame"
	local FriendMan = require "Friends.FriendMan"
	local auto_admit = UserData:GetRoleCfg("AutoReceiveFriend") --自动接受好友申请
	]]--
	local isinvite = isinvite_ == 1
	local f = {}
	f.msg = msg
	f.xid = xid

	local UIFriendInvite = require "Friends.GUI.UIFriendInvite"
	UIFriendInvite.Instance():AddNewFriendInvite(f,isinvite)

	--[[
	if not FriendMan.Instance():FindInvite(f) then
		FriendMan.Instance():AddInvite(f)
	end
	local ttl = 31
	if not auto_admit then
		MsgBox.ShowMsgBox(f,string.format(StringTable.Get(1127),GameUtil.UnicodeToUtf8(msg.name),GameUtil.UnicodeToUtf8(msg.content), ttl),nil,MsgBox.MsgBoxType.MBBT_OKCANCEL,function(sender,ret)
			local ci = CommonInvite()
			if MsgBox.MsgBoxRetT.MBRT_OK == ret then
				if FriendMan.Instance():IsFriendsFull() then
					FlashTipMan.FlashTip(StringTable.Get(67114))
					FriendMan.Instance():RemoveInvite(sender)
					--:加入申请列表
					local apply = make_apply_info(msg)
					FriendMan.Instance():DoOneApply(apply, isinvite, true)
					return
				end
				ci.retcode = 0
			else
				ci.retcode = 1
			end
			ci.isinvite = 0
			ci.xid = band(sender.xid, 0x7FFFFFFF)
			ECGame.Instance().m_Network:SendProtocol(ci)
			FriendMan.Instance():RemoveInvite(sender)
		end,ttl,function(box)
			if box.LifeTime <= 0 then
				--超时未同意，加入申请列表
				if box.sender then
					FriendMan.Instance():RemoveInvite(box.sender)
				end
				box:DestroyPanel()
				--:加入申请列表
				local apply = make_apply_info(msg)
				FriendMan.Instance():DoOneApply(apply, isinvite, true)
				return
			else
				box:SetText(string.format(StringTable.Get(1127),GameUtil.UnicodeToUtf8(msg.name),GameUtil.UnicodeToUtf8(msg.content), box.LifeTime))
			end
		end)
	else
		if FriendMan.Instance():IsFriendsFull() then
			FlashTipMan.FlashTip(StringTable.Get(67114))
			FriendMan.Instance():RemoveInvite(sender)
			--:加入申请列表
			local apply = make_apply_info(msg)
			FriendMan.Instance():DoOneApply(apply, isinvite, true)
			return
		end
		local ci = CommonInvite()
		ci.retcode = 0
		ci.isinvite = 0
		ci.xid = band(f.xid, 0x7FFFFFFF)
		ECGame.Instance().m_Network:SendProtocol(ci)
		FriendMan.Instance():RemoveInvite(f)
	end
	]]--
end

pb_helper.AddHandler("npt_friend_invite", on_friend_invite)

local function on_friend_relation_change( sender,msg )
	local m={}
	--print("on_friend_relation_change type",msg.type)

	m.type = msg.type
	m.friend = msg.friendid
	FriendMan.Instance():OnFriendRelationChange(m)
end
pb_helper.AddHandler("npt_friend_relation_change", on_friend_relation_change)
--[[
message npt_friend_apply_update {
	option (npt_type) = NPT_FRIEND_APPLY;
	enum OP_TYPE {
		OT_ALL			= 0;
		OT_ADD          = 1;
		OT_DEL          = 2;
		OT_DEL_ALL      = 3;
	};
	OP_TYPE op						= 2;
	repeated apply_info apply		= 3;
}
]]
local function on_friend_apply_update(_, msg)
	FriendMan.Instance():UpdateOneApply(msg.apply, msg.op)
end
pb_helper.AddHandler("npt_friend_apply_update", on_friend_apply_update)


-- --
-- --npt_set_command_notify 聊天设置
-- --
local function on_npt_set_command_notify(sender, msg)
	--local ECSettingSocialPage = require "GUI.Setting.ECSettingSocialPage"
    --ECSettingSocialPage.Instance():SetChatAcceptStranger(msg.command.forbid_stranger_info == 0)
	local ECSettingChatPage = require "GUI.Setting.ECSettingChatPage"
	ECSettingChatPage.Instance():SetChatAcceptStranger(msg.command.forbid_stranger_info == 0)

	--隐私设置
	local role_info = msg.command.hide_role_profile
	local faction_login = msg.command.hide_mafia_login
	local rank_anonymous = msg.command.hide_toplist
	local ECSettingPrivacyPage = require "GUI.Setting.ECSettingPrivacyPage"
	ECSettingPrivacyPage.Instance():SetPrivacyInfo(role_info, faction_login, rank_anonymous)
	--[[local ECGame = require "Main.ECGame"
	local client_msg = require "PB.client_msg"
	local id = client_msg.npt_set_command["CT_NO_STRANGER"]
	local FriendMsgSettingEvt = (require "Event.FriendEvent").FriendMsgSettingEvt()
	FriendMsgSettingEvt.id = id
	FriendMsgSettingEvt.value = msg.command.forbid_stranger_info
	ECGame.EventManager:raiseEvent(nil, FriendMsgSettingEvt)]]
end
pb_helper.AddHandler("npt_set_command_notify", on_npt_set_command_notify)


-- --
-- --npt_role_online_status_re
-- --
-- local function on_npt_role_online_status_re(sender,msg)
-- 	local ECFriendMan = require "Social.ECFriendMan"
-- 	ECFriendMan.Instance():OnPrtc_PlayerStatus(msg)
-- end

-- pb_helper.AddHandler("npt_role_online_status_re",on_npt_role_online_status_re)

--
--npt_get_friend_recommend_re
--

local function on_npt_get_friend_recommend_re(sender, msg)
	--local ECPanelAddFriend = require "GUI.Friend.ECPanelAddFriend"
	--ECPanelAddFriend.Instance():RecvRecommendedFriends(msg)
	--print_Friend("npt_get_friend_recommend_re", msg)
	require"Friends.RecommendMan".Instance():OnSyncRecommendFriends(msg)
end
pb_helper.AddHandler("npt_get_friend_recommend_re", on_npt_get_friend_recommend_re)

local function on_npt_get_player_attr_re(sender, msg)
	print_Friend("on_npt_get_player_attr_re", msg)
	--print_xf("on_npt_get_player_attr_re", msg)
	--print("on_npt_get_player_attr_re", msg)
	FriendMan.Instance():OnPlayersAttrRe(msg)
end
pb_helper.AddHandler("npt_get_players_attr", on_npt_get_player_attr_re)

-- --
-- --npt_recommend_friend
-- --
-- local function on_npt_recommend_friend(sender,msg)
-- 	local ECFriendMan = require "Social.ECFriendMan"
-- 	---@type ECGame
-- 	local ECGame = Lplus.ForwardDeclare("ECGame")
-- 	--warn(LuaUInt64.ToString(msg.roleid),msg.roleid == ECGame.Instance().m_HostPlayer.ID)
-- 	if msg.roleid == ECGame.Instance().m_HostPlayer.ID or 
-- 		ECFriendMan.Instance():IsPlayerYourFriend(msg.roleid) then
-- 		return 
-- 	end

-- 	local desc = StringTable.Get(22920):format(GameUtil.UnicodeToUtf8(msg.name))
-- 	MsgBox.ShowMsgBox(nil,desc,nil,MsgBoxType.MBBT_OKCANCEL,function(_,ret)
-- 		if ret == MsgBoxRetT.MBRT_OK then
-- 			local ECFriendMan = require "Social.ECFriendMan"
-- 			ECFriendMan.friend_add(msg.roleid,GameUtil.UnicodeToUtf8(msg.name),0)
-- 		end
-- 	end,
-- 		15,
-- 		function(box)
-- 			if box.LifeTime > 0 then
-- 				local descwithtime = desc.. StringTable.Get(2402):format(box.LifeTime)
-- 				box:SetText(descwithtime)
-- 			else
-- 				box:onClick("Btn_Refuse")
-- 			end
-- 		end
-- 	)
-- end

-- pb_helper.AddHandler("npt_recommend_friend",on_npt_recommend_friend)

-- --
-- --npt_recv_friend_gift
-- --

-- local function on_npt_recv_friend_gift(sender,msg)
-- 	local ECFriendAmityMan = require "Social.ECFriendAmityMan"
-- 	ECFriendAmityMan.Instance():RecvFriendGift(msg)
-- end

-- pb_helper.AddHandler("npt_recv_friend_gift",on_npt_recv_friend_gift)

-- --
-- --npt_send_friend_gift_re  协议设计，操作成功失败 和操作结果应该分开吧
-- --
-- local function on_npt_send_friend_gift_re(sender,msg)
-- 	local ECFriendAmityMan = require "Social.ECFriendAmityMan"
-- 	ECFriendAmityMan.Instance():GiveFriendGift_Re(msg) 

-- end

-- pb_helper.AddHandler("npt_send_friend_gift_re",on_npt_send_friend_gift_re)


-- --
-- --npt_send_item_2_friend_re 这个是赠送物品返回给赠送方的协议！！！！！
-- --
-- local function on_npt_send_item_2_friend_re(sender,msg)
-- 	if msg.result == 0 then
-- 		local ECFriendMan = require "Social.ECFriendMan"
-- 		local friendinfo = ECFriendMan.Instance():GetFriend(msg.friend_id)
-- 		FlashTipMan.FlashTip(StringTable.Get(23029):format(friendinfo and friendinfo.name or ""))
-- 	else
-- 		FlashTipMan.FlashTip(StringTable.Get(23030))
-- 	end
-- end
-- pb_helper.AddHandler("npt_send_item_2_friend_re",on_npt_send_item_2_friend_re)

-- --[[

-- message npt_friend_like_re
-- {
-- 	optional NET_PROTOCBUF_TYPE type	= 1	[ default = NPT_FRIEND_LIKE_RE ];
-- 	repeated int64 like_list		= 2;
-- 	repeated int64 be_like_list		= 3;
-- }
-- ]]

-- --
-- --点赞记录
-- --
-- local function on_npt_friend_like_re(sender,msg)
-- 	local ECFriendMan = require "Social.ECFriendMan"
-- 	ECFriendMan.Instance():OnPrtc_FriendLike(msg)
-- 	if msg.r_type == 2 then -- lick 
-- 		local FriendCommonConfig = ElementData.getSingletonDataByName("FriendCommonConfig")
-- 		local amitynum = FriendCommonConfig.like_add_amity
-- 		FlashTipMan.FlashTip(StringTable.Get(23064):format(amitynum))
-- 	end
-- end
-- pb_helper.AddHandler("npt_friend_like_re",on_npt_friend_like_re)


-- 好友祝贺，非更新，一般是一个列表，或玩家操作的结果
local function on_npt_frient_lottery_share_re(sender,msg)
	local CongratulateManager = require "Friends.Congratulate.CongratulateManager"
	--print_hsh("npt_frient_lottery_share_re  ",msg.op,msg.retcode)
	--print_jzw("npt_frient_lottery_share_re  ",msg.op,msg.retcode,msg)
	if FlashTipMan.FlashTipByPBErrorCode(msg.retcode) then
		return
	end
	CongratulateManager.Instance():SetCongratulateTodayCount(msg.wish_times)

	if msg.op == 1 then				--获取祝福列表
		CongratulateManager.Instance():ResetCongratulate(CongratulateManager.CongratulateType.GetPeople_S2O,msg.me2other_list)

		local CongratulateUpdateEvent = require "Event.CongratulateUpdateEvent"
		require"Main.ECGame".EventManager:raiseEvent(nil, CongratulateUpdateEvent.new(CongratulateManager.CongratulateType.GetPeople_S2O))
	elseif msg.op == 2 then			--获取留言列表
		CongratulateManager.Instance():ResetCongratulate(CongratulateManager.CongratulateType.GetPeople_O2S,msg.other2me_list)

		local CongratulateUpdateEvent = require "Event.CongratulateUpdateEvent"
		require"Main.ECGame".EventManager:raiseEvent(nil, CongratulateUpdateEvent.new(CongratulateManager.CongratulateType.GetPeople_O2S))
	elseif msg.op == 3 or msg.op == 6 then			--祝福
		CongratulateManager.Instance():SetCongratulateStateByUuid(CongratulateManager.CongratulateType.GetPeople_S2O,msg.unique_ids[1],true)
		CongratulateManager.Instance():ShowCongratulateReward(CongratulateManager.CongratulateType.GetPeople_S2O,msg.unique_ids)

		local CongratulateUpdateEvent = require "Event.CongratulateUpdateEvent"
		require"Main.ECGame".EventManager:raiseEvent(nil, CongratulateUpdateEvent.new(CongratulateManager.CongratulateType.GetPeople_S2O))
	elseif msg.op == 4 then			--收下一个留言
		CongratulateManager.Instance():SetCongratulateStateByUuid(CongratulateManager.CongratulateType.GetPeople_O2S,msg.unique_ids[1],true)
		CongratulateManager.Instance():ShowCongratulateReward(CongratulateManager.CongratulateType.GetPeople_O2S,msg.unique_ids)

		local CongratulateUpdateEvent = require "Event.CongratulateUpdateEvent"
		require"Main.ECGame".EventManager:raiseEvent(nil, CongratulateUpdateEvent.new(CongratulateManager.CongratulateType.GetPeople_O2S))
	elseif msg.op == 5 then			--一键收下留言
		for i,v in pairs(msg.unique_ids) do
			CongratulateManager.Instance():SetCongratulateStateByUuid(CongratulateManager.CongratulateType.GetPeople_O2S,v,true)
		end
		CongratulateManager.Instance():ShowCongratulateReward(CongratulateManager.CongratulateType.GetPeople_O2S,msg.unique_ids)

		local CongratulateUpdateEvent = require "Event.CongratulateUpdateEvent"
		require"Main.ECGame".EventManager:raiseEvent(nil, CongratulateUpdateEvent.new(CongratulateManager.CongratulateType.GetPeople_O2S))
	end
end
pb_helper.AddHandler("npt_frient_lottery_share_re",on_npt_frient_lottery_share_re)

-- 好友祝贺，更新，一般为单条信息更改
local function on_npt_frient_lottery_share_update(sender,msg)
	local CongratulateManager = require "Friends.Congratulate.CongratulateManager"
	print_hsh("npt_frient_lottery_share_update  ",msg.op)
	--print_jzw("npt_frient_lottery_share_update  ",msg.op,msg)

	if msg.op == 1 then				--祝福次数每日清零
		CongratulateManager.Instance():SetCongratulateTodayCount(0)
	elseif msg.op == 2 then  		--更新祝福列表
		CongratulateManager.Instance():DeleteCongratulateByUuid(CongratulateManager.CongratulateType.GetPeople_S2O,msg.update_me2other_data.delete_unique_id)
		CongratulateManager.Instance():AddCongratulate(CongratulateManager.CongratulateType.GetPeople_S2O,msg.update_me2other_data.add_info)
		CongratulateManager.Instance():ShowCongratulateInfoInPrivateMessage(CongratulateManager.CongratulateType.GetPeople_S2O,msg.update_me2other_data.add_info)

		local CongratulateUpdateEvent = require "Event.CongratulateUpdateEvent"
		require"Main.ECGame".EventManager:raiseEvent(nil, CongratulateUpdateEvent.new(CongratulateManager.CongratulateType.GetPeople_S2O))
	elseif msg.op == 3 then  		--更新留言列表
		CongratulateManager.Instance():DeleteCongratulateByUuid(CongratulateManager.CongratulateType.GetPeople_O2S,msg.update_other2me_data.delete_unique_id)
		CongratulateManager.Instance():AddCongratulate(CongratulateManager.CongratulateType.GetPeople_O2S,msg.update_other2me_data.add_info)
		CongratulateManager.Instance():ShowCongratulateInfoInPrivateMessage(CongratulateManager.CongratulateType.GetPeople_O2S,msg.update_other2me_data.add_info)

		local CongratulateUpdateEvent = require "Event.CongratulateUpdateEvent"
		require"Main.ECGame".EventManager:raiseEvent(nil, CongratulateUpdateEvent.new(CongratulateManager.CongratulateType.GetPeople_O2S))
	end
end
pb_helper.AddHandler("npt_frient_lottery_share_update",on_npt_frient_lottery_share_update)

local function on_npt_friendship_state(sender, msg)
	--print("on_gp_friendship_state",msg,"msg.info",msg.info,"msg.draw_times",msg.draw_times)
	require("Friends.GUI.UIFriendness").Instance():UpdateFriendnessMark(msg)

	local b, _, _ = require("Friends.GUI.UIFriendness").Instance():HasBadge()
	--print_xf("FriendnessNotifyEvent",b)
	require("Friends.GUI.UIFriendMain").Instance():UpdateFriendnessBadge(b)
end
pb_helper.AddHandler("npt_friendship_state", on_npt_friendship_state)

local function on_gp_popularity_info(sender,msg)
	--print_xf("on_gp_popularity_info",msg)
	require"Friends.GUI.UIFriendness".Instance():SetDailyFriendshipAndLevel(msg)
end
pb_helper.AddHandler("gp_popularity_info",on_gp_popularity_info)

local function on_npt_grc_get_friend_list(sender, msg)
    print_hsh("npt_grc_get_friend_list   retcode  ",msg.retcode)
    FlashTipMan.FlashTipByPBErrorCode(msg.retcode)
    if msg.retcode == 0 then
        FriendMan.Instance():OnGRCGetFriendList(msg)
    end
end
pb_helper.AddHandler("npt_grc_get_friend_list",on_npt_grc_get_friend_list)

local function on_npt_grc_user_login_info(sender, msg)
	FriendMan.Instance():OnGRCLoginInfo(msg)
end
pb_helper.AddHandler("npt_grc_user_login_info",on_npt_grc_user_login_info)


local function on_npt_bless_bag_url(sender, msg)
	local UIActivityShare = require "GUI.ActivitySet.WindTrial.UIActivityShare"
	if msg.ret == 0 then
		UIActivityShare.InstanceEX():ShareForWXCenter(msg.url)
	else
		warn("on_npt_bless_bag_url fail!    retcode:  ",msg.ret)
	end
end
pb_helper.AddHandler("npt_bless_bag_url",on_npt_bless_bag_url)



local function on_gp_ask_for_gift_rsp(sender, msg)
	print("on_gp_ask_for_gift_rsp   ",msg)
	if msg.ret_code == 0 then
		local ECShareUtil = require "GUI.Share.ECShareUtil"
		ECShareUtil.SendMiniAppShareOnGPRSP(msg)
	else
		FlashTipMan.FlashTipByPBErrorCode(msg.ret_code)
	end
end
pb_helper.AddHandler("gp_ask_for_gift_rsp",on_gp_ask_for_gift_rsp)
pb_helper.AddHandler("npt_ask_for_gift_rsp",on_gp_ask_for_gift_rsp)


local function on_gp_backflow_info(sender, msg)
	print_hsh("on_gp_ask_for_gift_rsp   ",msg)
	FriendMan.Instance():OnBackflowInfo(msg)
	local UIPanelWelfareBackFlow = require "GUI.Welfare.WelfareInviteFriend.UIPanelWelfareBackFlow"
	UIPanelWelfareBackFlow.Instance():UpdateUI()
	local UIPanelWelfareInviteFriendApply = require "GUI.Welfare.WelfareInviteFriend.UIPanelWelfareInviteFriendApply"
	UIPanelWelfareInviteFriendApply.Instance():UpdateUI()
end
pb_helper.AddHandler("gp_backflow_info",on_gp_backflow_info)


local function on_gp_backflow_event(sender, msg)
	print_hsh("on_gp_backflow_event   ",msg)
	local client_msg = require "PB.client_msg"
	local EVENT_TYPE = client_msg.gp_backflow_event.EVENT_TYPE
	local str = ""
	if msg.event == EVENT_TYPE.EVENT_APPLY then
		str = StringTable.Get(80569)
	elseif msg.event == EVENT_TYPE.EVENT_APPROVE then
		str = StringTable.Get(80568)
	end

	print_hsh("str  ",str)
	if str ~= "" then
		print_hsh("msg.roleid  ",msg.roleid)
		require "Common.GameBriefInfoCacheMan".Instance():RequestOneNameCache(msg.roleid,function (id, rname)
			print_hsh("id, rname   ", rname)
			FlashTipMan.FlashTip(str:format(rname))
		end)
	end

	-- 再向服务器申请刷新一下
	FriendMan.Instance():request_backflow_info()
end
pb_helper.AddHandler("gp_backflow_event",on_gp_backflow_event)