local Lplus = require "Lplus"
local pb_helper = require "PB.pb_helper"
local CommonInvite = require "Protocol.CommonInvite"
---@type ECFriendMan
local ECFriendMan = Lplus.ForwardDeclare "ECFriendMan"
---@type ECGame
local ECGame = Lplus.ForwardDeclare("ECGame")
local bit = require "bit"
local band = bit.band

--
-- npt_team_invite
--

local function isDisCard(name)
    if name == "" then
        return false
    end
    if name == ECGame.Instance().m_HostInfo.name:getStringUnicode() then
        return false
    end
    local isBlack = ECFriendMan.Instance():IsPlayerYourBlacklist2(name)
    return isBlack
end

local function _send_CommonInvite(xid, retcode, isinvite)
	local ci = CommonInvite()
	ci.retcode = retcode
	ci.isinvite = isinvite
	ci.xid = band(xid, 0x7FFFFFFF)
	ECGame.Instance().m_Network:SendProtocol(ci)
end

local function _handle_team_invite(info, callback, promptShip)
	if promptShip then
		local hp = globalGame:GetHostPlayer()
		local MountUIDataManager = require "Mount.UIMountManager.MountUIDataManager"
		local type_ship = MountUIDataManager.MountType.Ship
		local summonShip = MountUIDataManager.Instance():GetSummonDataByType(type_ship)
		if hp:GetPrivateCarrierID() ~= ZeroUInt64 and summonShip then
			MsgBox.ShowMsgBox(info, StringTable.Get(1087),nil,MsgBoxType.MBBT_OKCANCEL,function(sender,ret)
				if MsgBoxRetT.MBRT_OK == ret then
					local hp2 = globalGame:GetHostPlayer()
					if hp == hp2 then
						
						local ECCarrierNPCMan = require "NPCs.ECCarrierNPCMan"
						ECCarrierNPCMan.Instance():DismissShip()

						if callback then
							callback(info)
						end
					end
				end
			end)
		else
			callback(info)
		end
	else
		callback(info)
	end
end

local function on_team_invite_respond(sender, xid, msg, isinvite, roleid)
	local UserData = require "Data.UserData".Instance()
	if not UserData:GetSystemCfg("TeamInviteToggle") then  --组队申请
		return
	end
	-- 对方在黑名单中，不能组队
	local playerName = GameUtil.UnicodeToUtf8(msg.name)
	if isDisCard(playerName) then
		return
	end

	local TID = _G.glb_SpecialConfig
	local hp = ECGame.Instance().m_HostPlayer

	local f = {}
	f.msg = msg
	f.xid = xid
	f.isinvite = isinvite
	f.roleid = roleid
	f.time = os.time()

	if isinvite == 1 then  --收到组队邀请
	 --not require "Social.ECTeam".ECTeamMan.Instance():FindApply(f) then
		--require "Social.ECTeam".ECTeamMan.Instance():AddApply(f)
		local auto_admit = UserData:GetRoleCfg("AutoReceiveTeam")  --自动接受组队
		local FriendMan = require "Friends.FriendMan"
		local isFriend = FriendMan.Instance():IsPlayerYourFriend(f.roleid)
		local isFaction = hp.Faction and hp.Faction:IsMemberExists(f.roleid)
		local inviteFriend = UserData:GetSystemCfg("Team_FriendInvite")
		local inviteFaction = UserData:GetSystemCfg("Team_FactionInvite")
		auto_admit = auto_admit or (isFriend and inviteFriend) or (isFaction and inviteFaction)
		if not auto_admit then
			local CG = require "CG.CG"
			local AVGManager = require "AVG.AVGManager"
			if CG.Instance():IsPlayingAnyCg() or AVGManager.Instance():IsPlaying() then
				_send_CommonInvite(xid, 1, 0)
				return
			end

			local tip
			if isinvite == 1 then
				tip = string.format(StringTable.Get(1000), playerName)
			else
				tip = string.format(StringTable.Get(999), playerName)
			end
			local _tip = tip .. "\n" .. StringTable.Get(2091):format(30)
			MsgBox.ShowMsgBox(f, _tip, nil, MsgBoxType.MBBT_OKCANCEL, function(sender, ret)
				if MsgBoxRetT.MBRT_OK == ret then
					if hp and hp.InfoData.Lv < TID.team_min_role_level then
						FlashTipMan.FlashTip(string.format(StringTable.Get(23831), TID.team_min_role_level))
						return
					end

					if hp and hp:GetPrivateCarrierID() ~= ZeroUInt64 and not require "Social.ECTeam".ECTeamMan.Instance():IsHostPlayerLeader() then
						MsgBox.ShowMsgBox(nil, StringTable.Get(1087), nil, MsgBoxType.MBBT_OKCANCEL, function(sender, ret)
							if MsgBoxRetT.MBRT_OK == ret then
								local hp2 = globalGame:GetHostPlayer()
								if hp == hp2 then
									_send_CommonInvite(xid, 0, 0)
								end
							else
								local hp2 = globalGame:GetHostPlayer()
								if hp == hp2 then
									_send_CommonInvite(xid, 1, 0)
								end
							end
						end)
					else
						_send_CommonInvite(xid, 0, 0)
					end
				else
					_send_CommonInvite(xid, 1, 0)
				end
				--require "Social.ECTeam".ECTeamMan.Instance():RemoveApply(sender)
			end, 30, function(thebox)
				if thebox.LifeTime <= 0 then
					local ci = CommonInvite()
					ci.retcode = 1
					ci.isinvite = 0
					ci.xid = band(xid, 0x7FFFFFFF)
					ECGame.Instance().m_Network:SendProtocol(ci)
					--require "Social.ECTeam".ECTeamMan.Instance():RemoveApply(f)
				else
					local desc = tip .. "\n" .. StringTable.Get(2091):format(thebox.LifeTime)
					thebox:SetText(desc)
				end
			end)
		else
			if hp and hp.InfoData.Lv < TID.team_min_role_level then
				return
			end

			--warn("自动接受组队")
			local ci = CommonInvite()
			ci.retcode = 0
			ci.isinvite = 0
			ci.xid = band(xid, 0x7FFFFFFF)
			ECGame.Instance().m_Network:SendProtocol(ci)
			--require "Social.ECTeam".ECTeamMan.Instance():RemoveApply(f)
		end
	else  --作为队长收到入队申请
		local FriendMan = require "Friends.FriendMan"
		local isFriend = FriendMan.Instance():IsPlayerYourFriend(f.roleid)
		local isFaction = hp.Faction and hp.Faction:IsMemberExists(f.roleid)
		local UserDataTable = require "Data.UserData".Instance()
		local applyAll = UserDataTable:GetSystemCfg("Team_ApplyAll")
		local applyFriend = UserDataTable:GetSystemCfg("Team_ApplyFriend")
		local applyFaction = UserDataTable:GetSystemCfg("Team_ApplyFaction")
		local auto_agree = applyAll or (applyFriend and isFriend) or (applyFaction and isFaction)
		--print("on_team_invite_respond 收到了入队申请", isFriend, isFaction, applyAll, applyFriend, applyFaction)
		if auto_agree then
			local ci = CommonInvite()
			ci.retcode = 0
			ci.isinvite = 0
			ci.xid = band(xid, 0x7FFFFFFF)
			ECGame.Instance().m_Network:SendProtocol(ci)
		else
			local TeamMan = require "Social.ECTeam".ECTeamMan.Instance()
			if not TeamMan:FindApply(f) then
				TeamMan:AddApply(f)
			end
		end
	end
end
pb_helper.AddHandler("npt_team_invite", on_team_invite_respond)

--
-- npt_team_info
--
local function on_search_nearteams( sender,msg )
	--warn("------on_search_nearteams")
	--local ECPanelAroundTeam = require "GUI.ECPanelAroundTeam"
	--ECPanelAroundTeam.Instance():on_search_nearteams(msg.teams)
end
pb_helper.AddHandler("npt_team_info",on_search_nearteams)

local function on_gp_team_fire_notify(sender, msg)
	---@type ECGame
	local ECGame = Lplus.ForwardDeclare("ECGame")
	local teamMgr = require "Social.ECTeam".ECTeamMan.Instance()
	if teamMgr then
		teamMgr:S2C_GetTeamFireOrReteatResponse(msg)
	end
end
pb_helper.AddHandler("gp_team_fire_notify",on_gp_team_fire_notify)