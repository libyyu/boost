local Lplus = require "Lplus"

local pb_helper = require "PB.pb_helper"
local pb_helper = require "PB.pb_helper"
local CommonInvite = require "Protocol.CommonInvite"
local ECFriendMan = require "Social.ECFriendMan"
local ECGame = require "Main.ECGame"
local client_msg = require "PB.client_msg"
local ElementData = require "Data.ElementData"
local band = bit.band

local function SendBestfriendTitle( bestfriend_id )
	local pb_helper = require "PB.pb_helper"
	local msg = pb_helper.NewCmd "npt_intimate_friend_operate"
	msg.op = 3
	msg.targetroleid = bestfriend_id
	pb_helper.Send(msg)	
	--print("----------------SendBestfriendTitle:",msg)
end

local function on_active_intimate_friend_title(sender, msg)
	--print("on_active_intimate_friend_title:",msg)
	local hp = ECGame.Instance().m_HostPlayer
	if hp then
		ECFriendMan.Instance().m_titleSelectBestfriend = msg.roleid
	end
end

pb_helper.AddHandler("gp_active_intimate_friend_title", on_active_intimate_friend_title)

local function on_golden_intimate_operate_result( sender, msg)
	print("_______________________________________________on_golden_intimate_operate_result:",msg.op,msg)
	if msg.retcode == 0 then
		if msg.op ==  client_msg.GIO_GOLDEN_GET then
			print("_______________________________________________on_golden_intimate_operate_result   GIO_GOLDEN_GET",msg)
			ECFriendMan.Instance():On_GetSeniorIntimateList(msg)
		elseif msg.op ==  client_msg.GIO_GOLDEN_APPLY then
			print("_______________________________________________on_golden_intimate_operate_result   GIO_GOLDEN_APPLY",msg)
			for i,v in ipairs(msg.intimates) do
				ECFriendMan.Instance():AddOneSeniorIntimate(v)
			end
			FlashTipMan.FlashTip(StringTable.Get(16199))
		elseif msg.op ==  client_msg.GIO_GOLDEN_DELETE then
			print("_______________________________________________on_golden_intimate_operate_result   GIO_GOLDEN_DELETE",msg)
			if msg.roleid == ZeroUInt64 then -- 如果没有roleid，说明是协议解除
				FlashTipMan.FlashTip(StringTable.Get(16196))
			else
				local hp = ECGame.Instance().m_HostPlayer
				if hp then
					if hp.ID == msg.roleid then
						FlashTipMan.FlashTip(StringTable.Get(16196)) -- 自己强制解除
					else
						local briefInfo = require "Common.GameBriefInfoCacheMan".Instance():FindBriefCache(msg.roleid)
						local Intimate = ECFriendMan.Instance():GetSeniorIntimateInfor(msg.roleid)
						if Intimate and briefInfo then
							FlashTipMan.FlashTip(string.format(StringTable.Get(16189),Intimate.name,briefInfo.name))
						end
					end
				end
			end
			ECFriendMan.Instance():DelOneSeniorIntimate(msg.targetroleid)

		elseif msg.op ==  client_msg.GIO_MESSAGE_MODIFY then --GIO_MESSAGE_MODIFY
			print("_______________________________________________on_golden_intimate_operate_result   GIO_MESSAGE_MODIFY",msg)
			for i,v in ipairs(msg.intimates) do
				ECFriendMan.Instance():AddOneSeniorIntimate(v)
				local hp = ECGame.Instance().m_HostPlayer
				if hp then
					if hp.ID == msg.roleid then
						FlashTipMan.FlashTip(StringTable.Get(16197))
					else
						local briefInfo = require "Common.GameBriefInfoCacheMan".Instance():FindBriefCache(v.roleid)
						local Intimate = ECFriendMan.Instance():GetSeniorIntimateInfor(v.roleid)
						if Intimate and briefInfo then
							FlashTipMan.FlashTip(string.format(StringTable.Get(16188),Intimate.name,briefInfo.name))
						end
					end
				end
			end
		elseif msg.op ==  client_msg.GIO_LEVEL_AWARD then --GIO_LEVEL_AWARD
			print("_______________________________________________on_golden_intimate_operate_result   GIO_LEVEL_AWARD",msg)
			ECFriendMan.Instance():UpdateAwardInfo(msg.targetroleid)
			FlashTipMan.FlashTip(StringTable.Get(16198))
		elseif msg.op == client_msg.GIO_SELECT_TITLE then
			ECFriendMan.Instance().m_titleSelectBestfriend = msg.targetroleid
			print("_______________________________________________on_golden_intimate_operate_result   GIO_SELECT_TITLE",msg)
		elseif msg.op == client_msg.GIO_SELECT_THEME then
			ECFriendMan.Instance():On_ThemeChange(msg.intimates[1])
			print("_______________________________________________on_golden_intimate_operate_result   GIO_SELECT_THEME",msg)
		end

		local SeniorIntimateEvent = require "Event.SeniorIntimateEvent"
		local event = SeniorIntimateEvent.new()
		event.op_type = msg.op
		ECGame.EventManager:raiseEvent(nil, event)
	else
		if msg.retcode == 151 then
			FlashTipMan.FlashTip(StringTable.Get(16186)) --非法字符检测单独提示
		else
			FlashTipMan.FlashTip(StringTable.Get(14937 + msg.retcode))
		end
	end
end

pb_helper.AddHandler("npt_golden_intimate_operate_result", on_golden_intimate_operate_result)

local function on_golden_intimate_invite( sender,xid,isinvite,msg )
	print("____________________________________________________on_golden_intimate_invite",xid,msg)

	local f = {}
	f.msg = msg
	f.xid = xid
	
	if msg.invite_type == 1 then --create
		print("____________________________________________________on_golden_intimate_invite create invite_type = 1 ",xid,msg)
		local name =GameUtil.UnicodeToUtf8(msg.name)
		local intimatename = GameUtil.UnicodeToUtf8(msg.intimate_name) --msg.intimate_name --
		MsgBox.ShowMsgBox(f,string.format(StringTable.Get(28754),name,intimatename,50),nil,MsgBox.MsgBoxType.MBBT_OKCANCEL,function(sender,ret)
			local ci = CommonInvite()
			if MsgBox.MsgBoxRetT.MBRT_OK == ret then
				ci.retcode = 0
			else
				ci.retcode = 1
			end
			ci.isinvite = 0
			ci.xid = band(sender.xid, 0x7FFFFFFF)
			ECGame.Instance().m_Network:SendProtocol(ci)
		end,
		50,function (thebox)
			thebox.content = string.format(StringTable.Get(28754),name,intimatename,thebox.LifeTime)
			thebox:UpdateUI()	
			if thebox.LifeTime <= 0 then
				local ci = CommonInvite()
				ci.retcode = 1
				ci.isinvite = 0
				ci.xid = band(thebox.sender.xid, 0x7FFFFFFF)	
				ECGame.Instance().m_Network:SendProtocol(ci)
			end
		end)
	elseif msg.invite_type == 2 then --delete 
		print("____________________________________________________on_golden_intimate_invite delete invite_type = 2 ",xid,msg)
		local specCfg = ElementData.getConfig(special_id_config.id_special_id_config)
		local name =GameUtil.UnicodeToUtf8(msg.name)
		MsgBox.ShowMsgBox(f,string.format(StringTable.Get(28755),name,name,specCfg.invite_remove_intimate_remain_amity,50),nil,MsgBox.MsgBoxType.MBBT_OKCANCEL,function(sender,ret)
			local ci = CommonInvite()
			if MsgBox.MsgBoxRetT.MBRT_OK == ret then
				ci.retcode = 0
			else
				ci.retcode = 1
			end
			ci.isinvite = 0
			ci.xid = band(sender.xid, 0x7FFFFFFF)
			ECGame.Instance().m_Network:SendProtocol(ci)
		end,
		50,function (thebox)
			thebox.content = string.format(StringTable.Get(28755),name,name,specCfg.invite_remove_intimate_remain_amity,thebox.LifeTime)
			thebox:UpdateUI()	
			if thebox.LifeTime <= 0 then
				local ci = CommonInvite()
				ci.retcode = 1
				ci.isinvite = 0
				ci.xid = band(thebox.sender.xid, 0x7FFFFFFF)	
				ECGame.Instance().m_Network:SendProtocol(ci)
			end
		end)

	elseif msg.invite_type == 3 then --rename
		print("____________________________________________________on_golden_intimate_invite rename invite_type = 3 ",xid,msg)
		local name =GameUtil.UnicodeToUtf8(msg.name)
		local intimatename = GameUtil.UnicodeToUtf8(msg.intimate_name)
		MsgBox.ShowMsgBox(f,string.format(StringTable.Get(28756),name,intimatename,50),nil,MsgBox.MsgBoxType.MBBT_OKCANCEL,function(sender,ret)
			local ci = CommonInvite()
			if MsgBox.MsgBoxRetT.MBRT_OK == ret then
				ci.retcode = 0
			else
				ci.retcode = 1
			end
			ci.isinvite = 0
			ci.xid = band(sender.xid, 0x7FFFFFFF)
			ECGame.Instance().m_Network:SendProtocol(ci)
		end,
		50,function (thebox)
			thebox.content = string.format(StringTable.Get(28756),name,intimatename,thebox.LifeTime)
			thebox:UpdateUI()	
			if thebox.LifeTime <= 0 then
				local ci = CommonInvite()
				ci.retcode = 1
				ci.isinvite = 0
				ci.xid = band(thebox.sender.xid, 0x7FFFFFFF)	
				ECGame.Instance().m_Network:SendProtocol(ci)
			end
		end)
	end
end

pb_helper.AddHandler("npt_golden_intimate_invite", on_golden_intimate_invite)


local function on_gp_intimate_op_re(sender,msg)
--[[
	message gp_intimate_op_re
	{
		optional S2C_GS_PROTOC_TYPE     type    = 1 [ default = type_gp_intimate_op_re ];
		optional GS_INTIMATE_OP_TYPE op       	= 2; 
		optional int32 targetid			= 3;
		optional int32 retcode			= 4;
		optional bytes intimate_name		= 5;
	}
]]
	print("_______________________________________________on_gp_intimate_op_re:",msg.op,msg)
	if msg.retcode == 0 then
		if msg.op ==  client_msg.GIOT_CHANGE_NAME then

			print("_______________________________________________on_gp_intimate_op_re GIOT_CHANGE_NAME",msg)
		elseif msg.op ==  client_msg.GIOT_DEL_FORCE then
			print("_______________________________________________on_gp_intimate_op_re GIOT_DEL_FORCE",msg)
		end
		local SeniorIntimateEvent = require "Event.SeniorIntimateEvent"
		local event = SeniorIntimateEvent.new()
		event.op_type = msg.op
		ECGame.EventManager:raiseEvent(nil, event)
	else
		print("_______________________________________________on_gp_intimate_op_re    error retcode is  ",msg.retcode)
		if msg.retcode == 151 then
			FlashTipMan.FlashTip(StringTable.Get(16186)) --非法字符检测单独提示
		else
			FlashTipMan.FlashTip(StringTable.Get(14937 + msg.retcode))
		end
	end
end

pb_helper.AddHandler("gp_intimate_op_re",on_gp_intimate_op_re)