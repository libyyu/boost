local pb_helper = require "PB.pb_helper"
local client_msg = require "PB.client_msg"
local ECGame = require "Main.ECGame"

local function npt_change_zone_response(sender,msg)
	--跨服失败
	if msg.retcode ~= 0 then FlashTipMan.FlashTip(StringTable.Get(20031)) return end
end
-- pb_helper.AddHandler("npt_change_zone_response", npt_change_zone_response)

--zone id 查询列表
local function npt_notify_zoneid_list(sender,msg)
	require "Main.ECZoneInfoMan".Instance().m_zoneList = {}
	local list = require "Main.ECZoneInfoMan".Instance().m_zoneList
	for _,v in ipairs(msg.zoneid_list) do
		list[v.merge_zoneid] = v.cur_zoneid
	end
end
--pb_helper.AddHandler("npt_notify_zoneid_list", npt_notify_zoneid_list)


