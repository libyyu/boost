
local Lplus = require "Lplus"
local pb_helper = require "PB.pb_helper"
---@type ECGame
local ECGame = Lplus.ForwardDeclare("ECGame")

--接收实时拉去自己的平台VIP信息
local function on_npt_grc_get_self_plat_vip_info_re(sender, msg)
	--warn("on_npt_grc_get_self_plat_vip_info_plat_vip_kind", msg.plat_vip_kind)
	--warn("on_npt_grc_get_self_plat_vip_info_retcode:", msg.retcode)
	--local ECPanelCharHead = require "GUI.ECPanelCharHead"
	--local ECPanelQQRight = require "GUI.ECPanelQQRight"
	--ECPanelCharHead.Instance():UpdateQQVIP(msg.plat_vip_kind)
	--ECPanelQQRight.Instance():UpdateQQVIP(msg.plat_vip_kind)
end

pb_helper.AddHandler("npt_grc_get_self_plat_vip_info", on_npt_grc_get_self_plat_vip_info_re)


