-- ¾º¼¼³¡
-- gp_arena_solo
-- 
local pb_helper = require "PB.pb_helper"
local ECGame = require "Main.ECGame"
local StringTable = require "Data.StringTable"
local arenabattle_cfg = _G.require_config("Configs/arenabattle_cfg.lua")

local function on_arena_apply_result(sender,msg )
	print("----------------------------------on_arena_apply_result.result",msg.result, msg.battle_type)
	local hp = ECGame.Instance().m_HostPlayer
	if msg.result == 0 then
		local ECPanelRingMatching = require "GUI.ECPanelRingMatching"
		ECPanelRingMatching.Instance():ShowPanel(true,msg.battle_type)
		if hp and msg.battle_type <= SOLO_TYPE.SOLO_INVILID and msg.battle_type > 0 then
			hp.m_soloType = msg.battle_type
		end
	else
		if hp then
			hp.m_soloType = SOLO_TYPE.SOLO_INVILID
		end
		FlashTipMan.FlashTip(StringTable.Get(7313+msg.result))

		if msg.result == 931 then --931:竞技场已经报名
			local ECPanelRingMatching = require "GUI.ECPanelRingMatching"
			ECPanelRingMatching.Instance():ShowPanel(true,msg.battle_type)	
		end
	end

end

pb_helper.AddHandler("npt_arena_apply_result",on_arena_apply_result)

local function on_arena_match_result( sender,msg )
	print("----------------------------on_arena_match_result.result",msg.result)
	if msg.result == 0 then
		local ECPanelRingMatching = require "GUI.ECPanelRingMatching"
		if ECPanelRingMatching.Instance():IsVisible() then
			ECPanelRingMatching.Instance():UpdateEnemyList(msg)
		end	
	else
		print("--on_arena_match_result:",msg.result)
		local ECPanelRingMatching = require "GUI.ECPanelRingMatching"
		if ECPanelRingMatching.Instance():IsVisible() then
			ECPanelRingMatching.Instance():ShowPanel(false,msg.battle_type)
		end


		local hp = ECGame.Instance().m_HostPlayer
		if hp then
			hp.m_soloType = SOLO_TYPE.SOLO_INVILID
		end
		
		FlashTipMan.FlashTip(StringTable.Get(7313+msg.result))
	end
end

pb_helper.AddHandler("npt_arena_match_result",on_arena_match_result)

local function on_arena_quit_result(sender,msg)
	print("------------------------------on_arena_quit_result.result",msg.result)
	local ECPanelRingMatching = require "GUI.ECPanelRingMatching"
	if msg.result == 0 then		
		if ECPanelRingMatching.Instance():IsVisible() then
			ECPanelRingMatching.Instance():ShowPanel(false,msg.battle_type)
		end	
	else	
		FlashTipMan.FlashTip(StringTable.Get(7313+msg.result))
	end

	local hp = ECGame.Instance().m_HostPlayer
	if hp then
		hp.m_soloType = SOLO_TYPE.SOLO_INVILID
		print("(----)m_soloType:",hp.m_soloType)
	end
end

pb_helper.AddHandler("npt_arena_quit_result",on_arena_quit_result)

--local function on_arena_search_list_result(sender,msg)
--	print("------------------------------on_arena_search_list_result", msg.battle_type)
--	if msg.battle_type == 1  then
--		--没有该面板
--		--local ECPanelArenaSolo = require "GUI.ECPanelArenaSolo"
--		--ECPanelArenaSolo.Instance():OnArenaSearchListResult(msg)
--	elseif msg.battle_type == 2 then
--		local ECPanelArenaManySolo = require "GUI.ECPanelArenaManySolo"
--		for index = 1,#msg.list do
--			print("___msg.list", index,"index",GameUtil.UnicodeToUtf8(msg.list[index].role.name),"rank", msg.list[index].rank)
--		end
--		ECPanelArenaManySolo.Instance():OnArenaSearchListResult(msg)
--	end
--
--	local ECPanelArenaApply = require "GUI.ECPanelArenaApply"
--	ECPanelArenaApply.Instance():UpdateBadgeState(msg)
--end
--pb_helper.AddHandler("npt_arena_search_list_result",on_arena_search_list_result)

local function on_arena_get_award_result(sender,msg)
	print("----------------------------on_arena_get_award_result", msg.result)
	if msg.result == 0 then
		FlashTipMan.FlashTip(StringTable.Get(1860))
	else 
		FlashTipMan.FlashTip(StringTable.Get(1861))
	end
end

pb_helper.AddHandler("npt_arena_get_award_result",on_arena_get_award_result)

local function on_arena_battle_end(sender,msg)
	print("-------------on_arena_battle_end:", msg.battle_result)
	if not  msg.battle_result then return end
    local ECPanelPK = require "GUI.ECPanelPK"

    local instId = ECGame.Instance().m_Instance.m_curInstanceId
    if arenabattle_cfg:IsTeamArenaIstance(instId) then
	    --延后显示
		GameUtil.AddGlobalTimer(1, true, function()
			if  ECGame.Instance().m_inGameLogic then
				local ECPanelArenaResult = require "GUI.ECPanelArenaResult"
				ECPanelArenaResult.Instance():ShowPanel(true,msg)
			end
		end)
    else
    	if msg.battle_result == 0 then
	    	ECPanelPK.Instance():PopUp(3,1)
		elseif msg.battle_result == 1 then
	    	ECPanelPK.Instance():PopUp(3,0)
		elseif msg.battle_result == 2 or msg.battle_result == 3 then
	    	ECPanelPK.Instance():PopUp(3,2)
		end
    end
end

pb_helper.AddHandler("gp_arena_battle_end",on_arena_battle_end)
