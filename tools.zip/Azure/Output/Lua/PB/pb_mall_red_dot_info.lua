--- pb_mall_red_dot_info
--- Generate by IntelliJ IDEA
--- Create by lidengfeng
--- DateTime: 2022/10/18 14:47
---
local pb_helper = require "PB.pb_helper"

pb_helper.AddHandler("gp_mall_red_dot_info", function(_, msg)
	require "Mall.ECMallManager".Instance():RecordGoodsLimitReward(msg.click_goods, msg.sync)
	require "GUI.Welfare.IAPCoupon.IAPGiftManager".Instance():RecordLimitReward(msg.click_recharge, msg.sync)
end)