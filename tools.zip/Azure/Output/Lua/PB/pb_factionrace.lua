local Lplus = require "Lplus"

local pb_helper = require "PB.pb_helper"
local ECGame = require "Main.ECGame"

local function handle_error(errorid)
	local pb_error_code = _G.require_config("Configs/pb_error_code.lua")
	msg = pb_error_code[errorid]

	if msg and string.len(msg) > 0 then
		FlashTipMan.FlashTip(msg)
	end
end


local function on_factionrace_begin(sender, msg)
	print("on_factionrace_begin battle_tid,battle_id",msg.battle_tid,msg.battle_id)
	
end

local function on_factionrace_enter(sender, msg)
	print("on_factionrace_enter battle_type,result",msg.battle_type,msg.result)
	if msg.result ~= 0 then
		handle_error(msg.result)
	end
	
end

local function on_factionrace_end(sender, msg)
	print("on_factionrace_end result",msg.battle_result)
	local curWorldTid = ECGame.Instance():GetCurrentWorldTid()
	if curWorldTid > 0 then
		local ElementData = require "Data.ElementData"
		local cfg, configType = ElementData.getConfig(curWorldTid)
		
		
		if cfg and configType == _G.CONSTANT_DEFINE.CONFIG_TYPE.CONFIG_INSTANCE then
			-- if cfg.instance_class == cfg.INSTANCE_TYPE_ENUM.INSTTYPE_CORPS_BATTLE then
			-- 	local ECPanelFactionRaceBoard = require "GUI.ECPanelFactionRaceBoard"
			-- 	ECPanelFactionRaceBoard.Instance():onBattleResult(msg.battle_result)
			-- elseif cfg.instance_class == cfg.INSTANCE_TYPE_ENUM.INSTTYPE_CORPS_CENTER_BATTLE then
			-- 	local ECPanelBattleFieldBoard = require "GUI.ECPanelBattleFieldBoard"
			-- 	ECPanelBattleFieldBoard.Instance():onBattleResult(msg.battle_result)
			-- elseif cfg.instance_class == cfg.INSTANCE_TYPE_ENUM.INSTTYPE_CENTER_SERVER_BATTLE then
			-- 	local ECPanelBattleFieldBoard = require "GUI.ECPanelBattleFieldBoard"
			-- 	ECPanelBattleFieldBoard.Instance():onCityBattleResult(msg.battle_result,msg.players)
			-- else
			-- 	if msg.battle_result == 0 then
			-- 		--local ECPanelArenaFail = require "GUI.ECPanelArenaFail"
			-- 		--ECPanelArenaFail.Instance():Toggle()
			-- 	else
			-- 		--local ECPanelArenaWin = require "GUI.ECPanelArenaWin"
			-- 		--ECPanelArenaWin.Instance():Toggle()
			-- 	end
			-- end
		end
	end
end

pb_helper.AddHandler("npt_notify_client_corps_battle_begin", on_factionrace_begin)

pb_helper.AddHandler("npt_player_enter_corps_battle_result", on_factionrace_enter)

pb_helper.AddHandler("gp_corps_battle_end", on_factionrace_end)

