local Lplus = require "Lplus"
local pb_helper = require "PB.pb_helper"
---@type ECGame
local ECGame = Lplus.ForwardDeclare("ECGame")


local function on_gp_player_slave_op_re(sender,msg)
	local ECHomeSlaveMan = require "Social.ECHomeSlaveMan"
	ECHomeSlaveMan.Instance():onSlaveOpRe(msg)
end

pb_helper.AddHandler("gp_player_slave_op_re",on_gp_player_slave_op_re)