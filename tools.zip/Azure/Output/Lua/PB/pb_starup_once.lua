local Lplus = require "Lplus"
local pb_helper = require "PB.pb_helper"

-- local function OnStarUpOnceResponse(sender, msg)
-- 	local ECPanelEquipExterior = require "GUI.ECPanelEquipExterior"
-- 	ECPanelEquipExterior.Instance():OnStarUpOnceResponse(msg)
-- end
-- pb_helper.AddHandler("gp_one_click_equip_lianxing_res", OnStarUpOnceResponse)