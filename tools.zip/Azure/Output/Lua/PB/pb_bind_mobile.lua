
local pb_helper = require "PB.pb_helper"
local NotifyMoneyChange = require "Event.NotifyMoneyChange" 
local ECGame = require "Main.ECGame"

local function on_npt_sync_bind_mobile_phone_info( sender,msg )
	print("on_npt_sync_bind_mobile_phone_info:",msg.bind_mobile_flags,msg.award_times)
	

    local BindPhoneEvent = require "Event.BindPhoneEvent"
	local p = BindPhoneEvent.BindPhoneEvent()
	ECGame.EventManager:raiseEvent(nil, p)
end

pb_helper.AddHandler("npt_sync_bind_mobile_phone_info", on_npt_sync_bind_mobile_phone_info)



