--礼包卡
--
-- npt_use_gift_card_result
-- 
local pb_helper = require "PB.pb_helper"
local ECGame = require "Main.ECGame"

local function on_use_gift_card_result( sender,msg )
	local GiftCardResultEvent = require "Event.GiftCardResultEvent"
	local event = GiftCardResultEvent.new(msg.cardnumber,msg.retcode)
	ECGame.EventManager:raiseEvent(nil, event)

	FlashTipMan.FlashTip(StringTable.Get(18052 + msg.retcode))
end

pb_helper.AddHandler("npt_use_gift_card_result",on_use_gift_card_result)