
local pb_helper = require "PB.pb_helper"
local ECGame = require "Main.ECGame"

local function on_friend_bless_notify(sender, msg)
	local FriendBlessEvent = require "Event.FriendBlessEvent"
	local event = FriendBlessEvent.new(msg.from_roleid)
	ECGame.EventManager:raiseEvent(nil, event)
end

pb_helper.AddHandler("npt_friend_bless_notify", on_friend_bless_notify)