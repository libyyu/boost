local Lplus = require "Lplus"
local pb_helper = require "PB.pb_helper"
---@type ECGame
local ECGame = Lplus.ForwardDeclare("ECGame")


local function on_gp_dice_result(sender,msg)
--[[
	optional S2C_GS_PROTOC_TYPE type = 1 [ default = type_gp_dice_result ];
	optional int32 candice		 = 2;//1可以扔色子 0 不可
	optional int32 step			 = 3;//色子扔出的点数	
	optional int32 realstep		 = 4;//实际行走的点数	
	optional int32 newpos		 = 5;//走步数之后的停留点
	optional int32 missionid	 = 6;//获得的任务id	
]]
	local ECPanelAdventure = require "GUI.ECPanelAdventure"
	ECPanelAdventure.Instance():OnDiceResult(msg)
end

pb_helper.AddHandler("gp_dice_result",on_gp_dice_result)