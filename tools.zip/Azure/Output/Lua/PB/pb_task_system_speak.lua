--任务喊话接口
local pb_helper = require "PB.pb_helper"

local function on_task_system_speak(sender,msg)
	local str = GameUtil.UnicodeToUtf8(msg.msg)
	FlashTipMan.FlashTip(str)
end 

pb_helper.AddHandler("gp_task_system_speak",on_task_system_speak)
