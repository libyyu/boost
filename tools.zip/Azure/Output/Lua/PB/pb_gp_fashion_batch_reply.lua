local Lplus = require "Lplus"
local pb_helper = require "PB.pb_helper"
local ECGame = require "Main.ECGame"
local IvtrUpdateEvent = require "Event.IvtrUpdateEvent"

-- local function send_inventory_update_event(id, updateType, updateInfo)
-- 	local event = IvtrUpdateEvent()
-- 	event.InventoryId = id
-- 	event.m_UpdateType = updateType
-- 	event.m_UpdateInfo = updateInfo
-- 	ECGame.EventManager:raiseEvent(nil, event)
-- end

-- -- 操作处理{@link #cmd_exg_ivtr_item}，由于该协议仅仅涉及时装背包与装备背包，故很多事件并不需要处理
-- local function OnFashionBatchResponse(sender, msg)
-- 	local hostPlayer = ECGame.Instance().m_HostPlayer
-- 	if not hostPlayer then return end

-- 	local success = true
-- 	local list = msg.fashion_pair_list
-- 	for i = 1, #list do
-- 		local location1 = list[i].location1
-- 		local location2 = list[i].location2
-- 		local index1 = list[i].index1
-- 		local index2 = list[i].index2

-- 		local Package = hostPlayer.Package.NormalIvtrs
-- 		local package1 = Package[location1]  -- 装备背包
-- 		local package2 = Package[location2]  -- 时装背包
-- 		if package1 and package2 then
-- 			local item1 = package1.m_ItemSet[index1] -- 装备背包物品
-- 			local item2 = package2.m_ItemSet[index2] -- 时装背包物品

-- 			-- 交换位置
-- 			package1:SetItem(index1, item2)
-- 			package2:SetItem(index2, item1)
-- 			if item1 then item1.PackageType = location2 end
-- 			if item2 then item2.PackageType = location1 end

-- 			if location1 == IVTRTYPE_ENUM.IVTRTYPE_EQUIPPACK or location2 == IVTRTYPE_ENUM.IVTRTYPE_EQUIPPACK then
-- 				send_inventory_update_event(IVTRTYPE_ENUM.IVTRTYPE_EQUIPPACK, IvtrUpdateEvent.UPDATETYPE.EQUIPINFOCHANGE, nil)	
-- 			end
-- 		else
-- 			success = false
-- 			warn("(pack is nil)EXG_IVTR_ITEM:".. location1, index1, location2, index2)
-- 		end
-- 	end

-- 	-- 时装保存成功
-- 	if success then FlashTipMan.FlashTip(StringTable.Get(9050)) end
-- end
-- pb_helper.AddHandler("gp_fashion_batch_reply", OnFashionBatchResponse)




