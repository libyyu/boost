--[[
	人格盘协议
]]

local pb_helper = require "PB.pb_helper"

local function OnGpHdpUseInfo(_, msg)
	local FEHumanDignityMan = require "Humandignity.FEHumanDignityMan"
	Log.Warn("badge", "gp_hdp_use_info", msg)
	FEHumanDignityMan.Instance():OnPlateInfoMsg(msg)
end

pb_helper.AddHandler("gp_hdp_use_info", OnGpHdpUseInfo)


local function gp_badge_info(_, msg)
	local FEHumanDignityMan = require "Humandignity.FEHumanDignityMan"
	Log.Warn("badge", "gp_badge_info", msg)
	FEHumanDignityMan.Instance():OnBadgeMsg(msg)
end

pb_helper.AddHandler("gp_badge_info", gp_badge_info)


local function gp_hdp_operator_info(_, msg)
	local FEHumanDignityMan = require "Humandignity.FEHumanDignityMan"
	Log.Warn("badge", "gp_hdp_operator_info", msg)
	FEHumanDignityMan.Instance():OnOperatorRespond(msg)
end

pb_helper.AddHandler("gp_s2c_hdp_operator", gp_hdp_operator_info)
--------------------------------------------------------------------------------------

local function on_s2c_personality_plate(_, msg)
	--print_ldf("on_s2c_personality_plate", msg)
	local PersonalityPlateCore = require "Humandignity.PersonalityPlateCore"
	PersonalityPlateCore.Instance():OnHandleS2CPersonalityPlate(msg.info)
end
pb_helper.AddHandler("gp_s2c_personality_plate", on_s2c_personality_plate)