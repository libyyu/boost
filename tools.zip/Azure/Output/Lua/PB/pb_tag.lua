local pb_helper = require "PB.pb_helper"
local ECTagMan = require "GUI.ECTagMan"

local function on_tag_info(sender, msg)
    ECTagMan.Instance():UpdateSelfTagList(msg.tag_list)
end
pb_helper.AddHandler("gp_tag_info", on_tag_info)

local function on_all_tag_info(sender, msg)
    ECTagMan.Instance():UpdateAllTagList(msg.all_tag_list)
end
pb_helper.AddHandler("gp_all_tag_info", on_all_tag_info)