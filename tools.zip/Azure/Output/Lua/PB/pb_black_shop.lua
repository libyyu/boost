-- 黑市商店
local pb_helper = require "PB.pb_helper"
local ECBlackShopMan = require "Mall.ECBlackShopMan"

local function on_gp_blackshop_notify(sender, msg)
	--[[
	local FECards = require "GameSystem.CardCollect.FECards"
	local cardsInfo = FECards.Instance()
	if msg.notify_type==1 then
		cardsInfo.blackShopInfo = msg.shops
	elseif msg.notify_type==2 then
		for i=1,#msg.shops do
			for j=1,#cardsInfo.blackShopInfo do
				if msg.shops[i].shop_id==cardsInfo.blackShopInfo[j].shop_id then
					cardsInfo.blackShopInfo[j] = msg.shops[i]
				end
			end
		end
	elseif msg.notify_type==3 then				-- 更新某个物品是否已经购买信息
		local goodsInfo = msg.shops[1].goods
		local updateGoodsInfo = nil
		-- 获取是哪个商店更新
		for i=1, #cardsInfo.blackShopInfo do
			if msg.shops[1].shop_id==cardsInfo.blackShopInfo[i].shop_id then
				updateGoodsInfo = cardsInfo.blackShopInfo[i].goods
				break
			end
		end

		-- 根据good_pos查找对应物品，更新其已经买过，考虑可能有多个物品需要更新
		if updateGoodsInfo then
			for i=1, #goodsInfo do
				for j=1, #updateGoodsInfo do
					if goodsInfo[i].goods_pos==updateGoodsInfo[j].goods_pos and 
						updateGoodsInfo[j].is_selled==0 then
						updateGoodsInfo[j] = goodsInfo[i]
						break
					end
				end
			end
		end
	end
	
	local NotifyShop = require "Event.NotifyShop"
	local p = NotifyShop()
	p.result = msg
	ECGame.EventManager:raiseEvent(nil, p)
	]]

    ECBlackShopMan.Instance():UpdateInfo(msg)
end
pb_helper.AddHandler("gp_blackshop_notify", on_gp_blackshop_notify)