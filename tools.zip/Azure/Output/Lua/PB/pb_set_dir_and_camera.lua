
local Lplus = require "Lplus"
local pb_helper = require "PB.pb_helper"
---@type ECGame
local ECGame = Lplus.ForwardDeclare("ECGame")


local function on_gp_set_dir_and_camera(sender, msg)
	--print("on_gp_set_dir_and_camera----------------------",msg.dir, msg.yaw, msg.pitch)
	--[[
	local distance, yaw, pitch = MainCamera.GetCameraParam()
	MainCamera.SetCameraParam(distance, msg.yaw, msg.pitch)
	if ECGame.Instance().m_HostPlayer then
		DecompressDirH2(msg.dir, ECGame.Instance().m_HostPlayer.m_CurDir)
		ECGame.Instance().m_HostPlayer:SetDir(ECGame.Instance().m_HostPlayer.m_CurDir)
	end]]
end

pb_helper.AddHandler("gp_set_dir_and_camera", on_gp_set_dir_and_camera)


