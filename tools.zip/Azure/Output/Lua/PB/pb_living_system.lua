local pb_helper = require "PB.pb_helper"
local Lplus = require "Lplus"
---@type ECGame
local ECGame = Lplus.ForwardDeclare("ECGame")
local client_msg = require "PB.client_msg"

--
--gp_life_job_info 拉取生活职业信息
--
local function on_life_job_info_re(sender, msg)
    --warn("msg ===========================",msg)
    local op = msg.op
    local result = msg.result

    if result == 0 then
        local ECLivingSystemMan = require("LivingSystem.ECLivingSystemMan")
        ECLivingSystemMan.Instance():SetJobInfo(msg)

        local LivingJobInfoEvent = require("Event.LivingJobInfoEvent")
        ECGame.EventManager:raiseEvent(nil, LivingJobInfoEvent.new(op))

        local ECPanelLifeProfMainIns = require("GUI.LifeProf.ECPanelLifeProfMain").Instance()
        local PromoteLifeProfEvent = require("GUI.LifeProf.ECLifeProfEvents").PromoteLifeProfEvent
        if op == client_msg.LIFE_JOB_OP.LIFE_JOB_OP_REQ_DATA then
            GameUtil.AddGlobalTimer(0.5, true, function()
                ECGame.EventManager:raiseEvent(nil, PromoteLifeProfEvent())
            end)
        elseif op == client_msg.LIFE_JOB_OP.LIFE_JOB_OP_ACTIVATE and msg.job_infos[1] then
            local job_cfg = ElementData.getDataByName("LifeJob", msg.job_infos[1].tid)
            if false and job_cfg then --屏蔽提示
                MsgBox.ShowMsgBox(nil, StringTable.Get(78118):format(job_cfg.job_name), StringTable.Get(1850), MsgBoxType.MBBT_OKCANCEL, function(sender, retval)
                    local ECPanelActivityMain = require "GUI.ActivitySet.ECPanelActivityMain"
                    if retval == MsgBoxRetT.MBRT_OK then
                        ECPanelActivityMain.Instance():OpenPanel(CONSTANT_DEFINE.ACTIVITY_TYPE.AT_LIVE)
                    end
                end)
            end
        elseif op == client_msg.LIFE_JOB_OP.LIFE_JOB_OP_UPGRADE and msg.job_infos[1] then
            local livingSystemCfg = ECLivingSystemMan.GetLivingSystemCfg()
            for k, v in ipairs(livingSystemCfg.jobCfg) do
                if v.index == msg.job_infos[1].tid then
                    ECPanelLifeProfMainIns:ShowInfoPage(k)
                    ECGame.EventManager:raiseEvent(nil, PromoteLifeProfEvent())
                    break
                end
            end
        end

        local LivingSystemInQueueEvent = require "Event.LivingSystemInQueueEvent"

        local queueChange = LivingSystemInQueueEvent.new(op)
        ECGame.EventManager:raiseEvent(nil,queueChange)

    else
        warn("life job operation failed! op = " .. op .. ", err = " .. result)
    end
end
pb_helper.AddHandler("gp_life_job_info", on_life_job_info_re)

local function on_life_recipe_info_re(sender, msg)
    local ECLivingSystemMan = require "LivingSystem.ECLivingSystemMan"
    ECLivingSystemMan.Instance():SetRecipInfo(msg)

    local LivingJobInfoEvent = require "Event.LivingJobInfoEvent"
    local event = LivingJobInfoEvent()
    ECGame.EventManager:raiseEvent(nil, event)
end
pb_helper.AddHandler("gp_life_recipe_info", on_life_recipe_info_re)

local function on_life_level_info(sender, msg)
    local ECLifePassMan = require "LivingSystem.ECLifePassMan"
    ECLifePassMan.Instance():SyncLevelInfo(msg)
end
pb_helper.AddHandler("gp_life_level_info", on_life_level_info)