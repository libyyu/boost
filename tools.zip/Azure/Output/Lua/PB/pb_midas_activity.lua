local pb_helper = require "PB.pb_helper"
local client_msg = require "PB.client_msg"
local ECChargeData = require "Data.ECChargeData"
local ECIAPChargeData = require "Data.ECIAPChargeData"
local ECPayManager = require "Main.ECPayManager"
local UIPushGiftData = require "GUI.Mall.UIPushGiftData"
local ECPanelMainMenu = require "GUI.Main.ECPanelMainMenu"
local UIPushGift = require("GUI.Mall.UIPushGift")
local UICustomizeData = require "GUI.Mall.UICustomizeData"
local UIGiftGetReward = require "GUI.Welfare.IAPCoupon.UIGiftGetReward"
local ECPanelMenuLeft = require "GUI.Main.ECPanelMenuLeft"
local ECDebugOption = require "Main.ECDebugOption"

local function on_get_midas_activity_get_re(sender, msg)
	--print_wyl("on_get_recharge_activity_get_re:",msg.param, msg.recharge_configs)
 	if msg.param == 1 then
 		ECChargeData.Instance():SetChannelChargeData(msg.recharge_configs)
		ECIAPChargeData.Instance():InitChannelChargeData()

		do
			local UISubPanelWelfarePhantomCard = require "GUI.Welfare.UISubPanelWelfarePhantomCard"
			UISubPanelWelfarePhantomCard.Instance():OnBuildChargeData()
		end
 	end
end

pb_helper.AddHandler("npt_midas_activity_get_re", on_get_midas_activity_get_re)


local function on_get_gp_iap_request_resp(sender,msg)
	print("on_get_gp_iap_request_resp:  ",msg.retcode,msg.op_type,msg.serialid,msg.reward_infos)

    -- 支付检查
	if msg.op_type == client_msg.GP_Coupon_OP_TYPE.Coupon_BASE_CHECK or msg.op_type == client_msg.GP_Coupon_OP_TYPE.Coupon_SELF_CHOICE_CEHCK then
		if msg.retcode == 0 then
			ECPayManager.Instance():AfterCheckToCheckIAPItemInPackage(msg.serialid)
		else
			warn("pay check failed... retcode,type is : ",msg.retcode,msg.op_type)
			if ECDebugOption.Instance().debug_show_pay_tip then
				FlashTipMan.FlashTip(StringTable.Get(7517):format(msg.retcode,msg.op_type))
			end
			ECPayManager.WaitPay(false)
		end
	end

    -- 推送礼包
    if msg.op_type == client_msg.GP_Coupon_OP_TYPE.Coupon_OP_CONDITON_PUSH_REWARD then
        UIPushGiftData.Instance():SetPushGiftList(msg.reward_infos)
		--ECPanelMainMenu.Instance():CreateNewPushGiftTimer()	-- 更新计时器
		ECPanelMenuLeft.Instance():CreateNewPushGiftTimer()
		if globalGame:IsInWorld() then
			UIPushGift.Instance():PopUpPanelByLast()
		end
    end

	-- 推送礼包购买成功
	if msg.op_type == client_msg.GP_Coupon_OP_TYPE.Coupon_OP_CONDITON_PUSH_REWARD_DEL then
		--local uuid = msg.reward_infos.uuid
		--print_hsh("msg.reward_infos.uuid  ",msg.reward_infos.uuid)
		for i,v in pairs(msg.reward_infos) do
			--print_hsh("i,v")
			local uuid = v.uuid
			--print_hsh("uuid   ",v.uuid)
			UIPushGift.Instance():UpdateGiftByAfterBuy(uuid)
		end
		--ECPanelMainMenu.Instance():CreateNewPushGiftTimer()
		ECPanelMenuLeft.Instance():CreateNewPushGiftTimer()
	end

	-- 兑换改到这个协议里面了
	-- 获得的同时回复
	if msg.op_type == client_msg.GP_Coupon_OP_TYPE.Coupon_BUY_RECORD then
		if msg.retcode == 0 then
            ECPayManager.Instance():ResetIAPItems(msg.coupon_sum_info and msg.coupon_sum_info.coupon_reward_info or nil)
			ECPayManager.Instance():SendPayExchangeIAPRewardMsgByRecent()
		else
			warn("IAP_BUY_RECORD retcode is not 0 :  ",msg.retcode)
			if ECDebugOption.Instance().debug_show_pay_tip then
				FlashTipMan.FlashTip(StringTable.Get(7516):format(msg.retcode))
			end
			ECPayManager.WaitPay(false)
		end
	end

	if msg.op_type == client_msg.GP_Coupon_OP_TYPE.Coupon_EXCH_COUPON then			-- 兑换请求回应，表示流程完成
		ECPayManager.WaitPay(false)
		if msg.retcode ~= 0 then
			warn("IAP_EXCH_COUPON retcode is not 0 :  ",msg.retcode)
			if ECDebugOption.Instance().debug_show_pay_tip then
				FlashTipMan.FlashTip(StringTable.Get(7518):format(msg.retcode))
			end
		else
            ECPayManager.Instance():ResetIAPItems(msg.coupon_sum_info and msg.coupon_sum_info.coupon_reward_info or nil)
		end
	end
end

pb_helper.AddHandler("gp_coupon_request_resp", on_get_gp_iap_request_resp)


