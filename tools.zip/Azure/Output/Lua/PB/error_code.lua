---@type pb.File.error_code
return require "Utility.DynamicProtobufWrapper".LoadFile "data/PB/error_code.pb"
