local pb_helper = require "PB.pb_helper"
local ECRewardBookMan = require "GUI.RewardBook.ECRewardBookMan"

-- 功能策划没用，且切换场景会重复刷，有性能问题，关掉
local function on_passport_info(sender, msg)
    ECRewardBookMan.Instance():UpdateRewardBookData(msg)
end
pb_helper.AddHandler("gp_passport_info", on_passport_info)

local function on_passport_response(sender, msg)
    ECRewardBookMan.Instance():HandleRewardBookChange(msg)
end
pb_helper.AddHandler("gp_passport_response", on_passport_response)

local function on_passport_task_info(sender, msg)
    ECRewardBookMan.Instance():UpdateRewardBookTask(msg)
end
pb_helper.AddHandler("gp_passport_task_info", on_passport_task_info)
--