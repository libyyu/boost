--更新维护礼包
local pb_helper = require "PB.pb_helper"

local function deliver_2_ui(Compensations)
	local ECPanelCompensationEntry = require "GUI.ECPanelCompensationEntry"
	ECPanelCompensationEntry.Instance():Popup(Compensations)
end

local function on_deliver_compensation(sender,msg)
	--print("on_deliver_compensation",msg)
	local function func( )
		local Compensations = {}
		for i,v in ipairs(msg.list) do
			if v then
				local data = {}
				data.cid = v.cid
				data.tid = v.tid
				data.level = v.level
				data.repu = v.repu
				Compensations[#Compensations+1] = data
			end
		end
		deliver_2_ui(Compensations)
	end
	local ECGame = require "Main.ECGame"
	ECGame.Instance():OnHostPlayerCreate(func)
end

pb_helper.AddHandler("gp_deliver_compensation", on_deliver_compensation)