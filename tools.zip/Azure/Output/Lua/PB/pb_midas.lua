
local pb_helper = require "PB.pb_helper"
local NotifyMoneyChange = require "Event.NotifyMoneyChange" 
local ECGame = require "Main.ECGame"
local ECChargeData = require "Data.ECChargeData"

local function on_get_midas_info( sender,msg )
	print("midas count:",LuaUInt64.ToDouble(msg.midas_total_amount))
	print("midas bindcount:",LuaUInt64.ToDouble(msg.midas_bind_amount))
	print("midas midas_save_amt:",LuaUInt64.ToDouble(msg.midas_save_amt))
	-- warn("midas midas_first_save:",msg.midas_first_save)
	-- warn("midas mids_tss",type(msg.midas_tss),msg.midas_tss:len())

	local func = function()
		local packman = ECGame.Instance().m_HostPlayer.Package
		local pack = packman.NormalPack
		--pack.Money = LuaUInt64.ToDouble(msg.midas_total_amount) or 0 --兼容以前的经济系统
		if not require "Utility.BranchUtil".IsBanshu() then
			packman.Cash = LuaUInt64.ToDouble(msg.midas_total_amount) or 0
			packman.BindCash = LuaUInt64.ToDouble(msg.midas_bind_amount) or 0

			--require "GUI.Mall.ECPanelRechargeWaiting".Instance():DestroyPanel()

			local p = NotifyMoneyChange()
			ECGame.EventManager:raiseEvent(nil, p)

		end
	end
	ECGame.Instance():OnHostPlayerCreate(func)
	
end

--pb_helper.AddHandler("npt_send_client_midas_info", on_get_midas_info)



