

local Lplus = require "Lplus"
---@type ECGame
local ECGame = Lplus.ForwardDeclare("ECGame")
local pb_helper = require "PB.pb_helper"
local ECObject = require "Object.ECObject"
local ECSubObject = require "Object.ECSubObject"
local client_msg = require "PB.client_msg"

local function on_coordinate_bind_result( sender,msg )
	if not msg.for_debug_check then
		local rx,ry,rz = posVec3_from_server_split(msg.pos)
		local ax,ay,az = posVec3_from_server_split(msg.absolute_coordinate)

		local carrier_npc_id = msg.npc_id
		local object_id = msg.object_id

		if object_id then
			--print_jzw("on_coordinate_bind_result",LuaUInt64.ToString(object_id),LuaUInt64.ToString(carrier_npc_id))
		else
			--print_jzw("on_coordinate_bind_result nil")
		end

		print_ldf("CoordinateBindResult has_pos_info", msg:HasField("pos_info"), "has_npc_id", msg:HasField("npc_id"), tostring_r(msg.pos), tostring_r(msg.absolute_coordinate))

	    local obj = ECGame.Instance():FindObjectOrHost(object_id)
		if not obj then
			warn("carrier obj not find",LuaUInt64.ToString(object_id))
		elseif obj:is(ECObject) then
			print_ldf(obj, "s2c set carrier id", LuaUInt64.ToString(carrier_npc_id), msg.pos_info)
			obj:SetCarrier(carrier_npc_id)
			obj:SetCarrierBindpos(msg.pos_info)
		elseif obj:is(ECSubObject) then
			warn(("CoordinateBindResult should not effect sub object=[%s] id=[%s]"):format(obj:GetUeModelName(), LuaUInt64.ToString(object_id)))
		end
	else
	    --local test_info = require "test.test_info"
	    --test_info.OnShipMsg(msg) 
	end      
end

pb_helper.AddHandler("CoordinateBindResult", on_coordinate_bind_result)


local function on_SiegeStateChange( sender,msg )
	
	local ECNPC = require "NPCs.ECNPC"
	local rx,ry,rz = posVec3_from_server_split(msg.siege_pos)
	--print_jzw("on_SiegeStateChange",msg.is_siege)

	local object_id = msg.npc_id

    local obj = ECGame.Instance():FindObjectOrHost(object_id)
    if obj and obj:is(ECNPC) then
		---@type ECNPC
		local npc = obj:cast(ECNPC)
		if npc.m_RootObj then
			npc:EnterSiege(msg.is_siege, msg.target_id, msg.siege_pos)
		else
			--走到这儿说明npc模型异步加载还未完成
			npc.is_siege = msg.is_siege
			npc.siege_target_id = msg.target_id
			npc.siege_target_pos = msg.siege_pos
		end
	end
end

pb_helper.AddHandler("SiegeStateChange", on_SiegeStateChange)

local function on_FaceTargetStateChange( sender,msg )

	local ECNPC = require "NPCs.ECNPC"
	local rx,ry,rz = posVec3_from_server_split(msg.focus_pos)
	--print_jzw("NPCFocusTarget",msg.is_focus)--,LuaUInt64.ToString(msg.focus_target_id),msg.focus_pos

	local object_id = msg.npc_id

	local obj = ECGame.Instance():FindObjectOrHost(object_id)
	if obj and obj:is(ECNPC) then
		---@type ECNPC
		local npc = obj:cast(ECNPC)
		if npc.m_RootObj then
			npc:ChangeFaceTarget(msg.is_focus, msg.focus_target_id, msg.focus_pos)
			--print_jzw("NPCFocusTarget 1")
		else
			--走到这儿说明npc模型异步加载还未完成
			npc.is_face_target = msg.is_focus
			npc.face_target_id = msg.focus_target_id
			npc.face_target_pos = msg.focus_pos
			--print_jzw("NPCFocusTarget 2")
		end
	end
end

pb_helper.AddHandler("NPCFocusTarget", on_FaceTargetStateChange)


---@param msg pb.Message.PB.gp_hostplayer_basic_info_sync
local function on_gp_hostplayer_basic_info_sync( sender,msg )
	--print_jzw("on_gp_hostplayer_basic_info_sync 1",msg.role_level)
	local hp = ECGame.Instance():GetHostPlayer()
	if hp then
		local HostPropertyEvents = require "Event.HostPropertyEvents" 
		
		-- 改变等级
		hp.InfoData.Lv = msg.role_level
		local event = HostPropertyEvents.HostLevelChangeEvent()
		event.newLevel = msg.role_level
		ECGame.EventManager:raiseEvent(nil, event)

		hp.InfoData.OriginalLv = msg.origin_level
		
		-- 改变职业
        local oldProf = hp.InfoData.Prof
		hp.InfoData.Prof = msg.role_prof
		local event = HostPropertyEvents.HostProfChangeEvent()
		event.oldProf = oldProf
		event.newProf = hp.InfoData.Prof
		ECGame.EventManager:raiseEvent(nil, event)
		--print_jzw("on_gp_hostplayer_basic_info_sync 2",msg.role_level)
	end
end

pb_helper.AddHandler("gp_hostplayer_basic_info_sync", on_gp_hostplayer_basic_info_sync)



local function on_gp_gm_server_pos( sender,msg )
	print_jzw("on_gp_gm_server_pos 1")
	local hp = ECGame.Instance():GetHostPlayer()
	if hp then
		print("")
		print("host server pos",msg.position.x,msg.position.y,msg.position.z)

		local clientPos = hp:GetPos()
		print("host client pos",clientPos.x,clientPos.y,clientPos.z)

		local dx = msg.position.x - clientPos.x
		local dy = msg.position.y - clientPos.y
		local dz = msg.position.z - clientPos.z

		print("水平距离:",math.sqrt(dx * dx + dz * dz))
		print("垂直距离:",math.abs(dy))
		print("")
	end
end

pb_helper.AddHandler("gp_gm_server_pos", on_gp_gm_server_pos)



local function on_gp_check_move_err_info( sender,msg )
	local filename = msg.file_name

	local function GetErrorStr(err)
		--[[
		3：位移非法
		4：单次移动时间超时
		5：惩罚状态
		6：单次位移过大
		7：累计移动加成超速
		8：累计移动超速
		10：客户端服务器移动时间回滚
		11：移动速度过大
		--]]
		if err == 5 then
			return "惩罚状态"
		elseif err == 3 then
			return "位移非法"
		elseif err == 4 then
			return "单次移动时间超时"
		elseif err == 6 then
			return "启动单次位移过大"
		elseif err == 7 then
			return "累计移动加成超速"
		elseif err == 8 then
			return "累计移动超速"
		elseif err == 10 then
			return "客户端服务器移动时间回滚"
		elseif err == 11 then
			return "移动速度过大"
        elseif err == -12 then
            return "平均速度超速"
		elseif err == 13 then
			return "单次移动距离过大"
		elseif err == 2335 then
			return "不能离开限制区域"
		elseif err == 2320 then
			return "惩罚时间内"
		elseif err == 2321 then
			return "高度有问题"
		elseif err == 2326 then
			return "被控中收到移动协议"
		end

		return "none"
	end

	print("pull back file:",filename," line:",msg.line,msg.errcode,GetErrorStr(msg.errcode))
	if msg.move_info then
		print("pullback log======= start dis time speed",msg.move_info.total_move_distance,msg.move_info.total_move_time,msg.move_info.average_speed)
		print("move_frame",#msg.move_info.move_frame)
        local total_server_time = 0
        local total_client_time = 0
        for k,v in ipairs(msg.move_info.move_frame) do
			print("   ",k,GetFloatVec3Str(v.pos,1),v.server_use_time,v.use_time,GetFloatStr(v.move_distance,3),GetFloatStr(v.real_speed,3),GetFloatStr(v.server_move_time/1000,3),GetFloatStr(v.client_move_time/1000,3))
			--print("   ",k,GetFloatVec3Str(v.pos,1),v.server_use_time,v.use_time,GetFloatStr(v.move_distance,3),GetFloatStr(v.real_speed,3))
            total_server_time = total_server_time + v.server_use_time
            total_client_time = total_client_time + v.use_time
		end
		print("pullback log======= end servertime clienttime",total_server_time,total_client_time)
	end
end

pb_helper.AddHandler("gp_check_move_err_info", on_gp_check_move_err_info)



local function on_gp_check_pos_reachable_s2c( sender,msg )
	local list = msg.info
	for k,v in ipairs(list) do
		local color = v.is_reachable and  _G.ColorGreen or _G.ColorRed
		GameUtil.DrawDebugBox(v.pos, {x = 0.1,y = 0.1,z = 0.1}, { 0,0, 0}, false, color, 1)
	end
end

pb_helper.AddHandler("gp_check_pos_reachable_s2c", on_gp_check_pos_reachable_s2c)


pb_helper.AddHandler("gp_overflow_repu", function(_, msg)
	print("gp_overflow_repu", msg)
	local repu_id = msg.repu_id

	local ElementData = require "Data.ElementData"
	local reputationCfg = ElementData.getDataByName("PlayerRepu", repu_id)
	if #(reputationCfg.overflow_prompt) >0 then
		FlashTipMan.FlashTip(reputationCfg.overflow_prompt)
	end
end)


local function on_gp_force_move_op_rsp( sender,msg )
	--[[
	message gp_force_move_op_rsp {
		option (s2c_type)       = type_gp_force_move_rsp;
	FORCE_MOVE_OP   op      = 2; //操作类型
	int32           tid     = 3; //强制移动模板id
	int32           result  = 4; //操作结果 0 成功
	int64           npc_id  = 5; //创建出来的载具ncpid
	}]]

	print_jzw("on_gp_force_move_op_rsp",msg.result,msg.op,msg.tid,LuaUInt64.ToString(msg.npc_id))
	if msg.result == 0 then
		if msg.op == client_msg.FORCE_MOVE_OP.FMO_START then
			local host = ECGame.Instance():GetHostPlayer()
			if host then
				host:GetForceMove():OnMsgStart(msg.tid,msg.npc_id)
			end

		elseif msg.op == client_msg.FORCE_MOVE_OP.FMO_END then

		end
	end
end

pb_helper.AddHandler("gp_force_move_op_rsp", on_gp_force_move_op_rsp)



local function on_gp_forbid_skill_inform( sender,msg )
	--[[
	message gp_forbid_skill_inform {
		option (s2c_type) = type_gp_forbid_skill_inform;
		enum INFORM_TYPE {
			IT_UNKNOW    = 0;
			IT_FORBID    = 1; //禁止
			IT_RESTORE   = 2; //恢复
		}
		INFORM_TYPE type = 1;
		int64     mask = 2; //WEAPON_SKILL_TYPE_MASK
	}

	enum WEAPON_SKILL_TYPE_MASK {
		option (IsMask)         = true;
		WSTM_UNKNOW             =  0; //未知
		WSTM_NORMAL_ATTACK      =  0x00000001; //近战
		WSTM_DOGE               =  0x00000002; //闪避
		WSTM_JUMP               =  0x00000004; //跳跃
	}
	]]

	local ECSkillLimitCheckUtil = require "Skill.ECSkillLimitCheckUtil".Instance()

	local isHaveMainSkillFlag 	= (LuaUInt64.And(msg.mask, _G.ForbidSkillFlag.ForbidMainWeaponSkill)	~= ZeroUInt64)
	local isHaveDodgeFlag     	= (LuaUInt64.And(msg.mask, _G.ForbidSkillFlag.ForbidDodgeSkill) 	    ~= ZeroUInt64)
	local isHaveJumpFlag     	= (LuaUInt64.And(msg.mask, _G.ForbidSkillFlag.ForbidJump)		    	~= ZeroUInt64)

	--print_jzw("on_gp_forbid_skill_inform",msg.type,LuaUInt64.ToString(msg.mask))
	--print_jzw("isHaveMainSkillFlag",isHaveMainSkillFlag)
	--print_jzw("isHaveDodgeFlag",isHaveDodgeFlag)
	--print_jzw("isHaveJumpFlag",isHaveJumpFlag)

	if msg.type == 1 then --禁止
		if isHaveMainSkillFlag then
			ECSkillLimitCheckUtil.m_forbidMainWeaponSkill = true
		end

		if isHaveDodgeFlag then
			ECSkillLimitCheckUtil.m_forbidDodgeSkill = true
		end

		if isHaveJumpFlag then
			ECSkillLimitCheckUtil.m_forbidJump = true
		end

	else --取消禁止
		if isHaveMainSkillFlag then
			ECSkillLimitCheckUtil.m_forbidMainWeaponSkill = false
		end

		if isHaveDodgeFlag then
			ECSkillLimitCheckUtil.m_forbidDodgeSkill = false
		end

		if isHaveJumpFlag then
			ECSkillLimitCheckUtil.m_forbidJump = false
		end
	end

	if isHaveMainSkillFlag or isHaveDodgeFlag then
		local HostSkillEvents = require "Event.HostSkillEvents"
		ECGame.EventManager:raiseEvent(nil,  HostSkillEvents.HostForbidSkillEvent())
	end

	if isHaveJumpFlag then
		local ECPanelMainOperation = require "GUI.Main.ECPanelMainOperation"
		ECPanelMainOperation.Instance():SetEnableJump(not ECSkillLimitCheckUtil.m_forbidJump)
	end
end

pb_helper.AddHandler("gp_forbid_skill_inform", on_gp_forbid_skill_inform)



---@param msg pb.Message.PB.gp_strong_control_end
local function on_gp_strong_control_end( sender,msg )
	--print_jzw("on_gp_strong_control_end")

	local hp = globalGame:GetHostPlayer()
	if hp and hp:GetBeControledType() == msg.control_tye and hp:IsInState("ObjBeCtrl") then
		hp:SetWeakControl(true)
	end
end

pb_helper.AddHandler("gp_strong_control_end", on_gp_strong_control_end)


local function on_gp_national_plan_rsp( sender,msg )
	local ECAllPeoplePlanMan = require "GUI.ActivitySet.AllPeoplePlan.ECAllPeoplePlanMan"
	ECAllPeoplePlanMan.Instance():OnDealMsg(msg)
end

pb_helper.AddHandler("gp_national_plan_rsp", on_gp_national_plan_rsp)


local function on_gp_accumulate_charge_reward_re( sender,msg )
	local UISubPanelWelfareAccountRecharge = require "GUI.Welfare.UISubPanelWelfareAccountRecharge"
	UISubPanelWelfareAccountRecharge.Instance():OnDealMsg(msg)
end

pb_helper.AddHandler("gp_accumulate_charge_reward_re", on_gp_accumulate_charge_reward_re)


local function on_gp_permanent_card_rep( sender,msg )
	local UISubPanelWelfarePhantomCard = require "GUI.Welfare.UISubPanelWelfarePhantomCard"
	UISubPanelWelfarePhantomCard.Instance():OnReceiveMsg(msg)
end

pb_helper.AddHandler("gp_permanent_card_rep", on_gp_permanent_card_rep)


--首月登录
local function on_gp_acc_login_reward_res( sender,msg )
	do
		local UISubPanelWelfareFirstMonthLogin = require "GUI.Welfare.UISubPanelWelfareFirstMonthLogin"
		UISubPanelWelfareFirstMonthLogin.Instance():OnDealMsg(msg)
	end

	do
		local UISubPanelWelfareSignInShip = require "GUI.Welfare.UISubPanelWelfareSignInShip"
		UISubPanelWelfareSignInShip.Instance():OnDealMsg(msg)
	end

	do
		local UISubPanelWelfareAngleSign = require "GUI.Welfare.UISubPanelWelfareAngleSign"
		UISubPanelWelfareAngleSign.Instance():OnDealMsg(msg)
	end

	do
		local UISubPanelWelfareAngleSign2 = require "GUI.Welfare.UISubPanelWelfareAngleSign2"
		UISubPanelWelfareAngleSign2.Instance():OnDealMsg(msg)
	end
end

pb_helper.AddHandler("gp_acc_login_reward_res", on_gp_acc_login_reward_res)



local function on_gp_accumulate_charge_reward_oversea_re( sender,msg )
	local ECPanelAccountRechargeOversea = require "GUI.Mall.ECPanelAccountRechargeOversea"
	ECPanelAccountRechargeOversea.Instance():OnDealMsg(msg)
end

pb_helper.AddHandler("gp_accumulate_charge_reward_oversea_re", on_gp_accumulate_charge_reward_oversea_re)


local function on_gp_speople_friendship_upgrade( sender,msg )
	--print_jzw("on_gp_speople_friendship_upgrade",msg)

	local ECPanelPeopleFriendShip = require "GUI.SummonPeople.ECPanelPeopleFriendShip"
	ECPanelPeopleFriendShip.Instance():OnDealMsgParamChange(msg)
end

pb_helper.AddHandler("gp_speople_friendship_upgrade", on_gp_speople_friendship_upgrade)


local function on_gp_activity_exchange_s2c( sender,msg )
	--print_jzw("on_gp_activity_exchange_s2c",msg)

	if msg.retcode == 0 then
		local UISubPanelWelfareCollectWord = require "GUI.Welfare.UISubPanelWelfareCollectWord".Instance()
		UISubPanelWelfareCollectWord:UpdateData()
		UISubPanelWelfareCollectWord:UpdateUI()
	end
end

pb_helper.AddHandler("gp_activity_exchange_s2c", on_gp_activity_exchange_s2c)


























