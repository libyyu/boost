local pb_helper = require "PB.pb_helper"
local ECGame = require "Main.ECGame"
local StringTable = require "Data.StringTable"

local function on_blessing_history_result(sender,msg)
	print("test.on_blessing_history_result:",msg)

	-- local ECPanelFlowerHistory = require "Blessing.ECPanelFlowerHistory"
	-- if ECPanelFlowerHistory.Instance() and ECPanelFlowerHistory.Instance().m_panel then
	-- 	ECPanelFlowerHistory.Instance():UpdateFlowerHistoryListView(msg)
	-- end
end 
pb_helper.AddHandler("npt_blessing_history_result",on_blessing_history_result)