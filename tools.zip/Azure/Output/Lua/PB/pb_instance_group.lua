local pb_helper = require "PB.pb_helper"
local FEInstanceMan = require "Instance.FEInstanceMan"

local function on_instance_group(sender, msg)
    FEInstanceMan.Instance():OnInstanceGroupInfo(msg)
end

pb_helper.AddHandler("gp_instance_group", on_instance_group)