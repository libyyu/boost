
--2015年12月4日
--Wang Yinliang
--
-- 友好关服提示
-- gmshutdownserver_notify
-- 
local pb_helper = require "PB.pb_helper"
--[[
	message gmshutdownserver_notify{
		optional NET_PROTOCBUF_TYPE type	= 1	[ default = NPT_GM_SHUT_DOWN_SERVER ];
		optional int32		zoneid		= 2;
		optional int64		timestamp	= 3; //时间戳
		optional int32      speakid     = 4; //喊话id

	}
--]]
local function on_gmShutdown_notify (sender, msg)
    require "Alert.ECGMShutDown".Instance():OnNotifyMsg(msg)
end
pb_helper.AddHandler("gmshutdownserver_notify", on_gmShutdown_notify)
