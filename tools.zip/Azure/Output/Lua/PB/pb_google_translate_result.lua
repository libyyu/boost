
local pb_helper = require "PB.pb_helper"
pb_helper.AddHandler("npt_google_translate", function(_, msg)
	if not _G.GIsShipping then
		print("npt_google_translate", msg)
	end
	require "Chat.ECChatItem".Oversea_Translate_Respond(msg)
end)
