local ProtocolManager = require "Protocol.ProtocolManager"
local SendClientData = require "Protocol.SendClientData"
ProtocolManager.AddHandler(SendClientData, function (sender, msg)
	local UserData = require "Data.UserData"
	UserData.Instance():SetRoleData(msg)
end)