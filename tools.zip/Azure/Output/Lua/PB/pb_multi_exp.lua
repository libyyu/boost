

local Lplus = require "Lplus"
local pb_helper = require "PB.pb_helper"
---@type ECGame
local ECGame = Lplus.ForwardDeclare("ECGame")

--接收体力返回
local function on_gp_multi_exp(sender, msg)
	-- print("------------------------------------------------on_gp_multi_exp   ", msg.tid)
	do--暂时屏蔽
		return
	end
	local ECPanelActivityTip = require "GUI.ECPanelActivityTip"
	ECPanelActivityTip.PopupMultiExpTip(msg)
end

pb_helper.AddHandler("gp_multi_exp", on_gp_multi_exp)




