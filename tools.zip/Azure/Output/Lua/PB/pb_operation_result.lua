local pb_helper = require "PB.pb_helper"

local _MAX_NATION_FUND = 9999999999

local function on_operation_result(sender,msg)
	--print("on_operation_result",msg)
	if msg.oper_type == 1 then --国家捐献
		--[[if msg.oper_result == 1 then
			--FlashTipMan.FlashTip(StringTable.Get(12005))
			local ECPanelNationDonate = require "GUI.ECPanelNationDonate"
			ECPanelNationDonate.Instance():SuccessTip()
			local ECNationMan = require "Social.ECNationMan"
			ECNationMan.GetNationInfo()	

			if math.abs(ECNationMan.Instance().m_MyNationInfo.nation_money) >= _MAX_NATION_FUND then
				FlashTipMan.FlashTip(StringTable.Get(12034))
			end
		else
			FlashTipMan.FlashTip(StringTable.Get(12004))	
		end]]
	end
end

--pb_helper.AddHandler("gp_operation_result", on_operation_result)