---@type pb.File.config_common
local config_common = require "Utility.DynamicProtobufWrapper".LoadFile "data/PB/config_common.pb"
return config_common
