local pb_helper = require "PB.pb_helper"


--
--火车停靠协议
--
pb_helper.AddHandler("gp_train_open_door", function(_, msg)
    --print_ldf("gp_train_open_door", msg)
    local carriages_id_list = msg.carriages_id
    local timestamp = msg.timestamp
    ---@param world ECWorld
    globalGame:AddWorldCreateCallback(function(world)
        for _, id in ipairs(carriages_id_list) do
            local obj = world:FindObject(id)
            if obj then
                ---@type ECTrainNPC
                local npc = obj:as(require"NPCs.ECTrainNPC") --用cast是因为必须是npc
                if npc then
                    npc:OnTrainStatusSync(false, timestamp)
                end
            else
                print_ldf("no npc found", LuaUInt64.ToString(id))
            end
        end
    end)
end)