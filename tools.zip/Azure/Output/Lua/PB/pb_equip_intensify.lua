local Lplus = require "Lplus"
local pb_helper = require "PB.pb_helper"
---@type ECGame
local ECGame = Lplus.ForwardDeclare("ECGame")
local EquipIntensifyEvent = require "Event.EquipIntensifyEvent"

local function on_equip_forge_result(sender, msg)
    local event = EquipIntensifyEvent()
    event.result = msg
    ECGame.EventManager:raiseEvent(nil, event)
end
pb_helper.AddHandler("gp_equip_forge_result", on_equip_forge_result)