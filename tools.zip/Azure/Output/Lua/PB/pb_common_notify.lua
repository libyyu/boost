
local pb_helper = require "PB.pb_helper"
local client_msg = require "PB.client_msg"
local Lplus = require "Lplus"
---@type ECGame
local ECGame = Lplus.ForwardDeclare("ECGame")

---@param msg pb.Message.PB.gp_common_notify
local function on_gp_common_notify( sender,msg )
	--warn("on_gp_common_notify", msg)
	local gp_common_notify = client_msg.gp_common_notify
	if(msg.notifty_type == gp_common_notify.NOTIFY_TYPE_STAMINA_TIME_ADD)then
		--require("GUI.ForceCoolDownRefresher").Instance()._nextAddTime = msg.param;
		--local cur_time = GameUtil.GetServerGMTTime()
		--warn("************** on_gp_common_notify() nextAddTime",msg.param,cur_time,msg.param - cur_time);
	elseif msg.notifty_type == gp_common_notify.INSTANCE_KILL_PLAYER_COUNT then
		--require "GUI.ECNationWarEffect".DailyKillEffect():Popup(msg.param)
    --[[
	elseif msg.notifty_type == gp_common_notify.PHOTO_ACTIVE then --头像激活
		local hp = ECGame.Instance().m_HostPlayer
		local infoMap = hp.InfoData.PhotoInfoMap
		if not infoMap[1] then infoMap[1] = {} end
		infoMap[1][msg.param] = true

		local ECPanelFunctionUnlock = require "Guide.ECPanelFunctionUnlock"
		ECPanelFunctionUnlock.QueuePopup_GetNewPhotoAndFrame(msg.param,1)

	elseif msg.notifty_type == gp_common_notify.FRAME_ACTIVE then --头像框激活
		local hp = ECGame.Instance().m_HostPlayer
		local infoMap = hp.InfoData.PhotoInfoMap
		if not infoMap[2] then infoMap[2] = {} end
		infoMap[2][msg.param] = true

		local ECPanelFunctionUnlock = require "Guide.ECPanelFunctionUnlock"
		ECPanelFunctionUnlock.QueuePopup_GetNewPhotoAndFrame(msg.param,2)
        ]]
	elseif msg.notifty_type == gp_common_notify.COMBINE_ITEM then
		--ECSoundMan.Instance():Play2DSoundByID(252,-1)
	elseif msg.notifty_type == gp_common_notify.HP_POOL_HEAL then -- 血池变化
		FlashTipMan.FlashTip(string.format(StringTable.Get(920), msg.param))
	elseif msg.notifty_type == gp_common_notify.FIRST_CHANGE_WEAPON then
		-- 第一次切换武器时，指引修改技能方案
		if msg.param == 1 then
			-- 当前是系统方案，不指引
		else
			-- 当前是自定义方案，开始指引
			local ECGuideEventManager = require "Guide.ECGuideEventManager"
			ECGuideEventManager.Instance():StartChangeWeaponGuide()
		end

	elseif msg.notifty_type == gp_common_notify.ROGUELIKE_CONFIRM_SKILL_PLAN then --时空圣殿确认技能方案
		local str = StringTable.Get(104069)
        MsgBox.ShowMsgBox(self, str, nil, MsgBox.MsgBoxType.MBBT_OKCANCEL, function(sender, ret)
        	local plan_id = -1
            if MsgBox.MsgBoxRetT.MBRT_OK == ret then
               	plan_id = bit.lshift(_G.CONSTANT_DEFINE.WEAPON_SKILL_PLAN_TYPE.WSPT_ROGUELIKE, 16)
            end
            local ECSkillTreeManager = require "Skill.ECSkillTreeManager"
            ECSkillTreeManager.Instance():SendOpratePlan(_G.CONSTANT_DEFINE.SKILL_PLAN_OPERATION.SPO_CHANGE, plan_id, "", 0) 	
        end)
     elseif msg.notifty_type == gp_common_notify.GONGJI_REPU_NOTIFY then --通知特殊声望处理
		local repuID = msg.param
		local diffValue = LuaInt64.ToDouble(msg.param2)
		local reasonMask = LuaInt64.ToDouble(msg.param3)
		local ReputationCfg = require("Configs.ReputationCfg")
		local repuCfg = ReputationCfg.GetRepuCfg(repuID)
		if(repuCfg ~= nil)then
			if repuCfg:NeedShowTips() then
				if not repuCfg.hide_as_reward then
					local repuGalaxy = 2155
					local repuReason = --以后如果多的话，可以摘成configs下文件
					{
						[repuGalaxy] =
						{
							[1] = StringTable.Get(109450),
							[2] = StringTable.Get(109451),
							[3] = "",
							[4] = StringTable.Get(109452),
						}
					}
					local ECChatHandle = require "Chat.ECChatHandle"
					local ECChatManager = require "Chat.ECChatManager"
					local ECChatUtility = require "Chat.ECChatUtility"
					local chatHandle = ECChatHandle.Instance()
					if diffValue > 0 then
						local str
						str = StringTable.Get(100011):format(diffValue, repuCfg.name)
						local reason_str
						if bit.band(reasonMask, 1) ~= 0 then
							reason_str = repuReason[repuID][1]
						elseif bit.band(reasonMask, 2) ~= 0 then
							reason_str = repuReason[repuID][2]
						elseif bit.band(reasonMask, 4) ~= 0 then
							reason_str = repuReason[repuID][4]
						end
						if reason_str then
							str = str..string.format("(%s)", reason_str)
						end
						if repuID == repuGalaxy then
							require "GUI.UIPanelMainGalaxyTips".Instance():PopOne({from = reason_str and 'character' or '', value = diffValue})
						end
						local richStr =  ECChatUtility.GenerateRichText(str,nil)
						if repuCfg.icon ~= 0 then
							local iconPath = datapath.GetPathByID(repuCfg.icon)
							richStr = chatHandle:MakeReputationImg("inc_repuImg_0" , iconPath, 32 , -6) .. richStr
						end
						local ECMsgInfo = require "Chat.ECMsgInfo"
						ECChatManager.Instance():AddSimpleMessageWithType(str, richStr,
								_G.CONSTANT_DEFINE.CHAT_CHANNEL_ENUM.CHAT_CHANNEL_SYSTEM, ECMsgInfo.MSG_TYPE.SYSTEM, "")
					end
				end
			end
		end
	end
end
pb_helper.AddHandler("gp_common_notify", on_gp_common_notify)


local function on_gp_answer_activity(sender,msg)
	local ECPanelQuestActivity = require "GUI.Quest.ECPanelQuestActivity"
	ECPanelQuestActivity.Instance():SetQuestionInfo(msg)
end
pb_helper.AddHandler("gp_answer_activity_operate_ret",on_gp_answer_activity)