--
-- gp_auto_combat_config_s2c
-- 
local pb_helper = require "PB.pb_helper"

local function on_auto_combat_config( sender,msg )
	local UserData = require "Data.UserData"
	local UserDataTable = UserData.Instance()
	local config = msg.config
	--UserDataTable:SetRoleCfg("AutoFightRange", config.radius)
	--UserDataTable:SetRoleCfg("AutoDrugPercent", config.aid_hp_pesent)
	--UserDataTable:SetRoleCfg("AutoBuyDrug", config.auto_buy_item)
	--UserDataTable:SetRoleCfg("AutoPickUp", config.auto_pick_up)
	--UserDataTable:SetRoleCfg("PickUpQuality", config.pick_grade)

	--[[
	local ECPanelStayOnlineStop = require "GUI.ECPanelStayOnlineStop"
	local quit_panel = ECPanelStayOnlineStop.Instance()
	if quit_panel.need_show then
		quit_panel.time = config.last_bot_time
		quit_panel.exp = LuaUInt64.ToDouble(config.last_bot_exp)
		quit_panel:ShowPanel(true)
	end
	]]
end

pb_helper.AddHandler("gp_auto_combat_config_s2c", on_auto_combat_config)