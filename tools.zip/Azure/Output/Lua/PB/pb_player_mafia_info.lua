local pb_helper = require "PB.pb_helper"

local function on_gp_player_mafia_info(sender, msg)
	--print_ygao("on_gp_player_mafia_info", msg)
	local ECFactionInfoCache = require "Social.ECFactionInfoCache"
	ECFactionInfoCache.Instance():OnFactionNameReceived(msg)
end
pb_helper.AddHandler("gp_player_mafia_info", on_gp_player_mafia_info)

