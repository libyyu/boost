local Lplus = require "Lplus"
local pb_helper = require "PB.pb_helper"
---@type ECGame
local ECGame = Lplus.ForwardDeclare("ECGame")
--保护时间
local function on_gp_revenge_battle_info(sender,msg )
	local hp = ECGame.Instance().m_HostPlayer
	if hp then
		hp.m_ProtectTimeStamp = msg.timeout
	end
end

pb_helper.AddHandler("gp_revenge_battle_info",on_gp_revenge_battle_info)

--战书
local function on_gp_revenge_battle_letter(sender,msg )
--	local ECPanelDuelBtn = require "GUI.ECPanelDuelBtn"
--	ECPanelDuelBtn.Instance():PopUp(msg.enemy,msg.timeout)
end

pb_helper.AddHandler("gp_revenge_battle_letter",on_gp_revenge_battle_letter)

--战斗结果
local function on_npt_revenge_battle_result(sender,msg )
	-- local ECPanelDuelResult = require "GUI.ECPanelDuelResult"
	-- ECPanelDuelResult.Instance():PopUp(msg.winner,msg.loser,msg.is_draw)
	-- local ECPanelDuelReceive = require "GUI.ECPanelDuelReceive"
	-- ECPanelDuelReceive.Instance():DestroyPanel()
	-- local ECPanelDuelBtn = require "GUI.ECPanelDuelBtn"
	-- ECPanelDuelBtn.Instance():DestroyPanel()
end

pb_helper.AddHandler("npt_revenge_battle_result",on_npt_revenge_battle_result)




--申请返回
local function on_gp_revenge_battle_apply_result(sender,msg )
	if msg.retcode == 0 then
		FlashTipMan.FlashTip(StringTable.Get(18039))
	else
		local pb_error_code = _G.require_config("Configs/pb_error_code.lua")
		msg = pb_error_code[msg.retcode]

		if msg and string.len(msg) > 0 then
			FlashTipMan.FlashTip(msg)
		end
	end
end

pb_helper.AddHandler("gp_revenge_battle_apply_result",on_gp_revenge_battle_apply_result)


--接受邀请返回
local function on_gp_revenge_battle_response_result(sender,msg )
	-- if msg.result == 0 then
	-- 	local ECPanelDuelReceive = require "GUI.ECPanelDuelReceive"
	-- 	ECPanelDuelReceive.Instance():DestroyPanel()
	-- 	local ECPanelDuelBtn = require "GUI.ECPanelDuelBtn"
	-- 	ECPanelDuelBtn.Instance():DestroyPanel()
	-- else
	-- 	local error_message = _G.require_config("Configs/s2c_error_message.lua")
	-- 	msg = error_message[msg.result]
	-- 	if msg and string.len(msg) > 0 then
	-- 		FlashTipMan.FlashTip(msg)
	-- 	end
	-- end
end

pb_helper.AddHandler("gp_revenge_battle_response_result",on_gp_revenge_battle_response_result)


-- 邀请方进入副本
local function on_gp_revenge_battle_enter_instance(sender,msg )
	if msg.is_inviter>0 then
		local ECPanelDuelMatchInfo = require "GUI.ECPanelDuelMatchInfo"
		ECPanelDuelMatchInfo.Instance():PopUp(msg.wait_time_out)
	end
end

pb_helper.AddHandler("gp_revenge_battle_enter_instance",on_gp_revenge_battle_enter_instance)


