local pb_helper = require "PB.pb_helper"
local ECGame = require "Main.ECGame"
local Json =  require "Utility.json"

-- local function on_http_get_rep(sender,msg)
-- 	--warn("on_http_get_rep",msg)
-- 	--warn("on_http_get_rep",msg.contents)

-- 	local reserved = msg.reserved
-- 	local contents = msg.contents
-- 	local content_table

-- 	if msg.retcode == 200 then 
-- 		content_table = Json.decode(contents)
-- 	end
	
-- 	local HttpReplyManager = require "Utility.HttpReplyManager"
-- 	local instance = HttpReplyManager.Instance()
-- 	local callback_function = instance:GetMethod(reserved)
-- 	if callback_function ~= nil then
-- 		--warn("callback.....")
-- 		callback_function(content_table)
-- 	else
-- 		warn("callback_function is nil")
-- 	end

-- end

-- pb_helper.AddHandler("npt_get_http_resp", on_http_get_rep)

