local Lplus           = require "Lplus"
local client_msg      = require "PB.client_msg"
local pb_helper       = require "PB.pb_helper"

-- local function on_html5_info_notify(sender, msg)
-- 	--local Html5PageHelper = require "Utility.ECHtml5PageHelper"
-- 	--Html5PageHelper.Instance():NotifySign(msg.html5_sign, LuaUInt64.ToString(msg.timestamp))
-- end

-- pb_helper.AddHandler("npt_html5_info", on_html5_info_notify)