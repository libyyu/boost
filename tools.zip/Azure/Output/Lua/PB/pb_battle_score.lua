local pb_helper = require "PB.pb_helper"

local function on_battle_score(sender, msg)
    local ECBattleScoreMan = require "Main.ECBattleScoreMan".Instance()
    if ECBattleScoreMan then
        ECBattleScoreMan:setScore(msg.score)
    end
end

pb_helper.AddHandler("gp_battle_score", on_battle_score)

--- @param msg pb.Message.PB.gp_battle_ground_grand
local function on_gp_battle_ground_grand(sender, msg)
    local ECBattleFieldScoreManager = require "GUI.BattleField.ECBattleFieldScoreManager"
    ECBattleFieldScoreManager.Instance():OnBattleGroundGrand(msg)
end

pb_helper.AddHandler("gp_battle_ground_grand", on_gp_battle_ground_grand)

--- @param msg pb.Message.PB.gp_battle_player_enter
local function on_gp_battle_player_enter(sender, msg)
    local ECBattleFieldScoreManager = require "GUI.BattleField.ECBattleFieldScoreManager"
    ECBattleFieldScoreManager.Instance():SearchAllPlayerInfo({msg.roleid})
end
pb_helper.AddHandler("gp_battle_player_enter", on_gp_battle_player_enter)


--- @param msg pb.Message.PB.gp_avatar_notify
local function on_gp_avatar_notify(sender, msg)
    local ECBattleFieldScoreManager = require "GUI.BattleField.ECBattleFieldScoreManager"
    local OP_TYPE = require"PB.client_msg".gp_avatar_notify.OpType
    if msg.ot == OP_TYPE.OT_ROLEID_LIST then
        ECBattleFieldScoreManager.Instance():SearchAllPlayerInfo(msg.roleid_list.roleids)

        --输出机器人的名字
        local ECDebugOption = require "Main.ECDebugOption"
        if ECDebugOption.Instance().debug_avatar then
            warn("received avatar notify.")
            GameUtil.AddGlobalTimer(20, false, function ()
                local GameBriefInfoCacheMan = require "Common.GameBriefInfoCacheMan"
                for _, id in ipairs(msg.roleid_list.roleids) do
                    warn("avatar", LuaUInt64.ToString(id), GameBriefInfoCacheMan.Instance():FindNameCache(id))
                end
            end)
        end
    end
end
pb_helper.AddHandler("gp_avatar_notify", on_gp_avatar_notify)