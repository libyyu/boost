local Lplus = require "Lplus"
---@type ECGame
local ECGame = Lplus.ForwardDeclare("ECGame")
local pb_helper = require "PB.pb_helper"
local ECAvatarMan = require "GUI.ECAvatarMan"
local UIPanelAvatar = require "GUI.Character.UIPanelAvatar"
local NotifyAvatarChange = require "Event.AvatarEvents".NotifyAvatarChange
local OP_TYPE = require("PB.client_msg").gp_headicon_notify.OP_TYPE

local function on_headicon_notify(sender, msg)
    local update_unlock = false
    local update_cur = false
    local inited = false
    if msg.op_type == OP_TYPE.SYNC_ALL_DATA then
        update_unlock = true
        update_cur = true
        inited = true
    elseif msg.op_type == OP_TYPE.SYNC_CUR_DATA then
        update_cur = true
    elseif msg.op_type == OP_TYPE.SYNC_UNLOCK_DATA then
        update_unlock = true
    end

    local data = msg.headicon_data
    local ECAvatarManIns = ECAvatarMan.Instance()
    if update_unlock then
        ECAvatarManIns:UpdateDisplayedList(data.headicon_list, false, inited)
        ECAvatarManIns:UpdateDisplayedList(data.headframe_list, true, inited)
    end
    if update_cur then
        if not inited then
            local m_cur_avatar = ECAvatarManIns.m_cur_avatar
            if m_cur_avatar ~= 0 and m_cur_avatar ~= data.cur_headicon and not require "Roguelike.ECRoguelikeMan".Instance():IsInRoguelike() then
                FlashTipMan.FlashTip(StringTable.Get(68015))
            end
            local m_cur_frame = ECAvatarManIns.m_cur_frame
            if m_cur_frame ~= 0 and m_cur_frame ~= data.cur_headframe and not require "Roguelike.ECRoguelikeMan".Instance():IsInRoguelike() then
                FlashTipMan.FlashTip(StringTable.Get(68016))
            end
        end
        ECAvatarManIns:UpdateCurrentAvatarAndFrame(data.cur_headicon, data.cur_headframe)
    end

    local UIPanelAvatarIns = UIPanelAvatar.Instance()
    if UIPanelAvatarIns:IsValid() and update_unlock then
        UIPanelAvatarIns:UpdateScrollList()
        UIPanelAvatarIns:UpdateDetails()
    end
    if update_cur then
        ECGame.EventManager:raiseEvent(nil, NotifyAvatarChange())
    end
end

pb_helper.AddHandler("gp_headicon_notify", on_headicon_notify)