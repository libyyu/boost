
local pb_helper = require "PB.pb_helper"
local client_msg = require "PB.client_msg"
local C2S_GS_PROTOC_TYPE = client_msg.C2S_GS_PROTOC_TYPE

---@param sender any
---@param msg pb.Message.PB.gp_gs_error_message
local function on_gs_error_message(sender, msg)
	--warn("on_gs_error_message ",msg)
	if client_msg.GPROTOC_GET_RED_PACKET == msg.proto_type then
		local ECRedPacketMan = require "Main.ECRedPacketMan"
		ECRedPacketMan.Instance():onRedPacketError(msg)
	elseif client_msg.GPROTOC_COMPENSATION == msg.proto_type then
		local bHasError = false
		if 1 == msg.error_code then --今天已经领取；
			bHasError = true
			FlashTipMan.FlashTip(StringTable.Get(16100),"already_get")
		elseif 2 == msg.error_code then --活动尚未开启；
			bHasError = true
			FlashTipMan.FlashTip(StringTable.Get(16101),"activity_not_open")
		elseif 3 == msg.error_code then --级别不满足
			bHasError = true
			FlashTipMan.FlashTip(StringTable.Get(16102),"level_not_valid")
		end
		if bHasError then
			local ECPanelCompensationEntry = require "GUI.ECPanelCompensationEntry"
			--ECPanelCompensationEntry.Instance():DestroyPanel()
			ECPanelCompensationEntry.Instance():RemoveOneCompensation(msg.param)
		end
	elseif client_msg.GPROTOC_WUHUN_UPGRADE == msg.proto_type then
		if 1 == msg.error_code then
			FlashTipMan.FlashTip(StringTable.Get(16606))
		elseif 2 == msg.error_code then
			FlashTipMan.FlashTip(StringTable.Get(16607))
		elseif 3 == msg.error_code then
			FlashTipMan.FlashTip(StringTable.Get(16608))
		elseif 4 == msg.error_code then
			FlashTipMan.FlashTip(StringTable.Get(16603))
		elseif 5 == msg.error_code then
			FlashTipMan.FlashTip(StringTable.Get(16604))
		end
	elseif client_msg.GPROTOC_COMMON_OPERATION == msg.proto_type then
		local gp_common_operation = require "PB.client_msg".gp_common_operation
		local bHandled = false
		if msg.param ==  gp_common_operation.CO_INSTANCE_GROUP_REWARD then
			if 5 == msg.error_code then
				FlashTipMan.FlashTip(StringTable.Get(1334))
				bHandled = true
			end
		end
		if not bHandled then
			FlashTipMan.FlashTipByPBErrorCode(msg.error_code)
		end
	else
		FlashTipMan.FlashTipByPBErrorCode(msg.error_code)
	end
end
pb_helper.AddHandler("gp_gs_error_message", on_gs_error_message)