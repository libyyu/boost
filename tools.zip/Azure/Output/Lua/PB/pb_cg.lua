local Lplus = require "Lplus"

local pb_helper = require "PB.pb_helper"
local client_msg = require "PB.client_msg"
local CG = require "CG.CG"
local ECPanelCG = require "GUI.CG.ECPanelCG"




---@class CGProt:System.Object
---@field public Commit fun():CGProt @notnull
---@field public Skip fun(cg_id:number, skip:boolean)
local CGProt = Lplus.Class("CGProt")
local def = CGProt.define

---@param cg_id number
---@param skip boolean
---@return void
def.static("number", "boolean").Skip = function(cg_id, skip)
	Log.Print("cg", "Notify Server Cg:%d Stop, IsSkip:%s",cg_id, tostring(skip))
	local msg = client_msg.gp_cg_player_op()
	msg.cg_id = cg_id
	msg.skip = skip
	pb_helper.Send(msg)
	require "BehaviorRecords.BehaviorRecordsManager".Instance():RecordBehavior("PlayCG", {cg_id = cg_id, skip = skip})
end

local function on_gp_skip_cg_list(sender, msg)
	local SkipList = msg.ids
	if not SkipList then return end
	ECPanelCG.Instance():ShowAlreadySkip(SkipList)
end
pb_helper.AddHandler("gp_skip_cg_list", on_gp_skip_cg_list)



CGProt.Commit()


local function PlayCGInner(cgId)
	local cg = CG.Instance()
	local _, retCode = cg:PlayById(cgId,nil)

	-- 播放失败，通知服务器播放完成，否则副本脚本会等待播放完成协议直到超时
	if retCode ~= CG.PlayCGErrCode.Success then
		CGProt.Skip(cgId, false)
	end
end


local function PlayCG(sender, msg)
	PlayCGInner(msg.cg_id)
end
pb_helper.AddHandler("PlayCG", PlayCG)

local function on_gp_start_cg( sender,msg )
	PlayCGInner(msg.cg_id)
end
pb_helper.AddHandler("gp_start_cg", on_gp_start_cg)

local function on_gp_stop_cg( sender,msg )
	if not msg:HasField("cg_id") then return end
	local id = msg.cg_id
	if CG.Instance():IsPlaying(id) then
		Log.DebugError("收到服务器停止播放cg信息，检查是否播放cg接口给的超时时间不够", id)
		local cg = CG.Instance()
		cg:StopById(id, "server call")
	end
end
pb_helper.AddHandler("gp_stop_cg", on_gp_stop_cg)

return CGProt

