--活动返还
--
-- npt_get_activity_award
-- 
local pb_helper = require "PB.pb_helper"

local function on_get_activity_award( sender,msg )
	FlashTipMan.FlashTip(StringTable.Get(19000 + msg.retcode))
end

pb_helper.AddHandler("npt_get_activity_award",on_get_activity_award)