local pb_helper = require "PB.pb_helper"
local client_msg = require "PB.client_msg"

local function on_npt_common_notify (sender, msg)
	local notify_type = msg.notify_type
	if notify_type == client_msg.npt_common_notify.NOTIFY_TYPE.CLIENT_PATCH then
		require "Utility.CodePatch".ApplyPatch(msg.notify_message)
	else
		
	end
end

pb_helper.AddHandler("npt_common_notify", on_npt_common_notify)
