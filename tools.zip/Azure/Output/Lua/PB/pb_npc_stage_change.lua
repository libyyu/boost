--[[
	npc阶段变化
]]

local ECGame = require "Main.ECGame"
local pb_helper = require "PB.pb_helper"
local function on_gp_npc_stage_change(sender, msg )
	local world = ECGame.Instance():GetCurWorld()
	if not world then return end

	local npc = world.m_NPCMan:GetNPC(msg.id)
	if not npc then return end

	npc:CMD_ChangeStage(msg)
end

pb_helper.AddHandler("gp_npc_stage_change", on_gp_npc_stage_change)