local pb_helper = require "PB.pb_helper"


local on_gp_sign_in_info =  function(_, msg)
	--print_ygao("on_gp_sign_in_info msg", msg)
	--print_ygao("on_gp_sign_in_info msg_type", msg.msg_type							) --消息类型
	--print_ygao("on_gp_sign_in_info is_sign_in", msg.is_sign_in						) --今天是否已签过
	--print_ygao("on_gp_sign_in_info total_sign_in_times", msg.total_sign_in_times    ) --累计签到次数
	--print_ygao("on_gp_sign_in_info almanac_info_list", msg.almanac_info_list 		) --黄历信息
	--print_ygao("on_gp_sign_in_info items", msg.items								) --今日签到获得道具
	--print_ygao("on_gp_sign_in_info reward_tid", msg.reward_tid						) --今日通用奖励tid
	--print_ygao("on_gp_sign_in_info is_open", msg.is_open							) --是否七日签到已完成

	local client_msg = require "PB.client_msg"
	if msg.msg_type ~= client_msg.gp_sign_in_info.MSG_TYPE.REFRESH then
		require "GUI.Welfare.UIPanelWelfareLetter".Instance():On_gp_sign_in_info(msg)
	end
	require "GUI.Welfare.UISubPanelWelfareStarlight".Instance():On_gp_sign_in_info(msg)

	local ECSignInMan = require "GUI.SignIn.ECSignInMan"
	ECSignInMan.Instance():SetStarlightIsOpen(msg.is_open)
end
pb_helper.AddHandler("gp_sign_in_info", on_gp_sign_in_info)

local ECGame = require "Main.ECGame"
local ActivityEvents = require("Event.ActivityEvents")
--print_ygao("pb_sign_in_info")

---@param event Event.ActivityEvent.ActivityInfoInit
ECGame.EventManager:addHandler(ActivityEvents.ActivityInfoInit, function(_, event)
	--local UIPanelWelfareMain = require("GUI.Welfare.UIPanelWelfareMain")
	--local canShow = UIPanelWelfareMain.Instance():CanShow("Starlight")
	----print_ygao("ActivityInfoInit canShow",canShow)
	--if not canShow then
	--	return
	--end

	local pb_helper = require "PB.pb_helper"
	local client_msg = require "PB.client_msg"
	local gp_sign_in = client_msg.gp_sign_in
	--print_ygao("gp_sign_in.OPERATE",gp_sign_in.OPERATE.GET_INFO)
	local msg = gp_sign_in()
	msg.op = gp_sign_in.OPERATE.GET_INFO
	pb_helper.Send(msg)
end)