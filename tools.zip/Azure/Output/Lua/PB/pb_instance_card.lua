local pb_helper = require "PB.pb_helper"
local FEInstanceMan = require "Instance.FEInstanceMan"

local function on_close_info(sender, msg)
    FEInstanceMan.Instance():SetKickoutServerTime(msg.close_time)
    if not msg.card_draw then
        GameUtil.AddGlobalTimer(1, true, function()
            local ECPanelInstanceExtraBagInst = require "GUI.Instance.ECPanelInstanceExtraBag".Instance()
            local ECInstanceEndSequenceManager = require "GUI.Instance.ECInstanceEndSequenceManager"
            ECInstanceEndSequenceManager.Instance():StartSequenceWithIndex(ECPanelInstanceExtraBagInst, nil)
        end)
    end
end
pb_helper.AddHandler("gp_instance_close_info", on_close_info)

local function on_card_info(sender, msg)
    local ECPanelInstanceEndGift = require "GUI.Instance.ECPanelInstanceEndGift"
    --应当通过重新打开结果界面而自然开启
    --if msg.reconnect then
    --    local function show_end_gift_ui()
    --        GameUtil.AddGlobalTimer(1, true, function()
    --            ECPanelInstanceEndGift.Instance():ReshowPanel(msg.normal_card_info, msg.cost_info, msg.select_info)
    --        end)
    --    end
    --    local ECPanelLoadingMan = require "GUI.ECPanelLoadingMan"
    --    if ECPanelLoadingMan.Instance():IsLoadingUIShown() then
    --        ECPanelLoadingMan.Instance():WaitForLoadingUIHide(show_end_gift_ui)
    --    else
    --        show_end_gift_ui()
    --    end
    --else
        ECPanelInstanceEndGift.Instance():UpdateCardInfo(msg.normal_card_info, msg.cost_info)
    --end
end
pb_helper.AddHandler("gp_instance_card_info", on_card_info)

local function on_personal_reward(sender, msg)
    local ECPanelInstanceEndGift = require "GUI.Instance.ECPanelInstanceEndGift"
    ECPanelInstanceEndGift.Instance():UpdatePersonalReward(msg.normal_card_id, msg.normal_reward_item_tid, msg.friend_card_id, msg.friend_reward_item_tid)
end
pb_helper.AddHandler("gp_instance_card_personal_reward", on_personal_reward)

local function on_team_reward(sender, msg)
    local ECPanelInstanceEndGift = require "GUI.Instance.ECPanelInstanceEndGift"
    ECPanelInstanceEndGift.Instance():UpdateTeamReward(msg.team_card_info)
end
pb_helper.AddHandler("gp_instance_card_team_reward", on_team_reward)