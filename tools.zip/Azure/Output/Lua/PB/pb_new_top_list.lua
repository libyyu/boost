local pb_helper = require "PB.pb_helper"
local ECGame = require "Main.ECGame"

---@param msg pb.Message.PB.npt_new_toplist
local function on_new_top_list( sender,msg )
	--warn("npt_top_reward msg.tid ", msg)
	local ECRankData = require "Rank.ECRankData"
	ECRankData.Instance():SetNewTopList( msg )
end
 
pb_helper.AddHandler("npt_new_toplist", on_new_top_list)


local function on_npt_new_toplist_worship_count( sender,msg )
	--warn("npt_new_toplist_worship_count ", msg)
	local ECPanelRank = require "GUI.Rank.ECPanelRank"
	ECPanelRank.Instance():SetWorshipTimesData(msg)
end
pb_helper.AddHandler("npt_new_toplist_worship_count",on_npt_new_toplist_worship_count)
