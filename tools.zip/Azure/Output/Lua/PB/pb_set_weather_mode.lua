local Lplus = require "Lplus"
local pb_helper = require "PB.pb_helper"

local function OnWeatherToggleResponse(sender, msg)
	local ECGame = require "Main.ECGame"
	ECGame.Instance():ToggleWeather(msg.scene_id, msg.region_id, msg.weather_type, msg.on_off)
end
pb_helper.AddHandler("gp_set_weather_mode", OnWeatherToggleResponse)

