local Lplus = require "Lplus"

local pb_helper = require "PB.pb_helper"

--
-- npt_sync_nation_war_info
--
local function on_nation_war_info_respond( sender,msg )
	--print("on_nation_war_info_respond",msg)
	--local ECNationWarConvTool = require "GUI.ECNationWarConvTool"
	--ECNationWarConvTool.Instance():sync_nation_war_info(msg)
end

--
-- npt_nation_war_operate_info_re
-- 
local function on_nation_war_operate_info_respond( sender,msg )
	--local ECNationWarConvTool = require "GUI.ECNationWarConvTool"
	--ECNationWarConvTool.Instance():nation_war_operate_info(msg)
end

--
-- npt_nationwar_event
--
local function on_nationwar_event_respond(sender,msg)
	--print("on_nationwar_event_respond",msg)
	--local ECNationWarConvTool = require "GUI.ECNationWarConvTool"
	--ECNationWarConvTool.Instance():on_nationwar_event(msg)
end

--
-- npt_nation_war_history
-- 
local function on_nation_war_history(sender,msg)
	--print("on_nation_war_history",msg)
	--local ECNationMan = require "Social.ECNationMan"
	--ECNationMan.Instance():onnationwar_histroy(msg)
end


--pb_helper.AddHandler("npt_sync_nation_war_info", on_nation_war_info_respond)
--pb_helper.AddHandler("npt_nation_war_operate_info_re", on_nation_war_operate_info_respond)
--pb_helper.AddHandler("npt_nationwar_event", on_nationwar_event_respond)
--pb_helper.AddHandler("npt_nation_war_history", on_nation_war_history)