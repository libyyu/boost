local pb_helper = require "PB.pb_helper"

local function on_gp_open_inventory(sender, msg)
	print_ygao("on_gp_open_inventory")
	local packagePanel = require "GUI.Character.UIPanelPackage".Instance()
	packagePanel:OnArrangeInventory()
end
pb_helper.AddHandler("gp_open_inventory", on_gp_open_inventory)

