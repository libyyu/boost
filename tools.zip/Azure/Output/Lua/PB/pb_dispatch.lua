local pb_helper = require "PB.pb_helper"

---@param msg pb.Message.PB.gp_speople_dispatch_notify
local function on_gp_speople_dispatch_notify(sender, msg)
    local ECDispatchMan = require "Dispatch.ECDispatchMan"
    ECDispatchMan.Instance():OnDispatchNotify(msg)
end
pb_helper.AddHandler("gp_speople_dispatch_notify", on_gp_speople_dispatch_notify)

---@param msg pb.Message.PB.gp_speople_dispatch_state_notify
local function on_gp_speople_dispatch_state_notify(sender, msg)
    local ECDispatchMan = require "Dispatch.ECDispatchMan"
    ECDispatchMan.Instance():OnDispatchStateNotify(msg)
end
pb_helper.AddHandler("gp_speople_dispatch_state_notify", on_gp_speople_dispatch_state_notify)