---@type ECGame
local ECGame = require("Main.ECGame")
local pb_helper = require "PB.pb_helper"
local output_tip_type =
{
	log = 0,
	flashtip = 1,
	messagebox = 2,
	npcmsg = 3
}

local OutputLevelFlag =
{
	[output_tip_type.log] = true,
	[output_tip_type.flashtip] = true,
	[output_tip_type.messagebox] = true,
	[output_tip_type.npcmsg] = false,
}

local DEBUG = _G.STRICT_LOG
local function on_debug_output(sender, msg)
	local outStrList = string.split(msg.output.output,"\n")
	local level = msg.output.level
	local roleid = msg.output.roleid

	for i=1,#outStrList do
		if OutputLevelFlag[level] then
			print("server output:",outStrList[i])
		end

		if DEBUG then
			if level == output_tip_type.flashtip  and OutputLevelFlag[level] then
				_G.FlashTipMan.FlashTip(outStrList[i])
			end
		end
	end

	if DEBUG then
		if level == output_tip_type.messagebox and OutputLevelFlag[level] then
			MsgBox.ShowMsgBox(nil, "ServerWarning:"..msg.output.output, nil, MsgBoxType.MBBT_OK)
		elseif level == output_tip_type.npcmsg and OutputLevelFlag[level] then
			if roleid and roleid ~= "" then
				local pWorld = ECGame.Instance().m_CurWorld
				local npcMan = pWorld and pWorld.m_NPCMan or nil
				if npcMan then
					local npc = npcMan:GetNPC(roleid)
					if npc then
						if npc:IsBoss() then
							local CHAT_CHANNEL_ENUM = _G.CONSTANT_DEFINE.CHAT_CHANNEL_ENUM
							local mytest = require("test.mytest")
							mytest:add_msg_text(msg.output.output , CHAT_CHANNEL_ENUM.CHAT_CHANNEL_SYSTEM)
						else
							local message= msg.output.output
							npc:SetShowingDebugSay(true)
							npc:GetSpeaker():Speak(message, 5)
						end
					end
				end
			end
		end
	end
end

local function on_gp_debug_output(sender, msg)
	--print_jzw("on_gp_debug_output")
	on_debug_output(sender, msg)
end

local function on_npt_debug_output(sender, msg)
	--print_jzw("on_npt_debug_output")
	on_debug_output(sender, msg)
end

pb_helper.AddHandler("gp_debug_output", on_gp_debug_output)

pb_helper.AddHandler("npt_debug_output", on_npt_debug_output)



--[[
message flat_serialize_info {
	option (s2c_type) = type_gp_flat_serialize_info;
	message unit{
		string msg_name = 1;
		string meta	= 2;
	}
	repeated unit units 	= 1;
}
--]]
local function on_flat_serialize_info(sender, msg)
	local count = #msg.units
	for i = 1, count do
		local unit = msg.units[i]
		--warn(string.format("msg_name is %s and meta is %s on the flat_serialize_info`s output is:", unit.msg_name, unit.meta))
	end
	-- local FELogDataMan = require "Main.FELogDataMan"
	-- FELogDataMan.Instance():OnServerLog(msg.output)

	--warn("flat_serialize_info`s output is:", msg.output)
end

pb_helper.AddHandler("flat_serialize_info", on_flat_serialize_info)

local function SetLogLevelFlag(level, flag)
	OutputLevelFlag[level] = ToBoolean(flag)
	print("SetLogLevelFlag", level, ToBoolean(flag))
end

return
{
	SetLogLevelFlag = SetLogLevelFlag
}