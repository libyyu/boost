local pb_helper = require "PB.pb_helper"
local client_msg = require "PB.client_msg"
local ECGame = require "Main.ECGame"

-------------------------------------------------------Eleven帮派战----------------------------------------------------------
local function on_npt_clan_clash_list(sender, msg)
	ECGame.Instance():OnHostPlayerCreate(function()
		local ECFactionWarMan = require "Main.ECFactionWarMan"
		ECFactionWarMan.Instance():onGetFightListResponse(msg)
	end)
end
pb_helper.AddHandler("npt_clan_clash_list", on_npt_clan_clash_list)
