local Lplus = require "Lplus"

local pb_helper = require "PB.pb_helper"
local client_msg = require "PB.client_msg"
local ECGame = require "Main.ECGame"
local ECWorld = require "Main.ECWorld"

-- 通用的操作成功协议
local function gp_success_info(sender, msg)
	local hp = ECGame.Instance().m_HostPlayer
	if not hp then return end
	if msg.success_type == 1 then --伙伴兑换劵使用成功
		if msg.param1 and msg.param1 > 0 then
			-- local npcs = ElementData.getAllDataByName("AssistantNPC")
			-- GameWarn("=======npc id =====",msg.param1)
			-- local name = npcs[msg.param1].comments
			-- FlashTipMan.FlashTip(StringTable.Get(22461):format(name, StringTable.Get(22454-1+msg.param2)))
			
			-- -- 伙伴事件
			-- local PartnerNotifyEvent = require "Event.PartnerNotifyEvent"
			-- local event = PartnerNotifyEvent()
			-- event.partnerID = msg.param1
			-- event.unlockType = msg.param2
			-- ECGame.EventManager:raiseEvent(nil, event)
		end
	end
end
pb_helper.AddHandler("gp_success_info", gp_success_info)



