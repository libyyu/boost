--[[
	roguelike 玩法相关
]]

local pb_helper = require "PB.pb_helper"
local Lplus = require "Lplus"

local ECGame = require("Main.ECGame")

--[[
local function on_gp_player_reputation (sender, msg)
	--local StringTable = require "Data.StringTable"
	--int32 change_type = 1;//同步所有为-1
	--map<int32, player_reputation_struct> info = 2;//声望数据
	--message player_reputation_struct
	--{
	--	int32 value = 1;
	--	int32 beyond_limit_value = 2;
	--	int32 day_value = 3;
	--	int32 week_value = 4;
	--	int32 month_value = 5;
	--	int32 last_modify_time = 6;
	--}

	--warn("******** on_gp_player_reputation")
	local ECGame = require "Main.ECGame"
	ECGame.Instance():OnHostPlayerCreate(function() on_msg(sender, msg) end)
end]]

pb_helper.AddHandler("gp_roguelike_operation_re", function (sender, msg)
	local ECRoguelikeMan = require "Roguelike.ECRoguelikeMan"
	ECRoguelikeMan.Instance():OnServerMsg(msg)
end)
