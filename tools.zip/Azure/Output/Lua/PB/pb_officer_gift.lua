
local pb_helper = require "PB.pb_helper"
--[[
local function on_officer_gift(sender, msg)
	--warn("on_officer_gift--官员福利",msg)
	local ECNationMan = require "Social.ECNationMan"
	ECNationMan.Instance().mGiftId = msg.gift_id
	local ECGame = require "Main.ECGame"
	local OfficerGiftEvt = require "Event.OfficerGiftEvt"
	ECGame.EventManager:raiseEvent(nil, OfficerGiftEvt.new(msg.gift_id))
end

pb_helper.AddHandler("npt_officer_gift_notify", on_officer_gift)
]]