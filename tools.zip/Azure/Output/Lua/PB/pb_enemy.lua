--仇敌

--
-- gp_enemy_list
-- 
local pb_helper = require "PB.pb_helper"

local function on_enemy_list( sender,msg )
	local FriendMan = require "Friends.FriendMan"
	FriendMan.Instance():OnPbEnemyListRe(msg)
end

pb_helper.AddHandler("gp_enemy_list",on_enemy_list)