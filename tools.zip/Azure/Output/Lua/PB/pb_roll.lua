local Lplus = require "Lplus"
local pb_helper = require "PB.pb_helper"
local ECGame = require "Main.ECGame"
local bit = require "bit"
--local NotifyRoll = require "Event.NotifyRoll"
local band = bit.band

local function on_gp_roll_item_result(sender, msg)
	local hp = ECGame.Instance().m_HostPlayer
	if not hp then return end
	hp.Roll:onRollItemResult(msg.roll_id, msg.player_id, msg.eva_id, msg.point, msg.item_id)
	
	-- local NotifyRollResult = NotifyRoll.NotifyRollResult
	-- local event = NotifyRollResult()
	-- event.roll_id = msg.roll_id
	-- event.player_id = msg.player_id
	-- event.eva_id = msg.eva_id
	-- event.point = msg.point
	-- event.item_id = msg.item_id
	-- ECGame.EventManager:raiseEvent(nil, event)
end
pb_helper.AddHandler("gp_roll_item_result", on_gp_roll_item_result)


local function on_gp_roll_item_response(sender, msg)
	local hp = ECGame.Instance().m_HostPlayer
	if not hp then return end
	hp.Roll:onRollItemResponse(msg.roll_id, msg.player_id, msg.eva_id, msg.point, msg.item_id, msg.use_limit)

	-- local NotifyRollResponse = NotifyRoll.NotifyRollResponse
	-- local event = NotifyRollResponse()
	-- ECGame.EventManager:raiseEvent(nil, event)
end
pb_helper.AddHandler("gp_roll_item_response", on_gp_roll_item_response)


local function on_gp_notice_roll_items(sender, msg)
	local hp = ECGame.Instance().m_HostPlayer
	if not hp then return end
	hp.Roll:onNoticeRollItems(msg.item, msg.can_roll, msg.pos)

	-- local NotifyRollStart = NotifyRoll.NotifyRollStart
	-- local event = NotifyRollStart()
	-- ECGame.EventManager:raiseEvent(nil, event)
end
pb_helper.AddHandler("gp_notice_roll_items", on_gp_notice_roll_items)


local ROLL_ITEM_REWARD_TID = 1014
local function on_gp_receive_reward_fail(sender, msg)
	print("on_gp_receive_reward_fail", msg.tid)
	local hp = ECGame.Instance().m_HostPlayer
	if not hp then return end
	
	local rewardList = hp.InfoData.RewardList
	local tid = msg.tid
	if tid == ROLL_ITEM_REWARD_TID then
		for i = 1, #rewardList do
			if tid == rewardList[i].tid then
				if msg.extra_param == rewardList[i].extra_param then
					local receive_reward = require "C2S.receive_reward"
					local cmd = receive_reward.new(i - 1, tid, msg.extra_param)
					ECGame.Instance().m_Network:SendGameData(cmd)
					--print("______send", msg.extra_param)
					break
				end
			end
		end
	end
end
pb_helper.AddHandler("gp_receive_reward_fail", on_gp_receive_reward_fail)


