--[[
	名人
]]
local ECGame = require "Main.ECGame"
local pb_helper = require "PB.pb_helper"
local _warn = _G.GetModuleLog("people")

---@param msg pb.Message.PB.gp_speople_notify
local function on_gp_speople_notify(sender, msg)
	_warn("on_gp_speople_notify", msg)
	require "SummonPeople.ECSummonPeopleMan".Instance():OnNotify(msg)
end
pb_helper.AddHandler("gp_speople_notify", on_gp_speople_notify)
--名人数据
local function on_gp_speople_info(sender, msg)
	_warn("on_gp_speople_info", msg)
	require "SummonPeople.ECSummonPeopleMan".Instance():OnUpdatePeopleData(msg)
end
pb_helper.AddHandler("gp_speople_info", on_gp_speople_info)

--批量名人数据
local function on_gp_speople_batch(sender, msg)
	_warn("on_gp_speople_batch", msg)
	for _, v in pairs(msg.people_list) do
		require "SummonPeople.ECSummonPeopleMan".Instance():OnUpdatePeopleData(v)
	end
end
pb_helper.AddHandler("gp_speople_batch", on_gp_speople_batch)

local function on_gp_speople_common_info(sender, msg)
	_warn("on_gp_speople_common_info", msg)

	--[[
	enum SPEOPLE_COMMON_SYNC_OP {
		SCST_ALL            = 0;  //全量
		SCST_MEMBER_LIST    = 1;  //阵容配置
		SCST_MERCENARY_LIST = 2;  //阵容配置
		SCST_PALACE         = 3;  //殿堂
		SCST_FRAGMENT       = 4;  //碎片
		SCST_SOTHOTH_TOWER  = 5;  //索托斯之塔队伍变化
		SCST_FRIENDSHIP     = 6;  //羁绊
	}]]

	if msg.op == 6 then
		local ECPanelPeopleFriendShip = require "GUI.SummonPeople.ECPanelPeopleFriendShip"
		ECPanelPeopleFriendShip.Instance():OnDealMsgActive(msg)
	else
		require "SummonPeople.ECSummonPeopleMan".Instance():OnUpdateCommonData(msg)
	end

end
pb_helper.AddHandler("gp_speople_common_info", on_gp_speople_common_info)

local function on_gp_speople_operate_ret(sender, msg)
	_warn("on_gp_speople_operate_ret", msg)
	require "SummonPeople.ECSummonPeopleMan".Instance():OnOperationResult(msg)
end
pb_helper.AddHandler("gp_speople_operate_ret", on_gp_speople_operate_ret)

local function on_gp_speople_exp_notify(sender, msg)
	_warn("on_gp_speople_exp_notify", msg)
	require "SummonPeople.ECSummonPeopleMan".Instance():OnUpdateExp(msg)
end
pb_helper.AddHandler("gp_speople_exp_notify", on_gp_speople_exp_notify)

local function on_gp_speople_state_notify(sender, msg)
	_warn("on_gp_speople_state_notify", msg)
	require "SummonPeople.ECSummonPeopleMan".Instance():OnUpdatePeopleState(msg)
end
pb_helper.AddHandler("gp_speople_state_notify", on_gp_speople_state_notify)

local function on_gp_speople_inc_hp_notify(sender, msg)
	_warn("on_gp_speople_inc_hp_notify", msg)
	require "SummonPeople.ECSummonPeopleMan".Instance():OnUpdateHP(msg)
end
pb_helper.AddHandler("gp_speople_inc_hp_notify", on_gp_speople_inc_hp_notify)

local function on_gp_speople_pre_prop(sender, msg)
	local gp_speople_pre_prop = pb_helper.GetCmdClass("gp_speople_pre_prop")
	-- 目前只有升星需要该协议
	if msg.type == gp_speople_pre_prop.SPPT_STAR then
		--require("GUI.SummonPeople.ECPanelPeopleStar").Instance():SetAddonAttrs(msg)
	end
end
pb_helper.AddHandler("gp_speople_pre_prop", on_gp_speople_pre_prop)
--拆解战法成功后收到协议
--培养战法
--local function on_gp_speople_magic_info(sender, msg)
--	_warn("on_gp_speople_magic_info", msg)
--	require "SummonPeople.ECSummonPeopleMagicMan".Instance():OnServerUpdateMagicData(msg)
--end
--pb_helper.AddHandler("gp_speople_magic_info", on_gp_speople_magic_info)

--同步召唤的名人信息
local function on_gp_speople_fight_info(sender, msg)
	_warn("on_gp_speople_fight_info", msg)
	require "SummonPeople.ECSummonPeopleMan".Instance():OnUpdatePeopleFightData(msg)
end
pb_helper.AddHandler("gp_speople_fight_info", on_gp_speople_fight_info)

--幻灵复活
---@param msg pb.Message.PB.gp_people_extra_notify
local function on_gp_people_extra_notify(sender, msg)
	local ECSummonPeopleMan = require "SummonPeople.ECSummonPeopleMan"
	_warn("on_gp_people_extra_notify", msg)
	local data = ECSummonPeopleMan.Instance():GetPeopleData(msg.people_tid)
	if data then
		data:SetDeathTime(msg.mercenary_death_time)
	end
	local SummonPeopleReviveEvent = require("Event.SummonPeopleEvents").SummonPeopleReviveEvent
	local event = SummonPeopleReviveEvent.new(msg.people_tid, msg.mercenary_death_time)
	ECGame.EventManager:raiseEvent(nil, event)
end
pb_helper.AddHandler("gp_people_extra_notify", on_gp_people_extra_notify)

--幻灵推荐
local function npt_people_recommend( sender, msg )
	require "SummonPeople.ECSummonPeopleMan".Instance():OnRecommend(msg)
end
pb_helper.AddHandler("npt_people_recommend", npt_people_recommend)

--[[
local function on_gp_speople_npc_info(sender, msg)
	--幻灵召唤的情况下升级属性不变，只有下次再招的时候才会起作用，所以不用处理动态变化的了

	print_jzw("gp_speople_npc_info",msg.step_level,msg.people_tid,LuaUInt64.ToString(msg.npc_id))

	local ECGame = require "Main.ECGame"
	---@type ECNPC
	local npc = ECGame.Instance():FindObject(msg.npc_id)
	if npc then
		print_jzw("gp_speople_npc_info",msg.step_level,msg.people_tid,LuaUInt64.ToString(msg.npc_id))
		npc:SetStepLevel(msg.step_level)

		if npc:GetFightPerformModel() then
			npc:GetFightPerformModel():RefreshWeaponQianghuaFx()
		end
	end
end
pb_helper.AddHandler("gp_speople_npc_info", on_gp_speople_npc_info)
--]]

local function on_gp_rookie_people_reward_s2c( sender, msg )
	local retcode = msg.retcode
	_warn("on_gp_rookie_people_reward_s2c", msg)
end
pb_helper.AddHandler("gp_rookie_people_reward_s2c", on_gp_rookie_people_reward_s2c)