
local pb_helper = require "PB.pb_helper"
local client_msg = require "PB.client_msg"

local function on_notify_cash_change(sender, msg)
	local ECChatManager = require "Chat.ECChatManager"
	local ECChatHandle = require "Chat.ECChatHandle"
	--warn("on_notify_cash_change", msg.change_type,msg.bind_value,msg.unbind_value)
	local type = msg.change_type
	local NotifyMoneyChange = require "Event.NotifyMoneyChange" 
	local Lplus = require "Lplus"
	---@type ECGame
	local ECGame = Lplus.ForwardDeclare("ECGame")
	if msg.bind_value ~= 0 then
		if type == 1 then --使用
			FlashTipMan.FlashTip(StringTable.Get(520):format(msg.bind_value), "NOTIFYCASH")--消耗了[palette:CashNumber:%1$d]钻石
		elseif type == 2 then --退还
			FlashTipMan.FlashTip(StringTable.Get(521):format(msg.bind_value), "NOTIFYCASH")
		elseif type == 3 then --赠送
			local str = StringTable.Get(523):format(msg.bind_value)
			local richStr = ECChatHandle.Instance():MakeDiamondImg("inc_diamond_0",32 , -6)
			richStr = richStr .. str
			local ECMsgInfo = require "Chat.ECMsgInfo"
			ECChatManager.Instance():AddSimpleMessageWithType(str, richStr, _G.CONSTANT_DEFINE.CHAT_CHANNEL_ENUM.CHAT_CHANNEL_SYSTEM, ECMsgInfo.MSG_TYPE.SYSTEM, "")
			FlashTipMan.FlashRegionTip(StringTable.Get(522):format(msg.bind_value))
		end

		local ECGUIMan = require "GUI.ECGUIMan"
		local num = ECGUIMan.Instance():GetShowPopupRewardPanelNum()
		if type == 3 and num > 0 then
			local ECGeneralCostUtility = require "Utility.ECGeneralCostUtility"
			local itemTid = ECGeneralCostUtility.GetCostShowItemTid({type=CONSTANT_DEFINE.COMMON_COST_TYPE.CTT_DIAMOND_BIND,tid=0})
			local ECRewardHandle = require "Utility.ECRewardHandle"
			ECRewardHandle.Instance():HandleIncItemTip(0 , 0 , itemTid , msg.bind_value, "bind_cash")
		end

		local p = NotifyMoneyChange()
		p.add = msg.change_type == 2 or msg.change_type == 3
		p.inc = tostring(msg.bind_value)
		--p.money_type = GP_MONEY_TYPE.GPMONEYTYPE_BIND
	   	ECGame.EventManager:raiseEvent(nil, p)
	end

	if msg.unbind_value ~= 0 then
		local chatIndex = 0
		local descIndex = 0
		if type == 1 then --使用
			chatIndex = 517
		    descIndex = 100037
		elseif type == 2 then --退还
			chatIndex = 518
			descIndex = 100038
		elseif type == 3 then --赠送
			chatIndex = 519
			descIndex = 100039
		end

		local p = NotifyMoneyChange()
		p.add = msg.change_type == 2 or msg.change_type == 3
		p.inc = tostring(msg.unbind_value)
		--p.money_type = GP_MONEY_TYPE.GPMONEYTYPE_TRADE
	   	ECGame.EventManager:raiseEvent(nil, p)

		FlashTipMan.FlashRegionTip(StringTable.Get(descIndex):format(msg.unbind_value))

	   	local ECChatHandle = require "Chat.ECChatHandle"
		local ECChatUtility = require "Chat.ECChatUtility"
		local ECChatManager = require "Chat.ECChatManager"
		local str = StringTable.Get(chatIndex):format(msg.unbind_value)
		local richStr =  ECChatUtility.GenerateRichText(str,nil)
		richStr = ECChatHandle.Instance():MakeMoneyImg("inc_cash_0" , 32 , -6) .. richStr
		local ECMsgInfo = require "Chat.ECMsgInfo"
		ECChatManager.Instance():AddSimpleMessageWithType(str, richStr, _G.CONSTANT_DEFINE.CHAT_CHANNEL_ENUM.CHAT_CHANNEL_SYSTEM, ECMsgInfo.MSG_TYPE.SYSTEM, "")
		if type ~= 3 then
			FlashTipMan.FlashTip(str)
		end

		local ECGUIMan = require "GUI.ECGUIMan"
		local num = ECGUIMan.Instance():GetShowPopupRewardPanelNum()
		if type == 3 and num > 0 then
			local ECGeneralCostUtility = require "Utility.ECGeneralCostUtility"
			local itemTid = ECGeneralCostUtility.GetCostShowItemTid({type=CONSTANT_DEFINE.COMMON_COST_TYPE.CTT_DIAMOND_UNBIND,tid=0})
			local ECRewardHandle = require "Utility.ECRewardHandle"
			ECRewardHandle.Instance():HandleIncItemTip(0 , 0 , itemTid , msg.unbind_value, "unbind_cash")
		end
	end	
	
end

pb_helper.AddHandler("gp_notify_cash_change", on_notify_cash_change)