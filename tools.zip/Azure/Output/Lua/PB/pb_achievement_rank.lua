local pb_helper = require "PB.pb_helper"

local function on_gp_achievement_rank(sender, msg)
	local ECProfessionAchievementData = require("Data.ECProfessionAchievementData").ECProfessionAchievementData
	local professionAchievementData = ECProfessionAchievementData.Instance()
	local changeList = {}
	for achievementID , rank in pairs(msg.data.achieve_rank_map)do
		table.insert(changeList , achievementID)
		local info = professionAchievementData:GetAchievementInfoByAchievementID(achievementID)
		if(info ~= nil)then
			info._rank = rank
			--warn("********* on_gp_achievement_rank" , info._name , rank)
		end
	end

	local AchievementRankChangedEvent = require("Event.PlayerTitleUpdateEvent").AchievementRankChangedEvent
	local event = AchievementRankChangedEvent()
	event.ChangList = changeList
	require "Main.ECGame".EventManager:raiseEvent(nil, event)
end
pb_helper.AddHandler("gp_achievement_rank", on_gp_achievement_rank)