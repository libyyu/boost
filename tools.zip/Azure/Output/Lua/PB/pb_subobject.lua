---
---@author chenshilei
---@date 2019/8/16 15:36
---@description 处理子物体协议
---

local pb_helper = require "PB.pb_helper"
local ECGame = require "Main.ECGame"
local EC = require "Types.Vector3"

---@param msg pb.Message.PB.gp_subobject_stop_move
local function on_subobject_stop_move (sender, msg)
    if msg then
        local subObjMan = ECGame.Instance():GetSubObjectMan()
        if subObjMan then
            local subObj = subObjMan:GetObj(msg.subobject_id)
            subObj:MoveTo(EC.Vector3.clone(msg.stop_pos), subObj:GetInitSpeed(), 0.5)
        end
    end
end
pb_helper.AddHandler("gp_subobject_stop_move", on_subobject_stop_move)


---@param msg pb.Message.PB.gp_subobject_change_moving_type
local function on_subobject_change_moving_type (sender, msg)
    if msg then
        local subObjMan = ECGame.Instance():GetSubObjectMan()
        if subObjMan then
            local subObj = subObjMan:GetObj(msg.subobject_id)
            if subObj then
                subObj:changeMoveType(msg)
            end
        end
    end
end
pb_helper.AddHandler("gp_subobject_change_moving_type", on_subobject_change_moving_type)