local Lplus = require "Lplus"

local pb_helper = require "PB.pb_helper"

local function on_nation_shutup_info(sender, msg)
	--print("on_nation_shutup_info",msg)
	local ECGame = require "Main.ECGame"
	local ECChatManager = require "Chat.ECChatManager"
	ECChatManager.Instance().NationShutupInfo = {use_times=msg.use_times,remain_times=msg.remain_times}
	local NationShutupInfoEvt = require "Event.NationShutupInfoEvt"
	ECGame.EventManager:raiseEvent(nil, NationShutupInfoEvt.new(msg,false))
end

pb_helper.AddHandler("npt_nation_shutup_info", on_nation_shutup_info)

--禁言反馈
local function on_nation_shutup_reply(sender,msg)
	--print("on_nation_shutup_reply",msg)
	local ECGame = require "Main.ECGame"
	local NationShutupInfoEvt = require "Event.NationShutupInfoEvt"
	ECGame.EventManager:raiseEvent(nil, NationShutupInfoEvt.new(msg,true))
end

pb_helper.AddHandler("npt_nation_shutup_reply", on_nation_shutup_reply)