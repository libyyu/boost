
local pb_helper = require "PB.pb_helper"

local function on_weak_nation_gift(sender, msg)
	--print("on_weak_nation_gift--弱国奖励",msg)
	local ECNationMan = require "Social.ECNationMan"
	ECNationMan.Instance().mWeakNationGiftId = msg.gift_id
	local ECGame = require "Main.ECGame"
	local WeakNationGiftEvt = require "Event.WeakNationGiftEvt"
	ECGame.EventManager:raiseEvent(nil, WeakNationGiftEvt.new(msg.gift_id))
end

--pb_helper.AddHandler("npt_weak_nation_gift_notify", on_weak_nation_gift)