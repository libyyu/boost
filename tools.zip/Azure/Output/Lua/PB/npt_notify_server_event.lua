local pb_helper = require "PB.pb_helper"
local ECGame = require "Main.ECGame"

---@param msg pb.Message.PB.npt_notify_server_event
local function on_npt_notify_server_event(sender, msg)
    warn(("on_npt_notify_server_event msg=[%s] "):format(tostring(msg)))
    if msg.event_type == 0 then -- 服务器宕线
        local line = msg.event_param_int
        ECGame.Instance():OnServerLoseLine(line)
    end
end

pb_helper.AddHandler("npt_notify_server_event", on_npt_notify_server_event)