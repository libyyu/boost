local pb_helper = require "PB.pb_helper"

_G.DrawDebugPath = function(path_id, point_list)

    local DURATION = 30
    local count = 0
    local points = {}
    local AdjustPosH = function(pt)
        pt.y = pt.y - 0.5
        local fGndHei , bFound = _G.GetSupportPlaneHeightEnsured(pt , 2, nil)
        if bFound then
            pt.y = fGndHei + 0.1
        end
    end

    for idx , pt in ipairs(point_list) do
        local p = {x=pt.x , y=pt.y , z=pt.z}
        AdjustPosH(p)
        table.insert(points, p)
        count = count + 1
        --warn(("[%d]\t= (%s) "):format(idx,tostring_pt(coordination)))
    end
    warn("path_id = ", path_id)
    warn("count = ",count)
    GameUtil.DrawDebugDirectionalArrow(points[1], {x=points[1].x,y=points[1].y+2,z=points[1].z},0.1, _G.ColorYellow, DURATION)
    for idx = 2, count do
        local pt1 = points[idx - 1]
        local pt2 = points[idx]
        GameUtil.DrawDebugLine(pt1, pt2, _G.ColorRed, DURATION)
        GameUtil.DrawDebugDirectionalArrow(pt2, {x=pt2.x,y=pt2.y + 1,z=pt2.z},0.1, _G.ColorPurple, DURATION)
    end

end

local function on_gp_path_info(sender, msg)
    -- 这是个调试用的协议
    -- 服务器发来的路径点
    -- 在客户端画出来 参考
    -- c 2936 pathid
    
    -- int32 path_id = 1;
    -- repeated a3d_pos point_list = 2;
    DrawDebugPath(msg.path_id , msg.point_list)
end
pb_helper.AddHandler("gp_path_info", on_gp_path_info)