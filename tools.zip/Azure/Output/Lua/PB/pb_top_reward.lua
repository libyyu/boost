
--2015年9月17日
--Wang Yinliang
--
-- 限时排行奖励
-- npt_top_reward
-- 
local pb_helper = require "PB.pb_helper"
local ECGame = require "Main.ECGame"
--local TopRewardEvent = require "Event.TopRewardEvent"


--[[
message npt_top_reward
{
	optional NET_PROTOCBUF_TYPE type	= 1	[ default = NPT_TOP_REWARD ];
	message player
	{
		optional int64 roleid	= 1;
		optional bytes	name	= 2;
	}
	repeated player players			= 2;
	optional int32 self_rank		= 3;
	optional bool has_reward		= 4;
	optional int32 activity_end_time	= 5;	//活动结束时间
	optional bool get_reward		= 6;	//input 领奖
	optional int32 tid			= 7;
}

--]]

local function on_top_reward( sender,msg )
	--warn("npt_top_reward msg.tid ", msg.tid)

	local TopRewardMan = require "Social.ECTopRewardMan"
	TopRewardMan.Instance():SetTopRewardInfo( msg )

	-- local event = TopRewardEvent()
	-- event.tidType = msg.tid
	-- ECGame.EventManager:raiseEvent(nil, event)

end

pb_helper.AddHandler("npt_top_reward", on_top_reward)
