local Lplus = require "Lplus"
local pb_helper = require "PB.pb_helper"

local function on_get_tp_addon_result(sender,msg )
	local ECPanelRanklist = require "GUI.ECPanelRanklist"
	ECPanelRanklist.Instance():PopupInteractive(msg)
end

pb_helper.AddHandler("npt_get_tp_addon_result", on_get_tp_addon_result)