--2019年7月12日
--Wang Yinliang
--
local Lplus = require "Lplus"
local pb_helper = require "PB.pb_helper"

--[[
message addon_data_t
{
	int32  tid     = 1;    //属性模板id，对应addon_data.addonid，属性模板，指定了该条属性属性值的上下限
	int32  value    = 2;    //随机属性对应的属性值，由这个rand值以及tid指定的模板给出的上下线计算该条属性的生效数值
	int32  type    = 3;    //该条随机属性对应的属性类型，对应addon_data.id，指定该属性是加血，加攻击，还是其他的属性类型
	int32  extra_value   = 4 [(Default)=0];    //随机属性对应的属性值，由这个rand值以及tid指定的模板给出的上下线计算该条属性的生效数值
}
message addon_group_t
{
	int32 addon_group_id	=1;
	repeated addon_data_t basic_addon_data		= 3;    //基础附加属性，与代码中addon_group_data兼容，要么size为0，要么为EXP_ADDONGRP_BASIC_COUNT
	repeated addon_data_t random_addon_data  	= 4;    //随机附加属性
	bool active				=5[(DefaultBool) =false ];//active
}

message gp_suit_info{
	option (s2c_type) = type_gp_suit_info;
	message SuitInfo
	{
		int32 suit_id					=1;
		int32 match_count				=2;//第几个
		repeated addon_group_t  addons	=3;//每一套的属性 
	}
	bool data_loaded	=2 [(DefaultBool)=false];
	repeated SuitInfo suits			=3;
}
message gp_suit_info{
	option (s2c_type) = type_gp_suit_info;
	message SuitInfo
	{
		int32 suit_id					=1;
		int32 match_count				=2;//第几个
		repeated addon_group_t  addons	=3;//每一套的属性 
	}
	bool  update_equipsuit				=2 [(DefaultBool)=false];//是否更新装备好的套装信息
	repeated SuitInfo suits				=3;
	repeated SuitInfo pocket_suits		=4;
}

--]]

local function on_suit_info(sender, msg)
	--print_wyl("gp_suit_info", #msg.suits)

	local ECEquipSuitMan = require "Main.ECEquipSuitMan"
	ECEquipSuitMan.Instance():onSuitInfo(msg)
end

pb_helper.AddHandler("gp_suit_info", on_suit_info)
