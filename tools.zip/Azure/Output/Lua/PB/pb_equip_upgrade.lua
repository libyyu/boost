local Lplus = require "Lplus"
local pb_helper = require "PB.pb_helper"
---@type ECGame
local ECGame = Lplus.ForwardDeclare("ECGame")
local EquipUpgradeEvent = require "Event.EquipUpgradeEvent"

local function on_equip_upgrade_result(sender, msg)
    local event = EquipUpgradeEvent()
    event.result = msg
    ECGame.EventManager:raiseEvent(nil, event)
end
pb_helper.AddHandler("gp_equip_upgrade_result", on_equip_upgrade_result)


pb_helper.AddHandler("gp_equip_enchant_level_res", function(_, msg)
    local GrooveMan = require "Data.GrooveDataMan"
    GrooveMan.Instance():OnUpdateEquipEnchantLevel(msg.mask, msg.cur_level)
end)

pb_helper.AddHandler("gp_equip_enchant_level_notify", function(_, msg)
    local GrooveMan = require "Data.GrooveDataMan"
    GrooveMan.Instance():OnInitEquipEnchantLevel(msg)
end)