
--2015年3月30日
--Wang Yinliang
--
-- 副本挑战结果：组队副本
-- gp_level_score
-- 
local pb_helper = require "PB.pb_helper"

--[[
	message gp_level_score {
		optional S2C_GS_PROTOC_TYPE type                = 1 [ default = type_gp_level_score];
		optional int32 score                            = 2 [ default = -1];//分数负代表失败
	}
--]]

local function on_level_score( sender,msg )
	print("======= gp_level_score", msg.score)
	--[[
	if msg.score >= 0 then

		local ECMausoleumMan = require "Social.ECMausoleumMan"
		local MausoleumMan = ECMausoleumMan.Instance()

		MausoleumMan.m_AddScore = msg.score - MausoleumMan.m_AllScore
		MausoleumMan.m_AllScore = msg.score

		if MausoleumMan.m_AddScore > 1 then
			HUDMan.ShowReciveScore(MausoleumMan.m_AddScore)
		end

		local ECPanelMausoleumScore = require "GUI.ECPanelMausoleumScore"
		ECPanelMausoleumScore.Instance():UpdataScore()
	end]]
end

pb_helper.AddHandler("gp_level_score", on_level_score)
