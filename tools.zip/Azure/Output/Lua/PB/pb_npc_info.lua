
--2015年6月1日
--Wang Yinliang
--
-- 副本挑战冷却：npc受保护
-- gp_npc_info
-- 
local Lplus = require "Lplus"
---@type ECGame
local ECGame = Lplus.ForwardDeclare("ECGame")
local pb_helper = require "PB.pb_helper"

--[[
	message gp_npc_info {
	optional S2C_GS_PROTOC_TYPE type		= 1 [ default = type_gp_npc_info ];
	optional uint32 newtype				= 2;
	optional bool can_be_attacked			= 3;
}
--]]

---@param msg pb.Message.PB.gp_npc_info
local function on_npc_info( sender,msg )
	--warn("gp_npc_info")

	local ECNPC = require "NPCs.ECNPC"
	local newid = msg.newtype
	local isprotected = not msg.can_be_attacked
	local id = GetOldID(newid)

	local world = ECGame.Instance().m_CurWorld
	local target = world:FindObject(id)
	if target and target:is(ECNPC) then
		target:setActive(not isprotected)
	end

end

pb_helper.AddHandler("gp_npc_info", on_npc_info)

--[[
	投石车信息
]]
local function on_gp_npc_thrower_info(sender, msg)
	local npc =  ECGame.Instance().m_CurWorld.m_NPCMan:GetNPC(msg.npcid)
	if npc then
		local master_name = GameUtil.UnicodeToUtf8(msg.master_name)
		npc:SetThrowerInfo(msg.state, msg.master_id, master_name)
	end
end

pb_helper.AddHandler("gp_npc_thrower_info", on_gp_npc_thrower_info)


--[[
	箭塔信息
]]

local function on_npc_arrow_tower_info(sender, msg)
	local npc =  ECGame.Instance().m_CurWorld.m_NPCMan:GetNPC(msg.npcid)
	if npc then
		local master_name = GameUtil.UnicodeToUtf8(msg.master_name)
		npc:SetArrowTowerInfo(msg.mount, msg.master_id, master_name)
	end
end

pb_helper.AddHandler("gp_npc_arrow_tower_info", on_npc_arrow_tower_info)


local function on_gp_npc_phalanx_data(sender, msg)
	for i,info in ipairs(msg.info) do
		if info then
			local npc =  ECGame.Instance().m_CurWorld.m_NPCMan:GetNPC(GetOldID(info.newid))
			if npc then
				npc.phalanx_tid = info.tid
				npc.phalanx_seq = info.seq
			else
			end
		end
	end
end

--pb_helper.AddHandler("gp_npc_phalanx_data", on_gp_npc_phalanx_data)

local function on_gp_npc_transform_state(sender, msg)
	local npc =  ECGame.Instance().m_CurWorld.m_NPCMan:GetNPC(msg.roleid)
	if npc then
		npc:AddModelRealLoadedCallback(function ()
			npc:OnObjectTransform(msg.transform_id)
		end)
	end
end
pb_helper.AddHandler("gp_npc_transform_state", on_gp_npc_transform_state)
