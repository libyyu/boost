--卡牌

--
-- gp_card_data_notify
-- 
local pb_helper = require "PB.pb_helper"
local ECGame = require "Main.ECGame"

--[[
enum N_TYPE{
		N_TYPE_SYNCALL	= 	1;
		N_TYPE_ADDCARD	= 	2;
		N_TYPE_ACTIVESUIT = 	3;
		N_TYPE_DECOMPOSE  =	4;
	}
--]]

--[=[
local function on_card_data_notify( sender,msg )
	local ECCards = require "Players.ECCards"
	local cardsInfo = ECCards.Instance()
	if msg.notify_type == 1 then
		cardsInfo:Clear()
		for i=1,#msg.cards do
			cardsInfo.cards[msg.cards[i].card_id] = msg.cards[i].card_count
		end
		for i=1,#msg.card_suits do
			cardsInfo.cardSuits[msg.card_suits[i]] = 1
		end
	elseif msg.notify_type == 2 then

		--local ECPanelCardGet = require "GUI.ECPanelCardGet"

		--	如果发现需要延迟提示，则加入到延迟提示信息里
		--[[
		if #msg.cards == 1 then
			local id = msg.cards[1].card_id
			if id == cardsInfo.carddelayshowid then
				cardsInfo:AddDelayNotifyMsg(msg)
				return
			end
		end
		]]

		for i=1,#msg.cards do
			local id = msg.cards[i].card_id
			local count = msg.cards[i].card_count
			if cardsInfo.cards[id] then
				cardsInfo.cards[id] = cardsInfo.cards[id] + count
			else
				cardsInfo.cards[id] = count
			end
			
			if id ~= cardsInfo.carddelayshowid then
				--ECPanelCardGet.Instance():GetCard(id)
			else
				cardsInfo.carddelayshowid = 0
			end
		end
		local NotifyCard = require "Event.NotifyCard"
		local p = NotifyCard()
		p.result = msg
		ECGame.EventManager:raiseEvent(nil, p)
	elseif msg.notify_type == 3 then
		local idSuit = msg.card_suits[1]
		cardsInfo.cardSuits[idSuit] = 1
		for i=1,#msg.cards do
			cardsInfo.cards[msg.cards[i].card_id] = cardsInfo.cards[msg.cards[i].card_id] - msg.cards[i].card_count
			if cardsInfo.cards[msg.cards[i].card_id]<=0 then
				cardsInfo.cards[msg.cards[i].card_id] = nil
			end
		end
		--local ECPanelCard = require "GUI.ECPanelCard"
		--ECPanelCard.Instance():ActiveSuit(idSuit)
		local NotifyCard = require "Event.NotifyCard"
		local p = NotifyCard()
		p.result = msg
		ECGame.EventManager:raiseEvent(nil, p)
	elseif msg.notify_type == 4 then
		for i=1,#msg.cards do
			cardsInfo.cards[msg.cards[i].card_id] = cardsInfo.cards[msg.cards[i].card_id] - msg.cards[i].card_count
			if cardsInfo.cards[msg.cards[i].card_id]<=0 then
				cardsInfo.cards[msg.cards[i].card_id] = nil
			end
		end
		local NotifyCard = require "Event.NotifyCard"
		local p = NotifyCard()
		p.result = msg
		ECGame.EventManager:raiseEvent(nil, p)
	end
end

pb_helper.AddHandler("gp_card_data_notify", on_card_data_notify)
-]=]

