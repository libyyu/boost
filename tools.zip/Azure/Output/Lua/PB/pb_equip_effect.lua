local Lplus = require "Lplus"
local pb_helper = require "PB.pb_helper"
---@type ECGame
local ECGame = Lplus.ForwardDeclare("ECGame")

-- local function OnEquipEffectResponse(sender, msg)
-- 	do--暂时屏蔽
-- 		return
-- 	end
-- 	local ECPanelStarUpSuit = require "GUI.ECPanelStarUpSuit"
-- 	ECPanelStarUpSuit.Instance():ChangeEffect(msg.curr_texiao_id + 1)

-- 	local hostPlayer = ECGame.Instance().m_HostPlayer
-- 	if not hostPlayer then return end
-- 	hostPlayer.selectEquipEffectIndex = msg.curr_texiao_id + 1

-- 	local ECPanelStarUpPage = require "GUI.ECPanelStarUpPage"
-- 	ECPanelStarUpPage.Instance():UpdateEquipEffect()

-- 	local ECSubPanelInventoryEquip = require "GUI.ECSubPanelInventoryEquip"
-- 	ECSubPanelInventoryEquip.Instance():UpdateEquipEffect()
-- end
-- pb_helper.AddHandler("gp_suit_addon_texiao_id", OnEquipEffectResponse)