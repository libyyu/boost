--
-- gp_s2c_gs_ping
-- 
local pb_helper = require "PB.pb_helper"

local function on_gp_s2c_gs_ping( sender,msg )
	local ECGameDebug = require "Main.ECGameDebug"
	local gamedebug = ECGameDebug.Instance()
	if msg.client_send_time == gamedebug.mLastCheckTime then
		local cur_time = math.fmod( math.floor(GameUtil.GetMillisecondsFromEpoch()), 60000)
		gamedebug.mClientLastTTL = cur_time - msg.client_send_time
		if gamedebug.mClientLastTTL < 0 then gamedebug.mClientLastTTL = gamedebug.mClientLastTTL + 60000 end
		--warn("GS delay :", gamedebug.mClientLastTTL)
	end
end

pb_helper.AddHandler("gp_s2c_gs_ping",on_gp_s2c_gs_ping)
