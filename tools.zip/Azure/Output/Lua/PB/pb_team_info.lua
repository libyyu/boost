local pb_helper = require "PB.pb_helper"
local ECGame = require "Main.ECGame"

local function on_get_amity_max_result( sender,msg)
	local TeamAmityMax = require "Event.TeamAmityEvent".TeamAmityMax
	local event = TeamAmityMax.new(msg.utype,msg.amity_max)
	ECGame.EventManager:raiseEvent(nil, event)
end

pb_helper.AddHandler("npt_get_amity_max_result", on_get_amity_max_result)