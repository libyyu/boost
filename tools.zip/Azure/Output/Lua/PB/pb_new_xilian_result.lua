
local Lplus = require "Lplus"
local ECGame = require "Main.ECGame"
local pb_helper = require "PB.pb_helper"
local EquipClearEvent = require "Event.EquipClearEvent"

local function on_new_xilian_result(sender, msg)
	local event = EquipClearEvent()
	event.result = msg
	ECGame.EventManager:raiseEvent(nil, event)
end

pb_helper.AddHandler("gp_new_xilian_result", on_new_xilian_result)
