--
--客户端使用工具动作
--	
local Lplus = require "Lplus"
local pb_helper = require "PB.pb_helper"
---@type ECGame
local ECGame = Lplus.ForwardDeclare("ECGame")

--[[
message gp_broadcast_client_use_action_re {
    option (s2c_type) = type_gp_broadcast_client_use_action;
    client_use_action client_action = 2;
    int32 retcode = 3;
}
--]]

local function on_broadcast_client_use_action_re (sender, msg)
	--print_wyl("gp_broadcast_client_use_action_re--------retcode----------", msg.retcode, msg.client_action.act_type)
	local ERROR_CODE = require "PB.error_code".ERROR_CODE
	if msg.retcode == ERROR_CODE.OPERATION_LIMITED then --挖坑已到限制次数
		return
	end

	local who = msg.client_action.role_id
	local tool_type = msg.client_action.tools_type
	local act_type = msg.client_action.act_type
	g_WorldUnwrapPosVec(msg.client_action.pos)
	local pos = _G.A3dPosToVector3(msg.client_action.pos)

	--print_wyl("gp_broadcast_client_use_action_re--------msg----------", act_type, tool_type, pos.x, pos.y, pos.z)

	local hp = ECGame.Instance().m_HostPlayer
	local world = ECGame.Instance().m_CurWorld
	local target = nil
	if who == hp.ID then
		target = hp
	else
		local playerman = world.m_PlayerMan
		target = playerman:GetElsePlayer(who)
	end
	if target == nil then
		return
	end

	if act_type == _G.CONSTANT_DEFINE.CLIENT_USE_ACTION_TYPE.CLIENT_USE_ACT_DIG then --挖
		--使用工具
		if true then
			local FSMPlayerUseToolAction = require "FSM.PlayerFSM.FSMPlayerUseToolAction"
			local interact = FSMPlayerUseToolAction.new(target, tool_type, pos)
			target:ChangeState(interact)
		end

	elseif act_type == _G.CONSTANT_DEFINE.CLIENT_USE_ACTION_TYPE.CLIENT_USE_ACT_PIT then --坑
		globalGame.m_CurWorld.m_PitMan:CreatePit(msg.client_action)
	end

end

pb_helper.AddHandler("gp_broadcast_client_use_action_re", on_broadcast_client_use_action_re)