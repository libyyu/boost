
local Lplus = require "Lplus"
local pb_helper = require "PB.pb_helper"
---@type ECGame
local ECGame = Lplus.ForwardDeclare("ECGame")
local ECFxMan = require "Fx.ECFxMan"
local EC = require "Types.Vector3"
---@type ECChatManager
local ECChatManager = Lplus.ForwardDeclare("ECChatManager")
local CHAT_CHANNEL_ENUM = _G.CONSTANT_DEFINE.CHAT_CHANNEL_ENUM

local function GetPlayer(roleid)
	local player = ECGame.Instance():FindObjectOrHost(roleid)
	return player
end

local invite_list = {}
local duelinvite_man = {}

duelinvite_man.next_invite = function()
	table.remove(invite_list,1)
	local validindex = 0
	for i,j in ipairs(invite_list) do
		local lefttime = 30 - (GameUtil.GetServerGMTTime() - j.time)
		if lefttime > 0 then
			validindex = i
			duelinvite_man.process_duel_invite(j)
			break
		end
	end
	if validindex > 0 then
		for i = 1,validindex - 1 do
			table.remove(invite_list,1)
		end
	else
		invite_list = {}
	end
end

------------------------切磋邀请
duelinvite_man.process_duel_invite = function( oneInvite )
	--warn("---------------on_duel_invite:",msg)
	local msg = oneInvite.msg

	local playername = StringTable.Get(2907)
	local playerlevel = 0
	local player = GetPlayer(msg.player_id)
	if player then
		playername = player.InfoData.Name
		playerlevel = player.InfoData.Lv
	end
	local lefttime = 30 - (GameUtil.GetServerGMTTime() - oneInvite.time)
	MsgBox.ShowMsgBox(nil,string.format(StringTable.Get(2906),playername,playerlevel,lefttime),nil,MsgBox.MsgBoxType.MBBT_OKCANCEL,function(sender,ret)
		local pb_helper = require "PB.pb_helper"
		local client_msg = require "PB.client_msg"
		local gp_duel_invite_reply_c = client_msg.gp_duel_invite_reply_c
		local msg_re = gp_duel_invite_reply_c()
		msg_re.player_id = msg.player_id

		if MsgBox.MsgBoxRetT.MBRT_OK == ret then
			--接受切磋
			msg_re.reply = 0
		else
			--拒绝切磋
			msg_re.reply = 1
		end
		pb_helper.Send(msg_re)

		--warn("--------------on_duel_invite:",msg_re)
		if MsgBox.MsgBoxRetT.MBRT_OK == ret then
			invite_list = {}
		else
			duelinvite_man.next_invite()
		end
	end,
	lefttime,function (thebox)
		thebox.content = string.format(StringTable.Get(2906),playername,playerlevel,thebox.LifeTime)
		thebox:UpdateUI()
		if thebox.LifeTime < 1 then
			duelinvite_man.next_invite()
			thebox:DestroyPanel()
		end
	end)
end

local function on_duel_invite(sender,msg)
	local oneInvite = {}
	oneInvite.msg = msg
	oneInvite.time = GameUtil.GetServerGMTTime()
	table.insert(invite_list,oneInvite)
	if #invite_list == 1 then
		duelinvite_man.process_duel_invite(oneInvite)
	end
end

pb_helper.AddHandler("gp_duel_invite",on_duel_invite)


-------------切磋回复
local function on_duel_invite_reply(sender,msg )
	--warn("-----------------on_duel_invite_reply:",msg)
	local playername = require "Common.GameBriefInfoCacheMan".Instance():FindNameCache(msg.player_id)
	if playername == "" then
		playername = StringTable.Get(2907)
	end

	local strInfo = ""
	if msg.reply == 0 then --0 同意 1 拒绝 2 超时 3 距离太远 4 状态不对 5 对方对决中
		
	elseif msg.reply == 1 then
		strInfo = string.format(StringTable.Get(2910),playername)
		
		--ECChatManager.Instance():AddSimpleMessage(strInfo,CHAT_CHANNEL_ENUM.CHAT_CHANNEL_SYSTEM)
	elseif msg.reply == 2 then
		strInfo = string.format(StringTable.Get(2911),playername)
		
		--ECChatManager.Instance():AddSimpleMessage(strInfo,CHAT_CHANNEL_ENUM.CHAT_CHANNEL_SYSTEM)		
	elseif msg.reply == 3 then
		strInfo = StringTable.Get(2905)
		
		--ECChatManager.Instance():AddSimpleMessage(strInfo,CHAT_CHANNEL_ENUM.CHAT_CHANNEL_SYSTEM)	
	elseif msg.reply == 4 then
		strInfo = StringTable.Get(2916)
	elseif msg.reply == 5 then
		strInfo = StringTable.Get(2924)
	end
	FlashTipMan.FlashTip(strInfo)
end

pb_helper.AddHandler("gp_duel_invite_reply",on_duel_invite_reply)

-------------切磋准备
local function on_duel_prepare(sender,msg )
	--warn("----------------on_duel_prepare:",msg)
	local hp = ECGame.Instance().m_HostPlayer
	if not hp then return end

	local duelInfo = hp.m_DuelInfo
	if not duelInfo then return end

	duelInfo.duel_state = _G.CONSTANT_DEFINE.DUELSTATE_ENUM.DUEL_ST_PREPARE
	duelInfo.duel_time_count = msg.delay
	duelInfo.duel_result = _G.CONSTANT_DEFINE.DUELRES_ENUM.DUELRES_UNDEFINED

    local ECPanelPK = require "GUI.ECPanelPK"
    ECPanelPK.Instance():PopUp(1,msg.delay)
end

pb_helper.AddHandler("gp_duel_prepare",on_duel_prepare)

-----------切磋取消
local function on_duel_invite_cancel(sender,msg )
	--warn("----------------on_duel_invite_cancel:",msg)
	local hp = ECGame.Instance().m_HostPlayer
	if not hp then return end

	local duelInfo = hp.m_DuelInfo
	if not duelInfo then return end

	duelInfo:Reset()
end

pb_helper.AddHandler("gp_duel_cancel",on_duel_invite_cancel)


-----------重连同步duel信息
local function on_gp_duel_info(sender,msg )
	warn("----------------on_gp_duel_info:",msg)
	local hp = ECGame.Instance().m_HostPlayer
	if not hp then return end
	local duelInfo = hp.m_DuelInfo
	duelInfo:Reset()
	duelInfo.duel_state = msg.duel_mode
	duelInfo.duel_opp = msg.duel_target
	hp:UpdatePateNameColor()

	local target = GetPlayer(msg.duel_target)
	if target then
		local targetDuelInfo = target.m_DuelInfo
		targetDuelInfo:Reset()
		targetDuelInfo.duel_state = msg.duel_mode
		targetDuelInfo.duel_opp = hp.ID
		target:UpdatePateNameColor()
	end
	local ECPanelPK = require "GUI.ECPanelPK"
	if msg.duel_mode == _G.CONSTANT_DEFINE.DUELSTATE_ENUM.DUEL_ST_PREPARE then
   		ECPanelPK.Instance():PopUp(1,msg.duel_timeout)
	elseif msg.duel_mode == _G.CONSTANT_DEFINE.DUELSTATE_ENUM.DUEL_ST_INDUEL then
		ECPanelPK.Instance():PopUp(2,msg.duel_timeout)
		ECFxMan.Instance():PlayDuelFx(true,msg.flag_pos)
	end

	local NotifyPropEvent = require "Event.NotifyPropEvent"
	local event = NotifyPropEvent()
	event.obj_id = msg.duel_target
	ECGame.EventManager:raiseEvent(nil, event)
end

pb_helper.AddHandler("gp_duel_info",on_gp_duel_info)

-----------切磋开始
local function on_duel_invite_start(sender,msg )
	warn("----------------on_duel_invite_start2:",msg)
	local player = GetPlayer(msg.player_id)
	if player then
		local duelInfo = player.m_DuelInfo
		duelInfo:Reset()
		duelInfo.duel_state = _G.CONSTANT_DEFINE.DUELSTATE_ENUM.DUEL_ST_INDUEL
		duelInfo.duel_opp = msg.target_id
		--print(LuaInt64.ToString(msg.target_id))
		--warn("-----------------------更新目标玩家头顶颜色")
		player:UpdatePateNameColor()

		--if msg.duel_type == 1 then  
			--婚礼场景 更新目标决斗状态 并显示红名
			local target = GetPlayer(msg.target_id)
			if target then
				local targetDuelInfo = target.m_DuelInfo
				targetDuelInfo:Reset()
				targetDuelInfo.duel_state = _G.CONSTANT_DEFINE.DUELSTATE_ENUM.DUEL_ST_INDUEL
				targetDuelInfo.duel_opp = msg.player_id
				target:UpdatePateNameColor()
			end
		--end

		local ECPanelPK = require "GUI.ECPanelPK"
    	ECPanelPK.Instance():PopUp(2,10 * 60)

    	ECFxMan.Instance():PlayDuelFx(true,msg.flag_pos)

    	local NotifyPropEvent = require "Event.NotifyPropEvent"
		local event = NotifyPropEvent()
		event.obj_id = msg.target_id
		ECGame.EventManager:raiseEvent(nil, event)
	end
end

pb_helper.AddHandler("gp_duel_start",on_duel_invite_start)

-----------切磋结束
local function on_duel_invite_stop(sender,msg )
	--warn("----------------on_duel_invite_stop:",msg,LuaInt64.ToString(msg.player_id),LuaInt64.ToString(msg.target_id))
	local player = GetPlayer(msg.player_id)
	if player then
		local duelInfo = player.m_DuelInfo
		--[[if player._isHost then
			duelInfo.duel_state = _G.CONSTANT_DEFINE.DUELSTATE_ENUM.DUEL_ST_STOPPING
			duelInfo.duel_time_count = 3
			--播放结束特效 TODO 
		else
			duelInfo.duel_state = _G.CONSTANT_DEFINE.DUELSTATE_ENUM.DUEL_ST_NONE
		end]]
		duelInfo.duel_state = _G.CONSTANT_DEFINE.DUELSTATE_ENUM.DUEL_ST_NONE

		player:UpdatePateNameColor()
	end


	local target = GetPlayer(msg.target_id)
	if target then
		local duelInfo = target.m_DuelInfo
		duelInfo.duel_state = _G.CONSTANT_DEFINE.DUELSTATE_ENUM.DUEL_ST_NONE

		target:UpdatePateNameColor()
	end

	ECFxMan.Instance():PlayDuelFx(false,EC.Vector3.zero)
	local ECPanelPK = require "GUI.ECPanelPK"
	if ECPanelPK.Instance().m_panel and ECPanelPK.Instance().m_Stage == 2 then
		ECPanelPK.Instance():DestroyPanel()
	end
	local NotifyPropEvent = require "Event.NotifyPropEvent"
	local event = NotifyPropEvent()
	event.obj_id = msg.target_id
	ECGame.EventManager:raiseEvent(nil, event)
end

pb_helper.AddHandler("gp_duel_stop",on_duel_invite_stop)

-----------切磋结果
local function on_duel_result(sender,msg )
	--warn("----------------on_duel_result:",msg)
	local hp = ECGame.Instance().m_HostPlayer
	if not hp then return end

	local name1 = GameUtil.UnicodeToUtf8(msg.name1)
	local name2 = GameUtil.UnicodeToUtf8(msg.name2)

	local strInfo = ""
	local isWinner = false
	local isRelated = hp.ID == msg.id1 or hp.ID == msg.id2

	if msg.result == 2 then
		strInfo = string.format(StringTable.Get(2915),name1,name2)
	elseif msg.result == 1 then
		strInfo = string.format(StringTable.Get(2912),name2,name1)
		isWinner = hp.ID == msg.id2
	elseif msg.result == 0 then
		strInfo = string.format(StringTable.Get(2912),name1,name2)
		isWinner = hp.ID == msg.id1
	end
	if isRelated then
		local ECPanelPK = require "GUI.ECPanelPK"
	    ECPanelPK.Instance():PopUp(3,msg.result == 2 and 2 or (isWinner and 0 or 1))
	end

	ECChatManager.Instance():AddSimpleMessage(strInfo,CHAT_CHANNEL_ENUM.CHAT_CHANNEL_LOCAL)
end

pb_helper.AddHandler("gp_duel_result",on_duel_result)

-----------切磋超出范围

local function OnOutOfRange()

	local hp = ECGame.Instance().m_HostPlayer
	if not hp then return end

	local duelInfo = hp.m_DuelInfo
	if not duelInfo then return end

	if duelInfo.range_count_down <= 0 then return end
	FlashTipMan.FlashTip(StringTable.Get(2908):format(duelInfo.range_count_down))
	duelInfo.range_count_down = duelInfo.range_count_down -1

	GameUtil.AddGlobalTimer(1, true, function() 
			OnOutOfRange()
		end)
end

local function on_duel_out_of_range(sender,msg )
--warn("----------------on_duel_out_of_range:",msg)
	local hp = ECGame.Instance().m_HostPlayer
	if not hp then return end

	local duelInfo = hp.m_DuelInfo
	if not duelInfo then return end

	if msg.count_down == 0 then
		duelInfo.out_of_range = false
		duelInfo.range_count_down = 0
	else
		duelInfo.out_of_range = true
		duelInfo.range_count_down = 5
	end 

	OnOutOfRange()
end

pb_helper.AddHandler("gp_duel_out_of_range",on_duel_out_of_range)

