local pb_helper = require "PB.pb_helper"
local ECGame = require "Main.ECGame"
local client_msg = require "PB.client_msg"

--[[
local function on_gp_charge_stopped( sender,msg )
	local hp = ECGame.Instance().m_HostPlayer
	if hp and hp:IsCharging() then
		hp.SkillHdl:StopSkillCharge(msg.skill_id, msg:HasField("is_break") and msg.is_break ~= 0 or false)
	end
	-- warn("on_gp_charge_stopped")
end
pb_helper.AddHandler("gp_charge_stopped", on_gp_charge_stopped)
--]]

-- 技能信息同步协议
---@param msg pb.Message.PB.gp_skill_data
local function on_gp_skill_data( sender,msg )
	if _G.SkillSyncOld then
		return
	end
	print_LearnSkill("Receive gp_skill_data")

	local ECHostNetHdl = require "Players.ECHostNetHdl"
	local hp = ECGame.Instance():GetHostPlayer()
	if hp then
		local netHdl = hp.NetHdl
		if netHdl:is(ECHostNetHdl) then
			if msg.full_data then
				netHdl:ClearAllSkills()
			end
			for i, skillInfo in ipairs(msg.skill_list) do
				netHdl:SetSkillData(skillInfo.skill_id, skillInfo.level, skillInfo.addon_level, skillInfo.forbid_mask, skillInfo.strength_level)
			end

			local HostSkillDataEvent = require "Event.HostSkillEvents".HostSkillDataEvent
			ECGame.EventManager:raiseEvent(nil, HostSkillDataEvent())
		end
	else
		-- 后端可能在玩家创建前，比如装备初始化的阶段，先发送一次技能等级消息
		warn("Process on_gp_skill_data failed: Host player not found")
	end
end
pb_helper.AddHandler("gp_skill_data", on_gp_skill_data)

-- 技能信息变化协议
---@param msg pb.Message.PB.gp_skill_info_notify
local function on_gp_skill_info_notify( sender,msg )
	if _G.SkillSyncOld then
		return
	end
	print_LearnSkill("Receive gp_skill_info_notify")

	local ECHostNetHdl = require "Players.ECHostNetHdl"
	local hp = ECGame.Instance():GetHostPlayer()
	if hp then
		local netHdl = hp.NetHdl
		if netHdl:is(ECHostNetHdl) then
			if bit.band(msg.field_mask, client_msg.SKILL_FIELD_MASK.SFM_BASE_LEVEL) ~= 0 then
				netHdl:OnCmd_LearnSkill(msg.skill.skill_id, msg.skill.level)
			elseif bit.band(msg.field_mask, client_msg.SKILL_FIELD_MASK.SFM_ADDON_LEVEL) ~= 0 then
				netHdl:OnCmd_SkillAddon(msg.skill.skill_id, msg.skill.addon_level)
			elseif bit.band(msg.field_mask, client_msg.SKILL_FIELD_MASK.SFM_FORBID) ~= 0 then
				netHdl:OnCmd_SkillForbid(msg.skill.skill_id, msg.skill.forbid_mask)
			end

			if bit.band(msg.field_mask, client_msg.SKILL_FIELD_MASK.SFM_STRENGTH_LEVEL) ~= 0 then
				netHdl:OnCmd_SkillStrength(msg.skill.skill_id, msg.skill.strength_level)
			end

			local HostSkillDataEvent = require "Event.HostSkillEvents".HostSkillDataEvent
			ECGame.EventManager:raiseEvent(nil, HostSkillDataEvent())

			local HostNewSkillEvent = require "Event.HostSkillEvents".HostNewSkillEvent
			ECGame.EventManager:raiseEvent(nil, HostNewSkillEvent.new(msg.skill.skill_id))
		end
	else
		-- 后端可能在玩家创建前，比如装备初始化的阶段，先发送一次技能等级消息
		warn("Process gp_skill_info_notify failed: Host player not found")
	end
end
pb_helper.AddHandler("gp_skill_info_notify", on_gp_skill_info_notify)

local function on_gp_skill_replace(sender, msg)
	local ECSkillSequence = require "Skill.ECSkillSequence"
	local gp_skill_replace = pb_helper.GetCmdClass("gp_skill_replace")

	if msg.effect_type == gp_skill_replace.SRE_SKILL_SEQ then
		if msg.op_type == gp_skill_replace.SRO_REPLACE then
			ECSkillSequence.Instance():SetReplaceSeqId(msg.base_id, msg.replace_id)
		elseif msg.op_type == gp_skill_replace.SRO_CANCEL_REPLACE then
			ECSkillSequence.Instance():SetReplaceSeqId(msg.base_id, 0)
		end
	elseif msg.effect_type == gp_skill_replace.SRE_SKILL then
		if msg.op_type == gp_skill_replace.SRO_REPLACE then
			ECSkillSequence.Instance():SetReplaceSkillId(msg.base_id, msg.replace_id)
		elseif msg.op_type == gp_skill_replace.SRO_CANCEL_REPLACE then
			ECSkillSequence.Instance():SetReplaceSkillId(msg.base_id, 0)
		end
	end

	local HostSkillDataEvent = require "Event.HostSkillEvents".HostSkillDataEvent
	ECGame.EventManager:raiseEvent(nil, HostSkillDataEvent())
end
pb_helper.AddHandler("gp_skill_replace", on_gp_skill_replace)


local function on_gp_object_strength_skill_info(sender, msg)
	--print_jhj("on_gp_object_strength_skill_info", msg)
	--print_jzw("on_gp_object_strength_skill_info 受身强化", msg)
	---@type ECObject
	local target = ECGame.Instance():GetHostPlayer()
	if target and target:GetSkillStateData() then
		target:GetSkillStateData():IncrementalUpdate(msg)
	end
end
pb_helper.AddHandler("gp_object_strength_skill_info", on_gp_object_strength_skill_info)

local function on_gp_cooldown_ex_notify(sender, msg)
	local ECClientCoolDownManager = require "Main.ECClientCoolDownManager"
	ECClientCoolDownManager.Instance():OnSyncCoolDownData(msg, true, function (data)
		local ECClientCoolDownUIMan = require "Main.ECClientCoolDownUIMan"
		ECClientCoolDownUIMan.Instance():OnSyncCoolDownData(data)
	end)
end
pb_helper.AddHandler("gp_cooldown_ex_notify", on_gp_cooldown_ex_notify)

local function on_gp_cooldown_ex_info(sender, msg)
	local ECClientCoolDownManager = require "Main.ECClientCoolDownManager"
	ECClientCoolDownManager.Instance():OnSyncCoolDownData(msg, false,function (data)
		local ECClientCoolDownUIMan = require "Main.ECClientCoolDownUIMan"
		ECClientCoolDownUIMan.Instance():OnSyncCoolDownData(data)
	end)
end
pb_helper.AddHandler("gp_cooldown_ex_info", on_gp_cooldown_ex_info)

---@param msg pb.Message.PB.gp_buff_triggered
local function on_gp_buff_triggered(sender, msg)
	---@type ECObject
	local obj = ECGame.Instance():FindObjectOrHost(msg.role_id)
	if obj and obj:GetSkillHdl() then
		obj:GetSkillHdl():OnBuffTriggered(msg)
	end
end
pb_helper.AddHandler("gp_buff_triggered", on_gp_buff_triggered)
