local Lplus = require "Lplus"

local pb_helper = require "PB.pb_helper"
local ECGame = require "Main.ECGame"

--
-- gp_object_state
--
---@param sender any
---@param msg pb.Message.PB.gp_object_state
local function on_object_state_respond( sender,msg )
	local ECObject = require "Object.ECObject"
	if not ECGame.Instance().m_CurWorld then
		warn("gp_object_state: CurWorld is Nil")
	else
		local obj = ECGame.Instance().m_CurWorld:FindObjectOrHost(msg.roleid)
		if obj and obj:is(ECObject) then
			obj:UpdateObjectState(msg)
		else
			--warn("gp_object_state not found:", LuaUInt64.ToString(msg.roleid))
		end
	end
end

pb_helper.AddHandler("gp_object_state", on_object_state_respond)

---@param msg pb.Message.PB.BKStateChange
local function on_change_break_state(sender, msg)
	local ECObject = require "Object.ECObject"
	--warn("on_change_break_state:", msg.npc_id, msg.break_state)

	local id = msg.npc_id
	local breakState = msg.break_state
	local curTime = msg.cur_state_time 
	local durationTime =  msg.state_time
	local world = ECGame.Instance().m_CurWorld
	---@type ECNPC
	local target = world and world:FindObjectOrHost(id)

	if target and target:is(ECObject) then
		target:SetBreakState(breakState, (durationTime - curTime)/1000, durationTime/1000)
	end
end

pb_helper.AddHandler("BKStateChange", on_change_break_state)

--
--gp_pet_object_fight
--
-- local function on_pet_object_fight_state_respond(sender,msg)
-- 	do--暂时屏蔽
-- 		return
-- 	end
-- 	if not ECGame.Instance().m_CurWorld then return end
-- 	local obj = ECGame.Instance().m_CurWorld:FindObjectOrHost(msg.roleid)
-- 	if obj then
-- 		obj:UpdatePetObjectFightState(msg)
-- 	end
-- end
-- pb_helper.AddHandler("gp_pet_object_fight", on_pet_object_fight_state_respond)


local function on_gp_object_state_info(sender, msg)
	local object = ECGame.Instance():FindObjectOrHost(msg.id)
	--print_jzw("on_gp_object_state_info", msg, object)
	if object then --主角不用处理，处理了会引发客户端和服务器因为上下行不一致的问题
		--print_jzw("on_gp_object_state_info",msg.state_info)
		if object:IsHost() and msg.state_info == _G.BattlePoseType.DEFAULT_STATE and object:getBattlePoseMan():IsBlocking() then
			--print_jzw("blockstate")
		else
			object:OnPostureStateChange(msg)
		end

	end
end

pb_helper.AddHandler("gp_object_state_info", on_gp_object_state_info)

---@param msg pb.Message.PB.gp_object_update_action
local function on_gp_object_update_action(sender, msg)
	---@type ECPlayer
	local object = ECGame.Instance():FindObjectOrHost(msg.object_id)
	if object then
		if object:GetActionType() ~= msg.action_type or object:GetActionArg() ~= msg.param then
			Debug.LogError("object action update error, action_type and action_param can not update:", tostring(msg))
		end
		object:SetActionStage(msg.stage)
		if msg.action_type == GP_SESSION_TYPE.POINT_TO_POINT_MOVE then
			local FSMPlayerPointToPointMove = require "FSM.PlayerFSM.FSMPlayerPointToPointMove"
			local targetPos = EC.Vector3.new()
			targetPos:Assign(msg.target_pos)
			local state = FSMPlayerPointToPointMove.new(object, msg.param, msg.stage, targetPos)
			object:ChangeState(state)
		end
	end
end
pb_helper.AddHandler("gp_object_update_action", on_gp_object_update_action)