local Lplus = require "Lplus"
local pb_helper = require "PB.pb_helper"

local function OnTeamInactiveResponse(sender, msg)
	-- if msg.request_type == 1 then -- 非活跃队伍
	-- 	local ECPanelMatchPopUp = require "GUI.ECPanelMatchPopUp"
	-- 	ECPanelMatchPopUp.Instance():Toggle()
	-- elseif msg.request_type == 5 then -- 队伍冻结，且有成员退出
	-- 	local ECPanelAutoRecruit = require "GUI.ECPanelAutoRecruit"
	-- 	ECPanelAutoRecruit.Instance():Toggle()
	-- end
	if msg.request_type == 7 then -- 通知平台特权
		local FriendMan = require "Friends.FriendMan"
		FriendMan.Instance():GetHostPlayerAttr()
	end
end
pb_helper.AddHandler("npt_common_request", OnTeamInactiveResponse)

