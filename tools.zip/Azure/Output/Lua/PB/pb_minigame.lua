--小游戏服务器回复

--
-- gp_minigame_operate_notify
-- 
local pb_helper = require "PB.pb_helper"

-- local function on_minigame_notify( sender,msg )
	
-- end
-- pb_helper.AddHandler("gp_minigame_operate_notify",on_minigame_notify)
