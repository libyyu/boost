local Lplus = require "Lplus"
local pb_helper = require "PB.pb_helper"
---@type ECGame
local ECGame = Lplus.ForwardDeclare("ECGame")


--[[

//技能方案操作返回码
enum SKILL_PLAN_REPLY_CODE {
    SKILLPLAN_REPLY_SUCCESS           = 0;  //成功
    SKILLPLAN_REPLY_CHANGE_SUCCESS    = 1;  //官方方案切换成功
    SKILLPLAN_REPLY_CHANGE_INCOMPLETE = 2;  //等级或技能点不足，官方方案不完全切换
    SKILLPLAN_REPLY_EXP_NOT_ENOUGH    = 3;  //技能点不足
    SKILLPLAN_REPLY_PLAN_LOCKED       = 4;  //方案未解锁
    SKILLPLAN_REPLY_COVER_TO_EMPTY    = 5;  //弹窗：步骤不一致，覆盖到空方案 删掉
    SKILLPLAN_REPLY_COVER_TO_LAST     = 6;  //弹窗：步骤不一致，覆盖到最后一个方案  删掉
    SKILLPLAN_REPLY_FORGET_SUCCESS    = 7;  //方案重置成功(洗点)
    SKILLPLAN_REPLY_STEP_UNMATCH      = 8;  //官方方案学习技能步骤不一致
]]

local function plan_recode(msg)
    local errcode = msg.reply_code
    --print_wyl("-----plan_recode----------errcode-----", errcode)
    -- if errcode == _G.CONSTANT_DEFINE.SKILL_PLAN_REPLY_CODE.SKILLPLAN_REPLY_CHANGE_SUCCESS then
    --     FlashTipMan.FlashTip(StringTable.Get(104016))
    -- elseif errcode == _G.CONSTANT_DEFINE.SKILL_PLAN_REPLY_CODE.SKILLPLAN_REPLY_CHANGE_INCOMPLETE then
    --     FlashTipMan.FlashTip(StringTable.Get(104017))
    -- elseif errcode == _G.CONSTANT_DEFINE.SKILL_PLAN_REPLY_CODE.SKILLPLAN_REPLY_EXP_NOT_ENOUGH then
    --     FlashTipMan.FlashTip(StringTable.Get(104018))
    if errcode == _G.CONSTANT_DEFINE.SKILL_PLAN_REPLY_CODE.SKILLPLAN_REPLY_PLAN_LOCKED then
        FlashTipMan.FlashTip(StringTable.Get(104019))

    elseif errcode == _G.CONSTANT_DEFINE.SKILL_PLAN_REPLY_CODE.SKILLPLAN_REPLY_FORGET_SUCCESS then --方案重置成功
        FlashTipMan.FlashTip(StringTable.Get(104026))

    elseif errcode == _G.CONSTANT_DEFINE.SKILL_PLAN_REPLY_CODE.SKILLPLAN_REPLY_COVER_TO_EMPTY then --切换为空方案
        local cur_plan_id = msg.plan_id

        local plan = msg.plan
        local name = plan.name  --方案名称

        local str = StringTable.Get(104023):format(name)
        MsgBox.ShowMsgBox(self, str, nil, MsgBox.MsgBoxType.MBBT_OKCANCEL, function(sender, ret)
            if MsgBox.MsgBoxRetT.MBRT_OK == ret then
                local ECSkillTreeManager = require "Skill.ECSkillTreeManager"
                --ECSkillTreeManager.Instance():SendOpratePlan(_G.CONSTANT_DEFINE.SKILL_PLAN_OPERATION.SKILLPLAN_OPERATION_COVER, cur_plan_id, "", 0) 
            end
        end, 60)

    elseif errcode == _G.CONSTANT_DEFINE.SKILL_PLAN_REPLY_CODE.SKILLPLAN_REPLY_COVER_TO_LAST then --覆盖为自定义方案
        local cur_plan_id = msg.plan_id

        local plan = msg.plan
        local name = plan.name  --方案名称

        local str = StringTable.Get(104024):format(name)
        MsgBox.ShowMsgBox(self, str, nil, MsgBox.MsgBoxType.MBBT_OKCANCEL, function(sender, ret)
            if MsgBox.MsgBoxRetT.MBRT_OK == ret then
                local ECSkillTreeManager = require "Skill.ECSkillTreeManager"
                --ECSkillTreeManager.Instance():SendOpratePlan(_G.CONSTANT_DEFINE.SKILL_PLAN_OPERATION.SKILLPLAN_OPERATION_COVER, cur_plan_id, "", 0) 
            end
        end, 60)


    --优化代码逻辑
    elseif errcode == _G.CONSTANT_DEFINE.SKILL_PLAN_REPLY_CODE.SKILLPLAN_REPLY_STEP_UNMATCH then --官方方案学习技能步骤不一致：是否切换为新方案，客户端判断
            local ECSkillTreeManager = require "Skill.ECSkillTreeManager"
            local bExist, cur_plan_id, name = ECSkillTreeManager.Instance():IsExistEmptyPlan(0)
            --print_wyl("-------cur_plan_id-------", bExist, weapon_id, cur_plan_id)
            if bExist then
                local str = StringTable.Get(104023):format(name)
                MsgBox.ShowMsgBox(self, str, nil, MsgBox.MsgBoxType.MBBT_OKCANCEL, function(sender, ret)
                    if MsgBox.MsgBoxRetT.MBRT_OK == ret then
                        --ECSkillTreeManager.Instance():SendOpratePlan(_G.CONSTANT_DEFINE.SKILL_PLAN_OPERATION.SKILLPLAN_OPERATION_COVER, cur_plan_id, "", 0) 
                    end
                end, 60)

            else
                local plan = msg.plan
                local newname = plan.name  --方案名称

                local str = StringTable.Get(104024):format(newname)
                MsgBox.ShowMsgBox(self, str, nil, MsgBox.MsgBoxType.MBBT_OKCANCEL, function(sender, ret)
                    if MsgBox.MsgBoxRetT.MBRT_OK == ret then
                        --ECSkillTreeManager.Instance():SendOpratePlan(_G.CONSTANT_DEFINE.SKILL_PLAN_OPERATION.SKILLPLAN_OPERATION_COVER, cur_plan_id, "", 0) 
                    end
                end, 60)

            end

    end
end


-----------技能方案----------------------
--[[
//全部数据同步
message gp_skill_plan_data {
    option (s2c_type)        = type_gp_skill_plan_data;
    db_skill_plan skill_data = 2;
}
--]]
local function on_skill_plan_data(sender, msg)
    --print_wyl("------gp_skill_plan_data----------", msg)
	local ECSkillTreeManager = require "Skill.ECSkillTreeManager"
	ECSkillTreeManager.Instance():SetSkillAllPlans(msg)

	local SkillTreeDataEvent = require "Event.SkillTreeDataEvent"
	ECGame.EventManager:raiseEvent(nil,  SkillTreeDataEvent())

end
pb_helper.AddHandler("gp_skill_plan_data", on_skill_plan_data)


--[[
message skill_update_plan {
    int32             id             = 1;  //方案id
    map<int32, int32> cost_skill_exp = 2;  //消耗的技能经验 key:声望id value:count
    repeated skill_update_step step  = 3;  //具体加点步骤
}
//武器套件技能信息
message db_weapon_kit_skill_info {
    int32                      weapon_kit_id = 1;  //武器套件id
    repeated skill_update_plan update_plan   = 2;  //技能加点方案
}
//武器套件信息同步
message gp_weapon_kit_skill {
    option (s2c_type)                          = type_gp_weapon_kit_skill;
    db_weapon_kit_skill_info weapon_skill_data = 2;
}
--]]
-----------武器套件技能信息------------------
local function on_weapon_kit_skill(sender, msg)
    print_wyl("------gp_weapon_kit_skill----------")
    local ECSkillTreeManager = require "Skill.ECSkillTreeManager"
    ECSkillTreeManager.Instance():ChangeSkillPlan(msg)

    --if msg.is_refresh then
        local SkillTreeDataEvent = require "Event.SkillTreeDataEvent"
        ECGame.EventManager:raiseEvent(nil,  SkillTreeDataEvent())
    --end
end
pb_helper.AddHandler("gp_weapon_kit_skill", on_weapon_kit_skill)


--[[
//技能方案信息同步
message gp_weapon_kit_update_plan {
    int32             weapon_kit_id = 1;
    skill_update_plan plan          = 2;
}
message gp_skill_plan_info {
    option (s2c_type)                              = type_gp_skill_plan_info;
    int32           cur_plan_id                    = 2;
    skill_plan_info plan                           = 3;
    repeated gp_weapon_kit_update_plan update_data = 4;
    enum SKILL_PLAN_INFO_FIELD_MASK {
        WKPFM_NONE        = 0;
        WKPFM_CUR_PLAN_ID = 0x0001;  // cur_plan_id
        WKPFM_PLAN_INFO   = 0x0002;  // plan
        WKPFM_UPDATE_DATA = 0x0004;  // update_data
        WKPFM_END         = 0x0008;
    }
    int32 field_mask = 5;  //字段掩码 WEAPON_KIT_PLAN_FIELD_MASK
}
]]
-----------武器方案信息更新------------------
local function on_skill_plan_info(sender, msg)
    print_wyl("------gp_skill_plan_info----------", msg.field_mask)

    local ECSkillTreeManager = require "Skill.ECSkillTreeManager"
    ECSkillTreeManager.Instance():UpdateSkillPlan(msg)

end
pb_helper.AddHandler("gp_skill_plan_info", on_skill_plan_info)


--[[
message gp_weapon_skill_exp_change {
    option(s2c_type) = type_gp_weapon_skill_exp_change;
    repeated int32 change_count = 2;
}
--]]
-----------技能点更改信息------------------
local function on_weapon_skill_exp_change(sender, msg)
    local ECChatUtility = require "Chat.ECChatUtility"
    local ECChatManager = require "Chat.ECChatManager"
    print_wyl("-----on_weapon_skill_exp_change---------")
    local ECSkillTreeManager = require "Skill.ECSkillTreeManager"
	for i = 1, #msg.change_count do
        local skill_exp = msg.change_count[i]
		if skill_exp > 0 then
			local str = StringTable.Get(104010 + i - 1):format(skill_exp)
			FlashTipMan.FlashTip(str)
			local richStr =  ECChatUtility.GenerateRichText(str,nil)
			--ECChatManager.Instance():AddSimpleMessage2(str , richStr , _G.CONSTANT_DEFINE.CHAT_CHANNEL_ENUM.CHAT_CHANNEL_SYSTEM)
            local ECMsgInfo = require "Chat.ECMsgInfo"
            ECChatManager.Instance():AddSimpleMessageWithType(str, richStr, _G.CONSTANT_DEFINE.CHAT_CHANNEL_ENUM.CHAT_CHANNEL_SYSTEM, ECMsgInfo.MSG_TYPE.SYSTEM, "")
			--更新同类型武器技能点
            ECSkillTreeManager.Instance():SetWeaponExp(i-1, skill_exp)
		end
	end

    local SkillTreeDataEvent = require "Event.SkillTreeDataEvent"
    ECGame.EventManager:raiseEvent(nil,  SkillTreeDataEvent())

end
--pb_helper.AddHandler("gp_weapon_skill_exp_change", on_weapon_skill_exp_change)

--[[
message gp_skill_level_set_notify {
    option (s2c_type)    = type_gp_skill_level_set;
    message skill_level_info{
        int32 skill_id       = 1;  //技能id
        int32 base_level     = 2;  //技能等级，基础等级
        int32 addon_level    = 3;  //技能等级，附加等级
    }
    repeated skill_level_info skill_level_set = 2;
}
--]]

-----------技能等级信息------------------
---@param msg pb.Message.PB.gp_skill_level_set_notify
local function on_skill_level_set_notify(sender, msg)
    print_wyl("-----gp_skill_level_set_notify---------")
    for k, skillInfo in ipairs(msg.skill_level_set) do
        print_LearnSkill(("gp_skill_level_set_notify skill_id=[%s] base_level=[%s] addon_level=[%s]"):format(skillInfo.skill_id, skillInfo.base_level, skillInfo.addon_level))
    end

    local ECSkillTreeManager = require "Skill.ECSkillTreeManager"
    ECSkillTreeManager.Instance():UpdateSkillLevels(msg)

    -- local SkillTreeDataEvent = require "Event.SkillTreeDataEvent"
    -- ECGame.EventManager:raiseEvent(nil,  SkillTreeDataEvent())
end
pb_helper.AddHandler("gp_skill_level_set_notify", on_skill_level_set_notify)


--[[
message gp_skill_plan_operation_reply {
    option (s2c_type)               = type_gp_skill_plan_operation_reply;
    SKILL_PLAN_OPERATION operation  = 2;
    int32                reply_code = 3;  // SKILL_PLAN_REPLY_CODE
    int32                plan_id    = 4;  //加点方案id
    int32                skill_id   = 5;  //学习技能的ID
}
//技能方案操作类型
enum SKILL_PLAN_OPERATION {
    SPO_INVALID         = 0;
    SPO_FORGET          = 1;  //洗点
    SPO_CHANGE          = 2;  //切换 plan_id(logic_id)
    SPO_RENAME          = 3;  //改名 plan_id | new_name
    SPO_LEARN           = 4;  //学习技能 skill_id
    SPO_EQUIP_TALENT    = 5;  //装备天赋 talent_id | talent_hole_id
    SPO_TAKE_OFF_TALENT = 6;  //卸下天赋 talent_id | talent_hole_id
    SPO_AUTO_LEARN      = 7;  //一键加点
    SPO_OPEN_MAIN_PAGE  = 8;  //打开主页面 自动学习非当前系统方案
    SPO_COVER_TO        = 9;  //覆盖当前方案到 plan_id
    SPO_PRESET          = 10;  //方案预设 play_type | plan_id
    SPO_UNLEARN         = 11;  //技能降级 plan_id | skill_id
    SPO_UNLOCK          = 12;  //解锁方案 plan_id
    SPO_LEARN_SUMMONER  = 13;  //学习(解锁)召唤师技能 skill_id
    SPO_EQUIP_SUMMONER  = 14;  //装备(取消:skill_id=0)召唤师技能 plan_id | skill_id
}

enum SKILL_PLAN_REPLY_CODE {
    SPRC_SUCCESS        = 0;  //成功
    SPRC_EXP_NOT_ENOUGH = 1;  //技能点不足
}
--]]
--skill_plan_operation_reply------------ 3 0 54 1 0
-----------技能等级信息------------------
local function skill_plan_operation_reply(sender, msg)
    print_wyl("--------skill_plan_operation_reply------------", msg.operation, msg.reply_code, msg.plan_id, msg.skill_id, msg.plan_type)

    local SKILL_PLAN_OPERATION = _G.CONSTANT_DEFINE.SKILL_PLAN_OPERATION
    local SKILL_PLAN_REPLY_CODE = _G.CONSTANT_DEFINE.SKILL_PLAN_REPLY_CODE

    local operation = msg.operation
    local reply_code = msg.reply_code

    if operation == SKILL_PLAN_OPERATION.SPO_CHANGE then
        --print_wyl("------operation------------", operation, reply_code)
        if reply_code == SKILL_PLAN_REPLY_CODE.SPRC_SUCCESS then  --官方方案切换成功
            FlashTipMan.FlashTip(StringTable.Get(104016))
            require "Skill.ECSkillTreeManager".Instance():ChangeSkillPlanId(msg.plan_id)

        -- elseif reply_code == SKILL_PLAN_REPLY_CODE.SKILLPLAN_REPLY_CHANGE_INCOMPLETE then  --等级或技能点不足，官方方案不完全切换
        --     FlashTipMan.FlashTip(StringTable.Get(104017))

        elseif reply_code == SKILL_PLAN_REPLY_CODE.SPRC_EXP_NOT_ENOUGH then  --技能点不足
            FlashTipMan.FlashTip(StringTable.Get(104018))

        end

    elseif operation == SKILL_PLAN_OPERATION.SPO_RENAME then
        if reply_code == SKILL_PLAN_REPLY_CODE.SPRC_SUCCESS then  --方案改名成功

        end

    elseif operation == SKILL_PLAN_OPERATION.SPO_AUTO_LEARN then
        if reply_code == SKILL_PLAN_REPLY_CODE.SPRC_SUCCESS then  --推荐加点成功
            local plan_name = require "Skill.ECSkillTreeManager".Instance():GetRecommandTypeName(msg.plan_type)
            FlashTipMan.FlashTip(StringTable.Get(104058):format(plan_name))
        end
    end

    --走原有逻辑
    if reply_code > SKILL_PLAN_REPLY_CODE.SPRC_EXP_NOT_ENOUGH then
        plan_recode(msg)
    end

    print_wyl("-----msg.talent_id----------", msg.talent_id, msg.talent_hole_id)
    local ECSkillTreeManager = require "Skill.ECSkillTreeManager"
    if operation == SKILL_PLAN_OPERATION.SPO_EQUIP_TALENT then                 --装备
        ECSkillTreeManager.Instance():OnEquipTalent(msg.talent_id, true)

    elseif operation == SKILL_PLAN_OPERATION.SPO_TAKE_OFF_TALENT then          --卸下
        ECSkillTreeManager.Instance():OnEquipTalent(msg.talent_id, false)

    elseif operation == SKILL_PLAN_OPERATION.SPO_PRESET then          --方案预设 play_type | plan_id
        if reply_code == SKILL_PLAN_REPLY_CODE.SPRC_SUCCESS then
            FlashTipMan.FlashTip(StringTable.Get(104055))
        end
        local PreSetNotifyEvent = require "Event.PreSetNotifyEvent"
        local event = PreSetNotifyEvent()
        ECGame.EventManager:raiseEvent(nil, event)
        return

    elseif operation == SKILL_PLAN_OPERATION.SPO_UNLOCK then --解锁方案
        if reply_code == SKILL_PLAN_REPLY_CODE.SPRC_SUCCESS then  --成功
            ECSkillTreeManager.Instance():OnPlanUnlock(msg.plan_id, true)
        end
    end
    
    --if operation ~= SKILL_PLAN_OPERATION.SPO_LEARN then
        local SkillTreeDataEvent = require "Event.SkillTreeDataEvent"
        local event = SkillTreeDataEvent()
        event.type = operation
        event.tid = msg.skill_id
        ECGame.EventManager:raiseEvent(nil, event)
    --end

end
pb_helper.AddHandler("gp_skill_plan_operation_reply", skill_plan_operation_reply)


--[[
//技能附加功能通知
message gp_skill_ex_info {
    int32 id = 1;
    int32 level = 2;
    bool is_active = 3;
}
message gp_skill_ex_notify {
    option (s2c_type) = type_gp_skill_ex_notify;
    repeated gp_skill_ex_info data = 1;
}
--]]
local function on_skill_ex_notify(sender, msg)
    --print_wyl("--------gp_skill_ex_notify------------", msg.data)

    local ECSkillTreeManager = require "Skill.ECSkillTreeManager"
    ECSkillTreeManager.Instance():UpdateSkillReplaceTab(msg)

    --各个方案的数据已在其它协议中处理，不需要刷新了
    -- local SkillTreeDataEvent = require "Event.SkillTreeDataEvent"
    -- ECGame.EventManager:raiseEvent(nil,  SkillTreeDataEvent())

end
pb_helper.AddHandler("gp_skill_ex_notify", on_skill_ex_notify)


--[[
message gp_skill_ex_req {
    option (c2s_type) = GPROTOC_SKILL_EX_REQ;
    int32 skill_id = 2;
}
message gp_skill_ex_rep {
    option (s2c_type) = type_gp_skill_ex_rep;
    int32 ret = 1;
    int32 skill_id = 2;
}
--]]
local function on_skill_ex_rep(sender, msg)
    print_wyl("--------gp_skill_ex_rep------------", msg.ret)
    local ECSkillTreeManager = require "Skill.ECSkillTreeManager"
    ECSkillTreeManager.Instance():UpgradeReplaceNode(msg)

    local SkillTreeDataEvent = require "Event.SkillTreeDataEvent"
    ECGame.EventManager:raiseEvent(nil,  SkillTreeDataEvent())

end
pb_helper.AddHandler("gp_skill_ex_rep", on_skill_ex_rep)


--[[
message gp_skill_op_rep {
    option (s2c_type) = type_gp_skill_op_rep;
    int32 ret = 2;
}
]]
local function on_skill_op_rep(sender, msg)
    print_wyl("--------gp_skill_op_rep------------", msg.ret)
    
    -- local SkillTreeDataEvent = require "Event.SkillTreeDataEvent"
    -- ECGame.EventManager:raiseEvent(nil,  SkillTreeDataEvent())
end
pb_helper.AddHandler("gp_skill_op_rep", on_skill_op_rep)


--[[
// 雅芙之镜操作类型
enum YAFU_MIRROR_OP_TYPE {
    OT_YAFU_INVALID         = 0; //非法
    OT_YAFU_ALL_INFO        = 1; //登录通知全量信息
    OT_MIRROR_LEVELUP       = 2; //雅芙之镜升级
    OT_EQUIP_SKILLID        = 3; //装备神器技能
}
// buff详细信息list
message gp_yafu_mirror_resp {
    option (s2c_type) = type_gp_yafu_mirror_resp;

    YAFU_MIRROR_OP_TYPE ot = 1; //操作类型
    db_yafu_mirror_data data = 2; //数据
}
]]
local function on_yafu_mirror_resp(sender, msg)
    --print_wyl("--------gp_yafu_mirror_resp------------", msg.ot)

    local ECSkillTreeManager = require "Skill.ECSkillTreeManager"
    ECSkillTreeManager.Instance():YafuMirrorResp(msg)
    
    local SkillSummonerEvent = require "Event.SkillSummonerEvent"
    ECGame.EventManager:raiseEvent(nil,  SkillSummonerEvent())

end
pb_helper.AddHandler("gp_yafu_mirror_resp", on_yafu_mirror_resp)

