local pb_helper = require "PB.pb_helper"

--gp_hero_incre_info
local function on_hero_incre_info(sender, msg)
	Log.Print("mount",  "gp_hero_incre_info", msg)
	local ECMountMan = require "Mount.ECMountMan"
	ECMountMan.Instance():OnMountIncreInfo(msg)
end
pb_helper.AddHandler("gp_hero_incre_info", on_hero_incre_info)

