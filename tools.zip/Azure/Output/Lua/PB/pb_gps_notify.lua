local pb_helper = require "PB.pb_helper"
pb_helper.AddHandler("gp_gps_notify", function(sender, msg)
    --print_wyl("gp_gps_notify", msg)
    require "GUI.GPSGoal.GPSGoalMan".Get():OnGPSNotify(msg)
end)

---@param msg pb.Message.PB.gp_find_way_result
pb_helper.AddHandler("gp_find_way_result", function(sender, msg)
    --print_wyl("gp_find_way_result", msg)
	require "GUI.GPSGoal.GPSGoalMan".Get():OnFindWayResult(msg)
	require "Task.FTaskAutoMove".OnFindWayResult(msg)
end)


--[[
message gp_region_first_arrived {
    option (s2c_type)   = type_gp_region_first_arrived;
    int64 target_roleid = 1;  //观察者的目标id
    int32 type          = 2;  // 1 tips 2第一段跳转动画
}
--]]

pb_helper.AddHandler("gp_region_first_arrived", function(sender, msg)
	--print_wyl("gp_region_first_arrived------type-----", msg.type)
    --print_wyl("gp_region_first_arrive--target_roleid-", msg.target_roleid)
    local roleid = msg.target_roleid  --LuaInt64.ToString(roleId)
    local ECGame = require "Main.ECGame"
    local hp = ECGame.Instance().m_HostPlayer
    if hp == nil or hp.Team == nil then
    	return
    end

    if msg.type == 1 then
    	local member =  hp.Team:GetMemberByID(roleid)
    	if member ~= nil then
    		FlashTipMan.FlashTip(StringTable.Get(108010):format(member.Name))
    	end   		
	    --特效展示
	    hp:PlayPreJumpFx()

	elseif msg.type == 2 then
    	local elsePlayer = ECGame.Instance():FindObjectOrHost(roleid)
    	if elsePlayer ~= nil and roleid ~= hp.ID then
    		elsePlayer:PlayPreJumpFx()
    	end   	
    end

end)

