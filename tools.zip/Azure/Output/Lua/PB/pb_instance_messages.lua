--[[
	副本内信息相关协议
]]
local pb_helper = require "PB.pb_helper"
local ECGame = require "Main.ECGame"


local function on_level_attribute(sender, msg)
--	warn(" gp_level_attribute @@@@@@@@@@@@@@@@@@@ : ", msg)
	local FEInstanceMan = require "Instance.FEInstanceMan".Instance()
	FEInstanceMan:OnLevelAttribute(msg)
end

pb_helper.AddHandler("gp_level_attribute", on_level_attribute)

local function on_gp_level_trace_info(sender, msg)
--	warn(" gp_level_trace_info @@@@@@@@@@@@@@@@@@@ : ", msg)
	local FEInstanceMan = require "Instance.FEInstanceMan".Instance()
	FEInstanceMan:OnLevelTraceInfo(msg)
end

pb_helper.AddHandler("gp_level_trace_info", on_gp_level_trace_info)

local function on_gp_level_rank_list(sender,msg )
--	warn("on_gp_level_rank_list : ", msg)
	--local FEInstanceMan = require "Instance.FEInstanceMan"
	--FEInstanceMan.Instance():OnLevelRankList(msg)
	local ECMatchMan = require "Match.ECMatchMan"
	ECMatchMan.Instance():OnSyncInstRankList(msg)
end
pb_helper.AddHandler("gp_level_rank_list", on_gp_level_rank_list)



 local function on_gp_level_extern_info(sender, msg)
	 if require "Instance.FEInstanceMan".Instance():IsPVPInstance() then
		 local ECMatchMan = require "Match.ECMatchMan"
		 if ECMatchMan.Instance().onPVPInfoCB then
			 ECMatchMan.Instance().onPVPInfoCB(msg)
		 else
			 warn("Has No Info For PVP Instance")
		 end
	 end

	 require "Instance.FEInstanceMan".Instance():OnLevelExternInfo(msg)
 end
 pb_helper.AddHandler("gp_level_extern_info",on_gp_level_extern_info)


-- --
-- --gp_punishment_time
-- --
-- local function on_punishment_time(sender,msg)	
-- 	local FEInstanceMan = require "Instance.FEInstanceMan"
-- 	FEInstanceMan.Instance():OnPunishmentTime(msg)
-- end
-- pb_helper.AddHandler("gp_punishment_time",on_punishment_time)


-- local function on_npt_battle_match_result( sender,msg )
-- 	require "Main.ECCampionAutoMatchMan".MatchSuccess(msg)
-- end
-- pb_helper.AddHandler("npt_battle_match_result",on_npt_battle_match_result)


-- local function on_npt_battle_match_prepare( sender,msg )
-- 	require "Main.ECCampionAutoMatchMan".SetMatchState(msg)

-- 	if msg.prepare == 0 then
-- 		FlashTipMan.FlashTip(StringTable.Get(1083))
-- 	end
-- 	--end
-- 	--所有匹配消息
-- 	local ECGUIViewTeamMatching = require "GUI.ECGUIViewTeamMatching"
-- 	ECGUIViewTeamMatching.SetMatchMessage(msg)
-- end
-- pb_helper.AddHandler("npt_battle_match_prepare",on_npt_battle_match_prepare)



-- --[[
-- 	竞技场重置
-- ]]
-- local function on_npt_arena_reset(sender,msg)
-- 	local ECArenaMan = require "Social.ECArenaMan"
-- 	ECArenaMan.Instance():onResetArena(msg)
-- end
-- pb_helper.AddHandler("npt_arena_reset", on_npt_arena_reset)

-- local function on_npt_rece_arena_award(sender,msg)
-- 	local ECArenaMan = require "Social.ECArenaMan"
-- 	ECArenaMan.Instance():onRecieveArenaAward(msg)
-- end
-- pb_helper.AddHandler("npt_rece_arena_award", on_npt_rece_arena_award)

-- --[[
-- 	竞技场开战
-- ]]
-- local function on_npt_enter_arena_cost_ticket(sender,msg)
-- 	local ECArenaMan = require "Social.ECArenaMan"
-- 	ECArenaMan.Instance():onOpenArenaBattle(msg)
-- end
-- pb_helper.AddHandler("npt_enter_arena_cost_ticket", on_npt_enter_arena_cost_ticket)