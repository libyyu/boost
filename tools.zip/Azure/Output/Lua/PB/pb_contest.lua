local Lplus = require "Lplus"
local pb_helper = require "PB.pb_helper"

local function on_player_contset_begin_result(sender,msg)
	print("==========on_player_contset_begin_result:", msg)
	if 	msg.retcode == 0 then
		local instPicture = require "GUI.ECPanelExamPicture".Instance()
		local instExam = require "GUI.ECPanelExam".Instance()
		if instPicture.m_subType == msg.sub_type then
			instPicture:CreatePanel(RESPATH.Panel_Exam_Picture)
		elseif instExam.m_subType == msg.sub_type then
			instExam:CreatePanel(RESPATH.Panel_Exam)
		end
	else
		if msg.retcode == 959 then
			FlashTipMan.FlashTip(StringTable.Get(17006))
		else
			FlashTipMan.FlashTip(StringTable.Get(17000))
		end
	end
end
pb_helper.AddHandler("npt_player_contset_begin_result", on_player_contset_begin_result)

local function on_player_contest_for_help(sender,msg)
	if 	msg.retcode == 0 then
		if msg.update_counter then
				local inst = require "GUI.ECPanelExamPicture".Instance()
				if inst.m_subType ~= 0 then
					if inst.m_panel then
						inst.m_sysHelpUsed = inst.m_sysHelpUsed + 1
						inst:UpdateSysHelpTimes()
					end
				end
		end
		require "GUI.ECPanelExamPictureHelp".Instance():PopupPanel(msg.questionid)
	elseif msg.retcode == 962 then
		FlashTipMan.FlashTip(StringTable.Get(17008))
	end
end
pb_helper.AddHandler("npt_player_contest_for_help", on_player_contest_for_help)

local function on_player_contest_faction_help_result(sender,msg)
	if msg.retcode == 0 then
		local instPicture = require "GUI.ECPanelExamPicture".Instance()
		local instExam = require "GUI.ECPanelExam".Instance()
		if instPicture.m_subType ~= 0 then
			if instPicture.m_panel then
				instPicture:SendHelpMessage()
			end
		elseif instExam.m_subType ~= 0 then
			if instExam.m_panel then
				instExam:SendHelpMessage()
			end
		end
	else
		FlashTipMan.FlashTip(StringTable.Get(17004))
	end
end
pb_helper.AddHandler("npt_player_contest_faction_help_result", on_player_contest_faction_help_result)