---@type pb.File.constant
_G.CONSTANT_DEFINE = require "Utility.DynamicProtobufWrapper".LoadFile "data/PB/constant.pb"
return _G.CONSTANT_DEFINE
