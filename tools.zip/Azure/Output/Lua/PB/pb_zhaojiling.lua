local Lplus = require "Lplus"

local pb_helper = require "PB.pb_helper"
local ECGame = require "Main.ECGame"
local bit = require "bit"
local band = bit.band
local CommonInvite = require "Protocol.CommonInvite"

--[[
enum ZHAOJI_TYPE {
		ZT_ITEM			= 0;	//召集令 zhaojiling_id 不为 0
		ZT_NATION_WAR_START	= 1;	//国战开始召集
		ZT_NATION_WAR_ROLE	= 2;	//国战期间手动召集 src_name不为空
	};
]]
--
-- npt_zhaojiling
--

local function can_receive_msg()


	local theGame = ECGame.Instance()
	local hp = theGame.m_HostPlayer
	if not hp then
		return false
	end

	--副本中不弹
	local Inst = theGame.m_Instance
	if Inst:IsInInstance() then --and not ECGame.Instance():IsServerWarMode() then
		return false
	end

	--押镖收不到

	if hp._dartinfo and hp._dartinfo.ondart then
		return false
	end

	--喝酒收不到
	local fsm_state = hp._FsmHdl:GetCurrentState()
	if fsm_state and fsm_state.type == "ObjDrink" then
		return false
	end

	return true

end

local function on_respond( sender, xid, msg )
	--print("npt_zhaojiling ",msg)
	--local StringTable = require "Data.StringTable"	
	local NATION_DATA = require "Social.ECNationData"
    --local FACTION_DATA = require "Social.ECFactionData"

	local baseinfo = msg.baseinfo
	local caller_name = GameUtil.UnicodeToUtf8(baseinfo.src_name) 
    local delay_time = baseinfo.delay_time
    local scene_tag = baseinfo.scene_tag
    local _type = baseinfo.type
    local zhaojiling_id = baseinfo.zhaojiling_id
	
	local position = "Error"
	if baseinfo.src_nation_position > 0 then
		position = NATION_DATA.OFFICER_ID_TO_NAME[baseinfo.src_nation_position]
	elseif baseinfo.src_corp_position >= 0  then
		--position = FACTION_DATA.faction_position_to_name[baseinfo.src_corp_position]
	end
	print(LuaUInt64.ToString(baseinfo.src),caller_name,position,baseinfo.src_nation_position,baseinfo.src_corp_position,_type,delay_time,zhaojiling_id,scene_tag)
	
    if delay_time == 0 then delay_time = 60 end --国战所有传送确认消息，有效时间为1min
	
	if _type == 1 then
	elseif _type == 2 then --国战期间手动召集
	else

		if not can_receive_msg() then
			return
		end

	    local strformat = StringTable.Get(60)
		local ttl = baseinfo.delay_time
		if ttl == 0 then ttl = 60 end
		local showmsg = string.format(strformat, position, caller_name, ttl)

		MsgBox.ShowMsgBoxEx(nil,showmsg,nil,MsgBox.MsgBoxType.MBBT_OKCANCEL,function(mb, ret)
			local ci = CommonInvite()
			if ret == MsgBox.MsgBoxRetT.MBRT_OK then
				ci.retcode = 0
			else
				ci.retcode = 1
			end
			ci.xid = band(xid, 0x7FFFFFFF)
			ECGame.Instance().m_Network:SendProtocol(ci)
		end, ttl, function(thebox)
			ttl = ttl - 1
			if ttl >= 0 then
				showmsg = string.format(strformat, position, caller_name, ttl)
				thebox:SetText(showmsg)
			end		
		end
		)
	end
end
pb_helper.AddHandler("npt_zhaojiling", on_respond)
