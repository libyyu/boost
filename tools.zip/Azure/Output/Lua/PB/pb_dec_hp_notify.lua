---
---@author chenshilei
---@date 2019/8/12 11:49
---@description 特殊技能伤血协议
---

local pb_helper = require "PB.pb_helper"
local ECGame = require "Main.ECGame"

-- frome gengxu:对于这种自残技能，正式上线我们大概率不会选择冒伤害数字
-- from machao:默认打开伤血冒字
_G.isShowDecHpNotifyUI = true

---@param msg pb.Message.PB.gp_dec_hp_notify
local on_dec_hp_notify = function(sender, msg)
    local hp = ECGame.Instance().m_HostPlayer
    local isHost = (msg.roleid == hp.ID)
    
    if msg.dec_type == 0 then -- 客户端不需要显示来源
        return
    elseif msg.dec_type == 1 or msg.dec_type == 2 then -- 技能状态伤血，高空坠落伤血
        if isHost then
            if _G.isShowDecHpNotifyUI then
                HUDMan.ShowHostHPChange(-msg.dec_hp,nil,nil,msg.dec_type == 2)
            end
        end
    else
        warn("gp_dec_hp_notify 伤血类型 未知 dec_type = " , msg.dec_type)
    end
end

pb_helper.AddHandler("gp_dec_hp_notify", on_dec_hp_notify)
