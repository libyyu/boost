
--2015年4月1日
--Wang Yinliang
--
-- 副本倒计时
-- gp_level_info
-- 
local pb_helper = require "PB.pb_helper"

--[[
	optional S2C_GS_PROTOC_TYPE type        = 1 [ default = type_gp_level_info ];
	optional int32 inst_start_time			= 2;
--]]

local function on_level_info( sender,msg )
	local FEPanelSceneGuide = require "GUI.FEPanelSceneGuide"
	print_wyl("gp_level_info---------------", msg.inst_start_time)
	local Lplus = require "Lplus"
	---@type ECGame
	local ECGame = Lplus.ForwardDeclare("ECGame")

	local FEInstanceMan = require "Instance.FEInstanceMan".Instance()
	FEInstanceMan.m_InstStartTime = msg.inst_start_time
	local old_mode = FEInstanceMan._cur_instance_mode
	FEInstanceMan:SetCurrentInstanceMode(msg.mode)

	if ECGame.Instance():GetCurrentWorldTid() == 0 then
		warn("player is not in the instance")
		return
	end

	if require "Match.ECMatchMan".Instance():IsPVPInstance(msg.inst_tid)then
		local ECMatchMan = require "Match.ECMatchMan"
		local node = ECMatchMan.Instance():FindMatchingWithPair(msg.inst_tid, 1)
		if not node then
			ECMatchMan.Instance():OnSyncNewPVPInfo(msg)
		end
	end



	local ECPanelInstanceGuide =  FEPanelSceneGuide.Instance():GetInstanceGuidePanel()
	FEPanelSceneGuide.Instance().m_countDownView:StartCoolDown(msg.inst_start_time)
	ECPanelInstanceGuide:UpdateDisplay()
	FEPanelSceneGuide.Instance():UpdateReviveInfo()

	local ECChaosDungeonsManager = require "GUI.ChaosDungeons.ECChaosDungeonsManager"
	ECChaosDungeonsManager.Instance():SetCurrentChallengeModeAndFloor(msg.chaos_dungeons_team, msg.chaos_dungeons_floor)

end

pb_helper.AddHandler("gp_level_info", on_level_info)
