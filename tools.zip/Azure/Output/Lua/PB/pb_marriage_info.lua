--结婚信息
local pb_helper = require "PB.pb_helper"
local ECGame = require "Main.ECGame"

local function on_get_marriage_info_result(sender,msg)
	local ECFriendMan = require "Social.ECFriendMan"
	ECFriendMan.Instance():On_GetMarriageInfo(msg)
end 

pb_helper.AddHandler("npt_get_marriage_info_result",on_get_marriage_info_result)


--结婚纪念日通知
local function on_gp_marriage_anniversary(sender,msg)
	warn("marriage_anniversary notify~~~~~~~~~")

	local NotifyReputationChange = require "Event.NotifyReputationChange".NotifyReputationChange
	local hp = ECGame.Instance().m_HostPlayer
	local oldRepu = hp.InfoData.Reputations[REPUID.MARRIAGE_ANNIVERSARY]
	local function onReputationChange(sender,event)
		if event.index == REPUID.MARRIAGE_ANNIVERSARY then
			local newRepu = hp.InfoData.Reputations[REPUID.MARRIAGE_ANNIVERSARY]
	   		if newRepu - oldRepu == 1 then 
	   			warn("empty marriage_anniversary badge")
	   			ECGame.EventManager:removeHandler(NotifyReputationChange, onReputationChange)
	   		end
		end
	end
	ECGame.EventManager:addHandler(NotifyReputationChange, onReputationChange)
end 

pb_helper.AddHandler("gp_marriage_anniversary",on_gp_marriage_anniversary)


--婚礼通知
local function on_npt_wedding_begin_notify(sender,msg)
	warn("wedding begin notify")
	if msg.retcode == 0 then
		--婚礼举办成功
		local ECChatManager = require "Chat.ECChatManager"
		local ECFriendMan = require "Social.ECFriendMan"
		local hp = ECGame.Instance().m_HostPlayer

		local spouse = ECFriendMan.Instance():GetFriend(hp.InfoData.spouse)

		local InstanceCommon = require "Configs.InstanceCommon"
		local commoncfg = InstanceCommon.Instance():GetData(msg.scene_tag)
		local str = StringTable.Get(8776):format(spouse.name,commoncfg.map_name,msg.mirror_id)
		str = str .. ECChatManager.Instance():MakeSceneClient(msg.scene_tag)
	
		local CHAT_CHANNEL_ENUM = _G.CONSTANT_DEFINE.CHAT_CHANNEL_ENUM
		--发送消息至帮派频道
		if hp.InfoData.Faction ~= ZeroUInt64 then
			ECChatManager.Instance():SimpleSendContent(CHAT_CHANNEL_ENUM.CHAT_CHANNEL_FACTION,str,"","")
		end
	else
		FlashTipMan.FlashTip(StringTable.Get(8778):format(msg.retcode))
	end
end

pb_helper.AddHandler("npt_wedding_begin_notify",on_npt_wedding_begin_notify)


--巡游通知
local function on_npt_parading_begin_notify(sender,msg)
	warn("parading begin notify")
	local SCENE_TNPC = --场景ID对应寻路NPC 
	{
		[3] = 10104, 
		[15] = 12499,
		[16] = 12480,
	}

	local NPCId = SCENE_TNPC[msg.scene_tag]
	if not NPCId then
		error("there is no target npc in current scene" ..  msg.scene_tag)
	end

	local ECChatManager = require "Chat.ECChatManager"
	local ECFriendMan = require "Social.ECFriendMan"
	local hp = ECGame.Instance().m_HostPlayer
	--local spouse = ECFriendMan.Instance():GetFriend(hp.InfoData.spouse)
	local targetId = hp.ID == msg.applicant and msg.spouse or msg.applicant
	local target = ECGame.Instance():FindObject(targetId)
	local targetName = target and target.InfoData.Name or ""
	
	local InstanceCommon = require "Configs.InstanceCommon"
	local commoncfg = InstanceCommon.Instance():GetData(msg.scene_tag)
	local paradeName = StringTable.Get(27200 + msg.parade_type)
	local str = StringTable.Get(27290 + msg.parade_type):format(targetName,paradeName,commoncfg.map_name,msg.mirror_id)

	--Make Postion
	local npc_list = require "Configs.npc_list"
	local npc = npc_list:getNPC(NPCId)
	str = str .. ECChatManager.Instance():MakePositionClient(msg.scene_tag,npc.x,npc.z,StringTable.Get(8777))
	local CHAT_CHANNEL_ENUM = _G.CONSTANT_DEFINE.CHAT_CHANNEL_ENUM

	--发送消息至帮派频道
	if hp.InfoData.Faction ~= ZeroUInt64 then
		ECChatManager.Instance():SimpleSendContent(CHAT_CHANNEL_ENUM.CHAT_CHANNEL_FACTION,str,"","")
	end
end

pb_helper.AddHandler("npt_parading_begin_notify",on_npt_parading_begin_notify)


--婚礼抢亲查询通知
local function on_gp_check_wedding_snatch_cond_res(sender,msg)
	warn("on_gp_check_wedding_snatch_cond_res",msg.groom_name,msg.bride_name,msg.timestamp,msg.retcode)
	if msg.retcode == 0 then
		local ECPanelRobSpouse = require "GUI.ECPanelRobSpouse"
		ECPanelRobSpouse.Instance():OpenPanel(function(panel)
			if panel.m_panel then
				panel:setTypeInfo(ECPanelRobSpouse.ROBSPOUSE_TYPE.WEDDING,msg.target_roleid)
				panel:setCouplesName(GameUtil.UnicodeToUtf8(msg.groom_name),GameUtil.UnicodeToUtf8(msg.bride_name))
				panel:setRobTimeStamp(msg.timestamp)
			end
		end)
	elseif msg.retcode == 505 then
		FlashTipMan.FlashTip(StringTable.Get(27287))
	elseif msg.retcode == 436 then
		FlashTipMan.FlashTip(StringTable.Get(27286))
	else
		FlashTipMan.FlashTip(StringTable.Get(27289))
	end
end

pb_helper.AddHandler("gp_check_wedding_snatch_cond_res",on_gp_check_wedding_snatch_cond_res)


--婚礼被抢亲通知
local function on_gp_wedding_snatch_notify(sender,msg)
	--print("on_gp_wedding_snatch_notify")
	FlashTipMan.FlashTip(StringTable.Get(27264):format(GameUtil.UnicodeToUtf8(msg.rival_name)))
end

pb_helper.AddHandler("gp_wedding_snatch_notify",on_gp_wedding_snatch_notify)