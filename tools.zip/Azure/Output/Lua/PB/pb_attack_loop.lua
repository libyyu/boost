--
-- gp_attack_loop
-- 
local pb_helper = require "PB.pb_helper"

local function on_attack_loop( sender,msg )
	local ECGame = require "Main.ECGame"	
	local world = ECGame.Instance().m_CurWorld
	local object_id = GetOldID(msg.object_new_id)
	local object = world:FindObjectOrHost(object_id)
	local target_id = GetOldID(msg.target_new_id)
	if object ~= nil then
		--object.NetHdl:OnPB_AttackLoop(msg.start, msg.skill, target_id)
	end
end

pb_helper.AddHandler("gp_attack_loop",on_attack_loop)