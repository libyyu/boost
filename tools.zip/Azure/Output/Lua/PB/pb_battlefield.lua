local Lplus = require "Lplus"

local pb_helper = require "PB.pb_helper"
local client_msg = require "PB.client_msg"
local ArenaGroupEvents = require "Event.ArenaGroupEvents"
local centerbattlefield = _G.require_config("Configs/centerbattlefield.lua")
---@type ECGame
local ECGame = Lplus.ForwardDeclare("ECGame")
local function handle_error(errorid)
	local msg
	if errorid < 0 then
		errorid = -errorid	--很奇怪，待查
	end
	local pb_error_code = _G.require_config("Configs/pb_error_code.lua")
	msg = pb_error_code[-errorid]
	if msg and string.len(msg) > 0 then
		FlashTipMan.FlashTip(msg)
	end
end

local function on_center_battle_player_apply_re( sender,msg )
	--print("================on_center_battle_player_apply_re retcode:",msg.ret)
	if msg.ret == 0 then
		local ECPanelActivityDate = require "GUI.ECPanelActivityDate"
		ECPanelActivityDate.Instance():DestroyPanel()
		if msg.center_battle_type == 4 then --帮派勇者赛
			local ECPanelFactionHero = require "GUI.ECPanelFactionHero"
			ECPanelFactionHero.Instance():AddSignUpInfo(GameUtil.GetServerGMTTime())
		else
			local name = centerbattlefield[msg.center_battle_type][msg.battle_type].name
			FlashTipMan.FlashTip(string.format(StringTable.Get(19129),name))
			local ECPanelTeamMatchInfo = require "GUI.ECPanelTeamMatchInfo"
			ECPanelTeamMatchInfo.Instance():AddBattleFieldInfo(msg.center_battle_type,msg.battle_type,GameUtil.GetServerGMTTime(),true)
		end


		local ArenaGroupInfoChange = ArenaGroupEvents.ArenaGroupInfoChange
		ECGame.EventManager:raiseEvent(nil, ArenaGroupInfoChange())
	else
		handle_error(msg.ret)
	end
end

local function on_center_battle_player_search_list_re( sender,msg )
	--print("on_center_battle_player_search_list_re")
	local ECPanelTeamMatchInfo = require "GUI.ECPanelTeamMatchInfo"
	ECPanelTeamMatchInfo.Instance():RemoveAllBattleField()
	local hasBattle = false
	for k,v in pairs(msg.infos) do
		if v.battle_type and v.apply_time > 0 then	
			local battle_type = v.battle_type
			local center_battle_type = msg.center_battle_type			
			print("on_center_battle_player_search_list_re",v.battle_type,v.agree_join)
			if v.agree_join > 0 then
				local name = centerbattlefield[center_battle_type][battle_type].name
				MsgBox.ShowMsgBox(nil,string.format(StringTable.Get(19128),name),nil,MsgBox.MsgBoxType.MBBT_OKCANCEL,function(sender,ret)
						if MsgBox.MsgBoxRetT.MBRT_OK == ret then
							local msg = client_msg.npt_center_battle_join_answer()
							msg.center_battle_type = center_battle_type
							msg.battle_type = battle_type
							msg.agree = 1
							pb_helper.Send(msg)
						end
					end)
			else
				hasBattle = true
				ECPanelTeamMatchInfo.Instance():AddBattleFieldInfo(center_battle_type,battle_type,v.apply_time,false)
			end
		end
	end
	if hasBattle then
		local ECPanelActivityDate = require "GUI.ECPanelActivityDate"
		ECPanelActivityDate.Instance():DestroyPanel()
		ECPanelTeamMatchInfo.Instance():ShowPanel(true)
		local ArenaGroupInfoChange = ArenaGroupEvents.ArenaGroupInfoChange
		ECGame.EventManager:raiseEvent(nil, ArenaGroupInfoChange())
	end
end


local function on_center_battle_player_quit_re(sender,msg)
	--print("on_center_battle_player_quit_re retcode:",msg.ret,msg.center_battle_type,msg.battle_type)
	if msg.ret == 0 then
		local ECPanelActivityDate = require "GUI.ECPanelActivityDate"
		ECPanelActivityDate.Instance():DestroyPanel()
		local ECPanelTeamMatchInfo = require "GUI.ECPanelTeamMatchInfo"
		if msg.battle_type > 0 then	
			ECPanelTeamMatchInfo.Instance():RemoveBattleFieldInfo(msg.center_battle_type,msg.battle_type)	
			local name = centerbattlefield[msg.center_battle_type][msg.battle_type].name
			FlashTipMan.FlashTip(string.format(StringTable.Get(19107),name))
		else
			ECPanelTeamMatchInfo.Instance():RemoveAllBattleField()
			FlashTipMan.FlashTip(StringTable.Get(19108))
		end
		local ArenaGroupInfoChange = ArenaGroupEvents.ArenaGroupInfoChange
		ECGame.EventManager:raiseEvent(nil, ArenaGroupInfoChange())
	else
		handle_error(msg.ret)
	end
end

local join_ask_msgbox_id = 0

local function on_center_battle_join_ask(sender,msg)
	local center_battle_type = msg.center_battle_type
	local battle_type = msg.battle_type
	local name = centerbattlefield[center_battle_type][battle_type].name
	MsgBox.ShowMsgBox(nil,string.format(StringTable.Get(19100),name,60),nil,MsgBox.MsgBoxType.MBBT_OKCANCEL,function(sender,ret)
		local msg = client_msg.npt_center_battle_join_answer()
		msg.center_battle_type = center_battle_type
		msg.battle_type = battle_type
		if MsgBox.MsgBoxRetT.MBRT_OK == ret then
			msg.agree = 1
			if center_battle_type == 3 then
				FlashTipMan.FlashTip(StringTable.Get(23030))
			end
		else
			msg.agree = 0
		end
		pb_helper.Send(msg)
		join_ask_msgbox_id = 0
	end,
	60,function (thebox)
		thebox.content = string.format(StringTable.Get(19100),name,thebox.LifeTime)
		thebox:UpdateUI()
		if thebox.LifeTime <= 1 then
			local msg = client_msg.npt_center_battle_join_answer()
			msg.center_battle_type = center_battle_type
			msg.battle_type = battle_type
			msg.agree = 0
			pb_helper.Send(msg)
			join_ask_msgbox_id = 0
		end
	end,Priority.normal,function(thebox)
		join_ask_msgbox_id = thebox.msgboxID
	end)
	local ECPanelTeamMatchInfo = require "GUI.ECPanelTeamMatchInfo"
	ECPanelTeamMatchInfo.Instance():RemoveBattleFieldInfo(center_battle_type,battle_type)	
end

local function on_center_battle_player_punished(sender,msg)
	local name = centerbattlefield[msg.center_battle_type][msg.battle_type].name
	MsgBox.ShowMsgBox(nil,string.format(StringTable.Get(19101),name),nil,MsgBox.MsgBoxType.MBBT_OK)
	if join_ask_msgbox_id > 0 then
		local msgbox = MsgBox.FindBox(join_ask_msgbox_id)
		if msgbox then
			msgbox:onCancle()
		end
		join_ask_msgbox_id = 0
	end
end

local function on_center_battle_end(sender,msg)
	local curWorldTid = ECGame.Instance():GetCurrentWorldTid()
	local ElementData = require "Data.ElementData"
	local instancecfg, configType = ElementData.getConfig(curWorldTid)
	
	
	if instancecfg and configType == _G.CONSTANT_DEFINE.CONFIG_TYPE.CONFIG_INSTANCE then
		-- if instancecfg.instance_class == cfg.INSTANCE_TYPE_ENUM.INSTTYPE_CENTER_BATTLE or instancecfg.instance_class == cfg.INSTANCE_TYPE_ENUM.INSTTYPE_CORPS_CENTER_BATTLE
		-- 	or instancecfg.instance_class == cfg.INSTANCE_TYPE_ENUM.INSTTYPE_QIANKUNJING_BATTLE then
		-- 	local ECPanelBattleFieldBoard = require "GUI.ECPanelBattleFieldBoard"
		-- 	ECPanelBattleFieldBoard.Instance():onBattleResult(msg.battle_result)
		-- elseif instancecfg.instance_class == cfg.INSTANCE_TYPE_ENUM.INSTTYPE_CENTER_ARENA_TEAM_BATTLE then
		-- 	local ECPanelArenaGroupFieldBoard = require "GUI.ECPanelArenaGroupFieldBoard"
		-- 	ECPanelArenaGroupFieldBoard.Instance():onBattleResult(msg.battle_result,msg.players)
		-- end
	end
end
--现在仅用于战队竞技场
local function on_center_battle_prize(sender,msg)
	if msg.prize_type == 5 then
		local ECPanelArenaGroupFieldBoard = require "GUI.ECPanelArenaGroupFieldBoard"
		ECPanelArenaGroupFieldBoard.Instance().m_ScoreChange = msg.prize_value
	end
end

--[[todo:
message gp_update_roam_battle_kill_info
{
	optional S2C_GS_PROTOC_TYPE type    = 1 [ default = type_gp_update_roam_battle_kill_info];
	optional int32 consecutive_kill				= 2;	// 连杀次数
	optional bool first_blood					= 3;	// 是否首杀，客户端特效
	optional int32 end_consecutive_kill			= 4;	// 终结对方连杀次数，客户端特效，跟喊话一致
}]]
local function on_consecutive_kill(sender,msg)
	local ECPanelBattleKill = require "GUI.ECPanelBattleKill"
	ECPanelBattleKill.Instance():Kill(msg.consecutive_kill)
end

local function on_corps_center_battle_begin(sender,msg)
	--print("=============on_corps_center_battle_begin",msg.battle_type)
	---帮派竞赛(跨服)开始
	local battle_type = msg.battle_type
	MsgBox.ShowMsgBox(nil,string.format(StringTable.Get(battle_type == 4 and 19117 or 19127),60),nil,MsgBox.MsgBoxType.MBBT_OKCANCEL,function(sender,ret)
		if MsgBox.MsgBoxRetT.MBRT_OK == ret then
			if battle_type == 4 then
				local ECPanelFactionHero = require "GUI.ECPanelFactionHero"
				ECPanelFactionHero.Instance():SendEnterBattle()
			elseif battle_type == 5 then
				local ECPanelCityBattle = require "GUI.ECPanelCityBattle"
				ECPanelCityBattle.Instance():SendEnterBattle(false)
			end
		end
	end,
	60,function (thebox)
		thebox.content = string.format(StringTable.Get(battle_type == 4 and 19117 or 19127),thebox.LifeTime)
		thebox:UpdateUI()	
	end)
end

pb_helper.AddHandler("npt_center_battle_player_apply_re", on_center_battle_player_apply_re)
pb_helper.AddHandler("npt_center_battle_player_search_list_re", on_center_battle_player_search_list_re)
pb_helper.AddHandler("npt_center_battle_player_quit_re", on_center_battle_player_quit_re)
pb_helper.AddHandler("npt_center_battle_join_ask", on_center_battle_join_ask)
pb_helper.AddHandler("npt_center_battle_player_punished", on_center_battle_player_punished)
pb_helper.AddHandler("gp_center_battle_end", on_center_battle_end)
pb_helper.AddHandler("gp_center_battle_prize", on_center_battle_prize)
pb_helper.AddHandler("gp_update_roam_battle_kill_info", on_consecutive_kill)
pb_helper.AddHandler("npt_corps_center_battle_begin", on_corps_center_battle_begin)