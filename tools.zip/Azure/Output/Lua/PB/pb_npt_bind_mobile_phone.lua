--- pb_npt_bind_mobile_phone
--- Generate by IntelliJ IDEA
--- Create by lidengfeng
--- DateTime: 2022/6/20 10:26
---
local pb_helper = require "PB.pb_helper"

pb_helper.AddHandler("npt_bind_mobile_phone", function(_, msg)
	require "ProxySDK.ECUniSDK".Instance():SyncBindMobilePhoneInfo(msg)
end)