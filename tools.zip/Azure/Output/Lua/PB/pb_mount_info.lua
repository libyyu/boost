local pb_helper = require "PB.pb_helper"
local client_msg = require "PB.client_msg"
local ECMountMan = require "Mount.ECMountMan"
local ECMountNPC = require "NPCs.ECMountNPC"

local function on_mount_notify(sender, msg)
    ECMountMan.Instance():OnMountNewInfo(msg)
end
pb_helper.AddHandler("gp_mount_notify", on_mount_notify)

local function on_mount_catch_info(sender, msg)
    local ECCatchHorseManager = require "Mount.ECCatchHorseManager"
    local mount_name = ECMountMan.GetMountConfigName(msg.mount_tid)
    local MountsConfig = _G.GetConfigLua("Configs/mount/mount_cfg.lua")

    local function sync_alert()
        local speed = 0
        if msg.alert > 0 then
            local cfg = ECMountMan.GetMountConfig(msg.mount_tid)
            if cfg then
                local threshold = cfg.alert_critical[2]
                if threshold and threshold > 0 then
                    local ratio = msg.alert / threshold
                    for _, v in ipairs(MountsConfig.radar_speed) do
                        if ratio >= v.ratio then
                            speed = v.speed
                        else
                            break
                        end
                    end
                end
            end
        end

        local ECPanelMountRadarIns = require("Mount.ECPanelMountRadar").Instance()
        --local old_speed = ECPanelMountRadarIns:GetAnimSpeed()
        ECPanelMountRadarIns:SetAnimSpeed(speed)
        --[[
        if old_speed <= 0 and speed > 0 then
            FlashTipMan.FlashTip(StringTable.Get(2033):format(mount_name))
        end
        ]]
    end

    local function sync_disapper_pos()
        local obj = globalGame:FindObject(msg.mount_id)
        if obj and obj:is(ECMountNPC) then
            obj:SetLeavePos(msg.disapper_pos)
        end
    end

    local function clear_all_alert_cycle()
        local obj = globalGame:FindObject(msg.mount_id)
        if obj and obj:is(ECMountNPC) then
            obj:RemoveAllAlertCycle(0)
        end
    end

    --local VEHICLE_EVENT_TYPE = client_msg.VEHICLE_EVENT_TYPE
    if msg.event_type == VEHICLE_EVENT_TYPE.VET_WILD_SCARE then
        sync_alert()
        sync_disapper_pos()
        clear_all_alert_cycle()
        FlashTipMan.FlashTip(StringTable.Get(2034):format(mount_name))
    elseif msg.event_type == VEHICLE_EVENT_TYPE.VET_ALERT_CHANGE then
        print_catchHorse("on_mount_catch_info", msg)
        sync_alert()
    elseif msg.event_type == VEHICLE_EVENT_TYPE.VET_GET_ON then
        clear_all_alert_cycle()
    elseif msg.event_type == VEHICLE_EVENT_TYPE.VET_QTE_RET then
        ---@type ECPlayer
        local player = globalGame:FindObjectOrHost(msg.player_id)
        if player then
            local is_host = false
            local hp = globalGame:GetHostPlayer()
            if hp and hp.ID == player.ID then
                is_host = true
            end

            if is_host then
                ECCatchHorseManager.Instance():StopSequence(msg.is_qte_success)
            end

            local FSMPlayerEmotion = require "FSM.PlayerFSM.FSMPlayerEmotion"
            local state = player:GetCurrentState()
            if state and state:is(FSMPlayerEmotion) then
                state:StopLoop()
            end

            if msg.is_qte_success then
                local mount = player:GetMountNpc()
                if mount then
                    mount:SetMasterId(player.ID)
                end
            else
                require("Emotion.ECEmotionMan").Instance():TryPlayPlayerEmotion(player, 5)
                if is_host then
                    FlashTipMan.FlashTip(StringTable.Get(2035):format(mount_name))
                end
            end
        end

        if not msg.is_qte_success then
            sync_disapper_pos()
        end
    elseif msg.event_type == VEHICLE_EVENT_TYPE.VET_ALERT_TIP then
        FlashTipMan.FlashTip(StringTable.Get(2033):format(mount_name))
    end
end
pb_helper.AddHandler("gp_mount_catch_info", on_mount_catch_info)

local ERROR_CODE = require "PB.error_code".ERROR_CODE

local function on_mount_operation_ret(sender, msg)
    local OP_TYPE = client_msg.gp_mount_operation.OP_TYPE
    if msg.ret == 0 then
        if msg.op == OP_TYPE.MOT_CATCH_GET_ON_LOCK then
            local obj = globalGame:FindObject(msg.value)
            if obj and obj:is(ECMountNPC) then
                ECMountMan.Instance():RideMount(obj)
            end
        elseif msg.op == OP_TYPE.MOT_ACTIVE_PROP then --激活属性
            ECMountMan.Instance():OnActiveMount(msg.value)
            FlashTipMan.FlashTipByStrID(1995)
        elseif msg.op == OP_TYPE.MOT_RENAME then
			FlashTipMan.FlashTipByStrID(1998)
		end
		
    else
        --warn("mount operation failed, op = " .. msg.op .. ", ret = " .. msg.ret)
        if msg.op == OP_TYPE.MOT_CATCH_GET_ON_LOCK then
            local obj = globalGame:FindObject(msg.value)
            if obj and obj:is(ECMountNPC) then
                local mount_name = ECMountMan.GetMountConfigName(obj.m_mountTid)
                FlashTipMan.FlashTip(StringTable.Get(1981):format(mount_name))
            end
		elseif msg.op == OP_TYPE.MOT_RENAME then
			if msg.ret == ERROR_CODE.ERROR_DIRTY_FILTER then
				FlashTipMan.FlashTip(StringTable.Get(1996))
			else
				FlashTipMan.FlashTip(StringTable.Get(1999))
			end
        end
    end
end
pb_helper.AddHandler("gp_mount_operation_ret", on_mount_operation_ret)

--- @param msg pb.Message.PB.gp_vehicle_pos_notify
local function on_gp_vehicle_pos_notify(sender, msg)
    ECMountMan.OnVehiclePositionNotify(msg)
end
pb_helper.AddHandler("gp_vehicle_pos_notify", on_gp_vehicle_pos_notify)