local pb_helper = require "PB.pb_helper"
local ECGame = require "Main.ECGame"
local StringTable = require "Data.StringTable"
local ECChatManager = require "Chat.ECChatManager"
local ECTaskUtility = require "Task.ECTaskUtility"
local ECTaskDef = require "Task.ECTaskDef"
local ECTaskInterface = require "Task.ECTaskInterface"
local CHAT_CHANNEL_ENUM = _G.CONSTANT_DEFINE.CHAT_CHANNEL_ENUM
local _warn = _G.GetModuleLog("entrust_task")
--[[
--帮派求助
--2016/1/7
local function on_faction_task_help_msg(sender,msg)
	local taskid = msg.taskid
	local roleid = msg.roleid
	local roleName = msg.name
	--print(string.format("---taskid:%d\nroleid:%s\nroleName:%s",taskid,LuaUInt64.ToString(roleid),GameUtil.UnicodeToUtf8(roleName)))
	local TaskMethodEnum = ECTaskDef.TaskMethodEnum
	local taskMethod = TaskMethodEnum.KillNumMonster
	local taskName = ECTaskUtility.FormatTaskBaseName(taskid)
	local taskView = ECTaskInterface.Instance():GetTaskView(taskid)
	if taskView then
		taskMethod = taskView.method	
	end

	local taskHelpStr = ECChatManager.Instance():MakeTaskHelp(roleid, GameUtil.UnicodeToUtf8(roleName), taskName, taskid, taskMethod)
	--ECChatManager.Instance():AddSimpleMessage(taskHelpStr, CHAT_CHANNEL_ENUM.CHAT_CHANNEL_NATION)
	ECChatManager.Instance():AddSimpleMessage(taskHelpStr, CHAT_CHANNEL_ENUM.CHAT_CHANNEL_FACTION)
end 
pb_helper.AddHandler("npt_faction_task_help_msg",on_faction_task_help_msg)
]]
--组队寻宝委托任务相关
--拉取npc和任务库刷新到的任务
local function on_task2client_lib_data(sender,msg)
	_warn("on_task2client_lib_data msg : ", msg)
	local ECEntrustTaskMan = require "Entrust.ECEntrustTaskMan"
	ECEntrustTaskMan.Instance():OnTask2ClientLibData(msg)
end

local TaskEvents = require "Event.TaskEvents"
ECGame.EventManager:addHandler(TaskEvents.TaskStateChangeEvent, function (sender, event)
	local taskId = event.taskId
	local oldState, newState = event.lastState, event.newState
	require "GUI.Task.FEPanelTaskAdventureBegin".Instance():OnTaskStateChangeEvent(event)
	require "GUI.Task.FEPanelTaskMapShow".Instance():OnTaskStateChangeEvent(event)
end)
pb_helper.AddHandler("task2client_lib_data",on_task2client_lib_data)