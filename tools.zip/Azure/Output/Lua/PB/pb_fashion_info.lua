local Lplus = require "Lplus"

local pb_helper = require "PB.pb_helper"
local ECGame = require "Main.ECGame"

--local ECUserBaby = require "Utility.ECUserBaby"
--local ECPanelPartnerSpeak = require "GUI.ECPanelPartnerSpeak"


--
-- gp_fashion_info
--

--[[
local near_expire_note = {}

local function decodeColorInfo(FashionInfo, detail)
    local colors = FashionInfo.colors
    if not colors then
      colors = {}
    end
    --print("decodeColorInfo,detail.colors,#detail.part_color_hsv",detail.fashion_index,detail.colors,#detail.part_color_hsv)

    if detail.colors then
      local oct = Octets.Octets()
      oct:replace(detail.colors)
      
      colors.size = oct:size() * 8
      colors.max_size = detail.color_limit
      colors.info = oct
    end
    FashionInfo.colors = colors

    local part_hsv = FashionInfo.part_hsv
    if not part_hsv then
      part_hsv = {}
    end
    if detail.part_color_hsv then
      for i = 1,#detail.part_color_hsv do
        part_hsv[i] = {}
        for j = 1,FASHION_COLOR_MAX do
          local hsv = detail.part_color_hsv[i]["color_hsv"..tostring(j)]
          if hsv then
            part_hsv[i][j] = hsv
          end
        end
      end
    end
    FashionInfo.part_hsv = part_hsv
end]]

local function on_gp_fashion_info(sender, msg)

end

pb_helper.AddHandler("gp_fashion_info", on_gp_fashion_info)

local function on_gp_active_fashion(sender, msg)
end
pb_helper.AddHandler("gp_active_fashion", on_gp_active_fashion)

local function on_gp_select_fashion_result(sender, msg)

end
pb_helper.AddHandler("gp_select_fashion_result", on_gp_select_fashion_result)

local function on_gp_mult_select_fashion_result(sender, msg)

end
pb_helper.AddHandler("gp_mult_select_fashion_result", on_gp_mult_select_fashion_result)

local function on_gp_active_fashion_color_result(sender, msg)  

end
pb_helper.AddHandler("gp_active_fashion_color_result", on_gp_active_fashion_color_result)

local function on_gp_paint_fashion_result(sender, msg)

end
pb_helper.AddHandler("gp_paint_fashion_result", on_gp_paint_fashion_result)

local function on_gp_mult_paint_fashion_result(sender, msg)
end
pb_helper.AddHandler("gp_mult_paint_fashion_result", on_gp_mult_paint_fashion_result)

local function on_gp_fashion_expire(sender, msg)

end
pb_helper.AddHandler("gp_fashion_expire", on_gp_fashion_expire)

local function on_gp_fashion_renew(sender, msg)
end
pb_helper.AddHandler("gp_fashion_renew", on_gp_fashion_renew)


local function on_gp_extend_fashion_color_limit_result(sender, msg)

end
pb_helper.AddHandler("gp_extend_fashion_color_limit_result", on_gp_extend_fashion_color_limit_result)

local function on_gp_boardcast_fashion_change(sender, msg)
end
pb_helper.AddHandler("gp_boardcast_fashion_change", on_gp_boardcast_fashion_change)