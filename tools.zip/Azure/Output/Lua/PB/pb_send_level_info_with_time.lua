
--2015年10月18日
--Wang Yinliang
--
-- 守卫家园monster信息
-- gp_send_level_info_with_time
-- 
local Lplus = require "Lplus"
local pb_helper = require "PB.pb_helper"
---@type ECGame
local ECGame = Lplus.ForwardDeclare("ECGame")

local function on_faction_war(sender, msg)
	local hp = ECGame.Instance().m_HostPlayer
	if hp == nil then return end

	local instQuitShow = _G.GetConfigLua "Configs/instance_quit_show.lua"
	local curWorldTid = require "Instance.FEInstanceMan".Instance():GetCurrentInstanceTid()
	local ECFactionWarMan = require "Main.ECFactionWarMan"
	local ECZoneInfoMan = require "Main.ECZoneInfoMan"
	if instQuitShow.InstEight[curWorldTid] ~= nil then  --八阵图
		--require "GUI.ECPanelInstanceEightCrack".ECPanelEightNavition.Instance():ShowPanel(msg.info[1])
	elseif curWorldTid == 4919 then
		--warn(" send level info with time on_faction_war->msg ", msg)
		--require "GUI.ECPanelInstanceSelfChallengeInfo".Instance():ShowPanel(true, msg)
	elseif hp.Faction ~= nil then
		hp.Faction:SetDefenceInfo(msg)
		require "GUI.ECPanelFactionDefence".Instance():UpdateDefence()
	end
end

local function on_send_level_info_with_time( sender,msg )
	--warn("on_send_level_info_with_time",msg)
	local ECFactionWarMan = require "Main.ECFactionWarMan"
	on_faction_war(sender, msg) 
end
pb_helper.AddHandler("gp_send_level_info_with_time", on_send_level_info_with_time)


local function gp_level_object_info( sender,msg )
	
end
pb_helper.AddHandler("gp_level_object_info", gp_level_object_info)
