local Lplus = require "Lplus"
local pb_helper = require "PB.pb_helper"
local client_msg = require "PB.client_msg"

---@type ECGame
local ECGame = Lplus.ForwardDeclare("ECGame")

----
--变身
--
local function on_player_transform (sender, msg)
	warn("-------on_player_transform-----------", msg.tid, LuaUInt64.ToString(msg.roleid))
	local game = ECGame.Instance()
	local world = game.m_CurWorld
	local host = game.m_HostPlayer
	if msg.roleid == host.ID then
		host:AddModelRealLoadedCallback(function ()
			host:OnObjectTransform(msg.tid)
		end)
	else
		local player = ECGame.Instance().m_CurWorld.m_PlayerMan:GetElsePlayer(msg.roleid)
		if player then
			player:AddModelRealLoadedCallback(function ()
				player:OnObjectTransform(msg.tid)
			end)
		end
	end

	if msg:HasField("thrower_npc_pos") then
		-- local FEThrowerManager = require "Thrower.FEThrowerManager"
		-- local thrower_pos = _G.D3DPosToVector3(msg.thrower_npc_pos)
		-- FEThrowerManager.Instance():SetThrowerPos(thrower_pos)
	end
end
pb_helper.AddHandler("gp_transform_state", on_player_transform)


--聊天装饰相关信息
local function on_player_chat_decoration(sender,msg)
	--warn("=============on_player_chat_decoration:", msg)
	local hp = ECGame.Instance().m_HostPlayer
	if hp then
		hp:OnChatDecInfoChange(msg)
	end
end
pb_helper.AddHandler("gp_selected_chat_decoration", on_player_chat_decoration)


-- 玩家社交信息
local function on_gp_player_facebook(sender, msg)
	require("Players.ECHostFacebookMan").ECHostFacebookMan.Instance():UpdateHostFacebook(msg)
end
pb_helper.AddHandler("gp_player_facebook", on_gp_player_facebook)

--属性称号信息
pb_helper.AddHandler("gp_active_title_info_s2c", function(sender, msg)
	local hp = ECGame.Instance().m_HostPlayer
	if not hp then return end

	hp.InfoData.AttribActiveTitleID = msg.info.cur_addon_title_id

	local PlayerTitleUpdateEvent = require "Event.PlayerTitleUpdateEvent".TitleListUpdateEvent
	local e = PlayerTitleUpdateEvent()
	e.roleid = hp.ID
	ECGame.EventManager:raiseEvent(nil, e)
end)

local function Fast_lshift1(idx)
	return bit.lshift(1, idx)
end

--开关相关信息
local function on_switch_data(sender,msg)
	local hp = ECGame.Instance().m_HostPlayer
	if not hp then return end

	hp.InfoData.Switches = {}
	for i,v in ipairs(msg.data) do
		local oct = Octets.Octets()
		oct:replace(v.data)
		local os = OctetsStream.OctetsStream2(oct)

		local tmpTable = {}
		for i=1,#v.data do
			local tmp = os:unmarshal_byte()
			tmpTable[i - 1] = tmp
		end

		hp.InfoData.Switches[v.switch_type] = tmpTable
	end

	--local NotifySwitcherInit = require "Event.NotifyReputationChange".NotifySwitcherInit
	--local event = NotifySwitcherInit()
	--ECGame.EventManager:raiseEvent(nil, event)
end
pb_helper.AddHandler("gp_switch_data", on_switch_data)

--开关相关信息
local function on_switch_change(sender,msg)
	local hp = ECGame.Instance().m_HostPlayer
	if not hp then return end

	local index1 = math.floor(msg.index / 8)
	local index2 = msg.index % 8

	local data
	if hp.InfoData.Switches then
		hp.InfoData.Switches[msg.switch_type] = hp.InfoData.Switches[msg.switch_type] or {}
		data = hp.InfoData.Switches[msg.switch_type][index1] or 0

		hp.InfoData.Switches[msg.switch_type][index1] = msg.open and bit.bor(data, Fast_lshift1(index2)) or bit.band(data, bit.bnot(Fast_lshift1(index2)))
	else
		warn("on_switch_change: hp.InfoData.Switches is NIL!")
	end

	--local NotifySwitcherChange = require "Event.NotifyReputationChange".NotifySwitcherChange
	--local event = NotifySwitcherChange()
	--event.switchType = msg.switch_type
	--event.index = msg.index
	--event.open = msg.open
	--ECGame.EventManager:raiseEvent(nil, event)
end
pb_helper.AddHandler("gp_switch_change", on_switch_change)

-- 个人矿显隐
---@param sender any
---@param msg pb.Message.PB.gp_personal_mine_data_notify
local function on_personal_mine_data_notify(sender, msg)
	warn("gp_personal_mine_data_notify ", msg)
	local hp = ECGame.Instance().m_HostPlayer
	if not hp then return end

	if msg.ot == client_msg.gp_personal_mine_data_notify.OpType.OT_ALL then
		hp.InfoData.PersonalMineHideMap = {}
		for _, mine_info in ipairs(msg.op_data_list) do
			hp.InfoData.PersonalMineHideMap[mine_info.mine_id] = mine_info.switch_state_timeout
		end
	elseif msg.ot == client_msg.gp_personal_mine_data_notify.OpType.OT_ADD then
		for _, mine_info in ipairs(msg.op_data_list) do
			hp.InfoData.PersonalMineHideMap[mine_info.mine_id] = mine_info.switch_state_timeout
		end
	elseif msg.ot == client_msg.gp_personal_mine_data_notify.OpType.OT_DELETE then
		for _, mine_info in ipairs(msg.op_data_list) do
			hp.InfoData.PersonalMineHideMap[mine_info.mine_id] = nil
		end
	end

	local matterMan = globalGame:GetMatterMan()
	if matterMan then
		matterMan:RefreshPersonalMineHideStatus(true)
	end
end
pb_helper.AddHandler("gp_personal_mine_data_notify", on_personal_mine_data_notify)

-- 阶段矿
---@param sender any
---@param msg pb.Message.PB.gp_stage_mine_data_notify
local function on_stage_mine_data_notify(sender, msg)
	--print("on_stage_mine_data_notify", msg)

	local hp = ECGame.Instance().m_HostPlayer
	if not hp then return end

	if msg.ot == client_msg.gp_stage_mine_data_notify.OpType.OT_ALL then
		hp.InfoData.StageMineData = {}
		for tid, stage in pairs(msg.stagemine_stage_data_list) do
			local data = {}
			data.cur_stage = stage.curr_stage_id
			data.has_tickets = stage.has_tickets
			hp.InfoData.StageMineData[tid] = data
		end
	elseif msg.ot == client_msg.gp_stage_mine_data_notify.OpType.OT_ADD then
		for tid, stage in pairs(msg.stagemine_stage_data_list) do
			local data = {}
			data.cur_stage = stage.curr_stage_id
			data.has_tickets = stage.has_tickets
			hp.InfoData.StageMineData[tid] = data
		end
	elseif msg.ot == client_msg.gp_stage_mine_data_notify.OpType.OT_POPBOX then
		local mine_tid, stage_data = next(msg.stagemine_stage_data_list)
		local curr_stage_id = stage_data.curr_stage_id
		local ECPanelRepairBlackStone = require "Interact.ECPanelRepairBlackStone"
		local function onChoose(bOK)
			if bOK then
				---@type pb.Message.PB.gp_stage_mine_req
				local msg2 = client_msg.gp_stage_mine_req()
				msg2.ot = client_msg.gp_stage_mine_req.OpType.OT_ENTER_INSTANCE_POPBOX
				msg2.mine_tid = mine_tid
				msg2.mine_stage_index = stage_data.curr_stage_id
				msg2.cancel_enter = false
				pb_helper.Send(msg2)
				warn("gp_stage_mine_req ", msg2)
				require "BehaviorRecords.BehaviorRecordsManager".Instance():RecordBehavior("StageMineReq", 
					{ ot = msg2.ot, mine_tid = msg2.mine_tid,mine_stage_index = msg2.mine_stage_index, cancel_enter = msg2.cancel_enter})
			end
		end
		local ECTreasureMan = require "Main.ECTreasureMan"
		local isTreasure, storeId = ECTreasureMan.Instance():CheckBlackStone(mine_tid)
		if isTreasure then
			require "GUI.Treasure.ECPanelTreasureRepairBlackStone".Instance():Popup(storeId, mine_tid, onChoose)
		else
			ECPanelRepairBlackStone.Instance():SetStageIndex(curr_stage_id)
			ECPanelRepairBlackStone.PopupByMatterTid(mine_tid, onChoose)
		end
	elseif msg.ot == client_msg.gp_stage_mine_data_notify.OpType.OT_INVITED then
		local tid, stage_data = next(msg.stagemine_stage_data_list)
		-- 检查等级限制
		local ElementData = require "Data.ElementData"
		local mineConfig = ElementData.getNpc(tid)
		if mineConfig ~= nil then
			---@type pb.Message.PB.StageMineConfig
			local stageConfig = ElementData.getDataByConfigType(_G.CONSTANT_DEFINE.CONFIG_TYPE.CONFIG_STAGEMINE_CONFIG, mineConfig.stagemine_stage_id)
			if stageConfig ~= nil and stageConfig.stage_cfg_list ~= nil then
				local hostPlayer = globalGame:GetHostPlayer()
				local stageData = stageConfig.stage_cfg_list[stage_data.curr_stage_id + 1]
				if hostPlayer ~= nil and stageData ~= nil and hostPlayer:GetLevel() < stageData.req_level then
					FlashTipMan.FlashTipByStrID(108005)
					return
				end
			end
		end
		local _tip = StringTable.Get(16558):format(30)
		MsgBox.ShowMsgBox(nil, _tip,nil, MsgBoxType.MBBT_OKCANCEL,function(sender, ret)
			---@type pb.Message.PB.gp_stage_mine_req
			local msg2 = client_msg.gp_stage_mine_req()
			msg2.ot = client_msg.gp_stage_mine_req.OpType.OT_ENTER_INSTANCE_INVITED
			msg2.mine_tid = tid
			msg2.mine_stage_index = stage_data.curr_stage_id
			if MsgBoxRetT.MBRT_OK == ret then
				msg2.cancel_enter = false
			else
				msg2.cancel_enter = true
			end
			pb_helper.Send(msg2)
		end,30,function(thebox)
			if thebox.LifeTime <= 0 then
				---@type pb.Message.PB.gp_stage_mine_req
				local msg2 = client_msg.gp_stage_mine_req()
				msg2.ot = client_msg.gp_stage_mine_req.OpType.OT_ENTER_INSTANCE_INVITED
				msg2.mine_tid = tid
				msg2.mine_stage_index = stage_data.curr_stage_id
				msg2.cancel_enter = true
				pb_helper.Send(msg2)
			else
				local desc = StringTable.Get(16558):format(thebox.LifeTime)
				thebox:SetText(desc)
			end
		end)
	elseif msg.ot == client_msg.gp_stage_mine_data_notify.OpType.OT_REFUSE or msg.ot == client_msg.gp_stage_mine_data_notify.OpType.OT_LEVEL_ERR then
		local member = require "Social.ECTeam".ECTeamMan.Instance():GetMemberByID(msg.roleid)
		if member ~= nil then
			local prompt = nil
			if msg.ot == client_msg.gp_stage_mine_data_notify.OpType.OT_REFUSE then
				prompt = StringTable.Get(1044):format(member.Name)
			else
				prompt = member.Name .. StringTable.Get(108005)
			end
			FlashTipMan.FlashTip(prompt)
		end
	end

	local matterMan = globalGame:GetMatterMan()
	if matterMan then
		matterMan:RefreshStageMineStatus()
	end
end
pb_helper.AddHandler("gp_stage_mine_data_notify", on_stage_mine_data_notify)