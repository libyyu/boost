--[[
	似乎已废弃
]]

--更换装备
--gp_equip_change
--
local pb_helper = require "PB.pb_helper"
local ECGame = require "Main.ECGame"

local IvtrUpdateEvent = require "Event.IvtrUpdateEvent"

local function send_inventory_update_event(id, updateType, updateInfo)
	local event = IvtrUpdateEvent()
	event.InventoryId = id
	event.m_UpdateType = updateType
	event.m_UpdateInfo = updateInfo
	ECGame.EventManager:raiseEvent(nil, event)
end

local function on_change_equip_suit_result(sender,msg)
	if msg.result then
		local hp = ECGame.Instance().m_HostPlayer
		if hp then
			--print("--@@@@@@@@@@@@@@@@@------ on_change_equip_suit_result: ", msg.equip_location)
			hp.Package.ActiveEquipIndex = msg.equip_location

			send_inventory_update_event(hp.Package.ActiveEquipIndex, IvtrUpdateEvent.UPDATETYPE.CHANGE_SUIT, nil)

			local ECPanelInventory = require "GUI.ECPanelInventory"
			if ECPanelInventory.Instance():IsVisible() then
				ECPanelInventory.Instance():Update()
			end
		end
	end
end

pb_helper.AddHandler("gp_change_equip_suit_result",on_change_equip_suit_result)

local function on_self_equip_suit(sender,msg)
	local hp = ECGame.Instance().m_HostPlayer
	if hp then
		--print("--@@@@@@@@@@@@@@@@@------ on_self_equip_suit: ", msg.equip_location)
		hp.Package.ActiveEquipIndex = msg.equip_location
	end
end

pb_helper.AddHandler("gp_self_equip_suit",on_self_equip_suit)