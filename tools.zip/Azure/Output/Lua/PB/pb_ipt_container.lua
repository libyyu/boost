local Lplus = require "Lplus"

local client_msg = require "PB.client_msg"
local pb_helper = require "PB.pb_helper"
local ECGame = require "Main.ECGame"

local function on_gp_ipt_container(sender, msg)
	-- warn(msg.corps_info,#msg.corps_info,LuaUInt64.ToString(msg.corps_info.roleid),"帮派数据有变化",LuaUInt64.ToString(msg.corps_info.money), LuaUInt64.ToString(msg.corps_info.contribution)) 
	local hp = ECGame.Instance().m_HostPlayer
	local ID = hp.ID
	local faction = hp.Faction
	
	if ID == msg.corps_info.roleid then
		--local oldValue = faction._factionmoney
		local newValue = tonumber(LuaUInt64.ToString(msg.corps_info.money))
		if newValue > 0  then
			FlashTipMan.FlashTip(StringTable.Get(2123):format(newValue))
		end
		--oldValue = faction._factioncontribution
		newValue = tonumber(LuaUInt64.ToString(msg.corps_info.contribution))
		if newValue > 0  then
			FlashTipMan.FlashTip(StringTable.Get(2124):format(newValue))
		end
	end
end

pb_helper.AddHandler("gp_ipt_container", on_gp_ipt_container)