--生物矿刷新模板 是否开启
local pb_helper = require "PB.pb_helper"
local client_msg = require "PB.client_msg"

local function on_gp_spawner_query_resp(sender, msg)
    --warn("on_gp_spawner_query_resp", msg)
    require "Main.ECItemLinkNpcListMarkMan".Instance():UpdateSpawnerState(msg.res_list)
end
pb_helper.AddHandler("gp_spawner_query_resp", on_gp_spawner_query_resp)