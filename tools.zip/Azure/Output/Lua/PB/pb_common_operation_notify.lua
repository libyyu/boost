local pb_helper = require "PB.pb_helper"
local ECTagMan = require "GUI.ECTagMan"
local client_msg = require "PB.client_msg"
local ECGame = require "Main.ECGame"
---@param msg pb.Message.PB.gp_common_operation_notify
local function on_common_operation_notify(sender, msg)
    local ECPeopleLotteryMan = require "Main.ECPeopleLotteryMan"
    local client_msg = require "PB.client_msg"
    local OP_TYPE = client_msg.gp_common_operation_notify.OP_TYPE
    local OP_RET_CODE = client_msg.gp_common_operation_notify.OP_RET_CODE
    if msg.ret_code ~= OP_RET_CODE.RET_SUCCESS then
        warn("gp_common_operation_notify", msg.ret_code, msg.op)

        local ERROR_CODE = require "PB.error_code".ERROR_CODE
        if msg.ret_code > ERROR_CODE.PB_ERROR_BEGIN then
            FlashTipMan.FlashTipByPBErrorCode(msg.ret_code)
        end
        return
    end
    if msg.op == OP_TYPE.OP_CLIENT_AUTO_FIGHT then  --自动战斗
        -- 现在只以队长的战斗状态决定队员是否自动战斗
        --local ECHostAutoFightManager = require "Players.ECHostAutoFightManager"
        --ECHostAutoFightManager.Instance():updateAutoStateByLeader(msg.oper_roleid , msg.open)
    elseif msg.op == OP_TYPE.OP_RUSH then  --疾跑
        if msg.open == false then
            local hp = ECGame.Instance().m_HostPlayer
            if hp and hp:IsDashState() then
                hp:StopDash()
            end
        end
    elseif msg.op == OP_TYPE.OP_RETURN_LASTPOS_INFO then --通知脱离地宫的传送场景
        if msg.ret_code == 0 then
            print(LuaInt64.ToDouble(msg.param), msg.pos.x, msg.pos.y, msg.pos.z)
            require "IGU.ECIGUSceneHelper".OnRecvRestroomTargetSceneInfo(msg)
        else
            print("common_operation_notify error code:" .. msg.ret_code)
        end
    elseif msg.op == OP_TYPE.OP_MINIPACK_LACK_SCENE then --通知客户端缺少场景资源需下载
        local sceneId = LuaInt64.ToDouble(msg.param)
        require "IGU.ECIGUSceneHelper".PromptDownloadOnMatchInstance(sceneId, function () end)
    elseif msg.op == OP_TYPE.OP_GET_FAKE_RANDOM_DATA then
        local dcId = LuaInt64.ToDouble(msg.params[1] or ZeroInt64)
        local drawnCount = LuaInt64.ToDouble(msg.params[2] or ZeroInt64)
        ECPeopleLotteryMan.Instance():OnDrawProtectData(dcId, drawnCount, msg.fake_random_data)
    elseif msg.op == OP_TYPE.OP_DIAMOND_WISH_GET_DATA then
        local UISubPanelWelfareDiamondWish = require "GUI.Welfare.WelfareDiamondWish.UISubPanelWelfareDiamondWish"
        UISubPanelWelfareDiamondWish.Instance():UpdateDataFormMsg(msg.diamond_wish_data)

    elseif msg.op == OP_TYPE.OP_SAILING_LUCKY_DRAW_GET_DATA then

        --print_jzw("OP_SAILING_LUCKY_DRAW_GET_DATA",msg)
        print_wyl("----------OP_SAILING_LUCKY_DRAW_GET_DATA--------", LuaInt64.ToDouble(msg.param), msg.param2, msg.sailing_lucky_draw)
        local ECNavigationNewManager = require "GUI.Main.ECNavigationNewManager"
        ECNavigationNewManager.Instance():OnSailingLuckyDataEx(msg)

        local reward_tid = LuaInt64.ToDouble(msg.params[1] or ZeroInt64) 

        local ECNavigationEvent = require "Event.ECNavigationEvent"
        local event = ECNavigationEvent()
        event.op = msg.param2
        event.tid = LuaInt64.ToDouble(msg.param)
        event.reward_tid = reward_tid
        ECGame.EventManager:raiseEvent(nil, event)

    elseif msg.op == OP_TYPE.OP_BACKLOGIN_SIGNIN_INFO then --回归签到
        --print_wyl("----------OP_BACKLOGIN_SIGNIN_INFO--------", msg.open, msg.backlogin_signin)
        require "GUI.Main.ECBackFlowMan".Instance():OnSignDataNotify(msg.open, msg.backlogin_signin)

        local ECBackFlowEvent = require "Event.ECBackFlowEvent"
        ECGame.EventManager:raiseEvent(nil, ECBackFlowEvent())
        
    end
end
pb_helper.AddHandler("gp_common_operation_notify", on_common_operation_notify)