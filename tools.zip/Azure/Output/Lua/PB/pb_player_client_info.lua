local pb_helper = require "PB.pb_helper"
local Lplus = require "Lplus"
---@type ECGame
local ECGame = Lplus.ForwardDeclare("ECGame")
local ECElsePlayer = require "Players.ECElsePlayer"

local function on_gp_client_info_re(sender, msg)
    local player = ECGame.Instance():FindObject(msg.role_id)

    --print_jzw("on_gp_client_info_re",LuaUInt64.ToString(msg.role_id))
    if player and player:is(ECElsePlayer) then
        player:AddModelRealLoadedCallback(function(callerObj)
            player:OnClientInfoChange(msg)
        end)
    end

    --for _, v in pairs(msg.info) do
    --    if v.key == PlayerClientInfoType.HideBackWeapon then
    --        print_jzw("HideBackWeapon")
    --    end
    --end
end

pb_helper.AddHandler("client_info_re", on_gp_client_info_re)