local Lplus = require "Lplus"

local pb_helper = require "PB.pb_helper"
local ECGame = require "Main.ECGame"

--
-- gp_auto_reward_list
--
-- 充值奖励通知协议，目前包括：月卡、累冲
local function on_auto_reward_list(sender, msg)
	--print_hsh("on_auto_reward_list",msg)
	local function func()
		--[[
		local flag = false
		local reward_item = nil
		local reward_weak = nil
		local reward_nation_war = nil
		local reward_nation_war_free = nil
		local reward_server_open = nil
		local reward_online = nil
		local reward_QQRight_event_flag = 0 --QQ特权礼包标记
		local reward_QQRight_auto_get_flag = 0 --QQ特权新手礼包 腾讯平台 IOS自动领取标记
		local limitPackageInfo = {}
		]]--

		local rewardItem = ECGame.Instance().m_HostPlayer.InfoData.RewardItem

		local reward_monthly_card = nil				-- 月卡
		local reward_monthly_card_super = nil		-- 超级月卡
		local reward_first_cumulative_recharge = nil				-- 首次累计充值

		for _, v in pairs(msg.entry) do
			--print("......",v.type, v.reward,v.data and LuaUInt64.ToDouble(v.data) or "")
			local reward = rewardItem[v.type]
			if not reward and v.type then
				rewardItem[v.type] = {}
				rewardItem[v.type].type = v.type
			end
			if v.type then
				rewardItem[v.type].reward = v.reward
				rewardItem[v.type].data = v.data
			end

			--签到功能开放，并且当天没有签到，弹出签到界面
			--[[
			if v.type == REWARDS_TYPE.CHECKIN then
				reward_item = v
			elseif v.type == REWARDS_TYPE.REWARD_WEAK then
				reward_weak = v
			elseif v.type == REWARDS_TYPE.ACTIVITY_DAY then
				--warn("reward:",v.reward)
				local CanGetActivityRewardEvent = require "Event.NotifyReputationChange".CanGetActivityRewardEvent
				local p = CanGetActivityRewardEvent()
				if v.reward ~= 0 then
					p.m_Hint = 1
				else
					p.m_Hint = -1
				end
				ECGame.EventManager:raiseEvent(nil, p)
			elseif v.type == REWARDS_TYPE.REWARD_NATION_WAR then
				reward_nation_war = v
			elseif v.type == REWARDS_TYPE.REWARD_NATION_WAR2 then
				reward_nation_war_free = v
			elseif v.type == REWARDS_TYPE.SERVER_OPEN then
				reward_server_open = v
				ECGame.Instance().m_CurOpenTime = Time.realtimeSinceStartup
			elseif v.type == REWARDS_TYPE.ONLINE then
				reward_online = v
				--local ol_seconds
				--ol_seconds, _= LuaUInt64.GetHighAndLow(v.data)
				--print("ol_seconds = " .. ol_seconds)
				ECGame.Instance().m_CurLoginTime = Time.realtimeSinceStartup
			elseif v.type == REWARDS_TYPE.REWARD_QQ_VIP_FRESHMAN then --qq会员新人礼包
				reward_QQRight_event_flag = 1
				reward_QQRight_auto_get_flag = reward_QQRight_auto_get_flag + 1
			elseif v.type == REWARDS_TYPE.REWARD_QQ_VIP_RECHARGE then --qq会员续费礼包
				reward_QQRight_event_flag = 1
			elseif v.type == REWARDS_TYPE.REWARD_QQ_SVIP_FRESHMAN then --qq超级会员新人礼包
				reward_QQRight_event_flag = 1
				reward_QQRight_auto_get_flag = reward_QQRight_auto_get_flag + 2
			elseif v.type == REWARDS_TYPE.REWARD_QQ_SVIP_RECHARGE then --qq超级会员续费礼包
				reward_QQRight_event_flag = 1
			elseif v.type == REWARDS_TYPE.REWARD_NIGHT then -- 晚间活动
				-- 接受晚间活动事件
				local NightRewardEvent = require "Event.NightRewardEvent"
				local ECNightRewardUtils = require "Utility.ECNightRewardUtils".Instance()
				local event = NightRewardEvent()
				local high, low = LuaUInt64.GetHighAndLow(v.data)
				ECNightRewardUtils.nightRewardClaimed = low == 0
				ECGame.EventManager:raiseEvent(nil, event)
				--elseif v.type >= REWARDS_TYPE.REWARD_MIDAS_REWARD1 and v.type <= REWARDS_TYPE.REWARD_MIDAS_REWARD4 then
				--	table.insert(limitPackageInfo,v)
			end
			]]--
			if v.type == REWARDS_TYPE.MONTH_CARD_NORMAL then 			-- 普通月卡
				reward_monthly_card = v
			elseif v.type == REWARDS_TYPE.MONTH_CARD_SUPER then 		-- 超级月卡
				reward_monthly_card_super = v
			elseif v.type == REWARDS_TYPE.FIRST_CUMULATIVE_RECHATGE then 	-- 首次累计充值
				reward_first_cumulative_recharge = v
			end
		end
		
		
		ECGame.Instance().m_HostPlayer.InfoData.RewardItem = rewardItem

		local NotifyAutoReward = require "Event.NotifyAutoReward"
		local p = NotifyAutoReward()
		p.result = msg.entry
		ECGame.EventManager:raiseEvent(nil, p)	
		
		
		--TODO:SHOW UI
		--[[
		local week = 0 --周1到周7
		local check_count = 0 --签到次数
		local can_got = false --是否可以领取
		local can_checkin = false --签到
		local can_week = false --周末领奖
		if reward_item ~= nil then
			can_checkin = reward_item.reward > 0
			check_count = LuaUInt64.ToDouble(reward_item.data)
		end
		if reward_weak and reward_weak.data then
			week = LuaUInt64.ToDouble(reward_weak.data)
			can_week = week >5 and reward_weak.reward > 0 --当为周末类型时候，reward_weak.data为周几
		end
		can_got = can_checkin or can_week
		]]--

		--print_hsh("reward_monthly_card  ",reward_monthly_card,reward_monthly_card.reward)
		--[[ 福利里的不再需要了
		if reward_monthly_card then
			if reward_monthly_card.reward and reward_monthly_card.reward ~= 0 then
				require("GUI.Welfare.UIPanelWelfareMain").Instance():ShowWithTargetTabName("NormalMonthlyCard")
			end
			require "GUI.Welfare.IAPCoupon.MonthlyCard.UIMonthlyCardNormal".Instance():UpdateUI()
		end

		--print_hsh("reward_monthly_card_super  ",reward_monthly_card_super,reward_monthly_card_super.reward)
		if reward_monthly_card_super then
			if reward_monthly_card_super.reward and reward_monthly_card_super.reward ~= 0 then
				require("GUI.Welfare.UIPanelWelfareMain").Instance():ShowWithTargetTabName("SuperMonthlyCard")
			end
			require "GUI.Welfare.IAPCoupon.MonthlyCard.UIMonthlyCardSuper".Instance():UpdateUI()
		end

		if reward_first_cumulative_recharge then
			require "GUI.Welfare.IAPCoupon.FirstCharge.UIFirstCharge".Instance():UpdateUI()
		end
		]]--
		if reward_monthly_card or reward_monthly_card_super then
			local UIPanelPreferenceMonthlyCard = require "GUI.Mall.Preference.UIPanelPreferenceMonthlyCard".Instance():UpdateUI()
		end

		--[[
		local ECFunctionUnlock = require "Guide.ECFunctionUnlock"
		local isrewardregisterOpen = ECFunctionUnlock.IsUnlocked("rewardregister")
		local nowtime = os.date("*t", GameUtil.GetServerGMTTime())
		local year,month,day = nowtime.year,nowtime.month,nowtime.day

		if curInstanceId == 0 then --副本不提示						
			-------签到
			local ECPanelReward = require "GUI.ECPanelReward"
			--print("-------- ",year,month,day,ECPanelReward.Instance():IsTheSameDate(year,month,day))
			local lv = ECGame.Instance().m_HostPlayer.InfoData.Lv
			if isrewardregisterOpen and can_got and not ECPanelReward.Instance():IsTheSameDate(year,month,day) then
				ECPanelReward.Instance():AutoPopPanel(function(panel)
					if panel then
						panel:SwitchPage(ECPanelReward.SUBPAGE.DAY_ACTIVITY_ACHIEVEMENT)
						-- if can_checkin and can_week then 
						-- 	FlashTipMan.FlashTip(StringTable.Get(2701))
						-- elseif can_checkin then
						-- 	FlashTipMan.FlashTip(StringTable.Get(2702))
						-- elseif can_week then
						-- 	FlashTipMan.FlashTip(StringTable.Get(2703))
						-- end
						panel:UpdateCheckinDay(year,month,day)
						panel.mbJustOpened = true --已经打开过签到界面
					end
				end)
			end
		end]]

		-------开服大礼登录弹出
		--[[ 目前没有该功能
		local curInstanceId = require "Instance.FEInstanceMan".Instance():GetCurrentInstanceTid()
		if curInstanceId == 0 then --副本不提示	
			--
			local ECFunctionUnlock = require "Guide.ECFunctionUnlock"
			local l_allConfigs = ECFunctionUnlock.GetAllConfigs()
			local isrewardOpen = ECFunctionUnlock.IsUnlocked("rewardopen_new")
			--
			local isrewardOpen = false
			local hp = ECGame.Instance().m_HostPlayer
			for function_name, config in pairs(l_allConfigs) do
				if function_name == "rewardopen_new" then
					if hp.InfoData.Lv >= config.condition.value then
						isrewardOpen = true
					end
				elseif function_name == "rewardregister" then
					if hp.InfoData.Lv >= config.condition.value then
						isrewardregisterOpen = true
					end
				end
			end

			local nowtime = os.date("*t", GameUtil.GetServerGMTTime())
			local year,month,day = nowtime.year,nowtime.month,nowtime.day
			local ECPanelRewardOpen = require "GUI.ECPanelRewardOpen"
			local ECGUIGroupSetMain = require "GUI.ECGUIGroupSetMain"

			if ECPanelRewardOpen.CanGetReward() and not ECPanelRewardOpen.Instance():IsTheSameDate(year,month,day) and isrewardOpen  then
				ECPanelRewardOpen.Instance():RequestAutoPopup(function(panel)
					--panel:ShowPanel()
					--panel:UpdateCheckinDay(year,month,day)
				end)
			elseif ECPanelRewardOpen.IsCanShowCheckIn(isrewardOpen) then
				local ECPanelReward = require "GUI.ECPanelReward"
				--print("-------- ",year,month,day,ECPanelReward.Instance():IsTheSameDate(year,month,day))
				if isrewardregisterOpen and can_got and not ECPanelReward.Instance():IsTheSameDate(year,month,day) then
					ECPanelReward.Instance():RequestAutoPopup(function(panel)
						if panel then
							panel:SwitchPage(ECPanelReward.SUBPAGE.REGISTER)
							panel:UpdateCheckinDay(year,month,day)
							panel.mbJustOpened = true --已经打开过签到界面
						end
					end)
				end
			end
		end
		]]--
	end
	--确保 m_HostPlayer创建完成
	ECGame.Instance():OnHostPlayerCreate(func)
end
pb_helper.AddHandler("gp_auto_reward_list", on_auto_reward_list)

