--生物矿刷新模板 是否开启
local pb_helper = require "PB.pb_helper"
local client_msg = require "PB.client_msg"

local function on_gp_star_travel_info(sender, msg)
    --warn("on_gp_star_travel_info", msg) 
    local WelfareStarTaskTravelManager = require "GUI.Welfare.StarTaskTravel.WelfareStarTaskTravelManager"
    WelfareStarTaskTravelManager.Instance():OnStarTravelInfoNotify(msg.info)
end
pb_helper.AddHandler("gp_star_travel_info", on_gp_star_travel_info)