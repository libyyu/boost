
--2015年3月24日
--Wang Yinliang
--
-- 闯天关
-- type_gp_climb_tower
-- 
local pb_helper = require "PB.pb_helper"
local ECGame = require "Main.ECGame"
--local ClimbTowerChangeEvent = require "Event.ClimbTowerChangeEvent"

--[[
	enum CLIMB_OP {
		CO_MANUAL_FIGHT		= 1;	//手动挑战
		CO_AUTO_FIGHT_BEGIN	= 2;	//自动挑战开始
		CO_AUTO_FIGHT_RUSH	= 3;	//自动挑战加速
		CO_AUTO_FIGHT_STOP	= 4;	//自动挑战停止
		CO_AUTO_FIGHT_AWARD	= 5;	//自动挑战领奖
		CO_RESET		= 6;		//重置挑战
	}
--]]

local GETREWARD_ST = 3  --领奖状态

local function on_climb_tower( sender,msg )
	-- local ECPassMan = require "Social.ECPassMan"
	-- local climb_tower = ECPassMan.Instance()

	-- climb_tower.max_tower_lvl   = msg.max_tower_lvl			--最高挑战关卡
	-- climb_tower.cur_tower_lvl   = msg.cur_tower_lvl			--当前挑战关卡
	-- --climb_tower.reset_times     = msg.reset_times			--可用重置次数
	-- climb_tower.is_auto_running = msg.is_auto_running		--是否自动挑战中
	-- climb_tower.auto_begin_time = msg.auto_begin_time		--自动挑战开始时间
	-- climb_tower.auto_begin_lvl  = msg.auto_begin_lvl		--自动挑战开始关卡
	-- climb_tower.auto_reward_begin = msg.auto_reward_begin	--自动挑战奖励开始关卡
	-- climb_tower.auto_reward_end   = msg.auto_reward_end		--自动挑战奖励结束关卡
	-- climb_tower.auto_cur_lvl   = msg.auto_cur_lvl			--自动挑战当前关卡

	-- climb_tower:SetClimbTower( msg.level4shopid )

	-- --print("type_gp_climb_tower",msg.max_tower_lvl,msg.cur_tower_lvl,msg.is_auto_running
	-- --	,msg.auto_begin_time,msg.auto_begin_lvl,msg.auto_reward_begin,msg.auto_reward_end,msg.auto_cur_lvl)

	-- local event = ClimbTowerChangeEvent()
	-- ECGame.EventManager:raiseEvent(nil, event)

	-- --是否领奖状态
	-- --local ECPanelPass = require "GUI.ECPanelPass"
	-- local bFlag = climb_tower:GetPassState() == GETREWARD_ST 
	-- if bFlag then
	-- 	local ECBlessingMan = require "Blessing.ECBlessingMan"
	-- 	ECBlessingMan.Instance():AddClimbTower(nil)
	-- end

end

pb_helper.AddHandler("gp_climb_tower", on_climb_tower)
