local pb_helper = require "PB.pb_helper"

-- --
-- --npt_req_backflow_data_re  回归好友信息  回归好友个数 领取回归好友个数奖励状态 
-- --
-- local function on_npt_req_anniversary_all_data_re(sender,msg)

-- 	local AnniversaryAllDataEvt = require "Event.AnniversaryEvent".AnniversaryAllDataEvt
-- 	local ECGame = require "Main.ECGame"
-- 	local event = AnniversaryAllDataEvt()
-- 	-- 设置值 

-- 	ECGame.EventManager:raiseEvent(nil, event)
-- end
-- pb_helper.AddHandler("npt_req_anniversary_all_data_re", on_npt_req_anniversary_all_data_re)

-- --
-- --on_npt_req_anniversary_data_re 祭祀回调
-- --
-- local function on_npt_req_anniversary_data_re(sender,msg)
-- 	local AnniversaryEvt = require "Event.AnniversaryEvent".AnniversaryEvt
-- 	local ECGame = require "Main.ECGame"
-- 	local event = AnniversaryEvt()
-- 	event.errorcode = msg.errorcode
-- 	ECGame.EventManager:raiseEvent(nil, event)
-- end
-- pb_helper.AddHandler("npt_req_anniversary_data_re",on_npt_share_backflow_code_re)

-- --
-- --npt_help_country_re 助回调 
-- --
-- local function on_npt_help_country_re(sender,msg)
-- 	local HelpCountryEvt = require "Event.AnniversaryEvent".HelpCountryEvt
-- 	local ECGame = require "Main.ECGame"
-- 	local event = HelpCountryEvt()
-- 	event.rewardIndex = msg.index
-- 	event.errorcode = msg.errorcode
-- 	ECGame.EventManager:raiseEvent(nil, event)
-- end
-- pb_helper.AddHandler("npt_help_country_re", on_npt_help_country_re)
