local pb_helper = require "PB.pb_helper"
local ECGame = require "Main.ECGame"
local HostReviveInfoEvent = require "Event.HostReviveInfoEvent"
local ECHostReviveInfo = require "Players.ECHostReviveInfo"

local _warn = _G.GetModuleLog("revive")
local function on_gp_revive_times_info(sender, msg )
	_warn("on_gp_revive_times_info", msg)
	local ECPanelRevive = require "GUI.ECPanelRevive"
	ECHostReviveInfo.Instance():SetReviveTimesInfo(msg)
	ECGame.EventManager:raiseEvent(nil, HostReviveInfoEvent())
end

pb_helper.AddHandler("gp_revive_times_info", on_gp_revive_times_info)

local function on_gp_inst_revive_data(sender, msg)
	local FEPanelSceneGuide = require "GUI.FEPanelSceneGuide"
	_warn("on_gp_inst_revive_data", msg)
	local ECPanelRevive = require "GUI.ECPanelRevive"
	ECHostReviveInfo.Instance():SetInstanceReviveData(msg)
	ECGame.EventManager:raiseEvent(nil, HostReviveInfoEvent())
end

pb_helper.AddHandler("gp_inst_revive_data", on_gp_inst_revive_data)