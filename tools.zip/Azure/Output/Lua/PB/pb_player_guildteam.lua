local pb_helper = require "PB.pb_helper"
local ECPlayerGuildTeamMan = require "Social.ECPlayerGuildTeamMan"
local UIPlayerGuildTeamCreate = require "GUI.GuildTeam.UIPlayerGuildTeamCreate"
local ECPanelPlayerGuildTeamMain = require "GUI.GuildTeam.ECPanelPlayerGuildTeamMain"
local ECPanelPlayerGuildTeamList = require "GUI.GuildTeam.ECPanelPlayerGuildTeamList"
local ECSubPanelPlayerGuildTeamApplication = require "GUI.GuildTeam.ECSubPanelPlayerGuildTeamApplication"
local ERROR_CODE = require "PB.error_code".ERROR_CODE
local ECBlockManager = require "Home.Misc.ECBlockManager"

local function on_gp_player_group_state(sender, msg)
    -- 家园街区
    if msg.group_type == _G.CONSTANT_DEFINE.PLAYER_GROUP_TYPE.PGTT_HOME_STREET then
        ECBlockManager.Instance():OnHomeBlockMessage(msg)
        return
    end
    local ECPlayerGuildTeamManIns = ECPlayerGuildTeamMan.Instance()
    local gp_player_group_op = pb_helper.GetCmdClass("gp_player_group_op")
    local gp_player_group_state = pb_helper.GetCmdClass("gp_player_group_state")
    if msg.type == gp_player_group_state.SYNC_DATA then
        ECPlayerGuildTeamManIns:UpdatePlayerGuildTeamData(msg.data)
    elseif msg.type == gp_player_group_state.EVENT then
        ECPlayerGuildTeamManIns:UpdatePlayerGuildTeamByEvent(msg.events)
    elseif msg.type == gp_player_group_state.RETCODE then
        if msg.retcode == 0 then    -- 操作成功
            if msg.ret_op == gp_player_group_op.CREATE then
                ECPlayerGuildTeamManIns:UpdatePlayerGuildTeamData(msg.data)
                FlashTipMan.FlashTip(StringTable.Get(77448))

                if UIPlayerGuildTeamCreate.Instance():IsValid() then
                    UIPlayerGuildTeamCreate.Instance():DestroyPanel()
                end
                ECPanelPlayerGuildTeamMain.Instance():ShowPanel(true, nil, nil)
            elseif msg.ret_op == gp_player_group_op.APPLY then
                ECPlayerGuildTeamManIns:UpdateRequestItemApplyState(msg.events.event_id)
            elseif msg.ret_op == gp_player_group_op.RESPONSE_APPLY then
                ECPlayerGuildTeamManIns:UpdatePlayerGuildTeamData(msg.data)
                FlashTipMan.FlashTip(StringTable.Get(77449))
            elseif msg.ret_op == gp_player_group_op.RESPONSE_INVITE then
                ECPlayerGuildTeamManIns:UpdatePlayerGuildTeamData(msg.data)
                ECPanelPlayerGuildTeamMain.Instance():ShowPanel(true, nil, nil)
            end
        else
            warn("player guildteam operation failed! op = " .. msg.ret_op .. ", err = " .. msg.retcode)

            if msg.ret_op == gp_player_group_op.APPLY then
                if msg.retcode == ERROR_CODE.MEMBERS_IS_FULL and ECPanelPlayerGuildTeamList.Instance():SetApplyRespondedFlag() then
                    FlashTipMan.FlashTip(StringTable.Get(77440))
                end
            elseif msg.ret_op == gp_player_group_op.RESPONSE_APPLY then
                if msg.retcode == ERROR_CODE.MEMBERS_IS_FULL and ECSubPanelPlayerGuildTeamApplication.Instance():SetAgreeRespondedFlag() then
                    FlashTipMan.FlashTip(StringTable.Get(77426))
                end
            elseif msg.ret_op == gp_player_group_op.CREATE then
                if msg.retcode == 172 then    -- 重名
                    FlashTipMan.FlashTip(StringTable.Get(77414))
                elseif msg.retcode == ERROR_CODE.NOT_TEAM_LEADER then
                    FlashTipMan.FlashTip(StringTable.Get(77450))
                elseif msg.retcode == ERROR_CODE.ERROR_DIRTY_FILTER then
                    FlashTipMan.FlashTip(StringTable.Get(77413))
                end
            end
        end
    elseif msg.type == gp_player_group_state.LIST then
        ECPlayerGuildTeamManIns:UpdateRequestListData(msg)
    end
end
pb_helper.AddHandler("gp_player_group_state", on_gp_player_group_state)

local function on_gp_player_group_notify(sender, msg)
    local ECGame = require "Main.ECGame"
    local obj = ECGame.Instance():FindObject(msg.roleid)
    if obj then
        obj.InfoData.idGuildTeam = msg.group_id
        obj.InfoData.GuildTeamPos = msg.group_pos
        obj.InfoData.GuildTeamName = msg.group_name
        if obj.Pate then
            obj.Pate:UpdateGuildFlag(obj)
        end
    end
end
pb_helper.AddHandler("gp_player_group_notify", on_gp_player_group_notify)