-- pb_team_cross_server 跨服组队相关协议

local Lplus = require "Lplus"
local pb_helper = require "PB.pb_helper"
---@type ECGame
local ECGame = Lplus.ForwardDeclare("ECGame")


-- 修改协议，不再使用
local function on_gp_level_raid_team(sender,msg)
	print_hsh("on_gp_level_raid_team   ",msg)
	--local TeamMgr = require "Social.ECTeam".ECTeamMan.Instance()
	--TeamMgr:CreateCrossServerGroup(msg.raid_info)
end
pb_helper.AddHandler("gp_level_raid_team", on_gp_level_raid_team)

--[[ 挪个位置
local function on_gp_fake_level_team_s2c(sender,msg)
	--print_hsh("on_gp_fake_level_team_s2c   ",msg)
	--local TeamMgr = require "Social.ECTeam".ECTeamMan.Instance()
	--TeamMgr:OnCrossServerMsg(msg)
end
pb_helper.AddHandler("gp_fake_level_team_s2c", on_gp_fake_level_team_s2c)
]]--

-- 老项目错误码返回协议？
-- 给服务器做个提示
local function on_npt_response(sender,msg)
	print_hsh("on_npt_response   ",msg)
	if msg.retcode ~= 0 then
		FlashTipMan.FlashTipByPBErrorCode(msg.retcode)
		if _G.IgnoreInstanceCheck then 		-- 副本调试用，暂时加个限制
			local str = "type["..tostring(msg.request_type).."]retcod["..tostring(msg.retcode).."]param["..tostring(msg.param1).."]["..LuaUInt64.ToString(msg.param2).."]["..msg.param3.."]"
			FlashTipMan.FlashTip(str)
		end
	end
end
pb_helper.AddHandler("npt_response", on_npt_response)