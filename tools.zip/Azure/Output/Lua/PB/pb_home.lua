local Lplus = require "Lplus"
local pb_helper = require "PB.pb_helper"

local _warn = _G.GetModuleLog("home")

---@type ECGame
local ECGame = Lplus.ForwardDeclare("ECGame")

local function gp_home_op_res(sender, msg)
	_warn("gp_home_op_res", msg)

	local ECHomeManager = require "Home.ECHomeManager"
	ECHomeManager.Instance():on_hometown_op(msg)
end
pb_helper.AddHandler("gp_home_op_res",gp_home_op_res)

local function gp_home_scene_info(_, msg) 
	local ECHomeDynamicNPCPosData = require "Home.Misc.ECHomeDynamicNPCPosData"
	ECHomeDynamicNPCPosData.Get():S2CPosInfo(msg)
end
pb_helper.AddHandler("gp_home_scene_info", gp_home_scene_info)
