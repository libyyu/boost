--- pb_npc_service
--- Generate by IntelliJ IDEA
--- Create by lidengfeng
--- DateTime: 2021/3/11 19:44
---

local pb_helper = require "PB.pb_helper"

--pb_helper.AddHandler("gp_npc_service_data", function(_, msg)
--    print_ldf("gp_npc_service_data", msg)
--
--    local hp = globalGame:GetHostPlayer()
--    if hp then
--        hp:UpdateNPCServiceData(msg)
--    end
--end)

pb_helper.AddHandler("gp_npc_service_op_rep", function(_, msg)
    print_ldf("gp_npc_service_op_rep", msg)

    if msg.ret ~= 0 then

    else
        local hp = globalGame:GetHostPlayer()
        if hp then
            hp:UpdateNPCService(msg.npc_id, msg.service_id, msg.service_data)
        end
    end
end)

pb_helper.AddHandler("gp_npc_service_op_broadcast", function(_, msg)
    print_ldf("gp_npc_service_op_broadcast", msg)

    local world = globalGame:GetCurWorld()
    if world then
        ---@type ECPlayer
        local obj = world:FindObjectOrHost(msg.object_id)
        if obj and obj:IsPlayer() then
            obj:UpdateNPCService(msg.npc_id, msg.service_id, msg.service_data)
        else
            warn("failed to find player:", LuaUInt64.ToString(msg.object_id))
        end
    end
end)