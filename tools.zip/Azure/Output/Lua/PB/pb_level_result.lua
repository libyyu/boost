
--2015年3月7日
--Wang Yinliang
--
local Lplus = require "Lplus"
---@type ECGame
local ECGame = Lplus.ForwardDeclare("ECGame")
local pb_helper = require "PB.pb_helper"

--[[
	optional int32 result				= 2 [ default = 0 ];	// 0 falied 1 success
--]]

local function on_level_result(sender, msg)
	print_wyl("gp_level_result", msg.result)

	local FEInstanceMan = require "Instance.FEInstanceMan"
	FEInstanceMan.Instance():OnLevelResult(msg)
end

pb_helper.AddHandler("gp_level_result", on_level_result)


local function on_level_emotion_list(sender, msg)
	local ECPanelLevelAction = require "GUI.Social.ECPanelLevelAction"
	ECPanelLevelAction.Instance():ShowPanel(msg.enable, { emotion_list = msg.emotion_list },nil)
end
pb_helper.AddHandler("gp_level_emotion_list", on_level_emotion_list)
