--首充双倍
local pb_helper = require "PB.pb_helper"
local ECChargeData = require "Data.ECChargeData"

--[[

message npt_pixiu_buy_records{
    option (npt_type) = NPT_RESET_DOUBLERECHAGE;
	int64 roleid			= 2;    //角色id
	repeated pixiu_service_buy_record record= 3;	//购买次数处理首次双倍
	int64 firstbuy_sn		= 4 [(Default64) =0 ]; //用户的首冲序列号
	int64 system_firstbuy_sn	= 5 [(Default64) =0 ];//系统的首冲序列号
	bool reset_doublecharge	= 6 [(DefaultBool)= false ];//1是否全部显示双倍充值
}

--]]

local function on_first_double_charge( sender, msg )
	print_wyl("on_first_double_charge: ", msg)

	ECChargeData.Instance():SetDoubleChargeData(msg)

	--require "GUI.Mall.ECPanelRecharge".Instance():UpdateRecharge()
end

--pb_helper.AddHandler("npt_pixiu_buy_records", on_first_double_charge)