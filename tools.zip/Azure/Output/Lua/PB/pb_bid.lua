local pb_helper = require "PB.pb_helper"
local client_msg = require "PB.client_msg"

---@param msg pb.Message.PB.gp_auction_op_res
local function on_gp_auction_op_res(sender, msg)
	local ECBidMan = require "Main.ECBidMan"
	ECBidMan.Instance():OnBidOperation(msg)
end

pb_helper.AddHandler("gp_auction_op_res", on_gp_auction_op_res)