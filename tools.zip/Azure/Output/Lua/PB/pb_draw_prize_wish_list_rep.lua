local pb_helper = require "PB.pb_helper"

local function on_gp_draw_prize_wish_list_rep(sender, msg)
    local ECPeopleLotteryMan = require "Main.ECPeopleLotteryMan"
    ECPeopleLotteryMan.Instance():OnResponseWishList(msg)
end
pb_helper.AddHandler("gp_draw_prize_wish_list_rep", on_gp_draw_prize_wish_list_rep)