local Lplus = require "Lplus"

local pb_helper = require "PB.pb_helper"

local function on_player_list_info(sender, msg)
	--print("on_player_list_info",msg)
	local ECPlayerProfileCache = require "Main.ECPlayerProfileCache"
	ECPlayerProfileCache.Instance():RespondFightCapacity(msg)

	local PlayerListInfoEvt = require "Event.PlayerListInfoEvt"
	local ECGame = require "Main.ECGame"
	local p = PlayerListInfoEvt.new()
	p.msg = msg
	ECGame.EventManager:raiseEvent(nil, p)
end

pb_helper.AddHandler("gp_player_list_info", on_player_list_info)

local function on_facelift_result(sender, msg)
	require "GUI.CustomFace.UICustomFaceReshape".Instance():OnReshapeResult(msg)
end

pb_helper.AddHandler("gp_facelift_result", on_facelift_result)
