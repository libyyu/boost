local pb_helper = require "PB.pb_helper"


local function on_npt_get_battle_match_rank( sender,msg )
	local ECPvPArenaData = require "Data.ECPvPArenaData"
	local ArenaData = ECPvPArenaData.Instance() 
	ArenaData:SetRankNum(msg)
end
pb_helper.AddHandler("npt_get_battle_match_rank", on_npt_get_battle_match_rank)