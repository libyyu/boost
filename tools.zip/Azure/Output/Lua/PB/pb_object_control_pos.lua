local Lplus = require "Lplus"

local pb_helper = require "PB.pb_helper"
local ECGame = require "Main.ECGame"

local function on_gp_object_control_pos(sender, msg)
	local hp = ECGame.Instance().m_HostPlayer
	if not hp then return end
	
	if msg.id == hp.ID then
		hp:ResetCtrlBySkill(msg.pos)
	else
		local ECObject = require "Object.ECObject"
		local object = ECGame.Instance():FindObject(msg.id)
		if object and object:is(ECObject) then
			object:ResetCtrlBySkill(msg.pos)
		end
	end
end

pb_helper.AddHandler("gp_object_control_pos", on_gp_object_control_pos)