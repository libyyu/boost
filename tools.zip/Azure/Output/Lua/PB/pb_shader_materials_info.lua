local pb_helper = require "PB.pb_helper"
local ECGame = require "Main.ECGame"

-- 怪物部位材质修改
---@param msg pb.Message.PB.gp_shader_materials_info
local function on_gp_shader_materials_info( sender,msg )
	local npc =  ECGame.Instance().m_CurWorld.m_NPCMan:GetNPC(msg.npc_id)
	if npc ~= nil and npc.NetHdl ~= nil then
		npc.NetHdl:OnCmd_updateGfxMaterial(msg.mask)
	end
end
pb_helper.AddHandler("gp_shader_materials_info", on_gp_shader_materials_info)