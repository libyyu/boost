local Lplus = require "Lplus"
local pb_helper = require "PB.pb_helper"

---@param msg pb.Message.PB.gp_sothoth_tower_data
local function on_sothoth_tower_data(sender, msg)
	require "Instance.ECSothothTowerManager".Instance():OnReceivedTowerData(msg)
end
pb_helper.AddHandler("gp_sothoth_tower_data", on_sothoth_tower_data)

