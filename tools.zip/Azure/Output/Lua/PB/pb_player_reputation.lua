-- 声望
-- pb_player_reputation
-- 
local pb_helper = require "PB.pb_helper"
local Lplus = require "Lplus"

---@type ECGame
local ECGame = Lplus.ForwardDeclare("ECGame")

local hdConfig = _G.GetConfigLua("Configs/HumanDignityCfg.lua")

local function on_msg(sender, msg)
	local hp = ECGame.Instance().m_HostPlayer
	if hp == nil then
		warn("******** on_gp_player_reputation hp == nil ")
		return
	end
	local ECPlayerReputationInfo = require("Object.ECObjectInfo").ECPlayerReputationInfo

	local bInit = table.size(hp.InfoData.Reputations) == 0
	local loveRepuID, cfgLove
	if not bInit then
		local mall_preference_cfg = _G.GetConfigLua("Configs/mall_preference_cfg.lua")
		cfgLove = mall_preference_cfg.Love
		loveRepuID = cfgLove.repuID
	end

	for repuID, repu in pairs(msg.info) do
		local playerReputationInfo = hp.InfoData.Reputations[repuID]
		local oldValue = 0
		local diff = 0
		if(playerReputationInfo == nil)then
			playerReputationInfo = ECPlayerReputationInfo()
			hp.InfoData.Reputations[repuID] = playerReputationInfo
			playerReputationInfo.ID = repuID
		else
			oldValue = playerReputationInfo:GetValue()
		end
		--warn("******** on_gp_player_reputation repuID(" .. repuID .. ") value(" .. repu.value .. ") beyond_limit_value(" .. repu.beyond_limit_value .. ")" )

		playerReputationInfo.value				= repu.value;
		playerReputationInfo.beyond_limit_value = repu.beyond_limit_value;
		playerReputationInfo.day_value			= repu.day_value;
		playerReputationInfo.week_value			= repu.week_value;
		playerReputationInfo.month_value		= repu.month_value;
		playerReputationInfo.last_modify_time	= repu.last_modify_time;

		diff = playerReputationInfo:GetValue() - oldValue;

		local ReputationCfg = require("Configs.ReputationCfg")

		local defaultTipFunc = function()
			local repuCfg = ReputationCfg.GetRepuCfg(repuID)
			if(repuCfg ~= nil)then
				--warn("******** on_gp_player_reputation repuID , value , show_tips , beyond_limit_value", repuID , repuCfg.name,msg.change_type,repuCfg:NeedShowTips(),repuCfg.hide_as_reward, repuCfg.show_tips , repu.value,repu.beyond_limit_value)
				if repuCfg:NeedShowTips() then
					--warn("******** on_gp_player_reputation diff", diff)
					--warn("******** on_gp_player_reputation repuID , value , beyond_limit_value", repuID , repuCfg.name , repu.value,repu.beyond_limit_value)
					if not repuCfg.hide_as_reward then
						local ECChatHandle = require "Chat.ECChatHandle"
						local ECChatManager = require "Chat.ECChatManager"
						local ECChatUtility = require "Chat.ECChatUtility"
						local chatHandle = ECChatHandle.Instance()
						if diff > 0 then
							local str
							if repuID == 8 then
								str = StringTable.Get(100013):format(diff, repuCfg.name)
							else
								str = StringTable.Get(100011):format(diff, repuCfg.name)
 							end
							if msg.change_type ~= 49 then		-- 如果是随时间恢复则不显示
								_G.FlashTipMan.FlashRegionTip(str)
								if repuCfg.item_tid > 0 then
									local ECRewardHandle = require "Utility.ECRewardHandle"
									ECRewardHandle.Instance():HandleIncItemTip(0 , 0 , repuCfg.item_tid , diff, "reputation:" .. repuID)
								end
							end
							if str and repuID ~= 2155 then --星能提示不再这里进行同步了
								local richStr =  ECChatUtility.GenerateRichText(str,nil)
								if repuCfg.icon ~= 0 then
									local iconPath = datapath.GetPathByID(repuCfg.icon)
									richStr = chatHandle:MakeReputationImg("inc_repuImg_0" , iconPath, 32 , -6) .. richStr
								end
								local ECMsgInfo = require "Chat.ECMsgInfo"
								ECChatManager.Instance():AddSimpleMessageWithType(str, richStr, _G.CONSTANT_DEFINE.CHAT_CHANNEL_ENUM.CHAT_CHANNEL_SYSTEM, ECMsgInfo.MSG_TYPE.SYSTEM, "")
								--ECChatManager.Instance():AddSimpleMessage2(str , richStr , _G.CONSTANT_DEFINE.CHAT_CHANNEL_ENUM.CHAT_CHANNEL_SYSTEM)
							end
						elseif diff < 0 then
							local str = StringTable.Get(100012):format(-diff, repuCfg.name)
							--warn("******** on_gp_player_reputation FlashTip", diff , str)
							--_G.FlashTipMan.FlashTip(str)
							_G.FlashTipMan.FlashRegionTip(str)
							---else --diff == 0 什么也不做
						end
					end
				else
					local hd_tid = hdConfig.RepuMap[repuID]
					if type(hd_tid) == "number" then
						local FEHumanDignityMainTips = require "HumanDignity.GUI.FEHumanDignityMainTips"
						FEHumanDignityMainTips.Instance():Toggle(hd_tid, oldValue, diff)
					end
				end
			else
				warn("!!!!!!!!! on_gp_player_reputation repuCfg == nil repuID change_type", repuID,msg.change_type)
			end
		end

		local funcTable = {}
		-- 预留功能 根据不同的 msg.change_type 调用不同的 func
		funcTable[-1] = function() -- 初始化
			-- initialize  nothing todo
		end
		funcTable[22] = function() -- 服务器清除数据
			-- clear nothing todo
		end
		--funcTable[0] = funcXXXX
		--funcTable[1] = funcXXXX

		local func = funcTable[msg.change_type]
		if(func == nil )then
			defaultTipFunc()
		else
			func()
		end

        if require "Utility.BranchUtil".IsBanshu() and repuID == 12 then
            local hp = ECGame.Instance().m_HostPlayer
            local unbind_cash = playerReputationInfo:GetValue()
            hp.Package.Cash = unbind_cash + hp.Package.BindCash
        end

		local value = playerReputationInfo:GetValue()
		local NotifyReputationChange = require "Event.NotifyReputationChange".NotifyReputationChange
		local repuevent = NotifyReputationChange()
		repuevent.index = repuID
		repuevent.value = value
		repuevent.oldValue = oldValue
		repuevent.diff = diff
		repuevent.type = msg.change_type
		ECGame.EventManager:raiseEvent(nil, repuevent)

        -- 版署修改
        if require "Utility.BranchUtil".IsBanshu() and msg.change_type == 24 and repuID == 5 and diff > 0 then
            local hint = require "GUI.ECPanelPolicyHint"
            hint.Instance().clientPopHint = 2
            hint.Instance().param1 = diff
            hint.Instance():ShowPanel(true,nil,nil)
        end

		if value ~= 0 and diff ~= 0 and repuID == loveRepuID and cfgLove then
			FlashTipMan.FlashTip((cfgLove.exp_des):format(value, cfgLove.max_exp))
		end

		--韩国打点
		if _G.IsBranch("oversea_korea") then
			if repuID == 2037 then
				local UserData = require "Data.UserData"
				local repuVal = UserData.Instance():GetRoleCfg("reward_per_day") or 0
				if repuVal < 30 and repu.value >= 30 then
					require "ProxySDK.ECAppsFlyer".sendAppsFlyerEvent("daily30", "") --每日活跃度30领奖
					UserData.Instance():SetRoleCfg("reward_per_day", repuVal)
				elseif repuVal < 160 and repu.value >= 160 then
					require "ProxySDK.ECAppsFlyer".sendAppsFlyerEvent("daily160", "") --每日活跃度160领奖
					UserData.Instance():SetRoleCfg("reward_per_day", repuVal)
				end
			end
		end

	end
end

local function on_gp_player_reputation(sender, msg)
	--local StringTable = require "Data.StringTable"
	--int32 change_type = 1;//同步所有为-1
	--map<int32, player_reputation_struct> info = 2;//声望数据
	--message player_reputation_struct
	--{
	--	int32 value = 1;
	--	int32 beyond_limit_value = 2;
	--	int32 day_value = 3;
	--	int32 week_value = 4;
	--	int32 month_value = 5;
	--	int32 last_modify_time = 6;
	--}

	--warn("******** on_gp_player_reputation")
	ECGame.Instance():OnHostPlayerCreate(function() on_msg(sender, msg) end)
end

pb_helper.AddHandler("gp_player_reputation", on_gp_player_reputation)
