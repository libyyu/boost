local pb_helper = require "PB.pb_helper"
local ECGame = require "Main.ECGame"

-- 处理问卷调查
local function DoQuestionnaire(questionActivityList)
	do--暂时屏蔽
		return
	end
	local activityData = ElementData.getDataByName("GmtMailActivityItem", 1)
	local currentActivityID = nil
	if activityData then currentActivityID = activityData.activity_id end

	local answered = false
	for i = 1, #questionActivityList do
		local data = questionActivityList[i]
		local activityType = data.activity_type
		local roleID = data.roleid
		local activityID = data.activity_id
		if currentActivityID and currentActivityID == activityID then
			answered = true
			break
		end 
	end

	-- 问卷调查事件
    local GMTQuestionEvent = require "Event.GMTQuestionEvent"
    local event = GMTQuestionEvent()
    event.answered = answered
    ECGame.EventManager:raiseEvent(nil, event)
end

local function OnCSPGmtActivityResponse(sender, msg)
	local data = msg.data
	local questionActivityList = {} -- 问卷调查

	for i = 1, #data do
		if data[i].activity_type == 1 then
			table.insert(questionActivityList, data[i])
		end
	end

	-- 处理各种活动事件
	DoQuestionnaire(questionActivityList)
end
 
pb_helper.AddHandler("npt_csp_gmt_activity", OnCSPGmtActivityResponse)


