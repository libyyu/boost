
--2015年10月14日
--Wang Yinliang
--
-- 胜者为王积分排行
-- npt_send_level_sorted_info
-- 
local pb_helper = require "PB.pb_helper"
local ECGame = require "Main.ECGame"

--[[
message level_sorted_info {
	optional int32 score		= 1;
	optional bytes name			= 2;
	optional int64 id 			= 3;
}
message gp_send_level_sorted_info {
	optional NET_PROTOCBUF_TYPE type	= 1	[ default = NPT_SEND_LEVEL_SORTED_INFO];
	repeated level_sorted_info list		= 2;
}

--]]

local function on_level_sorted_info( sender,msg )

	local ECInstBattleMan = require "Social.ECInstBattleMan"
	ECInstBattleMan.Instance():SetScoreRank( msg )

	require "GUI.ECPanelInstBattleRank".Instance():UpdateBattleRank()
	
end

pb_helper.AddHandler("gp_send_level_sorted_info", on_level_sorted_info)

