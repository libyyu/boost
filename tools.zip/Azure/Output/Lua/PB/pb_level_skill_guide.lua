local Lplus = require "Lplus"
local pb_helper = require "PB.pb_helper"

---@param msg pb.Message.PB.gp_level_skill_guide
local function on_level_skill_guide(sender,msg )
	local ECGuideSkillManager = require "Guide.ECGuideSkillManager"
	if not msg.close then
		ECGuideSkillManager.Instance():ShowGuide(msg.guide_id)
	else
		ECGuideSkillManager.Instance():ReleasePanel()
	end
end

pb_helper.AddHandler("gp_level_skill_guide", on_level_skill_guide)