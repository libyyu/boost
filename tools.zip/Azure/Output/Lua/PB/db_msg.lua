---@type pb.File.db
local db = require "Utility.DynamicProtobufWrapper".LoadFile "data/PB/db.pb"
return db
