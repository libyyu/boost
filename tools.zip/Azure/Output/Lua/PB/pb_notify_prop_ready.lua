
local pb_helper = require "PB.pb_helper"
local client_msg = require "PB.client_msg"
local ECGame = require "Main.ECGame"

local function on_notify_prop_ready(sender, msg)
	--warn("on_notify_prop_ready", msg.ready)
	local func = function()
		ECGame.Instance().m_HostPlayer.IsPropertyReady = msg.ready
	end
	ECGame.Instance():OnHostPlayerCreate(func)
end

pb_helper.AddHandler("gp_notify_prop_ready", on_notify_prop_ready)