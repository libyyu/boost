---@type pb.File.oss
local db = require "Utility.DynamicProtobufWrapper".LoadFile "data/PB/oss.pb"
return db