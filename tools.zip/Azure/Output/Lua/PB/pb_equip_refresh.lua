local pb_helper = require "PB.pb_helper"
local ECGame = require "Main.ECGame"
local _warn = _G.GetModuleLog("equip_train")
local EquipRefreshEvent = require "Event.EquipRefreshEvent"

local function on_gp_equip_refresh_result(sender, msg)
	_warn("on_gp_equip_refresh_result", msg)
	local event = EquipRefreshEvent()
	event.result = msg
	ECGame.EventManager:raiseEvent(nil, event)
end

pb_helper.AddHandler("gp_equip_refresh_result", on_gp_equip_refresh_result)