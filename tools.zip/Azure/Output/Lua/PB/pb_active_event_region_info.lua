local pb_helper = require "PB.pb_helper"

local function ON_MSG (newScenceID , activeRegionIDs , offset)
    --print_ygao("*** ON_MSG() newScenceID="..tostring(newScenceID))
    --for k,v in pairs(activeRegionIDs) do
    --    print_ygao("*** ON_MSG() activeRegionIDs" , k , v)
    --end

    local regionManager = require "Main.RegionManager".Instance()
    local oldScenceID = regionManager._activeRegionSceneID
    local oldRegionIDMap = regionManager._activatedRegionIDs

    local newRegionIDMap = nil

	--offset.x = 0
	--offset.y = 0
	--offset.z = 0

    regionManager._offsetX = offset.x
    regionManager._offsetY = offset.y
    regionManager._offsetZ = offset.z
    --print_ygao("*** ON_MSG() offset(" .. offset.x .. "," .. offset.y .. "," .. offset.z ..")")

    regionManager._activeRegionSceneID = newScenceID
    -- regionManager._activatedRegionIDs = {}
    local count = #activeRegionIDs
   -- print_ygao("*** ON_MSG() count=" .. count , tostring_r(activeRegionIDs))
    for idx = 1 , count do
        local regionID = activeRegionIDs[idx]
        -- regionManager._activatedRegionIDs[regionID] = regionID;
        newRegionIDMap = newRegionIDMap or {}
        newRegionIDMap[regionID] = regionID
        --print_ygao("*** ON_MSG newRegionIDMap[" .. tostring(regionID) .. "]")
    end

    --for k,regionID in pairs(oldRegionIDMap) do
    --    warn("**********  ON_MSG oldRegionIDMap[" .. tostring(regionID) .. "]")
    --end

    local ActiveRegionChangedEvent = require("Event.RegionChangedEvent").ActiveRegionChangedEvent
    if(oldScenceID ~= newScenceID)then-- 新旧场景不一样
        --warn("**********  ON_MSG 11111 新旧场景不一样 oldScenceID , newScenceID" , oldScenceID , newScenceID)
        local event = ActiveRegionChangedEvent()
        event._decActiveRegionIDMap = oldRegionIDMap    -- 这次改变减少的
        event._addActiveRegionIDMap = newRegionIDMap	-- 这次改变新添的
        event._currActiveRegionIDMap = newRegionIDMap or {}	-- 这次激活区域的场景ID
        event._oldScenceID = oldScenceID     -- 上次的场景ID
        event._newScenceID = newScenceID    -- 这次的场景ID
        require "Main.ECGame".EventManager:raiseEvent(nil, event)

    else  -- 新旧场景一样
        local event = ActiveRegionChangedEvent()
        local addActiveRegionIDMap = nil
        local decActiveRegionIDMap = nil
        --print_ygao("*** ON_MSG 2222 新旧场景一样 newScenceID" , newScenceID)

        if(oldRegionIDMap ~= nil)then
            --warn("**********  ON_MSG 3333 oldRegionIDMap ~= nil")
            for k,RegionID in pairs(oldRegionIDMap) do
                --warn("**********  ON_MSG 3344",RegionID)
                if(newRegionIDMap == nil or newRegionIDMap[RegionID] == nil)then-- 老的有 新的没有
                    decActiveRegionIDMap = decActiveRegionIDMap or {}
                    decActiveRegionIDMap[RegionID] = RegionID
                    --warn("**********  ON_MSG decActiveRegionIDMap",RegionID)
                end
            end
        end

        if(newRegionIDMap ~= nil)then
            --warn("**********  ON_MSG 4444 newRegionIDMap ~= nil")
            for k,RegionID in pairs(newRegionIDMap) do
                --print_ygao("*** ON_MSG 4455",RegionID)
                if(oldRegionIDMap == nil or oldRegionIDMap[RegionID] == nil)then-- 新的有 老的没有
                    addActiveRegionIDMap = addActiveRegionIDMap or {}
                    addActiveRegionIDMap[RegionID] = RegionID
                    --print_ygao("*** ON_MSG addActiveRegionIDMap",RegionID)
                end
            end
        end

        event._decActiveRegionIDMap = decActiveRegionIDMap      -- 这次改变减少的
        event._addActiveRegionIDMap = addActiveRegionIDMap      -- 这次改变新添的
        event._currActiveRegionIDMap = newRegionIDMap or {}     -- 这次激活区域的场景ID
        event._oldScenceID = oldScenceID     -- 上次的场景ID
        event._newScenceID = newScenceID    -- 这次的场景ID

        require "Main.ECGame".EventManager:raiseEvent(nil, event)
    end

end

local function on_active_event_region_info (sender, msg)
    --warn("********** pb_active_event_region_info.on_active_event_region_info " , msg.offset_pos.x , msg.offset_pos.y , msg.offset_pos.z)
    local offset_pos = EC.Vector3.new()
    --local offset_pos = EC.Vector3.new(relative_pos_from_server_vec(msg.offset_pos))
    offset_pos.x = msg.offset_pos.x
    offset_pos.y = msg.offset_pos.y
    offset_pos.z = msg.offset_pos.z
    ON_MSG(msg.scene_id , msg.region_id , offset_pos)
end
_G.on_active_event_region_info = ON_MSG
pb_helper.AddHandler("gp_active_event_region_info", on_active_event_region_info)