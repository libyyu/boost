local Lplus = require "Lplus"
local pb_helper = require "PB.pb_helper"
local ECSignInMan = require "GUI.SignIn.ECSignInMan"
---@type ECGame
local ECGame = Lplus.ForwardDeclare("ECGame")
local ECSignInEvents = require "GUI.SignIn.ECSignInEvents"

local function on_sync_sixty(sender, msg)
    ECSignInMan.Instance():UpdateSixtyData(msg)
    ECGame.EventManager:raiseEvent(nil, ECSignInEvents.UpdateSixtySignInEvent())
end
--pb_helper.AddHandler("gp_sync_sixty_days_sign_info", on_sync_sixty)

local function on_sync_daily(sender, msg)
    ECSignInMan.Instance():UpdateDailyData(msg)
    ECGame.EventManager:raiseEvent(nil, ECSignInEvents.UpdateDailySignInEvent())
end
--pb_helper.AddHandler("gp_sync_daily_sign_info", on_sync_daily)

local function on_sync_activity(sender, msg)
    ECSignInMan.Instance():UpdateActivityData(msg)
    ECGame.EventManager:raiseEvent(nil, ECSignInEvents.UpdateActivitySignInEvent())
end
pb_helper.AddHandler("gp_sync_activity_sign_info", on_sync_activity)