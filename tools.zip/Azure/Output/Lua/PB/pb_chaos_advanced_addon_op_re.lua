
local Lplus = require "Lplus"
local pb_helper = require "PB.pb_helper"


local function on_gp_chaos_advanced_addon_op_re(sender,msg)
	--print_ygao("on_gp_chaos_advanced_addon_op_re",msg)
	local ECPanelChaosDungeonsTalent = require "GUI.ChaosDungeons.ECPanelChaosDungeonsTalent"
	ECPanelChaosDungeonsTalent.Instance():OnMsg_op_re(msg)
end

pb_helper.AddHandler("gp_chaos_advanced_addon_op_re", on_gp_chaos_advanced_addon_op_re)
