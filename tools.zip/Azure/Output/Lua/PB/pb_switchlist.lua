local pb_helper = require "PB.pb_helper"

---@param msg pb.Message.PB.npt_sync_func_switch
local function on_npt_sync_func_switch(sender, msg)
	require "Utility.FunctionSwitch".Get():RecordSwitchList(msg.close_list)
end

pb_helper.AddHandler("npt_sync_func_switch", on_npt_sync_func_switch)