local Lplus = require "Lplus"
local pb_helper = require "PB.pb_helper"

local function OnBindPhoneResponse(sender, msg)
	-- local ECSubPanelBindPhone = require "GUI.ECSubPanelBindPhone"
	-- ECSubPanelBindPhone.Instance().giftList = msg.data
	-- ECSubPanelBindPhone.Instance():Update()
end

pb_helper.AddHandler("npt_csp_mobile_binding_list", OnBindPhoneResponse)



