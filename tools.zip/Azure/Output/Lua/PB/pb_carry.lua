local pb_helper = require "PB.pb_helper"
local client_msg = require "PB.client_msg"
local _warn = _G.GetModuleLog("carry")

---@param msg pb.Message.PB.gp_treasure_stone_respond
local function on_gp_treasure_stone_respond(sender, msg)
	_warn('on_gp_treasure_stone_respond', msg)
	local gp_treasure_stone_respond = pb_helper.GetCmdClass("gp_treasure_stone_respond")
	local ECGame = require "Main.ECGame"
	---@type ECPlayer
	local player = ECGame.Instance():FindObjectOrHost(msg.player_id)
	if player then
		player.m_CarryStoneID = msg.stone_id
		player:AddModelRealLoadedCallback(function()
			local obj = ECGame.Instance():FindObjectOrHost(msg.stone_id)
			if msg.op == gp_treasure_stone_respond.RET_BIND then
				--print("player:CarryObject")
				player:CarryObject(obj)
			else
				local ECNPC = require "NPCs.ECNPC"
				if obj and obj:is(ECNPC) then
					if obj.Essence.is_stone_disappear_after_move then
						local ECFxMan = require "Fx.ECFxMan"
						local SkillGfxParam = require"Fx.SkillGfxParam"
						local hp = globalGame:GetHostPlayer()
						local pathid = obj.Essence.stone_disappear_gfx
						local param = SkillGfxParam.new()
						param.resName = datapath.GetPathByID(pathid)
						param.transform = {
							translation = hp:GetCarryObjectPos(),
						}
						ECFxMan.Instance():Play(param)
					end
				end

				--if player:GetFakeCarryModel() ~= nil then
					player:UnCarryObject(false)
					player:UnCarryFakeObject(msg.mine_id)
				--end
			end
		end)
	end
end

pb_helper.AddHandler("gp_treasure_stone_respond", on_gp_treasure_stone_respond)