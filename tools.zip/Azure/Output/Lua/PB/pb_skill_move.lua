local pb_helper = require "PB.pb_helper"
local ECGame = require "Main.ECGame"
local EC = require "Types.Vector3"

---实时同步技能位移
---@param msg pb.Message.PB.gp_skill_move_s2c
local function on_skill_move (sender, msg)
    local ECPlayer = require "Players.ECPlayer"
    local player = ECGame.Instance():FindObjectOrHost(msg.player_id)
    if player and player:is(ECPlayer) then
        g_WorldUnwrapPosVec(msg.position)
        player:OnServerSkillMove(msg)
    end
end
pb_helper.AddHandler("gp_skill_move_s2c", on_skill_move)

--技能位移的服务器通知（仅在实时同步时起效）
---@param msg pb.Message.PB.gp_skill_host_pos
local function on_skill_host_pos (sender, msg)
    local hp = ECGame.Instance():GetHostPlayer()
    if hp then
        g_WorldUnwrapPosVec(msg.position)

        -- 计算和设置Server坐标
        local serverLocation = EC.Vector3.new():Assign(msg.position)
        local serverDirVec = EC.Vector3.new()
        DecompressDirH2(msg.dir, serverDirVec)

        if msg.typ ~= _G.SKILL_HOST_POS_TYPE.SKILL_END then

            local y, bFind = _G.GetSupportPlaneHeight_OnHostNotifyPos(serverLocation)

            print_jzw("on_skill_host_pos",serverLocation.x,serverLocation.y,serverLocation.z,y,bFind)

            if bFind then
                serverLocation.y = y
            end
        end

        hp:SetServerPos(serverLocation)
        hp:SetServerDir(serverDirVec)

        --print_jzw("on_skill_host_pos",serverLocation.x,serverLocation.y,serverLocation.z)

        -- 计算和设置世界坐标
        local worldLocation, _, worldDir = hp:CalAbsParamFromRelative2(serverLocation, EC.Vector3.zero:clone(), msg.dir)
        worldLocation = EC.Vector3.new():Assign(worldLocation)
        local worldDirVec = EC.Vector3.new()
        DecompressDirH2(worldDir, worldDirVec)

        if msg.typ == _G.SKILL_HOST_POS_TYPE.NORMAL then
            warn(("[on_skill_host_pos] type=[NORMAL] pos=[%f, %f, %f] dir=[%.2f]"):format(msg.position.x, msg.position.y, msg.position.z, msg.dir))
        elseif msg.typ == _G.SKILL_HOST_POS_TYPE.PERFORM_OUT_OF_RANGE then
            -- 技能段位移超出范围
            if hp:IsUsingSkill() then
                -- 直接强制设置玩家位置
                hp:SetPos(worldLocation)
                hp:SetDir(worldDirVec)
            end
            -- hp:DrawDebugPosAndDir(worldLocation, worldDirVec, 1, _G.ColorRed)
            warn(("[on_skill_host_pos] type=[PERFORM_OUT_OF_RANGE] pos=[%f, %f, %f] dir=[%.2f]"):format(msg.position.x, msg.position.y, msg.position.z, msg.dir))
        elseif msg.typ == _G.SKILL_HOST_POS_TYPE.SKILL_END then
            -- 技能位移结束
            -- 若和玩家当前的水平距离有很大差距，强制设置玩家位置
            local horizontalDistance = (hp:GetPos() - worldLocation):get_LengthH()
            if horizontalDistance > 1.0 then
                -- 考虑到网络延迟，距离无法作为判断依据，因此不进行处理
                --hp:SetPos(worldLocation)
                --hp:SetDir(worldDirVec)
                --GameUtil2.SetGamePlayerParam(hp:GetRootObject(), "HostPlayer_SyncPos")
                --warn(("[on_skill_host_pos] type=[SKILL_END] pos=[%f, %f, %f] dir=[%.2f] distance=[%f]"):format(msg.position.x, msg.position.y, msg.position.z, msg.dir, horizontalDistance))
            end

            -- hp:DrawDebugPosAndDir(worldLocation, worldDirVec, 1, _G.ColorBlue)
            --warn(("[on_skill_host_pos] type=[SKILL_END] pos=[%f, %f, %f] dir=[%.2f] distance=[%f]"):format(msg.position.x, msg.position.y, msg.position.z, msg.dir, horizontalDistance))
        end
    end
end
pb_helper.AddHandler("gp_skill_host_pos", on_skill_host_pos)