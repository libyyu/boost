local pb_helper = require "PB.pb_helper"

local max_addon_num = 10

local function on_dynamic_move_map (sender, msg)
	local mask = 0
	if type(msg.map_seq) == "table" and #msg.map_seq > 0 then
		for i = 1, #msg.map_seq do
			if msg.map_seq[i] >= 0 and msg.map_seq[i] < max_addon_num then
				mask = bit.bor(mask, bit.lshift(1, msg.map_seq[i]))
			end
		end
	end

	movemap.SetAddonMask(mask)
end

pb_helper.AddHandler("gp_dynamic_move_map", on_dynamic_move_map)
