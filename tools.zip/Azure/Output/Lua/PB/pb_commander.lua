--指挥

local Lplus = require "Lplus"

local pb_helper = require "PB.pb_helper"

--新上线同步和广播指挥者
local function on_nation_commander_appoint_notify(sender, msg)
	print("npt_nation_commander_notify",msg)
	-- local ECGame = require "Main.ECGame"
	-- local cmd
	-- if not ECGame.Instance().m_commander then --之前没有任命消息
	-- 	cmd = {direct = msg.dst_name,old=""}
	-- 	ECGame.Instance().m_commander = cmd
	-- else
	-- 	cmd = {direct = msg.dst_name,old=ECGame.Instance().m_commander.direct}
	-- 	ECGame.Instance().m_commander = cmd
	-- end
	-- local CommanderEvt = require "Event.CommanderEvt"
	-- ECGame.EventManager:raiseEvent(nil, CommanderEvt.new(cmd))
end

--pb_helper.AddHandler("npt_nation_commander_notify", on_nation_commander_appoint_notify)

