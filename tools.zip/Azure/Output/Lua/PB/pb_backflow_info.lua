local pb_helper = require "PB.pb_helper"

--
--npt_req_backflow_data_re  回归好友信息  回归好友个数 领取回归好友个数奖励状态 
--
-- local function on_npt_req_backflow_data_re(sender,msg)

-- 	local BackFlowAllDataEvt = require "Event.BackFriendEvent".BackFlowAllDataEvt
-- 	local ECGame = require "Main.ECGame"
-- 	local event = BackFlowAllDataEvt()
-- 	event.count = msg.count
-- 	event.award1 = msg.invite1
-- 	event.award2 = msg.invite2
-- 	event.award3 = msg.invite3 
-- 	event.involvement = msg.involvement
-- 	event.convene = msg.convene
-- 	event.backflow = msg.backflow
-- 	event.exp = msg.exp
-- 	ECGame.EventManager:raiseEvent(nil, event)
-- end
-- pb_helper.AddHandler("npt_req_backflow_data_re", on_npt_req_backflow_data_re)


-- --
-- --on_npt_share_backflow_code_re 分享邀请码
-- --
-- local function on_npt_share_backflow_code_re(sender,msg)
-- 	local ShareInviteCodeEvt = require "Event.BackFriendEvent".ShareInviteCodeEvt
-- 	local ECGame = require "Main.ECGame"
-- 	local event = ShareInviteCodeEvt()
-- 	event.errorcode = msg.errorcode
-- 	ECGame.EventManager:raiseEvent(nil, event)
-- 	--warn("share code back ")
-- end
-- pb_helper.AddHandler("npt_share_backflow_code_re",on_npt_share_backflow_code_re)

-- --
-- --npt_rece_invite_award_re 领取好友个数奖励  npt_rece_invite_award
-- --
-- local function on_npt_rece_invite_award_re(sender,msg)
-- 	local BackFriendRewardEvt = require "Event.BackFriendEvent".BackFriendRewardEvt
-- 	local ECGame = require "Main.ECGame"
-- 	local event = BackFriendRewardEvt()
-- 	event.rewardIndex = msg.index + 1
-- 	event.errorcode = msg.errorcode
-- 	ECGame.EventManager:raiseEvent(nil, event)
-- end
-- pb_helper.AddHandler("npt_rece_invite_award_re", on_npt_rece_invite_award_re)

-- --
-- --npt_rece_convene_award_re--输入邀请码领取回归奖励
-- --
-- local function on_npt_rece_convene_award_re(sender,msg)
-- 	local InputInviteCodeEvt = require "Event.BackFriendEvent".InputInviteCodeEvt
-- 	local ECGame = require "Main.ECGame"
-- 	local event = InputInviteCodeEvt()
-- 	event.errorcode = msg.errorcode
-- 	ECGame.EventManager:raiseEvent(nil, event)
-- 	warn("input invite back")
-- end
-- pb_helper.AddHandler("npt_rece_convene_award_re", on_npt_rece_convene_award_re)

-- --
-- --npt_rece_backflow_award_re--领取回流玩家奖励
-- --
-- local function on_npt_rece_backflow_award_re(sender,msg)
-- 	local GetBackFlowRewardEvt = require "Event.BackFriendEvent".GetBackFlowRewardEvt
-- 	local ECGame = require "Main.ECGame"
-- 	local event = GetBackFlowRewardEvt()
-- 	event.errorcode = msg.errorcode
-- 	ECGame.EventManager:raiseEvent(nil, event)
-- end
-- pb_helper.AddHandler("npt_rece_backflow_award_re", on_npt_rece_backflow_award_re)
