--
--6、1儿童节
--
local pb_helper = require "PB.pb_helper"

-- local function on_children_day_info( sender, msg )
-- end
-- pb_helper.AddHandler("gp_children_day_info", on_children_day_info)


-- --
-- --gp_children_day_repu_reward
-- --
-- local function on_children_day_repu_reward( sender, msg )
-- end
-- pb_helper.AddHandler("gp_children_day_repu_reward", on_children_day_repu_reward)