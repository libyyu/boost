
local pb_helper = require "PB.pb_helper"

local function on_talisman_data_notify(sender, msg)
	local ECTalismanManger = require "Inventory.ECTalismanManager"
	ECTalismanManger.Instance():TalismanDataNotify(msg)
end

pb_helper.AddHandler("gp_talisman_data_notify", on_talisman_data_notify)