local pb_helper = require "PB.pb_helper"
local ECGame = require "Main.ECGame"



--
--gp_job_order_info
--
local function on_gp_job_order_info(sender,msg)
	-- local curjoborder = msg.info.cur_job_order
	-- local ECJobOrderInfo = require "Players.ECJobOrderInfo"
	-- local oldjoborder = ECJobOrderInfo.Instance().curjoborder
	-- ECJobOrderInfo.Instance().curjoborder = curjoborder
	-- ECJobOrderInfo.Instance().havegetrwd = msg.info.is_get == 1 and true or false
	-- ECJobOrderInfo.Instance().gotrwdjoborder = msg.info.receive_job
	-- --print(msg)
	-- --warn(msg.info.cur_job_order,msg.info.is_get)
	-- --if curjoborder ~= oldjoborder then
	-- 	local evt1 = (require "Event.JoborderEvent").JoborderLeveupEvt()
	-- 	evt1.curjoborder = curjoborder
	-- 	evt1.havegetrwd = ECJobOrderInfo.Instance().havegetrwd
	-- 	ECGame.EventManager:raiseEvent(nil,  evt1)
	-- --end
	-- if msg.is_auto == 1 then 
	-- 	local jobordercfg = GetTemplates("JobOrderConfig")[curjoborder]
	-- 	--FlashTipMan.FlashTip(StringTable.Get(22708):format(jobordercfg.comments))
	-- 	require "GUI.ECPanelJoborderLevelup".Instance():OpenPanel()
	-- 	local hp = ECGame.Instance().m_HostPlayer
	-- 	if hp then 
	-- 		local gfx = datapath.GetPathByID(_G.GetConfigLua("Configs/Joborder_cfg.lua")[8])
 --    		local ECFxMan = require "Fx.ECFxMan"
	-- 		ECFxMan.Instance():Play(gfx, hp:GetPos(), Quaternion.identity, -1, false, _G.fx_priority.Host) 
	-- 	end

	-- end

	
end

pb_helper.AddHandler("gp_job_order_info", on_gp_job_order_info)



--
--gp_job_order_result
--
local function on_gp_job_order_result(sender,msg)
	local result = msg.result
	if result == 1 then
		FlashTipMan.FlashTip(StringTable.Get(22707))
	end
end

pb_helper.AddHandler("gp_job_order_result", on_gp_job_order_result)


