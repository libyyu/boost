---
---@author chenshilei
---@date 2021/3/1 15:08
---@description NPC跟随骑乘协议
---

local pb_helper = require "PB.pb_helper"

---@param msg pb.Message.PB.gp_npc_riding_bind
local function on_gp_npc_riding_bind(sender,msg)
    local ECWheeledVehicleMan = require "Vehicle.ECWheeledVehicleMan"
    ECWheeledVehicleMan.Instance():OnNPCFollowOnRiding(msg)
end
pb_helper.AddHandler("gp_npc_riding_bind", on_gp_npc_riding_bind)

