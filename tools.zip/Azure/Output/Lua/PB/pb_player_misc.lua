local pb_helper = require "PB.pb_helper"

--
--gp_player_misc 简易杂项数据
--
local CONFIG_REPU_AUTO_REWARD = _G.CONSTANT_DEFINE.CONFIG_TYPE.CONFIG_REPU_AUTO_REWARD

local function on_gp_player_misc(sender,msg)
	local ECGame = require "Main.ECGame"
	local function updateRewardInfo ()
		local RepuAutoRewardMap = ECGame.Instance().m_HostPlayer.InfoData.RepuAutoRewardMap
		local notifyAutoReward = false
		-- warn("on_gp_player_misc",msg)
		for _, v in pairs(msg.auto_reward) do
			if v.style == CONFIG_REPU_AUTO_REWARD then
				local reputId = LuaInt64.ToDouble(v.param3)
				--从配置里读
				if reputId <= 0 then
					local cfg = ElementData.getDataByName("RepuAutoReward", v.tid)
					if cfg then reputId = cfg.repu_id end
				end
				notifyAutoReward = true

				local reward = RepuAutoRewardMap[reputId]
				if reward == nil then
					reward = {}
					RepuAutoRewardMap[reputId] = reward
				end

				reward.HasGetRewardIndex = LuaInt64.ToDouble(v.param1)
				reward.canGetRewardTid   = v.reward
				reward.tid               = v.tid
				reward.data              = v
			end
		end

		if notifyAutoReward then
			local NotifyNewAutoReward = require "Event.NotifyNewAutoReward"
			local p = NotifyNewAutoReward()
			p.result = msg.auto_reward
			ECGame.EventManager:raiseEvent(nil, p)
		end
	end
	--确保 m_HostPlayer创建完成
	ECGame.Instance():OnHostPlayerCreate(updateRewardInfo)

	do return end
	local ECPanelMixedAchievement = require "GUI.ECPanelMixedAchievement"
	--print("msg.auto_reward",require "Utility.malut".tableToString(msg))
	ECPanelMixedAchievement.Instance():SetRewardInfo(msg.auto_reward)
	local ECGUIAttrDan = require "GUI.ECGUIAttrDan"
	ECGUIAttrDan.Instance():SetPlayerUseData(msg.prop_pills)
end
pb_helper.AddHandler("gp_player_misc",on_gp_player_misc)