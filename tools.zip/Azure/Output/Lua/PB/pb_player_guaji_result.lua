local Lplus = require "Lplus"

local pb_helper = require "PB.pb_helper"

--[[
message gp_player_guaji_result
{
	optional S2C_GS_PROTOC_TYPE type        = 1 [ default = type_gp_player_guaji_result ];
	optional bool start_guaji			= 2;
	optional bool quit_mode				= 3;	//是否开启静默模式
	optional bool half_quit_mode			= 4;	//半静默模式
}
]]

local function on_player_guaji_result(sender, msg)
	--print("on_player_guaji_result: ", msg.start_guaji)

	--	测试先注掉！！！
	_G.OnPlayerGuajiResult(msg.start_guaji, msg.quit_mode, msg.half_quit_mode)
end

pb_helper.AddHandler("gp_player_guaji_result", on_player_guaji_result)