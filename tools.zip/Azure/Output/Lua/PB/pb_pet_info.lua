local pb_helper = require "PB.pb_helper"

--
--gp_pet_list_info：宠物列表
--
-- local function on_pet_list_info(sender,msg)
-- 	do--暂时屏蔽
--     	return
--   	end	
-- 	local ECPetData = require "Data.ECPetData"
-- 	ECPetData.LogWarn("on_pet_list_info",msg)
-- 	local oldaddedfightvalue = ECPetData.Instance():CalcAddedFightValueByPet()
-- 	ECPetData.Instance():onPetListInfo(msg)

-- 	local PetListEvt = require "Event.PetEvent".PetListEvt
-- 	local ECGame = require "Main.ECGame"
-- 	local event = PetListEvt()
-- 	ECGame.EventManager:raiseEvent(nil, event)

-- 	--当前出战的宠物
-- 	local cur_pet_tid,petdata = ECPetData.Instance():GetCurrentFightPet()
-- 	local PetSummonEvt = require "Event.PetEvent".PetSummonEvt
-- 	local event2 = PetSummonEvt()
-- 	event2.pet_tid = cur_pet_tid
-- 	event2.petdata = petdata
-- 	event2.pet_pos = petdata and petdata.pos_index or -1
-- 	ECGame.EventManager:raiseEvent(nil, event2)
-- 	local newaddedfightvalue = ECPetData.Instance():CalcAddedFightValueByPet()
-- 	if oldaddedfightvalue ~= newaddedfightvalue then 
-- 		local PetOnHostFightValue = require "Event.PetEvent".PetOnHostFightValue
-- 		ECGame.EventManager:raiseEvent(nil,PetOnHostFightValue.new(oldaddedfightvalue,newaddedfightvalue))
-- 	end
-- end
-- pb_helper.AddHandler("gp_pet_list_info", on_pet_list_info)


-- --
-- --gp_pet_info：宠物信息（pos)
-- --
-- local function on_pet_info(sender,msg)
-- 	do--暂时屏蔽
--     	return
--   	end	
-- 	local ECPetData = require "Data.ECPetData"
-- 	ECPetData.LogWarn("on_pet_info",msg)

-- 	local pet_pos_index = msg.pet_info.pos_index
-- 	local old_pet = ECPetData.Instance():GetPetDataAt(pet_pos_index)
-- 	local old_star_lv = (old_pet and old_pet.quality_star or 1)
-- 	local old_level = (old_pet and old_pet.level or 0)
-- 	local old_quality = (old_pet and old_pet.quality_color or 1)
-- 	local old_bless_value = (old_pet and old_pet.star_bless_value or 0)
-- 	local old_exp = (old_pet and LuaUInt64.ToDouble(old_pet.exp) or 0)
-- 	local new_got = (not old_pet and true or false)
-- 	local old_skill_addon = {}
-- 	local oldaddedfightvalue = ECPetData.Instance():CalcAddedFightValueByPet()

-- 	if old_pet then
-- 		for i,v in ipairs(old_pet.skill_addon) do
-- 			table.insert(old_skill_addon,v)
-- 		end
-- 	end

-- 	ECPetData.Instance():onPetInfo(msg)

-- 	local skill_addon_changelist = {}
-- 	local new_skill_addon = msg.pet_info.skill_addon
-- 	for i,_ in ipairs(new_skill_addon) do
-- 		if ( not old_skill_addon[i] and new_skill_addon[i] ) and (old_skill_addon[i] and new_skill_addon[i] and new_skill_addon[i] ~= old_skill_addon[i]) then
-- 			skill_addon_changelist[i] = true
-- 		end
-- 	end

-- 	local PetDataEvt = require "Event.PetEvent".PetDataEvt
-- 	local ECGame = require "Main.ECGame"
-- 	local event = PetDataEvt()
-- 	event.pet_pos = pet_pos_index
-- 	event.petdata = msg.pet_info
-- 	event.star_up = msg.pet_info.quality_star > old_star_lv
-- 	event.level_up = msg.pet_info.level > old_level
-- 	event.quality_up = msg.pet_info.quality_color > old_quality
-- 	event.exp_up = LuaUInt64.ToDouble(msg.pet_info.exp) > old_exp
-- 	event.new_got = new_got
-- 	event.bless_add = msg.pet_info.star_bless_value - old_bless_value
-- 	event.skill_addon_changelist = nil--skill_addon_changelist
-- 	ECGame.EventManager:raiseEvent(nil, event)

-- 	--当前出战的神兽
-- 	local cur_pet_tid,petdata = ECPetData.Instance():GetCurrentFightPet()
-- 	local PetSummonEvt = require "Event.PetEvent".PetSummonEvt
-- 	local event2 = PetSummonEvt()
-- 	event2.pet_tid = cur_pet_tid
-- 	event2.petdata = petdata
-- 	event2.pet_pos = petdata and petdata.pos_index or -1
-- 	ECGame.EventManager:raiseEvent(nil, event2)
-- 	local newaddedfightvalue = ECPetData.Instance():CalcAddedFightValueByPet()
-- 	if oldaddedfightvalue ~= newaddedfightvalue then 
-- 		local PetOnHostFightValue = require "Event.PetEvent".PetOnHostFightValue
-- 		ECGame.EventManager:raiseEvent(nil,PetOnHostFightValue.new(oldaddedfightvalue,newaddedfightvalue))
-- 	end

-- end
-- pb_helper.AddHandler("gp_pet_info", on_pet_info)

-- --
-- --操作返回
-- --
-- local function on_pet_operator_re(sender,msg)
-- 	do--暂时屏蔽
--     	return
--   	end	
-- 	local ECPetData = require "Data.ECPetData"
-- 	ECPetData.LogWarn("on_pet_operator_re",msg)
-- 	local ECGame = require "Main.ECGame"
-- 	if msg.oper_type == 3 then --分解
-- 		if msg.oper_retcode == 0 then
-- 			FlashTipMan.FlashTip(StringTable.Get(17706))
			
-- 			local cur_pet_tid,petdata = ECPetData.Instance():GetCurrentFightPet()

-- 			ECPetData.Instance():onPetDisappear(msg.result_param1)

-- 			local PetDisappearEvt = require "Event.PetEvent".PetDisappearEvt
			
-- 			local event = PetDisappearEvt()
-- 			event.pet_pos = msg.result_param1
-- 			ECGame.EventManager:raiseEvent(nil, event)

-- 			--当前出战的神兽
-- 			if petdata and petdata.pos_index == msg.result_param1 then
-- 				local PetSummonEvt = require "Event.PetEvent".PetSummonEvt
-- 				local event = PetSummonEvt()
-- 				event2.pet_tid = cur_pet_tid
-- 				event2.petdata = petdata
-- 				event2.pet_pos = msg.result_param1
-- 				ECGame.EventManager:raiseEvent(nil, event2)
-- 			end
-- 		end
-- 	elseif msg.oper_type == 5 then--合宠
-- 		if msg.oper_retcode == 0 then
-- 			FlashTipMan.FlashTip(StringTable.Get(17709))
-- 			GameUtil.AddGlobalTimer(0,true,function()
-- 				local old_pet = ECPetData.Instance():GetPetDataAt(msg.result_param1)
-- 				if old_pet then
-- 					local ECPanelPetCombineResult = require "GUI.Pet.ECPanelPetFuseResult"
-- 					ECPanelPetCombineResult.Instance():Popup(msg.result_param1,-1,true,nil)
-- 				end
-- 			end)

-- 			local unlockNum,skillNum = ECPetData.Instance():GetUnlockSkillNum(msg.result_param1)

-- 			if skillNum > unlockNum then
-- 				local Task = require "Utility.Task"
-- 				local ECAsyncTask = require "Utility.ECAsyncTask"
-- 				local task = Task.createSteps(function (task, step)
-- 					if step <= 2 then
-- 						FlashTipMan.FlashTip(StringTable.Get(17743),"pet_sklls")
-- 						return task:completeSub(ECAsyncTask.WaitForTime(5))
-- 					else
-- 						return "end"
-- 					end
-- 				end)
-- 				task:start()
-- 			end

-- 			local cur_pet_tid,petdata = ECPetData.Instance():GetCurrentFightPet()

-- 			ECPetData.Instance():onPetDisappear(msg.result_param2)

-- 			local PetDisappearEvt = require "Event.PetEvent".PetDisappearEvt
			
-- 			local event = PetDisappearEvt()
-- 			event.pet_pos = msg.result_param2
-- 			ECGame.EventManager:raiseEvent(nil, event)

-- 			--当前出战的神兽
-- 			if petdata and petdata.pos_index == msg.result_param2 then
-- 				local PetSummonEvt = require "Event.PetEvent".PetSummonEvt
-- 				local event2 = PetSummonEvt()
-- 				event2.pet_tid = cur_pet_tid
-- 				event2.petdata = petdata
-- 				event2.pet_pos = msg.result_param2
-- 				ECGame.EventManager:raiseEvent(nil, event2)
-- 			end
-- 		end
-- 	elseif msg.oper_type == 4 then--炼妖
-- 		if msg.oper_retcode == 0 then
-- 			local PetStarupEvt = require "Event.PetEvent".PetStarupEvt
			
-- 			local event = PetStarupEvt()
-- 			event.pet_pos = msg.result_param1
-- 			event.is_crit = msg.result_param2 == 1
-- 			ECGame.EventManager:raiseEvent(nil, event)
-- 		end
-- 	elseif msg.oper_type == 2 then--洗髓
-- 		if msg.oper_retcode == 0 then
-- 			local PetWashingEvt = require "Event.PetEvent".PetWashingEvt
			
-- 			local event = PetWashingEvt()
-- 			event.pet_pos = msg.result_param1
-- 			ECGame.EventManager:raiseEvent(nil, event)
-- 		end
-- 	elseif msg.oper_type == 7 then--重置
-- 		if msg.oper_retcode == 0 then
-- 			FlashTipMan.FlashTip(StringTable.Get(17761))
-- 		end
-- 	elseif msg.oper_type == 8 then --龙骨
-- 		if msg.oper_retcode == 0 then
-- 			FlashTipMan.FlashTip(StringTable.Get(17780))
-- 			local PetLongGuEvt = require "Event.PetEvent".PetLongGuEvt
			
-- 			local event = PetLongGuEvt()
-- 			event.pet_pos = msg.result_param1
-- 			ECGame.EventManager:raiseEvent(nil, event)
-- 		end
-- 	elseif msg.oper_type == 10 then --手动加点
-- 		if msg.oper_retcode == 0 then
-- 			FlashTipMan.FlashTip(StringTable.Get(17792))
-- 		end
-- 	elseif msg.oper_type == 9 then
-- 		if msg.oper_retcode == 0 then
-- 			FlashTipMan.FlashTip(StringTable.Get(17793))
-- 		end
-- 	elseif msg.oper_type == 11 then
-- 		if msg.oper_retcode == 0 then
-- 			FlashTipMan.FlashTip(StringTable.Get(17799))

-- 			ECPetData.Instance():onPetDisappear(msg.result_param1)

-- 			local PetDisappearEvt = require "Event.PetEvent".PetDisappearEvt
			
-- 			local event = PetDisappearEvt()
-- 			event.pet_pos = msg.result_param1
-- 			ECGame.EventManager:raiseEvent(nil, event)
-- 		end
-- 	elseif msg.oper_type == 12 then
-- 		if msg.oper_retcode == 0 then
-- 			FlashTipMan.FlashTip(StringTable.Get(17802))
-- 		end
-- 	elseif msg.oper_type == 13 then
-- 		if msg.oper_retcode == 0 then
-- 			--FlashTipMan.FlashTip(StringTable.Get(17825))
-- 		end
-- 	elseif msg.oper_type == 14 then
-- 		if msg.oper_retcode == 0 then
-- 			FlashTipMan.FlashTip(StringTable.Get(17828))

-- 		end
-- 	elseif msg.oper_type == 15 then
-- 		if msg.oper_retcode == 0 then
-- 			FlashTipMan.FlashTip(StringTable.Get(17831))
-- 			local ECPanelPetInsideUp = require "GUI.Pet.ECPanelPetInsideUp"
-- 			ECPanelPetInsideUp.Instance():DestroyPanel()
-- 		elseif msg.oper_retcode == 1 then
-- 			FlashTipMan.FlashTip(StringTable.Get(17835))
-- 		end
-- 	elseif msg.oper_type == 16 then
-- 		if msg.oper_retcode == 0 then
-- 			FlashTipMan.FlashTip(StringTable.Get(17847))
-- 		else
-- 			FlashTipMan.FlashTip(StringTable.Get(17848))
-- 		end
-- 	elseif msg.oper_type == 17 then
-- 		if msg.oper_retcode == 0 then
-- 			--local ECPetRecorePage = require "GUI.Pet.ECPetRecorePage"
-- 			--ECPetRecorePage.Instance():RealXiSui()
-- 		else
-- 		end
-- 	end
-- end
-- pb_helper.AddHandler("gp_pet_operate_re",on_pet_operator_re)

-- --
-- --gp_equip_soul_result
-- --
-- -- local function on_pet_equip_soul_result(sender,msg)
-- -- 	local ECPetData = require "Data.ECPetData"
-- -- 	ECPetData.LogWarn("on_pet_equip_soul_result",msg)
-- -- 	if msg.result == 0 then
-- -- 		local ECGame = require "Main.ECGame"
-- -- 		local PetEquipSoulEvt = require "Event.PetEvent".PetEquipSoulEvt
-- -- 		local event2 = PetEquipSoulEvt()
-- -- 		event2.pet_pos = ECPetData.Instance():PetLocationToIndex(msg.pet_location)
-- -- 		event2.equip_index = msg.equip_index
-- -- 		event2.property_index = msg.property_index
-- -- 		--event2.exp_value = msg.exp_value
-- -- 		event2.level = msg.level
-- -- 		event2.soulvalue_add = msg.exp_change

-- -- 		ECGame.EventManager:raiseEvent(nil, event2)
-- -- 	else
-- -- 		FlashTipMan.FlashTip(StringTable.Get(17748))
-- -- 	end
-- -- end
-- -- pb_helper.AddHandler("gp_equip_soul_result",on_pet_equip_soul_result)

-- --
-- --gp_pet_common_info
-- --
-- local function on_pet_common_info(sender,msg)
-- 	do--暂时屏蔽
--     	return
--   	end	
-- 	local ECPetData = require "Data.ECPetData"
-- 	ECPetData.LogWarn("on_pet_common_info",msg)
	
-- 	local common_data = msg.common_data 
-- 	if common_data then
-- 		local oldaddedfightvalue = ECPetData.Instance():CalcAddedFightValueByPet()
-- 		ECPetData.Instance():onPetFightPlan(common_data)
-- 		local ECGame = require "Main.ECGame"
-- 		local PetFightPlanEvt = require "Event.PetEvent".PetFightPlanEvt
-- 		local event2 = PetFightPlanEvt()
-- 		event2.pet_1 = common_data.fight_list[1].index or -1
-- 		event2.pet_2 = common_data.fight_list[2].index or -1
-- 		event2.pet_3 = common_data.fight_list[3].index or -1
-- 		ECGame.EventManager:raiseEvent(nil, event2)


-- 		local PetUnlockEvt = require "Event.PetEvent".PetUnlockEvt
-- 		local event3 = PetUnlockEvt()
-- 		event3.is_owned_pet = common_data.is_owned_pet
-- 		ECGame.EventManager:raiseEvent(nil,event3)
-- 		local newaddedfightvalue = ECPetData.Instance():CalcAddedFightValueByPet()
-- 		if oldaddedfightvalue ~= newaddedfightvalue then 
-- 			local PetOnHostFightValue = require "Event.PetEvent".PetOnHostFightValue
-- 			ECGame.EventManager:raiseEvent(nil,PetOnHostFightValue.new(oldaddedfightvalue,newaddedfightvalue))
-- 		end

-- 	end

-- end
-- pb_helper.AddHandler("gp_pet_common_info",on_pet_common_info)


-- --
-- --gp_pet_add_exp --特殊状态触发的经验增减
-- --

-- local function on_gp_pet_add_exp(sender,msg )
-- 	do--暂时屏蔽
--     	return
--   	end	
-- 	local addvalue = msg.exp
-- 	local ECPetData = require "Data.ECPetData"
-- 	local pos,petdata = ECPetData.Instance():GetCurrentFightPet()
-- 	local petname = ECPetData.Instance():GetPetNameByPetData(petdata)
-- 	FlashTipMan.FlashTip(StringTable.Get(17824):format(petname or "",addvalue))
-- end
-- pb_helper.AddHandler("gp_pet_add_exp",on_gp_pet_add_exp)