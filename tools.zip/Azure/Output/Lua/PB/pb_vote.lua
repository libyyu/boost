local pb_helper = require "PB.pb_helper"

--
--npt_vote_status_sync
--	
local function on_npt_vote_status_sync (sender, msg)

	local VoteResultSyncEvt = (require "Event.VoteEvent").VoteResultSyncEvt()
	VoteResultSyncEvt.msg = msg
	local ECGame = require "Main.ECGame"
	ECGame.EventManager:raiseEvent(nil, VoteResultSyncEvt)

end
pb_helper.AddHandler("npt_vote_status_sync", on_npt_vote_status_sync)

--
--npt_vote_team_instance_re
--
local function on_npt_vote_team_instance_re (sender, msg)
	local VoteTeamInstanceFailEvt = (require "Event.VoteEvent").VoteTeamInstanceFailEvt()
	VoteTeamInstanceFailEvt.msg = msg
	local ECGame = require "Main.ECGame"
	ECGame.EventManager:raiseEvent(nil,VoteTeamInstanceFailEvt)


end
pb_helper.AddHandler("npt_vote_team_instance_re", on_npt_vote_team_instance_re)