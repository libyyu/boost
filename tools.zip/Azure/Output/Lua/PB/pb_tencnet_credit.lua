
local Lplus = require "Lplus"
local pb_helper = require "PB.pb_helper"

--腾讯信用分不足时返回错误信息
local function on_credit_score_error(sender, msg)
	local str = ""
	if msg.error == 2796 then --信用分不足禁止聊天 ERROR_CREDIT_SCORE_OVER_CHAT
		str = StringTable.Get(2649):format(msg.need_credit + 1)
	elseif msg.error == 2797 then --信用分不足禁止加好友 ERROR_CREDIT_SCORE_OVER_FRIEND
		str = StringTable.Get(2650):format(msg.need_credit + 1)
	elseif msg.error == 2798 then --信用分不足禁止登录 ERROR_CREDIT_SCORE_OVER_LOGIN
		str = StringTable.Get(2651):format(msg.need_credit + 1)
	elseif msg.error == 2802 then --信用分不足禁止上排行榜 ERROR_CREDIT_SCORE_OVER_TOPLIST
		str = StringTable.Get(2652):format(msg.need_credit + 1)
		require "GUI.Rank.ECSubPanelRankList".Instance():SetRankCreditData(str)
		return --信用分排行榜相关不显示弹出提示 而是直接显示在排行榜界面上
	elseif msg.error == 2803 then --信用分不足禁止创建帮会 ERROR_CREDIT_SCORE_CREATE_MAFIA
		str = StringTable.Get(2653):format(msg.need_credit + 1)
	elseif msg.error == 2804 then --信用分不足禁止加入帮会 ERROR_CREDIT_SCORE_APPLY_MAFIA
		str = StringTable.Get(2654):format(msg.need_credit + 1)
	end
	local variables = require "Chat.Content.DataContentVariables".New()
	variables.Palette = "Tip"
	local web_str = require "Chat.Content.ContentWebsiteLink".Instance():MakeHTMLString({"", "tencent_credit", StringTable.Get(2648)}, variables)
	local content = str.."\n"..web_str
	MsgBox.ShowMsgBoxEx3(nil, content, StringTable.Get(1850), nil, MsgBoxType.MBBT_OK, nil, 0, function(box)
	end)
end

pb_helper.AddHandler("npt_credit_score_error", on_credit_score_error)
pb_helper.AddHandler("gp_credit_score_error", on_credit_score_error)
