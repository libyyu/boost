
--2015年12月8日
--Newer
--
-- 随从关协议处理
-- gp_produce
-- 
local Lplus = require "Lplus"
local pb_helper = require "PB.pb_helper"
---@type ECGame
local ECGame = Lplus.ForwardDeclare("ECGame")
local ECRetinueMan = require "Utility.ECRetinueMan"
--local ECPanelAttendantSummary = require "GUI.ECPanelAttendantSummary"
local ElementData = require "Data.ElementData"



local NOTIFY_TYPE =
{
	N_TYPE_SYNC_RETINUE			= 	1,
	N_TYPE_SYNC_GROUP			= 	2,
	N_TYPE_ADD_GROUP			= 	3,
	N_TYPE_USE_FORMATION		= 	4,
	N_TYPE_UNUSE_FORMATION		= 	5,
	N_TYPE_ADD_RETINUE			= 	6,
	N_TYPE_RETINUE_UP_QUALITY	=	7,
	N_TYPE_SYNC_RETINUE_ONE 	=	8,
	N_TYPE_ADD_TASK				= 	9,
	N_TYPE_DEL_TASK				= 	10,
	N_TYPE_UPGRADE_GROUP		= 	11,
	N_TYPE_ADD_FORMATION		=	12,
	N_TYPE_SELECT_COMBAT		= 	13,
	N_TYPE_ADD_PRIVATE			= 	14,
	N_TYPE_ACTIVE_PRIVATE		= 	15,
	N_TYPE_GAIN_EXP         	=   16,
	N_TYPE_DECOMPOSE			=	17,
	N_TYPE_SELECT_FASHION		= 	18,
	N_TYPE_RECRUIT 				= 	19,
	N_TYPE_EX_TASK_REFRESH 		= 	20,
	N_TYPE_GIVE_GIFT			=	21,
	N_TYPE_TAKE_GIFT			=	22,
	N_TYPE_MOOD_CHANGE			=	23,
	N_TYPE_GIFT_ADD             =	24,
}


-- 随从信息
local function on_retinue_data_notify( sender,msg )
	--warn("gp_retinue_data_notify ", msg.notify_type , msg)

	--if #msg.formation_owned>0 then -- 曾经拥有过的阵法
	--	ECRetinueMan.Instance():SetFormationOwned(msg.formation_owned)
	--end
	
	if msg.notify_type == NOTIFY_TYPE.N_TYPE_SYNC_RETINUE then
		ECRetinueMan.Instance().m_Combat = msg.param1
		ECRetinueMan.Instance().m_retinues = {}
		ECRetinueMan.Instance():InitPrivates(msg.privates)
		ECRetinueMan.Instance():InitGifts(msg.gifts)
		ECRetinueMan.Instance():InitRetinues(msg.retinues)

		--if msg.formation then
		--	ECRetinueMan.Instance():UseFormation(msg.formation)
		--end

		if msg.task then
			for i = 1, #msg.task do
				ECRetinueMan.Instance():AddRetinueTask(msg.task[i])
			end
		end
		ECRetinueMan.Instance():LoadNewRetinueState()
		ECRetinueMan.Instance():LoadStoryState()

		ECRetinueMan.Instance():RefreshExTask(msg.param2,msg.timestamp,msg.ex_task)

		return
	elseif msg.notify_type == NOTIFY_TYPE.N_TYPE_SYNC_GROUP then
		ECRetinueMan.Instance().m_retinue_groups = {}
		for i = 1, #msg.retinue_groups do
			--print("-----------------------------------随从组合N_TYPE_SYNC_GROUP ", msg.retinue_groups[i])
			ECRetinueMan.Instance():AddRetinueGroup(msg.retinue_groups[i])
		end
		
	elseif msg.notify_type == NOTIFY_TYPE.N_TYPE_ADD_GROUP then
		if not ECRetinueMan.Instance().m_retinue_groups then
			ECRetinueMan.Instance().m_retinue_groups = {}
		end
		for i = 1, #msg.retinue_groups do
			--print("随从组合N_TYPE_ADD_GROUP ", msg.retinue_groups[i].retinue_group_id,msg.retinue_groups[i])
			ECRetinueMan.Instance():AddRetinueGroup(msg.retinue_groups[i])
		end
	elseif msg.notify_type == NOTIFY_TYPE.N_TYPE_USE_FORMATION then
		local TaskTriggerMan = require "Task.TaskTriggerMan"
		TaskTriggerMan.EventTrigged(TaskTriggerMan.TASK_TRIGER_EVENT.RETINUE_FORMATION)
	--print("-----------------------------------N_TYPE_USE_FORMATION ", msg.formation)
		ECRetinueMan.Instance():UseFormation(msg.formation)
	elseif msg.notify_type == NOTIFY_TYPE.N_TYPE_UNUSE_FORMATION then
		ECRetinueMan.Instance():UnuseFormation()
		--print("-----------------------------------N_TYPE_UNUSE_FORMATION ", msg.formation)
	elseif msg.notify_type == NOTIFY_TYPE.N_TYPE_SYNC_RETINUE_ONE then
		if not ECRetinueMan.Instance().m_retinues then
			ECRetinueMan.Instance().m_retinues = {}
		end
		for i = 1, #msg.retinues do
			--print("AddRetinue type = ",msg.notify_type, msg.retinues[i].base_info.retinue_id)
			ECRetinueMan.Instance():AddRetinue(msg.retinues[i])
		end
	elseif msg.notify_type == NOTIFY_TYPE.N_TYPE_RETINUE_UP_QUALITY then
		if not ECRetinueMan.Instance().m_retinues then
			ECRetinueMan.Instance().m_retinues = {}
		end

		local retinueInfo = ECRetinueMan.Instance():GetRetinueInfo(msg.retinues[1].base_info.retinue_id)
		if retinueInfo ~= nil then
			local ECPanelPartnerView_Evolve = require "GUI.ECPanelPartnerView_Evolve"
			ECPanelPartnerView_Evolve.Instance():OnEvolveSuccess(retinueInfo)
		end
		
		for i = 1, #msg.retinues do
			ECRetinueMan.Instance():AddRetinue(msg.retinues[i])
		end

		--if ECPanelAttendantSummary.Instance():IsVisible() then
		--	if msg.retinues[1] then -- msg.retinues升品只有一个内容
		--		ECPanelAttendantSummary.Instance():PopUpgrade(msg.retinues[1].base_info.retinue_id)
		--	end		
		--end
	elseif msg.notify_type == NOTIFY_TYPE.N_TYPE_ADD_RETINUE  then
		if not ECRetinueMan.Instance().m_retinues then
			ECRetinueMan.Instance().m_retinues = {}
		end

		--print("---------------------N_TYPE_ADD_RETINUE:",msg.retinues[1].retinue_id)
		if msg.retinues[1].base_info.retinue_id then
			local retinueInfo = ECRetinueMan.Instance():GetRetinueInfo(msg.retinues[1].base_info.retinue_id)
			if not retinueInfo then
				local function_name = "attendant_get_" .. msg.retinues[1].base_info.retinue_id
				local ECPanelFunctionUnlock = require "Guide.ECPanelFunctionUnlock"
				ECPanelFunctionUnlock.QueuePopup(function_name)
				for i = 1, #msg.retinues do
					--print("AddRetinue type = ",msg.notify_type, msg.retinues[i].retinue_id,
					--	msg.retinues[i].count)
					ECRetinueMan.Instance():AddRetinue(msg.retinues[i])
				end
			else
				--local recruitment = msg.retinues[1].base_info.count - retinueInfo.base_info.count
				retinueInfo.base_info.count = msg.param1
				ECRetinueMan.Instance():AddRetinue(retinueInfo)
				--local dataT = ElementData.getData(cfg.CTABLE_TYPE.RETINUE_CARD_ESSENCE, msg.retinues[1].retinue_id)
				--local eb = ElementData.getEssence(msg.retinues[1].base_info.retinue_id)
				--if not eb then return end
				
				--local ECEquipDesc = require "Data.ECEquipDesc"
				--local retinueName = ECEquipDesc.GetTextColor(retinueInfo.base_info.quality) .. eb.name
				--FlashTipMan.FlashTip(string.format(StringTable.Get(16858),retinueName,recruitment))
			end
		end

	elseif msg.notify_type == NOTIFY_TYPE.N_TYPE_ADD_TASK then
		if msg.task  then
			for i = 1, #msg.task do
				ECRetinueMan.Instance():AddRetinueTask(msg.task[i])
			end
		end
		if msg.ex_task.taskid ~= 0 then
			ECRetinueMan.Instance():RefreshExTask(msg.param1,msg.timestamp,msg.ex_task)
		end
	elseif msg.notify_type == NOTIFY_TYPE.N_TYPE_DEL_TASK then
		if msg.award then
			ECRetinueMan.Instance():PopupTaskResult(msg.award)
			ECRetinueMan.Instance():RemoveRetinueTask(msg.award.taskid)
		end	
	elseif msg.notify_type == NOTIFY_TYPE.N_TYPE_UPGRADE_GROUP then
		for i = 1, #msg.retinue_groups do
			--print("N_TYPE_UPGRADE_GROUP ", msg.retinue_groups[i].retinue_group_id,msg.retinue_groups[i])
			ECRetinueMan.Instance():AddRetinueGroup(msg.retinue_groups[i])
		end
	elseif msg.notify_type == NOTIFY_TYPE.N_TYPE_ADD_FORMATION then
		local formation_id = msg.param1
		if formation_id then
			ECRetinueMan.Instance():AddFormationOwned(formation_id)

			local function_name = "formation_get_" .. formation_id
			local ECPanelFunctionUnlock = require "Guide.ECPanelFunctionUnlock"
			ECPanelFunctionUnlock.QueuePopup(function_name)
		end
	elseif msg.notify_type == NOTIFY_TYPE.N_TYPE_DECOMPOSE then
		local retinueInfo = ECRetinueMan.Instance():GetRetinueInfo(msg.retinue_id)
		if retinueInfo then
			retinueInfo.base_info.count = msg.param1
			ECRetinueMan.Instance():AddRetinue(retinueInfo)
		end

	elseif msg.notify_type == NOTIFY_TYPE.N_TYPE_SELECT_COMBAT then
		ECRetinueMan.Instance():SetCombat( msg.param1)
	elseif msg.notify_type == NOTIFY_TYPE.N_TYPE_SELECT_FASHION then
		ECRetinueMan.Instance():SetFashionSelect(msg.retinue_id,msg.param1,msg.param2)
	elseif msg.notify_type == NOTIFY_TYPE.N_TYPE_ADD_PRIVATE then
		ECRetinueMan.Instance():AddPrivate(msg.param1,msg.param2)
	elseif msg.notify_type == NOTIFY_TYPE.N_TYPE_ACTIVE_PRIVATE then
		if not ECRetinueMan.Instance().m_retinues then
			ECRetinueMan.Instance().m_retinues = {}
		end
		ECRetinueMan.Instance():AddPrivate(msg.param1,msg.param2)
		for i = 1, #msg.retinues do
			ECRetinueMan.Instance():AddRetinue(msg.retinues[i])
		end
		ECRetinueMan.Instance():AddPrivate(msg.param1,msg.param2)

	elseif msg.notify_type == NOTIFY_TYPE.N_TYPE_RECRUIT then

		local ECPanelPartnerSymbolLine = require "GUI.ECPanelPartnerSymbolLine"
		ECPanelPartnerSymbolLine.Instance():DestroyPanel()

		local ECPanelPartnerGet = require "GUI.ECPanelPartnerGet"
		print("N_TYPE_RECRUIT!!",msg.retinue_id,msg.param1)
		ECPanelPartnerGet.Instance():PopUp(msg.retinue_id,msg.param1)
	elseif msg.notify_type == NOTIFY_TYPE.N_TYPE_EX_TASK_REFRESH then
		ECRetinueMan.Instance():RefreshExTask(msg.param1,msg.timestamp,msg.ex_task)

	elseif msg.notify_type == NOTIFY_TYPE.N_TYPE_GIVE_GIFT then
		print("N_TYPE_GIVE_GIFT")
		local OldCount = ECRetinueMan.Instance():GetGiftCount(msg.param1)
		ECRetinueMan.Instance():UpdateGiftCount(msg.param1,OldCount - 1)
		local retinueInfo = ECRetinueMan.Instance():GetRetinueInfo(msg.retinue_id)
		if retinueInfo then
			retinueInfo.base_info.amity = msg.param2
		end
		local ECPanelPartnerView_Gift = require "GUI.ECPanelPartnerView_Gift"
		ECPanelPartnerView_Gift.Instance():OnSendGift()
	elseif msg.notify_type == NOTIFY_TYPE.N_TYPE_TAKE_GIFT then
		print("N_TYPE_TAKE_GIFT")
		--ECRetinueMan.Instance():UpdateGiftCount(msg.param1,msg.param2)
		local retinueInfo = ECRetinueMan.Instance():GetRetinueInfo(msg.retinue_id)
		if retinueInfo then
			retinueInfo.base_info.take_gift_level = msg.param1
		end
		local ECPanelPartnerView_Gift = require "GUI.ECPanelPartnerView_Gift"
		ECPanelPartnerView_Gift.Instance():OnTakeGift(msg.retinue_id,msg.param1)
		ECPanelPartnerView_Gift.Instance():RefreshByManager(retinueInfo)

	elseif msg.notify_type == NOTIFY_TYPE.N_TYPE_MOOD_CHANGE then
		print("N_TYPE_MOOD_CHANGE")
		ECRetinueMan.Instance():UpdateMood(msg.retinue_id,msg.param1,msg.param2)
	elseif msg.notify_type == NOTIFY_TYPE.N_TYPE_GIFT_ADD then
		print("N_TYPE_GIFT_ADD")
		ECRetinueMan.Instance():UpdateGiftCount(msg.param1,msg.param2)
	end

	local RetinueEvent = require "Event.RetinueEvent"
	local p = RetinueEvent()
	p.notify_type = msg.notify_type
	ECGame.EventManager:raiseEvent(nil, p)
end
pb_helper.AddHandler("gp_retinue_data_notify", on_retinue_data_notify)

-- 随从信息
local function on_retinue_cast_skill( sender,msg )
	local obj = ECGame.Instance():FindObjectOrHost(msg.player_id)
	if obj then
		obj:DoPartnerSkill(msg)
	end
end
pb_helper.AddHandler("gp_retinue_cast_skill", on_retinue_cast_skill)



