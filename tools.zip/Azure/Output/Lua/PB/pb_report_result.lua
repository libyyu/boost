local Lplus = require "Lplus"
local pb_helper = require "PB.pb_helper"
local ECGame = require "Main.ECGame"

local function on_illegal_report_result(sender,msg)
	print("------------on_illegal_report_result:",msg)
	if msg.result == 0 then
		--[[ 暂时没有举报的具体逻辑，暂时只弹个提示
		local hostID = ECGame.Instance().m_HostInfo.id
		local path = string.format("/userdata/%s/report_info.lua", LuaUInt64.ToString(hostID))
		local ret, data
		if utility.IsFileExist(path) then
			ret, data = pcall(dofile, path)
		end
		if not data or type(data) ~= "table" then
			data = {}
		end

		path = GameUtil.GetAssetsPath() .. path
		GameUtil.CreateDirectoryForFile(path)

		data[LuaUInt64.ToString(msg.target_roleid)] = GameUtil.GetServerGMTTime()
		local malut = require "Utility.malut"
		local bSucc, err = malut.toCodeToFile(data, path)
		if not bSucc then
			error(err)
		end
		]]--
		FlashTipMan.FlashTip(StringTable.Get(15220))
	elseif msg.result == 1 then
		FlashTipMan.FlashTip(StringTable.Get(15221))
	end
end
pb_helper.AddHandler("gp_illegal_report_result", on_illegal_report_result)