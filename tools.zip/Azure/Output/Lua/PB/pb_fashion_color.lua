local pb_helper = require "PB.pb_helper"
local client_msg = require "PB.client_msg"

local function gp_fashion_colorate_result( sender,msg )
	local fashionTypes =  require "Utility.ECIvtrUIUtility".GetFashionEquipPositions()
	local makeupTypes = require "Utility.ECIvtrUIUtility".GetMakeupEquipPositions()
	local pos = _G.FindPosInArray(fashionTypes,msg.index)
	if pos ~= 0 then
		require "GUI.ECSubPanelColorate".Instance():OnFashionColorateResult(msg)
		return
	else
		pos =  _G.FindPosInArray(makeupTypes,msg.index)
		if pos ~= 0 then 
			require "GUI.ECSubPanelFashionPackage".Instance():OnFashionColorateResult(msg)
			return
		end
	end

	
end

pb_helper.AddHandler("gp_fashion_colorate_result",gp_fashion_colorate_result)