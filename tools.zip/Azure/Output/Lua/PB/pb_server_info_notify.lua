
local pb_helper = require "PB.pb_helper"

local function on_server_info_notify(sender, msg)
	--print("on_server_info_notify",msg)
	--local ECGame = require "Main.ECGame"
	--ECGame.Instance():UpdateFreeWarBeginTime(msg.free_war_left)
end

pb_helper.AddHandler("npt_server_info_notify", on_server_info_notify)