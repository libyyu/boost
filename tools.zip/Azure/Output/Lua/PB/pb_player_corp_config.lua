local Lplus = require "Lplus"

local pb_helper = require "PB.pb_helper"
local client_msg = require "PB.client_msg"
local ECGame = require "Main.ECGame"
local NotifyFaction = require "Event.NotifyFaction"

local function on_gp_player_corp_config(sender, msg)
	 do--暂时屏蔽
    return
  end	
	local func = function()
		local config =  msg.config
		--print("@@@@@@@@@@@@@on_gp_corp_config", config.active_level, config.active_index)
		local faction = ECGame.Instance().m_HostPlayer.Faction
		--faction._activefactionskill = config.active_level * 5 + config.active_index
		--faction._activefactionskill = config.skills.level * 5 + config.skills.index
		faction._skillInfo = msg.config
		--print("FactionSkills",#msg.config.skills)
		ECGame.EventManager:raiseEvent(nil, NotifyFaction.NotifyFactionInfo())
	end
	ECGame.Instance():OnHostPlayerCreate(func)
end
pb_helper.AddHandler("gp_player_corp_config", on_gp_player_corp_config)


