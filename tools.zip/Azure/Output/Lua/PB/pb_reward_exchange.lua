-- pb_reward_exchange
-- 金币兑换相关协议

local pb_helper = require "PB.pb_helper"
local client_msg = require "PB.client_msg"
local ECGame = require "Main.ECGame"

local function on_gp_reward_exchange_records(sender,msg)
	local UIWelfareExchangeMoneyRecord = require "GUI.Welfare.WelfareExchangeMoney.UIWelfareExchangeMoneyRecord"
	local MSG_TYPE = client_msg.gp_reward_exchange_records.MSG_TYPE
	if msg.msg_type == MSG_TYPE.RECORD_ADD then
		UIWelfareExchangeMoneyRecord.Instance():AddMsg(msg.records)
	elseif msg.msg_type == MSG_TYPE.RECORD_INFO then
		UIWelfareExchangeMoneyRecord.Instance():ResetMsg(msg.records)
	end
end
pb_helper.AddHandler("gp_reward_exchange_records", on_gp_reward_exchange_records)


local function on_gp_reward_exchange_re(sender,msg)
	if msg.retcode == 0 then
		local ECPanelRewardShowSimple = require "GUI.Common.ECPanelRewardShowSimple"
		ECPanelRewardShowSimple.Instance():ShowWithCommonRewardList(msg.reward_ids)
	else
		warn("on_gp_reward_exchange_re retcode is not 0 :   ",msg.retcode)
	end
end
pb_helper.AddHandler("gp_reward_exchange_re", on_gp_reward_exchange_re)


