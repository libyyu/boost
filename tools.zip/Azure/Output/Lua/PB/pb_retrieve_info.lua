
--2015年7月2日
--Wang Yinliang
--
-- 找回奖励
-- gp_retrieve_info
-- 
local pb_helper = require "PB.pb_helper"
local ECGame = require "Main.ECGame"
--local RetrieveInfoEvent = require "Event.RetrieveInfoEvent"

--[[

	message retrieve_info_str {
		optional int32 type			= 1;		//类型
		optional int32 tid			= 2;		//对应的tid
		optional int32 left_count		= 3;	//剩余次数
		optional int32 timestamp		= 4;	//数据更新日期
		optional int32 retrieve_count	= 5;	//找回次数
		optional int32 activity_id		= 6;	//对应活动id校验用
	}

	message retrieve_info {
		repeated retrieve_info_str retrieve	= 1;
	}

	message gp_retrieve_info {
		optional S2C_GS_PROTOC_TYPE type	= 1 	[ default = type_gp_retrieve_info ];
		optional retrieve_info info		= 2;		//全部发送
		optional retrieve_info_str one		= 3;	//更新单条数据
	}

--]]
local function on_retrieve_info( sender,msg )
	--warn("gp_retrieve_info 11111111111 ", msg.single_data, #(msg.info.retrieve) )

	-- local info = msg.info
	-- local one = msg.one

	-- local event = RetrieveInfoEvent()
	-- local ECRetrieveMan = require "Social.ECRetrieveMan"
	-- local retrieveMan = ECRetrieveMan.Instance()
	-- if not msg.single_data then
	-- 	retrieveMan:SetRetrieveInfo( info.retrieve )

	-- 	event._type = 1
	-- else
	-- 	retrieveMan:SetSingleRetrieve( one )
	-- 	event._type = 0
	-- 	event._tid = one.activity_id
	-- end

	-- ECGame.EventManager:raiseEvent(nil, event)

end

pb_helper.AddHandler("gp_retrieve_info", on_retrieve_info)
