---
---@author chenshilei
---@date 2020/4/26 17:30
---@description 连携相关协议
---

local pb_helper = require "PB.pb_helper"

---@param msg pb.Message.PB.gp_speople_lian_xie_notify
local function on_gp_speople_lian_xie_notify(sender,msg)
    local ECUniteSkillMan = require "Skill.UniteSkill.ECUniteSkillMan"
    ECUniteSkillMan.Instance():OnPeopleUniteSkillNotify(msg)
end
pb_helper.AddHandler("gp_speople_lian_xie_notify", on_gp_speople_lian_xie_notify)

---@param msg pb.Message.PB.gp_speople_lian_xie_settle
local function on_speople_lian_xie_settle(sender,msg)
    local ECUniteSkillMan = require "Skill.UniteSkill.ECUniteSkillMan"
    ECUniteSkillMan.Instance():OnPeopleUniteSkillSettle(msg)
end
pb_helper.AddHandler("gp_speople_lian_xie_settle", on_speople_lian_xie_settle)