
local Lplus = require "Lplus"
---@type ECGame
local ECGame = Lplus.ForwardDeclare("ECGame")
local pb_helper = require "PB.pb_helper"
local Enum = require "Utility.Enum"
local ActivityEvents = require "Event.ActivityEvents"


local datatype = Enum.make
{
	"TYPE_NULL",'=', 0,
	"TYPE_INT",
	"TYPE_CHAR",
	"TYPE_SHORT",
	"TYPE_FLOAT",
	"TYPE_DOUBLE",
	"TYPE_OCTETS",
}


local function on_global_data_sync_player(sender,msg )
	--print("on_global_data_sync_player",#msg.sync_data)
	local global_data = ECGame.Instance().m_GlobalData
	for k,v in pairs(msg.sync_data) do
		if v.key then
			local br = BinaryReader.CreateFromLuaString(v.data,false)
			if v.data_type == datatype.TYPE_INT then
				global_data[v.key] = br:ReadInt32()
			elseif v.data_type == datatype.TYPE_CHAR then
				global_data[v.key] = br:ReadByte()
			elseif v.data_type == datatype.TYPE_SHORT then
				global_data[v.key] = br:ReadUInt16()
			elseif v.data_type == datatype.TYPE_FLOAT then
				global_data[v.key] = br:ReadSingle()
			elseif v.data_type == datatype.TYPE_DOUBLE then
				global_data[v.key] = br:ReadDouble()
			elseif v.data_type == datatype.TYPE_OCTETS then
				global_data[v.key] = br:ReadString()
			end
			br:Destroy()
			--print("Get sync Global Data",v.key,global_data[v.key])
		end
	end
	ECGame.Instance().m_GlobalData = global_data
	local GlobalDataEvent = ActivityEvents.GlobalDataEvent
	local event = GlobalDataEvent()
	ECGame.EventManager:raiseEvent(nil, event)
end

pb_helper.AddHandler("npt_global_data_sync_player",on_global_data_sync_player)

local function on_global_data_re(sender,msg )
	--print("on_global_data_sync_player",msg.all_send,#msg.global_datas)
	local global_data = {}
	if not msg.all_send then
		global_data = ECGame.Instance().m_GlobalData
	end
	
	for k,v in pairs(msg.global_datas) do
		if v.key then
			local br = BinaryReader.CreateFromLuaString(v.data,false)
			if v.data_type == datatype.TYPE_INT then
				global_data[v.key] = br:ReadInt32()
			elseif v.data_type == datatype.TYPE_CHAR then
				global_data[v.key] = br:ReadByte()
			elseif v.data_type == datatype.TYPE_SHORT then
				global_data[v.key] = br:ReadUInt16()
			elseif v.data_type == datatype.TYPE_FLOAT then
				global_data[v.key] = br:ReadSingle()
			elseif v.data_type == datatype.TYPE_DOUBLE then
				global_data[v.key] = br:ReadDouble()
			elseif v.data_type == datatype.TYPE_OCTETS then
				global_data[v.key] = br:ReadString()
			end
			br:Destroy()
			--print("Get Global Data",v.key,global_data[v.key])
		end
	end
	ECGame.Instance().m_GlobalData = global_data
	local GlobalDataEvent = ActivityEvents.GlobalDataEvent
	local event = GlobalDataEvent()
	ECGame.EventManager:raiseEvent(nil, event)
end

pb_helper.AddHandler("npt_get_global_data_re",on_global_data_re)

