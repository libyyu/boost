
--2015年12月8日
--Newer
--
-- 生产相关协议处理
-- gp_produce
-- 
local Lplus = require "Lplus"
local pb_helper = require "PB.pb_helper"
---@type ECGame
local ECGame = Lplus.ForwardDeclare("ECGame")
local ECProduceMan = require "Produce.ECProduceMan"
local ECPanelProduce = require "GUI.ECPanelProduce"
--生产技能
local function on_produce_skill( sender,msg )
--	print("gp_produce_skill %d", #msg.info ,type(msg))
	for i = 1, #msg.info do
--		print("gp_produce_skill  info ", msg.info[i].id,msg.info[i].level)
		ECProduceMan.Instance():setSkillLv(msg.info[i].id,msg.info[i].level)
	end
	ECPanelProduce.Instance():OnRefresh(false)
end

pb_helper.AddHandler("gp_produce_skill", on_produce_skill)

--生产技能升级
local function on_produce_skill_level_up_result( sender,msg )
--	print("on_produce_skill_level_up_result",msg.result,type(msg))
	if msg.result==1 then -- 1表示成功
		--local Lv = ECProduceMan.Instance():getSkillLv(self.m_CurSkillCfg.id)
		ECPanelProduce.Instance():OnRefresh(true)
	end
end

pb_helper.AddHandler("gp_produce_skill_level_up_result", on_produce_skill_level_up_result)

--生产物品
local function on_produce_item_result( sender,msg )
	--print("on_produce_item_result",msg)
	local ECItemTools = require "Inventory.ECItemTools"
	local ECIvtrItem = require "Inventory.IvtrItem.ECIvtrItem"
	local ECPanelEquipProduce = require "GUI.ECPanelEquipProduce"
	if ECPanelEquipProduce.Instance():IsVisible() then
		local ECSoundMan = require "Sound.ECSoundMan"
		--ECSoundMan.Instance():Play2DSoundByName("EquipReforge")
	end

	if msg.item_id then
		local TaskTriggerMan = require "Task.TaskTriggerMan"

		local pItem = ECItemTools.CreateItem(msg.item_id)
		local datatype = pItem:GetDateType()
		
		if datatype == _G.CONSTANT_DEFINE.CONFIG_TYPE.CONFIG_ITEM_MEDICINE then
			TaskTriggerMan.EventTrigged(TaskTriggerMan.TASK_TRIGER_EVENT.MEDICINE_PRODUCE,msg.item_id)
		elseif datatype == _G.CONSTANT_DEFINE.CONFIG_TYPE.CONFIG_ITEM_EQUIPMENT then
			local index_mask = mask_to_index[pItem.m_pDBEssence.equip_mask]
			local ECEquipDesc = require "Data.ECEquipDesc"
			local equip_postion = ECEquipDesc.GetDescData(0,index_mask)
			if msg.result == 0 then --使用幸运剂失败
				FlashTipMan.FlashTip(StringTable.Get(18200):format(equip_postion))
			elseif msg.result == 1 then --未使用幸运剂

			elseif msg.result == 2 then --使用幸运剂成功
				FlashTipMan.FlashTip(StringTable.Get(18201):format(equip_postion))
			end
			TaskTriggerMan.EventTrigged(TaskTriggerMan.TASK_TRIGER_EVENT.EQUIP_PRODUCE,msg.item_id)
		end		
	end

	ECPanelProduce.Instance():OnRefresh(false)
end

pb_helper.AddHandler("gp_produce_item_result", on_produce_item_result)