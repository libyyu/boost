
local pb_helper = require "PB.pb_helper"
local Lplus = require "Lplus"
---@type ECGame
local ECGame = Lplus.ForwardDeclare("ECGame")

local function on_npt_clan_readable(sender, msg)
	do--暂时屏蔽
		return
	end
	--local ECPanelCommunication = require "GUI.ECPanelCommunication"
	--ECPanelCommunication.Instance():onNptClanReadable(msg)
	--local ECClanMan = require "Social.ECClan".ECClanMan
	if ECGame.Instance().m_ClanMan then 
		ECGame.Instance().m_ClanMan:onNptClanReadable(msg)
	end
end

local function on_npt_clan_operation(sender, msg)
	if ECGame.Instance().m_ClanMan then 
		ECGame.Instance().m_ClanMan:onClanOperation(msg)
	end
end

local function on_npt_clan_writeable(sender, msg)
	if ECGame.Instance().m_ClanMan then 
		ECGame.Instance().m_ClanMan:onNptClanWriteable(msg)
	end
end

local function on_npt_clan_chat(sender, msg )
	if ECGame.Instance().m_ClanMan then 
		ECGame.Instance().m_ClanMan:onNptClanChat(msg)
	end
end
pb_helper.AddHandler("npt_clan_readable", on_npt_clan_readable)
pb_helper.AddHandler("npt_clan_operation", on_npt_clan_operation)
pb_helper.AddHandler("npt_clan_writeable", on_npt_clan_writeable)
pb_helper.AddHandler("npt_clan_chat", on_npt_clan_chat)