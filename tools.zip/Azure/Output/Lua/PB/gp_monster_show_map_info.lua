---
---@author chenshilei
---@date 2021/2/1 13:45
---@description
---

local client_msg = require "PB.client_msg"
local pb_helper = require "PB.pb_helper"

---@param msg pb.Message.PB.gp_monster_show_map_info
local function on_gp_monster_show_map_info(sender,msg)
    local ECGlobalVisualMonsterManager = require "Main.ECGlobalVisualMonsterManager"
    if msg.oper == client_msg.gp_monster_show_map_info.MONSTER_SHOW_MAP_TYPE.MSMT_ENTER then
        for i, info in ipairs(msg.info) do
            ECGlobalVisualMonsterManager.Instance():Enter(info)
        end
    elseif msg.oper == client_msg.gp_monster_show_map_info.MONSTER_SHOW_MAP_TYPE.MSMT_UPDATE then
        for i, info in ipairs(msg.info) do
            ECGlobalVisualMonsterManager.Instance():Update(info)
        end
    elseif msg.oper == client_msg.gp_monster_show_map_info.MONSTER_SHOW_MAP_TYPE.MSMT_LEAVE then
        for i, info in ipairs(msg.info) do
            ECGlobalVisualMonsterManager.Instance():Leave(info.monster_id)
        end
    end
end
pb_helper.AddHandler("gp_monster_show_map_info", on_gp_monster_show_map_info)