local pb_helper = require "PB.pb_helper"
local function on_npt_all_server_repu(sender,msg)
	local ECAllServerReputationMan = require "Main.ECAllServerReputationMan"
	ECAllServerReputationMan.Instance():OnGetReputationMsg(msg)
end
pb_helper.AddHandler("npt_all_server_repu",on_npt_all_server_repu)