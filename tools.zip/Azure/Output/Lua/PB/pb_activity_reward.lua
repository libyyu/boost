--
--
-- 活动相关：每日许愿
-- 
local Lplus = require "Lplus"
local pb_helper = require "PB.pb_helper"
local pb_error_code = _G.require_config("Configs/pb_error_code.lua")
---@type ECGame
local ECGame = Lplus.ForwardDeclare("ECGame")


--每日活跃许愿
--[[
	//下发日常许愿信息
	message gp_daily_wish_info {
	    option (s2c_type) = type_gp_daily_wish_info;
	    int32 wish_index                = 1; //许愿的幻灵tid
	    DAILY_WISH_STATUS wish_status   = 2; //许愿状态

	}
--]]
local function on_daily_wish_info(sender, msg)
	--print_wyl("------on_daily_wish_info-------", msg.wish_index, msg.wish_status, msg.reward_tid_list)

	local ECActivitySetMan = require "GUI.ActivitySet.ECActivitySetMan"
	ECActivitySetMan.Instance():OnSetWishInfo(msg)

	local DayWishEvent = require "Event.DayWishEvent"
    local event = DayWishEvent()
    event.oprate = msg.wish_status
    ECGame.EventManager:raiseEvent(nil, event)
end
pb_helper.AddHandler("gp_daily_wish_info", on_daily_wish_info)


--[[
	//日常许愿返回
	message gp_daily_wish_re {
	    option (s2c_type) = type_gp_daily_wish_re;
	    int32     retcode     = 1;
	    int32     wish_index  = 2; //许愿的幻灵tid
	    DAILY_WISH_OPERATE op = 3;                
	}
--]]
local function on_daily_wish_re(sender, msg)
	print_wyl("------on_daily_wish_re-------", msg.retcode, msg.wish_index, msg.op)
	if msg.retcode == 0 then
		local ECActivitySetMan = require "GUI.ActivitySet.ECActivitySetMan"
		ECActivitySetMan.Instance():OnNotiyWishInfo(msg)

		local DayWishEvent = require "Event.DayWishEvent"
		ECGame.EventManager:raiseEvent(nil,  DayWishEvent())
	elseif pb_error_code[msg.retcode] ~= nil then
		FlashTipMan.FlashTip(pb_error_code[msg.retcode])
	end
	
end
pb_helper.AddHandler("gp_daily_wish_re", on_daily_wish_re)



------------------风之试炼 begin----------------------------------
--[[
message gp_wind_trial_resp {
    option (s2c_type) = type_gp_wind_trial_resp;

    WIND_TRIAL_OP_TYPE ot       = 1; //操作类型
    db_windtrial_data all_data  = 2; //levelid_to_info字段除全量同步，其他时候都只是变化了才同步
    int32 param_01              = 3; //参数1
}
--]]
local function on_wind_trial_resp(sender, msg)
	--print_wyl("------on_wind_trial_resp-------", msg.ot, msg.param_01, msg.all_data)
	if msg.ot > 0 then

		local ECWindTrialManager = require "GUI.ActivitySet.WindTrial.ECWindTrialManager"
		ECWindTrialManager.Instance():OnNotiyWindTrial(msg)

		local WindTrialEvent = require "Event.WindTrialEvent"
        local event = WindTrialEvent()
        event.type = msg.ot
        ECGame.EventManager:raiseEvent(nil, event)
	end
	
end
pb_helper.AddHandler("gp_wind_trial_resp", on_wind_trial_resp)


--[[
	//批量获取风之试炼排名
	message npt_batch_get_windtrial_rank {
	    option (npt_type) = NPT_BATCH_GET_WINDTRIAL_RANK;
	    repeated int32 rank_ids = 1; //层级排行榜ID列表(请求值)
	    map<int32, int32> rankid_to_rank = 2; //排行榜ID=>排名(返回值)
	}
--]]
local function on_batch_get_windtrial_rank_resp(sender, msg)
	print_wyl("------npt_batch_get_windtrial_rank-------", msg)
	local ECWindTrialManager = require "GUI.ActivitySet.WindTrial.ECWindTrialManager"
	ECWindTrialManager.Instance():OnTrialRankResp(msg)

	local WindTrialRankEvent = require "Event.WindTrialRankEvent"
    local event = WindTrialRankEvent()
    ECGame.EventManager:raiseEvent(nil, event)
	
end
pb_helper.AddHandler("npt_batch_get_windtrial_rank", on_batch_get_windtrial_rank_resp)

------------------风之试炼 end----------------------------------

