---@type pb.File.client_msg
local client_msg = require "Utility.DynamicProtobufWrapper".LoadFile "data/PB/client_msg.pb"
return client_msg
