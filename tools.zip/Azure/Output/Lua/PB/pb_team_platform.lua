-- 组队平台
-- NPT_PLATFORM_TEAM_LIST
--[[
message name_roleid_pair
{
	required int64 roleid			= 1;
	required bytes name			= 2;
}
message platform_team_info
{
	required name_roleid_pair leader	= 1;	//队长
	required int32 leader_level		= 2;	//队长等级
	required int32 leader_prof		= 3;	//队长职业
	required uint32 teamid			= 4;	//队伍ID
	required int32 cur_size			= 5;	//队伍当前人数
	required int32 max_size			= 6;	//队伍人数上限
	required int32 category			= 7;	//
	required int32 tid			= 8;	//
}
message npt_platform_team_list
{
	optional NET_PROTOCBUF_TYPE type	= 1	[ default = NPT_PLATFORM_TEAM_LIST];
	required int64 roleid			= 2;	//玩家ID
	required int32 category			= 3;	//
	required int32 tid			= 4;	//
	repeated platform_team_info team_list	= 5;	//队伍列表
}
]]

local pb_helper = require "PB.pb_helper"
local ECGame = require "Main.ECGame"
local StringTable = require "Data.StringTable"

local function on_platform_team_list( sender,msg )
	local ECTeamPlatformPage =  require "Social.ECTeamPlatformPage"
	local TeamPlatform = ECTeamPlatformPage.Instance()
	if TeamPlatform.m_panel then
		TeamPlatform:GetTeamListRe(msg)
	end
end

pb_helper.AddHandler("npt_platform_team_list", on_platform_team_list)


-- NPT_PLATFORM_REGISTER_RESULT
--[[
message npt_platform_register_result {
	optional NET_PROTOCBUF_TYPE type	= 1	[ default = NPT_PLATFORM_REGISTER_RESULT];
	required int32 retcode			= 2;
	required int64 roleid			= 3;
	required int32 category			= 4;
	required int32 tid			= 5;
	required uint32 teamid			= 6;
	optional int64 errrole			= 7;
	optional int32 param1			= 8;
}
]]

local function on_platform_register_result( sender,msg )
	print("platform_register_result",msg.retcode)
	if msg.retcode ~= 0 then
		if msg.retcode == 24 then
			FlashTipMan.FlashTip(StringTable.Get(1058))
		elseif msg.retcode == 630 then
			FlashTipMan.FlashTip(StringTable.Get(13051))
		else
			--错误
			local briefInfo = require "Common.GameBriefInfoCacheMan".Instance():FindBriefCache(msg.roleid)
			if msg.retcode == 909 and briefInfo then
				FlashTipMan.FlashTip(string.format(StringTable.Get(13032 + msg.retcode - 900),briefInfo.name))
			elseif msg.retcode == 910 and briefInfo then
				FlashTipMan.FlashTip(string.format(StringTable.Get(13032 + msg.retcode - 900),briefInfo.name))
			else
				FlashTipMan.FlashTip(StringTable.Get(13032 + msg.retcode - 900))
			end
			--FlashTipMan.FlashTip(StringTable.Get(13060 - 301 + msg.retcode))
		end
	else
		if require "Social.ECTeam".ECTeamMan.Instance():IsHostPlayerInTeam() then
			FlashTipMan.FlashTip(StringTable.Get(13027))
		else
			FlashTipMan.FlashTip(StringTable.Get(13029))
		end
	end

	local ECTeamPlatMan = require "Social.ECTeamPlatformManager"
	ECTeamPlatMan.Instance():RegisterTeamResult(msg)
	--local ECTeamPlatformPage =  require "Social.ECTeamPlatformPage"
	--local TeamPlatform = ECTeamPlatformPage.Instance()
	--if TeamPlatform.m_panel then --不要这样判断 排队信息其他模块也要用 by: Niuyadong
	--	TeamPlatform:RegisterTeamResult(msg)
	--end

	local ECPanelActivityDate =  require "GUI.ECPanelActivityDate"
	if ECPanelActivityDate.Instance():IsVisible() then
		ECPanelActivityDate.Instance():UpdateActivityListView(false)
	end
end

pb_helper.AddHandler("npt_platform_register_result", on_platform_register_result)


-- NPT_PLATFORM_REGISTER_RESULT
--[[
message npt_platform_join_team_notify
{
	optional NET_PROTOCBUF_TYPE type	= 1	[ default = NPT_PLATFORM_JOIN_TEAM_NOTIFY];
	required uint32 teamid			= 2;
	required int32 category			= 3;
	required int32 tid			= 4;
}
]]

local function on_platform_join_team_result( sender,msg )
	--warn("--------on_platform_join_team_result")
	if msg.retcode ==0 then
		local ECTeamPlatMan = require "Social.ECTeamPlatformManager"
		ECTeamPlatMan.Instance():ClearRegisterInfo()

		local ECTeamPlatformPage =  require "Social.ECTeamPlatformPage"
		local TeamPlatform = ECTeamPlatformPage.Instance()
		if TeamPlatform.m_panel then
			TeamPlatform:ShowPanel(false)
		end

		local ECPanelTeam = require "GUI.ECPanelTeam"
  		ECPanelTeam.Instance():SelectSubPanel(ECPanelTeam.MainPanel.Team)

  		local ECPanelActivityDate =  require "GUI.ECPanelActivityDate"
		if ECPanelActivityDate.Instance():IsVisible() then
			ECPanelActivityDate.Instance():Toggle()
		end
  	else

		FlashTipMan.FlashTip(StringTable.Get(13032 + msg.retcode - 900))
		--FlashTipMan.FlashTip(StringTable.Get(13060 - 301 + msg.retcode))
  	end
end

pb_helper.AddHandler("npt_platform_join_team_result", on_platform_join_team_result)


local function on_platform_cancel_result( sender,msg )
	print("platform_cancel_result")
	if msg.retcode ~=0 then
		FlashTipMan.FlashTip(StringTable.Get(13032 + msg.retcode - 900))
		--FlashTipMan.FlashTip(StringTable.Get(13060 - 301 + msg.retcode))
	else
		print("___________________________on_platform_cancel_result")
		FlashTipMan.FlashTip(StringTable.Get(13028))
		local ECTeamPlatMan = require "Social.ECTeamPlatformManager"
		ECTeamPlatMan.Instance():CancelMatchResult(msg)

		local ECPanelActivityDate =  require "GUI.ECPanelActivityDate"
		if ECPanelActivityDate.Instance():IsVisible() then
			ECPanelActivityDate.Instance():UpdateActivityListView(false)
		end
  	end

	--local ECTeamPlatformPage =  require "Social.ECTeamPlatformPage"
	--local TeamPlatform = ECTeamPlatformPage.Instance()
	--if TeamPlatform.m_panel then --不要这样判断 排队信息其他模块也要用 by: Niuyadong
	--	TeamPlatform:CancelMatchResult(msg)
	--end

end

pb_helper.AddHandler("npt_platform_cancel_result", on_platform_cancel_result)


local function on_platform_join_team_notify( sender,msg )
	print("platform_join_team_notify")
	local ECTeamPlatformPage =  require "Social.ECTeamPlatformPage"
	local TeamPlatform = ECTeamPlatformPage.Instance()
	if TeamPlatform.m_panel then
		TeamPlatform:ShowPanel(false)
	end

	local ECPanelTeam = require "GUI.ECPanelTeam"
  	ECPanelTeam.Instance():SelectSubPanel(ECPanelTeam.MainPanel.Team)

  	local ECPanelActivityDate =  require "GUI.ECPanelActivityDate"
	if ECPanelActivityDate.Instance():IsVisible() then
		ECPanelActivityDate.Instance():Toggle()
	end
end

pb_helper.AddHandler("npt_platform_join_team_notify", on_platform_join_team_notify)

--npt_platform_team_reach_max
local function on_platform_platform_team_reach_max( sender,msg )
	print("npt_platform_team_reach_max")
	FlashTipMan.FlashTip(StringTable.Get(13018))
end

pb_helper.AddHandler("npt_platform_team_reach_max", on_platform_platform_team_reach_max)

--npt_platform_team_reach_min
local function on_platform_team_reach_min( sender,msg )
	print("npt_platform_team_reach_min")
	FlashTipMan.FlashTip(StringTable.Get(13019))
end

pb_helper.AddHandler("npt_platform_team_reach_min", on_platform_team_reach_min)

--npt_platform_add_member_notify
local function on_platform_add_member_notify( sender,msg )
	print("npt_platform_add_member_notify")
	FlashTipMan.FlashTip(StringTable.Get(13020):format(GameUtil.UnicodeToUtf8(msg.member.name),msg.cur_size))

	local ECTeamPlatformPage =  require "Social.ECTeamPlatformPage"
	local TeamPlatform = ECTeamPlatformPage.Instance()
	if TeamPlatform.m_panel then
		TeamPlatform:GetTeamList()
	end
end

pb_helper.AddHandler("npt_platform_add_member_notify", on_platform_add_member_notify)


--npt_platform_rejoin_notify
--组队平台队长变更，通知新队长是否重新排队
local function on_platform_rejoin_notify( sender,msg )
	print("npt_platform_rejoin_notify")

	local platformCfg = _G.require_config("Configs/platform_activity_list.lua")
	local platActCfg = platformCfg.ActivityInfo
	

	local actInfo ={}
	local find = false
	for i = 1, #platActCfg do
		local actlist = platActCfg[i].actlist
		for j=1,#actlist do
			if actlist[j].acttype == msg.category and actlist[j].tid == msg.tid then
				actInfo =  actlist[j]
				find = true
				break
			end
		end
		if find == true then break end
	end

	local function _OnClick(sender, ret)
		if MsgBox.MsgBoxRetT.MBRT_OK == ret then
			local pb_helper = require "PB.pb_helper"
			local client_msg = require "PB.client_msg"
			local npt_platform_register = client_msg.npt_platform_register

			local hp = ECGame.Instance().m_HostPlayer
			if hp then
				local level = hp.InfoData.Lv
				local recommandLv_min = level - actInfo.level_range
				local recommandLv_max = level + actInfo.level_range

				local minlevel = (actInfo.level_limit_min > recommandLv_min) and actInfo.level_limit_min or recommandLv_min
				local maxlevel = recommandLv_max

				if minlevel > maxlevel then	 --玩家等级不符合
					FlashTipMan.FlashTip(StringTable.Get(13026))
					return
				else
					local newmsg = npt_platform_register()
					newmsg.roleid = ECGame.Instance().m_HostInfo.id
					newmsg.tid = msg.tid
					newmsg.category = msg.category
					newmsg.teamid = ECGame.Instance().m_HostPlayer.TeamID
					pb_helper.Send(newmsg)
				end
			end
		end
	end


	local LIFETIME = 15
	local function _OnTimer(thebox)
		thebox.content =  string.format(StringTable.Get(13052),actInfo.name , thebox.LifeTime)
		thebox:UpdateUI()

		thebox:SetOkText(StringTable.Get(13090))
		thebox:SetCancleText(StringTable.Get(13091))
		if thebox.LifeTime <= 0 then
			_OnClick(MsgBox.MsgBoxRetT.MBRT_CANCEL)
		end
	end

	local box = MsgBox.ShowMsgBox(nil, string.format(StringTable.Get(13052),actInfo.name ,LIFETIME), nil, 
		MsgBox.MsgBoxType.MBBT_OKCANCEL,
		_OnClick,
		LIFETIME,
		_OnTimer
		)
	box:SetOkText(StringTable.Get(13090))
	box:SetCancleText(StringTable.Get(13091))
	--MsgBox.ShowMsgBox(nil, StringTable.Get(13052):format(actInfo.name), nil, MsgBox.MsgBoxType.MBBT_OKCANCEL, _OnClick, 30)
end

pb_helper.AddHandler("npt_platform_rejoin_notify", on_platform_rejoin_notify)

--npt_platform_reginfo_result
local function on_platform_reginfo_result( sender,msg )
	print("npt_platform_reginfo_result")

	local ECTeamPlatMan = require "Social.ECTeamPlatformManager"
	ECTeamPlatMan.Instance():RegisterInfoRe(msg)

	--local ECTeamPlatformPage =  require "Social.ECTeamPlatformPage"
	--local TeamPlatform = ECTeamPlatformPage.Instance()
	--if TeamPlatform.m_panel then --不要这样判断 排队信息其他模块也要用 by: Niuyadong
	--	TeamPlatform:RegisterInfoResult(msg)
	--end

	local ECPanelActivityDate =  require "GUI.ECPanelActivityDate"
	if ECPanelActivityDate.Instance():IsVisible() then
		ECPanelActivityDate.Instance():UpdateActivityListView(false)
	end
end

pb_helper.AddHandler("npt_platform_reginfo_result", on_platform_reginfo_result)