local Lplus = require "Lplus"

local client_msg = require "PB.client_msg"
local pb_helper = require "PB.pb_helper"
local ECGame = require "Main.ECGame"

--local _has_showed = false
-------------------------------------------------------------------------------
local function on_gp_vip_info(sender, msg)
	--warn("on_gp_vip_info",msg)
	--print_hsh("on_gp_vip_info  ",msg)
	--print_hsh("on_gp_vip_info  ",msg.bonus_mask)
	local ECGame = require "Main.ECGame"
	local ECPlayer = require "Players.ECPlayer"
	
	if ECGame.Instance().mGameState ~= GameState.GameWorld then
		warn("got vip info, but is not in world", ECGame.Instance().mGameState)
		return
	end

	local world = ECGame.Instance().m_CurWorld
	local player = nil
	local player_id = ZeroUInt64
	if msg.new_id == 0 then  -- 自己的VIP信息
		player = ECGame.Instance().m_HostPlayer
		player_id = player.ID
	else -- 广播玩家VIP信息
		player_id = GetOldID(msg.new_id)
		player = world:FindObjectOrHost(player_id)
	end

	if player ~= nil and player:is(ECPlayer) then 
		if player.m_VipInfo == nil then
			local ECVIPInfo = require "Players.ECVIPInfo"
			player.m_VipInfo = ECVIPInfo.new()
		end

		--print("gp_vip_info msg.system_close ", msg.system_close)
		
		player.m_VipInfo.system_close = msg.system_close
		player.m_VipInfo.cur_vip_level = msg.cur_vip_level
		player.m_VipInfo.reward_vip_level = msg.reward_vip_level
		player.m_VipInfo.reward_vip_end_time = msg.reward_vip_end_time
		player.m_VipInfo.buy_force_times_today  = msg.buy_force_times_today
		player.m_VipInfo.bonus_mask = msg.bonus_mask
	end

	local hp = ECGame.Instance().m_HostPlayer
	if player_id == hp.ID and hp.InfoData ~= nil and hp.InfoData.Lv < require "Social.ECServerLevel".Instance().curServerLevel then
		local offline_exp = LuaUInt64.ToDouble(msg.online.logout_exp_last)
		if offline_exp > 0 then --and not _has_showed then
			local nowtime = os.date("*t", GameUtil.GetServerGMTTime())
			local year,month,day = nowtime.year,nowtime.month,nowtime.day
			local ECPanelStayOffline = require "GUI.ECPanelStayOffline"
			if not ECPanelStayOffline.Instance():IsTheSameDate(year,month,day) then
				ECPanelStayOffline.Instance():RequestAutoPopup(function(panel)
					panel:UpdateCheckinDay(year,month,day)
					panel.OfflineExp = offline_exp
					panel:ShowPanel(true)
				end)
			end
		end
	end
	
	if player_id ~= ZeroUInt64 then
		local VIPInfoChangeEvent = require "Event.VIPInfoChangeEvent"
		local event = VIPInfoChangeEvent()
		event.who = player_id
		event.lv = msg.cur_vip_level
		ECGame.EventManager:raiseEvent(nil, event)
	end
	
	if _G.IsEvaluation() then
		if msg.cur_vip_level ~= 0 then
			warn("bad vip info: ", msg)
		end
	end
end
pb_helper.AddHandler("gp_vip_info", on_gp_vip_info)
-------------------------------------------------------------------------------

--[[
local function on_gp_vip_privilege_notify(sender, msg)

	local ECGame = require "Main.ECGame"
	local function func()
		local ECPlayer = require "Players.ECPlayer"
		local player = ECGame.Instance().m_HostPlayer
		if player.m_VipInfo == nil then
			local ECVIPInfo = require "Players.ECVIPInfo"
			player.m_VipInfo = ECVIPInfo.new()
		end
		local oldVipCardType = player.m_VipInfo.cur_vipCard_type;
		local oldExpire_time = player.m_VipInfo.expire_time;
		local OldAvailable = oldVipCardType > 0 and oldExpire_time > 0;
		player.m_VipInfo.cur_vipCard_type	= msg.card_type
		player.m_VipInfo.expire_time		= LuaInt64.ToDouble(msg.expire_time);
		player.m_VipInfo.can_got_daily_gift	= msg.can_got_daily_gift;
		--warn("********************** cur_vipCard_type expire_time",msg.card_type,player.m_VipInfo.expire_time);
		local VIPCardInfoChangeEvent = require "Event.VIPCardInfoChangeEvent"
		local event = VIPCardInfoChangeEvent();
		event.card_type = msg.card_type;
		event.expire_time = LuaInt64.ToDouble(msg.expire_time);
		event.can_got_daily_gift = msg.can_got_daily_gift;

		ECGame.EventManager:raiseEvent(nil, event)

		if not _G.IsEvaluation() then
			if(oldVipCardType ~= player.m_VipInfo.cur_vipCard_type)then-- 新旧不同并且新的有
				if(oldVipCardType >= 0 and player.m_VipInfo.cur_vipCard_type ~= 0 and player.m_VipInfo.expire_time > 0)then-- 新的有效 并且初始化过(oldVipCardType >= 0)
					local cardName = StringTable.Get(1422 - 1 + player.m_VipInfo.cur_vipCard_type);
					FlashTipMan.FlashTip( string.format( StringTable.Get(1428),cardName));-- 激活%s特权卡
				elseif((player.m_VipInfo.cur_vipCard_type == 0 or player.m_VipInfo.expire_time == 0)and OldAvailable == true)then-- 新的无效 并且老的有效
					local cardName = StringTable.Get(1422 - 1 + oldVipCardType);
					FlashTipMan.FlashTip( string.format( StringTable.Get(1429),cardName));-- %s特权卡过期了
				end
			end
		end
	end

	ECGame.Instance():OnHostPlayerCreate(func);
end]]

local function on_gp_vip_privilege_notify(sender, msg)
	--print("on_gp_vip_privilege_notify",msg)
	local function func()
		local ECPlayer = require "Players.ECPlayer"
		local player = ECGame.Instance().m_HostPlayer
		if player.m_VipCard == nil then
			local ECVIPCard = require "Players.ECVIPCard"
			player.m_VipCard = ECVIPCard.new()
		end
		
		player.m_VipCard:OnGetMsg(msg)
	end

	ECGame.Instance():OnHostPlayerCreate(func);
end
-- pb_helper.AddHandler("gp_vip_privilege_notify", on_gp_vip_privilege_notify)
-------------------------------------------------------------------------------
