--匹配进副本后的临时队伍

--
-- gp_match_team_list
-- 
local pb_helper = require "PB.pb_helper"

local function OnGetMatchTeamList(sender, msg)
	local ECTemporaryTeamMan = require "Social.ECTemporaryTeamMan"
	ECTemporaryTeamMan.Instance():OnGetMatchTeamList(msg)
end

pb_helper.AddHandler("gp_match_team_list", OnGetMatchTeamList)


local function OnXiaoduiMatch(sender, msg)
	print("OnXiaoduiMatch", msg)
end

pb_helper.AddHandler("npt_xiaodui_automatch", OnXiaoduiMatch)
