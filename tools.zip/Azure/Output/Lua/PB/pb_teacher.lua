--PB Teacher
-----------------------------------------
---Source Requirement
-----------------------------------------

local Lplus = require "Lplus"
local pb_helper = require "PB.pb_helper"
---@type ECGame
local ECGame = Lplus.ForwardDeclare("ECGame")
local client_msg = require "PB.client_msg"
local HtmlUtility = require "Utility.HtmlUtility"
local ECTeacherManager = require "Teacher.ECTeacherManager"
---@type ECChatManager
local ECChatManager = Lplus.ForwardDeclare("ECChatManager")
local RecommendTeacherEvent = require "Event.RecommendTeacherEvent"

-----------------------------------------
---Local Attribute
-----------------------------------------

local errorCode2Str = {}
errorCode2Str[client_msg.TEC_HAS]                = 23106
errorCode2Str[client_msg.TEC_STUDENT_FU]         = 23107
errorCode2Str[client_msg.TEC_LEVEL_S]            = 23108
errorCode2Str[client_msg.TEC_LEVEL_T]            = 23109
errorCode2Str[client_msg.TEC_IN_TEAM_S]          = 23110
errorCode2Str[client_msg.TEC_IN_TEAM_T]          = 23111
errorCode2Str[client_msg.TEC_IN_INST_S]          = 23112
errorCode2Str[client_msg.TEC_IN_INST_T]          = 23113
errorCode2Str[client_msg.TEC_TEAM_CHECK]         = 23114
errorCode2Str[client_msg.TEC_TEAM_JOIN]          = 23115
errorCode2Str[client_msg.TEC_NO_INTENT]          = 23116
errorCode2Str[client_msg.TEC_NO_APPLY]           = 23117
errorCode2Str[client_msg.TEC_JUMP]               = 23118
errorCode2Str[client_msg.TEC_REMOVE_LEVEL]       = 23119
errorCode2Str[client_msg.TEC_COST_ITEM_PRE]      = 23120
errorCode2Str[client_msg.TEC_COST_ITEM]          = 23121
errorCode2Str[client_msg.TEC_HELLO]              = 23122
errorCode2Str[client_msg.TEC_CD_S]               = 23123
errorCode2Str[client_msg.TEC_CD_T]               = 23124
errorCode2Str[client_msg.TEC_LEVEL_RANK]         = 23125
errorCode2Str[client_msg.TEC_FRIEND_FULL_S]      = 23126
errorCode2Str[client_msg.TEC_FRIEND_FULL_T]      = 23127
errorCode2Str[client_msg.TEC_HAS_STUDENT]        = 23128
errorCode2Str[client_msg.TEC_NO_REWARD]          = 23129
errorCode2Str[client_msg.TEC_STUDENT_P_LESS]     = 23130
errorCode2Str[client_msg.TEC_NO_MORE_REWARD]     = 23131
errorCode2Str[client_msg.TEC_TEACHER_OFFLINE]    = 23132
errorCode2Str[client_msg.TEC_STUDENT_WANT_LEAVE] = 23133
errorCode2Str[client_msg.TEC_LEAVE_TEACHER]      = 23134

-----------------------------------------
---Message Handler
-----------------------------------------

--
--Teacher login
--
local function npt_teacher_login(sender, msg)
	--print("=================npt_teacher_login========mt=="..msg.mt.."===param=="..msg.param)

	if msg.mt == client_msg.npt_teacher_login.MT_STUDENT_LOGIN then
		if msg.param and msg.param == 1 then
			MsgBox.ShowMsgBox(nil,StringTable.Get(23142),nil,MsgBoxType.MBBT_OKCANCEL,function(_,retval)
				if retval == MsgBox.MsgBoxRetT.MBRT_OK then
					local ECPanelCommunication = require "GUI.ECPanelCommunication"
					ECPanelCommunication.Instance():OpenTeacherPanel(true)
				end
			end)
		else
			ECChatManager.Instance():AddSimpleMessage(StringTable.Get(23143), _G.CONSTANT_DEFINE.CHAT_CHANNEL_SYSTEM)
		end
	elseif msg.mt == client_msg.npt_teacher_login.MT_TEACHER_LOGIN then
		ECChatManager.Instance():AddSimpleMessage(StringTable.Get(23144), _G.CONSTANT_DEFINE.CHAT_CHANNEL_SYSTEM)
	end
end
--pb_helper.AddHandler("npt_teacher_login", npt_teacher_login)

--
--gp_teacher_sc
--
local function on_teacher_sc(sender, msg) 
	--print("=================on_teacher_sc==========")
	local send = msg.ref
	if not msg.error_code or msg.error_code == client_msg.TEC_SUCCESS then

		if send.opt == client_msg.RELATION_INFO then --收到师徒基本信息
			local ECTeacherData = require "Data.ECTeacherData"
			ECTeacherData.Instance():OnTeacherInfo(msg)
			if send.value and send.value == 1 then --跳转到师徒界面
				MsgBox.ShowMsgBox(nil, StringTable.Get(23182), nil, MsgBoxType.MBBT_OKCANCEL, function (sender, ret)
					if MsgBoxRetT.MBRT_OK == ret then
						local ECPanelCommunication = require "GUI.ECPanelCommunication"
						ECPanelCommunication.Instance():OpenTeacherPanel(true)
					end
				end)
			end
		elseif msg.name and send.opt == client_msg.INTENT_T2S and send.rid_src ~= ECGame.Instance().m_HostInfo.id then --收到收徒请求

			local desc = StringTable.Get(23138):format(GameUtil.UnicodeToUtf8(msg.name))
			desc = HtmlUtility.HtmlToNguiText(desc)
			MsgBox.ShowMsgBox(nil,desc,nil,MsgBoxType.MBBT_OKCANCEL,function(_,retval)
				if retval == MsgBox.MsgBoxRetT.MBRT_OK then
					ECTeacherManager.Instance():AnswerToTeacher(send.rid_src, true)
				elseif retval == MsgBox.MsgBoxRetT.MBRT_CANCEL then
					ECTeacherManager.Instance():AnswerToTeacher(send.rid_src, false)
				end
			end,10,function(box)
				if box.LifeTime >0 then
					local cancelTxt = StringTable.Get(23140):format(box.LifeTime)
					box:SetCancleText(cancelTxt)
				else
					box:onClick("Btn_Refuse")
				end
			end,nil,function(box)
				box:SetOkText(StringTable.Get(23139))
				local cancelTxt = StringTable.Get(23140):format(box.LifeTime)
				box:SetCancleText(cancelTxt)
			end)
		elseif send.opt == client_msg.INTENT_T2S_RE then	--收到徒弟回复
			if send.agree == false then
				FlashTipMan.FlashTip(StringTable.Get(23141))
			end
		elseif send.opt == client_msg.TEACHER_ANSWER then  --报名当师父
			if send.value then
				local ECTeacherData = require "Data.ECTeacherData"
				ECTeacherData.Instance():OnSignCount(send.value)
			end
		elseif send.opt == client_msg.ANSWER_SELECT_TEACHER then	--徒弟答完题收到推荐师父回报
			if msg.apply_teacher_info then
				local event
				if #msg.apply_teacher_info > 0 then
					event = RecommendTeacherEvent.new(RecommendTeacherEvent.EventType.Normal,msg.apply_teacher_info[1])
				else
					event = RecommendTeacherEvent.new(RecommendTeacherEvent.EventType.Normal,nil)
				end
				ECGame.EventManager:raiseEvent(nil, event)
			end
		elseif send.opt == client_msg.INTENT_OR_APPLY_S2T then		--名师推荐徒弟意向拜师
			
			if send.rid_src == ECGame.Instance().m_HostInfo.id then --拜师徒弟方收到协议
				ECTeacherManager.Instance():ToBeStudent(nil, true) --reselect teacher
			else --拜师师父方收到协议
				local desc = StringTable.Get(23135):format(GameUtil.UnicodeToUtf8(msg.name))
				desc = HtmlUtility.HtmlToNguiText(desc)
				MsgBox.ShowMsgBox(nil,desc,nil,MsgBoxType.MBBT_OKCANCEL,function(_,retval)
					if retval == MsgBox.MsgBoxRetT.MBRT_OK then
						ECTeacherManager.Instance():ReplyToStudentForRecommend(send.rid_src,true)
					elseif retval == MsgBox.MsgBoxRetT.MBRT_CANCEL then
						ECTeacherManager.Instance():ReplyToStudentForRecommend(send.rid_src,false)
					end
				end,60,function(box)
					if box.LifeTime >0 then
						local cancelTxt = StringTable.Get(23140):format(box.LifeTime)
						box:SetCancleText(cancelTxt)
					else
						box:onClick("Btn_Refuse")
					end
				end,nil,function(box)
					box:SetOkText(StringTable.Get(23139))
					local cancelTxt = StringTable.Get(23140):format(box.LifeTime)
					box:SetCancleText(cancelTxt)
				end)
			end
		elseif (send.opt == client_msg.ACCEPT_TASK_REWARD or send.opt == client_msg.ACCEPT_INSTANCE_REWARD) and send.rid_src == ECGame.Instance().m_HostInfo.id then
			ECTeacherManager.Instance():RequestTeacherInfoMsg(0)
		elseif send.opt == client_msg.HELLO_S2T and send.rid_src == ECGame.Instance().m_HostInfo.id then
			FlashTipMan.FlashTip(StringTable.Get(23179))
			ECTeacherManager.Instance():RequestTeacherInfoMsg(0)
		elseif send.opt == client_msg.HELLO_T2S and send.rid_src == ECGame.Instance().m_HostInfo.id then
			FlashTipMan.FlashTip(StringTable.Get(23179))
			ECTeacherManager.Instance():RequestTeacherInfoMsg(0)
		elseif send.opt == client_msg.HELLO_S2S and send.rid_src == ECGame.Instance().m_HostInfo.id then
			FlashTipMan.FlashTip(StringTable.Get(23179))
			ECTeacherManager.Instance():RequestTeacherInfoMsg(0)
		elseif send.opt == client_msg.REMOVE_TA then
			ECChatManager.Instance():AddSimpleMessage(StringTable.Get(23176), _G.CONSTANT_DEFINE.CHAT_CHANNEL_SYSTEM)
			ECTeacherManager.Instance():RequestTeacherInfoMsg(0)
		elseif send.opt == client_msg.REMOVE_T_NO then
			MsgBox.ShowMsgBox(nil,StringTable.Get(23171),nil,MsgBoxType.MBBT_OKCANCEL,function(_,retval)
				if retval == MsgBox.MsgBoxRetT.MBRT_OK then
					ECTeacherManager.Instance():LeaveTeacher(send.rid_src, 1)
				elseif retval == MsgBox.MsgBoxRetT.MBRT_CANCEL then
				end
			end,nil,nil,nil,function(box)
				box:SetCancleText(StringTable.Get(23172))
			end)
		elseif send.opt == client_msg.REMOVE_S2T then --徒弟申请出师
			if send.rid_target == ECGame.Instance().m_HostInfo.id then --师父方'
				local ECTeacherData = require "Data.ECTeacherData"
				local studentInfo = ECTeacherData.Instance():GetStudentInfo(send.rid_src)
				if send.is_force == 1 then --强制出师
					ECChatManager.Instance():AddSimpleMessage(StringTable.Get(23177):format(studentInfo.name), _G.CONSTANT_DEFINE.CHAT_CHANNEL_SYSTEM)
					ECTeacherManager.Instance():RequestTeacherInfoMsg(0)
				end
			elseif send.rid_src == ECGame.Instance().m_HostInfo.id then --徒弟方
				ECTeacherManager.Instance():RequestTeacherInfoMsg(0)
			end
		elseif send.opt == client_msg.REMOVE_T2S then --师父逐出师门
			if send.rid_target == ECGame.Instance().m_HostInfo.id and send.is_force then 
				local ECTeacherData = require "Data.ECTeacherData"
				ECChatManager.Instance():AddSimpleMessage(StringTable.Get(23177):format(ECTeacherData.Instance().teacherInfo.name), _G.CONSTANT_DEFINE.CHAT_CHANNEL_SYSTEM)
				ECTeacherManager.Instance():RequestTeacherInfoMsg(0)
			elseif send.rid_src == ECGame.Instance().m_HostInfo.id then
				ECTeacherManager.Instance():RequestTeacherInfoMsg(0)
			end
		end
	elseif msg.error_code == client_msg.TEC_STUDENT_WANT_LEAVE then
		if send.rid_target == ECGame.Instance().m_HostInfo.id then --师父方'
				local ECTeacherData = require "Data.ECTeacherData"
				local studentInfo = ECTeacherData.Instance():GetStudentInfo(send.rid_src)
				if send.is_force == 0 then --强制出师
					local leaveType = ECTeacherData.Instance():GetLeaveType(studentInfo)
					MsgBox.ShowMsgBox(nil,StringTable.Get(23173):format(studentInfo.name),nil,MsgBoxType.MBBT_OKCANCEL,function(_,retval)
						if retval == MsgBox.MsgBoxRetT.MBRT_OK then
							ECTeacherManager.Instance():ReplyStudentLeave(send.rid_src, true)
						elseif retval == MsgBox.MsgBoxRetT.MBRT_CANCEL then
							ECTeacherManager.Instance():ReplyStudentLeave(send.rid_src, false)
						end
					end)
				end
		end
	elseif msg.error_code == client_msg.TEC_CD_T then
		FlashTipMan.FlashTip(StringTable.Get(23186))
	elseif msg.error_code == client_msg.TEC_CD_S then
		FlashTipMan.FlashTip(StringTable.Get(23187))
	elseif msg.error_code == client_msg.TEC_NO_TEACHER then
		ECGame.EventManager:raiseEvent(nil, RecommendTeacherEvent.new(RecommendTeacherEvent.EventType.NoMore,nil))
	elseif msg.error_code == client_msg.TEC_TEN_COUNT then
		ECGame.EventManager:raiseEvent(nil, RecommendTeacherEvent.new(RecommendTeacherEvent.EventType.TenCount,nil))
	elseif msg.error_code == client_msg.TEC_THREE_APPLY then
		ECGame.EventManager:raiseEvent(nil, RecommendTeacherEvent.new(RecommendTeacherEvent.EventType.ThreeApply,nil))
	elseif msg.error_code == client_msg.TEC_TEACHER_OFFLINE then
		if send.opt == client_msg.REMOVE_S2T then --徒弟申请出师
			MsgBox.ShowMsgBox(nil,StringTable.Get(23168),nil,MsgBoxType.MBBT_OKCANCEL,function(_,retval)
				if retval == MsgBox.MsgBoxRetT.MBRT_OK then
					ECTeacherManager.Instance():LeaveTeacher(send.rid_target, 1)
				elseif retval == MsgBox.MsgBoxRetT.MBRT_CANCEL then
				end
			end,nil,nil,nil,function(box)
				box:SetCancleText(StringTable.Get(23169))
			end)
		end
	elseif msg.error_code == client_msg.TEC_LEAVE_TEACHER then
		if send.opt == client_msg.REMOVE_S2T and send.rid_target == ECGame.Instance().m_HostInfo.id then
			ECChatManager.Instance():AddSimpleMessage(StringTable.Get(23174), _G.CONSTANT_DEFINE.CHAT_CHANNEL_SYSTEM)
			require "GUI.ECPanelCommunication".Instance():DestroyPanel()
			ECTeacherManager.Instance():RequestTeacherInfoMsg(0)
		elseif send.opt == client_msg.REMOVE_T2S and send.rid_target == ECGame.Instance().m_HostInfo.id then
			ECChatManager.Instance():AddSimpleMessage(StringTable.Get(23175), _G.CONSTANT_DEFINE.CHAT_CHANNEL_SYSTEM)
			require "GUI.ECPanelCommunication".Instance():DestroyPanel()
			ECTeacherManager.Instance():RequestTeacherInfoMsg(0)
		end
	elseif errorCode2Str[msg.error_code] ~= nil then
		FlashTipMan.FlashTip(StringTable.Get(errorCode2Str[msg.error_code]))
	end
end
pb_helper.AddHandler("gp_teacher_sc", on_teacher_sc)