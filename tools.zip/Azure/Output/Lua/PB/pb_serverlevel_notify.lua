local Lplus = require "Lplus"
local pb_helper = require "PB.pb_helper"
local client_msg = require "PB.client_msg"

-- 巅峰等级信息
local function gp_serverlevel_notify(sender,msg)
	--warn("收到巅峰等级信息: ", msg)
	require "Social.ECServerLevel".Instance():InitData(msg.repid,msg.server_level,msg.next_serverlevel,msg.days_later,msg.valid_role_level,msg.scale)
end
pb_helper.AddHandler("gp_serverlevel_notify", gp_serverlevel_notify)

-- 活动经验组
local function gp_player_exp(sender, msg)
	---@type ECGame
	local ECGame = Lplus.ForwardDeclare("ECGame")
	local function updateEventExpInfo ()
		local EventExpMap = ECGame.Instance().m_HostPlayer.InfoData.EventExpMap
		-- warn("gp_player_exp",msg)
		for k, v in pairs(msg.data.data) do
			local index = k
			local cfg = ElementData.getDataByName("PlayerExpType", index)
			local limitId = cfg and cfg.general_param_id or 0
			local num = LuaInt64.ToDouble(v.num)
			local max = LuaInt64.ToDouble(v.max_exp)

			if not EventExpMap[index] then
				EventExpMap[index] = {}
			end

			EventExpMap[index].limitId  = limitId
			EventExpMap[index].num      = num
			EventExpMap[index].ratio    = v.ratio
			EventExpMap[index].max      = max
		end

		if msg.data.yingfu_max > 0 then
			ECGame.Instance().m_HostPlayer.InfoData.YingfuMax = msg.data.yingfu_max --储备经验上限	
		end

		local NotifyEventExp = require "Event.NotifyEventExp"
		local p = NotifyEventExp()
		ECGame.EventManager:raiseEvent(nil, p)
	end
	--确保 m_HostPlayer创建完成
	ECGame.Instance():OnHostPlayerCreate(updateEventExpInfo)
end
pb_helper.AddHandler("gp_player_exp", gp_player_exp)