local Lplus = require "Lplus"

local pb_helper = require "PB.pb_helper"
local ECGame = require "Main.ECGame"
--
-- gp_tarot_re
--
local function on_mondaystay(sender, msg)
	local ECMondayStay = require "Players.ECMondayStay"
	ECMondayStay.Instance():InitData(msg.day_index,msg.data)

	local MondayStayEvent = require "Event.MondayStayEvent"
	local p = MondayStayEvent()

	ECGame.EventManager:raiseEvent(nil, p)
end
--pb_helper.AddHandler("gp_monday_stay_re", on_mondaystay)