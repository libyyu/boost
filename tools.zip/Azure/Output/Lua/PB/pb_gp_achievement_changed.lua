local pb_helper = require "PB.pb_helper"
local ECGame = require "Main.ECGame"


--[[
message gp_achievement_changed {
    option (s2c_type)         = type_gp_achievement_changed;
    enum ACHIEVE_OP {
        AO_ALL      = 0;  //全量
        AO_RESET    = 1;  //成就重置
    }; 
    ACHIEVE_OP achieve_op       = 2;  
    repeated int32 unlock_set   = 3;
}
]]

local function OnAchievementUnLockChanged(sender, msg)
	local unlockList = msg.unlock_set
	local ECTitleAndChivement = require "Data.ECTitleAndChivement"
	ECTitleAndChivement.ChangeUnlockAchievementList(unlockList)

	--print_wyl("------gp_achievement_changed------msg---", msg.achieve_op, #unlockList)
	if msg.achieve_op == 1 then
		ECTitleAndChivement.Instance():ResetAchievementST(unlockList)
	end

	local AchievementChangedEvent = require("Event.ProfessionAchievementEvent").AchievementChangedEvent
	ECGame.EventManager:raiseEvent(nil, AchievementChangedEvent())
end
 
pb_helper.AddHandler("gp_achievement_changed", OnAchievementUnLockChanged)




