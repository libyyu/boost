local pb_helper = require "PB.pb_helper"

--
-- gp_red_packet 发红包
-- 
local function gp_red_packet(_, msg)
	local ECRedPacketMan = require "Main.ECRedPacketMan"
	ECRedPacketMan.Instance():onRedPacketGet(msg)
end
pb_helper.AddHandler("gp_red_packet", gp_red_packet)

--
--npt_get_red_package 红包结果
--
local function gp_red_packet_rep(_, msg)
	local ECRedPacketMan = require "Main.ECRedPacketMan"
	ECRedPacketMan.Instance():onRedPacketReq(msg)
end
pb_helper.AddHandler("gp_red_packet_rep", gp_red_packet_rep)

--
--gp_red_packet_data 红包库存
--
local function gp_red_packet_data(_, msg)
	local ECRedPacketMan = require "Main.ECRedPacketMan"
	ECRedPacketMan.Instance():onRedPacketData(msg)
end
pb_helper.AddHandler("gp_red_packet_data", gp_red_packet_data)


