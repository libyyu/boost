if _G.MarkReloadAfterUpdate then _G.MarkReloadAfterUpdate() end

local config_name = (_G.GIsEditor and "EntryPointConfig.Editor" or "EntryPointConfig.Client")
local platform_name = GameUtil.GetPlatformName()
if platform_name == "Windows" then
elseif platform_name == "IOS" then
	config_name = "EntryPointConfig.IOS"
elseif platform_name == "Android" then
	config_name = "EntryPointConfig.Android"
end
print("EntryPoint config name:", config_name)
return require(config_name)