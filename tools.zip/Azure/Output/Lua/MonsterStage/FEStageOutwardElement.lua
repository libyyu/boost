--[[
	阶段特效的基类
]]

local Lplus = require "Lplus"
local FEStageOutwardElementId = require "MonsterStage.FEStageOutwardElementId"
local ECNPC = require "NPCs.ECNPC"
local monster_stage_cfg = _G.GetConfigLua("Configs/npc/monster_stage_cfg.lua")

---@class FEStageOutwardElement:System.Object
---@field public element_id FEStageOutwardElementId
---@field public target ECNPC
---@field public cfg table
---@field public Commit fun():FEStageOutwardElement @notnull
---@field public Play fun(self:FEStageOutwardElement, bTransition:boolean)
---@field public Destroy fun(self:FEStageOutwardElement)
---@field public CanReuse fun(self:FEStageOutwardElement, new_id:FEStageOutwardElementId):boolean
---@field protected _GetTargetModel fun(self:FEStageOutwardElement, target:number):ECModel
local FEStageOutwardElement = Lplus.Class("FEStageOutwardElement")
local def = FEStageOutwardElement.define

---@type FEStageOutwardElementId
def.field(FEStageOutwardElementId).element_id = nil

---@type ECNPC
def.field(ECNPC).target = nil

---@type table
def.field("table").cfg = nil

---@param self FEStageOutwardElement
---@param bTransition boolean
---@return void
def.virtual("boolean").Play = function(self, bTransition)
	
end

---@param self FEStageOutwardElement
---@return void
def.virtual().Destroy = function(self)

end

---@param self FEStageOutwardElement
---@param new_id FEStageOutwardElementId
---@return boolean
def.virtual(FEStageOutwardElementId, "=>", "boolean").CanReuse = function(self, new_id)
	return false
end

---@param self FEStageOutwardElement
---@param target number
---@return ECModel
def.method("number", "=>", "table")._GetTargetModel = function(self, target)
	local target_type = monster_stage_cfg.target_type
	if target == target_type.body then
		return self.target:GetShowModel()
	end

	return nil
end



return FEStageOutwardElement.Commit()