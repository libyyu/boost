--[[
	识别单个阶段特效
]]
local Lplus = require "Lplus"

---@class FEStageOutwardElementId:System.Object
---@field public stage_index number
---@field public element_index number
---@field public Commit fun():FEStageOutwardElementId
---@field public new fun(stage_index:number, element_index:number):FEStageOutwardElementId
---@field public Equal fun(self:FEStageOutwardElementId, other:FEStageOutwardElementId):boolean
local FEStageOutwardElementId = Lplus.Class("FEStageOutwardElementId")
local def = FEStageOutwardElementId.define

---@type number
def.field("number").stage_index = 0

---@type number
def.field("number").element_index = 0

---@param stage_index number
---@param element_index number
---@return FEStageOutwardElementId
def.static("number", "number", "=>", FEStageOutwardElementId).new = function(stage_index, element_index)
	local obj = FEStageOutwardElementId()
	obj.stage_index = stage_index
	obj.element_index = element_index
	return obj
end

---@param self FEStageOutwardElementId
---@param other FEStageOutwardElementId
---@return boolean
def.method(FEStageOutwardElementId, "=>", "boolean").Equal = function(self, other)
	return self.stage_index == other.stage_index
			and self.element_index == other.element_index
end

return FEStageOutwardElementId.Commit()