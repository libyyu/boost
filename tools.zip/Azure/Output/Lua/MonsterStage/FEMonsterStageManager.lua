--[[
	管理单个怪上的阶段效果
]]

local Lplus = require "Lplus"
local ECNPC = require "NPCs.ECNPC"
local FEStageOutwardElementId = require "MonsterStage.FEStageOutwardElementId"
local FEStageOutwardElement = require "MonsterStage.FEStageOutwardElement"
local monster_stage_all_cfg = _G.GetConfigLua("Configs/npc/monster_stage_cfg.lua")

---@class FEMonsterStageManager:System.Object
---@field protected m_owner ECNPC
---@field protected m_element_map table<number, FEStageOutwardElement>
---@field protected m_stage_index number
---@field protected m_history_stages table
---@field protected m_state number
---@field public Commit fun():FEMonsterStageManager @notnull
---@field public new fun(owner:ECNPC):FEMonsterStageManager
---@field private _GetStageCfg fun(self:FEMonsterStageManager):void
---@field private _CheckConfig fun(self:FEMonsterStageManager)
---@field public InitHistoryStages fun(self:FEMonsterStageManager, history_stages:table)
---@field public PlayAllElementWhenModeReady fun(self:FEMonsterStageManager)
---@field public OnStageChange fun(self:FEMonsterStageManager, new_stage_index:number)
---@field public FindItemElement fun(self:FEMonsterStageManager, element_id:FEStageOutwardElementId):FEStageOutwardElement
---@field public GetCurStageIndex fun(self:FEMonsterStageManager):number
---@field private _CalcValidEffectList fun(self:FEMonsterStageManager, stage_changes:table):table
---@field private _CreateElement fun(self:FEMonsterStageManager, element_id:FEStageOutwardElementId):FEStageOutwardElement
---@field public GetElementConfig fun(self:FEMonsterStageManager, id:FEStageOutwardElementId):table
---@field public Release fun(self:FEMonsterStageManager)
---@field private _UpdateAnimationStateIndex fun(self:FEMonsterStageManager)
local FEMonsterStageManager = Lplus.Class("FEMonsterStageManager")
local def = FEMonsterStageManager.define

local STATE =
{
	None = 1,
	InitOver = 2,
}
---@type ECNPC
def.field(ECNPC).m_owner = nil

---@type table<number, FEStageOutwardElement>
def.field("table").m_element_map = function() return {} end

---@type number
def.field("number").m_stage_index = 0

---@type table
def.field("table").m_history_stages = function() return {} end

---@type number
def.field("number").m_state = STATE.None

---@param owner ECNPC
---@return FEMonsterStageManager
def.final(ECNPC, "=>", FEMonsterStageManager).new = function(owner)
	local object = FEMonsterStageManager()
	object.m_owner = owner
	return object
end

local function PairsNumberKey(tb)
	local function Iter(it_tb, key)
		local value
		repeat
			key, value = next(it_tb, key)
		until(key == nil or type(key) == "number")
		return key, value
	end
	return Iter, tb, nil
end

---@param self FEMonsterStageManager
---@return void
def.method("=>", "table")._GetStageCfg = function(self)
	return monster_stage_all_cfg.monster_stage_cfg[self.m_owner:GetTID()]
end

---@param self FEMonsterStageManager
---@return void
def.method()._CheckConfig = function(self)
	local stage_cfg = self:_GetStageCfg()
	if not stage_cfg then
		Log.DebugError("not find stage cfg of monster", self.m_owner.InfoData.Tid)
	end
end
---@param self FEMonsterStageManager
---@param history_stages table
---@return void
def.method("table").InitHistoryStages = function(self, history_stages)
	Log.Print("stage", "InitHistoryStages", self.m_owner:GetTID(), table.ToString(history_stages))

	self:Release()
	self.m_history_stages = history_stages
end

---@param self FEMonsterStageManager
---@return void
def.method().PlayAllElementWhenModeReady = function(self)
	self.m_state = STATE.InitOver

	local stage_cfg = self:_GetStageCfg()
	if not stage_cfg then return end

	local element_id_map = self:_CalcValidEffectList(self.m_history_stages)
	for element_index, stage_index in pairs(element_id_map) do
		local element = self:_CreateElement(FEStageOutwardElementId.new(stage_index, element_index))
		self.m_element_map[element_index] = element
		element:Play(false)
	end

	self:_UpdateAnimationStateIndex()
end


---@param self FEMonsterStageManager
---@param new_stage_index number
---@return void
def.method("number").OnStageChange = function(self, new_stage_index)
	Log.Print("stage", "OnStageChange", new_stage_index)
	self:_CheckConfig()

	table.insert(self.m_history_stages, new_stage_index)
	if self.m_state == STATE.None then
		return
	end

	if new_stage_index == 0 then
		self:Release()
		return
	end

	local stage_cfg = self:_GetStageCfg()

	--bug fix.
	if not stage_cfg then
		return
	end

	local stage_info = stage_cfg.stage[new_stage_index]
	if not stage_info then
		warn("not find stage index of ", new_stage_index, self.m_owner.InfoData.Tid)
		return
	end

	for element_index, v in PairsNumberKey(stage_info) do
		local old_element = self.m_element_map[element_index]

		local id = FEStageOutwardElementId.new(new_stage_index, element_index)
		local new_element
		-- 同一种效果的不断变化，为了保证状态连续，复用对象
		if old_element and old_element:CanReuse(id) then
			new_element = old_element
			old_element = nil

			new_element.element_id = id
			new_element.cfg = self:GetElementConfig(id)
		else
			new_element = self:_CreateElement(id)
		end

		if old_element then
			old_element:Destroy()
		end

		if new_element then
			Log.Print("stage", "Play", new_stage_index, element_index, new_element)
			new_element:Play(true)
		end
		self.m_element_map[element_index] = new_element
	end

	self:_UpdateAnimationStateIndex()
end

---@param self FEMonsterStageManager
---@param element_id FEStageOutwardElementId
---@return FEStageOutwardElement
def.method(FEStageOutwardElementId, "=>", FEStageOutwardElement).FindItemElement = function(self, element_id)
	local element = self.m_element_map[element_id.element_index]
	if element.element_id:Equal(element_id) then
		return element
	end
	return nil
end

---@param self FEMonsterStageManager
---@return number
def.method("=>", "number").GetCurStageIndex = function(self)
	return self.m_history_stages[#self.m_history_stages] or 0
end

---@param self FEMonsterStageManager
---@param stage_changes table
---@return table
def.method("table", "=>", "table")._CalcValidEffectList = function(self, stage_changes)
	local stage_cfg = self:_GetStageCfg()
	local exist_element = {}
	for i, stage_index in ipairs(stage_changes) do
		local stage_info = stage_cfg.stage[stage_index]
		if stage_info then
			for element_index, v in PairsNumberKey(stage_info) do
				if not next(v) then
					exist_element[element_index] = nil
				elseif stage_index == 0 then
					exist_element = {}
				else
					exist_element[element_index] = stage_index
				end
			end
		else
			warn("not find stage index of ", stage_index, self.m_owner.InfoData.Tid)
		end
	end

	return exist_element
end

---@param self FEMonsterStageManager
---@param element_id FEStageOutwardElementId
---@return FEStageOutwardElement
def.method(FEStageOutwardElementId, "=>", FEStageOutwardElement)._CreateElement = function(self, element_id)
	local FEStageElementAnimationSequence = require "MonsterStage.FEStageElementAnimationSequence"
	local FEStageElementSwitchWeapon = require "MonsterStage.FEStageElementSwitchWeapon"
	local FEStageElementAnimation = require "MonsterStage.FEStageElementAnimation"
	local FEElementModelScale = require "MonsterStage.FEElementModelScale"
	local FEStageElementEffect = require "MonsterStage.FEStageElementEffect"

	local stage_cfg = self:_GetStageCfg()
	local cfg = stage_cfg.stage[element_id.stage_index][element_id.element_index]
	---@type FEStageOutwardElement
	local element
	if not next(cfg) then
		return element
	end

	local element_type = monster_stage_all_cfg.element_type
	if cfg.type == element_type.effect then
		element = FEStageElementEffect()
	elseif cfg.type == element_type.model_scale then
		element = FEElementModelScale()
	elseif cfg.type == element_type.animation then
		element = FEStageElementAnimation()
	elseif cfg.type == element_type.switch_weapon then
		element = FEStageElementSwitchWeapon()
	elseif cfg.type == element_type.animation_sequence then
		element = FEStageElementAnimationSequence()
	else
		warn("monster stage not support element type", cfg.type)
	end

	if element then
		element.element_id = element_id
		element.target = self.m_owner
		element.cfg = cfg
	end

	return element
end

---@param self FEMonsterStageManager
---@param id FEStageOutwardElementId
---@return table
def.method(FEStageOutwardElementId, "=>", "table").GetElementConfig = function(self, id)
	local stage_cfg = self:_GetStageCfg()
	local cfg = stage_cfg.stage[id.stage_index][id.element_index]
	return cfg
end

---@param self FEMonsterStageManager
---@return void
def.method().Release = function(self)
	for i, element in pairs(self.m_element_map) do
		element:Destroy()
	end
	self.m_element_map = {}
end

---@param self FEMonsterStageManager
---@return void
def.method()._UpdateAnimationStateIndex = function(self)
	local stage_cfg = self:_GetStageCfg()

	if not stage_cfg then
		return
	end

	local stage_index = self:GetCurStageIndex()
	local cfg = stage_cfg.stage[stage_index]
	if not cfg then return end
	local ani_index = cfg.animation_state_index
	if ani_index then
		Log.Print("stage", "Set AnimIndex", self.m_owner.InfoData.Tid, ani_index)
		self.m_owner:SetAnimationStateIndex(ani_index)
	end
end


return FEMonsterStageManager.Commit()