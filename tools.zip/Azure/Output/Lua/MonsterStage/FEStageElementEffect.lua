--[[
	特效
]]
local Lplus = require "Lplus"
local FEStageOutwardElement = require "MonsterStage.FEStageOutwardElement"
---@type FEItemFxHandle
local FEItemFxHandle = Lplus.ForwardDeclare("FEItemFxHandle")
local FECommonModelFxUtility = require "Utility.FECommonModelFxUtility"

---@class FEStageElementEffect:FEStageOutwardElement
---@field protected m_effect FEItemFxHandle
---@field public Commit fun():FEStageElementEffect
---@field public Destroy fun(self:FEStageElementEffect)
---@field private _DestroyEffect fun(self:FEStageElementEffect)
---@field public Play fun(self:FEStageElementEffect, bTransition:boolean)
local FEStageElementEffect = Lplus.Extend(FEStageOutwardElement, "FEStageElementEffect")
local def = FEStageElementEffect.define

---@type FEItemFxHandle
def.field(FEItemFxHandle).m_effect = nil


---@param self FEStageElementEffect
---@return void
def.override().Destroy = function(self)
    self:_DestroyEffect()
end

---@param self FEStageElementEffect
---@return void
def.method()._DestroyEffect = function(self)
    if nil ~= self.m_effect then
       self.m_effect:Destroy()
    end
end

---@param self FEStageElementEffect
---@param bTransition boolean
---@return void
def.override("boolean").Play = function(self, bTransition)
    self:_DestroyEffect()

    local target = self:_GetTargetModel(self.cfg.target_type)
    if not target then
        return
    end

    self.m_effect = FECommonModelFxUtility.PlayById(target, self.cfg.fx_id)
end


return FEStageElementEffect.Commit()