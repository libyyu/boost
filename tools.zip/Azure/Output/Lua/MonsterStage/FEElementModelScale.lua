--[[
	模型缩放效果
]]

local Lplus = require "Lplus"
local FEStageOutwardElement = require "MonsterStage.FEStageOutwardElement"
local FEStageOutwardElementId = require "MonsterStage.FEStageOutwardElementId"
local FETimerHelper = require "Utility.FETimerHelper"
local Vector3 = require "Types.Vector3"

---@class FEElementModelScale:FEStageOutwardElement
---@field protected m_target_comp userdata
---@field protected m_timer FETimerHelper
---@field protected m_cur_scale table
---@field protected m_ori_scale table
---@field public Commit fun():FEElementModelScale @notnull
---@field public CanReuse fun(self:FEElementModelScale, new_id:FEStageOutwardElementId):boolean
---@field public Play fun(self:FEElementModelScale, bTransition:boolean)
---@field public Destroy fun(self:FEElementModelScale)
local FEElementModelScale = Lplus.Extend(FEStageOutwardElement, "FEElementModelScale")
local def = FEElementModelScale.define

---@type userdata
def.field("userdata").m_target_comp = nil

---@type FETimerHelper
def.field(FETimerHelper).m_timer = function() return FETimerHelper() end

---@type table
def.field("table").m_cur_scale = nil

---@type table
def.field("table").m_ori_scale = nil

---@param self FEElementModelScale
---@param new_id FEStageOutwardElementId
---@return boolean
def.override(FEStageOutwardElementId, "=>", "boolean").CanReuse = function(self, new_id)
    local cfg = self.target.stage_manager:GetElementConfig(new_id)
	if not cfg then
		return false
	end

	return cfg.type == self.cfg.type
			and cfg.target == self.cfg.target
end

---@param self FEElementModelScale
---@param bTransition boolean
---@return void
def.override("boolean").Play = function(self, bTransition)
	local target = self:_GetTargetModel(self.cfg.target_type)
	if not self.m_target_comp then
		self.m_target_comp = target and target:GetSkelMesh()
		self.m_ori_scale = self.m_target_comp and Vector3.Vector3.CoverToVector3(self.m_target_comp:Get_RelativeScale3D())
	end

	if not self.m_target_comp then
		return
	end

	local transition_time = self.cfg.transition_time
	local x, y, z = unpack(self.cfg.scale_rate)
	local target_scale = Vector3.Vector3.new(x, y,z)
	if not bTransition or transition_time <= 0 then
		self.m_target_comp:SetRelativeScale3D(target_scale)
		return
	end

	local end_time_stamp = Time.realtimeSinceStartup + transition_time
	self.m_cur_scale = Vector3.Vector3.CoverToVector3(self.m_target_comp:Get_RelativeScale3D())
	self.m_timer:AddTimer("TransitionScale", 0.03, false, function ()
		local left = end_time_stamp - Time.realtimeSinceStartup
		local rate = math.clamp( 1-left/transition_time, 0, 1)
		rate = math.EaseInOutCubic(rate)
		local scale = Vector3.Vector3.Lerp(self.m_cur_scale, target_scale, rate)
		self.m_target_comp:SetRelativeScale3D(scale)
	end)
end

---@param self FEElementModelScale
---@return void
def.override().Destroy = function(self)
	self.m_timer:RemoveAllTimer()
	if self.m_target_comp then
		self.m_target_comp:SetRelativeScale3D(self.m_ori_scale)
	end
end




return FEElementModelScale.Commit()