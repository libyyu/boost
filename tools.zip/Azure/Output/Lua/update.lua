-- 更新后重载不安全，不允许重载
if _G.MarkNotReloadAfterUpdate then _G.MarkNotReloadAfterUpdate() end

require "coro"
local EntryPointConfig = require "EntryPointConfig"
local DaizongSDK = require "Daizong.DaizongSDK"
local GEMLogin = require "MSDK.MSDKGPMGEMLoginPost"
local VersionUtil = require "Utility.VersionUtil"
local SimulatorUtil = require "Utility.SimulatorUtil"
require "Utility.DirOverride"
local PVMovie = require "PVMovie"
local PlatformConfig = require "Configs.PlatformConfig"
local BranchUtil = require "Utility.BranchUtil"

local log = print
local log_error = warn

local Panel_Update = "UI/UMG/panel_update"

local Visible = 0
local Collapsed = 1
local Hidden = 2
local HitTestInvisible = 3
local SelfHitTestInvisible = 4

local GSDK_EVENT_CHECKVERSION = 2
local GSDK_EVENT_PROGRAMUPDATE = 3
local GSDK_EVENT_MAINTAIN = 4
local GSDK_EVENT_RESOURCEINIT = 5
local GSDK_EVENT_RESOURCUPDATE = 6

local SILENT_DOWNLOAD_LIMIT = 10*1024*1024
local USER_NON_WIFI_OK = false
local forceUpdateToLatest = true
local orgSlateFeathering = GameUtil.GetConsoleVariable("Slate.Feathering") or 0

local File = VersionUtil.File
local Path = VersionUtil.Path
local Version = VersionUtil.Version
local Lang = VersionUtil.Lang

local lastShowUpdateTipResourceIndex
local function ShouldSkipShowUpdateTipForCurrentResource()	
	local skip = (lastShowUpdateTipResourceIndex ~= nil) and (Version.GetUpdatingResourceIndex() ~= lastShowUpdateTipResourceIndex)--首次允许、同一资源重复调用允许（可能是网络原因导致中断、允许弹框再提醒）、换了资源首次则默认前面资源已提醒过而不再提醒（但再次进入则允许，可能是网络原因）
	lastShowUpdateTipResourceIndex = Version.GetUpdatingResourceIndex()
	return skip
end

-- 是不是小包客户端
_G.g_IsMiniApp = not not _G.g_IsMiniApp

local l_IsWindowsSimuMobile
--是否(内部开发时)用 Windows 模拟手机
function _G.IsWindowsSimuMobile()
	if l_IsWindowsSimuMobile == nil then
		l_IsWindowsSimuMobile = GameUtil.GetPlatformName() == "Windows"
				and (GameUtil2.GetCommandLineParam == nil or GameUtil2.GetCommandLineParam("--simulate_mobile=") == "1")	--兼容一下旧客户端
		if _G.GIsEditor then
			l_IsWindowsSimuMobile = true
		end
	end
	return l_IsWindowsSimuMobile
end

local update_config
local function get_update_config()
	if not update_config then
		update_config = dofile "Configs/update_config.lua"
	end

	return update_config
end

local function read_from_file(path)
	local fin = io.open(path, "rb")
	if fin then
		local content = fin:read("*a")
		fin:close()
		return content
	else
		return nil
	end
end

local function write_to_file(path, content)
	GameUtil.CreateDirectoryForFile(path)
	local fout = io.open(path, "wb")
	if fout then
		fout:write(content)
		fout:close()
		return true
	else
		return false
	end
end

--戴宗打点需求
local daizong_stepcode_flag = {}
local daizong_stepcode_update_size = not DAIZONG_STEPCODE.UPDATE_FILE_SIZE_1 and {} or 
{
	[DAIZONG_STEPCODE.UPDATE_FILE_SIZE_1] = 500 * 1024 * 1024,
	[DAIZONG_STEPCODE.UPDATE_FILE_SIZE_2] = 1000 * 1024 * 1024,
	[DAIZONG_STEPCODE.UPDATE_FILE_SIZE_3] = 1500 * 1024 * 1024,
	[DAIZONG_STEPCODE.UPDATE_FILE_SIZE_4] = 2000 * 1024 * 1024,
	[DAIZONG_STEPCODE.UPDATE_FILE_SIZE_5] = 2500 * 1024 * 1024,
	[DAIZONG_STEPCODE.UPDATE_FILE_SIZE_6] = 3000 * 1024 * 1024,
	[DAIZONG_STEPCODE.UPDATE_FILE_SIZE_7] = 3500 * 1024 * 1024,
}

--------------------------------------------------------------------------------------------------------------------------
local stringtable = {}
local function load_stringtable(name)
	local lang = Lang.GetCustomLangNoChecked()
	print("-----------------------load_stringtable", lang)
	local xml
	if lang and #lang >0 then
		lang = string.lower(lang)
		xml = GameUtil.StreamingAssetReadFileText(lang .. "/config/update_stringtable.xml")
	end
	if not xml then
		xml = GameUtil.StreamingAssetReadFileText("config/update_stringtable.xml")
	end

	if xml then
		local doc = rapidxml.new_doc()
		local bOK, err = rapidxml.doc_parse(doc, xml)
		if bOK then
			local root = rapidxml.doc_first_node(doc)
			if root then
				local node = rapidxml.node_first_node(root)
				while node do
					local origin = rapidxml.node_first_attribute(node, "origin")
					local translation = rapidxml.node_first_attribute(node, "translation")
					if origin and translation then
						local origin_value = rapidxml.attribute_value(origin)
						local translation_value = rapidxml.attribute_value(translation)
						if origin_value and translation_value then
							rawset(stringtable, origin_value, translation_value)
						end
					end
					node = rapidxml.node_next_sibling(node)
				end
			end
		else
			warn("parse config/stringtable.xml error:", err)
		end
		rapidxml.delete_doc(doc)
	end
end
--------------------------------------------------------------------------------------------------------------------------
local m_panel

local function show_panel(name, show, nolog)
	if not nolog then
		log("show_panel", name, show)
	end
	local panel = m_panel:GetWidgetFromName(name)
	if panel then panel:SetActive(show) end
end

local function set_slot_position(name, x, y)
	local panel = m_panel:GetWidgetFromName(name)
	if panel then panel:SetSlotPosition(x, y) end
end

local function set_panel_opacity(name, opacity)
	local panel = m_panel:GetWidgetFromName(name)
	if panel then panel:SetRenderOpacity(opacity) end
end

local function set_block_text(name, txt)
	local text = m_panel:GetWidgetFromName(name)
	if text then text:SetText(txt) end
end

local function set_progress_percent(percent)
	local ProgressBar = m_panel:GetWidgetFromName("Update_bar")
	if ProgressBar then ProgressBar:SetPercent(percent) end
end

local function play_animation(name, cb, startTime, loops, playmode)
	if cb then
		m_panel:PlayAnimationByName(cb, name, startTime, loops, playmode)
	else
		m_panel:PlayAnimationByName(name, startTime, loops, playmode)
	end
end

local function play_animation_util_finish(name, startTime)
	if not m_panel:GetAnimationByName(name) then
		return
	end
	local finish = false
	m_panel:PlayAnimationByName(function()
		finish = true
	end, name, startTime)
	while not finish do
		coro.yield()
	end
end

local function pause_animation(name)
	m_panel:PauseAnimationByName(name)
end

local function show_text_typer(name, text, no_typer, no_wait_typer, cb)
	local obj = m_panel:GetWidgetFromName(name)
	if obj then
		GameUtil.RunBlueprintFunc(obj, "SetContent", text, not no_typer)

		if not no_typer then
			local function wait()
				local isPlaying = true
				repeat
					isPlaying = GameUtil.RunBlueprintFunc(obj, "IsPlayingAnim")
					if isPlaying then
						coro.yield()
					end
				until (not isPlaying)

				if cb then cb() end
			end
			if not no_wait_typer then
				wait()
			else
				if cb then
					coro.start(wait)
				end
			end
		else
			if cb then cb() end
		end
	end
end

local function get_text_typer_value(name)
	local obj = m_panel:GetWidgetFromName(name)
	if obj then
		return GameUtil.GetBlueprintProperty(obj, "FullString")
	end
	return nil
end

local function set_widget_switch(name, index)
	local obj = m_panel:GetWidgetFromName(name)
	if obj then
		obj:SetActiveWidgetIndex(index)
	end
end

local function set_3d_panel_offset(name, offset)
	local obj = m_panel:GetWidgetFromName(name)
	if obj then
		obj:SetOffset(offset)
	end
end

local function load_panel_update_res()
	log("load update panel res", m_panel)
	if m_panel and not m_panel:is_nil() then
		return
	end
	local obj = GameUtil.SyncLoad(Panel_Update, "WidgetBlueprintGeneratedClass")
	coro.yield()
	m_panel = UserWidget.CreateWidget(obj)
end

local function load_panel_update()
	log("load update panel", m_panel)
	if m_panel and not m_panel:is_nil() then
		return
	end
	load_panel_update_res()
	m_panel:SetMsgTable({})
	m_panel:AddToViewport(10)
	coro.yield()
end

--[[
	分多帧计算大文件 MD5 值
	param filePath: 文件路径
	param onProgress: 进度回调 (可选)
		function onProgress (finishedSize)
]]
local function CalcBigFileMd5 (filePath, onProgress)
	local md5State = MD5.Create()
	local stream = MD5.OpenFileStream(filePath)
	if not stream then
		return nil
	end
	local chunkSize = 1024 * 1024 * 4
	local startTimeCurrentFrame = Time.realtimeSinceStartup
	local limitTimePerFrame = 1/30
	local totalLengthRead = 0
	while true do
		local readSize = MD5.UpdateFileStream(md5State, stream, chunkSize)
		totalLengthRead = totalLengthRead + readSize

		if readSize ~= chunkSize then
			break
		end

		if Time.realtimeSinceStartup - startTimeCurrentFrame > limitTimePerFrame then
			if onProgress then
				onProgress(totalLengthRead)
			end
			coro.yield()
			startTimeCurrentFrame = Time.realtimeSinceStartup
		end
	end
	MD5.CloseFileStream(stream)

	if onProgress then
		onProgress(totalLengthRead)
	end

	return MD5.Final(md5State)
end

local function CloseAFileSystem()
	print("-----------------------CloseAFileSystem")
	coro.yield()	
	GameUtil.BlockTillAllRequestsFinished()	
	coro.yield()
	coro.yield()
	print("-----------------------CheckClosePackageFileHandle")
	while not GameUtil.CheckClosePackageFileHandle() do
		coro.yield()
	end
	coro.yield()
	GameUtil.FlushRenderingCommands()
	coro.yield()

	print("-------!!!!!! AFileSystemEnable FALSE !!!!!!---------")
	GameUtil.AFileSystemEnable(false)
	while not GameUtil.CheckAFileSystemDisabled() do
		coro.yield()
	end
	coro.yield()
	Patcher.PackFinalize()	
end
---------------------------------------------------------------------------------------------------------------------------
local programVersion = 0
local descriptionName = ""
local descriptionContent = ""
_G.glb_programVersion = programVersion
local function load_local_version()
	print("-----------------------load_local_version")
	local xml = GameUtil.StreamingAssetReadFileText("config/local_version.xml")
	if xml then
		local doc = rapidxml.new_doc()
		local bOK, err = rapidxml.doc_parse(doc, xml)
		if bOK then
			local root = rapidxml.doc_first_node(doc)
			if root then
				local value = rapidxml.node_first_attribute(root, "value")
				if value then
					local version = rapidxml.attribute_value(value)
					programVersion = tonumber(version) or 0
					_G.glb_programVersion = programVersion
				end
				local node = rapidxml.node_first_node(root, "description")
				if node then
					local name = rapidxml.node_first_attribute(node, "name")
					if name then descriptionName = rapidxml.attribute_value(name) end
					local content = rapidxml.node_first_attribute(node, "content")
					if content then descriptionContent = rapidxml.attribute_value(content) end
				end
				log("********load_local_version******", programVersion, descriptionName, descriptionContent)
			end
		else
			warn("parse config/local_version.xml error:", err)
			_G.GSDKSetEvent(GSDK_EVENT_CHECKVERSION, false, "local version fail", false, false)
		end
		rapidxml.delete_doc(doc)
	end
end
--------------------------------------------------------------------------------------------------------------------------
local resBaseVersion = 0
_G.glb_resBaseVersion = 0
local function load_res_base_version()
	print("-----------------------load_res_base_version")
	resBaseVersion = VersionUtil.GetResBaseVersion()
	if resBaseVersion < 0 then
		_G.GSDKSetEvent(GSDK_EVENT_CHECKVERSION, false, "local res base version fail", false, false)
	else
		glb_resBaseVersion = resBaseVersion
	end
	print("********load_res_base_version******", resBaseVersion)
end
--------------------------------------------------------------------------------------------------------------------------

--------------------------------------------------------------------------------------------------------------------------
local MBT_None, MBT_OK, MBT_YES_NO, MBT_OK_CANCEL = 0, 1, 2, 3
local MBR_None, MBR_OK,	MBR_YES, MBR_NO, MBR_CANCEL = 0, 1, 2, 3, 4
local btn_to_type = {["Btn_OK"]=MBR_OK, ["Btn_Yes"]=MBR_YES, ["Btn_No"]=MBR_NO, ["Btn_Okay"]=MBR_OK, ["Btn_Cancel"]=MBR_CANCEL}

local onclick, click_name
local function MessageBoxPop(message, type)
	log(message, type)
	local MessageBox = m_panel:FindChild("MessageBox")
	if MessageBox then
		MessageBox:SetActive(true)

		local Txt_Message = m_panel:FindChild("Txt_Message")
		if Txt_Message then
			Txt_Message:SetText(message:gsub("\\n", "\n"))
		end

		local Panel_MB_OK = m_panel:FindChild("MB_OK")
		local Panel_MB_YESNO = m_panel:FindChild("MB_YESNO")
		local Panel_MB_OKCANCEL = m_panel:FindChild("MB_OKCANCEL")
		if Panel_MB_OK then
			Panel_MB_OK:SetActive(type == MBT_OK)
		end
		if Panel_MB_YESNO then
			Panel_MB_YESNO:SetActive(type == MBT_YES_NO)
		end
		if Panel_MB_OKCANCEL then
			Panel_MB_OKCANCEL:SetActive(type == MBT_OK_CANCEL)
		end

		local Btn_OK = m_panel:FindChild("Btn_OK")
		local Btn_Yes = m_panel:FindChild("Btn_Yes")
		local Btn_No = m_panel:FindChild("Btn_No")
		local Btn_Okay = m_panel:FindChild("Btn_Okay")
		local Btn_Cancel = m_panel:FindChild("Btn_Cancel")

		if onclick == nil then
			onclick = function(Widget)
				if Widget then
					click_name = Widget:GetName()
					MessageBox:SetActive(false)
				end
			end

			if Btn_OK then Btn_OK:setOnClickFunc(onclick) end
			if Btn_Yes then Btn_Yes:setOnClickFunc(onclick) end
			if Btn_No then Btn_No:setOnClickFunc(onclick) end
			if Btn_Okay then Btn_Okay:setOnClickFunc(onclick) end
			if Btn_Cancel then Btn_Cancel:setOnClickFunc(onclick) end
		end

		while MessageBox:GetActive() do
			local platform_name = GameUtil.GetPlatformName()
			if platform_name == "Windows" and WindowsUtil and WindowsUtil.GetAsyncKeyState(0x0D) then
				if type == MBT_OK then
					onclick(Btn_OK)
				elseif type == MBT_OK_CANCEL then
					onclick(Btn_Okay)
				elseif type == MBT_YES_NO then
					onclick(Btn_Yes)
				end
			end
			coro.yield()
		end

		return btn_to_type[click_name]
	end
end

local function PopupMessageBoxWithStringTable(msg, type)
	return MessageBoxPop(stringtable[msg] or msg, type)
end
--------------------------------------------------------------------------------------------------------------------------

local function request_dir()
	show_panel("RequestState", true)
	log(("PlatformConfig, platform: %s, special_region: %s"):format(PlatformConfig.GetPlatform(), PlatformConfig.GetSpecialRegion()))
	local dir_server_addreses = PlatformConfig.GetAllDirServers()
	
	local autoRetryMaxPerAddress = #dir_server_addreses == 1 and 3 or 2		--每个地址自动重试次数 (只有一个地址时增加重试次数)
	local autoRetryMaxAllAddress = autoRetryMaxPerAddress * #dir_server_addreses		--所有地址自动重试次数
	
	local isTimeout
	local function start_checktimeout(iTry)
		local timeOut = 6
		local retryTimeOut = 3
		local iTryOnOneAddress = (iTry-1) % autoRetryMaxPerAddress + 1
		local isRetry = iTryOnOneAddress > 1;
		local realTimeOut = isRetry and retryTimeOut or timeOut;

		isTimeout = false
		coro.start(function() coro.wait(realTimeOut * 1000) isTimeout = true end)
	end
	
	for iTry = 1, autoRetryMaxAllAddress do
		--根据重试次数计算用哪个地址
		local iAddress = math.floor((iTry - 1) / autoRetryMaxPerAddress) + 1
		local address = dir_server_addreses[iAddress];
		
		log(("RequestDirInfo %s:%d"):format(address.host, address.port))
		local sessionId = GameUtil.RequestDirInfo(address.host, address.port)
		start_checktimeout(iTry)
		while not (GameUtil.HasGotDirInfo() or isTimeout) do coro.yield() end
		if isTimeout then
			log(("RequestDirInfo timeout %s:%d"):format(address.host, address.port))
			GameUtil.AbortDirRequest(sessionId)
			DaizongSDK.LogNetState(address.host, 30)
		else
			log("HasGotDirInfo")
			PlatformConfig.SetUsedDirServerIndex(iAddress)
			set_widget_switch("RequestState", 0)
			DaizongSDK.LogNetState(address.host, 5)
			DaizongSDK.LogStepLogReport(DAIZONG_STEPCODE.UPDATE_ZDIR_SUCCESS)
			GEMLogin.PostLoginStepEvent(GEMLogin.LoginStep.LINK_ZDIR)
			return
		end
	end

	DaizongSDK.LogStepLogReport(DAIZONG_STEPCODE.UPDATE_ZDIR_FAILURE)
	GEMLogin.PostLoginStepEvent(GEMLogin.LoginStep.LINK_ZDIR,false,DAIZONG_STEPCODE.UPDATE_ZDIR_FAILURE,"ZDIR link fail")
	set_widget_switch("RequestState", 1)
	_G.GSDKSetEvent(GSDK_EVENT_CHECKVERSION, false, "network", false, false)
	local message = "failed to check for update. click confirm to retry"
	MessageBoxPop(stringtable[message] or message, MBT_OK)

	coro.yield()
	return request_dir()
end
--------------------------------------------------------------------------------------------------------------------------
-- VersionParam
local newestVersion;
local newestVersionShowName;
local newestVersionContent;
local compatibleVersion;
local minimumResourceVersion;
local updateMethod;
local updateUrl;
local updateMd5;

-- MaintenanceInfo
local maintenanceStatus;
local maintenanceReason;

-- GameUpdateManager
local m_isEvaluation;
local m_EvaluationUpdate;
local GovEvaluationVersion;
local m_isGovEvaluation;
local m_GovEvaluationUpdate;
local PackPrefix;
local Packext;
local Project;
local Address;
local BackupAddress;
local BackupIP;
local AnnouncementAddress;
local AnnouncementAddressPrefix;

local AddressList;

function _G.GetAddressList()
	return AddressList
end

local MediaAddressList;
function _G.GetMediaAddressList()
	return MediaAddressList
end

-- EntryPoint
local WriteLogLevel;
local isiOSOfficial;

local showUpdateText = 0

-- Mini Package App
local inGameUpdateConfig = {}

--默认只在 Android 开启后台下载
local EnableOfflineDownload = false
if GameUtil.GetPlatformName == "Android" then
	EnableOfflineDownload = true
end

local function load_node_arttr(node, attribs)
	local attrib = rapidxml.node_first_attribute(node)
	while attrib do
		local name = rapidxml.attribute_name(attrib)
		local value = rapidxml.attribute_value(attrib)
		if name and value then
			rawset(attribs, name, value)
		end
		attrib = rapidxml.attribute_next_attribute(attrib)
	end
end

local function load_dir_version()
	local xml = GameUtil.GetDirVersion()
	print("dir version: ", xml)
	if xml then
		local doc = rapidxml.new_doc()
		local bOK, err = rapidxml.doc_parse(doc, xml)
		if bOK then
			local root = rapidxml.doc_first_node(doc)
			if root then
				---------------------------------------------------------------------------------------
				local attribs = {}
				load_node_arttr(root, attribs)
				
				newestVersion = attribs.value and tonumber(attribs.value) or 0
				compatibleVersion = attribs.compatible_version and tonumber(attribs.compatible_version) or 0
				_G.g_IsPrecreateApp = attribs.is_precreate == "true"
				if _G.g_IsPrecreateApp then
					print("g_IsPrecreateApp is true")
				end
				
				m_isEvaluation = false
				m_EvaluationUpdate = false
				
				local evaluation_list = rapidxml.node_first_node(root, "evaluation_list")
				if evaluation_list then
					local evaluation = rapidxml.node_first_node(evaluation_list, "evaluation")
					while evaluation do
						local evaluation_attribs = {}
						load_node_arttr(evaluation, evaluation_attribs)
						local evaluationVersion = tonumber(evaluation_attribs.version)
						if programVersion == evaluationVersion then
							m_isEvaluation = true
							m_EvaluationUpdate = (evaluation_attribs.update == "true")
							break
						end
						evaluation = rapidxml.node_next_sibling(evaluation, "evaluation")
					end
				end
				
				GovEvaluationVersion = tonumber(attribs.gov_evaluation_version)
				m_isGovEvaluation = false
				if attribs.gov_evaluation then
					m_isGovEvaluation = (attribs.gov_evaluation == "true")
				else
					m_isGovEvaluation = GovEvaluationVersion ~= nil and programVersion >= GovEvaluationVersion
				end
				m_GovEvaluationUpdate = (attribs.gov_evaluation_update == "true")

				minimumResourceVersion = tonumber(attribs.minimum_resource_version) or 1
				WriteLogLevel = attribs.log_level and tonumber(attribs.log_level) or 0
				isiOSOfficial = (attribs.ios_official == "true")
				showUpdateText = attribs.show_update_text and tonumber(attribs.show_update_text) or 0
				---------------------------------------------------------------------------------------
				local update = rapidxml.node_first_node(root, "update")
				if update then
					local attribs = {}
					load_node_arttr(update, attribs)

					updateMethod = attribs.method;
					updateUrl = attribs.url;
					updateMd5 = attribs.md5;
				end
				---------------------------------------------------------------------------------------
				local description = rapidxml.node_first_node(root, "description")
				if description then
					local attribs = {}
					load_node_arttr(description, attribs)

					newestVersionShowName = attribs.name;
					newestVersionContent = attribs.content;
				end			
				---------------------------------------------------------------------------------------
				local maintenance = rapidxml.node_first_node(root, "maintenance")
				if maintenance then
					local attribs = {}
					load_node_arttr(maintenance, attribs)

					maintenanceStatus = (attribs.status == "true");
					maintenanceReason = attribs.reason;
				end				
				---------------------------------------------------------------------------------------
				local resource_update = rapidxml.node_first_node(root, "resource_update")
				if resource_update then
					local overrideName = PlatformConfig.GetDirOverrideName()
					if overrideName and overrideName ~= "" then
						local overrideNode = rapidxml.node_first_node(resource_update, overrideName)
						if overrideNode then
							resource_update = overrideNode
							print("use override update config name: ", overrideName)
						else
							print("override update config not found: ", overrideName)
						end
					end
					local attribs = {}
					load_node_arttr(resource_update, attribs)

					PackPrefix = attribs.packprefix or "YZF";
					Packext = attribs.packext;
					Project = attribs.project;
					Address = attribs.address;
					BackupAddress = attribs.backup_address;
					BackupIP = attribs.backup_ip or "";
					AnnouncementAddress = attribs.announcement_address;
					inGameUpdateConfig.baseUrl = attribs.ingame_update_baseurl or ""
					inGameUpdateConfig.backupUrl1 = attribs.ingame_update_backupurl1 or ""
					inGameUpdateConfig.backupUrl2 = attribs.ingame_update_backupurl2 or ""
					inGameUpdateConfig.useHttp2 = (attribs.ingame_update_usehttp2 == "true")
					inGameUpdateConfig.disablePrerequisite = (attribs.ingame_update_no_prerequisite == "true")
					log("---------------resource_update--------------------", Address)
				end

				--视频资源需要使用在线方式播放，media记录多媒体资源的路径
				MediaAddressList = {}
				local media_node = rapidxml.node_first_node(root, "media")
				if media_node then
					local overrideName = PlatformConfig.GetDirOverrideName()
					if overrideName and overrideName ~= "" then
						local overrideNode = rapidxml.node_first_node(media_node, overrideName)
						if overrideNode then
							media_node = overrideNode
							print("use override media config name: ", overrideName)
						else
							print("override media config not found: ", overrideName)
						end
					end

					local childNode = rapidxml.node_first_node(media_node, "prefix_url")
					while childNode do
						local attribs = {}
						load_node_arttr(childNode, attribs)
						for k, v in pairs(attribs) do
							MediaAddressList[k] = MediaAddressList[k] or {}
							table.insert(MediaAddressList[k], v)
						end
						childNode = rapidxml.node_next_sibling(childNode, "prefix_url")
					end
				end

				--公告
				local announcementNode = rapidxml.node_first_node(root, "announcement")
				if announcementNode then
					local overrideName = PlatformConfig.GetDirOverrideName()
					if overrideName and overrideName ~= "" then
						local overrideNode = rapidxml.node_first_node(announcementNode, overrideName)
						if overrideNode then
							announcementNode = overrideNode
							print("use override announcement config name: ", overrideName)
						end
					end

					local attribs = {}
					load_node_arttr(announcementNode, attribs)
					AnnouncementAddressPrefix = attribs.url
				end

				local PolicyUtility = require "Utility.PolicyUtility"
				if PolicyUtility then
					PolicyUtility:LoadVersionFromXML(root)
				end

				AddressList = {}
				if Address and Address ~= "" then AddressList[#AddressList+1]= Address end
				if BackupAddress and BackupAddress ~= "" then AddressList[#AddressList+1]= BackupAddress end
				if BackupIP and BackupIP ~= "" then AddressList[#AddressList+1]= BackupIP end


				local updateconfig_node = rapidxml.node_first_node(root, "updateconfig")
				if updateconfig_node then
					local attribs = {}
					load_node_arttr(updateconfig_node, attribs)

					local enableofflinedownloadAttr = attribs['enableofflinedownload']
					if enableofflinedownloadAttr == "true" then
						EnableOfflineDownload = true
						print("*****************Force Enable OfflineDownload***********************")
					elseif enableofflinedownloadAttr == "false" then
						EnableOfflineDownload = false
						print("*****************Force Disable OfflineDownload***********************")
					end
				end

				---------------------------------------------------------------------------------------	
				_G.GSDKSetEvent(GSDK_EVENT_CHECKVERSION, true, "success", false, false)
			end
		else
			warn("load_dir_version error:", err)
			_G.GSDKSetEvent(GSDK_EVENT_CHECKVERSION, false, "load dir version fail", false, false)
			local message = "update server has error"
			MessageBoxPop(stringtable[message] or message, MBT_None)
		end
		rapidxml.delete_doc(doc)
	end
end

local function mysplit(self, delimiter)
	local sep, fields = delimiter or "\t", {}

	local pattern = string.format("([^%s]+)", sep)

	string.gsub(self, pattern, function(c)
		fields[#fields+1] = c
	end)

	return fields
end
---@param self string
---@param s string
local function myendswith(self, s)
	if #s > 0 then
		local suffix = self:sub(-#s)
		return suffix == s
	else
		return true
	end
end

local function ParseContent(content)
	if not content then
		return {}
	end
	if content:sub(-1) ~= "\n" then
		content = content .. "\n"
	end
	local result = {}
	for line in content:gmatch("([^\r\n]*)\r-\n") do
		local vline = line:gsub("\n", "")
		local vs = mysplit(vline, ": ")
		local key, value = vs[1], vs[2]
		if key and value then
			if key == "BuildID" then
				result.BuildID = tonumber(value)
			elseif key == "ResVersion" then
				result.ResVersion = tonumber(value)
			elseif key == "FromPath" then
				result.FromPath = value
			elseif key == "UploadPath" then
				result.UploadPath = value
			elseif key == "BuildTime" then
				result.BuildTime = value
			end
		end
	end
	return result
end

--------------------------------------------------------------------------------------------------------------------------
local function IsNoResourceUpdateForDebug()
	if not _G.GIsEditor then
		local no_resourceupdate = GameUtil2.GetCommandLineParam and GameUtil2.GetCommandLineParam("--no_resourceupdate=")
		if no_resourceupdate and 1 == tonumber(no_resourceupdate) then
			return true
		end
	end
	return false
end

local buildTagTable
local function IsNoResourceUpdate()
	if IsNoResourceUpdateForDebug() == true then
		return true
	end
	
	if m_isEvaluation and not m_EvaluationUpdate then
		return true
	end

	if m_isGovEvaluation and not m_GovEvaluationUpdate then
		return true
	end
	
	if _G.g_ResBaseIsPrecreateApp then	--预创建，不更新
		return true
	end

	if _G.IsWindowsSimuMobile() then
		if not buildTagTable then
			local content = GameUtil.StreamingAssetReadFileText("buildTag.txt")
			buildTagTable = ParseContent(content)
		end
		--TODO:临时处理一下，后期通过jenkins设置
		if buildTagTable and buildTagTable.FromPath and (buildTagTable.FromPath:find("/stable") ~= nil) then
			return true
		end
	end
	return EntryPointConfig.NoResourceUpdate or EntryPointConfig.SepFile
end

--是否(内容)审核，将屏蔽部分游戏内容
function _G.IsEvaluation()
	return EntryPointConfig.ForceEvaluation or (m_isEvaluation and not m_isGovEvaluation)	--政府审核不能屏蔽游戏内容
end

--是否政府审核，政府审核不能屏蔽游戏内容
function _G.IsGovEvaluation()
	return m_isGovEvaluation
end

function _G.GetInGameUpdateConfig()
	return inGameUpdateConfig
end
--获取公共地址前缀
function _G.GetAnnouncementAddressPrefix()
	return AnnouncementAddressPrefix
end

local function IsForceGuest()
	return EntryPointConfig.ForceGuest;
end
--------------------------------------------------------------------------------------------------------------------------	
local function loop_endless()
	while true do coro.yield() end
end

local function show_maintenance()
	warn("-----------------------show_maintenance", maintenanceStatus)
	if maintenanceStatus then
		show_panel("Progress", false);
		show_panel("Maintenance", true);
		set_block_text("Txt_Announcement", maintenanceReason);
		_G.GSDKSetEvent(GSDK_EVENT_MAINTAIN, true, "success", false, true)
		loop_endless()
	end
end
--------------------------------------------------------------------------------------------------------------------------
local onclick_choose
local function choose_whether_update(title, content)
	local ChooseBox = m_panel:FindChild("ChooseBox")
	if ChooseBox then
		ChooseBox:SetActive(true)

		show_panel("TypeChoose", false)
		show_panel("UpdateChoose", true)

		local Btn_Yes2 = m_panel:FindChild("Btn_Yes2")
		local Btn_No2 = m_panel:FindChild("Btn_No2")

		local ret
		if onclick_choose == nil then
			onclick_choose = function(Widget)
				if Widget then
					ret = (Widget:GetName() == "Btn_Yes2")
					ChooseBox:SetActive(false)
				end
			end

			if Btn_Yes2 then Btn_Yes2:setOnClickFunc(onclick_choose) end
			if Btn_No2 then Btn_No2:setOnClickFunc(onclick_choose) end
		end

		while ChooseBox:GetActive() do
			local platform_name = GameUtil.GetPlatformName()
			if platform_name == "Windows" and WindowsUtil and WindowsUtil.GetAsyncKeyState(0x0D) then
				onclick_choose(Btn_Yes2)
			end
			coro.yield()
		end

		return ret
	end	
end

local function update_program()
	if updateMethod == "install" then
		-- TODO
	elseif updateMethod == "open_url" then
		GameUtil.OpenURL(updateUrl)
		local msg = "waiting for finish update"
		MessageBoxPop(stringtable[msg] or msg, MessageBoxType.None)
	elseif updateMethod == "yyb" then
		-- TODO
	elseif updateMethod == "pop_yyb" then
		-- TODO
	elseif updateMethod == "msg" then -- 实在没辙了可以显示一条消息
		MessageBoxPop(updateUrl, MBT_None)
	end
	return "Success"
end

-- IOS 更新界面逻辑修改
local function ios_check_update()
	local ChooseBox = m_panel:FindChild("ChooseBox")
	local Btn_Down = m_panel:FindChild("Btn_Down")
	ChooseBox:SetActive(true)
	show_panel("TypeChoose", false)
	show_panel("UpdateChoose", true)
	local Btn_Yes2 = m_panel:FindChild("Btn_Yes2")
	local Btn_No2 = m_panel:FindChild("Btn_No2")
	onclick_choose = function(Widget)
		if Widget then
			ChooseBox:SetActive(false)
			return
		end
	end
	if Btn_Yes2 then Btn_Yes2:setOnClickFunc(onclick_choose) end
	if Btn_No2 then Btn_No2:setOnClickFunc(function ()
		ChooseBox:SetActive(false)
		Btn_Down:SetActive(true)
	end) end
	if Btn_Down then Btn_Down:setOnClickFunc(function ()
		ChooseBox:SetActive(true)
		Btn_Down:SetActive(false)
	end) end

	while ChooseBox:GetActive() or Btn_Down:GetActive() do
		coro.yield()
	end
end

local function programs_update()
	print("-----------------------programs_update", EntryPointConfig.NoProgramUpdate)
	if _G.IsEvaluation() or _G.IsGovEvaluation() then	--审核一定不能提示换包！！
		print("evaluation force skip programs_update")
		return
	end
	if _G.g_ResBaseIsPrecreateApp then	--预创建，不换包
		print("resbase precreate force skip programs_update")
		return
	end
	
	if EntryPointConfig.NoProgramUpdate then return end
	print("newestVersion = ", newestVersion, programVersion)

	show_panel("TextGroup2", true)

	set_block_text("Txt_Local2", descriptionName)
	set_block_text("Txt_Sever2", newestVersionShowName)

	if compatibleVersion > programVersion then	--目前不支持自动更新安装包，直接显示一句话
		local msg = "auto update not supported, please update manually"
		MessageBoxPop(stringtable[msg] or msg, MBT_None)
		while true do coro.yield() end
	end
	
	if newestVersion > programVersion then
		if GameUtil.GetPlatformName() == "IOS" then
			ios_check_update()
		else
			if choose_whether_update() then -- 选了“是”
			else -- 选了“否”
				if compatibleVersion > programVersion then -- 必须更新
					local msg = "must update"
					_G.GSDKSetEvent(GSDK_EVENT_PROGRAMUPDATE, false, "user cancel", false, false)
					MessageBoxPop(stringtable[msg] or msg, MBT_OK)
				else -- 跳过更新
					return
				end
			end
		end

		if update_program() == "Fail" then
			local msg = "update failed"
			MessageBoxPop(stringtable[msg] or msg, MBT_None)
		end
	else
		_G.GSDKSetEvent(GSDK_EVENT_PROGRAMUPDATE, true, "no update", false, false)
	end
end
--------------------------------------------------------------------------------------------------------------------------
local ForceEvaluation = EntryPointConfig.ForceEvaluation
local patcher_stringtable
local function load_patcher_stringtable()
	if not patcher_stringtable then
		local lang = Lang.GetCustomLangNoChecked()
		print("load_patcher_stringtable", lang)
		if lang and #lang >0 then
			lang = string.lower(lang)
			patcher_stringtable = GameUtil.StreamingAssetReadFileText(lang .. "/config/patcher_stringtable.xml")
		end
		if not patcher_stringtable then
			patcher_stringtable = GameUtil.StreamingAssetReadFileText("config/patcher_stringtable.xml")
		end
	end
	return patcher_stringtable
end

_G.EHttpRequestStatus = {NotStarted = 0, Processing = 1, Failed = 2, Failed_ConnectionError = 3, Succeeded = 4}

local function get_http_filelength(url)
	log("get_http_filelength", url)
	local bSuccess = false
	local requestStatus = EHttpRequestStatus.Succeeded
	local responseCode = nil
	local locationString = nil
	local lengthString = nil

	local LastTimeout = Patcher.HttpGetTimeout()
	Patcher.HttpSetTimeout(15*1000)

	local HttpRequest = Patcher.HttpCreateRequest()

	local bComplete = false
	Patcher.HttpSetOnComplete(HttpRequest, function(InRequest, InResponse, InSucceeded)
		bComplete = true
		if InSucceeded and InResponse then
			bSuccess = true
			responseCode = Patcher.HttpGetResponseCode(InRequest, InResponse)
			lengthString = Patcher.HttpGetResponseHeader(InRequest, InResponse, "Content-Length")
			locationString = Patcher.HttpGetResponseHeader(InRequest, InResponse, "Location")
		end
	end)

	Patcher.HttpSetURL(HttpRequest, url)
	Patcher.HttpSetVerb(HttpRequest, "HEAD")

	Patcher.HttpProcessRequest(HttpRequest)

	while requestStatus == EHttpRequestStatus.Processing or
			(requestStatus == EHttpRequestStatus.Succeeded and bComplete == false) do
		requestStatus = Patcher.HttpGetRequestStatus(HttpRequest)
		coro.yield()
	end

	Patcher.HttpDestroyRequest(HttpRequest)
	HttpRequest = nil

	Patcher.HttpSetTimeout(LastTimeout)

	return bSuccess, requestStatus, responseCode, locationString, lengthString
end

local get_local_filelength = Patcher.GetFileSize
local ENetworkConnectionType = {
    Unknown = 0,
    None = 1,
    AirplaneMode = 2,
    Cell = 3,
    WiFi = 4,
	WiMAX = 5,
	Bluetooth = 6,
	Ethernet = 7
}

local _MobileHasNetwork = function()
	local PlatformName = GameUtil.GetPlatformName()
	if PlatformName == "Android" or PlatformName == "IOS" then
		local networkConnectionType = GameUtil.GetNetworkConnectionType()
		return networkConnectionType == ENetworkConnectionType.Cell
				or networkConnectionType == ENetworkConnectionType.WiFi
				or networkConnectionType == ENetworkConnectionType.WiMAX
				or networkConnectionType == ENetworkConnectionType.Ethernet
	else
		return true
	end
end

_G.has_network = function()
	local PlatformName = GameUtil.GetPlatformName()
	if PlatformName == "Android" or PlatformName == "IOS" then
		return _MobileHasNetwork()
	elseif PlatformName == "Windows" then
		if GameUtil.InternetGetConnectedState then
			local b, flags = GameUtil.InternetGetConnectedState()
			if not b then
				return false
			end

			if bit.band(flags, 0x01) == 0x01 then --拨号上网
				return true
			elseif bit.band(flags, 0x02) == 0x02 then --局域网上网
				return true
			elseif bit.band(flags, 0x04) == 0x04 then --代理上网
				return true
			else
				return false
			end
		else
			return true
		end
	else
		return true
	end
end

local lastPopFailTimeStamp = 0
local POP_FAIL_CD = 5
local function get_http_filelength_pop_on_fail(url)
	local actualUrl = url
	local visitedUrls = {}	--	to avoid redirection loop, necessary?
	while true do
		while not has_network() do
			log("-----------get_http_filelength:waiting for network----------")
			PopupMessageBoxWithStringTable("network not available", MBT_OK)
		end
		local bSuccess, requestStatus, responseCode, locationString, lengthString = get_http_filelength(actualUrl)
		visitedUrls[actualUrl] = true
		local has_location = function()
			return locationString ~= nil and string.len(locationString) > 0
		end
		local bRedirect = false
		if bSuccess then
			if responseCode == 200 then -- CAUTION:for curl with CURLOPT_FOLLOWLOCATION set to 1, it returns 200 rather than 302, and UE4 might return comma seperated lengthString such as "161, 266525009" or "266525009"
				if has_location() then	--	follow redirection url here and later(for efficiency) for curl with CURLOPT_FOLLOWLOCATION set to 1
					bRedirect = true
				else
					local fileLength = tonumber(lengthString)
					if fileLength ~= nil then
						return true, fileLength, actualUrl
					end
				end
			elseif responseCode == 302 then
				if has_location() then
					bRedirect = true
				end
			end
		end
		local bHasRedirectLoop = false
		if bRedirect then
			if not visitedUrls[locationString] then
				actualUrl = locationString
				bRedirect = true
			else
				bRedirect = false
				bHasRedirectLoop = true
			end
		end
		if not bRedirect then
			local curTime = Time.realtimeSinceStartup
			if curTime - lastPopFailTimeStamp < POP_FAIL_CD then
				--print("In CD", curTime, lastPopFailTimeStamp)
				bRedirect = true
			end
		end
		if not bRedirect then
			lastPopFailTimeStamp = Time.realtimeSinceStartup

			if _G.IsWindowsSimuMobile() then
				local msg = string.format("--------------failed to get remote file size:url[%s], actualUrl[%s], bSuccess[%s], requestStatus[%s], bHasRedirectLoop[%s], responseCode[%s], locationString[%s], lengthString[%s]", url, actualUrl, tostring(bSuccess), tostring(requestStatus), tostring(bHasRedirectLoop), tostring(responseCode), tostring(locationString), tostring(lengthString))
				log_error(msg)
				PopupMessageBoxWithStringTable("更新包正在发布中，请稍后再试", MBT_OK)
			else
				local msg = string.format("--------------failed to get remote file size:url[%s], actualUrl[%s], bSuccess[%s], requestStatus[%s], bHasRedirectLoop[%s], responseCode[%s], locationString[%s], lengthString[%s]", url, actualUrl, tostring(bSuccess), tostring(requestStatus), tostring(bHasRedirectLoop), tostring(responseCode), tostring(locationString), tostring(lengthString))
				log_error(msg)
				PopupMessageBoxWithStringTable("failed to get remote file size", MBT_OK)
			end

			return false, nil, nil
		end
	end
end

local function get_local_file_md5_guaranteed(localPath, msgOnFail)
	local md5 = nil
	while md5 == nil do
		if Patcher.FileExists(localPath) then
			md5 = Patcher.CalFileMd5(localPath)
			if md5 == nil then
				log_error(string.format("--------------cannot calculate md5:localPath[%s], msgOnFail[%s]", localPath, msgOnFail))
				PopupMessageBoxWithStringTable(msgOnFail, MBT_OK)
			end
		else
			break
		end
	end
	return md5
end

local function delete_local_file_guaranteed(localPath, deleteReason, msgOnFail)
	local TryTimes = 0
	while Patcher.FileExists(localPath) do
		if TryTimes >= 1 then
			log_error(string.format("--------------cannot delete:localPath[%s], deleteReason[%s]", localPath, tostring(deleteReason)))
			PopupMessageBoxWithStringTable(msgOnFail, MBT_OK)
		end
		Patcher.UDeleteFile(localPath)
		TryTimes = TryTimes+1
	end
end

--	return true for success
local function downloadFileImpl(argv)
	local url = argv[2]
	local localPath = argv[3]
	local timeout = argv[4]
	local param = argv[5]
	local callback = argv[6]
	local md5 = argv[7]	-- can be nil

	local remotelength_got = false
	local remotelength = 0
	local actualurl = nil
	local locallength = get_local_filelength(localPath)

	log(string.format("--------------downloadFile: url[%s], localPath[%s], timeout[%d], md5[%s], locallength[%f]", url, localPath, timeout, tostring(md5), locallength))

	--	pre-download check
	if md5 ~= nil then
		local localMD5 = get_local_file_md5_guaranteed(localPath, "cannot validate existed file before download")
		if localMD5 ~= nil then
			if string.upper(localMD5) == string.upper(md5) then
				log("--------------local file with given md5 already there and download skipped")
				local fileSize = Patcher.GetFileSize(localPath)
				Patcher.downloadFile_callOnFileStart(callback, param, fileSize)
				Patcher.downloadFile_callOnFileDone(callback, param)
				return true
			else
				remotelength_got, remotelength, actualurl = get_http_filelength_pop_on_fail(url)
				if not remotelength_got then
					DaizongSDK.LogStepLogReport(DAIZONG_STEPCODE.UPDATE_RESOURCE_FAILURE, "file_size_error")
					GEMLogin.PostLoginStepEvent(GEMLogin.LoginStep.DOWNLOAD_PATCHER,false,DAIZONG_STEPCODE.UPDATE_RESOURCE_FAILURE,"down patcher fail")
					return false
				end
				if locallength >= remotelength then
					local deleteReason = string.format("---------md5 different and locallength >= remotelength:localPath[%s],url[%s],actualurl[%s],locallength[%f],remotelength[%f],expected_md5[%s],local_md5[%s]", localPath, url, actualurl, locallength, remotelength, md5, localMD5)
					delete_local_file_guaranteed(localPath, deleteReason, "cannot delete cached file")
					locallength = 0
				end
			end
		end
	end

	if not remotelength_got then
		remotelength_got, remotelength, actualurl = get_http_filelength_pop_on_fail(url)
	end
	if not remotelength_got then
		DaizongSDK.LogStepLogReport(DAIZONG_STEPCODE.UPDATE_RESOURCE_FAILURE, "file_size_error")
		GEMLogin.PostLoginStepEvent(GEMLogin.LoginStep.DOWNLOAD_PATCHER,false,DAIZONG_STEPCODE.UPDATE_RESOURCE_FAILURE,"down patcher fail")
		return false
	end

	local remainlength = remotelength - locallength
	log(string.format("--------------actualurl[%s], remotelength[%f], locallength[%f], remainlength[%f]", actualurl, remotelength, locallength, remainlength))
	if remainlength <= 0 then
		return false
	end
	local needdownloadlength = remainlength

	local SIZE_PER_REQUEST
	local SIZE_PER_REQUEST_TO_AVOID
	if GameUtil.GetPlatformName() == "IOS" then
		SIZE_PER_REQUEST = 2 * 1024 * 1024
		SIZE_PER_REQUEST_TO_AVOID = 512 * 1024
	else
		SIZE_PER_REQUEST = 10 * 1024 * 1024
		SIZE_PER_REQUEST_TO_AVOID = 1024 * 1024
	end

	local ERR_CREATE_FILE = 4 --无法创建文件
	local ERR_CONNECTION = 6 --网络连接错误
	local ERR_UNKNOWN = 7 --俺也不知道

	local bComplete, bSucceeded
	local bRequestCancelled
	local bRetryOnFail
	local bFileChangedBeforeSave
	local bSaveContentHasError

	Patcher.HttpSetTimeout(timeout)
	local HttpRequest = Patcher.HttpCreateRequest()
	Patcher.HttpSetOnComplete(HttpRequest, function(InRequest, InResponse, InSucceeded)
		bComplete = true
		bSucceeded = InSucceeded
		if InSucceeded then
			local ResponseCode = Patcher.HttpGetResponseCode(InRequest, InResponse)
			if ResponseCode == 206 then
				bSucceeded = true
				local presave_filelength = get_local_filelength(localPath)
				if locallength ~= presave_filelength then
					--	local file deleted during downloading ?
					local msg = string.format("--------------file changed unexpectedly:localPath[%s],url[%s],actualurl[%s],locallength[%f],presave_filelength[%f]", localPath, url, actualurl, locallength, presave_filelength)
					log_error(msg)
					bFileChangedBeforeSave = true
				else
					local SaveContentResult = Patcher.HttpSaveContentAppend(InRequest, InResponse, localPath)
					if not SaveContentResult then
						bSaveContentHasError = true
						local new_locallength = get_local_filelength(localPath)
						local free_space = GameUtil.getDiskFreeSpace(GameUtil.GetAssetsPath())

						local msg = string.format("--------------not all content saved:localPath[%s],url[%s],actualurl[%s],free=[%f],new_locallength[%f],locallength[%f]", localPath, url, actualurl, free_space, new_locallength, locallength)
						log_error(msg)

						locallength = new_locallength
						remainlength = remotelength - locallength
					else
						locallength = get_local_filelength(localPath)
						remainlength = remotelength - locallength
					end
				end
			else
				local msg = string.format("--------------downloadFileImpl:invalid response code:[%d],url[%s],actualurl[%s]", ResponseCode, url, actualurl)
				log_error(msg)
				bSucceeded = false
				Patcher.downloadFile_callOnNetError(callback, param, ERR_UNKNOWN, ResponseCode)
			end
		else
			if not bRequestCancelled then
				bRetryOnFail = true
			end
			Patcher.downloadFile_callOnRetError(callback, param, ERR_CONNECTION)
		end
	end)

	local bHasStart = false
	Patcher.HttpSetOnProgress(HttpRequest, function(InRequest, BytesSent, BytesRcv)
		if not bHasStart then
			bHasStart = true
			Patcher.downloadFile_callOnFileStart(callback, param, remotelength)
		end
		local bContinue = Patcher.downloadFile_callOnProgressChange(callback, param, locallength + BytesRcv)
		if not bContinue then
			bRequestCancelled = true
			Patcher.CancelRequest(InRequest)
		end
	end)

	Patcher.HttpSetURL(HttpRequest, actualurl)
	Patcher.HttpSetVerb(HttpRequest, "Get")
	Patcher.HttpSetHeader(HttpRequest, "Content-Type", "application/json")
	Patcher.HttpSetHeader(HttpRequest, "Accept-Encoding", "identity")

    local downloadStartTime = Time.realtimeSinceStartup
	local status = EHttpRequestStatus.Succeeded
	local ret = true
	while remainlength > 0 and ret do
		local range = ((remainlength > SIZE_PER_REQUEST) and SIZE_PER_REQUEST or remainlength)
		if remainlength - range < SIZE_PER_REQUEST_TO_AVOID then range = remainlength end
		local range_str = string.format("bytes=%u-%u", locallength, locallength + range - 1)

		local max_try_times = 3
		local try_times = 0
		while try_times < max_try_times do
			try_times = try_times + 1

			Patcher.HttpSetHeader(HttpRequest, "Range", range_str)
			Patcher.HttpSetHeader(HttpRequest, "User-Agent", "X-UnrealEngine-Agent")

			bComplete, bSucceeded, bRetryOnFail, bRequestCancelled, bFileChangedBeforeSave, bSaveContentHasError = false, false, false, false, false, false
			Patcher.HttpProcessRequest(HttpRequest)

			status = EHttpRequestStatus.Succeeded
			while status == EHttpRequestStatus.Processing or
					(status == EHttpRequestStatus.Succeeded and bComplete == false) do
				status = Patcher.HttpGetRequestStatus(HttpRequest)
				coro.yield()
			end

			ret = (bSucceeded and (status == EHttpRequestStatus.Succeeded))
			if ret then
				if bFileChangedBeforeSave then
					PopupMessageBoxWithStringTable("local downloaded file unexpectely changed", MBT_OK)

					local msg = string.format("--------------localPath[%s] was unexpectedly changed/removed", localPath)
					log_error(msg)

					local deleteReason = msg
					delete_local_file_guaranteed(localPath, deleteReason, "cannot delete unexpectedly changed downloaded file")

					locallength = 0
					remainlength = remotelength
				end
				if bSaveContentHasError then
					PopupMessageBoxWithStringTable("save downloaded content failed", MBT_OK)
					--	continue download from saved content
				end
				break
			end

			if not bRetryOnFail then
				break
			end

			while not has_network() do
				log("-----------waiting for network----------")
				PopupMessageBoxWithStringTable("network not available", MBT_OK)
			end

			if not GameUtil.HasActiveWiFiConnection() and not USER_NON_WIFI_OK and (remainlength > SILENT_DOWNLOAD_LIMIT) then
				log("fail download maybe because connection status change")
				local ret = PopupMessageBoxWithStringTable("confirm download via wireless network", MBT_OK_CANCEL)
				if ret == MBR_OK then
					log("user allow to download using non wifi")
					USER_NON_WIFI_OK = true
				else
					log("user not allow to download using non wifi")
					break
				end
			end
		end
	end

	Patcher.HttpDestroyRequest(HttpRequest)

	--	validate downloaded file when required (md5 exists)
	if ret then
		if md5 ~= nil then
			local localMD5 = get_local_file_md5_guaranteed(localPath, "cannot validate existed file after download")
			if localMD5 ~= nil and string.upper(localMD5) == string.upper(md5) then
				Patcher.downloadFile_callOnFileDone(callback, param)
			else
				ret = false
				Patcher.downloadFile_callOnRetError(callback, param, ERR_UNKNOWN)

				local msg = string.format("--------------downloaded file failed md5 validation:url[%s],actualurl[%s],localPath[%s],md5[%s],expected md5[%s],locallength[%f],remotelength[%f]", url, actualurl, localPath, tostring(localMD5), md5,get_local_filelength(localPath),remotelength)
				log_error(msg)

				local deleteReason = msg
				delete_local_file_guaranteed(localPath, deleteReason, "cannot delete downloaded file with error")
			end
		else
			Patcher.downloadFile_callOnFileDone(callback, param)
		end
	end
	
	local downloadEndTime = Time.realtimeSinceStartup
	local downloadTimeMs = (downloadEndTime - downloadStartTime)*1000
	DaizongSDK.LogGameUpdate({
		updateid = 2,	--patcher更新
		updateurl = actualurl or "",
		filename = localPath,
		filesize = remotelength,
		downloadtime = downloadTimeMs,
		downloadsize = needdownloadlength - remainlength,
		updatestatus = ret and 0 or 1,
		updateversion = Patcher.getServerVersion()
	})

	log(string.format("--------------downloadFile finished with ret[%s]---------------", tostring(ret)))
	return ret
end

local function downloadFileRaw(url, localPath, size, onProcess, onFinish, onError)
	local SIZE_PER_REQUEST
	local SIZE_PER_REQUEST_TO_AVOID
	if GameUtil.GetPlatformName() == "IOS" then
		SIZE_PER_REQUEST = 2 * 1024 * 1024
		SIZE_PER_REQUEST_TO_AVOID = 512 * 1024
	else
		SIZE_PER_REQUEST = 10 * 1024 * 1024
		SIZE_PER_REQUEST_TO_AVOID = 1024 * 1024
	end
	local ERR_CREATE_FILE = 4 --无法创建文件
	local ERR_CONNECTION = 6 --网络连接错误
	local ERR_UNKNOWN = 7 --俺也不知道

	local bComplete, bSucceeded
	local bRequestCancelled
	local bRetryOnFail
	local bFileChangedBeforeSave
	local bSaveContentHasError

	GameUtil.CreateDirectoryForFile(localPath)
	local locallength = get_local_filelength(localPath)
	local remotelength_got, remotelength, actualurl = get_http_filelength_pop_on_fail(url)
	if remotelength_got and remotelength == size then
		url = actualurl
		GEMLogin.PostLoginStepEvent(GEMLogin.LoginStep.GET_PACKAGE_SIZE)
	else
		DaizongSDK.LogStepLogReport(DAIZONG_STEPCODE.UPDATE_EXTRA_PACKAGE_FILE_SIZE_FAILURE)
		GEMLogin.PostLoginStepEvent(GEMLogin.LoginStep.GET_PACKAGE_SIZE,false,DAIZONG_STEPCODE.UPDATE_EXTRA_PACKAGE_FILE_SIZE_FAILURE,"get package fail")
		return false
	end

	if locallength > remotelength then
		local deleteReason = string.format("---------locallength > remotelength:localPath[%s],url[%s], locallength[%f],remotelength[%f]", localPath, url, locallength, remotelength)
		delete_local_file_guaranteed(localPath, deleteReason, "cannot delete cached file")
		locallength = 0
	end

	local remainlength = remotelength - locallength
	log(string.format("--------------downloadFileRaw url[%s], remotelength[%f], locallength[%f], remainlength[%f]", url, remotelength, locallength, remainlength))

	--prepare to download
	local LastTimeout = Patcher.HttpGetTimeout()
	Patcher.HttpSetTimeout(15*1000)
	local HttpRequest = Patcher.HttpCreateRequest()

	Patcher.HttpSetOnComplete(HttpRequest, function(InRequest, InResponse, InSucceeded)
		bComplete = true
		bSucceeded = InSucceeded
		if InSucceeded then
			local ResponseCode = Patcher.HttpGetResponseCode(InRequest, InResponse)
			if ResponseCode == 206 then
				bSucceeded = true
				local presave_filelength = get_local_filelength(localPath)
				if locallength ~= presave_filelength then
					--	local file deleted during downloading ?
					local msg = string.format("--------------file changed unexpectedly:localPath[%s],url[%s],locallength[%f],presave_filelength[%f]", localPath, url, locallength, presave_filelength)
					log_error(msg)
					bFileChangedBeforeSave = true
				else
					local SaveContentResult = Patcher.HttpSaveContentAppend(InRequest, InResponse, localPath)
					if not SaveContentResult then
						bSaveContentHasError = true
						local new_locallength = get_local_filelength(localPath)
						local free_space = GameUtil.getDiskFreeSpace(GameUtil.GetAssetsPath())

						local msg = string.format("--------------not all content saved:localPath[%s],url[%s],free=[%f],new_locallength[%f],locallength[%f]", localPath, url, free_space, new_locallength, locallength)
						log_error(msg)

						locallength = new_locallength
						remainlength = remotelength - locallength
					else
						locallength = get_local_filelength(localPath)
						remainlength = remotelength - locallength
					end
				end
			else
				local msg = string.format("--------------downloadFileImpl:invalid response code:[%d],url[%s]", ResponseCode, url)
				log_error(msg)
				bSucceeded = false
				if onError then
					onError(ERR_UNKNOWN, ResponseCode)
				end
			end
		else
			if not bRequestCancelled then
				bRetryOnFail = true
			end
			if onError then
				onError(ERR_CONNECTION)
			end
		end
	end)

	local bHasStart = false
	Patcher.HttpSetOnProgress(HttpRequest, function(InRequest, BytesSent, BytesRcv)
		if not bHasStart then
			bHasStart = true
			if onProcess then onProcess(locallength + BytesRcv, true) end
		else
			if onProcess then onProcess(locallength + BytesRcv, false) end
		end
	end)

	Patcher.HttpSetURL(HttpRequest, url)
	Patcher.HttpSetVerb(HttpRequest, "Get")
	Patcher.HttpSetHeader(HttpRequest, "Content-Type", "application/json")
	Patcher.HttpSetHeader(HttpRequest, "Accept-Encoding", "identity")

	local status = EHttpRequestStatus.Succeeded
	local ret = true
	while remainlength > 0 and ret do
		local range = ((remainlength > SIZE_PER_REQUEST) and SIZE_PER_REQUEST or remainlength)
		if remainlength - range < SIZE_PER_REQUEST_TO_AVOID then range = remainlength end
		local range_str = string.format("bytes=%u-%u", locallength, locallength + range - 1)

		local max_try_times = 3
		local try_times = 0
		while try_times < max_try_times do
			try_times = try_times + 1

			Patcher.HttpSetHeader(HttpRequest, "Range", range_str)
			Patcher.HttpSetHeader(HttpRequest, "User-Agent", "X-UnrealEngine-Agent")

			bComplete, bSucceeded, bRetryOnFail, bRequestCancelled, bFileChangedBeforeSave, bSaveContentHasError = false, false, false, false, false, false
			Patcher.HttpProcessRequest(HttpRequest)

			status = EHttpRequestStatus.Succeeded
			while status == EHttpRequestStatus.Processing or
					(status == EHttpRequestStatus.Succeeded and bComplete == false) do
				status = Patcher.HttpGetRequestStatus(HttpRequest)
				coro.yield()
			end

			ret = (bSucceeded and (status == EHttpRequestStatus.Succeeded))
			if ret then
				if bFileChangedBeforeSave then
					PopupMessageBoxWithStringTable("local downloaded file unexpectely changed", MBT_OK)

					local msg = string.format("--------------localPath[%s] was unexpectedly changed/removed", localPath)
					log_error(msg)

					local deleteReason = msg
					delete_local_file_guaranteed(localPath, deleteReason, "cannot delete unexpectedly changed downloaded file")

					locallength = 0
					remainlength = remotelength
				end
				if bSaveContentHasError then
					PopupMessageBoxWithStringTable("save downloaded content failed", MBT_OK)
					--	continue download from saved content
				end
				break
			end

			if not bRetryOnFail then
				break
			end

			while not has_network() do
				log("-----------waiting for network----------")
				PopupMessageBoxWithStringTable("network not available", MBT_OK)
			end

			if not GameUtil.HasActiveWiFiConnection() and not USER_NON_WIFI_OK and (remainlength > SILENT_DOWNLOAD_LIMIT) then
				log("fail download maybe because connection status change")
				local mret = PopupMessageBoxWithStringTable("confirm download via wireless network", MBT_OK_CANCEL)
				if mret == MBR_OK then
					log("user allow to download using non wifi")
					USER_NON_WIFI_OK = true
				else
					log("user not allow to download using non wifi")
					break
				end
			end
		end
	end

	Patcher.HttpDestroyRequest(HttpRequest)
	Patcher.HttpSetTimeout(LastTimeout)

	if ret then
		if onFinish then
			onFinish(locallength)
		end
	end

	return ret
end

--参数同 downloadFiles
local function downloadFilesForeground (fileList, inOnProgress, inOnFinish, inOnError)
	Patcher.new()
	local totalSize = 0
	for i, fileInfo in ipairs(fileList) do
		totalSize = totalSize + fileInfo.size
	end
	local finalSuccess = true
	local finishedFilesSize = 0
	for i, fileInfo in ipairs(fileList) do
		local url, localPath, size = fileInfo.url, fileInfo.localPath, fileInfo.size
		local function oneFileOnProgress (finishedSize)
			if inOnProgress then
				local finishedTotalSize = finishedFilesSize + finishedSize
				inOnProgress(finishedTotalSize / totalSize)
			end
		end
		local function oneFileOnFinish ()
			finishedFilesSize = finishedFilesSize + size
			--单个文件下载成功
			if inOnFinish then
				if "failed" == inOnFinish(i) then
					finalSuccess = false
				end
			end
		end
		local function oneFileOnError (ERR, ...)
			if inOnError then
				inOnError(ERR)
			end
		end

		if not finalSuccess then
			break
		end

		local bSuccess = downloadFileRaw(url, localPath, size, oneFileOnProgress, oneFileOnFinish, oneFileOnError)
		if not bSuccess then
			finalSuccess = false
			break
		end
	end

	if finalSuccess then
		if inOnFinish then
			inOnFinish("all")
		end
	end

	Patcher.delete()
	return finalSuccess
end

--参数同 downloadFiles
local function downloadFilesBackground(fileList, inOnProgress, inOnFinish, inOnError)
	print("start downloadFilesBackground")

	local totalSize = 0
	local urlToFileInfo = {}
	local urlToFileIndex = {}
	local urlDownState = {}
	for i, fileInfo in ipairs(fileList) do
		totalSize = totalSize + fileInfo.size
		GameUtil.CreateDirectoryForFile(fileInfo.localPath)
		urlToFileInfo[fileInfo.url] = fileInfo
		urlToFileIndex[fileInfo.url] = i
	end
	local finishedFilesSize = 0
	
	if ZLOfflineDownload.SetDownloadWhenNoWifi then
		--实现新增此函数前的旧逻辑，即在非 wifi 环境开始下载则允许用非 wifi 下载
		ZLOfflineDownload.SetDownloadWhenNoWifi(not GameUtil.HasActiveWiFiConnection())
	end
	ZLOfflineDownload.ClearOfflineDownloadTask()
	ZLOfflineDownload.SetDownloadTotalLengthAndLimitSpeed(0, 8*1024*1024)	--清空已下载文件，并设置较大的限速 (默认为 4MB/s)

	local function innerOnProgress (url, localPath, percentage)
		local fileInfo = urlToFileInfo[url]
		if not fileInfo then return end
		local totalFinishedSize = finishedFilesSize + percentage * fileInfo.size
		if inOnProgress then
			inOnProgress(totalFinishedSize / totalSize)
		end
	end

	local isEnd = false
	local isSuccess = false
	local errorCode = 0
	local coroRunningCount = 0

	local function dealWithOnOneFinish(downIndex)
		coroRunningCount = coroRunningCount + 1
		coro.start(function()
			if not inOnFinish then
				coroRunningCount = coroRunningCount - 1
				return
			end

			local ret = inOnFinish(downIndex)

			if "failed" == ret then
				--isEnd = true --单个文件验证失败不停止
				isSuccess = false
				errorCode = -1
				print("dealWithOnOneFinish failed")
			end

			coroRunningCount = coroRunningCount - 1
		end)
	end

	local function innerOnFileFinish (url, localPath, retCode)
		if retCode == 0 then
			local fileInfo = urlToFileInfo[url]
			if not fileInfo then return end
			finishedFilesSize = finishedFilesSize + fileInfo.size
			--单个文件下载成功
			--这里是主线程
			dealWithOnOneFinish(urlToFileIndex[url])
		else
			--isEnd = true --单个文件下载失败不停止
			isSuccess = false
			errorCode = retCode
			if inOnError then
				inOnError(retCode)
			end
		end
	end

	local function innerOnAllFinish (retCode)
		if retCode == 0 then
			isSuccess = true
		else
			isSuccess = false
			errorCode = retCode
		end
		isEnd = true --可能还在验证md5
	end

	local callbackHandle = ZLOfflineDownload.AddDownloadCallbacks(innerOnProgress, innerOnFileFinish, innerOnAllFinish)
	for i, fileInfo in ipairs(fileList) do
		local url, localPath, size = fileInfo.url, fileInfo.localPath, fileInfo.size
		ZLOfflineDownload.AddOfflinedDownloadTask(url, localPath, size)
	end
	while not isEnd do
		coro.yield()
	end

	while coroRunningCount > 0 do
		coro.yield()
	end

	if isSuccess then
		if inOnFinish then
			inOnFinish("all")
		end
	else
		errorCode = errorCode or -1
		if inOnError then
			inOnError(errorCode)
		end
	end

	--避免下载结束后还会调到回调
	inOnProgress = nil
	inOnFinish = nil
	inOnError = nil

	ZLOfflineDownload.RemoveDownloadCallbacks(callbackHandle)
	if not isSuccess then
		ZLOfflineDownload.CancelOfflineDownload()	--失败重试前需 cancel，以清空 natvie 库里记录的已下载长度
	end
	return isSuccess
end

--[[
	下载一组文件，尽量在后台下载
	param fileList: [i] = {url=, localPath=, size=}
	param onProgress: function onProgress (percentage), percentage: 0~1
	param onError: function onError (), return errorInfo
	return: 下载完成后返回，下载成功返回 true
]]
local function downloadFiles (fileList, onProgress, onFinish, onError)
	if EnableOfflineDownload then
		local platform_name = GameUtil.GetPlatformName()
		if platform_name == "Android" or platform_name == "IOS" then	--特定平台支持后台下载
			local noBackgroundDownload = false
			if SimulatorUtil.IsLeidianSimulator() then
				print("disable BackgroundDownload for leidian")
				noBackgroundDownload = true
			end
			if not noBackgroundDownload then
				return downloadFilesBackground(fileList, onProgress, onFinish, onError)
			end
		end
	end

	return downloadFilesForeground(fileList, onProgress, onFinish, onError)
end

local async_call_funcs
async_call_funcs = 
{
	downloadFile = function (argv)
		local url = argv[2]
		local localPath = argv[3]
		local timeout = argv[4]
		log("--------------enter downloadFile: url[%s], localPath[%s], timeout[%d]", url, localPath, timeout)
		local ret = downloadFileImpl(argv)
		Patcher.async_resume(ret and 1 or 0)
	end,
	downloadFileResumable = function (argv)
		local url = argv[2]
		local localPath = argv[3]
		local md5 = argv[4]
		log("--------------enter downloadFileResumable----------------", url, localPath, md5)
		argv[4] = 15*1000
		argv[7] = md5
		local ret = downloadFileImpl(argv)
		Patcher.async_resume(ret and 1 or 0)
	end,
	copyResBaseFiles = function (argv)
		log("--------------copyResBaseFiles----------------")
		Patcher.async_resume(0)	
	end,
	checkDiskFreeSpace = function (argv)
		local path = argv[2]
		local size = argv[3]
		local freesize = GameUtil.getDiskFreeSpace(path)		
		log("--------------checkDiskFreeSpace----------------", path, size, freesize)
		Patcher.async_resume(freesize>size and 1 or 0)
	end,
	popMessageBox = function (argv)
		local message = argv[2]
		local type = argv[3]
		local ret = MessageBoxPop(message, type or MBT_None)
		Patcher.async_resume(ret)
	end,
	HasActiveWiFiConnection = function (argv)
		local has = GameUtil.HasActiveWiFiConnection()
		log("--------------HasActiveWiFiConnection----------------", has)
		Patcher.async_resume(has and 1 or 0)
	end,
	isShowUpdateTip = function (argv)
		local ret = 1
		if IsEvaluation() then
			ret = 1
		elseif ShouldSkipShowUpdateTipForCurrentResource() then
			ret = 0
		elseif GameUtil.GetPlatformName() ~= "Windows" then
			if GameUtil.HasActiveWiFiConnection() then
				ret = 0
			else
				local totalPackSize = argv[2]
				--if totalPackSize < 5000000 then
				if totalPackSize < SILENT_DOWNLOAD_LIMIT then
					ret = 0
				end
			end
		else
			ret = 0
		end
		log("--------------isShowUpdateTip----------------", ret)
		Patcher.async_resume(ret)
	end,
	updateCurrentResourceDownloadTask = function (argv)
		Version.UpdateCurrentResourceDownloadTask(argv[2], argv[3], argv[4])
		log("--------------updateCurrentResourceDownloadTask----------------")
		Patcher.async_resume(1)
	end,
}

local b_check_async_call = true
local b_async_call_exited = true
local function check_async_call()
	while b_check_async_call do
		local argv = {Patcher.async_call()}
		if #argv > 0 then
			warn("check_async_call>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>", argv[1], async_call_funcs[argv[1]])
			async_call_funcs[argv[1]](argv)
		end
		coro.yield()
	end
	b_async_call_exited = true
end

local UpdateStage_None = 0
local UpdateStage_CheckLocalVersion = 1
local UpdateStage_CheckServerVersion = 2
local UpdateStage_Update = 3
local UpdateStage_Defrag =4

local ErrorCode_OK = 0
local ErrorCode_Fail = 1
local ErrorCode_Cancel = 2
local ErrorCode_Restart = 3
local ErrorCode_QuitGame = 4

local function FormatFileSize(size)
	local table_sizes = {stringtable['B'] or "B", stringtable['KB'] or "KB", stringtable['MB'] or "MB", stringtable['GB'] or "GB",}
	local table_sizes_length = #table_sizes

	local len = size
	local order = 1
	while len >= 1024 and (order + 1) < table_sizes_length do
		order = order + 1
		len = len / 1024
	end

	-- Adjust the format string to your preferences. For example "{0:0.#}{1}" would
	-- show a single decimal place, and no space.
	return string.format("%.1f %s", len, table_sizes[order])
end

local string_builder = {"","/",""}
local function RunPatcherStage(stageAction)
	stageAction()
	coro.yield()

	local toFinish = 2
	while toFinish > 0 do
		if not Patcher.is_busy() then
			toFinish = toFinish - 1
		end

		set_block_text("Txt_Local1", tostring(Patcher.getLocalVersion()))
		set_block_text("Txt_Sever1", tostring(Patcher.getServerVersion()))

		local progress = Patcher.getTotalProgress()
		set_progress_percent(progress)
		set_block_text("Text_Check", Patcher.getStatusText())

		local totalUpdateSize = Patcher.getUpdateTotalSize()
		local updateStage = Patcher.getUpdateStage()
		--print(string.format("__RunPatcherStage: toFinish[%d], totalUpdateSize[%d], updateStage[%d]", toFinish, totalUpdateSize, updateStage))

		if totalUpdateSize > 0 and updateStage == UpdateStage_Update then
			string_builder[1] = FormatFileSize(totalUpdateSize * progress)
			string_builder[3] = FormatFileSize(totalUpdateSize)


			--戴宗打点需求
			local step_size = {}
			for code, size in pairs(daizong_stepcode_update_size) do
				table.insert(step_size, {code=code, size=size})
			end
			table.sort(step_size, function(l, r) return l.size < r.size  end)
			for _, v in ipairs(step_size) do
				if not daizong_stepcode_flag[v.code] and totalUpdateSize >= v.size then
					daizong_stepcode_flag[v.code] = true
					DaizongSDK.LogStepLogReport(v.code)
				end
			end
		end
		local strDetail = (string.len(string_builder[1]) > 0) and table.concat(string_builder) or ""
		set_block_text("Text_Detail", strDetail)

		coro.yield()
	end

	local errorCode = Patcher.getErrorCode()
	log("................getErrorCode...............", errorCode)

	if errorCode == ErrorCode_Fail then
		local msg = "update failed"
		MessageBoxPop(stringtable[msg] or msg, MBT_None)
	end

	return errorCode
end

local extra_packages
local extra_packages_folder
local function load_extra_package_config()
	log("load_extra_package_config")

	if extra_packages then
		return
	end

	if not EntryPointConfig.ExtraPackageFolder then
		log("no extra_package")
		return
	end

	local xml = GameUtil.StreamingAssetReadFileText("res_base/extra_package.xml")
	if xml then
		local doc = rapidxml.new_doc()
		local bOK, err = rapidxml.doc_parse(doc, xml)
		if bOK then
			local root = rapidxml.doc_first_node(doc)
			if root then
				do
					local origin = rapidxml.node_first_attribute(root, "name")
					if origin then
						local name = rapidxml.attribute_value(origin)
						extra_packages_folder = name
						print("extra_packages_folder ", name)
					end
				end
				local node = rapidxml.node_first_node(root)
				while node do
					local nameattr = rapidxml.node_first_attribute(node, "name")
					local bnameattr = rapidxml.node_first_attribute(node, "basename")
					local extattr = rapidxml.node_first_attribute(node, "ext")
					local md5attr = rapidxml.node_first_attribute(node, "md5")
					local sizeattr = rapidxml.node_first_attribute(node, "size")

					local name = rapidxml.attribute_value(nameattr)
					local bname = rapidxml.attribute_value(bnameattr)
					local ext = rapidxml.attribute_value(extattr)
					local md5 = rapidxml.attribute_value(md5attr)
					local size = rapidxml.attribute_value(sizeattr)
					extra_packages = extra_packages or {}
					extra_packages[#extra_packages+1] = {name=name, bname=bname, ext=ext, md5=md5, size=tonumber(size)}
					print("extra_package ", name, size)

					node = rapidxml.node_next_sibling(node)
				end
			end
		else
			warn("parse res_base/extra_package.xml error:", err)
		end
		rapidxml.delete_doc(doc)
	end
end

local function rename_file(srcFile, dstFile)
	--改名：
	print("rename file:", srcFile, dstFile)
	local result = false
	while Patcher.FileExists(srcFile) do
		local b, err, code = os.rename(srcFile, dstFile)
		if not b then
			print("rename failed", srcFile, dstFile, err, code)
			PopupMessageBoxWithStringTable("rename file failed", MBT_OK)
		else
			result = true
			break
		end
	end
	print("rename file result:", result)

	return result
end

local --[[function]] predownload_extra_package_inner
local function predownload_extra_package()
	print("===========================predownload_extra_package=====================")
	load_extra_package_config()
	-- no extra_packages
	if not extra_packages then
		return
	end
	DaizongSDK.LogStepLogReport(DAIZONG_STEPCODE.UPDATE_EXTRA_PACKAGE_ENTER)
	GEMLogin.PostLoginStepEvent(GEMLogin.LoginStep.START_UPDATE_PACKAGE)

	if UniSDK then
		UniSDK.action("sendAppsFlyerEvent", {eventName="begin_package", eventValue=""})
	end

	local maxTrialsEachAddress = 2
	while true do
		local finished = false
		for iAddress, address in ipairs(AddressList) do
			for iTrial = 1, maxTrialsEachAddress do
				print(("predownload_extra_package start, address: %s, trail: %d"):format(address, iTrial))
				if predownload_extra_package_inner(address) then
					finished = true
					break
				else
					print("predownload_extra_package failed, will retry")
				end
			end
			if finished then
				break
			end
		end
		if finished then
			break
		end
	end

	DaizongSDK.LogStepLogReport(DAIZONG_STEPCODE.UPDATE_EXTRA_PACKAGE_FINISH)
	GEMLogin.PostLoginStepEvent(GEMLogin.LoginStep.FINISH_PACKAGE)

	if UniSDK then
		UniSDK.action("sendAppsFlyerEvent", {eventName="end_package", eventValue=""})
	end
end

--尝试一次下载+md5验证，成功时返回 true，失败时弹出相应提示并返回 false
--[[local]] function predownload_extra_package_inner (updateAddress)
	local Address = updateAddress

	local urlprefix = Address .. "bin/extra_package/"

	if extra_packages_folder and #extra_packages_folder >0 then
		urlprefix = urlprefix .. extra_packages_folder .. "/"
	end

	local extraPackageLayer = 3
	local extraPackagePath = GameUtil.GetDocumentPath() .. "/" .. EntryPointConfig.ExtraPackageFolder
	local destFolder = extraPackagePath .. "/package"

	--new: basename_resourceversion_md5.ext
	local function split_filename(filename)
		local arr = mysplit(filename, "_")
		local basename = arr[1]
		local resource_version = arr[2]
		local v = mysplit(arr[3], ".")
		local md5 = v[1]
		local ext = table.concat(v, ".",  2)

		return basename, resource_version, md5, ext
	end

	local function write_to_file(path, content)
		GameUtil.CreateDirectoryForFile(path)
		local fout = io.open(path, "wb")
		if fout then
			fout:write(content)
			fout:close()
			return true
		else
			return false
		end
	end

	local function read_file_content(path)
		local fin = io.open(path, "rb")
		if fin then
			local content = fin:read("*a")
			fin:close()
			return content
		else
			return nil
		end
	end

	af.InitPackageLayer(extraPackageLayer, extraPackagePath, EntryPointConfig.SepFile);
	af.SetReadOnly(extraPackageLayer, true);
	af.SetKeepFullPath(extraPackageLayer, false);

	local total_size = 0
	local filelist = {}
	for _, pckConfig in pairs(extra_packages) do
		local remotename, bname, remotemd5, ext  = pckConfig.name, pckConfig.bname, pckConfig.md5, pckConfig.ext
		local fname = bname .. "." .. ext
		local destFile = destFolder.."/".. fname --下载到本地之后存储的实际文件
		local destFileTmp = destFolder .."/" .. remotename .. ".dl" --直接下载写入到目的文件, 成功后会改名为最终文件

		--检查是否需要下载
		local bNeedDownload = false

		--检查记录文件
		local localmd5File = extraPackagePath .. "/" .. bname .. ".txt" --md5文件， 比如maps.txt里面记录了maps的md5值
		if not bNeedDownload then
			local localPath = destFile
			local md5Match = false
			if af.IsSepFileExist(localmd5File) then
				local localMD5 = read_file_content(localmd5File)
				if localMD5 and string.upper(localMD5) == string.upper(remotemd5) then
					md5Match = true
				end
			end
			if not md5Match then
				bNeedDownload = true
				print("local md5 not equal remotemd5: " .. bname)

				--删除本地不匹配的文件
				local deleteReason = "md5 not match: " .. fname
				delete_local_file_guaranteed(localmd5File, deleteReason, "cannot delete downloaded file with error")
				delete_local_file_guaranteed(destFile, deleteReason, "cannot delete downloaded file with error")
			end
		end

		--本地不存在，需要下载
		if not bNeedDownload and not af.IsSepFileExist(destFile) then
			bNeedDownload = true
			print("need download local not found", remotename)
			local deleteReason = "local file not exist: " .. fname
			delete_local_file_guaranteed(localmd5File, deleteReason, "cannot delete downloaded file with error")
		end

		--本地文件大小不一致，需要下载
		if not bNeedDownload and Patcher.GetFileSize(destFile) ~= pckConfig.size then
			bNeedDownload = true
			print("need download local size different", remotename)

			--删除本地不匹配的文件
			local deleteReason = "wrong file size " .. fname
			delete_local_file_guaranteed(localmd5File, deleteReason, "cannot delete downloaded file with error")
			delete_local_file_guaranteed(destFile, deleteReason, "cannot delete downloaded file with error")
		end

		--需要下载
		if bNeedDownload then
			total_size = total_size + pckConfig.size
			local url = urlprefix .. remotename

			filelist[#filelist + 1] =
			{
				url = url,
				name = remotename,
				dest = destFile,
				destTmp = destFileTmp,
				size = pckConfig.size,
				localmd5File = localmd5File,
				md5 = remotemd5,
			}
		else
			print("extral package", fname, "is ready, no need download")
		end
	end

	if #filelist > 0 then
		print(("need download size:%s"):format(FormatFileSize(total_size)))
		--下载
		local downloadRemainSize = total_size
		local downloadFileList = {}
		for i, onepackage in ipairs(filelist) do
			downloadFileList[#downloadFileList+1] = {url=onepackage.url, localPath=onepackage.destTmp, size=onepackage.size}
			if af.IsSepFileExist(onepackage.destTmp) then
				local downSize = Patcher.GetFileSize(onepackage.destTmp)
				downloadRemainSize = downloadRemainSize - downSize
			end
		end

		local Txt_Process = m_panel:FindDirect("UpdateBar/Text_Detail")
		local ProBar = m_panel:FindDirect("UpdateBar/Update_bar")
		local progress_string_builder = {"","/",""}

		ProBar:SetPercent(0)

		local verifyMd5ToDownloadSizeRatio = 0.1	--验证md5计为下载大小的比例 (验证 md5 一般比下载要快)
		local progressTotalSize = total_size + total_size * verifyMd5ToDownloadSizeRatio --需要下载的大小，以及需要验证md5的大小
		local hasverifyMD5Size = 0
		local hasdownloadSize = 0
		local function onFileListDownloadProgress (percentage)
			local has_download_size = total_size * percentage
			hasdownloadSize = has_download_size
			progress_string_builder[1] = FormatFileSize(has_download_size)
			progress_string_builder[3] = FormatFileSize(total_size)
			Txt_Process:SetText(table.concat(progress_string_builder))

			local progress = (has_download_size + hasverifyMD5Size * verifyMd5ToDownloadSizeRatio) / math.max(progressTotalSize, 1)
			--print("progress", BytesRcv, has_download_size, info.download_length, info.total_size, progress)
			ProBar:SetPercent(progress)
			GEMLogin.PostEventGEMForDownloadProgress(progress)
		end

		set_block_text("Text_Check", stringtable['extra package downloading'] or 'extra package downloading')
		DaizongSDK.LogStepLogReport(DAIZONG_STEPCODE.UPDATE_EXTRA_PACKAGE_DOWNLOAD)
		GEMLogin.PostLoginStepEvent(GEMLogin.LoginStep.START_DOWNLOAD_PACKAGE)

		if UniSDK then
			UniSDK.action("sendAppsFlyerEvent", {eventName="download_package", eventValue=""})
		end

		local downloadStartTime = Time.realtimeSinceStartup
		local downloadSuccess
		local verifyingMD5Error
		local diskSpaceValid = true
		local extral_size = math.max(downloadRemainSize*0.05, 20*1024*1024)
		local free_space = GameUtil.getDiskFreeSpace(GameUtil.GetAssetsPath())
		if downloadRemainSize + extral_size > free_space then --剩余空间不足
			diskSpaceValid = false
			print("there is insufficient space on the disk", downloadRemainSize, extral_size, free_space)
		end
		if not diskSpaceValid then
			downloadSuccess = false
		else
			local function VerifyingOneFile(onepackage, downIndex)
				set_block_text("Text_Check", stringtable['extra package verifying'] or 'extra package verifying')

				local file_size = onepackage.size
				local function onCalcMd5Progress (finishedSize)
					--Txt_Process:SetText("")
					local progress = (hasdownloadSize + (hasverifyMD5Size + finishedSize) * verifyMd5ToDownloadSizeRatio) / math.max(progressTotalSize, 1)
					ProBar:SetPercent(progress)
				end

				local localMD5 = CalcBigFileMd5(onepackage.destTmp, onCalcMd5Progress)
				hasverifyMD5Size = hasverifyMD5Size + file_size

				if string.upper(localMD5) == string.upper(onepackage.md5) then
					rename_file(onepackage.destTmp, onepackage.dest)
					--记录下载md5
					print("save md5 to file",  onepackage.md5, onepackage.localmd5File)
					write_to_file(onepackage.localmd5File, onepackage.md5)

					verifyingMD5Error = nil

					--下一个文件的下载
					if downIndex < #filelist then
						set_block_text("Text_Check", stringtable['extra package downloading'] or 'extra package downloading')
					end
				else
					warn(("check md5 for extra package '%s' failed. downfile md5 is:%s, server md5 is:%s"):format(onepackage.name, tostring(localMD5), onepackage.md5))
					local deleteReason = string.format("---------md5 different")
					delete_local_file_guaranteed(onepackage.destTmp, deleteReason, "cannot delete cached file")

					DaizongSDK.LogStepLogReport(DAIZONG_STEPCODE.UPDATE_EXTRA_PACKAGE_CHECK_MD5_FAILURE)
					GEMLogin.PostLoginStepEvent(GEMLogin.LoginStep.CHECK_PACKAGE,false,DAIZONG_STEPCODE.UPDATE_EXTRA_PACKAGE_CHECK_MD5_FAILURE,"check package md5 fail")

					verifyingMD5Error = true
					return false
				end

				return true
			end

			local function OnAllDownFinish()
				print("OnAllDownFinish")
			end
			--单个文件下载成功
			local function OnFileDownFinish(downIndex)
				if downIndex == "all" then
					OnAllDownFinish()
				else
					local onepackage = filelist[downIndex]
					print("=======================down one finish", onepackage.url)
					if not VerifyingOneFile(onepackage, downIndex) then
						return "failed"
					end
				end
			end
			downloadSuccess = downloadFiles(downloadFileList, onFileListDownloadProgress, OnFileDownFinish, nil)
		end

		local downloadEndTime = Time.realtimeSinceStartup
		local downloadTimeMs = (downloadEndTime - downloadStartTime)*1000
		local resourceVersion
		do
			local _, resource_version, _, _ = split_filename(filelist[1].name)
			resourceVersion = resource_version
		end
		DaizongSDK.LogGameUpdate({
			updateid = 1,	--package更新
			updateurl = Address,
			filesize = total_size,
			downloadtime = downloadTimeMs,
			downloadsize = total_size,
			updatestatus = downloadSuccess and 0 or 1,
			updateversion = resourceVersion or "",
		})

		if not downloadSuccess then
			print("download extra package failed")
			DaizongSDK.LogStepLogReport(DAIZONG_STEPCODE.UPDATE_EXTRA_PACKAGE_DOWNLOAD_FAILURE)
			DaizongSDK.LogNetState(Address, 30)
			GEMLogin.PostLoginStepEvent(GEMLogin.LoginStep.DOWNLOAD_PACKAGE,false,DAIZONG_STEPCODE.UPDATE_EXTRA_PACKAGE_DOWNLOAD_FAILURE,"down package fail")
			if not diskSpaceValid then
				local fmt = stringtable["insufficient space on the disk, need %s, left %s"] or "insufficient space on the disk, need %s, left %s"
				local text = string.format(fmt, FormatFileSize(downloadRemainSize + extral_size), FormatFileSize(free_space))
				--PopupMessageBoxWithStringTable(text, MBT_OK)
				MessageBoxPop(text, MBT_OK)
			else
				PopupMessageBoxWithStringTable("extra package download error", MBT_OK)
			end
			return false
		else
			DaizongSDK.LogStepLogReport(DAIZONG_STEPCODE.UPDATE_EXTRA_PACKAGE_DOWNLOAD_SUCCESS)
			DaizongSDK.LogNetState(Address, 5)
			GEMLogin.PostLoginStepEvent(GEMLogin.LoginStep.DOWNLOAD_PACKAGE)
		end

		if false then --check md5 after all finish
			set_block_text("Text_Check", stringtable['extra package verifying'] or 'extra package verifying')

			--验证文件 md5
			local hasFailedMd5 = false
			local calcMd5TotalFinishedFileSize = 0
			local function onCalcMd5Progress (finishedSize)
				Txt_Process:SetText("")

				local progress = (calcMd5TotalFinishedFileSize + finishedSize) / total_size
				--print("progress", BytesRcv, has_download_size, info.download_length, info.total_size, progress)
				ProBar:SetPercent(progress)
			end

			for i, onepackage in ipairs(filelist) do
				local localMD5 = CalcBigFileMd5(onepackage.destTmp, onCalcMd5Progress)
				calcMd5TotalFinishedFileSize = calcMd5TotalFinishedFileSize + onepackage.size

				if string.upper(localMD5) == string.upper(onepackage.md5) then
					rename_file(onepackage.destTmp, onepackage.dest)
					--记录下载md5
					print("save md5 to file",  onepackage.md5, onepackage.localmd5File)
					write_to_file(onepackage.localmd5File, onepackage.md5)
				else
					warn(("check md5 for extra package '%s' failed. downfile md5 is:%s, server md5 is:%s"):format(onepackage.name, tostring(localMD5), onepackage.md5))
					hasFailedMd5 = true
					local deleteReason = string.format("---------md5 different")
					delete_local_file_guaranteed(onepackage.destTmp, deleteReason, "cannot delete cached file")
				end
			end

			if hasFailedMd5 then
				DaizongSDK.LogStepLogReport(DAIZONG_STEPCODE.UPDATE_EXTRA_PACKAGE_CHECK_MD5_FAILURE)
				GEMLogin.PostLoginStepEvent(GEMLogin.LoginStep.CHECK_PACKAGE,false,DAIZONG_STEPCODE.UPDATE_EXTRA_PACKAGE_CHECK_MD5_FAILURE,"check package md5 fail")
				PopupMessageBoxWithStringTable("extra package download error", MBT_OK)
				return false
			end
		end

		GEMLogin.PostLoginStepEvent(GEMLogin.LoginStep.CHECK_PACKAGE)

		--现在已经下载完成了，清理仍然存在的 .dl 文件，可能是之前下载残留的
        for file in lfs.dir(destFolder) do
            if file:find("%.dl$") then
				Patcher.UDeleteFile(destFolder .. "/" .. file)
			end
		end

		print("download extra packages finished!!!")
	end
	return true
end

local function GetVersionList()
	return GameUtil.GetVersionList() or ""
end

local function patcher_init(progressData)
	DaizongSDK.LogStepLogReport(DAIZONG_STEPCODE.UPDATE_RESOURCE_ENTER)

	if UniSDK then
		UniSDK.action("sendAppsFlyerEvent", {eventName="begin_patcher", eventValue=""})
	end

	local resBasePath = EntryPointConfig.BackupAssetsPath
	local resourcePath = EntryPointConfig.AssetsPath
	local cachePath = EntryPointConfig.AssetsPath.."/cache"
	local stringTableContent = load_patcher_stringtable()
	local newVersionFromDirInfo = GetVersionList()
	local isEvaluation = IsEvaluation()

	local extraPackagePath = ""
	if EntryPointConfig.ExtraPackageFolder then
		extraPackagePath = GameUtil.GetDocumentPath() .. "/" .. EntryPointConfig.ExtraPackageFolder
	end

	local buildinLang = Lang.GetAppBuiltinLang()
	local xmlVersionTag = Lang.GetXmlVersionTag(buildinLang)
	local packSubPath = ""
	local otherPackCount = progressData and progressData.otherPackCount or 0
	local otherPackSize = progressData and progressData.otherPackSize or 0
	local otherFinishedPackCount = progressData and progressData.otherFinishedPackCount or 0
	local otherDownloadedPackSize = progressData and progressData.otherDownloadedPackSize or 0
	local initTotalProgress = progressData and progressData.initTotalProgress or 0

	warn("Patcher Init resource_update")
	warn("minimumResourceVersion:", minimumResourceVersion)
	warn("resBaseVersion:", resBaseVersion)
	warn("resBasePath:", resBasePath)
	warn("resourcePath:", resourcePath)
	warn("cachePath:", cachePath)
	warn("stringTableContent:", stringTableContent)
	warn("PackPrefix:", PackPrefix)
	warn("Packext:", Packext)
	warn("Project:", Project)
	warn("Address:", Address)
	warn("BackupAddress:", BackupAddress)
	warn("BackupIP:", BackupIP)
	warn("newVersionFromDirInfo:", newVersionFromDirInfo)
	warn("isEvaluation:", isEvaluation)
	warn("forceUpdateToLatest", forceUpdateToLatest)
	warn("extraPackagePath", extraPackagePath)
	warn("buildinLang", buildinLang)
	warn("xmlVersionTag", xmlVersionTag)
	
	Patcher.new(initTotalProgress)

	Patcher.init(minimumResourceVersion,resBaseVersion,
		resBasePath,resourcePath,cachePath,stringTableContent,
		PackPrefix,Packext,Project,Address,BackupAddress,BackupIP,
		newVersionFromDirInfo,false --[[本是 isEvaluation，现禁用审核时假装下载更新的做法]],forceUpdateToLatest,_G.g_IsMiniApp,
		extraPackagePath, xmlVersionTag, packSubPath,
		otherPackCount, otherPackSize, otherFinishedPackCount, otherDownloadedPackSize)

	DaizongSDK.LogStepLogReport(DAIZONG_STEPCODE.UPDATE_RESOURCE_DOWNLOAD)
	GEMLogin.PostLoginStepEvent(GEMLogin.LoginStep.START_DOWNLOAD_PATCHER)

	if UniSDK then
		UniSDK.action("sendAppsFlyerEvent", {eventName="download_patcher", eventValue=""})
	end

	b_check_async_call = true
	b_async_call_exited = false
	coro.start(check_async_call)
end

local function patcher_init_language(currentLang, langVersionList, progressData)
	local langMinimumVersion = langVersionList.VerSeparate	-- 根据当前能更新的最低版本、在必要时删除之前的语言包重新下载
	local langBaseVersion = 0
	local langBasePath = ""
	local resourcePath = Path.GetLangPath(currentLang)
	local cachePath = resourcePath.."/cache"
	local stringTableContent = load_patcher_stringtable()
	local newVersionFromDirInfo = GetVersionList()
	local isEvaluation = IsEvaluation()
	local extraPackagePath = ""
	local xmlVersionTag = Lang.GetXmlVersionTag(currentLang)
	local packSubPath = currentLang
	local otherPackCount = progressData and progressData.otherPackCount or 0
	local otherPackSize = progressData and progressData.otherPackSize or 0
	local otherFinishedPackCount = progressData and progressData.otherFinishedPackCount or 0
	local otherDownloadedPackSize = progressData and progressData.otherDownloadedPackSize or 0
	local initTotalProgress = progressData and progressData.initTotalProgress or 0
	
	DaizongSDK.LogStepLogReport(DAIZONG_STEPCODE.UPDATE_RESOURCE_ENTER)
	if UniSDK then
		UniSDK.action("sendAppsFlyerEvent", {eventName="begin_patcher_lang", eventValue=""})
	end

	Patcher.new(initTotalProgress)

	Patcher.init(langMinimumVersion,langBaseVersion,
		langBasePath,resourcePath,cachePath,stringTableContent,
		PackPrefix,Packext,Project,Address,BackupAddress,BackupIP,
		newVersionFromDirInfo,isEvaluation,forceUpdateToLatest,_G.g_IsMiniApp,
		extraPackagePath, xmlVersionTag, packSubPath,
		otherPackCount, otherPackSize, otherFinishedPackCount, otherDownloadedPackSize)

	DaizongSDK.LogStepLogReport(DAIZONG_STEPCODE.UPDATE_RESOURCE_DOWNLOAD)
	GEMLogin.PostLoginStepEvent(GEMLogin.LoginStep.START_DOWNLOAD_PATCHER)
	if UniSDK then
		UniSDK.action("sendAppsFlyerEvent", {eventName="download_patcher_lang", eventValue=""})
	end

	b_check_async_call = true
	b_async_call_exited = false
	coro.start(check_async_call)
end

local function patcher_destroy()
	b_check_async_call = false
	while not b_async_call_exited do
		coro.yield()
	end
	Patcher.delete()
end

local function init_igu_for_resource_update ()
	if _G.g_IsMiniApp then
		if InGameUpdate.RepairAllSavedDownloadEntryListAsync then
			local needRepair = false
			local corruptFilePath = GameUtil.GetAssetsPath() .. "/ingameupdate/corrupt_file.txt"
			if lfs.attributes(corruptFilePath, "mode") == "file" then
				print("InGameUpdate, has corrupt file flag, will repair")
				needRepair = true
			end
			
			if needRepair then
				os.remove(corruptFilePath)
				
				local finished = false
				InGameUpdate.RepairAllSavedDownloadEntryListAsync(GameUtil.GetAssetsPath(), function (errFlag, anyEntryRepaired)
					finished = true
					if errFlag == 0 then
						if anyEntryRepaired then
							print("InGameUpdate, one or more entries repaired")
						else
							warn("ingameupdate file no entries repaired")
						end
					else
						warn("ingameupdate RepairAllSavedDownloadEntryListAsync failed: ", errFlag)
					end
				end)
				while not finished do
					coro.yield()
				end
			end
		end
		if InGameUpdate.InitForResUpdate then
			print("resource_update, InGameUpdate.InitForResUpdate")
			InGameUpdate.InitForResUpdate()
		end
	end
end

local function resource_update()
	warn("-----------------------Patcher Start resource_update")
	init_igu_for_resource_update()
	
	patcher_init(Version.CollectCurrentResourceProgressData())

	show_panel("TextGroup2", false)
	show_panel("TextGroup1", true)
	set_block_text("Txt_Local1", "")
	set_block_text("Txt_Sever1", "")

	local restart_count = 0
	local errorCode = ErrorCode_Restart
	while errorCode == ErrorCode_Restart do
		local bSkipResourceUpdate = IsNoResourceUpdate()
		log("Start update stages: bSkipResourceUpdate ", bSkipResourceUpdate)

		repeat		
			errorCode = RunPatcherStage(function() Patcher.startInitResource(); log("------startInitResource--------") end)

			if errorCode ~= ErrorCode_OK then 
				local msg = tostring(errorCode)
				if Patcher.getInnerErrorCode ~= nil then
					msg = tostring(Patcher.getInnerErrorCode())
				end
				_G.GSDKSetEvent(GSDK_EVENT_RESOURCEINIT, false, msg, false, false)
				break
			end

			_G.GSDKSetEvent(GSDK_EVENT_RESOURCEINIT, true, "success", false, false)

			if not bSkipResourceUpdate then
				if errorCode ~= ErrorCode_OK then 
					break 
				end

				errorCode = RunPatcherStage(function() Patcher.startAutoUpdate(); log("------startAutoUpdate--------") end, true)
				if errorCode ~= ErrorCode_OK then 
					local msg = tostring(errorCode)
					if Patcher.getInnerErrorCode ~= nil then
						msg = tostring(Patcher.getInnerErrorCode())
						log("getInnerErrorCode = ", msg) 
					end
					_G.GSDKSetEvent(GSDK_EVENT_RESOURCUPDATE, false, msg, false, false)
				end
			end
		until true
		restart_count = restart_count + 1
		if restart_count == 10 then	
			local msg = "restart_count == 10"
			MessageBoxPop(stringtable[msg] or msg, MBT_None)
		end
	end

	if errorCode == ErrorCode_OK then
		if Patcher.getUpdateTotalSize() > 0 then
			_G.GSDKSetEvent(GSDK_EVENT_RESOURCUPDATE, true, "success", false, false)
		else
			_G.GSDKSetEvent(GSDK_EVENT_RESOURCUPDATE, true, "no need update", false, false)
		end
	end

	if errorCode == ErrorCode_QuitGame then
		GameUtil2.QuitGame()
		loop_endless()
	end

	patcher_destroy()
	
	if _G.g_IsMiniApp then
		print("resource_update, InGameUpdate.Release")
		if InGameUpdate.ReleaseForResUpdate then
			InGameUpdate.ReleaseForResUpdate()
		else
			InGameUpdate.Release()
		end
	end

	warn("-----------------------Patcher Finish resource_update")
	DaizongSDK.LogStepLogReport(DAIZONG_STEPCODE.UPDATE_RESOURCE_FINISH)
	GEMLogin.PostLoginStepEvent(GEMLogin.LoginStep.FINISH_PATCHER)

	if UniSDK then
		UniSDK.action("sendAppsFlyerEvent", {eventName="end_patcher", eventValue=""})
	end
end

local function language_update()
	if not Lang.HasCustomLang() then
		return
	end

	local currentLang = Lang.GetCustomLang()	
	warn(string.format("-----------------------Patcher Start language_update(%s)", currentLang))	

	set_block_text("Txt_Local1", "")
	set_block_text("Txt_Sever1", "")

	local langVersionList = Version.GetOrParseVersionList(currentLang)
	if not langVersionList then
		PopupMessageBoxWithStringTable("update failed", MBT_None)
	end

	patcher_init_language(currentLang, langVersionList, Version.CollectCurrentResourceProgressData())

	local restart_count = 0
	local errorCode = ErrorCode_Restart
	while errorCode == ErrorCode_Restart do
		repeat		
			errorCode = RunPatcherStage(function() Patcher.startInitResource(); log("------startInitResource(language)--------") end)
			if errorCode ~= ErrorCode_OK then 
				local msg = tostring(errorCode)
				if Patcher.getInnerErrorCode ~= nil then
					msg = tostring(Patcher.getInnerErrorCode())
				end
				_G.GSDKSetEvent(GSDK_EVENT_RESOURCEINIT, false, msg, false, false)
				break
			end
			_G.GSDKSetEvent(GSDK_EVENT_RESOURCEINIT, true, "success", false, false)

			errorCode = RunPatcherStage(function() Patcher.startAutoUpdate(); log("------startAutoUpdate(language)--------") end, true)
			if errorCode ~= ErrorCode_OK then 
				local msg = tostring(errorCode)
				if Patcher.getInnerErrorCode ~= nil then
					msg = tostring(Patcher.getInnerErrorCode())
					log("getInnerErrorCode(language) = ", msg) 
				end
				_G.GSDKSetEvent(GSDK_EVENT_RESOURCUPDATE, false, msg, false, false)
			end
		until true

		restart_count = restart_count + 1
		if restart_count == 10 then	
			PopupMessageBoxWithStringTable("restart_count == 10", MBT_None)
		end
	end

	if errorCode == ErrorCode_OK then
		if Patcher.getUpdateTotalSize() > 0 then
			_G.GSDKSetEvent(GSDK_EVENT_RESOURCUPDATE, true, "success", false, false)
		else
			_G.GSDKSetEvent(GSDK_EVENT_RESOURCUPDATE, true, "no need update", false, false)
		end
	end

	if errorCode == ErrorCode_QuitGame then
		GameUtil2.QuitGame()
		loop_endless()
	end

	patcher_destroy()

	warn("-----------------------Patcher Finish language_update")
	DaizongSDK.LogStepLogReport(DAIZONG_STEPCODE.UPDATE_RESOURCE_FINISH)
	GEMLogin.PostLoginStepEvent(GEMLogin.LoginStep.FINISH_PATCHER)

	if UniSDK then
		UniSDK.action("sendAppsFlyerEvent", {eventName="end_patcher_lang", eventValue=""})
	end
end

local function resource_reset_local_version()
	patcher_init()

	log("------resetLocalVersion--------")
	Patcher.resetLocalVersion()
	coro.yield()
	while Patcher.is_busy() do
		coro.yield()
	end
	log("................getErrorCode...............", Patcher.getErrorCode())

	patcher_destroy()
end

--------------------------------------------------------------------------------------------------------------------------
local function HasExtraPackage(extraPackageBaseName)
	if extra_packages then
		for _, extra_package in ipairs(extra_packages) do
			if extra_package.bname == extraPackageBaseName then
				return true
			end
		end
	end
	return false
end

local g_szPckDir = require "pckdir"
local function InitAFilePacks()

	af.SetAlgorithmID(161);
	local languagePackagerLayer, currentLang
	local resourcePackageLayer
	local resBasePackageLayer
	local extraPackageLayer
	local extraPackagePath
	do
		local layerIndex = 0

		--layer: pck (debug dir) --eg: /storage/emulated/0/Android/data/com.zulong.phecda/files/pck
		--if GameUtil.HasDebugPath() then
		af.InitPackageLayer(layerIndex, EntryPointConfig.PckDebugDir, true);
		af.SetReadOnly(layerIndex, true);
		af.SetKeepFullPath(layerIndex, false);

		layerIndex = layerIndex + 1;
		--end

		--layer: language --eg:/storage/emulated/0/Android/data/com.zulong.phecda/files/en		
		if Lang.HasCustomLang() then
			currentLang = Lang.GetCustomLang()
			languagePackagerLayer = layerIndex;
			af.InitPackageLayer(layerIndex, Path.GetLangPath(currentLang), EntryPointConfig.SepFile);
			af.SetReadOnly(layerIndex, true);
			af.SetKeepFullPath(layerIndex, false);

			layerIndex = layerIndex + 1;
		end

		--layer: resource --eg:/storage/emulated/0/Android/data/com.zulong.phecda/files
		resourcePackageLayer = layerIndex;
		af.InitPackageLayer(layerIndex, EntryPointConfig.AssetsPath, EntryPointConfig.SepFile);
		af.SetReadOnly(layerIndex, true);
		af.SetKeepFullPath(layerIndex, false);

		layerIndex = layerIndex + 1;

		--layer: res base --eg:assets://res_base
		resBasePackageLayer = layerIndex;
		af.InitPackageLayer(layerIndex, EntryPointConfig.BackupAssetsPath, false);
		af.SetReadOnly(layerIndex, true);
		af.SetKeepFullPath(layerIndex, false);

		layerIndex = layerIndex + 1;

		--Android需要额外资源包目录
		if EntryPointConfig.ExtraPackageFolder then
			extraPackageLayer = layerIndex
			extraPackagePath = GameUtil.GetDocumentPath() .. "/" .. EntryPointConfig.ExtraPackageFolder
			log("InitPackageLayer extraPackagePath", extraPackagePath)
			af.InitPackageLayer(layerIndex, extraPackagePath, EntryPointConfig.SepFile);
			af.SetReadOnly(layerIndex, true);
			af.SetKeepFullPath(layerIndex, false);

			layerIndex = layerIndex + 1;
		end

		--layer: non-package files
		af.InitPackageLayer(layerIndex, EntryPointConfig.AssetsPath, true);
		af.SetReadOnly(layerIndex, false);
		af.SetKeepFullPath(layerIndex, false);

		layerIndex = layerIndex + 1;
	end

	--if not _G.GIsEditor then
		local need_reset_local_version = false
		local need_reset_lang_version = false
		for strFolder, strPckFile in pairs(g_szPckDir) do
			if languagePackagerLayer and not af.OpenFilePackage(languagePackagerLayer, strPckFile, strFolder) then
				need_reset_lang_version = true
				warn("Failed to open: ", strPckFile)
			end
			local bExists = true
			if af.IsSepFileExist then
				bExists = af.IsSepFileExist(EntryPointConfig.AssetsPath.."/"..strPckFile)
			end
			if bExists and not af.OpenFilePackage(resourcePackageLayer, strPckFile, strFolder) then
				need_reset_local_version = true
				warn("Failed to open: ", strPckFile)
			end
			if not af.OpenFilePackage(resBasePackageLayer, strPckFile, strFolder) then
				warn("Failed to open backup pck: ", strPckFile)
			end

			--Android需要额外资源包目录
			if EntryPointConfig.ExtraPackageFolder and extraPackageLayer then
				local bExists = true
				if af.IsSepFileExist then
					bExists = af.IsSepFileExist(extraPackagePath .."/"..strPckFile)
				end
				if HasExtraPackage(strFolder) and bExists and not af.OpenFilePackage(extraPackageLayer, strPckFile, strFolder) then
					warn("Failed to open extra package: ", strPckFile)
				end
			end

			if need_reset_lang_version or need_reset_local_version then
				CloseAFileSystem()
				if need_reset_lang_version then
					Lang.ResetLocalVersion(currentLang)
				end
				if need_reset_local_version then
					resource_reset_local_version()
				end
				PopupMessageBoxWithStringTable("pack broken and reset", MBT_OK)
				GameUtil2.QuitGame()
				loop_endless()
			end
		end
	--end
end

local bHasInitAFilePacksConfigs
local function InitAFilePacksConfigs()
	if not _G.GIsEditor then
		local resourcePackageLayer = 1
		local resBasePackageLayer = 2

		--这里layer初始化是在AFileWrapper.cpp里面设置的，没有多语言layer
		local strFolder = "configs"
		local strPckFile = g_szPckDir.configs
		log("EntryPointConfig.AssetsPath", EntryPointConfig.AssetsPath)

		local bExists = true
        if af.IsSepFileExist then
            bExists = af.IsSepFileExist(EntryPointConfig.AssetsPath.."/"..strPckFile)
        end
		if bExists and not af.OpenFilePackage(resourcePackageLayer, strPckFile, strFolder) then
			warn("Failed to open: ", strPckFile)
		end
		if not af.OpenFilePackage(resBasePackageLayer, strPckFile, strFolder) then
			warn("Failed to open backup pck: ", strPckFile)
		end

		bHasInitAFilePacksConfigs = true
	end
end
--------------------------------------------------------------------------------------------------------------------------
local is_background_turn = false
local is_background_turn_exit = true
local is_update_text_turn = false
local is_update_text_turn_exit = true
local start_background_turn
local start_updatetext_turn
local function load_background()
	print("-----------------------load_background")

	local background_images = {}
	for _, v in ipairs(get_update_config().images) do
		local img = GameUtil.SyncLoad(v, "Texture2D")
		--print("__load_background:", v, img)
		table.insert(background_images, img)
		coro.yield()
	end

	if #background_images <= 0 then return end

	start_background_turn = function()
		print("-----------------------start_background_turn")
		coro.start(function ()
			local interval = get_update_config().interval
			local blendframe = get_update_config().blendframe

			show_panel("Bg", true)

			local Group_Bg = {}
			Group_Bg[1] = m_panel:GetWidgetFromName("Bg0")
			Group_Bg[2] = m_panel:GetWidgetFromName("Bg1")

			if Group_Bg[1] and Group_Bg[2] then
				Group_Bg[1]:SetActive(true)
				Group_Bg[2]:SetActive(false)

				local curridx = 1
				local contentidx = 1
				local img_num = #background_images

				if img_num == 1 then
					local image = rawget(background_images, contentidx)
					Group_Bg[1]:SetBrushFromTexture(image)
				else
					is_background_turn = true
					is_background_turn_exit = false

					local function random_idx(from, to, idx)
						if idx < from or idx > to or from >= to then
							return from
						end

						local newidx = math.random(from, to)
						while newidx == idx do
							newidx = math.random(from, to)
						end
						return newidx
					end

					while is_background_turn do
						do
							local startTime = GameUtil.GetMillisecondsFromEpoch()
							while GameUtil.GetMillisecondsFromEpoch() - startTime < interval do
								if is_background_turn then coro.yield() else break end
							end
							if not is_background_turn then break end
						end

						--switch between 1 and 2
						local nextidx = 3 - curridx

						local curr_Bg_Img = Group_Bg[curridx]
						local next_Bg_Img = Group_Bg[nextidx]

						curridx = nextidx

						contentidx = random_idx(1, img_num, contentidx)

						local image = rawget(background_images, contentidx)

						next_Bg_Img:SetBrushFromTexture(image)
						next_Bg_Img:SetActive(true)
						next_Bg_Img:SetOpacity(0)

						local opacity_delta = 1.0/blendframe
						local opacity = 1.0

						for i = 1, blendframe do
							if is_background_turn then coro.yield() else break end

							curr_Bg_Img:SetOpacity(opacity)
							next_Bg_Img:SetOpacity(1.0 - opacity)

							opacity = opacity - opacity_delta
						end

						if not is_background_turn then break end

						next_Bg_Img:SetOpacity(1.0)
						curr_Bg_Img:SetActive(false)
					end
				end
			end

			start_background_turn = nil
			background_images = nil
			
			is_background_turn_exit = true
			log("----------------background_turn exit---------------")
		end)
	end

	start_updatetext_turn = function()
		print("-----------------------updatetext_turn start")
		coro.start(function ()
			local update_text_interval = get_update_config().update_text_interval
			local update_text = get_update_config().update_text
			local blendframe = get_update_config().update_text_blendframe

			show_panel("UpdateTips", true)
			show_panel("Btn_Switch", true)
			play_animation("Refresh", nil, 0, 1)

			local Tip_Title = m_panel:GetWidgetFromName("Text_UpdateTipTitle")
			local Tip_Detail = m_panel:GetWidgetFromName("Text_UpdateTip")

			local changeTips = false
			local Btn_Switch = m_panel:GetWidgetFromName("Btn_Switch")
			Btn_Switch:setOnClickFunc(function()
				changeTips = true
			end)

			if Tip_Title and Tip_Detail then
				Tip_Title:SetActive(true)
				Tip_Detail:SetActive(true)

				local contentidx = 1
				local text_num = #update_text

				if text_num == 1 then
					local tip = rawget(update_text, text_num)
					Tip_Title:SetText(tip[1])
					Tip_Detail:SetText(tip[2])
				else
					is_update_text_turn = true
					is_update_text_turn_exit = false

					local function random_idx(from, to, idx)
						if idx < from or idx > to or from >= to then
							return from
						end

						local newidx = math.random(from, to)
						while newidx == idx do
							newidx = math.random(from, to)
						end
						return newidx
					end

					while is_update_text_turn do
						do
							local startTime = GameUtil.GetMillisecondsFromEpoch()
							while GameUtil.GetMillisecondsFromEpoch() - startTime < update_text_interval and not changeTips do
								if is_update_text_turn then coro.yield() else break end
							end
							if not is_update_text_turn then break end
						end

						changeTips = false

						local opacity_delta = 1.0/blendframe
						local opacity = 1.0

						for i = 1, blendframe do
							Tip_Title:SetOpacity(opacity)
							Tip_Detail:SetOpacity(opacity)
							opacity = opacity - opacity_delta
							if is_update_text_turn then coro.yield() else break end
						end

						contentidx = random_idx(1, text_num, contentidx)

						local tip = rawget(update_text, contentidx)
						Tip_Title:SetText(tip[1])
						Tip_Detail:SetText(tip[2])

						for i = 1, blendframe do
							Tip_Title:SetOpacity(opacity)
							Tip_Detail:SetOpacity(opacity)
							opacity = opacity + opacity_delta
							if is_update_text_turn then coro.yield() else break end
						end

						if not is_update_text_turn then break end

						Tip_Title:SetOpacity(1.0)
						Tip_Detail:SetOpacity(1.0)
					end
				end
			end

			start_updatetext_turn = nil

			show_panel("Btn_Switch", false)

			is_update_text_turn_exit = true
			log("----------------updatetext_turn exit---------------")
		end)
	end
end

local function update_stage_zdir()
	show_panel("TextGroup1", true)

	local localVersion = Patcher.getLocalVersion(EntryPointConfig.AssetsPath)
	if localVersion == -1 then
		localVersion = resBaseVersion
	end

	set_block_text("Txt_Local1", tostring(localVersion))
	set_block_text("Txt_Sever1", "")

	request_dir()

	load_dir_version()

	local newVersionFromDirInfo = GetVersionList()
	local serverVersion = Patcher.getServerVersion(EntryPointConfig.AssetsPath, newVersionFromDirInfo, Lang.GetAppBuildinLangXmlVersionTag())
	set_block_text("Txt_Local1", tostring(localVersion))
	set_block_text("Txt_Sever1", tostring(serverVersion))
	DaizongSDK.LogStepLogReport(DAIZONG_STEPCODE.UPDATE_CHECK_VERSION)
	GEMLogin.PostLoginStepEvent(GEMLogin.LoginStep.CHECK_UPDATE)

	if UniSDK then
		UniSDK.action("sendAppsFlyerEvent", {eventName="verify_version", eventValue=""})
	end
end

local is_init_tips_playing = false
local is_init_tips_finish = true
local function start_init_tips()
	local interval = get_update_config().init_text_interval
	local init_text = get_update_config().init_text
	local loading_shader_cache_text = _G.IsEvaluation() and get_update_config().loading_shader_cache_text_evaluation or get_update_config().loading_shader_cache_text

	if not init_text or #init_text == 0 then return end

	set_block_text("Text_Check", "")

	local Text_Detail = m_panel:GetWidgetFromName("Text_Detail")

	local function get_loadstatus()
		if _G.StartLoadShaderCacheWhenInit then
			--print("loadstatus", _G.StartLoadShaderCacheWhenInit, _G.StartInGameUpdate, _G.g_IsMiniApp)
			if _G.StartLoadShaderCacheWhenInit == 1 then
				return 1
			else
				return 0
			end
		else
			return nil
		end
	end

	coro.start(function ()
		is_init_tips_playing = true
		is_init_tips_finish = false

		local start_auto_progress = false
		local auto_progress_duration = 50*1000
		local auto_progress_start_time = 0
		local auto_progress_target = 0.95
		local auto_progress_cur_value = 0

		local curIndex = 1
		while is_init_tips_playing and (curIndex <= #init_text or not start_auto_progress) do
			--local startTime = GameUtil.GetMillisecondsFromEpoch()
			--while GameUtil.GetMillisecondsFromEpoch() - startTime < interval do
			--	if is_init_tips_playing then coro.yield() else break end
			--end
			if not is_init_tips_playing then break end

			if get_loadstatus() then
				if get_loadstatus() == 1 then
					if not start_auto_progress then
						start_auto_progress = true
						auto_progress_start_time = GameUtil.GetMillisecondsFromEpoch()
						auto_progress_cur_value = 0
					end
					auto_progress_cur_value = math.min((GameUtil.GetMillisecondsFromEpoch() - auto_progress_start_time) / auto_progress_duration * auto_progress_target, auto_progress_target)
					local str = string.format(loading_shader_cache_text, math.floor(auto_progress_cur_value*100))
					Text_Detail:SetText(str)
				else
					local str = string.format(loading_shader_cache_text, 100)
					Text_Detail:SetText(str)
				end
			else
				if curIndex <= #init_text then
					Text_Detail:SetText(init_text[curIndex])
					curIndex = curIndex + 1
				end
			end

			local startTime = GameUtil.GetMillisecondsFromEpoch()
			while GameUtil.GetMillisecondsFromEpoch() - startTime < interval do
				if is_init_tips_playing then coro.yield() else break end
			end
		end

		is_init_tips_playing = false
		is_init_tips_finish = true
	end)
end

local function clean_on_click()
	local Btn_OK = m_panel:FindChild("Btn_OK")
	local Btn_Yes = m_panel:FindChild("Btn_Yes")
	local Btn_No = m_panel:FindChild("Btn_No")
	local Btn_Okay = m_panel:FindChild("Btn_Okay")
	local Btn_Cancel = m_panel:FindChild("Btn_Cancel")
	local Btn_Yes2 = m_panel:FindChild("Btn_Yes2")
	local Btn_No2 = m_panel:FindChild("Btn_No2")
	local Btn_Switch = m_panel:GetWidgetFromName("Btn_Switch")

	Btn_OK:setOnClickFunc(nil)
	Btn_Yes:setOnClickFunc(nil)
	Btn_No:setOnClickFunc(nil)
	Btn_Okay:setOnClickFunc(nil)
	Btn_Cancel:setOnClickFunc(nil)
	Btn_Yes2:setOnClickFunc(nil)
	Btn_No2:setOnClickFunc(nil)
	Btn_Switch:setOnClickFunc(nil)
end

local function checkDeviceLimit()
	local ECDeviceLoginLimit = require "Configs.ECDeviceLoginLimit"
	local succ, desc = ECDeviceLoginLimit.CheckDevice()
	if not succ then
		GEMLogin.PostLoginStepEvent(GEMLogin.LoginStep.CHECK_DEVICE,false,2011,"check device limit failed")
		if desc and desc ~= "" then
			MessageBoxPop(desc, MBT_OK)
		end
	end
end

local function CheckInGameUpdateDataVersion()
	if _G.g_IsMiniApp then
		local iguDataVersion = InGameUpdate.GetDataVersion and InGameUpdate.GetDataVersion() or 0
		local iguLocalDataVersionPath = GameUtil.GetAssetsPath() .. "/ingameupdate_data_version.txt"	--ingameupdate 目录可能被整体删除，版本号文件需在外面
		local iguLocalDataVersionStr = read_from_file(iguLocalDataVersionPath)
		local iguLocalDataVersion = tonumber(iguLocalDataVersionStr) or 0
		if iguDataVersion > iguLocalDataVersion then
			print("InGameUpdate, local data version too old, will delete data, local version: ", iguLocalDataVersion, "new version: ", iguDataVersion)
			
			GameUtil.DeleteDirectoryRecursively(GameUtil.GetAssetsPath() .. "/ingameupdate")
			--资源更新与小包密切相关，需一同删除 (但多语言资源与小包无关，不需删除)
			os.remove(GameUtil.GetAssetsPath() .. "/patcher/config/game_ver.sw")

			write_to_file(iguLocalDataVersionPath, iguDataVersion)
		end
	end
end

--下载公共信息，不考虑结果是否成功还是失败
_G.Announcement_lang_mapping = {
	["zh-cn"] = "cn",
	["zh-hant"] = "tw",
	["ko"] = "kr",
}
local is_load_announcement_exit = true
local function load_announcement()
	--目前只给海外渠道使用了
	if not BranchUtil.IsOversea() then
		return
	end

	coro.start(function ()
		if not GetAnnouncementAddressPrefix() then
			print("no AnnouncementAddressPrefix")
			return
		end
		local lang = Lang.GetCustomLang()
		if not lang or lang == "" then
			lang = Lang.GetAppBuiltinLang()
		end

		print("AnnouncementAddressPrefix:", GetAnnouncementAddressPrefix(), "lang:", lang)
		local url = GetAnnouncementAddressPrefix()
		if not myendswith(url, "/") then
			url = url .. "/"
		end
		url = url .. "announcement"
		if lang ~= "" then
			url = url .. "_" .. (Announcement_lang_mapping[lang] or lang)
		end
		url = url .. ".html"
		is_load_announcement_exit = false

		local localfile = GameUtil.GetAssetsPath() .. "/UserData/announcementcache"
		if lang ~= "" then
			localfile = localfile .. "_" .. (Announcement_lang_mapping[lang] or lang)
		end
		localfile = localfile .. ".html"
		print("download announcement from", url, localfile)
		GameUtil.CreateDirectoryForFile(localfile)
		GameUtil.downLoadUrl(url, localfile, function(success, url, file, data)
			print("load announcement return", success)
			is_load_announcement_exit = true
		end)
	end)
end
--------------------------------------------------------------------------------------------------------------------------
local function dummyFunc() end	--luajit 出问题了，报 cannot resume dead coroutine。似乎随便改点就好了
local NeedPlayPVFlag = false
return {function()
	_G.IsUpdating = true
	DaizongSDK.LogStepLogReport(DAIZONG_STEPCODE.UPDATE_ENTER)

	if UniSDK then
		UniSDK.action("sendAppsFlyerEvent", {eventName="enter_update", eventValue=""})
	end


	GEMLogin.PostLoginStepEvent(GEMLogin.LoginStep.ENTER_UPDATE)
	print("==============================================================Update Start")
	GameUtil.SetConsoleVariable("Slate.Feathering", "2")
	local bSkipResourceUpdate = IsNoResourceUpdate()
	print("bSkipResourceUpdate = ", bSkipResourceUpdate)
	if not bSkipResourceUpdate and not bHasInitAFilePacksConfigs then
		InitAFilePacksConfigs()
		print("-------!!!!!! AFileSystemEnable true !!!!!!---------")
		GameUtil.AFileSystemEnable(true)
		load_background()
	end
	--走到这里的时候，肯定启动视频已经播放完了
	GameUtil2.SetScreenMovieSkippable(true)

	if NeedPlayPVFlag then
		--加载pv窗口
		PVMovie.Starup({Panel_Update})
		--播放PV
		PVMovie.StartPlayLoop(load_panel_update)
	else
		load_panel_update()
	end

	show_panel("UpdateTips", false)
	show_panel("MessageBox", false)
	show_panel("ChooseBox", false)
	if BranchUtil.IsOversea() then
		show_panel("Lab_Tips", false)	--海外隐藏国内的健康游戏公告等
	end

	---------------------------------------------------------------------
	load_stringtable()
	load_local_version()
	load_res_base_version()
	---------------------------------------------------------------------
	show_panel("UpdateBar", true)
	show_panel("TextGroup1", false)
	show_panel("TextGroup2", false)
	set_progress_percent(0)
	set_block_text("Text_Detail", "")
	local txt = "checking for update"
	set_block_text("Text_Check", stringtable[txt] or txt)

	-- 检查机型限制
	--checkDeviceLimit()	--没必要在更新前检查了

	--不进行资源更新得时候，也要拉取di信息
	update_stage_zdir()
	
	Version.Init(GetVersionList())
	
	CheckInGameUpdateDataVersion()

	if not bSkipResourceUpdate then
		--update_stage_zdir()
		---------------------------------------------------------------------
		programs_update()
		---------------------------------------------------------------------
		show_maintenance()
		---------------------------------------------------------------------
		start_background_turn()
		start_updatetext_turn()

		CloseAFileSystem()

		predownload_extra_package()

		local resDownloadTask, langDownloadTask
		if Lang.HasCustomLang() then
			resDownloadTask = Version.CalcResDownloadTask(PackPrefix, Packext)
			langDownloadTask = Version.CalcLangDownloadTask(PackPrefix, Packext)
		end
		Version.SetResourceDownloadTasks(resDownloadTask, langDownloadTask)

		Version.IncUpdatingResourceIndex()
		resource_update()

		Version.IncUpdatingResourceIndex()
		language_update()

		if ZLOfflineDownload then	--清空 ZLOfflineDownload 已下载文件记录，避免对后续游戏内下载造成影响
			ZLOfflineDownload.CancelOfflineDownload()
		end
		
		Version.SetResourceDownloadTasks()
		lastShowUpdateTipResourceIndex = nil
		---------------------------------------------------------------------
	else
		CloseAFileSystem()
	end

	Version.Reset()

    show_panel("UpdateTips", false)
	set_progress_percent(1)
	log("------------------OK------------------")

	if ZLUtil.addSkipBackupAttributeToPath then
		ZLUtil.addSkipBackupAttributeToPath(EntryPointConfig.AssetsPath,true)
	end

	_G.MemoryMarkBegin"InitAFilePacks"
	InitAFilePacks()
	_G.MemoryMarkEnd"InitAFilePacks"

	print("-------!!!!!! AFileSystemEnable true !!!!!!---------")
	GameUtil.AFileSystemEnable(true)
	_G.IsUpdating = nil
	if _G.ReloadModuleAfterUpdate then _G.ReloadModuleAfterUpdate() end

	--重新加载
	update_config = nil

	start_init_tips()

	load_announcement()

	print("==============================================================Update End")
end, 
function()
	is_background_turn = false
	is_update_text_turn = false
	is_init_tips_playing = false

	clean_on_click()

	while not is_background_turn_exit or not is_update_text_turn_exit or not is_init_tips_finish or not is_load_announcement_exit do
		coro.yield()
	end

	m_panel:RemoveFromParent()
	GameUtil.RemoveRef(m_panel)
	m_panel = nil
	update_config = nil
	GameUtil.SetConsoleVariable("Slate.Feathering", orgSlateFeathering)
	log("--------------m_panel:RemoveFromParent()-----------------")
	DaizongSDK.LogStepLogReport(DAIZONG_STEPCODE.UPDATE_FINISH)
	GEMLogin.PostLoginStepEvent(GEMLogin.LoginStep.FINISH_UPDATE)

	if UniSDK then
		UniSDK.action("sendAppsFlyerEvent", {eventName="end_update", eventValue=""})
	end
end,
function(show_predown_progress, package_index, package_count, package_progress, msg)

end,
function()--预先执行一些操作
	print("pre action while init language")
	local bSkipResourceUpdate = IsNoResourceUpdate()
	print("bSkipResourceUpdate = ", bSkipResourceUpdate)
	if not bSkipResourceUpdate then
		InitAFilePacksConfigs()
		print("-------!!!!!! AFileSystemEnable true !!!!!!---------")
		GameUtil.AFileSystemEnable(true)
		load_background()
	end

	load_panel_update_res()

	show_panel("UpdateTips", false)
	show_panel("MessageBox", false)
	show_panel("ChooseBox", false)
	if BranchUtil.IsOversea() then
		show_panel("Lab_Tips", false)	--海外隐藏国内的健康游戏公告等
	end

	show_panel("UpdateBar", false)
	show_panel("TextGroup1", false)
	show_panel("TextGroup2", false)
	set_progress_percent(0)
	set_block_text("Text_Detail", "")
	--local txt = "checking for update"
	set_block_text("Text_Check", "")--stringtable[txt] or txt)

	m_panel:SetMsgTable({})
	m_panel:AddToViewport(10)
	coro.yield()
end}
--------------------------------------------------------------------------------------------------------------------------