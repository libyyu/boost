--- EndUserLicenseAgreement.lua
--- Generate by IntelliJ IDEA
--- Create by lidengfeng
--- DateTime: 2021/12/13 19:44
--- end-user license agreement (EULA)
--- 注意：不要require更新阶段之后的模块
local BranchUtil = require "Utility.BranchUtil"

local log = print
local warn = warn or print

--local common = {
--	disappearing_panels = {},
--	panel_disappear_animation = {},
--	DEFAULT_ANIMATION_NAME = "Open",
--}
--
--function common.play_panel_appear_animation(panel, animationName)
--	animationName = animationName or common.DEFAULT_ANIMATION_NAME
--	panel:PlayAnimationByName(animationName, 0, 1, 0)
--	common.disappearing_panels[panel] = nil
--end
--
--function common.play_panel_disappear_animation(panel, animationName)
--	animationName = animationName or common.DEFAULT_ANIMATION_NAME
--	common.disappearing_panels[panel] = true
--	panel:PlayAnimationByName(animationName, 0, 1, 1)
--end
--
--function common.is_panel_disappearing(panel)
--	return common.disappearing_panels[panel] == true
--end
--
--function common.is_panel_disappear_finished(panel, animationName)
--	animationName = animationName or common.DEFAULT_ANIMATION_NAME
--	if not common.disappearing_panels[panel] then
--		return false
--	end
--
--	if common.panel_disappear_animation[panel] == nil then
--		common.panel_disappear_animation[panel] = panel:GetAnimationByName(animationName)
--	end
--	local disappear_animation = common.panel_disappear_animation[panel]
--	if disappear_animation and panel:IsAnimationPlaying(disappear_animation) then
--		return false
--	end
--
--	common.disappearing_panels[panel] = nil
--	common.panel_disappear_animation[panel] = nil
--	return true
--end
--
--function common.loop_endless()
--	while true do coro.yield() end
--end
-------------------------------------------------------------------------------------------
---
-------------------------------------------------------------------------------------------
local visiturl = {
	['contract'] = "https://game.qq.com/tencent_other_contract.shtml",
	--['privacy_guide'] = "https://game.qq.com/tencent_other_privacy.shtml",
	['privacy_guide'] = "https://rule.tencent.com/rule/preview/a51ad1b3-45ee-4ece-bde7-bd7c9a145972",	--无地理位置版
	['privacy_guide_children'] = "https://game.qq.com/tencent_other_children_privacy.shtml",
}

--检查用户许可协议，如果用户没有同意，需要弹出许可界面
local function check_end_user_license_agreement()
	local agreeFlagPath = GameUtil.GetAssetsPath() .. "/userdata/end_user_license_agreed.flag"

	local function save_end_user_license_agreed_flag()
		GameUtil.CreateDirectoryForFile(agreeFlagPath)
		local file = io.open(agreeFlagPath, "w")
		if file then
			file:close()
		end
	end

	local function need_check()
		--海外渠道不是tencent
		if BranchUtil.IsOversea() then
			return false
		end

		--已经使用MSDKPolicyActivity显示用户许可协议
		if GameUtil.GetPlatformName() == "Android" then
			return false
		end

		--local PolicyUtility = require "Utility.PolicyUtility"
		----协议是否变更了
		--if PolicyUtility and PolicyUtility:IsPolicyChanged() then
		--	log("policy has changed")
		--	if Patcher.FileExists(agreeFlagPath) then
		--		Patcher.UDeleteFile(agreeFlagPath)
		--	end
		--	return true
		--end

		--记录文件存在
		local file = io.open(agreeFlagPath, "r")
		if file then
			file:close()
			log("already agree end_user_license")
			return false
		end

		--返回true可以让pc上也能测试
		return true
	end

	if not need_check() then
		log("do not need check end_user_license")
		save_end_user_license_agreed_flag()
		return
	end

	local obj = GameUtil.SyncLoad("UI/UMG/Policy/Panel_ProtocolTips", "WidgetBlueprintGeneratedClass")
	if obj == nil then
		--兼容旧客户端
		return
	end

	local m_eula_panel
	local function end_ui()
		m_eula_panel:SetMsgTable(nil)
		m_eula_panel:RemoveFromParent()
		GameUtil.RemoveRef(m_eula_panel)
		m_eula_panel = nil
	end

	coro.yield()
	m_eula_panel = UserWidget.CreateWidget(obj)
	m_eula_panel:AddToViewport(20)
	coro.yield()

	--绑定按钮事件
	--local Btn_Agree = m_eula_panel:FindChild("Btn2")
	--local Btn_Refuse = m_eula_panel:FindChild("Btn1")
	local isRefused = false
	local isFinish = false
	local function onAgree()
		--if common.is_panel_disappearing(m_eula_panel) then
		--	return
		--end
		save_end_user_license_agreed_flag()
		--common.play_panel_disappear_animation(m_eula_panel)
		isFinish = true
	end

	local function onRefuse()
		--if common.is_panel_disappearing(m_eula_panel) then
		--	return
		--end
		warn("refuse end_user_license")
		isRefused = true
		--common.play_panel_disappear_animation(m_eula_panel)
		isFinish = true
	end

	local function onVisitURL(href)
		local tag = href:sub(5, -1)
		if visiturl[tag] then
			GameUtil.OpenURL(visiturl[tag])
		elseif tag then
			GameUtil.OpenURL(tag)
		end
	end

	m_eula_panel:SetMsgTable({
		OnClickHTML = function(_, href)
			print("onclick html", href)
			onVisitURL(href)
		end,
		onClick = function(id)
			if id == "Btn2" then
				onAgree()
			elseif id == "Btn1" then
				onRefuse()
			end
		end
	})

	while not isFinish do
		coro.yield()
	end

	end_ui()


	if isRefused then
		GameUtil2.QuitGame()
	end
end

return {
	check_end_user_license_agreement = check_end_user_license_agreement
}