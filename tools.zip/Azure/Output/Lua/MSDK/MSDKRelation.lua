-------------------------------------------------------------------------------------------
-- MSDK分享模块
-- 分享模块是 MSDK 的一个社交功能模块，主要功能包括：
--    1. 发送消息功能，消息类型包括好友邀请、文字、链接、图片、音乐、视频、小程序等。微信渠道下部分类型可以给指定好友发送。
--    2. 分享功能（微信朋友圈、微信游戏圈、QQ 空间、Facebook TimeLine、Twitter），分享类型包括文字、图片、链接、邀请、音乐、视频。
-- 支持的渠道有： WeChat QQ Facebook Twitter System Line SMS WhatsApp
--
-- MSDK好友模块
-- 好友模块是 MSDK 的一个社交功能模块，主要功能包括：
--    1. 查询个人信息
--    2. 添加 QQ 好友
--
-- MSDK群组模块
-- MSDK群组模块，只有国内版本支持该模块功能。 支持的渠道有： WeChat QQ
-- 主要功能包括：建群、加入现有群组、获取群状态、获取群关系、绑定群、解绑群、提醒会长绑群、获取会长的建群列表、发送群组消息。其中，QQ 渠道特有的功能有：绑定群、提醒会长绑群、获取会长的建群列表。
-------------------------------------------------------------------------------------------

local Lplus = require "Lplus"
---@type ECGame
local ECGame = Lplus.ForwardDeclare("ECGame")
---@class ECMSDK.MSDKRelation:System.Object
---@field protected m_MyInfo table
---@field public shareCallBack function
---@field public Commit fun():ECMSDK.MSDKRelation @notnull
---@field public Instance fun():ECMSDK.MSDKRelation
---@field public SendTextMessage fun(self:ECMSDK.MSDKRelation, title:string, desc:string, openid:string)
---@field public SendLinkMessage fun(self:ECMSDK.MSDKRelation, title:string, link:string, openid:string, desc:string)
---@field public SendImageMessageByChannel fun(self:ECMSDK.MSDKRelation, title:string, path:string, openid:string, channel:number)
---@field public ShareTextMessage fun(self:ECMSDK.MSDKRelation, title:string, desc:string)
---@field public ShareLinkMessage fun(self:ECMSDK.MSDKRelation, title:string, link:string, desc:string)
---@field public ShareImageMessageByChannel fun(self:ECMSDK.MSDKRelation, title:string, path:string, channel:number)
---@field public SendStructMessage fun(self:ECMSDK.MSDKRelation, channel:number, title:string, link:string, desc:string, img:string)
---@field public ShareStructMessage fun(self:ECMSDK.MSDKRelation, channel:number, title:string, link:string, desc:string, img:string)
---@field public SendReqInviteMessage fun(self:ECMSDK.MSDKRelation, channel:number)
---@field public ShareReqInviteMessage fun(self:ECMSDK.MSDKRelation, channel:number)
---@field public SendReqInviteMessageByArk fun(self:ECMSDK.MSDKRelation, channel:number)
---@field public SendReqMiniAppMessage fun(self:ECMSDK.MSDKRelation, link_url:string, title:string, desc:string, app_path:string, app_id:string, ext:table)
---@field public CanSendMessage fun(self:ECMSDK.MSDKRelation, channel:number):boolean
---@field public CanShareMessage fun(self:ECMSDK.MSDKRelation, channel:number):boolean
---@field public OnDeliverMessageNotify fun(self:ECMSDK.MSDKRelation, retCode:number, retMsg:string, methodNameID:number, thirdCode:number, thirdMsg:string)
---@field public QueryMyInfo fun(self:ECMSDK.MSDKRelation)
---@field public AddGameFriendToQQ fun(self:ECMSDK.MSDKRelation, openId:string, desc:string, title:string)
---@field public AddFriend fun(self:ECMSDK.MSDKRelation, openId:string, desc:string, title:string)
---@field public CreateGroup fun(self:ECMSDK.MSDKRelation, unionID:string, unionName:string, roleName:string, zoneID:string, roleID:string, extraJson:string)
---@field public JoinGroup fun(self:ECMSDK.MSDKRelation, unionID:string, zoneID:string, roleID:string, groupID:string, extraJson:string)
---@field public GetGroupState fun(self:ECMSDK.MSDKRelation, unionID:string, zoneID:string, extraJson:string)
---@field public GetGroupRelation fun(self:ECMSDK.MSDKRelation, targetID:string, extraJson:string)
---@field public UnbindGroup fun(self:ECMSDK.MSDKRelation, unionID:string, unionName:string, zoneID:string, roleID:string, extraJson:string)
---@field public RemindToBindGroup fun(self:ECMSDK.MSDKRelation, unionID:string, zoneID:string, roleID:string, roleName:string, leaderOpenID:string, leaderRoleID:string, extraJson:string)
---@field public BindGroup fun(self:ECMSDK.MSDKRelation, unionID:string, zoneID:string, roleID:string, groupID:string, groupName:string, extraJson:string)
---@field public GetGroupList fun(self:ECMSDK.MSDKRelation)
---@field public SendGroupMessage fun(self:ECMSDK.MSDKRelation, ID:string, type:string, actionReport:string, title:string, desc:string, link:string, extraJson:string)
---@field public OnRelationNotify fun(self:ECMSDK.MSDKRelation, relationRet:table)
---@field public OnShare fun(self:ECMSDK.MSDKRelation, platform:number, flag:number, desc:string, extInfo:string)
---@field public OnLoadGroupData fun(self:ECMSDK.MSDKRelation, groupRet:table)
---@field public IsNotificationOpened fun(self:ECMSDK.MSDKRelation):boolean
---@field public Clear fun(self:ECMSDK.MSDKRelation)
local MSDKRelation = Lplus.Class("ECMSDK.MSDKRelation")
local MSDKInfo = require("MSDK.MSDKInfo")
local MSDKUtil = require("MSDK.MSDKUtil")
local Json = require "Utility.json"

local def = MSDKRelation.define

local PCallMSDKFunction = function(FunctionName, ...)
	if MSDK and MSDK[FunctionName] then
		return MSDK[FunctionName](...)
	else
		warn(("There is no function = %s in MSDK"):format(FunctionName))
		return nil
	end
end

---@type table
def.field("table").m_MyInfo = nil

local instance = nil
---@return ECMSDK.MSDKRelation
def.static("=>", MSDKRelation).Instance = function()
  if not instance then
       instance = MSDKRelation()
       instance.m_MyInfo = {}
  end
  return instance
end

-------------------------------------------------------------------------------------
-- 分享相关
-------------------------------------------------------------------------------------

-- 发送文本消息给好友，支持微信，Line
-- param: title  标题
-- param: desc   概述，简单描述分享内容
-- param: openid 填好友的openId, 不填会拉起好友列表，让你选择去分享
---@param self ECMSDK.MSDKRelation
---@param title string
---@param desc string
---@param openid string
---@return void
def.method("string", "string", "string").SendTextMessage = function(self, title, desc, openid)
	local bCheckInstall = false
	if _G.LoginPlatform == MSDK_LOGIN_PLATFORM.LINE then
		--line 分享文本和图片均需要安装app
		bCheckInstall = true
	end

	if bCheckInstall and not MSDKUtil.Instance():IsAppInstalled(_G.LoginPlatform) then
		warn("安装应用后才可以分享")
		-- FlashTipMan.FlashTip("安装应用后才可以分享")
		self.shareCallBack = nil
		return
	end

	local reqType = MSDKInfo.ShareReqType.kMSDKFriendReqTypeText
	local thumbPath = MSDKInfo.URLs.Logo -- TODO: 需要设定: 缩略图(logo)
	--参数: type, title, desc, userid, imagePath, thumbPath, mediaPath, link, extraJson, channel
	PCallMSDKFunction("sendMessage", reqType, title, desc, openid, "", thumbPath, "", "", "", "")
end

-- 发送链接消息给好友，支持微信，QQ
-- param: title  标题
-- param: link   分享链接，可以是图片链接、音乐链接、视频链接或者跳转链接等等
-- param: openid 填好友的openId, 不填会拉起好友列表，让你选择去分享
---@param self ECMSDK.MSDKRelation
---@param title string
---@param link string
---@param openid string
---@param desc string
---@return void
def.method("string", "string", "string","string").SendLinkMessage = function(self, title, link, openid, desc)
	local bCheckInstall = false
	if _G.LoginPlatform == MSDK_LOGIN_PLATFORM.LINE then
		--line 分享文本和图片均需要安装app
		bCheckInstall = true
	end

	if bCheckInstall and not MSDKUtil.Instance():IsAppInstalled(_G.LoginPlatform) then
		warn("安装应用后才可以分享")
		-- FlashTipMan.FlashTip("安装应用后才可以分享")
		self.shareCallBack = nil
		return
	end

	local reqType = MSDKInfo.ShareReqType.kMSDKFriendReqTypeLink
	local thumbPath = MSDKInfo.URLs.Logo
	--参数: type, title, desc, userid, imagePath, thumbPath, mediaPath, link, extraJson, channel
	PCallMSDKFunction("sendMessage", reqType, title, desc, openid, "", thumbPath, "", link, "", "")
end

-- 分享图片给好友(指定渠道)，支持微信，QQ，Line
-- param: title   标题
-- param: path    图片路径(可以是本地地址或者是URL，建议使用本地地址)
-- param: openid 填好友的openId, 不填会拉起好友列表，让你选择去分享
-- param: channel 分享的渠道: WeChat、QQ、Line等
---@param self ECMSDK.MSDKRelation
---@param title string
---@param path string
---@param openid string
---@param channel number
---@return void
def.method("string", "string", "string", "number").SendImageMessageByChannel = function(self, title, path, openid, channel)
	local bCheckInstall = false
	if channel == MSDK_LOGIN_PLATFORM.LINE then
		--line 分享文本和图片均需要安装app
		bCheckInstall = true
	end

	if bCheckInstall and not MSDKUtil.Instance():IsAppInstalled(channel) then
		warn("安装应用后才可以分享")
		-- FlashTipMan.FlashTip("安装应用后才可以分享")
		self.shareCallBack = nil
		return
	end

	local reqType = MSDKInfo.ShareReqType.kMSDKFriendReqTypeIMG
	local thumbPath = MSDKInfo.URLs.Logo
	local platformName = _G.MSDK_LOGIN_PLATFORM_NAME[channel] or ""

	--参数: type, title, desc, userid, imagePath, thumbPath, mediaPath, link, extraJson, channel
	PCallMSDKFunction("sendMessage", reqType, title, "", openid, path, thumbPath, "", "", "", platformName)
end

-- 发送消息到信息墙，比如微信朋友圈、QQ空间、Facebook
-- param: title  标题
-- param: desc   描述
---@param self ECMSDK.MSDKRelation
---@param title string
---@param desc string
---@return void
def.method("string", "string").ShareTextMessage = function(self, title, desc)
	local reqType = MSDKInfo.ShareReqType.kMSDKFriendReqTypeText
	local thumbPath = MSDKInfo.URLs.Logo
	--参数: type, title, desc, userid, imagePath, thumbPath, mediaPath, link, extraJson, channel
	PCallMSDKFunction("shareMessage", reqType, title, desc, "", "", thumbPath, "", "", "", "")
end

-- 发送链接到信息墙，比如微信朋友圈、QQ空间、Facebook
-- param: title  标题
-- param: link   分享链接，可以是图片链接、音乐链接、视频链接或者跳转链接等等
---@param self ECMSDK.MSDKRelation
---@param title string
---@param link string
---@param desc string
---@return void
def.method("string", "string","string").ShareLinkMessage = function(self, title, link, desc)
	local reqType = MSDKInfo.ShareReqType.kMSDKFriendReqTypeLink
	local thumbPath = MSDKInfo.URLs.Logo
	--参数: type, title, desc, userid, imagePath, thumbPath, mediaPath, link, extraJson, channel
	PCallMSDKFunction("shareMessage", reqType, title, desc, "", "", thumbPath, "", link, "", "")
end

-- 发送图片到信息墙，比如微信朋友圈、QQ空间、Facebook
-- param: title   标题
-- param: path    图片路径(可以是本地地址或者是URL，建议使用本地地址)
-- param: channel 分享的渠道: WeChat、QQ、Line等
---@param self ECMSDK.MSDKRelation
---@param title string
---@param path string
---@param channel number
---@return void
def.method("string", "string", "number").ShareImageMessageByChannel = function(self, title, path, channel)
	local bCheckInstall = false
	if channel == MSDK_LOGIN_PLATFORM.TWITTER and _G.platformName == "android" then
		-- android下twitter分享图片必须安装app
		bCheckInstall = true
	end

	if bCheckInstall and not MSDKUtil.Instance():IsAppInstalled(channel) then
		warn("安装应用后才可以分享")
		-- FlashTipMan.FlashTip("安装应用后才可以分享")
		self.shareCallBack = nil
		return
	end

	local reqType = MSDKInfo.ShareReqType.kMSDKFriendReqTypeIMG
	local thumbPath = MSDKInfo.URLs.Logo
	local platformName = _G.MSDK_LOGIN_PLATFORM_NAME[channel] or ""
	--参数: type, title, desc, userid, imagePath, thumbPath, mediaPath, link, extraJson, channel
	PCallMSDKFunction("shareMessage", reqType, title, "", "", path, thumbPath, "", "", "", platformName)
end


-- 结构化分享，会话
---@param self ECMSDK.MSDKRelation
---@param channel number
---@param title string
---@param link string
---@param desc string
---@param img string
---@return void
def.method("number", "string", "string","string","string").SendStructMessage = function(self,channel,title, link, desc,img)
	if not self:CanSendMessage(channel) then
		return
	end
	local reqType = MSDKInfo.ShareReqType.kMSDKFriendReqTypeInvite
	local platformName = _G.MSDK_LOGIN_PLATFORM_NAME[channel] or ""
	local thumbPath = MSDKInfo.URLs.Logo
	local extra = {}
	extra.game_data = "游戏自定义透传数据"
	local extraJson = Json.encode(extra)
	--参数: type, title, desc, userid, imagePath, thumbPath, mediaPath, link, extraJson, channel
	PCallMSDKFunction("sendMessage", reqType, title, desc, "", img, thumbPath, "", link, extraJson, platformName)
end
-- 结构化分享，空间
---@param self ECMSDK.MSDKRelation
---@param channel number
---@param title string
---@param link string
---@param desc string
---@param img string
---@return void
def.method("number", "string", "string","string","string").ShareStructMessage = function(self,channel,title, link, desc,img)
	if not self:CanSendMessage(channel) then
		return
	end
	local reqType = MSDKInfo.ShareReqType.kMSDKFriendReqTypeInvite
	local platformName = _G.MSDK_LOGIN_PLATFORM_NAME[channel] or ""
	local thumbPath = MSDKInfo.URLs.Logo
	local extra = {}
	extra.game_data = "游戏自定义透传数据"
	local extraJson = Json.encode(extra)
	--参数: type, title, desc, userid, imagePath, thumbPath, mediaPath, link, extraJson, channel
	PCallMSDKFunction("shareMessage", reqType, title, desc, "", img, thumbPath, "", link, extraJson, platformName)
end

-- 向好友发送邀请
---@param self ECMSDK.MSDKRelation
---@param channel number
---@return void
def.method("number").SendReqInviteMessage = function(self,channel)
	if not self:CanSendMessage(channel) then
		return
	end
	local reqType = MSDKInfo.ShareReqType.kMSDKFriendReqTypeInvite
	local platformName = _G.MSDK_LOGIN_PLATFORM_NAME[channel] or ""
	local link_url = ""
	if channel == MSDK_LOGIN_PLATFORM.QQ then
		link_url = "https://speed.gamecenter.qq.com/pushgame/v1/detail?appid=1110048757&_wv=2164260896&_wwv=448&autodownload=1&autolaunch=1&autosubscribe=1"
		--link_url = "https://speed.gamecenter.qq.com/pushgame/v1/detail?appid=1110048757&_wv=2164260896&_wwv=448"
	elseif channel == MSDK_LOGIN_PLATFORM.WX then
		link_url = "https://game.weixin.qq.com/cgi-bin/comm/openlink?auth_appid=wx62d9035fd4fd2059&url=https%3A%2F%2Fgame.weixin.qq.com%2Fcgi-bin%2Fh5%2Fstatic%2Fcirclecenter%2Fmixed_circle.html%3Ftabid%3D7%26appid%3Dwxf902c98a6f6dc266%26ssid%3D46%23wechat_redirect#wechat_redirect"
	end
	local title = StringTable.Get(80404)
	local thumbPath = MSDKInfo.URLs.Logo
	local extra = {}
	extra.game_data = "游戏自定义透传数据"
	local extraJson = Json.encode(extra)
	--参数: type, title, desc, userid, imagePath, thumbPath, mediaPath, link, extraJson, channel
	PCallMSDKFunction("sendMessage", reqType, title, "", "", thumbPath, thumbPath, "", link_url, extraJson, platformName)
end

-- 朋友圈展示邀请
---@param self ECMSDK.MSDKRelation
---@param channel number
---@return void
def.method("number").ShareReqInviteMessage = function(self,channel)
	if not self:CanShareMessage(channel) then
		return
	end
	local reqType = MSDKInfo.ShareReqType.kMSDKFriendReqTypeInvite
	local platformName = _G.MSDK_LOGIN_PLATFORM_NAME[channel] or ""
	local link_url = ""
	if channel == MSDK_LOGIN_PLATFORM.QQ then
		link_url = "https://nyzx.qq.com/act/2803/a20200430yu/pc/index.html?_sharetype=1&_shareid=12345&_appid=1110048757&_other=1"
	elseif channel == MSDK_LOGIN_PLATFORM.WX then
		--link_url = "https://game.weixin.qq.com/cgi-bin/comm/openlink?auth_appid=wx62d9035fd4fd2059&url=https%3A%2F%2Fgame.weixin.qq.com%2Fcgi-bin%2Fh5%2Fstatic%2Fcirclecenter%2Fmixed_circle.html%3Ftabid%3D7%26appid%3Dwxf902c98a6f6dc266%26ssid%3D46%23wechat_redirect#wechat_redirect"
		FlashTipMan.FlashTip(StringTable.Get(80501))
		return
	end
	local title = StringTable.Get(80404)
	local thumbPath = "https://game.gtimg.cn/images/ulink/act/2803/a20200430yu/pc/p5_img3.jpg"
	--参数: type, title, desc, userid, imagePath, thumbPath, mediaPath, link, extraJson, channel
	PCallMSDKFunction("shareMessage", reqType, title, "", "", "", thumbPath, "", link_url, "", platformName)
end

-- ARK前端分享
---@param self ECMSDK.MSDKRelation
---@param channel number
---@return void
def.method("number").SendReqInviteMessageByArk = function(self,channel)
	if not self:CanSendMessage(channel) then
		return
	end
	local reqType = MSDKInfo.ShareReqType.kMSDKFriendReqTypeArk
	local platformName = _G.MSDK_LOGIN_PLATFORM_NAME[channel] or ""
	local link_url = ""
	if channel == MSDK_LOGIN_PLATFORM.QQ then
		link_url = "http://gamecenter.qq.com/gcjump?appid=100703379&pf=invite&from=iphoneqq&plat=qq&originuin=111&ADTAG=gameobj.msg_invite"
		--link_url = "https://speed.gamecenter.qq.com/pushgame/v1/detail?appid=1110048757&_wv=2164260896&_wwv=448"
	elseif channel == MSDK_LOGIN_PLATFORM.WX then
		return
	end
	local title = StringTable.Get(80404)
	local thumbPath = "https://game.gtimg.cn/images/ulink/act/2803/a20200430yu/pc/p5_img3.jpg"
	local extra = {}
	--extra.game_data = "游戏自定义透传数据"
	extra.app = "com.tencent.gamecenter.qqsy"
	extra.view = "picView2"
	extra.desc = "游戏分享"
	extra.ver = "1.0.0.1"
	extra.config = {}
	extra.config.forward = 0
	extra.config.type = "normal"
	extra.meta = {}
	extra.meta.shareData = {}
	extra.meta.shareData.appid = "1110048757"
	extra.meta.shareData.openId = ""
	extra.meta.shareData.scene = "920"
	extra.meta.shareData.url = ""
	extra.meta.shareData.extData = {}
	local extraJson = Json.encode(extra)
	--参数: type, title, desc, userid, imagePath, thumbPath, mediaPath, link, extraJson, channel
	PCallMSDKFunction("sendMessage", reqType, title, "", "", thumbPath, thumbPath, "", link_url, extraJson, platformName)
end

-- 小程序分享（仅支持微信）
-- link_url 不支持小程序时打开的分享链接
-- title 	分享标题
-- desc		分享文本
-- app_path	分享小程序地址
-- app_id	分享小程序id
-- ext 		扩展信息，可在回调中获取
---@param self ECMSDK.MSDKRelation
---@param link_url string
---@param title string
---@param desc string
---@param app_path string
---@param app_id string
---@param ext table
---@return void
def.method("string","string","string","string","string","table").SendReqMiniAppMessage = function(self,link_url,title,desc,app_path,app_id,ext)
	if _G.LoginPlatform ~= MSDK_LOGIN_PLATFORM.WX then
		return
	end
	if not self:CanSendMessage(_G.LoginPlatform) then
		return
	end

	local reqType = MSDKInfo.ShareReqType.kMSDKFriendReqTypeMiniApp
	local platformName = _G.MSDK_LOGIN_PLATFORM_NAME[_G.LoginPlatform] or ""

	local thumbPath = MSDKInfo.URLs.Logo
	local extra = {}
	extra.media_tag_name = ""
	extra.message_ext = Json.encode(ext)
	extra.weapp_id = app_id
	extra.mini_program_type = "0"
	local extraJson = Json.encode(extra)
	--参数: type, title, desc, userid, imagePath, thumbPath, mediaPath, link, extraJson, channel
	PCallMSDKFunction("sendMessage", reqType, title, desc, "", thumbPath, thumbPath, app_path, link_url, extraJson, platformName)
end

-- 是否能够分享至QQ/微信好友
-- 目前仅判断是否安装应用
-- 仅QQ/微信两个平台
---@param self ECMSDK.MSDKRelation
---@param channel number
---@return boolean
def.method("number", "=>","boolean").CanSendMessage = function(self,channel)
	if channel == MSDK_LOGIN_PLATFORM.WX or channel == MSDK_LOGIN_PLATFORM.QQ then
		if MSDKUtil.Instance():IsAppInstalled(channel) then
			return true
		else
			if _G.platform == PLATFORM_TYPE_IOS then
				FlashTipMan.FlashTip(StringTable.Get(80405))
			else
				FlashTipMan.FlashTip(StringTable.Get(80402))
			end
		end
	end
	return false
end

-- 是否能够分享至QQ空间/朋友圈
-- 目前仅判断是否安装应用
-- 仅QQ/微信两个平台
---@param self ECMSDK.MSDKRelation
---@param channel number
---@return boolean
def.method("number","=>","boolean").CanShareMessage = function(self,channel)
	if channel == MSDK_LOGIN_PLATFORM.WX or channel == MSDK_LOGIN_PLATFORM.QQ then
		if MSDKUtil.Instance():IsAppInstalled(channel) then
			return true
		else
			if _G.platform == PLATFORM_TYPE_IOS then
				FlashTipMan.FlashTip(StringTable.Get(80405))
			else
				FlashTipMan.FlashTip(StringTable.Get(80402))
			end
		end
	end
	return false
end

-- 分享回调
-- param: retCode        MSDK 返回码，详情可参考 MSDKError.h
-- param: retMsg         MSDK 描述信息
-- param: methodNameID   标记是从哪个方法过来
-- param: thirdCode      第三方渠道返回码
-- param: thirdMsg       第三方渠道描述信息
---@param self ECMSDK.MSDKRelation
---@param retCode number
---@param retMsg string
---@param methodNameID number
---@param thirdCode number
---@param thirdMsg string
---@return void
def.method("number", "string", "number", "number", "string").OnDeliverMessageNotify = function(self, retCode, retMsg, methodNameID, thirdCode, thirdMsg)
	print(string.format("OnDeliverMessageNotify retCode=%d, retMsg=%s", retCode, retMsg))
	-- ECGame.EventManager:raiseEvent(nil, MSDKEvent.MSDKDeliverMessageEvent.new(retCode, retMsg, methodNameID, thirdCode, thirdMsg))
	self:OnShare(_G.LoginPlatform, retCode, retMsg, "") 
end

-------------------------------------------------------------------------------------
-- 好友模块相关
-------------------------------------------------------------------------------------

-- 在游戏中，获取用户当前登录渠道的账号信息，包括第三方的账号信息
---@param self ECMSDK.MSDKRelation
---@return void
def.method().QueryMyInfo = function(self)
	PCallMSDKFunction("queryUserInfo")
end

-- 玩家可以在游戏中直接添加（拉起手Q）游戏玩家为QQ好友（多次点击不会发送多条添加QQ申请）。目前只有QQ支持该功能。
-- param openid: 用户 好友的openid
-- param desc: 概述，简单描述内容
-- param title: 标题
---@param self ECMSDK.MSDKRelation
---@param openId string
---@param desc string
---@param title string
---@return void
def.method("string", "string", "string").AddGameFriendToQQ = function(self, openId, desc, title)
	if _G.LoginPlatform == MSDK_LOGIN_PLATFORM.QQ then
		if not MSDKUtil.Instance():IsAppInstalled(_G.MSDK_LOGIN_PLATFORM.QQ) then --未安装QQ
			-- FlashTipMan.FlashTip("未检测到可分享平台")
			return
		end
		PCallMSDKFunction("addGameFriendToQQ", openId, desc, title)
	end
end

-- 玩家可以在游戏中直接添加（拉起手Q）游戏玩家为QQ好友（多次点击不会发送多条添加QQ申请）。目前只有QQ支持该功能。 (此接口是为了和msdk保持一致)
-- param openid: 用户 好友的openid
-- param desc: 概述，简单描述内容
-- param title: 标题
---@param self ECMSDK.MSDKRelation
---@param openId string
---@param desc string
---@param title string
---@return void
def.method("string", "string", "string").AddFriend = function(self, openId, desc, title)
	self:AddGameFriendToQQ(openId, desc, title)
end

-- def.method("=>", "table").GetMyInfo = function(self)
--   return self.m_MyInfo
-- end

-------------------------------------------------------------------------------------
-- 群组模块
-------------------------------------------------------------------------------------

-- 创建群
-- 功能描述
--  ① 微信端，工会会长创建微信群；
--  ② 手Q端，工会会长创建手Q群。测试环境手Q需传 areaID
-- 返回信息及结果：
-- createGroup 的 retCode 为 0 表示创建群成功，在移动设备的手Q/微信，可以看到新建的群组信息。

-- param unionID 工会ID
-- param unionName 工会名称
-- param roleName 游戏中的角色名称
-- param zoneID 游戏区服ID
-- param roleID 游戏角色ID
-- param extraJson 扩展字段，默认为空。严格区分大小写，格式参考：{"areaID":"1","partitionID":"1"}
---@param self ECMSDK.MSDKRelation
---@param unionID string
---@param unionName string
---@param roleName string
---@param zoneID string
---@param roleID string
---@param extraJson string
---@return void
def.method("string", "string", "string", "string", "string", "string").CreateGroup = function(self, unionID, unionName, roleName, zoneID, roleID, extraJson)
	PCallMSDKFunction("createGroup", unionID, unionName, roleName, zoneID, roleID, extraJson)
end

-- 加入群
-- 功能描述
-- 工会成员加入已存在的群。
--    ① 微信端：加入微信群，MSDK V5.8及之前的版本只需要填写 unionID, MSDK V5.9 及以后版本支持加入工会群时通过扩展字段 nickName 设置昵称
--    ② 手Q端：加入QQ群，手Q因为可以加入多个群组，需要额外填写 groupID（手Q群号），及 zoneID，roleID，nickName，测试环境手Q需传入 areaID（用户需保留创建群的信息）
-- 返回信息及结果：
--    joinGroup 的 retCode 为 0 表示添加成功，手Q端/微信端可见显示已成功进入相应群组。
-- param unionID 工会ID
-- param zoneID 游戏区服ID
-- param roleID 游戏角色ID
-- param groupID 手Q群ID
-- param extraJson 扩展字段，默认为空。严格区分大小写，格式参考：{"areaID":"1","partitionID":"1","nickName":"test"}
---@param self ECMSDK.MSDKRelation
---@param unionID string
---@param zoneID string
---@param roleID string
---@param groupID string
---@param extraJson string
---@return void
def.method("string", "string", "string", "string", "string").JoinGroup = function(self, unionID, zoneID, roleID, groupID, extraJson)
	PCallMSDKFunction("joinGroup", unionID, zoneID, roleID, groupID, extraJson)
end

-- 获取群状态
-- 功能描述
-- 查看工会绑群的状态。
--     ① 微信端：只需要输入查询的工会信息 unionID
--     ② 手Q端：需要 unionID 和 zoneID，查询工会绑群状态信息 返回信息及结果，可以获取 group_openid 用于发送群消息：
-- 返回码中，0 表示未绑定群组，1 表示工会已绑定群组 *
-- param unionID 工会ID
-- param zoneID 游戏区服ID
-- param extraJson 扩展字段，默认为空。严格区分大小写，格式参考：{"areaID":"1","partitionID":"1"}
---@param self ECMSDK.MSDKRelation
---@param unionID string
---@param zoneID string
---@param extraJson string
---@return void
def.method("string", "string", "string").GetGroupState = function(self, unionID, zoneID, extraJson)
	PCallMSDKFunction("getGroupState", unionID, zoneID, extraJson)
end

-- 获取群关系
-- 功能描述
-- 查看用户在指定群组中的身份关系。
--     ① 微信端：输入查询的工会信息 unionID
--     ② 手Q端：输入指定的 groupID
-- 返回信息及结果如下：
--      微信 3：群成员； 4：非群成员； -1：查询失败
--      QQ	1：群主； 2：管理员；3：普通成员；4：非成员；-1：查询错误
-- param targetID 微信时填写工会 unionID，手Q时填写群号 groupID
-- param extraJson 扩展字段，默认为空。严格区分大小写，格式参考：{"areaID":"1","partitionID":"1"}
---@param self ECMSDK.MSDKRelation
---@param targetID string
---@param extraJson string
---@return void
def.method("string", "string").GetGroupRelation = function(self, targetID, extraJson)
	PCallMSDKFunction("getGroupRelation", targetID, extraJson)
end

-- 解绑群
-- 功能描述
-- 解除绑定所在的群组。
--     ① 微信端：只需要输入 unionID
--     ② 手Q端：依次输入之前记录的 unionID，unionName 及 zoneID，roleID
-- 返回信息及结果：
--     返回解绑成功信息返回码，通过查询 getGroupState，如果返回用户所在工会未绑定群组，则可验证用户解绑群组成功。
-- param unionID 工会ID
-- param unionName 工会名称
-- param zoneID 游戏区服ID
-- param roleID 游戏角色ID
-- param extraJson 扩展字段，默认为空。严格区分大小写，格式参考：{"areaID":"1","partitionID":"1"}
---@param self ECMSDK.MSDKRelation
---@param unionID string
---@param unionName string
---@param zoneID string
---@param roleID string
---@param extraJson string
---@return void
def.method("string", "string", "string", "string", "string").UnbindGroup = function(self, unionID, unionName, zoneID, roleID, extraJson)
	PCallMSDKFunction("unbindGroup", unionID, unionName, zoneID, roleID, extraJson)
end

-- 提醒会长绑群（仅支持QQ渠道）
-- 功能描述
-- 手Q端提醒会长绑群。
-- 会长关注“QQ手游”服务号，返回功能执行成功后，会长会在服务号中收到消息。
-- param unionID 工会ID
-- param zoneID 游戏区服ID
-- param roleID 游戏角色ID
-- param roleName 游戏中的角色名称
-- param leaderOpenID 会长openID
-- param leaderRoleID 会长角色ID
-- param extraJson 扩展字段，默认为空。严格区分大小写，格式参考：{"areaID":"1","partitionID":"1"}
---@param self ECMSDK.MSDKRelation
---@param unionID string
---@param zoneID string
---@param roleID string
---@param roleName string
---@param leaderOpenID string
---@param leaderRoleID string
---@param extraJson string
---@return void
def.method("string", "string", "string", "string", "string", "string", "string").RemindToBindGroup = function(self, unionID, zoneID, roleID, roleName, leaderOpenID, leaderRoleID, extraJson)
	PCallMSDKFunction("remindToBindGroup", unionID, zoneID, roleID, roleName, leaderOpenID, leaderRoleID, extraJson)
end

-- 绑定群（仅支持QQ渠道）
-- 功能描述
-- 手Q端，会长绑定已存在的 QQ 群组。测试环境需传 areaID
-- 返回信息及结果：
--     返回绑定成功的返回值信息，通过调用 getGroupState，可见已绑定到群组，实现验证。
-- param unionID 工会ID
-- param zoneID 游戏区服ID
-- param roleID 游戏角色ID
-- param groupID 手Q群号，创建群时获得
-- param groupName 手Q群名，创建群时获得
-- param extraJson 扩展字段，默认为空。严格区分大小写，格式参考：{"areaID":"1","partitionID":"1"}
---@param self ECMSDK.MSDKRelation
---@param unionID string
---@param zoneID string
---@param roleID string
---@param groupID string
---@param groupName string
---@param extraJson string
---@return void
def.method("string", "string", "string", "string", "string", "string").BindGroup = function(self, unionID, zoneID, roleID, groupID, groupName, extraJson)
	PCallMSDKFunction("bindGroup", unionID, zoneID, roleID, groupID, groupName, extraJson)
end

-- 获取会长的建群列表（QQ渠道独有）
-- 功能描述
-- 手Q端，查看会长已经拥有的群组列表。
-- 返回信息：
--     返回值中的 GroupInfo 记录会长拥有的群组列表，其中每一群组记录包含群组的 groupID 和 groupName
---@param self ECMSDK.MSDKRelation
---@return void
def.method().GetGroupList = function(self)
	PCallMSDKFunction("getGroupList")
end

-- 发送群组消息
-- 功能描述
-- 微信/QQ端，发送消息到群聊。发送信息成功，微信/QQ端可见消息记录。
-- param ID 微信平台：工会ID; QQ平台：分享指定群的group_openid
-- param type 【必填】消息类型，1：应用邀请 2：link链接分享
-- param actionReport 【必填】分享类型，邀请1，炫耀2，赠送3，索要4
-- param title 【必填】，标题
-- param desc 【必填】，概述，消息的介绍
-- param link 【选填】，链接地址，type等于1时不需要带；type等于2时必须要带
-- param extraJson 【选填】，扩展字段，默认为空
---@param self ECMSDK.MSDKRelation
---@param ID string
---@param type string
---@param actionReport string
---@param title string
---@param desc string
---@param link string
---@param extraJson string
---@return void
def.method("string", "string", "string", "string", "string", "string", "string").SendGroupMessage = function(self, ID, type, actionReport, title, desc, link, extraJson)
	PCallMSDKFunction("sendGroupMessage", ID, type, actionReport, title, desc, link, extraJson)
end


--MSDK查詢回调OnQueryInfo的回调
---@param self ECMSDK.MSDKRelation
---@param relationRet table
---@return void
def.method("table").OnRelationNotify = function(self, relationRet)
	--relationRet结构说明:
	-- int flag;     //查询结果flag，0为成功
	-- string desc;    // 描述
	-- std::vector<PersonInfo> persons;//保存好友或个人信息
	-- string extInfo; //游戏查询是传入的自定义字段，用来标示一次查询
	--
	-- PersonInfo结构说明:
	-- string nickName;         //昵称
	-- string openId;           //帐号唯一标示
	-- string gender;           //性别
	-- string pictureSmall;     //小头像
	-- string pictureMiddle;    //中头像
	-- string pictureLarge;     //datouxiang
	-- string provice;          //省份(老版本属性，为了不让外部app改代码，没有放在AddressInfo)
	-- string city;             //城市(老版本属性，为了不让外部app改代码，没有放在AddressInfo)
	-- bool        isFriend;    //是否好友
	-- int         distance;    //离此次定位地点的距离
	-- string lang;             //语言
	-- string country;          //国家
	-- string gpsCity;          //根据GPS信息获取到的城市
	-- string bindList;		    //绑定信息
	
	print("OnRelationNotify: ", relationRet.flag)
	if relationRet.flag == 0 then
		print("Desc and ExtInfo: ", relationRet.desc, relationRet.extendInfo)
		if #relationRet.persons > 0 then
			self.m_MyInfo = relationRet.persons[1] 
			print("Save MyInfo",self.m_MyInfo.nickName)
			local MSDKEvent = require "Event.MSDKEvent"
			ECGame.EventManager:raiseEvent(nil, MSDKEvent.MSDKQueryInfoSuccessEvent.new())
		end
		for i,v in ipairs(relationRet.persons) do
			warn("relationRet.persons."..i,v.nickName,v.openId,v.pictureSmall)
		end
	end
end

---@type function
def.field("function").shareCallBack = nil
---@param self ECMSDK.MSDKRelation
---@param platform number
---@param flag number
---@param desc string
---@param extInfo string
---@return void
def.method("number", "number", "string", "string").OnShare = function(self, platform, flag, desc, extInfo)
	print("OnShare",platform, flag, desc, extInfo)
	if type(self.shareCallBack) == "function" then
		self.shareCallBack(flag)
		self.shareCallBack = nil
	end
end

--groupRet属性:
-- int retCode;				//MSDK 返回码，详情可参考 MSDKError.h
-- int methodNameID;		//标记是从哪个方法过来
-- int thirdCode;			//第三方渠道返回码
-- int status;				//MSDKGroupRet 状态码
-- std::string retMsg;		//MSDK 描述信息
-- std::string groupID;     // 工会ID(即为群号)
-- std::string groupName;   // 工会名称
-- std::string groupOpenID; // 取群信息手Q需要用的，用于发送群消息
-- std::vector<GroupInfo> groupInfo; // 工会信息列表
-- GroupInfo属性:
-- std::string groupID;    //群id
-- std::string groupName;  //群名称
-- std::string extraJson;  //扩展字段，默认为空
-- 群组功能用到的methodNameID:
-- kMethodNameCreateGroup              = 311,
-- kMethodNameBindGroup                = 312,
-- kMethodNameGetGroupList             = 313,
-- kMethodNameGetGroupState            = 314,
-- kMethodNameJoinGroup                = 315,
-- kMethodNameUnbindGroup              = 316,
-- kMethodNameRemindToBindGroup        = 317,
-- kMethodNameSendMessageToGroup       = 318,
-- kMethodNameGetGroupRelation         = 319,

---@param self ECMSDK.MSDKRelation
---@param groupRet table
---@return void
def.method("table").OnLoadGroupData = function(self, groupRet)
	--print("OnLoadGroupData, groupRet:")
	for k,v in pairs(groupRet) do
		--warn("OnLoadGroupData.groupRet k=",k,", v=",v)
	end
	local NotifyFaction = require "Event.NotifyFaction"
	if groupRet.retCode == 0 then
		if groupRet.methodNameID == 314 then							-- 查询创建群状态
			local hostPlayer = globalGame:GetHostPlayer()
			if hostPlayer == nil or hostPlayer.Faction == nil or not hostPlayer.Faction:IsValid() then
				return
			end
			--print_hsh("SetGroupState  groupRet ",groupRet.groupInfo)--啥都没传
			hostPlayer.Faction:SetGroupState(groupRet.status,groupRet.groupOpenID,groupRet.groupID)
		elseif groupRet.methodNameID == 319 then						-- 查询成员状态
			local hostPlayer = globalGame:GetHostPlayer()
			if hostPlayer == nil or hostPlayer.Faction == nil or not hostPlayer.Faction:IsValid() then
				return
			end
			--print_hsh("SetGroupRelation   groupRet ",groupRet.groupInfo)--啥都没传
			hostPlayer.Faction:SetGroupRelation(groupRet.status)
		elseif groupRet.methodNameID == 317	then						-- 提醒建群
			FlashTipMan.FlashTip(StringTable.Get(45701))
		elseif groupRet.methodNameID == 311 then						-- 创建群回调
			ECGame.EventManager:raiseEvent(nil, NotifyFaction.NotifyFactionGroupCreateEvent())
		elseif groupRet.methodNameID == 316 then						-- 解绑群回调
			ECGame.EventManager:raiseEvent(nil, NotifyFaction.NotifyFactionGroupUnbindEvent())
		elseif groupRet.methodNameID == 315 then						-- 加入群回调
			ECGame.EventManager:raiseEvent(nil, NotifyFaction.NotifyFactionGroupJoinEvent())
		end
	else
		if groupRet.methodNameID == 317	then							-- 提醒建群
			FlashTipMan.FlashTip(StringTable.Get(45702))
		elseif groupRet.methodNameID == 311 then
			FlashTipMan.FlashTip(StringTable.Get(45703))
		end
	end
end

-- (此方法c++没有实现)
---@param self ECMSDK.MSDKRelation
---@return boolean
def.method("=>", "boolean").IsNotificationOpened = function(self)
	local ret = PCallMSDKFunction("isNotificationOpened")
	return ret and ret or false
end

---@param self ECMSDK.MSDKRelation
---@return void
def.method().Clear = function(self)
	self.m_MyInfo = {}
end

MSDKRelation.Commit()
return MSDKRelation
