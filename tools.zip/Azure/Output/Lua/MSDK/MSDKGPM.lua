-------------------------------------------------------------------------------------------
-- GPM SDK
-- 提供一站式用户体验优化解决方案，主要根据客户端提供的各类性能信息来提供数据上报及性能监控
-- 需要GMSK
-- 接入内容：1.GCCloud AppID  2.引擎(UE4)  3.基本信息  4.定制  5.邮件名单
-------------------------------------------------------------------------------------------

local Lplus = require "Lplus"
local MSDKInfo = require("MSDK.MSDKInfo")

---@class MSDKGPM:System.Object
---@field public GameDataKey table
---@field public Commit fun():MSDKGPM @notnull
---@field public Init fun(appId:number, debug:boolean)
---@field public Inited fun(self:MSDKGPM):boolean
---@field public SetFirstData fun()
---@field public PostFrame fun(deltaTime:number)
---@field public UpdateFpsTarget fun()
---@field public MarkLevelLoad fun(sceneName:string)
---@field public MarkLevelFin fun()
---@field public MarkLevelLoadCompleted fun()
---@field public PostNTL fun(latency:number)
---@field public UpdateGameInfo fun(key:number, value:string)
---@field public UpdateGameInfoByString fun(key:string, value:string)
---@field public PostEventGEM fun(key:string, info:table)
---@field public BeginExclude fun()
---@field public EndExclude fun()
---@field public TDMGetDeviceInfo fun(key:string):string
---@field public GetASAForTLog fun():table
---@field public SendASATLog fun()
local MSDKGPM = Lplus.Class("MSDKGPM")
local def = MSDKGPM.define

local PCallGSDKFunction = function(FunctionName, ...)
	if GSDK and GSDK[FunctionName] then
		return GSDK[FunctionName](...)
	else
		warn(("There is no function = %s in GSDK"):format(FunctionName))
		return nil
	end
end

-- 初始化标识
---@type boolean
local _init = false
-- 初始化
-- appId : GCCloud GameID
-- debug : 是否为调试模式
---@param appId number
---@param debug boolean
---@return void
def.static("number", "boolean").Init = function( appId ,debug)
	--正式版初始化前关闭debug日志
	GPMSDK.enableLog(false)

	print("GPMSDK   init",_init)
	if GPMSDK == nil or _init then
		return
	end
	--[[
	local init = GPMSDK.initContext(tostring(appId),debug)
	if (init == -1) then
		error("fail to init GPM SDK")
		return
	else
		warn("init GMP SDK")
		_init = true
	end
	]]--

	--[[ AppID 和  ChannelID 不清楚是什么   暂时不传
	if GameUtil.GetPlatformName() == "Android" then
		TApm.UpdateGameInfo("AppID", "1106940691")
		local channelId = ECMSDK.GetChannelID()
		print("tapm channelId is ", channelId)
		TApm.UpdateGameInfo("ChannelID", channelId)
	end]]--

	_init = true
end
-- 是否初始化
---@param self MSDKGPM
---@return boolean
def.method("=>" , "boolean").Inited = function(self)
	return _init
end




-------------------------------------------------------------------------------------------------------------
-- 发送数据定义介绍     （UpdateGameInfo 中首位数字所代表的含义）
--	信息			Key编号		含义							是否必须		发送频率
--	主版本号		1			游戏的App版本号					必选			初始化后发一次
--	副版本号		2			游戏的资源版本号				可选			初始化后发一次
--	场景			4											必选			场景变化时发送
--	帧数			5			一段时间内的平补平均帧数		必选			SDK中处理
--	游戏目标帧数	7			整型（30、60）					必选			初始化、变动时发
--	游戏画质		8			整型（0、1、2）					必选			初始化、变动时发
--	特效画质		9			整型（0、1、2）					可选			初始化、变动时发
--	高清模式/分辨率	10			整型（从0开始递增）				可选			初始化、变动时发
--	同屏幕可见玩家	11			整型							可选			一定时间统计，变化较大时发
--	网络延迟		12			整型							可选			默认每3s统计发一次
--	游戏线程tid		50			轻负载							必选			初始化、变动时发
--	游戏线程tid		51			重负载							必选			初始化、变动时发
-------------------------------------------------------------------------------------------------------------

---@type table
def.const("table").GameDataKey = {
	OPEN_ID						= 0,
	MAIN_VERSION				= 1,
	SUB_VERSION					= 2,
	TIME_STAMP					= 3,
	SCENES						= 4,
	FPS							= 5,
	FRAME_MISS					= 6,
	FPS_TARGET					= 7,
	PICTURE_QUALITY				= 8,
	EFFECT_QUALITY				= 9,
	RESOLUTION					= 10,
	ROLE_COUNT					= 11,
	NET_DELAY					= 12,
	RECORDING					= 13,
	URGENT_SIGNAL				= 14,
	SERVER_IP					= 15,
	ROLE_STATUS					= 16,
	SCENE_TYPE					= 40,
	LOAD_TRUNK					= 41,
	BLOOM_AREA					= 42,
	MTR							= 43,
	KILL_REPORT					= 44,
	LIGHT_THREAD_TID			= 50,
	HEAVY_THREAD_TID			= 51,
	ROLE_OUT_LINE				= 52,
	PICTURN_STYLE				= 53,
	ANTI_ALIASING				= 54,
	SERVER_PORT					= 55,
	SOCKET_TYPE					= 56,
	SHADOW						= 57,
}



-- 第一次发送数据   初始化后
-- openId 为玩家登陆后的openid
---@return void
def.static().SetFirstData = function()
	print("GPM   SetFirstData  ",_init)
	if not _init then
		return
	end

	local openId = MSDKInfo.Instance():GetMSDKInfo("openId")
	GPMSDK.setOpenId(openId)     --函数区分大小写
	print("openId   ",openId)
	GPMSDK.updateGameInfo(MSDKGPM.GameDataKey.FPS_TARGET,_G.max_frame_rate)
	GPMSDK.updateGameInfo(MSDKGPM.GameDataKey.PICTURE_QUALITY, tostring(_G.cur_quality_level))
	GPMSDK.updateGameInfo(MSDKGPM.GameDataKey.EFFECT_QUALITY, tostring(FxCacheMan.Get_FxQuality()))
	GPMSDK.updateGameInfo(MSDKGPM.GameDataKey.RESOLUTION, 0)
	GPMSDK.updateGameInfo(MSDKGPM.GameDataKey.ROLE_COUNT, tostring(_G.max_visible_player))
	--GPMSDK.updateGameInfo(MSDKGPM.GameDataKey.HEAVY_THREAD_TID, tostring(GameUtil.GetGameThreadId()))
	--GPMSDK.updateGameInfo(MSDKGPM.GameDataKey.HEAVY_THREAD_TID, tostring(GameUtil.GetRenderThreadId()))

	-- 非官方 性能数据
	GPMSDK.updateGameInfo("GPU", SystemInfo.get_graphicsDeviceName())
	local QualitySetting = require "Configs.QualitySetting"
	local QualityID = QualitySetting.GetQualityTypeID()
	local DefQuality = QualitySetting.GetRecommandedQualitySettingIndex()
	local score = 0
	if _G.platform == _G.PLATFORM_TYPE_ANDROID then
		score = get_android_graphics_performance_score()
	end
	GPMSDK.updateGameInfo("DefaultQuality", DefQuality)
	GPMSDK.updateGameInfo("AndroidScore", score)
	local TApmQuality = _G.cur_quality_level*100000 + QualityID * 100 + DefQuality
	print("___________TApmQuality:_G.cur_quality_level,DefQuality,TApmQuality",_G.cur_quality_level,DefQuality,TApmQuality)
	GPMSDK.setQuality(TApmQuality)
end

-- 帧率上报
-- deltaTime 为传入间隔时间
-- 在ECGame中进行调用计算
---@param deltaTime number
---@return void
def.static("number").PostFrame = function(deltaTime)
	if not _init then
		return
	end

	GPMSDK.postFrame(deltaTime)
end

---@return void
def.static().UpdateFpsTarget = function ()
	if not _init then
		return
	end

	GPMSDK.updateGameInfo(MSDKGPM.GameDataKey.FPS_TARGET,_G.max_frame_rate)
end

local needFin = false
-- 场景加载标记
-- sceneName 为场景的名字
-- 第二个参数已废弃，若要使用，使用SetQuality接口进行画质设定，龙族似乎没有使用
-- 场景结束 MarkLevelFin() 通过第二次调用来自动标记  不再创建
---@param sceneName string
---@return void
def.static("string").MarkLevelLoad = function(sceneName)
	if not _init then
		return
	end

	if not needFin then
		GPMSDK.markLevelFin()
	else
		needFin = true
	end

	GPMSDK.markLevelLoad(sceneName)
end


---@return void
def.static().MarkLevelFin = function()
	if not _init then
		return
	end

	GPMSDK.markLevelFin()
end


-- 场景加载结束
---@return void
def.static().MarkLevelLoadCompleted = function()
	if not _init then
		return
	end

	GPMSDK.markLevelLoadCompleted()
end

-- 网络延时
-- latency 具体耗时值
-- 龙族没找到相应调用
---@param latency number
---@return void
def.static("number").PostNTL = function(latency)
	if not _init then
		return
	end

	GPMSDK.postNTL(latency)
end

-- 场景性能保障     即发送游戏数据
---@param key number
---@param value string
---@return void
def.static("number","string").UpdateGameInfo = function(key,value)
	if not _init then
		return
	end

	GPMSDK.updateGameInfo(key, value)
end

-- 发送非GameDataKey数据
---@param key string
---@param value string
---@return void
def.static("string","string").UpdateGameInfoByString = function(key,value)
	if not _init then
		return
	end

	GPMSDK.updateGameInfo(key, value)
end

-- GEM自定义数据上报
-- 频率需控制1次
-- info 需是 string:string
---@param key string
---@param info table
---@return void
def.static("string","table").PostEventGEM = function(key,info)
	--print_hsh("PostEventGEM   ",key,info)
	if not _init then
		return
	end

	GPMSDK.reportEvent(key,info)
end

local _excluded = false		--是否开启剔除
-- 开启区域剔除
-- 为了不再上报帧率
---@return void
def.static().BeginExclude = function()
	if not _init or _excluded then
		return
	end
	--print_hsh("BeginExclude   ")
	GPMSDK.beginExclude()
	_excluded = true
end
-- 结束区域剔除
---@return void
def.static().EndExclude = function()
	if not _init or not _excluded then
		return
	end
	--print_hsh("EndExclude   ")
	GPMSDK.endExclude()
	_excluded = false
end

-- 通过TDM获取数据
---@param key string
---@return string
def.static("string","=>","string").TDMGetDeviceInfo = function(key)
	return TDMSDK and TDMSDK.GetDeviceInfo(key) or ""
end

-- 获取 ASA 表，强转为字符串
---@return table
def.static("=>","table").GetASAForTLog = function()
	local asa = MSDKGPM.TDMGetDeviceInfo("AppleASA")
	local json = require "Utility.json"
	local asa_table = {}
	if asa ~= "" then
		asa_table = json.decode(asa)
	end
	for k,v in pairs(asa_table) do
		--warn("i,v  ",i,v,type(v))
		if type(v) ~= "string" then
			asa_table[k] = tostring(v)
		end
		--warn("i,v  ",i,v,type(v))
	end
	return asa_table
end

---@return void
def.static().SendASATLog = function()
	local MSDKUtil = require "MSDK.MSDKUtil"
	local pb_helper = require "PB.pb_helper"
	local msg = pb_helper.NewCmd "npt_send_tlog_info"

	msg.tlog_type = 11
	msg.param4 = MSDKGPM.TDMGetDeviceInfo("IDFA")
	msg.param5 = MSDKGPM.TDMGetDeviceInfo("CAID")

	local asa = MSDKGPM.GetASAForTLog()
	msg.str_params:append(MSDKUtil.Instance():GetIOSUserAgent())
	local b_attr = asa["iad-attribution"] or asa ["attribution"]
	local str_attr = ""
	if b_attr == "true" then
		str_attr = "1"
	else
		str_attr = "0"
	end
	msg.str_params:append(str_attr)
	msg.str_params:append(asa["iad-org-name"] or "")
	msg.str_params:append(asa["iad-org-id"] or asa ["orgId"] or "")
	msg.str_params:append(asa["iad-campaign-id"] or asa ["campaignId"] or "")
	msg.str_params:append(asa["iad-campaign-name"] or "")
	msg.str_params:append(asa["iad-click-date"] or asa ["clickDate"] or "")
	msg.str_params:append(asa["iad-purchase-date"] or "")
	msg.str_params:append(asa["iad-conversion-date"] or "")
	msg.str_params:append(asa["iad-conversion-type"] or asa ["conversionType"] or "")
	msg.str_params:append(asa["iad-adgroup-id"] or asa ["adGroupId"] or "")
	msg.str_params:append(asa["iad-adgroup-name"] or "")
	msg.str_params:append(asa["iad-country-or-region"] or asa ["countryOrRegion"] or "")
	msg.str_params:append(asa["iad-keyword"] or "")
	msg.str_params:append(asa["iad-keyword-id"] or asa ["keywordId"] or "")
	msg.str_params:append(asa["iad-keyword-matchtype"] or "")
	msg.str_params:append(asa["iad-creativeset-id"] or asa ["creativeSetId"] or "")
	msg.str_params:append(asa["iad-creativeset-name"] or "")

	--print_hsh("SendASATLog  ",msg)
	pb_helper.Send(msg)
end



MSDKGPM.Commit()
return MSDKGPM
