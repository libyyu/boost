-------------------------------------------------------------------------------------------
-- MSDKGPMGEMLoginPost
-- GPM中关于登陆前的上报
-- 无法使用Lplus，只能用Lua语法
-------------------------------------------------------------------------------------------

if _G.MarkReloadAfterUpdate then _G.MarkReloadAfterUpdate() end
local GEMLogin = {}


-- 开启下TDM接口
-- 早点开启GPM初始化
_G.bOpenTDM = false
local OpenTDM = function()
	--print("_G.bOpenTDM   ",_G.bOpenTDM)
	if not _G.bOpenTDM then
		if TDMSDK then
			--TDMSDK.SetRouterAddress(false,"https://hc.tdm.qq.com:8013/tdm/v1/route")
			--TDMSDK.Init("771320867","Android","Azure")
			--print("requestIDFAPermission   ")
			--if GameUtil.GetPlatformName() == "IOS" and ZLUtil.requestIDFAPermission then
			--	ZLUtil.requestIDFAPermission()
			--end
			TDMSDK.EnableDeviceInfo(true)
			TDMSDK.EnableReport(true)
			if GameUtil.GetPlatformName() == "IOS" and TDMSDK.ReportASA then
				TDMSDK.ReportASA()
			end
		end

		if GPMSDK and GPMSDK.initContext then
			local init = GPMSDK.initContext("1690133797",true)
			if (init == -1) then
				--error("fail to init GPM SDK")
				--return
			else
				--warn("init GMP SDK")
			end
		end

		_G.bOpenTDM = true
	end
end

-- 登陆路径转化步骤
---@type table
GEMLogin.LoginStep = {
	GAME_INIT 					= 0,	-- 初始化
	ENTER_UPDATE				= 1,	-- 进入更新界面
	CHECK_DEVICE				= 2,	-- 机型检查
	LINK_ZDIR					= 3,	-- 链接资源服
	CHECK_UPDATE				= 4,	-- 检查更新

	START_UPDATE_PACKAGE		= 5,	-- 开始更新Package
	START_DOWNLOAD_PACKAGE		= 6,	-- 开始下载Package
	GET_PACKAGE_SIZE			= 7,	-- 获取Package大小
	DOWNLOAD_PACKAGE			= 8,	-- 下载Package
	CHECK_PACKAGE				= 9,	-- 校验Package
	FINISH_PACKAGE				= 10,	-- 结束更新Package

	START_UPDATE_PATCHER		= 11,	-- 开始更新Patcher
	START_DOWNLOAD_PATCHER		= 12,	-- 开始下载Patcher
	DOWNLOAD_PATCHER			= 13,	-- 下载Patcher
	FINISH_PATCHER				= 14,	-- 结束更新Patcher

	FINISH_UPDATE				= 15,	-- 结束更新

	LOGIN_ENTER					= 16,	-- 进入登陆界面
	CLICK_MSDK_LOGIN			= 17,	-- MSDK手动登陆
	LOGIN_RESULT				= 18,	-- 登陆成功

	CONNECT_SERVER				= 19,	-- 链接服务器
	CREATE_ROLE					= 20,	-- 创建角色
	HP_INIT						= 21,	-- 主玩家初始化

	MAX_NUMBER					= 21,	-- 总共数量


	UPDATE						= -4,	-- 更新完成（不再使用）
}

-- 发送非GameDataKey数据
-- step 步骤，需要逐步递增，没有则返回
-- ret 成功或失败，默认为成功
-- retcode 错误码，默认为0
-- msg 提示信息，默认为空，成功固定为"success"
-- ext 扩展信息，默认为空
GEMLogin.PostLoginStepEvent = function(step,ret,retcode,msg,ext)
	print("PostLoginStepEvent   ",step,ret,retcode)
	if not _G.bOpenTDM then
		OpenTDM()
	end

	if GPMSDK == nil or GPMSDK.postStepEvent == nil then
		return
	end
	if not step then return end
	local bret = true
	if ret ~= nil then
		bret = ret
	end
	local ret_num = bret and 0 or 1
	local nretcode = retcode or 0
	local smsg = msg or ""
	local sext = ext or ""
	if bret then
		smsg = "success"
	end
	local bAuthorize = step == GEMLogin.LoginStep.LOGIN_GOPENID
	local bFinish = step == GEMLogin.LoginStep.MAX_NUMBER
	GPMSDK.postStepEvent(step, ret_num,nretcode,smsg,sext,bAuthorize,bFinish)
end

-- GEM自定义数据上报
-- 频率需控制1次
-- info 需是 string:string
GEMLogin.PostEventGEM = function(key,info)
	print("PostEventGEM   ",key,info)
	if GPMSDK == nil or GPMSDK.reportEvent == nil then
		return
	end

	GPMSDK.reportEvent(key,info)
end

local progress_list = {"0","0.25","0.5","0.75","1"}		-- 进度表
local progress_list_flag =		-- 用于标记各个阶段是否已经经过
{
	["0"] = false,
	["0.25"] = false,
	["0.5"] = false,
	["0.75"] = false,
	["1"] = false,
}
local get_progress_now = function()		-- 获取当前进度
	for i,v in pairs(progress_list) do
		if not progress_list_flag[v] then
			return v
		end
	end
end
local get_progress_info = function()		-- 要上报的数据，暂时没想好要上传什么
	local date = os.date("%Y-%m-%d %H:%M:%S")
	local table = {}
	table["date"] = date
	print("get_progress_info    ",date)
	return table
end
-- 下载数据上报
GEMLogin.PostEventGEMForDownloadProgress = function(progress)
	local progress_now = get_progress_now()
	if progress_now then
		local now = tonumber(progress_now)
		if progress >= now then
			local key = "download_progress_"..progress_now
			local info = get_progress_info()
			GEMLogin.PostEventGEM(key,info)
			progress_list_flag[progress_now] = true
		end
	end
end


-- 安卓上报OAID
GEMLogin.PostOAID = function()
	-- 必须先开启TGPA(GPM)，后间隔几秒
	if _G.bOpenTDM and GameUtil.GetPlatformName() == "Android" then
		if GPMSDK and GPMSDK.getDataFromTGPA then
			local oaid = GPMSDK.getDataFromTGPA("OAID")
			warn("oaid  ",oaid)
			if TDMSDK and TDMSDK.SetDeviceInfo then
				TDMSDK.SetDeviceInfo("oaid",oaid)
			end
		end
	end
end

return GEMLogin
