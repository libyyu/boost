-------------------------------------------------------------------------------------------
-- msdk 公告模块
--   公告模块是 MSDK 为游戏提供的信息通知系统。
--   公告系统只提供数据，具体 UI 样式需要业务自己定制，通过 飞鹰系统 -> 左侧菜单 SDK 接入->公告管理处配置下发文本、图片以及网址等信息。
--   使用方法: 首先调用LoadNoticeData拉取公告数据, 当回调函数OnNoticeInfo返回后, 通过GetNotifyInfo函数获取公告信息
-- MSDK 推送模块
--   推送功能分为本地推送与远程推送，可以在游戏未运行的情况下给玩家手机推送游戏相关的信息，如各种节假日活动、周年庆活动等。
--   支持的渠道有：1.信鸽(XG); 2.Firebase
-------------------------------------------------------------------------------------------

local Lplus = require "Lplus"
---@class ECMSDK.MSDKNotify:System.Object
---@field protected m_NotifyInfo table
---@field public Commit fun():ECMSDK.MSDKNotify @notnull
---@field public Instance fun():ECMSDK.MSDKNotify
---@field public LoadNoticeData fun(self:ECMSDK.MSDKNotify, noticeGroup:string, language:string, region:number, partition:string)
---@field public GetNotifyInfo fun(self:ECMSDK.MSDKNotify):table
---@field public Clear fun(self:ECMSDK.MSDKNotify)
---@field public RegisterPushAccout fun(self:ECMSDK.MSDKNotify, channel:string, accout:string)
---@field public UnregisterPush fun(self:ECMSDK.MSDKNotify, channel:string)
---@field public setTag fun(self:ECMSDK.MSDKNotify, channel:string, tag:string)
---@field public delTag fun(self:ECMSDK.MSDKNotify, channel:string, tag:string)
---@field public AddLocalNotification fun(params:table)
---@field public ClearLocalNotifications fun()
---@field public OnNoticeInfo fun(self:ECMSDK.MSDKNotify, noticeGroup:string, noticeInfos:table)
local MSDKNotify = Lplus.Class("ECMSDK.MSDKNotify")

local def = MSDKNotify.define

local PCallMSDKFunction = function(FunctionName, ...)
	if MSDK and MSDK[FunctionName] then
		return MSDK[FunctionName](...)
	else
		warn(("There is no function = %s in MSDK"):format(FunctionName))
		return nil
	end
end

local instance = nil

-- 

---@type table
def.field("table").m_NotifyInfo = nil

---@return ECMSDK.MSDKNotify
def.static("=>", MSDKNotify).Instance = function()
  if not instance then
       instance = MSDKNotify()
       instance.m_NotifyInfo = {}
  end
  return instance
end

-------------------------------------------------------------------------------------
-- 公告相关
-------------------------------------------------------------------------------------

-- 通知sdk拉取公告数据. (调用该函数后,公告数据从回调函数OnNoticeInfo返回)
-- param: noticeGroup 公告分组（必填），后台填好公告并且分好组就可以对应拉取公告信息。参数为 0 可以拉取到所有分组的公告，飞鹰侧配置公告时必填
-- param: language 公告的语种 国家/地区简码。同一种文字可能有多个简码，注意入参时不要填错。例如简体中文就有 zh-CN、zh-ID、zh-IE 多种
-- param: region  地区，北美、亚太、南美等，游戏自己配置定义。如果在飞鹰系统> SDK 接入>公告管理> MSDK_V5 公告管理>添加公告信息>公告地区(Region)选择了所有地区，获取公告数据时 region 填任意地区，都可以拉取该公告
-- param: partition 游戏大区，游戏自己配置定义
---@param self ECMSDK.MSDKNotify
---@param noticeGroup string
---@param language string
---@param region number
---@param partition string
---@return void
def.method("string", "string", "number", "string").LoadNoticeData = function(self, noticeGroup, language, region, partition)
	print("call fetch notice info")
	-- 最后一个参数是: 扩展字段，直接透传到后台，json格式 (项目可根据需要使用)
	PCallMSDKFunction("fetchNoticeInfo", noticeGroup, language, region, partition, "")
end

--获取从sdk返回的公告数据
---@param self ECMSDK.MSDKNotify
---@return table
def.method("=>", "table").GetNotifyInfo = function(self)
	return self.m_NotifyInfo or {}
end

-- 清除公告数据
---@param self ECMSDK.MSDKNotify
---@return void
def.method().Clear = function(self)
	self.m_NotifyInfo = nil
end

-- --获取公告数据
-- def.method("string").FetchNoticeInfo = function(self, scene)
-- 	print("call fetch notice info")
-- 	PCallMSDKFunction("fetchNoticeInfo", scene, "zh-CN", 392, ECGame.Instance().m_ZoneID, "")
-- end


-------------------------------------------------------------------------------------
-- 推送相关
-------------------------------------------------------------------------------------

-- 注册推送
-- param: channel 渠道名，比如 "XG", "Firebase"
-- param: accout 账号 (msdk登陆返回的openid)
---@param self ECMSDK.MSDKNotify
---@param channel string
---@param accout string
---@return void
def.method("string", "string").RegisterPushAccout = function(self, channel, accout)
	PCallMSDKFunction("registerPush", channel, accout)
end

-- 注销推送
-- param: channel 渠道名，比如 "XG", "Firebase"
---@param self ECMSDK.MSDKNotify
---@param channel string
---@return void
def.method("string").UnregisterPush = function(self, channel)
	PCallMSDKFunction("unregisterPush", channel, accout)
end

-- 注册标签推送
--  游戏可以针对用户设置标签，如性别、年龄、学历、爱好等，推送时可根据不同的标签有针对的进行推送。另外说明，XG SDK 有默认标签，详情可咨询 TPNS_helper(腾讯移动推送助手)。
--  发送标签推送消息同发送推送消息一样，只是在添加推送消息时发送人群范围需选择个性化推送。
-- param: channel 渠道名，比如 "XG", "Firebase"
-- param: tag 标签，不能为 null 或包含空格
---@param self ECMSDK.MSDKNotify
---@param channel string
---@param tag string
---@return void
def.method("string", "string").setTag = function(self, channel, tag)
	PCallMSDKFunction("setTag", channel, tag)
end

-- 注销标签推送
-- param: channel 渠道名，比如 "XG", "Firebase"
-- param: tag 标签，不能为 null 或包含空格
---@param self ECMSDK.MSDKNotify
---@param channel string
---@param tag string
---@return void
def.method("string", "string").delTag = function(self, channel, tag)
	PCallMSDKFunction("delTag", channel, tag)
end

-- 增加本地推送(此接口c++没有实现)
-- param: params 推送信息参数
--	 title		标题
--	 content	内容
--	 date		推送触发时间
--	 hour		触发小时
--	 min		触发分钟
---@param params table
---@return void
def.static("table").AddLocalNotification = function(params)
	local t = {}
	local dataStr = os.date("%Y/%m/%d/", params.date)
	for s in dataStr:gmatch("%d+/") do
		s = s:sub(1, -2)
		table.insert(t, tonumber(s))
	end
	--print_hsh("_G.platformName   ",_G.platformName)
	if _G.platformName == "android" then
		--android接口参数: 标题 内容 时间(年月日) 小时 分钟
		PCallMSDKFunction("addLocalNotificationForAndroid", params.title, params.content, ("%d%02d%02d"):format(t[1], t[2], t[3]), params.hour, params.min)
	elseif GameUtil.GetPlatformName() == "IOS" then
		-- ios接口参数: fireTime(触发时间), body(推送内容), badge(角标), action(替换弹框的按钮文字内容,默认为"启动"), userInfo(table,自定义参数)
		--local time = ("%d-%02d-%02d %d:%d:01"):format(t[1], t[2], t[3], params.hour, params.min)
		--这个产出的时间有问题
		--local timestamp = os.time({year=t[1], month=t[2], day=t[3], hour=params.hour, minute=params.min, second=0})
		--print_hsh("timestamp   ",timestamp)
		if MSDK and MSDK.addLocalNotificationForIosNew then
			PCallMSDKFunction("addLocalNotificationForIos", params.date, params.content, 1, "Start",0, {title = params.title})
		end
	end
end

-- 清空本地推送
-- param: channel 渠道名，比如 "XG", "Firebase"
---@return void
def.static().ClearLocalNotifications = function()
	if _G.platformName == "android" then
		PCallMSDKFunction("clearLocalNotifications", "XG")
	elseif _G.platformName == "ios" then
		PCallMSDKFunction("clearLocalNotifications", "")
	end
end

-- 公告模块的回调, 返回公告信息
---@param self ECMSDK.MSDKNotify
---@param noticeGroup string
---@param noticeInfos table
---@return void
def.method("string", "table").OnNoticeInfo = function(self, noticeGroup, noticeInfos)
	-- 将公告放入对应的公告分组
	self.m_NotifyInfo[noticeGroup] = noticeInfos
	print("get noticeinfo noticeInfos:",noticeGroup,noticeInfos)
	-- 公告结构
	-- {
	-- 	msg_id;			//string 公告id
	-- 	open_id;		//string 用户open_id
	-- 	msg_url;		//string 公告跳转链接
	-- 	msg_type;		//number 公告类型 
	-- 	msg_group;		//string 公告组(公告展示的场景，管理端后台配置)
	-- 	start_time;		//string 公告有效期开始时间
	-- 	end_time;		//string 公告有效期结束时间
	-- 	content_type;	//number 公告内容类型 0:文本公告, 1:图片公告, 2:网页公告
	-- 	content_url;    //string 网页公告URL(网页公告特殊字段)
	-- 	picArray;  		//table  图片数组(图片公告特殊字段)
	-- 	msg_title;		//string 公告标题 (文本公告特殊字段)
	-- 	msg_content;	//string 公告内容 (文本公告特殊字段)
	-- }
	-- picArray 图片数组信息结构
	-- {
	-- 	screenDir		//number 屏幕方向 0:横竖屏, 1:竖屏, 2:横屏
	-- 	picPath			//string 图片路径
	-- 	hashValue		//string 图片的hash码
	-- }

	local i
	for i = 1, #noticeInfos do
		local info = noticeInfos[i]
		local noticeTitle = info.msg_title or "No title"
		local noticeContent = info.msg_content or "No content"
		print("ECMSDK.MSDKNotify OnNoticeInfo noticeGroup:", noticeGroup)
		print("ECMSDK.MSDKNotify OnNoticeInfo title:", noticeTitle)
		print("ECMSDK.MSDKNotify OnNoticeInfo content:", noticeContent)
		print("ECMSDK.MSDKNotify OnNoticeInfo noticeType:", info.msg_type)
		print("ECMSDK.MSDKNotify OnNoticeInfo content_type:", info.content_type)
		if info.msg_type == 1000 then -- 登录前公告
			local ECPanelAnnouncement = require "GUI.ECPanelAnnouncement"
			ECPanelAnnouncement.Instance():ShowPanel(true,nil,nil)
		end
		
	end
	
	-- [[local event = require "Event.NoticeFetchedEvent"()
	-- ECGame.EventManager:raiseEvent(nil, event)]]
end


MSDKNotify.Commit()
return MSDKNotify
