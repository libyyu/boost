-------------------------------------------------------------------------------------------
-- msdk的全局定义文件
-------------------------------------------------------------------------------------------

-- msdk的渠道平台
_G.MSDK_LOGIN_PLATFORM =
{
	NON				= 0,
	WX				= 1, --微信
	QQ				= 2, --QQ
	GUEST			= 3, --游客
	FACEBOOK		= 4,
	GAME_CENTER		= 5,
	GOOGLE			= 6,
	TWITTER			= 9,
	GARENA			= 10,
	EMAIL			= 11,
	SMS				= 12,
	LINE			= 14,
	APPLE			= 15,
	WX_GAMECENTER	= -100, --实际没有，占位用
	QQHALL			= -200, --实际没有，占位用
}

-- msdk渠道平台的名字
_G.MSDK_LOGIN_PLATFORM_NAME =
{
	[MSDK_LOGIN_PLATFORM.WX] = "WeChat",
	[MSDK_LOGIN_PLATFORM.QQ] = "QQ",
	[MSDK_LOGIN_PLATFORM.WX_GAMECENTER] = "WX_GAMECENTER",
	[MSDK_LOGIN_PLATFORM.QQHALL] = "QQHALL",
	[MSDK_LOGIN_PLATFORM.GUEST] = "Guest",
	[MSDK_LOGIN_PLATFORM.FACEBOOK] = "Facebook",
	[MSDK_LOGIN_PLATFORM.GAME_CENTER] = "GameCenter",
	[MSDK_LOGIN_PLATFORM.GOOGLE] = "Google",
	[MSDK_LOGIN_PLATFORM.TWITTER] = "Twitter",
	[MSDK_LOGIN_PLATFORM.EMAIL] = "Email",
	[MSDK_LOGIN_PLATFORM.SMS] = "SMS",
	[MSDK_LOGIN_PLATFORM.LINE] = "Line",
	[MSDK_LOGIN_PLATFORM.APPLE] = "Apple",
}

--玩家登录平台
_G.LoginPlatform = 0

-- 接下来登陆的平台
_G.NEXT_PLATFORM = 0

--尚未找到对应项
local _UNKNOWN_MAP_VAL = -100

-- 登录错误码
_G.MSDK_LOGIN_ERROR_CODE =
{
	Succ          = 0,
	QQ_UserCancel = 2, 		--qq用户取消
	WX_UserCancel = 5, 		--微信用户取消授权
	WX_NotInstall = 15,
	WX_NotSupportApi = 16,
	WX_UserCancel = 26, --微信用户取消
	WX_LoginFail = 3,
	Local_Invalid = _UNKNOWN_MAP_VAL,
	Need_Login = 10,
	Need_Login_Accout = 1012, --异账号:需要进入登录页
	Need_Select_Accout = 1013,
	Net_Work_Err = 4,
	Not_Support_Api = 16,
	WX_AccessTokenExpired = _UNKNOWN_MAP_VAL,
	WX_RefreshTokenExpired = _UNKNOWN_MAP_VAL,
	UrlLogin = _UNKNOWN_MAP_VAL,
	AccountRefresh = 1014,
	Guest_LoginError = _UNKNOWN_MAP_VAL, --游客模式登录失败
	Server_Error = 5,
	TimeOut_Error = 6,
}

_G.MSDK_PAY_CODE =
{
	PAY_ERROR = -1,		--支付流程失败
	PAY_SUCCESS = 0,	--支付成功
	PAY_CANCEL = 2, 	--用户取消
	PAY_PARAMERROR = 3, --参数错误
	PAY_WARNING1 = 1139,
	PAY_WARNING2 = 1140,
	PAY_WARNING3 = 1141,
}

-- _G.MSDK_PAY_CODE_IOS =
-- {
-- 	PAY_ERROR = -1,
-- 	PAY_SUCCESS = 0,
-- 	PAY_CANCEL = 1,
-- 	PAY_PARAM_ERROR = 2,
-- 	PAY_NET_ERROR = 3,
-- 	PAY_IAP_ERROR = 4,
-- }

-- --腾讯VIP类型
-- _G.TX_VIP_TYPE =
-- {
-- 	NORMAL = 0,			--普通用户
-- 	QQVIP = 1,			--QQ会员
-- 	QQSUPERVIP = 2,		--超级QQ会员
-- 	WXVIP = 3,			--微信会员
-- }

_G.Login_GameCenter_Platform =
{
    Normal = 0, --普通登录
    QQ_MEMBER = 1, --QQ普通会员
    QQ_SMEMBER = 2,--QQ超级会员
    QQ = 3,     --QQ游戏中心登录
    WX = 4,     --微信游戏中心登录
}

-- Midas Pay 支付环境
-- true 表示为沙箱环境
-- false 表示为现网环境
_G.TEST_PAY_ENV = false
