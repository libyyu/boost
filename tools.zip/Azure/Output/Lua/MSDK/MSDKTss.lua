local Lplus = require "Lplus"
---@type ECGame
local ECGame = Lplus.ForwardDeclare("ECGame")
---@class MSDKTss:System.Object
---@field public Status table
---@field public EntryId table
---@field public Commit fun():MSDKTss @notnull
---@field public Init fun(game_id:number)
---@field public OnLogin fun()
---@field public PutData fun(data:userdata)
---@field public OnApplicationPause fun(pause:boolean)
---@field public OnceSend fun()
---@field public GetReportCoreDataFromTssSDK fun():string
local MSDKTss = Lplus.Class("MSDKTss")
---@type ECMSDK
local ECMSDK = Lplus.ForwardDeclare("ECMSDK")
---@type MSDKInfo
local MSDKInfo = require("MSDK.MSDKInfo")

local def = MSDKTss.define

local _init = false

---@type table
def.const("table").Status = {
	GAME_STATUS_FRONTEND = 1,
    GAME_STATUS_BACKEND  = 2,
    GAME_STATUS_START_PVP = 3,
    GAME_STATUS_END_PVP = 4,
    GAME_STATUS_UPDATE_FINISHED = 5,
}

---@type table
def.const("table").EntryId = {
	ENTRY_ID_QZONE		= 1,
	ENTRY_ID_MM			= 2,
	ENTRT_ID_FACEBOOK	= 3,
	ENTRY_ID_TWITTER	= 4,
	ENTRY_ID_LINE		= 5,
	ENTRY_ID_WHATSAPP	= 6,
	ENTRY_ID_GAMECENTER = 7,
	ENTRY_ID_GOOGLEPLAY = 8,
	ENTRY_ID_VK = 9,
	ENTRY_ID_OTHERS		= 99,
}

---@param game_id number
---@return void
def.static("number").Init = function ( game_id )
	if TssSDK == nil or _init then
		return
	end

	_init = true
	TssSDK.Init(game_id)
	GameUtil.AddGlobalTimer(5,false,function()
		local hp = ECGame.Instance().m_HostPlayer
		if hp then
			local data = TssSDK.GetDataFromSDK()
			if string.len(data) > 0 then
				--print("[TssSDK] send data ", string.len(data))
			else
				--print("[TssSDK] no data to send ")
				return
			end

			local TencentSecureInfo = require "Protocol.TencentSecureInfo"
			local p = TencentSecureInfo()

			p.role_id = hp.ID
			p.secure_data = Octets.fromString(data)

			--print(p.role_id,p.secure_data)
			ECGame.Instance().m_Network:SendProtocol(p)
		end
	end)

	local pauseEvent = require "Event.SystemEvents".ApplicationPause
    ECGame.EventManager:addHandler(pauseEvent, function ( sender, event )
    	MSDKTss.OnApplicationPause(event.paused)
    end)

    local HostPlayerReadyEvent = require "Event.HostPlayerReadyEvent"
	ECGame.EventManager:addHandler(HostPlayerReadyEvent, function ( ... )
		MSDKTss.OnLogin()
	end)    
end

---@return void
def.static().OnLogin = function ()
	local entryId = MSDKTss.EntryId.ENTRY_ID_OTHERS
	local appId = MSDKInfo.Instance():GetMSDKInfo("appId")
	local openId = MSDKInfo.Instance():GetMSDKInfo("openId")
	if _G.LoginPlatform == MSDK_LOGIN_PLATFORM.QQ then
		entryId = MSDKTss.EntryId.ENTRY_ID_QZONE
	elseif _G.LoginPlatform == MSDK_LOGIN_PLATFORM.WX then
		entryId = MSDKTss.EntryId.ENTRY_ID_MM
	end

	local hp = ECGame.Instance().m_HostPlayer
	local idStr = LuaUInt64.ToString(hp.ID)
	local worldId = hp:GetZoneId()
	print(("tss sdk set user info [entry:%s] [appId:%s] [openId:%s] [worldId:%s] [idStr:%s]"):format(entryId, appId, openId, worldId, idStr))
	TssSDK.SetUserInfo(entryId,openId)
end

---@param data userdata
---@return void
def.static("userdata").PutData = function ( data )
	if TssSDK ~= nil then
		--print("[TssSDK] get data from server")
		TssSDK.PutDataToSDK(data:getStringUTF8())
	end
end

---@param pause boolean
---@return void
def.static("boolean").OnApplicationPause = function ( pause )
	if TssSDK ~= nil then
		if pause then
			--print("[TssSDK] pause")
			TssSDK.SetGameStatus(MSDKTss.Status.GAME_STATUS_BACKEND)
		else
			--print("[TssSDK] resume")
			TssSDK.SetGameStatus(MSDKTss.Status.GAME_STATUS_FRONTEND)
		end
	end
end

---@return void
def.static().OnceSend = function ( )
	print("OnceSend")
	if TssSDK == nil then
		return
	end

	local hp = ECGame.Instance().m_HostPlayer
	if hp then
		local data = TssSDK.GetDataFromSDK()
		if string.len(data) > 0 then
			print("[TssSDK] send data ", string.len(data))
		else
			print("[TssSDK] no data to send ")
			--return
		end

		local TencentSecureInfo = require "Protocol.TencentSecureInfo"
		local p = TencentSecureInfo()

		p.role_id = hp.ID
		p.secure_data = Octets.fromString(data)

		print(p.role_id,p.secure_data)
		ECGame.Instance().m_Network:SendProtocol(p)
	end
end

-- 获取安全SDK的核心初始化数据
---@return string
def.static("=>","string").GetReportCoreDataFromTssSDK = function()
	if TssSDK ~= nil then
		local core_data = ""
		core_data = TssSDK.GetDataFromSDK2()
		return core_data
	end
	return ""
end

MSDKTss.Commit()
return MSDKTss
