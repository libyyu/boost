-------------------------------------------------------------------------------------------
-- msdk的登录模块, Account模块
-- 登录函数: Login,LoginUI,LoginTencentAccount
-- 登录返回: OnLoginSuccess回调函数中获取登录游戏用的账号密码

-------------------------------------------------------------------------------------------

local Lplus = require "Lplus"
local DaizongSDK = require "Daizong.DaizongSDK"
local GEMLogin = require "MSDK.MSDKGPMGEMLoginPost"
local MSDKLoginLimit = require "MSDK.MSDKLoginLimit"
local MSDKInfo = require("MSDK.MSDKInfo")
local MSDKRelation = require("MSDK.MSDKRelation")
local Json = require "Utility.json"

---@type ECGame
local ECGame = Lplus.ForwardDeclare("ECGame")
---@type ECMSDK.MidasPay
local MidasPay = Lplus.ForwardDeclare("ECMSDK.MidasPay")

---@class ECMSDK.MSDKLogin:System.Object
---@field protected m_LoginPlatform number
---@field protected m_TryLoginPlatform number
---@field protected m_simulateUsername string
---@field protected m_simulatePassword string
---@field protected m_CombimeAppId string
---@field protected m_tencentAccount string
---@field protected m_tencentPassword string
---@field protected m_isRealName boolean
---@field protected m_isSwitching boolean
---@field public Commit fun():ECMSDK.MSDKLogin @notnull
---@field public Instance fun():ECMSDK.MSDKLogin
---@field public Login fun(self:ECMSDK.MSDKLogin, loginPlatform:number)
---@field public ShowQrCodeWebPage fun(self:ECMSDK.MSDKLogin, url:string, redirect_uri:string, onFinish:function)
---@field public LoginUI fun(self:ECMSDK.MSDKLogin)
---@field public LoginTencentAccount fun(self:ECMSDK.MSDKLogin, account:string, password:string)
---@field public UserLogOut fun(self:ECMSDK.MSDKLogin)
---@field public SwitchUser fun(self:ECMSDK.MSDKLogin, flag:boolean):boolean
---@field public SetSimulateAccount fun(self:ECMSDK.MSDKLogin, username:string, password:string)
---@field public Bind fun(self:ECMSDK.MSDKLogin, bindPlatform:number)
---@field public RegisteTencentAccount fun(self:ECMSDK.MSDKLogin, account:string, password:string, verifyCode:number)
---@field public ResetPassword fun(self:ECMSDK.MSDKLogin, channel:number, accout:string, password:string, verifyCode:number, areaCode:string, extraJson:string)
---@field public RequestVerifyCode fun(self:ECMSDK.MSDKLogin, channel:number, accout:string, codeType:number, areaCode:string, langType:string, extraJson:string)
---@field public DifferentAccoutAction fun(self:ECMSDK.MSDKLogin, wakeupPlatform:number, openId:string, jsonStr:string)
---@field public ExitToLogOut fun(self:ECMSDK.MSDKLogin)
---@field public CheckLoginRecord fun(self:ECMSDK.MSDKLogin)
---@field public GetLoginRetToken fun(self:ECMSDK.MSDKLogin, tokens:table, tokenType:number):string
---@field public RefreshMSDKTicket fun(self:ECMSDK.MSDKLogin)
---@field public GetLoginPlatform fun(self:ECMSDK.MSDKLogin):number
---@field public GetCombineAppID fun(self:ECMSDK.MSDKLogin):string
---@field public IsRealNameAuth fun(self:ECMSDK.MSDKLogin):boolean
---@field public IsLogin fun():boolean
---@field public OnLoginSuccess fun(self:ECMSDK.MSDKLogin, wakeupPlatform:number, openId:string, pf:string, pfKey:string, token:string, channelInfoJsonStr:string, regChannelDis:string)
---@field public OnQrCodeNotify fun(self:ECMSDK.MSDKLogin, channelID:number, channel:string, qrCodeUrl:string)
---@field public OnLoginError fun(self:ECMSDK.MSDKLogin, flag:number, desc:string, openid:string, method:number)
---@field public OnWakeup fun(self:ECMSDK.MSDKLogin, flag:number, wakeupPlatform:number, mediaTagName:string, openId:string, desc:string, lang:string, country:string, messageExt:string, extInfo:table)
---@field public OnLogout fun(self:ECMSDK.MSDKLogin, flag:number)
---@field public ClearTencentCenterInfo fun(self:ECMSDK.MSDKLogin)
---@field public OnBindNotify fun(self:ECMSDK.MSDKLogin, flag:number, thirdCode:number, confirmCode:string)
---@field public OnAccountNotify fun(self:ECMSDK.MSDKLogin, flag:number, msg:string, methodId:number, thirdCode:number, thirdMsg:string)
---@field public SaveMSDKInfo fun(self:ECMSDK.MSDKLogin, key:string, value:any)
---@field public GetMSDKInfo fun(self:ECMSDK.MSDKLogin, key:string):any
---@field public SendPrivilegeType fun(self:ECMSDK.MSDKLogin)
---@field public GetCenterOpenIDByHTTP fun(self:ECMSDK.MSDKLogin)
local MSDKLogin = Lplus.Class("ECMSDK.MSDKLogin")
local def = MSDKLogin.define

local PCallMSDKFunction = function(FunctionName, ...)
	if MSDK and MSDK[FunctionName] then
		return MSDK[FunctionName](...)
	else
		warn(("There is no function = %s in MSDK"):format(FunctionName))
		return nil
	end
end

-- 登录的渠道

---@type number
def.field("number").m_LoginPlatform = MSDK_LOGIN_PLATFORM.NON
-- 尝试登录的渠道

---@type number
def.field("number").m_TryLoginPlatform = MSDK_LOGIN_PLATFORM.NON
-- PC模拟账号用户名

---@type string
def.field("string").m_simulateUsername = ""
-- PC模拟账号密码

---@type string
def.field("string").m_simulatePassword = ""

---@type string
def.field("string").m_CombimeAppId = ""

---@type string
def.field("string").m_tencentAccount = ""

---@type string
def.field("string").m_tencentPassword = ""

---@type boolean
def.field("boolean").m_isRealName = false
--正在切换用户,此时不应再登出

---@type boolean
def.field("boolean").m_isSwitching = false

local instance = nil
---@return ECMSDK.MSDKLogin
def.static("=>", MSDKLogin).Instance = function()
	if not instance then
		instance = MSDKLogin()
	end
	return instance
end

--MSDK登录相关接口----------------------------------------------------------------

--登录, 参数:登录的渠道平台(QQ,WX,......)
---@param self ECMSDK.MSDKLogin
---@param loginPlatform number
---@return void
def.method("number").Login = function(self, loginPlatform)
	if not MSDKLoginLimit.CheckForLimit(true) then
		return
	end

	local MSDKUtil = require "MSDK.MSDKUtil"

	if _G.platform == _G.PLATFORM_TYPE_IOS or _G.platform == _G.PLATFORM_TYPE_ANDROID then
		DaizongSDK.LogStepLogReport(DAIZONG_STEPCODE.LOGIN_MSDK_LOGIN)
		GEMLogin.PostLoginStepEvent(GEMLogin.LoginStep.CLICK_MSDK_LOGIN)
		self.m_TryLoginPlatform = loginPlatform

		local loginPlatformName = MSDK_LOGIN_PLATFORM_NAME[loginPlatform]
		local extraTab = {}
		if loginPlatform == _G.MSDK_LOGIN_PLATFORM.WX then
			if not MSDKUtil.Instance():IsAppInstalled(loginPlatform) then
				--warn("WX QRCodeLogin")
				extraTab["QRCode"] = true
			end
		elseif loginPlatform == _G.MSDK_LOGIN_PLATFORM.EMAIL then
			extraTab["type"] = "login"
			extraTab["account"] = self.m_tencentAccount
			extraTab["password"] = self.m_tencentPassword
		end

		local extraJson = Json.encode(extraTab)
		print("loginByName params is ", loginPlatformName, extraJson)
		PCallMSDKFunction("loginByName", loginPlatformName, "all", "", extraJson)
	else
		if not _G.IsWindowsSimuMobile() then
			local loginPlatformName = MSDK_LOGIN_PLATFORM_NAME[loginPlatform]

			local UrlHelper = require "Utility.UrlHelper"
			if loginPlatform == _G.MSDK_LOGIN_PLATFORM.WX then
				local url = string.format(MSDKInfo.URLs.WebAuthWeChat, MSDKInfo.APPID.WX, UrlHelper.urlEncode(MSDKInfo.WebAuthRedirectUri.WeChat), "test")
				self:ShowQrCodeWebPage(url, MSDKInfo.WebAuthRedirectUri.WeChat, function(isSucc, code, state)
					print(isSucc, code, state)

					local extraTab = {}
					extraTab["channel"] = loginPlatformName
					extraTab["channelID"] = 1
					extraTab["channelOpenID"] = ""
					extraTab["pluginData"] = {code=code}
					local extraJson = Json.encode(extraTab)
					print("loginByName params is ", extraJson)
					PCallMSDKFunction("loginByName", "", "", "", extraJson)
				end)
			elseif loginPlatform == _G.MSDK_LOGIN_PLATFORM.QQ then
				local url = string.format(MSDKInfo.URLs.WebAuthQQ, MSDKInfo.APPID.QQ, UrlHelper.urlEncode(MSDKInfo.WebAuthRedirectUri.QQ), "test")
				self:ShowQrCodeWebPage(url, MSDKInfo.WebAuthRedirectUri.QQ, function(isSucc, code, state)
					print(isSucc, code, state)

					local extraTab = {}
					extraTab["channel"] = loginPlatformName
					extraTab["channelID"] = 2
					extraTab["channelOpenID"] = ""
					extraTab["pluginData"] = {
						code = code,
						redirect_uri = MSDKInfo.WebAuthRedirectUri.QQ,
						msdk_qq_login_use_code = 1,
					}
					local extraJson = Json.encode(extraTab)
					print("loginByName params is ", extraJson)
					PCallMSDKFunction("loginByName", "", "", "", extraJson)
				end)
			end
		end
	end
end

---@param self ECMSDK.MSDKLogin
---@param url string
---@param redirect_uri string
---@param onFinish function
---@return void
def.method("string", "string", "function").ShowQrCodeWebPage = function(self, url, redirect_uri, onFinish)
	local response_url = redirect_uri
	if response_url:find("/$") == nil then
		response_url = response_url .. "/"
	end
	response_url = response_url .. "%?code=(.+)&state=(.+)"
	--print("ShowQrCodeWebPage", response_url)
	local UICommonBrowser = require "GUI.Utility.UICommonBrowser"
	UICommonBrowser.Instance():OpenPanel(url, function(newUrl)
		if newUrl then
			--print(newUrl, response_url)
			if string.find(newUrl, response_url) ~= nil then
				local code, state = string.match(newUrl, response_url)
				if onFinish then
					onFinish(true, code, state)
				end

				-- 得延迟一会儿关闭，不然会崩，囧
				GameUtil.AddGlobalTimer(0.5, true, function()
					UICommonBrowser.Instance():DestroyPanel()
				end)
			end
		else
			onFinish(false)
		end
	end)
end

--使用腾讯UI登录 (需要腾讯sdk配置支持, sdk会打开一个渠道列表的界面供用户选择)
---@param self ECMSDK.MSDKLogin
---@return void
def.method().LoginUI = function ( self )
	local param = Json.encode({isUE4Engine = false, countDownTime = 60})
	PCallMSDKFunction("loginUI", param)
end

-- 使用腾讯账号登录, 参数:账号, 密码
---@param self ECMSDK.MSDKLogin
---@param account string
---@param password string
---@return void
def.method("string", "string").LoginTencentAccount = function ( self, account, password )
	self.m_tencentAccount = account
	self.m_tencentPassword = password
	self:Login(_G.MSDK_LOGIN_PLATFORM.EMAIL)
end

-- 登出游戏
---@param self ECMSDK.MSDKLogin
---@return void
def.method().UserLogOut = function (self)
	if self.m_isSwitching then
		return
	end

	PCallMSDKFunction("logout")
	self.m_LoginPlatform = MSDK_LOGIN_PLATFORM.NON
	_G.loginPlatform = self.m_LoginPlatform
	MSDKRelation.Instance():Clear()
end

-- 切换游戏账号
-- 1.如果玩家选择切换账号，请将 flag 置为 true。切换账号的结果将从游戏监控的登录回调处返回。
-- 2.如果玩家选择不切换账号，请将 flag 置为 false。MSDK 将自动触发自动登录逻辑，但不会回调给游戏
---@param self ECMSDK.MSDKLogin
---@param flag boolean
---@return boolean
def.method("boolean", "=>", "boolean").SwitchUser = function(self, flag)
	local ret = PCallMSDKFunction("switchUser", flag)
	return ret
end

--设置 windows 模拟登录的账号
---@param self ECMSDK.MSDKLogin
---@param username string
---@param password string
---@return void
def.method("string", "string").SetSimulateAccount = function (self, username, password)
	self.m_simulateUsername = username
	self.m_simulatePassword = password
end

-- 绑定（仅支持海外）, 参数: 渠道
-- 绑定的本质是指多个第三方账号共用一个MSDK openid。一般使用场景为：游客登陆游戏，之后绑定 Facebook 或者 Google 账号。
---@param self ECMSDK.MSDKLogin
---@param bindPlatform number
---@return void
def.method("number").Bind = function ( self, bindPlatform )
	local bindPlatformName = MSDK_LOGIN_PLATFORM_NAME[bindPlatform]
	PCallMSDKFunction("bind", bindPlatformName)
end

-- 注册腾讯账号, 参数:账号, 密码, 验证码
---@param self ECMSDK.MSDKLogin
---@param account string
---@param password string
---@param verifyCode number
---@return void
def.method("string", "string", "number").RegisteTencentAccount = function ( self, account, password, verifyCode )
	local extraJson = Json.encode({
		type = "register",
		account = account,
		password = password,
		verifyCode = verifyCode,
		isNeedVerify = 1
	})
	PCallMSDKFunction("loginByName", "Email", "", "", extraJson)
end

-- 重置腾讯账号密码, 参数:渠道, 账号, 密码, 验证码
---@param self ECMSDK.MSDKLogin
---@param channel number
---@param accout string
---@param password string
---@param verifyCode number
---@param areaCode string
---@param extraJson string
---@return void
def.method("number", "string", "string", "number", "string", "string").ResetPassword = function ( self, channel, accout, password, verifyCode, areaCode, extraJson)
	local loginPlatformName = MSDK_LOGIN_PLATFORM_NAME[channel]
	PCallMSDKFunction("resetPassword", loginPlatformName, accout, password, verifyCode, areaCode, extraJson)  
end

-- 申请验证码, 参数:渠道, 账号, , ,
---@param self ECMSDK.MSDKLogin
---@param channel number
---@param accout string
---@param codeType number
---@param areaCode string
---@param langType string
---@param extraJson string
---@return void
def.method("number", "string", "number", "string", "string", "string").RequestVerifyCode = function ( self, channel, accout, codeType, areaCode, langType, extraJson)
	local loginPlatformName = MSDK_LOGIN_PLATFORM_NAME[channel]
	PCallMSDKFunction("requestVerifyCode", loginPlatformName, accout, codeType, areaCode, langType, extraJson)  
end

-- wakeupPlatform 当前平台
-- openId 当前账号
-- jsonStr 唤醒的信息
---@param self ECMSDK.MSDKLogin
---@param wakeupPlatform number
---@param openId string
---@param jsonStr string
---@return void
def.method("number", "string","string").DifferentAccoutAction = function(self, wakeupPlatform, openId, jsonStr)
    --print_hsh("DifferentAccoutAction   ",wakeupPlatform, openId)
	local msg = Json.decode(jsonStr)
	--print_hsh("msg   ",msg)
	local param = Json.decode(msg.params)
	--print_hsh("param   ",param)

	local show_tips = ""	-- 文本提示
	if param.platform == "qq_m" then			-- 手Q拉起
		show_tips = StringTable.Get(80503)
		_G.NEXT_PLATFORM = _G.MSDK_LOGIN_PLATFORM.QQ
	elseif param.platform == "WeChat" or param.messageExt=="WX_GameCenter" then		-- 微信拉起
		show_tips = StringTable.Get(80502)
		_G.NEXT_PLATFORM = _G.MSDK_LOGIN_PLATFORM.WX
	end
	MsgBox.ShowMsgBox(self, show_tips, nil, MsgBox.MsgBoxType.MBBT_OKCANCEL, function(sender, ret)
		if ret == MsgBox.MsgBoxRetT.MBRT_OK then
			--会跳过勾选协议，暂不使用切换平台的功能
			--微信要添加
			local cb = function()
				self:Login(_G.NEXT_PLATFORM)
				_G.NEXT_PLATFORM = 0
			end
			local ECPanelLogin = require "GUI.LoginRole.ECPanelLogin"
			ECPanelLogin.Instance():SetReEnterCallBack(cb)
			--
			self:ExitToLogOut()
		else
			--self:ClearTencentCenterInfo()
		end
	end)
end

-- 退出至登陆前
---@param self ECMSDK.MSDKLogin
---@return void
def.method().ExitToLogOut = function(self)
	local state = ECGame.Instance().mGameState
	if state == _G.GameState.SelectServer then
		local ECPanelServerListNew = require "GUI.ECPanelServerListNew"
		ECPanelServerListNew.Instance():DestroyPanel()
	elseif state == _G.GameState.Login then
		local ECPanelLogin = require "GUI.LoginRole.ECPanelLogin"
		ECPanelLogin.Instance():ChangeAccount()
	elseif state == _G.GameState.ChooseRole then
		ECGame.Instance().m_GUIMan:BackToLogin()
	elseif state == _G.GameState.GameWorld then
		ECGame.LogoutGame()
	end
	self:UserLogOut()
end

-- ??
---@param self ECMSDK.MSDKLogin
---@return void
def.method().CheckLoginRecord = function ( self )
	self.m_isSwitching = false
	-- 获取登录信息
	local ret, flag, desc, plat, openId, tokens, userId, pf, pfKey, channelInfo = PCallMSDKFunction("getLoginRecord")
	if flag == MSDK_LOGIN_ERROR_CODE.Succ then
		local token = self:GetLoginRetToken(tokens, MSDKInfo.TOKENTYPE.FOREIGN) --C++提供的lua接口中token只有一个且type始终为0， 历史遗留代码改过来的吧？
	    self:OnLoginSuccess(plat, openId, pf, pfKey, token, channelInfo, "")
	end
end

---@param self ECMSDK.MSDKLogin
---@param tokens table
---@param tokenType number
---@return string
def.method("table", "number", "=>", "string").GetLoginRetToken = function ( self, tokens, tokenType )
	for i, token in ipairs( tokens ) do
		if token.type == tokenType then
			return token.value
		end
	end

	warn("[login] not find token for type ", tokenType)
	return ""
end

---@param self ECMSDK.MSDKLogin
---@return void
def.method().RefreshMSDKTicket = function(self)
	-- local appId = self:GetMSDKInfo("appId")
	-- local openId = self:GetMSDKInfo("openId")
	-- local accessToken = self:GetMSDKInfo("accessToken")
	-- local loginPlatform = _G.LoginPlatform
end

-- 获取登录的渠道平台
---@param self ECMSDK.MSDKLogin
---@return number
def.method("=>", "number").GetLoginPlatform = function(self)
	return self.m_LoginPlatform
end

-- 
---@param self ECMSDK.MSDKLogin
---@return string
def.method("=>", "string").GetCombineAppID = function(self)
	return self.m_CombimeAppId
end

-- 获取是否实名(暂时不能使用)
---@param self ECMSDK.MSDKLogin
---@return boolean
def.method("=>", "boolean").IsRealNameAuth = function (self)
	return self.m_isRealName
end

---@return boolean
def.static("=>", "boolean").IsLogin = function()
	return self.m_LoginPlatform ~= MSDK_LOGIN_PLATFORM.NON
end

--MSDK登录回调处理-----------------------------------------
local postId = 0
local lastOpenID = nil
---@param self ECMSDK.MSDKLogin
---@param wakeupPlatform number
---@param openId string
---@param pf string
---@param pfKey string
---@param token string
---@param channelInfoJsonStr string
---@param regChannelDis string
---@return void
def.method("number", "string", "string", "string", "string", "string","string").OnLoginSuccess = function(self, wakeupPlatform, openId, pf, pfKey, token, channelInfoJsonStr,regChannelDis)
	DaizongSDK.LogStepLogReport(DAIZONG_STEPCODE.LOGIN_MSDK_LOGIN_SUCCESS)
	GEMLogin.PostLoginStepEvent(GEMLogin.LoginStep.LOGIN_RESULT)
	GEMLogin.PostOAID()
	MSDKLoginLimit.ResetLimitOnSuccess()
    
	local ECGameSDK = require "ProxySDK.ECGameSDK"
	local accessToken
	local payToken
	local channelInfo = Json.decode(channelInfoJsonStr)
	self:SaveMSDKInfo("regChannelDis",regChannelDis)
	
	if channelInfo.extra and channelInfo.extra == "ios" then	--REFCX-10781 H5 云游平台指定全平台登录的操作系统平台为 iOS
		local ECLoginProcessManager = require "Main.ECLoginProcessManager"
		ECLoginProcessManager.Instance():SetupUsernamePlatformForThisRun("ios")
	else
		local ECLoginProcessManager = require "Main.ECLoginProcessManager"
		ECLoginProcessManager.Instance():DetermineUsernamePlatform()	--自动登录时需刷新为上次的选择
	end

	accessToken = token

	if channelInfo then
		if not accessToken or accessToken == "" then
			accessToken = channelInfo.access_token or ""
		end
		payToken = channelInfo.pay_token or ""
	end

	if not payToken or payToken == "" then
		payToken = accessToken
	end
	--print_hsh(("MSDKLoginSuccess wakeupPlatform = %d, openId = %s, pf = %s, pfKey = %s, accessToken = %s, payToken = %s"):format(
	--		wakeupPlatform, openId, pf, pfKey, accessToken, payToken))
	--wakeupPlatform, openId, pf, pfKey, accessToken, payToken))
	if ECGame.Instance == nil then
		warn("OnLoginSuccess too early")
		return
	end

	local game = ECGame.Instance()
	--游戏过程中有可能会收到LoginSuccess
	if game.m_inGameLogic or game.mGameState == GameState.ChooseRole then
		if self.m_LoginPlatform == MSDK_LOGIN_PLATFORM.WX then
			local _, _, _, _, _, tokens, _, _, _ = PCallMSDKFunction("getLoginRecord")
			for k, v in pairs(tokens) do
				if v.type == 3 then --微信accessToken
					warn("Refresh WX accessToken in game")
					self:SaveMSDKInfo("accessToken", v.value)
					MidasPay.Instance():UpdateLoginInfo()
					return
				end
			end
		end
		--print("游戏还在进行")
		self:SaveMSDKInfo("pf", pf)
		self:SaveMSDKInfo("pfKey", pfKey)
		self:SaveMSDKInfo("accessToken", accessToken)
		self:SaveMSDKInfo("payToken", payToken)
		MidasPay.Instance():UpdateLoginInfo()
		return
	end

	local SaveMSDKInfo = function(appId, appKey, openId, pf, pfKey, accessToken, payToken, sessionId, sessionType)
		if lastOpenID ~= openId then
			-- OpenID切换：清除一些信息
			--warn("__OpendIDChanged: ", lastOpenID, openId)
			require "MSDK.ECMSDK".ClearInfoWhenOpenIDChanged()
			lastOpenID = openId
		end
		self:SaveMSDKInfo("appId", appId)
		self:SaveMSDKInfo("appKey", appKey)
		self:SaveMSDKInfo("openId", openId)
		self:SaveMSDKInfo("pf", pf)
		self:SaveMSDKInfo("pfKey", pfKey)
		self:SaveMSDKInfo("accessToken", accessToken)
		self:SaveMSDKInfo("payToken", payToken)
		self:SaveMSDKInfo("sessionId", sessionId)
		self:SaveMSDKInfo("sessionType", sessionType)
		self:SaveMSDKInfo("combineAppId", self.m_CombimeAppId)

		self:GetCenterOpenIDByHTTP()
	end

	local loginPlatform = (wakeupPlatform == 0 and PCallMSDKFunction("platform") or wakeupPlatform)
	self.m_LoginPlatform = loginPlatform
	_G.LoginPlatform = loginPlatform

	-- 保存最后一次正常登录的信息
	local UserData = require "Data.UserData"
	local UserDataTable = UserData.Instance()
	UserDataTable:SetSystemCfg("MSDKLoginPlatform", loginPlatform)
	UserDataTable:SetSystemCfg("MSDKLoginOpenId", openId)
	UserData.Instance():SaveUserData()
	
	-- 登录服务器的账号密码(按照统一渠道处理)
	do
		local account, channelid
		if loginPlatform == MSDK_LOGIN_PLATFORM.QQ then --qq登陆
			channelid = 2
			account = openId.."$qq"
			local pass = Json.encode({
				token = SimpleEncryptEncodeText(accessToken),
				channelid = loginPlatform,
				pf = pf,
				pfkey = pfKey,
				appid = (_G.platformName == "ios") and "ios_qq" or "android_qq",
				os = (_G.platformName == "ios") and 2 or 1,
				paytoken = payToken,
			})
			--warn("msdk account, pass:", account, pass)

			self.m_CombimeAppId = _G.platformName == "ios" and "ios_qq" or "android_qq"
			SaveMSDKInfo(MSDKInfo.APPID.QQ, MSDKInfo.APPKEY.QQ, openId, pf, pfKey, accessToken, payToken, "itopid", "itop")

		elseif loginPlatform == MSDK_LOGIN_PLATFORM.WX then --微信登陆
			channelid = 1
			account = openId.."$wechat"
			local pass = Json.encode({
				token = SimpleEncryptEncodeText(accessToken),
				channelid = loginPlatform,
				pf = pf,
				pfkey = pfKey,
				appid = (_G.platformName == "ios") and "ios_wechat" or "android_wechat",
				os = (_G.platformName == "ios") and 2 or 1,
			})
			--warn("account, pass ", account, pass)

			self.m_CombimeAppId = _G.platformName == "ios" and "ios_wechat" or "android_wechat"
			SaveMSDKInfo(MSDKInfo.APPID.WX, MSDKInfo.APPKEY.WX, openId, pf, pfKey, accessToken, payToken, "itopid", "itop")
		elseif loginPlatform == MSDK_LOGIN_PLATFORM.APPLE then --APPLE账号登陆
			channelid = 15
			account = openId.."$msdk_apple"
			self.m_CombimeAppId = _G.platformName == "ios" and "A_ios_qq" or ""
			SaveMSDKInfo("", "", openId, pf, pfKey, accessToken, payToken, "hy_gameid", "st_apple_v5")
		elseif loginPlatform == MSDK_LOGIN_PLATFORM.GUEST then --游客登陆
			channelid = 3
			local pass = Json.encode({
				token = SimpleEncryptEncodeText(accessToken),
				channelid = loginPlatform,
				pf = pf,
				pfkey = pfKey,
				appid = (_G.platformName == "ios") and "G_ios_qq" or "G_android_qq",
				os = (_G.platformName == "ios") and 2 or 1,
			})
			--warn("account, pass ", account, pass)

			local flag
			if openId:sub(1, 3) == "G_wx" then
				flag = "wechat"
			else
				flag = "qq"
			end
			account = openId.."$"..flag
			local loginflag = _G.platformName == "ios" and ("ios_" .. flag) or ("android_" .. flag)
			self.m_CombimeAppId = "G_" .. loginflag
			SaveMSDKInfo(nil, nil, openId, pf, pfKey, accessToken, payToken, "hy_gameid", "st_dummy")
		else
			account = ""
			SaveMSDKInfo(nil, nil, nil, nil, nil, nil, nil, nil, nil)
			Debug.LogWarning("Unkown Login Platform", loginPlatform)
		end
		MSDKRelation.Instance():Clear()
		MSDKRelation.Instance():QueryMyInfo()

		HttpDns.Init(MSDKInfo.Instance():GetMSDKInfo("appId"),true,2000)
		HttpDns.SetOpenId(MSDKInfo.Instance():GetMSDKInfo("openId"))

		globalGame.m_Network:SetUserName(account .. "#" .. _G.UsernamePlatform)
		globalGame.m_Network:SetAuth("")
		do	--计算并设置密码
			local info = {}
			info.token = self:GetMSDKInfo("accessToken")
			info.os = _G.UsernamePlatform == "android" and 1 or 2
			info.channelid = channelid
			info.pf = self:GetMSDKInfo("pf")
			info.pfkey = self:GetMSDKInfo("pfKey")
			info.appid = self:GetMSDKInfo("combineAppId")			-- self.m_CombimeAppId
			info.paytoken = self:GetMSDKInfo("payToken")
			info.openkey = self:GetMSDKInfo("accessToken")

			local psw = Json.encode(info)

			globalGame.m_Network:SetPassword(psw)
		end

		local MSDKNotify = require "MSDK.MSDKNotify"
		MSDKNotify.Instance():RegisterPushAccout("XG",MSDKInfo.Instance():GetMSDKInfo("openId"))

		game:OnHostPlayerCreate(function () MidasPay.Instance():UpdateLoginInfo() end)

		local MSDKEvent = require "Event.MSDKEvent"
		ECGame.EventManager:raiseEvent(nil, MSDKEvent.MSDKLoginSuccessEvent.new())

		ECGameSDK.Instance():OnLoginSuccess()
	end
	
	--print("success login & post GPM")
	--require "ProxySDK.ECGPMSDK".SetFirstData()
	require "MSDK.MSDKGPM".SetFirstData()
	
	self:RefreshMSDKTicket()
end

---@param self ECMSDK.MSDKLogin
---@param channelID number
---@param channel string
---@param qrCodeUrl string
---@return void
def.method("number", "string", "string").OnQrCodeNotify = function(self, channelID, channel, qrCodeUrl)
	local url_str = "start "
	if channel == "QQ" then
		url_str = url_str .. qrCodeUrl
	elseif channel == "WeChat" then
		url_str = url_str .. "https://cli.im/api/qrcode/code?text=" .. qrCodeUrl
	end

	os.execute(url_str)
end

local bWXFirstLogin = true
-- method 枚举参数 为   MSDKDefint.h  中的  typedef enum MSDK_EXPORT MethodName
---@param self ECMSDK.MSDKLogin
---@param flag number
---@param desc string
---@param openid string
---@param method number
---@return void
def.method("number", "string", "string","number").OnLoginError = function(self, flag, desc,openid, method)
	warn(("MSDKLoginError Flag = %d Desc = %s "):format(flag, desc))
	--print_hsh("method  ",method,type(method))
	DaizongSDK.LogStepLogReport(DAIZONG_STEPCODE.LOGIN_MSDK_LOGIN_FAILURE)
	GEMLogin.PostLoginStepEvent(GEMLogin.LoginStep.LOGIN_RESULT,false,DAIZONG_STEPCODE.LOGIN_MSDK_LOGIN_FAILURE,"msdk login failed")
	if method == 112 then
		MSDKLoginLimit.SetLastFailTimeAndCount()
	end

	-- local game = ECGame.Instance() 
	if flag == MSDK_LOGIN_ERROR_CODE.Local_Invalid then --登录数据失效
	elseif flag == MSDK_LOGIN_ERROR_CODE.Need_Select_Accout then --异账号
	elseif flag == MSDK_LOGIN_ERROR_CODE.Net_Work_Err then --网络异常
	elseif flag == MSDK_LOGIN_ERROR_CODE.Not_Support_Api then --你的手机QQ版本过低，请升级后再进入游戏
	elseif flag == MSDK_LOGIN_ERROR_CODE.WX_NotSupportApi then --你的微信版本过低，请升级后再进入游戏
	elseif flag == MSDK_LOGIN_ERROR_CODE.WX_TokenException then --
	   --if self.m_LoginPlatform == MSDK_LOGIN_PLATFORM.WX then
	   --   self:Login(MSDK_LOGIN_PLATFORM.WX)
	   --end
	elseif flag == MSDK_LOGIN_ERROR_CODE.WX_RefreshTokenExpired then
	elseif flag == MSDK_LOGIN_ERROR_CODE.QQ_UserCancel then--QQ取消登录授权
		-- 这样很蠢，但为了过平台
		local MSDKUtil = require "MSDK.MSDKUtil"
		if not MSDKUtil.Instance():IsAppInstalled(_G.MSDK_LOGIN_PLATFORM.QQ) and _G.platformName == "ios" and desc=="-1" then
			FlashTipMan.FlashTip(StringTable.Get(79998))
		end
	elseif flag == MSDK_LOGIN_ERROR_CODE.WX_UserCancel then--QQ取消登录授权
		if bWXFirstLogin then
			bWXFirstLogin = false
			FlashTipMan.FlashTip(StringTable.Get(79997))
		end
	elseif flag == MSDK_LOGIN_ERROR_CODE.WX_NotInstall then--微信没有安装
	elseif flag == 1003 then
	    if self.m_LoginPlatform == MSDK_LOGIN_PLATFORM.WX then
	        local _, _, _, _, _, tokens, _, _, _ = PCallMSDKFunction("getLoginRecord")
	        for k, v in pairs(tokens) do
	             if v.type == 3 then --微信accessToken
	                  warn("OnLoginError Refresh WX accessToken")
	                  self:SaveMSDKInfo("accessToken", v.value)
	                  break
	             end
	        end
	   end
	elseif flag == MSDK_LOGIN_ERROR_CODE.Server_Error then --登录失败，请检查账户名和密码
	   if self.m_TryLoginPlatform == MSDK_LOGIN_PLATFORM.EMAIL then
	   end
	elseif flag == MSDK_LOGIN_ERROR_CODE.TimeOut_Error then -- 登录超时，请重试
	   --ios网页登录，可能还在网页界面时就回调了，flashtip会看不到
	   -- MsgBox.ShowMsgBox(nil, StringTable.Get(3034), nil, MsgBox.MsgBoxType.MBBT_OK, function(sender, retval) end)
	end
	if flag ~= MSDK_LOGIN_ERROR_CODE.Local_Invalid then
	   -- _G.GSDKSetEvent(_G.GSDK_EVENT.MSDKAuth, false, desc, false, false)
	   -- ECGame.EventManager:raiseEvent(nil, MSDKEvent.MSDKLoginFailEvent.new())
	end
end

-- 应用唤醒回调
-- extInfo  游戏－平台携带的自定义参数手Q专用
---@param self ECMSDK.MSDKLogin
---@param flag number
---@param wakeupPlatform number
---@param mediaTagName string
---@param openId string
---@param desc string
---@param lang string
---@param country string
---@param messageExt string
---@param extInfo table
---@return void
def.method("number", "number", "string", "string", "string", "string", "string", "string", "table").OnWakeup = function(self, flag, wakeupPlatform, mediaTagName, openId, desc, lang, country, messageExt, extInfo)
    --print(("OnWakeup : %d, %d, %s, %s, %s, %s, %s, %s, %s"):format(MSDK.platform(), flag, wakeupPlatform, mediaTagName, openId, desc, lang, country, messageExt))
    --print_hsh(("OnWakeup : %d, %d, %s, %s, %s, %s, %s, %s, %s"):format(MSDK.platform(), flag, wakeupPlatform, mediaTagName, openId, desc, lang, country, messageExt))
	--print_hsh("messageExt   ",messageExt)
	--print_hsh("extInfo  ",extInfo)
    local SaveMSDKInfoEx = function(mediaTagName, messageExt, extInfo)
		self:SaveMSDKInfo("mediaTagName", mediaTagName)
		self:SaveMSDKInfo("messageExt", messageExt)
		self:SaveMSDKInfo("extInfo", extInfo)
	end
	--local _, _, _, _, _, tokens, _, pf, pfKey = PCallMSDKFunction("getLoginRecord")
	--local tokens = PCallMSDKFunction("getTokens")			-- 空的

    --print_hsh("OnWakeup  flag  ",flag)
	--print_hsh("tokens   ",tokens)		--都是空
	if flag == MSDK_LOGIN_ERROR_CODE.Succ or flag == MSDK_LOGIN_ERROR_CODE.AccountRefresh then
		--[[ 数据都是空，不知道调这个干嘛
		if wakeupPlatform == MSDK_LOGIN_PLATFORM.QQ then
			--openId, pf, pfKey, token, channelInfoJsonStr,regChannelDis
			self:OnLoginSuccess(wakeupPlatform, openId, pf, pfKey, tokens[1], tokens[2] or "", "")
		elseif wakeupPlatform == MSDK_LOGIN_PLATFORM.WX then
			self:OnLoginSuccess(wakeupPlatform, openId, pf, pfKey, tokens[3], "", "")
		elseif wakeupPlatform == MSDK_LOGIN_PLATFORM.GUEST then --游客登录
			self:OnLoginSuccess(wakeupPlatform, openId, pf, pfKey, tokens[6], "", "")
		end
		]]--
		SaveMSDKInfoEx(mediaTagName, messageExt, extInfo)
		self:SendPrivilegeType()
	elseif flag == MSDK_LOGIN_ERROR_CODE.Need_Select_Accout or flag == MSDK_LOGIN_ERROR_CODE.Need_Login_Accout then --异账号
		SaveMSDKInfoEx(mediaTagName, messageExt, extInfo)
		print_hsh("openId  ",openId)
		self:DifferentAccoutAction(wakeupPlatform, openId, messageExt)
	elseif flag == MSDK_LOGIN_ERROR_CODE.UrlLogin then
		SaveMSDKInfoEx(mediaTagName, messageExt, extInfo)
	elseif flag == MSDK_LOGIN_ERROR_CODE.Need_Login then
		SaveMSDKInfoEx(mediaTagName, messageExt, extInfo)
		self:Login(wakeupPlatform)
	else
		self:OnLoginError(flag, desc,"",119)
	end
end

--登出回调
---@param self ECMSDK.MSDKLogin
---@param flag number
---@return void
def.method("number").OnLogout = function(self, flag)
	local MSDKEvent = require "Event.MSDKEvent"
	ECGame.EventManager:raiseEvent(nil, MSDKEvent.MSDKLogoutEvent.new(self.m_LoginPlatform))

	--self:ClearTencentCenterInfo()
end

-- 清理账号信息
---@param self ECMSDK.MSDKLogin
---@return void
def.method().ClearTencentCenterInfo = function(self)
	-- 清一下平台记录信息
	self:SaveMSDKInfo("mediaTagName", "")
	self:SaveMSDKInfo("messageExt", "")
	self:SaveMSDKInfo("extInfo", "")
end

-- 账号bind回调
---@param self ECMSDK.MSDKLogin
---@param flag number
---@param thirdCode number
---@param confirmCode string
---@return void
def.method("number", "number", "string").OnBindNotify = function(self, flag, thirdCode, confirmCode)
	print("OnBindNotify Flag:",flag, thirdCode, confirmCode)
	if flag == 0 then --绑定成功
	elseif thirdCode == 1403 then --当前绑定账号已有游戏角色，无法绑定
	else --绑定失败
	end
	-- ECGame.EventManager:raiseEvent(nil, MSDKEvent.MSDKBindEvent.new(flag, thirdCode, confirmCode))
end

-- 账号操作回调(注册账号,修改密码)
---@param self ECMSDK.MSDKLogin
---@param flag number
---@param msg string
---@param methodId number
---@param thirdCode number
---@param thirdMsg string
---@return void
def.method("number", "string", "number", "number", "string").OnAccountNotify = function(self, flag, msg, methodId, thirdCode, thirdMsg)
	print("OnAccountNotify Flag:",flag, msg)
	-- ECGame.EventManager:raiseEvent(nil, MSDKEvent.MSDKAccountEvent.new(flag, msg, methodId, thirdCode, thirdMsg))
end

-- 存储信息
---@param self ECMSDK.MSDKLogin
---@param key string
---@param value any
---@return void
def.method("string", "dynamic").SaveMSDKInfo = function(self, key, value)
	MSDKInfo.Instance():SaveMSDKInfo(key, value)
end

-- 读取信息
---@param self ECMSDK.MSDKLogin
---@param key string
---@return any
def.method("string", "=>", "dynamic").GetMSDKInfo = function(self, key)
	return MSDKInfo.Instance():GetMSDKInfo(key) or ""
end

--给服务器同步平台特权
---@param self ECMSDK.MSDKLogin
---@return void
def.method().SendPrivilegeType = function(self)
	local pb_helper = require "PB.pb_helper"
	local client_msg = require "PB.client_msg"
	local msg = client_msg.npt_common_request()
	msg.request_type = 6 --通知平台特权
	local ECMSDK = require "MSDK.ECMSDK"
	msg.request_param = ECMSDK.GetLoginPrivilegeType()
	pb_helper.Send(msg)
end

local copenid_requestId = 0
--请求下游戏中心用的OpenID
---@param self ECMSDK.MSDKLogin
---@return void
def.method().GetCenterOpenIDByHTTP = function(self)
	local ECMSDK = require "MSDK.ECMSDK"
	local timestamp = os.time()
	local accessToken = ECMSDK.GetMSDKInfo("accessToken")
	local appID = ECMSDK.GetMSDKInfo("appId")
	local openID = ECMSDK.GetMSDKInfo("openId")

	--local loginPlat = self():GetLoginPlatform()
	local urlprefix = "https://itop.qq.com"
	local channelid = self.m_LoginPlatform
	local gameid = 16301
	local os_ = 1
	local seq = ""
	local source = 0
	local ts = timestamp
	local version = 2.0
	local sigKey = MSDKInfo.MSDKKey

	local data = {
		openid = openID,
		token = accessToken,
		--f_openid = fopenID,	--同渠道好友，可能会用来干别的事
	}

	local dataStr = Json.encode(data)

	local api = ("/v2/profile/openid2uid?channelid=%d&gameid=%d&os=%d&seq=%s&source=%d&ts=%s"):format(channelid, gameid, os_, seq, source, ts)
	--print("api", api)
	local sig = GameUtil.md5(api .. dataStr .. sigKey)
	--print("data", dataStr)
	--print("sign", sig)
	api = api .. "&sig="..sig

	copenid_requestId = copenid_requestId + 1

	self:SaveMSDKInfo("CenterOpenID", "")			-- 请求前先置空
	GameUtil.httpRequest("POST", urlprefix .. api, copenid_requestId, nil, dataStr, function(success, responseCode, url, Id, retdata)
		if success and copenid_requestId == tonumber(Id) then
			local info = Json.decode(GameUtil.byteArray2Str(retdata))
			if info and info.ret == 0 then
				print_hsh("GetCenterOpenIDByHTTP: Id, copenid = ", Id, info.uid)
				self:SaveMSDKInfo("CenterOpenID", info.uid)
			else
				--xinYueVipLevel = -1 -- -1: GotFromServer but Request return Failed
				print_hsh("GetCenterOpenIDByHTTP: ret!=0, ", tostring_r(info))
			end
		else
			print_hsh("GetCenterOpenIDByHTTP error: ", Id, responseCode)
		end
	end, "Content-Type", "application/json")

end

MSDKLogin.Commit()
return MSDKLogin
