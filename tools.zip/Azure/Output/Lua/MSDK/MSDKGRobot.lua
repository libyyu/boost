-------------------------------------------------------------------------------------------
-- GRobot SDK
-- 腾讯隐私小助手
-------------------------------------------------------------------------------------------

local Lplus = require "Lplus"
local Json = require "Utility.json"

---@class MSDKGRobot:System.Object
---@field public Commit fun():MSDKGRobot @notnull
---@field public Init fun()
---@field public OpenByClick fun()
---@field public Open fun(msg:table)
---@field public Close fun()
---@field public OnURL fun(json_str:string)
---@field public OnOpen fun()
---@field public OnClose fun()
local MSDKGRobot = Lplus.Class("MSDKGRobot")
local def = MSDKGRobot.define

-- 初始化标识
---@type boolean
local _init = false
-- 初始化
-- 设置回调
---@return void
def.static().Init = function()
	if GRobotSDK and not _init then
		_init = true

		GRobotSDK.SetUrlCallback(MSDKGRobot.OnURL)
		GRobotSDK.SetOpenCallback(MSDKGRobot.OnOpen)
		GRobotSDK.SetCloseCallback(MSDKGRobot.OnClose)
	end
end

-- 粗略的做个打开功能
---@return void
def.static().OpenByClick = function()
	local MSDKRelation = require "MSDK.MSDKRelation"
	local MSDKUtil = require "MSDK.MSDKUtil"
	local ECMSDK = require "MSDK.ECMSDK"
	local MSDKInfo = require "MSDK.MSDKInfo"
	local hp = globalGame:GetHostPlayer()
	local role_id = ZeroUInt64
	if hp and hp.ID then
		role_id = hp.ID
	end

	MSDKGRobot.Init()
	local msg = {}
	msg.msdkVer = 5
	msg.token = MSDKInfo.Instance():GetMSDKInfo("accessToken")
	msg.msdkSigKey = "29d42eaa176aeaded79194f2e8868fd6"
	msg.msdkGameId = "16301"
	msg.openId = ECMSDK.GetMSDKInfo("openId")
	msg.appId = "1110048757"
	msg.channelId = _G.LoginPlatform
	msg.platId = ECMSDK.GetPlatId()
	msg.partitionId = require "Main.ECZoneMan".Instance():GetZoneID(role_id)
	msg.areaId = MSDKUtil.Instance():GetAreaID(msg.partitionId)
	msg.roleId = LuaUInt64.ToString(role_id)
	msg.gameId = 1386
	msg.headerUrlStr = MSDKRelation.Instance().m_MyInfo.pictureSmall
	print_hsh("msg  ",msg)
	MSDKGRobot.Open(msg)
end

-- 开启
---@param msg table
---@return void
def.static("table").Open = function(msg)
	if _init then
		local Json = require "Utility.json"
		local str = Json.encode(msg)
		GRobotSDK.Open(str)
	end
end

---@return void
def.static().Close = function()
	if _init then
		GRobotSDK.Close()
	end
end


---@param json_str string
---@return void
def.static("string").OnURL = function(json_str)
	warn("GRobot OnURL ",json_str)
	local msg = Json.decode(json_str)
	if msg.type == "ModifyPersonalInfo" then
		require "GUI.Setting.ECPanelChangeRoleName".Instance():ShowPanelSimple(true)
	elseif msg.type == "CancelAccount" then
		local ECSettingSocialPage = require "GUI.Setting.ECSettingSocialPage"
		ECSettingSocialPage.Instance():OnClickCancelAccountURL()
	end
end

---@return void
def.static().OnOpen = function()
	warn("GRobot OnOpen ")
end

---@return void
def.static().OnClose = function()
	warn("GRobot OnClose ")
end

MSDKGRobot.Commit()
return MSDKGRobot
