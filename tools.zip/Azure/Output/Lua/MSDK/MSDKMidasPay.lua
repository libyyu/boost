-------------------------------------------------------------------------------------------
-- Midas支付
-------------------------------------------------------------------------------------------

local Lplus = require "Lplus"
local MSDKInfo = require("MSDK.MSDKInfo")
local MSDKUtil = require("MSDK.MSDKUtil")
local MSDKEvent = require "Event.MSDKEvent"
local pb_helper = require "PB.pb_helper"
local client_msg = require "PB.client_msg"
local Json = require "Utility.json"
---@type ECGame
local ECGame = Lplus.ForwardDeclare("ECGame")
---@type ECMSDK.MSDKLogin
local MSDKLogin = Lplus.ForwardDeclare("ECMSDK.MSDKLogin")

---@class ECMSDK.MidasPay:System.Object
---@field protected m_DataJson string
---@field protected m_LastZoneId string
---@field public Commit fun():ECMSDK.MidasPay @notnull
---@field public Instance fun():ECMSDK.MidasPay
---@field public GetMarketData fun(self:ECMSDK.MidasPay):string
---@field public RegisterMidas fun(self:ECMSDK.MidasPay, env:string):boolean
---@field public PayByParams fun(self:ECMSDK.MidasPay, payParams:table)
---@field public Pay fun(self:ECMSDK.MidasPay, heroLv:string, heroId:string, zoneId:string, offerId:string, payParams:table)
---@field public GetPayToken fun(self:ECMSDK.MidasPay):string
---@field public GetMarketInfo fun(self:ECMSDK.MidasPay)
---@field public UpdateLoginInfo fun(self:ECMSDK.MidasPay)
---@field public SendMidasInfo fun(self:ECMSDK.MidasPay)
---@field public OnPayCallback fun(self:ECMSDK.MidasPay, retcode:number, msg:string, realSaveNum:number, payChannel:number, payState:number, provideState:number, extendInfo:string)
---@field public OnPayNeedLogin fun(self:ECMSDK.MidasPay)
---@field public OnMarketJsonInfo fun(self:ECMSDK.MidasPay, jsonResult:string)
---@field public Clear fun(self:ECMSDK.MidasPay)
local MidasPay = Lplus.Class("ECMSDK.MidasPay")
local def = MidasPay.define

local PCallMSDKFunction = function(FunctionName, ...)
	if MSDK and MSDK[FunctionName] then
		return MSDK[FunctionName](...)
	else
		warn(("There is no function = %s in MSDK"):format(FunctionName))
		return nil
	end
end

---@type string
def.field("string").m_DataJson = ""

---@type string
def.field("string").m_LastZoneId = ""


local instance = nil
---@return ECMSDK.MidasPay
def.static("=>", MidasPay).Instance = function()
	if not instance then
		instance = MidasPay()
	end
	return instance
end

---@param self ECMSDK.MidasPay
---@return string
def.method("=>", "string").GetMarketData = function(self)
	return self.m_DataJson
end

-- 注册支付功能
-- 1. 设置sdk支付流程，走国内还是海外 (在extra参数中设置)
-- 2. 支付sdk初始化，在使用Midas其它接口之前必须调用一次init初始化操作（可重复调用）。
-- param offerId 米大师的支付ID，可以在midas.oa.com里查看到 必须设置
-- param env 环境参数设置：现网环境“release”，沙箱”test”.建议应用在接入时先在沙箱环境测试通过后，切换至release再发布。
-- param zoneId 游戏服务器大区id (需设置为字符串类型)
---@param self ECMSDK.MidasPay
---@param env string
---@return boolean
def.method("string", "=>", "boolean").RegisterMidas = function(self, env)
	local offerId = MSDKInfo.Instance():GetMSDKInfo("offerId")
	local zoneId = tostring(glb_GetZoneID() or 0)
	local pf = MSDKInfo.Instance():GetMSDKInfo("pf")
	local pfKey = MSDKInfo.Instance():GetMSDKInfo("pfKey")
	local openId = MSDKInfo.Instance():GetMSDKInfo("openId")
	local sessionId = MSDKInfo.Instance():GetMSDKInfo("sessionId")
	local sessionType = MSDKInfo.Instance():GetMSDKInfo("sessionType")
	local openKey = self:GetPayToken()
	self.m_LastZoneId = zoneId
	print(("register midas offerId[%s], openId[%s], sessionId[%s], sessionType[%s], pf[%s], pfKey[%s], env[%s]"):format(
		offerId, openId, sessionId, sessionType, pf, pfKey, env))
	local extra = {
		idc = "local", --米大师IDC，即米大师服务所在国家，目前支持香港、加拿大、越南、日本等,其中国内为“local”。
		zoneId = zoneId, --游戏服务器大区id (需设置为字符串类型)
		logEnable = "false", -- 米大师调试日志是否打开, 值:true; false
		processName = "local", -- (必填) 是国内版本还是海外版本. 国内: local; 海外: sea
		payChannel = "os_offical", -- 指定支付渠道。(不需要指定支付渠道可不传)
		goodsZoneId = "0", --由业务自定义idip发货的partition小区和角色，如1001_角色id
		currencyType = "",
		country = "",
		idc = "local",
		idcInfo = "",
	}
	-- 注册支付功能接口说明, 包含功能
	-- 1. 设置sdk支付流程，走国内还是海外 (在extra参数中设置)
	-- 2. 支付sdk初始化，在使用Midas其它接口之前必须调用一次init初始化操作（可重复调用）。
	-- 参数信息:
	-- param offerId 米大师的支付ID，可以在midas.oa.com里查看到 必须设置
	-- param openId 用户帐号openid
	-- param openKey 手机QQ登陆，传入paytoken；微信登陆，传入accesstoken；游客，可以是一个随机值；
	-- param sessionId, sessionType (玩家登陆后,在login模块设置)
	--      登陆态帐号类型，sessionId和sessionType匹配使用： 
	-- 	    手机QQ登陆：sessionId=“openid”，sessionType=“kp_actoken”
	-- 	    微信登陆：sessionId="hy_gameid"，sessionType=“wc_actoken”
	-- 	    游客：sessionId="hy_gameid"，sessionType=“st_dummy” //海外发布时一般为Guest登陆态
	-- 	    itop登录（统一了手Q登录和微信登录）：sessionId="itopid"，sessionType=“itop” //openid为msdk的gopenid，微信登录openkey传入accesstoken;手Q登录openkey传入paytoken
	-- param pf 平台标识信息：Pf=  平台 + 注册渠道 + 版本 + 安装渠道 + 业务标识(自定义)
	-- param pfKey 由平台直接传给应用，应用原样传给平台即可. 自研应用不校验，可以传递为pfKey=“pfKey”; 非自研强校验,pfKey=”58FCB2258B0BF818008382BD025E8022”（来自平台）
	-- param env 环境参数设置：现网环境“release”，沙箱”test”.建议应用在接入时先在沙箱环境测试通过后，切换至release再发布。
	-- param extra:
	--        logEnable: 设置米大师调试日志是否打开, 值:true; false
	--        zoneId: 游戏服务器大区id,游戏不分大区则默认zoneId ="1",String类型。如果应用选择支持角色，则角色接在分区ID号后用"_"连接，角色需要进行urlencode。
	--        appExtends: IOS使用，相当于原参数vartiem="drm_info=version%3d3.0" 包月业务为了方便统计提供的透传字段: appExtends ="remark=xxx"
	--        channelExtras: 透传给第三方支付渠道需要的参数，比如roleid，rolename等
	--        goodsZoneId: 由业务自定义idip发货的partition小区和角色，如1001_角色id
	--        currencyType: 指定的货币类型。米大师后台会根据货币类型来过滤物品。(国内此参数不传)
	--        country: 指定的国家。米大师后台会根据国家来过滤支付渠道(国内此参数不传)
	--        payChannel:指定支付渠道。(不需要指定支付渠道可不传)
	--        processName: (必填) 是国内版本还是海外版本. 国内: local; 海外: sea
	--        idc: 米大师IDC，即米大师服务所在国家，目前支持香港、加拿大、越南、日本等,其中国内为“local”。
	--        idcInfo: 主要用于多区域部署时业务可由后台下发IP域名配置，json格式，由midas提供。为空时会取客户端预埋IP进行连接。
	return PCallMSDKFunction("registerPay", offerId, openId, openKey, sessionId, sessionType, pf, pfKey, env, extra)
end

---@param self ECMSDK.MidasPay
---@param payParams table
---@return void
def.method("table").PayByParams = function(self, payParams)
	local zoneId = tostring(glb_GetZoneID() or 0)
	local offerId = MSDKInfo.Instance():GetMSDKInfo("offerId")
	local heroLv = tostring(ECGame.Instance().m_HostPlayer.InfoData.Lv)
	local heroId = LuaUInt64.ToString(ECGame.Instance():GetHostPlayerID())

	self:Pay(heroLv,heroId,zoneId,offerId,payParams)
end

-- Midas支付接口
-- param heroLv 玩家的等级
-- param heroId 玩家的ID
-- param zoneId 游戏服务器大区id
-- param offerId 米大师的支付ID，可以在midas.oa.com里查看到 必须设置
-- param payParams参数说明:
-- 		payType 购买类型(参照MSDKInfo.PAYTYPE)
-- 		productID 物品ID
-- 		durtime 道具，传“物品ID*单价(单位：角)*数量”；月卡，传“天数”；游戏币，传“数量” (Only For iOS)
-- 		serviceCode 月卡业务代码 (月卡专用)
-- 		serviceName 月卡业务名称 (月卡专用)
-- 		autoPay 是否自动续费，默认为false，不自动续费 (月卡专用)
---@param self ECMSDK.MidasPay
---@param heroLv string
---@param heroId string
---@param zoneId string
---@param offerId string
---@param payParams table
---@return void
def.method("string", "string", "string", "string", "table").Pay = function(self, heroLv, heroId, zoneId, offerId, payParams)
	self:UpdateLoginInfo()
	local payToken = self:GetPayToken()
	local openId = MSDKInfo.Instance():GetMSDKInfo("openId")
	local sessionId = MSDKInfo.Instance():GetMSDKInfo("sessionId")
	local sessionType = MSDKInfo.Instance():GetMSDKInfo("sessionType")
	local channelId = MSDKUtil.Instance():GetChannelID()
	local pf = MSDKInfo.Instance():GetMSDKInfo("pf")..("-%d_%s_%d_%s"):format(heroLv, channelId, zoneId, heroId)
	local pfKey = MSDKInfo.Instance():GetMSDKInfo("pfKey")

	print("ECMSDK-Pay zoneId:", zoneId, self.m_LastZoneId)
	--if zoneId ~= self.m_LastZoneId then
	--	warn("pay and init not equal, reinit")
	--	self:RegisterMidas(_G.TEST_PAY_ENV and "test" or "release")
	--end
	-- ECMSDK.ReportEvent(ECMSDK.EventType.PurchaseStart)
	local extrasTab = {uiconfig = {isCanChange = false}}
	if _G.platform == PLATFORM_TYPE_ANDROID or _G.platform == PLATFORM_TYPE_IOS then
		if payParams.payType == MSDKInfo.PAYTYPE.CYCLE then --购买月卡、道具
			-- param offerId 米大师的支付ID，可以在midas.oa.com里查看到 必须设置
			-- param openId 用户帐号openid
			-- param openKey 手机QQ登陆，传入paytoken；微信登陆，传入accesstoken；游客，可以是一个随机值；
			-- param sessionId, sessionType 登陆态帐号类型，sessionId和sessionType匹配使用：
			-- 	手机QQ登陆：sessionId=“openid”，sessionType=“kp_actoken”
			-- 	微信登陆：sessionId="hy_gameid"，sessionType=“wc_actoken”
			-- 	游客：sessionId="hy_gameid"，sessionType=“st_dummy” //海外发布时一般为Guest登陆态
			-- 	itop登录（统一了手Q登录和微信登录）：sessionId="itopid"，sessionType=“itop” //openid为msdk的gopenid，微信登录openkey传入accesstoken;手Q登录openkey传入paytoken
			-- param zoneId: 游戏服务器大区id,游戏不分大区则默认zoneId ="1",String类型。如果应用选择支持角色，则角色接在分区ID号后用"_"连接，角色需要进行urlencode。
			-- param pf 平台标识信息：Pf=  平台 + 注册渠道 + 版本 + 安装渠道 + 业务标识(自定义)
			-- param pfKey 由平台直接传给应用，应用原样传给平台即可. 自研应用不校验，可以传递为pfKey=“pfKey”; 非自研强校验,pfKey=”58FCB2258B0BF818008382BD025E8022”（来自平台）
			-- param productid 物品ID
			-- param payItem 道具，传“物品ID*单价(单位：角)*数量”；月卡，传“天数”；游戏币，传“数量” (Only For iOS)
			-- param saveValue 购买数量。如果值 为null或””，将展示midas的商城页 (Onley For Android国内)
			-- param currencyType: 指定的货币类型。米大师后台会根据货币类型来过滤物品。(国内此参数不传)
			-- param country: 指定的国家。米大师后台会根据国家来过滤支付渠道(国内此参数不传)
			-- param payChannel:指定支付渠道。(不需要指定支付渠道可不传)
			-- param channelExtras: 透传给第三方支付渠道需要的参数，比如roleid，rolename等
			-- param appExtends: IOS使用，相当于原参数vartiem="drm_info=version%3d3.0" 包月业务为了方便统计提供的透传字段: appExtends ="remark=xxx"
			-- param goodsZoneId: 由业务自定义idip发货的partition小区和角色，如1001_角色id
			-- param serviceCode 月卡业务代码。
			-- param serviceName 月卡业务名称
			-- param extras 扩展信息
			-- param autoPay 是否自动续费，默认为false，不自动续费
			-- param serviceType SERVICETYPE_NORMAL = 1 //开通包月; SERVICETYPE_RENEW = 2 //续费; SERVICETYPE_UPGRADE = 3 //升级
			local extras = Json.encode(extrasTab)-- [[{"uiconfig":{"isCanChange":false}}]]
			PCallMSDKFunction("paySubscribe", offerId, openId, payToken, sessionId, sessionType, zoneId, pf, pfKey, payParams.productID,
					payParams.durtime, payParams.saveValue, "", "", "", "payItem="..payParams.durtime, "payItem="..payParams.durtime, "0", payParams.serviceCode,
					payParams.serviceName, extras,payParams.autoPay, 1)
			--[[
			warn("MSDKMidasPay.Pay:      ","offerId: ",offerId,
					"\npayParams:\n        payParams.payType: ",payParams.payType,
					"\n       payParams.productID: ",payParams.productID,
					"\n       payParams.durtime: ",payParams.durtime,
					"\n       payParams.serviceCode: ",payParams.payType,
					"\n       payParams: payParams.saveValue: ",payParams.saveValue,
					"\n       ",
					"\npf:  ",pf,
					"\npfKey:  ",pfKey,
					"\nopenId:  ",openId,
					"\npayToken:  ", SimpleEncryptEncodeText(payToken),
					"\nsessionId:  ",sessionId,
					"\nzoneId:  ",zoneId
			)
			]]--
		else -- 购买虚拟币
			-- param offerId 米大师的支付ID，可以在midas.oa.com里查看到 必须设置
			-- param openId 用户帐号openid
			-- param openKey 手机QQ登陆，传入paytoken；微信登陆，传入accesstoken；游客，可以是一个随机值；
			-- param sessionId, sessionType
			--      登陆态帐号类型，sessionId和sessionType匹配使用：
			-- 	手机QQ登陆：sessionId=“openid”，sessionType=“kp_actoken”
			-- 	微信登陆：sessionId="hy_gameid"，sessionType=“wc_actoken”
			-- 	游客：sessionId="hy_gameid"，sessionType=“st_dummy” //海外发布时一般为Guest登陆态
			-- 	itop登录（统一了手Q登录和微信登录）：sessionId="itopid"，sessionType=“itop” //openid为msdk的gopenid，微信登录openkey传入accesstoken;手Q登录openkey传入paytoken
			-- param zoneId: 游戏服务器大区id,游戏不分大区则默认zoneId ="1",String类型。如果应用选择支持角色，则角色接在分区ID号后用"_"连接，角色需要进行urlencode。
			-- param pf 平台标识信息：Pf=  平台 + 注册渠道 + 版本 + 安装渠道 + 业务标识(自定义)
			-- param pfKey 由平台直接传给应用，应用原样传给平台即可. 自研应用不校验，可以传递为pfKey=“pfKey”; 非自研强校验,pfKey=”58FCB2258B0BF818008382BD025E8022”（来自平台）
			-- param productid 物品ID
			-- param payItem 道具，传“物品ID*单价(单位：角)*数量”；月卡，传“天数”；游戏币，传“数量” (Only For iOS)
			-- param saveValue 购买数量。如果值 为null或””，将展示midas的商城页 (Onley For Android国内)
			-- param currencyType: 指定的货币类型。米大师后台会根据货币类型来过滤物品。(国内此参数不传)
			-- param country: 指定的国家。米大师后台会根据国家来过滤支付渠道(国内此参数不传)
			-- param payChannel:指定支付渠道。(不需要指定支付渠道可不传)
			-- param channelExtras: 透传给第三方支付渠道需要的参数，比如roleid，rolename等
			-- param appExtends: IOS使用，相当于原参数vartiem="drm_info=version%3d3.0" 包月业务为了方便统计提供的透传字段: appExtends ="remark=xxx"
			-- param goodsZoneId: 由业务自定义idip发货的partition小区和角色，如1001_角色id
			PCallMSDKFunction("payCoin", offerId, openId, payToken, sessionId,	sessionType, zoneId, pf, pfKey, payParams.productID,
					payParams.durtime, payParams.saveValue, "", "", "",	"payItem="..payParams.durtime, "payItem="..payParams.durtime, "0")
			--[[warn("MSDKMidasPay.Pay:      ","offerId: ",offerId,
					"\npayParams:\n        payParams.payType: ",payParams.payType,
					"\n       payParams.productID: ",payParams.productID,
					"\n       payParams.durtime: ",payParams.durtime,
					"\n       payParams.serviceCode: ",payParams.payType,
					"\n       payParams: payParams.saveValue: ",payParams.saveValue,
					"\n       ",
					"\npf:  ",pf,
					"\npfKey:  ",pfKey,
					"\nopenId:  ",openId,
					"\npayToken:  ",SimpleEncryptEncodeText(payToken),
					"\nsessionId:  ",sessionId,
					"\nzoneId:  ",zoneId
                    )]]--
        end
    --elseif _G.platform == PLATFORM_TYPE_IOS then
	--	PCallMSDKFunction("payCoin", offerId, openId, payToken, sessionId,	sessionType, zoneId, pf, pfKey, payParams.productID,
	--			payParams.durtime, payParams.saveValue, "", "", "",	"payItem="..payParams.durtime, "payItem="..payParams.durtime, "0")
		--[[
		print_hsh("MSDKMidasPay.Pay:      ","offerId: ",offerId,
				"\npayParams:\n        payParams.payType: ",payParams.payType,
				"\n       payParams.productID: ",payParams.productID,
				"\n       payParams.durtime: ",payParams.durtime,
				"\n       payParams.serviceCode: ",payParams.payType,
				"\n       payParams: payParams.saveValue: ",payParams.saveValue,
				"\n       ",
				"\npf:  ",pf,
				"\npfKey:  ",pfKey,
				"\nopenId:  ",openId,
				"\npayToken:  ", SimpleEncryptEncodeText(payToken),
				"\nsessionId:  ",sessionId,
				"\nzoneId:  ",zoneId
		)
		]]--
	end
end

--获取支付token
---@param self ECMSDK.MidasPay
---@return string
def.method("=>", "string").GetPayToken = function(self)
	local payToken = MSDKInfo.Instance():GetMSDKInfo("payToken")
	return payToken == "" and MSDKInfo.Instance():GetMSDKInfo("accessToken") or payToken
end

-- 拉取营销活动信息
-- 从Midas营销平台拉取首充、满赠、限次等营销活动的配置信息
-- param offerId 米大师的支付ID，可以在midas.oa.com里查看到
-- param zoneId 游戏服务器大区id
---@param self ECMSDK.MidasPay
---@return void
def.method().GetMarketInfo = function(self)
	local offerId = MSDKInfo.Instance():GetMSDKInfo("offerId")
	local payToken = self:GetPayToken()
	local openId = MSDKInfo.Instance():GetMSDKInfo("openId")
	local sessionId = MSDKInfo.Instance():GetMSDKInfo("sessionId")
	local sessionType = MSDKInfo.Instance():GetMSDKInfo("sessionType")
	local pf = MSDKInfo.Instance():GetMSDKInfo("pf")
	local pfKey = MSDKInfo.Instance():GetMSDKInfo("pfKey")
	local zoneId = tostring(glb_GetZoneID() or 0)
	-- 接口参数说明:
	-- param offerId 米大师的支付ID，可以在midas.oa.com里查看到 必须设置
	-- param openId 用户帐号openid
	-- param openKey 手机QQ登陆，传入paytoken；微信登陆，传入accesstoken；游客，可以是一个随机值；
	-- param sessionId, sessionType
	--  登陆态帐号类型，sessionId和sessionType匹配使用：
	-- 	手机QQ登陆：sessionId=“openid”，sessionType=“kp_actoken”
	-- 	微信登陆：sessionId="hy_gameid"，sessionType=“wc_actoken”
	-- 	游客：sessionId="hy_gameid"，sessionType=“st_dummy” //海外发布时一般为Guest登陆态
	-- 	itop登录（统一了手Q登录和微信登录）：sessionId="itopid"，sessionType=“itop” //openid为msdk的gopenid，微信登录openkey传入accesstoken;手Q登录openkey传入paytoken
	-- param zoneId: 游戏服务器大区id,游戏不分大区则默认zoneId ="1",String类型。如果应用选择支持角色，则角色接在分区ID号后用"_"连接，角色需要进行urlencode。
	-- param pf 平台标识信息：Pf=  平台 + 注册渠道 + 版本 + 安装渠道 + 业务标识(自定义)
	-- param pfKey 由平台直接传给应用，应用原样传给平台即可. 自研应用不校验，可以传递为pfKey=“pfKey”; 非自研强校验,pfKey=”58FCB2258B0BF818008382BD025E8022”（来自平台）
	-- param reqType type为“mp”(GetInfo的type参数)
	PCallMSDKFunction("getMarketInfo", offerId, openId, payToken, sessionId, sessionType, zoneId, pf, pfKey, "mp")
end

-- 更新Token
---@param self ECMSDK.MidasPay
---@return void
def.method().UpdateLoginInfo = function(self)
	local npt_update_login_status = client_msg.npt_update_login_status
	local msg = npt_update_login_status()
	msg.openkey = MSDKInfo.Instance():GetMSDKInfo("accessToken")
	msg.paytoken = self:GetPayToken()
	--print_hsh("UpdateLoginInfo payToken", msg.paytoken)
	msg.pf = MSDKInfo.Instance():GetMSDKInfo("pf")
	msg.pfkey = MSDKInfo.Instance():GetMSDKInfo("pfKey")
	pb_helper.Send(msg)
end

---@param self ECMSDK.MidasPay
---@return void
def.method().SendMidasInfo = function(self)
	local npt_notify_recharge = client_msg.npt_notify_recharge
	local msg = npt_notify_recharge()
	msg.appid = MSDKInfo.Instance():GetMSDKInfo("combineAppId")

	local ECPayManager = require "Main.ECPayManager"
	local _,data = ECPayManager.GetNearlyPay()
	if data and data.rechargeData and data.rechargeData.service_code then
		msg.service_code = data.rechargeData.service_code
	end
	print_hsh("SendMidasInfo : ", msg)
	pb_helper.Send(msg)
end

-- QQ心悦会员(此接口暂未整理)
-- def.method().QQXinYueVIP = function(self)
-- 	local gameId = 80
-- 	local openId = ECMSDK.GetMSDKInfo("openId")
-- 	local accessToken = ECMSDK.GetMSDKInfo("accessToken")
-- 	local appId = ECMSDK.GetMSDKInfo("appId")
-- 	local loginType = ECMSDK.GetLoginPlatform() == MSDK_LOGIN_PLATFORM.QQ and 1 or 2 --默认QQ登录为1


-- 	local gameInstance = ECGame.Instance()
-- 	local opencode = GameUtil.Base64Encode(openId .. "," .. accessToken .. "," .. appId .. "," .. loginType)
-- 	local zoneId = gameInstance.m_ZoneID
-- 	local hp = gameInstance.m_HostPlayer
-- 	ECMSDK.OpenURL(("textRes.Common.xinyue_vip"):format(gameId, opencode, zoneId, LuaInt64.ToString(hp.ID)))
-- end

-------------------------------------------------------------------------------------
-- 相关回调
-------------------------------------------------------------------------------------

--Midas支付回调
-- param retcode 结果码(对应APMidasResponse.retcode)
-- param msg 返回信息(对应APMidasResponse.resultMsg)
-- param realSaveNum game coin quantity(对应APMidasResponse.realSaveNum)
-- param payChannel 渠道(暂没有使用, APMidasResponse.payChannel)
-- param payState (暂没有使用)
-- param provideState (暂没有使用)
-- param extendInfo 扩展信息(APMidasResponse.appExtends)
---@param self ECMSDK.MidasPay
---@param retcode number
---@param msg string
---@param realSaveNum number
---@param payChannel number
---@param payState number
---@param provideState number
---@param extendInfo string
---@return void
def.method("number", "string", "number", "number", "number", "number", "string").OnPayCallback = function(self, retcode, msg, realSaveNum, payChannel, payState, provideState, extendInfo)
	print_hsh(("OnPayCallback retcode = %d ,msg = %s, realSaveNum = %d, payChannel = %d, payState = %d, provideState = %d, extendInfo = %s"):format(retcode, msg, realSaveNum, payChannel, payState, provideState, extendInfo))
	local notifyRechargeOnFail = false
	if retcode == MSDK_PAY_CODE.PAY_SUCCESS then
		-- 支付成功
		local event = MSDKEvent.MSDKPaySuccessEvent.new()
		event.save_num = tonumber(realSaveNum)
		event.extend_info = extendInfo
		ECGame.EventManager:raiseEvent(nil, event)
		-- FlashTipMan.FlashTip(StringTable.Get(3028))
		-- ECMSDK.ReportEvent(ECMSDK.EventType.PurchaseSuccess)
		return
	elseif retcode == MSDK_PAY_CODE.PAY_WARNING1 then
		-- 你的账户涉嫌第三方代充，点券无法到账，请你自行向第三方充值平台进行售后维权。若有疑问，请到到官方论坛按照论坛指引提交申诉材料
	elseif retcode == MSDK_PAY_CODE.PAY_WARNING2 then
		-- 你的账户涉嫌第三方代充，帐号已被封停，无法登录！请你自行向第三方充值平台进行售后维权。若有疑问，请到到官方论坛根据指引提交申诉材料
	elseif retcode == MSDK_PAY_CODE.PAY_WARNING3 then
		-- 你的账户涉嫌第三方违规代充，点券无法到账, 请你自行向第三方充值平台进行售后维权，再次违规将永久封号处罚。若有疑问，请到到官方论坛按照论坛指引提交申诉材料
	else

	end

	local payFailEvent = MSDKEvent.MSDKPayFailEvent.new()
	-- --maybe is network error, and the payment maybe finish in serverside, so just try notify charge
	payFailEvent.notify_charge = notifyRechargeOnFail
	ECGame.EventManager:raiseEvent(nil, payFailEvent)
end

-- 支付需要登录时的回调
-- 在支付过程中如果检测到登录态失效则回调。支付SDK不会主动重新发起登录，需要接入业务通过此接口来通知用户重新登录。
---@param self ECMSDK.MidasPay
---@return void
def.method().OnPayNeedLogin = function(self)
	-- MsgBox.ShowMsgBox(nil, StringTable.Get(2610), StringTable.Get(1850), MsgBoxType.MBBT_OK, function(sender, retval)
	-- 	if retval == MsgBox.MsgBoxRetT.MBRT_OK then
	-- 		if ECMSDK.GetLoginPlatform() == MSDK_LOGIN_PLATFORM.WX then
	-- 			ECMSDK.Login(MSDK_LOGIN_PLATFORM.WX)
	-- 		else
	-- 			ECMSDK.UserLogOut()
	-- 			ECGame.LogoutGame()
	-- 		end
	-- 	end
	-- end)
end

-- GetInfo的回调
---@param self ECMSDK.MidasPay
---@param jsonResult string
---@return void
def.method("string").OnMarketJsonInfo = function(self, jsonResult)
	print("OnMarketJsonInfo ", jsonResult)
	self.m_DataJson = jsonResult
	if jsonResult == "" then return end
	local json = require "Utility.json"
	local market = json.decode(self.m_DataJson)
	if market.ret == 1018 then
		print_hsh("market.res  ",market.msg)
		if require "Misc.TencentCloudGameUtil".IsH5CloudGame() then	--H5 可能会有这个问题，相关方要求屏蔽报错
		else
			MsgBox.ShowMsgBox(self, StringTable.Get(79996), nil, MsgBox.MsgBoxType.MBBT_OKCANCEL, function (sender, ret)
				if ret == MsgBoxRetT.MBRT_OK then
					--MSDKLogin.Instance():ExitToLogOut()
					MSDKLogin.Instance():Login(_G.LoginPlatform)
				end
			end)
		end
	end
	ECGame.EventManager:raiseEvent(nil, MSDKEvent.MSDKMarketDataEvent.new())
end

---@param self ECMSDK.MidasPay
---@return void
def.method().Clear = function(self)
	self.m_DataJson = nil
end

MidasPay.Commit()
return MidasPay
