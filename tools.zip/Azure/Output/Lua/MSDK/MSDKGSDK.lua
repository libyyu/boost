-------------------------------------------------------------------------------------------
-- GSDK相关接口
-- 目前没有找到GSDK的任何相关实现
-------------------------------------------------------------------------------------------

local Lplus = require "Lplus"
local GSDK = Lplus.Class("ECMSDK.GSDK")
-- local ECMSDK = Lplus.ForwardDeclare("ECMSDK")
-- local MSDKInfo = Lplus.ForwardDeclare("ECMSDK.MSDKInfo")

local def = GSDK.define
local instance = nil

local PCallGSDKFunction = function(FunctionName, ...)
  if GSDKWrapper and GSDKWrapper[FunctionName] then
       print("call gsdk function ", FunctionName, ...)
       return GSDKWrapper[FunctionName](...)
  else
       warn(("There is no function = %s in GSDK"):format(FunctionName))
       return nil
  end 
end

def.static("=>", GSDK).Instance = function()
  if not instance then
       instance = GSDK()
  end
  return instance
end

def.method("boolean").InitGSDK = function(self, debug) --初始化放到C#
	-- local appId = MSDKInfo.APPID.QQ
	-- PCallGSDKFunction("Init", appId, debug, 1)
end

def.method().GSDKSetUserName = function(self) 
	-- local openId = ECMSDK.GetMSDKInfo("openId")
	-- if openId ~= "" then
	-- 	PCallGSDKFunction("SetUserName", ECMSDK.GetLoginPlatform(), openId)
	-- else
	-- 	warn("GSDKSetUserName Don't have openId")
	-- end
end

def.method("boolean").GSDKBackAndFront = function(self, pauseStatus)
	-- if pauseStatus then
	-- 	self:GSDKEnd()
	-- else
	-- 	self:GSDKStart()
	-- end  
end

def.method().GSDKStart = function(self)
	-- local gameInstance = ECGame.Instance()
	-- local zoneId = gameInstance.m_ZoneID
	-- if zoneId > 0 then
	-- 	local serverIp = gameInstance.m_ServerIP
	-- 	local serverPort = gameInstance.m_ServerPort
	-- 	local worldId = gameInstance.m_curWorldTid
	-- 	if worldId > 0 then 
	-- 		local frameRate = ""
	-- 		local qualityLevel = _G.cur_quality_level
	-- 		local serverAddress = serverIp .. ":" .. serverPort
	-- 		local qualityStr = ""
	-- 		if qualityLevel <= 3 then
	-- 			qualityStr = "Low"
	-- 		elseif qualityLevel == 4 then
	-- 			qualityStr = "Medium"
	-- 		elseif qualityLevel >= 5 then
	-- 			qualityStr = "High"
	-- 		end
	-- 		PCallGSDKFunction("Start", zoneId, ("%d_%s_%s"):format(worldId, frameRate, qualityStr), serverAddress)
	-- 	end
	-- end
end

def.method().GSDKEnd = function(self)
	PCallGSDKFunction("End")
end

def.method("number", "boolean", "string", "boolean", "boolean").SetGSDKEvent = function(self, tag, status, msg, isAuth, isLogin)
	PCallGSDKFunction("SetEvent", tag, status, msg, isAuth, isLogin)
end

def.method("=>", "string").GSDKGetCpuList = function(self)
	return PCallGSDKFunction("GetCpuList")
end

def.method("=>", "string").GSDKGetMemList = function(self)
	return PCallGSDKFunction("GetMemList")
end

def.method("=>", "string").GSDKGetFpsInfo = function(self)
	return PCallGSDKFunction("GetFpsInfo")
end

def.method("=>", "string").GSDKGetUdpList = function(self)
	return PCallGSDKFunction("GetUdpList")
end

GSDK.Commit()
return GSDK
