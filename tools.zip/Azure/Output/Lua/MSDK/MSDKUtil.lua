-------------------------------------------------------------------------------------------
-- MSDK工具模块
-- 工具模块主要提供一些常用的工具方法，比如判断 App 是否安装， 其中 IsAppInstalled 是同步调用，不需要回调。
-- 
-- MSDK扩展模块
-- MSDK 提供扩展模块用于封装无法复用现有 MSDK 接口的功能，比如渠道内置的游戏商城。
-- 
-- WebView模块
-- WebView 模块主要功能：
--     打开指定网页，Android 可以选择使用X5内核或原生系统浏览器，iOS使用原生的 WebView 组件；
--     支持JS代码与 Native 代码之间的通信；
--     JS调用原生功能包括：关闭 WebView、设置/取消全屏、自定义 Scheme、JS发消息/分享到指定渠道等；
--     获取加密票据；
--
-- MSDK位置模块(LBS)
-- 位置模块（ Location Based Service, LBS ）, 主要为业务提供相关玩家位置的功能。如，玩家可以获取当前位置，获取附近好友，清除位置设定，查询当前 IP 所处国家。使用 LBS 功能尽量避免短时间内频繁调用。
-- 说明：LBS 定位功能当前仅支持国内 QQ、Wechat 登录
-- 
-- Bugly接口
-- 当游戏发生异常或者崩溃的时候，可以上报异常堆栈信息到渠道管理端上。
-- 提供bugly的日志, 设置自定义用户id和设置关键数据接口, 项目可以根据需要设置
-------------------------------------------------------------------------------------------

local Lplus = require "Lplus"
---@class ECMSDK.MSDKUtil:System.Object
---@field protected m_IsTencentForGM boolean
---@field public Commit fun():ECMSDK.MSDKUtil @notnull
---@field public Instance fun():ECMSDK.MSDKUtil
---@field public IsAppInstalled fun(self:ECMSDK.MSDKUtil, platform:number):boolean
---@field public GetChannelID fun(self:ECMSDK.MSDKUtil):string
---@field public SetChannelIsTencentForGM fun(self:ECMSDK.MSDKUtil, isTencent:boolean)
---@field public GetChannelIsTencentForGM fun(self:ECMSDK.MSDKUtil):boolean
---@field public GetIsTencentWhiteListChannel fun(self:ECMSDK.MSDKUtil):boolean
---@field public GetIsTencentBlackListChannel fun(self:ECMSDK.MSDKUtil):boolean
---@field public ReportPrajna fun(self:ECMSDK.MSDKUtil, serialNumber:string)
---@field public OpenPrajnaWebView fun(self:ECMSDK.MSDKUtil, jsonStr:string)
---@field public OpenDeepLink fun(self:ECMSDK.MSDKUtil, link:string)
---@field public openMicroCommunity fun(self:ECMSDK.MSDKUtil, url:string)
---@field public GetDeviceId fun(self:ECMSDK.MSDKUtil):string
---@field public GetVersion fun(self:ECMSDK.MSDKUtil):string
---@field public GetRegisterChannelID fun(self:ECMSDK.MSDKUtil):string
---@field public RealNameAuth fun(self:ECMSDK.MSDKUtil, provinceID:number, identityType:number, identityNum:number, name:string, city:string)
---@field public UpdateConfigs fun(self:ECMSDK.MSDKUtil, params:table)
---@field public Invoke fun(self:ECMSDK.MSDKUtil, channel:string, extendMethodName:string, paramsJson:string)
---@field public OpenURL fun(self:ECMSDK.MSDKUtil, url:string, screenDir:any)
---@field public GetEncodeUrl fun(self:ECMSDK.MSDKUtil, url:string):string
---@field public OpenURLForTencent fun(self:ECMSDK.MSDKUtil, url:string)
---@field public OpenTencentCreditURL fun(self:ECMSDK.MSDKUtil)
---@field public OpenServiceURL fun(self:ECMSDK.MSDKUtil, base_url:string, default_zoneid:any)
---@field public GetAreaID fun(self:ECMSDK.MSDKUtil, zoneid:number):string
---@field public GetAccountInfo fun(self:ECMSDK.MSDKUtil, accout:string):AccountInfo
---@field public GetLocationInfo fun(self:ECMSDK.MSDKUtil)
---@field public GetNearby fun(self:ECMSDK.MSDKUtil)
---@field public CleanLocation fun(self:ECMSDK.MSDKUtil)
---@field public OnLocationGot fun(self:ECMSDK.MSDKUtil, flag:number, desc:string, longitude:number, latitude:number)
---@field public BuglyLog fun(self:ECMSDK.MSDKUtil, logLv:number, logMsg:string)
---@field public BuglySetUserId fun(self:ECMSDK.MSDKUtil, userId:string)
---@field public BuglySetUserValue fun(self:ECMSDK.MSDKUtil, k:string, v:string)
---@field public Clear fun(self:ECMSDK.MSDKUtil)
---@field public GetFirstValueForAddress fun(self:ECMSDK.MSDKUtil, family:string):string
---@field public GetIPv4 fun(self:ECMSDK.MSDKUtil):string
---@field public GetIPv6 fun(self:ECMSDK.MSDKUtil):string
---@field public GetIOSUserAgent fun(self:ECMSDK.MSDKUtil):string
---@field public GetAndroidOAID fun(self:ECMSDK.MSDKUtil):string
local MSDKUtil = Lplus.Class("ECMSDK.MSDKUtil")
local MSDKInfo = require("MSDK.MSDKInfo")
local channel_id_cfg = _G.GetConfigLua("Configs/tencent/channel_id_cfg.lua")

local def = MSDKUtil.define

local PCallMSDKFunction = function(FunctionName, ...)
	if MSDK and MSDK[FunctionName] then
		return MSDK[FunctionName](...)
	else
		warn(("There is no function = %s in MSDK"):format(FunctionName))
		return nil
	end
end

local instance = nil

---@type boolean
def.field("boolean").m_IsTencentForGM = false --命令控制是否是腾讯渠道(默认false)

---@return ECMSDK.MSDKUtil
def.static("=>", MSDKUtil).Instance = function()
	if not instance then
		instance = MSDKUtil()
	end
	return instance
end

-------------------------------------------------------------------------------------
-- MSDK工具模块
-------------------------------------------------------------------------------------

-- 判断软件是否安装。Android 平台传 packageName 参数，而 iOS 平台传渠道参数或者 URLScheme，比如 "QQ"、"WeChat" 。
-- param: platform 渠道
---@param self ECMSDK.MSDKUtil
---@param platform number
---@return boolean
def.method("number", "=>", "boolean").IsAppInstalled = function(self, platform)
	local channelStr
	if _G.platformName == "ios" then
		channelStr = MSDK_LOGIN_PLATFORM_NAME[platform]
	elseif _G.platformName == "android" then
		channelStr = MSDKInfo.ChannelPackageName[platform]
	else
		return false
	end

	return PCallMSDKFunction("isAppInstalled", channelStr)
end

-- 获取渠道号
-- Android 版本在飞鹰上根据不同渠道打包 apk，发布到不同渠道商店，通过该接口获取渠道名称。只支持 Android 平台。修改渠道名称的方法依旧是 GCloud 提供。
-- return 返回渠道号
---@param self ECMSDK.MSDKUtil
---@return string
def.method("=>", "string").GetChannelID = function(self)
	local channelID = PCallMSDKFunction("getChannelId") or ""
	-- if channelID == "" then
	-- 	local iniContent = GameUtil.StreamingAssetReadFileText("channel.ini")
	-- 	if iniContent then
	-- 		channelID = string.match(iniContent, "CHANNEL=(%d+)")
	-- 	end
	-- end

	if GameUtil.GetPlatformName() == "IOS" then	--iOS 写死渠道号为 1001 (接口好像有问题)
		return "1001"
	end

	-- 渠道号回写
	local ClientData = require "Data.ClientData"
	local write_back = ClientData.Instance():GetLoginCfg("write_back_channel_id")
	-- print_hsh("GetChannelID  ",write_back,channelID)
	if write_back and write_back ~= "" then
		return write_back
	else
		ClientData.Instance():SetLoginCfg("write_back_channel_id",channelID)
		ClientData.Instance():SaveUserData()
	end
	
	return channelID
end

--用命令设置是否是腾讯渠道
---@param self ECMSDK.MSDKUtil
---@param isTencent boolean
---@return void
def.method("boolean").SetChannelIsTencentForGM = function(self, isTencent)
	self.m_IsTencentForGM = isTencent
end

--获取用命令设置的是否是腾讯渠道
---@param self ECMSDK.MSDKUtil
---@return boolean
def.method("=>", "boolean").GetChannelIsTencentForGM = function(self)
	return self.m_IsTencentForGM
end

--获取是否是腾讯白名单渠道
---@param self ECMSDK.MSDKUtil
---@return boolean
def.method("=>", "boolean").GetIsTencentWhiteListChannel = function(self)
	local isTencentWhiteListChannel = false
	if channel_id_cfg and channel_id_cfg.white_list then
		local channelID = self:GetChannelID()
		for _, v in pairs(channel_id_cfg.white_list) do
			if channelID == tostring(v) then
				isTencentWhiteListChannel = true
				break
			end
		end
	end
	return isTencentWhiteListChannel
end

--获取是否是腾讯黑名单渠道
---@param self ECMSDK.MSDKUtil
---@return boolean
def.method("=>", "boolean").GetIsTencentBlackListChannel = function(self)
	local isTencentBlackListChannel = false
	if channel_id_cfg and channel_id_cfg.black_list then
		local channelID = self:GetChannelID()
		for _, v in pairs(channel_id_cfg.black_list) do
			if channelID == tostring(v) then
				isTencentBlackListChannel = true
				break
			end
		end
	end
	return isTencentBlackListChannel
end

-- 上报防沉迷信息
-- 中控相关，上报 Prajna serial Number，目前支持国内渠道，海外渠道暂不支持。 游戏接入中控，会和中控建立一个长连接，serialNumber 是中控下发的，MSDK 只做上报。
-- param serialNumber 是中控下发的，MSDK 只做上报
---@param self ECMSDK.MSDKUtil
---@param serialNumber string
---@return void
def.method("string").ReportPrajna = function(self, serialNumber)
	PCallMSDKFunction("reportPrajna", serialNumber)
end

-- 打开中控网页
-- 中控相关，用于打开中控网页，目前支持国内渠道，海外渠道暂不支持。 jsonStr 由中控下发的，MSDK 会用这个参数打开中控的 webview 页面。
-- param jsonStr 由中控下发的，MSDK 会用这个参数打开中控的 webview 页面。
---@param self ECMSDK.MSDKUtil
---@param jsonStr string
---@return void
def.method("string").OpenPrajnaWebView = function(self, jsonStr)
	PCallMSDKFunction("openPrajnaWebView", jsonStr)
end

-- 微信 deeplink
-- 根据当前登录态，打开对应应用 deeplink（ deeplink 功能的开通和配置请联系各平台）
-- param link
---@param self ECMSDK.MSDKUtil
---@param link string
---@return void
def.method("string").OpenDeepLink = function(self, link)
	PCallMSDKFunction("openDeepLink", link)
end

-- (此方法没有实现)
---@param self ECMSDK.MSDKUtil
---@param url string
---@return void
def.method("string").openMicroCommunity = function(self, url)
	-- local MSDKInfo = Lplus.ForwardDeclare("ECMSDK.MSDKInfo")
	-- local supportedOrientations = 3
	-- local qqAppid = MSDKInfo.APPID.QQ
	-- local wxAppid = MSDKInfo.APPID.WX
	-- print(("openMicroCommunity, url = %s, supportedOrientations = %d, qqAppid = %s, wxAppid = %s"):format(url,supportedOrientations,qqAppid,wxAppid))
	-- PCallMSDKFunction("openMicroCommunity", url, supportedOrientations, qqAppid, wxAppid)
end

-- 获取设备id(此方法没有实现)
---@param self ECMSDK.MSDKUtil
---@return string
def.method("=>", "string").GetDeviceId = function(self)
	return PCallMSDKFunction("getDeviceId") or ""
end

-- 获取版本(此方法没有实现)
---@param self ECMSDK.MSDKUtil
---@return string
def.method("=>", "string").GetVersion = function(self)
	return PCallMSDKFunction("getVersion") or ""
end

-- (此方法没有实现)
---@param self ECMSDK.MSDKUtil
---@return string
def.method("=>", "string").GetRegisterChannelID = function(self)
	return PCallMSDKFunction("getRegisterChannelId") or ""
end

-- (此接口c++没有实现)
---@param self ECMSDK.MSDKUtil
---@param provinceID number
---@param identityType number
---@param identityNum number
---@param name string
---@param city string
---@return void
def.method("number", "number", "number", "string", "string").RealNameAuth = function(self, provinceID, identityType, identityNum, name, city)
	print("RealNameAuth", provinceID, "  ",identityType, "   ", identityNum, " ",  name, "    ",city)
	PCallMSDKFunction("realNameAuth", provinceID, identityType, identityNum, name, city)
end

-- 更新调试模式打印log开关
---@param self ECMSDK.MSDKUtil
---@param params table
---@return void
def.method("table").UpdateConfigs = function(self, params)
	PCallMSDKFunction("updateConfigs", params)
end

-------------------------------------------------------------------------------------
-- MSDK扩展模块
-------------------------------------------------------------------------------------

-- 渠道扩展功能调用
-- 扩展模块提供统一的扩展功能调用接口，所有的扩展模块功能将统一使用该方法实现。
--    游戏在使用扩展模块的功能时需要将渠道名称（channel）、方法名（extendMethodName）和方法参数列表（paramsJson, Json 格式）传入，
--    MSDK Core 将根据渠道名称和方法名查找到对应方法，调用到 Extend 插件进行处理。具体需要填写的内容需要根据不同渠道的要求填写。
-- param channel 渠道信息，比如“WeChat”、“QQ”、“Facebook”
-- param extendMethodName 扩展模块的方法名
-- param paramsJson 方法参数列表，JSON 格式
---@param self ECMSDK.MSDKUtil
---@param channel string
---@param extendMethodName string
---@param paramsJson string
---@return void
def.method("string", "string", "string").Invoke = function(self, channel, extendMethodName, paramsJson)
	PCallMSDKFunction("invoke", channel, extendMethodName, paramsJson)
end


-------------------------------------------------------------------------------------
-- WebView模块
-------------------------------------------------------------------------------------

-- 按照指定格式打开网址
-- param url 网址链接
-- param screenDir 屏幕方向：1 默认 2 竖屏 3 横屏
---@param self ECMSDK.MSDKUtil
---@param url string
---@param screenDir any
---@return void
def.method("string", "varlist").OpenURL = function(self, url, screenDir)
	if screenDir then
		PCallMSDKFunction("openUrl", url, screenDir)
	else
		PCallMSDKFunction("openUrl", url)
	end
end

-- 添加加密票据
-- 将指定的URL进行加密，添加登录态信息，并返回加密后的URL。这是个同步接口，不需要在回调中获取结果
-- param url 需要加密票据的 URL
---@param self ECMSDK.MSDKUtil
---@param url string
---@return string
def.method("string", "=>", "string").GetEncodeUrl = function(self, url)
	return PCallMSDKFunction("getEncodeUrl", url) or ""
end

-- def.method("number").OnWebViewNotify = function(self, flag)
-- 	print("OnWebViewNotify flag = " .. flag)
-- 	if flag == 0 then
-- 	elseif flag == 6001 then
-- 	end
-- end

-- 打开腾讯平台URL
-- 后面会跟若干腾讯所需要的后缀
---@param self ECMSDK.MSDKUtil
---@param url string
---@return void
def.method("string").OpenURLForTencent = function(self,url)
	local ECMSDK = require "MSDK.ECMSDK"
	local hp = globalGame:GetHostPlayer()
	local role_id = ZeroUInt64
	if hp and hp.ID then
		role_id = hp.ID
	end
	--local area_id = _G.LoginPlatform		-- _G.MSDK_LOGIN_PLATFORM
	--[[
	local area_id = 0
	if _G.LoginPlatform == MSDK_LOGIN_PLATFORM.WX then
		area_id = 1001
	elseif _G.LoginPlatform == MSDK_LOGIN_PLATFORM.QQ then
		area_id = 2002
	end
	]]--
	local plat_id = ECMSDK.GetPlatId()			-- IOS:0 Android:1
	local partition = require "Main.ECZoneMan".Instance():GetZoneID(role_id)					-- 改为ZoneID
	local area_id = self:GetAreaID(partition)
	local role_id_str = LuaUInt64.ToString(role_id)
	local url_postfix = StringTable.Get(2636):format(area_id,tostring(plat_id),tostring(partition),role_id_str)
	self:OpenURL(url..url_postfix)
end

--打开腾讯游戏信用页面
---@param self ECMSDK.MSDKUtil
---@return void
def.method().OpenTencentCreditURL = function(self)
	local ECMSDK = require "MSDK.ECMSDK"
	local param = {}
	local hp = globalGame:GetHostPlayer()
	if hp then
		local UrlHelper = require "Utility.UrlHelper"
		param.rolename = UrlHelper.urlEncode(hp.InfoData.Name or "")
	end
	local role_id = ZeroUInt64
	if hp and hp.ID then
		role_id = hp.ID
	end
	local partition = require "Main.ECZoneMan".Instance():GetZoneID(role_id)
	param.partition = tostring(partition)
	param.charac_no = LuaUInt64.ToString(role_id)
	param.areaid = self:GetAreaID(partition)
	param.platid = ECMSDK.GetPlatId() --IOS:0 Android:1
	local url_param = ""
	local is_first = true
	for k, v in pairs(param) do
		if is_first then
			is_first = false
			url_param = "?"..k.."="..v
		else
			url_param = url_param.."&"..k.."="..v
		end
	end
	local credit_cfg = _G.GetConfigLua("Configs/tencent/credit_cfg.lua")
	local url = credit_cfg.game_credit_url
	self:OpenURL(url..url_param)
end

--打开腾讯客服
---@param self ECMSDK.MSDKUtil
---@param base_url string
---@param default_zoneid any
---@return void
def.method("string", "varlist").OpenServiceURL = function(self, base_url, default_zoneid)
	if base_url and #base_url > 0 then
		local ECMSDK = require "MSDK.ECMSDK"
		local UrlHelper = require "Utility.UrlHelper"
		local param = {}
		--角色昵称
		local hp = globalGame:GetHostPlayer()
		local role_name = ""

		if hp then
			role_name = hp.InfoData.Name or ""
		end
		--角色id
		local role_id
		if hp and hp.ID then
			role_id = hp.ID
		end
		--是否安装手Q
		param.qi = MSDKUtil.Instance():IsAppInstalled(_G.MSDK_LOGIN_PLATFORM.QQ) and "1" or "0"
		--是否安装微信
		param.wi = MSDKUtil.Instance():IsAppInstalled(_G.MSDK_LOGIN_PLATFORM.WX) and "1" or "0"
		--操作平台
		param.platid = ECMSDK.GetPlatId() --IOS:0 Android:1
		--游戏区id
		local zoneid = default_zoneid and default_zoneid or require "Main.ECZoneMan".Instance():GetZoneID(role_id and role_id or ZeroUInt64)
		local zonename = require "Main.ECZoneMan".Instance():GetZoneName(zoneid) or ""
		param.z = tostring(zoneid) 
		--小区中文名
		param.zn = zonename
		param.roleid = role_id and LuaUInt64.ToString(role_id) or ""
		param.role = role_name
		param.areaid = self:GetAreaID(zoneid)

		local paramsStr = ""
		for k, v in pairs(param) do
			paramsStr = paramsStr .. "&" .. k .. "=" .. UrlHelper.urlEncode(tostring(v))
		end
		self:OpenURL(base_url..paramsStr)
	end
end

---@param self ECMSDK.MSDKUtil
---@param zoneid number
---@return string
def.method("number","=>","string").GetAreaID = function(self,zoneid)
	local ECServerList = require "Configs.ECServerList"
	local serverInfo = ECServerList.GetServerInfoByZoneid(zoneid, false)
	--print_hsh("serverInfo  ",zoneid,serverInfo)
	if serverInfo and serverInfo.areaid then
		if _G.LoginPlatform == MSDK_LOGIN_PLATFORM.WX and serverInfo.areaid_wx ~= "" then
			return serverInfo.areaid_wx
		elseif _G.LoginPlatform == MSDK_LOGIN_PLATFORM.QQ  and serverInfo.areaid_qq ~= "" then
			return serverInfo.areaid_qq
		end
		if serverInfo.areaid ~= "" then
			return serverInfo.areaid
		end
	end
	-- 第二次测试定的写死配置
	if _G.LoginPlatform == MSDK_LOGIN_PLATFORM.WX then
		if serverInfo and serverInfo.areaid_wx ~= "" then
			return serverInfo.areaid_wx
		end
		return "1001"
	elseif _G.LoginPlatform == MSDK_LOGIN_PLATFORM.QQ then
		if serverInfo and serverInfo.areaid_qq ~= "" then
			return serverInfo.areaid_qq
		end
		return "2002"
	end
	return "0"
end

-- 获取账号隐藏信息，仅适用于MSDK登陆
---@class AccountInfo
---@field public openid
---@field public platid @comment 0:ios, 1:android, 3:other
---@field public type @comment 0:shadow, 1:qq, 2:wechat

---@param self ECMSDK.MSDKUtil
---@param accout string
---@return AccountInfo
def.method("string","=>","table").GetAccountInfo = function(self,accout)
	---@type AccountInfo
	local need = {}
	local account_list = string.split(accout,"$")
	need.openid = account_list[1]
	need.platid = 3
	if string.find(accout,"ios") then
		need.platid = 0
	elseif string.find(accout,"android") then
		need.platid = 1
	end
	need.type = 0
	if string.find(accout,"qq") then
		need.type = 1
	elseif string.find(accout,"wechat") then
		need.type = 2
	end

	return need
end

-------------------------------------------------------------------------------------
-- MSDK位置模块(LBS)
-------------------------------------------------------------------------------------

-- 获取位置
-- 调用该接口，可通过基站定位、WIFI 定位、GPS 定位（任何一种定位成功即可）得到玩家的位置信息，返回玩家当前的经纬度。建议 Android 工程中加上 ACCESS_WIFI_STATE 非敏感权限。
---@param self ECMSDK.MSDKUtil
---@return void
def.method().GetLocationInfo = function(self)
	PCallMSDKFunction("getLocationInfo")
end

-- 获取附近玩家
-- 可获取到玩家附近位置的其他已定位玩家列表
---@param self ECMSDK.MSDKUtil
---@return void
def.method().GetNearby = function(self)
	PCallMSDKFunction("getNearbyPersonInfo")
end

-- 清除位置信息
-- 在获取位置和获取附近好友功能中，都会设置玩家的信息到后台。调用该接口可清除后台对该玩家的位置设置，使得该玩家不会出现在别的玩家的附近玩家列表中。
---@param self ECMSDK.MSDKUtil
---@return void
def.method().CleanLocation = function(self)
	PCallMSDKFunction("cleanLocation")
end

-- 获取位置回调, 对应OnLBSLocationRetNotify
---@param self ECMSDK.MSDKUtil
---@param flag number
---@param desc string
---@param longitude number
---@param latitude number
---@return void
def.method("number", "string", "number", "number").OnLocationGot = function(self, flag, desc, longitude, latitude)
	print("OnLocationGot " ,flag, "  ", desc, "  ", longitude, "  ", latitude)
end

-------------------------------------------------------------------------------------
-- Bugly接口
-------------------------------------------------------------------------------------

-- 打印自定义日志 (for bugly)
-- 自定义日志打印接口，用于记录一些关键的业务调试信息，可以更全面地反映 APP 发生崩溃或异常的上下文环境。
-- param logLv 日志级别(MSDKCrashLevel int): 0-silent，1-error，2-warning，3-inifo，4-debug，5-verbose
-- param logMsg 日志内容
---@param self ECMSDK.MSDKUtil
---@param logLv number
---@param logMsg string
---@return void
def.method("number", "string").BuglyLog = function(self, logLv, logMsg)
	PCallMSDKFunction("buglyLog", logLv, logMsg)
end

-- 设置用户ID (for bugly)
-- 支持自定义设置用户ID，您可能会希望能精确定位到某个用户的异常，通过该接口记录用户 ID，在页面上可以精确定位到每个用户发生 Crash 的情况。
-- param userId 用户Id
---@param self ECMSDK.MSDKUtil
---@param userId string
---@return void
def.method("string").BuglySetUserId = function(self, userId)
	PCallMSDKFunction("buglySetUserId", userId)
end

-- 设置关键数据，随崩溃信息上报
-- 设置关键数据键值对，随崩溃信息上报。最多允许设置 9 对键值。
-- param k 键，键值必须匹配正则表达式[a-zA-Z[0-9]]+，限制长度50字节。详情请参阅 Bugly官方文档 - 设置自定义Map参数
-- param v 值，限制长度200字节
---@param self ECMSDK.MSDKUtil
---@param k string
---@param v string
---@return void
def.method("string", "string").BuglySetUserValue = function(self, k, v)
	PCallMSDKFunction("buglySetUserValue", k, v)
end

---@param self ECMSDK.MSDKUtil
---@return void
def.method().Clear = function(self)
end

---@param self ECMSDK.MSDKUtil
---@param family string
---@return string
def.method("string","=>","string").GetFirstValueForAddress = function(self,family)
	local socket = require("socket")
	local dns = socket.dns
	local hostname = dns.gethostname()
	local info = dns.getaddrinfo(hostname)
	if not info then
		return ""
	end
	for i,v in ipairs(info) do
		if v.family == family then
			return v.addr
		end
	end
	return ""
end
---@param self ECMSDK.MSDKUtil
---@return string
def.method("=>","string").GetIPv4 = function(self)
	return self:GetFirstValueForAddress("inet")
end
---@param self ECMSDK.MSDKUtil
---@return string
def.method("=>","string").GetIPv6 = function(self)
	return self:GetFirstValueForAddress("inet6")
end
---@param self ECMSDK.MSDKUtil
---@return string
def.method("=>","string").GetIOSUserAgent = function(self)
	local ZLUtilHelper = require "Utility.ZLUtilHelper"
	-- 去除多余转义字符
	local s = ZLUtilHelper.getUserAgent()
	local pat = "%\\%/"
	local newS = s:gsub(pat, function(text)
		local _, _, plain = text:find("^%\\%/$")
		return "/"
	end)
	return newS
end
---@param self ECMSDK.MSDKUtil
---@return string
def.method("=>","string").GetAndroidOAID = function(self)
	if GPMSDK and GPMSDK.getDataFromTGPA then
		local oaid = GPMSDK.getDataFromTGPA("OAID")
		warn("oaid  ",oaid)
		if oaid then
			return oaid
		end
	end
	return ""
end

MSDKUtil.Commit()
return MSDKUtil
