local Lplus = require "Lplus"
local malut = require "Utility.malut"
local ApplicationPause = require "Event.SystemEvents".ApplicationPause
---@type ECGame
local ECGame = Lplus.ForwardDeclare("ECGame")
local UserData = require "Data.UserData"
local ECSoundMan = require "Sound.ECSoundMan"
local ECActivityInfo = require "Social.ECActivityInfo"
local MSDKInfo = require("MSDK.MSDKInfo")
local GVoiceEvents = require "Event.GVoiceEvents"

local l_instance = nil

---@class MSDKGVoice:System.Object
---@field public GVOICE_MODE table
---@field public RECORD_STATE table
---@field public recordState number
---@field public curTranslateText string
---@field public afterStreamTextCallback function
---@field public recordFilePath string
---@field public bApplyMessageKeyComplete boolean
---@field public bInitGvoice boolean
---@field public joinRoomCompleteCallback function
---@field public roomMemberJoinRoomCallback function
---@field public roomMemberQuitRoomCallback function
---@field public roomMemberStateChangeCallback function
---@field public roomMemberJoinRoomStateChangeCallback function
---@field public roomRoleChangedCallback function
---@field public quitRoomCompleteCallback function
---@field public uploadFileCallback function
---@field public curUploadFileId string
---@field public downloadFileCallback function
---@field public curFileId string
---@field public translateCompleteCallback function
---@field public RSTTCompleteCallback function
---@field public Commit fun():MSDKGVoice @notnull
---@field public IsJoining fun(self:MSDKGVoice):boolean
---@field public IsInRoom fun(self:MSDKGVoice):boolean
---@field public GetMicLevel fun(self:MSDKGVoice):number
---@field public GetRecordFilePath fun(self:MSDKGVoice):string
---@field public TryGetPermission fun(cb:function)
---@field public Instance fun():MSDKGVoice
---@field public Init fun(self:MSDKGVoice)
---@field public SetHandler fun(self:MSDKGVoice)
---@field public SetMode fun(self:MSDKGVoice, mode:number):number
---@field public Update fun(self:MSDKGVoice)
---@field public OnApplicationPause fun(self:MSDKGVoice, paused:boolean)
---@field public JointTeamRoom fun(self:MSDKGVoice, roomName:string, cb:function, mj_cb:function, mq_cb:function, mj_st_cb:function):boolean
---@field public JoinNationalRoom fun(self:MSDKGVoice, roomName:string, role:number, cb:function, mj_cb:function, mq_cb:function, mj_st_cb:function, rc_cb:function):boolean
---@field public SetMic fun(self:MSDKGVoice, flag:boolean)
---@field public SetSpeaker fun(self:MSDKGVoice, flag:boolean)
---@field public QuitRoom fun(self:MSDKGVoice, roomName:string, cb:function):boolean
---@field public EnableRoomMore fun(self:MSDKGVoice, enable:boolean):boolean
---@field public EnableRoomMic fun(self:MSDKGVoice, roomName:string, enable:boolean):boolean
---@field public EnableRoomSpeaker fun(self:MSDKGVoice, roomName:string, enable:boolean):boolean
---@field public ForbidMemberVoiceInRoom fun(self:MSDKGVoice, playerMember:number, isForbid:boolean, roomName:string):boolean
---@field public GetRoomMembers fun(self:MSDKGVoice, roomName:string):table
---@field public IsSpeakingInRoom fun(self:MSDKGVoice):boolean
---@field public BeginRecord fun(self:MSDKGVoice):boolean
---@field public EndRecord fun(self:MSDKGVoice):boolean
---@field public UploadAudio fun(self:MSDKGVoice, cb:function):boolean
---@field public DownloadAudio fun(self:MSDKGVoice, fileId:string, filePath:string, cb:function):boolean
---@field public PlayAudio fun(self:MSDKGVoice, fileId:string, filepath:string):boolean
---@field public StopPlay fun(self:MSDKGVoice):boolean
---@field public Translate fun(self:MSDKGVoice, fileid:string, cb:function):boolean
---@field public BeginRecordByRSTT fun(self:MSDKGVoice, cb:function):boolean
---@field public EnableKeyWordsDetect fun(self:MSDKGVoice, flag:boolean)
---@field public SetCivilBinPath fun(self:MSDKGVoice, path:string)
---@field public SetReportBufferTime fun(self:MSDKGVoice, nSecs:number)
---@field public SetReportedPlayerInfo fun(self:MSDKGVoice, openids:table, memberids:table)
---@field public ReportPlayer fun(self:MSDKGVoice, openids:table, strInfo:string):number
---@field public OnReportPlayerHandler fun(self:MSDKGVoice, code:number, strInfo:string)
---@field public EnableCivilVoice fun(self:MSDKGVoice, bEnable:boolean)
---@field public EnableReportALL fun(self:MSDKGVoice, bEnable:boolean)
---@field public ReportTeamBadVoice fun(self:MSDKGVoice, desc:string, params:table)
local MSDKGVoice = Lplus.Class("MSDKGVoice")
local def = MSDKGVoice.define

local RECORD_STATE =
{
    RS_AVAILABLE = 0,
    RS_RECORDING = 1,
    RS_UPLOADING = 2,
    RS_TRANSLATE = 3,
}

-- 响应时间 60s
local MS_TIMEOUT = 60000


---@type table
def.const("table").GVOICE_MODE = GVOICE_MODE

---@type table
def.const("table").RECORD_STATE = RECORD_STATE

---@type number
def.field("number").recordState = RECORD_STATE.RS_AVAILABLE

---@type string
def.field("string").curTranslateText = ""

---@type function
def.field("function").afterStreamTextCallback = nil

---@type string
def.field("string").recordFilePath = ""


------------------------------------------------------------------------------------------------------
--- 〇  工具函数
---     包括枚举类与其异常检测
--- 1.ErrorNo
---     主调函数返回码，异常输出为GVoiceErrorNoTip
--- 2.CompleteCode
---     回调函数返回码，异常输出为GVoiceCompleteCodeTip
------------------------------------------------------------------------------------------------------

local ErrorNo =
{
    -- 基础流程
    kErrorNoSucc                    = 0,            -- 成功
    kErrorNoParamNULL               = 4097,         -- 参数为空
    kErrorNoNeedSetAppInfo          = 4098,         -- 没有设置GameID和GameKey
    kErrorNoInitErr                 = 4099,         -- 引擎创建出错
    kErrorNoRecordingErr            = 4100,         -- 正在录制音频，请先关闭
    kErrorNoModeStateErr            = 4102,         -- 模式不对
    kErrorNoParamInvalid            = 4103,         -- 参数不对
    kErrorNoOpenFileErr             = 4104,         -- 文件打开失败
    kErrorNoNeedInit                = 4105,         -- 没有初始化

    -- 实时语音
    -- kErrorNokModeRealTimeStateErr                -- 状态不对     C++里没有，先不加入
    kErrorNoRealtimeStateErr        = 8193,         -- 语音模式不对，检测是否为语音模式
    kErrorNoJoinErr                 = 8194,         -- 加入房间失败
    kErrorNoQuitRoomNameErr         = 8195,         -- 退房房间名不存在
    kErrorNoCreateRoomErr           = 8197,         -- 创建房间失败
    kErrorNoNoRoom                  = 8198,         -- 没有该房间
    kErrorNoQuitRoomErr             = 8199,         -- 退出房间失败
    kErrorNoAlreadyInTheRoom        = 8200,         -- 已在房间中

    -- 语音消息
    kErrorNoAuthKeyErr              = 12289,        -- 内部错误
    kErrorNoPathAccessErr           = 12290,        -- 路径不合法
    kErrorNoPermissionMicErr        = 12291,        -- 没有麦克风权限
    kErrorNoNeedAuthKey             = 12292,        -- 需要语音key
    kErrorNoUploadErr               = 12293,        -- 上传出错，请尝试重新上传
    kErrorNoHttpBusy                = 12294,        -- 网络堵塞
    kErrorNoDownloadErr             = 12295,        -- 下载出错
    kErrorNoSpeakerErr              = 12296,        -- 未开扬声器
    kErrorNoTVEPlaySoundErr         = 12297,        -- 录音文件播放失败，内部错误
    kErrorNoLimit                   = 12299,        -- 不能上传永久文件
    kErrorNoNothingToReport         = 12300,        -- 没有可以举报的语言消息


    -- 其他
    kErrorNoInternalTVEErr          = 20481,        -- 内部错误
    kErrorNoSTTing                  = 28673,        -- 正在转换，请等待
}

-- 主调方法错误提示
local function GVoiceErrorNoTip(ret, reason)
    local err_str = ""

    if ret == ErrorNo.kErrorNoSucc then
        return
    elseif ret == ErrorNo.kErrorNoParamNULL then
        err_str = "some param is null"
    elseif ret == ErrorNo.kErrorNoNeedSetAppInfo then
        err_str = "you should call SetAppInfo first before call other api"
    elseif ret == ErrorNo.kErrorNoInitErr then
        err_str = "Init Erro"
    elseif ret == ErrorNo.kErrorNoRecordingErr then
        err_str = "now is recording, can't do other operator"
    elseif ret == ErrorNo.kErrorNoModeStateErr then
        err_str = "call some api, but the mode is not correct, maybe you shoud call SetMode first and correct"
    elseif ret == ErrorNo.kErrorNoParamInvalid then
        err_str = "some param is null or value is invalid for our request, used right param and make sure is value range is correct by our comment"
    elseif ret == ErrorNo.kErrorNoOpenFileErr then
        err_str = "open a file err"
    elseif ret == ErrorNo.kErrorNoNeedInit then
        err_str = "you should call Init before do this operator"

    elseif ret == ErrorNo.kErrorNoAuthKeyErr then
        err_str = "apply authkey api error"
    elseif ret == ErrorNo.kErrorNoPathAccessErr then
        err_str = "the path can not access ,may be path file not exists or deny to access"
    elseif ret == ErrorNo.kErrorNoPermissionMicErr then
        err_str = "you have not right to access micphone in android"
    elseif ret == ErrorNo.kErrorNoNeedAuthKey then
        err_str = "you have not get authkey, call ApplyMessageKey first"
    elseif ret == ErrorNo.kErrorNoUploadErr then
        err_str = "upload file err"
    elseif ret == ErrorNo.kErrorNoHttpBusy then
        err_str = "http is busy,maybe the last upload/download not finish."
    elseif ret == ErrorNo.kErrorNoDownloadErr then
        err_str = "download file err"
    elseif ret == ErrorNo.kErrorNoSpeakerErr then
        err_str = "open or close speaker tve error"
    elseif ret == ErrorNo.kErrorNoTVEPlaySoundErr then
        err_str = "tve play file error"
    elseif ret == ErrorNo.kErrorNoLimit then
        err_str = "upload limit"

    elseif ret == ErrorNo.kErrorNoInternalTVEErr then
        err_str = "internal TVE err, our used. Please call Tencent!"
    end

    if reason then
        warn("GVoiceErrorNoTip:   ", reason, ret, err_str)
    else
        warn("GVoiceErrorNoTip:   ",ret, err_str)
    end
end

-- 回调函数返回码
local CompleteCode =
{
    -- 实时语音
    kCompleteCodeJoinRoomSucc                       = 8193,         -- 加入房间成功
    kCompleteCodeQuitRoomSucc                       = 8198,         -- 退出房间成功
    kCompleteCodeRoleSucc                           = 8200,         -- 改变角色成功

    -- 语音消息
    kCompleteCodeMessageKeyAppliedSucc              = 12289,        -- 请求语音消息Key回调成功
    kCompleteCodeMessageKeyAppliedTimeout           = 12290,        -- 请求语音消息Key回调超时
    kCompleteCodeUploadRecordDone                   = 12293,        -- 上传语音文件成功
    kCompleteCodeDownloadRecordDone                 = 12295,        -- 下载语音文件成功
    kCompleteCodePlayFileDone                       = 12297,        -- 正常播放完成回调
    kCompleteCodeSTTSucc                            = 16385,        -- 离线语音转文字转换完成
    kCompleteCodeRSTTSucc                           = 20481,        -- 实时语音转文字转换完成
    -- 文明语音举报
    kCompleteCodeReportSucc                         = 24577,        -- 举报成功
    kCompleteCodePunished                           = 24579,        -- 被举报成功
    kCompleteCodeReportSuccSelf                     = 0x6006,       --

    -- 成员进退房间回调
    kCompleteCodeRoomMemberInRoom                   = 32769,        -- 成员加入房间
    kCompleteCodeRoomMemberOutRoom                  = 32770,        -- 成员退出房间
    kCompleteCodeRoomMemberMicOpen                  = 32771,        -- member mic is open
    kCompleteCodeRoomMemberMicClose                 = 32772,        -- member mic is close

}

-- 回调失败提示
local function GCloudCompleteCodeTip(tag, code)
    print(("GVoice %s : code:%d, %s"):format(tag, code, str))
end

------------------------------------------------------------------------------------------------------
------------------------------------------------------------------------------------------------------

-- 回调函数
-- 实时语音回调函数
local function JoinRoomHandler( code, room, id )
    print("GVoice JoinRoomHandler ", code, room, id)

    if code == CompleteCode.kCompleteCodeJoinRoomSucc then
        --ECGame.Instance():MuteBackground(false)
        --ECSoundMan.Instance():Play2DSoundByName("RTVoice")

        --UserData.Instance():SetRoleCfg("GVoiceRoomName", room)
        --UserData.Instance():SetRoleCfg("GVoiceRoomInfo", {})
        --UserData.Instance():SaveDataToFile(0)

        if l_instance.joinRoomCompleteCallback then
            l_instance.joinRoomCompleteCallback(room, id)
            l_instance.joinRoomCompleteCallback = nil
        end
    end
    --ECTeamChatMan.Instance():JoinRoomCB(code, room, id)
end

local function QuitRoomHandler( code, room, id )
    print("GVoice QuitRoomHandler ", code, room, id)

    if code == CompleteCode.kCompleteCodeQuitRoomSucc then
        --ECGame.Instance():ResumeBackground()

        if l_instance.quitRoomCompleteCallback then
            l_instance.quitRoomCompleteCallback(room, id)
            l_instance.quitRoomCompleteCallback = nil
        end
    end
    --UserData.Instance():SetRoleCfg("GVoiceRoomName", "")
    --UserData.Instance():SetRoleCfg("GVoiceRoomInfo", {})
    --ECTeamChatMan.Instance():QuitRoomCB(code, room, id)
end

--改变状态的member成员，其值为[memberID status]这样的对，总共有count对，status有“0”：停止说话 “1”：开始说话 “2”:继续说话
local function MemberVoiceHandler(roomName, member, status)
    --ECTeamChatMan.Instance():MemberVoiceCB(member, status)

    print("GVoice MemberVoiceHandler ", roomName, member, status)
    --roomMemberStateChangeCallback
    --if code == CompleteCode.kCompleteCodeQuitRoomSucc then
        --ECGame.Instance():ResumeBackground()

        if l_instance.roomMemberStateChangeCallback then
            l_instance.roomMemberStateChangeCallback(roomName, member, status)
            l_instance.roomMemberStateChangeCallback = nil
        end
    --end
end

local function RoleChangedHandler(code,roomName, member, role)
    print("GVoice RoleChangedHandler ",code, roomName, member, role)
    if code == CompleteCode.kCompleteCodeQuitRoomSucc then
        if l_instance.roomRoleChangedCallback then
            l_instance.roomRoleChangedCallback(roomName, member, role)
            l_instance.roomRoleChangedCallback = nil
        end
    end
end

local function MemberVoiceMultiRoomHandler(roomName, member, status)
    --ECTeamChatMan.Instance():MemberVoiceCB(member, status)

    -- 没有code
    --warn("NotifyGvoiceSpeakingChange    ",member,status,roomName)
    local event = GVoiceEvents.NotifyGvoiceSpeakingChange.new(member, status ,roomName)
    ECGame.EventManager:raiseEvent(nil, event)
end

-- 状态改变 回调
local function StatusUpdateHandler(code, roomName, memberID)

end

-- 成员进退房通知
-- 当房间中的成员加入或退出时，通过该回调接口通知
local function RoomMemberInfoHandler(code, roomName, memid, openID)
    --print("GVoice RoomMemberInfoHandler  ",code, roomName, memid, openID)

    if code == CompleteCode.kCompleteCodeRoomMemberInRoom then
        if l_instance.roomMemberJoinRoomCallback then
            l_instance.roomMemberJoinRoomCallback(roomName, memid, openID)
            --l_instance.roomMemberJoinRoomCallback = nil
        end
    elseif code == CompleteCode.kCompleteCodeRoomMemberOutRoom then
        if l_instance.roomMemberQuitRoomCallback then
            l_instance.roomMemberQuitRoomCallback(roomName, memid, openID)
            --l_instance.roomMemberQuitRoomCallback = nil
        end
    elseif code == CompleteCode.kCompleteCodeRoomMemberMicOpen 
            or code == CompleteCode.kCompleteCodeRoomMemberMicClose then --房间成员加入 收到的是这个
        if l_instance.roomMemberJoinRoomStateChangeCallback then
            local status = code == CompleteCode.kCompleteCodeRoomMemberMicOpen and 1 or 0
            l_instance.roomMemberJoinRoomStateChangeCallback(roomName, memid, openID)
            --l_instance.roomMemberJoinRoomCallback = nil
        end
    end
end


-- 语音消息回调函数
-- 请求语音消息Key回调
---@type boolean
def.field("boolean").bApplyMessageKeyComplete = false
-- 申请语音消息key完成 回调
local function ApplyMessageKeyCompleteHandler(code)
    if l_instance and code then
        if code == CompleteCode.kCompleteCodeMessageKeyAppliedSucc then
            l_instance.bApplyMessageKeyComplete = true

            local gvoice_cfg = ClientCfg.GetGVoiceCfg()
            -- 文明语音
            local path = gvoice_cfg.civil_bin_path
            if path and path ~= "" then
                l_instance:SetCivilBinPath(path)
                l_instance:EnableKeyWordsDetect(true)
            end
        else
            GCloudCompleteCodeTip("ApplyMessageKeyCompleteHandler",code)
        end
    end
end
-- 上传语音消息完成 回调
local function UploadReccordFileCompleteHandler(code, filepath, fileid)
    if l_instance and code then
        print("GVoice upload record file code, filepath, fileid :", code, filepath, fileid)
        if code == CompleteCode.kCompleteCodeUploadRecordDone then
            --GVoice.SpeechToText(fileid)
            l_instance.curUploadFileId = fileid
                if l_instance.uploadFileCallback then
                    l_instance.uploadFileCallback(fileid, "")
                    l_instance.uploadFileCallback = nil
                    l_instance.recordState = RECORD_STATE.RS_AVAILABLE
                end
        else
            GCloudCompleteCodeTip("UploadReccordFileCompleteHandler",code)
        end
        l_instance.recordState = RECORD_STATE.RS_AVAILABLE
        --ResumeRealTimeVoiceIfNeeded()
    end
end
-- 下载语音消息完成 回调
local function DownloadRecordFileCompleteHandler(code, filepath, fileid)
    if l_instance and code then
        print("GVoice download record file complete code, filepath, fileid", code, filepath, fileid)
        if code == CompleteCode.kCompleteCodeDownloadRecordDone then
            if l_instance.downloadFileCallback then
                l_instance.downloadFileCallback(fileid, filepath)
                l_instance.downloadFileCallback = nil
            end
        else
            GCloudCompleteCodeTip("DownloadRecordFileCompleteHandler", code)
        end
    end
end
-- 播放语音消息完成 回调
local function PlayRecordFilCompleteHandler(code, filepath)
    if l_instance and code then
        -- 恢复背景音
        local ECSoundMan = require "Sound.ECSoundMan"
        ECSoundMan.Instance():WakeupFromSuspend()
    end
end
-- 离线语音转文字 回调
local function SpeechToTextHandler(code, fileid, result)
    --ResumeRealTimeVoiceIfNeeded()
    if l_instance and code then
        print("GVoice speech file code, fileid, result :", code, fileid, result)
        if code == CompleteCode.kCompleteCodeSTTSucc then
            if l_instance.translateCompleteCallback then
                l_instance.translateCompleteCallback(fileid, result)
                l_instance.translateCompleteCallback = nil
                l_instance.recordState = RECORD_STATE.RS_AVAILABLE
            end
        else
            l_instance.recordState = RECORD_STATE.RS_AVAILABLE
            GCloudCompleteCodeTip("SpeechToTextHandler", code)
        end
    end
end
-- 实时语音转文字 回调
local function StreamSpeechToTextHandler(code, error, result, voicePath)
    if l_instance and code then
        print("GVoice stream speech file code, error, result :", code, error, result)
        if code == CompleteCode.kCompleteCodeRSTTSucc then
            --还没有使用实时语音转文字功能
            l_instance.recordState = RECORD_STATE.RS_AVAILABLE
            l_instance.curTranslateText = result
            if l_instance.RSTTCompleteCallback then
                l_instance.RSTTCompleteCallback(true, result, voicePath)
            end
        else
            l_instance.recordState = RECORD_STATE.RS_AVAILABLE
            l_instance.curTranslateText = ""
            if l_instance.RSTTCompleteCallback then
                l_instance.RSTTCompleteCallback(false, result, voicePath)
            end
            GCloudCompleteCodeTip("StreamSpeechToTextHandler", code)
        end
    end
end


-- 文明语音回调
-- 举报玩家回调
local function ReportPlayerHandler(code, info)
    print("GVoice report player code, info:   ", code, info)
    if l_instance then
        l_instance:OnReportPlayerHandler(code, info)
    end
end



---@param self MSDKGVoice 是否在加入过程中
---@return boolean
def.method("=>", "boolean").IsJoining = function (self)
    return self.bInitGvoice and GVoice.GetState and GVoice.GetState() == 1
end

---@param self MSDKGVoice 是否在房间中
---@return boolean
def.method("=>", "boolean").IsInRoom = function (self)
    return self.bInitGvoice and GVoice.GetState and GVoice.GetState() == 2
end

-- 设备相关API列表
-- 获取麦克风音量
---@param self MSDKGVoice
---@return number
def.method("=>", "number").GetMicLevel = function (self)
    local volume = 0
    if self.bInitGvoice then
        volume = GVoice.GetMicLevel()
    end
    return volume
end


---@param self MSDKGVoice
---@return string
def.method("=>", "string").GetRecordFilePath = function (self)
	if "" == self.recordFilePath then
		local dir = GameUtil.GetAssetsPath() .. "/Audio_arc/"
		return dir .. "myvoice.gv"
	else
		return self.recordFilePath
	end
end


---@param cb function
---@return void
def.static("function").TryGetPermission = function ( cb )
    if _G.platform == PLATFORM_TYPE_ANDROID then
        if not ZLUtil.checkSelfPermission("android.permission.RECORD_AUDIO") then
            local box = MsgBox.ShowMsgBox(nil, StringTable.Get(7680), nil, MsgBox.MsgBoxType.MBBT_YESNO, function (sender, ret)
                if ret == MsgBoxRetT.MBRT_OK then
                    local rationalBeforeRequest = ZLUtil.shouldShowRequestPermission("android.permission.RECORD_AUDIO")
                    _G._TempPause = true
                    ZLUtil.startAsyncAction("requestPermission", function ( requestCode, permission, granted )
                        _G._TempPause = false
                        local rationalAfterRequest = ZLUtil.shouldShowRequestPermission("android.permission.RECORD_AUDIO")
                        if granted then
                            cb(1,1,0)
                        else
                            local alwaysReject = not rationalBeforeRequest and not rationalAfterRequest
                            cb(0,0,alwaysReject and 1 or 0)
                        end
                    end, "android.permission.RECORD_AUDIO")
                    return
                else
                    cb(0,0,0)
                end
            end)
            box:SetOkText(StringTable.Get(77503))
            box:SetNoText(StringTable.Get(77504))
            return
        else
            cb(1,0,0)
        end
    elseif _G.platform == PLATFORM_TYPE_IOS or _G.platform == PLATFORM_TYPE_WINDOWS then
        _G._TempPause = true
        GVoice.TryGetPermission(function ( success, acquireThisTime )
            _G._TempPause = false
            cb(success, acquireThisTime, 1)
        end)
        return
    end
end

------------------------------------------------------------------------------------------------------
--- 一  基础流程（所有功能共通的流程）
--- 1.获取Gvoice引擎对象
---     lua中没有  GetVoiceEngine()    过程在cpp中
---     成功获得GVoice对象；失败返回空
--- 2.设置业务信息
---     注册为 GVoice.SetOpenId        注意参数顺序与文档有区别
---     在引擎Init前需要进行信息设置，传入的包括AppID、AppKey、OpenID
---         AppID 与 AppKey 找腾讯人员询问（GameID和GameKey）
---         OpenID 未用户唯一标识符（可以为手Q账号、微信账号、设备ID等）
---     返回值为ErrorNo
---         kErrorNoParamNULL           参数为空
---         kErrorNoSucc                成功
--- 3.初始化
---     Init()写在了 GVoice.SetOpenId 里    不需要在lua中调用
---     返回值为ErrorNo
---         kErrorNoNeedSetAppInfo      没有设置GameID和GameKey
---         kErrorNoInitErr             引擎创建出错
---         kErrorNoSucc                成功
--- 4.设置回调
---     用回调来通知异步操作结果，在Init()之后  SetNotify()
---     LuaGVoiceNotify实现了IGCloudVoiceNotify接口，lua只能实现cpp中已有的回调 GetNotify()->RegisterLuaCallback()
---     具体回调函数在后续各功能进行说明
---     注意：具体回调函数的返回值为CompleteCode     与ErrorNo有值相同 但意不同
---     返回值为ErrorNo
---         kErrorNoNeedInit            没有进行初始化
---         kErrorNoParamNULL           参数为空
---         kErrorNoSucc                成功
--- 5.设置引擎模式
---     Init之后  传入参数mode为模式 详见枚举值GVOICE_MODE
---     返回值为ErrorNo
---         kErrorNoNeedInit            没有初始化
---         kErrorNoInternalTVEErr      内部错误
---         kErrorNoRecordingErr        正在录制音频，请先关闭
---         kErrorNoSucc                成功
--- 6.查询触发事件回调
---     Poll()
---     lua中为 GVoice.Update()
---     返回值为ErrorNo
---         kErrorNoNeedInit            没有初始化
---         kErrorNoSucc                成功
--- 7.系统暂停（退后台）、系统恢复（返回）
---     Pause()、Resume()
---     lua中为 GVoice.OnApplicationPause()   将两个函数合并为一个开关
---     返回值为ErrorNo
------------------------------------------------------------------------------------------------------

---@type boolean 标志是否进行了初始化
def.field("boolean").bInitGvoice = false

---@return MSDKGVoice 单例
def.static("=>", MSDKGVoice).Instance = function()
    if not l_instance then
        l_instance = MSDKGVoice()
    end
    return l_instance
end

---@param self MSDKGVoice 初始化
---@return void
def.method().Init = function(self)
    -- 平台为内网Windows则放弃
    if _G.platform == PLATFORM_TYPE_WINDOWS and _G.IsWindowsSimuMobile() then
        return
    end
    -- 已经初始化过了
    if self.bInitGvoice then return end
    -- 配置信息   问腾讯人员要
    local gvoice_cfg = ClientCfg.GetGVoiceCfg()
    local appID = gvoice_cfg.app_id
    local appKey = gvoice_cfg.app_key
    -- 设置服务器地址  国外版本需要
    -- local url =
    local openId = MSDKInfo.Instance():GetMSDKInfo("openId")
    local hostId = LuaInt64.ToString(ECGame.Instance().m_HostInfo.id)
    -- 因队伍语音需求，还是传入角色ID比较方便设置禁音
    --print("gvoice: before setopenid ", openId, hostId)
    --local gvoice_setopenid = GVoice.SetOpenId(hostId, appID, appKey)

    --GVoice OpenID 为用户唯一性标识ID，由游戏根据自己的业务场景决定
    --海外版没有MSDK openId，使用hostId
    if not _G.ClientCfg.IsMSDK() then
        openId = hostId
    end
    local gvoice_setopenid = GVoice.SetOpenId(openId, appID, appKey)
   -- print("gvoice_setopenid_1 ", gvoice_setopenid)
    if gvoice_setopenid ~= 0 then
        GameUtil.AddGlobalTimer(2,true,function ()
            gvoice_setopenid = GVoice.SetOpenId(openId, appID, appKey)
            --print("gvoice_setopenid_2 ", gvoice_setopenid)
            self.bInitGvoice = true
        end)
    else
        self.bInitGvoice = true
    end

    if self.bInitGvoice then
        -- 海外版需要传入海外服务器地址
        -- GVoice.SetForeignNodeAddress(url)

        -- 设置回调
        self:SetHandler()

        -- 重新进入游戏时发现有没退出的房间，强制退出一下
        local RoomName = UserData.Instance():GetRoleCfg("GVoiceRoomName") or ""
        if RoomName:len() > 1 then
            GVoice.ForceQuitRoom(RoomName)
        end

        -- 语音消息     详见第三部分
        GVoice.ApplyMessageKey(MS_TIMEOUT)
        --GVoice.SetMaxMessageLength(_G.SPEECH_MESSAGE_MAX_TIME * 1000)

        -- 创建存储音频路径
        local dir = GameUtil.GetAssetsPath() .. "/Audio_arc/"
        self.recordFilePath = dir .. "myvoice.gv"
        GameUtil.CreateDirectoryForFile(self.recordFilePath)
    end
end

---@param self MSDKGVoice 设置回调
---@return void
def.method().SetHandler = function(self)
    --设置加入/退出房间回调
    GVoice.SetJoinRoomHandler(JoinRoomHandler)
    GVoice.SetQuitRoomHandler(QuitRoomHandler)
    GVoice.SetMemberVoiceHandler(MemberVoiceHandler)
    GVoice.SetMemberVoiceMultiRoomHandler(MemberVoiceMultiRoomHandler)
    if GVoice.SetRoleChangedHandler then
        GVoice.SetRoleChangedHandler(RoleChangedHandler)
    end
    -- 语音消息相关回调
    GVoice.SetApplyMessageKeyCompleteHandler(ApplyMessageKeyCompleteHandler)
    GVoice.SetUploadReccordFileCompleteHandler(UploadReccordFileCompleteHandler)
    GVoice.SetDownloadRecordFileCompleteHandler(DownloadRecordFileCompleteHandler)
    GVoice.SetPlayRecordFilCompleteHandler(PlayRecordFilCompleteHandler)
    GVoice.SetSpeechToTextHandler(SpeechToTextHandler)
    GVoice.SetStreamSpeechToTextHandler(StreamSpeechToTextHandler)
    -- 状态改变
    GVoice.SetStatusUpdateHandler(StatusUpdateHandler)
    GVoice.SetRoomMemberInfoHandler(RoomMemberInfoHandler)
    -- 举报玩家回调
    GVoice.SetReportPlayerHandler(ReportPlayerHandler)
end

-- 5.设置引擎模式
-- 设置引擎模式的何种模式
-- 根据文档修改，与龙族有区别
local GVOICE_MODE =
{
    GM_UNKNOW = -1,         -- 未知模式
    GM_REALTIME = 0,        -- 实时语音  (小队语音、国战语音、范围语音、多房间模式(仅支持两个小队或范围))
    GM_MESSAGES = 1,        -- 语音消息
    GM_TRANSLATION = 2,     -- 翻译模式  语音便条
    GM_RSTT = 3,            -- 实时语音转文字
    GM_HIGHQUALITY = 4,     -- 高质量模式
    GM_RSTS = 5,            -- 实时语音同传模式
}

---@param self MSDKGVoice 设置引擎模式
---@param mode number
---@return number
def.method("number", "=>", "number").SetMode = function(self, mode)
    local ret = GVoice.SetMode(mode)
    GVoiceErrorNoTip(ret)
    return ret
end

-- 6.查询触发事件回调
---@param self MSDKGVoice
---@return void
def.method().Update = function(self)
    if self.bInitGvoice then
        GVoice.Update()
    end
end

-- 7.暂停/恢复
---@param self MSDKGVoice
---@param paused boolean
---@return void
def.method("boolean").OnApplicationPause = function ( self, paused )
    if self.bInitGvoice then
        GVoice.OnApplicationPause(paused)
    end
end

------------------------------------------------------------------------------------------------------


------------------------------------------------------------------------------------------------------
--- 二  实时语音流程
---     初始化->设置模式为实时->加入房间->进房成功回调->开/关 麦/扬声器->退出房间
--- 1.加入小队语音房间
---     传入房间名与超时时间、返回码为ErrorNo
--- 2.加入国战语音房间
---     C++未接入，需要时请找相关人员添加。除了房间名和超时时间外，还有加入角色（目前包括两种）
--- 3.加入范围语音房间（同上未接入，与小队相同）
--- 4.更新坐标（在范围语音内）
--- 5.改变角色（国战语音内）
---
--- 6.打开/关闭麦克风
--- 7.打开/关闭扬声器
--- 8.退出房间
---     需要传入房间名和超时时间
---     三个房间都可以用这个函数，但现在只有小队房间
---
--- 9.运行多房间
---     在加入房间之前，仅传入一个布尔值
--- 10.开关房间麦克风/扬声器
---     对比之前函数，需要传入房间名和布尔值
---
--- 11.禁止接受某成员语音
--- 12.获取房间成员
--- 13.判断当前用户是否正在讲话
------------------------------------------------------------------------------------------------------

---@type function
def.field("function").joinRoomCompleteCallback = nil
---@type function
def.field("function").roomMemberJoinRoomCallback = nil
---@type function
def.field("function").roomMemberQuitRoomCallback = nil
---@type function
def.field("function").roomMemberStateChangeCallback = nil
---@type function
def.field("function").roomMemberJoinRoomStateChangeCallback = nil --作为roomMemberJoinRoomCallback的补充
---@type function 国战玩家角色改变回调
def.field("function").roomRoleChangedCallback = nil
---@param self MSDKGVoice
---@param roomName string
---@param cb function
---@param mj_cb function
---@param mq_cb function
---@param mj_st_cb function
---@return boolean
def.method("string", "function", "function", "function","function","=>", "boolean").JointTeamRoom = function (self, roomName, cb, mj_cb, mq_cb, mj_st_cb)
    if not self.bInitGvoice then
        warn("GVoice not Init")
        return false
    end

    local ret = self:SetMode(GVOICE_MODE.GM_REALTIME)
    if ret ~= 0 then
        print("GVoice JointTeamRoom : SetMode GM_REALTIME fail")
        return false
    end

    -- 配置信息   问腾讯人员要
    local gvoice_cfg = ClientCfg.GetGVoiceCfg()
    self:SetReportBufferTime(gvoice_cfg.civil_buffer_time)

    self.joinRoomCompleteCallback = cb
    self.roomMemberJoinRoomCallback = mj_cb
    self.roomMemberQuitRoomCallback = mq_cb
    self.roomMemberJoinRoomStateChangeCallback = mj_st_cb
    --self.roomMemberStateChangeCallback = msc_cb
    ret = GVoice.JoinTeamRoom(roomName)
    if ret ~= 0 then
        print("GVoice JointTeamRoom fail roomName : ", roomName)
        GVoiceErrorNoTip(ret)
        return false
    end
    print("GVoice JointTeamRoom succ roomName : ", roomName)
    return true
end

-- 加入国战语音房间
---@param self MSDKGVoice
---@param roomName string
---@param role number
---@param cb function
---@param mj_cb function
---@param mq_cb function
---@param mj_st_cb function
---@param rc_cb function
---@return boolean
def.method("string","number", "function", "function", "function","function","function","=>", "boolean").JoinNationalRoom = function (self, roomName,role, cb, mj_cb, mq_cb, mj_st_cb, rc_cb)
    if not self.bInitGvoice then
        warn("GVoice not Init")
        return false
    end

    local ret = self:SetMode(GVOICE_MODE.GM_REALTIME)
    if ret ~= 0 then
        print("GVoice JointTeamRoom : SetMode GM_REALTIME fail")
        return false
    end

    -- 配置信息   问腾讯人员要
    local gvoice_cfg = ClientCfg.GetGVoiceCfg()
    self:SetReportBufferTime(gvoice_cfg.civil_buffer_time)

    self.joinRoomCompleteCallback = cb
    self.roomMemberJoinRoomCallback = mj_cb
    self.roomMemberQuitRoomCallback = mq_cb
    self.roomMemberJoinRoomStateChangeCallback = mj_st_cb
    self.roomRoleChangedCallback = rc_cb
    if not GVoice.JoinNationalRoom then
        FlashTipMan.FlashTip(StringTable.Get(30032))
        return false
    end
    ret = GVoice.JoinNationalRoom(roomName,role)
    if ret ~= 0 then
        print("GVoice JointTeamRoom fail roomName : ", roomName)
        GVoiceErrorNoTip(ret)
        return false
    end
    print("GVoice JointTeamRoom succ roomName : ", roomName)
    return true
end

---@param self MSDKGVoice
---@param flag boolean
---@return void
def.method("boolean").SetMic = function (self, flag)
    if not self.bInitGvoice then
        warn("GVoice not Init")
        return
    end
    local ret = 0
    if flag then
        ret = GVoice.OpenMic()
    else
        ret = GVoice.CloseMic()
    end
    print("SetMic flag, ret", flag, ret)
    if ret ~= 0 then
        GVoiceErrorNoTip(ret)
    end
end

---@param self MSDKGVoice
---@param flag boolean
---@return void
def.method("boolean").SetSpeaker = function (self, flag)
    if not self.bInitGvoice then
        warn("GVoice not Init")
        return
    end
    local ret = 0
    if flag then
        ret = GVoice.OpenSpeaker()
    else
        ret = GVoice.CloseSpeaker()
    end
    print("SetSpeaker flag, ret", flag, ret)
    if ret ~= 0 then
        GVoiceErrorNoTip(ret)
    end
end

---@type function
def.field("function").quitRoomCompleteCallback = nil
---@param self MSDKGVoice
---@param roomName string
---@param cb function
---@return boolean
def.method("string", "function", "=>", "boolean").QuitRoom = function (self, roomName, cb)
    if not self.bInitGvoice then
        warn("GVoice not Init")
        return false
    end

    self.quitRoomCompleteCallback = cb
    local ret = GVoice.ForceQuitRoom(roomName)
    if ret ~= 0 then
        print("GVoice QuitRoom fail roomName : ", roomName)
        GVoiceErrorNoTip(ret)
        return false
    end
    print("GVoice QuitRoom succ roomName : ", roomName)
    return true
end

---@param self MSDKGVoice
---@param enable boolean
---@return boolean
def.method("boolean", "=>", "boolean").EnableRoomMore = function (self, enable)
    if not self.bInitGvoice then
        warn("GVoice not Init, by EnableRoomMore")
        return false
    end

    local ret = 0
    ret = self:SetMode(GVOICE_MODE.GM_REALTIME)
    if ret ~= 0 then
        print("GVoice EnableRoomMore : SetMode fail : ret ", ret)
        GVoiceErrorNoTip(ret)
        return false
    end

    ret = 0
    ret = GVoice.EnableMultiRoom(enable)
    if ret ~= 0 then
        GVoiceErrorNoTip(ret)
        return false
    end
    print("GVoice EnableRoomMore Success : ",ret)
    return true
end

---@param self MSDKGVoice
---@param roomName string
---@param enable boolean
---@return boolean
def.method("string", "boolean", "=>", "boolean").EnableRoomMic = function (self, roomName, enable)
    if not self.bInitGvoice then
        warn("GVoice not Init")
        return false
    end

    local ret = GVoice.EnableRoomMicrophone(roomName,enable)
    if ret ~= 0 then
        print("GVoice EnableRoomMic fail roomName : ", roomName, enable)
        GVoiceErrorNoTip(ret)
        return false
    end
    print("GVoice EnableRoomMic succ roomName : ", roomName, enable)
    return true
end

---@param self MSDKGVoice
---@param roomName string
---@param enable boolean
---@return boolean
def.method("string", "boolean", "=>", "boolean").EnableRoomSpeaker = function (self, roomName, enable)
    if not self.bInitGvoice then
        warn("GVoice not Init")
        return false
    end

    local ret = GVoice.EnableRoomSpeaker(roomName,enable)
    if ret ~= 0 then
        print("GVoice EnableRoomSpeaker fail roomName : ", roomName, enable)
        GVoiceErrorNoTip(ret)
        return false
    end
    print("GVoice EnableRoomSpeaker succ roomName : ", roomName, enable)
    return true
end

---@param self MSDKGVoice
---@param playerMember number
---@param isForbid boolean
---@param roomName string
---@return boolean
def.method("number", "boolean", "string", "=>", "boolean").ForbidMemberVoiceInRoom = function (self, playerMember, isForbid, roomName)
    if not self.bInitGvoice then
        warn("GVoice not Init")
        return false
    end

    local ret = GVoice.ForbidMemberVoiceInRoom(playerMember,isForbid,roomName)
    if ret ~= 0 then
        print("GVoice ForbidMemberVoiceInRoom fail roomName,playerMember : ", roomName,playerMember)
        GVoiceErrorNoTip(ret)
        return false
    end
    print("GVoice ForbidMemberVoiceInRoom succ roomName,playerMember,isForbid : ", roomName, playerMember, isForbid)
    return true
end

---@param self MSDKGVoice
---@param roomName string
---@return table
def.method("string", "=>", "table").GetRoomMembers = function (self, roomName)
    if not self.bInitGvoice then
        warn("GVoice not Init")
        return nil
    end

    if roomName == "" then
       warn("GetRoomMembers roomName can not be null")
        return nil
    end

    local members = GVoice.GetRoomMembers(roomName)
    if not members then
        print("GVoice GetRoomMembers fail roomName,playerMember : ", roomName)
        return nil
    end
    print("GVoice GetRoomMembers succ roomName,playerMember : ", roomName)
    return members
end

---@param self MSDKGVoice
---@return boolean
def.method("=>", "boolean").IsSpeakingInRoom = function (self)
    if not self.bInitGvoice then
        warn("GVoice not Init")
        return false
    end

    local isSpeaking = GVoice.IsSpeaking()
    return isSpeaking
end

------------------------------------------------------------------------------------------------------
------------------------------------------------------------------------------------------------------
--- 三  语音消息流程
---     初始化后，设置语音模式为语音消息模式（2），再进行相关逻辑
--- 1.申请语音消息key
---     ApplyMessageKey(int)    写在了初始化中
---     调用回调函数OnApplyMessageKey(code)来返回结果
---     返回值 ErrorNo
---     回调函数OnApplyMessageKey(code)     code 值为CompleteCode
--- 2.开始录音
---     传入参数为录音文件存储的地址路径    VoIP模式暂时不管
---     GVoice.StartRecording()
--- 3.停止录音
---     GVoice.StopRecording()
---     取消与结束逻辑一样，先删了
--- 4.上传录音
---     传至GVoice服务器，有上传成功回调函数
--- 5.下载语音
---     从GVoice服务器下载，有下载成功回调函数（用来播放语音）
--- 6.播放语音/停止播放
---     可播放录制的或者下载的，有正常播放完的回调函数
---     仅支持GVoice引擎录制的语音消息
--- 7.语音转文字
---     离线语音转文字（Translation）
---     在Translation中只支持中文，转别的语种去RSTT模式
---     回调接口为OnSpeeckToText，翻译结果也在此获得
---     传入文件ID、转换语种（0：中文）、超时时间
--- 8.设置语音消息最大长度
---     在Init中进行了设置，目前为15s
--- 9.获得录音文件大小和时长
---     在下载语音后可进行获取，cpp中好像没接，lua中没有调用该接口的函数
---
---回调函数
--- 10.请求语音消息Key回调
---     成功才能进行语音消息功能
--- 11.上传完成回调
---     参数有路径、服务器中唯一ID
--- 12.下载完成回调
---     路径、ID
--- 13.正常播放完成回调
---     播放文件路径
--- 14.正常录音中的回调
--- 15.语音转文字完成回调
--- 16.实时语音转文字完成回调
------------------------------------------------------------------------------------------------------

-- 开始录音
-- 将同传与消息分开，接口差别太大
---@param self MSDKGVoice
---@return boolean
def.method("=>", "boolean").BeginRecord = function(self)
    if not self.bInitGvoice then
        print("GVoice BeginRecord : is not ready!")
        return false
    end

    if self.curFileId ~= "" then
        self:StopPlay()
    end

    if self.recordState ~= RECORD_STATE.RS_AVAILABLE then
        print("GVoice BeginRecord : message is busy")
        return false
    end

    local ret = 0
    ret = self:SetMode(GVOICE_MODE.GM_MESSAGES)
    if ret ~= 0 then
        print("GVoice BeginRecord : SetMode fail : ret ", ret)
        GVoiceErrorNoTip(ret)
        return false
    end

    if not self.bApplyMessageKeyComplete then
        print("GVoice BeginRecord : apply message authkey fail")
        GVoice.ApplyMessageKey(MS_TIMEOUT)
        return false
    end

    self.recordState = RECORD_STATE.RS_RECORDING
    print("self.recordFilePath ===================",self.recordFilePath)
    local ret = GVoice.StartRecording(self.recordFilePath)
    if ret ~= 0 then
        GVoiceErrorNoTip(ret)
        self.recordState = RECORD_STATE.RS_AVAILABLE
        return false
    end
    return true
end

-- 结束录音
---@param self MSDKGVoice
---@return boolean
def.method("=>", "boolean").EndRecord = function(self)
    if not self.bInitGvoice then
        print("GVoice EndRecord : is not ready!")
        return false
    end

    if self.recordState == RECORD_STATE.RS_RECORDING then
        local ret = GVoice.StopRecording()
        if ret ~= 0 then
            print("GVoice EndRecord : StopRecording fail ret : ", ret)
            GVoiceErrorNoTip(ret)
            return false
        end

        self.recordState = RECORD_STATE.RS_AVAILABLE
        print("GVoice end record ok")
        return true
    else
        warn("GVoice EndRecord : is not recording")
        return false
    end
end

-- 上传语音
---@type function 上传成功后的回调函数
def.field("function").uploadFileCallback = nil
---@type string 上传后的语音ID，翻译时会用到
def.field("string").curUploadFileId = ""
---@param self MSDKGVoice
---@param cb function
---@return boolean
def.method("function", "=>", "boolean").UploadAudio = function(self, cb)
    if not self.bInitGvoice then
        print("GVoice UploadAudio : is not ready!")
        return false
    end

    if self.recordState ~= RECORD_STATE.RS_AVAILABLE then
        print("GVoice UploadAudio : message is busy")
        return false
    end

    self.uploadFileCallback = cb
    local ret = GVoice.UploadRecordedFile(self.recordFilePath, MS_TIMEOUT)
    if ret ~= 0 then
        self.recordState = RECORD_STATE.RS_AVAILABLE
        print("GVoice EndRecord : UploadRecordedFile fail ret : ", ret)
        GVoiceErrorNoTip(ret)
        return false
    end

    self.recordState = RECORD_STATE.RS_UPLOADING
    return true
end

-- 下载语音
---@type function 下载成功后的回调函数
def.field("function").downloadFileCallback = nil
---@param self MSDKGVoice
---@param fileId string 文件ID
---@param filePath string 存储路径
---@param cb function 成功回调
---@return boolean
def.method("string", "string", "function", "=>", "boolean").DownloadAudio = function(self, fileId, filePath, cb)
    if not self.bInitGvoice then
        print("GVoice DownloadAudio : is not ready!")
        return false
    end

    if self.recordState ~= RECORD_STATE.RS_AVAILABLE then
        print("GVoice DownloadAudio : message is busy")
        return false
    end

    local ret = 0
    self:SetMode(GVOICE_MODE.GM_MESSAGES)
    self.downloadFileCallback = cb
    ret = GVoice.DownloadRecordedFile(fileId, filePath, MS_TIMEOUT)
    if ret ~= 0 then
        -- self:SetMode(GVOICE_MODE.GM_REALTIME) 为什么转模式？
        print("GVoice DownloadAudio : ", filePath, fileId, false, "fail:", ret)
        return false
    end
    return true
end

-- 播放语音
-- 有正常播放完的回调函数OnPlayRecordedFile
---@type string 播放语音文件ID
def.field("string").curFileId = ""
---@param self MSDKGVoice
---@param fileId string
---@param filepath string
---@return boolean
def.method("string", "string", "=>", "boolean").PlayAudio = function(self, fileId, filepath)
    if not self.bInitGvoice then
        print("GVoice PlayAudio : is not ready!")
        return false
    end

    if self.recordState ~= RECORD_STATE.RS_AVAILABLE then
        print("GVoice PlayAudio : message is busy")
        return false
    end

    local ret = 0
    ret = self:SetMode(GVOICE_MODE.GM_MESSAGES)
    if ret ~= 0 then
        print("GVoice PlayAudio : SetMode GM_MESSAGES fail")
        return false
    end

    if self.curFileId ~= "" then
        if self.curFileId == fileId then
            return true
        else
            self:StopPlay()
        end
    end

    if not self.bApplyMessageKeyComplete then
        print("GVoice PlayAudio : apply message authkey fail")
        return false
    end

    ret = GVoice.PlayRecordedFile(filepath)
    if ret ~= 0 then
        print("GVoice PlayAudio : play recorded file fail : ret", ret)
        return false
    end
    self.curFileId = fileId
    return true
end
-- 停止播放
---@param self MSDKGVoice
---@return boolean
def.method("=>", "boolean").StopPlay = function (self)
    if not self.bInitGvoice then
        print("GVoice StopPlay : is not ready!")
        return false
    end

    if not self.curFileId or self.curFileId:len() <= 1 then
        return false
    end

    local ret = GVoice.StopPlayFile()
    if ret ~= 0 then
        print("GVoice StopPlayFile : stop play file fail, ret : ", ret)
        return false
    end
    self.curFileId = ""
    return true
end

-- 语音转文字 Translate模式
---@type function 离线翻译完成后的回调函数
def.field("function").translateCompleteCallback = nil
---@param self MSDKGVoice
---@param fileid string
---@param cb function
---@return boolean
def.method("string","function", "=>", "boolean").Translate = function (self, fileid, cb)
    if not self.bInitGvoice then
        print("GVoice Translate : is not ready!")
        return false
    end

    local ret = 0
    ret = self:SetMode(GVOICE_MODE.GM_TRANSLATION)
    if ret ~= 0 then
        print("GVoice Translate : SetMode GM_TRANSLATION fail")
        return false
    end

    self.translateCompleteCallback = cb
    ret = GVoice.SpeechToText(fileid, 0, MS_TIMEOUT)
    if ret ~= 0 then
        print("GVoice Translate : speech play to text, ret : ", ret)
        return false
    end
    self.recordState = RECORD_STATE.RS_TRANSLATE
    return true
end

-- 实时语音转文字 RSTT模式
-- 因为新版本GCloud2.0.19离线翻译接口被删除，内部流程均使用实时转文字接口
---@type function
def.field("function").RSTTCompleteCallback = nil
---@param self MSDKGVoice
---@param cb function
---@return boolean
def.method("function", "=>", "boolean").BeginRecordByRSTT = function (self, cb)
    if not self.bInitGvoice then
        print("GVoice Translate : is not ready!")
        return false
    end

    local ret = 0
    ret = self:SetMode(GVOICE_MODE.GM_RSTT)
    if ret ~= 0 then
        print("GVoice Translate : SetMode GM_RSTT fail")
        return false
    end

    if self.curFileId ~= "" then
        self:StopPlay()
    end

    self.RSTTCompleteCallback = cb

    if self.recordState ~= RECORD_STATE.RS_AVAILABLE then
        print("GVoice BeginRecord : message is busy")
        return false
    end

    if ret ~= 0 then
        print("GVoice BeginRecord : SetMode fail : ret ", ret)
        GVoiceErrorNoTip(ret)
        return false
    end

    if not self.bApplyMessageKeyComplete then
        print("GVoice BeginRecord : apply message authkey fail")
        GVoice.ApplyMessageKey(MS_TIMEOUT)
        return false
    end

    self.recordState = RECORD_STATE.RS_RECORDING
    print("self.recordFilePath ===================",self.recordFilePath)
    local ret = GVoice.StartRecording(self.recordFilePath)
    if ret ~= 0 then
        GVoiceErrorNoTip(ret)
        self.recordState = RECORD_STATE.RS_AVAILABLE
        return false
    end
    return true
end

------------------------------------------------------------------------------------------------------
------------------------------------------------------------------------------------------------------
--- 五   文明语音
---     目前没有开启腾讯安全测功能，因此只做本地的关键词检测（仅检测自身）
--- 1.关键词检测
---     在语音消息Key申请成功后进行设置，设置成功即可通过回调函数来确认是否有不文明用语
---     回调函数为OnReportPlayer
--- 2.设置语料库路径
---     通过配置设置，在初始化后，开启检测之前
------------------------------------------------------------------------------------------------------

---@param self MSDKGVoice
---@param flag boolean
---@return void
def.method("boolean").EnableKeyWordsDetect = function (self, flag)
    if not self.bInitGvoice then
        warn("GVoice not Init")
        return
    end

    local ret = GVoice.EnableKeyWordsDetect(flag)

    if ret ~= 0 then
        GVoiceErrorNoTip(ret)
    end
end

---@param self MSDKGVoice
---@param path string
---@return void
def.method("string").SetCivilBinPath = function (self, path)
    if not self.bInitGvoice then
        warn("GVoice not Init")
        return
    end

    local ret = GVoice.SetCivilBinPath(path)

    if ret ~= 0 then
        GVoiceErrorNoTip(ret)
    end
end

---设置客户端录制时长
---该接口会清空语音缓冲区，不要在调用后立即调用 ReportPlayer 接口
---@param self MSDKGVoice
---@param nSecs number
---@return void
def.method("number").SetReportBufferTime = function(self, nSecs)
    if not self.bInitGvoice then
        warn("GVoice not Init")
        return
    end
    if not GVoice.SetReportBufferTime then
        return
    end
    GVoice.SetReportBufferTime(nSecs)
end

---设置可以被举报的玩家信息
---SDK 只会缓冲设置进来的玩家的语音数据，该接口同样会清空语音缓冲区
---@param self MSDKGVoice
---@param openids table
---@param memberids table
---@return void
def.method("table", "table").SetReportedPlayerInfo = function(self, openids, memberids)
    if not self.bInitGvoice then
        warn("GVoice not Init")
        return
    end
    local nOpenids = openids and #openids or 0
    local nMembers = memberids and #memberids or 0
    if nOpenids ~= nMembers or nOpenids * nMembers == 0 then
        warn("openid count not equal to members or empty")
        return
    end

    if not GVoice.SetReportedPlayerInfo then
        return
    end

    local ret = GVoice.SetReportedPlayerInfo(openids, memberids)
    if ret ~= 0 then
        GVoiceErrorNoTip(ret, "SetReportedPlayerInfo")
    end
end

---@param self MSDKGVoice
---@param openids table
---@param strInfo string
---@return number
def.method("table", "string", "=>", "number").ReportPlayer = function(self, openids, strInfo)
    if not self.bInitGvoice then
        warn("GVoice not Init")
        return ErrorNo.kErrorNoNeedInit
    end
    local nOpenids = openids and #openids or 0
    if nOpenids == 0 then
        warn("openiss is empty")
        return ErrorNo.kErrorNoParamInvalid
    end

    if not GVoice.ReportPlayer then
        return 0
    end

    local ret = GVoice.ReportPlayer(openids, strInfo)
    if ret ~= 0 then
        GVoiceErrorNoTip(ret, "ReportPlayer")
    end

    return ret
end

---举报玩家的结果回调
---@param self MSDKGVoice
---@param code number
---@param strInfo string
---@return void
def.method("number", "string").OnReportPlayerHandler = function(self, code, strInfo)
    if code == CompleteCode.kCompleteCodeReportSucc then --举报成功
        FlashTipMan.FlashTip(StringTable.Get(114811))
    elseif code == CompleteCode.kCompleteCodePunished then --被他人举报成功 提示
        local UserDataTable = UserData.Instance()
        local cur_time = GameUtil.GetServerGMTTime()
        UserDataTable:SetRoleCfg("ReportSuccSelfLocalTime",cur_time)
    end
end

---@param self MSDKGVoice
---@param bEnable boolean
---@return void
def.method("boolean").EnableCivilVoice = function(self, bEnable)
    if not self.bInitGvoice then
        warn("GVoice not Init")
        return
    end

    if not GVoice.EnableCivilVoice then
        return
    end

    local ret = GVoice.EnableCivilVoice(bEnable)
    if ret ~= 0 then
        GVoiceErrorNoTip(ret, "EnableCivilVoice")
    end
end

---@param self MSDKGVoice
---@param bEnable boolean
---@return void
def.method("boolean").EnableReportALL = function(self, bEnable)
    if not self.bInitGvoice then
        warn("GVoice not Init")
        return
    end

    if not GVoice.EnableReportALL then
        return
    end

    local ret = GVoice.EnableReportALL(bEnable)
    print(" GVoice EnableReportALL ")
    if ret ~= 0 then
        GVoiceErrorNoTip(ret, "EnableReportALL")
    end
end

--举报不良语音
---@param self MSDKGVoice
---@param desc string
---@param params table
---@return void
def.method("string", "table").ReportTeamBadVoice = function(self, desc, params)
    local gvoice_cfg = _G.ClientCfg.GetGVoiceCfg()

    local UserDataTable = UserData.Instance()
    if not UserDataTable:GetSystemCfg("ReportBadVoice") then
        FlashTipMan.FlashTip(StringTable.Get(114812))
        return
    end

    --举报太过频繁
    local lastReportTime = UserDataTable:GetSystemCfg("ReportBadVoiceTimestamp") or 0
    local nowReportTime = GameUtil.GetServerGMTTime()
    local interTime = nowReportTime - lastReportTime 
    if interTime < gvoice_cfg.civil_cooldown then
        FlashTipMan.FlashTip(StringTable.Get(114813):format( gvoice_cfg.civil_cooldown - interTime))
        return
    end

    local MSDKInfo = require "MSDK.MSDKInfo"

    local FriendMan = require "Friends.FriendMan"
    local friendCnt = 0
    local teamMemberCnt = 0
    local openids = {}
    if globalGame.m_HostPlayer.Team then
        local members = globalGame.m_HostPlayer.Team:GetMemberList()
        teamMemberCnt = #members
        for i=1, teamMemberCnt do
            if members[i].ID ~= globalGame.m_HostPlayer.ID then
                local isfriend = FriendMan.Instance():IsPlayerYourFriend(members[i].ID)
                if isfriend then
                    friendCnt = friendCnt + 1
                end
                if _G.ClientCfg.IsMSDK() then --腾讯渠道
                    openids[#openids+1] = MSDKInfo.Instance():TryGetOpenID(members[i].ID)
                else
                    openids[#openids+1] = LuaUInt64.ToString(members[i].ID)
                end
            end
        end
    end

    --没有队伍，或者队伍中只有自己
    if not globalGame.m_HostPlayer.Team or teamMemberCnt <=1 then
        FlashTipMan.FlashTip(StringTable.Get(114810))
        return
    end

    --全部是好友
    if friendCnt == teamMemberCnt - 1 then
        FlashTipMan.FlashTip(StringTable.Get(114810))
        return
    end

    --记录举报时间
    UserDataTable:SetSystemCfg("ReportBadVoiceTimestamp", GameUtil.GetServerGMTTime())

    print_r("client report:", tostring_r(openids))
    --TODO:GVoice举报
    local ret = self:ReportPlayer(openids, desc)
    if ret == ErrorNo.kErrorNoNothingToReport then
        FlashTipMan.FlashTip(StringTable.Get(114810))
        return
    elseif ret == ErrorNo.kErrorNoHttpBusy then
        FlashTipMan.FlashTip(StringTable.Get(114814))
        return
    elseif ret ~= ErrorNo.kErrorNoSucc then
        FlashTipMan.FlashTip(StringTable.Get(114815))
        return
    end
end


MSDKGVoice.Commit()
return MSDKGVoice
