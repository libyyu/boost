-------------------------------------------------------------------------------------------
-- MSDK相关的数据
-------------------------------------------------------------------------------------------

local Lplus = require "Lplus"
local Json = require "Utility.json"
require "MSDK.MSDKDefine"
---@class ECMSDK.MSDKInfo:System.Object
---@field public MSDKKey string
---@field public APPID table
---@field public APPKEY table
---@field public OFFERID table
---@field public PAYTYPE table
---@field public SHARETYPE table
---@field public TOKENTYPE table
---@field public URLs table
---@field public WebAuthRedirectUri table
---@field public ShareReqType table
---@field public ChannelPackageName table
---@field protected m_InfoDic table
---@field protected m_roleIdToOpenId table
---@field private _getOpenIdCallback table
---@field public Commit fun():ECMSDK.MSDKInfo @notnull
---@field public Instance fun():ECMSDK.MSDKInfo
---@field public SaveMSDKInfo fun(self:ECMSDK.MSDKInfo, key:string, value:any)
---@field public GetMSDKInfo fun(self:ECMSDK.MSDKInfo, key:string):any
---@field public Clear fun(self:ECMSDK.MSDKInfo)
---@field public TryGetOpenID fun(self:ECMSDK.MSDKInfo, roleid:string):string
---@field public TryGetRoleIDByOpenId fun(self:ECMSDK.MSDKInfo, openid:string):string
---@field public RecordUserOpenID fun(self:ECMSDK.MSDKInfo, roleid:string, openid:string)
---@field public RequestOpenIDByRoleID fun(self:ECMSDK.MSDKInfo, roleid:string, cb:function)
local MSDKInfo = Lplus.Class("ECMSDK.MSDKInfo")
     
local def = MSDKInfo.define
local instance = nil

---@type string
def.const("string").MSDKKey = "29d42eaa176aeaded79194f2e8868fd6"

---@type table
def.const("table").APPID =
{
	QQ = "1110048757",
	WX = "wxf902c98a6f6dc266",
}

---@type table
def.const("table").APPKEY =
{
	QQ = "Btyr9KB7Z2oG1v9i",
	WX = "c5081b4da24ae529f350a5022f9afedf",
}

---@type table
def.const("table").OFFERID =
{
	IOS = "1450024563",
	ANDROID = "1450024101",
}
-- def.const("table").NOTICETYPE =
-- {
-- 	BEFOR_LOGIN_ALERT_SCENE = "1",
-- 	LOGIN_ALERT_SCENE = "2",
-- 	BEFOR_LOGIN_SCROLL_SCENE = "509",
-- 	LOGIN_SCROLL_SCENE = "511",
-- }

-- def.const("table").LOGINPRIVILEGETYPE = 
-- {
-- 	NON = 0, 
-- 	QQ = 1, 
-- 	WX = 2, 
-- 	YYB = 3
-- }

-- 支付购买类型

---@type table
def.const("table").PAYTYPE =
{
	NORMAL = 1, --1:购买虚拟币、道具
	CYCLE = 2,	--2:购买月卡
}

---@type table
def.const("table").SHARETYPE = --1.普通会话 2.空间(朋友圈)
 {
	CONVERSATION = 1,
 	FRIENDSCIRCLE = 2,
 	OTHER = 3,
	FACEBOOK = 4,
	TWITTER = 5,
 }

---@type table
def.const("table").TOKENTYPE =
{
	FOREIGN = 0,
	QQ_ACCESS = 1,
	QQ_PAY = 2,
	WX_ACCESS = 3,
	WX_CODE = 4, --deprcated
	WX_REFRESH = 5,
 	GUEST_ACCESS = 6,
}

-- def.const("table").GAMETAG = 
-- {
-- 	QQ = 
-- 	{
-- 		INVITE = "MSG_INVITE", 
-- 		INVITE_ARK = "MSG_INVITE_ARK", 
-- 		EXCEED = "MSG_FRIEND_EXCEED", 
-- 		SEND = "MSG_HEART_SEND", 
-- 		PVP = "MSG_SHARE_FRIEND_PVP", 
-- 		RECALL = "MSG_FRIEND_RECALL_HYZH",
-- 		INVITE_FRIEND_ARK= "MSG_INVITE_FRIEND_ARK",
-- 	},
-- 	WX = 
-- 	{
-- 		INVITE = "MSG_INVITE", 
-- 		EXCEED = "MSG_friend_exceed", 
-- 		SEND = "MSG_heart_send", 
-- 		HIGHSCORE = "MSG_SHARE_MOMENT_HIGH_SCORE", 
-- 		RECALL = "MSG_FRIEND_RECALL_HYZH", 
-- 		BESTSCORE = "MSG_SHARE_MOMENT_BEST_SCORE", 
-- 		CROWN = "MSG_SHARE_MOMENT_CROWN",
-- 		SHAREHIGHSCORE = "MSG_SHARE_FRIEND_HIGH_SCORE",
-- 		SHAREBESTSCORE = "MSG_SHARE_FRIEND_BEST_SCORE",
-- 		SHAREFRIENDCROWW = "MSG_SHARE_FRIEND_CROWN",
-- 		GIFT = "MSG_GIFT_PACKS_FD",
-- 		INVITE_FRIEND_ARK= "MSG_INVITE_FRIEND_ARK",
-- 	}
-- }

-- def.const("table").ADTAG = 
-- {
-- 	INVITE = "gameobj.msg_invite",
-- 	EXCEED = "gameobj.msg_exceed",
-- 	HEART = "gameobj.msg_heart",
-- 	PVP = "gameobj.msg_pvp",
-- 	SHOW = "gameobj.msg_show",
-- }
local plat_logo = {
	["IOS"] = "https://azure-1300342622.cos.ap-beijing.myqcloud.com/icon_ios.png",
	["Android"] = "https://azure-1300342622.cos.ap-beijing.myqcloud.com/icon_android.png",
	["default"] = "https://azure-1300342622.cos.ap-beijing.myqcloud.com/icon.png"
}
---@type table
def.const("table").URLs =
{
	Logo = plat_logo[GameUtil.GetPlatformName()] or plat_logo["default"],				-- 使用腾讯云Cos储存做的
	-- 游戏Logo 分享使用的缩略图, 根据项目进行配置
	-- Logo = "https://game.gtimg.cn/images/xiawa/cp/D181226/images/96-.png",			-- 分享Logo 需要替换，现在是龙族的
	-- QQGameCenter = "https://dna.qq.com/cp/a20181211xtcs/index.html?adtag=game",
	-- WXGameCenter = "https://dna.qq.com/cp/a20181211xtcs/index.html?adtag=game",
	-- SharePic = "https://ossweb-img.qq.com/images/1213share.jpg",
	-- QQVIP = "https://imgcache.gtimg.cn/ACT/svip_act/act_img/v_xkhuang/201701/m1484126920_hyzhmz.jpg",
	-- TargetURL = "https://gamecenter.qq.com/gamecenter/index/detail.html?appid=1105938573&pf=invite&plat=qq&from=%s&ADTAG=gameobj.msg_heart&originuin=%s",
	-- CheckFirst = "%s/profile/%s?timestamp=%d&appid=%s&sig=%s&openid=%s&encode=2",--检测是否首次登陆
	-- MSDKURLAndroid = "https://da.ssl.msdk.qq.com",
	-- MSDKURLIOS = "https://i.ssl.msdk.qq.com",

	-- PC端的Web页面授权
	WebAuthQQ = "https://graph.qq.com/oauth2.0/authorize?response_type=code&client_id=%s&redirect_uri=%s&state=%s",
	WebAuthWeChat = "https://open.weixin.qq.com/connect/qrconnect?appid=%s&redirect_uri=%s&response_type=code&scope=snsapi_login&state=%s#wechat_redirect",
}

---@type table
def.const("table").WebAuthRedirectUri = {
	QQ = "https://nyzx.qq.com",
	WeChat = "https://nyzx.qq.com/",
}

---@type table
def.const("table").ShareReqType =
{
	kMSDKFriendReqTypeText 		= 10000,           	--文字分享
	kMSDKFriendReqTypeLink 		= 10001,           	--链接分享
	kMSDKFriendReqTypeIMG 		= 10002,            --图片分享
	kMSDKFriendReqTypeInvite 	= 10003,         	--应用邀请
	-- kMSDKFriendReqTypeMusic,                  --音乐分享
	-- kMSDKFriendReqTypeVideo,                  --视频分享
	kMSDKFriendReqTypeMiniApp	= 10006,            --小程序分享
	-- kMSDKFriendReqTypePullUpMiniApp,          --小程序拉起
	kMSDKFriendReqTypeArk       = 10008,            --ARK分享
	-- kMSDKFriendReqTypeOpenBusinessView,       --业务功能拉起

	-- kMSDKFriendReqTypeTextSilent = 20000,     --文字分享（静默）
	-- kMSDKFriendReqTypeLinkSilent,             --链接分享 (静默)
	-- kMSDKFriendReqTypeIMGSilent,              --图片分享 （静默）
	-- kMSDKFriendReqTypeInviteSilent,           --应用邀请 (静默）
	-- kMSDKFriendReqTypeMusicSilent,            --音乐分享 (静默)
	-- kMSDKFriendReqTypeVideoSilent,            --视频分享 (静默)
	-- kMSDKFriendReqTypeMiniAppSilent,          --小程序分享 (静默)
}

-- for android, TODO: 这些常量需要整理到一个公共的地方

---@type table
def.const("table").ChannelPackageName = {
	[MSDK_LOGIN_PLATFORM.WX] = "com.tencent.mm",
	[MSDK_LOGIN_PLATFORM.QQ] = "com.tencent.mobileqq",
	[MSDK_LOGIN_PLATFORM.FACEBOOK] = "com.facebook.katana",
	[MSDK_LOGIN_PLATFORM.TWITTER] = "com.twitter.android",
	[MSDK_LOGIN_PLATFORM.LINE] = "jp.naver.line.android",
}

---@type table
def.field("table").m_InfoDic = nil

---@return ECMSDK.MSDKInfo
def.static("=>", MSDKInfo).Instance = function()
	if not instance then
		instance = MSDKInfo()
		instance.m_InfoDic = {}
		-- instance.m_InfoDic.offerId = MSDKInfo.OFFERID.MSDK
        if GameUtil.GetPlatformName() == "IOS" then
            instance.m_InfoDic.offerId = MSDKInfo.OFFERID.IOS
        elseif GameUtil.GetPlatformName() == "Android" then
            instance.m_InfoDic.offerId = MSDKInfo.OFFERID.ANDROID
        end
	end
	return instance
end

---@param self ECMSDK.MSDKInfo
---@param key string
---@param value any
---@return void
def.method("string", "dynamic").SaveMSDKInfo = function(self, key, value)
	self.m_InfoDic[key] = value
end

---@param self ECMSDK.MSDKInfo
---@param key string
---@return any
def.method("string", "=>", "dynamic").GetMSDKInfo = function(self, key)
	return self.m_InfoDic[key] or ""
end

---@param self ECMSDK.MSDKInfo
---@return void
def.method().Clear = function(self)
	self.m_InfoDic = nil
end

---@type table
def.field("table").m_roleIdToOpenId = nil

---@type table
def.field("table")._getOpenIdCallback = nil

---转换roleid到openid
---@param self ECMSDK.MSDKInfo
---@param roleid string
---@return string
def.method("string", "=>", "string").TryGetOpenID = function(self, roleid)
	if roleid == globalGame:GetHostPlayerID() then
		return self:GetMSDKInfo("openId")
	end
	if self.m_roleIdToOpenId and self.m_roleIdToOpenId[roleid] then
		return self.m_roleIdToOpenId[roleid]
	end
	return ""
end

---@param self ECMSDK.MSDKInfo
---@param openid string
---@return string
def.method("string","=>","string").TryGetRoleIDByOpenId = function(self, openid)
	if self.m_roleIdToOpenId then
		for _roleid, _openid in pairs(self.m_roleIdToOpenId) do
			if openid == openid then
				return _roleid
			end
		end
	end
	return ZeroUInt64
end
---@param self ECMSDK.MSDKInfo
---@param roleid string
---@param openid string
---@return void
def.method("string", "string").RecordUserOpenID = function(self, roleid, openid)
	print("RecordUserOpenID", LuaUInt64.ToString(roleid), openid)
	if roleid ~= ZeroUInt64 and openid ~= "" then
		self.m_roleIdToOpenId = self.m_roleIdToOpenId or {}
		self.m_roleIdToOpenId[roleid] = openid

		local cbs = self._getOpenIdCallback
		self._getOpenIdCallback = nil
		if cbs then
			for _, func in ipairs(cbs) do
				func(openid, roleid)
			end
		end
	end
end

---@param self ECMSDK.MSDKInfo
---@param roleid string
---@param cb function
---@return void
def.method("string", "function").RequestOpenIDByRoleID = function(self, roleid, cb)
	local openId = self:TryGetOpenID(roleid)
	if openId ~= "" then
		if cb then cb(openId, roleid) end
		return
	end

	--添加处理回调
	if cb then
		if not self._getOpenIdCallback then
			self._getOpenIdCallback = {}
		end
		table.insert(self._getOpenIdCallback, cb)
	end

	--开始请求
	print("RequestOpenIDByRoleID", LuaUInt64.ToString(roleid))
	local client_msg = require "PB.client_msg"
	local pb_helper = require "PB.pb_helper"
	local m = pb_helper.NewCmd "npt_get_player_profile"
	m.data.roleid = roleid
	m.data.get_profile_mask = client_msg.get_player_profile_struct.GET_PROPERTY
	m.ignore_cd = true
	pb_helper.Send(m)
end


 
MSDKInfo.Commit()
return MSDKInfo
