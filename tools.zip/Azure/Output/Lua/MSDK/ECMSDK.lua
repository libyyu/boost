-------------------------------------------------------------------------------------------
-- msdk的总文件
-- MSDK事件上报模块功能也写在此处
-------------------------------------------------------------------------------------------
require("MSDK.MSDKDefine")
local Lplus = require "Lplus"
local MSDKLogin = require("MSDK.MSDKLogin")
local MidasPay = require("MSDK.MSDKMidasPay")
local MSDKNotify = require("MSDK.MSDKNotify")
local MSDKRelation = require("MSDK.MSDKRelation")
local MSDKUtil = require("MSDK.MSDKUtil")
local MSDKInfo = require("MSDK.MSDKInfo")


---@class ECMSDK:System.Object
---@field public EventType table
---@field public EventName table
---@field protected m_IosNotificationOpenedCb function
---@field public Commit fun():ECMSDK @notnull
---@field public Instance fun():ECMSDK
---@field public InitMSDK fun(self:ECMSDK)
---@field public BuglyExInfoSet fun()
---@field public GetChannelID fun():string
---@field public GetDeviceId fun():string
---@field public GetVersion fun():string
---@field public GetRegisterChannelID fun():string
---@field public InitReport fun(channels:string):boolean
---@field public ReportEvent fun(eventType:number)
---@field public ReportEventForName fun(eventName:string, channel:string)
---@field public OpenPrajnaWebView fun(jsonStr:string)
---@field public SaveMSDKInfo fun(key:string, value:any)
---@field public GetMSDKInfo fun(key:string):any
---@field public GetLoginPrivilegeType fun():number
---@field public GetAreaId fun():string
---@field public GetPlatId fun():string
---@field public QuerySuperRInfo fun()
---@field public GetIsSuperR fun():boolean
---@field public OpenSuperR fun()
---@field public GetXinYueVipLevel fun():number
---@field public ClearInfoWhenOpenIDChanged fun()
---@field public GetXinYueVIPInfo fun()
---@field public RequestAPI fun(urlprefix:string, apiprefix:string, params:table, data:table, onRespond:function)
---@field public IsFromWXGameCenter fun():boolean
---@field public IsFromQQGameCenter fun():boolean
---@field public onDeepLink fun(url:string)
local ECMSDK = Lplus.Class("ECMSDK")
local def = ECMSDK.define

local PCallMSDKFunction = function(FunctionName, ...)
	if MSDK and MSDK[FunctionName] then
		return MSDK[FunctionName](...)
	else
		warn(("There is no function = %s in MSDK"):format(FunctionName))
		return nil
	end
end

---@type table
def.const("table").EventType =
{
	FirstTimeActivated = 1,
	Activated = 2,
	ResDownloadStart = 3,
	ResDownloadFinish = 4,
	Register = 5,
	Login = 6,
	TutorialStart = 7,
	TutorialEnd = 8,
	PurchaseStart = 9,
	PurchaseSuccess = 10,
	PurchaseCancel = 11
}

---@type table
def.const("table").EventName =
{
	Firebase = {
		"firsttime_activated",
		"activated_app",
		"res_download_start",
		"res_download_complete",
		"completed_registration",
		"login",
		"tutorial_start",
		"completed_tutorial",
		"purchase_concider",
		"purchase",
		"purchase_cancel",
	},
	Adjust = {
		_G.platform == PLATFORM_TYPE_IOS and "blvocf" or "mn3yws",
		_G.platform == PLATFORM_TYPE_IOS and "bf59zu" or "l7upam",
		_G.platform == PLATFORM_TYPE_IOS and "aq6dk9" or "lqdvpo",
		_G.platform == PLATFORM_TYPE_IOS and "euysz3" or "edquni",
		_G.platform == PLATFORM_TYPE_IOS and "ozgi2i" or "5j0u48",
		_G.platform == PLATFORM_TYPE_IOS and "qrg4k7" or "prte8c",
		_G.platform == PLATFORM_TYPE_IOS and "ahdccb" or "tec10z",
		_G.platform == PLATFORM_TYPE_IOS and "xsehd4" or "9u7r72",
		_G.platform == PLATFORM_TYPE_IOS and "4swa8b" or "9hwmod",
		_G.platform == PLATFORM_TYPE_IOS and "hxrac6" or "2pagnf",
		_G.platform == PLATFORM_TYPE_IOS and "4gm7bg" or "wud3r6",
	},
}

---@type function
def.field("function").m_IosNotificationOpenedCb = nil

local instance = nil
---@return ECMSDK
def.static("=>", ECMSDK).Instance = function()
	if not instance then
		instance = ECMSDK()
	end
	return instance
end

-- MSDK初始化
---@param self ECMSDK
---@return void
def.method().InitMSDK = function(self)
	local luaCallBackFunction = 
	{
		--登录模块相关回调
		onLoginSuccess = function(openId, pf, pfKey, token, channelInfo,regChannelDis)
			MSDKLogin.Instance():OnLoginSuccess(0, openId, pf, pfKey, token, channelInfo,regChannelDis)
		end,
		onLoginError = function(flag, desc,openid,method)
			MSDKLogin.Instance():OnLoginError(flag, desc,openid,method)
		end,
		onQrCodeNotify = function(channelID, channel, qrCodeUrl)
			MSDKLogin.Instance():OnQrCodeNotify(channelID, channel, qrCodeUrl)
		end,
		onLogout = function(flag)
			MSDKLogin.Instance():OnLogout(flag)
		end,
		onWakeup = function(flag, platform, mediaTagName, openId, desc, lang, country, messageExt, extInfo) 
			MSDKLogin.Instance():OnWakeup(flag, platform, mediaTagName, openId, desc, lang, country, messageExt, extInfo) 
		end,
		onBindNotify = function ( flag, thirdCode, confirmCode )
			MSDKLogin.Instance():OnBindNotify(flag, thirdCode, confirmCode)   
		end,
		onAccountNotify = function ( flag, msg, methodId, thirdCode, thirdMsg )
			MSDKLogin.Instance():OnAccountNotify(flag, msg, methodId, thirdCode, thirdMsg) 
		end,
		
		--Midas支付相关回调
		onPayCallback = function(retcode, msg, realSaveNum, payChannel, payState, provideState, extendInfo) 
			MidasPay.Instance():OnPayCallback(retcode, msg, realSaveNum, payChannel, payState, provideState, extendInfo) 
		end,
		onPayNeedLogin = function() 
			MidasPay.Instance():OnPayNeedLogin()
		end,
		onYingXiaoJsonInfo = function(jsonResult) 
			MidasPay.Instance():OnMarketJsonInfo(jsonResult) 
		end,
		
		--MSDKNotify相关回调
		onNoticeInfo = function(scene, info) 
			MSDKNotify.Instance():OnNoticeInfo(scene, info)
		end,

		--MSDK关系链(分享相关)回调
		onRelationNotify = function(relationRet) 
			MSDKRelation.Instance():OnRelationNotify(relationRet) 
		end,
		onDeliverMessageNotify = function ( flag, msg, methodId, thirdCode, thirdMsg )
			MSDKRelation.Instance():OnDeliverMessageNotify(flag, msg, methodId, thirdCode, thirdMsg)
		end,
		-- onShare = function(platform, flag, desc, extInfo)
		-- 	MSDKRelation.Instance():OnShare(platform, flag, desc, extInfo) 
		-- end,

		onLoadGroupData = function(groupRet)
			MSDKRelation.Instance():OnLoadGroupData(groupRet)
		end,

		-- MSDKUtil相关回调
		-- onLocationNotify = function(relationRet) 
		-- 	MSDKUtil.Instance():OnLocationNotify(relationRet) 
		-- end,
		onLocationGot = function(flag, desc, longitude, latitude) 
			MSDKUtil.Instance():OnLocationGot(flag, desc, longitude, latitude) 
		end,
		-- onWebViewNotify = function(flag) 
		-- 	MSDKUtil.Instance():OnWebViewNotify(flag) 
		-- end,
		-- onQRScan = function(text,status) 
		-- 	MSDKUtil.Instance():OnQRScan(text,status) 
		-- end,

		-- 其他回调
		-- onLowMemory = function(level)
		-- 	_G.onMemoryWarning(level)
		-- end,
		-- onQueryNotificationOpened = function(isAllowed)
		-- 	if instance.m_IosNotificationOpenedCb then
		-- 		instance.m_IosNotificationOpenedCb(isAllowed)
		-- 		instance.m_IosNotificationOpenedCb = nil
		-- 	end
		-- end,
		-- onMicroCommunityReturn = function(routeInfo)
		-- 	if not routeInfo then return end
		-- 	local ECGUIMan = require "GUI.ECGUIMan"
		-- 	ECGUIMan.Instance():MicroCommunityJumpTo(routeInfo)
		-- end,
		onDeepLink = function(url)
			ECMSDK.onDeepLink(url)
		end,
	}

	print("begin MSDK init")
	local status,ret = pcall(function ( ... )
		PCallMSDKFunction("init", luaCallBackFunction)
	end)
	ECMSDK.InitReport("Firebase,Adjust,Beacon")
	--print("end MSDK init ", status, ret)

	--require "ProxySDK.ECGPMSDK".Init(2167,true)
	require "MSDK.MSDKGPM".Init(1690133797,true)
	ECMSDK.BuglyExInfoSet()

	--关闭调试模式
	--MSDKUtil.Instance():UpdateConfigs("updateConfigs", {MSDK_DEBUG = 0,})

	--在 Android 上忽略调试器，这是因为 MSDK 自带的 GameProtector 被识别为调试器，会导致非 Shipping 版 ensure 失败时崩溃
	if GameUtil.GetPlatformName() == "Android" then
		GameUtil.SetUEIgnoreDebugger(true)
	end

	-- 开始授权
	MSDK.setCouldCollectSensitiveInfo(1)
end

---@return void
def.static().BuglyExInfoSet = function()
	local content = GameUtil.StreamingAssetReadFileText("res_base/app_info.xml")
	local appInfoStr = ""
	if content then
		local doc = rapidxml.new_doc()
		local bOK, err = rapidxml.doc_parse(doc, content)
		if bOK then
			local root = rapidxml.doc_first_node(doc)
			if root then
				local svnBranch = rapidxml.node_first_attribute(root, "branches")
				if svnBranch then
					local svnBranch_value = rapidxml.attribute_value(svnBranch)
					if svnBranch_value then
						appInfoStr = appInfoStr .. "branch=" .. svnBranch_value .. " "
					end
				end
				local resourceVersion = rapidxml.node_first_attribute(root, "resource_version")
				if resourceVersion then
					local resourceVersion_value = rapidxml.attribute_value(resourceVersion)
					if resourceVersion_value then
						appInfoStr = appInfoStr .. "version=" .. resourceVersion_value .. " "
					end
				end

				local node = rapidxml.node_first_node(root)
				while node do
					local key = rapidxml.node_first_attribute(node, "name")
					local value = rapidxml.node_first_attribute(node, "version")
					if key and value then
						local key_value = (rapidxml.attribute_value(key) or "") .. "Version"
						local value_value = rapidxml.attribute_value(value)
						if key_value and value_value then
							appInfoStr = appInfoStr .. key_value .. "=" .. value_value .. " "
						end
					end
					node = rapidxml.node_next_sibling(node)
				end
			end
		else
			warn("parse res_base/app_info.xml error:", err)
		end
		rapidxml.delete_doc(doc)
	end
	MSDKUtil.Instance():BuglySetUserValue("appInfo",appInfoStr)
	MSDKUtil.Instance():BuglySetUserValue("localVersion",tostring(Patcher.getLocalVersion(GameUtil.GetAssetsPath())))

	--添加bugly 信息
	local Build = GameUtil.GetBuildConfiguration()
	--MSDKUtil.Instance():BuglySetUserValue("build", Build)

	local CodeVersion = GameUtil.GetCurCodeVersion()
	MSDKUtil.Instance():BuglySetUserValue("buildversion", string.format("Build[%s], CodeVersion[%d]", Build, CodeVersion))

	--warn(string.format("Build[%s], CodeVersion[%d]", Build, CodeVersion))

end

---@return string
def.static("=>", "string").GetChannelID = function()
	--local channelID = PCallMSDKFunction("getChannelId") or ""

	local channelID = tostring(_G.LoginPlatform)
	print("GetChannelID:",channelID)
	--[[
	if channelID == "" then
		channelID = tostring(_G.LoginPlatform)
	end
	]]
	return channelID
end

---@return string
def.static("=>", "string").GetDeviceId = function()
	return PCallMSDKFunction("getDeviceId") or ""
end

---@return string
def.static("=>", "string").GetVersion = function()
	return PCallMSDKFunction("getVersion") or ""
end

---@return string
def.static("=>", "string").GetRegisterChannelID = function()
	local regChannelId = PCallMSDKFunction("getRegisterChannelId") or ""
	if regChannelId == "" then
		--通过日志发现，大量用户创建角色时，RegChannelID 为空字符串，ChannelID 正常，同时此后再次登录 RegChannelID 正常，且与 ChannelID 相同
		--  猜测 MSDK 有某种 bug，在首次登录后，未刷新 GetRegisterChannelID
		--  此时，用 ChannelID 替代是正确的
		regChannelId = PCallMSDKFunction("getChannelId") or ""
		
		if GameUtil.GetPlatformName() == "IOS" then	--iOS 写死渠道号为 1001 (接口好像有问题)
			regChannelId = "1001"
		end
	end
	return regChannelId
end

---@param channels string
---@return boolean
def.static("string", "=>", "boolean").InitReport = function (channels)
	return PCallMSDKFunction("initReport", channels) 
end

--事件上报模块 对应 MSDKReport::ReportEvent
--参数类型
---@param eventType number
---@return void
def.static("number").ReportEvent = function ( eventType )
	print("[ECMSDK] report event ", eventType)
	for channel, eventNameTable in pairs( ECMSDK.EventName ) do
		local eventName = eventNameTable[eventType]
		if eventName then
			print("[ECMSDK] report channel event ", eventName, channel)
			-- 事件名字 key-value信息 isRealtime 渠道 扩展信息(json格式) 
			PCallMSDKFunction("reportEvent", eventName, { openid = ECMSDK.GetMSDKInfo("openId") }, true, channel, "")  
		else
			warn(("no eventName for eventType[%d] in channel[%d]"):format(eventType, channel))
		end
	end
end

--事件上报模块 对应 MSDKReport::ReportEvent
-- param: eventName 事件名字
-- param: channel 渠道
---@param eventName string
---@param channel string
---@return void
def.static("string", "string").ReportEventForName = function ( eventName, channel)
	print("[ECMSDK] report channel eventName=", eventName, "channel=", channel)
	-- 事件名字 key-value信息 isRealtime 渠道 扩展信息(json格式) 
	PCallMSDKFunction("reportEvent", eventName, { openid = ECMSDK.GetMSDKInfo("openId") }, true, channel, "")  
end

---@param jsonStr string
---@return void
def.static("string").OpenPrajnaWebView = function(jsonStr)
	PCallMSDKFunction("openPrajnaWebView", jsonStr)
end

---@param key string
---@param value any
---@return void
def.static("string", "dynamic").SaveMSDKInfo = function(key, value)
	if instance then
		MSDKInfo.Instance():SaveMSDKInfo(key, value)
	end
end

---@param key string
---@return any
def.static("string", "=>", "dynamic").GetMSDKInfo = function(key)
	if instance then
		return MSDKInfo.Instance():GetMSDKInfo(key)
	end
	return ""
end

-- def.static("function", "=>", "boolean").IsNotificationOpened = function(cb)
-- 	if instance then
-- 		if _G.platform == PLATFORM_TYPE_IOS then
-- 			instance.m_IosNotificationOpenedCb = cb
-- 			return MSDKRelation.Instance():IsNotificationOpened()
-- 		else
-- 			return MSDKRelation.Instance():IsNotificationOpened()
-- 		end
-- 	else
-- 		return false
-- 	end
-- end

-- 获取vip类型
---@return number
def.static("=>", "number").GetLoginPrivilegeType = function()
	local loginPlatform = _G.LoginPlatform
	if loginPlatform == MSDK_LOGIN_PLATFORM.QQ and ECMSDK.IsFromQQGameCenter() then
		return Login_GameCenter_Platform.QQ--MSDKInfo.LOGINPRIVILEGETYPE.QQ
	elseif loginPlatform == MSDK_LOGIN_PLATFORM.WX and ECMSDK.IsFromWXGameCenter() then
		return Login_GameCenter_Platform.WX--MSDKInfo.LOGINPRIVILEGETYPE.WX
	end
	return Login_GameCenter_Platform.Normal--MSDKInfo.LOGINPRIVILEGETYPE.NON
end

-- 此方法没有实现
-- def.static("string").OpenWeixinDeeplink = function(link)
-- 	PCallMSDKFunction("openWeixinDeeplink", link)
-- end

--
---@return string
def.static("=>", "string").GetAreaId = function ()
	local LoginPlatform = _G.LoginPlatform
	if LoginPlatform == MSDK_LOGIN_PLATFORM.NON then
		return "0"
	elseif LoginPlatform == MSDK_LOGIN_PLATFORM.QQ or LoginPlatform == MSDK_LOGIN_PLATFORM.QQHALL or LoginPlatform == MSDK_LOGIN_PLATFORM.GUEST then
		return "2"
	elseif LoginPlatform == MSDK_LOGIN_PLATFORM.WX then
		return "1"
	-- elseif LoginPlatform == PDSDK_LOGIN_PLATFORM.PD then 
	-- 	return "3"
	else
		return "0"
	end     
end

--
---@return string
def.static("=>", "string").GetPlatId = function ()
	local platform = _G.UsernamePlatform
	if platform == "win" then
		return "2"
	elseif platform == "ios" then
		return "0"
	elseif platform == "android" then
		return "1"
	else
		return "2"
	end
end

-- local MSDK_LINK_PREFIX_ANDROID = "https://da.ssl.msdk.qq.com"
-- local MSDK_LINK_PREFIX_IOS = "https://i.ssl.msdk.qq.com"
-- local XINYUE_SUPER_R_URL = "http://superr.game.qq.com:15625/xyapi/super_user_query"
-- local MD5_CHECK_KEY = "Super_R#Valide#Service#*^!"

-- local xinYueSuperR_requestId = 0
-- local xinYueSuperR_LastTimestamp = 0
-- def.static().GetXinYueSuperRInfo = function()
-- 	local timestamp = os.time()

-- 	local getExtraUrlParam = function ()
-- 		local accessToken = ECMSDK.GetMSDKInfo("accessToken")
-- 		local appID = ECMSDK.GetMSDKInfo("appId")
-- 		local openID = ECMSDK.GetMSDKInfo("openId")
-- 		local traceId = ("lzhx-%s-%s-190716"):format(openID, os.date("%Y%m%d%H%M%S", timestamp))
-- 		local from = "pc_cli"
-- 		--local accessType = MSDKLogin.Instance():GetLoginPlatform() == MSDK_LOGIN_PLATFORM.WX and 2 or 1
-- 		local sign = string.upper(GameUtil.md5(appID..MD5_CHECK_KEY..openID..MD5_CHECK_KEY..accessToken))
-- 		local sink = 1
-- 		local ECMSDK = require("ProxySDK.ECMSDK")
-- 		return string.format("userid=&appid=%s&openid=%s&from=%s&trace_id=%s&access_token=%s&sign=%s&sink=%s",
-- 						appID,
-- 						openID,
-- 						from,
-- 						traceId,
-- 						accessToken,
-- 						sign,
-- 						sink
-- 					)
-- 	end

-- 	if timestamp == xinYueSuperR_LastTimestamp then
-- 		-- duplicated request!
-- 		return
-- 	end
-- 	xinYueSuperR_LastTimestamp = timestamp

-- 	local getUrl = XINYUE_SUPER_R_URL
-- 	getUrl = getUrl.."?"..getExtraUrlParam()
-- 	print("____________________getUrl",getUrl)

-- 	xinYueSuperR_requestId = xinYueSuperR_requestId + 1
-- 	GameUtil.httpRequest("GET", getUrl, xinYueSuperR_requestId, nil, nil, function(success, responseCode, url, Id, retdata)
-- 		if success and xinYueSuperR_requestId == tonumber(Id) then
-- 			local Json = require "Utility.json"
-- 			local info = Json.decode(GameUtil.byteArray2Str(retdata))
-- 			if info and info.result == 0 then
-- 				xinYueSuperRLevel = info.ilevel
-- 				warn("GetXinYueSuperRInfo: Id, lvl = ", Id, xinYueSuperRLevel)
-- 			else
-- 				xinYueSuperRLevel = -1 -- -1: GotFromServer but Request return Failed
-- 				warn(getUrl, "GetXinYueSuperRInfo ", info.msg)
-- 			end

-- 			local ECPanelSocialContact = require "GUI.ECPanelSocialContact"
-- 			ECPanelSocialContact.Instance():RefreshBadge(false)
-- 			if ECPanelSocialContact.Instance():IsShow() then
-- 				ECPanelSocialContact.Instance():RefreshPartnerList()
-- 				ECPanelSocialContact.Instance():RefreshContactors()
-- 			end
-- 		else
-- 			warn(getUrl, " GetXinYueSuperRInfo  error  ", " ", Id, responseCode)
-- 		end
-- 	end)
-- end

local SuperR_requestId = 0
local SuperR_LastTimestamp = 0
local SuperR_game_id = 1386 --超R游戏ID
local SuperR_strategy_id = 0 --身份策略ID,类似身份等级,如果为0说明没有超R会员身份

--查询超核玩家信息
---@return void
def.static().QuerySuperRInfo = function()
	local lastTimestamp = os.time()
	if lastTimestamp == SuperR_LastTimestamp then
		-- duplicated request!
		return
	end
	SuperR_LastTimestamp = lastTimestamp

	local getExtraUrlParam = function ()
		local query_type = 2 --需要查询的身份类型 1:平台身份 2:单游戏身份 3:平台身份和单游戏身份
		local query_game_id = SuperR_game_id --超R游戏ID
		local auth_type = 2 --登录态类型 1:游戏内登录态 2:MSDKV5登录态 3:PtLogin/WtLogin登录态
		local auth_app_id = ECMSDK.GetMSDKInfo("appId") --游戏APPID,用于用户登录态鉴权,微信用户就传微信的APPID,QQ用户就传QQ的APPID
		local auth_open_id = ECMSDK.GetMSDKInfo("openId") --用户openID,用于用户登录态鉴权
		local auth_open_key = ECMSDK.GetMSDKInfo("accessToken") --用户token,对应于openID,用于用户登录态鉴权
		local timestamp = GameUtil.GetServerGMTTime() --当前服务器unix秒
		local trace_id = ("nyzx-%s-%s"):format(auth_open_id, os.date("%Y%m%d%H%M%S", timestamp)) --流水号,业务自定义,每次请求唯一流水号
		local platform_app_id = "25C54392354DD012012FEA01B8121363"  --用于签名校验,超核玩家开放平台注册的APPID
		local platform_app_key = "a8xo0z0gkd6yu445pys3qqa4zwi2z379" --超核玩家开放平台注册的APPKEY
		local nonce = random_string(6) --6位随机数, 字符范围0-9,A-Z,a-z

		--MSDKV5登录态场景下的参数说明
		--当调用方使用MSDKV5登录态进行身份查询时,需要填充extends字段
		--extends形式上是一个使用urlencode编码的字符串
		--内容包括msdk_os、msdk_game_id、msdk_channel_id
		--msdk_os:操作系统标识,和MSDKV5文档同步 1:Android 2:iOS
		--msdk_game_id:MSDK分配的GameID
		--msdk_channel_id:登录渠道,和MSDKV5文档同步 1:微信 2:QQ
		local UrlHelper = require "Utility.UrlHelper"
		local msdk_os = GameUtil.GetPlatformName() == "Android" and 1 or 2
		local msdk_game_id = 16301
		local msdk_channel_id = _G.LoginPlatform == MSDK_LOGIN_PLATFORM.WX and 1 or 2
		local extends = "msdk_os"..UrlHelper.urlEncode("="..msdk_os.."&")
						.."msdk_game_id"..UrlHelper.urlEncode("="..msdk_game_id.."&")
						.."msdk_channel_id"..UrlHelper.urlEncode("="..msdk_channel_id)

		--签名规则
		--请求参数sign的生成方式:
		--1、将所有的请求参数值按照对应的参数名进行字典升序排列
		--2、将排序后的参数值依次品鉴成一个字符串str1
		--3、将管家提供的platform_app_key的值拼接在str1的后面,作为str2
		--4、对str2字符串进行MD5计算生成摘要值md(请使用标准的MD5函数库)
		--5、将md的所有字母转为大写形式作为sign字段的值
		local sign = string.upper(GameUtil.md5(auth_app_id
						..auth_open_id
						..auth_open_key
						..auth_type
						..extends
						..nonce
						..platform_app_id
						..query_game_id
						..query_type
						..timestamp
						..trace_id
						..platform_app_key)) --请求参数的签名,所有字母需转为大写形式

		local url_param_str = "?query_type="..query_type
							.."&query_game_id="..query_game_id
							.."&auth_type="..auth_type
							.."&auth_app_id="..auth_app_id
							.."&auth_open_id="..auth_open_id
							.."&auth_open_key="..auth_open_key
							.."&trace_id="..trace_id
							.."&extends="..extends
							.."&platform_app_id="..platform_app_id
							.."&timestamp="..timestamp
							.."&nonce="..nonce
							.."&sign="..sign

		return url_param_str
	end

	local query_url = "https://superr.game.qq.com/identity/query"..getExtraUrlParam()
	warn("QuerySuperRInfo url = ", query_url)

	SuperR_requestId = SuperR_requestId + 1
	GameUtil.httpRequest("GET", query_url, SuperR_requestId, nil, nil, function(success, responseCode, url, Id, retdata)
		warn("##QuerySuperRInfo## success =",success," responseCode =", responseCode, " Id =", Id)
		if success and SuperR_requestId == tonumber(Id) then
			local Json = require "Utility.json"
			local info = Json.decode(GameUtil.byteArray2Str(retdata))
			if info then
				if info.code == 0 then
					if info.data and info.data.list then
						for k, v in pairs(info.data.list) do
							if v.game_id == SuperR_game_id then
								SuperR_strategy_id = v.strategy_id
								warn("QuerySuperRInfo strategy_id =", SuperR_strategy_id)
							end
						end
					else
						warn("QuerySuperRInfo data error !")
					end
				else
					warn("QuerySuperRInfo info.code error: code = ", info.code)
				end
			else
				warn("QuerySuperRInfo info error !")
			end
		else
			warn("QuerySuperRInfo error !")
		end
	end)
end

--获取是否是超核玩家
---@return boolean
def.static("=>", "boolean").GetIsSuperR = function()
	--身份策略ID,类似身份等级,如果为0说明没有超R会员身份
	return SuperR_strategy_id > 0
end

--打开超核玩家链接
---@return void
def.static().OpenSuperR = function()
	local UrlHelper = require "Utility.UrlHelper"
	local game_id = 1386 --心悦游戏ID,产品经理提供
	local source = "xy_games" --渠道来源
	local role_id = "" --游戏角色id
	local role_name = "" --游戏角色名
	local area_id = 1 --游戏大区ID
	local partition_id = 1 --游戏小区ID
	local hp = globalGame:GetHostPlayer()
	if hp then
		role_id = LuaUInt64.ToString(hp.ID)
		role_name = hp:GetName()
		local zoneId = require "Main.ECZoneMan".Instance():GetZoneID(hp.ID)
		area_id = require "MSDK.MSDKUtil".Instance():GetAreaID(zoneId)
		partition_id = zoneId
	end
	local system_id = 0 --操作系统: IOS=0, Android=1, PC=2
	if GameUtil.GetPlatformName() == "IOS" then
		system_id = 0
	elseif GameUtil.GetPlatformName() == "Android" then
		system_id = 1
	else 
		system_id = 2
	end
	local plat_id = _G.LoginPlatform == MSDK_LOGIN_PLATFORM.WX and 1 or 2 --平台: 微信=1, QQ=2
	local login_type = "msdk-v5"

	local url = "https://svip.game.qq.com/svippage/api/redirect"
				.."?game_id="..game_id
				.."&source="..source
				.."&role_id="..role_id
				.."&role_name="..UrlHelper.urlEncode(role_name)
				.."&area_id="..area_id
				.."&partition_id="..partition_id
				.."&system_id="..system_id
				.."&plat_id="..plat_id
				.."&login_type="..login_type

	warn("OpenSuperR url = ",url)

	glb_OpenWebView(url)
end

 -- -2: NOT Got From Server
 -- -1: GotFromServer but Request return Failed
 --  0: 无vip
 --  1~4：游戏家G1~G4
 --  5~7: 心悦vip1~3
 local xinYueVipLevel = -2

 local xinYueVip_LastTimestamp = 0
 local xinYueVip_ReRequest_IfGot_Interval = 1800 --如果已获取，则需要重新获取的过期时间
 local xinYueVip_ReRequest_IfNotGot_Interval = 5 --如果未获取，则需要重新获取的过期时间

 ---@return number
 def.static("=>", "number").GetXinYueVipLevel = function()
 	local timestamp = os.time()
 	if xinYueVipLevel < 0 then
 		-- 未获取：
 		if timestamp >= xinYueVip_LastTimestamp + xinYueVip_ReRequest_IfNotGot_Interval then
 			-- 过期重新获取
 			ECMSDK.GetXinYueVIPInfo()
 		end
 	else
 		-- 已获取：
 		if timestamp >= xinYueVip_LastTimestamp + xinYueVip_ReRequest_IfGot_Interval then
 			-- 过期重新获取
 			ECMSDK.GetXinYueVIPInfo()
 		end
 	end

 	return xinYueVipLevel
 end

 ---@return void
 def.static().ClearInfoWhenOpenIDChanged = function()
	 xinYueVipLevel = -2
	 xinYueVip_LastTimestamp = 0
 end

 ---@return void
 def.static().GetXinYueVIPInfo = function()
 	local timestamp = os.time()
 	if timestamp == xinYueVip_LastTimestamp then
 		-- Avoid duplicated request!
 		warn("__GetXinYueVIPInfo: timestamp == xinYueVip_LastTimestamp: Avoid duplicated request!", timestamp)
 		return
 	end
 	xinYueVip_LastTimestamp = timestamp

 	local Json = require "Utility.json"
 	local accessToken = ECMSDK.GetMSDKInfo("accessToken")
 	local appID = ECMSDK.GetMSDKInfo("appId")
 	local openID = ECMSDK.GetMSDKInfo("openId")

 	local loginPlat = MSDKLogin.Instance():GetLoginPlatform()

 	--warn(("__GetXinYueVIPInfo: plat[%d] openID[%s]"):format(loginPlat, tostring(openID)))

 	if loginPlat == MSDK_LOGIN_PLATFORM.WX or loginPlat == MSDK_LOGIN_PLATFORM.WX_GAMECENTER then
	    local serial = ("ref_%s_190716"):format(os.date("%Y%m%d_%H%M%S", timestamp))
	    local data = {
		    openid = openID,
		    token = accessToken,
		    serial = serial,
		    seven_flag = 1,
	    }
	    local params = {}
	    ECMSDK.RequestAPI("https://itop.qq.com", "/v2/profile/query_wx_xinyue_vip", params, data, function(info, err)
		    if info then
			    xinYueVipLevel = info.ilevel
			    warn("GetXinYueVIPInfo_WX: lvl = ", xinYueVipLevel)
		    else
			    xinYueVipLevel = -1 -- -1: GotFromServer but Request return Failed
			    warn("GetXinYueVIPInfo_WX: errir ", err)
		    end
	    end)

 	elseif loginPlat == MSDK_LOGIN_PLATFORM.QQ or loginPlat == MSDK_LOGIN_PLATFORM.QQHALL then
	    local params = {}
	    local data = {
		    openid = openID,
		    token = accessToken,
		    vip = 0x200,
	    }
	    ECMSDK.RequestAPI("https://itop.qq.com", "/v2/profile/query_qq_vip", params, data, function(info, err)
		    if info then
			    if #info.lists > 0 then
				    xinYueVipLevel = info.lists[1].level
				    warn("GetXinYueVIPInfo_QQ: lvl = ", xinYueVipLevel)
			    else
				    warn("GetXinYueVIPInfo_QQ: ret == 0 but #info.lists <= 0!")
				    xinYueVipLevel = -1 -- -1: GotFromServer but return Failed
			    end
		    else
			    xinYueVipLevel = -1 -- -1: GotFromServer but Request return Failed
			    warn("GetXinYueVIPInfo_QQ: errir ", err)
		    end
	    end)
 	elseif loginPlat == MSDK_LOGIN_PLATFORM.GUEST then
 		xinYueVipLevel = 0 -- 0 for guest
 		warn("GetXinYueVIPInfo: Guest, xinYueVipLevel = 0")
 	else
 		xinYueVipLevel = -2 -- -2 for none
 		warn("GetXinYueVIPInfo: Plat-None, xinYueVipLevel = -2")
 	end
 end

local _s_requestId = 0
---提供msdk的http-api操作
---@param urlprefix string
---@param apiprefix string
---@param params table
---@param data table
---@param onRespond function
---@return void
def.static("string", "string", "table", "table", "function").RequestAPI = function(urlprefix, apiprefix, params, data, onRespond)
	local loginPlat = MSDKLogin.Instance():GetLoginPlatform()
	local Json = require "Utility.json"

	local channelid = params.channelid
	if not channelid then
		if loginPlat == MSDK_LOGIN_PLATFORM.WX or loginPlat == MSDK_LOGIN_PLATFORM.WX_GAMECENTER then
			channelid = 1
		else
			channelid = 2
		end
	end

	local gameid = params.gameid
	if not gameid then
		if loginPlat == MSDK_LOGIN_PLATFORM.WX or loginPlat == MSDK_LOGIN_PLATFORM.WX_GAMECENTER then
			gameid = 16301
		else
			gameid = 16301
		end
	end

	local os_ = params.os
	if not os_ then
		if loginPlat == MSDK_LOGIN_PLATFORM.WX or loginPlat == MSDK_LOGIN_PLATFORM.WX_GAMECENTER then
			os_ = 1
		else
			os_ = 1
		end
	end

	local seq = params.seq or ""
	local source = params.source or 0
	local ts = params.timestamp or os.time()
	local version = params.version or 2.0

	local sigKey = MSDKInfo.MSDKKey

	local dataStr = Json.encode(data)

	local api = ("%s?channelid=%d&gameid=%d&os=%d&seq=%s&source=%d&ts=%s"):format(apiprefix, channelid, gameid, os_, seq, source, ts)
	print("api", api)
	local sig = GameUtil.md5(api .. dataStr .. sigKey)
	print("data", dataStr)
	print("sign", sig)
	api = api .. "&sig="..sig

	_s_requestId = _s_requestId + 1

	GameUtil.httpRequest("POST", urlprefix .. api, _s_requestId, nil, dataStr, function(success, responseCode, url, Id, retdata)
		if success and _s_requestId == tonumber(Id) then
			local info = Json.decode(GameUtil.byteArray2Str(retdata))
			if info and info.ret == 0 then
				if onRespond then
					onRespond(info)
				end
			else
				warn("request: " .. apiprefix .. " ret!=0, ", tostring_r(info))
				if onRespond then
					onRespond(nil, info)
				end
			end
		else
			warn("request: " .. apiprefix .. " error: ", Id, responseCode)
			if onRespond then
				onRespond(nil)
			end
		end
	end, "Content-Type", "application/json")
end

---@return boolean
def.static("=>", "boolean").IsFromWXGameCenter = function()
	if _G.IsEvaluation() then
		return false
	end

	local copenid = ECMSDK.GetMSDKInfo("CenterOpenID")
	print_hsh("copenid   ",copenid)
	if copenid == "" then
		return false
	end
	local b_match_copenid = false

	local btag = false
	local mediaTagName = ECMSDK.GetMSDKInfo("mediaTagName")
	-- warn("IsFromWXGameCenter2", "mediaTagName", mediaTagName)
	if mediaTagName == "wgWXGameRecommend" then
		btag = true
	end

	local binfo = false
	local extInfo = ECMSDK.GetMSDKInfo("extInfo")
	if extInfo ~= "" then
		for _, v in pairs(extInfo) do
			-- warn("IsFromWXGameCenter:", v)
			if v == "WX_GameCenter" or v == "wgWXGameRecommend" then
				binfo = true
			end
		end
	end

	local bext = false
	local messageExt = ECMSDK.GetMSDKInfo("messageExt")
	if messageExt ~= "" then
		local Json = require "Utility.json"
		local ExtraJson = Json.decode(messageExt)
		if ExtraJson and ExtraJson.params then
			print_hsh("ExtraJson.params  ",ExtraJson.params)
			local params = Json.decode(ExtraJson.params)
			if params then
				for k, v in pairs(params) do
					if v == "WX_GameCenter" then
						bext = true
					end
					if k == "openid" then
						b_match_copenid = (v == copenid)
					end
				end
			end
		end
	end

	return (btag or binfo or bext) and b_match_copenid
end

---@return boolean
def.static("=>", "boolean").IsFromQQGameCenter = function()
	--print_hsh("IsFromQQGameCenter   ",_G.IsEvaluation())
	if _G.IsEvaluation() then
		return false
	end

	local copenid = ECMSDK.GetMSDKInfo("CenterOpenID")
	print_hsh("copenid   ",copenid)
	if copenid == "" then
		return false
	end
	local b_match_copenid = false

	local binfo = false
	local extInfo = ECMSDK.GetMSDKInfo("extInfo")
	if extInfo ~= "" then
		--return false
		for _, v in pairs(extInfo) do
			-- warn("--IsFromQQGameCenter:", v)
			if v == "sq_gamecenter" then
				binfo = true
			end
		end
	end

	local bext = false
	local messageExt = ECMSDK.GetMSDKInfo("messageExt")
	print_hsh("messageExt  ",messageExt)
	if messageExt ~= "" then
		local Json = require "Utility.json"
		local ExtraJson = Json.decode(messageExt)
		print_hsh("ExtraJson.params  ",ExtraJson)
		if ExtraJson and ExtraJson.params then
			print_hsh("ExtraJson.params  ",ExtraJson.params)
			local params = Json.decode(ExtraJson.params)
			if params then
				for k, v in pairs(params) do
					if v == "sq_gamecenter" then
						bext = true
					end
					if k == "openid" then
						b_match_copenid = (v == copenid)
					end
				end
			end
		end
	end

	return (binfo or bext) and b_match_copenid
end

local l_delayProcessDeepLinkUrl
local l_currentDelayProcessDeepLinkHandler

---@param url string
---@return void
def.static("string").onDeepLink = function(url)
	print("ECMSDK.onDeepLink: ", url)
	require "Utility.DeepLinkHandler".OnDeepLink(url)
end

ECMSDK.Commit()
return ECMSDK
