--[[
	提示功能已解锁
]]

local Lplus = require "Lplus"
local ECPanelBase = require "GUI.ECPanelBase"
local ECFunctionUnlock = require "Guide.ECFunctionUnlock"
local AtlasMan = require "GUI.Main.AtlasMan"
local ECGuide = require "Guide.ECGuide"
local ECHostConditionOp = require "Players.ECHostConditionOp"
local ECAutoPopupManager = require "GUI.ECAutoPopupManager"
local Callbacks = require "Utility.Callbacks"
local ECGUITools = require "GUI.ECGUITools"
local GcCallbacks = require "Utility.GcCallbacks"
local ECSoundMan = require "Sound.ECSoundMan"
local TweenPosition = require "GUI.TweenPosition"
---@type ECGame
local ECGame = Lplus.ForwardDeclare("ECGame")

---@class Guide.ECPanelFunctionUnlock:ECPanelBase
---@field protected m_requestQueue table
---@field protected m_currentFunctionName string
---@field protected m_createTime number
---@field protected m_bUnlocking boolean
---@field protected m_finishUnlockingCallbacks Callbacks
---@field protected m_exclusivePopupState ExclusivePopupState
---@field protected m_cleaner GcCallbacks
---@field protected m_fading boolean
---@field protected m_icon userdata
---@field public Commit fun():Guide.ECPanelFunctionUnlock @notnull
---@field public Instance fun():Guide.ECPanelFunctionUnlock
---@field public IsProhibit fun(self:Guide.ECPanelFunctionUnlock):boolean
---@field public QueuePopup fun(function_name:string)
---@field public IsUnlocking fun():boolean
---@field public AddFinishUnlockingCallback fun(callback:function)
---@field public Create fun(self:Guide.ECPanelFunctionUnlock)
---@field public OnGUIChange fun(self:Guide.ECPanelFunctionUnlock, rolechange:boolean, userchange:boolean)
---@field public MakeSessionChecker fun(self:Guide.ECPanelFunctionUnlock):function
---@field public OnCreate fun(self:Guide.ECPanelFunctionUnlock)
---@field public onClick fun(self:Guide.ECPanelFunctionUnlock, id:string)
---@field public simuOnClick fun(self:Guide.ECPanelFunctionUnlock)
---@field public StartFadeOut fun(self:Guide.ECPanelFunctionUnlock)
---@field public autoExpand fun(self:Guide.ECPanelFunctionUnlock, onFinish:function)
---@field public FadeOut fun(self:Guide.ECPanelFunctionUnlock)
---@field public PrepareEntry fun(self:Guide.ECPanelFunctionUnlock)
---@field public OnTweenPos fun(self:Guide.ECPanelFunctionUnlock, target:userdata, subIcon:userdata, deltatime:number)
---@field public OnFadeOutEnd fun(self:Guide.ECPanelFunctionUnlock, bTempEndExclusive:boolean)
---@field public End fun(self:Guide.ECPanelFunctionUnlock)
---@field public OnDestroy fun(self:Guide.ECPanelFunctionUnlock)
---@field public PopupNext fun(self:Guide.ECPanelFunctionUnlock)
---@field public Popup fun(self:Guide.ECPanelFunctionUnlock, function_name:string)
---@field public OnAllStart fun(self:Guide.ECPanelFunctionUnlock)
---@field public OnAllEnd fun(self:Guide.ECPanelFunctionUnlock)
local ECPanelFunctionUnlock = Lplus.Extend(ECPanelBase, "Guide.ECPanelFunctionUnlock")
---@type Guide.ECPanelFunctionUnlock
local l_instance = nil

local m_TweenPos = nil

do
	local def = ECPanelFunctionUnlock.define
	

	---@return Guide.ECPanelFunctionUnlock
	def.static("=>",ECPanelFunctionUnlock).Instance = function()
		return l_instance
	end

	---@param self Guide.ECPanelFunctionUnlock
	---@return boolean
	def.method("=>", "boolean").IsProhibit = function(self)
		return self:HasAnyInvisibleFlag()
	end

	---@param function_name string
	---@return void
	def.static("string").QueuePopup = function (function_name)
		if l_instance:IsProhibit() then
			return
		end

		print_xf("=======QueuePopup")


		l_instance.m_requestQueue[#l_instance.m_requestQueue+1] = function_name
		if #l_instance.m_requestQueue == 1 then
			local sessionCheck = l_instance:MakeSessionChecker()
			local function StartFunctionUnlock()

				l_instance.m_exclusivePopupState:RequestBegin(function ()
					if not sessionCheck() then
						l_instance.m_exclusivePopupState:End()
						local FxEnum =_G.require_config("Configs/fx_play_sequence_cfg.lua"):GetFxEnum()
						local FxQueueFinishEvent = require("Event.FxQueueFinishEvent")
						ECGame.EventManager:raiseEvent(nil, FxQueueFinishEvent.new(FxEnum.FunctionUnlock))
						return
					end
					print_xf("=======functionunlock Start!")
					l_instance:OnAllStart()
					l_instance:PopupNext()
				end)
			end
			local ECFxQueueManager = require"GUI.ECFxQueueManager"
			local FxEnum =_G.require_config("Configs/fx_play_sequence_cfg.lua"):GetFxEnum()

			ECFxQueueManager.Instance():AddFxToQueue(FxEnum.FunctionUnlock,StartFunctionUnlock)
		end

	end
	

	---@return boolean
	def.static("=>", "boolean").IsUnlocking = function ()
		return l_instance.m_bUnlocking
	end
	

	---@param callback function
	---@return void
	def.static("function").AddFinishUnlockingCallback = function (callback)
		if l_instance.m_bUnlocking then
			l_instance.m_finishUnlockingCallbacks:add(callback)
		else
			callback()
		end
	end





---------------------------------------------------------------
	-- End of public
	

	---@param self Guide.ECPanelFunctionUnlock
	---@return void
	def.method().Create = function (self)
		self.m_depthLayer = GUIDEPTH.TOPMOST
		self:CreatePanel(RESPATH.Panel_FunctionUnlock)
	end

	local l_sessionId = 1

	---@param self Guide.ECPanelFunctionUnlock
	---@param rolechange boolean
	---@param userchange boolean
	---@return void
	def.override("boolean", "boolean").OnGUIChange = function (self, rolechange, userchange)
		l_sessionId = l_sessionId + 1
		
		for i = 1, #self.m_requestQueue do
			table.remove(self.m_requestQueue)
		end
		self:DestroyPanel()
		self.m_exclusivePopupState:End()
	end


	

	---@param self Guide.ECPanelFunctionUnlock
	---@return function
	def.method("=>", "function").MakeSessionChecker = function (self)
		local currentSessionId = l_sessionId
		return function ()
			return l_sessionId == currentSessionId
		end
	end
	

	---@param self Guide.ECPanelFunctionUnlock
	---@return void
	def.override().OnCreate = function (self)
		local panel = self.m_panel
		if not panel then return end
		self.m_cleaner = GcCallbacks()
		self.m_fading = false
		panel:SetActive(true)

		local config = ECFunctionUnlock.GetConfig(self.m_currentFunctionName)
	
		ECGUITools.setVisible(self.m_panel:FindChild("Widget"), true)
		ECGUITools.UpdateLable(config.desc,panel:FindChild("Txt_Title"))
		if config.title then
			ECGUITools.UpdateLable(config.title,panel:FindChild("AzureTextBlock_0"))
		end
		local iconw = panel:FindChild("Icon_func")
		if config.icon.size then
			iconw:SetSlotSize(config.icon.size.x,config.icon.size.y)
		end

		if config.icon.atlas then
			ECGUITools.UpdateGridAtlas(config.icon.atlas,config.icon.sprite, iconw)
		elseif config.icon.path_id then
			local path = datapath.GetPathByID(config.icon.path_id)
			ECGUITools.UpdateGridImage(path, iconw,nil,true,true)
		else
			--warn("invalid icon when unlock function: ", self.m_currentFunctionName)
			local title_sprite
			if config.type == "function" then
				title_sprite = "menu1"
			elseif config.type == "skill" then
				title_sprite = "skillup"
			elseif config.type == "activity" then
				title_sprite = "radio0"
			else
				title_sprite = ""
			end

			ECGUITools.setSprite(iconw,title_sprite)
		end
		self:PrepareEntry()
	
		self.m_createTime = Time.realtimeSinceStartup
		
		local auto_close_time = 3
		local timer = GameUtil.AddGlobalTimer(auto_close_time, true, function ()
			if panel:is_nil() then return end	--check guarder
			
			self:simuOnClick()
		end)
		self.m_cleaner:add(function () GameUtil.RemoveGlobalTimer(timer) end)
	end
	

	---@param self Guide.ECPanelFunctionUnlock
	---@param id string
	---@return void
	def.method("string").onClick = function (self, id)
		self:simuOnClick()
	end
	

	---@param self Guide.ECPanelFunctionUnlock
	---@return void
	def.method().simuOnClick = function (self)
		if Time.realtimeSinceStartup - self.m_createTime >= 0.5 then
			self:StartFadeOut()
		end
	end
	

	---@param self Guide.ECPanelFunctionUnlock
	---@return void
	def.method().StartFadeOut = function (self)
		if self.m_fading then
			return
		end
		self.m_fading = true
		--local panel = self.m_panel
		--panel:FindChild("NonIcon"):SetActive(false)

		
		self:autoExpand(function ()
			local panel = self.m_panel
			if panel:is_nil() then return end	--check guarder
			
			self:FadeOut()
		end)
	end
	

	---@param self Guide.ECPanelFunctionUnlock
	---@param onFinish function
	---@return void
	def.method("function").autoExpand = function (self, onFinish)
		local expandName = "none"
		local fly_pos = "none"
		for _, config in ECFunctionUnlock.EachChainFunction(self.m_currentFunctionName) do
			if config.fly_pos ~= "none" then	-- autoExpand 正是为 fly_pos 而存在的
				expandName = config.auto_expand
				fly_pos = config.fly_pos
				break
			end
		end

		--local target = ECHostConditionOp.Executor.find_ui(unpack(fly_pos))
		--if target then
		--	--print_xf("target:GetVisibility()",{target:GetVisibility()})
		--	target:SetVisibilityRaw(ESlateVisibility.Visible)
		--	--print_xf("target:GetWidgetSizeAbsolute()",{target:GetWidgetSizeAbsolute()})
		--	--ECGUITools.setVisible(target,ESlateVisibility.Hidden)
		--end

		if expandName == "none" then
			onFinish()
			return
		end

		if expandName == "Main_MenuUnlock" then	--panel_menu

			GameUtil.AddGlobalTimer(0.5, true, onFinish)
		elseif expandName == "panel_activity" then			

			GameUtil.AddGlobalTimer(0.5, true, onFinish)
		else
			warn("unsupported auto expandName target: " .. tostring(expandName))
			onFinish()
		end
	end

	---@param self Guide.ECPanelFunctionUnlock
	---@return void
	def.method().FadeOut = function (self)
		local panel = self.m_panel
		--panel:FindChild("NonIcon"):SetActive(false)
		local bTempEndExclusive = (#self.m_requestQueue == 1)
		if bTempEndExclusive then
			self.m_exclusivePopupState:End()
		end
		
		local fly_pos = "none"
		local deltatime = 0.08
		local configs = nil
		local fly_sub_pos = nil
		for _, config in ECFunctionUnlock.EachChainFunction(self.m_currentFunctionName) do
			if config.fly_pos ~= "none" then	-- autoExpand 正是为 fly_pos 而存在的
				fly_pos = config.fly_pos
				if config.fly_sub_pos then
					fly_sub_pos = config.fly_sub_pos
				end
				if config.movespeed then
					deltatime = config.movespeed
				end
				configs = config
				break
			end
		end
		if fly_pos == "none" then
			self:OnFadeOutEnd(bTempEndExclusive)
			return
		end
		
		local target = ECHostConditionOp.Executor.find_ui(unpack(fly_pos))
		if not target then
			warn("failed to find target when ECPanelFunctionUnlock.FadeOut: ", unpack(fly_pos))
			self:OnFadeOutEnd(bTempEndExclusive)
			return
		end

		local subIcon = nil
		if fly_sub_pos then
			subIcon = ECHostConditionOp.Executor.find_ui(unpack(fly_sub_pos))
			if not subIcon then
				warn("failed to find subIcon target when ECPanelFunctionUnlock.FadeOut: ", unpack(fly_sub_pos))
				self:OnFadeOutEnd(bTempEndExclusive)
				return
			end
		end




		self:OnTweenPos(target,subIcon,deltatime)
		local timer = GameUtil.AddGlobalTimer(0.03, true, function ()
			if self.m_panel:is_nil() then return end	--check guarder

			if configs.finalSize then
				self.m_panel:FindChild("Icon_func"):SetSlotSize(configs.finalSize.x,configs.finalSize.y)
			end
		end)
		self.m_cleaner:add(function () GameUtil.RemoveGlobalTimer(timer) end)


		local timer2 = GameUtil.AddGlobalTimer(0.5, true, function()
			if not self:IsValid() or not configs.fade_out then
				return
			end
			local Tweener = require "Utility.Tweener"
			local tweener = Tweener.To(function(value)
				if self:IsValid() then
					self:FindDirect("Widget/Icon/Icon_func"):SetRenderOpacity(1 - value)
				end
			end, 1)
			tweener:Play()
		end)
		self.m_cleaner:add(function () GameUtil.RemoveGlobalTimer(timer2) end)


		local timer3 = GameUtil.AddGlobalTimer(1.95, true, function ()

			if panel:is_nil() then return end	--check guarder
			self:OnFadeOutEnd(bTempEndExclusive)
		end)
		self.m_cleaner:add(function () GameUtil.RemoveGlobalTimer(timer3) end)
	end

	---@param self Guide.ECPanelFunctionUnlock
	---@return void
	def.method().PrepareEntry = function (self)
		--在进入动画前先将入口创建出来，否则解锁图标可能会乱飞
		--local entry_poss = {}
		local fly = "none"

		for _, config in ECFunctionUnlock.EachChainFunction(self.m_currentFunctionName) do
			if config.fly_pos ~= "none" then	-- autoExpand 正是为 fly_pos 而存在的
				--expandName = config.auto_expand
				--entry_poss = config.entry
				fly = config.fly_pos
				break
			end
		end

		if fly == "none" then
			return
		end
		--local target = ECHostConditionOp.Executor.find_ui(unpack(fly))
		--target:SetVisibilityRaw(ESlateVisibility.Visible)
		--print_xf("target",target:GetSlotPositionAbsolute())
		local target = ECHostConditionOp.Executor.find_ui(unpack(fly))
		if target  and target:GetVisibility() == ESlateVisibility.Collapsed then
			--print_xf("target:GetVisibility()",{target:GetVisibility()})
			target:SetVisibilityRaw(ESlateVisibility.Hidden)
			--print_xf("target:GetWidgetSizeAbsolute()",{target:GetWidgetSizeAbsolute()})
			--ECGUITools.setVisible(target,ESlateVisibility.Hidden)
		end
	end

	---@param self Guide.ECPanelFunctionUnlock
	---@param target userdata
	---@param subIcon userdata
	---@param deltatime number
	---@return void
	def.method("userdata","userdata","number").OnTweenPos = function (self,target,subIcon,deltatime)
		local function OnTweenFinished()
			local play = true
			for _, config in ECFunctionUnlock.EachChainFunction(self.m_currentFunctionName) do
				if config.fly_pos ~= "none" and config.play_fx ~= nil then	-- autoExpand 正是为 fly_pos 而存在的
					--expandName = config.auto_expand
					play = config.play_fx
					break
				end
			end
			self:FindDirect("Widget/Icon/Fx_Appear"):ActivateParticles(play,true)
		end



		local x1,y1=target:GetSlotPositionAbsolute()

		if subIcon then
			local xs,ys = subIcon:GetSlotPosition()
			x1 , y1 = target:LocalToAbsolute(xs,ys)
		end

		self.m_icon = self.m_panel:FindChild("Icon")

		local destpos  = { x1 , y1 }
		--target:SetVisibilityRaw(ESlateVisibility.Collapsed)
		--target:SetVisibilityRaw(ESlateVisibility.Hidden)
		--target:LockVisibility(false)
		--ECFunctionUnlock.SetLock(target, true)
		--target:SetVisibilityRaw(ESlateVisibility.Collapsed)
		print_xf("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@OnTweenPos destpos",target:GetName(),destpos,target:GetActive(),target:GetVisibility(),self.m_currentFunctionName)
		local srcPos = { self.m_icon:GetSlotPositionAbsolute() }
		if not m_TweenPos then
			m_TweenPos = TweenPosition()
		end
		m_TweenPos:Begin(self.m_icon, srcPos, destpos, 1, deltatime, true, OnTweenFinished)
		--ECGUITools.setVisible(self.m_panel:FindChild("Widget"), false)
	end



	---@param self Guide.ECPanelFunctionUnlock
	---@param bTempEndExclusive boolean
	---@return void
	def.method("boolean").OnFadeOutEnd = function (self, bTempEndExclusive)
		local panel = self.m_panel
		ECFunctionUnlock.FinishUnlocking(self.m_currentFunctionName)

		if bTempEndExclusive and not self:IsProhibit() then
			self.m_exclusivePopupState:RequestBegin(function ()

				if panel:is_nil() then	--check guarder
					self.m_exclusivePopupState:End()
					return
				end
				
				self:End()
			end)
		else
			self:End()
		end
	end



	

	---@param self Guide.ECPanelFunctionUnlock
	---@return void
	def.method().End = function (self)
		local panel = self.m_panel
		
		GameUtil.AddGlobalTimer(0.3, true, function ()
			table.remove(self.m_requestQueue, 1)
			self:PopupNext()
		end)

		
		self:DestroyPanel()
	end
	

	---@param self Guide.ECPanelFunctionUnlock
	---@return void
	def.override().OnDestroy = function (self)
		if self.m_cleaner then
			self.m_cleaner:dispose()
			self.m_cleaner = nil
		end
		if m_TweenPos then
			m_TweenPos:Stop()
			m_TweenPos = nil
		end
	end
	

	---@param self Guide.ECPanelFunctionUnlock
	---@return void
	def.method().PopupNext = function (self)

		print_xf("#self.m_requestQueue",#self.m_requestQueue)
		if #self.m_requestQueue >= 1 then
			local function_name = self.m_requestQueue[1]
			if ECFunctionUnlock.IsUnlocked(function_name) then
				warn("function already unlocked: ", function_name)
				table.remove(self.m_requestQueue, 1)
				self:PopupNext()
			else

				self:Popup(function_name)
			end
		else
			--彻底完结
			self:OnAllEnd()
		end
	end
	
	

	---@param self Guide.ECPanelFunctionUnlock
	---@param function_name string
	---@return void
	def.method("string").Popup = function (self, function_name)
		print("PopUp function unlock play sound")
		--ECSoundMan.Instance():Play2DSoundByName("FunctionOpen")
		self.m_currentFunctionName = function_name
		self:Create()
		self:SetVisible(true)
	end
	
	

	---@param self Guide.ECPanelFunctionUnlock
	---@return void
	def.method().OnAllStart = function (self)
		print_xf("=====functionunlock OnAllStart")
		self.m_bUnlocking = true
		local function_name = self.m_requestQueue[1]
		if function_name then
			local config = ECFunctionUnlock.GetConfig(function_name)
			if config and config.no_close_panels ~= true then

				local ui_close_except = ECFunctionUnlock.GetUICloseExcept()
				--local ui_close_except = { panel_actskill=true }
				--if  config.condition and config.condition.type and config.condition.type == "flysword_level_above" then --飞剑解锁不关飞剑界面
				--	ui_close_except["panel_wing"]= true
				--end

				ECGuide.ExecuteEnv.ui_close_all_except(ui_close_except)
			end
		end
	end
	

	---@param self Guide.ECPanelFunctionUnlock
	---@return void
	def.method().OnAllEnd = function (self)
		self.m_exclusivePopupState:End()
		
		self.m_bUnlocking = false
		self.m_finishUnlockingCallbacks:invoke()
		self.m_finishUnlockingCallbacks:clear()
		local FxEnum =_G.require_config("Configs/fx_play_sequence_cfg.lua"):GetFxEnum()
		local FxQueueFinishEvent = require("Event.FxQueueFinishEvent")
		ECGame.EventManager:raiseEvent(nil, FxQueueFinishEvent.new(FxEnum.FunctionUnlock))
	end
	
	-- {function_name_1, ...}

	---@type table
	def.field("table").m_requestQueue = function () return {} end
	

	---@type string
	def.field("string").m_currentFunctionName = ""

	---@type number
	def.field("number").m_createTime = 0
	

	---@type boolean
	def.field("boolean").m_bUnlocking = false

	---@type Callbacks
	def.field(Callbacks).m_finishUnlockingCallbacks = function () return Callbacks() end

	---@type ExclusivePopupState
	def.field(ECAutoPopupManager.ExclusivePopupState).m_exclusivePopupState = function () return ECAutoPopupManager.Instance():MakeExclusivePopupState() end
	

	---@type GcCallbacks
	def.field(GcCallbacks).m_cleaner = nil		--每次创建

	---@type boolean
	def.field("boolean").m_fading = false		--每次创建

	---@type userdata
	def.field("userdata").m_icon = nil
end
ECPanelFunctionUnlock.Commit()

l_instance = ECPanelFunctionUnlock()

return ECPanelFunctionUnlock


