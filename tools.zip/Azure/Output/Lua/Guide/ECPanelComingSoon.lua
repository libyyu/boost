--[[
	“即将开启”界面
	包括其内容显示界面(ECPanelComingSoon)，提示按钮(ECPanelComingSoon.ECPanelComingSoonEntry)
]]

local Lplus = require "Lplus"
local ECPanelBase = require "GUI.ECPanelBase"
local ECGame = require "Main.ECGame"
local ECComingSoonEvents = require "Guide.ECComingSoonEvents"
local ECComingSoon = require "Guide.ECComingSoon"
local ECTaskInterface = require "Task.ECTaskInterface"
local ECTaskUtility = require "Task.ECTaskUtility"
local GcCallbacks = require "Utility.GcCallbacks"
local TaskEvents = require "Event.TaskEvents"
local HostPropertyEvents = require "Event.HostPropertyEvents"
local SelfEnterWorldEvent = require "Event.SelfEnterWorldEvent"
local ECGUITools = require "GUI.ECGUITools"
local FETimerHelper = require "Utility.FETimerHelper"
local ECVideoMan = require "Video.ECVideoMan"
local ECColorPaletteMan = require "GUI.ECColorPaletteMan"
local UIRewardView = require "GUI.Common.UIRewardView"

--TODO 外网下载会卡，需要临时屏蔽

local function printLog(...)
    if _G.LogDef.lidengfeng.value then
        print("[ComingSoon]", ...)
    end
end

---@class Guide.ECPanelComingSoon:ECPanelBase
---@field protected m_cleaner GcCallbacks
---@field protected m_IntroduceViewPic ComingSoon.ECAdvertisingPicture
---@field protected m_IntroduceViewVideo ComingSoon.ECAdvertisingVideo
---@field protected m_current_index number
---@field protected m_current_config table
---@field protected m_finish_timestamp table
---@field protected m_countdown_flag table
---@field protected m_timer FETimerHelper
---@field protected m_view_reward UIRewardView
---@field public Commit fun():Guide.ECPanelComingSoon @notnull
---@field public Instance fun():Guide.ECPanelComingSoon
---@field public GetResPath fun(self:Guide.ECPanelComingSoon):string
---@field public init fun(self:Guide.ECPanelComingSoon)
---@field public OnCreate fun(self:Guide.ECPanelComingSoon)
---@field public OnDestroy fun(self:Guide.ECPanelComingSoon)
---@field public Refresh fun(self:Guide.ECPanelComingSoon)
---@field public CanShowNext fun(self:Guide.ECPanelComingSoon):boolean
---@field public InitIntroduceView fun(self:Guide.ECPanelComingSoon)
---@field public RefreshInfo fun(self:Guide.ECPanelComingSoon)
---@field public RefreshAwardIcon fun(self:Guide.ECPanelComingSoon)
---@field public FormatLevelRequire fun(level:number):string
---@field public FormatTaskFinishedRequire fun(taskId:number):string
---@field public FormatComingSoonRequire fun(index:number):string
---@field public FormatTaskHasOrFinishedRequire fun(taskId:number):string
---@field public FormatInstanceFinishedRequire fun(inst_tid:number, mode:number):string
---@field public NeedCoolDown fun(self:Guide.ECPanelComingSoon, index:number):boolean,number
---@field public RefreshFinishStatus fun(self:Guide.ECPanelComingSoon)
---@field public RefreshIntroduceView fun(self:Guide.ECPanelComingSoon)
---@field public ShowNext fun(self:Guide.ECPanelComingSoon)
---@field public ShowPrev fun(self:Guide.ECPanelComingSoon)
---@field public onToggleObj fun(self:Guide.ECPanelComingSoon, sender:userdata, check:boolean)
---@field public onClickObj fun(self:Guide.ECPanelComingSoon, sender:userdata)
---@field public getAward fun(self:Guide.ECPanelComingSoon, config:table)
local ECPanelComingSoon = Lplus.Extend(ECPanelBase,"Guide.ECPanelComingSoon")
local l_instance = nil
do
	--[[
		内部类 ECPanelComingSoonEntry
	]]
	--[[
	---@class Guide.ECPanelComingSoon.ECPanelComingSoonEntry:ECPanelBase
	---@field public Commit fun():Guide.ECPanelComingSoon.ECPanelComingSoonEntry @notnull
	local ECPanelComingSoonEntry = Lplus.Extend(ECPanelBase,"Guide.ECPanelComingSoon.ECPanelComingSoonEntry")

    local l_entryInstance
	do
		local def = ECPanelComingSoonEntry.define

		---@return Guide.ECPanelComingSoon.ECPanelComingSoonEntry
		def.static("=>",ECPanelComingSoonEntry).Instance = function()
			return l_entryInstance
		end

		---@param self Guide.ECPanelComingSoon.ECPanelComingSoonEntry
		---@return void
		def.method().Create = function (self)
			if not self.m_panel then
				self.m_depthLayer = GUIDEPTH.BOTTOM
				self:CreatePanel(RESPATH.Panel_ComingSoonEntry)
			end
		end
		

		---@param self Guide.ECPanelComingSoon.ECPanelComingSoonEntry
		---@return void
		def.override().OnCreate = function (self)
			self.m_cleaner = GcCallbacks()

			ECGame.EventManager:addHandlerWithCleaner(ECComingSoonEvents.FunctionStageChangeEvent, function (sender, event)
				self:Refresh()
			end, self.m_cleaner)

			ECGame.EventManager:addHandlerWithCleaner(HostPropertyEvents.HostLevelUpEvent, function (sender, event)
				self:Refresh()
			end, self.m_cleaner)

			ECGame.EventManager:addHandlerWithCleaner(ECComingSoonEvents.LeaveFunctionEvent, function (sender, event)
				self:DestroyPanel()
			end, self.m_cleaner)
			
			ECGame.EventManager:addHandlerWithCleaner(SelfEnterWorldEvent, function (sender, event)
				self:Refresh()
			end, self.m_cleaner)
			
			self:Refresh()
		end
		

		---@param self Guide.ECPanelComingSoon.ECPanelComingSoonEntry
		---@return void
		def.override().OnDestroy = function (self)
			if self.m_cleaner then
				self.m_cleaner:dispose()
				self.m_cleaner = nil
			end
		end
		-----------------------------------------------
		-- End of public
		

		---@param self Guide.ECPanelComingSoon.ECPanelComingSoonEntry
		---@return void
		def.method().Refresh = function (self)
			if ECGame.Instance():GetCurrentWorldTid() ~= 0 then
				self:SetVisible(false)
				return
			end
			
			local activeIndex = ECComingSoon.Instance():GetActiveFuncIndex()
			local activeStage = ECComingSoon.Instance():GetActiveFuncStage()
			if activeStage ~= "wait_finish" and activeStage ~= "wait_get_award" then
				self:SetVisible(false)
				return
			end
			
			self:SetVisible(true)
			
			local config = ECComingSoon.GetConfig(activeIndex)
			assert(config)
			
			self:RefreshDesc(config)
			self:RefreshFinishStatus(config)
		end
		

		---@param self Guide.ECPanelComingSoon.ECPanelComingSoonEntry
		---@param config table
		---@return void
		def.method("table").RefreshDesc = function (self, config)
			ECGUITools.setTextAndColor(self.m_panel:FindDirect("Widget/Txt_Title"),config.name)
			ECGUITools.UpdateGridImage(datapath.GetPathByID(config.icon), self:FindDirect("Widget/Img_Icon"))
		end
		

		---@param self Guide.ECPanelComingSoon.ECPanelComingSoonEntry
		---@param config table
		---@return void
		def.method("table").RefreshFinishStatus = function (self, config)
			local text = self:FindDirect("Widget/Txt_Lv")
			--local finish_fx = self.m_panel:FindChild("finish_fx")
			
			local activeStage = ECComingSoon.Instance():GetActiveFuncStage()
			local condition = config.finish_condition
			
			if activeStage == "wait_finish" then	--未完成

				--if not ECComingSoon.IsLevelFit(condition.level_above) then
				--	text:SetText(StringTable.Get(3302):format(condition.level_above))		--"%d级\n可获得"
				--elseif not ECComingSoon.IsTaskFinishedFit(condition.task_is_finished) then
				--	local taskName = ECTaskUtility.FormatTaskBaseName(condition.task_is_finished)
				--	text:SetText(StringTable.Get(3303):format(taskName))		--"%s\n完成获得"
				--else
				--	text:SetText("")
				--end
				--finish_fx:SetActive(false)
				text:SetText(config.tip)
			else	--完成
				text:SetText(StringTable.Get(3301))		--"  \n已满足"
				--finish_fx:SetActive(true)
			end
		end
		

		---@param self Guide.ECPanelComingSoon.ECPanelComingSoonEntry
		---@param id string
		---@return void
		def.method("string").onClick = function (self, id)
			ECPanelComingSoon.Instance():Toggle()
			
			--local UserMoveEvent = require "Event.UserMoveEvent"
			--ECGame.EventManager:raiseEvent(self, UserMoveEvent.new(UserMoveEventType.UserClick))
		end


		---@type GcCallbacks
		def.field(GcCallbacks).m_cleaner = nil
	end
	ECPanelComingSoonEntry.Commit()

	---@type table
	def.const("table").ECPanelComingSoonEntry = ECPanelComingSoonEntry
	
	l_entryInstance = ECPanelComingSoonEntry()
	]]


	---@class ECPanelComingSoon.DynamicTokenTransfer:System.Object
	---@field public Commit fun():ECPanelComingSoon.DynamicTokenTransfer @notnull
	---@field public Translate fun(oriStr:string, env:table):string
	local DynamicTokenTransfer = Lplus.Class("ECPanelComingSoon.DynamicTokenTransfer")
	do
		local def = DynamicTokenTransfer.define
		local function RequireConditionParam(env, paramName)
			local value = env.condition[paramName]
			if not value then
				Log.DebugError("ECPanelComingSoon:转译时未找到条件配置"..tostring(paramName))
			end
			return value
		end
		local transferMap = {}
		transferMap.level_above = function(env)
			local level = RequireConditionParam(env, "level_above")
			if not level then return "" end
			return ECPanelComingSoon.FormatLevelRequire(level)
		end

		transferMap.task_is_finished = function(env)
			local taskId = RequireConditionParam(env, "task_is_finished")
			if not taskId then return "" end
			return ECPanelComingSoon.FormatTaskFinishedRequire(taskId)
		end

		transferMap.task_is_finished_bak = function(env)
			local taskId = RequireConditionParam(env, "task_is_finished_bak")
			if not taskId then return "" end
			return ECPanelComingSoon.FormatTaskFinishedRequire(taskId)
		end

		transferMap.instance_finished = function(env)
			local instanceCfg = RequireConditionParam(env, "instance_finished")
			if not instanceCfg then return "" end
			local tid, mode = instanceCfg.tid, instanceCfg.value
			return ECPanelComingSoon.FormatInstanceFinishedRequire(tid, mode or 1)
		end

		transferMap.task_has_or_finished = function(env)
			local taskId = RequireConditionParam(env, "task_has_or_finished")
			if not taskId then return "" end
			return ECPanelComingSoon.FormatTaskHasOrFinishedRequire(taskId)
		end

		local patternStr = "<%%([%w_]+)%%>"
		---@param oriStr string
		---@param env table
		---@return string
		def.static("string", "table", "=>", "string").Translate = function(oriStr, env)
			local resultStr = string.gsub(oriStr, patternStr, function (token)
				local transferFunc = transferMap[token]
				if not transferFunc then
					Log.DebugError("ECPanelComingSoon:未知的转译关键字", token)
					return token
				end

				local itemResult = transferFunc(env)
				return itemResult
			end)
			return resultStr
		end


		DynamicTokenTransfer.Commit()
	end
	
	local downloading_caches = {}
	local resource_type =
	{
		Media = 0,
		Picture = 1,
	}
	---媒体播放基础类
	---@class ComingSoon.ECAdvertisingBase:System.Object
	---@field protected m_owner Guide.ECPanelComingSoon
	---@field protected m_config table
	---@field protected m_index number
	---@field protected m_sourceList table
	---@field protected m_timer FETimerHelper
	---@field public Commit fun():ComingSoon.ECAdvertisingBase @notnull
	---@field public SetVisible fun(self:ComingSoon.ECAdvertisingBase, b:boolean)
	---@field public OnCreate fun(self:ComingSoon.ECAdvertisingBase)
	---@field public OnDestroy fun(self:ComingSoon.ECAdvertisingBase)
	---@field public onClickObj fun(self:ComingSoon.ECAdvertisingBase, sender:userdata)
	---@field public onToggleObj fun(self:ComingSoon.ECAdvertisingBase, sender:userdata, active:boolean)
	---@field public OnReadyToPlay fun(self:ComingSoon.ECAdvertisingBase)
	---@field public OnPreCacheNext fun(self:ComingSoon.ECAdvertisingBase)
	---@field public PrepareMediaSource fun(self:ComingSoon.ECAdvertisingBase, callback:function)
	---@field public GetCurrentSourceConfig fun(self:ComingSoon.ECAdvertisingBase):table
	---@field public InitFromConfig fun(self:ComingSoon.ECAdvertisingBase, config:table)
	---@field public OnInitWithConfig fun(self:ComingSoon.ECAdvertisingBase)
	---@field public PlayIndex fun(self:ComingSoon.ECAdvertisingBase, index:number)
	---@field public UpdateDesc fun(self:ComingSoon.ECAdvertisingBase)
	---@field public PlayNext fun(self:ComingSoon.ECAdvertisingBase)
	---@field public PlayPrev fun(self:ComingSoon.ECAdvertisingBase)
	---@field public StartPlay fun(self:ComingSoon.ECAdvertisingBase)
	---@field public StopPlay fun(self:ComingSoon.ECAdvertisingBase)
	---@field public PreCheckConfigValid fun(self:ComingSoon.ECAdvertisingBase, config:table):boolean
	---@field public GetCacheFolder fun(_:ComingSoon.ECAdvertisingBase):string
	---@field public InvokeDownloadCallback fun(self:ComingSoon.ECAdvertisingBase, fileURL:string)
	---@field public IsDownloading fun(self:ComingSoon.ECAdvertisingBase, fileURL:string):boolean
	local ECAdvertisingBase = Lplus.Class("ComingSoon.ECAdvertisingBase")
	do
		local def = ECAdvertisingBase.define

		---@type Guide.ECPanelComingSoon
		def.field(ECPanelComingSoon).m_owner = nil

		---@type table
		def.field("table").m_config = nil

		---@type number
		def.field("number").m_index = 0

		---@type table
		def.field("table").m_sourceList = function() return {} end

		---@type FETimerHelper
		def.field(FETimerHelper).m_timer = function() return FETimerHelper() end

		---@param self ComingSoon.ECAdvertisingBase
		---@param b boolean
		---@return void
		def.virtual("boolean").SetVisible = function(self, b)
		end

		---@param self ComingSoon.ECAdvertisingBase
		---@return void
		def.virtual().OnCreate = function(self)
			printLog("ECAdvertisingBase.OnCreate", self.m_index)
		end
		---@param self ComingSoon.ECAdvertisingBase
		---@return void
		def.virtual().OnDestroy = function(self)
			self.m_timer:RemoveAllTimer()
			printLog("ECAdvertisingBase.OnDestroy", self.m_index)
		end
		---@param self ComingSoon.ECAdvertisingBase
		---@param sender userdata
		---@return void
		def.virtual("userdata").onClickObj = function(self, sender) end
		---@param self ComingSoon.ECAdvertisingBase
		---@param sender userdata
		---@param active boolean
		---@return void
		def.virtual("userdata", "boolean").onToggleObj = function(self, sender, active) end

		---@param self ComingSoon.ECAdvertisingBase
		---@return void
		def.virtual().OnReadyToPlay = function(self)
			printLog("ECAdvertisingBase.OnReadyToPlay", self.m_index)
		end

		---@param self ComingSoon.ECAdvertisingBase
		---@return void
		def.virtual().OnPreCacheNext = function(self)
			printLog("ECAdvertisingBase.OnPreCacheNext", self.m_index)
		end

		---@param self ComingSoon.ECAdvertisingBase
		---@param callback function
		---@return void
		def.virtual("function").PrepareMediaSource = function(self, callback)
			printLog("ECAdvertisingBase.PrepareMediaSource", self.m_index)
		end

		---@param self ComingSoon.ECAdvertisingBase
		---@return table
		def.method("=>", "table").GetCurrentSourceConfig = function(self)
			return self.m_sourceList[self.m_index]
		end

		---@param self ComingSoon.ECAdvertisingBase
		---@param config table
		---@return void
		def.method("table").InitFromConfig = function(self, config)
			printLog("ECAdvertisingBase.InitFromConfig", self.m_index)
			if not self:PreCheckConfigValid(config) then
				return
			end
			self.m_config = config
			self.m_sourceList = {}
			self.m_index = 0

			for i, v in ipairs(self.m_config.notice_resource) do
				local res = v.resource
				local fileURL = res[1]
				local duration = res[2]
				local fileType = res[3]

				local sourceConfig = {
					fileURL = fileURL,
					fileType = fileType,
					duration = duration,
					desc = v.desc,
				}
				if sourceConfig.fileType == 0 then --本地
					sourceConfig.localPath = sourceConfig.fileURL

				elseif sourceConfig.fileType == 1 then --在线下载本地
					local TempFileLocalPath, TempLocalFlag = ECVideoMan.TransformURLToFilename(sourceConfig.fileURL)
					local localFilePath = self:GetCacheFolder() .."/"..TempFileLocalPath

					sourceConfig.localPath = localFilePath

					if self.m_config.mayChange and ECVideoMan.IsFileExist(sourceConfig.localPath) then
						TCos.DeleteFile(sourceConfig.localPath)
					end
				end

				table.insert(self.m_sourceList, sourceConfig)
			end

			self:OnInitWithConfig()
		end
		---@param self ComingSoon.ECAdvertisingBase
		---@return void
		def.virtual().OnInitWithConfig = function(self)
			printLog("ECAdvertisingBase.OnInitWithConfig", self.m_index)
		end

		---@param self ComingSoon.ECAdvertisingBase
		---@param index number
		---@return void
		def.virtual("number").PlayIndex = function(self, index)
			local oldIndex = self.m_index
			if oldIndex == index then
				return
			end
			self.m_index = index
			printLog("ECAdvertisingBase.PlayIndex", oldIndex, "-->", self.m_index)
			--准备
			self:PrepareMediaSource(function()
				self:OnReadyToPlay()
				self:OnPreCacheNext()
			end)

			self:UpdateDesc()
		end

		---@param self ComingSoon.ECAdvertisingBase
		---@return void
		def.method().UpdateDesc = function(self)
			if not self.m_owner or not self.m_owner:IsValid() then
				return
			end
			if not self.m_config then return end
			
			local notice_resource = self.m_config.notice_resource
			if notice_resource and notice_resource[self.m_index] then
				local content = notice_resource[self.m_index].desc
				local condition
				if self.m_config.finish_condition then
					condition = self.m_config.finish_condition
				else
					condition = self.m_config.activate_condition
				end

				if condition then
					content = DynamicTokenTransfer.Translate(content, {condition = condition})
				end
				self.m_owner:RequireFind("Widget/Preview/ConditionContent/Describe"):SetHTMLText(content)
			end
		end

		---@param self ComingSoon.ECAdvertisingBase
		---@return void
		def.virtual().PlayNext = function(self)
			local newIndex = self.m_index
			if newIndex >= #self.m_sourceList then
				newIndex = 0
			end
			newIndex = newIndex + 1
			printLog("ECAdvertisingBase.PlayNext", newIndex)

			self:PlayIndex(newIndex)
		end

		---@param self ComingSoon.ECAdvertisingBase
		---@return void
		def.virtual().PlayPrev = function(self)
			local newIndex = self.m_index
			newIndex = newIndex - 1
			if newIndex <= 0 then
				newIndex = #self.m_sourceList
			end
			printLog("ECAdvertisingBase.PlayPrev", newIndex)

			self:PlayIndex(newIndex)
		end

		---@param self ComingSoon.ECAdvertisingBase
		---@return void
		def.virtual().StartPlay = function(self)
			printLog("ECAdvertisingBase.StartPlay", self.m_index)
			self:PlayNext()
		end

		---@param self ComingSoon.ECAdvertisingBase
		---@return void
		def.virtual().StopPlay = function(self)
			printLog("ECAdvertisingBase.StopPlay", self.m_index)
		end

		---@param self ComingSoon.ECAdvertisingBase
		---@param config table
		---@return boolean
		def.virtual("table", "=>", "boolean").PreCheckConfigValid = function(self, config)
			return true
		end

		---@param _ ComingSoon.ECAdvertisingBase
		---@return string
		def.virtual("=>", "string").GetCacheFolder = function(_)
		end

		---@param self ComingSoon.ECAdvertisingBase
		---@param fileURL string
		---@return void
		def.method("string").InvokeDownloadCallback = function(self, fileURL)
			if downloading_caches[fileURL] then
				local vinfo = downloading_caches[fileURL]
				downloading_caches[fileURL] = nil
				for _, v in ipairs(vinfo) do
					if v.callback then
						v.callback()
					end
				end
			end
		end

		---@param self ComingSoon.ECAdvertisingBase
		---@param fileURL string
		---@return boolean
		def.method("string", "=>", "boolean").IsDownloading = function(self, fileURL)
			return not not downloading_caches[fileURL]
		end
	end
	ECAdvertisingBase.Commit()

	---图片轮播
	---@class ComingSoon.ECAdvertisingPicture:ComingSoon.ECAdvertisingBase
	---@field public ownerCanvas userdata
	---@field public picListObj userdata
	---@field public picPageObj userdata
	---@field private _tex_map table
	---@field public Commit fun():ComingSoon.ECAdvertisingPicture @notnull
	---@field public New fun(owner:Guide.ECPanelComingSoon):ComingSoon.ECAdvertisingPicture
	---@field public SetVisible fun(self:ComingSoon.ECAdvertisingPicture, b:boolean)
	---@field public OnCreate fun(self:ComingSoon.ECAdvertisingPicture)
	---@field public OnDestroy fun(self:ComingSoon.ECAdvertisingPicture)
	---@field public StopPlay fun(self:ComingSoon.ECAdvertisingPicture)
	---@field public OnInitWithConfig fun(self:ComingSoon.ECAdvertisingPicture)
	---@field public StartPlay fun(self:ComingSoon.ECAdvertisingPicture)
	---@field public PlayIndex fun(self:ComingSoon.ECAdvertisingPicture, index:number)
	---@field public PreCheckConfigValid fun(self:ComingSoon.ECAdvertisingPicture, config:table):boolean
	---@field public PrepareMediaSource fun(self:ComingSoon.ECAdvertisingPicture, callback:function)
	---@field public OnReadyToPlay fun(self:ComingSoon.ECAdvertisingPicture)
	---@field public OnPreCacheNext fun(self:ComingSoon.ECAdvertisingPicture)
	---@field public GetCacheFolder fun(_:ComingSoon.ECAdvertisingPicture):string
	---@field public UpdatePicList fun(self:ComingSoon.ECAdvertisingPicture)
	---@field public onToggleObj fun(self:ComingSoon.ECAdvertisingPicture, sender:userdata, active:boolean)
	local ECAdvertisingPicture = Lplus.Extend(ECAdvertisingBase, "ComingSoon.ECAdvertisingPicture")
	do
		local def = ECAdvertisingPicture.define

		---@type userdata
		def.field("userdata").ownerCanvas = nil

		---@type userdata
		def.field("userdata").picListObj = nil

		---@type userdata
		def.field("userdata").picPageObj = nil

		---@type table
		def.field("table")._tex_map = function() return {} end

		---@param owner Guide.ECPanelComingSoon
		---@return ComingSoon.ECAdvertisingPicture
		def.static(ECPanelComingSoon, "=>", ECAdvertisingPicture).New = function(owner)
			local obj = ECAdvertisingPicture()
			obj.m_owner = owner
			return obj
		end

		---@param self ComingSoon.ECAdvertisingPicture
		---@param b boolean
		---@return void
		def.override("boolean").SetVisible = function(self, b)
			if self.ownerCanvas and not self.ownerCanvas:is_nil() then
				self.ownerCanvas:SetVisibility(b and ESlateVisibility.Visible or ESlateVisibility.Collapsed)
			end

			if not b then
				self:StopPlay()
			end
		end

		---@param self ComingSoon.ECAdvertisingPicture
		---@return void
		def.override().OnCreate = function(self)
			printLog("ECAdvertisingPicture.OnCreate", self.m_index)
			self.ownerCanvas = self.m_owner:RequireFind("Widget/Preview/Introduction/Picture")
			self.picListObj = self.ownerCanvas:RequireFind("Scroll_Pic")
			self.picPageObj = self.ownerCanvas:RequireFind("Page_List")
			ECAdvertisingBase.OnCreate(self)

			ScrollList_setUpdateFunc(self.picListObj, function(itemObj, index)
				local tex = self._tex_map[index]
				if tex then
					itemObj:RequireFind("WIdget/Image_0"):SetBrushFromTexture(tex, true)
				end
			end)
		end

		---@param self ComingSoon.ECAdvertisingPicture
		---@return void
		def.override().OnDestroy = function(self)
			printLog("ECAdvertisingPicture.OnDestroy", self.m_index)
			self.ownerCanvas = nil
			self.picListObj = nil
			self.picPageObj = nil
			self._tex_map = {}
			self:StopPlay()
			ECAdvertisingBase.OnDestroy(self)
		end

		---@param self ComingSoon.ECAdvertisingPicture
		---@return void
		def.override().StopPlay = function(self)
			printLog("ECAdvertisingPicture.StopPlay", self.m_index)
			self.m_timer:RemoveTimer("ad_loop")

			--if self.ownerCanvas and not self.ownerCanvas:is_nil() then
			--	self.ownerCanvas:SetVisibility(false)
			--end

			for fileURL, vinfo in pairs(downloading_caches) do
				if not vinfo or not vinfo.config then
					downloading_caches[fileURL] = nil
				end
			end
			ECAdvertisingBase.StopPlay(self)
		end

		---@param self ComingSoon.ECAdvertisingPicture
		---@return void
		def.override().OnInitWithConfig = function(self)
			printLog("ECAdvertisingPicture.OnInitWithConfig", self.m_index)
			self._tex_map = {}
		end

		---@param self ComingSoon.ECAdvertisingPicture
		---@return void
		def.override().StartPlay = function(self)
			if not self.picListObj or self.picListObj:is_nil() then
				return
			end
			printLog("ECAdvertisingPicture.StartPlay", self.m_index, "source num = ", #self.m_sourceList)
			self.picListObj:SetCount(#self.m_sourceList)
			self.picPageObj:SetCount(#self.m_sourceList)
			--if self.ownerCanvas and not self.ownerCanvas:is_nil() then
			--	self.ownerCanvas:SetVisibility(true)
			--end
			self.picPageObj:SetActive(#self.m_sourceList >1)
			for i=1, #self.m_sourceList do
				local objPage = self.picPageObj:getItem(i)
				objPage:RequireFind("Tab_Advert_1"):SetUserData(i)
				objPage:RequireFind("Tab_Advert_1"):SetChecked(i == self.m_index)
			end

			ECAdvertisingBase.StartPlay(self)
		end

		---@param self ComingSoon.ECAdvertisingPicture
		---@param index number
		---@return void
		def.override("number").PlayIndex = function(self, index)
			ECAdvertisingBase.PlayIndex(self, index)

			local sourceConfig = self:GetCurrentSourceConfig()
			if #self.m_sourceList >1 then
				--页码
				if self.picPageObj and not self.picPageObj:is_nil() then
					local objPage = self.picPageObj:getItem(index)
					if objPage then
						objPage:RequireFind("Tab_Advert_1"):SetChecked(true)
					end
				end
				--计时
				self.m_timer:AddTimer("ad_loop", sourceConfig.duration, true, function()
					printLog("ECAdvertisingPicture. Auto PlayNext")
					self:PlayNext()
				end)
				if self.picListObj and not self.picListObj:is_nil() then
					ScrollList_setFirstIndex(self.picListObj, index, true)
				end
			end
		end

		---@param self ComingSoon.ECAdvertisingPicture
		---@param config table
		---@return boolean
		def.override("table", "=>", "boolean").PreCheckConfigValid = function(self, config)
			if config.notice_type ~= resource_type.Picture then
				Debug.LogError(string.format("notice_type must be Picture in '%s'", tostring_r(config)))
				return false
			end

			if not config.notice_resource or #(config.notice_resource) == 0 then
				Debug.LogError(string.format("resource must not be empty in '%s'", tostring_r(config)))
				return false
			end

			return true
		end

		---@param self ComingSoon.ECAdvertisingPicture
		---@param callback function
		---@return void
		def.override("function").PrepareMediaSource = function(self, callback)
			printLog("ECAdvertisingPicture.PrepareMediaSource", self.m_index)

			local sourceList = self.m_sourceList
			local sourceIndex = self.m_index

			local sourceConfig = sourceList[sourceIndex]
			if sourceConfig.fileType == 0 then --本地图片
				callback()
			elseif sourceConfig.fileType == 1 then --在线下载本地
				if ECVideoMan.IsFileExist(sourceConfig.localPath) then
					callback()
				else
					if downloading_caches[sourceConfig.fileURL] then --正在下载中
						table.insert(downloading_caches[sourceConfig.fileURL], {callback=callback, config=sourceConfig})
						return
					end
					downloading_caches[sourceConfig.fileURL] = downloading_caches[sourceConfig.fileURL] or {}
					table.insert(downloading_caches[sourceConfig.fileURL], {callback=callback, config=sourceConfig})
					ECVideoMan.LoadVideoFile(sourceConfig.fileURL, sourceConfig.localPath, function(bSuccess, fileURL, filename, isDownload)
						--不管下载成功还是失败，都调用
						self:InvokeDownloadCallback(fileURL)
					end)
				end
			else--不支持
				Debug.LogError("unsupport fileType for Picture!")
			end
		end

		---@param self ComingSoon.ECAdvertisingPicture
		---@return void
		def.override().OnReadyToPlay = function(self)
			printLog("ECAdvertisingPicture.OnReadyToPlay", self.m_index)
			local sourceConfig = self:GetCurrentSourceConfig()
			if not sourceConfig then
				Debug.LogError("current is nil.")
				return
			end

			if self._tex_map[self.m_index] then
				self:UpdatePicList()
				return
			end
			local tmp_index = self.m_index
			local function _onload(tex)
				self._tex_map[tmp_index] = tex
				self:UpdatePicList()


				--这里在更新一下页码吧， 打开第一次没法选中
				if tmp_index == self.m_index and self.picPageObj and not self.picPageObj:is_nil() then
					local objPage = self.picPageObj:getItem(self.m_index)
					if objPage then
						objPage:RequireFind("Tab_Advert_1"):SetChecked(true)
					end
				end

			end

			if sourceConfig.fileType == 0 then
				GameUtil.AsyncLoad(sourceConfig.localPath, function (texture)
					_onload(texture)
				end)
			elseif sourceConfig.fileType == 1 then
				TCos.LoadTexture(sourceConfig.localPath, -1, -1, function(tex, _filename, wLimit, hLimit)
					_onload(tex)
				end)
			else
			end
		end

		---@param self ComingSoon.ECAdvertisingPicture
		---@return void
		def.override().OnPreCacheNext = function(self)
			printLog("ECAdvertisingPicture.OnPreCacheNext", self.m_index)
			local sourceList = self.m_sourceList
			local sourceIndex = self.m_index

			if sourceIndex >= #sourceList then
				return
			end

			local nextSource = sourceList[sourceIndex+1]
			if nextSource.fileType == 0 then --本地图片
			elseif nextSource.fileType == 1 then --在线下载本地
				if ECVideoMan.IsFileExist(nextSource.localPath) then
					return
				else
					if downloading_caches[nextSource.fileURL] then --正在下载中
						return
					end
					ECVideoMan.LoadVideoFile(nextSource.fileURL, nextSource.localPath, function(bSuccess, fileURL, filename, isDownload)
						self:InvokeDownloadCallback(fileURL)
					end)
				end
			else--不支持

			end
		end

		---@param _ ComingSoon.ECAdvertisingPicture
		---@return string
		def.override("=>", "string").GetCacheFolder = function(_)
			local video_folder = GameUtil.GetAssetsPath() .. "/UserData/ComingSoon/Picture"
			return video_folder
		end

		---@param self ComingSoon.ECAdvertisingPicture
		---@return void
		def.method().UpdatePicList = function(self)
			if not self.picListObj or self.picListObj:is_nil() then
				return
			end
			printLog("ECAdvertisingPicture.UpdatePicList", self.m_index)
			--self.picPageObj:SetCount(#self.m_sourceList)
			--ScrollList_setCount(self.picListObj, #self.m_sourceList)
			ScrollList_forceUpdate(self.picListObj)
		end

		---@param self ComingSoon.ECAdvertisingPicture
		---@param sender userdata
		---@param active boolean
		---@return void
		def.override("userdata", "boolean").onToggleObj = function(self, sender, active)
			local id = sender:GetName()
			if id == "Tab_Advert_1" then
				local ud = sender:GetUserData()
				if tonumber(ud) then
					if ud ~= self.m_index then
						self:StopPlay()
						self:PlayIndex(ud)
					end
				end
			end
		end
	end
	ECAdvertisingPicture.Commit()

	---@class ComingSoon.ECAdvertisingVideo:ComingSoon.ECAdvertisingBase
	---@field protected m_mediaPlaylist userdata
	---@field protected m_mediaPlayer userdata
	---@field protected m_mediaUIMaterial userdata
	---@field protected m_bindOnMediaOpen userdata
	---@field protected m_bindOnEndReached userdata
	---@field protected m_bindOnSeekCompleted userdata
	---@field protected m_mediaStaticCanvas userdata
	---@field protected m_mediaStaticProgress userdata
	---@field public Commit fun():ComingSoon.ECAdvertisingVideo @notnull
	---@field public New fun(owner:Guide.ECPanelComingSoon):ComingSoon.ECAdvertisingVideo
	---@field public SetVisible fun(self:ComingSoon.ECAdvertisingVideo, b:boolean)
	---@field public OnCreate fun(self:ComingSoon.ECAdvertisingVideo)
	---@field public OnDestroy fun(self:ComingSoon.ECAdvertisingVideo)
	---@field public StopPlay fun(self:ComingSoon.ECAdvertisingVideo)
	---@field public PreCheckConfigValid fun(self:ComingSoon.ECAdvertisingVideo, config:table):boolean
	---@field public PrepareMediaSource fun(self:ComingSoon.ECAdvertisingVideo, callback:function)
	---@field public PlayNext fun(self:ComingSoon.ECAdvertisingVideo)
	---@field public PlayPrev fun(self:ComingSoon.ECAdvertisingVideo)
	---@field public PlayIndex fun(self:ComingSoon.ECAdvertisingVideo, index:number)
	---@field public GetDuration fun(self:ComingSoon.ECAdvertisingVideo):number
	---@field public GetTime fun(self:ComingSoon.ECAdvertisingVideo):number
	---@field public ClearMaterial fun(self:ComingSoon.ECAdvertisingVideo)
	---@field public PrepareMediaPlayer fun(self:ComingSoon.ECAdvertisingVideo)
	---@field public PrepareMediaCanvas fun(self:ComingSoon.ECAdvertisingVideo)
	---@field public OnReadyToPlay fun(self:ComingSoon.ECAdvertisingVideo)
	---@field private _OnMediaOpenedCallback fun(self:ComingSoon.ECAdvertisingVideo)
	---@field private _OnEndReachedCallback fun(self:ComingSoon.ECAdvertisingVideo)
	---@field private _OnSeekCompletedCallback fun(self:ComingSoon.ECAdvertisingVideo)
	---@field public RemovePlaylistAllSource fun(self:ComingSoon.ECAdvertisingVideo)
	---@field public OnPreCacheNext fun(self:ComingSoon.ECAdvertisingVideo)
	---@field public GetCacheFolder fun(_:ComingSoon.ECAdvertisingVideo):string
	local ECAdvertisingVideo = Lplus.Extend(ECAdvertisingBase, "ComingSoon.ECAdvertisingVideo")
	do
		local def = ECAdvertisingVideo.define

		---@type userdata
		def.field("userdata").m_mediaPlaylist = nil
		---@type userdata
		def.field("userdata").m_mediaPlayer = nil
		---@type userdata
		def.field("userdata").m_mediaUIMaterial = nil
		---@type userdata
		def.field("userdata").m_bindOnMediaOpen = nil
		---@type userdata
		def.field("userdata").m_bindOnEndReached = nil
		---@type userdata
		def.field("userdata").m_bindOnSeekCompleted = nil
		---@type userdata
		def.field("userdata").m_mediaStaticCanvas = nil
		---@type userdata
		def.field("userdata").m_mediaStaticProgress = nil

		---@param owner Guide.ECPanelComingSoon
		---@return ComingSoon.ECAdvertisingVideo
		def.static(ECPanelComingSoon, "=>", ECAdvertisingVideo).New = function(owner)
			local obj = ECAdvertisingVideo()
			obj.m_owner = owner
			return obj
		end

		---@param self ComingSoon.ECAdvertisingVideo
		---@param b boolean
		---@return void
		def.override("boolean").SetVisible = function(self, b)
			if self.m_owner:IsValid() then
				self.m_owner:RequireFind("Widget/Preview/Introduction/Video"):SetActive(b)
			end
		end

		---@param self ComingSoon.ECAdvertisingVideo
		---@return void
		def.override().OnCreate = function(self)
			printLog("ECAdvertisingVideo.OnCreate", self.m_index)
			ECAdvertisingBase.OnCreate(self)
			self.m_mediaStaticCanvas = self.m_owner:RequireFind("Widget/Preview/Introduction/Video/Video_Content")
			self.m_mediaStaticProgress = self.m_owner:RequireFind("Widget/Preview/Introduction/Video/Video_pro")
		end

		---@param self ComingSoon.ECAdvertisingVideo
		---@return void
		def.override().OnDestroy = function(self)
			printLog("ECAdvertisingVideo.OnDestroy", self.m_index)
			self:StopPlay()

			if self.m_mediaPlayer and not self.m_mediaPlayer:is_nil() then
				self.m_mediaPlayer:Close()
				if self.m_bindOnMediaOpen then
					self.m_mediaPlayer:unbindOnMediaOpened(self.m_bindOnMediaOpen)
					self.m_bindOnMediaOpen = nil
				end
				if self.m_bindOnEndReached then
					self.m_mediaPlayer:unbindOnEndReached(self.m_bindOnEndReached)
					self.m_bindOnEndReached = nil
				end
				if self.m_bindOnSeekCompleted then
					self.m_mediaPlayer:unbindOnSeekCompleted(self.m_bindOnSeekCompleted)
					self.m_bindOnSeekCompleted = nil
				end
			end
			self.m_mediaPlaylist = nil
			self.m_mediaPlayer = nil
			self.m_mediaUIMaterial = nil
			ECAdvertisingBase.OnDestroy(self)
		end

		---@param self ComingSoon.ECAdvertisingVideo
		---@return void
		def.override().StopPlay = function(self)
			printLog("ECAdvertisingVideo.StopPlay", self.m_index)
			if self.m_mediaStaticCanvas and not self.m_mediaStaticCanvas:is_nil() then
				self.m_mediaStaticCanvas:SetVisibility(ESlateVisibility.Collapsed)
			end

			for fileURL, vinfo in pairs(downloading_caches) do
				if not vinfo or not vinfo.config then
					downloading_caches[fileURL] = nil
				end
			end

			self:RemovePlaylistAllSource()
			if self.m_mediaPlayer and not self.m_mediaPlayer:is_nil() then
				self.m_mediaPlayer:Close()
			end

			self.m_timer:RemoveTimer("tick_pro")

			ECAdvertisingBase.StopPlay(self)
		end

		---@param self ComingSoon.ECAdvertisingVideo
		---@param config table
		---@return boolean
		def.override("table", "=>", "boolean").PreCheckConfigValid = function(self, config)
			--print_ldf("PreCheckConfigValid", self)
			if config.notice_type ~= resource_type.Media then
				Debug.LogError(string.format("notice_type is invalid in '%s'", tostring_r(config)))
				return false
			end

			if not config.notice_resource or #(config.notice_resource) == 0 then
				Debug.LogError(string.format("notice_resource must not be empty in '%s'", tostring_r(config)))
				return false
			end

			return true
		end

		---@param self ComingSoon.ECAdvertisingVideo
		---@param callback function
		---@return void
		def.override("function").PrepareMediaSource = function(self, callback)
			printLog("ECAdvertisingVideo.PrepareMediaSource", self.m_index)
			local sourceList = self.m_sourceList
			local sourceIndex = self.m_index

			local sourceConfig = sourceList[sourceIndex]
			if sourceConfig.fileType == 0 then --本地视频
				callback()
			elseif sourceConfig.fileType == 1 then --在线下载本地
				if ECVideoMan.IsFileExist(sourceConfig.localPath) then
					callback()
				else
					if downloading_caches[sourceConfig.fileURL] then --正在下载中
						table.insert(downloading_caches[sourceConfig.fileURL], {callback=callback, config=sourceConfig})
						return
					end
					downloading_caches[sourceConfig.fileURL] = downloading_caches[sourceConfig.fileURL] or {}
					table.insert(downloading_caches[sourceConfig.fileURL], {callback=callback, config=sourceConfig})
					ECVideoMan.LoadVideoFile(sourceConfig.fileURL, sourceConfig.localPath, function(bSuccess, fileURL, filename, isDownload)
						--不管下载成功还是失败，都调用
						self:InvokeDownloadCallback(fileURL)
					end)
				end
			else --在线播放
				callback()
			end
		end

		---@param self ComingSoon.ECAdvertisingVideo
		---@return void
		def.override().PlayNext = function(self)
			printLog("ECAdvertisingVideo.PlayNext", self.m_index)
			self:RemovePlaylistAllSource()
			if self.m_mediaPlayer and not self.m_mediaPlayer:is_nil() then
				self.m_mediaPlayer:Close()
			end
			self:ClearMaterial()
			ECAdvertisingBase.PlayNext(self)
		end

		---@param self ComingSoon.ECAdvertisingVideo
		---@return void
		def.override().PlayPrev = function(self)
			printLog("ECAdvertisingVideo.PlayPrev", self.m_index)
			self:RemovePlaylistAllSource()
			if self.m_mediaPlayer and not self.m_mediaPlayer:is_nil() then
				self.m_mediaPlayer:Close()
			end

			ECAdvertisingBase.PlayPrev(self)
		end

		---@param self ComingSoon.ECAdvertisingVideo
		---@param index number
		---@return void
		def.override("number").PlayIndex = function(self, index)
			ECAdvertisingBase.PlayIndex(self, index)

			if self.m_mediaStaticProgress and not self.m_mediaStaticProgress:is_nil() then
				self.m_mediaStaticProgress:SetPercent(0)
			end
		end

		---@param self ComingSoon.ECAdvertisingVideo
		---@return number
		def.method("=>", "number").GetDuration = function(self)
			if not self.m_mediaPlayer or self.m_mediaPlayer:is_nil() then
				return -1
			end
			return self.m_mediaPlayer:GetDurationTimeStamp()
		end

		---获取当前视频已经播放时间
		---@param self ComingSoon.ECAdvertisingVideo
		---@return number
		def.method("=>", "number").GetTime = function(self)
			if not self.m_mediaPlayer or self.m_mediaPlayer:is_nil() then
				return 0
			end
			return self.m_mediaPlayer:GetTimeTimeStamp()
		end

		---@param self ComingSoon.ECAdvertisingVideo
		---@return void
		def.method().ClearMaterial = function(self)
			if not self.m_mediaStaticCanvas or self.m_mediaStaticCanvas:is_nil() then
				return
			end
			self.m_mediaStaticCanvas:SetBrushFromAtlas(nil)
			self.m_mediaStaticCanvas:SetBrushFromMaterial(nil)
		end

		---准备播放器
		---@param self ComingSoon.ECAdvertisingVideo
		---@return void
		def.method().PrepareMediaPlayer = function(self)
			printLog("ECAdvertisingVideo.PrepareMediaPlayer", self.m_index)
			if not self.m_mediaPlayer or self.m_mediaPlayer:is_nil() then
				if not self.m_config.mediaPlayerPath then
					self.m_mediaPlayer = GameUtil.SyncLoad(RESPATH.MediaPlayer, g_LoadType_MediaPlayer)
				else
					self.m_mediaPlayer = GameUtil.SyncLoad(self.m_config.mediaPlayerPath, g_LoadType_MediaPlayer)
				end
			end
			if not self.m_mediaPlaylist or self.m_mediaPlaylist:is_nil() then
				if not self.m_config.mediaPlaylistPath then
					self.m_mediaPlaylist = GameUtil.SyncLoad(RESPATH.MediaPlaylist, g_LoadType_MediaPlaylist)
				else
					self.m_mediaPlaylist = GameUtil.SyncLoad(self.m_config.mediaPlaylistPath, g_LoadType_MediaPlaylist)
				end
			end

			if not self.m_mediaUIMaterial or self.m_mediaUIMaterial:is_nil() then
				if not self.m_config.mediaUIMaterial then
					self.m_mediaUIMaterial = GameUtil.SyncLoad(RESPATH.Movie1UI)
				else
					self.m_mediaUIMaterial = GameUtil.SyncLoad(self.m_config.mediaUIMaterial)
				end
			end


			if #self.m_sourceList == 1 then--单碟循环
				self.m_mediaPlayer:SetLooping(true)
			else
				self.m_mediaPlayer:SetLooping(false)
			end

		end

		---@param self ComingSoon.ECAdvertisingVideo
		---@return void
		def.method().PrepareMediaCanvas = function(self)
			if not self.m_mediaStaticCanvas then
				warn("failed to init self.m_mediaStaticCanvas")
				return
			end

			self.m_mediaStaticCanvas:SetVisibility(ESlateVisibility.Collapsed)
			self.m_mediaStaticCanvas:SetBrushFromAtlas(nil)
			self.m_mediaStaticCanvas:SetBrushFromMaterial(nil)
		end

		---@param self ComingSoon.ECAdvertisingVideo
		---@return void
		def.override().OnReadyToPlay = function(self)
			printLog("ECAdvertisingVideo.OnReadyToPlay", self.m_index)
			local sourceConfig = self:GetCurrentSourceConfig()
			if not sourceConfig then
				Debug.LogError("current is nil.")
				return
			end

			self:PrepareMediaPlayer()
			self:PrepareMediaCanvas()

			if self.m_bindOnMediaOpen then
				self.m_mediaPlayer:unbindOnMediaOpened(self.m_bindOnMediaOpen)
				self.m_bindOnMediaOpen = nil
			end
			if self.m_bindOnEndReached then
				self.m_mediaPlayer:unbindOnEndReached(self.m_bindOnEndReached)
				self.m_bindOnEndReached = nil
			end
			if self.m_bindOnSeekCompleted then
				self.m_mediaPlayer:unbindOnSeekCompleted(self.m_bindOnSeekCompleted)
				self.m_bindOnSeekCompleted = nil
			end

			self.m_bindOnMediaOpen = self.m_mediaPlayer:bindOnMediaOpened(function(mediaName)
				self:_OnMediaOpenedCallback()
			end)

			--准备播放
			if sourceConfig.fileType == 0 then
				local filepath = sourceConfig.fileURL
				if not filepath:startswith("./") then
					filepath = "./" .. filepath
				end
				if not self.m_mediaPlayer:OpenFile(filepath) then
					warn("[0]failed to open videofile:", filepath)

					self.m_mediaPlayer:unbindOnMediaOpened(self.m_bindOnMediaOpen)
					self.m_bindOnMediaOpen = nil

					self:PlayNext()
				end
			elseif sourceConfig.fileType == 1 then
				local filepath = sourceConfig.localPath
				if not filepath:startswith("./") then
					filepath = "./" .. filepath
				end
				if not self.m_mediaPlayer:OpenFile(filepath) then
					warn("[1]failed to open videofile:", filepath)

					self.m_mediaPlayer:unbindOnMediaOpened(self.m_bindOnMediaOpen)
					self.m_bindOnMediaOpen = nil

					self:PlayNext()
				end
			else--在线播放
				if not self.m_mediaPlayer:OpenUrl(sourceConfig.fileURL) then
					warn("[2]failed to open videofile:", sourceConfig.fileURL)

					self.m_mediaPlayer:unbindOnMediaOpened(self.m_bindOnMediaOpen)
					self.m_bindOnMediaOpen = nil

					self:PlayNext()
				end
			end

			--进度
            self.m_timer:AddTimerAndExecuteImmediately("tick_pro", 0.1, function()
                if self.m_mediaStaticProgress and not self.m_mediaStaticProgress:is_nil() then
                    self.m_mediaStaticProgress:SetPercent(self:GetTime()/self:GetDuration())
                end
            end)
		end

		---@param self ComingSoon.ECAdvertisingVideo
		---@return void
		def.method()._OnMediaOpenedCallback = function(self)
			printLog("ECAdvertisingVideo._OnMediaOpenedCallback", self.m_index)

			if self.m_mediaStaticCanvas and not self.m_mediaStaticCanvas:is_nil() then
				self.m_mediaStaticCanvas:SetBrushFromMaterial(self.m_mediaUIMaterial)
				self.m_mediaStaticCanvas:SetVisibility(ESlateVisibility.Visible)
			end

			if self.m_mediaPlayer and not self.m_mediaPlayer:is_nil() then
				if self.m_bindOnMediaOpen and not self.m_bindOnMediaOpen:is_nil() then
					self.m_mediaPlayer:unbindOnMediaOpened(self.m_bindOnMediaOpen)
					self.m_bindOnMediaOpen = nil
				end

				self.m_bindOnEndReached = self.m_mediaPlayer:bindOnEndReached(function(_)
					self:_OnEndReachedCallback()
				end)

				self.m_bindOnSeekCompleted = self.m_mediaPlayer:bindOnSeekCompleted(function(_)
					self:_OnSeekCompletedCallback()
				end)
			end
		end

		---@param self ComingSoon.ECAdvertisingVideo
		---@return void
		def.method()._OnEndReachedCallback = function(self)
			printLog("ECAdvertisingVideo._OnEndReachedCallback", self.m_index)
			if #self.m_sourceList > 1 then
				self:PlayNext()
			end
		end
		---@param self ComingSoon.ECAdvertisingVideo
		---@return void
		def.method()._OnSeekCompletedCallback = function(self)
			printLog("ECAdvertisingVideo._OnSeekCompletedCallback", self.m_index)
		end

		---@param self ComingSoon.ECAdvertisingVideo
		---@return void
		def.method().RemovePlaylistAllSource = function(self)
			printLog("ECAdvertisingVideo.RemovePlaylistAllSource", self.m_index)
			if self.m_mediaPlaylist and not self.m_mediaPlaylist:is_nil() then
				local sourceNum = self.m_mediaPlaylist:Num()
				for i = sourceNum, 1, -1 do
					self.m_mediaPlaylist:RemoveAt(i - 1)
				end
			end
		end

		---@param self ComingSoon.ECAdvertisingVideo
		---@return void
		def.override().OnPreCacheNext = function(self)
			printLog("ECAdvertisingVideo.OnPreCacheNext", self.m_index)
			local sourceList = self.m_sourceList
			local sourceIndex = self.m_index

			if sourceIndex >= #sourceList then
				return
			end

			local nextSource = sourceList[sourceIndex]
			if nextSource.fileType == 0 then --本地图片
			elseif nextSource.fileType == 1 then --在线下载本地
				if ECVideoMan.IsFileExist(nextSource.localPath) then
					return
				else
					if downloading_caches[nextSource.fileURL] then --正在下载中
						return
					end

					ECVideoMan.LoadVideoFile(nextSource.fileURL, nextSource.localPath, function(bSuccess, fileURL, filename, isDownload)
						self:InvokeDownloadCallback(fileURL)
					end)
				end
			else--在线播放的，不需要缓存

			end
		end

		---@param _ ComingSoon.ECAdvertisingVideo
		---@return string
		def.override("=>", "string").GetCacheFolder = function(_)
			local video_folder = GameUtil.GetAssetsPath() .. "/UserData/Video"
			return video_folder
		end

	end
	ECAdvertisingVideo.Commit()


	
	--
	-- 主体
	
	
	local def = ECPanelComingSoon.define

	---@return Guide.ECPanelComingSoon
	def.static("=>",ECPanelComingSoon).Instance = function()
		return l_instance
	end
	

	---@param self Guide.ECPanelComingSoon
	---@return string
	def.override("=>", "string").GetResPath = function(self)
		return RESPATH.Panel_ComingSoon
	end

	---@param self Guide.ECPanelComingSoon
	---@return void
	def.constructor().init = function(self)
		self.m_view_reward = self:RegisterSubView("Widget/Preview/ConditionContent/RewardList", UIRewardView())
	end


	---@param self Guide.ECPanelComingSoon
	---@return void
	def.override().OnCreate = function (self)
		self.m_cleaner = GcCallbacks()
		
		ECGame.EventManager:addHandlerWithCleaner(ECComingSoonEvents.FunctionStageChangeEvent, function (sender, event)
			--if event.newStage == "wait_get_award" then
			--	self.m_finish_timestamp[event.index] = GameUtil.GetServerGMTTime()
			--end
			self:Refresh()
		end, self.m_cleaner)
		
		ECGame.EventManager:addHandlerWithCleaner(HostPropertyEvents.HostLevelUpEvent, function (sender, event)
			--local index = self.m_current_index
			--local state = ECComingSoon.GetAwardState(index)
			--if state == "can_get" and not self.m_finish_timestamp[index] then
			--	self.m_finish_timestamp[index] = GameUtil.GetServerGMTTime()
			--end
			self:Refresh()
		end, self.m_cleaner)
		
		ECGame.EventManager:addHandlerWithCleaner(TaskEvents.SimpleNotifyEvent, function (sender, event)
			--local index = self.m_current_index
			--local state = ECComingSoon.GetAwardState(index)
			--if state == "can_get" and not self.m_finish_timestamp[index] then
			--	self.m_finish_timestamp[index] = GameUtil.GetServerGMTTime()
			--end
			self:Refresh()
		end, self.m_cleaner)
		
		ECGame.EventManager:addHandlerWithCleaner(ECComingSoonEvents.LeaveFunctionEvent, function (sender, event)
			--扫描第一个未完成的功能
			--local iFirstUnfinished = ECComingSoon.Instance():findNextUnfinished(event.index)
			--if iFirstUnfinished < 0 then	--已全部完成
			--	self:DestroyPanel()
			--end
			--local index = self.m_current_index
			--local state = ECComingSoon.GetAwardState(index)
			--if state == "can_get" and not self.m_finish_timestamp[index] then
			--	self.m_finish_timestamp[index] = GameUtil.GetServerGMTTime()
			--end
			self:Refresh()
		end, self.m_cleaner)
		
		ECGame.EventManager:addHandlerWithCleaner(SelfEnterWorldEvent, function (sender, event)
			self:DestroyPanel()
		end, self.m_cleaner)

		if self.m_current_index == 0 then
			self.m_current_index = ECComingSoon.Instance():GetActiveFuncIndex()
		end

		if self.m_current_index == 0 then
			self.m_current_index = 1
		end

		local config = ECComingSoon.GetConfig(self.m_current_index)
		self.m_current_config = config

		if self.m_countdown_flag[self.m_current_index] == "can_get" then
			self.m_countdown_flag[self.m_current_index] = "" --重置一下，让强制进入3秒倒计时
		end

		self:InitIntroduceView()
		self:Refresh()
		self:RefreshIntroduceView()
		--if require "GUI.Main.ECPanelMainMenu".Instance():IsHideOutsideComingSoon() then
		--	self:RequireFind("TodayLimit"):SetChecked(true)
		--	self:RequireFind("TodayLimit"):SetActive(false)
		--else
		--	self:RequireFind("TodayLimit"):SetActive(true)
		--end
	end
	

	---@param self Guide.ECPanelComingSoon
	---@return void
	def.override().OnDestroy = function (self)
		if self.m_cleaner then
			self.m_cleaner:dispose()
			self.m_cleaner = nil
		end

		if self.m_IntroduceViewPic then
			self.m_IntroduceViewPic:OnDestroy()
			self.m_IntroduceViewPic = nil
		end

		if self.m_IntroduceViewVideo then
			self.m_IntroduceViewVideo:OnDestroy()
			self.m_IntroduceViewVideo = nil
		end

		self.m_timer:RemoveAllTimer()

		self.m_current_index = 0
		self.m_current_config = nil
	end
	
	-------------------------------------------
	-- End of public
	

	---@param self Guide.ECPanelComingSoon
	---@return void
	def.method().Refresh = function (self)
		--local activeIndex = ECComingSoon.Instance():GetActiveFuncIndex()
		--local activeStage = ECComingSoon.Instance():GetActiveFuncStage()
		--if activeStage ~= "wait_finish" and activeStage ~= "wait_get_award" then
		--	self:DestroyPanel()
		--	return
		--end

		self:RefreshInfo()
		self:RefreshFinishStatus()

		self:RequireFind("Btn_Right"):SetActive(self:CanShowNext())
		self:RequireFind("Btn_Left"):SetActive(self.m_current_index > 1)
	end

	---是否可以显示下一个解锁功能
	---@param self Guide.ECPanelComingSoon
	---@return boolean
	def.method("=>", "boolean").CanShowNext = function(self)
		local total = ECComingSoon.GetTotalFunc()
		local activeIndex = ECComingSoon.Instance():GetActiveFuncIndex()
		if self.m_current_index <= activeIndex and self.m_current_index < total then
			return true
		end
		return false
	end

	---初始化音视频组件
	---@param self Guide.ECPanelComingSoon
	---@return void
	def.method().InitIntroduceView = function(self)

		self.m_IntroduceViewPic = ECAdvertisingPicture.New(self)
		self.m_IntroduceViewVideo = ECAdvertisingVideo.New(self)

		self.m_IntroduceViewPic:OnCreate()
        self.m_IntroduceViewVideo:OnCreate()
	end
	

	---@param self Guide.ECPanelComingSoon
	---@return void
	def.method().RefreshInfo = function (self)
		if not self.m_current_config then
			return
		end
		ECGUITools.setTextAndColor(self:RequireFind("Widget/AzureTextBlock_4"), self.m_current_config.name)
		--ECGUITools.setTextAndColor(self:RequireFind("Widget/Preview/ConditionContent/Name"), self.m_current_config.name)
		--ECGUITools.setTextAndColor(self:RequireFind("Widget/Preview/ConditionContent/Condition"), self.m_current_config.detail_desc)
		self:RefreshAwardIcon()

		-- 描述中有条件，条件状态变了，更新描述
		if self.m_current_config.notice_type == resource_type.Picture then
			self.m_IntroduceViewPic:UpdateDesc()
		elseif self.m_current_config.notice_type == resource_type.Media then
			self.m_IntroduceViewVideo:UpdateDesc()
		end
	end

	---解锁奖励，通用奖励模板
	---@param self Guide.ECPanelComingSoon
	---@return void
	def.method().RefreshAwardIcon = function(self)
		if not self.m_current_config then
			return
		end
		local task_id = self.m_current_config.award_task
		local taskConfig = ECTaskInterface.GetTaskConfig(task_id)
		if not taskConfig then
			warn("Failed to GetTaskConfig " .. task_id)
			return
		end
		local TaskReward = taskConfig['succ_reward']
		if not TaskReward then
			return
		end

		local config_common = require "PB.config_common"
		local TASK_REWARD = config_common.TASK_REWARD

		-- 固定奖励

		local fixedReward = TaskReward.fixed
		if #fixedReward < 1 then
			print("no reward in task", task_id)
			return
		end
		local common_tid
		for i=1, #fixedReward do
			local rtype = fixedReward[i].type
			local tid = fixedReward[i].tid
			if rtype == TASK_REWARD.COMMON_REWARD then
				common_tid = tid
			end
		end
		if not common_tid then
			warn(string.format("task:%d must config COMMON_REWARD at succ_cond.fixed", task_id))
			return
		end
		local tmpl_config = require"Data.ElementData".getDataByConfigType(CONSTANT_DEFINE.CONFIG_TYPE.CONFIG_COMMON_REWARD, common_tid)
		if not tmpl_config then
			warn(string.format("task:%d COMMON_REWARD:%d not valid.", task_id, common_tid))
			return
		end
		--local goItem = self:RequireFind("Widget/Preview/ConditionContent/Common_Item")
		--if tmpl_config.icon ~= 0 then
		--	ECUIUtility.SetIconByPathId(goItem:FindDirect("Widget/Img_Icon"), tmpl_config.icon)
		--else
		--	warn("icon is empty at COMMON_REWARD:", common_tid)
		--end
		--
		----local pItem = ECItemTools.CreateItem(self.m_current_config.award_item, 0, 0)
		----if pItem then
		----	ECIvtrUIUtility.SetIconEx(goItem, pItem,false,false)
		----	goItem:RequireFind("Widget/Img_Icon"):SetUserData(self.m_current_config.award_item)
		----else
		--	goItem:RequireFind("Widget/Img_Icon"):SetUserData(common_tid)
		----end

		self.m_view_reward:SetRewardByID(common_tid)
		if Log.IsDebugMode() then
			local itemCount = self.m_view_reward.m_rewardListView:GetItemCount()
			if itemCount > 1 then
				Log.DebugError("功能预告奖励不能出现多个")
			end
		end
	end

	local function makeHtmlText(text, dwColor)
		local color = ECColorPaletteMan.ToHtmlTagColor(dwColor)
		--text = text:gsub(" ", "&nbsp;")
		--text = text:gsub("\n", "<br />")
		return string.format("<font color=%s>%s</font>", color, text)
	end

	---@param level number
	---@return string
	def.static("number", "=>", "string").FormatLevelRequire = function (level)
		local palette = ECColorPaletteMan.GetPalette("ComingSoon")
		local fit = ECComingSoon.IsLevelFit(level)
		if fit then
			return makeHtmlText(tostring(level), palette.Valid)
		else
			return makeHtmlText(tostring(level), palette.InValid)
		end
	end
	

	---@param taskId number
	---@return string
	def.static("number", "=>", "string").FormatTaskFinishedRequire = function (taskId)
		local task_id = taskId

		local fit = ECComingSoon.IsTaskFinishedFit(task_id)
		local palette = ECColorPaletteMan.GetPalette("ComingSoon")
		if fit then
			local taskName = ECTaskUtility.FormatTaskBaseName(task_id)
			return makeHtmlText(taskName, palette.Valid)
		else
			local taskName = ECTaskUtility.FormatTaskBaseName(taskId)
			return makeHtmlText(taskName, palette.InValid)
		end
	end

	---@param index number
	---@return string
	def.static("number", "=>", "string").FormatComingSoonRequire = function(index)
		local config = ECComingSoon.GetConfig(index)
		if not config then
			return "<unknow-coming_soon:" .. index .. ">"
		end
		local fit = ECComingSoon.IsComingSoonAtIndexFit(index)
		local palette = ECColorPaletteMan.GetPalette("ComingSoon")
		return makeHtmlText(StringTable.Get(3303):format(config.name), fit and palette.Valid or palette.InValid)
	end

	---@param taskId number
	---@return string
	def.static("number", "=>", "string").FormatTaskHasOrFinishedRequire = function(taskId)
		local fit = ECComingSoon.IsTaskHasOrFinishedFit(taskId)
		local taskName = ECTaskUtility.FormatTaskBaseName(taskId)
		local palette = ECColorPaletteMan.GetPalette("ComingSoon")
		return makeHtmlText(StringTable.Get(3304):format(taskName), fit and palette.Valid or palette.InValid)
	end

	---@param inst_tid number
	---@param mode number
	---@return string
	def.static("number", "number", "=>", "string").FormatInstanceFinishedRequire = function(inst_tid, mode)
		local fit = ECComingSoon.IsInstanceFinishedFit(inst_tid, mode)
		local inst_name
		local instance_config = require "Data.ElementData".getDataByConfigType(_G.CONSTANT_DEFINE.CONFIG_TYPE.CONFIG_INSTANCE, inst_tid)
		if not instance_config then
			inst_name = "Failed to get instance config" .. inst_tid
		else
			inst_name = instance_config.name
		end
		local palette = ECColorPaletteMan.GetPalette("ComingSoon")
		return makeHtmlText(inst_name, fit and palette.Valid or palette.InValid)
	end

	---@param self Guide.ECPanelComingSoon
	---@param index number
	---@return boolean,number
	def.method("number", "=>", "boolean", "number").NeedCoolDown = function(self, index)
		if not self.m_finish_timestamp[index] then
			return false, 0
		end

		local config = ECComingSoon.GetConfig(index)
		if not config.reward_cooltime then
			return false, 0
		end

		local curTime = GameUtil.GetServerGMTTime()
		local endTime = self.m_finish_timestamp[index] + config.reward_cooltime
		if curTime < endTime then
			return true, endTime
		end

		return false, 0
	end
	

	---@param self Guide.ECPanelComingSoon
	---@return void
	def.method().RefreshFinishStatus = function (self)
		if not self.m_current_config then
			return
		end
		local awardState = ECComingSoon.GetAwardState(self.m_current_index)

		local oldState = self.m_countdown_flag[self.m_current_index]
		self.m_countdown_flag[self.m_current_index] = awardState
		--warn("RefreshFinishStatus", oldState, awardState)
		if awardState == "can_get" then--可以领奖
			local b, endTime = false, 0 --self:NeedCoolDown(self.m_current_index)
			if oldState ~= awardState then
				b, endTime = true, self.m_current_config.reward_cooltime+GameUtil.GetServerGMTTime()
			end
			self:RequireFind("Widget/Preview/ConditionContent/Buttons/Received"):SetActive(false)
			self:RequireFind("Widget/Preview/ConditionContent/Buttons/NotAchieved"):SetActive(false)
			if b then --需要倒计时的
				self:RequireFind("Widget/Preview/ConditionContent/Buttons/Btn_Receive"):SetActive(false)
				self:RequireFind("Widget/Preview/ConditionContent/Buttons/Count_Down"):SetActive(true)
				local counter = 0
				local cooltime = self.m_current_config.reward_cooltime
				local tmp_index = self.m_current_index
				self.m_timer:AddTimerAndExecuteImmediately("delay", 1, function()
					if not self:IsValid() then
						self.m_timer:RemoveTimer("delay")
						return
					end
					if GameUtil.GetServerGMTTime() >= endTime then
						self.m_timer:RemoveTimer("delay")
						self:RefreshFinishStatus()
					else
						local text = string.format("%1$d",endTime - GameUtil.GetServerGMTTime())
						self:RequireFind("Widget/Preview/ConditionContent/Buttons/Count_Down/CountNum"):SetText(text)
					end
					counter = counter + 1
				end)
			else
				self:RequireFind("Widget/Preview/ConditionContent/Buttons/Btn_Receive"):SetActive(true)
				self:RequireFind("Widget/Preview/ConditionContent/Buttons/Count_Down"):SetActive(false)
				self:RequireFind("Widget/Preview/ConditionContent/Buttons/Btn_Receive/Content/Img_RedPoint"):SetActive(true)
			end
		elseif awardState == "has_get" then --已经领取
			self:RequireFind("Widget/Preview/ConditionContent/Buttons/Received"):SetActive(true)
			self:RequireFind("Widget/Preview/ConditionContent/Buttons/NotAchieved"):SetActive(false)
			self:RequireFind("Widget/Preview/ConditionContent/Buttons/Btn_Receive"):SetActive(false) 
			self:RequireFind("Widget/Preview/ConditionContent/Buttons/Count_Down"):SetActive(false)

			if oldState ~= "has_get" then
				local index = self.m_current_index
				GameUtil.AddGlobalTimer(0, true, function()
					if self:IsValid() then
						if index == self.m_current_index and ECComingSoon.IsComingSoonAtIndexFit(self.m_current_index) then
							if self:CanShowNext() then
								self:ShowNext()
							end
						end
					end
				end)
			end
		elseif awardState == "wait_get" then --等待领取
			self:RequireFind("Widget/Preview/ConditionContent/Buttons/Received"):SetActive(false)
			self:RequireFind("Widget/Preview/ConditionContent/Buttons/NotAchieved"):SetActive(true)
			self:RequireFind("Widget/Preview/ConditionContent/Buttons/Btn_Receive"):SetActive(false)
			self:RequireFind("Widget/Preview/ConditionContent/Buttons/Count_Down"):SetActive(false)
		--elseif awardState == "none" then
		--	self:RequireFind("Widget/Preview/ConditionContent/Buttons/Received"):SetActive(false)
		--	self:RequireFind("Widget/Preview/ConditionContent/Buttons/NotAchieved"):SetActive(false)
		--	self:RequireFind("Widget/Preview/ConditionContent/Buttons/Btn_Receive"):SetActive(false)
		--	self:RequireFind("Widget/Preview/ConditionContent/Buttons/Count_Down"):SetActive(false)
		end

	end

	---@param self Guide.ECPanelComingSoon
	---@return void
	def.method().RefreshIntroduceView = function(self)
		if not self.m_current_config then
			return
		end

		---@type ComingSoon.ECAdvertisingBase
		local pIntroduceVidw
		if self.m_current_config.notice_type == resource_type.Picture then
			pIntroduceVidw = self.m_IntroduceViewPic
			self.m_IntroduceViewVideo:SetVisible(false)
		elseif self.m_current_config.notice_type == resource_type.Media then
			pIntroduceVidw = self.m_IntroduceViewVideo
			self.m_IntroduceViewPic:SetVisible(false)
		else
			return
		end
		pIntroduceVidw:InitFromConfig(self.m_current_config)
		pIntroduceVidw:SetVisible(true)
		pIntroduceVidw:StartPlay()
	end

	---@param self Guide.ECPanelComingSoon
	---@return void
	def.method().ShowNext = function(self)
		printLog("Show Next")

		if self.m_current_config then
			---@type ComingSoon.ECAdvertisingBase
			local pIntroduceVidw
			if self.m_current_config.notice_type == resource_type.Picture then
				pIntroduceVidw = self.m_IntroduceViewPic
			elseif self.m_current_config.notice_type == resource_type.Media then
				pIntroduceVidw = self.m_IntroduceViewVideo
			end

			if pIntroduceVidw then
				pIntroduceVidw:StopPlay()
			end
		end

		self.m_current_index = self.m_current_index + 1

		local config = ECComingSoon.GetConfig(self.m_current_index)
		self.m_current_config = config

		if not self.m_current_config then
			return
		end

		if self.m_countdown_flag[self.m_current_index] == "can_get" then
			self.m_countdown_flag[self.m_current_index] = "" --重置一下，让强制进入3秒倒计时
		end

		self:Refresh()
		self:RefreshIntroduceView()


	end
	---@param self Guide.ECPanelComingSoon
	---@return void
	def.method().ShowPrev = function(self)
		printLog("Show Prev")

		if self.m_current_config then
			---@type ComingSoon.ECAdvertisingBase
			local pIntroduceVidw
			if self.m_current_config.notice_type == resource_type.Picture then
				pIntroduceVidw = self.m_IntroduceViewPic
			elseif self.m_current_config.notice_type == resource_type.Media then
				pIntroduceVidw = self.m_IntroduceViewVideo
			end

			if pIntroduceVidw then
				pIntroduceVidw:StopPlay()
			end
		end

		self.m_current_index = self.m_current_index - 1

		local config = ECComingSoon.GetConfig(self.m_current_index)
		self.m_current_config = config

		if not self.m_current_config then
			return
		end

		if self.m_countdown_flag[self.m_current_index] == "can_get" then
			self.m_countdown_flag[self.m_current_index] = "" --重置一下，让强制进入3秒倒计时
		end

		self:Refresh()
		self:RefreshIntroduceView()
	end


	---@param self Guide.ECPanelComingSoon
	---@param sender userdata
	---@param check boolean
	---@return void
	def.method("userdata","boolean").onToggleObj = function(self, sender, check)
		local id = sender:GetName()
		if id == "TodayLimit" then
			--require "GUI.Main.ECPanelMainMenu".Instance():SetHideOutsideComingSoon(check)
		else
			if self.m_current_config then
				---@type ComingSoon.ECAdvertisingBase
				local pIntroduceVidw
				if self.m_current_config.notice_type == resource_type.Picture then
					pIntroduceVidw = self.m_IntroduceViewPic
				elseif self.m_current_config.notice_type == resource_type.Media then
					pIntroduceVidw = self.m_IntroduceViewVideo
				end

				if pIntroduceVidw then
					pIntroduceVidw:onToggleObj(sender, check)
				end
			end
		end
	end
	

	---@param self Guide.ECPanelComingSoon
	---@param sender userdata
	---@return void
	def.method("userdata").onClickObj = function (self, sender)
		local id = sender:GetName()
		if id == "Btn_Close" then
			self:DestroyPanel()
		elseif id == "Img_Icon" then
			local tid = sender:GetUserData()
			if tonumber(tid) then
				ItemTipMan.ShowRewardTmpl(tid, sender)
			end
		elseif id == "Btn_Right" then
			self:ShowNext()
		elseif id == "Btn_Left" then
			self:ShowPrev()
		elseif id == "Btn_Receive" then
			--local activeIndex = ECComingSoon.Instance():GetActiveFuncIndex()
			local config = ECComingSoon.GetConfig(self.m_current_index)
			self:getAward(config)
		else
			if self.m_current_config then
				---@type ComingSoon.ECAdvertisingBase
				local pIntroduceVidw
				if self.m_current_config.notice_type == resource_type.Picture then
					pIntroduceVidw = self.m_IntroduceViewPic
				elseif self.m_current_config.notice_type == resource_type.Media then
					pIntroduceVidw = self.m_IntroduceViewVideo
				end

				if pIntroduceVidw then
					pIntroduceVidw:onClickObj(sender)
				end
			end
		end
	end
	

	---@param self Guide.ECPanelComingSoon
	---@param config table
	---@return void
	def.method("table").getAward = function (self, config)
		local taskId = config.award_task
		if taskId == 0 then
			return
		end
		--ECTaskUtility.ManualAcceptTask(taskId)
		ECTaskInterface.AcceptTask(taskId)
		--local rewardList = ECTaskInterface.CalcTaskAwardList(taskId, "succ")
		--for _,v in ipairs(rewardList) do
		--	if v.type == GAME_REWARD_TYPE.REPUTATION or v.type == GAME_REWARD_TYPE.ITEM then
		--		v.showcount = v.value > 1
		--	else
		--		v.showcount = true
		--	end
		--end
		--print_r("rewardList", taskId, rewardList)
		--local ECPanelCommonReward = require "GUI.PlotDish.GUI.ECPanelCommonReward"
		--ECPanelCommonReward.Instance():Popup(rewardList, true, function()
		--	ECTaskInterface.AcceptTask(taskId)
		--end)
	end
	

	---@type GcCallbacks
	def.field(GcCallbacks).m_cleaner = nil

	---视频或者图片轮播
	---@type ComingSoon.ECAdvertisingPicture
	def.field(ECAdvertisingPicture).m_IntroduceViewPic = nil

	---@type ComingSoon.ECAdvertisingVideo
	def.field(ECAdvertisingVideo).m_IntroduceViewVideo = nil

    ---@type number
    def.field("number").m_current_index = 0

	---@type table
	def.field("table").m_current_config = nil

	---@type table
	def.field("table").m_finish_timestamp = function() return {} end

	---@type table
	def.field("table").m_countdown_flag = function() return {} end

	---@type FETimerHelper
	def.field(FETimerHelper).m_timer = function() return FETimerHelper.new() end

	---@type UIRewardView
	def.field(UIRewardView).m_view_reward = nil
	ECPanelComingSoon.Commit()
	
end

if Lplus.fresh() then
	l_instance = ECPanelComingSoon()

	do	--注册 Entry 的创建函数
		--ECGame.EventManager:addHandler(ECComingSoonEvents.FunctionStageChangeEvent, function (sender, event)
		--	if event.newStage == "wait_finish" or event.newStage == "wait_get_award" then
		--        require "GUI.Main.ECPanelMainMenu".Instance():ToggleComingSoon(true)
		--	end
		--end)
	end
end

return ECPanelComingSoon
