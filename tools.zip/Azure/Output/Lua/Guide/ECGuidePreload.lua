local ECGuide = require "Guide.ECGuide"
local TaskInitEvent = require "Event.TaskEvents".TaskInitEvent
local ECGame = require "Main.ECGame"
local ECFunctionUnlock = require "Guide.ECFunctionUnlock"
local ECComingSoon = require "Guide.ECComingSoon"
local S2CManager = require "S2C.S2CManager"
local GcCallbacks = require "Utility.GcCallbacks"
local pb_helper = require "PB.pb_helper"
local LeaveGameLogicEvent = require "Event.LeaveGameLogicEvent"
local FEPanelControls = require "Guide.FEPanelControls"

local help_mask_data = require "S2C.help_mask_data"
S2CManager.AddHandler(help_mask_data, function (sender, p)
	local ECGuideSaveData = require "Guide.ECGuideSaveData"
	ECGuideSaveData.Instance():Init(p.data)
end)

local LoadProtocFinishEvent = require "Event.LoadProtocFinishEvent"

ECGame.EventManager:addHandler(LoadProtocFinishEvent, function (sender, event)
	if event.is_login and not event.is_reconnect then
		FEPanelControls.Init()
		ECFunctionUnlock.Init()
		ECComingSoon.Init()
		ECGuide.Init()
	end
end)

ECGame.EventManager:addHandler(LeaveGameLogicEvent, function (sender, event)
	FEPanelControls.Release()
	--ECFunctionUnlock.Release()
	ECComingSoon.Release()
	ECGuide.Release()
	local ECGuideSaveData = require "Guide.ECGuideSaveData"
	ECGuideSaveData.Instance():Release()
end)

require "Guide.ECPanelComingSoon"
