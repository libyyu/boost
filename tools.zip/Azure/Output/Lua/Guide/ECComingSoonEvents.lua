local Lplus = require "Lplus"

--[[
	进入某功能流程
]]
---@class Guide.EnterFunctionEvent:System.Object
---@field public index number
---@field public Commit fun():Guide.EnterFunctionEvent @notnull
---@field public new fun(index:number):Guide.EnterFunctionEvent
local EnterFunctionEvent = Lplus.Class("Guide.EnterFunctionEvent")
do
	local def = EnterFunctionEvent.define

	---@type number
	def.field("number").index = 0
	

	---@param index number
	---@return Guide.EnterFunctionEvent
	def.static("number", "=>", EnterFunctionEvent).new = function (index)
		local obj = EnterFunctionEvent()
		obj.index = index
		return obj
	end
end
EnterFunctionEvent.Commit()

--[[
	离开某功能流程 (功能完成)
]]
---@class Guide.LeaveFunctionEvent:System.Object
---@field public index number
---@field public Commit fun():Guide.LeaveFunctionEvent @notnull
---@field public new fun(index:number):Guide.LeaveFunctionEvent
local LeaveFunctionEvent = Lplus.Class("Guide.LeaveFunctionEvent")
do
	local def = LeaveFunctionEvent.define

	---@type number
	def.field("number").index = 0
	

	---@param index number
	---@return Guide.LeaveFunctionEvent
	def.static("number", "=>", LeaveFunctionEvent).new = function (index)
		local obj = LeaveFunctionEvent()
		obj.index = index
		return obj
	end
end
LeaveFunctionEvent.Commit()

--[[
	某功能流程状态变化
]]
---@class Guide.FunctionStageChangeEvent:System.Object
---@field public index number
---@field public newStage string
---@field public Commit fun():Guide.FunctionStageChangeEvent @notnull
---@field public new fun(index:number, newStage:string):Guide.FunctionStageChangeEvent
local FunctionStageChangeEvent = Lplus.Class("Guide.FunctionStageChangeEvent")
do
	local def = FunctionStageChangeEvent.define

	---@type number
	def.field("number").index = 0

	---@type string
	def.field("string").newStage = ""
	

	---@param index number
	---@param newStage string
	---@return Guide.FunctionStageChangeEvent
	def.static("number", "string", "=>", FunctionStageChangeEvent).new = function (index, newStage)
		local obj = FunctionStageChangeEvent()
		obj.index = index
		obj.newStage = newStage
		return obj
	end
end
FunctionStageChangeEvent.Commit()

---@class Guide.ComingSoonInitEvent:System.Object
---@field public Commit fun():Guide.ComingSoonInitEvent @notnull
local ComingSoonInitEvent = Lplus.Class("Guide.ComingSoonInitEvent")
do

end
ComingSoonInitEvent.Commit()

return
{
	EnterFunctionEvent = EnterFunctionEvent,
	LeaveFunctionEvent = LeaveFunctionEvent,
	FunctionStageChangeEvent = FunctionStageChangeEvent,
	ComingSoonInitEvent = ComingSoonInitEvent,
}

