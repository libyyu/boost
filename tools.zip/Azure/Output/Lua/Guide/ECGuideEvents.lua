local Lplus = require "Lplus"

---@class Guide.GuideEndEvent:System.Object
---@field public id number
---@field public success boolean
---@field public Commit fun():Guide.GuideEndEvent
---@field public new fun(id:number, success:boolean):Guide.GuideEndEvent
local GuideEndEvent = Lplus.Class("Guide.GuideEndEvent")
do
	local def = GuideEndEvent.define
	

	---@type number
	def.field("number").id = 0

	---@type boolean
	def.field("boolean").success = false
	

	---@param id number
	---@param success boolean
	---@return Guide.GuideEndEvent
	def.static("number", "boolean", "=>", GuideEndEvent).new = function (id, success)
		local obj = GuideEndEvent()
		obj.id = id
		obj.success = success
		return obj
	end
end
GuideEndEvent.Commit()

return
{
	GuideEndEvent = GuideEndEvent,
}
