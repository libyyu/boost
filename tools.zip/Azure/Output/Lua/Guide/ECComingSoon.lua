--[[
	运行即将开启功能
]]

local Lplus = require "Lplus"
local ECGame = require "Main.ECGame"
local GcCallbacks = require "Utility.GcCallbacks"
local Task = require "Utility.Task"
local ECTaskInterface = require "Task.ECTaskInterface"
local ConditionOp = require "Utility.ConditionOp"
local ConditionOpTask = require "Utility.ConditionOpTask"
local ECHostConditionOp = require "Players.ECHostConditionOp"
local ECComingSoonEvents = require "Guide.ECComingSoonEvents"

local l_allConfigs = _G.GetConfigLua "Configs/coming_soon.lua".getAllConfigs()

---@class Guide.ECComingSoon:System.Object
---@field protected m_activeFuncIndex number
---@field protected m_activeFuncStage string
---@field protected m_activeTask Task
---@field public Commit fun():Guide.ECComingSoon @notnull
---@field public Instance fun():Guide.ECComingSoon
---@field public Init fun()
---@field public Release fun()
---@field public GetConfig fun(index:number):table
---@field public GetTotalFunc fun():number
---@field public GetFuncNameByIndex fun(index:number):string
---@field public GetActiveFuncIndex fun(self:Guide.ECComingSoon):number
---@field public GetActiveFuncStage fun(self:Guide.ECComingSoon):string
---@field public IsActiveConditionFit fun(index:number):boolean
---@field public IsLevelFit fun(level:number):boolean
---@field public IsTaskFinishedFit fun(task_id:number):boolean
---@field public IsTaskHasOrFinishedFit fun(task_id:number):boolean
---@field public IsInstanceFinishedFit fun(inst_tid:number, mode:number):boolean
---@field public TransformComingSoonIdToIndex fun(id:string):number
---@field public IsComingSoonAtIndexFit fun(index:number):boolean
---@field public GetAwardState fun(index:number):string
---@field public HasAward fun():boolean,number
---@field public waitForNext fun(self:Guide.ECComingSoon, iPrev:number)
---@field public findNextUnfinished fun(self:Guide.ECComingSoon, iPrev:number):number
---@field public isFunctionAtIndexFinished fun(index:number):boolean
---@field public isConditionReady fun(condition:table):boolean
---@field public waitForFunction fun(self:Guide.ECComingSoon, index:number)
---@field public waitForConditionTask fun(self:Guide.ECComingSoon, condition:table):Task
---@field public IsComingSoonCommonAwardTid fun(tid:number):boolean
---@field public debugLog fun(self:Guide.ECComingSoon, ...:table)
---@field public debugLogStage fun(self:Guide.ECComingSoon)
local ECComingSoon = Lplus.Class("Guide.ECComingSoon")
local l_instance
do
	local def = ECComingSoon.define
	

	---@return Guide.ECComingSoon
	def.static("=>", ECComingSoon).Instance = function ()
		return l_instance
	end
	
	--[[
		需在任务数据准备好后调用
	]]

	---@return void
	def.static().Init = function ()
		ECComingSoon.Release()
		
		l_instance = ECComingSoon()
		local self = l_instance
		
		self:debugLog("Init")
		
		self:waitForNext(0)
		
		ECGame.EventManager:raiseEvent(nil, ECComingSoonEvents.ComingSoonInitEvent())
	end
	

	---@return void
	def.static().Release = function ()
		if l_instance then
			local self = l_instance
			
			self:debugLog("Release")

			if self.m_activeTask then
				self.m_activeTask:cancel()
				self.m_activeTask = nil
			end
			
			l_instance = nil
		end
	end
	

	---@param index number
	---@return table
	def.static("number", "=>", "table").GetConfig = function (index)
		return l_allConfigs[index]
	end

	---@return number
	def.static("=>", "number").GetTotalFunc = function()
		return #l_allConfigs
	end

	---@param index number
	---@return string
	def.static("number", "=>", "string").GetFuncNameByIndex = function(index)
		local cfg = ECComingSoon.GetConfig(index)
		if not cfg then
			return ""
		end
		return cfg.name
	end
	

	---@param self Guide.ECComingSoon
	---@return number
	def.method("=>", "number").GetActiveFuncIndex = function (self)
		return self.m_activeFuncIndex
	end
	

	---@param self Guide.ECComingSoon
	---@return string
	def.method("=>", "string").GetActiveFuncStage = function (self)
		return self.m_activeFuncStage
	end

	---@param index number
	---@return boolean
	def.static("number", "=>", "boolean").IsActiveConditionFit = function(index)
		if index == 0 then
			return true
		end
		local config = l_allConfigs[index]
		assert(config)
		return ECComingSoon.isConditionReady(config.activate_condition)
	end
	

	---@param level number
	---@return boolean
	def.static("number", "=>", "boolean").IsLevelFit = function (level)
		if level == 0 then
			return true
		end
		return ECHostConditionOp.Executor.host_level_between(level, math.huge)
	end
	

	---@param task_id number
	---@return boolean
	def.static("number", "=>", "boolean").IsTaskFinishedFit = function (task_id)
		if task_id == 0 then
			return true
		end
		return ECHostConditionOp.Executor.task_is_finished(task_id)
	end

	---@param task_id number
	---@return boolean
	def.static("number", "=>", "boolean").IsTaskHasOrFinishedFit = function (task_id)
		if task_id == 0 then
			return true
		end
		return ECHostConditionOp.Executor.task_has_or_finished(task_id)
	end

	---@param inst_tid number
	---@param mode number
	---@return boolean
	def.static("number", "number", "=>", "boolean").IsInstanceFinishedFit = function (inst_tid, mode)
		if inst_tid == 0 then
			return true
		end
		return ECHostConditionOp.Executor.instance_finished(inst_tid, mode)
	end

	local _id_index_map
	local _index_id_map
	---@param id string
	---@return number
	def.static("string", "=>", "number").TransformComingSoonIdToIndex = function(id)
		if not _id_index_map or not _index_id_map then
			_id_index_map = {}
			_index_id_map = {}
			for index, config in ipairs(l_allConfigs) do
				_index_id_map[index] = config.id
				_id_index_map[config.id] = index
			end
		end

		return _id_index_map[id] or 0
	end

	---@param index number
	---@return boolean
	def.static("number", "=>", "boolean").IsComingSoonAtIndexFit = function(index)
		if index == 0 then
			return true
		end
		return ECComingSoon.isFunctionAtIndexFinished(index)
	end

	---@param index number
	---@return string
	def.static("number", "=>", "string").GetAwardState = function(index)
		local config = l_allConfigs[index]
		assert(config)

		if ECComingSoon.isFunctionAtIndexFinished(index) then --已经完成，即已经领取
			return "has_get"
		end

		if not ECComingSoon.isConditionReady(config.finish_condition) then
			return "wait_get"
		end

		if config.award_task ~= 0 and not ECHostConditionOp.Executor.task_is_finished(config.award_task) then
			return "can_get" --可以领奖了
		end

		return "wait_get"
	end

	---@return boolean,number
	def.static("=>", "boolean", "number").HasAward = function()
		for i=1, #l_allConfigs do
			if "can_get" == ECComingSoon.GetAwardState(i) then
				return true, i
			end
		end
		return false, 0
	end
	
	--------------------------------------------
	-- End of public
	

	---@type number
	def.field("number").m_activeFuncIndex = -1			--有效序号从1开始

	---@type string
	def.field("string").m_activeFuncStage = "none"		--"none", "wait_activate", "wait_finish", "wait_get_award", "end"

	---@type Task
	def.field(Task).m_activeTask = nil
	
	-- param iPrev: 前一个的序号，如果从头开始，则为0

	---@param self Guide.ECComingSoon
	---@param iPrev number
	---@return void
	def.method("number").waitForNext = function (self, iPrev)
		self:debugLog(("waitForNext from %d"):format(iPrev))
		
		--扫描第一个未完成的功能
		local iFirstUnfinished = self:findNextUnfinished(iPrev)
		if iFirstUnfinished < 0 then	--已全部完成
			return
		end
		
		self:waitForFunction(iFirstUnfinished)
	end
	
	-- param iPrev: 从这个序号的下一个开始向后扫描. return: -1 表示找不到

	---@param self Guide.ECComingSoon
	---@param iPrev number
	---@return number
	def.method("number", "=>", "number").findNextUnfinished = function (self, iPrev)
		for i = iPrev + 1, #l_allConfigs do
			if not ECComingSoon.isFunctionAtIndexFinished(i) then
				return i
			end
		end
		
		return -1
	end
	

	---@param index number
	---@return boolean
	def.static("number", "=>", "boolean").isFunctionAtIndexFinished = function (index)
		local config = l_allConfigs[index]
		assert(config)
		
		if config.award_task and config.award_task ~= 0 then
			return ECHostConditionOp.Executor.task_is_finished(config.award_task)
		end
		
		return ECComingSoon.isConditionReady(config.finish_condition)
	end
	

	---@param condition table
	---@return boolean
	def.static("table", "=>", "boolean").isConditionReady = function (condition)
		local levelfit = true
		if condition.level_above and condition.level_above >0 then
			levelfit = ECComingSoon.IsLevelFit(condition.level_above)
		end
		local taskfit = true
		if condition.task_is_finished and condition.task_is_finished > 0 then
			taskfit = ECComingSoon.IsTaskFinishedFit(condition.task_is_finished)
		end
		if not taskfit and condition.task_is_finished_bak and condition.task_is_finished_bak > 0 then
			taskfit = ECComingSoon.IsTaskFinishedFit(condition.task_is_finished_bak)
		end

		local taskfit2 = true
		if condition.task_has_or_finished and condition.task_has_or_finished >0 then
			taskfit = ECComingSoon.IsTaskHasOrFinishedFit(condition.task_has_or_finished)
		end

		local instancefit = true
		if condition.instance_finished then
			instancefit = ECComingSoon.IsInstanceFinishedFit(condition.instance_finished.tid, condition.instance_finished.value or 1)
		end

		local comingsoonfit = true
		if condition.comingsoon_is_finished then
			if type(condition.comingsoon_is_finished) == "string" then
				local index = ECComingSoon.TransformComingSoonIdToIndex(condition.comingsoon_is_finished)
				if index == 0 then
					comingsoonfit = false
				else
					comingsoonfit = ECComingSoon.IsComingSoonAtIndexFit(index)
				end
			elseif condition.comingsoon_is_finished >0 then
				comingsoonfit = ECComingSoon.IsComingSoonAtIndexFit(condition.comingsoon_is_finished)
			end
		end

		return levelfit and taskfit and taskfit2 and instancefit and comingsoonfit
	end
	

	---@param self Guide.ECComingSoon
	---@param index number
	---@return void
	def.method("number").waitForFunction = function (self, index)
		assert(self.m_activeFuncStage == "none")
		local config = l_allConfigs[index]
		
		local task = Task.createStepsEx(function (intask, step)
			if step == 1 then
				self.m_activeFuncIndex = index
				self:debugLog(("EnterFunctionEvent #%d"):format(index))
				ECGame.EventManager:raiseEvent(self, ECComingSoonEvents.EnterFunctionEvent.new(index))
				
				if not ECComingSoon.isConditionReady(config.activate_condition) then	--未满足激活条件，等待激活
					self.m_activeFuncStage = "wait_activate"
					self:debugLogStage()
					ECGame.EventManager:raiseEvent(self, ECComingSoonEvents.FunctionStageChangeEvent.new(index, self.m_activeFuncStage))
					
					-- self:debugLog("waitFor activate_condition")
					-- coroutine.yield(task:completeSub(self:waitForConditionTask(config.activate_condition)))
					return intask:completeSub(self:waitForConditionTask(config.activate_condition))
				end
				
				return "continue"
			elseif step == 2 then
				if not ECComingSoon.isConditionReady(config.finish_condition) then	--未满足完成条件，等待完成
					self.m_activeFuncStage = "wait_finish"
					self:debugLogStage()
					ECGame.EventManager:raiseEvent(self, ECComingSoonEvents.FunctionStageChangeEvent.new(index, self.m_activeFuncStage))
					
					-- self:debugLog("waitFor finish_condition")
					-- coroutine.yield(task:completeSub(self:waitForConditionTask(config.finish_condition)))
					return intask:completeSub(self:waitForConditionTask(config.finish_condition))
				end
				
				return "continue"
			elseif step == 3 then
				if config.award_task ~= 0 and not ECHostConditionOp.Executor.task_is_finished(config.award_task) then		--未领取奖励，等待领取
					self.m_activeFuncStage = "wait_get_award"
					self:debugLogStage()
					ECGame.EventManager:raiseEvent(self, ECComingSoonEvents.FunctionStageChangeEvent.new(index, self.m_activeFuncStage))
					
					-- self:debugLog("waitFor award_task")
					local conditionOp = ECHostConditionOp.Maker.task_is_finished(config.award_task)
					local task = ConditionOpTask.waitForSingleOp(conditionOp)
					-- coroutine.yield(task:completeSub(task))
					return intask:completeSub(task)
				end
			
				return "continue"
			elseif step == 4 then
				self.m_activeFuncIndex = -1
				self.m_activeFuncStage = "none"

				self:debugLog("LeaveFunctionEvent #"..index)
				ECGame.EventManager:raiseEvent(self, ECComingSoonEvents.LeaveFunctionEvent.new(index))
				
				self:waitForNext(index)
				
				return "end"
			end
		end, function () return "stop" end)
		
		self.m_activeTask = task
		task:start()
	end
	

	---@param self Guide.ECComingSoon
	---@param condition table
	---@return Task
	def.method("table", "=>", Task).waitForConditionTask = function (self, condition)
		local opArr = {}
		if condition.level_above and condition.level_above ~= 0 then
			opArr[#opArr+1] = ECHostConditionOp.Maker.host_level_between(condition.level_above, math.huge)
		end

		if condition.task_is_finished and condition.task_is_finished ~= 0 then
			if condition.task_is_finished_bak and condition.task_is_finished_bak ~= 0 then
				--如果两个任务都填了，只需完成一个
				local taskOp = ECHostConditionOp.Maker.task_is_finished(condition.task_is_finished)
				local taskBakOp = ECHostConditionOp.Maker.task_is_finished(condition.task_is_finished_bak)
				opArr[#opArr+1] = ConditionOp.mergeInLogicOr({taskOp, taskBakOp})
			else
				opArr[#opArr+1] = ECHostConditionOp.Maker.task_is_finished(condition.task_is_finished)
			end
		end

		if condition.task_has_or_finished and condition.task_has_or_finished ~= 0 then
			opArr[#opArr+1] = ECHostConditionOp.Maker.task_has_or_finished(condition.task_has_or_finished)
		end

		if condition.instance_finished then
			local tid, mode = condition.instance_finished.tid, condition.instance_finished.value
			if tid and tid ~= 0 then
				opArr[#opArr+1] = ECHostConditionOp.Maker.instance_finished(tid, mode or 1)
			end
		end

		if condition.comingsoon_is_finished and condition.comingsoon_is_finished > 0 then
			opArr[#opArr+1] = ECHostConditionOp.Maker.comingsoon_is_finished(condition.comingsoon_is_finished)
		end

		return ConditionOpTask.waitForMultipleOp(opArr)
	end

	local common_award_tid_map
	---@param tid number
	---@return boolean
	def.static("number", "=>", "boolean").IsComingSoonCommonAwardTid = function(tid)
		if not common_award_tid_map then
			common_award_tid_map = {}
			local config_common = require "PB.config_common"
			local TASK_REWARD = config_common.TASK_REWARD
			for _, config in ipairs(l_allConfigs) do
				local taskId = config.award_task
				if taskId and taskId ~= 0 then
					local rewardList = ECTaskInterface.CalcTaskAwardList(taskId, "succ")
					local rewards = ECTaskInterface.GetTaskRewards(taskId, "succ")

					local taskConfig = ECTaskInterface.GetTaskConfig(taskId)
					if taskConfig then
						local TaskReward = taskConfig['succ_reward']
						-- 固定奖励

						local fixedReward = TaskReward.fixed
						for i = 1, #fixedReward do
							local reward_type = fixedReward[i].type
							local atid = fixedReward[i].tid
							if reward_type == TASK_REWARD.COMMON_REWARD then
								common_award_tid_map[atid] = true
							end
						end
					end
				end
			end
		end
		return not not common_award_tid_map[tid]
	end


	local debugOption = require "Main.ECDebugOption".Instance()

	---@param self Guide.ECComingSoon
	---@param ... table
	---@return void
	def.method("varlist").debugLog = function (self, ...)
		if debugOption.comingsoonlog then
			warn("ECComingSoon: ", ...)
		end
	end
	

	---@param self Guide.ECComingSoon
	---@return void
	def.method().debugLogStage = function (self)
		self:debugLog(("#%d cur stage: %s"):format(self.m_activeFuncIndex, self.m_activeFuncStage))
	end
end
ECComingSoon.Commit()

return ECComingSoon
