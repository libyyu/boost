--[[
	运行指引
]]

local Lplus = require "Lplus"
local TaskEvents = require "Event.TaskEvents"
local ECGUIMan = require "GUI.ECGUIMan"
local select = select
local Callbacks = require "Utility.Callbacks"
local ECTaskInterface = require "Task.ECTaskInterface"
local GcCallbacks = require "Utility.GcCallbacks"
-- local IvtrUpdateEvent = require "Event.IvtrUpdateEvent"
local ECTaskDef = require "Task.ECTaskDef"
local GuideEndEvent = require "Guide.ECGuideEvents".GuideEndEvent
local Task = require "Utility.Task"
local ECGuideSaveData = require "Guide.ECGuideSaveData"
local ECDebugOption = require "Main.ECDebugOption"
local ECFunctionUnlockEvents = require "Guide.ECFunctionUnlockEvents"
-- local HostSkillEvents = require "Event.HostSkillEvents"
local ECAutoPopupManager = require "GUI.ECAutoPopupManager"
local ConditionOp = require "Utility.ConditionOp"
local ECHostConditionOp = require "Players.ECHostConditionOp"
local Executor = ECHostConditionOp.Executor
local CleanerHelper = require "Utility.CleanerHelper"
local GUIEvents = require "Event.GUIEvents"
local ECPanelBase = require "GUI.ECPanelBase"

--是否启用弹出窗口管理。启用时，多个窗口不会一起弹出
local l_enableGuidePopupManagement = false
local l_AutoPopupManager = l_enableGuidePopupManagement and ECAutoPopupManager.Instance() or ECAutoPopupManager()

--
-- Helpers
--

local function checkNonNil (obj, who, argIndex, errLevel)
	if obj == nil then
		error(([[bad argument #%d to %s in 'ECGuide' (Non-nil expected, got nil)]]):format(argIndex, who, type(obj)), errLevel+1)
	end
end

local function checkSimpleType (value, who, argIndex, needType, errLevel)
	if type(value) ~= needType then
		error(([[bad argument #%d to %s in 'ECGuide' (%s expected, got %s)]]):format(argIndex, who, needType, type(value)), errLevel+1)
	end
end

local l_prevUniqueId = 0
local function createUniqueId ()
	local id = l_prevUniqueId + 1
	l_prevUniqueId = id
	return id
end

-- forward delare
---@type Guide.ECGuide
local ECGuide = Lplus.ForwardDeclare("Guide.ECGuide")
local SimpleConditionOp = ECHostConditionOp.SimpleConditionOp

--[[
	GuideState
	一条指引
]]
---@class Guide.GuideState:System.Object
---@field protected m_guideManager Guide.ECGuide
---@field protected m_config table
---@field protected m_id number
---@field protected m_stepSessionId number
---@field protected m_currentStepIndex number
---@field protected m_stepCleaner GcCallbacks
---@field protected m_enterStepStack table
---@field protected m_enterStepDepth number
---@field protected m_finishStateRecorded boolean
---@field protected m_guidePopupState table
---@field protected m_forceGuidePopupState table
---@field protected m_forceModeConfig table
---@field public Commit fun():Guide.GuideState @notnull
---@field public new fun(guideManager:Guide.ECGuide, config:table):Guide.GuideState
---@field public start fun(self:Guide.GuideState)
---@field public reset fun(self:Guide.GuideState)
---@field public getId fun(self:Guide.GuideState):number
---@field public currentStepIndex fun(self:Guide.GuideState):number
---@field public currentStep fun(self:Guide.GuideState):table
---@field public addStepEndCallback fun(self:Guide.GuideState, callback:function)
---@field public checkRequires fun(self:Guide.GuideState, stepIndex:number, requires:table):boolean
---@field public checkStepRequires fun(self:Guide.GuideState, stepIndex:number):boolean,number
---@field public isWaitsAffected fun(self:Guide.GuideState, stepIndex:number, waits:table, destStepIndex:number):boolean
---@field public checkWaitsBeginState fun(self:Guide.GuideState, stepIndex:number, waits:table, destStepIndex:number):boolean
---@field public checkStepCWaitsBeginState fun(self:Guide.GuideState, stepIndex:number):boolean,number
---@field public checkStepWaitsBeginState fun(self:Guide.GuideState, stepIndex:number):boolean,number
---@field public checkWaitGroup fun(self:Guide.GuideState, stepIndex:number, waitGroup:table):boolean
---@field public alwaysHasWaitableConditionOp fun(self:Guide.GuideState, waits:table):boolean
---@field public selectWaitableOp fun(self:Guide.GuideState, stepIndex:number, waitGroup:table):number,number
---@field public waitStep fun(self:Guide.GuideState, stepIndex:number, callback:function, stepCleaner:GcCallbacks)
---@field public waitForWaits fun(self:Guide.GuideState, stepIndex:number, waits:table, destStepIndex:number, callback:function, stepCleaner:GcCallbacks, bCheckRequires:boolean, stepSessionChecker:function)
---@field public waitForOpGroup fun(self:Guide.GuideState, stepIndex:number, opGroup:table, callback:function, stepCleaner:GcCallbacks, waitCleaner:Callbacks)
---@field public performExecutes fun(self:Guide.GuideState, stepIndex:number, callback:function)
---@field public performExecutesInner fun(self:Guide.GuideState, stepIndex:number, executes:table, lastGroupIndex:number, lastOpIndex:number, callback:function)
---@field public enterStep fun(self:Guide.GuideState, prevStepIndex:number, stepIndex:number)
---@field public enterStepInner fun(self:Guide.GuideState, prevStepIndex:number, stepIndex:number)
---@field public enterStepRaw fun(self:Guide.GuideState, prevStepIndex:number, stepIndex:number)
---@field public leaveStep fun(self:Guide.GuideState)
---@field public recordFinishState fun(self:Guide.GuideState)
---@field public finishCurrentStep fun(self:Guide.GuideState, sourceStepIndex:number)
---@field public abortCurrentStep fun(self:Guide.GuideState, sourceStepIndex:number)
---@field public isActive fun(self:Guide.GuideState):boolean
---@field public preStartGuide fun(self:Guide.GuideState)
---@field public startGuide fun(self:Guide.GuideState)
---@field public endGuide fun(self:Guide.GuideState, bSuccess:boolean, stepBeforeEnd:number)
---@field public forceFinishGuide fun(self:Guide.GuideState)
---@field public forceCancelGuide fun(self:Guide.GuideState)
---@field public stepError fun(self:Guide.GuideState, stepIndex:number, msg:string, errorLevel:number)
---@field public stepLog fun(self:Guide.GuideState, stepIndex:number, msg:string)
---@field public currentStepSessionId fun(self:Guide.GuideState):number
---@field public checkStepSession fun(self:Guide.GuideState, stepSessionId:number):boolean
---@field public makeStepSessionChecker fun(self:Guide.GuideState):function
local GuideState = Lplus.Class("Guide.GuideState")
do
	local def = GuideState.define
	
	---@param guideManager Guide.ECGuide
	---@param config table
	---@return Guide.GuideState
	def.static(ECGuide, "table", "=>", GuideState).new = function (guideManager, config)
		local self = GuideState()
		self.m_guideManager = guideManager
		self.m_config = config
		self.m_id = config.id
		self.m_stepSessionId = createUniqueId()
		return self
	end

	---@param self Guide.GuideState
	---@return void
	def.method().start = function (self)
		local guideManager = self.m_guideManager
		local config = self.m_config

		local step_0 = self.m_config.steps[0]
		assert(step_0)
		
		if #step_0.executes ~= 0 then
			self:stepError(0, [[can not have execute op]], 2)
		end
		
		--应总有一个可等待条件
		if not self:alwaysHasWaitableConditionOp(step_0.waits) then
			self:stepError(0, [[waits must have at least one waitable condition op]], 2)
		end
		
		local step_0 = self.m_config.steps[0]
		
		--给第0步增加前提条件：指引未完成过
		local guideNotFinishedOp = SimpleConditionOp.createState(function ()
				-- ECGuide.DebugLog("GetFinishState", guideManager:GetFinishState(self.m_id))
				return not guideManager:GetFinishState(self.m_id)
			end)
		table.insert(step_0.requires, {guideNotFinishedOp})

		for iGroup = 1, #step_0.waits do
			--给第0步增加完成条件：当前无其他指引激活
			local notHaveActiveGuideOp = SimpleConditionOp.createEvent(
				function ()
					-- ECGuide.DebugLog("notHaveActiveGuideOp", guideManager:GetActiveGuideId())
					return not guideManager:GetActiveGuideId()
				end,
				GuideEndEvent,
				nil)

			table.insert(step_0.waits[iGroup], notHaveActiveGuideOp)
		end

		--给所有步骤增加前提条件：场景未在加载中
		for iStep = 0, #self.m_config.steps do
			for iGroup = 1, #self.m_config.steps[iStep].waits do
				local sceneLoadingFinished = ECHostConditionOp.Maker.scene_loading_finished()
				table.insert(self.m_config.steps[iStep].waits[iGroup], sceneLoadingFinished)
			end
		end
		
		--开始等待第0步
		if not self:checkStepRequires(0) then
			return
		end
		
		self:enterStep(-1, 0)
		
		return
	end
	
	CleanerHelper.defineCleaner(def, "cleaner", "disposeCleaner")
	

	---@param self Guide.GuideState
	---@return void
	def.method().reset = function (self)
		self.m_forceModeConfig = nil
		self:disposeCleaner()
	end
	

	---@param self Guide.GuideState
	---@return number
	def.method("=>", "number").getId = function (self)
		return self.m_id
	end
	

	---@param self Guide.GuideState
	---@return number
	def.method("=>", "number").currentStepIndex = function (self)
		return self.m_currentStepIndex
	end
	

	---@param self Guide.GuideState
	---@return table
	def.method("=>", "table").currentStep = function (self)
		return self.m_config.steps[self.m_currentStepIndex]
	end
	

	---@param self Guide.GuideState
	---@param callback function
	---@return void
	def.method("function").addStepEndCallback = function (self, callback)
		self.m_stepCleaner:add(callback)
	end
	
	--
	-- helpers
	--
	

	---@param self Guide.GuideState
	---@param stepIndex number
	---@param requires table
	---@return boolean
	def.method("number", "table", "=>", "boolean").checkRequires = function (self, stepIndex, requires)
		for iGroup = 1, #requires do
			local group = requires[iGroup]
			if #group > 0 then
				local bSuccess = false
				for i = 1, #group do
					local condOp = group[i]
					if not condOp:hasState() then
						self:stepError(stepIndex, ([[requires[%d][%d] has no state]]):format(iGroup, i), 2)
					end
					if condOp:getState() then
						bSuccess = true
						break
					end
				end
				if not bSuccess then
					self:stepLog(stepIndex, ("checkStepRequires return false (%d)"):format(iGroup))
					return false
				end
			end
		end
		
		return true
	end
	
	-- requires: config.steps[n].requires. 所有条件都必须可检查
	-- return 2: sourceStepIndex

	---@param self Guide.GuideState
	---@param stepIndex number
	---@return boolean,number
	def.method("number", "=>", "boolean", "number").checkStepRequires = function (self, stepIndex)
		-- ECGuide.DebugLog("checkStepRequires", self.m_id, stepIndex)
		
		--持续性前提
		for index = 0, stepIndex do
			local c_requires = self.m_config.steps[index].c_requires
			if #c_requires > 0 and not self:checkRequires(index, c_requires) then
				return false, index
			end
		end
		
		--普通前提
		do
			local requires = self.m_config.steps[stepIndex].requires
			
			if not self:checkRequires(stepIndex, requires) then
				return false, stepIndex
			end
		end
		
		return true, -1
	end
	

	---@param self Guide.GuideState
	---@param stepIndex number
	---@param waits table
	---@param destStepIndex number
	---@return boolean
	def.method("number", "table", "number", "=>", "boolean").isWaitsAffected = function (self, stepIndex, waits, destStepIndex)
		local affect_step_num = waits.affect_step_num or 1
		return affect_step_num < 0 or stepIndex - affect_step_num < destStepIndex
	end
	
	-- 是否一开始就满足一组等待条件。事件型的条件算 false
	-- param destStepIndex: 所影响的 step，如是 waits 时 destStepIndex 与 stepIndex 一致，c_waits 可以不一致

	---@param self Guide.GuideState
	---@param stepIndex number
	---@param waits table
	---@param destStepIndex number
	---@return boolean
	def.method("number", "table", "number", "=>", "boolean").checkWaitsBeginState = function (self, stepIndex, waits, destStepIndex)
		for iGroup = 1, #waits do
			local group = waits[iGroup]
			
			if self:isWaitsAffected(stepIndex, waits, destStepIndex) then
				local bFailed = false
				for i = 1, #group do
					local condOp = group[i]
					if not condOp:hasState() or not condOp:getState() then
						self:stepLog(stepIndex, ("check wait failed (%d, %d)"):format(iGroup, i))
						bFailed = true
						break
					end
				end
				if not bFailed then		--只要有一组成功
					self:stepLog(stepIndex, ("checkStepWaitsBeginState return true (%d)"):format(iGroup))
					return true
				end
			end
		end
		
		return false
	end
	
	-- 是否一开始就满足步骤持续性等待条件。waits: config.stpes[?].c_waits. 事件型的条件算 false
	-- return 2: 满足了哪个步骤上的等待条件

	---@param self Guide.GuideState
	---@param stepIndex number
	---@return boolean,number
	def.method("number", "=>", "boolean", "number").checkStepCWaitsBeginState = function (self, stepIndex)
		--以从后向前顺序检查当前及其后步骤的持续性条件
		if stepIndex > 0 then
			for index = #self.m_config.steps, stepIndex, -1 do
				local c_waits = self.m_config.steps[index].c_waits
				if #c_waits > 0 and self:checkWaitsBeginState(index, c_waits, stepIndex) then
					return true, index
				end
			end
		end
		return false, -1
	end
	
	-- 是否一开始就满足步骤等待条件。waits: config.steps[n].waits, config.stpes[?].c_waits. 事件型的条件算 false
	-- return 2: 满足了哪个步骤上的等待条件

	---@param self Guide.GuideState
	---@param stepIndex number
	---@return boolean,number
	def.method("number", "=>", "boolean", "number").checkStepWaitsBeginState = function (self, stepIndex)
		--1 先检查持续性条件
		local bCFit, cfitStepIndex = self:checkStepCWaitsBeginState(stepIndex)
		if bCFit then
			return bCFit, cfitStepIndex
		end
		
		--2 然后是当前步骤的普通条件
		do
			local waits = self.m_config.steps[stepIndex].waits
			
			if #waits > 0 and self:checkWaitsBeginState(stepIndex, waits, stepIndex) then
				return true, stepIndex
			end
		end
		
		return false, -1
	end
	
	-- waitGroup: config.steps[n].waits[i]. 事件型的条件算 true

	---@param self Guide.GuideState
	---@param stepIndex number
	---@param waitGroup table
	---@return boolean
	def.method("number", "table", "=>", "boolean").checkWaitGroup = function (self, stepIndex, waitGroup)
		self:stepLog(stepIndex, "checkWaitGroup")
		for i = 1, #waitGroup do
			local condOp = waitGroup[i]
			if condOp:hasState() and not condOp:getState() then
				self:stepLog(stepIndex, ("checkWaitGroup failed (?, %d)"):format(i))
				return false
			end
		end
		
		self:stepLog(stepIndex, ("checkWaitGroup return true (?)"):format())
		return true
	end
	
	
	
	-- waits: config.steps[n].waits 总有一个可等待条件，即包含一个事件，或全为 状态+事件

	---@param self Guide.GuideState
	---@param waits table
	---@return boolean
	def.method("table", "=>", "boolean").alwaysHasWaitableConditionOp = function (self, waits)
		--包含一个事件
		for iGroup = 1, #waits do
			local group = waits[iGroup]
			for i = 1, #group do
				local condOp = group[i]
				if not condOp:hasState() then
					return true
				end
			end
		end
		
		--全为 状态+事件
		for iGroup = 1, #waits do
			local group = waits[iGroup]
			for i = 1, #group do
				local condOp = group[i]
				if not condOp:canWait() then
					return false
				end
			end
		end
		
		return true
	end
	
	--[[
		优先等待那些只能等待的条件
		return 1: 只能等待的条件, index or -1
		return 2: 可等待而未满足的条件, index or -1
	]]

	---@param self Guide.GuideState
	---@param stepIndex number
	---@param waitGroup table
	---@return number,number
	def.method("number", "table", "=>", "number", "number").selectWaitableOp = function (self, stepIndex, waitGroup)
		--找到可等待的条件
		--优先等待那些只能等待的条件，但只能有一个
		local iWaitOnlyCondOp
		for i = 1, #waitGroup do
			local op = waitGroup[i]
			if op:canWait() and not op:hasState() then
				if iWaitOnlyCondOp then	--不只一个
					self:stepError(stepIndex, ([[waits #%d has multiple wait only condition op (#%d, #%d)]]):format(#waitGroup, iWaitOnlyCondOp, i), 2)
				end
				
				iWaitOnlyCondOp = i
			end
		end
		
		if iWaitOnlyCondOp then
			return iWaitOnlyCondOp, -1
		end
		
		--没有只能等待的条件，找第一个可等待而未满足条件
		for i = 1, #waitGroup do
			local op = waitGroup[i]
			if op:canWait() and (not op:hasState() or not op:getState()) then
				return -1, i
			end
		end
		
		return -1, -1
	end
	
	--[[
		等待一个步骤
		param callback:
			function (bValid, bSuccess, sourceStepIndex)
		param stepCleaner: 加入清理所需操作，会在step结束时调用
	]]

	---@param self Guide.GuideState
	---@param stepIndex number
	---@param callback function
	---@param stepCleaner GcCallbacks
	---@return void
	def.method("number", "function", GcCallbacks).waitStep = function (self, stepIndex, callback, stepCleaner)
		self:stepLog(stepIndex, "start waitStep")
		
		local step = self.m_config.steps[stepIndex]
		local bCheckRequires = stepIndex > 0
		
		if bCheckRequires then
			local bOK, sourceStepIndex = self:checkStepRequires(stepIndex)	--前提条件
			if not bOK then
				self:stepLog(stepIndex, "waitStep checkStepRequires at beginning failed")
				callback(true, false, sourceStepIndex)
				return
			end
		end
		
		if #step.waits == 0 and #step.c_waits == 0 then		--空条件
			self:stepLog(stepIndex, ("waitStep %d: waits is empty"):format(stepIndex))
			callback(true, true, stepIndex)
			return
		end
		
		local bFitWaitAtBegin, fitWaitStepIndex = self:checkStepWaitsBeginState(stepIndex)
		if bFitWaitAtBegin then	-- 一开始就满足条件
			self:stepLog(stepIndex, ("waitStep of step %d is ready at beginning"):format(fitWaitStepIndex))
			callback(true, true, fitWaitStepIndex)
			return
		end
		
		local stepSessionChecker = self:makeStepSessionChecker()

		--普通 waits
		if #step.waits > 0 then
			self:waitForWaits(stepIndex, step.waits, stepIndex, callback, stepCleaner, bCheckRequires, stepSessionChecker)
		end
		
		--持续性 waits
		if stepIndex > 0 then
			for index = stepIndex, #self.m_config.steps do
				local c_waits = self.m_config.steps[index].c_waits
				if #c_waits > 0 then
					self:waitForWaits(index, c_waits, stepIndex, callback, stepCleaner, bCheckRequires, stepSessionChecker)
				end
			end
		end
		
		--定时 checkStepRequires
		if bCheckRequires then
			local checkTimer
			local checkRequiresTimeStep = 0.1
			checkTimer = GameUtil.AddGlobalTimer(checkRequiresTimeStep, false, function ()
				if bCheckRequires then
					local bOK, sourceStepIndex = self:checkStepRequires(stepIndex)
					if not bOK then
						self:stepLog(stepIndex, "waitStep checkStepRequires in timer failed")
						callback(stepSessionChecker(), false, sourceStepIndex)
					end
				end
			end)
			stepCleaner:add(function () GameUtil.RemoveGlobalTimer(checkTimer) end)
		end
	end
	

	---@param self Guide.GuideState
	---@param stepIndex number
	---@param waits table
	---@param destStepIndex number
	---@param callback function
	---@param stepCleaner GcCallbacks
	---@param bCheckRequires boolean
	---@param stepSessionChecker function
	---@return void
	def.method("number", "table", "number", "function", GcCallbacks, "boolean", "function").waitForWaits = function (self, stepIndex, waits, destStepIndex, callback, stepCleaner, bCheckRequires, stepSessionChecker)
		for iGroup = 1, #waits do
			local group = waits[iGroup]
			if #group == 0 then	--每一组至少有一个条件
				self:stepError(stepIndex, ([[waits #%d is empty]]):format(iGroup), 2)
			end
			
			if self:isWaitsAffected(stepIndex, group, destStepIndex) then
				local waitCleaner = Callbacks()
				self:waitForOpGroup(stepIndex, group, function ()
					if bCheckRequires then
						local bOK, sourceStepIndex = self:checkStepRequires(stepIndex)
						if not bOK then	--完成前再次检查前提
							callback(stepSessionChecker(), false, sourceStepIndex)
							return
						end
					end
					
					callback(stepSessionChecker(), true, stepIndex)
				end, stepCleaner, waitCleaner)
				stepCleaner:add(function () waitCleaner:invoke() end)
			end
		end
	end

	-- stepCleaner: step 结束时调用；waitCleaner: waitForOpGroup 内部使用，step 结束时调用 
	---@param self Guide.GuideState
	---@param stepIndex number
	---@param opGroup table
	---@param callback function
	---@param stepCleaner GcCallbacks
	---@param waitCleaner Callbacks
	---@return void
	def.method("number", "table", "function", GcCallbacks, Callbacks).waitForOpGroup = function (self, stepIndex, opGroup, callback, stepCleaner, waitCleaner)
		local step = self.m_config.steps[stepIndex]
		
		-- 找到可等待的条件
		local iWaitOnlyCondOp, iWaitCondOp = self:selectWaitableOp(stepIndex, opGroup)
		if iWaitOnlyCondOp >= 0 then	--有事件型条件，则等待之
			local waitOp = opGroup[iWaitOnlyCondOp]
			waitOp:wait(function ()
				if self:checkWaitGroup(stepIndex, opGroup) then
					callback()
				end
			end)
			stepCleaner:add(function () waitOp:stopWaiting() end)
		elseif iWaitCondOp >= 0 then	--有未满足条件的可等待条件
			local waitOp = opGroup[iWaitCondOp]
			waitOp:wait(function ()
				if self:checkWaitGroup(stepIndex, opGroup) then
					callback()
				else	--再等一次
					waitCleaner:invoke()	--先清理之前的wait
					waitCleaner:clear()
					self:waitForOpGroup(stepIndex, opGroup, callback, stepCleaner, waitCleaner)
				end
			end)
			waitCleaner:add(function () waitOp:stopWaiting() end)
		else	--循环等待
			local waitTimer
			local waitTimeStep = 0.1
			local finish = false
			waitTimer = GameUtil.AddGlobalTimer(waitTimeStep, false, function ()
				if finish then  --finish后再过0.1秒触发callback 等界面渲染
					callback()
				else
					if self:checkWaitGroup(stepIndex, opGroup) then
						finish = true
					end
				end
			end)
			stepCleaner:add(function () GameUtil.RemoveGlobalTimer(waitTimer) end)
		end
	end
	
	--[[
		param callback: 操作结束后执行此回调
			function callback (bValid, bSuccess)
	]]

	---@param self Guide.GuideState
	---@param stepIndex number
	---@param callback function
	---@return void
	def.method("number", "function").performExecutes = function (self, stepIndex, callback)
		self:stepLog(stepIndex, "performExecutes")
		
		local executes = self.m_config.steps[stepIndex].executes
		
		self:performExecutesInner(stepIndex, executes, 1, 0, callback)
	end
	
	-- lastGroupIndex, lastOpIndex: 从这里继续执行

	---@param self Guide.GuideState
	---@param stepIndex number
	---@param executes table
	---@param lastGroupIndex number
	---@param lastOpIndex number
	---@param callback function
	---@return void
	def.method("number", "table", "number", "number", "function").performExecutesInner = function (self, stepIndex, executes, lastGroupIndex, lastOpIndex, callback)
		if #executes == 0 then
			callback(true, true)
			return
		end
		
		assert(stepIndex > 0)
		
		local stepSessionChecker = self:makeStepSessionChecker()
		
		for iGroup = lastGroupIndex, #executes do
			local group = executes[iGroup]
			local iStart = (iGroup == lastGroupIndex) and lastOpIndex+1 or 1
			for i = iStart, #group do
				if not stepSessionChecker() then
					callback(false, false)
					return
				end

				local op = group[i]
				local opRet = op(self)
				if type(opRet) == "boolean" then
					if not opRet then
						callback(true, false)
						return
					end
				elseif Lplus.is(opRet, Task) then	--Task
					
					opRet:continueWith(function (task)
						if not stepSessionChecker() then
							callback(false, false)
							return
						end
						
						if task:isCompleted() then
							self:performExecutesInner(stepIndex, executes, iGroup, i, callback)
						else
							callback(true, false)
						end
					end)
					self:addStepEndCallback(function () opRet:cancel() end)
					opRet:start()
					return
				else
					error(("invalid execute op return value, %d, %d, %d"):format(self.m_id, stepIndex, i))
				end
			end
		end
		
		callback(true, true)
	end
	
	-- 进入步骤，当前应当没有步骤

	---@param self Guide.GuideState
	---@param prevStepIndex number
	---@param stepIndex number
	---@return void
	def.method("number", "number").enterStep = function (self, prevStepIndex, stepIndex)
		self:stepLog(stepIndex, "enterStep from step: "..prevStepIndex)
		if stepIndex > 0 then
			ECGuide.triggerTlog(self.m_id, "step", stepIndex)
		end
		
		assert(self.m_currentStepIndex == -1)
		
		self.m_stepSessionId = createUniqueId()
		
		local step = self.m_config.steps[stepIndex]
		local prevStep = self.m_config.steps[prevStepIndex]
		
		if prevStep and step.forceModeEnterStep ~= prevStep.forceModeEnterStep then	--forceMode 有变化
			self.m_forceGuidePopupState:End()
			
			if step.forceModeEnterStep then
				local forceModeConfig = self.m_config.steps[step.forceModeEnterStep].forceMode
				self.m_forceModeConfig = forceModeConfig
				
				local stepSessionChecker = self:makeStepSessionChecker()
				self.m_forceGuidePopupState:RequestBegin(function ()
					if not stepSessionChecker() then
						self.m_forceGuidePopupState:End()
						return
					end
					
					if forceModeConfig.closeExcept then
						ECGuide.ExecuteEnv.ui_close_all_except(forceModeConfig.closeExcept)
					end
					self:enterStepInner(prevStepIndex, stepIndex)
				end)
				return
			else
				self.m_forceModeConfig = nil
			end
		end
		
		self:enterStepInner(prevStepIndex, stepIndex)
	end
	
	-- 进入步骤，当前应当没有步骤

	---@param self Guide.GuideState
	---@param prevStepIndex number
	---@param stepIndex number
	---@return void
	def.method("number", "number").enterStepInner = function (self, prevStepIndex, stepIndex)
		self:stepLog(stepIndex, "enterStepInner from step: "..prevStepIndex)
		assert(self.m_currentStepIndex == -1)
		
		self.m_enterStepDepth = self.m_enterStepDepth + 1
		table.insert(self.m_enterStepStack, stepIndex)
		
		if self.m_enterStepDepth > 64 then		--太深，应该是无限递归
			local strBuilder = {}
			strBuilder[#strBuilder+1] = ("guide(%d) infinite recursion detected, the last guide steps: "):format(self.m_id)
			
			for i = #self.m_enterStepStack - 10, #self.m_enterStepStack do
				local iStep = self.m_enterStepStack[i]
				strBuilder[#strBuilder+1] = self.m_config.steps[iStep].name
				strBuilder[#strBuilder+1] = "("..iStep..")"
				strBuilder[#strBuilder+1] = ", "
			end

			warn(table.concat(strBuilder))
			self.m_guideManager:RecordFinishState(self.m_id)
			self:forceCancelGuide()
			return
		end
		
		self:enterStepRaw(prevStepIndex, stepIndex)
		
		table.remove(self.m_enterStepStack)
		self.m_enterStepDepth = self.m_enterStepDepth - 1
	end
	

	---@param self Guide.GuideState
	---@param prevStepIndex number
	---@param stepIndex number
	---@return void
	def.method("number", "number").enterStepRaw = function (self, prevStepIndex, stepIndex)
		local stepCleaner = GcCallbacks()

		if self.m_stepCleaner then
			self.m_stepCleaner:dispose()
			self.m_stepCleaner = nil
		end

		self.m_stepCleaner = stepCleaner
		stepCleaner:setNeedDispose(("stepCleaner of guide(%d)[%d]"):format(self.m_id, stepIndex))
		
		self.m_currentStepIndex = stepIndex
		
		-- check requires
		do
			local bOK, sourceStepIndex = self:checkStepRequires(stepIndex)
			if not bOK then	--前提条件
				self:stepLog(stepIndex, "checkStepRequires failed when enter")
				self:abortCurrentStep(sourceStepIndex)
				return
			end
		end
		
		local function onWaitOK (bSuccess, sourceStepIndex)
			self:stepLog(stepIndex, "step callback: "..tostring(bSuccess))
			
			if bSuccess then
				self:finishCurrentStep(sourceStepIndex)
			else
				self:abortCurrentStep(sourceStepIndex)
			end
		end
		
		local bFit, sourceStepIndex = self:checkStepCWaitsBeginState(stepIndex)
		if bFit then
			--直接满足条件，跳过当前步骤
			self:stepLog(stepIndex, "checkStepCWaitsBeginState success: " .. sourceStepIndex)
			onWaitOK(true, sourceStepIndex)
		else
			-- perform executes
			self:performExecutes(stepIndex, function (bValid, bSuccess)
				if not bValid then
					self:stepLog(stepIndex, "performExecutes aborted")
					return
				end
				
				self:stepLog(stepIndex, "performExecutes: " .. tostring(bSuccess))
				if not bSuccess then
					self:abortCurrentStep(stepIndex)
					return
				end

				-- wait
				self:waitStep(stepIndex, function (bValid, bSuccess, sourceStepIndex)
					if not bValid then
						self:stepLog(stepIndex, "waitStep aborted")
						return
					end
					
					onWaitOK(bSuccess, sourceStepIndex)
				end, stepCleaner)
			end)
		end
	end
	

	---@param self Guide.GuideState
	---@return void
	def.method().leaveStep = function (self)
		if self.m_stepCleaner then
			self.m_stepCleaner:dispose()
			self.m_stepCleaner = nil
		end
		self.m_currentStepIndex = -1
		self.m_stepSessionId = createUniqueId()
	end
	

	---@param self Guide.GuideState
	---@return void
	def.method().recordFinishState = function (self)
		if not self.m_finishStateRecorded then	--自动记录
			self.m_finishStateRecorded = true
			self.m_guideManager:RecordFinishState(self.m_id)
		end
	end
	
	-- 让当前步骤成功

	---@param self Guide.GuideState
	---@param sourceStepIndex number
	---@return void
	def.method("number").finishCurrentStep = function (self, sourceStepIndex)
		local currentStep = self.m_currentStepIndex
		self:stepLog(currentStep, "finishCurrentStep")
		assert(currentStep >= 0)
		
		self:leaveStep()
		
		local nextStepIndex = sourceStepIndex + 1
		
		--处理 bFinishGuide, bExitGuide
		for index = currentStep + 1, nextStepIndex do
			local step = self.m_config.steps[index]
			if step then
				if step.bFinishGuide then
					self:recordFinishState()
				end
				
				if self.m_config.steps[index].bExitGuide then
					self:endGuide(true, currentStep)
					return
				end
			end
		end
		
		--进入下一步
		if nextStepIndex > #self.m_config.steps then	--全部完成
			self:recordFinishState()
			self:endGuide(true, currentStep)
		else
			if currentStep == 0 then
				assert(not self.m_guideManager:GetActiveGuideId())

				self:preStartGuide()	--调用后防止其他指引激活
				
				local stepSessionChecker = self:makeStepSessionChecker()
				self.m_guidePopupState:RequestBegin(function ()
					if not stepSessionChecker() then
						self.m_guidePopupState:End()
						return
					end
					
					assert(self:isActive())
					
					self:startGuide()
					self:enterStep(currentStep, nextStepIndex)
				end)
			else
				self:enterStep(currentStep, nextStepIndex)
			end
		end
	end
	
	-- 让当前步骤失败

	---@param self Guide.GuideState
	---@param sourceStepIndex number
	---@return void
	def.method("number").abortCurrentStep = function (self, sourceStepIndex)
		local currentStepIndex = self.m_currentStepIndex
		if currentStepIndex < 0 then	--可能已经被中止
			return
		end
		self:stepLog(currentStepIndex, "abortCurrentStep")
		
		self:leaveStep()
		
		local nextStepIndex = sourceStepIndex
		while true do
			local thisStep = self.m_config.steps[nextStepIndex]
			if thisStep then
				if thisStep.onFail == "exit" then
					nextStepIndex = 0	--退出
				elseif thisStep.onFail == "abort" then
					nextStepIndex = -1	--完全放弃
					self:recordFinishState()
				elseif thisStep.onFail == "quit" then  --不存盘
					nextStepIndex = -1	--完全放弃
				else
					nextStepIndex = nextStepIndex - 1
				end
			else
				nextStepIndex = -1	--完全放弃
			end
			
			self:stepLog(nextStepIndex, "try step")
			if nextStepIndex < 0 then		--指引完全失败
				self:endGuide(false, currentStepIndex)
				return
			end
			
			if nextStepIndex == 0 then
				self:endGuide(false, currentStepIndex)
				self:enterStep(-1, 0)	--重新开始等待
				return
			end
			
			local nextStep = self.m_config.steps[nextStepIndex]
			if #nextStep.waits > 0 then
				self:enterStep(currentStepIndex, nextStepIndex)
				return
			else
				-- 无 WAIT 则继续向上找
			end
		end
	end
	

	---@param self Guide.GuideState
	---@return boolean
	def.method("=>", "boolean").isActive = function (self)
		local hasActiveGuideId, activeGuideId = self.m_guideManager:GetActiveGuideId()
		return hasActiveGuideId and self.m_id == activeGuideId
	end
	

	---@param self Guide.GuideState
	---@return void
	def.method().preStartGuide = function (self)
		self:reset()
		self.m_guideManager:OnPreGuideStart(self.m_id)
	end
	

	---@param self Guide.GuideState
	---@return void
	def.method().startGuide = function (self)
		self.m_guideManager:OnGuideStart(self.m_id)
		
		local function onCreatePanel (sender, event)
			if self.m_forceModeConfig then
				local closeExcept = self.m_forceModeConfig.closeExcept
				ECGuide.ExecuteEnv.ui_close_except(event.panel, closeExcept)
			end
		end
		
		local ECGame = require "Main.ECGame"
		ECGame.EventManager:addHandlerWithCleaner(GUIEvents.PreCreatePanelEvent, onCreatePanel, self:cleaner())
		ECGame.EventManager:addHandlerWithCleaner(GUIEvents.CreatePanelEvent, onCreatePanel, self:cleaner())
	end
	

	---@param self Guide.GuideState
	---@param bSuccess boolean
	---@param stepBeforeEnd number
	---@return void
	def.method("boolean", "number").endGuide = function (self, bSuccess, stepBeforeEnd)
		self:reset()
		
		ECGuide.DebugLog(("guide(%d) endGuide, success: %s"):format(self.m_id, bSuccess and "true" or "false"))
		ECGuide.triggerTlog(self.m_id, bSuccess and "finish" or (self.m_guideManager:GetFinishState(self.m_id) and "abort" or "fail"), stepBeforeEnd)
		
		self.m_currentStepIndex = -1
		self.m_stepSessionId = createUniqueId()
		
		if self:isActive() then
			self.m_guideManager:OnGuideEnd(self.m_id, bSuccess)
			
			GameUtil.AddGlobalTimer(0, true, function ()
				self.m_guidePopupState:End()
				self.m_forceGuidePopupState:End()
			end)
		end
	end
	

	---@param self Guide.GuideState
	---@return void
	def.method().forceFinishGuide = function (self)
		ECGuide.DebugLog(("guide(%d) forceFinishGuide"):format(self.m_id))
		
		self.m_guideManager:RecordFinishState(self.m_id)

		local stepBeforeEnd = self.m_currentStepIndex
		self:leaveStep()
		self:endGuide(true, stepBeforeEnd)
	end
	

	---@param self Guide.GuideState
	---@return void
	def.method().forceCancelGuide = function (self)
		ECGuide.DebugLog(("guide(%d) forceCancelGuide"):format(self.m_id))
		
		local stepBeforeEnd = self.m_currentStepIndex
		self:leaveStep()
		self:endGuide(false, stepBeforeEnd)
	end
	

	---@param self Guide.GuideState
	---@param stepIndex number
	---@param msg string
	---@param errorLevel number
	---@return void
	def.method("number", "string", "number").stepError = function (self, stepIndex, msg, errorLevel)
		local step = self.m_config.steps[stepIndex]
		error(([[guide(%d).step["%s"(%d)] has error: %s]]):format(self.m_id, step and step.name or "???", stepIndex, msg), errorLevel+1)
	end
	

	---@param self Guide.GuideState
	---@param stepIndex number
	---@param msg string
	---@return void
	def.method("number", "string").stepLog = function (self, stepIndex, msg)
		local step = self.m_config.steps[stepIndex]
		ECGuide.DebugLog(([[guide(%d).step["%s"(%d)]: %s]]):format(self.m_id, step and step.name or "???", stepIndex, msg))
	end
	

	---@param self Guide.GuideState
	---@return number
	def.method("=>", "number").currentStepSessionId = function (self)
		return self.m_stepSessionId
	end
	
	--[[
		检测当前 step 是否有变化
	]]

	---@param self Guide.GuideState
	---@param stepSessionId number
	---@return boolean
	def.method("number", "=>", "boolean").checkStepSession = function (self, stepSessionId)
		return stepSessionId == self.m_stepSessionId and self.m_guideManager:checkSession()
	end
	

	---@param self Guide.GuideState
	---@return function
	def.method("=>", "function").makeStepSessionChecker = function (self)
		local stepSid = self:currentStepSessionId()
		return function ()
			-- warn("step session stepSid", stepSid, self:currentStepSessionId(),
			-- 	"manager", self.m_guideManager, self.m_guideManager.m_bQuiting,
			-- 	"result: ", self:checkStepSession(stateSid, stepSid))
			return self:checkStepSession(stepSid)
		end
	end
	

	---@type Guide.ECGuide
	def.field(ECGuide).m_guideManager = nil

	---@type table
	def.field("table").m_config = nil

	---@type number
	def.field("number").m_id = 0
	

	---@type number
	def.field("number").m_stepSessionId = 0
	

	---@type number
	def.field("number").m_currentStepIndex = -1

	---@type GcCallbacks
	def.field(GcCallbacks).m_stepCleaner = nil

	---@type table
	def.field("table").m_enterStepStack = function () return {} end

	---@type number
	def.field("number").m_enterStepDepth = 0

	---@type boolean
	def.field("boolean").m_finishStateRecorded = false
	
	local POPUP_LEVEL = ECAutoPopupManager.POPUP_LEVEL

	---@type table
	def.field(ECAutoPopupManager.ExclusivePopupState).m_guidePopupState = function () return l_AutoPopupManager:MakePopupState(POPUP_LEVEL.GUIDE, true, POPUP_LEVEL.GUIDE, true) end

	---@type table
	def.field(ECAutoPopupManager.ExclusivePopupState).m_forceGuidePopupState = function () return l_AutoPopupManager:MakeExclusivePopupState() end

	---@type table
	def.field("table").m_forceModeConfig = nil
end
GuideState.Commit()

---@class Guide.ExecuteEnv:System.Object
---@field public Commit fun():Guide.ExecuteEnv @notnull
---@field public ui_close_all_except fun(excepts:table):boolean
---@field public ui_close_all_fullscreen_panel fun()
---@field public ui_close_except fun(panel:ECPanelBase, excepts:table):boolean
---@field public set_toggle fun(value:boolean, pos:table):boolean
local ExecuteEnv = Lplus.Class("Guide.ExecuteEnv")
do
	local def = ExecuteEnv.define
	
	local panel_cfg = _G.require_config("Configs/popup_panel_list.lua")

	local function isSpecialForbitClose (panel)
		--高优先级的msgbox不可关闭
		local ECMsgBox = require "GUI.Common.ECMsgBoxMan".ECMsgBox
		if panel:is(ECMsgBox) then
			if panel.mPriority >= Priority.guide then
				return true
			end
		end
	end
	
	local function shouldClosePanel (panel, excepts)
		if isSpecialForbitClose(panel) or not panel then
			return false
		end
		
		-- 递归找 m_parentPanel
		local currentPanel = panel
		if currentPanel.m_IsBG then
			return false
		end

		local popup_panel_list = panel_cfg.popup_panel_list

		while currentPanel do
			local panelName = currentPanel.m_panelName

			if currentPanel.m_IsBG then
				break
			end
			if not popup_panel_list[panelName] or (excepts and excepts[panelName]) then
				return false
			end
			--warn("scrollView not found: " .. panelName)
			--currentPanel = currentPanel.m_parentPanel
			currentPanel = nil
		end
		return true
	end
	

	---@param excepts table
	---@return boolean
	def.static("table", "=>", "boolean").ui_close_all_except = function (excepts)
		local ECGUIMan = require "GUI.ECGUIMan"
		local panelSetToClose = {}
		for panelName, panel in ECGUIMan.Instance():EachPanel() do
			if shouldClosePanel(panel, excepts) then
				panelSetToClose[panel] = true	--先记录后面再关闭，避免 DestroyPanel 改变 ECGUIMan.m_panelMap 使迭代出问题
			end
		end
		for panel in pairs(panelSetToClose) do
			panel:DestroyPanel()
		end
		
		return true
	end

	---@return void
	def.static().ui_close_all_fullscreen_panel = function()
		local ECGUIMan = require "GUI.ECGUIMan"
		local panelSetToClose = {}
		local fullscreen_panel_list = panel_cfg.fullscreen_panel_list
		for panelName, panel in ECGUIMan.Instance():EachPanel() do
			if fullscreen_panel_list[panelName] then
				panelSetToClose[panel] = true	--先记录后面再关闭，避免 DestroyPanel 改变 ECGUIMan.m_panelMap 使迭代出问题
			end
		end
		for panel in pairs(panelSetToClose) do
			panel:DestroyPanel()
		end
	end


	---@param panel ECPanelBase
	---@param excepts table
	---@return boolean
	def.static(ECPanelBase, "table", "=>", "boolean").ui_close_except = function (panel, excepts)
		if shouldClosePanel(panel, excepts) then
			panel:DestroyPanel()
		end
		
		return true
	end
	

	---@param value boolean
	---@param pos table
	---@return boolean
	def.static("boolean", "table", "=>", "boolean").set_toggle = function (value, pos)
		local obj = Executor.find_ui(unpack(pos))
		if obj then
			local toggle = obj:GetComponent("UIToggle")
			if toggle then
				toggle.value = value
				return true
			end
		end
		
		return false
	end
end
ExecuteEnv.Commit()

---@class Guide.DefGuideTools:System.Object
---@field public Commit fun():Guide.DefGuideTools @notnull
---@field public delay fun(seconds:number):function
---@field public ui_wait_show fun(...:table):function
---@field public ui_forbid_click fun():function
---@field public ui_highlight_ex fun(style:table, pos:table):function
---@field public ui_highlight_multi_target fun(style:table, panelName:string, ...:any):function
---@field public ui_highlight fun(style:table, ...:table):function
---@field public ui_highlight_oneof_tasks fun(style:table, taskids:table):function
---@field public ui_highlight_task fun(style:table, taskid:number):function
---@field public ui_highlight_instance_goal fun(style:table):function
---@field public ui_highlight_inventory fun(style:table, itemid:number):function
---@field public ui_highlight_inventory_multi_id fun(style:table, ...:any):function
---@field public ui_highlight_fashion fun(style:table, fashionid:number):function
---@field public ui_highlight_recipe fun(style:table, recipe_id:number):function
---@field public ui_highlight_people fun(style:table, people_id:number):function
---@field public ui_highlight_oneof_ex fun(style:table, posList:table, scrollViewPos:table):function
---@field public ui_highlight_oneof fun(style:table, ...:table):function
---@field public ui_highlight_scrollitem fun(style:table, scrollViewPos:table, ...:table):function
---@field public ui_scrolltoitem fun(widgetname:string, ...:any):function
---@field public ui_close_all_except fun(...:table):function
---@field public set_toggle fun(value:boolean, ...:table):function
---@field public speak fun(id:number):function
---@field public start_panel fun(panelName:string):function
---@field public popup_text fun(text:string, options:table):function
---@field public play_sound fun(stopOnStepEnd:boolean, eventName:string, switches:table):function
---@field public skill_guide fun(skill_id:number):function
---@field public skill_btn_highlight fun(btn_guide_id:number):function
---@field public dash_highlight fun():function
---@field public open_world_map fun(scale:any):function
---@field public temporarily_unlock_function fun(function_name:string):function
---@field public switch_sceneguide_subpanel fun(category:number):function
---@field public switch_mission_category fun(category:number):function
---@field public do_people_lottery fun(pool_id:number):function
---@field public do_people_contract fun(people_tid:number):function
---@field public show_strategy fun(id:any):function
---@field public ui_first_recharge fun(...:any):function
local DefGuideTools = Lplus.Class("Guide.DefGuideTools")
do
	local def = DefGuideTools.define
	
	--
	-- condition op
	--
	
	-- 见 ECHostConditionOp
	
	--
	-- execute op
	--

	---@param seconds number
	---@return function
	def.static("number", "=>", "function").delay = function (seconds)
		local ECAsyncTask = require "Utility.ECAsyncTask"
		return function (guideState)
			return ECAsyncTask.WaitForTime(seconds)
		end
	end
	
	--[[
		循环等待 ui 显示出来，较费，有超时。适用于等待即将弹出的窗口
	]]

	---@param ... table
	---@return function
	def.static("varlist", "=>", "function").ui_wait_show = function (...)
		local timerId
		local args = {...}
		
		return function (guideState) return Task.createOneStepEx(
			function (task)
				local realPos = Executor.calcRealPos(args)	--解除args中的函数
				
				if Executor.ui_is_show(unpack(realPos)) then
					return "end"
				end
				
				return function (task, resumeEntry)
					local usedTime = 0
					local timeStep = 0.1
					local timeout = 5
					timerId = GameUtil.AddGlobalTimer(timeStep, false, function ()
						usedTime = usedTime + timeStep
						if usedTime > timeout then	--超时
							if timerId then
								GameUtil.RemoveGlobalTimer(timerId)
								timerId = nil
							end
							task:cancel()
							resumeEntry()
							return
						end

						if Executor.ui_is_show(unpack(realPos)) then	--完成
							if timerId then
								GameUtil.RemoveGlobalTimer(timerId)
								timerId = nil
							end
							resumeEntry()
							return
						end
					end)
				end
			end,
			function ()
				if timerId then
					GameUtil.RemoveGlobalTimer(timerId)
					timerId = nil
				end
				return "stop"
			end)
		end
	end
	

	---@return function
	def.static("=>", "function").ui_forbid_click = function ()
		return function (guideState)
			local cover = require "Guide.ECPanelGuideCover".Instance()
			cover:SetDepth(GUIDEPTH.GUIDE_COVER)
			cover:Create()
			cover:EnableCover(guideState:getId(), guideState:currentStepIndex())
			
			guideState:addStepEndCallback(function ()
				cover:DisableCover(guideState:getId(), guideState:currentStepIndex())
			end)
			
			return true
		end
	end
	

	---@param style table
	---@param pos table
	---@return function
	def.static("table", "table", "=>", "function").ui_highlight_ex = function (style, pos)
		return function (guideState)
			local realPos = Executor.calcRealPos(pos)	--解除pos中的函数
			
			-- warn("ui_highlight_ex exec", unpack(realPos))
			
			local ECPanelGuideHighlight = require "Guide.ECPanelGuideHighlight"
			
			-- if not Executor.ui_is_show(unpack(realPos)) then		--这样查的话就无法跳过步骤了
			-- 	return false
			-- end
			ECPanelGuideHighlight.Popup(style, unpack(realPos))
			
			if guideState then
				guideState:addStepEndCallback(function ()
					-- ECGuide.DebugLog("ui_highlight_ex clean up", panelName)
					ECPanelGuideHighlight.Instance():StartFadeOut()
				end)
			end
			
			return true
		end
	end

	---@param style table
	---@param panelName string
	---@param ... any
	---@return function
	def.static("table", "string", "varlist", "=>", "function").ui_highlight_multi_target = function (style, panelName, ...)
		local pos_list = {...}
		return function (guideState)
			local realPos = Executor.calcRealPos(pos_list)	--解除pos中的函数

			local ECPanelGuideHighlight = require "Guide.ECPanelGuideHighlight"

			ECPanelGuideHighlight.PopupMultiTargets(style, panelName, realPos)

			if guideState then
				guideState:addStepEndCallback(function ()
					-- ECGuide.DebugLog("ui_highlight_multitarget clean up", panelName)
					ECPanelGuideHighlight.Instance():StartFadeOut()
				end)
			end

			return true
		end
	end

	---@param style table
	---@param ... table
	---@return function
	def.static("table", "varlist", "=>", "function").ui_highlight = function (style, ...)
		return DefGuideTools.ui_highlight_ex(style, {...})
	end

	---@param style table
	---@param taskids table
	---@return function
	def.static("table","table","=>", "function").ui_highlight_oneof_tasks = function(style, taskids)
		---@param guideState Guide.GuideState
		return function (guideState)
			local taskPanel = require "GUI.FEPanelSceneGuide".Instance().missionGuidePanel
			local taskListView = taskPanel.m_pTrackView

			local realIndex = taskListView:AutoSelectOneOfTaskViewItem(taskids)
			if realIndex == 0 then
				return false
			end
			local realTaskId = taskListView:GetTaskByIndex(realIndex)
			if realTaskId == 0 then
				return false
			end

			local ECPanelGuideHighlight = require "Guide.ECPanelGuideHighlight"
			local panelName = "questlist"
			--local objPath = ("QuestList/%d/Widget/Mark_CanAutoMove"):format(realIndex)
			local objVarlistPath = {"QuestList"}
			table.insert(objVarlistPath, function(panel, obj)
				local taskId = taskListView:GetTaskByIndex(realIndex)
				if taskId ~= realTaskId then
					return nil
				end
				local objItem = obj:FindWidgetByIndex(realIndex-1)
				if objItem then
					local sender = objItem:FindDirect("Widget/Btn_Click")
					if not sender then
						return nil
					end
					local ud = sender:GetUserData()
					if ud and type(ud) == "string" and ud:startswith("task:") then
						return objItem
					end
				end
				return nil
			end)
			table.insert(objVarlistPath, "Widget")

			-- if not Executor.ui_is_show(unpack(realPos)) then		--这样查的话就无法跳过步骤了
			-- 	return false
			-- end
			ECPanelGuideHighlight.Popup(style, panelName, unpack(objVarlistPath))
			if guideState then
				guideState:addStepEndCallback(function ()
					-- ECGuide.DebugLog("ui_highlight_ex clean up", panelName)
					ECPanelGuideHighlight.Instance():StartFadeOut()
				end)
			end
			
			return true
		end
	end

	---@param style table
	---@param taskid number
	---@return function
	def.static("table","number","=>", "function").ui_highlight_task = function(style, taskid)
		return DefGuideTools.ui_highlight_oneof_tasks(style, {taskid})
	end

	---@param style table
	---@return function
	def.static("table", "=>", "function").ui_highlight_instance_goal = function (style)
		return function(guideState)
			local instPanel = require("GUI.FEPanelSceneGuide").Instance():GetInstanceGuidePanel()
			if not instPanel:IsValid() then
				return false
			end

			local commonList = instPanel.m_commonStyleList
			local goalItem = commonList:GetItem(1):GetRootObj()
			if not goalItem then
				return false
			end

			local ECPanelGuideHighlight = require "Guide.ECPanelGuideHighlight"
			local panelName = "main_instanceguide"
			local objPath = string.format("Widget/StyleCommon/%s/Widget/Btn_Auto", goalItem:GetName())
			ECPanelGuideHighlight.Popup(style, panelName, objPath)
			if guideState then
				guideState:addStepEndCallback(function()
					ECPanelGuideHighlight.Instance():StartFadeOut()
				end)
			end

			return true
		end
	end

	---@param style table
	---@param itemid number
	---@return function
	def.static("table","number","=>", "function").ui_highlight_inventory = function(style, itemid)
		return function (guideState)
			local packagePanel = require "GUI.Character.UIPanelPackage".Instance()
			if not packagePanel.m_viewObj then
				return false
			end

			local itemData = packagePanel:GetPackageItemDataList()
			local itemIndex
			for i = 0, #itemData-1 do
				local item = itemData[i]
				if item.data and item.data.tid == itemid then
					itemIndex = i
					break
				end
			end
			if not itemIndex then
				return false
			end

			local scrollList = packagePanel.m_viewObj:FindDirect("Widget/Knapsack/Content_knapsack/GroupList/Itemlist")
			scrollList:SetFirstIndex(itemIndex+1, true, 0, EDescendantScrollDestination.IntoView)

			--print("ui_highlight_inventory realPos",itemindex,unpack(realPos))
			--warn("ui_highlight_task exec", unpack(realPos))
			
			local ECPanelGuideHighlight = require "Guide.ECPanelGuideHighlight"
			
			-- if not Executor.ui_is_show(unpack(realPos)) then		--这样查的话就无法跳过步骤了
			-- 	return false
			-- end
			local panelName = "inventory"
			local objListPath = ("Widget/Knapsack/Content_knapsack/GroupList/Itemlist/%d/Widget/img_Click"):format(itemIndex+1)
			ECPanelGuideHighlight.Popup(style, panelName, objListPath)
			
			guideState:addStepEndCallback(function ()
				-- ECGuide.DebugLog("ui_highlight_ex clean up", panelName)
				ECPanelGuideHighlight.Instance():StartFadeOut()
			end)
			
			return true
		end
	end

	---@param style table
	---@param ... any
	---@return function
	def.static("table", "varlist", "=>", "function").ui_highlight_inventory_multi_id = function(style, ...)
		local id_list = {...}
		return function (guideState)
			local packagePanel = require "GUI.Character.UIPanelPackage".Instance()
			if not packagePanel.m_viewObj then
				return false
			end

			local itemData = packagePanel:GetPackageItemDataList()
			local itemIndexList = {}
			for i = 0, #itemData-1 do
				local item = itemData[i]
				if item.data and table.Contains(id_list, item.data.tid) then
					table.insert(itemIndexList, i)
				end
			end
			if #itemIndexList == 0 then
				return false
			end

			local scrollList = packagePanel.m_viewObj:FindDirect("Widget/Knapsack/Content_knapsack/GroupList/Itemlist")
			scrollList:SetFirstIndex(itemIndexList[1]+1, true, 0, EDescendantScrollDestination.IntoView)

			--print("ui_highlight_inventory realPos",itemindex,unpack(realPos))
			--warn("ui_highlight_task exec", unpack(realPos))

			local ECPanelGuideHighlight = require "Guide.ECPanelGuideHighlight"

			-- if not Executor.ui_is_show(unpack(realPos)) then		--这样查的话就无法跳过步骤了
			-- 	return false
			-- end
			local panelName = "inventory"
			local controlPathList = {}
			for _, itemIndex in pairs(itemIndexList) do
				table.insert(controlPathList, {
					("Widget/Knapsack/Content_knapsack/GroupList/Itemlist/%d/Widget/img_Click"):format(itemIndex+1),
				})
			end
			ECPanelGuideHighlight.PopupMultiTargets(style, panelName, controlPathList)

			guideState:addStepEndCallback(function ()
				-- ECGuide.DebugLog("ui_highlight_ex clean up", panelName)
				ECPanelGuideHighlight.Instance():StartFadeOut()
			end)

			return true
		end
	end

	---@param style table
	---@param fashionid number
	---@return function
	def.static("table","number","=>", "function").ui_highlight_fashion = function(style, fashionid)
		return function (guideState)
			return true
		end
	end

	---@param style table
	---@param recipe_id number
	---@return function
	def.static("table", "number", "=>", "function").ui_highlight_recipe = function(style, recipe_id)
		return function (guideState)
			local ECPanelLifeProfMain = require "GUI.LifeProf.ECPanelLifeProfMain"
			local recipePanel = ECPanelLifeProfMain.Instance():GetShowingPage()
			if not recipePanel then
				return false
			end

			---@type ECViewLivingSystemRecipe
			local recipeView = recipePanel:GetSubView(recipePanel:GetCurPage())
			if not recipeView then
				return false
			end
			local recipeData = recipeView.m_RecipeList
			local recipeIndex
			for i = 1, #recipeData do
				local recipe = recipeData[i]
				if recipe.id == recipe_id then
					recipeIndex = i
					break
				end
			end
			if not recipeIndex then
				return false
			end

			--[[
			local scrollList = recipeView.m_viewObj:FindDirect("Menu_Bag/Menu_ScrollBox/MenuList")
			scrollList:SetFirstIndex(recipeIndex+1, true, 0, EDescendantScrollDestination.IntoView)]]

			local ECPanelGuideHighlight = require "Guide.ECPanelGuideHighlight"

			-- if not Executor.ui_is_show(unpack(realPos)) then		--这样查的话就无法跳过步骤了
			-- 	return false
			-- end
			local panelName = recipePanel:GetPanelName()

			local objListPath = ("Widget/WidSwit/MenuCook/Menu_Bag/MenuList/%d/Widget/Common_Item/Widget/Img_Icon"):format(recipeIndex)
			ECPanelGuideHighlight.Popup(style, panelName, objListPath)

			guideState:addStepEndCallback(function ()
				-- ECGuide.DebugLog("ui_highlight_recipe clean up", panelName)
				ECPanelGuideHighlight.Instance():StartFadeOut()
			end)

			return true
		end
	end

	---@param style table
	---@param people_id number
	---@return function
	def.static("table", "number", "=>", "function").ui_highlight_people = function(style, people_id)
		return function (guideState)
			local panel = require "GUI.SummonPeople.ECPanelPeopleList".Instance()
			if not panel.m_viewObj then
				return false
			end

			local peopleList = panel:GetPeopleDataList()
			if #peopleList == 0 then
				return false
			end

			local peopleIndex
			for i = 1, #peopleList do
				if peopleList[i]:GetTid() == people_id then
					peopleIndex = i
					break
				end
			end
			if not peopleIndex then
				return false
			end

			local scrollList = panel:FindDirect("Widget/List")
			scrollList:SetFirstIndex(peopleIndex, true, 0, EDescendantScrollDestination.IntoView)

			local ECPanelGuideHighlight = require "Guide.ECPanelGuideHighlight"

			-- if not Executor.ui_is_show(unpack(realPos)) then		--这样查的话就无法跳过步骤了
			-- 	return false
			-- end
			local panelName = panel:GetPanelName()
			local objListPath = ("Widget/List/%d/Widget/Btn_Infomation"):format(peopleIndex)
			ECPanelGuideHighlight.Popup(style, panelName, objListPath)

			guideState:addStepEndCallback(function ()
				-- ECGuide.DebugLog("ui_highlight_people clean up", panelName)
				ECPanelGuideHighlight.Instance():StartFadeOut()
			end)

			return true
		end
	end
	
	-- 如果 scrollViewPos 不为空，则自动卷动 scrollView 使目标可见

	---@param style table
	---@param posList table
	---@param scrollViewPos table
	---@return function
	def.static("table", "table", "table", "=>", "function").ui_highlight_oneof_ex = function (style, posList, scrollViewPos)
		return function (guideState)
			-- warn("ui_highlight_oneof_ex exec", panelName, unpack(childNames))
			
			--找到第一个可见的目标
			local targetPos
			for _, pos in ipairs(posList) do
				if Executor.ui_is_show(unpack(Executor.calcRealPos(pos))) then
					targetPos = Executor.calcRealPos(pos)
					break
				end
			end
			
			if not targetPos then	--print error info
				local strBuffer = {}
				for _, pos in ipairs(posList) do
					strBuffer[#strBuffer+1] = table.concat(Executor.calcRealPos(pos), ".")
				end
				warn("target not found in one of: " .. table.concat(strBuffer, ", "))
				return false
			end
			
			return Task.createStepsEx(
				function (task, step)
					if step == 1 then
						if scrollViewPos then	--自动卷动 scrollView 使 targetPos 可见
							local scrollViewObj = Executor.find_ui(unpack(scrollViewPos))
							local scrollView
							if scrollViewObj then
								scrollView = scrollViewObj:GetComponent("UIScrollView")
							end
							if not scrollView then
								warn("scrollView not found: " .. table.concat(scrollViewPos, "."))
								task:cancel()
								return "end"
							end
							
							local target = Executor.find_ui(unpack(targetPos))
							if not target then
								warn("target not found: " .. table.concat(targetPos, "."))
								task:cancel()
								return "end"
							end
							
							scrollView:DragToMakeVisible(target.transform, 1000)
							
							local ECAsyncTask = require "Utility.ECAsyncTask"
							return task:completeSub(ECAsyncTask.WaitForTime(0.1))
						else
							return "continue"
						end
					elseif step == 2 then
						local ECPanelGuideHighlight = require "Guide.ECPanelGuideHighlight"
						ECPanelGuideHighlight.Popup(style, unpack(targetPos))
						
						guideState:addStepEndCallback(function ()
							-- ECGuide.DebugLog("ui_highlight_oneof_ex clean up", panelName)
							ECPanelGuideHighlight.Instance():StartFadeOut()
						end)
					
						return "end"
					end
				end,
				function () return "stop" end)
		end
	end

	---@param style table
	---@param ... table
	---@return function
	def.static("table", "varlist", "=>", "function").ui_highlight_oneof = function (style, ...)
		return DefGuideTools.ui_highlight_oneof_ex(style, {...}, nil)
	end
	

	---@param style table
	---@param scrollViewPos table
	---@param ... table
	---@return function
	def.static("table", "table", "varlist", "=>", "function").ui_highlight_scrollitem = function (style, scrollViewPos, ...)
		return DefGuideTools.ui_highlight_oneof_ex(style, {...}, scrollViewPos)
	end

	---@param widgetname string
	---@param ... any
	---@return function
	def.static("string", "varlist", "=>", "function").ui_scrolltoitem = function (widgetname, ...)
		local realPos = {...}
		return function (guideState)
			local Scroll = Executor.find_ui(unpack(realPos))
			if Scroll then
				local widget = Scroll:FindDirect(widgetname)
				if widget then
					Scroll:ScrollWidgetIntoView(widget)
					return true
				end
			end
			return false
		end
	end
	

	---@param ... table
	---@return function
	def.static("varlist", "=>", "function").ui_close_all_except = function (...)
		local excepts = nil
		for i = 1, select("#", ...) do
			excepts = excepts or {}
			excepts[select(i, ...)] = true
		end
		
		return function (guideState)
			return ExecuteEnv.ui_close_all_except(excepts)
		end
	end
	

	---@param value boolean
	---@param ... table
	---@return function
	def.static("boolean", "varlist", "=>", "function").set_toggle = function (value, ...)
		local pos = {...}
		return function (guideState)
			return ExecuteEnv.set_toggle(value, pos)
		end
	end
	

	---@param id number
	---@return function
	def.static("number", "=>", "function").speak = function (id)
		return function ()
			return Task.createOneStepEx(function (task)
					return function (task, resumeEntry)
						local ECSystemSpeak = require "Chat.ECSystemSpeak"
						local ret = ECSystemSpeak.SpeakWithCallback(id, function () resumeEntry() end)
						if not ret then
							task:cancel()
							resumeEntry()
						end
					end
				end, function ()
					return "stop"
				end)
		end
	end
	

	---@param panelName string
	---@return function
	def.static("string", "=>", "function").start_panel = function (panelName)
		return function (guideState)
			local ECPanelBase = require "GUI.ECPanelBase"
			local instance = ECPanelBase()
			instance:CreatePanel("UI/UMG/"..panelName)
			
			guideState:addStepEndCallback(function ()
				instance:DestroyPanel()
			end)
			
			return true
		end
	end

	--[[
		options: {image=1, offx=offx or 0, offy=offy or 0, layer=layer or 1, bInCG=not not bInCG}
	]]
	---@param text string
	---@param options table
	---@return function
	def.static("string", "table", "=>", "function").popup_text = function (text, options)
		return function (guideState)
			local ECPanelGuideText = require "Guide.ECPanelGuideText"
			ECPanelGuideText.Instance():ShowGuideTextPanel(text, options)
			
			guideState:addStepEndCallback(function ()
				ECPanelGuideText.Instance():DestroyPanel()
			end)
			
			return true
		end
	end

	---@param stopOnStepEnd boolean
	---@param eventName string
	---@param switches table
	---@return function
	def.static("boolean", "string", "table", "=>", "function").play_sound = function (stopOnStepEnd, eventName, switches)
		---@param guideState Guide.GuideState
		return function (guideState)
			local ECSoundMan = require "Sound.ECSoundMan"
			local playingId = ECSoundMan.Instance():PlaySingleSfx(eventName)
			if stopOnStepEnd then
				guideState:addStepEndCallback(function ()
					ECSoundMan.Instance():StopPlayingID(playingId)
				end)
			end
			
			return true
		end
	end

	---@param skill_id number
	---@return function
	def.static("number", "=>", "function").skill_guide = function (skill_id)
		return function (guideState)
			local UISkillGuide = require "Skill.GUI.UISkillGuide"
			UISkillGuide.Instance():OpenPanel(skill_id, 0, nil)
			return true
		end
	end

	---@param btn_guide_id number
	---@return function
	def.static("number", "=>", "function").skill_btn_highlight = function(btn_guide_id)
		return function(guideState)
			local ECGame = require "Main.ECGame"
			local GuideSkillEvent = require "Event.GuideSkillEvent"
			local GuideSKillBeginEvent = GuideSkillEvent.GuideSKillBeginEvent
			ECGame.EventManager:raiseEvent(nil, GuideSKillBeginEvent.new(btn_guide_id))
			guideState:addStepEndCallback(function ()
				local GuideSKillFinishEvent = GuideSkillEvent.GuideSKillFinishEvent
				ECGame.EventManager:raiseEvent(nil, GuideSKillFinishEvent.new(btn_guide_id))
			end)
			return true
		end
	end

	---@return function
	def.static("=>", "function").dash_highlight = function()
		return function(guideState)
            local ECPanelGuideSprint = require "GUI.ECPanelGuideSprint"
            ECPanelGuideSprint.Instance():ShowPanelSimple(true)
			guideState:addStepEndCallback(function ()
                ECPanelGuideSprint.Instance():ShowPanelSimple(false)
			end)
			return true
		end
	end

	---@param scale any
	---@return function
	def.static("dynamic", "=>", "function").open_world_map = function(scale)
		return function (guideState)
			local UIWorldMap = require "GUI.Map.UIWorldMap"
			UIWorldMap.Instance():CreateEx(nil, scale or -1, false, nil)
			return true
		end
	end

	---@param function_name string
	---@return function
	def.static("string", "=>", "function").temporarily_unlock_function = function (function_name)
		return function(guideState)
			require "Guide.ECFunctionUnlock".TemporarilyUnlock(function_name)
			return true
		end
	end

	---@param category number
	---@return function
	def.static("number", "=>", "function").switch_sceneguide_subpanel = function (category)
		return function(guideState)
			require("GUI.FEPanelSceneGuide").Instance():_ShowSubPanelOnly(category)
			return true
		end
	end

	---@param category number
	---@return function
	def.static("number", "=>", "function").switch_mission_category = function (category)
		return function(guideState)
			require("GUI.FEPanelSceneGuide").Instance():SetQuestPage(category)
			return true
		end
	end

	-- 模拟幻灵抽卡
	---@param pool_id number
	---@return function
	def.static("number", "=>", "function").do_people_lottery = function(pool_id)
		return function(guideState)
			local is_free = false
			local hp = globalGame:GetHostPlayer()
			---@type pb.Message.PB.DrawPrizePoolConfig
			local cfg = ElementData.getDataByName("DrawPrizePoolConfig" , pool_id)
			for i=1, 2 do
				local gear = cfg.gear_list[i]
				if gear.gear_type == CONSTANT_DEFINE.DRAW_PRIZE_GEAR_TYPE.DPGT_ONE then
					for cost_idx=1, #gear.cost_list do
						if gear.cost_list[cost_idx].type == CONSTANT_DEFINE.DRAW_PRIZE_COST_TYPE.DPCT_FREE then
							local useNum =  hp:GetCommonUseCount(gear.free_common_uselimit_id)
							local maxNum =  hp:GetCommonUseMaxCount(gear.free_common_uselimit_id)
							is_free = (gear.free_common_uselimit_id ~= 0 and useNum < maxNum)
							break
						end
					end
				end
			end
			if is_free then
				-- 发送摇奖协议
				local client_msg = require "PB.client_msg"
				local pb_helper = require "PB.pb_helper"
				local gp_draw_prize_req = client_msg.gp_draw_prize_req
				local msg = gp_draw_prize_req()
				msg.pool_id = pool_id
				msg.draw_gear = CONSTANT_DEFINE.DRAW_PRIZE_GEAR_TYPE.DPGT_ONE
				pb_helper.Send(msg)
			end
			return true
		end
	end

	-- 模拟幻灵签约附体
	---@param people_tid number
	---@return function
	def.static("number", "=>", "function").do_people_contract = function(people_tid)
		local ECSummonPeopleMan = require "SummonPeople.ECSummonPeopleMan"
		return function(guideState)
			local people = ECSummonPeopleMan.Instance():GetPeopleData(people_tid)
			if not people or not people:IsActive() then
				return true
			end
			local function doFuti()
				-- 立即附体
				local curTeamId = ECSummonPeopleMan.Instance():GetPeopleCurTeamId()
				local memberList = ECSummonPeopleMan.Instance():GetPeopleCurTeamMemberIdList()
				local maxMercenaryCount = ECSummonPeopleMan.GetMaxMercenaryCount()
				for i = 1, maxMercenaryCount do
					if memberList[i] == people_tid then
						memberList[i] = memberList[maxMercenaryCount + 1]
						break
					end
				end
				memberList[maxMercenaryCount + 1] = people_tid
				ECSummonPeopleMan.Instance():ChangeFormation(curTeamId, memberList)
			end
			if not people:IsFuTiActive() then
				-- 签约
				--ECSummonPeopleMan.Instance():ActiveFuTi(people_tid, function(event)
				--	if event.ret == _G.SPEOPLE_OPERATION_RET.SOT_SUCCESS then
				--		doFuti()
				--	end
				--end)
			else
				local cur_team_id = ECSummonPeopleMan.Instance():GetPeopleCurTeamId()
				local is_futi = ECSummonPeopleMan.Instance():IsAttachPeopleInTeam(people_tid, cur_team_id)
				if not is_futi then
					doFuti()
				end
			end
			return true
		end
	end

	---@param id any
	---@return function
	def.static("dynamic", "=>", "function").show_strategy = function(id)
		return function (guideState)
			require "Guide.ECPanelStrategy".Instance():ShowGuide(id, true)
			return true
		end
	end

	---@param ... any
	---@return function
	def.static("varlist", "=>", "function").ui_first_recharge = function (...)
		return function (guideState)
			local ECPanelMenuLeft = require "GUI.Main.ECPanelMenuLeft"
			ECPanelMenuLeft.Instance():PopUpSecondaryCharge()
			return true
		end
	end

end
DefGuideTools.Commit()

---@class Guide.ECGuide:System.Object
---@field public ConditionOp table
---@field public ExecuteEnv table
---@field public DefGuideTools Guide.DefGuideTools
---@field protected m_bQuiting boolean
---@field protected m_guideStates Guide.GuideState[]
---@field protected m_activeGuideId number
---@field public Commit fun():Guide.ECGuide @notnull
---@field public Instance fun():Guide.ECGuide
---@field public AddInitCallback fun(callback:function)
---@field public Init fun()
---@field public OnInit fun()
---@field public Release fun()
---@field public FakeRelease fun()
---@field public RecordFinishState fun(self:Guide.ECGuide, guideId:number)
---@field public GetFinishState fun(self:Guide.ECGuide, guideId:number):boolean
---@field public GetAllFinishState fun(self:Guide.ECGuide):table
---@field public ResetAllFinishState fun(self:Guide.ECGuide)
---@field public ResetAllGuides fun(self:Guide.ECGuide)
---@field public OnPreGuideStart fun(self:Guide.ECGuide, id:number)
---@field public OnGuideStart fun(self:Guide.ECGuide, id:number)
---@field public OnGuideEnd fun(self:Guide.ECGuide, id:number, bSuccess:boolean)
---@field public GetActiveGuideId fun(self:Guide.ECGuide):boolean,number
---@field public GetActiveGuide fun(self:Guide.ECGuide):Guide.GuideState
---@field public ForceSkipActiveGuide fun(self:Guide.ECGuide)
---@field public checkSession fun(self:Guide.ECGuide):boolean
---@field public DebugLog fun(...:table)
---@field public triggerTlog fun(guideId:number, reason:string, param:number)
---@field public clearTlogHistory fun()
local ECGuide = Lplus.Class("Guide.ECGuide")
---@type Guide.ECGuide
local l_instance
local l_disable = false
do
	local def = ECGuide.define
	

	---@type table
	def.const("table").ConditionOp = ConditionOp
	

	---@type table
	def.const("table").ExecuteEnv = ExecuteEnv

	---@type Guide.DefGuideTools
	def.const("table").DefGuideTools = DefGuideTools
	
	local l_guide_config
	local l_initCallbacks


	---@return Guide.ECGuide
	def.static("=>", ECGuide).Instance = function ()
		return l_instance
	end
	
	---@param callback function
	---@return void
	def.static("function").AddInitCallback = function (callback)
		if l_instance then
			callback()
			return
		end

		l_initCallbacks = l_initCallbacks or Callbacks()
		l_initCallbacks:add(callback)
	end

	---@return void
	def.static().Init = function ()
		ECGuide.Release()

		if l_disable then
			return
		end
		
		l_instance = ECGuide()
		local self = l_instance
		
		ECGuide.DebugLog("guide init")
		--每次重新加载，否则 start 有问题
		l_guide_config = dofile("Configs/guide_loader.lua", true, "Configs/guide_macro.lua", "Configs/guide.lua")
		
		for id = 1, table.maxn(l_guide_config) do
			local config = l_guide_config[id]
			if config then
				local guideState = GuideState.new(self, config)
				self.m_guideStates[id] = guideState
			end
		end
		--先准备好 m_guideStates 再 start，否则若立即触发，m_guideStates 状态可能不对
		for id = 1, table.maxn(l_guide_config) do
			local guideState = self.m_guideStates[id]
			if guideState then
				guideState:start()
			end
		end
	end
	
	---@return void
	def.static().OnInit = function ()
		if l_initCallbacks then
			l_initCallbacks:invoke()
			l_initCallbacks:clear()
		end
	end

	---@return void
	def.static().Release = function ()
		if l_instance then
			ECGuide.DebugLog("guide release")
			
			l_instance.m_bQuiting = true
			local activeGuide = l_instance:GetActiveGuide()
			if activeGuide then
				activeGuide:forceCancelGuide()
			end
			
			--清理在 step 0 等待的步骤
			for id, state in pairs(l_instance.m_guideStates) do
				state:leaveStep()
			end

			l_instance = nil
			l_guide_config = nil
			ECGuide.clearTlogHistory()
		end
	end

	-- 仅调试用，清理全部指引。不直接使用 Release，避免 l_instance、l_guide_config 为空可能导致的报错。
	---@return void
	def.static().FakeRelease = function ()
		l_disable = true
		if l_instance then
			l_instance.m_bQuiting = true

			local activeGuide = l_instance:GetActiveGuide()
			if activeGuide then
				activeGuide:forceCancelGuide()
			end

			--清理在 step 0 等待的步骤
			for id, state in pairs(l_instance.m_guideStates) do
				state:forceCancelGuide()
			end
		end
	end

	---@param self Guide.ECGuide
	---@param guideId number
	---@return void
	def.method("number").RecordFinishState = function (self, guideId)
		ECGuideSaveData.Instance():SetFinishState(guideId, true)
	end
	

	---@param self Guide.ECGuide
	---@param guideId number
	---@return boolean
	def.method("number", "=>", "boolean").GetFinishState = function (self, guideId)
		return ECGuideSaveData.Instance():IsFinished(guideId)
	end
	

	---@param self Guide.ECGuide
	---@return table
	def.method("=>", "table").GetAllFinishState = function (self)
		return ECGuideSaveData.Instance():GetAllState()
	end
	

	---@param self Guide.ECGuide
	---@return void
	-- 这个函数仅仅是清了完成状态，需重进游戏才生效
	---@param self Guide.ECGuide
	---@return void
	def.method().ResetAllFinishState = function (self)
		ECGuideSaveData.Instance():ResetAllFinishState()
	end

	-- 这个函数相当于清完状态，重进游戏
	---@param self Guide.ECGuide
	---@return void
	def.method().ResetAllGuides = function(self)
		ECGuideSaveData.Instance():ResetAllFinishStateWithCB(function()
			-- 重新初始化指引系统
			ECGuide.Init()
		end)
	end

	---@param self Guide.ECGuide
	---@param id number
	---@return void
	def.method("number").OnPreGuideStart = function (self, id)
		if self.m_activeGuideId ~= -1 then
			error(("OnPreGuideStart %d when m_activeGuideId is %d"):format(id, self.m_activeGuideId))
		end
		

		ECGuide.DebugLog(("guide(%d) OnGuideStart"):format(id))
		ECGuide.triggerTlog(id, "start" , 0)
		self.m_activeGuideId = id
		
		-- 保存 npc_quest 状态后关闭所有弹出界面
		local ECPanelNPCQuest = require "GUI.NPC.ECPanelNPCQuest"
		ECPanelNPCQuest.SavePopState()
	end
	

	---@param self Guide.ECGuide
	---@param id number
	---@return void
	def.method("number").OnGuideStart = function (self, id)
		assert(self.m_activeGuideId ~= -1)
	end
	

	---@param self Guide.ECGuide
	---@param id number
	---@param bSuccess boolean
	---@return void
	def.method("number", "boolean").OnGuideEnd = function (self, id, bSuccess)
		local oldActiveGuideId = self.m_activeGuideId
		ECGuide.DebugLog(("guide(%d) OnGuideEnd, success: %s"):format(id, bSuccess and "true" or "false"))
		self.m_activeGuideId = -1
		
		local ECGame = require "Main.ECGame"
		ECGame.EventManager:raiseEvent(self, GuideEndEvent.new(id, bSuccess))
	end
	
	-- return1: 有激活的；return2: id

	---@param self Guide.ECGuide
	---@return boolean,number
	def.method("=>", "boolean", "number").GetActiveGuideId = function (self)
		return self.m_activeGuideId >= 0, self.m_activeGuideId
	end
	

	---@param self Guide.ECGuide
	---@return Guide.GuideState
	def.method("=>", GuideState).GetActiveGuide = function (self)
		if self.m_activeGuideId >= 0 then
			return self.m_guideStates[self.m_activeGuideId]
		else
			return nil
		end
	end
	

	---@param self Guide.ECGuide
	---@return void
	def.method().ForceSkipActiveGuide = function (self)
		local activeGuide = self:GetActiveGuide()
		if activeGuide then
			activeGuide:recordFinishState()
			activeGuide:forceCancelGuide()
		end
	end
	
	--[[
		检查当前 state 的 session 是否过期
	]]

	---@param self Guide.ECGuide
	---@return boolean
	def.method("=>", "boolean").checkSession = function (self)
		return not self.m_bQuiting
	end
	

	---@type boolean
	def.field("boolean").m_bQuiting = false
	

	---@type Guide.GuideState[]
	def.field("table").m_guideStates = function () return {} end

	---@type number
	def.field("number").m_activeGuideId = -1
	
	

	---@param ... table
	---@return void
	def.static("varlist").DebugLog = function (...)
		if ECDebugOption.Instance().guidelog then
			warn(...)
		end
	end
	
	local pb_helper = require "PB.pb_helper"
	local client_msg = require "PB.client_msg"
	--[[
		reason: 1: "start", 2: "step", 3: "finish", 4: "fail", 5: "abort"
	]]
	local tlogReasonMap =
	{
		start = 1,
		step = 2,
		finish = 3,
		fail = 4,
		abort = 5,
	}
	local tLogSendHistory = {}

	---@param guideId number
	---@param reason string
	---@param param number
	---@return void
	def.static("number", "string", "number").triggerTlog = function (guideId, reason, param)
		if not guideId or guideId < 1 then
			warn("triggerTlog error", guideId, param, "reason:", reason)
			return 
		end
		if guideId >= 10000 then  --特殊指引
			return
		end

		local tLogStep = tLogSendHistory[guideId]
		local reasonIdx = tlogReasonMap[reason] or 0

		if not tLogStep or not tLogStep[reason] or not tLogStep[reason][param] then
			if not tLogStep then
				tLogStep = {}
				tLogSendHistory[guideId] = {}
			end
			if not tLogStep[reason] then
				tLogStep[reason] = {}
			end
			do
				tLogStep[reason][param] = true  --记录发送历史，避免反复重发
				local msg = pb_helper.NewCmd "npt_send_tlog_info"
				msg.tlog_type = client_msg.npt_send_tlog_info.TLOG_TYPE_GUIDE
				
				msg.param1 = guideId
				msg.param2 = reasonIdx
				msg.param3 = param

				print("guide tlog", guideId, reasonIdx, param, "reason:", reason)
				pb_helper.Send(msg)
			end
		end
	end

	---@return void
	def.static().clearTlogHistory = function ()
		tLogSendHistory = {}
	end
end

ECGuide.Commit()
-- l_instance = ECGuide()

return ECGuide