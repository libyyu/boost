local Lplus = require "Lplus"

--[[
	重置解锁状态 (一般在游戏加载时)
]]
---@class Guide.ReloadUnlockStateEvent:System.Object
---@field public Commit fun():Guide.ReloadUnlockStateEvent @notnull
local ReloadUnlockStateEvent = Lplus.Class("Guide.ReloadUnlockStateEvent")
ReloadUnlockStateEvent.Commit()

--[[
	功能开始解锁 (条件已满足，转入解锁提示过程中)
]]
---@class Guide.FunctionStartUnlockEvent:System.Object
---@field public function_name string
---@field public Commit fun():Guide.FunctionStartUnlockEvent @notnull
---@field public new fun(function_name:string):Guide.FunctionStartUnlockEvent
local FunctionStartUnlockEvent = Lplus.Class("Guide.FunctionStartUnlockEvent")
do
	local def = FunctionStartUnlockEvent.define

	---@type string
	def.field("string").function_name = ""

	---@param function_name string
	---@return Guide.FunctionStartUnlockEvent
	def.static("string", "=>", FunctionStartUnlockEvent).new = function (function_name)
		local obj = FunctionStartUnlockEvent()
		obj.function_name = function_name
		return obj
	end
end
FunctionStartUnlockEvent.Commit()

--[[
	功能已解锁
]]
---@class Guide.FunctionUnlockedEvent:System.Object
---@field public function_name string
---@field public Commit fun():Guide.FunctionUnlockedEvent @notnull
---@field public new fun(function_name:string):Guide.FunctionUnlockedEvent
local FunctionUnlockedEvent = Lplus.Class("Guide.FunctionUnlockedEvent")
do
	local def = FunctionUnlockedEvent.define

	---@type string
	def.field("string").function_name = ""
	def.field("string").oprate_name = ""

	---@param function_name string
	---@return Guide.FunctionUnlockedEvent
	def.static("string", "=>", FunctionUnlockedEvent).new = function (function_name)
		local obj = FunctionUnlockedEvent()
		obj.function_name = function_name
		return obj
	end
end
FunctionUnlockedEvent.Commit()

--[[
	(临时强制解锁的)功能重新上锁
]]
---@class Guide.FunctionRelockedEvent:System.Object
---@field public function_name string
---@field public Commit fun():Guide.FunctionRelockedEvent @notnull
---@field public new fun(function_name:string):Guide.FunctionRelockedEvent
local FunctionRelockedEvent = Lplus.Class("Guide.FunctionRelockedEvent")
do
	local def = FunctionRelockedEvent.define

	---@type string
	def.field("string").function_name = ""

	---@param function_name string
	---@return Guide.FunctionRelockedEvent
	def.static("string", "=>", FunctionRelockedEvent).new = function (function_name)
		local obj = FunctionRelockedEvent()
		obj.function_name = function_name
		return obj
	end
end
FunctionRelockedEvent.Commit()


return
{
	ReloadUnlockStateEvent = ReloadUnlockStateEvent,
	FunctionStartUnlockEvent = FunctionStartUnlockEvent,
	FunctionUnlockedEvent = FunctionUnlockedEvent,
	FunctionRelockedEvent = FunctionRelockedEvent,
}
