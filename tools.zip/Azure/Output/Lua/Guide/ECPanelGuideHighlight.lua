--[[
	指引中高亮标记某一控件
]]

local Lplus = require "Lplus"
local ECPanelBase = require "GUI.ECPanelBase"
local ECGuide = require "Guide.ECGuide"
local ECHostConditionOp = require "Players.ECHostConditionOp"
local ECGUITools = require "GUI.ECGUITools"
local TweenPosition = require "GUI.TweenPosition"
local ECGUIMan = require "GUI.ECGUIMan"

---@class Guide.ECPanelGuideHighlight:ECPanelBase
---@field protected m_style table
---@field protected m_createTime number
---@field protected m_targetPanelName string
---@field protected m_targetInfos table
---@field protected m_objs userdata
---@field protected m_redirectObjs table
---@field protected m_lastAction string
---@field protected m_sessionId number
---@field protected m_checkTargetHideTimer any
---@field protected m_checkObjToPosTimer any
---@field protected m_SkipNum number
---@field protected m_aniname string
---@field protected m_checkTargetPosTimer any
---@field protected m_stamp number
---@field protected m_currentGuideId number
---@field protected m_currentStepIndex number
---@field public Commit fun():Guide.ECPanelGuideHighlight @notnull
---@field public Instance fun():Guide.ECPanelGuideHighlight
---@field public Create fun(self:Guide.ECPanelGuideHighlight)
---@field public Destroy fun(self:Guide.ECPanelGuideHighlight)
---@field public Popup fun(style:table, targetPanelName:string, ...:table)
---@field public PopupMultiTargets fun(style:table, targetPanelName:string, targetList:table)
---@field public StartFadeOut fun(self:Guide.ECPanelGuideHighlight)
---@field public OnCreate fun(self:Guide.ECPanelGuideHighlight)
---@field public StartUpdateGuideUIPos fun(self:Guide.ECPanelGuideHighlight, bNewlyCreated:boolean)
---@field public UpdateGuideUIWithPosCheck fun(self:Guide.ECPanelGuideHighlight, bNewlyCreated:boolean)
---@field public UpdateGuideUI fun(self:Guide.ECPanelGuideHighlight, bNewlyCreated:boolean)
---@field public BeginCheckTargetPosTick fun(self:Guide.ECPanelGuideHighlight)
---@field public MovePlaceHolder fun(self:Guide.ECPanelGuideHighlight, placeHolder:userdata, arrowShape:string, targetx:number, targety:number, obj:userdata)
---@field public EnableCover fun(self:Guide.ECPanelGuideHighlight, bEnable:boolean)
---@field public EnableGray fun(self:Guide.ECPanelGuideHighlight, grayValue:number, obj:userdata, index:number)
---@field public OnDestroy fun(self:Guide.ECPanelGuideHighlight)
---@field public CleanupContent fun(self:Guide.ECPanelGuideHighlight)
---@field public FadeInAndFlyCtrl fun(self:Guide.ECPanelGuideHighlight, ctrl:userdata, placeHolder:userdata, placeHolderAng:userdata, bShow:boolean, bNewlyCreated:boolean):number
---@field public FadeInCtrl fun(self:Guide.ECPanelGuideHighlight, ctrl:userdata, placeHolder:userdata, delay:number, bShow:boolean, bNewlyCreated:boolean)
---@field public onClick fun(self:Guide.ECPanelGuideHighlight, id:string)
---@field public onPress fun(self:Guide.ECPanelGuideHighlight, id:string, bButtondown:boolean)
---@field public onAnimationFinished fun(self:Guide.ECPanelGuideHighlight, id:string, aniname:string)
---@field public chooseTipArrowStyle fun(self:Guide.ECPanelGuideHighlight, obj:userdata):string,string
---@field private _GetStyleText fun(self:Guide.ECPanelGuideHighlight):string
---@field public MakeStampChecker fun(self:Guide.ECPanelGuideHighlight):function
---@field public MakeSessionChecker fun(self:Guide.ECPanelGuideHighlight):function
local ECPanelGuideHighlight = Lplus.Extend(ECPanelBase,"Guide.ECPanelGuideHighlight")
local l_instance = nil
do
	local def = ECPanelGuideHighlight.define

	local MAX_TARGET_COUNT = 3

	---@return Guide.ECPanelGuideHighlight
	def.static("=>",ECPanelGuideHighlight).Instance = function()
		return l_instance
	end

	---@param self Guide.ECPanelGuideHighlight
	---@return void
	def.method().Create = function (self)
		self.m_lastAction = "Create"
		self.m_sessionId = self.m_sessionId + 1

		if self.m_panel then
			self:StartUpdateGuideUIPos(false)
		else
			self:CreatePanel(RESPATH.Panel_Guide)
		end
	end

	---@param self Guide.ECPanelGuideHighlight
	---@return void
	def.method().Destroy = function (self)
		self.m_lastAction = "Destroy"
		
		self:DestroyPanel()
	end

	---@param style table
	---@param targetPanelName string
	---@param ... table
	---@return void
	def.static("table", "string", "varlist").Popup = function (style, targetPanelName, ...)
		local self = ECPanelGuideHighlight.Instance()
		local specifiedLayer = GUIDEPTH[style.layer]
		if specifiedLayer then
			self:SetDepth(specifiedLayer)
		elseif style.force then
			self:SetDepth(GUIDEPTH.TOPMOST)
		else
			local targetPanel = ECGUIMan.Instance():FindPanelByName(targetPanelName)
			if targetPanel then
				self:SetDepth(targetPanel:GetDepthLayer())
			else
				self:SetDepth(GUIDEPTH.TOPMOST)
			end
		end
		
		self.m_style = style
		self.m_targetPanelName = targetPanelName
		self.m_targetInfos = { {...} }
		
		self:Create()
	end

	---@param style table
	---@param targetPanelName string
	---@param targetList table
	---@return void
	def.static("table", "string", "table").PopupMultiTargets = function(style, targetPanelName, targetList)
		local self = ECPanelGuideHighlight.Instance()
		local specifiedLayer = GUIDEPTH[style.layer]
		if specifiedLayer then
			self:SetDepth(specifiedLayer)
		elseif style.force then
			self:SetDepth(GUIDEPTH.TOPMOST)
		else
			local targetPanel = ECGUIMan.Instance():FindPanelByName(targetPanelName)
			if targetPanel then
				self:SetDepth(targetPanel:GetDepthLayer())
			else
				self:SetDepth(GUIDEPTH.TOPMOST)
			end
		end

		self.m_style = style
		self.m_targetPanelName = targetPanelName
		self.m_targetInfos = targetList

		self:Create()
	end

	---@param self Guide.ECPanelGuideHighlight
	---@return void
	def.method().StartFadeOut = function (self)
		if self.m_lastAction == "Destroy" then
			return
		end
		
		if not self.m_panel or self.m_panel:is_nil() then
			self:Destroy()
			return
		end
		
		if self.m_lastAction ~= "StartFadeOut" then
			self.m_lastAction = "StartFadeOut"
			
			self:CleanupContent()
			
			self.m_panel:PlayAnimationByName("Ani_Image",0,1,1)
			local arrow = self.m_panel:FindDirect("Widget/Arrow")
			arrow:SetActive(false)

			for i=1, MAX_TARGET_COUNT do
				local groupstyle = self.m_panel:FindDirect("Widget/style"..i)
				groupstyle:SetActive(false)
			end
		end
	end
	

	---@param self Guide.ECPanelGuideHighlight
	---@return void
	def.override().OnCreate = function (self)
		local activeGuide = ECGuide.Instance():GetActiveGuide()
		self.m_currentGuideId = activeGuide:getId()
		self.m_currentStepIndex = activeGuide:currentStepIndex()

		self:StartUpdateGuideUIPos(true)
	end

	local function GetObjPositionAbsolute(obj)
		--local scale = GameUtil.GetViewportScale()
		local x, y = obj:GetSlotPositionAbsolute()
		--local alix,aliy = obj:GetSlotAlignment()
		--local sizex,sizey = obj:GetWidgetSize()
		if x == nil then
			local p = obj:GetParent()
			while p ~= nil do
				x,y = p:GetSlotPositionAbsolute()
				--alix,aliy = p:SetSlotAlignment()
				--sizex,sizey = p:GetWidgetSize()
				if x ~= nil then
					break
				else
					p = p:GetParent()
				end
			end
		end

		return x,y
	end

	local function ChooseTargetArrow(arrowShape,tips_placeholder)
		if arrowShape == "upleft" then
			local obj = tips_placeholder:FindDirect("UpLeft")
			return obj,obj:FindDirect("Img_UL"),"AniUpLeft"
		elseif arrowShape == "left" then
			local obj = tips_placeholder:FindDirect("Left")
			return obj,obj:FindDirect("Img_L"),"AniLeft"
		elseif arrowShape == "downleft" then
			local obj = tips_placeholder:FindDirect("DownLeft")
			return obj,obj:FindDirect("Img_DL"),"AniDownleft"
		elseif arrowShape == "upright" then
			local obj = tips_placeholder:FindDirect("UpRight")
			return obj,obj:FindDirect("Img_UR"),"AniUpright"
		elseif arrowShape == "right" then
			local obj = tips_placeholder:FindDirect("Right")
			return obj,obj:FindDirect("Img_R"),"AniRight"
		elseif arrowShape == "downright" then
			local obj = tips_placeholder:FindDirect("DownRight")
			return obj,obj:FindDirect("Img_DR"),"AnidownRight"
		elseif arrowShape == "up" then
			local obj = tips_placeholder:FindDirect("Up")
			return obj,obj:FindDirect("Img_U"),"AniUp"
		elseif arrowShape == "down" then
			local obj = tips_placeholder:FindDirect("Down")
			return obj,obj:FindDirect("Img_D"),"AniDown"
		end
	end

	---@param self Guide.ECPanelGuideHighlight
	---@param bNewlyCreated boolean
	---@return void
	def.method("boolean").StartUpdateGuideUIPos = function(self,bNewlyCreated)
		self:EnableCover(not not self.m_style.force)

		local objs = {}
		for _, targetInfo in pairs(self.m_targetInfos) do
			local obj = ECHostConditionOp.Executor.find_ui(self.m_targetPanelName, unpack(targetInfo))
			if not obj then
				warn("Guide Highlight target not found", self.m_targetPanelName, unpack(targetInfo))
				self:Destroy()
				return
			end

			if not obj:GetActive() then
				warn("Guide Highlight target not active", self.m_targetPanelName, unpack(targetInfo))
				self:Destroy()
				return
			end
			table.insert(objs, obj)
		end

		if self.m_checkTargetHideTimer then
			GameUtil.RemoveGlobalTimer(self.m_checkTargetHideTimer)
			self.m_checkTargetHideTimer = nil
		end
		self.m_checkTargetHideTimer = GameUtil.AddGlobalTimer(0.2, false, function ()
			--目标消失时，自动中止 step
			for i, targetInfo in pairs(self.m_targetInfos) do
				local obj = ECHostConditionOp.Executor.find_ui(self.m_targetPanelName, unpack(targetInfo))
				if not obj or not obj:IsHierarchyVisible() or (self.m_objs[i] and obj ~= self.m_objs[i]) then--说明发生了变化
					self:CleanupContent()
					local activeGuide = ECGuide.Instance():GetActiveGuide()
					if activeGuide then
						activeGuide:abortCurrentStep(activeGuide.m_currentStepIndex)
					end
					return
				end
			end
		end)
		local panel = self.m_panel
		self.m_createTime = Time.realtimeSinceStartup
		local image = panel:FindDirect("Widget/Group_Image")
		local arrow = panel:FindDirect("Widget/Arrow")
		image:SetActive(false)
		arrow:SetActive(false)

		for i=1, MAX_TARGET_COUNT do
			local groupstyle = panel:FindDirect("Widget/style"..i)
			if self.m_targetInfos[i] then
				for j = 0,groupstyle:GetChildrenCount() - 1 do
					groupstyle:GetChildAt(j):SetVisibility(2)
				end
				groupstyle:SetActive(true)
			else
				groupstyle:SetActive(false)
			end
			local target = panel:FindDirect(("Widget/target%d"):format(i))
			target:SetActive(false)
		end

		self.m_objs = objs

		if self.m_style.redirect_target then
			local redirectObj = ECHostConditionOp.Executor.find_ui(unpack(self.m_style.redirect_target))
			self.m_redirectObjs = {redirectObj}
		else
			self.m_redirectObjs = self.m_objs
		end
		self:UpdateGuideUIWithPosCheck(bNewlyCreated)
	end

	---@param self Guide.ECPanelGuideHighlight
	---@param bNewlyCreated boolean
	---@return void
	def.method("boolean").UpdateGuideUIWithPosCheck = function(self, bNewlyCreated)
		local obj = self.m_objs[1]
		local checktimes = 0
		local targetx,targety = GetObjPositionAbsolute(self.m_objs[1])
		if self.m_checkObjToPosTimer then
			GameUtil.RemoveGlobalTimer(self.m_checkObjToPosTimer)
			self.m_checkObjToPosTimer = nil
		end
		self.m_checkObjToPosTimer = GameUtil.AddGlobalTimer(0.3, false, function ()
			--等待目标初始位置稳定后再设置UI位置
			if obj and not obj:is_nil() then
				local newx,newy = GetObjPositionAbsolute(obj)
				if math.abs(newx - targetx) < 0.5 and math.abs(newy - targety) < 0.5 then
					self:UpdateGuideUI(bNewlyCreated)
					return
				else
					targetx = newx
					targety = newy
				end
				checktimes = checktimes + 1
				if checktimes > 10 then
					self:UpdateGuideUI(bNewlyCreated)
				end
			end
		end)
	end

	local ori_size = 80
	---@param self Guide.ECPanelGuideHighlight
	---@param bNewlyCreated boolean
	---@return void
	def.method("boolean").UpdateGuideUI = function (self, bNewlyCreated)
		if self.m_checkObjToPosTimer then
			GameUtil.RemoveGlobalTimer(self.m_checkObjToPosTimer)
			self.m_checkObjToPosTimer = nil
		end

		self.m_SkipNum = 0
		local style = self.m_style

		if not self.m_objs or #self.m_objs == 0 then
			self:Destroy()
			return
		end
		for _, obj in pairs(self.m_objs) do
			if not obj or obj:is_nil() then
				self:Destroy()
				return
			end
		end

		-- 持续检查目标位置，刷新指引位置
		if style.refresh_pos_c then
			self:BeginCheckTargetPosTick()
		end

		local panel = self.m_panel
		local guarder = self:MakeSessionChecker()

		local image = panel:FindDirect("Widget/Group_Image")
		local arrow = panel:FindDirect("Widget/Arrow")

		for i=1, MAX_TARGET_COUNT do
			local obj = self.m_objs[i]
			if not obj then break end
			local groupstyle = panel:FindDirect("Widget/style"..i)

			-- Style
			local targetx,targety = GetObjPositionAbsolute(obj)
			do	--setup target
				local sizeX_absolute,sizeY_absolute = obj:GetWidgetSizeAbsolute()

				local bShowTarget = not not style.force --== "redirect"
				local target = panel:FindDirect(("Widget/target%d"):format(i))
				ECGUITools.setVisible(target, bShowTarget)

				if bShowTarget then
					target:SetSlotSizeAbsolute(sizeX_absolute, sizeY_absolute)
					target:SetSlotPositionAbsolute(targetx, targety)
				end

				if style.shape ~= nil then
					local targetstyle = groupstyle:FindDirect(style.shape.."_"..i)
					if targetstyle then
						groupstyle:SetSlotPositionAbsolute(targetx,targety)
						targetstyle:SetVisibility(4)
						if style.auto then
							targetstyle:SetSlotSizeAbsolute(sizeX_absolute,sizeY_absolute)
							targetstyle:SetSlotPosition(0,0)
						else
							local sizeX_local, sizeY_local = obj:AbsoluteToLocalSize(sizeX_absolute, sizeY_absolute)
							targetstyle:SetSlotSize(ori_size,ori_size)
							targetstyle:SetSlotPosition((sizeX_local - ori_size)/2,(sizeY_local - ori_size)/2)
						end
						self.m_panel:PlayAnimationByName("Ani"..style.shape,0,0,0)
					end
				end

				self:EnableGray(self.m_style.shade or 0, obj, i)
			end
		end

		local obj = self.m_objs[1]
		local tips_placeholder = panel:FindDirect("Widget/Content")

		local targetx,targety = GetObjPositionAbsolute(obj)
		local arrowShape, whichImage = self:chooseTipArrowStyle(obj)
		self:MovePlaceHolder(tips_placeholder,arrowShape,targetx,targety,obj)

		local bShowArrow = not not style.arrow
		local styleText = self:_GetStyleText()
		local bShowImage = styleText ~= nil and #styleText > 0
		if bShowImage then
			local imageIndex = style.text_image or 1
			local imageSwitcher = image:FindDirect("ImageSw")
			imageSwitcher:SetActiveWidgetIndex(imageIndex - 1)
			local activeImage = imageSwitcher:GetActiveWidget()
			local ImageLeft = activeImage:FindDirect(("Image_Left_%d"):format(imageIndex))
			local ImageRight = activeImage:FindDirect(("Image_Right_%d"):format(imageIndex))
			local bLeft = whichImage == "left"
			ImageLeft:SetActive(bLeft)
			ImageRight:SetActive(not bLeft)
			if bLeft then
				ECGUITools.setTextAndColor(ImageLeft:FindDirect(("Tips_Left_%d"):format(imageIndex)),styleText)
			else
				ECGUITools.setTextAndColor(ImageRight:FindDirect(("Tips_Right_%d"):format(imageIndex)),styleText)
			end
		end

		GameUtil.AddGlobalTimer(0.1,true,function()
				if not guarder() or not self.m_panel or self.m_panel:is_nil() or not obj or obj:is_nil() then return end
				local obj, objang, aniname = ChooseTargetArrow(arrowShape, tips_placeholder)
				self.m_aniname = aniname
				
				local flyTime = self:FadeInAndFlyCtrl(arrow, obj, objang, bShowArrow, bNewlyCreated)
				self:FadeInCtrl(image, tips_placeholder:FindDirect("Target/Img_Target"), flyTime, bShowImage, bNewlyCreated)

				self.m_panel:PlayAnimationByName(self.m_aniname, 0, 0, 2)
				self:BringTop()
			end)
	end

	---@param self Guide.ECPanelGuideHighlight
	---@return void
	def.method().BeginCheckTargetPosTick = function(self)
		if self.m_checkTargetPosTimer then
			GameUtil.RemoveGlobalTimer(self.m_checkTargetPosTimer)
			self.m_checkTargetPosTimer = nil
		end

		local obj = self.m_objs[1]
		local currentX, CurrentY = GetObjPositionAbsolute(obj)
		local currentSizeX,currentSizeY = obj:GetWidgetSizeAbsolute()
		self.m_checkTargetPosTimer = GameUtil.AddGlobalTimer(0.3, false, function ()
			if not self.m_panel or self.m_panel:is_nil() or not obj or obj:is_nil() then return end
			local newx, newy = GetObjPositionAbsolute(obj)
			local newSizeX, newSizeY = obj:GetWidgetSizeAbsolute()
			if math.abs(newx - currentX) > 0.6 or math.abs(newy - CurrentY) > 0.6 or math.abs(newSizeX - currentSizeX) > 0.6 or math.abs(newSizeY - currentSizeY) > 0.6 then
				self:UpdateGuideUIWithPosCheck(false)

				if self.m_checkTargetPosTimer then
					GameUtil.RemoveGlobalTimer(self.m_checkTargetPosTimer)
					self.m_checkTargetPosTimer = nil
				end
			end
		end)
	end

	---@param self Guide.ECPanelGuideHighlight
	---@param placeHolder userdata
	---@param arrowShape string
	---@param targetx number
	---@param targety number
	---@param obj userdata
	---@return void
	def.method("userdata","string","number","number","userdata").MovePlaceHolder = function (self,placeHolder,arrowShape,targetx,targety,obj)
		local targetAbsoluteX = targetx
		local targetAbsoluteY = targety
		local targetSizeX,targetSizeY = obj:GetWidgetSizeAbsolute()
		local holderSizeX,holderSizeY = placeHolder:GetWidgetSizeAbsolute()
		--local scale = GameUtil.GetViewportScale()
		--targetSizeX = targetSizeX * scale
		--targetSizeY = targetSizeY * scale
		--holderSizeX = holderSizeX * scale
		--holderSizeY = holderSizeY * scale

		local dstAbsoluteX,dstAbsoluteY
		if arrowShape == "upleft" then
			dstAbsoluteX = targetAbsoluteX + targetSizeX
			dstAbsoluteY = targetAbsoluteY + targetSizeY
		elseif arrowShape == "left" then
			dstAbsoluteX = targetAbsoluteX + targetSizeX
			dstAbsoluteY = targetAbsoluteY + targetSizeY/2 - holderSizeY/2
		elseif arrowShape == "downleft" then
			dstAbsoluteX = targetAbsoluteX + targetSizeX
			dstAbsoluteY = targetAbsoluteY - holderSizeY
		elseif arrowShape == "upright" then
			dstAbsoluteX = targetAbsoluteX - holderSizeX
			dstAbsoluteY = targetAbsoluteY + targetSizeY
		elseif arrowShape == "right" then
			dstAbsoluteX = targetAbsoluteX - holderSizeX
			dstAbsoluteY = targetAbsoluteY + targetSizeY/2 - holderSizeY/2
		elseif arrowShape == "downright" then
			dstAbsoluteX = targetAbsoluteX - holderSizeX
			dstAbsoluteY = targetAbsoluteY - holderSizeY
		elseif arrowShape == "up" then
			dstAbsoluteX = targetAbsoluteX + targetSizeX/2 - holderSizeX/2
			dstAbsoluteY = targetAbsoluteY + targetSizeY
		elseif arrowShape == "down" then
			dstAbsoluteX = targetAbsoluteX + targetSizeX/2 - holderSizeX/2
			dstAbsoluteY = targetAbsoluteY - holderSizeY
		end
		--print("targetAbsoluteX,targetAbsoluteY",arrowShape,targetAbsoluteX,targetAbsoluteY)
		--print("targetSizeX,targetSizeY",targetSizeX,targetSizeY)
		--print("holderSizeX,holderSizeY",holderSizeX,holderSizeY)
		--print("dstAbsoluteX,dstAbsoluteY",dstAbsoluteX,dstAbsoluteY,scale)

		placeHolder:SetSlotPositionAbsolute(dstAbsoluteX,dstAbsoluteY)
	end
	

	---@param self Guide.ECPanelGuideHighlight
	---@param bEnable boolean
	---@return void
	def.method("boolean").EnableCover = function (self, bEnable)
		local cover = require "Guide.ECPanelGuideCover".Instance()
		if bEnable then
			cover:SetDepth(self:GetDepthLayer() - 1)
			cover:Create()
			cover:EnableCover(self.m_currentGuideId, self.m_currentStepIndex)
		else
			cover:DisableCover(self.m_currentGuideId, self.m_currentStepIndex)
		end
	end

	---@param self Guide.ECPanelGuideHighlight
	---@param grayValue number
	---@param obj userdata
	---@param index number
	---@return void
	def.method("number", "userdata", "number").EnableGray = function(self, grayValue, obj, index)
		local Gray = self.m_panel:FindDirect("Widget/Gray")
		Gray:SetVisibility(grayValue > 0 and 4 or 1)
		if grayValue > 0 then
			--[[
				UI指引材质说明：
				CenterPosition指的是圆心位置，x轴填R，y轴填G，范围0-1，(0,0)是左上角，(1,1)是右下角
				Hardness是圆边缘过度硬度，0是最软（从圆心就开始渐变），1是最硬（不过度），默认值是0.8
				OpacityScale是黑暗处的透明度，1是完全不透明，即只能看到圆圈处的内容，0是完全透明，即和没有遮盖效果一样，默认值0.8
				Radius，圆圈的半径，范围0-1，这个值对应的是y轴，即纵向的长度比例，比如填写0.5的话，圆圈刚好遮盖住从上到下
				Ratio_X，这个是当前分辨率比例，为x/y，比如1920/1080即填写1.7778，默认填写大小是1.775
			]]
			Gray:SetRenderOpacity(grayValue)
			local material = Gray:GetDynamicMaterial()
			if material then
				local ViewportSize = GameUtil.GetViewportSize()
				local targetx,targety = obj:GetSlotPositionViewport()
				local scale = GameUtil.GetViewportScale()
				local sizeX,sizeY = obj:GetWidgetSize()
				sizeX = sizeX * scale
				sizeY = sizeY * scale
				
				local centerX = targetx + sizeX/2
				local centerY = targety + sizeY/2

				if _G.platform == PLATFORM_TYPE_WINDOWS and not _G.GIsEditor then
					local PCDPIX,PCDPIY = GameUtil.AbsoluteToViewport(0,0,false)
					centerX = centerX + PCDPIX
					centerY = centerY + PCDPIY
				end

				if index <= 2 then
					local CenterPosition = material:GetVectorParameterValue("CenterPosition")
					if index == 1 then
						CenterPosition[1] = centerX/ViewportSize.x
						CenterPosition[2] = centerY/ViewportSize.y
					else
						CenterPosition[3] = centerX/ViewportSize.x
						CenterPosition[4] = centerY/ViewportSize.y
					end
					material:SetVectorParameterValue("CenterPosition", CenterPosition)
				else
					material:SetVectorParameterValue("CenterPosition2",{centerX/ViewportSize.x,centerY/ViewportSize.y})
				end

				local radius = sizeX
				if sizeY > sizeX then
					radius = sizeY
				end
				radius = radius / 2
				radius = radius + 5

				if index == 1 then
					material:SetScalarParameterValue("Radius",radius/ViewportSize.y)
					material:SetScalarParameterValue("Ratio_X",ViewportSize.x/ViewportSize.y)
				else
					material:SetScalarParameterValue(string.format("Radius%d", index), radius/ViewportSize.y)
					material:SetScalarParameterValue(string.format("Ratio%d_X", index), ViewportSize.x/ViewportSize.y)
				end
			end
		end
	end

	---@param self Guide.ECPanelGuideHighlight
	---@return void
	def.override().OnDestroy = function (self)
		self:CleanupContent()
	end

	---@param self Guide.ECPanelGuideHighlight
	---@return void
	def.method().CleanupContent = function (self)
		if self.m_checkTargetHideTimer then
			GameUtil.RemoveGlobalTimer(self.m_checkTargetHideTimer)
			self.m_checkTargetHideTimer = nil
		end
		if self.m_checkObjToPosTimer then
			GameUtil.RemoveGlobalTimer(self.m_checkObjToPosTimer)
			self.m_checkObjToPosTimer = nil
		end
		if self.m_checkTargetPosTimer then
			GameUtil.RemoveGlobalTimer(self.m_checkTargetPosTimer)
			self.m_checkTargetPosTimer = nil
		end
		
		self:EnableCover(false)
		self:EnableGray(0, nil, 0)
		self.m_objs = nil
		self.m_SkipNum = 0
		if self.m_aniname ~= "" then
			self.m_panel:StopAnimationByName(self.m_aniname)
		end
		self.m_aniname = ""
	end
	
	--return: 最小转向偏角
	local function minDiffAngle (diffAngle)
		local _, frac = math.modf((diffAngle + 180) / 360)
		_, frac = math.modf(frac + 2)	--make it positive
		return frac * 360 - 180
	end
	
	local l_TweenPos = nil
	-- return 1: fly time

	---@param self Guide.ECPanelGuideHighlight
	---@param ctrl userdata
	---@param placeHolder userdata
	---@param placeHolderAng userdata
	---@param bShow boolean
	---@param bNewlyCreated boolean
	---@return number
	def.method("userdata", "userdata", "userdata","boolean", "boolean", "=>", "number").FadeInAndFlyCtrl = function (self, ctrl, placeHolder, placeHolderAng ,bShow, bNewlyCreated)
		if not bShow then
			if bNewlyCreated then
				ctrl:SetActive(false)
			end
			return 0
		end
		
		if not l_TweenPos then
			l_TweenPos = TweenPosition()
		end

		--local guarder = self:MakeSessionChecker()
		ECGUITools.setEnable(ctrl,true)
		ctrl:SetVisibility(3)

		local dstx,dsty = placeHolder:GetSlotPositionAbsolute()
		local dstAngle = placeHolderAng:GetRenderAngle()
		local ctrl_arrow = ctrl:FindDirect("Img_arrows")

		if bNewlyCreated then
			ctrl:SetSlotPositionAbsolute(dstx,dsty)
			ctrl_arrow:SetRenderAngle(dstAngle)
			return 0
		end

		ECGUITools.setEnable(ctrl,true)
		ctrl:SetVisibility(3)

		local srcx,srcy = ctrl:GetSlotPositionAbsolute()
		local distx = dstx - srcx
		local disty = dsty - srcy
		local len = math.sqrt( distx*distx + disty*disty)


		local srcAngle = ctrl_arrow:GetRenderAngle()
		local diffAngle = minDiffAngle(dstAngle - srcAngle)

		local flyTime = math.max(len / 1500,	--每秒1500点
								math.abs(diffAngle) / 90 * 0.3)		--每90度0.3秒

		l_TweenPos:Begin(ctrl,{srcx,srcy},{dstx,dsty},flyTime,0.05,true,nil)
		l_TweenPos:TweenAngle(ctrl_arrow,srcAngle,dstAngle)
								
		return flyTime
	end
	

	---@param self Guide.ECPanelGuideHighlight
	---@param ctrl userdata
	---@param placeHolder userdata
	---@param delay number
	---@param bShow boolean
	---@param bNewlyCreated boolean
	---@return void
	def.method("userdata", "userdata", "number", "boolean", "boolean").FadeInCtrl = function (self, ctrl, placeHolder, delay, bShow, bNewlyCreated)
		if not bShow then
			if bNewlyCreated then
				ctrl:SetActive(false)
			end
			return
		end
		
		local guarder = self:MakeSessionChecker()
		
		--ctrl:SetActive(false)

		local x,y = placeHolder:GetSlotPositionAbsolute()
		ctrl:SetSlotPositionAbsolute(x,y)
		
		GameUtil.AddGlobalTimer(delay, true, function ()
			if not guarder() then return end
			
			ctrl:SetActive(true)
			self.m_panel:PlayAnimationByName("Ani_Image")
		end)
	end
	

	---@param self Guide.ECPanelGuideHighlight
	---@param id string
	---@return void
	def.method("string").onClick = function (self, id)
		if id:find("targetclick") == 1 then	--做转发 (redirect)
			if self.m_redirectObjs then
				local index = tonumber(string.match(id, "targetclick(%d+)"))
				local obj = self.m_redirectObjs[index]
				if not obj or obj:is_nil() then return end
				local targetPanel = ECGUIMan.Instance():FindPanelByName(self.m_targetPanelName)
				if targetPanel then
					local NotifyClick = require "Event.NotifyClick"
					local ECGame = require "Main.ECGame"
					local event = NotifyClick()
					if targetPanel.m_panel and not targetPanel.m_panel:is_nil() then
						event.who = targetPanel.m_panel:GetRootWidget():GetName()
					end
					event.panel = targetPanel
					event.id = obj:GetName()
					event.obj = obj
					ECGame.EventManager:raiseEvent(nil, event)

					if obj:IsA("AzureRadioBox") then
						if targetPanel.m_panel and not targetPanel.m_panel:is_nil() then
							obj:SetChecked(not obj:GetChecked())
							targetPanel.m_panel:OnChecked(obj, obj:GetCheckedState())
						end
					else
						if targetPanel.m_panel and not targetPanel.m_panel:is_nil() then
							targetPanel.m_panel:OnClicked(obj)
						end

						if targetPanel.m_panel and not targetPanel.m_panel:is_nil() then
							targetPanel.m_panel:OnPressed(obj)
							targetPanel.m_panel:OnReleased(obj)
						end
					end
				end
			end
		else

			--if self.m_aniname ~= "" then
			--	self.m_panel:PlayAnimationByName(self.m_aniname,0,2,2)
			--end

			local forceTime = self.m_style.force_time
			if forceTime and Time.realtimeSinceStartup - self.m_createTime < forceTime then		--forceTime 时间未到
				return
			end
			
			local forceTimes = self.m_style.force_times or 0
			if forceTimes == 0 then
				return
			end

			self.m_SkipNum = self.m_SkipNum + 1
			--[[
			if self.m_SkipNum == forceTimes then
				FlashTipMan.FlashTip(StringTable.Get(3204))]]
			if self.m_SkipNum > forceTimes then
				MsgBox.ShowMsgBox(nil, StringTable.Get(3201), 	--您是否要跳过强制引导？
					nil, MsgBoxType.MBBT_OKCANCEL, function (_, retVal)
						if retVal == MsgBoxRetT.MBRT_OK then
							ECGuide.Instance():ForceSkipActiveGuide()
						else
							self.m_SkipNum = forceTimes
						end
					end, nil, nil, Priority.guide, nil)
			end
		end
	end
	

	---@param self Guide.ECPanelGuideHighlight
	---@param id string
	---@param bButtondown boolean
	---@return void
	def.method("string", "boolean").onPress = function (self, id, bButtondown)
		--[[
		if id == "target" then
			if self.m_obj and not self.m_obj:is_nil() then
				self.m_obj:SendMessage("OnPress", bButtondown, SendMessageOptions.DontRequireReceiver)
			end
		end]]
	end
	

	---@param self Guide.ECPanelGuideHighlight
	---@param id string
	---@param aniname string
	---@return void
	def.override("string", "string").onAnimationFinished = function (self, id, aniname)
		ECPanelBase.onAnimationFinished(self, id, aniname)

		if 1 == string.find(aniname,"Ani_Image") then
			if self.m_lastAction == "StartFadeOut" then
				self:Destroy()
			end
		end
	end

	---@param self Guide.ECPanelGuideHighlight
	---@param obj userdata
	---@return string,string
	def.method("userdata", "=>", "string", "string").chooseTipArrowStyle = function (self, obj)
		local ViewportSize = GameUtil.GetViewportSize()

		local targetx,targety = obj:GetSlotPositionViewport()
		if not targetx or not targety then
			return "upleft", "right"
		end
		local maxSidewardWidthRatio = 0.4
		local maxSidewardHeightRatio = 0.3
		local bLeft = targetx <= ViewportSize.x * maxSidewardWidthRatio
		local bRight = targetx >= ViewportSize.x * (1 - maxSidewardWidthRatio)
		local bTop = targety <= ViewportSize.y * maxSidewardHeightRatio
		local bBottom = targety >= ViewportSize.y * (1 - maxSidewardHeightRatio)

		--print("chooseTipArrowStyle",targetx,targety,ViewportSize.x,ViewportSize.y)
		--print("chooseTipArrowStyle",bLeft,bRight,bTop,bBottom)
		if bLeft then	--左1/3，向左指
			if bTop then
				return "upleft", "right"
			elseif bBottom then
				return "downleft", "right"
			else
				return "left", "right"
			end
		elseif bRight then	--右1/3，向右指
			if bTop then
				return "upright", "left"
			elseif bBottom then
				return "downright", "left"
			else
				return "right", "left"
			end
		else	--上下指
			local whichImage = targetx <= ViewportSize.x * 0.5 and "right" or "left"
			if targety <= ViewportSize.y * 0.5 then	--上半屏，向上指
				return "up", whichImage
			else
				return "down", whichImage
			end
		end
	end

	---@param self Guide.ECPanelGuideHighlight
	---@return string
	def.method("=>", "string")._GetStyleText = function(self)
		local isClientPC = _G.platform == _G.PLATFORM_TYPE_WINDOWS and not _G.IsWindowsSimuMobile()
		local text = nil
		if isClientPC then
			text = self.m_style.text_pc
		else
			text = self.m_style.text_mobile
		end
		if not text then
			text = self.m_style.text
		end
		return text or ""
	end
	
	--[[
		style =
		{
			shape = "shape_name",
			text = "text_content",
			text_image = "text_image",
		}
	]]

	---@type table
	def.field("table").m_style = nil

	---@type number
	def.field("number").m_createTime = 0

	---@type string
	def.field("string").m_targetPanelName = ""

	---@type table
	def.field("table").m_targetInfos = nil

	--要高亮的按钮
	---@type userdata
	def.field("table").m_objs = nil

	--强制指引时，redirect 点击消息时发送目标 (可以和 m_objs 不同)
	---@type table
	def.field("table").m_redirectObjs = nil

	---@type string
	def.field("string").m_lastAction = ""

	---@type number
	def.field("number").m_sessionId = 0

	---@type any
	def.field("dynamic").m_checkTargetHideTimer = nil

	---@type any
	def.field("dynamic").m_checkObjToPosTimer = nil

	---@type number
	def.field("number").m_SkipNum = 0

	---@type string
	def.field("string").m_aniname = ""

	---@type any
	def.field("dynamic").m_checkTargetPosTimer = nil
	
	---@type number
	def.field("number").m_stamp = 0

	---@type number
	def.field("number").m_currentGuideId = 0

	---@type number
	def.field("number").m_currentStepIndex = -1

	--[[
		返回一个函数，用于检查 stamp。函数返回 true 表示检查成功
	]]
	---@param self Guide.ECPanelGuideHighlight
	---@return function
	def.method("=>", "function").MakeStampChecker = function (self)
		local stamp = self.m_stamp
		return function ()
			return self.m_panel ~= nil and stamp == self.m_stamp
		end
	end

	---@param self Guide.ECPanelGuideHighlight
	---@return function
	def.method("=>", "function").MakeSessionChecker = function (self)
		local sessionId = self.m_sessionId
		local panelStampChecker = self:MakeStampChecker()
		return function ()
			return sessionId == self.m_sessionId and panelStampChecker()
		end
	end
end
ECPanelGuideHighlight.Commit()

l_instance = ECPanelGuideHighlight()
l_instance.m_uigroup_mask = bit.band(UISHOWGROUP.ALL,bit.bnot(UISHOWGROUP.CG),bit.bnot(UISHOWGROUP.SHOT),bit.bnot(UISHOWGROUP.SHARE))

return ECPanelGuideHighlight
