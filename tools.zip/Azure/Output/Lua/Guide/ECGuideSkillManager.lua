local Lplus = require "Lplus"

local UserData = require "Data.UserData"
local ECHostPlayer = require "Players.ECHostPlayer"
local ECGame = require "Main.ECGame"
local GuideSkillCfg = _G.require_config("Configs/guide_skill_cfg.lua")

local ECGuideSkill = require "Guide.ECGuideSkill"

---@class ECGuideSkillManager:System.Object
---@field protected m_currentGuideId number
---@field protected m_nextGuideId number
---@field protected m_TimerID number
---@field protected m_ignoreIds table
---@field public Commit fun():ECGuideSkillManager @notnull
---@field public Instance fun():ECGuideSkillManager
---@field public InstanceNotCreate fun():ECGuideSkillManager
---@field public Init fun(self:ECGuideSkillManager)
---@field public isSKillIgnored fun(self:ECGuideSkillManager, skillid:number):boolean
---@field public Release fun(self:ECGuideSkillManager)
---@field public ReleasePanel fun(self:ECGuideSkillManager)
---@field public ShowGuide fun(self:ECGuideSkillManager, id:number)
---@field public ShowGuideByCMD fun(self:ECGuideSkillManager, id:number, ignoreCheck:boolean)
---@field public GetShowGuideID fun(self:ECGuideSkillManager, id:number):number
---@field public prepareShowNext fun(self:ECGuideSkillManager, id:number, time:number)
---@field public onEnterJump fun(self:ECGuideSkillManager)
---@field public OnSummonPeople fun(self:ECGuideSkillManager)
local ECGuideSkillManager = Lplus.Class("ECGuideSkillManager")

local def = ECGuideSkillManager.define

---@type number
def.field("number").m_currentGuideId = 0

---@type number
def.field("number").m_nextGuideId = 0

---@type number
def.field("number").m_TimerID = 0

---@type table
def.field("table").m_ignoreIds = nil

---@type ECGuideSkillManager
local m_Instance = nil

---@return ECGuideSkillManager
def.static("=>", ECGuideSkillManager).Instance = function()
    if not m_Instance then
        m_Instance = ECGuideSkillManager()
        m_Instance:Init()
    end
    return m_Instance
end

---@return ECGuideSkillManager
def.static("=>", ECGuideSkillManager).InstanceNotCreate = function()
    return m_Instance
end

---@param self ECGuideSkillManager
---@return void
def.method().Init = function(self)
    self.m_ignoreIds = {}
    local ignores = GuideSkillCfg.ignoreSkillids
    if ignores then
        for i,v in pairs(ignores) do
            self.m_ignoreIds[v] = true
        end
    end

    -- 监听主角名人创建/销毁的事件
    local SummonPeopleEvents = require("Event.SummonPeopleEvents")
    local SummonPeopleChangeEvent = SummonPeopleEvents.SummonPeopleChangeEvent
    ---@param event SummonPeopleChangeEvent
    ECGame.EventManager:addHandler(SummonPeopleChangeEvent, function (sender, event)
        if sender and sender:is(ECHostPlayer) and event.m_people then
            self:OnSummonPeople()
        end
    end)
end

---@param self ECGuideSkillManager
---@param skillid number
---@return boolean
def.method("number","=>","boolean").isSKillIgnored = function(self,skillid)
    local ignored = self.m_ignoreIds[skillid] or false
    return ignored
end

---@param self ECGuideSkillManager
---@return void
def.method().Release = function(self)
    if self.m_TimerID and self.m_TimerID > 0 then
        GameUtil.RemoveGlobalTimer(self.m_TimerID)
        self.m_TimerID = 0
    end
    self = nil
end

---@param self ECGuideSkillManager
---@return void
def.method().ReleasePanel = function(self)
    local eCGuideSkill = ECGuideSkill.InstanceNotCreate()
    if eCGuideSkill then
        eCGuideSkill:DestroyPanel()
    end
    if self.m_TimerID and self.m_TimerID > 0 then
        GameUtil.RemoveGlobalTimer(self.m_TimerID)
        self.m_TimerID = 0
    end
end

---@param self ECGuideSkillManager
---@param id number
---@return void
def.method("number").ShowGuide = function(self,id)
    local guideID = self:GetShowGuideID(id)
    if guideID <= 0 then return end

    local eCGuideSkill = ECGuideSkill.InstanceNotCreate()
    --同时只显示一份引导
    if eCGuideSkill then
        eCGuideSkill:DestroyPanel()
        --return
    end
    self.m_currentGuideId = guideID
    ECGuideSkill.Instance():ShowPanel(true,nil,function ()
        ECGuideSkill.Instance():ShowGuideByID(guideID)
    end)
end

---@param self ECGuideSkillManager
---@param id number
---@param ignoreCheck boolean
---@return void
def.method("number","boolean").ShowGuideByCMD = function(self,id,ignoreCheck)
    local guideID = id
    if not ignoreCheck then
        guideID = self:GetShowGuideID(id)
    end
    if guideID <= 0 then return end

    local eCGuideSkill = ECGuideSkill.InstanceNotCreate()
    --同时只显示一份引导
    if eCGuideSkill then
        eCGuideSkill:DestroyPanel()
        --return
    end
    self.m_currentGuideId = guideID
    ECGuideSkill.Instance():ShowPanel(true,nil,function ()
        ECGuideSkill.Instance():ShowGuideByID(guideID)
    end)
end

--根据配置和记录，找到当前需要进行的指引id
---@param self ECGuideSkillManager
---@param id number
---@return number
def.method("number","=>","number").GetShowGuideID = function(self,id)
    local GuideSkillState = UserData.Instance():GetRoleCfg("GuideSkillState") or {}
    local showed = GuideSkillState[id] or false
    --没完成的指引，直接进行
    if not showed then
        return id
    end
    --如果该指引已经完成了
    local config = ECGuideSkill.getGuideSkillConfig(id)
    if not config then
        return 0
    end
    --如果该引导支持重复
    if not config.guide_once then
        return id
    end
    --如果没有下一个自动引导id，则不引导了
    if config.next_guide_id <= 0 then
        return 0
    end

    return self:GetShowGuideID(config.next_guide_id)
end

---@param self ECGuideSkillManager
---@param id number
---@param time number
---@return void
def.method("number","number").prepareShowNext = function(self,id,time)
    local eCGuideSkill = ECGuideSkill.InstanceNotCreate()
    --同时只显示一份引导
    if eCGuideSkill then
        eCGuideSkill:DestroyPanel()
    end
    if self.m_TimerID and self.m_TimerID > 0 then
        GameUtil.RemoveGlobalTimer(self.m_TimerID)
        self.m_TimerID = 0
    end
    self.m_nextGuideId = id
    self.m_TimerID = GameUtil.AddGlobalTimer(time/1000, true, function()
        if ECGuideSkill.InstanceNotCreate() == nil then
            self.m_currentGuideId = self.m_nextGuideId
            self.m_nextGuideId = 0
            ECGuideSkillManager.Instance():ShowGuide(self.m_currentGuideId)
        end
    end)
end

---@param self ECGuideSkillManager
---@return void
def.method().onEnterJump = function(self)
    local eCGuideSkill = ECGuideSkill.InstanceNotCreate()
    if eCGuideSkill then
        eCGuideSkill:OnGuideSkillDoneByNotSkillBtn(CONSTANT_DEFINE.GUIDE_SKILL_BTNS.BTN_JUMP)
    end
end

---@param self ECGuideSkillManager
---@return void
def.method().OnSummonPeople = function(self)
    local eCGuideSkill = ECGuideSkill.InstanceNotCreate()
    if eCGuideSkill then
        eCGuideSkill:OnGuideSkillDoneByNotSkillBtn(CONSTANT_DEFINE.GUIDE_SKILL_BTNS.BTN_PEOPLE)
    end
end

ECGuideSkillManager.Commit()

return ECGuideSkillManager