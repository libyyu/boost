--[[
	指引中高亮标记某一控件
]]

local Lplus = require "Lplus"
local ECPanelBase = require "GUI.ECPanelBase"
local ECGuide = require "Guide.ECGuide"
local EC = require "Types.Vector3"
local ECFxMan = require "Fx.ECFxMan"

---@class Guide.ECPanelGuideFx:ECPanelBase
---@field protected m_path string
---@field public Commit fun():Guide.ECPanelGuideFx @notnull
---@field public Instance fun():Guide.ECPanelGuideFx
---@field public Popup fun(self:Guide.ECPanelGuideFx, path:string)
---@field public Destroy fun(self:Guide.ECPanelGuideFx)
---@field public Create fun(self:Guide.ECPanelGuideFx)
---@field public OnCreate fun(self:Guide.ECPanelGuideFx)
local ECPanelGuideFx = Lplus.Extend(ECPanelBase,"Guide.ECPanelGuideFx")
local l_instance = nil
do
	local def = ECPanelGuideFx.define

	---@return Guide.ECPanelGuideFx
	def.static("=>",ECPanelGuideFx).Instance = function()
		return l_instance
	end

	---@param self Guide.ECPanelGuideFx
	---@param path string
	---@return void
	def.method("string").Popup = function (self, path)
		self.m_path = path
		self:Create()
	end
	

	---@param self Guide.ECPanelGuideFx
	---@return void
	def.method().Destroy = function (self)
		self:DestroyPanel()
	end
	
	-------------------------------------------------
	--
	

	---@param self Guide.ECPanelGuideFx
	---@return void
	def.method().Create = function (self)
		self.m_depthLayer = GUIDEPTH.BOTTOM
		self:CreatePanel(RESPATH.Panel_GuideFx)
	end
	

	---@param self Guide.ECPanelGuideFx
	---@return void
	def.override().OnCreate = function (self)
		local fxControl = self.m_panel:FindChild("Widget")

		local SkillGfxParam = require"Fx.SkillGfxParam"
		local skillGfmParam = SkillGfxParam.new()
		skillGfmParam.resName = self.m_path
		skillGfmParam.transform = {}
		skillGfmParam.prio = FXPRIO.HIGH
		skillGfmParam.lifetime = INFINITE_DURATION
		skillGfmParam.needHighLod = false
		skillGfmParam.extendParam = {}
		skillGfmParam.extendParam.parent = fxControl
		skillGfmParam.extendParam.socketname = ""
		local fx = ECFxMan.Instance():PlayAsChild(skillGfmParam)
		if fx then
--			fx:GetComponent("FxOne"):Set_CanReplay(true)
			fx:SetLayer(ClientDef_Layer.UI)
		end
	end
	

	---@type string
	def.field("string").m_path = ""
end
ECPanelGuideFx.Commit()

l_instance = ECPanelGuideFx()

return ECPanelGuideFx
