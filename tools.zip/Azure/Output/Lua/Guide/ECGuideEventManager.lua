---
---@author chenshilei
---@date 2020/8/31 16:27
---@description
---

local Lplus = require "Lplus"

--
-- 更换武器时指引选择技能方案
--
---@class ECGuideChangeWeapon:System.Object
---@field public Commit fun():ECGuideChangeWeapon @notnull
---@field public new fun():ECGuideChangeWeapon
---@field public Start fun(self:ECGuideChangeWeapon)
local ECGuideChangeWeapon = Lplus.Class("ECGuideChangeWeapon")
local def = ECGuideChangeWeapon.define

---@return ECGuideChangeWeapon
def.final("=>", ECGuideChangeWeapon).new = function()
    local object = ECGuideChangeWeapon()
    return object
end

---@param self ECGuideChangeWeapon
---@return void
def.method().Start = function(self)
    MsgBox.ShowMsgBox(nil, StringTable.Get(717), nil, MsgBoxType.MBBT_OKCANCEL, function(_, ret)
        local ECGame = require "Main.ECGame"
        local ChangeWeaponGuideEvent = require "Event.ChangeWeaponGuideEvent"
        
        if ret == MsgBox.MsgBoxRetT.MBRT_OK then
            -- 选择系统方案，发送事件触发指引
            ECGame.EventManager:raiseEvent(self, ChangeWeaponGuideEvent.ChangeWeaponSystemPlanGuideEvent.new())
        elseif ret == MsgBox.MsgBoxRetT.MBRT_CANCEL then
            -- 选择自定义方案，发送事件触发指引
            ECGame.EventManager:raiseEvent(self, ChangeWeaponGuideEvent.ChangeWeaponCustomPlanGuideEvent.new())
        end
    end, nil, nil, nil, function(box)
        box:SetOkText(StringTable.Get(718))
        box:SetCancleText(StringTable.Get(719))
    end
    )
end

ECGuideChangeWeapon.Commit()

---
--- 程序触发指引的通用入口
---

---@class ECGuideEventManager:System.Object
---@field public Commit fun():ECGuideEventManager @notnull
---@field public Instance fun():ECGuideEventManager
---@field public StartChangeWeaponGuide fun(self:ECGuideEventManager)
local ECGuideEventManager = Lplus.Class("ECGuideEventManager")
local def = ECGuideEventManager.define

---@type ECGuideEventManager
local l_instance

---@return ECGuideEventManager
def.final("=>", ECGuideEventManager).Instance = function()
    if not l_instance then
        l_instance = ECGuideEventManager()
    end
    return l_instance
end

---@param self ECGuideEventManager
---@return void
def.method().StartChangeWeaponGuide = function(self)
    local guide = ECGuideChangeWeapon.new()
    guide:Start()
end

ECGuideEventManager.Commit()

return ECGuideEventManager