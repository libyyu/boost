--[[
	指引盖板
]]

local Lplus = require "Lplus"
local ECPanelBase = require "GUI.ECPanelBase"
local CleanerHelper = require "Utility.CleanerHelper"

---@class Guide.ECPanelGuideCover:ECPanelBase
---@field protected m_enabled boolean
---@field protected m_guideId number
---@field protected m_stepIndex number
---@field public Commit fun():Guide.ECPanelGuideCover @notnull
---@field public Instance fun():Guide.ECPanelGuideCover
---@field public Create fun(self:Guide.ECPanelGuideCover)
---@field public OnCreate fun(self:Guide.ECPanelGuideCover)
---@field private _EnableCoverInner fun(self:Guide.ECPanelGuideCover, bEnable:boolean)
---@field public EnableCover fun(self:Guide.ECPanelGuideCover, guideId:number, stepIndex:number)
---@field public DisableCoverNoStepCheck fun(self:Guide.ECPanelGuideCover)
---@field public DisableCover fun(self:Guide.ECPanelGuideCover, guideId:number, stepIndex:number)
---@field public OnDestroy fun(self:Guide.ECPanelGuideCover)
---@field public onClick fun(self:Guide.ECPanelGuideCover, id:string)
local ECPanelGuideCover = Lplus.Extend(ECPanelBase,"Guide.ECPanelGuideCover")
local l_instance = nil
do
	local def = ECPanelGuideCover.define

	---@return Guide.ECPanelGuideCover
	def.static("=>",ECPanelGuideCover).Instance = function()
		return l_instance
	end

	---@param self Guide.ECPanelGuideCover
	---@return void
	def.method().Create = function (self)
		self:CreatePanel(RESPATH.Panel_GuideCover)
	end
	

	---@param self Guide.ECPanelGuideCover
	---@return void
	def.override().OnCreate = function (self)
		self:_EnableCoverInner(self.m_enabled)
	end
	

	---@param self Guide.ECPanelGuideCover
	---@param bEnable boolean
	---@return void
	def.method("boolean")._EnableCoverInner = function (self, bEnable)
		self:disposeTimerCleaner()
		self.m_enabled = bEnable
		
		if not self.m_panel or self.m_panel:is_nil() then
			return
		end

		--warn("ECPanelGuideCover EnableCover",bEnable)
		
		self.m_panel:FindDirect("Widget"):SetActive(bEnable)
		if bEnable then
			--无论如何，等一会儿后解除挡板，以防万一
			local timer = GameUtil.AddGlobalTimer(30, true, function ()
				self:_EnableCoverInner(false)
			end)
			self:timerCleaner():add(function () GameUtil.RemoveGlobalTimer(timer) end)
		end

		if not bEnable then
			self.m_guideId = 0
			self.m_stepIndex = -1
		end
	end

	---@param self Guide.ECPanelGuideCover
	---@param guideId number
	---@param stepIndex number
	---@return void
	def.method("number", "number").EnableCover = function (self, guideId, stepIndex)
		self.m_guideId = guideId
		self.m_stepIndex = stepIndex
		self:_EnableCoverInner(true)
	end

	---@param self Guide.ECPanelGuideCover
	---@return void
	def.method().DisableCoverNoStepCheck = function (self)
		self:_EnableCoverInner(false)
	end

	---@param self Guide.ECPanelGuideCover
	---@param guideId number
	---@param stepIndex number
	---@return void
	def.method("number", "number").DisableCover = function (self, guideId, stepIndex)
		if self.m_guideId == guideId and self.m_stepIndex == stepIndex then
			self:DisableCoverNoStepCheck()
		end
	end

	-----------------------------------
	-- End of public
	

	---@param self Guide.ECPanelGuideCover
	---@return void
	def.override().OnDestroy = function (self)
		--warn("ECPanelGuideCover OnDestroy")
		self:disposeTimerCleaner()
	end

	---@param self Guide.ECPanelGuideCover
	---@param id string
	---@return void
	def.method("string").onClick = function (self, id)
		local ECPanelGuideHighlight = require "Guide.ECPanelGuideHighlight"
		local instance = ECPanelGuideHighlight.Instance()
		if instance.m_panel then
			instance:onClick(id)
		end
	end
	
	CleanerHelper.defineCleaner(def, "timerCleaner", "disposeTimerCleaner")

	---@type boolean
	def.field("boolean").m_enabled = false

	---@type number
	def.field("number").m_guideId = 0

	---@type number
	def.field("number").m_stepIndex = -1
end
ECPanelGuideCover.Commit()
l_instance = ECPanelGuideCover()
l_instance.m_uigroup_mask = UISHOWGROUP.ALL

return ECPanelGuideCover
