local Lplus = require "Lplus"
---@type ECGame
local ECGame = Lplus.ForwardDeclare("ECGame")
local NotifyClick = require "Event.NotifyClick"
local NotifyScroll = require "Event.NotifyScroll"
local StandbyEvents = require "Event.StandbyEvents"

---@class ECStandby:System.Object
---@field protected m_timer number
---@field protected m_elapse number
---@field protected m_info table
---@field protected m_times table
---@field public Commit fun():ECStandby @notnull
---@field public Instance fun():ECStandby
---@field public Init fun(self:ECStandby)
---@field public OnEnterGameLogic fun(self:ECStandby)
---@field public OnLeaveGameLogic fun(self:ECStandby)
---@field public Reset fun(self:ECStandby)
---@field public DestroyTimer fun(self:ECStandby)
---@field public Start fun(self:ECStandby)
---@field public GetTriggeredByIndex fun(self:ECStandby, index:number):boolean
---@field public GetElapse fun(self:ECStandby):number
---@field public GetTimes fun(self:ECStandby, index:number):number
---@field public ClearTimes fun(self:ECStandby, index:number)
---@field public AddTimes fun(self:ECStandby, index:number):boolean
local ECStandby = Lplus.Class("ECStandby")
local def = ECStandby.define
local m_instance = nil

local __is_idle = false

local function StartStandby()
    ECStandby.Instance():Start()
    __is_idle = true
end

local function ResetStandby()
    ECStandby.Instance():Reset()
    __is_idle = false
end

local function HandleClick()
    if __is_idle then
        ECStandby.Instance():Start()
    end
end

---@type number
def.field("number").m_timer = 0

---@type number
def.field("number").m_elapse = 0

---@type table
def.field("table").m_info = nil

---@type table
def.field("table").m_times = nil

---@return ECStandby
def.static("=>", ECStandby).Instance = function ()
    if not m_instance then
        m_instance = ECStandby()
        m_instance:Init()
    end
    return m_instance
end

---@param self ECStandby
---@return void
def.method().Init = function (self)
    local standby_config = _G.GetConfigLua("Configs/standby_config.lua")
    self.m_info = {}
    for k, v in ipairs(standby_config.trigger_time) do
        self.m_info[k] = { time = v, triggered = false }
    end

    self.m_times = {}
    for k, v in ipairs(standby_config.trigger_limit) do
        self.m_times[k] = { limit = v, times = 0 }
    end
end

---@param self ECStandby
---@return void
def.method().OnEnterGameLogic = function (self)
    -- 避免重复调用
    self:OnLeaveGameLogic()

    --self:Start()
    __is_idle = false

    ECGame.EventManager:addHandler(StandbyEvents.NotifyStartIdle, StartStandby)
    ECGame.EventManager:addHandler(StandbyEvents.NotifyEndIdle, ResetStandby)
    ECGame.EventManager:addHandler(NotifyClick, HandleClick)
    ECGame.EventManager:addHandler(NotifyScroll, HandleClick)
end

---@param self ECStandby
---@return void
def.method().OnLeaveGameLogic = function (self)
    self:Reset()
    for _, v in ipairs(self.m_times) do
        v.times = 0
    end

    ECGame.EventManager:removeHandler(StandbyEvents.NotifyStartIdle, StartStandby)
    ECGame.EventManager:removeHandler(StandbyEvents.NotifyEndIdle, ResetStandby)
    ECGame.EventManager:removeHandler(NotifyClick, HandleClick)
    ECGame.EventManager:removeHandler(NotifyScroll, HandleClick)
end

---@param self ECStandby
---@return void
def.method().Reset = function (self)
    self:DestroyTimer()
    self.m_elapse = 0
    for _, v in ipairs(self.m_info) do
        v.triggered = false
    end
end

---@param self ECStandby
---@return void
def.method().DestroyTimer = function (self)
    if self.m_timer ~= 0 then
        GameUtil.RemoveGlobalTimer(self.m_timer)
        self.m_timer = 0
    end
end

---@param self ECStandby
---@return void
def.method().Start = function (self)
    self:Reset()
    self.m_timer = GameUtil.AddGlobalTimer(1, false, function()
        self.m_elapse = self.m_elapse + 1

        local all_triggered = true
        for k, v in ipairs(self.m_info) do
            if self.m_elapse >= v.time then
                v.triggered = true
                if self.m_elapse == v.time then
                    ECGame.EventManager:raiseEvent(nil, StandbyEvents.TriggerStandby.new(k))
                end
            else
                v.triggered = false
                all_triggered = false
            end
        end

        if all_triggered and self.m_elapse > 0 then  --避免TriggerStandby->Start->AddGlobalTimer->DestroyTimer
            self:DestroyTimer()
        end
    end)
end

---@param self ECStandby
---@param index number
---@return boolean
def.method("number", "=>", "boolean").GetTriggeredByIndex = function (self, index)
    return self.m_info[index] and self.m_info[index].triggered or false
end

---@param self ECStandby
---@return number
def.method("=>", "number").GetElapse = function (self)
    return self.m_elapse
end

---@param self ECStandby
---@param index number
---@return number
def.method("number", "=>", "number").GetTimes = function (self, index)
    return self.m_times[index] and self.m_times[index].times or 0
end

---@param self ECStandby
---@param index number
---@return void
def.method("number").ClearTimes = function (self, index)
    if self.m_times[index] then
        self.m_times[index].times = 0
    end
end

---@param self ECStandby
---@param index number
---@return boolean
def.method("number", "=>", "boolean").AddTimes = function (self, index)
    local times_info = self.m_times[index]
    if times_info and times_info.times + 1 <= times_info.limit then
        times_info.times = times_info.times + 1
        return times_info.times < times_info.limit
    else
        return false
    end
end

return ECStandby.Commit()