local Lplus = require "Lplus"
local ECPanelBase = require "GUI.ECPanelBase"

---@class GUI.ECPanelGuideText:ECPanelBase
---@field public text string
---@field public offx number
---@field public offy number
---@field public imageIndex number
---@field public Commit fun():GUI.ECPanelGuideText @notnull
---@field public Instance fun():GUI.ECPanelGuideText
---@field public Create fun(self:GUI.ECPanelGuideText)
---@field public ShowGuideTextPanel fun(self:GUI.ECPanelGuideText, text:string, options:table)
---@field public OnCreate fun(self:GUI.ECPanelGuideText)
---@field public OnDestroy fun(self:GUI.ECPanelGuideText)
local ECPanelGuideText = Lplus.Extend(ECPanelBase,"GUI.ECPanelGuideText")
local l_instance = nil

local def = ECPanelGuideText.define
do

	---@type string
	def.field("string").text = ""

	---@type number
	def.field("number").offx = 0

	---@type number
	def.field("number").offy = 0

	---@type number
	def.field("number").imageIndex = 1

	---@return GUI.ECPanelGuideText
	def.static("=>",ECPanelGuideText).Instance = function()
		if (l_instance == nil) then
		    l_instance = ECPanelGuideText()
		    l_instance.m_uigroup_mask = bit.band(UISHOWGROUP.ALL,bit.bnot(UISHOWGROUP.CG),bit.bnot(UISHOWGROUP.SHOT),bit.bnot(UISHOWGROUP.SHARE))
		    l_instance.m_depthLayer = GUIDEPTH.TOPMOST1
		end
		return l_instance
	end

	---@param self GUI.ECPanelGuideText
	---@return void
	def.method().Create = function (self)
		self:CreatePanel(RESPATH.Panel_GuideWord)
	end

	local layers = 
	{
		[1] = GUIDEPTH.NORMALLESS,
		[2] = GUIDEPTH.TOP,
		[3] = GUIDEPTH.TOPMOST1,
	}

	--[[
		options: {image=1, offx=offx or 0, offy=offy or 0, layer=layer or 1, bInCG=not not bInCG}
	]]
	---@param self GUI.ECPanelGuideText
	---@param text string
	---@param options table
	---@return void
	def.method("string", "table").ShowGuideTextPanel = function(self, text, options)
		self.text = text
		self.offx = options.offx or 0
		self.offy = options.offy or 0
		self.imageIndex = options.image or 1
		self:SetDepth(layers[options.layer or 1] or GUIDEPTH.TOPMOST1)
		if options.bInCG then
			self.m_uigroup_mask = bit.bor(self.m_uigroup_mask,UISHOWGROUP.CG)	
		else
			self.m_uigroup_mask = bit.band(self.m_uigroup_mask,bit.bnot(UISHOWGROUP.CG)) 
		end
		if self.m_panel then
			self.m_panel:ChangeUIGroup(self.m_uigroup_mask)		
			self:OnCreate()
		else
			self:Create()
		end
	end
	
	---@param self GUI.ECPanelGuideText
	---@return void
	def.override().OnCreate = function(self)
		local switcher = self.m_panel:FindDirect("Switcher")
		local imageIndex = self.imageIndex
		switcher:SetActiveWidgetIndex(self.imageIndex - 1)
		local activeImage = switcher:GetActiveWidget()
		activeImage:FindDirect(("Group_Tips_%d/Txt_Word_%d"):format(imageIndex, imageIndex)):SetRichText(self.text)
		switcher:SetSlotPosition(self.offx,140 + self.offy)
	end
	
	---@param self GUI.ECPanelGuideText
	---@return void
	def.override().OnDestroy = function (self)
	end

end
ECPanelGuideText.Commit()
return ECPanelGuideText

