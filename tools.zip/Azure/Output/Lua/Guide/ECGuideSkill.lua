--------------------------------------------------------
----            技能引导
----            2020/7/24
----            xiongzhongmin
--------------------------------------------------------
local Lplus = require "Lplus"
local ECViewBase = require "GUI.ECViewBase"
local ECPanelBase = require "GUI.ECPanelBase"
local ECGUITools = require "GUI.ECGUITools"
local ElementData = require "Data.ElementData"
local GuideSkillEvent = require "Event.GuideSkillEvent"
local ECPanelMainOperation = require "GUI.Main.ECPanelMainOperation"
local FETimerHelper = require "Utility.FETimerHelper"
local GuideSkillCfg = _G.require_config("Configs/guide_skill_cfg.lua")
---@type ECGuideSkillManager
local ECGuideSkillManager = Lplus.ForwardDeclare("ECGuideSkillManager")

---@type ECGame
local ECGame = Lplus.ForwardDeclare("ECGame")

---@class SkillItemSlot:ECViewBase
---@field protected m_showArrow boolean
---@field protected m_info table
---@field public Commit fun():SkillItemSlot @notnull
---@field public CreateSlot fun(info:table):SkillItemSlot
---@field public OnDestroyInternal fun(self:SkillItemSlot)
---@field public OnCreate fun(self:SkillItemSlot)
---@field public UpdateUI fun(self:SkillItemSlot)
---@field public setState fun(self:SkillItemSlot, state:number)
---@field public SetShowArrow fun(self:SkillItemSlot, show:boolean)
---@field public showHideUpdateEffect fun(self:SkillItemSlot, show:boolean)
local SkillItemSlot = Lplus.Extend(ECViewBase)
do
    local def = SkillItemSlot.define

    ---@type boolean
    def.field("boolean").m_showArrow = true

    ---@type table
    def.field("table").m_info = nil

    ---@param info table
    ---@return SkillItemSlot
    def.static("table", "=>", SkillItemSlot).CreateSlot = function(info)
        local obj = SkillItemSlot()
        obj.m_info = info
        obj.m_showArrow = true
        return obj
    end

    ---@param self SkillItemSlot
    ---@return void
    def.override().OnDestroyInternal = function (self)
        ECViewBase.OnDestroyInternal(self)
    end

    ---@param self SkillItemSlot
    ---@return void
    def.override().OnCreate = function(self)
        self:UpdateUI()
    end

    ---@param self SkillItemSlot
    ---@return void
    def.method().UpdateUI = function(self)
        self:SetVisible(true)

        if not self.m_info then
            self.m_info = {}
        end

        local iconPath = 0
        if self.m_info.forceIcon and self.m_info.forceIcon > 0 then
            iconPath = self.m_info.forceIcon
        else
            iconPath = self.m_info.icon or 0
        end

        if iconPath ~= 0 then
            local iconImg = self:FindDirect("Widget/Icon")
            local imgPath = datapath.GetPathByID(iconPath)
            iconImg:SetActive(true)
            ECGUITools.UpdateGridImage(imgPath, iconImg)
        end

        ---@type ue.UWidgetSwitcher
        local stateIcon = self:FindDirect("Widget/State")
        if stateIcon then
            stateIcon:SetActiveWidgetIndex(0)
        end

        local state = self.m_info.state or 1
        self:setState(state)
    end

    ---@param self SkillItemSlot
    ---@param state number
    ---@return void
    def.method("number").setState = function(self, state)
        --state 1普通状态 2等待执行 3执行成功 4执行失败
        state = state or 1

        --发光
        local Guide_Light = self:FindDirect("Widget/Guide_Light")
        if Guide_Light then
            Guide_Light:SetActive(state == 2)
        end

        if state == 2 then
            self:PlayAnimationByName("Guide_Light_Ani",nil,nil,0)
        else
            self:StopAnimationByName("Guide_Light_Ani")
        end

        --成功
        ---@type ue.UWidgetSwitcher
        local stateIcon = self:FindDirect("Widget/State")
        if stateIcon then
            stateIcon:SetActive(state == 3 or state == 4)
            local index = 0
            if state == 4 then
                index = 1
            end
            stateIcon:SetActiveWidgetIndex(index)
        end

        --箭头
        ---@type ue.UWidgetSwitcher
        local arrow = self:FindDirect("Arrow1")
        if arrow and not arrow:is_nil() then
            local index = 0
            if state == 3 then
                index = 1
            end
            arrow:SetActiveWidgetIndex(index)
        end
    end

    ---@param self SkillItemSlot
    ---@param show boolean
    ---@return void
    def.method("boolean").SetShowArrow = function(self, show)
        self.m_showArrow = show
        ---@type ue.UWidgetSwitcher
        local arrow = self:FindDirect("Arrow1")
        if arrow and not arrow:is_nil() then
            arrow:SetActive(show)
        end
    end

    ---@param self SkillItemSlot
    ---@param show boolean
    ---@return void
    def.method("boolean").showHideUpdateEffect = function(self, show)
        if show then
            self:PlayAnimationByName("Update_Ani")
        else
            self:StopAnimationByName("Update_Ani")
        end
    end

    SkillItemSlot.Commit()
end

--[[
	主面板
]]
---@class ECGuideSkill:ECPanelBase
---@field protected m_guide_id number
---@field protected m_failed boolean
---@field protected m_finished boolean
---@field protected m_next_guide_id number
---@field protected m_next_guide_time number
---@field protected m_currentIndex number
---@field protected m_slotItems SkillItemSlot[]
---@field protected m_itemData table
---@field protected m_listView ue.UAzureFixedList
---@field protected m_timer FETimerHelper
---@field public Commit fun():ECGuideSkill @notnull
---@field public Instance fun():ECGuideSkill
---@field public InstanceNotCreate fun():ECGuideSkill
---@field public init fun(self:ECGuideSkill)
---@field public GetResPath fun(self:ECGuideSkill):string
---@field public getGuideSkillConfig fun(tid:number):any
---@field public ShowGuideByID fun(self:ECGuideSkill, guideid:number)
---@field public getIconIDByBtnAndSkill fun(self:ECGuideSkill, btn:number, skillid:number):number
---@field public reset fun(self:ECGuideSkill)
---@field public OnDestroy fun(self:ECGuideSkill)
---@field public OnCreate fun(self:ECGuideSkill)
---@field private _BindEventHandler fun(self:ECGuideSkill)
---@field public onSceneChange fun(self:ECGuideSkill)
---@field public fireFinishEvent fun(self:ECGuideSkill)
---@field public fireCanceledEvent fun(self:ECGuideSkill)
---@field public fireRetryEvent fun(self:ECGuideSkill)
---@field public SendCmd fun(self:ECGuideSkill, tid:number, success:boolean, op:number)
---@field public fireBeginEvent fun(self:ECGuideSkill)
---@field public onGuideSKillFailed fun(self:ECGuideSkill)
---@field public onGuideSKillDone fun(self:ECGuideSkill, skillid:number)
---@field public OnGuideSkillDoneByNotSkillBtn fun(self:ECGuideSkill, btnType:number)
---@field public updateGuideState fun(self:ECGuideSkill)
---@field public updateGuideDoneEffect fun(self:ECGuideSkill)
local ECGuideSkill = Lplus.Extend(ECPanelBase, "ECGuideSkill")
do
    local def = ECGuideSkill.define
    local l_instance

    ---@type number
    def.field("number").m_guide_id = 0

    ---@type boolean
    def.field("boolean").m_failed = false

    ---@type boolean
    def.field("boolean").m_finished = false

    ---@type number
    def.field("number").m_next_guide_id = 0

    ---@type number
    def.field("number").m_next_guide_time = 0

    ---当前正在引导第几步
    ---@type number
    def.field("number").m_currentIndex = 0

    ---@type SkillItemSlot[]
    def.field("table").m_slotItems = function()
        return {}
    end

    ---@type table
    def.field("table").m_itemData = function()
        return {}
    end

    ---@type ue.UAzureFixedList
    def.field("userdata").m_listView = nil

    ---@type FETimerHelper
    def.field(FETimerHelper).m_timer = nil

    ---@return ECGuideSkill
    def.final("=>",ECGuideSkill).Instance = function()
        if l_instance == nil then
            l_instance = ECGuideSkill()
            l_instance.m_EventPrivate = false
        end
        return l_instance
    end

    ---@return ECGuideSkill
    def.static("=>", ECGuideSkill).InstanceNotCreate = function()
        return l_instance
    end

    ---@param self ECGuideSkill
    ---@return void
    def.constructor().init = function (self)
        self.m_timer = FETimerHelper()
    end

    ---@param self ECGuideSkill
    ---@return string
    def.override("=>", "string").GetResPath = function(self)
        return RESPATH.Panel_Guide_Skill
    end

    ---@param tid number
    ---@return any
    def.static("number", "=>", "dynamic").getGuideSkillConfig = function (tid)
        return ElementData.getDataByConfigType(_G.CONSTANT_DEFINE.CONFIG_TYPE.CONFIG_GUIDE_SKILL, tid)
    end

    ---@param self ECGuideSkill
    ---@param guideid number
    ---@return void
    def.method("number").ShowGuideByID = function(self,guideid)
        self.m_guide_id = guideid
        self.m_itemData = {}
        self.m_slotItems = {}
        self.m_currentIndex = 1
        self.m_failed = false
        self.m_finished = false
        local _name = ""

        local guideSkillButtonCfgs = ECPanelMainOperation.Instance():GetGuideSkillButtonCfgs()
        --_G.CONSTANT_DEFINE.CHIP_TYPE_MASK.CHIP_AUTO_DODGE
        ---@type pb.Message.PB.GuideSkillConfig
        local config = ECGuideSkill.getGuideSkillConfig(guideid)
        if config then
            local num = #config.guide_skill_items
            local index = 1
            for i=1,num do
                local info = config.guide_skill_items[i]
                if info and info.btn > 0 then
                    local data = {}
                    data.btn = info.btn
                    data.forceIcon = info.force_icon_pathid
                    data.index = index
                    data.skillids = {}
                    data.skillids[info.skillid] = true
                    for i, skillId in ipairs(info.skillids) do
                        data.skillids[skillId] = true
                    end
                    data.duration = info.duration
                    if data.duration <= 0 then
                        data.duration = 5
                    end
                    data.state = 1 --state 1普通状态 2等待执行 3执行成功 4执行失败
                    data.icon = self:getIconIDByBtnAndSkill(info.btn,info.skillid)
                    table.insert(self.m_itemData,data)
                    index = index + 1
                end
            end

            _name = config.title

            self.m_next_guide_id = config.next_guide_id
            self.m_next_guide_time = config.time_show_next
        end

        local num = #self.m_itemData

        if self.m_listView then
            self.m_listView:SetCount(num)
            for i = 1, num do
                local itemObj =  self.m_listView:GetItemByIndex(i - 1)
                self.m_slotItems[i] = SkillItemSlot.CreateSlot(self.m_itemData[i])
                self:AttachSubView(itemObj, self.m_slotItems[i], false)
                self.m_slotItems[i]:SetShowArrow(i ~= num)
                self.m_slotItems[i]:UpdateUI()
            end
        end

        local title = self:FindDirect("Widget/Hint/Hint_Lab")
        if title then
            ECGUITools.setTextAndColor(title, _name)
        end

        self:updateGuideState()

        self:fireBeginEvent()
    end

    ---@param self ECGuideSkill
    ---@param btn number
    ---@param skillid number
    ---@return number
    def.method("number","number","=>","number").getIconIDByBtnAndSkill = function(self,btn,skillid)
        local ECPlayerSkillDesc = require "Skill.ECPlayerSkillDesc"
        local iconPath = 0
        if btn == _G.CONSTANT_DEFINE.GUIDE_SKILL_BTNS.BTN_JUMP then
            iconPath = 896
        else
            iconPath = ECPlayerSkillDesc.GetTriggerIcon(skillid)
        end
        return iconPath
    end

    ---@param self ECGuideSkill
    ---@return void
    def.method().reset = function(self)
        self.m_currentIndex = 1
        self.m_failed = false
        self:updateGuideState()
        self:fireBeginEvent()
    end

    ---@param self ECGuideSkill
    ---@return void
    def.override().OnDestroy = function(self)
        for _,v in pairs(self.m_slotItems) do
            if v then
                self:DetachSubView(v, true)
                v = nil
            end
        end
        self.m_slotItems = {}

        self.m_timer:RemoveAllTimer()
        if self.m_guide_id > 0 and not self.m_finished then
            self:fireCanceledEvent()
        end

        l_instance = nil
    end

    ---@param self ECGuideSkill
    ---@return void
    def.override().OnCreate = function(self)
        --注册事件更新
        self:_BindEventHandler()

        --设置格子更新处理
        self.m_listView = self:FindDirect("Widget/Sequence/Sequence_List")
    end

    --[[
        绑定事件处理
    ]]
    ---@param self ECGuideSkill
    ---@return void
    def.method()._BindEventHandler = function(self)
        local GuideSKillDoneStepEvent = GuideSkillEvent.GuideSKillDoneStepEvent
        self:AddHandlerAutoDelOnDestroy(GuideSKillDoneStepEvent, function(sender, event)
            if self then
                self:onGuideSKillDone(event.m_skillid)
            end
        end)

        local SceneChangeEvent = require "Event.SceneChangeEvent"
        local AfterSceneChangeEventHandler = function(sender, event)
            self:onSceneChange()
        end
        self:AddHandlerAutoDelOnDestroy(SceneChangeEvent.AfterSceneChangeEvent, AfterSceneChangeEventHandler)
    end

    ---@param self ECGuideSkill
    ---@return void
    def.method().onSceneChange = function(self)
        if not self then return end
        self:DestroyPanel()
    end

    ---@param self ECGuideSkill
    ---@return void
    def.method().fireFinishEvent = function(self)
        if not self or self.m_guide_id <= 0 then return end

        local UserData = require "Data.UserData"
        local GuideSkillState = UserData.Instance():GetRoleCfg("GuideSkillState") or {}
        GuideSkillState[self.m_guide_id] = true
        UserData.Instance():SetRoleCfg("GuideSkillState" , GuideSkillState)

        local GuideSKillFinishEvent = GuideSkillEvent.GuideSKillFinishEvent
        ECGame.EventManager:raiseEvent(self, GuideSKillFinishEvent.new(self.m_guide_id))

        self.m_timer:RemoveAllTimer()

        self.m_finished = true

        self:PlayAnimationByName("Finish_Anim")

        local duration = GuideSkillCfg.finishedDuration or 5
        self.m_timer:AddTimer("guidefinished", duration, true, function()
            self:DestroyPanel()

            if self.m_next_guide_id > 0 then
                ECGuideSkillManager.Instance():prepareShowNext(self.m_next_guide_id,self.m_next_guide_time)
            end
        end)
        self:SendCmd(self.m_guide_id, true,0)
    end

    ---@param self ECGuideSkill
    ---@return void
    def.method().fireCanceledEvent = function(self)
        if not self or self.m_guide_id <= 0 or self.m_finished then return end

        self.m_timer:RemoveAllTimer()

        local GuideSKillCanceledEvent = GuideSkillEvent.GuideSKillCanceledEvent
        ECGame.EventManager:raiseEvent(self, GuideSKillCanceledEvent.new(self.m_guide_id))
        self:SendCmd(self.m_guide_id, false,0)
    end

    ---@param self ECGuideSkill
    ---@return void
    def.method().fireRetryEvent = function(self)
        self:SendCmd(self.m_guide_id, false,1)
    end
    
    ---@param self ECGuideSkill
    ---@param tid number
    ---@param success boolean
    ---@param op number
    ---@return void
    def.method("number", "boolean", "number").SendCmd = function(self, tid, success,op)
        local client_msg = require "PB.client_msg"
        local pb_helper = require "PB.pb_helper"
        ---@type pb.Message.PB.gp_skill_guide_c2s
        local cmd = client_msg.gp_skill_guide_c2s()
        cmd.guide_tid = tid
        cmd.success = success
        cmd.op = op --0成功 1放错技能重新试
        pb_helper.Send(cmd)

        --print_jzw("SendCmd",tid,success,op)
    end
    
    ---@param self ECGuideSkill
    ---@return void
    def.method().fireBeginEvent = function(self)
        if not self or not self.m_itemData then return end

        local guideData = self.m_itemData[self.m_currentIndex]
        if not guideData then return end

        local GuideSKillBeginEvent = GuideSkillEvent.GuideSKillBeginEvent
        ECGame.EventManager:raiseEvent(self, GuideSKillBeginEvent.new(guideData.btn))

        --除了第一步，其他每一步都有一个有效时间，超过了就认为失败，重头开始
        self.m_timer:RemoveAllTimer()
        if self.m_currentIndex > 1 then
            local duration = guideData.duration or 5
            self.m_timer:AddTimer("guideduration", duration, true, function()
                self:reset()
            end)
        end
    end

    ---@param self ECGuideSkill
    ---@return void
    def.method().onGuideSKillFailed = function(self)
        local guideData = self.m_itemData[self.m_currentIndex]
        if not guideData then return end
        self.m_failed = true
        self:updateGuideState()

        self:fireRetryEvent()

        self.m_timer:RemoveAllTimer()
        local duration = GuideSkillCfg.failedDuration or 5
        self.m_timer:AddTimer("guidefailed", duration, true, function()
            self:reset()
        end)
    end

    ---技能引导步骤的完成判断是是否释放了某个指定的技能，所以这边不用管按钮id了
    ---@param self ECGuideSkill
    ---@param skillid number
    ---@return void
    def.method("number").onGuideSKillDone = function(self,skillid)
        local ignored = ECGuideSkillManager.Instance():isSKillIgnored(skillid)
        if ignored then return end
        --失败等待过程中，不处理
        if self.m_failed then return end

        local guideData = self.m_itemData[self.m_currentIndex]
        if not guideData then return end
        if not guideData.skillids[skillid] then--没有按照步骤走，重新开始
            self:onGuideSKillFailed()
            return
        end

        self:updateGuideDoneEffect()

        local num = #self.m_itemData
        self.m_currentIndex = self.m_currentIndex + 1
        self:updateGuideState()
        if self.m_currentIndex > num then--完成了
            self:fireFinishEvent()
        else
            self:fireBeginEvent()
        end
    end

    ---非技能操作做特殊处理
    ---@param self ECGuideSkill
    ---@param btnType number CONSTANT_DEFINE.GUIDE_SKILL_BTNS
    ---@return void
    def.method("number").OnGuideSkillDoneByNotSkillBtn = function(self, btnType)
        local guideData = self.m_itemData[self.m_currentIndex]
        if not guideData then return end

        --失败等待过程中，不处理
        if self.m_failed then return end

        if guideData.btn ~= btnType then
            self:onGuideSKillFailed()
            return
        end

        self:updateGuideDoneEffect()

        local num = #self.m_itemData
        self.m_currentIndex = self.m_currentIndex + 1
        self:updateGuideState()
        if self.m_currentIndex > num then--完成了
            self:fireFinishEvent()
        else
            self:fireBeginEvent()
        end
    end

    ---@param self ECGuideSkill
    ---@return void
    def.method().updateGuideState = function(self)
        --print_jzw("updateGuideState",debug.traceback())
        for i,v in pairs(self.m_itemData) do
            --state 1普通状态 2等待执行 3执行成功 4执行失败
            local nowState = 1
            if v.index == self.m_currentIndex then--正在等待执行
                nowState = self.m_failed and 4 or 2
            elseif v.index < self.m_currentIndex then--已经执行过了
                nowState = 3
            else
                nowState = 1
            end
            v.state = nowState
            local itemCell = self.m_slotItems[i]
            if itemCell then
                itemCell:setState(nowState)
            end
        end
    end

    ---@param self ECGuideSkill
    ---@return void
    def.method().updateGuideDoneEffect = function(self)
        if not self or not self.m_slotItems then return end

        local itemCell = self.m_slotItems[self.m_currentIndex]
        if itemCell then
            itemCell:showHideUpdateEffect(true)
        end
    end

    ECGuideSkill.Commit()
end

return ECGuideSkill
