--[[
	指引存盘记录
]]

local Lplus = require "Lplus"
local UserData = require "Data.UserData"
local USER_DATA_KEY = "guide_save_data"
local GcCallbacks = require "Utility.GcCallbacks"
local Task = require "Utility.Task"
local ECAsyncTask = require "Utility.ECAsyncTask"
local Callbacks = require "Utility.Callbacks"

---@class Guide.ECGuideSaveData:System.Object
---@field protected m_cleaner GcCallbacks
---@field protected m_data table
---@field protected m_dataReady boolean
---@field protected m_initCallbacks Callbacks
---@field public Commit fun():Guide.ECGuideSaveData @notnull
---@field public Instance fun():Guide.ECGuideSaveData
---@field public AddInitCallback fun(self:Guide.ECGuideSaveData, callback:function)
---@field public Init fun(self:Guide.ECGuideSaveData, data:string)
---@field public Release fun(self:Guide.ECGuideSaveData)
---@field public IsFinished fun(self:Guide.ECGuideSaveData, id:number):boolean
---@field public SetFinishState fun(self:Guide.ECGuideSaveData, id:number, bFinished:boolean)
---@field public ResetAllFinishState fun(self:Guide.ECGuideSaveData)
---@field public ResetAllFinishStateWithCB fun(self:Guide.ECGuideSaveData, cb:function)
---@field public GetAllState fun(self:Guide.ECGuideSaveData):table
---@field public initData fun(self:Guide.ECGuideSaveData, rawData:string)
local ECGuideSaveData = Lplus.Class("Guide.ECGuideSaveData")
local l_instance
do
	local def = ECGuideSaveData.define
	
	local function toTrueOrNil (v)
		if v then
			return true
		else
			return nil
		end
	end

	---@return Guide.ECGuideSaveData
	def.static("=>", ECGuideSaveData).Instance = function ()
		return l_instance
	end

	---@param self Guide.ECGuideSaveData
	---@param callback function
	---@return void
	def.method("function").AddInitCallback = function (self, callback)
		if self.m_dataReady then
			callback()
			return
		end

		self.m_initCallbacks = self.m_initCallbacks or Callbacks()
		self.m_initCallbacks:add(callback)
	end

	---@param self Guide.ECGuideSaveData
	---@param data string
	---@return void
	def.method("string").Init = function (self, data)
		l_instance:Release()
		
		self.m_cleaner = GcCallbacks()
		
		self:initData(data)

		local S2CManager = require "S2C.S2CManager"
		local help_mask_change = require "S2C.help_mask_change"
		
		S2CManager.AddHandlerWithCleaner(help_mask_change, function (sender, p)
			self.m_data[p.index] = toTrueOrNil(p.value)
		end, self.m_cleaner)

		self.m_dataReady = true
		if self.m_initCallbacks then
			self.m_initCallbacks:invokeAndClear()
		end
	end

	---@param self Guide.ECGuideSaveData
	---@return void
	def.method().Release = function (self)
		if self.m_cleaner then
			self.m_cleaner:dispose()
		end
		self.m_dataReady = false
	end
	

	---@param self Guide.ECGuideSaveData
	---@param id number
	---@return boolean
	def.method("number", "=>", "boolean").IsFinished = function (self, id)
		return not not self.m_data[id]
	end


	---@param self Guide.ECGuideSaveData
	---@param id number
	---@param bFinished boolean
	---@return void
	def.method("number", "boolean").SetFinishState = function (self, id, bFinished)
		if self.m_data[id] ~= bFinished then
			self.m_data[id] = toTrueOrNil(bFinished)		--本地直接改应该没问题
			
			local helpmask_set = require "C2S.helpmask_set"
			if id <= helpmask_set.MAX_INDEX then
				local cmd = helpmask_set.new(id, bFinished)
				
				local ECGame = require "Main.ECGame"
				ECGame.Instance().m_Network:SendGameData(cmd)
			else
				warn("guide id too large to save: ", id)
			end
		end
	end
	

	---@param self Guide.ECGuideSaveData
	---@return void
	def.method().ResetAllFinishState = function (self)
		for id, value in pairs(self.m_data) do
			if value then
				self:SetFinishState(id, false)
			end
		end
	end

	-- 清完状态回调一下
	---@param self Guide.ECGuideSaveData
	---@param cb function
	---@return void
	def.method("function").ResetAllFinishStateWithCB = function(self, cb)

		local S2CManager = require "S2C.S2CManager"
		local help_mask_change = require "S2C.help_mask_change"

		local function restoreHandler()
			if self.m_cleaner then
				self.m_cleaner:dispose()
			end
			S2CManager.AddHandlerWithCleaner(help_mask_change, function (sender, p)
				self.m_data[p.index] = toTrueOrNil(p.value)
			end, self.m_cleaner)
		end

		local task = Task.createStepsEx(function(task, step)
			if step == 1 then
				return function(task, resumeEntry)
					local count = 0

					-- 清一下旧的协议响应函数
					if self.m_cleaner then
						self.m_cleaner:dispose()
					end

					-- 等待所有C2S协议的返回
					S2CManager.AddHandlerWithCleaner(help_mask_change, function (sender, p)
						self.m_data[p.index] = toTrueOrNil(p.value)
						count = count - 1
						if count == 0 then
							resumeEntry()
						end
					end, self.m_cleaner)

					for id, value in pairs(self.m_data) do
						if value then
							if self:SetFinishState(id, false) then
								count = count + 1
							end
						end
					end

					if count == 0 then resumeEntry() end
				end
			else
				restoreHandler()
				if cb then cb() end
				return "end"
			end
		end, function() restoreHandler() return "stop" end)

		ECAsyncTask.AddTimeLimit(task, 5):start()
	end

	---@param self Guide.ECGuideSaveData
	---@return table
	def.method("=>", "table").GetAllState = function (self)
		return self.m_data
	end

	-------------------------------------------
	-- End of public
	

	---@type GcCallbacks
	def.field(GcCallbacks).m_cleaner = nil
	
	-- {[id] = true/nil}

	---@type table
	def.field("table").m_data = function () return {} end

	---@type boolean
	def.field("boolean").m_dataReady = false

	---@type Callbacks
	def.field(Callbacks).m_initCallbacks = nil
	

	---@param self Guide.ECGuideSaveData
	---@param rawData string
	---@return void
	def.method("string").initData = function (self, rawData)
		-- clear
		for k, v in pairs(self.m_data) do
			self.m_data[k] = nil
		end

		for iByte = 0, #rawData-1 do
			local byte = rawData:byte(iByte+1)
			for iBit = 0, 7 do
				if bit.band(byte, bit.lshift(1, iBit)) ~= 0 then
					self.m_data[iByte*8 + iBit] = true
				end
			end
		end
	end
end
ECGuideSaveData.Commit()

l_instance = ECGuideSaveData()

return ECGuideSaveData
