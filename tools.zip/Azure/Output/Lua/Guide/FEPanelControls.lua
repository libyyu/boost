local Lplus = require "Lplus"
---@type ConditionOp
local ConditionOp = Lplus.ForwardDeclare("ConditionOp")
local GcCallbacks = require "Utility.GcCallbacks"
local Callbacks = require "Utility.Callbacks"
---@type ECPanelBase
local ECPanelBase = Lplus.ForwardDeclare("ECPanelBase")
local FEConditionMaker = require "Utility.FEConditionMaker"

local l_allConfigs = {} --_G.GetConfigLua("Configs/panel_controls.lua"):getAllConfigs()
local l_panelConfigMap = {} --存储跟panel有关的配置信息
do
	for name, config in pairs(l_allConfigs) do
		local entry = config.entry
		if entry then
			for _, oneEntry in ipairs(config.entry) do
				if oneEntry.pos[1] then
					local panelName = oneEntry.pos[1]
					l_panelConfigMap[panelName] = l_panelConfigMap[panelName] or {}
					table.insert(l_panelConfigMap[panelName], config)
				end
			end
		end
	end
end

---@class FEPanelControls:System.Object
---@field protected m_stateMap table
---@field protected m_cleaner GcCallbacks
---@field public Commit fun():FEPanelControls @notnull
---@field public Release fun()
---@field public Init fun()
---@field public ReloadState fun()
---@field public RefreshUI fun(panel:ECPanelBase)
---@field public GetConfig fun(name:string):table
---@field public GetParentConfig fun(name:string):table
---@field public eachConfig fun(name:string):table
---@field public GetState fun(name:string):boolean
---@field public PrintState fun(name:string)
---@field public StartListen fun(self:FEPanelControls)
---@field public StopListen fun(self:FEPanelControls)
---@field public onState fun(name:string)
---@field public freshControlState fun(name:string)
---@field public waitState fun(name:string, StateInfo:table)
---@field public createCondOp fun(config:table):ConditionOp
---@field public makeCond fun(condition:table):ConditionOp
local FEPanelControls = Lplus.Class("FEPanelControls")
do
	local l_instance = nil
	local l_conditions = {}

	local def = FEPanelControls.define
	

	---@return void
	def.static().Release = function()
		--1.销毁所有的condition
		--1.销毁callbacks
		if l_instance then
			l_instance:StopListen()
			if l_instance.m_cleaner ~= nil then
				l_instance.m_cleaner:dispose()
			end
			l_instance.m_cleaner = nil
		end	
		l_instance = nil
	end

	---@return void
	def.static().Init = function()
		FEPanelControls.Release()

		l_instance = FEPanelControls()
		l_instance.m_cleaner = GcCallbacks()

		l_instance:StartListen()

		--TaskInit
		local ECGame = require "Main.ECGame"
		local TaskInitEvent = require "Event.TaskEvents".TaskInitEvent
		ECGame.EventManager:addHandlerWithCleaner(TaskInitEvent, function (sender, event)
			if l_instance then
				l_instance:StopListen()
				l_instance:StartListen()
				FEPanelControls.ReloadState()
			end
		end, l_instance.m_cleaner)

		local HostSkillInitDataEvent = require "Event.HostSkillEvents".HostSkillInitDataEvent
		ECGame.EventManager:addHandlerWithCleaner(HostSkillInitDataEvent, function (sender, event)
			FEPanelControls.ReloadState()
		end, l_instance.m_cleaner)

		-- local AchievementInitEvent = require "Event.PlayerTitleUpdateEvent".AchievementInitEvent
		-- ECGame.EventManager:addHandlerWithCleaner(AchievementInitEvent, function (sender, event)
		-- 	FEPanelControls.ReloadState()
		-- end, l_instance.m_cleaner)
	end

	---@return void
	def.static().ReloadState = function()
		for name, config in pairs(l_allConfigs) do
			local StateInfo = l_instance.m_stateMap[name]
			if not StateInfo.state and StateInfo.condOp and StateInfo.condOp:getState() then
				StateInfo.state = true
				FEPanelControls.onState(name)
			end
		end
	end

	---@param panel ECPanelBase
	---@return void
	def.static(ECPanelBase).RefreshUI = function (panel)
		if not panel.m_panel then
			warn("panel not created when RefreshUI: " .. tostring(panel))
			return
		end
		
		local panelName = panel.m_panelName
		local panelConfigs = l_panelConfigMap[panelName]
		if not panelConfigs then return end
		
		for _, config in pairs(panelConfigs) do
			FEPanelControls.freshControlState(config.name)
		end
	end

	---@param name string
	---@return table
	def.static("string", "=>", "table").GetConfig = function(name)
		return l_allConfigs[name]
	end

	---@param name string
	---@return table
	def.static("string", "=>", "table").GetParentConfig = function(name)
		-- for chain_name, chain_config in FEPanelControls.eachConfig(name) do
		-- 	if chain_name ~= name then
		-- 		return chain_config
		-- 	end
		-- end
		-- return nil
		local parent_name = l_allConfigs[name].parent
		if parent_name then
			return FEPanelControls.GetConfig(parent_name)
		else
			return nil
		end
	end

	local function nextConfig (firstName, curName)
		if not curName then
			return firstName, FEPanelControls.GetConfig(firstName)
		else
			local curConfig = FEPanelControls.GetConfig(curName)
			local parent = curConfig.parent
			if parent then
				return parent, FEPanelControls.GetConfig(parent)
			else
				return nil, nil
			end
		end
	end

	---@param name string
	---@return table
	def.static("string", "=>", "varlist").eachConfig = function (name)
		return nextConfig, name, nil
	end

	---@param name string
	---@return boolean
	def.static("string", "=>", "boolean").GetState = function(name)
		if l_instance and l_instance.m_stateMap[name] then
			return not not l_instance.m_stateMap[name].state
		else
			return false
		end
	end

	---@param name string
	---@return void
	def.static("string").PrintState = function(name)
		local self = l_instance
		if not self then return end
		if name == "" then
			for k, StateInfo in pairs( self.m_stateMap ) do
				warn(">>>>>>>>>>>>>>>>>>>>>>>>>>>name=", k, ", state=", StateInfo.state)
			end
		elseif self.m_stateMap[name] then
			local StateInfo = self.m_stateMap[name]
			warn(">>>>>>>>>>>>>>>>>>>>>>>>>>>name=", name, ", state=", StateInfo.state)
		else
			warn(name .. " not found!!!")
		end
	end

	-----------------------------------------
	--End Public

-----------------------------------------
	---@type table
	def.field("table").m_stateMap = function () return {} end

	---@type GcCallbacks
	def.field(GcCallbacks).m_cleaner = nil

	---@param self FEPanelControls
	---@return void
	def.method().StartListen = function(self)
		for name, config in pairs(l_allConfigs) do
			local condOp = FEPanelControls.createCondOp(config)
			if condOp then
				assert(condOp:hasState() and condOp:canWait())

				local state = condOp:getState()
				local StateInfo = { state = state, }		
				if not state or condOp:isVolatile() then
					StateInfo.condOp = condOp
					FEPanelControls.waitState(name, StateInfo)
				end

				--存储
				self.m_stateMap[name] = StateInfo
			else
				--无条件
				self.m_stateMap[name] = {state = true, }
			end
		end

		--更新所有初始状态
		for name, _ in pairs(l_allConfigs) do
			FEPanelControls.onState(name)
		end
	end

	---@param self FEPanelControls
	---@return void
	def.method().StopListen = function(self)
		for name, StateInfo in pairs(self.m_stateMap) do
			if StateInfo.condOp then
				StateInfo.condOp:forcedStopWaiting()
				StateInfo.condOp = nil
			end
			l_conditions[name] = nil
		end
		self.m_stateMap = {}
		l_conditions = {}
	end

	---@param name string
	---@return void
	def.static("string").onState = function(name)
		local self = l_instance
		if not self then return end
		local state = self.m_stateMap[name] and self.m_stateMap[name].state or false
		FEPanelControls.freshControlState(name)
	end


	local function panel_name_2_module(panel_name)
		--debug
		if panel_name == "panel_announcement" then
			return require "GUI.ECPanelAnnouncement".Instance()
		end
		return nil
	end

	local function find_ui_or_panel(panel_name, ...)
		local ECGUIMan = require "GUI.ECGUIMan"
		local panel = ECGUIMan.Instance():FindPanelByName(panel_name)
		if select("#", ...) == 0 then
			return panel
		end
		local ECHostConditionOp = require "Players.ECHostConditionOp"
		return ECHostConditionOp.Executor.find_ui(panel_name, ...)
	end

	-- 在parent中找到componentType, 到 panelName 为止
	local function findComponentInParent (control, componentType, panelName, ...)
		if not control then
			return nil
		end
		
		local parent = control.parent
		while parent and parent.name ~= panelName do
			local component = parent:GetComponent(componentType)
			if component then
				return component
			end
			
			parent = parent.parent
		end
		
		return nil
	end

	---@param name string
	---@return void
	def.static("string").freshControlState = function(name)
		local config = FEPanelControls.GetConfig(name)
		for _, oneEntry in ipairs(config.entry) do	--entry 中有指定多个控件
			repeat
				local style = oneEntry.style
				local panelName = oneEntry.pos[1]
				local is_panel = #oneEntry.pos == 1
				local state = FEPanelControls.GetState(name)
				--需要隐藏
				if not state then
					local control = find_ui_or_panel(unpack(oneEntry.pos))
					if not control then
						break
					end

					if not style or style == "simple" then
						if is_panel then
							control:SetVisible(false)
						else
							control:SetActive(false)
						end
					elseif style == "layer" then
						control:SetLayer(ClientDef_Layer.Invisible)
					elseif style == "UITable" or style == "UIGrid" or style == "UIList" then
						local uiContainer = findComponentInParent(control, style, unpack(oneEntry.pos))
						if not uiContainer then
							break
						end
						control:SetActive(false)
						GameUtil.AddGlobalTimer(0, true, function()
							local control = find_ui_or_panel(unpack(oneEntry.pos))
							local uiContainer = findComponentInParent(control, style, unpack(oneEntry.pos))
							if uiContainer and FEPanelControls.GetState(name) == state then
								--暂时不做合并
								if style == "UITable" then
									uiContainer:Reposition()
								elseif style == "UIGrid" then
									uiContainer:Reposition()
								elseif style == "UIList" then
									uiContainer:Reposition()
								end
							end
						end)
					end
				else
					local panel = panel_name_2_module(panelName)
					if not panel then
						warn(("failed to load module '%s'"):format(panelName))
						break
					end

					if style == "layer" then
						panel:SetLayer(ClientDef_Layer.UI)
					end
					--打开界面
					if not panel.m_panel then
						panel:SetVisible(true)
					end
					if is_panel then
						break
					end

					local control = find_ui_or_panel(unpack(oneEntry.pos))
					if not control then
						break
					end

					if not style or style == "simple" then
						control:SetActive(true)
					elseif style == "layer" then
						control:SetLayer(ClientDef_Layer.UI)
					elseif style == "UITable" or style == "UIGrid" or style == "UIList" then
						local uiContainer = findComponentInParent(control, style, unpack(oneEntry.pos))
						if not uiContainer then
							break
						end
						control:SetActive(true)
						GameUtil.AddGlobalTimer(0, true, function()
							local control = find_ui_or_panel(unpack(oneEntry.pos))
							local uiContainer = findComponentInParent(control, style, unpack(oneEntry.pos))
							if uiContainer and FEPanelControls.GetState(name) == state then
								--暂时不做合并
								if style == "UITable" then
									uiContainer:Reposition()
								elseif style == "UIGrid" then
									uiContainer:Reposition()
								elseif style == "UIList" then
									uiContainer:Reposition()
								end
							end
						end)
					end
				end	
			until true
		end
	end

	---@param name string
	---@param StateInfo table
	---@return void
	def.static("string", "table").waitState = function(name, StateInfo)
		local condOp = StateInfo.condOp
		if not condOp then
			error("condOp must not be null")
			return
		end

		condOp:wait(function(op)
			if condOp:getState() then
				--1. 停止监听
				condOp:stopWaiting()
				--2. 删除非易变的
				if not condOp:isVolatile() then
					 StateInfo.condOp = nil
					 l_conditions[name] = nil
				end
				--3. 处理结果
				if not StateInfo.state then
					StateInfo.state = true
					FEPanelControls.onState(name)
				end
			else
				--像活动等，会变化的
				StateInfo.state = false
				FEPanelControls.onState(name)
			end
		end)
	end

	---@param config table
	---@return ConditionOp
	def.static("table", "=>", ConditionOp).createCondOp = function(config)
		if l_conditions[config.name] then
			return l_conditions[config.name]
		end

		--基础满足条件是parent
		local parentConfig = FEPanelControls.GetParentConfig(config.name)
		local parentCond = parentConfig and FEPanelControls.createCondOp(parentConfig) or nil
		local rtCondOp = parentCond


		local condition = config.condition
		if not condition or #condition == 0 then
			return rtCondOp
		end
		--必须是奇数个
		if math.fmod(#condition, 2) ~= 1 then
			error(("condition: '%s' has invalid count: %d"):format(config.name, #condition))
		end	

		for i=1, #condition do
			local condOp = FEPanelControls.makeCond(condition[i])
			condOp:setTag(config.name)
			if not rtCondOp then
				rtCondOp = condOp
			else
				rtCondOp = FEConditionMaker.combine(rtCondOp, condOp, false)
				rtCondOp:setTag(condOp.tag)
			end
		end

		--保存Cond, 避免多个
		l_conditions[config.name] = rtCondOp

		return rtCondOp
	end

	---@param condition table
	---@return ConditionOp
	def.static("table", "=>", ConditionOp).makeCond = function(condition)
		local type_ = condition.type
		local value = condition.value

		local condOp = FEConditionMaker.create(type_, value)

		if not condOp then
			error(("invalid condition type: %s"):format(type_))
		end

		return condOp
	end

	FEPanelControls.Commit()
end

return FEPanelControls
