--安卓系统下的return按钮
local Lplus = require "Lplus"
---@type ECPanelBase
local ECPanelBase = Lplus.ForwardDeclare("ECPanelBase")
---@type ECGame
local ECGame = Lplus.ForwardDeclare("ECGame")

---@class PanelBehaviorSingleList:System.Object
---@field public count number
---@field public data table
---@field public Commit fun():PanelBehaviorSingleList
---@field public new fun():PanelBehaviorSingleList
---@field public Push fun(self:PanelBehaviorSingleList, t:table, pos:number)
---@field public Pop fun(self:PanelBehaviorSingleList, pos:number):table
---@field public Data fun(self:PanelBehaviorSingleList, pos:number):table
---@field public Front fun(self:PanelBehaviorSingleList):table
---@field public Size fun(self:PanelBehaviorSingleList):number
---@field public Clear fun(self:PanelBehaviorSingleList)
local PanelBehaviorSingleList = Lplus.Class("PanelBehaviorSingleList")
do
	local def = PanelBehaviorSingleList.define

	---@type number
	def.field("number").count = 0

	---@type table
	def.field("table").data = nil

	---@return PanelBehaviorSingleList
	def.static("=>",PanelBehaviorSingleList).new = function()
		local self = PanelBehaviorSingleList()
		self.count = 0
		self.data = {}
		return self
	end

	---@param self PanelBehaviorSingleList
	---@param t table
	---@param pos number
	---@return void
	def.method("table","number").Push = function(self,t,pos)
		table.insert(self.data,pos,t)
		self.count = self.count + 1
	end

	---@param self PanelBehaviorSingleList
	---@param pos number
	---@return table
	def.method("number","=>","table").Pop = function(self,pos)
		local t = table.remove(self.data,pos)
		self.count = self.count - 1
		return t
	end

	---@param self PanelBehaviorSingleList
	---@param pos number
	---@return table
	def.method("number","=>","table").Data = function(self,pos)
		return self.data[pos]
	end

	---@param self PanelBehaviorSingleList
	---@return table
	def.method("=>","table").Front = function(self)
		return self.data[1]
	end

	---@param self PanelBehaviorSingleList
	---@return number
	def.method("=>","number").Size = function(self)
		return self.count
	end

	---@param self PanelBehaviorSingleList
	---@return void
	def.method().Clear = function(self)
		self.data = {}
		self.count = 0
	end
	PanelBehaviorSingleList.Commit()
end



---@class ECFunctionReturn:System.Object
---@field public stack_ PanelBehaviorSingleList
---@field public Components table
---@field public Commit fun():ECFunctionReturn
---@field public new fun():ECFunctionReturn
---@field public ResetReturns fun()
---@field public Filter fun(panel:ECPanelBase):boolean
---@field public onPanelCreate fun(panel:ECPanelBase)
---@field public onPanelDestroy fun(panel:ECPanelBase)
---@field public FindPanelFromContainer fun(panel:ECPanelBase):number
---@field public FindReturnComponentByNPriority fun(comps:table):number
---@field public doReturn fun()
---@field public CheckClosedPanel fun()
---@field public PrintStack fun()
local ECFunctionReturn = Lplus.Class("ECFunctionReturn")
local l_instance = nil
do
	local def = ECFunctionReturn.define

	---@type PanelBehaviorSingleList
	def.field(PanelBehaviorSingleList).stack_ = nil

	---@type table
	def.field("table").Components = nil 

	---@return ECFunctionReturn
	def.static("=>",ECFunctionReturn).new = function()
		local self = ECFunctionReturn()
		self.stack_ = PanelBehaviorSingleList.new()
		self.Components = {}
		return self
	end

	---@return void
	def.static().ResetReturns = function()
		if l_instance.stack_ then
			l_instance.stack_:Clear()
		else
			l_instance.stack_ = PanelBehaviorSingleList.new()
		end
	end

	---@param panel ECPanelBase
	---@return boolean
	def.static(ECPanelBase,"=>","boolean").Filter = function(panel)
		if not panel.m_panel or panel.m_panel:is_nil() then return false end
		if l_instance.Components[panel.m_panelName] then return true end
		local comps = panel.m_panel:GetComponentsInChildren("ECReturnComponent",true)
		if not comps or #comps == 0 then return false end
		l_instance.Components[panel.m_panelName] = true
		return true
	end

	---@param panel ECPanelBase
	---@return void
	def.static(ECPanelBase).onPanelCreate = function(panel)
		if _G.platform == PLATFORM_TYPE_IOS then return end --IOS没有返回键功能
		local has_return = ECFunctionReturn.Filter(panel)
		if not has_return then
			return
		end
		local panel_name = panel.m_panelName
		local behavior = {}
		behavior.name = panel_name
		behavior.panel = panel
		behavior.is_return = true
		l_instance.stack_:Push(behavior,1)
		--print(("Push: {name:'%s',is_return:%d},stack_::size:%d"):format(behavior.name,behavior.is_return and 1 or 0,l_instance.stack_:Size()))
	end

	---@param panel ECPanelBase
	---@return void
	def.static(ECPanelBase).onPanelDestroy = function(panel)
		if _G.platform == PLATFORM_TYPE_IOS then return end
		if not l_instance.Components[panel.m_panelName] then
			return
		end
		local panel_name = panel.m_panelName
		local behavior = l_instance.stack_:Front()
		if not behavior then
			warn("onPanelDestroy: stack data is nil")
			return
		end
		--出栈顺序和入栈顺序不匹配
		if behavior.is_return and behavior.name ~= panel_name then
			warn("stack data not match!")
			local pos = ECFunctionReturn.FindPanelFromContainer(panel)
			if pos >0 then
				l_instance.stack_:Pop(pos)		
				warn(("Pop: {name:'%s',pos: %d},stack_::size:%d"):format(panel_name,pos,l_instance.stack_:Size()))
			end
			return
		end
		l_instance.stack_:Pop(1)
		--print(("Pop: {name:'%s',is_return:%d},stack_::size:%d"):format(behavior.name,behavior.is_return and 1 or 0,l_instance.stack_:Size()))
	end

	---@param panel ECPanelBase
	---@return number
	def.static(ECPanelBase,"=>","number").FindPanelFromContainer = function(panel)
		for i=1, l_instance.stack_:Size() do
			local behavior = l_instance.stack_:Data(i)
			if behavior.is_return and behavior.panel == panel then
				return i
			end
		end
		return 0
	end

	---@param comps table
	---@return number
	def.static("table","=>","number").FindReturnComponentByNPriority = function(comps)
		if not comps then return 0 end
		for i,comp in ipairs(comps) do
			if comp.gameObject:get_activeInHierarchy() then
				return i
			end
		end
		return 0
	end
	--执行Return事件

	---@return void
	def.static().doReturn = function()
		if l_instance.stack_:Size() == 0 then --退出游戏
			warn("exit game......")
			ECGame.Instance():ShowQuitTips()
		else
			ECFunctionReturn.CheckClosedPanel()

			local behavior = l_instance.stack_:Front()
			if not behavior then
				warn("doReturn: stack data is nil")
				return
			end
			if not behavior.is_return then
				warn("stack data top is wrong,panel excepted")
				return
			end
			local panel_name = behavior.name
			local panel = behavior.panel
			if not panel or not panel.m_panel then
				warn(("stack data top is invalid,%s is already destroyed"):format(panel_name))
				return
			end

			local comps = panel.m_panel:GetComponentsInChildren("ECReturnComponent",false)
			table.sort( comps, function (l,r)
				return l.nPriority > r.nPriority
			end )
			local index = ECFunctionReturn.FindReturnComponentByNPriority(comps)
			if index >0 and comps[index] then
				comps[index]:InvokeClick()
			else
				warn("exit game......")
				ECGame.Instance():ShowQuitTips()
			end
		end
	end

	---@return void
	def.static().CheckClosedPanel = function()
		for i=1, l_instance.stack_:Size() do
			local behavior = l_instance.stack_:Data(i)
			if behavior and behavior.is_return then
				local panel = behavior.panel
				if not panel or not panel.m_panel then
					l_instance.stack_:Pop(i)
				end
			end
		end
	end

	--DebugTest
	---@return void
	def.static().PrintStack = function()
		if l_instance.stack_:Size() == 0 then
			warn("stack is empty")
		end
		for i=1, l_instance.stack_:Size() do
			local behavior = l_instance.stack_:Data(i)
			warn(("%d: {name:'%s',is_return: %d}"):format(i,behavior.name,behavior.is_return and 1 or 0))
		end
	end


	ECFunctionReturn.Commit()
end

do
	l_instance = ECFunctionReturn.new()
end

return ECFunctionReturn

