--[[
	客户端功能解锁
	状态查询，读取配置，触发事件
]]

local Lplus = require "Lplus"
local ECHostConditionOp = require "Players.ECHostConditionOp"
local ECFunctionUnlockEvents = require "Guide.ECFunctionUnlockEvents"
local GcCallbacks = require "Utility.GcCallbacks"
local Callbacks = require "Utility.Callbacks"
local function_unlock = _G.GetConfigLua "Configs/function_unlock.lua"
local skillFunctionUnlockEvent = require "Event.SkillFunctionUnlockEvent"
local ConditionParse = require "Utility.ConditionParse"

---@type ECPanelBase
local ECPanelBase = Lplus.ForwardDeclare("ECPanelBase")

---@class Guide.ECFunctionUnlock:System.Object
---@field public UnlockStateEnum table
---@field protected m_unlockStateMap table<string, FunctionUnlockState>
---@field protected m_functionChildrenMap table<string, number>
---@field protected m_cleaner GcCallbacks
---@field protected m_promptedBadFunctionNameSet table
---@field public Commit fun():Guide.ECFunctionUnlock @notnull
---@field public Instance fun():Guide.ECFunctionUnlock
---@field public Init fun()
---@field public ReloadUnlockState fun()
---@field public Release fun()
---@field public GetConfig fun(functionName:string):table
---@field public GetAllConfigs fun():table
---@field public GetUICloseExcept fun():table
---@field public GetRootConfig fun(function_name:string):table
---@field public EachChainFunction fun(function_name:string):any
---@field public GetUnlockedState fun(functionName:string):string
---@field public IsUnlocked fun(functionName:string):boolean
---@field public HasFunction fun(functionName:string):boolean
---@field public FinishUnlocking fun(functionName:string)
---@field public RefreshUI fun(panel:ECPanelBase)
---@field public OnDestroy fun(panel:ECPanelBase)
---@field public OnHideUnlockObj fun(panel:ECPanelBase, control:userdata)
---@field public OnShowUnlockObj fun(panel:table, control:userdata, function_name:string, iEntry:number)
---@field public OnLockObjClick fun(function_name:string, iEntry:number)
---@field public GetAllLockObjHandle fun():table
---@field public TemporarilyUnlock fun(functionName:string)
---@field public ResetAllTemporarilyUnlocked fun()
---@field public GetAllState fun():table
---@field public UnlockAll fun()
---@field public LockAllExcept fun(exceptions:table)
---@field public PrintUnlockState fun()
---@field public AddInitCallback fun(callback:function)
---@field public OnInit fun()
---@field private _AddFunctionChildrenMap fun(function_name:string, config:table):number
---@field private _InitOneFunctionConditionOp fun(functionName:string)
---@field public WaitUnlockState fun(function_name:string, unlockState:FunctionUnlockState)
---@field public FinishUnlockingInner fun(functionName:string, bRaiseEvent:boolean)
---@field public FinishRelockedInner fun(functionName:string, bRaiseEvent:boolean)
---@field private _ResetTemporarilyUnlocked fun(self:Guide.ECFunctionUnlock, functionName:string)
---@field private _ResetAllParentUnlockState fun(self:Guide.ECFunctionUnlock)
---@field public IsRelativeViewBasePanel fun(config:table, panel:ECPanelBase):boolean
---@field public IsRelativePanel fun(config:table, panelName:string):boolean
---@field public ListenToUnlockEvent fun()
---@field public ShowUI fun(widget:ue.UWidget, is_show:boolean, function_name:string)
---@field public SetLock fun(widget:ue.UWidget, isLock:boolean)
---@field public freshVisualState fun(function_name:string)
---@field public freshViewBaseVisualStateEx fun(function_name:string, limitPanelName:string, rootPanel:ECPanelBase)
---@field public freshVisualStateEx fun(function_name:string, limitPanelName:string)
---@field public GetLevelCondition fun(functionName:string):boolean,number
local ECFunctionUnlock = Lplus.Class("Guide.ECFunctionUnlock")
do
	local def = ECFunctionUnlock.define

	---@type Guide.ECFunctionUnlock
	local l_instance
	local l_unlockall = false
	local l_temporarilyUnlockedSet = {}

	local UnlockStateEnum =
	{
		none = "none",
		locked = "locked",
		unlocking = "unlocking",
		unlocked = "unlocked",
	}

	---@type table
	def.const("table").UnlockStateEnum = UnlockStateEnum
	

	---@return Guide.ECFunctionUnlock
	def.static("=>", ECFunctionUnlock).Instance = function ()
		return l_instance
	end

	---加这个函数，主要是为了调试使用
	---@param unlockState FunctionUnlockState
	local function updateUnlockState(function_name, unlockState, v, tag)
		--if function_name == "npc_shop_service_4" then
		--	print_hsh("updateUnlockState  ",function_name,unlockState,v,tag)
		--end

		--if function_name == "Btn_Activity" then
		--	print_jzw("Btn_Activity unlock update",v,debug.traceback())
		--end

		unlockState.state = v

		--更新在父状态中的子状态位
		local EUnlocked = UnlockStateEnum.unlocked
		local config = ECFunctionUnlock.GetConfig(function_name)
		local parent = config.parent
		if parent and parent ~= "none" then
			local parentState = l_instance.m_unlockStateMap[parent]
			if parentState then
				parentState.childrenBits = _G.BitSetByIndex(parentState.childrenBits or 0, unlockState.indexInParent, v == EUnlocked)
			end
		end
	end
	---@param unlockState FunctionUnlockState
	local function clearStateCondition(unlockState, state)
		unlockState.constState = state and UnlockStateEnum.unlocked or UnlockStateEnum.locked
		unlockState.conditionOp = nil
	end
	
	local virtualPanelSetVisibleFuncMap = {}
	local function RegisterVirtualPanel(panelName, SetVisibleFunc)
		virtualPanelSetVisibleFuncMap[panelName] = SetVisibleFunc
	end
	
	local function SetVirtualPanelVisible(panelName, visible)
		if virtualPanelSetVisibleFuncMap[panelName] then
			virtualPanelSetVisibleFuncMap[panelName](visible)
			return true
		end
		
		return false
	end

	RegisterVirtualPanel("vp_joystick", function (visible)
		_G.SetJoyStickVisible(_G.ECJoyStickVisibleType.FunctionUnlock, visible)
	end)

	--[[
		加载配置，重置状态，要求角色数据已获取(基础属性、技能、任务)
	]]

	---@return void
	def.static().Init = function ()
		ECFunctionUnlock.Release()

		l_instance = ECFunctionUnlock()
		l_instance.m_cleaner = l_instance.m_cleaner or GcCallbacks()

		local l_allConfigs = function_unlock.getAllConfigs()

		--设置初始状态
		local function _onInit()
			--设置初始状态
			for function_name, config in pairs(l_allConfigs) do
				ECFunctionUnlock._InitOneFunctionConditionOp(function_name)
			end

			--更新父功能的解锁状态
			for function_name, config in pairs(l_allConfigs) do
				if ECFunctionUnlock.IsUnlocked(function_name) then
					--递归设置为 "unlocked"
					for chain_name, _ in ECFunctionUnlock.EachChainFunction(function_name) do
						if not ECFunctionUnlock.IsUnlocked(chain_name) then
							updateUnlockState(chain_name, l_instance.m_unlockStateMap[chain_name], UnlockStateEnum.unlocked)
						end
					end
				end
			end

			--更新所有功能的ui
			for function_name, config in pairs(l_allConfigs) do
				ECFunctionUnlock.freshVisualState(function_name)
			end
		end
		_onInit()
		
		--更新父功能的解锁状态
		for function_name, config in pairs(l_allConfigs) do
			if ECFunctionUnlock.IsUnlocked(function_name) then
				--递归设置为 "unlocked"
				for chain_name, _ in ECFunctionUnlock.EachChainFunction(function_name) do
					if not ECFunctionUnlock.IsUnlocked(chain_name) then
						updateUnlockState(chain_name, l_instance.m_unlockStateMap[chain_name], UnlockStateEnum.unlocked)
					end
				end
			end
		end
		
		--更新所有功能的ui
		for function_name, config in pairs(l_allConfigs) do
			ECFunctionUnlock.freshVisualState(function_name)
		end
		
		ECFunctionUnlock.ListenToUnlockEvent()
		
		do	--有时需要重新检查初始解锁状态
			local ECGame = require "Main.ECGame"

			local onHandle = function (sender, event)
				if l_instance then
					--print_xf("@@@@@@ TaskInitEvent oninit")
					for function_name, unlockState in pairs(l_instance.m_unlockStateMap) do
						if unlockState.conditionOp then
							unlockState.conditionOp:forcedStopWaiting()
							clearStateCondition(unlockState, unlockState.conditionOp:getState())
						end
					end
					l_instance.m_unlockStateMap = {}
					l_instance.m_functionChildrenMap = {}
					_onInit()
					ECFunctionUnlock.ReloadUnlockState()
				end
			end
			local TaskInitEvent = require "Event.TaskEvents".TaskInitEvent
			ECGame.EventManager:addHandlerWithCleaner(TaskInitEvent, onHandle, l_instance.m_cleaner)
			local InstanceInitEvent = require "Event.InstanceInfoEvent".InstanceInitEvent
			ECGame.EventManager:addHandlerWithCleaner(InstanceInitEvent, onHandle, l_instance.m_cleaner)
			local ActivityEvents = require("Event.ActivityEvents")
			ECGame.EventManager:addHandlerWithCleaner(ActivityEvents.ActivityInfoInit, onHandle, l_instance.m_cleaner)
			ECGame.EventManager:addHandlerWithCleaner(ActivityEvents.ActivityOpenEvent, onHandle, l_instance.m_cleaner)
			ECGame.EventManager:addHandlerWithCleaner(ActivityEvents.ActivityCloseEvent, onHandle, l_instance.m_cleaner)

			local HostSkillInitDataEvent = require "Event.HostSkillEvents".HostSkillInitDataEvent
			ECGame.EventManager:addHandlerWithCleaner(HostSkillInitDataEvent, function (sender, event)				
				ECFunctionUnlock.ReloadUnlockState()
				--print("debug ReloadUnlockState on HostSkillInitDataEvent, when: skill_index_learned(1) = ", ECHostConditionOp.Executor.skill_index_learned(1), ", skill_index_1 = ", ECFunctionUnlock.GetUnlockedState("skill_index_1"))
				ECGame.EventManager:raiseEvent(nil, skillFunctionUnlockEvent())
			end, l_instance.m_cleaner)
		end
		
		--print("debug ReloadUnlockState on Init, when: skill_index_learned(1) = ", ECHostConditionOp.Executor.skill_index_learned(1), ", skill_index_1 = ", ECFunctionUnlock.GetUnlockedState("skill_index_1"))
		ECFunctionUnlock.ReloadUnlockState()
		
		ECFunctionUnlock.OnInit()
	end
	
	--[[
		重新设置初始解锁状态，将未解锁，但已满足条件的功能设为已解锁
	]]

	---@return void
	def.static().ReloadUnlockState = function ()
		if not l_instance then
			ECFunctionUnlock.Init()
		end
		local l_allConfigs = function_unlock.getAllConfigs()
		for function_name, config in pairs(l_allConfigs) do
			local unlockState = l_instance.m_unlockStateMap[function_name]
			local temporarilyUnlockedSet = l_temporarilyUnlockedSet
			if unlockState.state == "none" and (temporarilyUnlockedSet[function_name] or unlockState.conditionOp and unlockState.conditionOp:getState()) then

				updateUnlockState(function_name, unlockState, UnlockStateEnum.unlocking)
				ECFunctionUnlock.FinishUnlockingInner(function_name, false)
			end
		end
		local ECGame = require "Main.ECGame"
		ECGame.EventManager:raiseEvent(nil, ECFunctionUnlockEvents.ReloadUnlockStateEvent())
	end

	---@return void
	def.static().Release = function ()
		if l_instance then
			for function_name, unlockState in pairs(l_instance.m_unlockStateMap) do
				if unlockState.conditionOp then
					unlockState.conditionOp:stopWaiting()
					clearStateCondition(unlockState, unlockState.conditionOp:getState())
				end
			end
			l_instance.m_cleaner:dispose()
		end
		l_instance = nil
	end

	---@param functionName string
	---@return table
	def.static("string", "=>", "table").GetConfig = function (functionName)
		local l_allConfigs = function_unlock.getAllConfigs()
		return l_allConfigs[functionName]
	end

	---@return table
	def.static("=>", "table").GetAllConfigs = function()
		return function_unlock.getAllConfigs()
	end

	---@return table
	def.static("=>", "table").GetUICloseExcept = function()
		return function_unlock.getUICloseExcept()
	end
	
	--[[
		取得最顶层功能的配置，即查找功能的 parent 直到 parent 为 "none"
	]]

	---@param function_name string
	---@return table
	def.static("string", "=>", "table").GetRootConfig = function (function_name)
		local last_config
		for chain_name, chain_config in ECFunctionUnlock.EachChainFunction(function_name) do
			last_config = chain_config
		end
		return last_config
	end
	
	local function nextChainFunction (firstName, curName)
		if not curName then
			return firstName, ECFunctionUnlock.GetConfig(firstName)
		else
			local curConfig = ECFunctionUnlock.GetConfig(curName)
			if not curConfig then
				error("invalid unlock name: " .. tostring(curName))
			end
			local parent = curConfig.parent
			if parent ~= "none" then
				return parent, ECFunctionUnlock.GetConfig(parent)
			else
				return nil, nil
			end
		end
	end
	

	---@param function_name string
	---@return any
	def.static("string", "=>", "varlist").EachChainFunction = function (function_name)
		return nextChainFunction, function_name, nil
	end


	--[[
		return "none", "unlocking", "unlocked"
	]]

	---@param functionName string
	---@return string
	def.static("string", "=>", "string").GetUnlockedState = function (functionName)
		if not l_instance then
			return UnlockStateEnum.none
		end
		
		local unlockState = l_instance.m_unlockStateMap[functionName]
		if not unlockState then
			if not l_instance.m_promptedBadFunctionNameSet[functionName] then
				l_instance.m_promptedBadFunctionNameSet[functionName] = true
				--warn(debug.traceback("bad unlock function name: " .. tostring(functionName)))
			end
			return UnlockStateEnum.unlocked		--找不到的当作解锁了吧
		end

		return unlockState.state
	end
	
	--[[
		功能是否已解锁
	]]

	---@param functionName string
	---@return boolean
	def.static("string", "=>", "boolean").IsUnlocked = function (functionName)
		local state = ECFunctionUnlock.GetUnlockedState(functionName)
		--[[if functionName == "Baby" then
			print("__________IsUnlocked: ", functionName, state, debug.traceback())
		end]]
		return state == UnlockStateEnum.unlocked
	end
	
	--[[
		是否有某功能
	]]

	---@param functionName string
	---@return boolean
	def.static("string", "=>", "boolean").HasFunction = function (functionName)
		if not l_instance then return false end
		return l_instance.m_unlockStateMap[functionName] ~= nil
	end
	

	---@param functionName string
	---@return void
	def.static("string").FinishUnlocking = function (functionName)
		ECFunctionUnlock.FinishUnlockingInner(functionName, true)
	end
	
	--[[
		触发自动解锁的一次刷新。当界面的一部分从隐藏变为显示，应调用
	]]
	local l_allLockObjHandle

	---@param panel ECPanelBase
	---@return void
	def.static(ECPanelBase).RefreshUI = function (panel)
		if not panel.m_panel then
			--Debug.LogInfo("panel not created when RefreshUI: " .. tostring(panel)..debug.traceback())
			return
		end

		local l_allConfigs = function_unlock.getAllConfigs()
		local panelName = panel.m_panelName
		for function_name, config in pairs(l_allConfigs) do
			if config.viewBase and ECFunctionUnlock.IsRelativeViewBasePanel(config, panel) then
				ECFunctionUnlock.freshViewBaseVisualStateEx(function_name, "*",panel)
			elseif ECFunctionUnlock.IsRelativePanel(config, panelName) then
				ECFunctionUnlock.freshVisualStateEx(function_name, panelName)
			end
		end
	end

	---@param panel ECPanelBase
	---@return void
	def.static(ECPanelBase).OnDestroy = function(panel)
		if not l_allLockObjHandle then
			return
		end

		if not l_allLockObjHandle[panel] then
			return
		end

		for control, v in pairs(l_allLockObjHandle[panel]) do
			if v then
				ECFunctionUnlock.OnHideUnlockObj(panel, control)
			end
		end
		l_allLockObjHandle[panel] = nil
	end

	---@param panel ECPanelBase
	---@param control userdata
	---@return void
	def.static("table", "userdata").OnHideUnlockObj = function(panel, control)
		if not l_allLockObjHandle then
			return
		end

		if control and not control:is_nil() then
			--print_ldf("unbind lockobj click envent")
			control:RemoveAllEventHandlers("onClick", true)
		end
		if control and l_allLockObjHandle[panel] then
			l_allLockObjHandle[panel][control] = nil
		end
	end
	---@param panel table
	---@param control userdata
	---@param function_name string
	---@param iEntry number
	---@return void
	def.static("table", "userdata", "string", "number").OnShowUnlockObj = function(panel, control, function_name, iEntry)
		l_allLockObjHandle = l_allLockObjHandle or {}
		l_allLockObjHandle[panel] = l_allLockObjHandle[panel] or setmetatable({}, { __mode = "k"})
		if l_allLockObjHandle[panel][control] then
			return
		end
		if control and not control:is_nil() then
			l_allLockObjHandle[panel][control] = true
			--print_ldf("bind lockobj click envent")
			control:AddEventHandler("onClick", function(...)
				print_ldf(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>", function_name, iEntry)
				ECFunctionUnlock.OnLockObjClick(function_name, iEntry)
			end)
		end
	end

    ---@param function_name string
    ---@param iEntry number
    ---@return void
    def.static("string", "number").OnLockObjClick = function(function_name, iEntry)
		local config = ECFunctionUnlock.GetConfig(function_name)
		if not config then
			return
		end
		local oneEntry = config.entry and config.entry[iEntry] or nil
		if not oneEntry then
			return
		end

		if oneEntry.hide_style ~= "unlocked" then
			return
		end

		local hostLv = globalGame:GetHostPlayer():GetLevel()
		if oneEntry.locked_tips then
			for _, v in ipairs(oneEntry.locked_tips) do
				local low, high = v.low, v.high
				if hostLv >= low and hostLv <= high then
					FlashTipMan.FlashTip(v.tip)
					return
				end
			end
		end

		FlashTipMan.FlashTip(StringTable.Get(111505))
    end

	---@return table
	def.static("=>", "table").GetAllLockObjHandle = function()
		return l_allLockObjHandle
	end

	--临时解锁功能，无视解锁条件强制解锁
	---@param functionName string
	---@return void
	def.static("string").TemporarilyUnlock = function (functionName)
		local l_allConfigs = function_unlock.getAllConfigs()
		if not l_allConfigs[functionName] then
			warn("TemporarilyUnlock invalid function name: ", functionName)
			return
		end

		local temporarilyUnlockedSet = l_temporarilyUnlockedSet
		if not temporarilyUnlockedSet[functionName] then
			temporarilyUnlockedSet[functionName] = true

			local unlockState = l_instance.m_unlockStateMap[functionName]
			if unlockState.state == UnlockStateEnum.none then	--未解锁
				updateUnlockState(functionName, unlockState, UnlockStateEnum.unlocking)
				ECFunctionUnlock.FinishUnlockingInner(functionName, true)
			end
		end
	end

	--重置所有临时解锁的功能，恢复到解锁条件对应的状态
	---@return void
	def.static().ResetAllTemporarilyUnlocked = function ()
		if not l_instance then
			return
		end
		
		local temporarilyUnlockedSet = l_temporarilyUnlockedSet
		for functionName in pairs(temporarilyUnlockedSet) do
			temporarilyUnlockedSet[functionName] = nil
			l_instance:_ResetTemporarilyUnlocked(functionName)
		end

		l_instance:_ResetAllParentUnlockState()
	end
	
	--调试用

	---@return table
	def.static("=>", "table").GetAllState = function ()
		return l_instance.m_unlockStateMap
	end
	

	---@return void
	def.static().UnlockAll = function ()
		l_unlockall = true
		
		if l_instance then
			for function_name, unlockState in pairs(l_instance.m_unlockStateMap) do
				local bRaiseEvent = unlockState.state ~= UnlockStateEnum.unlocked
				updateUnlockState(function_name, unlockState, UnlockStateEnum.unlocked)
				if unlockState.conditionOp then
					unlockState.conditionOp:stopWaiting()
					clearStateCondition(unlockState, unlockState.conditionOp:getState())
				end
				if not bRaiseEvent then
					ECFunctionUnlock.freshVisualState(function_name)
				else
					local ECGame = require "Main.ECGame"		
					for chain_name, _ in ECFunctionUnlock.EachChainFunction(function_name) do
						local chain_unlockState = l_instance.m_unlockStateMap[chain_name]
						if bRaiseEvent then
							local unlockedEvent = ECFunctionUnlockEvents.FunctionUnlockedEvent.new(chain_name)
							unlockedEvent.oprate_name = "ua"
							ECGame.EventManager:raiseEvent(nil, unlockedEvent)
						end
					end
				end
			end
		end
	end

	---@param exceptions table
	---@return void
	def.static("table").LockAllExcept = function (exceptions)
		l_unlockall = false
		if l_instance then
			local exception_map = {}
			for _, v in ipairs(exceptions) do
				exception_map[v] = true
			end
			for function_name, unlockState in pairs(l_instance.m_unlockStateMap) do
				local bRaiseEvent
				local bLock = true
				if exception_map[function_name] then

					bRaiseEvent = unlockState.state ~= UnlockStateEnum.unlocked
					updateUnlockState(function_name, unlockState, UnlockStateEnum.unlocked)
					bLock = false
				else
					bRaiseEvent = unlockState.state ~= UnlockStateEnum.locked
					updateUnlockState(function_name, unlockState, UnlockStateEnum.locked)
				end
				print_roguelike("LockAllExcept ", function_name, unlockState.state, bRaiseEvent)

				if unlockState.conditionOp then
					unlockState.conditionOp:stopWaiting()
					clearStateCondition(unlockState, unlockState.conditionOp:getState())
				end
				if not bRaiseEvent then
					ECFunctionUnlock.freshVisualState(function_name)
				else
					local ECGame = require "Main.ECGame"
					for chain_name, _ in ECFunctionUnlock.EachChainFunction(function_name) do
						local chain_unlockState = l_instance.m_unlockStateMap[chain_name]
						if bRaiseEvent then
							local event
							if bLock then
								event = ECFunctionUnlockEvents.FunctionRelockedEvent.new(chain_name)
							else
								event = ECFunctionUnlockEvents.FunctionUnlockedEvent.new(chain_name)
								event.oprate_name = "lae"
							end
							ECGame.EventManager:raiseEvent(nil, event)
						end
					end
				end
			end
		end
	end
	

	---@return void
	def.static().PrintUnlockState = function ()
		local malut = require "Utility.malut"
		warn(malut.tableToString(ECFunctionUnlock.GetAllState(), 2))
	end
	
	-------------------------------------------------------
	-- End of public
	
	local l_initCallbacks

	---@param callback function
	---@return void
	def.static("function").AddInitCallback = function (callback)
		if l_instance then
			callback()
			return
		end
		
		l_initCallbacks = l_initCallbacks or Callbacks()
		l_initCallbacks:add(callback)
	end
	

	---@return void
	def.static().OnInit = function ()
		if l_initCallbacks then
			l_initCallbacks:invoke()
			l_initCallbacks:clear()
		end
	end

	---@param function_name string
	---@param config table
	---@return number
	def.static("string", "table", "=>", "number")._AddFunctionChildrenMap = function(function_name, config)
		local parent = config.parent
		if parent and parent ~= "none" then
			local children = l_instance.m_functionChildrenMap[parent]
			if not children then
				children = 0
			end
			children = children + 1
			if children > 32 then
				error("[function unlock] child count can not over 32.")
			end
			l_instance.m_functionChildrenMap[parent] = children
			return children
		end
		return 0
	end
	---@param functionName string
	---@return void
	def.static("string")._InitOneFunctionConditionOp = function (functionName)
		local l_allConfigs = function_unlock.getAllConfigs()
		local config = l_allConfigs[functionName]
		--分配index
		local childIndex = ECFunctionUnlock._AddFunctionChildrenMap(functionName, config)

		if not l_unlockall then
			local conditionOp = ConditionParse.createConditionOp(config)
			if conditionOp then
				assert(conditionOp:hasState() and conditionOp:canWait())

				local bReady = l_temporarilyUnlockedSet[functionName] or conditionOp:getState()
				---@type FunctionUnlockState
				local unlockState = {indexInParent = childIndex}--{ state = bReady and "unlocked" or "none" }
				local state = bReady and UnlockStateEnum.unlocked or UnlockStateEnum.none
				updateUnlockState(functionName, unlockState, state, bReady)
				if not bReady or conditionOp:isVolatile() then	--未解锁的功能或者易变功能，监听解锁事件
					unlockState.conditionOp = conditionOp
					ECFunctionUnlock.WaitUnlockState(functionName, unlockState)
				else
					unlockState.constState = state
				end
				l_instance.m_unlockStateMap[functionName] = unlockState
			else	--无解锁条件
				---@type FunctionUnlockState
				local unlockState = {indexInParent = childIndex, constState = UnlockStateEnum.none}
				updateUnlockState(functionName, unlockState, UnlockStateEnum.none, "not createop")
				l_instance.m_unlockStateMap[functionName] = unlockState --{ state = "none" }
			end
		else
			---@type FunctionUnlockState
			local unlockState = {indexInParent = childIndex, constState = UnlockStateEnum.unlocked}
			updateUnlockState(functionName, unlockState, UnlockStateEnum.unlocked)
			l_instance.m_unlockStateMap[functionName] = unlockState --{ state = "unlocked" }
		end
	end

	---@param function_name string
	---@param unlockState FunctionUnlockState
	---@return void
	def.static("string", "table").WaitUnlockState = function (function_name, unlockState)
		local conditionOp = unlockState.conditionOp
		conditionOp:wait(function ()
			if conditionOp:getState() or conditionOp:isVolatile() then
				--如果是清除了条件，也要刷新一次，不然后面就没机会刷新了
				local bConditionCleared = false
				if not conditionOp:isVolatile() then
					conditionOp:stopWaiting()
					clearStateCondition(unlockState, conditionOp:getState())
					bConditionCleared = true
				end

				if unlockState.state == UnlockStateEnum.none and not conditionOp:isVolatile() then
					local ECGame = require "Main.ECGame"

					local config = ECFunctionUnlock.GetConfig(function_name)

					local FEInstanceMan = require "Instance.FEInstanceMan"
					local no_notify = config.no_notify or not FEInstanceMan.Instance():CanShowFunctionUnlock()
					--本应递归设置为 "unlocking"，但显示效果上，父功能在飞图标前就应显示，故直接解锁。如果 no_notify 也直接解锁
					for chain_name, _ in ECFunctionUnlock.EachChainFunction(function_name) do
						local chain_unlockState = l_instance.m_unlockStateMap[chain_name]
						if chain_unlockState and chain_unlockState.state == UnlockStateEnum.none then
							if chain_name ~= function_name or no_notify then
								updateUnlockState(chain_name, chain_unlockState, UnlockStateEnum.unlocking)
								ECFunctionUnlock.FinishUnlockingInner(chain_name, true)
							else
								updateUnlockState(chain_name, chain_unlockState, UnlockStateEnum.unlocking)
								ECGame.EventManager:raiseEvent(nil, ECFunctionUnlockEvents.FunctionStartUnlockEvent.new(chain_name))
							end
						end
					end

					if not no_notify then
						--有报错暂时注释：没有解锁界面资源
						--因为升级动画，暂时延迟一些
						local ECPanelFunctionUnlock = require "Guide.ECPanelFunctionUnlock"
						ECPanelFunctionUnlock.QueuePopup(function_name)
						--GameUtil.AddGlobalTimer(1.7 + 0.1,true,function()
						--	local ECPanelFunctionUnlock = require "Guide.ECPanelFunctionUnlock"
						--	ECPanelFunctionUnlock.QueuePopup(function_name)
						--end)
					end
					--没有解锁面板，临时放这里
					--ECFunctionUnlock.FinishUnlocking(function_name)
					if config.unlock_cb then
						config.unlock_cb()
					end
				elseif conditionOp:isVolatile() or bConditionCleared then
					if conditionOp:getState() then
						local ECGame = require "Main.ECGame"
						local config = ECFunctionUnlock.GetConfig(function_name)
						local FEInstanceMan = require "Instance.FEInstanceMan"
						local no_notify = config.no_notify or not FEInstanceMan.Instance():CanShowFunctionUnlock()

						for chain_name, _ in ECFunctionUnlock.EachChainFunction(function_name) do
							local chain_unlockState = l_instance.m_unlockStateMap[chain_name]
							if chain_unlockState and (chain_unlockState.state == UnlockStateEnum.locked or chain_unlockState.state == UnlockStateEnum.none) then
								if chain_name ~= function_name or no_notify then
									updateUnlockState(chain_name, chain_unlockState, UnlockStateEnum.unlocking)
									ECFunctionUnlock.FinishUnlockingInner(chain_name, true)
								else
									updateUnlockState(chain_name, chain_unlockState, UnlockStateEnum.unlocking)
									ECGame.EventManager:raiseEvent(nil, ECFunctionUnlockEvents.FunctionStartUnlockEvent.new(chain_name))
								end
							end
						end

						if not no_notify then
							--有报错暂时注释：没有解锁界面资源
							--因为升级动画，暂时延迟一些
							local ECPanelFunctionUnlock = require "Guide.ECPanelFunctionUnlock"
							ECPanelFunctionUnlock.QueuePopup(function_name)
							--GameUtil.AddGlobalTimer(1.7 + 0.1,true,function()
							--	local ECPanelFunctionUnlock = require "Guide.ECPanelFunctionUnlock"
							--	ECPanelFunctionUnlock.QueuePopup(function_name)
							--end)
						end
						--没有解锁面板，临时放这里
						--ECFunctionUnlock.FinishUnlocking(function_name)
						if config.unlock_cb then
							config.unlock_cb()
						end
					else
						local chain_unlockState = l_instance.m_unlockStateMap[function_name]
						if chain_unlockState then
							updateUnlockState(function_name, chain_unlockState, UnlockStateEnum.locked)
							ECFunctionUnlock.FinishRelockedInner(function_name, true)
						end
					end
				end

				if not conditionOp:isVolatile() then
					clearStateCondition(unlockState, conditionOp:getState())
				end
			end
		end)
	end
	

	---@param functionName string
	---@param bRaiseEvent boolean
	---@return void
	def.static("string", "boolean").FinishUnlockingInner = function (functionName, bRaiseEvent)
		if not l_instance then return end
		local unlockState = l_instance.m_unlockStateMap[functionName]
		if unlockState.state ~= UnlockStateEnum.unlocking then
			warn(([[wrong state when FinishUnlocking:%s ("unlocking" expected, got "%s")]]):format(functionName, unlockState.state))
			return
		end
		
		local ECGame = require "Main.ECGame"
		
		--递归设置为 "unlocked"
		for chain_name, _ in ECFunctionUnlock.EachChainFunction(functionName) do
			local chain_unlockState = l_instance.m_unlockStateMap[chain_name]
			if chain_unlockState and chain_unlockState.state ~= UnlockStateEnum.unlocked then
				updateUnlockState(chain_name, chain_unlockState, UnlockStateEnum.unlocked)
				if bRaiseEvent then
					ECGame.EventManager:raiseEvent(nil, ECFunctionUnlockEvents.FunctionUnlockedEvent.new(chain_name))
				end
			end
		end
	end

	---@param functionName string
	---@param bRaiseEvent boolean
	---@return void
	def.static("string", "boolean").FinishRelockedInner = function (functionName, bRaiseEvent)
		if not l_instance then return end
		local unlockState = l_instance.m_unlockStateMap[functionName]
		if unlockState.state ~= UnlockStateEnum.locked then
			warn(([[wrong state when FinishUnlocking:%s ("locked" expected, got "%s")]]):format(functionName, unlockState.state))
			return
		end

		local ECGame = require "Main.ECGame"

		--递归设置为 "unlocked"
		for chain_name, _ in ECFunctionUnlock.EachChainFunction(functionName) do
			local chain_unlockState = l_instance.m_unlockStateMap[chain_name]
			--print_hsh("chain_name  ",chain_name,chain_unlockState)
			if chain_unlockState and chain_unlockState.state ~= UnlockStateEnum.locked then
				--子状态没有解锁的并且自身状态也是未解锁的
				local childrenBits = chain_unlockState.childrenBits or 0
				local selfState = chain_unlockState.constState
				if chain_unlockState.conditionOp then
					selfState = chain_unlockState.conditionOp:getState() and UnlockStateEnum.unlocked or UnlockStateEnum.locked
				end
				if childrenBits == 0 and selfState ~= UnlockStateEnum.unlocked then
					updateUnlockState(chain_name, chain_unlockState, UnlockStateEnum.locked)
					if bRaiseEvent then
						ECGame.EventManager:raiseEvent(nil, ECFunctionUnlockEvents.FunctionRelockedEvent.new(chain_name))
					end
				end
			end
		end
	end



	---@param self Guide.ECFunctionUnlock
	---@param functionName string
	---@return void
	def.method("string")._ResetTemporarilyUnlocked = function (self, functionName)
		local unlockState = self.m_unlockStateMap[functionName]
		if unlockState.state == UnlockStateEnum.unlocked then	--当前状态为已解锁
			local conditionOp = unlockState.conditionOp
			if conditionOp then
				conditionOp:forcedStopWaiting()
				clearStateCondition(unlockState, conditionOp:getState())
			end

			ECFunctionUnlock._InitOneFunctionConditionOp(functionName)
			if not ECFunctionUnlock.IsUnlocked(functionName) then
				local ECGame = require "Main.ECGame"
				ECGame.EventManager:raiseEvent(nil, ECFunctionUnlockEvents.FunctionRelockedEvent.new(functionName))
			end
		end
	end

	--[[
		(重置临时解锁状态后)处理应重新锁上的父功能
	]]
	---@param self Guide.ECFunctionUnlock
	---@return void
	def.method()._ResetAllParentUnlockState = function (self)
		local l_allConfigs = function_unlock.getAllConfigs()

		--不能有正在解锁过程中的功能
		for functionName, config in pairs(l_allConfigs) do
			local unlockState = self.m_unlockStateMap[functionName]
			if unlockState.state == UnlockStateEnum.unlocking then
				ECFunctionUnlock.FinishUnlockingInner(functionName, true)
			end
		end

		--取得父功能新的解锁状态
		local newUnlockedSet = {}
		for functionName, config in pairs(l_allConfigs) do
			local unlockState = self.m_unlockStateMap[functionName]
			if config.condition ~= UnlockStateEnum.none and unlockState.state == UnlockStateEnum.unlocked then	--condition 为 "none" 时自身无法解锁，一般是父功能
				--递归记录应解锁的功能
				for chain_name, _ in ECFunctionUnlock.EachChainFunction(functionName) do
					if newUnlockedSet[chain_name] then
						break
					else
						newUnlockedSet[chain_name] = true
					end
				end
			end
		end

		for functionName, config in pairs(l_allConfigs) do
			--状态变为未解锁的处理之
			if not newUnlockedSet[functionName] and ECFunctionUnlock.IsUnlocked(functionName) then
				local unlockState = self.m_unlockStateMap[functionName]
				updateUnlockState(functionName, unlockState, UnlockStateEnum.none)

				local ECGame = require "Main.ECGame"
				ECGame.EventManager:raiseEvent(nil, ECFunctionUnlockEvents.FunctionRelockedEvent.new(functionName))
			end
		end
	end

	---@param config table
	---@param panel ECPanelBase
	---@return boolean
	def.static("table", ECPanelBase, "=>", "boolean").IsRelativeViewBasePanel = function (config, panel)
		local entry = config.entry
		if not entry or entry == "none" then
			return false
		end

		for _, oneEntry in ipairs(config.entry) do
			local entryPanelName = string.lower(oneEntry.pos[1])
			local childObj = panel:FindDirect("Widget/"..entryPanelName)
			if childObj then
				return true
			end
		end

		return false
	end

	---@param config table
	---@param panelName string
	---@return boolean
	def.static("table", "string", "=>", "boolean").IsRelativePanel = function (config, panelName)
		local entry = config.entry
		if not entry or entry == "none" then
			return false
		end
		
		for _, oneEntry in ipairs(config.entry) do
			 local entryPanelName = string.lower(oneEntry.pos[1])
            panelName = string.lower(panelName)
			if entryPanelName == panelName then
				return true
			end
		end

		return false
	end

	---@return void
	def.static().ListenToUnlockEvent = function ()
		local ECGame = require "Main.ECGame"
		ECGame.EventManager:addHandlerWithCleaner(ECFunctionUnlockEvents.FunctionStartUnlockEvent, function (sender, event)
			ECFunctionUnlock.freshVisualState(event.function_name)
		end, l_instance.m_cleaner)
		
		ECGame.EventManager:addHandlerWithCleaner(ECFunctionUnlockEvents.FunctionUnlockedEvent, function (sender, event)
			ECFunctionUnlock.freshVisualState(event.function_name)
		end, l_instance.m_cleaner)

		ECGame.EventManager:addHandlerWithCleaner(ECFunctionUnlockEvents.FunctionRelockedEvent, function (sender, event)
			ECFunctionUnlock.freshVisualState(event.function_name)
		end, l_instance.m_cleaner)
	end

	-- {[function_name] = {conditionOp = ..., state = "none"/"unlocking"/"unlocked", childrenBits = 0, indexInParent = 0}}
	---@class FunctionUnlockState
	---@field public conditionOp ConditionOp
	---@field public state string
	---@field public childrenBits number @comment 每一位对应子状态
	---@field public indexInParent number @comment 子状态在父状态的索引
	---@field public constState string @comment 自身默认的固定值

	---@type table<string, FunctionUnlockState>
	def.field("table").m_unlockStateMap = function () return {} end

	---@type table<string, number>
	def.field("table").m_functionChildrenMap = BLANK_TABLE_INIT --function_unlock对应的子节点数量

	---@type GcCallbacks
	def.field(GcCallbacks).m_cleaner = nil

	---@type table
	def.field("table").m_promptedBadFunctionNameSet = function () return {} end
	
	
	-- 在parent中找到componentType, 到 panelName 为止
	local function findComponentInParent (control, componentType, panelName, ...)
		if not control then
			return nil
		end
		
		local parent = control.parent
		while parent and parent.name ~= panelName do
			local component = parent:GetComponent(componentType)
			if component then
				return component
			end
			
			parent = parent.parent
		end
		
		return nil
	end

	---@param widget ue.UWidget
	---@param is_show boolean 显隐状态
	---@param function_name string 功能名称。如果功能被锁定，则会隐藏控件。
	---@return void
	def.static("userdata", "boolean", "string").ShowUI = function(widget, is_show, function_name)
		if not l_instance then return end
		if not widget or widget:is_nil() then
			return
		end

		if ECFunctionUnlock.IsUnlocked(function_name) then
			-- 功能解锁，正常显隐（现状）
			widget:SetActive(is_show)
		else
			if not widget:IsLockVisibility() then
				-- 功能锁定，且控件没有被锁定，隐藏控件（现状）
				widget:SetActive(false)
			else
				-- 功能锁定，且控件被锁定，延后显隐
				widget:SetActive(is_show)
			end
		end
	end
	
	---@param widget ue.UWidget
	---@param isLock boolean
	---@return void
	def.static("userdata", "boolean").SetLock = function(widget, isLock)
		if not widget or widget:is_nil() then
			return
		end

		--print_jzw("setlock",widget:GetName(),isLock)
		if isLock then
			-- 锁定对Visibility的修改，并隐藏UI
			if not widget:IsLockVisibility() then
				widget:LockVisibility(true)
				widget:SetActiveRaw(false)
			end
		else
			-- 恢复对UI的显示
			if widget:IsLockVisibility() then
				widget:UnlockVisibility()
			end
		end
	end
	
	-- visualState: "visible", "hidden", "place_holder"
	---@param function_name string
	---@return void
	def.static("string").freshVisualState = function (function_name)
		return ECFunctionUnlock.freshVisualStateEx(function_name, "*")
	end
	
	-- visualState: "visible", "hidden", "place_holder"
	---@param function_name string
	---@param limitPanelName string
	---@param rootPanel ECPanelBase
	---@return void
	def.static("string", "string",ECPanelBase).freshViewBaseVisualStateEx = function (function_name, limitPanelName,rootPanel)
		local config = ECFunctionUnlock.GetConfig(function_name)
		if not config.entry then return end

		local ECGUIMan = require "GUI.ECGUIMan"
		if config.entry == "none" then
			return
		end

		for iEntry, oneEntry in ipairs(config.entry) do	--entry 中有指定多个控件
			repeat
				local hide_style = oneEntry.hide_style

				if not hide_style or hide_style == "none" then
					break	--continue outter
				end

				local panelName = string.lower(oneEntry.pos[1])

				if limitPanelName == "*" or panelName == limitPanelName then
					local panel = rootPanel:FindDirect("Widget/"..panelName)--ECGUIMan.Instance():FindPanelByName(panelName)
					if not panel or panel:is_nil() then
						break	--continue outter
					end

					local realPos = {}

					for i = 2, #oneEntry.pos do
						table.insert(realPos,oneEntry.pos[i])
					end
					local control = panel:FindDirect(table.concat(realPos, "/"))--ECHostConditionOp.Executor.find_ui(unpack(oneEntry.pos))
					if not control then
						local poss = ""
						for _, p in ipairs(oneEntry.pos) do
							poss = poss .. "/" .. tostring(p)
						end
						warn(("failed to find ui control when unlock '%s': %s"):format(function_name, poss))
						break	--continue outter
					end

					if hide_style == "simple" then
						local bUnLocked = ECFunctionUnlock.IsUnlocked(function_name)
						--print_ldf("-------viewbase hide_style simple--------------", function_name, bUnLocked)
						ECFunctionUnlock.SetLock(control, not bUnLocked)

					elseif hide_style == "unlocked" then --解锁之后隐藏
						local bUnLocked = ECFunctionUnlock.IsUnlocked(function_name)
						--print_ldf("-------viewbase hide_style unlocked--------------", function_name, bUnLocked)
						if bUnLocked then --功能解锁了，直接隐藏
							ECFunctionUnlock.SetLock(control, true)

							ECFunctionUnlock.OnHideUnlockObj(rootPanel, control)
						else
							ECFunctionUnlock.SetLock(control, false)

							---需要绑定的点击
							ECFunctionUnlock.OnShowUnlockObj(rootPanel, control, function_name, iEntry)
						end
						--[[elseif hide_style == "layer" then
	
							local state = ECFunctionUnlock.GetUnlockedState(function_name)
							if state == "unlocked" then
								panel.m_panel:SetLayer(ClientDef_Layer.UI)
							else
								panel.m_panel:SetLayer(ClientDef_Layer.Invisible)
							end
	
						elseif hide_style == "UITable" or hide_style == "UIGrid" or hide_style == "UIList" then
							--在parent中找到 hide_style 名称的 Component
							local uiContainer = findComponentInParent(control, hide_style, unpack(oneEntry.pos))
							if not uiContainer then
								warn(("failed to find %s when unlock '%s': %s"):format(hide_style, function_name, table.concat(oneEntry.pos, ".")))
								break	--continue outter
							end
							--uiContainer:unbind()
	
							local state = ECFunctionUnlock.GetUnlockedState(function_name)
							local bOpen = true
							if function_name == "Home" then
								local ECActivityInfo = require "Social.ECActivityInfo"
								bOpen = ECActivityInfo.IsOpen(HOME_ACTIVITY_ID)
							end
							ECFunctionUnlock.SetLock(control, state == "none" or not bOpen)
	
							GameUtil.AddGlobalTimer(0, true, function ()
								local control = ECHostConditionOp.Executor.find_ui(unpack(oneEntry.pos))
								local uiContainer = findComponentInParent(control, hide_style, unpack(oneEntry.pos))
	
								if uiContainer then
									if ECFunctionUnlock.GetUnlockedState(function_name) == state then	--防止 state 发生变化
										if hide_style == "UITable" then
											uiContainer:Reposition()
										elseif hide_style == "UIGrid" then
											uiContainer:Reposition()
										end
	
										if state == "unlocking" then
											GameUtil.AddGlobalTimer(0, true, function ()
												local control = ECHostConditionOp.Executor.find_ui(unpack(oneEntry.pos))
												if control then
													if ECFunctionUnlock.GetUnlockedState(function_name) == state then --防止 state 发生变化
														ECFunctionUnlock.SetLock(control, true)
													end
													--control:unbind()
												end
											end)
										end
									end
									--uiContainer:unbind()
								end
							end)]]
					else
						error("unsupported hide style: " .. tostring(hide_style))
					end
					--control:unbind()
				end
			until true
		end
	end

	---@param function_name string
	---@param limitPanelName string
	---@return void
	def.static("string", "string").freshVisualStateEx = function (function_name, limitPanelName)		
		local config = ECFunctionUnlock.GetConfig(function_name)
		if not config.entry then return end
		
		local ECGUIMan = require "GUI.ECGUIMan"
		if config.entry == "none" then
			return 
		end
		local bUnLocked = ECFunctionUnlock.IsUnlocked(function_name)
		for iEntry, oneEntry in ipairs(config.entry) do	--entry 中有指定多个控件
			repeat
				local hide_style = oneEntry.hide_style
				if not hide_style or hide_style == "none" then
					break	--continue outter
				end
				
				local panelName = string.lower(oneEntry.pos[1])
				if limitPanelName == "*" or panelName == limitPanelName then
					if SetVirtualPanelVisible(panelName, bUnLocked) then
						break
					end
					
					local panel = ECGUIMan.Instance():FindPanelByName(panelName)
					if not panel or not panel.m_panel then
						break	--continue outter
					end

					local control = ECHostConditionOp.Executor.find_ui(unpack(oneEntry.pos))
					if not control then
						local poss = ""
						for _, p in ipairs(oneEntry.pos) do
							poss = poss .. "." .. tostring(p)
						end
						warn(("failed to find ui control when unlock '%s': %s"):format(function_name, poss))
						break	--continue outter
					end
					
					if hide_style == "simple" then --简单隐藏
						
						--print_ldf("-------panel hide_style simple--------------", function_name, bUnLocked)
						ECFunctionUnlock.SetLock(control, not bUnLocked)

					elseif hide_style == "unlocked" then --解锁之后隐藏
						--print_ldf("-------panel hide_style unlocked--------------", function_name, bUnLocked)
						if bUnLocked then --功能解锁了，直接隐藏
							ECFunctionUnlock.SetLock(control, true)

							ECFunctionUnlock.OnHideUnlockObj(panel, control)
						else
							ECFunctionUnlock.SetLock(control, false)

							---需要绑定的点击
							ECFunctionUnlock.OnShowUnlockObj(panel, control, function_name, iEntry)
						end

					--[[elseif hide_style == "layer" then

						local state = ECFunctionUnlock.GetUnlockedState(function_name)
						if state == "unlocked" then
							panel.m_panel:SetLayer(ClientDef_Layer.UI)
						else
							panel.m_panel:SetLayer(ClientDef_Layer.Invisible)
						end

					elseif hide_style == "UITable" or hide_style == "UIGrid" or hide_style == "UIList" then
						--在parent中找到 hide_style 名称的 Component
						local uiContainer = findComponentInParent(control, hide_style, unpack(oneEntry.pos))
						if not uiContainer then
							warn(("failed to find %s when unlock '%s': %s"):format(hide_style, function_name, table.concat(oneEntry.pos, ".")))
							break	--continue outter
						end
						--uiContainer:unbind()

						local state = ECFunctionUnlock.GetUnlockedState(function_name)
						local bOpen = true
						if function_name == "Home" then
							local ECActivityInfo = require "Social.ECActivityInfo"
							bOpen = ECActivityInfo.IsOpen(HOME_ACTIVITY_ID)
						end
						ECFunctionUnlock.SetLock(control, state == "none" or not bOpen)

						GameUtil.AddGlobalTimer(0, true, function ()
							local control = ECHostConditionOp.Executor.find_ui(unpack(oneEntry.pos))
							local uiContainer = findComponentInParent(control, hide_style, unpack(oneEntry.pos))

							if uiContainer then
								if ECFunctionUnlock.GetUnlockedState(function_name) == state then	--防止 state 发生变化
									if hide_style == "UITable" then
										uiContainer:Reposition()
									elseif hide_style == "UIGrid" then
										uiContainer:Reposition()
									end

									if state == "unlocking" then
										GameUtil.AddGlobalTimer(0, true, function ()
											local control = ECHostConditionOp.Executor.find_ui(unpack(oneEntry.pos))
											if control then
												if ECFunctionUnlock.GetUnlockedState(function_name) == state then --防止 state 发生变化
													ECFunctionUnlock.SetLock(control, true)
												end
											    --control:unbind()
											end
										end)
									end
								end
								--uiContainer:unbind()
							end
						end)]]
					else
						error("unsupported hide style: " .. tostring(hide_style))
					end
					--control:unbind()
				end
			until true
		end
	end

	--获得解锁等级条件
	---@param functionName string
	---@return boolean,number
	def.static("string", "=>", "boolean", "number").GetLevelCondition = function (functionName)
		local config = ECFunctionUnlock.GetConfig(functionName)
		if config then
			local condition = config.condition
			if #condition == 0 then
				if condition.type == "level_above" then
					return true, condition.value
				end
			elseif math.fmod(#condition, 2) == 1 then
				for i = 1, #condition, 2 do
					if condition[i].type == "level_above" then
						return true, condition[i].value
					end
				end
			end
		end

		return false, 0	
	end
end

ECFunctionUnlock.Commit()
return ECFunctionUnlock