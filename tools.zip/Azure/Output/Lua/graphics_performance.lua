--显卡性能的指标, 1 差，2 好 3 非常好, 同时返回一个评分，再返回是否是模拟器
--以Adreno 420作为基准线100分, 140分以上为lev 3，45-140为lev 2，45以下为lev 1
	
function _G.get_android_graphics_performance_score()
	
	local l_graphics_fantastic_list =
	{
		{ "Adreno (TM) 630", 	400 },
		{ "Adreno (TM) 540", 	308 },
		{ "Mali-G71",			270 },
		{ "Mali-G72",			300 },
		{ "Adreno (TM) 530",	247 },
		{ "Adreno (TM) 430",	141 },	
	}
	
	local l_graphics_good_list =	
	{
		{ "Adreno (TM) 512",	110 },	
		{ "Adreno (TM) 420",	100 },
		{ "Adreno (TM) 418",	80	},
		{ "Adreno (TM) 510",	82	},
		{ "Adreno (TM) 506",	49	},
		{ "Adreno (TM) 330",	50	},
		{ "Mali-T880",			89	},
		{ "Mali-T860",			81	},
		--"Mali-T764",		
		--"Mali-T760",		
		{ "Intel(R) HD Graphics for Atom(TM) x5/x7",	80	},
		{ "PowerVR Rogue G6430",	80 },
	}
	
	local l_device_fantastic_list =
	{
		{ "samsung SM-G935F",	202 },
		{ "samsung SM-G935L",	202 },
	}
	
	local l_device_good_list =
	{
		{ "Meizu PRO 5",	110 },
	}
	
	local l_device_poor_list =
	{
	}
	
	local l_cpu_fantastic_list =
	{
		{ "Exynos8890",		180 },
		{ "Exynos7420",		120 },
	}
	
	local l_cpu_good_list =
	{
		{ "Exynos5433",		87 	},
		{ "Exynos7880",		71	},
		{ "Exynos5430",		68	},
		{ "MT6795",			60	},
		{ "MT6795T",		60	},
		{ "Kirin 930",		45	},
		{ "RK3288",			50	},
	}
	
	local l_cpu_poor_list =
	{
		{ "MT6738",			30 },
		{ "MT6750",			35 },
		{ "MT6750T",		35 },
		{ "MT6752",			35 },
		{ "MT6755",			35 },
		{ "MT6755T",		35 },
		{ "MT6755M",		35 },
	}
	
	local l_simulator_gpu_list =
	{
		"powervrg6400",
		"OpenGL",
		"Bluestacks",
		"Tencent",
		"MuMu",
		"Direct3D",
	}	
	
	local function match_string(list, name)
		for i = 1, #list do
			local node = list[i]
			if node[1] == name then
				return node[2]
			end
		end
		
		return false
	end
	
	local function end_with (str, part)
		local offset = #str - #part + 1
		if offset <= 0 then
			return false
		end
		return str:find(part, offset, true) ~= nil
	end

	local function end_with_string(list, name)
		for i = 1, #list do
			local node = list[i]
			if end_with(name, node[1]) then
				return node[2]
			end
		end
		
		return false
	end	
	
	local cur_graphics_name = SystemInfo.get_graphicsDeviceName()
	local cur_device_name = SystemInfo.get_deviceModel()
	local cur_cpu_name = ZLUtil.getCpuName()

	local function final_level(lev, score)
		if lev >= 3 and SystemInfo.get_systemMemorySize() <= 2600 then
			lev = 2
		end
		local is_simulator = false
		for i = 1, #l_simulator_gpu_list do
			if cur_graphics_name:find(l_simulator_gpu_list[i]) then
				is_simulator = true
				break
			end
		end
		print("graphicsDeviceName:", cur_graphics_name)
		print("deviceModel:", cur_device_name)		
		print("cpuName:", cur_cpu_name)		
		print("final_level, score, simulator:", lev, score, is_simulator)
		return lev, score, is_simulator
	end
	
	local score = match_string(l_device_fantastic_list, cur_device_name)
	if score then
		return final_level(3, score)
	end	
	
	score = match_string(l_device_good_list, cur_device_name)
	if score then
		return final_level(2, score)
	end		
	
	score = match_string(l_device_poor_list, cur_device_name)
	if score then
		return final_level(1, score)
	end			
	
	if cur_cpu_name then
		score = end_with_string(l_cpu_fantastic_list, cur_cpu_name)
		if score then
			return final_level(3, score)
		end	
		
		score = end_with_string(l_cpu_good_list, cur_cpu_name)
		if score then
			return final_level(2, score)
		end		
		
		score = end_with_string(l_cpu_poor_list, cur_cpu_name)
		if score then
			return final_level(1, score)
		end	
	end
	
	score = match_string(l_graphics_fantastic_list, cur_graphics_name)
	if score then
		return final_level(3, score)
	end
		
	score = match_string(l_graphics_good_list, cur_graphics_name)
	if score then
		return final_level(2, score)
	end	
	
	return final_level(1, 30)	
end
