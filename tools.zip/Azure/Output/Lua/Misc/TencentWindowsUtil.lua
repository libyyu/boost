--[[
	腾讯 Windows 版相关处理
]]
local ECPanelBase = require "GUI.ECPanelBase"
local tencent_windows_cfg = _G.require_config "Configs/tencent_windows_cfg.lua"
local Lplus = require "Lplus"

---@class UIPromptCreateRoleDisabled:ECPanelBase
---@field public Commit fun():UIPromptCreateRoleDisabled @notnull
---@field public Instance fun():UIPromptCreateRoleDisabled
---@field public GetResPath fun(self:UIPromptCreateRoleDisabled):string
---@field public OnCreate fun(self:UIPromptCreateRoleDisabled)
---@field private _OnClickBtnCloudGame fun(self:UIPromptCreateRoleDisabled)
---@field private _OnClickBtnClose fun(self:UIPromptCreateRoleDisabled)
---@field private _OnClickBtnBg fun(self:UIPromptCreateRoleDisabled)
local UIPromptCreateRoleDisabled = Lplus.Extend(ECPanelBase)
do
	local def = UIPromptCreateRoleDisabled.define
	
	local l_instace
	---@return UIPromptCreateRoleDisabled
	def.static("=>", UIPromptCreateRoleDisabled).Instance = function ()
		if not l_instace then
			l_instace = UIPromptCreateRoleDisabled()
		end
		return l_instace
	end
	
	---@param self UIPromptCreateRoleDisabled
	---@return string
	def.override("=>", "string").GetResPath = function (self)
		return RESPATH.Panel_Tencent_WindowsCreateRole
	end
	
	---@param self UIPromptCreateRoleDisabled
	---@return void
	def.override().OnCreate = function (self)
		self:OnEvent("Widget/Btn_CloudGame", "onClick", function (widget)
			self:_OnClickBtnCloudGame()
		end)
		self:OnEvent("Widget/Group_Bg/Btn_Close", "onClick", function (widget)
			self:_OnClickBtnClose()
		end)
		self:OnEvent("Btn_Bg", "onClick", function (widget)
			self:_OnClickBtnBg()
		end)
	end
	
	---@param self UIPromptCreateRoleDisabled
	---@return void
	def.method()._OnClickBtnCloudGame = function (self)
		local TencentWindowsUtil = require "Misc.TencentWindowsUtil"
		TencentWindowsUtil.StartCreateRoleOnCloud()
	end
	
	---@param self UIPromptCreateRoleDisabled
	---@return void
	def.method()._OnClickBtnClose = function (self)
		self:DestroyPanel()
	end
	
	---@param self UIPromptCreateRoleDisabled
	---@return void
	def.method()._OnClickBtnBg = function (self)
		self:DestroyPanel()
	end
end
UIPromptCreateRoleDisabled.Commit()

local Protocol = require "Protocol.Protocol"
---@class WrongProtocolForGloudGame:Protocol.Protocol
---@field public Commit fun():WrongProtocolForGloudGame @notnull
---@field public GetType fun(self:WrongProtocolForGloudGame):number
local WrongProtocolForGloudGame = Lplus.Extend(Protocol)
do
	local def = WrongProtocolForGloudGame.define
	---@param self WrongProtocolForGloudGame
	---@return number
	def.override("=>", "number").GetType = function (self) return 100081 end
	WrongProtocolForGloudGame.Commit()
end

---@class UIPromptPaymentDisabled:ECPanelBase
---@field public Commit fun():UIPromptPaymentDisabled @notnull
---@field public Instance fun():UIPromptPaymentDisabled
---@field public GetResPath fun(self:UIPromptPaymentDisabled):string
---@field public OnCreate fun(self:UIPromptPaymentDisabled)
---@field private _OnClickBtnCloudGame fun(self:UIPromptPaymentDisabled)
---@field private _OnClickBtnClose fun(self:UIPromptPaymentDisabled)
---@field private _OnClickBtnBg fun(self:UIPromptPaymentDisabled)
---@field private _DoLaunchCloudGame fun(self:UIPromptPaymentDisabled)
local UIPromptPaymentDisabled = Lplus.Extend(ECPanelBase)
do
	local def = UIPromptPaymentDisabled.define
	
	local l_instace
	---@return UIPromptPaymentDisabled
	def.static("=>", UIPromptPaymentDisabled).Instance = function ()
		if not l_instace then
			l_instace = UIPromptPaymentDisabled()
		end
		return l_instace
	end
	
	---@param self UIPromptPaymentDisabled
	---@return string
	def.override("=>", "string").GetResPath = function (self)
		return RESPATH.Panel_Tencent_WindowsPay
	end
	
	---@param self UIPromptPaymentDisabled
	---@return void
	def.override().OnCreate = function (self)
		self:OnEvent("Widget/Btn_CloudGame", "onClick", function (widget)
			self:_OnClickBtnCloudGame()
		end)
		self:OnEvent("Widget/Group_Bg/Btn_Close", "onClick", function (widget)
			self:_OnClickBtnClose()
		end)
		self:OnEvent("Btn_Bg", "onClick", function (widget)
			self:_OnClickBtnBg()
		end)
	end
	
	---@param self UIPromptPaymentDisabled
	---@return void
	def.method()._OnClickBtnCloudGame = function (self)
		MsgBox.ShowMsgBox(nil, StringTable.Get(41402), nil, MsgBoxType.MBBT_YESNO, function (sender, ret)
			if ret == MsgBoxRetT.MBRT_OK then
				self:_DoLaunchCloudGame()
			end
		end)
	end
	
	---@param self UIPromptPaymentDisabled
	---@return void
	def.method()._OnClickBtnClose = function (self)
		self:DestroyPanel()
	end
	
	---@param self UIPromptPaymentDisabled
	---@return void
	def.method()._OnClickBtnBg = function (self)
		self:DestroyPanel()
	end
	
	---@param self UIPromptPaymentDisabled
	---@return void
	def.method()._DoLaunchCloudGame = function (self)
		local ECDebugOption = require "Main.ECDebugOption"
		local TencentWindowsUtil = require "Misc.TencentWindowsUtil"
		TencentWindowsUtil.StartPayOnCloud()
		
		--直接利用 offline 调试命令，还凑合吧
		ECDebugOption.Instance().offline_mode = true
		globalGame.m_Network:SendProtocol(WrongProtocolForGloudGame())
		
		MsgBox.ShowMsgBox(nil, StringTable.Get(41403), nil, MsgBoxType.MBBT_OK, function (sender, ret)
			if ret == MsgBoxRetT.MBRT_OK then
				ECDebugOption.Instance().offline_mode = false
				globalGame.m_Network:ClearReconnectTimes()
				require "Main.ECZoneMan".Instance():ReConnect()
			end
		end)
		
		self:DestroyPanel()
	end
end
UIPromptPaymentDisabled.Commit()

---@class TencentWindowsUtil:System.Object
---@field public Commit fun():TencentWindowsUtil @notnull
---@field public IsCreateRoleEnabled fun():boolean
---@field public IsPaymentEnabled fun():boolean
---@field public PromptCreateRoleDisabled fun()
---@field public PromptPaymentDisabled fun()
---@field public StartCreateRoleOnCloud fun()
---@field public StartPayOnCloud fun()
local TencentWindowsUtil = Lplus.Class("TencentWindowsUtil")
do
	local def = TencentWindowsUtil.define
	
	---@return boolean
	def.static("=>", "boolean").IsCreateRoleEnabled = function ()
		return not not tencent_windows_cfg.create_role_enabled
	end
	
	---@return boolean
	def.static("=>", "boolean").IsPaymentEnabled = function ()
		return not not tencent_windows_cfg.payment_enabled
	end
	
	---@return void
	def.static().PromptCreateRoleDisabled = function ()
		if tencent_windows_cfg.payment_redirect_cloud_game then
			UIPromptCreateRoleDisabled.Instance():ShowPanelSimple(true)
		else
			FlashTipMan.FlashTipByStrID(41401)
		end
	end
	
	---@return void
	def.static().PromptPaymentDisabled = function ()
		if _G.UsernamePlatform == "ios" then	--iOS 用云游也充不了
			FlashTipMan.FlashTipByStrID(7525)
			return
		end
		
		if tencent_windows_cfg.payment_redirect_cloud_game then
			UIPromptPaymentDisabled.Instance():ShowPanelSimple(true)
		else
			FlashTipMan.FlashTipByStrID(7522)
		end
	end
	
	---@return void
	def.static().StartCreateRoleOnCloud = function ()
		local url = tencent_windows_cfg.create_role_via_cloud_game_url
		GameUtil.OpenURL(url)
	end
	
	---@return void
	def.static().StartPayOnCloud = function ()
		local url = tencent_windows_cfg.payment_via_cloud_game_url
		GameUtil.OpenURL(url)
	end
end
return TencentWindowsUtil.Commit()
