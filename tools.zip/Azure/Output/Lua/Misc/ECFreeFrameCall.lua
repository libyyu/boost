--[[
	用于空闲帧的额外调用,这些个函数不要太复杂，而且不能影响任何逻辑，
	因为在超级垃圾的机子上有能永远执行不了
]]

local Lplus = require "Lplus"

---@class ECFreeFrameCall:System.Object
---@field public FreeCallPriority table
---@field protected m_Tasks table
---@field protected m_TotalTaskCnt number
---@field protected m_InFreeCalling boolean
---@field public Commit fun():ECFreeFrameCall @notnull
---@field public Instance fun():ECFreeFrameCall
---@field public TotalTaskCnt fun(self:ECFreeFrameCall):number
---@field public Init fun(self:ECFreeFrameCall)
---@field public AddFreeTask_Inner fun(self:ECFreeFrameCall, taskfunc:function, priority:number, no_loading:boolean)
---@field public AddTask_NoLoading fun(self:ECFreeFrameCall, taskfunc:function, ...:any)
---@field public AddFreeTask fun(self:ECFreeFrameCall, taskfunc:function, ...:any)
---@field public FreeCall fun(self:ECFreeFrameCall)
local ECFreeFrameCall = Lplus.Class("ECFreeFrameCall")
local def = ECFreeFrameCall.define

local FreeCallPriority = {
	FCP_High 		= 1,
	FCP_Normal		= 2,
	FCP_Lower		= 3,
}

-- 优先级别

---@type table
def.const("table").FreeCallPriority = FreeCallPriority

---@type table
def.field("table").m_Tasks = BLANK_TABLE_INIT

---@type number
def.field("number").m_TotalTaskCnt = 0

---@type boolean
def.field("boolean").m_InFreeCalling = false -- 是否正在空闲调用中

local l_instance
---@return ECFreeFrameCall
def.static("=>", ECFreeFrameCall).Instance = function()
	if not l_instance then
		l_instance = ECFreeFrameCall()
		l_instance:Init()
	end
	return l_instance
end

---@param self ECFreeFrameCall
---@return number
def.method("=>", "number").TotalTaskCnt = function(self)
	return self.m_TotalTaskCnt
end

---@param self ECFreeFrameCall
---@return void
def.method().Init = function(self)
	for priority = FreeCallPriority.FCP_High, FreeCallPriority.FCP_Lower do
		self.m_Tasks[priority] = {}
	end
end

--[[
	@Function 添加一个空闲任务
	@Param taskfunc 任务函数
	@Param priority 优先级别
	@Param no_loading 在异步加载队列为空的时候再执行
]] 
---@param self ECFreeFrameCall
---@param taskfunc function
---@param priority number
---@param no_loading boolean
---@return void
def.method("function", "number", "boolean").AddFreeTask_Inner = function(self, taskfunc, priority, no_loading)
	assert(self.m_InFreeCalling == false) -- 不要搞那种乱起八糟嵌套的函数
	table.insert(self.m_Tasks[priority], {taskfunc = taskfunc, no_async_loading = no_loading})
	self.m_TotalTaskCnt = self.m_TotalTaskCnt + 1
end

---@param self ECFreeFrameCall
---@param taskfunc function
---@param ... any
---@return void
def.method("function", "varlist").AddTask_NoLoading = function(self, taskfunc, ...)
	local priority = select(1, ...) or FreeCallPriority.FCP_Normal
	self:AddFreeTask_Inner(taskfunc, priority, true)
end

---@param self ECFreeFrameCall
---@param taskfunc function
---@param ... any
---@return void
def.method("function", "varlist").AddFreeTask = function(self, taskfunc, ...)
	local priority = select(1, ...) or FreeCallPriority.FCP_Normal
	self:AddFreeTask_Inner(taskfunc, priority, false)
end

local function canTaskExecute(task)
	if task.no_async_loading then
		return not GameUtil.IsAsyncLoading()
	else
		return true
	end
end

--[[
	空闲帧调用
]]
---@param self ECFreeFrameCall
---@return void
def.method().FreeCall = function(self)
	if self.m_TotalTaskCnt <= 0 then return end
	self.m_InFreeCalling = true
	for _, tasks in ipairs(self.m_Tasks) do
		local task = tasks[1]
		if task then
			if canTaskExecute(task) then
				table.remove(tasks, 1)
				self.m_TotalTaskCnt = self.m_TotalTaskCnt - 1
				task.taskfunc()
				--print("excute a free task")
				break
			end
		end
	end
	self.m_InFreeCalling = false
end

return ECFreeFrameCall.Commit()