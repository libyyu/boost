--[[
	腾讯云游戏辅助工具
]]

local Lplus = require "Lplus"
local tencent_cloudgame_cfg = _G.require_config "Configs/tencent_cloudgame_cfg.lua"

---@class TencentCloudGameUtil:System.Object
---@field public Commit fun():TencentCloudGameUtil @notnull
---@field public IsTencentCloudGame fun():boolean
---@field private _IsTencentCloudGameNoCache fun():boolean
---@field private _InitCGSdk fun()
---@field public ReportCreateRoleSuccessToTencentCloudGame fun()
---@field public IsH5CloudGame fun():boolean
local TencentCloudGameUtil = Lplus.Class("TencentCloudGameUtil")
do
	local def = TencentCloudGameUtil.define
	
	local l_cached_IsTencentCloud
	---@return boolean
	def.static("=>", "boolean").IsTencentCloudGame = function ()
		if l_cached_IsTencentCloud == nil then
			l_cached_IsTencentCloud = TencentCloudGameUtil._IsTencentCloudGameNoCache()
		end
		return l_cached_IsTencentCloud
	end
	
	---@return boolean
	def.static("=>", "boolean")._IsTencentCloudGameNoCache = function ()
		if _G.ClientCfg.IsMSDK() then
			--参考“腾讯先锋云游戏IOS登录”文档
			local kTssSDKRequestCmdIdIsEmulator = 10
			local ret = TssSDK and TssSDK.Ioctl(kTssSDKRequestCmdIdIsEmulator, ("files_dir=%s|wait=1"):format(GameUtil.GetAssetsPath()))
			print(("TencentCloudGameUtil, check IsTencentCloudGame, ret: '%s'"):format(ret))
			local matchedRet = ("retval=1|emulator_name=%s"):format(tencent_cloudgame_cfg.cloud_game_emulator_name)
			if ret and ret:find(matchedRet, 1, true) == 1 then	--ret 结尾可能有 \0，不能直接判等
				return true
			end
		end
		return false
	end
		
	local l_cgSDKInited = false
	---@return void
	def.static()._InitCGSdk = function ()
		if not l_cgSDKInited then
			l_cgSDKInited = true
			if TCgSDK then
				TCgSDK.initCgsdk()
			end
		end
	end
	
	--上报云游角色创建完成 (REFCX-10781)
	---@return void
	def.static().ReportCreateRoleSuccessToTencentCloudGame = function ()
		if _G.ClientCfg.IsMSDK() then
			TencentCloudGameUtil._InitCGSdk()
			if TCgSDK then
				print("try report create role success to TCgSDK")
				TCgSDK.sendGameEvent("{\"type\":\"CG_GAME_EVENT_CREATE_ROLE_DONE\", \"data\": {}}")
			end
		end
	end
	
	--不一定全，但一定准
	---@return boolean
	def.static("=>", "boolean").IsH5CloudGame = function ()
		local MSDKLogin = require "MSDK.MSDKLogin"
		return MSDKLogin.Instance():GetMSDKInfo("payToken"):find("^GAMEMATRIX") ~= nil
	end
end
return TencentCloudGameUtil.Commit()
