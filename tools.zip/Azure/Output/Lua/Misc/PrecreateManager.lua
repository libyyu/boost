--[[
	预创建管理，对接腾讯云游戏
	特殊功能：
	1 从云游平台获得 openid 等信息，自动登录选服
	消息格式为：
		{
			"cmd": "CGSDK_NOTIFY_CLIENT_EVENT",
			"data": { 
				"event": "{ \"type\": \"CG_GAME_EVENT_LOGIN_PARAM\", \"data\": { \"sOpenID\": \"m02\", \"accType\": \"wx\", \"os\": \"ios\" } }"
			}
		}
	2 创建角色进入游戏按钮改为预创建完毕，通知云游
		{
			"cmd": "CGSDK_NOTIFY_GAME_EVENT",
			"data": {
			"event": "{\"type\":\"CG_GAME_EVENT_PINCH_FACE_DONE\", \"data\": {}}"
			}
		}
]]

local Lplus = require "Lplus"
local json = require "Utility.json"

---@class PrecreateManager:System.Object
---@field protected m_sOpenIdFromCloud string
---@field protected m_accTypeFromCloud string
---@field protected m_osFromCloud string
---@field public Commit fun():PrecreateManager @notnull
---@field public Instance fun():PrecreateManager
---@field public Init fun(self:PrecreateManager)
---@field public TryAutoLogin fun(self:PrecreateManager)
---@field public OnFinishCreateRole fun(self:PrecreateManager)
---@field private _InitInner fun(self:PrecreateManager)
---@field private _TCgSDK_Callback fun(self:PrecreateManager, dataStr:string)
---@field private _OnCgSDKData fun(self:PrecreateManager, data:table)
---@field private _OnCgSDKNotifyClientEvent fun(self:PrecreateManager, event:table)
---@field private _OnCgGameEventLoginParam fun(self:PrecreateManager, data:table)
---@field private _sendGameEvent fun(self:PrecreateManager, event:table)
---@field private _sendGameEventRaw fun(self:PrecreateManager, eventStr:string)
local PrecreateManager = Lplus.Class("PrecreateManager")
do
	local def = PrecreateManager.define
	
	local l_instance
	---@return PrecreateManager
	def.static("=>", PrecreateManager).Instance = function ()
		if not l_instance then
			l_instance = PrecreateManager()
		end
		return l_instance
	end

	---@param self PrecreateManager
	---@return void
	def.method().Init = function (self)
		if _G.g_IsPrecreateApp and _G.ClientCfg.IsMSDK() then
			print("PrecreateManager, IsPrecreateApp, will init")
			self:_InitInner()
		end
	end
	
	---@param self PrecreateManager
	---@return void
	def.method().TryAutoLogin = function (self)
		local ECGame = require "Main.ECGame"
		local ECPanelLogin = require "GUI.LoginRole.ECPanelLogin"
		if not ECPanelLogin.Instance():IsValid() then
			return
		end
		
		if self.m_sOpenIdFromCloud ~= "" and self.m_accTypeFromCloud ~= "" then
			local auth = ""
			if self.m_accTypeFromCloud == "qq" then
				auth = "qq"
			elseif self.m_accTypeFromCloud == "wx" then
				auth = "wechat"
			end
			local platform = "android"
			if self.m_osFromCloud == "android" then
				platform = "android"
			elseif self.m_osFromCloud == "ios" then
				platform = "ios"
			end
			
			local userName = ("%s$%s#%s"):format(self.m_sOpenIdFromCloud, auth, platform)
			print("auto login with userName: ", userName)
			globalGame.m_Network:SetUserName(userName)
			globalGame.m_Network:SetAuth("")	--预创建服不需密码
	
			local MSDKEvent = require "Event.MSDKEvent"
			ECGame.EventManager:raiseEvent(nil, MSDKEvent.MSDKLoginSuccessEvent.new())
			
			ECPanelLogin.Instance():DoLogin()
		end
	end
	
	---@param self PrecreateManager
	---@return void
	def.method().OnFinishCreateRole = function (self)
		self:_sendGameEventRaw("{\"type\":\"CG_GAME_EVENT_PINCH_FACE_DONE\", \"data\": {}}")
	end

	---@type string
	def.field("string").m_sOpenIdFromCloud = ""
	
	---@type string
	def.field("string").m_accTypeFromCloud = ""
	
	---@type string
	def.field("string").m_osFromCloud = ""
	
	---@param self PrecreateManager
	---@return void
	def.method()._InitInner = function (self)
		if TCgSDK then
			print("before initCgsdk, TCgSDK.isClougGameEnv: ", TCgSDK.isClougGameEnv())	--测试用
			print("PrecreateManager, initCgsdk")
			TCgSDK.initCgsdk()
			print("after initCgsdk, TCgSDK.isClougGameEnv: ", TCgSDK.isClougGameEnv())	--测试用
		end
		if TCgSDK then
			print("PrecreateManager, will init TCgSDK")			--本应判断 isClougGameEnv，有 g_IsPrecreateApp 判断也够了
			local old_TCgSDK_Callback = _G.TCgSDK_Callback
			function _G.TCgSDK_Callback (data)
				if old_TCgSDK_Callback then old_TCgSDK_Callback(data) end
				PrecreateManager.Instance():_TCgSDK_Callback(data)
			end
			
			TCgSDK.setupCallback(true)
		end
	end
	
	---@param self PrecreateManager
	---@param dataStr string
	---@return void
	def.method("string")._TCgSDK_Callback = function (self, dataStr)
		print("PrecreateManager, TCgSDK_Callback: ", dataStr)
		
		local data = json.decode(dataStr)
		if not data then
			warn("PrecreateManager, failed to decode data: ", dataStr)
			return
		end
		
		self:_OnCgSDKData(data)
	end
	
	---@param self PrecreateManager
	---@param data table
	---@return void
	def.method("table")._OnCgSDKData = function (self, data)
		if data.cmd == "CGSDK_NOTIFY_CLIENT_EVENT" then
			if not data.data or not data.data.event then
				warn("PrecreateManager, invalid data")
				return
			end
			local eventStr = data.data.event
			local event = json.decode(eventStr)
			if not event then
				warn("PrecreateManager, failed to decode event: ", eventStr)
				return
			end
			self:_OnCgSDKNotifyClientEvent(event)
		else
			warn("PrecreateManager, unknown data cmd: ", data.cmd)
		end
	end
	
	---@param self PrecreateManager
	---@param event table
	---@return void
	def.method("table")._OnCgSDKNotifyClientEvent = function (self, event)
		if event.type == "CG_GAME_EVENT_LOGIN_PARAM" then
			if not event.data then
				warn("PrecreateManager, invalid data")
				return
			end
			self:_OnCgGameEventLoginParam(event.data)
			
			GameUtil.AddGlobalTimer(0, true, function ()
				self:TryAutoLogin()
			end)
		else
			warn("PrecreateManager, invalid data")
			return
		end
	end
	
	---@param self PrecreateManager
	---@param data table
	---@return void
	def.method("table")._OnCgGameEventLoginParam = function (self, data)
		self.m_sOpenIdFromCloud = data.sOpenID or ""
		self.m_accTypeFromCloud = data.accType or ""
		self.m_osFromCloud = data.os or ""
	end
	
	---@param self PrecreateManager
	---@param event table
	---@return void
	def.method("table")._sendGameEvent = function (self, event)
		local eventStr = json.encode(event)
		self:_sendGameEvent(eventStr)
	end
	
	---@param self PrecreateManager
	---@param eventStr string
	---@return void
	def.method("string")._sendGameEventRaw = function (self, eventStr)
		print("PrecreateManager, TCgSDK.sendGameEvent: ", eventStr)
		TCgSDK.sendGameEvent(eventStr)
	end
end
return PrecreateManager.Commit()
