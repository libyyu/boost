--[[
	平滑帧的调用,用于密集型的调用，分帧执行
]]

local Lplus = require "Lplus"

---@class ECSmoothFrameCall:System.Object
---@field protected m_CallUniqueID number
---@field protected m_CurExecuteID number
---@field protected m_CurFrameExeCnt number
---@field protected m_SmoothCalls table
---@field protected m_SmoothParams table
---@field protected m_SmoothTimer number
---@field protected m_CurSmoothParam table
---@field protected m_Release boolean
---@field protected m_RenderFrameCount number
---@field protected m_DebugLevel number
---@field public Commit fun():ECSmoothFrameCall @notnull
---@field public Create fun(param:table):ECSmoothFrameCall
---@field public Release fun(self:ECSmoothFrameCall)
---@field public OnQualitySetting fun()
---@field public SetDebugLevel fun(self:ECSmoothFrameCall, debugLevel:number)
---@field private _OnQualityEval fun(self:ECSmoothFrameCall)
---@field private _ExecuteOnce fun(self:ECSmoothFrameCall)
---@field public Clear fun(self:ECSmoothFrameCall)
---@field private _Restart fun(self:ECSmoothFrameCall)
---@field public Sleep fun(self:ECSmoothFrameCall)
---@field public Wakeup fun(self:ECSmoothFrameCall)
---@field private _CreateTimer fun(self:ECSmoothFrameCall)
---@field private _AddCall fun(self:ECSmoothFrameCall, cb:function)
---@field public SmoothCall fun(self:ECSmoothFrameCall, func:function, ...:any)
local ECSmoothFrameCall = Lplus.Class("ECSmoothFrameCall")
local def = ECSmoothFrameCall.define

---@type number
def.field("number").m_CallUniqueID = 0

---@type number
def.field("number").m_CurExecuteID = 0

---@type number
def.field("number").m_CurFrameExeCnt = 0 -- 当前轮次执行过多少个， 这个不一定是帧

---@type table
def.field("table").m_SmoothCalls = BLANK_TABLE_INIT

---@type table
def.field("table").m_SmoothParams = nil

---@type number
def.field("number").m_SmoothTimer = 0

---@type table
def.field("table").m_CurSmoothParam = nil

---@type boolean
def.field("boolean").m_Release = false

---@type number
def.field("number").m_RenderFrameCount = 0 -- 当前渲染帧的索引

---@type number
def.field("number").m_DebugLevel = 0

--[[
	@Param param 形如{
		[1] = { -- 档次，暂时按QualityLevel的分级来
			interval = 0, -- 每隔多长时间执行一次， 
			call_count = 1, -- 没次最多执行多少个
		},
		[2] = {
	
		},
		[3] = {
		
		}
	}
]]

---@type table<ECSmoothFrameCall, boolean>
local l_smoothFrameCalls = setmetatable({}, {__mode = "k"})

---@param param table
---@return ECSmoothFrameCall
def.final("table", "=>", ECSmoothFrameCall).Create = function(param)
	local obj = ECSmoothFrameCall()
	obj.m_SmoothParams = param
	l_smoothFrameCalls[obj] = true
	return obj
end

---@param self ECSmoothFrameCall
---@return void
def.method().Release = function(self)
	self.m_Release = true
	self:_ExecuteOnce()
	l_smoothFrameCalls[self] = nil
end

-- 重新设置分级
---@return void
def.static().OnQualitySetting = function()
	for smoothCall, _ in pairs(l_smoothFrameCalls) do
		smoothCall:_OnQualityEval()
	end
end

---@param self ECSmoothFrameCall
---@param debugLevel number
---@return void
def.method("number").SetDebugLevel = function(self, debugLevel)
	self.m_DebugLevel = debugLevel
	self:_OnQualityEval()
end

---@param self ECSmoothFrameCall
---@return void
def.method()._OnQualityEval = function(self)
	local curQualityLv = (self.m_DebugLevel ~= 0) and self.m_DebugLevel or _G.cur_quality_level
	for k = curQualityLv, 1, -1 do
		local smoothParam = self.m_SmoothParams[k]
		if smoothParam then
			if smoothParam == self.m_CurSmoothParam then
				break
			else
				self.m_CurSmoothParam = smoothParam
				self:_Restart()
				break
			end
		end
	end
end

---@param self ECSmoothFrameCall
---@return void
def.method()._ExecuteOnce = function(self)
	--warn("smoothcall pre finished")
	if not self.m_Release and self.m_CurFrameExeCnt >= self.m_CurSmoothParam.call_count then return end
	--warn("smoothcall begin", self.m_CurFrameExeCnt, self.m_CurSmoothParam.call_count)
	local canCallCnt = 0
	local maxCall = self.m_CallUniqueID - self.m_CurExecuteID
	local maxReserveCallCnt = self.m_CurSmoothParam.call_count - self.m_CurFrameExeCnt
	if self.m_Release then
		canCallCnt = math.max(maxCall, maxReserveCallCnt)
	else
		canCallCnt = maxReserveCallCnt
	end

	local realCallCnt = 0
	for callIdx = 1, canCallCnt do
		--self.m_CurExecuteID = self.m_CurExecuteID + 1
		local curExecuteID = self.m_CurExecuteID + 1
		local call = self.m_SmoothCalls[curExecuteID]
		self.m_SmoothCalls[curExecuteID] = nil
		if call then
			local bSucc, err = xpcall(call, function(err) return debug.traceback(err) end)
			if not bSucc then
				Debug.LogError(err)
			end
			self.m_CurExecuteID = curExecuteID
			realCallCnt = realCallCnt + 1
		else
			break
		end
	end
	self.m_CurFrameExeCnt = self.m_CurFrameExeCnt + realCallCnt
	if next(self.m_SmoothCalls) == nil then
		self:Sleep()
	end
	--warn("smoothcall end", realCallCnt, self.m_CurSmoothParam.call_count)
end

---@param self ECSmoothFrameCall
---@return void
def.method().Clear = function(self)
	self.m_SmoothCalls = {}
	self:Sleep()
end

---@param self ECSmoothFrameCall
---@return void
def.method()._Restart = function(self)
	self:Sleep()
	self:Wakeup()
end

---@param self ECSmoothFrameCall
---@return void
def.method().Sleep = function(self)
	if self.m_SmoothTimer ~= 0 then
		GameUtil.RemoveGlobalTimer(self.m_SmoothTimer)
		self.m_SmoothTimer = 0
	end

	if next(self.m_SmoothCalls) == nil then
		self.m_CallUniqueID = 0
		self.m_CurExecuteID = 0
	end
end

---@param self ECSmoothFrameCall
---@return void
def.method().Wakeup = function(self)
	if self.m_SmoothTimer == 0 and next(self.m_SmoothCalls) ~= nil then
		self:_CreateTimer()
	end
	if next(self.m_SmoothCalls) then
		self:_ExecuteOnce()
	end
end

---@param self ECSmoothFrameCall
---@return void
def.method()._CreateTimer = function(self)
	if self.m_SmoothTimer ~= 0 then
		GameUtil.RemoveGlobalTimer(self.m_SmoothTimer)
	end
	self.m_SmoothTimer = GameUtil.AddGlobalTimer(self.m_CurSmoothParam.interval / 1000, false, function()
		-- 如果本帧还没处理过，那么从0开始，否则从执行到的地方开始
		if self.m_RenderFrameCount ~= Time.frameCount then
			self.m_CurFrameExeCnt = 0
			self.m_RenderFrameCount = Time.frameCount
		end
		self:_ExecuteOnce()
	end)
end

---@param self ECSmoothFrameCall
---@param cb function
---@return void
def.method("function")._AddCall = function(self, cb)
	self.m_CallUniqueID = self.m_CallUniqueID + 1
	self.m_SmoothCalls[self.m_CallUniqueID] = cb
	self:Wakeup()
end

---@param self ECSmoothFrameCall
---@param func function
---@param ... any
---@return void
def.method("function", "varlist").SmoothCall = function(self, func, ...)
	if self.m_CurSmoothParam == nil then
		self:_OnQualityEval()
	end

	-- 先看看能不能立即执行了
	if self.m_CurFrameExeCnt < self.m_CurSmoothParam.call_count then
		-- 消息包在timer前处理，可能导致第一帧处理了两倍的调用
		local renderedFrameCount = Time.frameCount
		if self.m_RenderFrameCount ~= renderedFrameCount then
			self.m_RenderFrameCount = renderedFrameCount
			self.m_CurFrameExeCnt = 1
		else
			self.m_CurFrameExeCnt = self.m_CurFrameExeCnt + 1
		end
		func(...)
		return
	end

	local cb = func
	if select('#', ...) > 0 then
		local param = {...}
		cb = function() func(unpack(param)) end
	end
	self:_AddCall(cb)
end

return ECSmoothFrameCall.Commit()