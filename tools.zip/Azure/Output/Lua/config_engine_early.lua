local l_IsWindowsSimuMobile
--是否(内部开发时)用 Windows 模拟手机
function _G.IsWindowsSimuMobile()
	if l_IsWindowsSimuMobile == nil then
		l_IsWindowsSimuMobile = ConfigEngine.GetPlatformName() == "Windows"
				and (ConfigEngine.GetCommandLineParam == nil or ConfigEngine.GetCommandLineParam("--simulate_mobile=") == "1")	--兼容一下旧客户端
	end
	return l_IsWindowsSimuMobile
end

local  function config_engine_early()
	ConfigEngine.SetConsoleVariable("gc.MaxObjectsInGame", "200000")
	local platform_name = ConfigEngine.GetPlatformName()
	if platform_name == "Android" then
		ConfigEngine.ForceSetRHISupportsRHIThread(1)
			
	elseif platform_name == "IOS" then
	--else
	--	win: 不要Force，集成显卡的机器会崩
	--	ConfigEngine.ForceSetRHISupportsRHIThread(1)
		ConfigEngine.SetConsoleVariable("a.IOSPlatformDefaultStackSize", "524288")
		ConfigEngine.SetConsoleVariable("rhi.Metal.ResourcePurgeInPool", "1")
	
	elseif platform_name == "Windows" then
		if not _G.IsWindowsSimuMobile() then
			ConfigEngine.SetConsoleVariable("azure.GameSingleInstance", "1")
		end

	end

	if not _G.GIsShipping then
		if ConfigEngine.SetEngineDebugFlag then
			ConfigEngine.SetEngineDebugFlag(true)
		end
	end	

	ConfigEngine.AppendCommandLineText(" -azurethreads")
	--ConfigEngine.AppendCommandLineText(" -opengl -FeatureLevelES31")
end

config_engine_early()
