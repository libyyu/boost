--- PVMovie
--- Generate by IntelliJ IDEA
--- Create by lidengfeng
--- DateTime: 2021/4/14 16:54
---

-- 标记为更新后重载
if _G.MarkReloadAfterUpdate then _G.MarkReloadAfterUpdate() end
--由于更新之前，只会打开特定的资源包，这里将资源放到UI所在的layer了
local Panel_Movie = "UI/UMG/Update/panel_update_media"
local m_playlistResource = 'UI/UMG/Update/MediaPlaylist'
local m_playermediaResource = 'UI/UMG/Update/MediaPlayer'
local m_mediaUIMaterialResource = 'UI/UMG/Update/Movie1UI'
local m_mediaSoundResource = 'UI/UMG/Update/mediaSound'
local pv_config = dofile "Configs/pv_config.lua"
local warn = warn or print

local PVM = {}
local m_panel
local is_ready = false
local is_playing = false
local is_skip = false
local is_exit = false
local has_ever_played = false
local is_media_preparing
local is_media_ready
--预加载资源列表
local preloadAssetList
local callBeforeExit

local function log(...)
    print("[:PV]", ...)
end
local function logWarn(...)
    warn("[:PV]", ...)
end


---@type userdata
local m_mediaCanvas
---@type userdata
local m_mediaPlaylist
---@type userdata
local m_mediaPlayer
---@type userdata
local m_mediaUIMaterial
---@type userdata
local m_mediaSound
---@type userdata
local m_bindOnMediaOpen
---@type userdata
local m_bindOnEndReached

local m_sourceIndex = 0
local m_sourceList = {}

local function mystartswith(self, s)
    local b, e = self:find(s)
    if not b or not e then return false end
    return b == 1 and e-b+1 == #s
end

function PVM.Init(panel)
    m_panel = panel
    PVM.OnCreate()
    PVM.OnShow(true)
end
function PVM.UnInit()
    PVM.OnShow(false)
    PVM.OnDestroy()
    m_panel = nil
end

function PVM.ShowWidget(name, show, nolog)
    if not nolog then
        log("show_panel widget", name, show)
    end
    local panel = m_panel:GetWidgetFromName(name)
    if panel then
        panel:SetActive(show)
    else
        logWarn("widet " .. name .. " not found")
    end
end

function PVM.OnDestroy()
    PVM._ReleaseMedia()
    m_mediaCanvas = nil
    if m_panel then
        local btnSkip = m_panel:FindDirect("Widget/Control/Skip")
        if btnSkip then
            btnSkip:setOnClickFunc(nil)
        end

        m_panel:RemoveFromParent()
        GameUtil.RemoveRef(m_panel)
        m_panel = nil
    end
end

function PVM.OnCreate()
    log("create media canvas")

    m_mediaCanvas = m_panel:FindDirect("Widget/Canvas/Video_Content")
    m_mediaCanvas:SetActive(false)
    --创建多媒体播放器
    PVM._CreateMedia()
    --每次都重置播放列表
    PVM.ClearAll ()

    is_ready = false

    local function onFinish(nSuccessCount)
        log("init media source playlists ", nSuccessCount)
        is_ready = true
    end

    local media_list = pv_config.GetCurrentPVAssets()

    local nTotalCount = 0
    local nSuccessCount = 0
    for _, v in ipairs(media_list) do
        PVM._AddSourceToPlaylist (v.furl, v.ftype, function(bSucess, ...)
            nTotalCount = nTotalCount + 1
            if bSucess then
                nSuccessCount = nSuccessCount + 1
            end
            if nTotalCount == #media_list then
                onFinish(nSuccessCount)
            end
        end)
    end

    local btnSkip = m_panel:FindDirect("Widget/Control/Skip")
    if btnSkip then 
        btnSkip:setOnClickFunc(function()
            if PVM.CanSkippable() then
                is_skip = true
            end
        end)
    end
end
function PVM.OnShow(b)

end
---是否可以跳过
function PVM.CanSkippable()
    --非shipping版本可以跳过
    --if not _G.GIsShipping then
    --    return true
    --end

    return LocalFlag:Get(LocalFlag.Type.PVCanSkip)
end

function PVM._OnMediaOpened ()
    log("media open success")
    has_ever_played = true

    --预加载资源
    if preloadAssetList then
        for _, res in ipairs(preloadAssetList) do
            log("pre load ", res)
            GameUtil.AsyncLoad(res, function() end, "WidgetBlueprintGeneratedClass")
        end

        preloadAssetList = nil
    end
end
function PVM._OnMediaEndReached ()
    log("media endreached")
    PVM._PlayNext ()
end
function PVM._OnMediaOpenedFailed()
    PVM._PlayNext ()
end
function PVM._OnMediaListEndReached()
    log("playlist endreached")
    is_exit = true
end
function PVM._OnMediaPreparing()
    log("mediasource is prepared")
end
function PVM._OnMediaReady()
    log("mediasource is ready")
    m_mediaCanvas:SetActive(true)
end

function PVM._CreateMedia()
    log("create media")
    if not m_mediaPlaylist then
        m_mediaPlaylist = GameUtil.SyncLoad(m_playlistResource, "MediaPlaylist")
    end
    if not m_mediaPlayer then
        m_mediaPlayer = GameUtil.SyncLoad(m_playermediaResource, "MediaPlayer")
    end
    if not m_mediaUIMaterial then
        m_mediaUIMaterial = GameUtil.SyncLoad(m_mediaUIMaterialResource)
    end

    if not m_mediaPlayer then
        logWarn("create media failed!!!")
        return
    end
    --创建MediaSound
    local asset = GameUtil.SyncLoad(m_mediaSoundResource, "BlueprintGeneratedClass")
    if asset then
        local actor = GameUtil.Instantiate(asset)
        m_mediaSound = actor:GetComponentInChildren("MediaSoundComponent")
    end
    m_mediaSound:SetMediaPlayer(m_mediaPlayer)

    m_bindOnMediaOpen = m_mediaPlayer:bindOnMediaOpened(function(_)
        PVM._OnMediaOpened()
    end, true)
    m_bindOnEndReached = m_mediaPlayer:bindOnEndReached(function(_)
        PVM._OnMediaEndReached()
    end, true)

    m_mediaCanvas:SetBrushFromAtlas(nil)
    m_mediaCanvas:SetBrushFromMaterial(m_mediaUIMaterial)
end

function PVM._ReleaseMedia()
    log("release media")
    if m_mediaPlayer then
        m_mediaPlayer:Close()
    end

    PVM.ClearAll ()

    if m_bindOnMediaOpen and not m_bindOnMediaOpen:is_nil() then
        m_mediaPlayer:unbindOnMediaOpened(m_bindOnMediaOpen)
        m_bindOnMediaOpen = nil
    end
    if m_bindOnEndReached and not m_bindOnEndReached:is_nil() then
        m_mediaPlayer:unbindOnEndReached(m_bindOnEndReached)
        m_bindOnEndReached = nil
    end

    if m_mediaSound and not m_mediaSound:is_nil() then
        m_mediaSound:GetOwner():Destroy()
    end

    m_mediaPlaylist = nil
    m_mediaPlayer = nil
    m_mediaUIMaterial = nil
    m_mediaSound = nil
end

function PVM.ClearAll ()
    log("clear all playlists")
    m_sourceIndex = 0
    m_sourceList = {}
    if m_mediaPlaylist then
        local num = m_mediaPlaylist:Num()
        for i=num, 1, -1 do
            m_mediaPlaylist:RemoveAt(i-1)
        end
    end
end

function PVM._AddSourceToPlaylist (fileURL, fileType, onFinish)
    if not m_mediaPlaylist then
        return
    end
    log("add source to playlists", fileURL, fileType)
    --在列表中查找
    for sourceIndex, v in ipairs(m_sourceList) do
        if v.fileURL == fileURL and v.fileType == fileType and v.localPath then--已经在播放队列了
            onFinish(true, v, sourceIndex)
            return
        end
    end

    local function onFinishWrapper(fileURL_, fileType_, localPath)
        local data = {}
        data.fileURL = fileURL_
        data.fileType = fileType_
        data.localPath = localPath
        table.insert(m_sourceList, data)

        onFinish(true, data, #m_sourceList)
    end

    if fileType == 0 then --本地视频
        local filepath = fileURL
        if not mystartswith(filepath, "./") then
            filepath = "./" .. filepath
        end
        local ret = m_mediaPlaylist:AddFile(filepath)
        if ret then
            onFinishWrapper(fileURL, 0, filepath)
        else
            warn(fileURL .. "add to playlist failed. ", filepath)
            onFinish(false, nil, 0)
        end

    elseif fileType == 1 then --需要下载到本地的视频
        --TODO:更新阶段，不应该支持
    elseif fileType == 2 then --在线视频
        local ret = m_mediaPlaylist:AddUrl(fileURL)
        if ret then
            onFinishWrapper(fileURL, 2, fileURL)
        else
            warn(fileURL .. "add url to playlist failed.")
            onFinish(false, nil, 0)
        end
    end
end

function PVM._PlaySourceIndex (sourceIndex)
    log("_PlaySourceIndex", sourceIndex)
    if not m_mediaPlayer then
        return false
    end
    local num = m_mediaPlaylist:Num()
    if num == 0 then
        return false
    end

    if sourceIndex <1 or sourceIndex > num then
        return false
    end

    is_media_preparing = false
    is_media_ready = false

    local ret = m_mediaPlayer:OpenPlaylistIndex(m_mediaPlaylist, sourceIndex-1)
    if not ret then
        logWarn("OpenPlaylistIndex failed:", sourceIndex)
        PVM._OnMediaOpenedFailed()

        return false
    end

    return true
end

function PVM._PlayNext ()
    --log("play next", m_sourceIndex + 1)
    if not m_mediaPlayer then
        return
    end
    local num = m_mediaPlaylist:Num()

    if m_sourceIndex < num then
        m_sourceIndex = m_sourceIndex + 1
        PVM._PlaySourceIndex(m_sourceIndex)
    else
        PVM._OnMediaListEndReached()
    end
end

function PVM.Starup(pre_res)
    log("load movie panel")
    local obj = GameUtil.SyncLoad(Panel_Movie, "WidgetBlueprintGeneratedClass")
    coro.yield()
    if not obj then
        logWarn("failed to load pv panel", Panel_Movie)
        return
    end
    preloadAssetList = pre_res

    local movie_panel = UserWidget.CreateWidget(obj)
    movie_panel:SetMsgTable({})
    movie_panel:AddToViewport(10)
    PVM.Init(movie_panel)
    coro.yield()
end

function PVM.StartPlayLoop(cb)
    if not m_panel then
        if cb then cb() end
        return
    end
    callBeforeExit = cb
    if not m_mediaPlayer then
        if m_panel then
            PVM._OnExit()
        end
        return
    end

    log("enter pv loop")
    is_playing = false
    is_skip = false
    is_exit = false

    while true do
        if is_ready then
            if not is_playing then
                is_playing = true
                PVM._PlayNext ()
            else
                if is_exit then
                    PVM._OnExit()
                    break
                elseif is_skip then
                    PVM._OnSkip()
                end

                if not is_media_preparing and m_mediaPlayer and m_mediaPlayer:IsPreparing() then
                    is_media_preparing = true
                    PVM._OnMediaPreparing()
                end

                if not is_media_ready and m_mediaPlayer and m_mediaPlayer:IsReady() then
                    is_media_ready = true
                    PVM._OnMediaReady()
                end
            end
        end
        coro.yield()
    end
end

function PVM._OnExit()
    log("exit pv")
    if has_ever_played then
        --记录完成看过标记
        return LocalFlag:Set(LocalFlag.Type.PVCanSkip, true)
    end

    --在视频销毁之前调用
    if callBeforeExit then
        callBeforeExit()
        callBeforeExit = nil
    end

    PVM.UnInit()
end

function PVM._OnSkip()
    log("skip", m_sourceIndex)
    PVM._PlayNext ()
end

return PVM