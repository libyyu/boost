--require_config_stable will be called from MiscDef which requre in ECMSDK
--require_config_stable define in ECUtility
--if we require ECUtility here, we must preload some other lua files
--so just define a temp version here, and which would be override later

--local EntryPointConfig = require "EntryPointConfig"

if not _G.versionFlag_InitGameReloadModuleNameFixed then
	require "Utility.InitGameReloader".ReloadModulePatchVersion()
end

local function GetLoginSDKType()
	local ClientCfg = require "Configs.ClientCfg"
	if MSDK then
		local needMSDK = false
		if (GameUtil.GetPlatformName() == "Windows" and not _G.IsWindowsSimuMobile())
				or GameUtil.GetPlatformName() == "IOS" or GameUtil.GetPlatformName() == "Android" then
			needMSDK = true
		end

		if needMSDK and ClientCfg.IsTencentChannel() then
			return "msdk"
		end
	elseif UniSDK then
		local needUniSDK = false
		if GameUtil.GetPlatformName() ~= "Windows" then
			if not require "Utility.BranchUtil".IsBanshu() then
				--TODO: 有可能就是一个母包，需要判断UniSDK.config文件是否存在。
				--TODO: 母包使用shadow方式登录
				needUniSDK = true
			end
		end
		if needUniSDK and ClientCfg.IsOverseaChannel() then --海外渠道才使用unisdk
			if GameUtil.GetPlatformName() == "Android" and UniSDK.IsSkipUniSDK and UniSDK.IsSkipUniSDK() then
				warn("unisdk is skiped, this apk maybe a base-package, will use shadow to login.")
			else
				return "unisdk"
			end
		end
	else
		if DzoSDK then
			require "Utility.BranchUtil"
			if _G.IsBranch("oversea_vietnam") then
				return "dzosdk"
			end
		end

		if LoongSDK then
			local needPCSDK = false
			if GameUtil.GetPlatformName() == "Windows" and not _G.IsWindowsSimuMobile() then
				needPCSDK = true
			end
			if needPCSDK and ClientCfg.IsOverseaChannel() then --海外渠道才使用pcsdk
				return "pcsdk"
			end
		end
	end
end
---初始化登录SDK
local function InitLoginSDK()
	--这里仅仅是初始的默认登录类型，后续可以通过命令行设置
	local ltype = GetLoginSDKType()
	if ltype == "msdk" then
		print(">>>>> msdk init")
		_G.ClientCfg.SetClientLoginType(_G.ClientCfg.CLIENT_LOGIN_TYPE.MSDK)

		local ECMSDK = require("MSDK.ECMSDK")
		ECMSDK.Instance():InitMSDK()
	elseif ltype == "unisdk" then
		print(">>>>> zulongsdk init")
		_G.ClientCfg.SetClientLoginType(_G.ClientCfg.CLIENT_LOGIN_TYPE.UNISDK)

		local ECUNISDK = require("ProxySDK.ECUniSDK")
		ECUNISDK.Instance():Init()
	elseif ltype == "pcsdk" then
		print(">>>>> pcsdk init")
		_G.ClientCfg.SetClientLoginType(_G.ClientCfg.CLIENT_LOGIN_TYPE.PCSDK)

		local ECPCSDK = require("PCSDK.PCSDK")
		ECPCSDK.Instance():InitSDK()
	elseif ltype == "dzosdk" then
		print(">>>>> dzosdk init")
		_G.ClientCfg.SetClientLoginType(_G.ClientCfg.CLIENT_LOGIN_TYPE.PCSDK)

		local ECDzoSDK = require("ProxySDK.ECDzoSDK")
		ECDzoSDK.Instance():InitSDK()
	else
		print(">>>>> shadow sdk init")
		_G.ClientCfg.SetClientLoginType(_G.ClientCfg.CLIENT_LOGIN_TYPE.SHADOW)
	end
end

function _G.IsPreDownloadEnable( ... )
	if GameUtil.GetPlatformName() == "Windows" then
		return true
	else
		return false
	end
	--[[
	return (bit.band(_G.DirForbidMask, _DIR_FORBID_PERDOWNLOAD_BIT) == 0)
			and (bit.band(_G.ServerNotifyForbidMask, _DIR_FORBID_PERDOWNLOAD_BIT) == 0)]]
end

--应对获取下载目录API因为网络原因可能卡顿的处理
local _NextTryGetDirTimeMs = 0
local _NextTryGetDirIntervalMs = 60*1000
local _GetDirTimeOutMs = 1000

--应对获取下载目录API有jni资源泄露的处理
local _PredownloadDirCaches = {} -- { [filename] = { lastDir = "", lastTime = xxx}, xxx }
local _NextTryGetDirIntervalMs2 = 2*60*60*1000

function _G.GetPreDownloadPackageDir(fileName)
	print("GetPreDownloadDir ", fileName)
	if not _G.IsPreDownloadEnable() then
		return ""
	end
	local preDownloadDir
	if GameUtil.GetPlatformName() == "Windows" then
		preDownloadDir = GameUtil.GetAssetsPath() .. "/testpackage/"
	else
		--[[
		if _NextTryGetDirTimeMs ~= 0 then
			if GameUtil.GetMillisecondsFromEpoch() > _NextTryGetDirTimeMs then
				_NextTryGetDirTimeMs = 0
			else
				warn("don't try get dir because timeout")
				return ""
			end
		end

		local dirCacheInfo = _PredownloadDirCaches[fileName]
		if not dirCacheInfo then
			dirCacheInfo = {
				lastDir = "",
				lastTime = 0,
			}
			_PredownloadDirCaches[fileName] = dirCacheInfo
		end

		local startMs = GameUtil.GetMillisecondsFromEpoch()
		local cacheValid = (startMs - dirCacheInfo.lastTime) < _NextTryGetDirIntervalMs2
		if (dirCacheInfo.lastTime ~= 0) and cacheValid then
			print("return cache dir ", dirCacheInfo.lastDir, fileName)
			return dirCacheInfo.lastDir
		end
		dirCacheInfo.lastTime = startMs
		preDownloadDir = TApm.GetDataFromTGPA("GetPredownPath", fileName)
		dirCacheInfo.lastDir = preDownloadDir
		local endMs = GameUtil.GetMillisecondsFromEpoch()
		local dt = endMs - startMs
		print("preDownloadDir get dt is ", dt)
		if dt > _GetDirTimeOutMs then
			warn("get predownload timeout")
			_NextTryGetDirTimeMs = endMs + _NextTryGetDirIntervalMs
		end]]
	end
	print("preDownloadDir is ", preDownloadDir)
	return preDownloadDir
end

function _G.NotifyPredownloadPackage(fileName,BeforeReadyForUseStage,StartToProcess,PackageSize,PackageIndex)
	print("NotifyPredownloadPackage ", fileName)
	if not StartToProcess then
		--[[
		TApm.UpdateGameInfoAsMap("PreDownload", {
			EnablePredownload = "1",
			ErrCode = "0",
			FindPatchfile = "1",
			OpenPatch = "1",
			Patchfile = fileName,
			PredownloadType = "90",
		})]]
	end

	if not BeforeReadyForUseStage then
		local ECInGameUpdate = require "IGU.ECInGameUpdate"
		ECInGameUpdate.Instance():OnNotifyPredownloadPackage(StartToProcess)
	end
end

function _G.NotifyPredownloadVersion(version)
	print("NotifyPredownloadVersion ", version)
	--[[
	TApm.UpdateGameInfo(1, "1")
	TApm.UpdateGameInfo(2, tostring(version))]]
end

local FinalInitStage = function ( ... )
	_G.MemoryMark"FinalInitStage"
    print("FinalInitStage")
	--Patcher.HttpSetTimeout(15*1000)
    -- 下载额外的包
    --Android需要额外资源包目录
	--[[
    if EntryPointConfig.ExtraPackageFolder then
		local update = ...
		local update_predown_progress = update[3]

        local extraPackagePath = GameUtil.GetDocumentPath() .. "/" .. EntryPointConfig.ExtraPackageFolder
	end]]

	-- 小包系统初始化
	if _G.g_IsMiniApp then
		local update = ...
		local update_predown_progress = update[3]
		local igu_entrylist_path = "Configs/igu_auto_gen/igu_entrylist.dat"
		local igu_packagesinfo_path = "Configs/igu_auto_gen/igu_packagesinfo.dat"
		if af.IsFileExist(igu_entrylist_path) then
			if not InGameUpdate.IsInit() then
				-- 这时候EntryPoint.lua还没加载，在这里临时处理下
				function _G.OnInGameUpdateFatalError(ErrorFlag, NeedExitGameFlag)
					if NeedExitGameFlag then
						warn(("InGameUpdate meet fatal error %d"):format(ErrorFlag))
						GameUtil2.QuitGame()
					end
				end

				local inGameUpdateConfig = _G.GetInGameUpdateConfig()
				if not inGameUpdateConfig.disablePrerequisite then
					local ingame_update_config = _G.require_config("Configs/ingame_update_config.lua")
					if ingame_update_config.predownload_abtest_enable then
						-- 如果没有强制关闭，则根据设备ID进行AB测试
						if GameUtil.StrCrc32 then
							local deviceIdCrc32 = GameUtil.StrCrc32(SystemInfo.deviceUniqueIdentifier)
							warn("deviceIdCrc32="..deviceIdCrc32)
							if deviceIdCrc32 % 2 == 0 then
								inGameUpdateConfig.disablePrerequisite = true
							end
						end
					end
					-- 送审模式下，禁用预下载包
					if _G.IsEvaluation() then
						inGameUpdateConfig.disablePrerequisite = true
					end
					--[[
					-- 双OBB模式下，理论上预下载包相关资源都在Patch.obb里了，所以不用下了
					if _G.g_UseAzureDoubleOBB then
						inGameUpdateConfig.disablePrerequisite = true
					end]]
				end

				if not inGameUpdateConfig.baseUrl or inGameUpdateConfig.baseUrl == "" then
					update_predown_progress(false, 0, 0, 0, "Cannot find valid inGameUpdateConfig.baseUrl mini package!!!")
					error("Cannot find valid inGameUpdateConfig.baseUrl mini package!!!")
				end

				local ret = InGameUpdate.Init(
						igu_entrylist_path,
						inGameUpdateConfig.baseUrl,
						true,
						inGameUpdateConfig.useHttp2,
						inGameUpdateConfig.backupUrl1,
						inGameUpdateConfig.backupUrl2,
						igu_packagesinfo_path,
						inGameUpdateConfig.disablePrerequisite,
						GameUtil.GetAssetsPath(),
						"b_file_list/")

				warn("InGameUpdate.Init baseUrl="..tostring(inGameUpdateConfig.baseUrl)..", backupUrl1="..tostring(inGameUpdateConfig.backupUrl1)..
						", backupUrl2="..tostring(inGameUpdateConfig.backupUrl2)..", useHttp2="..tostring(inGameUpdateConfig.useHttp2)..
						", disablePrerequisite="..tostring(inGameUpdateConfig.disablePrerequisite))
				if not ret then
					update_predown_progress(false, 0, 0, 0, "InGameUpdate.Init failed!")
					error("InGameUpdate.Init failed!")
				end
				InGameUpdate.SetHttpRetryTimeInterval(5)
				InGameUpdate.SetMinFreeDiskSpaceToFail(500 * 1024 * 1024)

				local predownload_info = {}
				while not InGameUpdate.IsReadyForUse() do
					if update_predown_progress then
						local isOK, totalSize, processSize, _, packageIndex, packageCount, needCount, remainCount = InGameUpdate.GetCurPreDownloadPackageSizeInfo()
						if isOK then
							if totalSize ~= 0 then
								if not predownload_info[packageIndex] then
									predownload_info[packageIndex] = true
								end
								update_predown_progress(true, packageIndex, packageCount, processSize / totalSize)
							else
								update_predown_progress(false)
							end
						else
							update_predown_progress(false)
						end
					end
					coro.yield()
				end
				if update_predown_progress then
					update_predown_progress(false)
				end
				inGameUpdateConfig.predownload_info = predownload_info
			end
		else
			error("Cannot find igu_entrylist.dat for mini package, something is wrong!!")
		end
	end

    -- 启动游戏
	do
		local preload = require "preload"
		local EPConfig = require "EntryPointConfig"

		_G.MemoryMarkBegin"preload"
		while not preload() do coro.yield()	end
		_G.MemoryMarkEnd"preload"

		_G.GSDKSetEvent(_G.GSDK_EVENT.Preload, true, "success", false, false)
		--这里不用设置
		--_G.SetUserName(EPConfig.UserName, EPConfig.Password, EPConfig.ServerIP, EPConfig.ServerPort)

		_G.SetCreateConsole(EPConfig.CreateConsole)
		GameUtil.GetGameDataSendFilter(_G.GetGameDataSendFilter())

		_G.MemoryMarkBegin"InitLoginSDK"
		InitLoginSDK()
		_G.MemoryMarkEnd"InitLoginSDK"

		_G.MemoryMarkBegin"LoadShaderCache"
		local ECShaderCacheMan = require "Main.ECShaderCacheMan"
		--_G.StartLoadShaderCacheWhenInit = 1
		--print("StartLoadShaderCacheWhenInit")
		ECShaderCacheMan.Instance():StartLoadShaderCacheWhenInit(function()
			--print("StartLoadShaderCacheWhenInit finished")
			_G.StartLoadShaderCacheWhenInit = 0
		end)
		while _G.StartLoadShaderCacheWhenInit ~= 0 do
			coro.yield()
		end
		coro.yield()
		coro.yield()
		_G.StartLoadShaderCacheWhenInit = nil
		_G.MemoryMarkEnd"LoadShaderCache"
		
		_G.MemoryMarkBegin"StartGame"
		_G.StartGame()
		_G.MemoryMarkEnd"StartGame"


		_G.MemoryMarkBegin"GameStarted"
		GameUtil.GameStarted(true)
		_G.MemoryMarkEnd"GameStarted"
	end
end

local InitGameStage2 = function ( ... )
	FinalInitStage(...)
end

return InitGameStage2