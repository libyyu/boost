--[[
local l_warn_old = warn
function _G.warn(...)
	l_warn_old(table.concat({...}, '\t'), debug.traceback())
end
]]

function _G.GetConfigLuaWithoutCache(name)
	local config
	local bSucc
	local func, err = loadfile(name)
	if not func then
		warn("Failed to get config file =", name, err)
		return nil
	end
	bSucc, config = xpcall(function () return func() end, function (err) return debug.traceback(err) end)
	if not bSucc then
		error(config)
	end
	return config
end

function _G.IsTestSDKParams()
	return lfs.attributes(GameUtil.GetAssetsPath() .. "/UserData/testsdkparams.flag", "mode") == "file"
end
--[[
	抓取当前栈里面的局部已经上层变量信息
]]
function _G.DumpStack(info, withTraceback, thread, level)
	local function make_value(value)
		local mt = getmetatable(value)
		if mt and (mt.__pMessage or mt.__pb_accessor) then--是一个pb协议
			local v = tostring(value)
			local arr = v:split("\n")
			local sb = {}
			for ii, v in ipairs(arr) do
				if ii == 1 then
					sb[#sb+1] = tostring(v)
				else
					sb[#sb+1] = '        ' .. tostring(v)
				end
			end
			return table.concat(sb, "\n")
		else
			return tostring(value)
		end
	end

	local function make_kv(name, value, records)
		local tt = type(value)
		if (tt=="userdata") then
			if not records[value] then
				records[value] = true
				return name .. '=' .. tostring(value) .. '\n'
			end
		elseif (tt=="table") then
			if not records[value] then
				records[value] = true
				return name .. '=' .. make_value(value) .. "\n"
			end
		else
			if tt == "function" and tostring(value):find('function: builtin#') then
				return nil
			end

			return name .. '=' .. tostring(value) .. '\n'
		end
	end

	local function vars(f, records)
		local dump = ''
		local func = (thread and debug.getinfo(thread, f, 'f').func or debug.getinfo(f, 'f').func)
		local i = 1
		-- get locals
		while true do
			local name, value = nil, nil
			if thread then
				name, value = debug.getlocal(thread, f, i)
			else
				name, value = debug.getlocal(f, i)
			end
			if not name or name == "" then break end
			if string.sub(name, 1, 1) ~= '(' then
				local result = make_kv(name, value, records)
				if result then
					dump = dump ..  '        ' .. result
				end
			end
			i = i + 1
		end
		-- get varargs (these use negative indices)
		i = 1
		local iarg = 0
		while true do
			local name, value = nil, nil
			if thread then
				name, value = debug.getlocal(thread, f, -i)
			else
				name, value = debug.getlocal(f, -i)
			end
			-- `not name` should be enough, but LuaJIT 2.0.0 incorrectly reports `(*temporary)` names here
			if not name or name == ""  or name ~= '(*vararg)' then break end
			iarg = iarg + 1
			name = "#"..iarg

			local result = make_kv(name, value, records)
			if result then
				dump = dump ..  '        ' .. result
			end

			i = i + 1
		end
		-- get upvalues
		i = 1
		while func do -- check for func as it may be nil for tail calls
			local name, value = nil, nil
			if thread then
				name, value = debug.getupvalue(thread, func, i)
			else
				name, value = debug.getupvalue(func, i)
			end
			if not name or name == "" then break end
			local result = make_kv(name, value, records)
			if result then
				dump = dump ..  '        ' .. result
			end

			i = i + 1
		end
		return dump
	end
	local stacktrack
	if withTraceback then
		stacktrack = thread and debug.traceback(thread, info, 2) or debug.traceback(info, 2) or ""
	else
		stacktrack = info or "stack info:"
	end
	local records = {}
	local dump = ''
	local count = 0
	level = level or 3
	for i = level, 10 do
		local source = (thread and debug.getinfo(thread, i, 'S') or debug.getinfo(i, 'S'))
		if not source then break end
		local params = vars(i+1, records)
		if params and #params >0 then
			count = count + 1
			dump = dump .. '    -stack' .. tostring(count) .. '\n'
			dump = dump .. params
		end
		if source.what == 'main' then break end
	end
	return stacktrack .. '\n' .. dump .. "\n"
end

--[[
	错误回调，重写了traceback， 过滤掉Lplus信息
	并且会打印堆栈数据
]]

if GameUtil and GameUtil.GetPlatformName() == "Windows" then
	function _G.error_traceback(...)
		local info = debug.traceback(...)
		if DumpStack then
			local stack = try
			{
				function()
					return DumpStack(info, false, nil, 5)
				end,
				catch
				{
					function (errors)
						warn("DumpStack error: ", errors)
					end,
				}
			}
			return stack or info
		else
			return info
		end
	end
end

local step = 0
local function preload()
	--
	--禁止 global
	--
	step = step + 1
	if step == 1 then

        if jit and jit.off then
			jit.off() --关闭luajit（速度更快）
		end

		--------TEST!
		--utility.alloc_start_trace(Time.frameCount)
		require "Utility.NativePatch"	--早于其他模块，以免其他模块缓存了错误的函数
		require "Utility.LuaPatch"
		require "Main.ECConfigs"	--早于其他模块，以免 Lplus 设置不对
		require "Lplus"		--早于其他模块，以免无法 reload
		require "Core.preload"
		require "Utility.UE4Related"
		require "Utility.global".disableWriteForThread()
		require "Utility.LogHelper"
		require "Utility.GlobalHook"
		require "Utility.FunctionBind"
		--
		-- 资源路径
		--
		require "Common.ECResPath"
		require "PB.constant"
		require "Utility.ProtoUtils"
		require "Data.LocalFlag"

	--
	-- 网络协议定义及处理
	--
	elseif step == 2 then
		require "Protocol.ProtocolList"

	elseif step == 3 then
		--require "cfg.helper" --elementdata[后面准备废除]
		--require "cfg.data_hot_update_helper"
		-- 主逻辑预加载
		require "Common.CommonDef"
		require "Utility.ECUtility"
		require "Utility.UEEnumDefine"

		require "Common.ECClientDef"
		require "Common.ECSkillDef"
		require "Common.BehaviorDef"
		dofile("Configs/PlatformDef.lua")
		dofile("Configs/ECSimulator.lua")
		require "Common.QualityDef"
		require "Common.AnimDef"
		require "Common.WeaponDef"
		require "Common.PlayerDef"
		require "Common.VehicleDef"

		require "Common.MiscDef"
		require "Common.NPCDef"
		require "Home.ECHomeDef"
		require "Configs.TLogConfig"

		require "Utility.HttpDnsFixUrl"
		dofile("Configs/common/func_codes.lua")

		require "Utility.PolicyUtility"

	elseif step == 4 then
		require "Common.ECNetDef"
		require "PB.pb_preload"

	elseif step == 5 then
		require "S2C.S2CPreload"

		require "graphics_performance"
		require "Main.ECWorldLoaderTemp"
		require "Main.ECGame"

	elseif step == 6 then
		require "GUI.GUIPreload"

		--
		-- 入口点
		--

		require "Main.EntryPoint"

		--
		-- 事件监听
		--

		require "Main.ECProtocolHandler"

		require "Event.EventsPreRegister"

		--
		-- 其他
		--
		-- azure todo
		require "CG.Preload"
		--require "Data.ECTallentData" --预先注册一下天赋模块

		require "Utility.GameInfo_preload"
		require "Guide.ECGuidePreload"
		require "Scene.ScenePreload"
		require "Notification.FENotificationCenter"
		--require "Sound.SoundPreload"  --任务声音不要了 by yangxiaoning
		require "Players.ECSurroundingSample"

		--item define
		require "Inventory.ItemPreload"

		-- MsgBox
		require "Common.ECMsgBox"

		-- FlashTip
		require "Common.ECFlashTip"


		--ItemTip
		require "Common.ECItemTip"

		--Input
		--require "Common.ECInput"  --特殊键盘

		require "Common.HUDMan".PreLoad()

		require "Object.DropGroup"
	elseif step == 7 then
		require "AVG.preload"
		require "Home.Preload"

	else
		if step ~= 8 then
			error("preload")
		end
		require "Main.ECGame".Instance():Init()
		require "Grass.ECGrassMan".Instance()
		require "Utility.ReloadHelper".Init()
		require "Instance.PreloadInstance"
		return true
	end

	--保证预加载资源加载完
	GameUtil.FlushAsyncLoading()
	return false

end

return preload
