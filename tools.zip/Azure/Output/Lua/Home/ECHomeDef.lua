--[[
	家园相关定义
]]

_G.ECHOME_ELEMENT_TYPE_ENUM =
{
	NONE = 0, 		--无
	HOME = 1,					--家园
	FLOOR = 2,				--楼层
	LINK = 3,
	LINK_BARRIER = 4,
	WALL = 5,
	BARRIER = 6,
	TOP = 7,
	STAIR = 8,
	GROUND = 9,				--地基预留 暂时没用
	ITEM = 10,
	MAT_WALL = 11,				--墙纸
	MAT_FLOOR = 12,			--地板
	MAT_ROOF = 13,			    --天花板
	MAT_TOP = 14,			    --房顶
	HOLE_MODEL = 15,			--门窗
	TOPWALL = 16,				--房顶的围墙
	POOL = 17,					--泳池
	GRID = 18,        			--格子地板
	BASEMENT = 19,				--地下室
}

_G.HOMEACTOR_MASK_CACHE_SIZE = 512*512

_G.HOME_COLLISION_NAME = "BuildingBlockCam"
_G.HOME_COLLISION_NAME_NO_CAM = "Building" --策划要求家具不和相机碰撞
_G.HOME_GRID_COLLISION_NAME = "Terrain"
_G.HOME_COLLISION_EDIT_NAME = "AzureObject"
_G.HOME_NO_COLLISION_NAME = "NoCollision"

_G.AZUREHOMETOP_TYPE = 
{
	TYPE_UNKNOW = 0, --未赋值
	TYPE_A = 1, --样式A
	TYPE_B = 2, --样式B
	TYPE_C = 3, --样式C
	TYPE_D = 4, --样式D
	TYPE_E = 5, --样式E
	TYPE_F = 6, --样式F
}

_G.AZUREHOME_FLOOR_WALLHEIGHT_TYPE = --这三个标准直接关系到墙的贴图坐标 美术做图如果方图最好是     如果是条形图最好是8x1比例及1024x128分辨率
{	
	TYPE_UNKNOW = 0,	--未赋值
	TYPE_4M = 1,		--4米墙样式
	TYPE_5M = 2,		--5米墙样式
	TYPE_6M = 3,		--6米墙样式  
}

_G.AZUREHOME_WALL_TEXTURE_TYPE = --墙壁使用的三种贴图类型
{	
	TYPE_UNKNOW = 0,	--未赋值
	TYPE_8X8 = 1,		--(内墙大方图)8x8比例1024x1024分辨率，如果不是TYPE_8M墙，层和层之间贴图无法衔接，所以只能做内墙
	TYPE_1X1 = 2,		--（外墙和内墙小方图）1x1比例256x256，因为是小方图，墙宽高都是其整数倍，所以层和层之间可以很好的连接，内外墙都可用，但图形单调写
	TYPE_1X8 = 3,		--（内墙条形图）1x8比例及1024x128分辨率
	TYPE_2X8 = 4,		--（内墙条形图）2x8比例及1024x256分辨率
}

_G.AZUREHOMESTAIR_HANDRAIL_TYPE = --楼梯扶手模型的类型
{   
	TYPE_START	= 0, --起始部分
	TYPE_LOOP	= 1, --中间部分
	TYPE_END	= 2, --结束部分
	TYPE_COUNT  = 3,
}

_G.AZUREHOMESTAIR_MESH_TYPE = --阶梯模型的类型
{   
	TYPE_LEFT = 0, --左边部分
	TYPE_CENTER = 1, --中间部分
	TYPE_RIGHT = 2, --右边部分
	TYPE_COUNT = 3,
}

--1~9 (3x3)
--上左，	上中，	上右
--中左，	中，	中右
--下左，	下中，	下右
_G.AZUREHOMEPOOL_TYPE = --泳池模型的类型
{   
	UP_LEFT			= 7, 
	UP_CENTER		= 4, 
	UP_RIGHT		= 1, 
	MIDDLE_LEFT		= 8,
	MIDDLE_CENTER	= 5,
	MIDDLE_RIGHT	= 2,
	DOWN_LEFT		= 9, 
	DOWN_CENTER		= 6, 
	DOWN_RIGHT		= 3, 
	COUNT = 9,
}

_G.AZUREHOMEACTION = --家园内动作
{   
	CLEAN = 0,
	REPAIR = 1,
}

_G.AZUREHOME_KEEPER_TYPE = --家园管家类型
{   
	NPC = 1,
	PARTNER = 2,
	PLAYER = 3,
}

_G.AZUREHOME_PI = 3.14159265

-------------------------
local DIR_TABLE =
{
	[0] = { x = 1, y = 0 },
	[1] = { x = 1, y = 1 },
	[2] = { x = 0, y = 1 },
	[3] = { x = -1, y = 1 },
	[4] = { x = -1, y = 0 },
	[5] = { x = -1, y = -1 },
	[6] = { x = 0, y = -1 },
	[7] = { x = 1, y = -1 },
}
local SQRT_2 = math.sqrt(2)

local DIR_LENGTH =
{
	[0] = 1,
	[1] = SQRT_2,
	[2] = 1,
	[3] = SQRT_2,
	[4] = 1,
	[5] = SQRT_2,
	[6] = 1,
	[7] = SQRT_2,
}
local DIR_NORMALIZED =
{
	[0] = { x = 1, y = 0 },
	[1] = { x = 1/SQRT_2, y = 1/SQRT_2 },
	[2] = { x = 0, y = 1 },
	[3] = { x = -1/SQRT_2, y = 1/SQRT_2 },
	[4] = { x = -1, y = 0 },
	[5] = { x = -1/SQRT_2, y = -1/SQRT_2 },
	[6] = { x = 0, y = -1 },
	[7] = { x = 1/SQRT_2, y = -1/SQRT_2 },
}
local DIR_DEFAULT = { x = 0,  y = 0 }

-------------------------
local DEGREE_TABLE =
{
	[0] = 0,
	[1] = 45,
	[2] = 90,
	[3] = 135,
	[4] = 180,
	[5] = 225,
	[6] = 270,
	[7] = 315,
}
local DEGREE_DEFAULT = 0
-------------------------

-------------------------
local SIN_COS_TABLE =
{
	[0] =
	{
		c = 1,
		s = 0,
	},
	[45] =
	{
		c = math.cos(math.rad(45)),
		s = math.sin(math.rad(45)),
	},
	[90] =
	{
		c = 0,
		s = 1,
	},
	[135] =
	{
		c = math.cos(math.rad(135)),
		s = math.sin(math.rad(135)),
	},
	[180] =
	{
		c = -1,
		s = 0,
	},
	[225] =
	{
		c = math.cos(math.rad(225)),
		s = math.sin(math.rad(225)),
	},
	[270] =
	{
		c = 0,
		s = -1,
	},
	[315] =
	{
		c = math.cos(math.rad(315)),
		s = math.sin(math.rad(315)),
	},
}
-------------------------

_G.AZUREHOME_FUNC = 
{
	--wall_height单位grid
	GetTextureSizeUnit = function(TextureType, wall_height)--获取贴图宽高比例单位Grid 和AZUREHOME_FLOOR_WALLHEIGHT_TYPE::TYPE_4M相关 如果矮墙就是裁剪 不缩放，否则会很难看
		if TextureType == _G.AZUREHOME_WALL_TEXTURE_TYPE.TYPE_8X8 then
			return { x = 8, y = 8 }
		elseif TextureType == _G.AZUREHOME_WALL_TEXTURE_TYPE.TYPE_1X1 then
			return { x = 1, y = 1 }
		elseif TextureType == _G.AZUREHOME_WALL_TEXTURE_TYPE.TYPE_1X8 then
			local height = wall_height/2
			return { x = height/8, y = height }--{ x = 1, y = 8 }
		else 
			local height = wall_height/2
			return { x = (2*height)/8, y = height }
		end
	end,

	Len_Vec2_11 = SQRT_2,

	-- return Dir(Not Normalised), Length
	GetDir = function( dir )
		local ret = DIR_TABLE[dir]
		if ret then
			return ret, DIR_LENGTH[dir]
		else
			return DIR_DEFAULT, 0
		end
	end,

	GetDir_Normalized = function( dir )
		local ret = DIR_NORMALIZED[dir]
		return ret or DIR_DEFAULT
	end,

	GetDegree = function(dir)
		local ret = DEGREE_TABLE[dir]
		return ret or DEGREE_DEFAULT
	end,

	GetDir_ByDegree = function(degree)
		for i, v in pairs(DEGREE_TABLE) do
			if i == 0 then
				if math.abs(degree - 0) < 1 or math.abs(degree - 360) < 1 then
					return i
				end
			else
				if math.abs(degree - v) < 1 then
					return i
				end
			end
		end
		return -1
	end,

	GetRotated2D = function(vDir, _Deg)
		local Deg = _Deg
		if Deg < 0 then
			Deg = Deg + 360
		elseif Deg >= 360 then
			Deg = Deg - 360
		end
		local c, s
		local def = SIN_COS_TABLE[Deg]
		if def then
			c = def.c
			s = def.s
		else
			--print("__GetRotated2D: deg = ", Deg, debug.tracebackex())
			local Rad = math.rad(Deg)
			c = math.cos(Rad)
			s = math.sin(Rad)
		end
		return { x = vDir.x * c - vDir.y * s, y = vDir.x * s + vDir.y * c }
	end,
	GetPointIntersection = function(ps1, pe1, ps2, pe2, realCheck)
		-- Get A,B,C of first line - points : ps1 to pe1
		local A1 = pe1.y - ps1.y
		local B1 = ps1.x - pe1.x
		local C1 = A1 * ps1.x + B1 * ps1.y

		-- Get A,B,C of second line - points : ps2 to pe2
		local A2 = pe2.y - ps2.y
		local B2 = ps2.x - pe2.x
		local C2 = A2 * ps2.x + B2 * ps2.y

		-- Get delta and check if the lines are parallel
		local delta = A1 * B2 - A2 * B1
		if math.abs(delta)<0.001 then
			return nil
		else
			local intersect = { x =(B2*C1 - B1 * C2) / delta, y = (A1*C2 - A2 * C1) / delta }
			if realCheck then
				local dx11 = intersect.x - ps1.x
				local dy11 = intersect.y - ps1.y
				local dx12 = intersect.x - pe1.x
				local dy12 = intersect.y - pe1.y
				local dx21 = intersect.x - ps2.x
				local dy21 = intersect.y - ps2.y
				local dx22 = intersect.x - pe2.x
				local dy22 = intersect.y - pe2.y
				if dx11*dx12+dy11*dy12 >= 0 or dx21*dx22+dy21*dy22 >= 0 then
					intersect = nil
				end
			end
			return intersect
		end
	end,
	SquaredLenVec2 = function( v )
		return v.x*v.x + v.y*v.y
	end,
	LengthVector2 = function( v )
		return math.sqrt( v.x*v.x + v.y*v.y)
	end,
	NormalizeVector2 = function( v )
		local len = math.sqrt( v.x*v.x + v.y*v.y)
		if len > 1e-5 then
			v.x = v.x / len; v.y = v.y / len
		else
			v.x = 0; v.y = 0
		end
		return v
	end,
	Vector2 = function( x, y )
		return {x=x,y=y}
	end,
	CreateVector2 = function( v )
		return {x=v.x,y=v.y}
	end,
	AddVector2 = function( v1, v2 )
		return {x=v1.x+v2.x,y=v1.y+v2.y}
	end,
	SubVector2 = function( v1, v2 )
		return {x=v1.x-v2.x,y=v1.y-v2.y}
	end,
	MulVector2 = function( v1, l )
		return {x=v1.x*l,y=v1.y*l}
	end,
	Dot2 = function( v1, v2 )
		return v1.x * v2.x + v1.y * v2.y
	end,
	SquaredLenVec3 = function( v )
		return v.x*v.x + v.y*v.y + v.z*v.z
	end,
	LengthVector3 = function( v )
		return math.sqrt( v.x*v.x + v.y*v.y + v.z*v.z)
	end,
	NormalizeVector3 = function( v )
		local len = math.sqrt( v.x*v.x + v.y*v.y + v.z*v.z)
	    if len > 1e-5 then
	      local f = 1/len
	      v.x = v.x * f; v.y = v.y * f; v.z = v.z * f
	    else
	      v.x = 0; v.y = 0; v.z = 1 --避免设置Zero方向
	    end

	    return v
	end,
	Vector3 = function( x, y, z )
		return {x=x,y=y,z=z}
	end,
	CreateVector3 = function( v )
		return {x=v.x,y=v.y,z=v.z}
	end,
	AddVector3 = function( v1, v2 )
		return {x=v1.x+v2.x,y=v1.y+v2.y,z=v1.z+v2.z}
	end,
	SubVector3 = function( v1, v2 )
		return {x=v1.x-v2.x,y=v1.y-v2.y,z=v1.z-v2.z}
	end,
	MulVector3 = function( v1, l )
		return {x=v1.x*l,y=v1.y*l,z=v1.z*l}
	end,
	QuatAxis3 = function( Axis, AngleRad )
		local half_a = 0.5 * AngleRad
		local s = math.sin(half_a)
		local c = math.cos(half_a)
		return {x=s*Axis.x,y=s*Axis.y,z=s*Axis.z,w=c}
	end,
	QuatVector3 = function( Quat, v )
		local Q = { x = Quat.x, y = Quat.y, z = Quat.z }
		local T = { x = (Q.y*v.z - Q.z*v.y)*2, y = (Q.z*v.x - Q.x*v.z)*2, z = (Q.x*v.y - Q.y*v.x)*2 }
		local QCT = { x = Q.y*T.z - Q.z*T.y, y = Q.z*T.x - Q.x*T.z, z = Q.x*T.y - Q.y*T.x }
		return { x = v.x+Quat.w*T.x+QCT.x, y = v.y+Quat.w*T.y+QCT.y, z = v.z+Quat.w*T.z+QCT.z }
	end,
	
}

_G.HOME_ROOT_PUT_INDEX = 1
_G.BASEMENT_PUT_INDEX = 99
_G.BASEMENT_FLOOR_INDEX = -1

_G.AZUREHOME_FSL_STATE =  --家具的加载状态
{
	UNLOAD = 0, --未加载
	LOADING = 1, --加载中
	LOADED = 2, --加载完
}

_G.ECHOME_WALL_SHOW_TYPE_ENUM =
{
	NONE = 0,		--无
	HALF = 1,		--半墙显示
	ALL = 2,		--全墙显示
	NO = 3,			--无墙显示
	COUNT = 4,
}

_G.ARROW_PARENT_TYPE = {
	WALL = 0,
	TOP = 1,
	STAIR = 2,
	POOL = 3,
	BARRIER = 4,
}

_G.WALL_ARROW_TYPE = --墙上箭头的类型
{
	FORWARD = 1,
	RIGHT = 2,
	BACK = 3,
	LEFT = 4,
	TOP = 5,
}

_G.ARROW_DIR_TYPE =
{
	FORWARD_BACK = 1, --前后
	LEFT = 2,	--左侧
	RIGHT = 3,	--右侧
}

-- 家园属性
_G.AZUREHOME_MaxProperty = 5
_G.AZUREHOME_Properties = {
	[250] = StringTable.Get(93001),
	[251] = StringTable.Get(93002),
	[2239] = StringTable.Get(93003),
	[2240] = StringTable.Get(93004),
	[2241] = StringTable.Get(93005),
}

_G.AZUREHOME_QueryOtherCoolDown = 3

-- 街区相关
_G.AZUREHOME_BlockMaxMember = 4
_G.AZUREHOME_BlockMaxSupply = 3
_G.AZUREHOME_BlockSupplyState =
{
	Invalid = 0,	-- 无效
	CanAcquire = 1,	-- 可领取
	Acquired = 2,	-- 已领取
}
_G.AZUREHOME_BlockSloganMaxLength = 60
_G.AZUREHOME_InviteCoolDown = 30