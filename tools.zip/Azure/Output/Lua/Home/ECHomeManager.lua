--[[
	家园管理器(家园相关各个系统的管理入口，上下行协议相关)
]]

local Lplus = require "Lplus"
local ECBuildToolBase = require "Home.BuildTool.ECBuildToolBase"
local ECHomeData = require "Home.Data.ECHomeData"
local ECHomeNode = require "Home.Data.ECHomeNode"
local ECHomeView = require "Home.View.ECHomeView"
local ECHomeElementRel = require "Home.Data.ECHomeElementRel"
local ECHomeSpaceUtil = require "Home.Util.ECHomeSpaceUtil"
local ECHomeCamMan = require "Home.ECHomeCamMan"
local ECHomeUndoMan = require "Home.Undo.ECHomeUndoMan"
local ElementData = require "Data.ElementData"
local ReputationCfg = require "Configs.ReputationCfg"
local HomeEvents = require "Event.HomeEvents"
local client_msg = require "PB.client_msg"
local db_msg = require "PB.db_msg"
local pb_helper = require "PB.pb_helper"
local ECLRUCache = require "Common.ECLRUCache"
local ECArrowMan = require "Home.Util.ECArrowMan"
local ECShowLogicMan = require "Home.Util.ECShowLogicMan"
local ECHomeStageMan = require "Home.Misc.ECHomeStageMan"
local ECHomeHouseKeeper = require "Home.Misc.ECHomeHouseKeeper"
local ECHomeProduce = require "Home.Misc.ECHomeProduce"
local ECHomeConfig = require "Home.Misc.ECHomeConfig"
local ECHomeUtil = require "Home.Util.ECHomeUtil"
local ECHostAsyncTask = require "Players.ECHostAsyncTask"

local homeCfg = _G.require_config("Configs/home/home.lua")
local home_task = _G.require_config("Configs/home/home_task.lua")

local _warn = _G.GetModuleLog("home")


local __all_tasks = {}
do
	for i, v in ipairs(home_task) do
		local task_id = v.task_id
		__all_tasks[task_id] = i
	end
end


---@type ECGame
local ECGame = Lplus.ForwardDeclare("ECGame")

---@class ECHomeManager:System.Object
---@field protected m_bInited boolean
---@field protected m_OwnerRoleID string
---@field protected m_bUnlock boolean
---@field protected m_bUnlockIndoor boolean
---@field protected m_bUnlockOutdoor boolean
---@field protected m_HomeInfoMap ECLRUCache
---@field protected m_HostHomeInfo table
---@field protected m_bWalkInHome boolean
---@field protected m_bInEditMode boolean
---@field protected m_bShowHomeInfo boolean
---@field protected m_last_BuyOperation number
---@field protected m_curOperTid number
---@field protected m_bInDeleteMode boolean
---@field protected m_bOptLock boolean
---@field protected m_WaitingUpdatePutIndex number
---@field protected m_S2C_CallBackTab table
---@field protected m_QueryHomeInfoCB table
---@field protected m_bInDesignMode boolean
---@field protected m_bDebugMode boolean
---@field protected m_bDuringRebuild boolean
---@field protected m_bCreateInComplete boolean
---@field public DisplayType pb.Enum.PB.home_display_t.TYPE
---@field public Commit fun():ECHomeManager @notnull
---@field public Instance fun():ECHomeManager
---@field public Init fun(self:ECHomeManager)
---@field public Reset fun(self:ECHomeManager, bInEditMode:boolean)
---@field public Release fun(self:ECHomeManager)
---@field public OnReleaseGame fun(self:ECHomeManager)
---@field public OnEnterGameLogic fun(self:ECHomeManager)
---@field public OnLeaveGameLogic fun(self:ECHomeManager)
---@field public OnLeaveHome fun(self:ECHomeManager)
---@field public OnEnterHome fun(self:ECHomeManager)
---@field public HasVisitHomeToDay fun(self:ECHomeManager, role_id:string):boolean
---@field public EnterMyHome fun(self:ECHomeManager, indoor:boolean):boolean
---@field public CheckAndPromptMyHomeIGU fun(self:ECHomeManager, indoor:boolean):boolean
---@field public EnterOtherHome fun(self:ECHomeManager, role_id:string, indoor:boolean):boolean
---@field public IsUnlocked fun(self:ECHomeManager):boolean
---@field public GetSceneUnlockStatus fun(self:ECHomeManager):boolean,boolean
---@field public SetUnlocked fun(self:ECHomeManager, b:boolean)
---@field public IsInHome fun(self:ECHomeManager):boolean
---@field public GetHomeType fun(self:ECHomeManager):number
---@field public IsInMyRoom fun(self:ECHomeManager):boolean
---@field public IsInMyHome fun(self:ECHomeManager):boolean
---@field public IsInOtherHome fun(self:ECHomeManager, role_id:string):boolean
---@field public GetHomeOwnerID fun(self:ECHomeManager):string
---@field public IsWalkMode fun(self:ECHomeManager):boolean
---@field public SetWalkMode fun(self:ECHomeManager, bWalkMode:boolean)
---@field public SetCurOperTid fun(self:ECHomeManager, OperTid:number)
---@field public CreateEmptyHome fun(self:ECHomeManager)
---@field public EnterDesignMode fun(self:ECHomeManager, dataType:number, homeDataFromServer:table)
---@field public SetDebugMode fun(self:ECHomeManager, debugMode:boolean)
---@field public IsStandalone fun(self:ECHomeManager):boolean
---@field public OnClickScreen fun(self:ECHomeManager, screenPos:table):boolean
---@field public OnClickNothing fun(self:ECHomeManager, actor:userdata, pos:table, x:number, y:number)
---@field public OnSelectWall fun(self:ECHomeManager, screenPos:table, link_put_index:number, wall_put_index:number)
---@field public HandleTouch fun(self:ECHomeManager, typeStr:string, x:number, y:number, distX:number, distY:number):boolean
---@field public SaveDesignData fun(self:ECHomeManager)
---@field public IsInEditMode fun(self:ECHomeManager):boolean
---@field public SetEditMode fun(self:ECHomeManager, bEdit:boolean)
---@field public ShowGrid fun(self:ECHomeManager, bShow:boolean)
---@field public CanOperate fun(self:ECHomeManager, showTips:boolean):boolean
---@field public IsDuringRebuild fun(self:ECHomeManager):boolean
---@field public IsDataInited fun(self:ECHomeManager):boolean
---@field public IsAllReady fun(self:ECHomeManager):boolean
---@field public on_hometown_op fun(self:ECHomeManager, msg:pb.Message.PB.gp_home_op_res)
---@field public Set_S2C_SUCC_CallBack fun(self:ECHomeManager, op:number, callback:function)
---@field public On_S2C_SUCC_CallBack fun(self:ECHomeManager, op:number)
---@field public On_S2C_QueryInfo_CallBack fun(self:ECHomeManager, home_owner:string)
---@field public Remove_S2C_SUCC_CallBack fun(self:ECHomeManager, op:number)
---@field public S2C_HomeData fun(self:ECHomeManager, hometown_data:pb.Message.PB.db_ref_home, home_type:number, bInEditMode:boolean)
---@field public UpdateHomeInfoFromData fun(self:ECHomeManager, OwnerID:string, hometown_data:pb.Message.PB.db_ref_home)
---@field public OnInCompleteCreate fun(self:ECHomeManager)
---@field public GetNeedBuyAndSell fun(self:ECHomeManager, multiPut:table, multiUpdate:table, multiCancel:table):table,table,number,table,number
---@field public SerializeRelationData fun(self:ECHomeManager, bCompress:boolean):boolean,string,boolean,string
---@field public SerializeRelationData_LargeLimit fun(self:ECHomeManager, bCompress:boolean):boolean,string,boolean,string
---@field public CompressRelationData fun(self:ECHomeManager, org_relation:string, bCompress:boolean, bUseLargeLimitWhenCompress:boolean):string,boolean,string
---@field public SerializeRelationData_Inner fun(self:ECHomeManager, bCompress:boolean, bUseLargeLimitWhenCompress:boolean):boolean,string,boolean,string
---@field public SerializeRelationData_Empty fun(self:ECHomeManager, bCompress:boolean, bUseLargeLimitWhenCompress:boolean):boolean,string,boolean,string
---@field public C2S_UpdateRelation fun(self:ECHomeManager, relation:string, relation_compress:boolean, relation_origin:string, bUndo:boolean):boolean
---@field public S2C_UpdateRelation fun(self:ECHomeManager, update_relation:pb.Message.PB.home_update_relation_t)
---@field public OperationCheck fun(self:ECHomeManager, bBuyOrAdd:boolean):boolean
---@field public C2S_BuyAndPut fun(self:ECHomeManager, obj_type:number, put_index:number, count:number, data:table, put_param:any, bUndo:boolean):boolean
---@field public S2C_BuyAndPut fun(self:ECHomeManager, put:pb.Message.PB.home_put_t, buy_count:number)
---@field public S2C_ItemSync fun(self:ECHomeManager, sync:pb.Message.PB.home_sync)
---@field public C2S_Update fun(self:ECHomeManager, obj_type:number, put_index:number, data:string, count:number, relation:string, relation_compress:boolean, relation_origin:string, bUndo:boolean):boolean
---@field public S2C_Update fun(self:ECHomeManager, update_obj_data:pb.Message.PB.home_update_obj_data_t)
---@field public S2C_HomeMiscData fun(self:ECHomeManager, home_owner:string, misc_data:table)
---@field public S2C_HomeInfo fun(self:ECHomeManager, home_owner:string, info:pb.Message.PB.home_info_t, unlock:boolean)
---@field public GetSmeltInfo fun(self:ECHomeManager):number,number
---@field public GetStationInfo fun(self:ECHomeManager):number,number
---@field public GetHomeInfo fun(self:ECHomeManager, role_id:string):table
---@field public GetHomeScore fun(self:ECHomeManager, role_id:string):table
---@field public GetHostHomeScore fun(self:ECHomeManager):table
---@field public GetHostHomeLevel fun(self:ECHomeManager):number
---@field public GetCurHomeInstanceID fun(self:ECHomeManager, indoor:boolean):number
---@field public GetCurHomeSceneID fun(self:ECHomeManager, indoor:boolean):number
---@field public GetHostHomeKeeper fun(self:ECHomeManager):number
---@field public IsDailyRewardReceived fun(self:ECHomeManager):boolean
---@field public IsUpgrading fun(self:ECHomeManager):boolean
---@field public GetUpgradeSeconds fun(self:ECHomeManager):number
---@field public CanLevelUp fun(self:ECHomeManager):boolean
---@field public CanGetDailyReward fun(self:ECHomeManager):boolean
---@field public GetHostHomeMoney fun(self:ECHomeManager):number
---@field public IsAnyTechCanResearch fun(self:ECHomeManager):boolean
---@field public GetResearchingInfo fun(self:ECHomeManager):table,string
---@field public C2S_Cancel fun(self:ECHomeManager, obj_type:number, put_index:number, bUndo:boolean):boolean
---@field public S2C_Cancel fun(self:ECHomeManager, cancel:pb.Message.PB.home_cancel_t)
---@field public C2S_Put fun(self:ECHomeManager, obj_type:number, put_index:number, count:number, data:table, put_param:any, bUndo:boolean, undo_param:table):boolean
---@field public S2C_Put fun(self:ECHomeManager, put:pb.Message.PB.home_put_t)
---@field public DeleteFurniture fun(self:ECHomeManager, put_index:number)
---@field public DeleteFurnitureInner fun(self:ECHomeManager, put_index:number)
---@field public CheckCanDelete fun(self:ECHomeManager, put_index:number):boolean,table
---@field public CheckCanDelete_ForEachChild fun(self:ECHomeManager, deletePutIndex:number):boolean,table
---@field public C2S_CancelHomeItem fun(self:ECHomeManager, tid:number, count:number):boolean
---@field public C2S_QueryHomeInfo fun(self:ECHomeManager, home_owner:string, cb:function):boolean
---@field public C2S_CancelAllItem fun(self:ECHomeManager, bUndo:boolean):boolean
---@field public S2C_CancelAllItem fun(self:ECHomeManager, cancel_all:pb.Message.PB.home_cancel_all_t, hometown_data:pb.Message.PB.db_ref_home, home_type:number)
---@field public C2S_MultiCancel fun(self:ECHomeManager, multi:table, bUndo:boolean):boolean
---@field public S2C_MultiCancel fun(self:ECHomeManager, multi_cancel:pb.Message.PB.home_multi_cancel_t)
---@field public C2S_MultiPut fun(self:ECHomeManager, multi:pb.Message.PB.home_multi_put_t, bUndo:boolean):boolean
---@field public S2C_MultiPut fun(self:ECHomeManager, multi_put:pb.Message.PB.home_multi_put_t)
---@field public C2S_HomeLevelUp fun(self:ECHomeManager):boolean
---@field public S2C_HomeLevelUp fun(self:ECHomeManager, home_owner:string, info:pb.Message.PB.home_info_t)
---@field public C2S_StageDisplayByTid fun(self:ECHomeManager, type:number, put_index:number, tid:number):boolean
---@field public C2S_StageDisplay fun(self:ECHomeManager, type:number, put_index:number, tid:number, id:string):boolean
---@field public S2C_StageDisplay fun(self:ECHomeManager, homeType:number, info:pb.Message.PB.home_display_t)
---@field public S2C_DelStageDisplay fun(self:ECHomeManager, homeType:number, putIndexList:table)
---@field public C2S_UnlockRoom fun(self:ECHomeManager, room_put_index:number):boolean
---@field public S2C_UnlockRoom fun(self:ECHomeManager, info:pb.Message.PB.home_unlock_room_t)
---@field public C2S_MultiOperation fun(self:ECHomeManager, multi_buy:table, multi_sell:table, multi_cancel:table, multi_put:table, multi_data:table, param:number, undo_relation:table, bUndo:boolean):boolean
---@field public S2C_MultiOperation fun(self:ECHomeManager, multi_oper:pb.Message.PB.home_multi_oper_t)
---@field public CheckPlayerPos fun(self:ECHomeManager, bMove:boolean):boolean
---@field public C2S_HomeDebugData fun(self:ECHomeManager):boolean
---@field public S2C_HomeDebugData fun(self:ECHomeManager, debug:pb.Message.PB.home_debug_t)
---@field public C2S_GetDailyReward fun(self:ECHomeManager):boolean
---@field public S2C_GetDailyReward fun(self:ECHomeManager)
---@field public C2S_ChangeButler fun(self:ECHomeManager, people_tid:number):boolean
---@field public S2C_Butler fun(self:ECHomeManager, owner_id:string, info:pb.Message.PB.home_butler_t)
---@field public S2C_VisitInfo fun(self:ECHomeManager, owner_id:string, info:pb.Message.PB.db_ref_home.VisitorInfo)
---@field public C2S_DispatchPeople fun(self:ECHomeManager, src_room_index:number, dst_room_index:number, people_tid:number):boolean
---@field public C2S_DispatchPeoples fun(self:ECHomeManager, list:table):boolean
---@field public C2S_DispatchOrder fun(self:ECHomeManager, op:number, room_index:number, order_tid:number, order_index:number):boolean
---@field public C2S_ReformRoom fun(self:ECHomeManager, room_index:number, func_type:number):boolean
---@field public S2C_RoomRefresh fun(self:ECHomeManager, owner_id:string, room_map:table<number, pb.Message.PB.room_info>)
---@field public S2C_DispatchParam fun(self:ECHomeManager, owner_id:string, dispatch_param:pb.Message.PB.db_ref_home.DispatchParam)
---@field public S2C_PeopleRefresh fun(self:ECHomeManager, owner_id:string, people_map:table<number, pb.Message.PB.db_ref_home.PeopleInfo>, del_people_list:number[])
---@field public C2S_HomeResearch fun(self:ECHomeManager, tech_tid:number, op:number):boolean
---@field public S2C_ResearchRefresh fun(self:ECHomeManager, home_owner:string, research_info:pb.Message.PB.db_ref_home.ResearchingInfo, active_research_tids:table)
---@field public S2C_ActiveOrderRefresh fun(self:ECHomeManager, home_owner:string, active_order_tids:table)
---@field public S2C_SpeedListClear fun(self:ECHomeManager, home_owner:string)
---@field public C2S_SpeedUp fun(self:ECHomeManager):boolean
---@field public S2C_SpeedUp fun(self:ECHomeManager, home_owner:string, speed_up_map:table)
---@field public S2C_Reputation fun(self:ECHomeManager, home_owner:string, repu_map:table)
---@field public S2C_RewardInform fun(self:ECHomeManager, rwd_type:number, rwd_map:table)
---@field public GetHomeSerializedData fun(self:ECHomeManager):boolean,string
---@field public SaveHomeDataToTemplateFile fun(self:ECHomeManager, empty_template:boolean)
---@field public MergeAllHomeTemplates fun(self:ECHomeManager)
---@field public DumpHomeTemplateFile fun(self:ECHomeManager, templ_file:string)
---@field public UpgradeOutdoorHomeTemplateFile fun(self:ECHomeManager, templ_file:string)
---@field public LoadHomeTemplateFromFile fun(self:ECHomeManager, tmpl_file:string)
---@field public CheckRelationIsOK fun(self:ECHomeManager, relation:string, exclude_tab:table, checkView:boolean):boolean
---@field public CheckRelationIsOK_Element fun(self:ECHomeManager, e:ECHomeElementRel, exclude_tab:table, checkView:boolean):boolean
---@field public S2C_MerchantInfo fun(self:ECHomeManager, ownerID:string, merchant_data:table)
---@field public UpdateMerchantInfo fun(self:ECHomeManager, ownerID:string, npc_tid:number, leave_time:number)
---@field public GetMerchantInfo fun(self:ECHomeManager, ownerID:string):number,number
---@field public GetMerchantPosition fun(self:ECHomeManager, ownerID:string):table
---@field public TalkToMerchant fun(self:ECHomeManager)
---@field public S2C_UnlockIndoorInfo fun(self:ECHomeManager, ownerID:string, unlock_indoor_info:table)
---@field public S2C_ObjUnlock fun(self:ECHomeManager, ownerID:string, obj_unlock_info:pb.Message.PB.home_obj_unlock_t)
---@field public GetUnlockIndoorRemainTime fun(self:ECHomeManager):number
---@field public CheckTaskPageNeedActive fun(self:ECHomeManager):boolean
---@field public GetTaskCount fun(self:ECHomeManager):number
---@field public GetTaskCountRemain fun(self:ECHomeManager):number
---@field public GetExtendCfgNpcInfoList fun(self:ECHomeManager):table
---@field public GetMerchantPosInfo fun(self:ECHomeManager):table
---@field public CalcTaskIcon fun(self:ECHomeManager, npcTid:number):number,any
---@field public GetAllTaskNPCList fun(self:ECHomeManager):table
---@field public FilterTaskFromConfig fun(task_id:number):boolean
local ECHomeManager = Lplus.Class("ECHomeManager")
local def = ECHomeManager.define

local DESIGN_DATA_TYPE =
{
	USE_LOCAL = 1, --使用本地数据
	USE_HOME = 2,  --使用当前家园数据
	USE_EMPTY = 3, --使用空数据
}

local CD_TIME = 2 --服务器金钱操作需要1.5秒冷却

local START_COMPR_RELATION_SIZE = 1000 --RelationSize>=这个值开始压缩
local MAX_RELATION_SIZE = 16384 --Relation数据最大Size:16KB（压缩后）
local MAX_RELATION_SIZE_LARGELIMIT = 20480 --Relation数据最终最大Size:20KB（压缩后），因为多步操作可能导致临时超过上面的Size，但此时允许卖和Cancel

local DEFAULT_INTENSITY = 1
local HIGH_INTENSITY = 2

---@type boolean
def.field("boolean").m_bInited = false

---@type string
def.field("string").m_OwnerRoleID = ZeroUInt64				-- 当前家园的主人

---@type boolean
def.field("boolean").m_bUnlock = false						-- 自己的家园是否解锁

---@type boolean
def.field("boolean").m_bUnlockIndoor = false				-- 自己的家园室内是否解锁

---@type boolean
def.field("boolean").m_bUnlockOutdoor = false				-- 自己的家园室外是否解锁

---@type ECLRUCache
def.field(ECLRUCache).m_HomeInfoMap = nil					-- 其他人的家园信息

---@type table
def.field("table").m_HostHomeInfo = BLANK_TABLE_INIT		-- 主角的家园信息

---@type boolean
def.field("boolean").m_bWalkInHome = true	--在家园内为走路模式

---@type boolean
def.field("boolean").m_bInEditMode = false --是否处于编辑模式

---@type boolean
def.field("boolean").m_bShowHomeInfo = false

---@type number
def.field("number").m_last_BuyOperation = 0

---@type number
def.field("number").m_curOperTid = 0		-- 当前装修或家具的TID

---@type boolean
def.field("boolean").m_bInDeleteMode = false

---@type boolean
def.field("boolean").m_bOptLock = false --协议的收发要按照 “ONE BY ONE” 的规则 没有收到回复就不允许操作 为了保证relation的安全

---@type number
def.field("number").m_WaitingUpdatePutIndex = 0

---@type table
def.field("table").m_S2C_CallBackTab = BLANK_TABLE_INIT

---@type table
def.field("table").m_QueryHomeInfoCB = BLANK_TABLE_INIT

---@type boolean
def.field("boolean").m_bInDesignMode = false

---@type boolean
def.field("boolean").m_bDebugMode = false

---@type boolean
def.field("boolean").m_bDuringRebuild = false --重建过程中（比如收到服务器S2C_HomeData消息时）

---@type boolean
def.field("boolean").m_bCreateInComplete = false --创建不完整（因内存问题等）

---@type ECHomeManager
local m_Instance = nil

---@return ECHomeManager
def.static("=>", ECHomeManager).Instance = function()
	if not m_Instance then
		m_Instance = ECHomeManager()
	end
	return m_Instance
end

---@param self ECHomeManager
---@return void
def.method().Init = function(self)
	if self.m_bInited then
		return
	end

	self.m_HomeInfoMap = ECLRUCache.new("home_info_cache", 50)

	ECHomeData.Instance():Init()
	ECHomeView.Instance():Init()
	ECHomeSpaceUtil.Instance():Init()

	self.m_bInited = true
end

---@param self ECHomeManager
---@param bInEditMode boolean
---@return void
def.method("boolean").Reset = function(self, bInEditMode)
	self.m_bOptLock = false

	if not bInEditMode then
		self:SetEditMode(false)
	end

	self.m_bDuringRebuild = false
	self:SetCurOperTid(0)
	self.m_S2C_CallBackTab = {}
	self.m_QueryHomeInfoCB = {}
	self.m_OwnerRoleID = ZeroUInt64

	if self.m_HomeInfoMap then
		self.m_HomeInfoMap:Release()
	end

	ECShowLogicMan.Instance():EndShowLogicTimer()

	ECArrowMan.Instance():ClearWallArrows()
	ECHomeView.Instance():Reset()
	ECHomeData.Instance():Reset()
	ECHomeSpaceUtil.Instance():Reset()
	ECHomeStageMan.Instance():Reset()
	ECHomeHouseKeeper.Instance():Reset()
	ECHomeProduce.Instance():Reset()
end

---@param self ECHomeManager
---@return void
def.method().Release = function(self)
	self.m_bUnlock = false
	self.m_bUnlockIndoor = false
	self.m_bUnlockOutdoor = false
	self.m_bDuringRebuild = false
	self.m_bInEditMode = false
	self.m_bOptLock = false
	self:SetCurOperTid(0)
	self.m_S2C_CallBackTab = {}
	self.m_QueryHomeInfoCB = {}

	self.m_HostHomeInfo = {}
	if self.m_HomeInfoMap then
		self.m_HomeInfoMap:Release()
		self.m_HomeInfoMap = nil
	end

	ECArrowMan.Instance():ClearWallArrows()
	ECHomeStageMan.Instance():Reset()
	ECHomeHouseKeeper.Instance():Reset()
	ECHomeProduce.Instance():Reset()

	ECHomeView.Instance():Release()
	ECHomeData.Instance():Release()
	ECHomeSpaceUtil.Instance():Release()
	local ECHomeDynamicNPCPosData = require "Home.Misc.ECHomeDynamicNPCPosData"
	ECHomeDynamicNPCPosData.Get():Reset()

	self.m_bInited = false
end

---@param self ECHomeManager
---@return void
def.method().OnReleaseGame = function (self)
	self:Release()
end

---@param self ECHomeManager
---@return void
def.method().OnEnterGameLogic = function(self)
	self:Init()
end

---@param self ECHomeManager
---@return void
def.method().OnLeaveGameLogic = function(self)
	--print("ECHomeManager.OnLeaveGameLogic")
	self:OnLeaveHome()
	self:Release()
end

---@param self ECHomeManager
---@return void
def.method().OnLeaveHome = function(self)
	ECGame.EventManager:raiseEvent(nil, HomeEvents.LeaveHomeEvent())

	self:SetEditMode(false)
	self:Reset(false)
end

---@param self ECHomeManager
---@return void
def.method().OnEnterHome = function(self)
	local hp = ECGame.Instance():GetHostPlayer()
	if not hp then return end

	local ECPanelMainHome = require "GUI.Home.ECPanelMainHome"
	ECPanelMainHome.Instance():OpenPanel()

	local ECHostAsyncTask = require "Players.ECHostAsyncTask"
	local task = ECHostAsyncTask.WaitForHomeDataReady()
	task:completeWith(function()
		local ECShowStageObj = require "Home.View.ECShowStageObj"
		---@type ECShowStageObj[]
		local showStageObjs = ECHomeView.Instance():GetViewNodesOfClass(ECShowStageObj)
		if #showStageObjs > 0 then
			local index = math.random(1, #showStageObjs)
			showStageObjs[index]:OnVisitorEnter()
		end
	end)
	task:start()

	ECGame.EventManager:raiseEvent(nil, HomeEvents.EnterHomeEvent())

	--if not self:IsInMyHome() then
		local UserData = require"Data.UserData"
		local ownerId = self:GetHomeOwnerID()
		local ownerIdKey = LuaUInt64.ToString(ownerId)
		local homedata = UserData.Instance():GetRoleCfg("home_visitlog")
		if not homedata then
			homedata = {}
			UserData.Instance():SetRoleCfg("home_visitlog", homedata)
		end
		homedata[ownerIdKey] = GameUtil.GetServerGMTTime()
		UserData.Instance():SetRoleCfg("home_visitlog", homedata) --记录访问时间
		ECGame.EventManager:raiseEvent(nil, HomeEvents.HomeVisitorLogTimeEvent())
	--end
end
---今日是否已拜访
---@param self ECHomeManager
---@param role_id string
---@return boolean
def.method("string", "=>", "boolean").HasVisitHomeToDay = function(self, role_id)
	local UserData = require"Data.UserData"
	local ownerIdKey = LuaUInt64.ToString(role_id)
	local homedata = UserData.Instance():GetRoleCfg("home_visitlog")
	if not homedata then
		return false
	end
	local todayVisitTime = homedata[ownerIdKey]
	if not todayVisitTime then
		return false
	end

	local nowtime = GameUtil.GetServerGMTTime()
	--local tt = os.date("*t", nowtime)
	--tt.day = tt.day + 1
	--nowtime = os.time(tt)

	--下次8点刷新
	local eightClockTimestamp = os.GetDayStartTimeStamp(nowtime, 8*60*60)
	--warn("ownerIdKey", ownerIdKey, todayVisitTime, os.ToDate(todayVisitTime), os.ToDate(nowtime), os.ToDate(eightClockTimestamp))
	--local t = os.date("*t", nowtime)
	if nowtime > eightClockTimestamp then --次日上午8点
		eightClockTimestamp = eightClockTimestamp + 24*3600
	end

	local visiteightClockTimestamp = os.GetDayStartTimeStamp(todayVisitTime, 8*60*60)
	local diftime = os.difftime(eightClockTimestamp, visiteightClockTimestamp)

	if todayVisitTime < eightClockTimestamp and nowtime < eightClockTimestamp and os.ToWholeTime(diftime)[1] <= 1 then
		return true
	end

	return false
end

---@param self ECHomeManager
---@param indoor boolean
---@return boolean
def.method("boolean", "=>", "boolean").EnterMyHome = function(self, indoor)
	if self.m_bOptLock then
		return false
	end

	if not self.m_bUnlock then
		FlashTipMan.FlashTipByStrID(91015)
		return false
	end

	local newHomeType = indoor and CONSTANT_DEFINE.HOME_TYPE.HT_INDOOR or CONSTANT_DEFINE.HOME_TYPE.HT_OUTDOOR
	--print(self:GetHomeType(), indoor, newHomeType)
	if self:IsInMyHome() and self:GetHomeType() == newHomeType then
		FlashTipMan.FlashTipByStrID(91016)
		return false
	end

	if self:IsUpgrading() then
		FlashTipMan.FlashTipByStrID(91035)
		return false
	end

	local hostPlayer = globalGame:GetHostPlayer()
	if hostPlayer:IsFollowed() then
		FlashTipMan.FlashTipByStrID(74019)
		return false
	end

	if not self:IsInHome() and globalGame:IsInInstance() then
		FlashTipMan.FlashTipByStrID(91088)
		return false
	end

	if not require "Utility.FunctionSwitch".Get():IsFunctionActive(FUNC_CODE.kFuncCodeHometown) then
		FlashTipMan.FlashTip(StringTable.Get(17))
		return false
	end
	
	if not self:CheckAndPromptMyHomeIGU(indoor) then
		return false
	end
	
	local client_msg = require "PB.client_msg"
	local msg = client_msg.gp_home_op_req()
	msg.op = _G.CONSTANT_DEFINE.HOME_OP_ENTER
	msg.home_owner = hostPlayer:GetID()
	msg.transfer_type = indoor and CONSTANT_DEFINE.HOME_TYPE.HT_INDOOR or CONSTANT_DEFINE.HOME_TYPE.HT_OUTDOOR
	pb_helper.Send(msg)

	self.m_bOptLock = true
	return true
end

---@param self ECHomeManager
---@param indoor boolean
---@return boolean
def.method("boolean", "=>", "boolean").CheckAndPromptMyHomeIGU = function (self, indoor)
	local ECIGUSceneHelper = require "IGU.ECIGUSceneHelper"
	local sceneId = self:GetCurHomeSceneID(indoor)
	return ECIGUSceneHelper.BeforeGetIntoPosInScene(sceneId, 0, 0, 0)
end

---@param self ECHomeManager
---@param role_id string
---@param indoor boolean
---@return boolean
def.method("string", "boolean", "=>", "boolean").EnterOtherHome = function(self, role_id, indoor)
	if self.m_bOptLock then
		return false
	end

	local newHomeType = indoor and CONSTANT_DEFINE.HOME_TYPE.HT_INDOOR or CONSTANT_DEFINE.HOME_TYPE.HT_OUTDOOR
	if self:IsInOtherHome(role_id) and self:GetHomeType() == newHomeType then
		FlashTipMan.FlashTipByStrID(91016)
		return false
	end

	if globalGame:GetHostPlayer():IsFollowed() then
		FlashTipMan.FlashTipByStrID(74019)
		return false
	end

	if not self:IsInHome() and globalGame:IsInInstance() then
		FlashTipMan.FlashTipByStrID(91088)
		return false
	end

	local client_msg = require "PB.client_msg"
	local msg = client_msg.gp_home_op_req()
	msg.op = _G.CONSTANT_DEFINE.HOME_OP_ENTER
	msg.home_owner = role_id
	msg.transfer_type = indoor and CONSTANT_DEFINE.HOME_TYPE.HT_INDOOR or CONSTANT_DEFINE.HOME_TYPE.HT_OUTDOOR
	pb_helper.Send(msg)

	self.m_bOptLock = true
	return true
end

---@param self ECHomeManager
---@return boolean
def.method("=>", "boolean").IsUnlocked = function(self)
	return self.m_bUnlock
end

-- 获取自己的家园室内外解锁情况
---@param self ECHomeManager
---@return boolean,boolean
def.method("=>", "boolean", "boolean").GetSceneUnlockStatus = function(self)
	return self.m_bUnlockIndoor, self.m_bUnlockOutdoor
end

---@param self ECHomeManager
---@param b boolean
---@return void
def.method("boolean").SetUnlocked = function(self, b)
	local changed = self.m_bUnlock ~= b
	self.m_bUnlock = b
	if changed and b then
		if _G.IsBranch("oversea_korea") then
			require "ProxySDK.ECAppsFlyer".sendAppsFlyerEvent("unlocked_home", "")
		end
	end
end

---@param self ECHomeManager
---@return boolean
def.method("=>", "boolean").IsInHome = function(self)
	local FEInstanceMan = require "Instance.FEInstanceMan"
	return FEInstanceMan.Instance():IsInHomeInstance()
end

---@param self ECHomeManager
---@return number
def.method("=>", "number").GetHomeType = function(self)
	return ECHomeConfig.GetHomeSceneType(globalGame:GetCurrentSceneID())
end

-- 是否在我的家园房间内
---@param self ECHomeManager
---@return boolean
def.method("=>", "boolean").IsInMyRoom = function(self)
	return self:IsInMyHome() and self:GetHomeType() == CONSTANT_DEFINE.HOME_TYPE.HT_INDOOR
end

---@param self ECHomeManager
---@return boolean
def.method("=>", "boolean").IsInMyHome = function(self)
	return self:IsInHome() and self.m_OwnerRoleID == globalGame:GetHostPlayerID()
end

---@param self ECHomeManager
---@param role_id string
---@return boolean
def.method("string", "=>", "boolean").IsInOtherHome = function(self, role_id)
	return self:IsInHome() and self.m_OwnerRoleID == role_id
end

---@param self ECHomeManager
---@return string
def.method("=>", "string").GetHomeOwnerID = function(self)
	return self.m_OwnerRoleID
end

---@param self ECHomeManager
---@return boolean
def.method("=>", "boolean").IsWalkMode = function(self)
	return self.m_bWalkInHome
end

---@param self ECHomeManager
---@param bWalkMode boolean
---@return void
def.method("boolean").SetWalkMode = function(self, bWalkMode)
	self.m_bWalkInHome = bWalkMode

	local hp = globalGame:GetHostPlayer()
	if hp then
		hp:RefreshDefaultWalk()
	end
end

---@param self ECHomeManager
---@param OperTid number
---@return void
def.method("number").SetCurOperTid = function (self, OperTid)
	if self.m_curOperTid ~= OperTid then
		if self.m_curOperTid ~= 0 then	-- 还原高亮效果
			local cfg, dt = ElementData.getConfig(self.m_curOperTid)
			if cfg and dt == CONSTANT_DEFINE.CONFIG_TYPE.CONFIG_HOME_BUILD then
				if cfg.func_class== CONSTANT_DEFINE.HOME_BUILD_CLASS.HOME_BUILD_WALLPAPER then--墙纸
					ECHomeView.Instance():SetWallIntensity(DEFAULT_INTENSITY)
				elseif cfg.func_class== CONSTANT_DEFINE.HOME_BUILD_CLASS.HOME_BUILD_FLOOR then--地板
					ECHomeView.Instance():SetFloorIntensity(DEFAULT_INTENSITY)
				elseif cfg.func_class== CONSTANT_DEFINE.HOME_BUILD_CLASS.HOME_BUILD_ROOF_MAT then--天花板
					ECHomeView.Instance():SetRoofIntensity(DEFAULT_INTENSITY)
				elseif cfg.func_class== CONSTANT_DEFINE.HOME_BUILD_CLASS.HOME_BUILD_TOP_MAT then--瓦
					ECHomeView.Instance():SetTopIntensity(DEFAULT_INTENSITY)
				end
			end
		end

		self.m_curOperTid = OperTid

		local tip
		if self.m_curOperTid ~= 0 then --设置高亮效果
			local config, dataType = ElementData.getConfig(self.m_curOperTid)
			if config and dataType == CONSTANT_DEFINE.CONFIG_TYPE.CONFIG_HOME_BUILD then
				if config.func_class == CONSTANT_DEFINE.HOME_BUILD_CLASS.HOME_BUILD_WALLPAPER then--墙纸
					ECHomeView.Instance():SetWallIntensity(HIGH_INTENSITY)

					if ECHomeCamMan.Instance():GetViewMode() ~= ECHomeCamMan.VIEW_MODE.GOD45 then
						ECHomeCamMan.Instance():SwitchViewMode(ECHomeCamMan.VIEW_MODE.GOD45)
					end
				elseif config.func_class == CONSTANT_DEFINE.HOME_BUILD_CLASS.HOME_BUILD_FLOOR then--地板
					ECHomeView.Instance():SetFloorIntensity(HIGH_INTENSITY)

					if ECHomeCamMan.Instance():GetViewMode() ~= ECHomeCamMan.VIEW_MODE.TOP then
						ECHomeCamMan.Instance():SwitchViewMode(ECHomeCamMan.VIEW_MODE.TOP)
					end
				elseif config.func_class == CONSTANT_DEFINE.HOME_BUILD_CLASS.HOME_BUILD_ROOF_MAT then--天花板
					ECHomeView.Instance():SetRoofIntensity(HIGH_INTENSITY)

					if ECHomeCamMan.Instance():GetViewMode() ~= ECHomeCamMan.VIEW_MODE.BOTTOM then
						ECHomeCamMan.Instance():SwitchViewMode(ECHomeCamMan.VIEW_MODE.BOTTOM)
					end
				elseif config.func_class == CONSTANT_DEFINE.HOME_BUILD_CLASS.HOME_BUILD_TOP_MAT then--瓦
					ECHomeView.Instance():SetTopIntensity(HIGH_INTENSITY)
				end
				local funcclass = config.func_class
				if funcclass == 0 then
					funcclass = config.tool_type - 1
				end

				if homeCfg.tips.buildtip and homeCfg.tips.buildtip[funcclass] then
					tip = homeCfg.tips.buildtip[funcclass]
				end
			end
		end

		local ECPanelMainHomeEdit = require "GUI.Home.ECPanelMainHomeEdit"
		if tip then
			ECPanelMainHomeEdit.Instance():ShowBuildTip(true, tip)
		else
			ECPanelMainHomeEdit.Instance():ShowBuildTip(false,"")
		end
	end
end

---@param self ECHomeManager
---@return void
def.method().CreateEmptyHome = function(self)
	ECHomeData.Instance():CreateEmptyHome()

end

---@param self ECHomeManager
---@param dataType number
---@param homeDataFromServer table
---@return void
def.method("number", "table").EnterDesignMode = function (self, dataType, homeDataFromServer)
	local hp = ECGame.Instance().m_HostPlayer
	if not hp then return end

	--[[
	local home_data
	if dataType == DESIGN_DATA_TYPE.USE_EMPTY then --使用空数据
		home_data = client_msg.gp_home_op_res.gp_home_op_res()
		home_data.home_owner = hp.ID
	end]]

end

---@param self ECHomeManager
---@param debugMode boolean
---@return void
def.method("boolean").SetDebugMode = function(self, debugMode)
	self.m_bDebugMode = debugMode
end

---@param self ECHomeManager
---@return boolean
def.method("=>", "boolean").IsStandalone = function(self)
	return self.m_bDebugMode or self.m_bInDesignMode
end

---@param self ECHomeManager
---@param screenPos table
---@return boolean
def.method("table", "=>", "boolean").OnClickScreen = function (self, screenPos)
	if not self.m_bInEditMode then
		local clickRet = false
		-- 非编辑模式下点击家具
		local channel = CollisionChannel.TerrainBuilding
		local touchInfo = ECHomeView.Instance():TouchHomeItem(screenPos, channel)
		if touchInfo and touchInfo.result and touchInfo.result.Actor then
			-- 遍历所有家具
			local ECItemActorObj = require "Home.View.ECItemActorObj"
			---@type ECItemActorObj[]
			local furnitures = ECHomeView.Instance():GetViewNodesOfClass(ECItemActorObj)
			for _, v in pairs(furnitures) do
				if v.Actor and v.Actor == touchInfo.result.Actor then
					clickRet = clickRet or v:OnClick()
					break
				end
			end

			-- 遍历所有门
			local ECHoleObj = require "Home.View.ECHoleObj"
			---@type ECHoleObj[]
			local holes = ECHomeView.Instance():GetViewNodesOfClass(ECHoleObj)
			for _, hole in pairs(holes) do
				if hole.BindActor and hole.BindActor == touchInfo.result.Actor then
					clickRet = clickRet or hole:OnClick()
					break
				end
			end
		end
		return clickRet
	end

	local ECPanelMainHomeEdit = require "GUI.Home.ECPanelMainHomeEdit"

	local config = nil
	local dataType = nil
	local channel = CollisionChannel.TerrainBuilding
	if self.m_curOperTid == 0 then
		channel = CollisionChannel.Building
	else
		config, dataType = ElementData.getConfig(self.m_curOperTid)
		if config then
			if dataType == _G.CONSTANT_DEFINE.CONFIG_TYPE.CONFIG_HOME_BUILD then
				if config.tool_type == _G.CONSTANT_DEFINE.HOME_BUILD_TOOL_TYPE.HOME_BUILD_TOOL_MAT then --贴图
					if config.func_class == _G.CONSTANT_DEFINE.HOME_BUILD_CLASS.HOME_BUILD_FLOOR then
						-- 地板和grid地面重合，排除地面
						channel = CollisionChannel.Building
					elseif config.func_class == _G.CONSTANT_DEFINE.HOME_BUILD_CLASS.HOME_BUILD_ROOF_MAT then
						channel = CollisionChannel.Building
					else
						--channel = CollisionChannel.Building
					end
				end
			elseif dataType == CONSTANT_DEFINE.CONFIG_TYPE.CONFIG_HOME_FURNITURE then
				channel = CollisionChannel.TerrainBuilding
			end
		end
	end

	local touchInfo = ECHomeView.Instance():TouchHomeItem(screenPos, channel)
	if self.m_bShowHomeInfo then
		warn("OnClickScreen info:",self.m_curOperTid,channel,CollisionChannel.TerrainBuilding,config and config.tool_type or 0,touchInfo and touchInfo.type or nil
			,touchInfo and touchInfo.result and touchInfo.result.Actor or nil)
	end

	if self.m_curOperTid~=0 then
		if config and touchInfo then
			local operret
			if dataType == _G.CONSTANT_DEFINE.CONFIG_TYPE.CONFIG_HOME_BUILD then
				if config.tool_type == _G.CONSTANT_DEFINE.HOME_BUILD_TOOL_TYPE.HOME_BUILD_TOOL_MAT then --贴图
					local ECBuildToolMaterial = require "Home.BuildTool.ECBuildToolMaterial"
					operret = ECBuildToolMaterial.Instance():TouchHomeItem(config, touchInfo, self.m_curOperTid)
					if not operret and config.func_class== _G.CONSTANT_DEFINE.HOME_BUILD_CLASS.HOME_BUILD_FLOOR then
						local ECBuildToolGridFloor = require "Home.BuildTool.ECBuildToolGridFloor"
						if ECBuildToolGridFloor.Instance():CheckPutGridFloor() then
							return true
						end
					end
				elseif config.tool_type == _G.CONSTANT_DEFINE.HOME_BUILD_TOOL_TYPE.HOME_BUILD_TOOL_MODEL then --生成模型
					if config.func_class== _G.CONSTANT_DEFINE.HOME_BUILD_CLASS.HOME_BUILD_ROOF then--屋顶
						local ECBuildToolTop = require "Home.BuildTool.ECBuildToolTop"
						operret = ECBuildToolTop.Instance():BeginPut(touchInfo)
					elseif config.func_class == _G.CONSTANT_DEFINE.HOME_BUILD_CLASS.HOME_BUILD_DOOR or config.func_class == _G.CONSTANT_DEFINE.HOME_BUILD_CLASS.HOME_BUILD_WINDOW then --门
						local ECBuildToolDoor = require "Home.BuildTool.ECBuildToolDoor"
						operret = ECBuildToolDoor.Instance():BeginPut(touchInfo)
					elseif config.func_class == _G.CONSTANT_DEFINE.HOME_BUILD_CLASS.HOME_BUILD_STAIR then --楼梯
						local ECBuildToolStair = require "Home.BuildTool.ECBuildToolStair"
						operret = ECBuildToolStair.Instance():BeginPut(touchInfo)
					end
				elseif config.tool_type == _G.CONSTANT_DEFINE.HOME_BUILD_TOOL_TYPE.HOME_BUILD_TOOL_CUSTOM then --生成自定义模板
					if config.custom_build and config.custom_build~="" then
						local ECBuildToolCustomRoom = require "Home.BuildTool.ECBuildToolCustomRoom"
						operret = ECBuildToolCustomRoom.Instance():BeginPut(touchInfo)
					end
				end
			elseif dataType == _G.CONSTANT_DEFINE.CONFIG_TYPE.CONFIG_HOME_FURNITURE then
				local ECBuildToolFurniture = require "Home.BuildTool.ECBuildToolFurniture"
				operret = ECBuildToolFurniture.Instance():BeginPut(touchInfo)
			else
			end
			if operret ~= nil then
				if operret then
					ECHomeManager.Instance():SetCurOperTid(0)
					--ECPanelMainHomeEdit.Instance():TryShowTools()
				end
				return operret
			end
		end
	else
		--没有工具
		if touchInfo then
			if touchInfo.type == "wall" then --选中墙
				if self.m_bInDeleteMode then
					self:DeleteWall(touchInfo.home_id, touchInfo.floor_id, touchInfo.link_id, touchInfo.wall_id)
				else
					self:OnSelectWall(screenPos, touchInfo.link_id, touchInfo.wall_id)
				end
				return true
			elseif touchInfo.type == "roof" then --选中天花板
				if self.m_bInDeleteMode then
					self:DeleteRoof(touchInfo.home_id, touchInfo.floor_id, touchInfo.link_id)
				else
					self:OnSelectWall(screenPos, touchInfo.link_id, -1)
				end
				return true
			elseif touchInfo.type == "floor" then --选中地板
				if self.m_bInDeleteMode then
					self:DeleteFloor(touchInfo.home_id, touchInfo.floor_id, touchInfo.link_id)
				else
					self:OnSelectWall(screenPos, touchInfo.link_id, -1)
				end
				return true
			elseif touchInfo.type == "top" or touchInfo.type == "topwall" then --选中屋顶
				if self.m_bInDeleteMode then
					self:DeleteTop(touchInfo.home_id, touchInfo.floor_id, touchInfo.top_id)
				else
					self:OnSelectTop(touchInfo.home_id, touchInfo.floor_id, touchInfo.top_id)
				end
				return true
			elseif touchInfo.type == "stair" then --选中楼梯
				if self.m_bInDeleteMode then
					local stair = ECHomeView.Instance():GetHomeStair(touchInfo.home_id, touchInfo.floor_id, touchInfo.stair_id)
					if stair then
						local bSell = false
						local homeData = ECHomeData.Instance():GetNodeByPutIndex(stair.put_index)
						if homeData then
							local config, dataType = ElementData.getConfig(homeData.tid)
							if config and not config.recyclable then--不可以回收 sell
								bSell = true
							end
							local ECBuildToolStair = require "Home.ECBuildToolStair"
							ECBuildToolStair.Instance():DeleteHomeData(stair.put_index,bSell)
						end
					end
				else
					self:OnSelectStair(touchInfo.home_id, touchInfo.floor_id, touchInfo.stair_id)
				end
				return true
			elseif touchInfo.type == "barrier" then --选中栅栏
				if self.m_bInDeleteMode then
					local barrier = ECHomeView.Instance():GetLinkBarrier(touchInfo.home_id, touchInfo.floor_id, touchInfo.link_id)
					if barrier then
						local bSell = false
						local homeData = ECHomeData.Instance():GetNodeByPutIndex(barrier.put_index)
						if homeData then
							local config, dataType = ElementData.getConfig(homeData.tid)
							if config and not config.recyclable then--不可以回收 sell
								bSell = true
							end
							local ECBuildToolBarrier = require "Home.ECBuildToolBarrier"
							ECBuildToolBarrier.Instance():DeleteHomeData(barrier.put_index,bSell)
						end
					end
				else
					self:OnSelectBarrier(touchInfo.home_id, touchInfo.floor_id, touchInfo.link_id, touchInfo.barrier_id)
				end
				return true
			elseif touchInfo.type == "pool" then --选中泳池
				if self.m_bInDeleteMode then
					local pool = ECHomeView.Instance():GetPool(touchInfo.home_id, touchInfo.floor_id, touchInfo.pool_id)
					if pool then
						local bSell = false
						local homeData = ECHomeData.Instance():GetNodeByPutIndex(pool.put_index)
						if homeData then
							local config, dataType = ElementData.getConfig(homeData.tid)
							if config and not config.recyclable then--不可以回收 sell
								bSell = true
							end
							local ECBuildToolPool = require "Home.BuildTool.ECBuildToolPool"
							ECBuildToolPool.Instance():DeleteHomeData(pool.put_index,bSell)
						end
					end
				else
					self:OnSelectPool(touchInfo.home_id, touchInfo.floor_id, touchInfo.pool_id)
				end

				return true
			elseif touchInfo.type == "gridfloor" then --格子地板
				if self.m_bInDeleteMode then
					local ECBuildToolDelete = require "Home.BuildTool.ECBuildToolDelete"
					if not ECBuildToolDelete.Instance().m_bMoved then
						local gridFloor_floorIndex, gridFloor_gridIndex = ECHomeData.Instance():GetGridFloorIndexByPos(touchInfo.result.ImpactPoint.x, touchInfo.result.ImpactPoint.y, touchInfo.result.ImpactPoint.z)
						return self:DeleteGridFloor(gridFloor_floorIndex, gridFloor_gridIndex)
					end
					return false
				end
			elseif touchInfo.result and touchInfo.result.Actor then
				local bOper = false
				local ECItemActorObj = require "Home.View.ECItemActorObj"
				---@type ECItemActorObj[]
				local furnitures = ECHomeView.Instance():GetViewNodesOfClass(ECItemActorObj)
				for _, v in pairs(furnitures) do
					if v.Actor and v.Actor == touchInfo.result.Actor then
						local ECBuildToolFurniture = require "Home.BuildTool.ECBuildToolFurniture"
						if self.m_bInDeleteMode then
							self:DeleteFurniture(v.put_index)
						else
							local putInfo = ECHomeSpaceUtil.Instance():GetItemPutInfoByPutIndex(v.put_index)
							local editWorldPos = touchInfo.result.ImpactPoint
							if putInfo then
								editWorldPos.x = putInfo.x
								editWorldPos.y = putInfo.y
								editWorldPos.z = putInfo.z
							end
							ECPanelMainHomeEdit.Instance():ShowEditPanel(editWorldPos, ECBuildToolFurniture.Instance(), v.put_index)
						end
						bOper = true
						break
					end
				end
				local ECHoleObj = require "Home.View.ECHoleObj"
				---@type ECHoleObj[]
				local holes = ECHomeView.Instance():GetViewNodesOfClass(ECHoleObj)
				for _, v in pairs(holes) do
					-- 只有动态墙的上门可以删除移动
					if v.BindActor and v.BindActor == touchInfo.result.Actor then
						if not v:IsStaticDoor() then
							local ECBuildToolDoor = require "Home.BuildTool.ECBuildToolDoor"
							if self.m_bInDeleteMode then
								local bSell = false
								---@type ECHomeNodeHole
								local holeNode = ECHomeData.Instance():GetNodeByPutIndex(v.put_index)
								if holeNode then
									local config, dataType = ElementData.getConfig(holeNode.tid)
									if config and not config.recyclable then--不可以回收 sell
										bSell = true
									end
									ECBuildToolDoor.Instance():DeleteHomeData(v.put_index, bSell)
								end
							else
								ECPanelMainHomeEdit.Instance():ShowEditPanel(touchInfo.result.ImpactPoint, ECBuildToolDoor.Instance(), v.put_index)
							end
							bOper = true
							break
						end
					end
				end
				if bOper then
					return true
				end
			end
		end
	end
	return false
end

---@param self ECHomeManager
---@param actor userdata
---@param pos table
---@param x number
---@param y number
---@return void
def.method("userdata","table","number","number").OnClickNothing = function(self,actor,pos,x,y)
	if not self.m_bInEditMode then
		return
	end

	local ECPanelMainHomeEdit = require "GUI.Home.ECPanelMainHomeEdit"
	if not ECPanelMainHomeEdit.Instance():IsEditPanelShow() then
		return
	end
	if not self.m_bInDeleteMode then
		ECPanelMainHomeEdit.Instance():HideEditPanel()
	end
end

---@param self ECHomeManager
---@param screenPos table
---@param link_put_index number
---@param wall_put_index number
---@return void
def.method("table", "number", "number").OnSelectWall = function(self, screenPos, link_put_index, wall_put_index)
	if not self.m_bInEditMode then return end

	local ECBuildToolOneWall = require "Home.BuildTool.ECBuildToolOneWall"
	if not ECBuildToolOneWall.Instance():CanBuildNow() then return end

	local PlayerCtrl = GameUtil.GetPlayerController()
	local ret, WorldLocation, WorldDirection = PlayerCtrl:DeprojectScreenPositionToWorld(screenPos.x, screenPos.y)
	if not ret then return end
	local temp_v = {}
	vec_mul_num(temp_v, WorldDirection, 100000)
	vec_add(temp_v, WorldLocation, temp_v)
	local theWorld = GameUtil.GetWorld()
	local result = theWorld:LineTraceSingleByChannel(WorldLocation, temp_v, CollisionChannel.Terrain)
	if not result or not result.ImpactPoint then return end

	---@type ECLinkWallObj
	local link = ECHomeView.Instance():GetViewNodeByPutIndex(link_put_index)
	if not link or not link:IsDynamicLink() then return end
	if link then
		local curPos = result.ImpactPoint

		local WallSize = ECHomeView.Instance().WallSize
		local GridSize = ECHomeView.Instance().GridSize
		local centerWorldPos = link:GetCenterPos(WallSize)
		centerWorldPos.x = centerWorldPos.x * GridSize
		centerWorldPos.y = centerWorldPos.y * GridSize
		local floor_idx = ECHomeData.Instance():GetFloorIndexOfNode(link.put_index)
		centerWorldPos.z = ECHomeView.Instance():GetFloorsZ(floor_idx)
		local offsetx = centerWorldPos.x - curPos.x
		local offsety = centerWorldPos.y - curPos.y
		local offsetz = centerWorldPos.z - curPos.z
		centerWorldPos.z = curPos.z
		centerWorldPos.x = curPos.x
		centerWorldPos.y = curPos.y
		centerWorldPos.zOffset = offsetz
		centerWorldPos.xOffset = offsetx
		centerWorldPos.yOffset = offsety

		local ECPanelMainHomeEdit = require "GUI.Home.ECPanelMainHomeEdit"
		if link.bClosed and link.WallCount > 2 then
			local ECBuildToolOneRoom = require "Home.ECBuildToolOneRoom"
			ECPanelMainHomeEdit.Instance():ShowEditPanel(centerWorldPos, ECBuildToolOneRoom.Instance(), link.put_index)
		elseif link.WallCount == 1 then
			ECPanelMainHomeEdit.Instance():ShowEditPanel(centerWorldPos, ECBuildToolOneWall.Instance(), link.put_index)
		end
	end
end

---@param self ECHomeManager
---@param typeStr string
---@param x number
---@param y number
---@param distX number
---@param distY number
---@return boolean
def.method("string", "number", "number", "number", "number", "=>", "boolean").HandleTouch = function (self, typeStr, x, y, distX, distY)
	if not self.m_bInEditMode then
		return false
	end

	--print("HandleTouch", typeStr)

	local curOperMode = CONSTANT_DEFINE.HOME_BUILD_TOOL_TYPE.HOME_BUILD_TOOL_NONE
	local curOperFuncClass = CONSTANT_DEFINE.HOME_BUILD_CLASS.HOME_BUILD_NONE
	if self.m_curOperTid ~= 0 then
		local config, dataType = ElementData.getConfig(self.m_curOperTid)
		if config then
			if dataType == CONSTANT_DEFINE.CONFIG_TYPE.CONFIG_HOME_BUILD then
				curOperMode = config.tool_type
				curOperFuncClass = config.func_class
			elseif dataType == CONSTANT_DEFINE.CONFIG_TYPE.CONFIG_HOME_FURNITURE then
			else
				return false
			end
		else
		end
	end

	--warn("HandleTouch++++++++++",typeStr,self.m_curOperTid,curOperMode)
	if typeStr == "begin" then
		if self.m_bInDeleteMode then
			local buildToolDelete = ECBuildToolBase.GetBuildToolInstance("delete")
			return buildToolDelete:HandleTouchBegin(x, y, distX, distY)
		elseif curOperMode == CONSTANT_DEFINE.HOME_BUILD_TOOL_TYPE.HOME_BUILD_TOOL_WALL then --建单墙
			local buildToolOneWall = ECBuildToolBase.GetBuildToolInstance("one_wall")
			return buildToolOneWall:HandleTouchBegin(x, y, distX, distY)
		elseif curOperMode == CONSTANT_DEFINE.HOME_BUILD_TOOL_TYPE.HOME_BUILD_TOOL_ROOM then --建空房间
			local buildToolOneRoom = ECBuildToolBase.GetBuildToolInstance("one_room")
			return buildToolOneRoom:HandleTouchBegin(x, y, distX, distY)
		elseif curOperMode == CONSTANT_DEFINE.HOME_BUILD_TOOL_TYPE.HOME_BUILD_TOOL_NONE then
			local buildToolNone = ECBuildToolBase.GetBuildToolInstance("none")
			return buildToolNone:HandleTouchBegin(x, y, distX, distY)
		elseif curOperMode == CONSTANT_DEFINE.HOME_BUILD_TOOL_TYPE.HOME_BUILD_TOOL_MODEL then
			local build_eb = ElementData.getDataByConfigType(CONSTANT_DEFINE.CONFIG_TYPE.CONFIG_HOME_BUILD, self.m_curOperTid)
			if build_eb then
				if build_eb.func_class == CONSTANT_DEFINE.HOME_BUILD_CLASS.HOME_BUILD_BARRIER then --建栅栏
					local buildToolBarrier = ECBuildToolBase.GetBuildToolInstance("barrier")
					return buildToolBarrier:HandleTouchBegin(x, y, distX, distY)
				elseif build_eb.func_class == CONSTANT_DEFINE.HOME_BUILD_CLASS.HOME_BUILD_POOL then --泳池
					local buildToolPool = ECBuildToolBase.GetBuildToolInstance("pool")
					return buildToolPool:HandleTouchBegin(x, y, distX, distY)
				elseif build_eb.func_class == CONSTANT_DEFINE.HOME_BUILD_CLASS.HOME_BUILD_STAIR or
						build_eb.func_class == CONSTANT_DEFINE.HOME_BUILD_CLASS.HOME_BUILD_ROOF then --屋顶和楼梯 检测缩放
					local buildToolNone = ECBuildToolBase.GetBuildToolInstance("none")
					return buildToolNone:HandleTouchBegin(x, y, distX, distY)
				end
			end
		elseif curOperMode == CONSTANT_DEFINE.HOME_BUILD_TOOL_TYPE.HOME_BUILD_TOOL_MAT then
			if curOperFuncClass == CONSTANT_DEFINE.HOME_BUILD_CLASS.HOME_BUILD_FLOOR then
				local buildToolGridFloor = ECBuildToolBase.GetBuildToolInstance("grid_floor")
				return buildToolGridFloor:HandleTouchBegin(x, y, distX, distY)
			end
		end
	elseif typeStr == "move" then
		if self.m_bInDeleteMode then
			local buildToolDelete = ECBuildToolBase.GetBuildToolInstance("delete")
			return buildToolDelete:HandleTouchMove(x, y, distX, distY)
		elseif curOperMode == CONSTANT_DEFINE.HOME_BUILD_TOOL_TYPE.HOME_BUILD_TOOL_WALL then --建单墙
			local buildToolOneWall = ECBuildToolBase.GetBuildToolInstance("one_wall")
			return buildToolOneWall:HandleTouchMove(x, y, distX, distY)
		elseif curOperMode == CONSTANT_DEFINE.HOME_BUILD_TOOL_TYPE.HOME_BUILD_TOOL_ROOM then --建空房间
			local buildToolOneRoom = ECBuildToolBase.GetBuildToolInstance("one_room")
			return buildToolOneRoom:HandleTouchMove(x, y, distX, distY)
		elseif curOperMode == CONSTANT_DEFINE.HOME_BUILD_TOOL_TYPE.HOME_BUILD_TOOL_NONE then
			local buildToolNone = ECBuildToolBase.GetBuildToolInstance("none")
			return buildToolNone:HandleTouchMove(x, y, distX, distY)
		elseif curOperMode == CONSTANT_DEFINE.HOME_BUILD_TOOL_TYPE.HOME_BUILD_TOOL_MODEL then
			local build_eb = ElementData.getDataByConfigType(CONSTANT_DEFINE.CONFIG_TYPE.CONFIG_HOME_BUILD, self.m_curOperTid)
			if build_eb then
				if build_eb.func_class == CONSTANT_DEFINE.HOME_BUILD_CLASS.HOME_BUILD_BARRIER then --建栅栏
					local buildToolBarrier = ECBuildToolBase.GetBuildToolInstance("barrier")
					return buildToolBarrier:HandleTouchMove(x, y, distX, distY)
				elseif build_eb.func_class == CONSTANT_DEFINE.HOME_BUILD_CLASS.HOME_BUILD_POOL then --泳池
					local buildToolPool = ECBuildToolBase.GetBuildToolInstance("pool")
					return buildToolPool:HandleTouchMove(x, y, distX, distY)
				elseif build_eb.func_class == CONSTANT_DEFINE.HOME_BUILD_CLASS.HOME_BUILD_STAIR or
						build_eb.func_class == CONSTANT_DEFINE.HOME_BUILD_CLASS.HOME_BUILD_ROOF then --屋顶和楼梯 检测缩放
					local buildToolNone = ECBuildToolBase.GetBuildToolInstance("none")
					return buildToolNone:HandleTouchMove(x, y, distX, distY)
				end
			end
		elseif curOperMode == CONSTANT_DEFINE.HOME_BUILD_TOOL_TYPE.HOME_BUILD_TOOL_MAT then
			if curOperFuncClass == CONSTANT_DEFINE.HOME_BUILD_CLASS.HOME_BUILD_FLOOR then
				local buildToolGridFloor = ECBuildToolBase.GetBuildToolInstance("grid_floor")
				return buildToolGridFloor:HandleTouchMove(x, y, distX, distY)
			end
		end
	elseif typeStr == "end" then
		if self.m_bInDeleteMode then
			local buildToolDelete = ECBuildToolBase.GetBuildToolInstance("delete")
			return buildToolDelete:HandleTouchEnd(x, y, distX, distY)
		elseif curOperMode == CONSTANT_DEFINE.HOME_BUILD_TOOL_TYPE.HOME_BUILD_TOOL_WALL then --建单墙
			local buildToolOneWall = ECBuildToolBase.GetBuildToolInstance("one_wall")
			return buildToolOneWall:HandleTouchEnd(x, y, distX, distY)
		elseif curOperMode == CONSTANT_DEFINE.HOME_BUILD_TOOL_TYPE.HOME_BUILD_TOOL_ROOM then --建空房间
			local buildToolOneRoom = ECBuildToolBase.GetBuildToolInstance("one_room")
			return buildToolOneRoom:HandleTouchEnd(x, y, distX, distY)
		elseif curOperMode == CONSTANT_DEFINE.HOME_BUILD_TOOL_TYPE.HOME_BUILD_TOOL_NONE then
			local buildToolNone = ECBuildToolBase.GetBuildToolInstance("none")
			return buildToolNone:HandleTouchEnd(x, y, distX, distY)
		elseif curOperMode == CONSTANT_DEFINE.HOME_BUILD_TOOL_TYPE.HOME_BUILD_TOOL_MODEL then --生成模型 门窗等
			local build_eb = ElementData.getDataByConfigType(CONSTANT_DEFINE.CONFIG_TYPE.CONFIG_HOME_BUILD, self.m_curOperTid)
			if build_eb then
				if build_eb.func_class == CONSTANT_DEFINE.HOME_BUILD_CLASS.HOME_BUILD_DOOR then --门
					local buildToolDoor = ECBuildToolBase.GetBuildToolInstance("door")
					return buildToolDoor:HandleTouchEnd(x, y, distX, distY)
				elseif build_eb.func_class == CONSTANT_DEFINE.HOME_BUILD_CLASS.HOME_BUILD_WINDOW then --窗
					local buildToolDoor = ECBuildToolBase.GetBuildToolInstance("door")
					return buildToolDoor:HandleTouchEnd(x, y, distX, distY)
				elseif build_eb.func_class == CONSTANT_DEFINE.HOME_BUILD_CLASS.HOME_BUILD_BARRIER then --栅栏
					local buildToolBarrier = ECBuildToolBase.GetBuildToolInstance("barrier")
					return buildToolBarrier:HandleTouchEnd(x, y, distX, distY)
				elseif build_eb.func_class == CONSTANT_DEFINE.HOME_BUILD_CLASS.HOME_BUILD_POOL then --泳池
					local buildToolPool = ECBuildToolBase.GetBuildToolInstance("pool")
					return buildToolPool:HandleTouchEnd(x, y, distX, distY)
				elseif build_eb.func_class == CONSTANT_DEFINE.HOME_BUILD_CLASS.HOME_BUILD_STAIR or
						build_eb.func_class == CONSTANT_DEFINE.HOME_BUILD_CLASS.HOME_BUILD_ROOF then --屋顶和楼梯 检测缩放
					local buildToolNone = ECBuildToolBase.GetBuildToolInstance("none")
					return buildToolNone:HandleTouchEnd(x, y, distX, distY)
				end
			end
		elseif curOperMode == CONSTANT_DEFINE.HOME_BUILD_TOOL_TYPE.HOME_BUILD_TOOL_MAT then
			if curOperFuncClass == CONSTANT_DEFINE.HOME_BUILD_CLASS.HOME_BUILD_FLOOR then
				local buildToolGridFloor = ECBuildToolBase.GetBuildToolInstance("grid_floor")
				return buildToolGridFloor:HandleTouchEnd(x, y, distX, distY)
			end
		end
	end

	return false
end

---@param self ECHomeManager
---@return void
def.method().SaveDesignData = function (self)
	--TODO SaveDesignData
	--[[
	local hp = ECGame.Instance().m_HostPlayer
	if not hp then
		return
	end

	local hostidStr = LuaUInt64.ToString(hp.ID)

	if hostID == ZeroUInt64 then return end
	local file = string.format("/userdata/%s/Home/design_data.lua", hostidStr)
	local path = GameUtil.GetAssetsPath() .. file
	GameUtil.CreateDirectoryForFile(path)

	local writeData = {}
	writeData.relation = ECHomeRelation.Instance():SerializeRelationData(ECHomeRelation.Instance().m_Element)
	writeData.homeData = ECHomeRelation.Instance().m_HomeData
	writeData.gridFloorData = ECHomeRelation.Instance().m_gridFloorTid_gridIndexs
	writeData.instanceId = ECGame.Instance().m_curWorldTid

	local malut = require "Utility.malut"
	local bSucc, err = malut.toCodeToFile(writeData, path)

	local ECPanelHome_Edit = require "GUI.Home.ECPanelHome_Edit"
	if ECPanelHome_Edit.Instance():IsShow() then
		ECPanelHome_Edit.Instance():UpdateHomeProsperity()
	end]]
end

---@param self ECHomeManager
---@return boolean
def.method("=>", "boolean").IsInEditMode = function(self)
	return self.m_bInEditMode
end

---@param self ECHomeManager
---@param bEdit boolean
---@return void
def.method("boolean").SetEditMode = function(self, bEdit)
	local hp = ECGame.Instance():GetHostPlayer()
	if not hp then return end

	if bEdit then
		if self.m_bDuringRebuild then
			FlashTipMan.FlashTip(StringTable.Get(91011))
			return
		end

        -- 停止移动
        if hp:IsMoving() then
            hp:FSMChangeToStandState("enter home edit", 0)
        end

		-- 结束交互动作
		if hp:IsInteracting() then
			hp:SendInteractStop(true)
		end

		local _, _, z = hp:GetPos_UE()
		local floorIndex = ECHomeView.Instance():GetFloorIndexByZ(z)
		if floorIndex > 1 or ECHomeData.Instance():GetCurrentFloorIndex() < 1 then
			ECHomeData.Instance():SetCurrentFloorIndex(floorIndex)
		end

		-- TODO 地下室开关
		--[[
		if ECHomeData.Instance():GetCurrentFloorIndex() == _G.BASEMENT_FLOOR_INDEX and not ECGame.Instance():IsFunctionOpen(FUNC_CODE.kFuncCodeHometownBasement) then
			ECHomeData.Instance():SetCurrentFloorIndex(1)
		end]]
	end

	self.m_bInEditMode = bEdit

	if bEdit then
		ECHomeCamMan.Instance():EnterHomeCamera()
	else
		ECHomeCamMan.Instance():ExitHomeCamera()
	end

	self:ShowGrid(bEdit)

	ECShowLogicMan.Instance():ForceUpdateShowLogic(ECShowLogicMan.FORCE_UPDATE_MASK.ALL)
end

---@param self ECHomeManager
---@param bShow boolean
---@return void
def.method("boolean").ShowGrid = function (self, bShow)
	if bShow and not self.m_bInEditMode then
		return
	end

	if globalGame.m_isReleasing then
		return
	end

	local ECHomeGrid = require "Home.Util.ECHomeGrid"
	if bShow then
		local MaxWidth = ECHomeView.Instance().MaxWidth
		local MaxLength = ECHomeView.Instance().MaxLength
		local GridSize = ECHomeView.Instance().GridSize
		local zStart = ECHomeView.Instance():GetCurFloorsZ() / GridSize
		local floor_put_index = ECHomeData.Instance():GetCurFloorPutIndex()
		ECHomeGrid.Instance():Draw(0,0,zStart,MaxWidth,MaxLength,GridSize,false,floor_put_index)
	else
		ECHomeGrid.Instance():Show(false)
	end
end

---@param self ECHomeManager
---@param showTips boolean
---@return boolean
def.method("boolean", "=>", "boolean").CanOperate = function (self, showTips)
	if self.m_bOptLock then
		if showTips then
			FlashTipMan.FlashTip(StringTable.Get(91005))
		end
	end

	return (not self.m_bOptLock) and self.m_bInEditMode
end

---@param self ECHomeManager
---@return boolean
def.method("=>", "boolean").IsDuringRebuild = function(self)
	return self.m_bDuringRebuild
end

---@param self ECHomeManager
---@return boolean
def.method("=>", "boolean").IsDataInited = function(self)
	return ECHomeData.Instance().m_DataInited
end

---@param self ECHomeManager
---@return boolean
def.method("=>", "boolean").IsAllReady = function(self)
	return self:IsDataInited() and not self:IsDuringRebuild()
end

---@param self ECHomeManager
---@param msg pb.Message.PB.gp_home_op_res
---@return void
def.method("table").on_hometown_op = function (self, msg)
	self.m_bOptLock = false
	if msg.retcode == 0 then
        if msg.op == CONSTANT_DEFINE.HOME_OP_TYPE.HOME_OP_LOGIN then
	        self:SetUnlocked(msg.unlocked)
            ECGame.EventManager:raiseEvent(nil, HomeEvents.HomeUnlockEvent.new(self.m_bUnlock))

            self:S2C_HomeInfo(msg.home_owner, msg.oper_data.home_info, msg.unlocked)
            self:S2C_HomeMiscData(msg.home_owner, msg.misc_data)
        elseif msg.op == CONSTANT_DEFINE.HOME_OP_TYPE.HOME_OP_UNLOCK then
	        self:SetUnlocked(msg.unlocked)
            ECGame.EventManager:raiseEvent(nil, HomeEvents.HomeUnlockEvent.new(self.m_bUnlock))

            self:S2C_HomeInfo(msg.home_owner, msg.oper_data.home_info, msg.unlocked)
        elseif msg.op == CONSTANT_DEFINE.HOME_OP_TYPE.HOME_OP_ENTER then

        elseif msg.op == CONSTANT_DEFINE.HOME_OP_TYPE.HOME_OP_OBJ_BUY_AND_PUT then
            self:S2C_BuyAndPut(msg.oper_data.buy_and_put.put, msg.oper_data.buy_and_put.buy_count)
        elseif msg.op == CONSTANT_DEFINE.HOME_OP_TYPE.HOME_OP_OBJ_PUT then
            self:S2C_Put(msg.oper_data.put)
        elseif msg.op == CONSTANT_DEFINE.HOME_OP_TYPE.HOME_OP_OBJ_SYNC then
            self:S2C_HomeData(msg.home_data, msg.home_type, false)
        elseif msg.op == CONSTANT_DEFINE.HOME_OP_TYPE.HOME_OP_USE_ITEM_SYNC then

        elseif msg.op == CONSTANT_DEFINE.HOME_OP_TYPE.HOME_OP_CANCEL_ITEM_SYNC then

        elseif msg.op == CONSTANT_DEFINE.HOME_OP_TYPE.HOME_OP_UPDATE_OBJ_DATA then
            self:S2C_Update(msg.oper_data.update_obj)
        elseif msg.op == CONSTANT_DEFINE.HOME_OP_TYPE.HOME_OP_INFO then
            self:S2C_HomeInfo(msg.home_owner, msg.oper_data.home_info, msg.unlocked)
            self:On_S2C_QueryInfo_CallBack(msg.home_owner)
            return
        elseif msg.op == CONSTANT_DEFINE.HOME_OP_TYPE.HOME_OP_OBJ_CANCEL then
            self:S2C_Cancel(msg.oper_data.cancel)
        elseif msg.op == CONSTANT_DEFINE.HOME_OP_TYPE.HOME_OP_OBJ_CANCEL_ALL then
            self:S2C_CancelAllItem(msg.oper_data.cancel_all, msg.home_data, msg.home_type)
        elseif msg.op == CONSTANT_DEFINE.HOME_OP_TYPE.HOME_OP_OBJ_MULTI_CANCEL then
            self:S2C_MultiCancel(msg.oper_data.multi_cancel)
        elseif msg.op == CONSTANT_DEFINE.HOME_OP_TYPE.HOME_OP_OBJ_MULTI_PUT then
            self:S2C_MultiPut(msg.oper_data.multi_put)
        elseif msg.op == CONSTANT_DEFINE.HOME_OP_TYPE.HOME_OP_UPGRADE then
            self:S2C_HomeLevelUp(msg.home_owner, msg.oper_data.home_info)
        elseif msg.op == CONSTANT_DEFINE.HOME_OP_TYPE.HOME_OP_DISPLAY then
            self:S2C_StageDisplay(msg.home_type, msg.oper_data.display)
		elseif msg.op == CONSTANT_DEFINE.HOME_OP_TYPE.HOME_OP_DISPLAY_REFRESH then
			self:S2C_DelStageDisplay(msg.home_type, msg.del_display_list)
		elseif msg.op == CONSTANT_DEFINE.HOME_OP_TYPE.HOME_OP_UNLOCK_ROOM then
            self:S2C_UnlockRoom(msg.oper_data.unlock_room)
        elseif msg.op == CONSTANT_DEFINE.HOME_OP_TYPE.HOME_OP_OBJ_MULTI_OPER then
            self:S2C_MultiOperation(msg.oper_data.multi_oper)
        elseif msg.op == CONSTANT_DEFINE.HOME_OP_TYPE.HOME_OP_UPDATE_RELATION then
            self:S2C_UpdateRelation(msg.oper_data.update_relation)
        elseif msg.op == CONSTANT_DEFINE.HOME_OP_TYPE.HOME_OP_DEBUG then
            self:S2C_HomeDebugData(msg.oper_data.debug)
        elseif msg.op == CONSTANT_DEFINE.HOME_OP_TYPE.HOME_OP_DAILY_REWARD then
            --self:S2C_GetDailyReward()
        elseif msg.op == CONSTANT_DEFINE.HOME_OP_TYPE.HOME_OP_BUTLER then
            self:S2C_Butler(msg.home_owner, msg.oper_data.butler)
        elseif msg.op == CONSTANT_DEFINE.HOME_OP_TYPE.HOME_OP_VISIT_REFRESH then
            self:S2C_VisitInfo(msg.home_owner, msg.visitor_info)
        elseif msg.op == CONSTANT_DEFINE.HOME_OP_TYPE.HOME_OP_ROOM_REFRESH then
            self:S2C_RoomRefresh(msg.home_owner, msg.room_map)
        elseif msg.op == CONSTANT_DEFINE.HOME_OP_TYPE.HOME_OP_DISPATCH_REFRESH then
            self:S2C_DispatchParam(msg.home_owner, msg.dispatch_param)
        elseif msg.op == CONSTANT_DEFINE.HOME_OP_TYPE.HOME_OP_PEOPLE_REFRESH then
            self:S2C_PeopleRefresh(msg.home_owner, msg.people_map, msg.del_people_list)
        elseif msg.op == CONSTANT_DEFINE.HOME_OP_TYPE.HOME_OP_DISPATCH then
        elseif msg.op == CONSTANT_DEFINE.HOME_OP_TYPE.HOME_OP_DISPATCH_ORDER then
        elseif msg.op == CONSTANT_DEFINE.HOME_OP_TYPE.HOME_OP_ROOM_REFORM then
        elseif msg.op == CONSTANT_DEFINE.HOME_OP_TYPE.HOME_OP_RESEARCH_REFRESH then
            self:S2C_ResearchRefresh(msg.home_owner, msg.researching_info, msg.active_tech_tids)
        elseif msg.op == CONSTANT_DEFINE.HOME_OP_TYPE.HOME_OP_ORDER_REFRESH then
            self:S2C_ActiveOrderRefresh(msg.home_owner, msg.active_order_tids)
        elseif msg.op == CONSTANT_DEFINE.HOME_OP_TYPE.HOME_OP_SPEED then
            self:S2C_SpeedUp(msg.home_owner, msg.give_speed_map)
        elseif msg.op == CONSTANT_DEFINE.HOME_OP_TYPE.HOME_OP_SPEED_CLEAR then
            self:S2C_SpeedListClear(msg.home_owner)
        elseif msg.op == CONSTANT_DEFINE.HOME_OP_TYPE.HOME_OP_REPU_REFRESH then
            self:S2C_Reputation(msg.home_owner, msg.repu_map)
        elseif msg.op == CONSTANT_DEFINE.HOME_OP_TYPE.HOME_OP_REWARD_INFORM then
            self:S2C_RewardInform(msg.rwd_type, msg.rwd_map)
        elseif msg.op == CONSTANT_DEFINE.HOME_OP_TYPE.HOME_OP_MERCHANT_INFO then
            self:S2C_MerchantInfo(msg.home_owner, msg.merchant_info)
        elseif msg.op == CONSTANT_DEFINE.HOME_OP_TYPE.HOME_OP_UNLOCK_INDOOR then
			self:S2C_UnlockIndoorInfo(msg.home_owner, msg.oper_data.home_info.owner_extra.unlock_indoor_info)
        elseif msg.op == CONSTANT_DEFINE.HOME_OP_TYPE.HOME_OP_OBJ_UNLOCK then
			self:S2C_ObjUnlock(msg.home_owner, msg.oper_data.obj_unlock)
		else
            _warn("on_hometown_op, unknown op "..msg.op)
            FlashTipMan.FlashTip("on_hometown_op, unknown op "..msg.op)
        end
        ECHomeManager.Instance():On_S2C_SUCC_CallBack(msg.op)

		if msg.oper_data and msg.oper_data.sync then
			self:S2C_ItemSync(msg.oper_data.sync)
		end
	else
		print(("on_hometown_op, op: %d, retcode: %d"):format(msg.op, msg.retcode))
		--if homeCfg.tips.errortip[msg.retcode] then
		--	FlashTipMan.FlashTip(homeCfg.tips.errortip[msg.retcode])
		--else
		if msg.retcode < PB_ERROR_CODE.PB_ERROR_BEGIN then
			FlashTipMan.FlashTipByPBErrorCode(msg.retcode)
		end

		local ECPanelMainHomeEdit = require "GUI.Home.ECPanelMainHomeEdit"
		if ECPanelMainHomeEdit.Instance():IsVisible() then
			ECPanelMainHomeEdit.Instance():OnUpdateUI()
		end
	end
end

---@param self ECHomeManager
---@param op number
---@param callback function
---@return void
def.method("number","function").Set_S2C_SUCC_CallBack = function (self, op, callback)
	if not self.m_S2C_CallBackTab[op] then
		self.m_S2C_CallBackTab[op] = {}
	end
	table.insert(self.m_S2C_CallBackTab[op],callback)
end

---@param self ECHomeManager
---@param op number
---@return void
def.method("number").On_S2C_SUCC_CallBack = function (self, op)
	if self.m_S2C_CallBackTab[op] then
		--print_xf("self.m_S2C_CallBackTab[op]",#self.m_S2C_CallBackTab[op])
		for i,v in ipairs(self.m_S2C_CallBackTab[op]) do
			--print_xf(i,v)
			v()
		end
		self.m_S2C_CallBackTab[op] = nil
	end
end

---@param self ECHomeManager
---@param home_owner string
---@return void
def.method("string").On_S2C_QueryInfo_CallBack = function(self, home_owner)
	local cb_list = self.m_QueryHomeInfoCB[home_owner]
	if cb_list then
		for _, cb in ipairs(cb_list) do
			if cb then
				cb()
			end
		end
		self.m_QueryHomeInfoCB[home_owner] = nil
	end
end

---@param self ECHomeManager
---@param op number
---@return void
def.method("number").Remove_S2C_SUCC_CallBack = function (self, op)
	if self.m_S2C_CallBackTab[op] then
		self.m_S2C_CallBackTab[op] = nil
	end
end

---@param self ECHomeManager
---@param hometown_data pb.Message.PB.db_ref_home
---@param home_type number
---@param bInEditMode boolean
---@return void
def.method("table", "number", "boolean").S2C_HomeData = function (self, hometown_data, home_type, bInEditMode)
	_warn("S2C_HomeData", hometown_data)

	local oldRelLen = 0
	if ECHomeData.Instance():GetHomeRootNode() then
		local succ, relation = self:SerializeRelationData(false)
		if succ then
			oldRelLen = relation:len()
		end
	end

	local OwnerID = hometown_data.owner

	_warn(("S2C_HomeData++++++++: Owner[%s] len[%d] OldRelLen[%d]"):format(
			LuaUInt64.ToString(OwnerID), hometown_data.relation:len(), oldRelLen))

	self:Reset(bInEditMode)

	self.m_bDuringRebuild = true

	if not bInEditMode then
		self:SetEditMode(false)
	end

	self.m_OwnerRoleID = OwnerID

	ECHomeData.Instance():SetHomeData(hometown_data, home_type)

	-- 更新一下主人的家园信息
	self:UpdateHomeInfoFromData(OwnerID, hometown_data)
	-- 更新商人信息
	self:S2C_MerchantInfo(OwnerID, hometown_data.merchant_info)
	-- 更新解锁室内信息
	self:S2C_UnlockIndoorInfo(OwnerID, hometown_data.unlock_indoor_info)

	--local bHostHome = self.m_OwnerRoleID == ECGame.Instance():GetHostPlayerID()
	--if bHostHome then
		if not self.m_bInEditMode then
			local ECPanelMainHome = require "GUI.Home.ECPanelMainHome"
			ECPanelMainHome.Instance():OpenPanel()
		else
			local hp = globalGame:GetHostPlayer()
			local _, _, z = hp:GetPos_UE()
			local floorIndex = ECHomeView.Instance():GetFloorIndexByZ(z)
			ECHomeData.Instance():SetCurrentFloorIndex(floorIndex)
		end
	--end

	local ECPanelMainHomeEdit = require "GUI.Home.ECPanelMainHomeEdit"
	if ECPanelMainHomeEdit.Instance():IsValid() then
		ECPanelMainHomeEdit.Instance():SetEditMode(self.m_bInEditMode)
	end

	local function afterHomeCreate()
		---@param node ECHomeNode
		local function doAddPosData(node)
			if not node then return end
			if node then
				if node.type == _G.ECHOME_ELEMENT_TYPE_ENUM.LINK then
					ECHomeSpaceUtil.Instance():AddOrUpdateLinkPosData(node.put_index)
				elseif node.type == _G.ECHOME_ELEMENT_TYPE_ENUM.ITEM then
					ECHomeSpaceUtil.Instance():AddOrUpdateItemGridData(node.put_index)
				end
			end

			for child in node:ChildIterator() do
				doAddPosData(child)
			end
		end

		doAddPosData(ECHomeData.Instance():GetHomeRootNode())

		if not self.m_bCreateInComplete then
			--修正下单墙的拐角
			---@type ECHomeObj
			local home = ECHomeView.Instance():GetViewNodeByPutIndex(_G.HOME_ROOT_PUT_INDEX)
			if home then
				for _, floor in pairs(home.Floors) do
					for _, link in pairs(floor.Links) do
						if link:IsDynamicLink() then
							-- if link.WallCount==1 then
							for wall_id, wall in pairs(link.Walls) do
								local bUpdate = false
								if wall:GetPreWall(link) then
									bUpdate = true
								end
								if wall:GetNextWall(link) then
									bUpdate = true
								end
								if bUpdate then
									--warn("  __UpdateWallMesh: ", floor_id,link_id,wall_id)
									ECHomeView.Instance():UpdateWallMesh(wall_id)
								end
							end
						end
					end
				end

				_G.gc()
			end

			-- 家园展示台相关
			ECHomeStageMan.Instance():OnHomeInfo(hometown_data)

			-- 家园管家
			ECHomeHouseKeeper.Instance():OnHomeInfo(hometown_data)

			-- 家园生产
			ECHomeProduce.Instance():OnHomeInfo(hometown_data)
		end

		--if bHostHome then
			self.m_bDuringRebuild = false
			ECGame.EventManager:raiseEvent(nil, HomeEvents.HomeDataRebuildReadyEvent())
		--end
	end

	-- 更新几何节点树
	ECHomeView.Instance():UpdateViewTree(true, function()
		afterHomeCreate()
	end)
end

---@param self ECHomeManager
---@param OwnerID string
---@param hometown_data pb.Message.PB.db_ref_home
---@return void
def.method("string", "table").UpdateHomeInfoFromData = function(self, OwnerID, hometown_data)
	if OwnerID == globalGame:GetHostPlayerID() then
		local old_daily_rwd_state = self.m_HostHomeInfo.daily_rwd_state

		self.m_HostHomeInfo.daily_rwd_state = hometown_data.daily_rwd_state
		self.m_HostHomeInfo.street_daily_rwd_state = hometown_data.street_daily_rwd_state

		local DAILY_RWD_STATE = db_msg.db_ref_home.DAILY_RWD_STATE
		if old_daily_rwd_state == DAILY_RWD_STATE.DRS_UNCLAIMED and self.m_HostHomeInfo.daily_rwd_state == DAILY_RWD_STATE.DRS_CLAIMED then
			self:S2C_GetDailyReward()
		end

		self.m_HostHomeInfo.repus = {}
		for tid, repu in pairs(hometown_data.repu.repus) do
			self.m_HostHomeInfo.repus[tid] = LuaUInt64.ToDouble(repu.value)
		end
	else
		local homeInfo = self:GetHomeInfo(OwnerID)
		if not homeInfo then
			homeInfo = {}
			self.m_HomeInfoMap:Set(OwnerID, homeInfo)
		end

		homeInfo.unlock = true
		homeInfo.unlock_indoor = hometown_data.unlock_indoor
		homeInfo.unlock_outdoor = hometown_data.unlock_outdoor
		homeInfo.cur_level = hometown_data.cur_level
		homeInfo.is_upgrading = hometown_data.is_upgrading
		homeInfo.upgrade_end_ts = hometown_data.upgrade_end_ts
		homeInfo.house_keeper = hometown_data.butler_tid
		homeInfo.daily_rwd_state = hometown_data.daily_rwd_state
		homeInfo.street_daily_rwd_state = hometown_data.street_daily_rwd_state
		homeInfo.repus = {}
		for tid, repu in pairs(hometown_data.repu.repus) do
			homeInfo.repus[tid] = LuaUInt64.ToDouble(repu.value)
		end
		homeInfo.last_update = GameUtil.GetServerGMTTime()
	end
end

---@param self ECHomeManager
---@return void
def.method().OnInCompleteCreate = function (self)
	-- 家园创建未完成！（内存不足等原因）
	self.m_bCreateInComplete = true
end

--根据put update 和cancel数据获得需要的buy和sell
---@param self ECHomeManager
---@param multiPut table
---@param multiUpdate table
---@param multiCancel table
---@return table,table,number,table,number
def.method("table", "table", "table", "=>", "table", "table", "number", "table","number").GetNeedBuyAndSell = function (self, multiPut, multiUpdate, multiCancel)
	local multiBuy = {}
	local multiSell = {}
	local costMoney = 0
	local costCash = 0
	local costRepuList = {}

	local minus_tid2Count = {}
	local add_tid2Count = {}

	-- local malut = require "Utility.malut"
	-- print("GetNeedBuyAndSell multiUpdate")
	-- malut.printTable(multiUpdate)
	-- print("multiPut")
	-- malut.printTable(multiPut)
	-- print("multiCancel")
	-- malut.printTable(multiCancel)

	if multiCancel then
		for i = 1, #multiCancel do
			local config, dataType = ElementData.getConfig(multiCancel[i].obj_type)
			if config and not config.recyclable then--不可以回收 sell
				local homeData = ECHomeData.Instance():GetNodeByPutIndex(multiCancel[i].put_index)
				if homeData then
					if not minus_tid2Count[multiCancel[i].obj_type] then
						minus_tid2Count[multiCancel[i].obj_type] = 0
					end
					minus_tid2Count[multiCancel[i].obj_type] = minus_tid2Count[multiCancel[i].obj_type] + homeData.count
				end
			end
		end
	end

	if multiUpdate then
		for k,v in pairs(multiUpdate) do
			-- print("one update v.oldCount = ",v.oldCount)
			-- malut.printTable(v)
			if v.count > 0 then --数量变化
				local config, dataType = ElementData.getConfig(v.obj_type)
				if config then
					local delta = v.count - v.oldCount
					if delta < 0 then --回收或卖出
						if not config.recyclable then--卖出
							if not minus_tid2Count[v.obj_type] then
								minus_tid2Count[v.obj_type] = 0
							end
							minus_tid2Count[v.obj_type] = minus_tid2Count[v.obj_type] + math.abs(delta)
						end
					else
						if not add_tid2Count[v.obj_type] then
							add_tid2Count[v.obj_type] = 0
						end
						add_tid2Count[v.obj_type] = add_tid2Count[v.obj_type] + delta
					end
				end
			end
		end
	end

	if multiPut then
		for k,v in pairs(multiPut) do
			if not add_tid2Count[v.obj_type] then
				add_tid2Count[v.obj_type] = 0
			end
			add_tid2Count[v.obj_type] = add_tid2Count[v.obj_type] + v.count
		end
	end

	for k,v in pairs(add_tid2Count) do
		if minus_tid2Count[k] and minus_tid2Count[k] > 0 then
			if minus_tid2Count[k] > add_tid2Count[k] then
				minus_tid2Count[k] = minus_tid2Count[k] - add_tid2Count[k]
				add_tid2Count[k] = nil
			elseif minus_tid2Count[k] < add_tid2Count[k] then
				add_tid2Count[k] = add_tid2Count[k] - minus_tid2Count[k]
				minus_tid2Count[k] = nil
			else
				add_tid2Count[k] = nil
				minus_tid2Count[k] = nil
			end
		end
	end

	for k,v in pairs(add_tid2Count) do
		local data = ECHomeData.Instance():GetHomeDataByTid(k)
		local hascount = 0
		if data then
			hascount = data:GetUnputCount()
		end
		if hascount < v then --数量不够
			local lackcount = v - hascount
			local config, dataType = ElementData.getConfig(k)
			if config then
				local buyData = {}
				buyData.obj_type = k
				buyData.count = lackcount
				table.insert(multiBuy, buyData)

				if config.shopsell_repu_id and config.shopsell_repu_id > 0 then
					if not costRepuList[config.shopsell_repu_id] then
						costRepuList[config.shopsell_repu_id] = 0
					end
					costRepuList[config.shopsell_repu_id] = costRepuList[config.shopsell_repu_id] + config.shopsell_repu_val * lackcount
				else
					if config.shopsell_mode == 4 then
						costCash = costCash + config.shopsell_price * lackcount
					else
						costMoney = costMoney + config.shopsell_price * lackcount
					end
				end
			end
		end
	end

	for k,v in pairs(minus_tid2Count) do
		local config, dataType = ElementData.getConfig(k)
		if config then
			local sellData = {}
			sellData.obj_type = k
			sellData.count = v
			table.insert(multiSell, sellData)

			if config.shopsell_repu_id and config.shopsell_repu_id > 0 then
				if not costRepuList[config.shopsell_repu_id] then
					costRepuList[config.shopsell_repu_id] = 0
				end
				costRepuList[config.shopsell_repu_id] = costRepuList[config.shopsell_repu_id] - config.shopsell_repu_val * v
			else
				if config.shopsell_mode == 4 then
					costCash = costCash - config.shopsell_price * v
				else
					costMoney = costMoney - config.shopsell_price * v
				end
			end
		end
	end

	-- local malut = require "Utility.malut"
	-- print(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>multiBuy")
	-- malut.printTable(multiBuy)
	-- print("multiSell")
	-- malut.printTable(multiSell)
	-- print("costMoney = ",costMoney)
	-- print("costRepuList = ",costRepuList)
	-- malut.printTable(costRepuList)

	return multiBuy, multiSell, costMoney, costRepuList, costCash
end

---@param self ECHomeManager
---@param bCompress boolean
---@return boolean,string,boolean,string
def.method("boolean", "=>", "boolean", "string", "boolean", "string").SerializeRelationData = function (self, bCompress)
	return self:SerializeRelationData_Inner(bCompress, false)
end

---@param self ECHomeManager
---@param bCompress boolean
---@return boolean,string,boolean,string
def.method("boolean", "=>", "boolean", "string", "boolean", "string").SerializeRelationData_LargeLimit = function (self, bCompress)
	return self:SerializeRelationData_Inner(bCompress, true)
end

---@param self ECHomeManager
---@param org_relation string
---@param bCompress boolean
---@param bUseLargeLimitWhenCompress boolean
---@return string,boolean,string
def.method("string", "boolean", "boolean", "=>", "string", "boolean", "string").CompressRelationData = function(self, org_relation, bCompress, bUseLargeLimitWhenCompress)
	local data = org_relation
	local org_len = data:len()

	local ret_data, bCompressed = nil, false
	if bCompress and org_len >= START_COMPR_RELATION_SIZE then
		ret_data, bCompressed = ECHomeData.CompressData(data)

		local maxSize = (bUseLargeLimitWhenCompress and MAX_RELATION_SIZE_LARGELIMIT or MAX_RELATION_SIZE)
		local bExceedMax = ret_data:len() > maxSize
		warn(("CompressRelationData: Compress: size[%d -> %d] maxSize[%d] ExceedMax[%d]"):format(
				org_len, ret_data:len(), maxSize, bExceedMax and 1 or 0)) --, debug.tracebackex())

		if bExceedMax then
			FlashTipMan.FlashTip(StringTable.Get(91009)) --您的家园数据过于复杂，操作失败，请简化一下家园布置哦~
			return ret_data, bCompressed, data
		end
	else
		--warn("__SerializeRelationData: data, size = ", data, org_len, debug.tracebackex())

		ret_data = data
		bCompressed = false
	end

	return ret_data, bCompressed, data
end

---@param self ECHomeManager
---@param bCompress boolean
---@param bUseLargeLimitWhenCompress boolean
---@return boolean,string,boolean,string
def.method("boolean", "boolean", "=>", "boolean", "string", "boolean", "string").SerializeRelationData_Inner = function (self, bCompress, bUseLargeLimitWhenCompress)
	if not ECHomeData.Instance().m_DataInited then
		warn("err SerializeRelationData, DataInited is false!")
		return false, "", false, ""
	end

	local data = ECHomeData.Instance():SerializeRelationData()
	local org_len = data:len()

	local ret_data, bCompressed = nil, false
	if bCompress and org_len >= START_COMPR_RELATION_SIZE then
		ret_data, bCompressed = ECHomeData.CompressData(data)

		local maxSize = (bUseLargeLimitWhenCompress and MAX_RELATION_SIZE_LARGELIMIT or MAX_RELATION_SIZE)
		local bExceedMax = ret_data:len() > maxSize
		warn(("__SerializeRelation: Compress: size[%d -> %d] maxSize[%d] ExceedMax[%d]"):format(
				org_len, ret_data:len(), maxSize, bExceedMax and 1 or 0)) --, debug.tracebackex())

		if bExceedMax then
			FlashTipMan.FlashTip(StringTable.Get(91009)) --您的家园数据过于复杂，操作失败，请简化一下家园布置哦~
			return false, ret_data, bCompressed, data
		end
	else
		--warn("__SerializeRelationData: data, size = ", data, org_len, debug.tracebackex())

		ret_data = data
		bCompressed = false
	end

	return true, ret_data, bCompressed, data
end

---@param self ECHomeManager
---@param bCompress boolean
---@param bUseLargeLimitWhenCompress boolean
---@return boolean,string,boolean,string
def.method("boolean", "boolean", "=>", "boolean", "string", "boolean", "string").SerializeRelationData_Empty = function (self, bCompress, bUseLargeLimitWhenCompress)
	if not ECHomeData.Instance().m_DataInited then
		warn("err SerializeRelationData_Empty, DataInited is false!")
		return false, "", false, ""
	end

	local data = ECHomeData.Instance():MakeEmptyRelationData()
	local org_len = data:len()

	local ret_data, bCompressed
	if bCompress and org_len >= START_COMPR_RELATION_SIZE then
		ret_data, bCompressed = ECHomeData.CompressData(data)

		local maxSize = (bUseLargeLimitWhenCompress and MAX_RELATION_SIZE_LARGELIMIT or MAX_RELATION_SIZE)
		local bExceedMax = ret_data:len() > maxSize
		warn(("__SerializeRelation: Compress: size[%d -> %d] maxSize[%d] ExceedMax[%d]"):format(
				org_len, ret_data:len(), maxSize, bExceedMax and 1 or 0)) --, debug.tracebackex())

		if bExceedMax then
			FlashTipMan.FlashTip(StringTable.Get(91009)) --您的家园数据过于复杂，操作失败，请简化一下家园布置哦~
			return false, ret_data, bCompressed, data
		end
	else
		--warn("__SerializeRelationData: data, size = ", data, org_len, debug.tracebackex())

		ret_data = data
		bCompressed = false
	end

	return true, ret_data, bCompressed, data
end

--更新树形结构
---@param self ECHomeManager
---@param relation string
---@param relation_compress boolean
---@param relation_origin string
---@param bUndo boolean
---@return boolean
def.method("string", "boolean", "string", "boolean", "=>","boolean").C2S_UpdateRelation = function (self, relation, relation_compress, relation_origin, bUndo)
	_warn(("C2S_UpdateRelation+++++++ bUndo[%d] compress[%d] rel_len[%d] srclen[%d]"):format(
			bUndo and 1 or 0, relation_compress and 1 or 0, relation:len(), relation_origin:len()))

	if self.m_bOptLock then return false end

	local check_relation = self:CheckRelationIsOK(relation_origin,{}, false)
	if not check_relation then return false end

	local relation_sourcelen = relation_origin and relation_origin:len() or 0
	if relation_compress and relation_sourcelen < 1 then
		warn("relation_compress but relation_sourcelen < 1!", relation_sourcelen, debug.tracebackex())
		FlashTipMan.FlashTip(StringTable.Get(91032))
		return false
	end

	---@type pb.Message.PB.gp_home_op_req
	local msg = client_msg.gp_home_op_req()
	msg.op = CONSTANT_DEFINE.HOME_OP_TYPE.HOME_OP_UPDATE_RELATION
	msg.transfer_type = self:GetHomeType()
	msg.update_relation.undo = bUndo
	msg.update_relation.relation = relation
	msg.update_relation.relation_compress = relation_compress
	msg.update_relation.relation_sourcelen = relation_sourcelen

	local succ = true
	if not self:IsStandalone() then
		local exceedMaxSize
		succ, exceedMaxSize = pb_helper.Send(msg)
		if exceedMaxSize then
			FlashTipMan.FlashTip(StringTable.Get(91008))
		end
	end
	if succ then
		self.m_bOptLock = true

		if self:IsStandalone() then
			GameUtil.AddGlobalTimer(0, true, function()
				local s2cMsg = {}
				s2cMsg.retcode = 0
				s2cMsg.op = msg.op
				s2cMsg.oper_data = {}
				s2cMsg.oper_data.update_relation = msg.update_relation
				self:on_hometown_op(s2cMsg)
			end)
		end
	end
	return succ
end

---@param self ECHomeManager
---@param update_relation pb.Message.PB.home_update_relation_t
---@return void
def.method("table").S2C_UpdateRelation  = function (self, update_relation)
	_warn(("S2C_UpdateRelation++++++++ undo[%d] rel_compress[%d] len[%d] srclen[%d]"):format(
			update_relation.undo and 1 or 0, update_relation.relation_compress and 1 or 0, update_relation.relation:len(), update_relation.relation_sourcelen or 0))

	local rel_decompressed = update_relation.relation
	if update_relation.relation_compress then
		local decompressed = ECHomeData.DecompressData(update_relation.relation, update_relation.relation_sourcelen)
		if not decompressed then
			MsgBox.ShowMsgBox(nil, StringTable.Get(91090), nil, MsgBoxType.MBBT_OK)
			return
		end
		rel_decompressed = decompressed
	end

	--ECHomeData.Instance():UnserializeRelationData(rel_decompressed)

	if self.m_bInDesignMode then
		self:SaveDesignData()
	end
end

---@param self ECHomeManager
---@param bBuyOrAdd boolean
---@return boolean
def.method("boolean", "=>", "boolean").OperationCheck = function (self, bBuyOrAdd)
	if self.m_bOptLock or self.m_bDuringRebuild then
		return false
	end

	if bBuyOrAdd then
		if self.m_bCreateInComplete then
			FlashTipMan.FlashTip(StringTable.Get(91022))
			return false
		end

		if mtSystemInfo.GetMemoryStats and homeCfg.AvailPhysMemMBLimit then
			local AvailablePhysicalMB, TotalPhysicalMB = SystemInfo:GetMemoryStats()
			if AvailablePhysicalMB < homeCfg.AvailPhysMemMBLimit then
				-- 可用内存极低：无法进行添加、购买等操作，只能拆/卖
				FlashTipMan.FlashTip(StringTable.Get(91023))
				return false
			end
		end
	end

	return true
end

--购买和摆放
---@param self ECHomeManager
---@param obj_type number
---@param put_index number
---@param count number
---@param data table
---@param put_param any
---@param bUndo boolean
---@return boolean
def.method("number","number","number","table","dynamic","boolean","=>","boolean").C2S_BuyAndPut = function (self, obj_type, put_index, count, data, put_param, bUndo)
	_warn(("C2S_BuyAndPut+++++++ bUndo[%d] obj_type[%d] put_index[%d] count[%d]"):format(bUndo and 1 or 0, obj_type, put_index, count))
	if not self:OperationCheck(true) then
		return false
	end

	--TODO 设计模式
	--[[
	if self.m_bInDesignMode then
		local total_count = 0
		for obj_type, oneData in pairs(ECHomeRelation.Instance().m_HomeData) do
			if oneData.items and next(oneData.items) then
				for put_index, itemData in pairs(oneData.items) do
					total_count = total_count + itemData.count
				end
			end
		end

		if total_count >= homeCfg.design_cfg.designMaxCount then
			FlashTipMan.FlashTip(homeCfg.tips[128])
			return false
		end
	end]]

	local curTime = GameUtil.GetTimeSeconds()
	if not self.m_bInDesignMode and self.m_last_BuyOperation >0 and self.m_last_BuyOperation + CD_TIME > curTime then
		FlashTipMan.FlashTip(StringTable.Get(91013))
		return false
	end

	local succ, relation, bCompressed, relation_origin = self:SerializeRelationData(true)
	if not succ then
		return false
	end

	if not self:CheckRelationIsOK(relation_origin, {}, not bUndo) then
		return false
	end

	local node = ECHomeData.Instance():GetNodeByPutIndex(put_index)
	if not node then
		if not bUndo then
			warn("err C2S_BuyAndPut, node is nil ", obj_type, put_index, node)
			return false
		else
			node = ECHomeNode.CreateByTid(obj_type)
			node:CopyData(data)
		end
	end

	---@type pb.Message.PB.gp_home_op_req
	local msg = client_msg.gp_home_op_req()
	msg.op = CONSTANT_DEFINE.HOME_OP_TYPE.HOME_OP_OBJ_BUY_AND_PUT
	msg.transfer_type = self:GetHomeType()
	msg.buy_and_put.put.put_index = put_index
	msg.buy_and_put.put.tid = obj_type
	msg.buy_and_put.put.count = count
	msg.buy_and_put.put.data = node:Serialize()
	msg.buy_and_put.put.undo = bUndo

	if put_param and put_param ~= ZeroUInt64 then
		msg.buy_and_put.put_param = put_param
	end

	if msg.buy_and_put.put.count > 0  and msg.buy_and_put.put.data then
		msg.buy_and_put.put.relation = relation
		msg.buy_and_put.put.relation_compress = bCompressed
		msg.buy_and_put.put.relation_sourcelen = relation_origin:len()
		ECHomeData.Instance():SetTempUsedID(msg.buy_and_put.put.tid, msg.buy_and_put.put.put_index, data)

		local succ = true
		if not self:IsStandalone() then
			local exceedMaxSize
			succ, exceedMaxSize = pb_helper.Send(msg)
			if exceedMaxSize then
				FlashTipMan.FlashTip(StringTable.Get(91008))
			end
		end
		if succ then
			self.m_last_BuyOperation = curTime
			self.m_bOptLock = true

			if self:IsStandalone() then
				GameUtil.AddGlobalTimer(0, true, function()
					local s2cMsg = {}
					s2cMsg.retcode = 0
					s2cMsg.op = msg.op
					s2cMsg.buy_and_put = msg.buy_and_put
					self:on_hometown_op(s2cMsg)
				end)
			end
		end
		return succ
	end
	return false
end

---@param self ECHomeManager
---@param put pb.Message.PB.home_put_t
---@param buy_count number
---@return void
def.method("table", "number").S2C_BuyAndPut = function(self, put, buy_count)
	_warn(("S2C_BuyAndPut++++++++ undo[%d] rel_compress[%d] len[%d] srclen[%d]"):format(
			put.undo and 1 or 0, put.relation_compress and 1 or 0, put.relation:len(), put.relation_sourcelen or 0))

	local rel_decompressed = put.relation
	if put.relation_compress then
		local decompressed = ECHomeData.DecompressData(put.relation, put.relation_sourcelen)
		if not decompressed then
			MsgBox.ShowMsgBox(nil, StringTable.Get(91090), nil, MsgBoxType.MBBT_OK)
			return
		end
		rel_decompressed = decompressed
	end

	ECHomeData.Instance():UnserializeRelationData(rel_decompressed)

	-- 更新节点的数据
	local node = ECHomeData.Instance():GetNodeByPutIndex(put.put_index)
	node.tid = put.tid
	node.count = put.count
	node:Unserialize(put.data)

	if node.is_temp then
		node.is_temp = false

		ECHomeData.Instance():UpdateNode(node, false)
	else
		local event = HomeEvents.HomeNodeAddEvent.new(node)
		ECGame.EventManager:raiseEvent(nil, event)
	end

	if not put.undo then
		local operationData = {}
		operationData.obj_type = put.tid
		operationData.put_index = put.put_index
		operationData.count = put.count
		operationData.data = node:GetDataTable()
		operationData.parent_put_index = node.Parent.put_index
		operationData.element_type = node.type
		if put.put_param and put.put_param ~= ZeroUInt64 then
			operationData.put_param = put.put_param
		end

		local ECHomeUndoMan = require "Home.Undo.ECHomeUndoMan"
		ECHomeUndoMan.Instance():RecordOperation(CONSTANT_DEFINE.HOME_OP_TYPE.HOME_OP_OBJ_PUT, operationData)
	end

	ECHomeData.Instance():RemoveTempUsedID(put.tid, put.put_index, node:GetDataTable())
	ECHomeData.Instance():AddItemCount(put.tid, buy_count)

	local ECPanelMainHomeEdit = require "GUI.Home.ECPanelMainHomeEdit"
	if ECPanelMainHomeEdit.Instance():IsValid() then
		ECPanelMainHomeEdit.Instance():OnUpdateUI()
	end

	if node.type == _G.ECHOME_ELEMENT_TYPE_ENUM.LINK then
		ECShowLogicMan.Instance():ForceUpdateShowLogic(ECShowLogicMan.FORCE_UPDATE_MASK.ROOF_AND_WALL)

		local linkInfo = ECHomeSpaceUtil.Instance():AddOrUpdateLinkPosData(put.put_index)
		if linkInfo and not put.undo then
			ECHomeSpaceUtil.Instance():CheckDetect({[1] = linkInfo})
		end

		ECHomeView.Instance():UpdateLinkCorner(put.put_index)
	elseif node.type == _G.ECHOME_ELEMENT_TYPE_ENUM.ITEM then
		ECHomeSpaceUtil.Instance():AddOrUpdateItemGridData(put.put_index)
	end

	if self.m_bInDesignMode then
		self:SaveDesignData()
	end
end

---@param self ECHomeManager
---@param sync pb.Message.PB.home_sync
---@return void
def.method("table").S2C_ItemSync = function(self, sync)
	--print("S2C_ItemSync", sync)

	for tid, obj in pairs(sync.sync_map) do
		ECHomeData.Instance():OnSyncItemInfo(tid, obj)
	end

	ECGame.EventManager:raiseEvent(nil, HomeEvents.HomeItemChangeEvent())
end

--更新自身数据 例如位移朝向贴图等
---@param self ECHomeManager
---@param obj_type number
---@param put_index number
---@param data string
---@param count number
---@param relation string
---@param relation_compress boolean
---@param relation_origin string
---@param bUndo boolean
---@return boolean
def.method("number", "number", "string", "number", "string", "boolean", "string", "boolean", "=>", "boolean").C2S_Update = function (self, obj_type, put_index, data, count, relation, relation_compress, relation_origin, bUndo)
	_warn(("C2S_Update+++++++ bUndo[%d] obj_type[%d] put_index[%d] count[%d] compress[%d] rel_len[%d] srclen[%d]"):format(
			bUndo and 1 or 0, obj_type, put_index, count, relation_compress and 1 or 0, relation:len(), relation_origin:len()))

	if self.m_bOptLock then return false end

	if relation_origin and relation_origin~="" and not self:CheckRelationIsOK(relation_origin, {}, not bUndo) then
		return false
	end

	local relation_sourcelen = relation_origin and relation_origin:len() or 0
	if relation_compress and relation_sourcelen < 1 then
		warn("relation_compress but relation_sourcelen < 1!", relation_sourcelen, debug.tracebackex())
		FlashTipMan.FlashTip(StringTable.Get(91032))
		return false
	end

	---@type pb.Message.PB.gp_home_op_req
	local msg = client_msg.gp_home_op_req()
	msg.op = CONSTANT_DEFINE.HOME_OP_TYPE.HOME_OP_UPDATE_OBJ_DATA
	msg.transfer_type = self:GetHomeType()
	msg.update_obj.undo = bUndo
	msg.update_obj.obj_type	= obj_type
	msg.update_obj.put_index = put_index
	msg.update_obj.data = data
	msg.update_obj.count = count
	msg.update_obj.relation	= relation
	msg.update_obj.relation_compress = relation_compress
	msg.update_obj.relation_sourcelen = relation_sourcelen

	local succ = true
	if not self:IsStandalone() then
		local exceedMaxSize
		succ, exceedMaxSize = pb_helper.Send(msg)
		if exceedMaxSize then
			FlashTipMan.FlashTip(StringTable.Get(91008))
		end
	end
	if succ then
		self.m_WaitingUpdatePutIndex = put_index
		self.m_bOptLock = true

		if self:IsStandalone() then
			GameUtil.AddGlobalTimer(0, true, function()
				local s2cMsg = {}
				s2cMsg.retcode = 0
				s2cMsg.op = msg.op
				s2cMsg.oper_data = { update_obj = msg.update_obj }
				self:on_hometown_op(s2cMsg)
			end)
		end
	end
	return succ
end

---@param self ECHomeManager
---@param update_obj_data pb.Message.PB.home_update_obj_data_t
---@return void
def.method("table").S2C_Update = function (self, update_obj_data)
	_warn(("S2C_Update+++++++ undo[%d] put_index[%d]"):format(
			update_obj_data.undo and 1 or 0, update_obj_data.put_index))
	local node = ECHomeData.Instance():GetNodeByPutIndex(update_obj_data.put_index)
	if self.m_WaitingUpdatePutIndex == update_obj_data.put_index then
		self.m_WaitingUpdatePutIndex = 0
	end
	if node then
		if not update_obj_data.undo then
			local operationData = {}
			operationData.obj_type = update_obj_data.obj_type
			operationData.put_index = update_obj_data.put_index
			operationData.count = node.count
			operationData.data = node:Serialize()
			operationData.relation = update_obj_data.relation
			operationData.newCount = update_obj_data.count
			operationData.newData = update_obj_data.data

			local succ, relation, bCompress, relation_origin = self:SerializeRelationData(false)
			operationData.old_relation = relation

			ECHomeUndoMan.Instance():RecordOperation(CONSTANT_DEFINE.HOME_OP_TYPE.HOME_OP_UPDATE_OBJ_DATA, operationData)
		end

		local oldData = node:GetDataTable()
		node:Unserialize(update_obj_data.data)
		local newData = node:GetDataTable()

		if update_obj_data.count >= 0 then
			node.count = update_obj_data.count
		end

		ECHomeData.Instance():UpdateNode(node, false)

		if node.type == _G.ECHOME_ELEMENT_TYPE_ENUM.LINK then
			local bDetect = ECHomeData.Instance():CheckLinkChangeNeedDetect(oldData, newData)
			local linkInfo = ECHomeSpaceUtil.Instance():AddOrUpdateLinkPosData(update_obj_data.put_index)
			if bDetect and linkInfo and not update_obj_data.undo then
				ECHomeSpaceUtil.Instance():CheckDetect({[1] = linkInfo})
			end
			ECHomeView.Instance():UpdateLinkCorner(update_obj_data.put_index)

			ECShowLogicMan.Instance():ForceUpdateShowLogic(ECShowLogicMan.FORCE_UPDATE_MASK.ROOF_AND_WALL)
		elseif node.type == _G.ECHOME_ELEMENT_TYPE_ENUM.ITEM then
			ECHomeSpaceUtil.Instance():AddOrUpdateItemGridData(update_obj_data.put_index)
		end

		local floor_index = ECHomeData.Instance():GetFloorIndexOfNode(update_obj_data.put_index)
		local bNeedCheckPlayerPos = false
		--local newData = node:GetDataTable()

		--操作地下室的房间和一楼泳池以及一楼下陷家具时需要检查玩家位置
		if node.type == _G.ECHOME_ELEMENT_TYPE_ENUM.LINK and newData and newData.walls and #newData.walls > 1
				and floor_index == _G.BASEMENT_FLOOR_INDEX + 1 then
			bNeedCheckPlayerPos = true
		elseif node.type == _G.ECHOME_ELEMENT_TYPE_ENUM.ITEM and floor_index == 1 then
			local config = ElementData.getConfig(node.tid)
			if config then
				if config.hole_length and config.hole_length > 0 and config.hole_width and config.hole_width > 0 then
					bNeedCheckPlayerPos = true
				end
			end
		elseif node.type == _G.ECHOME_ELEMENT_TYPE_ENUM.POOL and floor_index == 1 then
			bNeedCheckPlayerPos = true
		elseif node.type == _G.ECHOME_ELEMENT_TYPE_ENUM.STAIR and floor_index == _G.BASEMENT_FLOOR_INDEX + 1 then
			bNeedCheckPlayerPos = true
		end

		if bNeedCheckPlayerPos then
			self:CheckPlayerPos(true)
		end
	end
	--warn("S2C_Update+++++++",update_obj_data,home_item,unmarshal_data,update_obj_data.count)

	local ECPanelMainHomeEdit = require "GUI.Home.ECPanelMainHomeEdit"
	if ECPanelMainHomeEdit.Instance():IsVisible() then
		ECPanelMainHomeEdit.Instance():OnUpdateUI()
	end

	if self.m_bInDesignMode then
		self:SaveDesignData()
	end
end

---@param self ECHomeManager
---@param home_owner string
---@param misc_data table
---@return void
def.method("string", "table").S2C_HomeMiscData = function(self, home_owner, misc_data)
	if home_owner == globalGame:GetHostPlayerID() then
		ECHomeProduce.Instance():OnHomeMiscData(misc_data)
	end
end

---@param self ECHomeManager
---@param home_owner string
---@param info pb.Message.PB.home_info_t
---@param unlock boolean
---@return void
def.method("string", "table", "boolean").S2C_HomeInfo = function(self, home_owner, info, unlock)
	--_warn("S2C_HomeInfo", LuaUInt64.ToString(home_owner), LuaUInt64.ToString(globalGame:GetHostPlayerID()), info)
	if home_owner == globalGame:GetHostPlayerID() then
		self:SetUnlocked(unlock)
		self.m_bUnlockIndoor = info.unlock_indoor
		self.m_bUnlockOutdoor = info.unlock_outdoor

		local old_daily_rwd_state = self.m_HostHomeInfo.daily_rwd_state

		self.m_HostHomeInfo.cur_level = info.cur_level
        -- 废弃
		--self.m_HostHomeInfo.is_daily_reward_done = info.is_daily_reward_done
		self.m_HostHomeInfo.is_upgrading = info.is_upgrading
		self.m_HostHomeInfo.upgrade_end_ts = info.upgrade_end_ts

		self.m_HostHomeInfo.repus = {}
		for tid, repu in pairs(info.repu.repus) do
			self.m_HostHomeInfo.repus[tid] = LuaUInt64.ToDouble(repu.value)
		end

		self.m_HostHomeInfo.order_smelt_total = info.owner_extra.order_smelt_total
		self.m_HostHomeInfo.order_smelt_finish = info.owner_extra.order_smelt_finish
		self.m_HostHomeInfo.order_station_total = info.owner_extra.order_station_total
		self.m_HostHomeInfo.order_station_finish = info.owner_extra.order_station_finish
		self.m_HostHomeInfo.daily_rwd_state = info.owner_extra.daily_rwd_state
		self.m_HostHomeInfo.street_daily_rwd_state = info.owner_extra.street_daily_rwd_state
		self.m_HostHomeInfo.money_cur = info.owner_extra.money_cur
		self.m_HostHomeInfo.food_cur = info.owner_extra.food_cur
		self.m_HostHomeInfo.researching_info = info.owner_extra.researching_info

		ECHomeData.Instance():SyncItemCountFromInfo(info.owner_extra.obj_total_cnt_map)

		local DAILY_RWD_STATE = db_msg.db_ref_home.DAILY_RWD_STATE
		if old_daily_rwd_state == DAILY_RWD_STATE.DRS_UNCLAIMED and self.m_HostHomeInfo.daily_rwd_state == DAILY_RWD_STATE.DRS_CLAIMED then
			self:S2C_GetDailyReward()
		end

		ECHomeHouseKeeper.Instance():SetHouseKeeper(info.butler_tid)

		ECGame.EventManager:raiseEvent(nil, HomeEvents.HomeInfoEvent.new(home_owner))
	else
		local otherInfo = self.m_HomeInfoMap:Get(home_owner)
		if not otherInfo then
			otherInfo = {}
			self.m_HomeInfoMap:Set(home_owner, otherInfo)
		end
		otherInfo.cur_level = info.cur_level
		otherInfo.is_upgrading = info.is_upgrading
		otherInfo.upgrade_end_ts = info.upgrade_end_ts
		otherInfo.unlock = unlock
		otherInfo.unlock_indoor = info.unlock_indoor
		otherInfo.unlock_outdoor = info.unlock_outdoor
		otherInfo.house_keeper = info.butler_tid

		otherInfo.repus = {}
		for tid, repu in pairs(info.repu.repus) do
			otherInfo.repus[tid] = LuaUInt64.ToDouble(repu.value)
		end
		otherInfo.last_update = GameUtil.GetServerGMTTime()

		if home_owner == self.m_OwnerRoleID then
			ECGame.EventManager:raiseEvent(nil, HomeEvents.HomeInfoEvent.new(home_owner))
		end
	end

	-- 更新商人信息
	self:UpdateMerchantInfo(home_owner, info.merchant_tid, info.merchant_leave_ts)
	-- 更新解锁室内信息
	self:S2C_UnlockIndoorInfo(home_owner, info.owner_extra.unlock_indoor_info)
end

-- 获取炼金房订单信息（主角）
---@param self ECHomeManager
---@return number,number
def.method("=>", "number", "number").GetSmeltInfo = function(self)
	if not self:IsInMyHome() then
		if self.m_HostHomeInfo then
			return self.m_HostHomeInfo.order_smelt_finish or 0, self.m_HostHomeInfo.order_smelt_total or 0
		end
		return 0, 0
	else
		local doneCount, doingCount, _ = ECHomeProduce.Instance():GetSmeltOrderCount()
		return doneCount, doingCount + doneCount
	end
end

-- 获取驿站订单信息（主角）
---@param self ECHomeManager
---@return number,number
def.method("=>", "number", "number").GetStationInfo = function(self)
	if not self:IsInMyHome() then
		if self.m_HostHomeInfo then
			return self.m_HostHomeInfo.order_station_finish or 0, self.m_HostHomeInfo.order_station_total or 0
		end
		return 0, 0
	else
		local doneCount, doingCount, _ = ECHomeProduce.Instance():GetStationOrderCount()
		return doneCount, doingCount + doneCount
	end
end

---@param self ECHomeManager
---@param role_id string
---@return table
def.method("string", "=>", "table").GetHomeInfo = function(self, role_id)
	if role_id == globalGame:GetHostPlayerID() then
		return self.m_HostHomeInfo
	else
		return self.m_HomeInfoMap:Get(role_id)
	end
end

---@param self ECHomeManager
---@param role_id string
---@return table
def.method("string", "=>", "table").GetHomeScore = function(self, role_id)
	local scoreList, filter = {}, {}
	local homeInfo = self:GetHomeInfo(role_id)
	if homeInfo ~= nil then
		for repu_id, repu_value in pairs(homeInfo.repus) do
			table.insert(scoreList, { tid = repu_id, name = _G.AZUREHOME_Properties[repu_id], value = repu_value })
			filter[repu_id] = true
		end
	end
	for k, v in pairs(_G.AZUREHOME_Properties) do
		if not filter[k] then
			table.insert(scoreList, { tid = k, name = v, value = 0 })
		end
	end
	table.sort(scoreList, function(left, right)
		return left.tid < right.tid
	end)
	return scoreList
end

---@param self ECHomeManager
---@return table
def.method("=>", "table").GetHostHomeScore = function(self)
	local hp = ECGame.Instance():GetHostPlayer()
	if not hp then return nil end
	local scoreList = {}
	for k, v in pairs(_G.AZUREHOME_Properties) do
		table.insert(scoreList, { tid = k, name = v, value = hp:GetReputation(k) })
	end
	table.sort(scoreList, function(left, right)
		return left.tid < right.tid
	end)
	return scoreList
end

---@param self ECHomeManager
---@return number
def.method("=>", "number").GetHostHomeLevel = function(self)
    if self:IsStandalone() then
        local scene_id = globalGame:GetCurrentSceneID()
        return ECHomeConfig.GetHomeLevelBySceneID(scene_id)
    end

	return self.m_HostHomeInfo and self.m_HostHomeInfo.cur_level or 0
end

-- 获取主角当前的家园副本ID
---@param self ECHomeManager
---@param indoor boolean
---@return number
def.method("boolean", "=>", "number").GetCurHomeInstanceID = function(self, indoor)
	local homeConfig = ECHomeConfig.GetHomeConfig()
	if indoor then
		local curLevel = self:GetHostHomeLevel()
		if curLevel <= 0 or curLevel > CONSTANT_DEFINE.MISC_TYPE.EXP_HOME_MAX_LEVEL then
			return 0
		end
		return homeConfig.level_param[curLevel].inst_tid
	else
		return homeConfig.inst_tid
	end
end

-- 获取当前家园的场景ID
---@param self ECHomeManager
---@param indoor boolean
---@return number
def.method("boolean", "=>", "number").GetCurHomeSceneID = function(self, indoor)
	local homeConfig = ECHomeConfig.GetHomeConfig()
	local inst_tid = 0
	if indoor then
		local curLevel = self:GetHostHomeLevel()
		if curLevel <= 0 or curLevel > CONSTANT_DEFINE.MISC_TYPE.EXP_HOME_MAX_LEVEL then
			return 0
		end
		inst_tid = homeConfig.level_param[curLevel].inst_tid
	else
		inst_tid = homeConfig.inst_tid
	end
	---@type pb.Message.PB.InstanceConfig
	local instCfg = ElementData.getDataByConfigType(CONSTANT_DEFINE.CONFIG_TYPE.CONFIG_INSTANCE, inst_tid)
	if instCfg then
		return instCfg.id_scene
	end
	return 0
end

---@param self ECHomeManager
---@return number
def.method("=>", "number").GetHostHomeKeeper = function(self)
	return ECHomeHouseKeeper.Instance():GetHouseKeeper()
end

---@param self ECHomeManager
---@return boolean
def.method("=>", "boolean").IsDailyRewardReceived = function(self)
	local DAILY_RWD_STATE = db_msg.db_ref_home.DAILY_RWD_STATE
	if self.m_HostHomeInfo then
		return self.m_HostHomeInfo.daily_rwd_state == DAILY_RWD_STATE.DRS_CLAIMED
	end
	return false

	-- 废弃
	--return self.m_HostHomeInfo and self.m_HostHomeInfo.is_daily_reward_done or false
end

---@param self ECHomeManager
---@return boolean
def.method("=>", "boolean").IsUpgrading = function(self)
	if self.m_OwnerRoleID == ZeroUInt64 or self.m_OwnerRoleID == globalGame:GetHostPlayerID() then
		return self.m_HostHomeInfo and self.m_HostHomeInfo.is_upgrading or false
	else
		local homeInfo = self:GetHomeInfo(self.m_OwnerRoleID)
		return homeInfo and homeInfo.is_upgrading or false
	end
end

---@param self ECHomeManager
---@return number
def.method("=>", "number").GetUpgradeSeconds = function(self)
	local seconds = 0
	if self.m_OwnerRoleID == ZeroUInt64 or self.m_OwnerRoleID == globalGame:GetHostPlayerID() then
		if self.m_HostHomeInfo ~= nil and self.m_HostHomeInfo.is_upgrading and self.m_HostHomeInfo.upgrade_end_ts ~= nil then
			seconds = self.m_HostHomeInfo.upgrade_end_ts - GameUtil.GetServerGMTTime()
		end
	else
		local homeInfo = self:GetHomeInfo(self.m_OwnerRoleID)
		if homeInfo ~= nil and homeInfo.is_upgrading and homeInfo.upgrade_end_ts ~= nil then
			seconds = homeInfo.upgrade_end_ts - GameUtil.GetServerGMTTime()
		end
	end
	if seconds < 0 then
		seconds = 0
	end
	return seconds
end

---@param self ECHomeManager
---@return boolean
def.method("=>", "boolean").CanLevelUp = function(self)
	local ECGeneralCostUtility = require "Utility.ECGeneralCostUtility"
	local scoreList = self:GetHostHomeScore()
	if not scoreList then return false end
	local decorative_value = scoreList[1].value
	local practical_value = scoreList[2].value
	---@type pb.Message.PB.HomeConfig
	local cfg = ElementData.getConfig(homeCfg.homeConfigTid)
	local cur_home_level = self:GetHostHomeLevel()
	if cur_home_level <= 0 or cur_home_level >= CONSTANT_DEFINE.MISC_TYPE.EXP_HOME_MAX_LEVEL then
		return false
	end
	if cfg.level_param[cur_home_level] then
		local cur_money = ECHomeManager.Instance():GetHostHomeMoney()
		return cur_money >= cfg.level_param[cur_home_level].up_cost_money and
				decorative_value >= cfg.level_param[cur_home_level].up_min_decorative_value and
				practical_value >= cfg.level_param[cur_home_level].up_min_practical_value and
				ECGeneralCostUtility.CanUse(cfg.level_param[cur_home_level].up_cost_id)
	else
		return false
	end
end

---@param self ECHomeManager
---@return boolean
def.method("=>", "boolean").CanGetDailyReward = function(self)
	local curLevel = self:GetHostHomeLevel()
	if curLevel <= 0 or curLevel > CONSTANT_DEFINE.MISC_TYPE.EXP_HOME_MAX_LEVEL then
		return false
	end
	if self:IsDailyRewardReceived() then
		return false
	end
    -- 废弃
    --[[
	local ECTaskInterface = require "Task.ECTaskInterface"
	---@type pb.Message.PB.HomeConfig
	local cfg = ElementData.getConfig(homeCfg.homeConfigTid)
	for i=1, CONSTANT_DEFINE.MISC_TYPE.EXP_HOME_MAX_LEVEL do
		if cfg.level_param[i].reward_task_id ~= 0 and ECTaskInterface.TaskHasFinished(cfg.level_param[i].reward_task_id) then
			return true
		end
	end]]
	local DAILY_RWD_STATE = db_msg.db_ref_home.DAILY_RWD_STATE
	if self.m_HostHomeInfo then
		return self.m_HostHomeInfo.daily_rwd_state == DAILY_RWD_STATE.DRS_UNCLAIMED
	end
	return false
end

---@param self ECHomeManager
---@return number
def.method("=>", "number").GetHostHomeMoney = function(self)
	local money = 0
	if self:IsInMyHome() then
		money = ECHomeProduce.Instance():GetMoney()
	elseif self.m_HostHomeInfo ~= nil and type(self.m_HostHomeInfo.money_cur) == "number" then
		money = self.m_HostHomeInfo.money_cur
	end
	return money
end

---@param self ECHomeManager
---@return boolean
def.method("=>", "boolean").IsAnyTechCanResearch = function(self)
	local homeTechList = ECHomeConfig.GetTechniqueList()
	local min_level = CONSTANT_DEFINE.MISC_TYPE.EXP_HOME_MAX_LEVEL
	for level, list in pairs(homeTechList) do
		if #list > 0 and level < min_level then
			min_level = level
		end
	end
	return self:GetHostHomeLevel() >= min_level
end

---@param self ECHomeManager
---@return table,string
def.method("=>", "table", "string").GetResearchingInfo = function(self)
	local researching_info = self.m_HostHomeInfo.researching_info
	if researching_info == nil or researching_info.tech_tid < 1 then
		return nil, ""
	end
	local remainTime
	if researching_info.end_ts > 0 then
		remainTime = researching_info.end_ts - GameUtil.GetServerGMTTime()
		if remainTime < 0 then
			remainTime = 0
		end
		local hours = math.floor(remainTime / 3600)
		local mins = math.floor(remainTime % 3600 / 60)
		local secs = math.floor(remainTime % 60)
		remainTime = ("%02d:%02d:%02d"):format(hours, mins, secs)
	else
		remainTime = StringTable.Get(91050)
	end
	return researching_info, remainTime
end

--删除
---@param self ECHomeManager
---@param obj_type number
---@param put_index number
---@param bUndo boolean
---@return boolean
def.method("number","number","boolean", "=>","boolean").C2S_Cancel = function (self, obj_type, put_index, bUndo)
	_warn(("C2S_Cancel+++++++ bUndo[%d] obj_type[%d] put_index[%d]"):format(bUndo and 1 or 0, obj_type, put_index))

	if not self:OperationCheck(false) then
		return false
	end

	---@type pb.Message.PB.gp_home_op_req
	local msg = client_msg.gp_home_op_req()
	msg.op = CONSTANT_DEFINE.HOME_OP_TYPE.HOME_OP_OBJ_CANCEL
	msg.transfer_type = self:GetHomeType()
	msg.cancel.undo = bUndo
	msg.cancel.tid	= obj_type	--模板id
	msg.cancel.put_index = put_index	--客户端分配的摆放索引

	local node = ECHomeData.Instance():GetNodeByPutIndex(put_index)
	if node then
		node.enable_marshal = false
		local succ, relation, bCompressed, relation_origin = self:SerializeRelationData_LargeLimit(true)
		node.enable_marshal = true

		if not succ then return false end

		local exclude_tab = {}
		exclude_tab[node.put_index] = 1
		if not self:CheckRelationIsOK(relation_origin, exclude_tab, false) then
			return false
		end

		msg.cancel.relation = relation
		msg.cancel.relation_compress = bCompressed
		msg.cancel.relation_sourcelen = relation_origin:len()

		local succ = true
		if not self:IsStandalone() then
			local exceedMaxSize
			succ, exceedMaxSize = pb_helper.Send(msg)
			if exceedMaxSize then
				FlashTipMan.FlashTip(StringTable.Get(91008))
			end
		end
		if succ then
			self.m_bOptLock = true
			if self:IsStandalone() then
				GameUtil.AddGlobalTimer(0, true, function()
					local s2cMsg = {}
					s2cMsg.retcode = 0
					s2cMsg.op = msg.op
					s2cMsg.oper_data = { cancel = msg.cancel }
					self:on_hometown_op(s2cMsg)
				end)
			end
		end
		return succ
	else
		warn("Err C2S_Cancel cannot find the node!", put_index)
		return false
	end
end

---@param self ECHomeManager
---@param cancel pb.Message.PB.home_cancel_t
---@return void
def.method("table").S2C_Cancel = function (self, cancel)
	_warn(("S2C_Cancel+++++++ undo[%d] obj_type[%d] put_index[%d]"):format(
			cancel.undo and 1 or 0, cancel.tid, cancel.put_index))

	local node = ECHomeData.Instance():GetNodeByPutIndex(cancel.put_index)
	if node and node.type==_G.ECHOME_ELEMENT_TYPE_ENUM.LINK then
		ECHomeSpaceUtil.Instance():DeleteLinkPosData(cancel.put_index)
	elseif node and node.type == _G.ECHOME_ELEMENT_TYPE_ENUM.ITEM then
		ECHomeSpaceUtil.Instance():DeleteItemGridData(cancel.put_index)
	end

	if not cancel.undo then
		local operationData = {}
		operationData.obj_type = cancel.tid
		operationData.put_index = cancel.put_index
		operationData.count = node.count
		operationData.data = node:GetDataTable()
		operationData.parent_put_index = node.Parent.put_index
		operationData.element_type = node.type

		local ECHomeUndoMan = require "Home.Undo.ECHomeUndoMan"
		ECHomeUndoMan.Instance():RecordOperation(CONSTANT_DEFINE.HOME_OP_TYPE.HOME_OP_OBJ_CANCEL, operationData)
	end

	local bNeedCheckPlayerPos = false
	if node then
		local floor_index = ECHomeData.Instance():GetFloorIndexOfNode(cancel.put_index)

		--操作地下室的房间和一楼泳池以及一楼下陷家具时需要检查玩家位置
		if node.type == _G.ECHOME_ELEMENT_TYPE_ENUM.LINK and node:HasWalls() and floor_index == _G.BASEMENT_FLOOR_INDEX then
			bNeedCheckPlayerPos = true
		elseif node.type == _G.ECHOME_ELEMENT_TYPE_ENUM.ITEM and floor_index == 1 then
			local config = ElementData.getConfig(node.tid)
			if config and config.hole_length and config.hole_length > 0
					and config.hole_width and config.hole_width > 0 then
				bNeedCheckPlayerPos = true
			end
		elseif node.type == _G.ECHOME_ELEMENT_TYPE_ENUM.POOL and floor_index == 1 then
			bNeedCheckPlayerPos = true
		elseif node.type == _G.ECHOME_ELEMENT_TYPE_ENUM.STAIR and floor_index == _G.BASEMENT_FLOOR_INDEX then
			bNeedCheckPlayerPos = true
		end

		ECHomeData.Instance():RemoveNodeByPutIndex(cancel.put_index, true)

		local curFloorIndex = ECHomeData.Instance():GetCurrentFloorIndex()
		if node.type == _G.ECHOME_ELEMENT_TYPE_ENUM.LINK and curFloorIndex > 1 and floor_index == curFloorIndex - 1 and node:HasWalls() then
			local ECHomeGrid = require "Home.Util.ECHomeGrid"
			ECHomeGrid.Instance():Update()
		end
	else
		warn("Err S2C_Cancel node is nil!")
	end

	local ECPanelMainHomeEdit = require "GUI.Home.ECPanelMainHomeEdit"
	if ECPanelMainHomeEdit.Instance():IsValid() then
		ECPanelMainHomeEdit.Instance():OnUpdateUI()
	end

	if bNeedCheckPlayerPos then
		self:CheckPlayerPos(true)
	end

	if self.m_bInDesignMode then
		self:SaveDesignData()
	end
end

--摆放
---@param self ECHomeManager
---@param obj_type number
---@param put_index number
---@param count number
---@param data table
---@param put_param any
---@param bUndo boolean
---@param undo_param table
---@return boolean
def.method("number", "number", "number", "table", "dynamic", "boolean", "table", "=>", "boolean").C2S_Put = function (self, obj_type, put_index, count, data, put_param, bUndo, undo_param)
	_warn(("C2S_Put+++++++ bUndo[%d] obj_type[%d] put_index[%d] count[%d]"):format(
			bUndo and 1 or 0, obj_type, put_index, count))

	if not self:OperationCheck(true) then
		return false
	end

	local node = ECHomeData.Instance():GetNodeByPutIndex(put_index)
	if not node then
		if not bUndo then
			warn("err C2S_Put, node is nil", obj_type, put_index, node)
			return false
		else
			-- 临时创建数据节点用来构建relation数据
			node = ECHomeNode.CreateByTid(obj_type)
			node.put_index = put_index
			node.tid = obj_type
			node.count = count
			node.type = undo_param.element_type
			node:CopyData(data)

			local parentNode = ECHomeData.Instance():GetNodeByPutIndex(undo_param.parent_put_index)
			parentNode:AddChildNode(node)
		end
	end

	local succ, relation, bCompressed, relation_origin = self:SerializeRelationData(true)
	if not succ or not self:CheckRelationIsOK(relation_origin,{}, not bUndo) then
		return false
	end

	if bUndo then
		local parentNode = ECHomeData.Instance():GetNodeByPutIndex(undo_param.parent_put_index)
		parentNode:RemoveChildByPutIndex(put_index)
	end

	---@type pb.Message.PB.gp_home_op_req
	local msg = client_msg.gp_home_op_req()
	msg.op = CONSTANT_DEFINE.HOME_OP_TYPE.HOME_OP_OBJ_PUT
	msg.transfer_type = self:GetHomeType()
	msg.put.undo = bUndo
	msg.put.tid	= obj_type	--模板id
	msg.put.put_index = put_index	--摆放索引
	msg.put.count = count		--数量

	if put_param and put_param ~= ZeroUInt64 then
		msg.put.put_param = put_param
	end

	-- print(">>>>>>>>>>>>>>>>>>C2S_Put data.data.parent_put_index = ",data.parent_put_index)
	msg.put.data = node:Serialize()
	--warn("C2S_Put+++++++",obj_type,put_index,count,data,"+",msg.put.data,"+")
	if msg.put.count > 0 and msg.put.data then
		msg.put.relation = relation
		msg.put.relation_compress = bCompressed
		msg.put.relation_sourcelen = relation_origin:len()
		ECHomeData.Instance():SetTempUsedID(msg.put.tid, msg.put.put_index, data)

		local succ = true
		if not self:IsStandalone() then
			local exceedMaxSize
			succ, exceedMaxSize = pb_helper.Send(msg)
			if exceedMaxSize then
				FlashTipMan.FlashTip(StringTable.Get(91008))
			end
		end
		if succ then
			self.m_bOptLock = true
			if self:IsStandalone() then
				GameUtil.AddGlobalTimer(0, true, function()
					local s2cMsg = {}
					s2cMsg.retcode = 0
					s2cMsg.op = msg.op
					s2cMsg.oper_data = { put = msg.put }
					self:on_hometown_op(s2cMsg)
				end)
			end
		end
		return succ
	end
	return false
end

---@param self ECHomeManager
---@param put pb.Message.PB.home_put_t
---@return void
def.method("table").S2C_Put = function (self, put)
	--optional int32 obj_type  = 1;
	--optional int32 count     = 2;
	--optional bytes data      = 3;
	--optional int32 put_index = 4;
	_warn(("S2C_Put++++++++ undo[%d] put_index[%d] obj_type[%d] compress[%d] len[%d] srclen[%d]"):format(
			put.undo and 1 or 0, put.put_index, put.tid, put.relation_compress and 1 or 0, put.relation:len(), put.relation_sourcelen or 0))

	local rel_decompressed = put.relation
	if put.relation_compress then
		local decompressed = ECHomeData.DecompressData(put.relation, put.relation_sourcelen)
		if not decompressed then
			MsgBox.ShowMsgBox(nil, StringTable.Get(91090), nil, MsgBoxType.MBBT_OK)
			return
		end
		rel_decompressed = decompressed
	end

	ECHomeData.Instance():UnserializeRelationData(rel_decompressed)

	-- 更新节点的数据
	local node = ECHomeData.Instance():GetNodeByPutIndex(put.put_index)
	node.tid = put.tid
	node.count = put.count
	node:Unserialize(put.data)

	if node.is_temp then
		node.is_temp = false

		ECHomeData.Instance():UpdateNode(node, false)
	else
		local event = HomeEvents.HomeNodeAddEvent.new(node)
		ECGame.EventManager:raiseEvent(nil, event)
	end

	if not put.undo then
		local operationData = {}
		operationData.obj_type = put.tid
		operationData.put_index = put.put_index
		operationData.count = put.count
		operationData.data = node:GetDataTable()
		operationData.parent_put_index = node.Parent.put_index
		operationData.element_type = node.type
		if put.put_param and put.put_param ~= ZeroUInt64 then
			operationData.put_param = put.put_param
		end

		local ECHomeUndoMan = require "Home.Undo.ECHomeUndoMan"
		ECHomeUndoMan.Instance():RecordOperation(CONSTANT_DEFINE.HOME_OP_TYPE.HOME_OP_OBJ_PUT, operationData)
	end

	ECHomeData.Instance():RemoveTempUsedID(put.tid, put.put_index, node:GetDataTable())

	local ECPanelMainHomeEdit = require "GUI.Home.ECPanelMainHomeEdit"
	if ECPanelMainHomeEdit.Instance():IsValid() then
		ECPanelMainHomeEdit.Instance():OnUpdateUI()
	end

	if node and node.type==_G.ECHOME_ELEMENT_TYPE_ENUM.LINK then
		ECShowLogicMan.Instance():ForceUpdateShowLogic(ECShowLogicMan.FORCE_UPDATE_MASK.ROOF_AND_WALL)

		local linkInfo = ECHomeSpaceUtil.Instance():AddOrUpdateLinkPosData(put.put_index)
		if linkInfo and not put.undo then
			ECHomeSpaceUtil.Instance():CheckDetect({[1] = linkInfo})
		end

		ECHomeView.Instance():UpdateLinkCorner(put.put_index)
	elseif node and node.type == _G.ECHOME_ELEMENT_TYPE_ENUM.ITEM then
		ECHomeSpaceUtil.Instance():AddOrUpdateItemGridData(put.put_index)
	end

	if self.m_bInDesignMode then
		self:SaveDesignData()
	end

	local homeLevel = self:GetHostHomeLevel()
	---@type pb.Message.PB.HomeFurnitureConfig
	local furnitureCfg = ElementData.getDataByConfigType(CONSTANT_DEFINE.CONFIG_TYPE.CONFIG_HOME_FURNITURE, put.tid)
	if furnitureCfg then
		local maxCount = furnitureCfg.level_param[homeLevel] and furnitureCfg.level_param[homeLevel].prop_valid_count or 0
		local data = ECHomeData.Instance():GetHomeDataByTid(put.tid)
		--print(data.put_count, maxCount)
		if data.put_count > maxCount then
			FlashTipMan.FlashTip(StringTable.Get(91020))
		end
	end
end

---@param self ECHomeManager
---@param put_index number
---@return void
def.method("number").DeleteFurniture = function (self, put_index)
	local ECBuildToolFurniture = require "Home.BuildTool.ECBuildToolFurniture"
	local deletePutIndex = put_index
	local can_delete,reason_list = ECBuildToolFurniture.Instance():CheckCanDelete(deletePutIndex)
	if can_delete then
		self:DeleteFurnitureInner(deletePutIndex)
	elseif reason_list then
		local DeleteMsg
		DeleteMsg = function()
			if #reason_list > 0 then
				local reason_info = reason_list[1]
				MsgBox.ShowMsgBox(nil, reason_info.msg_str or "" , nil, MsgBox.MsgBoxType.MBBT_OKCANCEL, function(sender, ret)
					if ret == MsgBoxRetT.MBRT_OK then
						table.remove(reason_list,1)
						DeleteMsg()
					end
				end)
			else
				self:DeleteFurnitureInner(deletePutIndex)
			end
		end
		if #reason_list > 0 then
			DeleteMsg()
		end
	end
end

---@param self ECHomeManager
---@param put_index number
---@return void
def.method("number").DeleteFurnitureInner = function (self, put_index)
	local node = ECHomeData.Instance():GetNodeByPutIndex(put_index)
	if node then
		local multiCancel = {}

		local childPutIndexs = {}
		node:GetChildPutIndexes(childPutIndexs)

		local childCount = #childPutIndexs

		local cancelData = {}
		cancelData.obj_type = node.tid
		cancelData.put_index = node.put_index
		table.insert(multiCancel, cancelData)

		if childCount > 0 then
			for k, v in pairs(childPutIndexs) do
				local childNode = ECHomeData.Instance():GetNodeByPutIndex(v)
				if childNode then
					if childNode.tid and childNode.put_index then
						local childCancelData = {}
						childCancelData.obj_type = childNode.tid
						childCancelData.put_index = childNode.put_index
						table.insert(multiCancel, childCancelData)
					end
				end
			end
		end

		if #multiCancel > 0 then
			local multiBuy, multiSell, costMoney, costRepuList = self:GetNeedBuyAndSell({}, {}, multiCancel)
			if #multiSell > 0 then
				self:C2S_MultiOperation({}, multiSell, multiCancel, {}, {}, 0, nil, false)
			else
				self:C2S_MultiCancel(multiCancel,false)
			end
		end
	end
end

---@param self ECHomeManager
---@param put_index number
---@return boolean,table
def.method("number", "=>", "boolean", "table").CheckCanDelete = function (self, put_index)
	return true, nil
end

---@param self ECHomeManager
---@param deletePutIndex number
---@return boolean,table
def.method("number", "=>", "boolean", "table").CheckCanDelete_ForEachChild = function (self, deletePutIndex)
	if deletePutIndex > 0 then
		local node = ECHomeData.Instance():GetNodeByPutIndex(deletePutIndex)
		if node then
			if node.tid and node.put_index then
				local ret = true
				local reason_list = {}
				local can_delete,reason_info = self:CheckCanDelete(node.put_index)
				if not can_delete then
					ret = false
					table.insert(reason_list, reason_info)
				end

				local bHasPasswordDoor = false
				local bBabyPasswordDoor = false
				if node.type == _G.ECHOME_ELEMENT_TYPE_ENUM.HOLE_MODEL then
					--[[
					local owner,isBaby,babyName = self:GetPasswordDoorOwner(homedata.put_index)
					if owner and owner ~= ZeroUInt64 then
						bHasPasswordDoor = true
						bBabyPasswordDoor = isBaby
					end]]
				elseif node.type == _G.ECHOME_ELEMENT_TYPE_ENUM.LINK then
					local childElements = {}
					node:GetAllChildNodes(childElements)
					for _, childElement in pairs(childElements) do
						if childElement.type == _G.ECHOME_ELEMENT_TYPE_ENUM.HOLE_MODEL then
							--[[
							local owner,isBaby,babyNameowner = self:GetPasswordDoorOwner(childElement.put_index)
							if owner and owner ~= ZeroUInt64 then
								bHasPasswordDoor = true
								bBabyPasswordDoor = isBaby
								break
							end]]
						end
					end
				end

				if bHasPasswordDoor then
					ret = false
					table.insert(reason_list, {msg_str = homeCfg.tips[bBabyPasswordDoor and 134 or 117] or ""})
				end

				local childPutIndexs = {}
				node:GetChildPutIndexes(childPutIndexs)
				for i, put_index in ipairs(childPutIndexs) do
					local can_delete,reason_info = self:CheckCanDelete(put_index)
					if not can_delete then
						ret = false
						table.insert(reason_list,reason_info)
					end
				end
				return ret,reason_list
			end
		end
	end

	return true,nil
end

---@param self ECHomeManager
---@param tid number
---@param count number
---@return boolean
def.method("number", "number", "=>", "boolean").C2S_CancelHomeItem = function (self, tid, count)
	if not self:OperationCheck(true) then
		return false
	end

	---@type pb.Message.PB.gp_home_op_req
	local msg = client_msg.gp_home_op_req()
	msg.op = CONSTANT_DEFINE.HOME_OP_TYPE.HOME_OP_CANCEL_ITEM_SYNC
	msg.transfer_type = self:GetHomeType()
	msg.cancel_item.tid = tid
	msg.cancel_item.count = count
	local succ = pb_helper.Send(msg)
	if succ then
		self.m_bOptLock = true
	end

	return true
end

---@param self ECHomeManager
---@param home_owner string
---@param cb function
---@return boolean
def.method("string", "function", "=>", "boolean").C2S_QueryHomeInfo = function(self, home_owner, cb)
	if home_owner == globalGame:GetHostPlayerID() then
		if cb then
			cb()
		end
		return true
	end

	local localData = self.m_HomeInfoMap:Get(home_owner)
	if localData ~= nil and GameUtil.GetServerGMTTime() - localData.last_update <= _G.AZUREHOME_QueryOtherCoolDown then
		if cb then
			cb()
		end
		return true
	end

	local cb_list = self.m_QueryHomeInfoCB[home_owner]
	if cb_list then
		if cb then
			table.insert(cb_list, cb)
		end
		return true
	end

	self.m_QueryHomeInfoCB[home_owner] = {cb}

	---@type pb.Message.PB.gp_home_op_req
	local msg = client_msg.gp_home_op_req()
	msg.op = CONSTANT_DEFINE.HOME_OP_TYPE.HOME_OP_INFO
	msg.home_owner = home_owner
	local succ = pb_helper.Send(msg)
	return succ
end

---@param self ECHomeManager
---@param bUndo boolean
---@return boolean
def.method("boolean", "=>", "boolean").C2S_CancelAllItem = function(self, bUndo)
	--救赎措施，不应该检查
	--if not self:OperationCheck(false) then
	--	return false
	--end

	local succ, relation, bCompressed, relation_origin = self:SerializeRelationData_Empty(true, true)
	if not succ then
		return false
	end

	---@type pb.Message.PB.gp_home_op_req
	local msg = client_msg.gp_home_op_req()
	msg.op = CONSTANT_DEFINE.HOME_OP_TYPE.HOME_OP_OBJ_CANCEL_ALL
	msg.transfer_type = self:GetHomeType()
	msg.home_owner = self.m_OwnerRoleID
	msg.cancel_all.undo = bUndo
	msg.cancel_all.relation = relation
	msg.cancel_all.relation_compress = bCompressed
	msg.cancel_all.relation_sourcelen = relation:len()

	local succ = true
	if not self:IsStandalone() then
		local exceedMaxSize
		succ, exceedMaxSize = pb_helper.Send(msg)
		if exceedMaxSize then
			FlashTipMan.FlashTip(StringTable.Get(91008))
		end
	end
	if succ then
		self.m_bOptLock = true
		if self:IsStandalone() then
			GameUtil.AddGlobalTimer(0, true, function()
				local s2cMsg = {}
				s2cMsg.retcode = 0
				s2cMsg.op = msg.op
				s2cMsg.oper_data = { cancel_all = msg.cancel_all }
				self:on_hometown_op(s2cMsg)
			end)
		end
	end

	return true
end

---@param self ECHomeManager
---@param cancel_all pb.Message.PB.home_cancel_all_t
---@param hometown_data pb.Message.PB.db_ref_home
---@param home_type number
---@return void
def.method("table", "table", "number").S2C_CancelAllItem = function(self, cancel_all, hometown_data, home_type)
	--[[
	---@type pb.Message.PB.db_ref_home
	local home_data = db_msg.db_ref_home()
	home_data.relation = cancel_all.relation
	home_data.owner = self.m_OwnerRoleID
	for tid, info in pairs(sync_items.sync_map) do
		---@type pb.Message.PB.owned_obj_info
		local owned_obj_info = home_data.owned_objs_map:add(tid)
		owned_obj_info.total_cnt = info.total_count
	end]]
	self:S2C_HomeData(hometown_data, home_type, true)

	if not cancel_all.undo then
		local operationData = {}

		local ECHomeUndoMan = require "Home.Undo.ECHomeUndoMan"
		ECHomeUndoMan.Instance():RecordOperation(CONSTANT_DEFINE.HOME_OP_TYPE.HOME_OP_OBJ_CANCEL_ALL, operationData)
	end

	local ECPanelMainHomeEdit = require "GUI.Home.ECPanelMainHomeEdit"
	if ECPanelMainHomeEdit.Instance():IsValid() then
		ECPanelMainHomeEdit.Instance():OnUpdateUI()
	end

	ECShowLogicMan.Instance():ForceUpdateShowLogic(ECShowLogicMan.FORCE_UPDATE_MASK.ALL)
end

---@param self ECHomeManager
---@param multi table
---@param bUndo boolean
---@return boolean
def.method("table", "boolean", "=>","boolean").C2S_MultiCancel = function (self, multi, bUndo)
	_warn(("C2S_MultiCancel+++++++ bUndo[%d]"):format(bUndo and 1 or 0))
	if not self:OperationCheck(false) then
		return false
	end

	---@type pb.Message.PB.gp_home_op_req
	local msg = client_msg.gp_home_op_req()
	msg.op = CONSTANT_DEFINE.HOME_OP_TYPE.HOME_OP_OBJ_MULTI_CANCEL
	msg.transfer_type = self:GetHomeType()
	msg.multi_cancel.undo = bUndo

	local checkok = 0
	---@type table<number, ECHomeNode>
	local node_table = {}
	local exclude_tab = {}
	for i=1, #multi do
		local put_index = multi[i].put_index
		local node = ECHomeData.Instance():GetNodeByPutIndex(put_index)
		if node then
			node.enable_marshal = false --临时不许marshal这个节点用来模拟未来删除后的relation
			node_table[put_index] = node
			exclude_tab[put_index] = 1
		else
			checkok = 2
			break
		end

		---@type pb.Message.PB.home_multi_cancel_t.cancel_t
		local onePut = msg.multi_cancel.cancels:add()
		onePut.tid = multi[i].obj_type
		onePut.put_index = multi[i].put_index
	end

	local ret = true
	if checkok == 0 then
		local succ, relation, bCompressed, relation_origin = self:SerializeRelationData_LargeLimit(true)
		if not succ then
			ret = false
		else
			if self:CheckRelationIsOK(relation_origin, exclude_tab, false) then
				msg.multi_cancel.relation = relation
				msg.multi_cancel.relation_compress = bCompressed
				msg.multi_cancel.relation_sourcelen = relation_origin:len()
				_warn("C2S_MultiCancel++++++++", relation, bCompressed, relation:len(), msg.multi_cancel.relation_sourcelen)
				if not self:IsStandalone() then
					local exceedMaxSize
					ret, exceedMaxSize = pb_helper.Send(msg)
					if exceedMaxSize then
						FlashTipMan.FlashTip(StringTable.Get(91008))
					end
				end
				if ret then
					self.m_bOptLock = true
					if self:IsStandalone() then
						GameUtil.AddGlobalTimer(0, true, function()
							local s2cMsg = {}
							s2cMsg.retcode = 0
							s2cMsg.op = msg.op
							s2cMsg.oper_data = { multi_cancel = msg.multi_cancel }
							self:on_hometown_op(s2cMsg)
						end)
					end
				end
			end
		end
	else
		warn("Err C2S_MultiCancel :", checkok)
		ret = false
	end

	--还原
	for _, node in pairs(node_table) do
		node.enable_marshal = true
	end

	return ret
end

---@param self ECHomeManager
---@param multi_cancel pb.Message.PB.home_multi_cancel_t
---@return void
def.method("table").S2C_MultiCancel = function(self, multi_cancel)
	_warn(("S2C_MultiCancel+++++++ undo[%d]"):format(multi_cancel.undo and 1 or 0))
	local bUpdateGrid = false

	local operationData = {}
	if not multi_cancel.undo then
		local succ, old_relation = self:SerializeRelationData(false)
		operationData.oldRelation = old_relation

		operationData.nodes = {}
		for i=1, #multi_cancel.cancels do
			local cancel = multi_cancel.cancels[i]
			local node = ECHomeData.Instance():GetNodeByPutIndex(cancel.put_index)
			if node then
				local put_data = {}
				put_data.obj_type = cancel.tid
				put_data.put_index = cancel.put_index
				put_data.count = node.count
				put_data.data = node:Serialize()
				put_data.dataTable = node:GetDataTable()
				table.insert(operationData.nodes, put_data)
			end
		end
	end

	local bNeedCheckPlayerPos = false
	for i=1, #multi_cancel.cancels do
		local cancel = multi_cancel.cancels[i]
		local node = ECHomeData.Instance():GetNodeByPutIndex(cancel.put_index)
		if node then
			if not bNeedCheckPlayerPos then
				local floor_index = ECHomeData.Instance():GetFloorIndexOfNode(cancel.put_index)

				-- 操作地下室的房间和一楼泳池以及一楼下陷家具时需要检查玩家位置
				if node.type == _G.ECHOME_ELEMENT_TYPE_ENUM.LINK and node:HasWalls()
						and floor_index == _G.BASEMENT_FLOOR_INDEX then
					bNeedCheckPlayerPos = true
				elseif node.type == _G.ECHOME_ELEMENT_TYPE_ENUM.ITEM and floor_index == 1 then
					local config = ElementData.getConfig(node.tid)
					if config and config.hole_length and config.hole_length > 0
							and config.hole_width and config.hole_width > 0 then
						bNeedCheckPlayerPos = true
					end
				elseif node.type == _G.ECHOME_ELEMENT_TYPE_ENUM.POOL and floor_index == 1 then
					bNeedCheckPlayerPos = true
				elseif node.type == _G.ECHOME_ELEMENT_TYPE_ENUM.STAIR and floor_index == _G.BASEMENT_FLOOR_INDEX then
					bNeedCheckPlayerPos = true
				end
			end

			if node.type==_G.ECHOME_ELEMENT_TYPE_ENUM.LINK then
				ECHomeSpaceUtil.Instance():DeleteLinkPosData(cancel.put_index)

				--[[
				if not bUpdateGrid and ECHomeData.Instance():GetCurrentFloorIndex() > 1 then
					local floor_index = ECHomeData.Instance():GetFloorIndexOfNode(cancel.put_index) + 1
					if floor_index == ECHomeData.Instance():GetCurrentFloorIndex() - 1 and node:HasWalls() then
						bUpdateGrid = true
					end
				end]]
			elseif node.type == _G.ECHOME_ELEMENT_TYPE_ENUM.ITEM then
				ECHomeSpaceUtil.Instance():DeleteItemGridData(cancel.put_index)
			end

			ECHomeData.Instance():RemoveNodeByPutIndex(cancel.put_index, true)
		end
	end

	if not multi_cancel.undo then
		local ECHomeUndoMan = require "Home.Undo.ECHomeUndoMan"
		ECHomeUndoMan.Instance():RecordOperation(CONSTANT_DEFINE.HOME_OP_TYPE.HOME_OP_OBJ_MULTI_CANCEL, operationData)
	end

	local ECPanelMainHomeEdit = require "GUI.Home.ECPanelMainHomeEdit"
	if ECPanelMainHomeEdit.Instance():IsValid() then
		ECPanelMainHomeEdit.Instance():OnUpdateUI()
	end

	if bUpdateGrid then
		local ECHomeGrid = require "Home.Util.ECHomeGrid"
		ECHomeGrid.Instance():Update()
	end

	if bNeedCheckPlayerPos then
		self:CheckPlayerPos(true)
	end

	if self.m_bInDesignMode then
		self:SaveDesignData()
	end
end

--批量摆放multi_put
---@param self ECHomeManager
---@param multi pb.Message.PB.home_multi_put_t
---@param bUndo boolean
---@return boolean
def.method("table", "boolean", "=>", "boolean").C2S_MultiPut = function (self, multi, bUndo)
	_warn(("C2S_MultiPut+++++++ bUndo[%d]"):format(bUndo and 1 or 0))
	if not self:OperationCheck(true) then
		return false
	end

	if not multi or #multi.old_relation == 0 or #multi.cancel_nodes == 0 then
		return false
	end

	---@type pb.Message.PB.gp_home_op_req
	local msg = client_msg.gp_home_op_req()
	msg.op = CONSTANT_DEFINE.HOME_OP_TYPE.HOME_OP_OBJ_MULTI_PUT
	msg.transfer_type = self:GetHomeType()
	msg.multi_put.undo = bUndo

	if not bUndo then
		warn("MultiPut, bUndo = ", bUndo)
		return false
	end

	local exclude_tab = {}

	for i=1, #multi.cancel_nodes do
		-- 临时创建数据节点用来构建relation数据
		local node = multi.cancel_nodes[i]

		-- TODO 临时忽略一下未创建的relation中存在的节点
		exclude_tab[node.put_index] = 1

		---@type pb.Message.PB.home_multi_put_t.put_t
		local onePut = msg.multi_put.puts:add()
		onePut.tid = node.obj_type
		onePut.put_index = node.put_index
		onePut.count = node.count
		onePut.data = node.data

		ECHomeData.Instance():SetTempUsedID(node.obj_type, node.put_index, node.dataTable) --先占用这些id 收到后释放
	end

	local succ, relation, bCompressed, relation_origin = true, multi.old_relation, false, multi.old_relation
	if not succ then return false end

	if not self:CheckRelationIsOK(relation_origin, exclude_tab, false) then
		return false
	end

	msg.multi_put.relation = relation
	msg.multi_put.relation_compress = bCompressed
	msg.multi_put.relation_sourcelen = relation_origin:len()

	local succ = true
	if not self:IsStandalone() then
		local exceedMaxSize
		succ, exceedMaxSize = pb_helper.Send(msg)
		--print("C2S_MultiPut", tostring(msg))
		if exceedMaxSize then
			FlashTipMan.FlashTip(StringTable.Get(91008))
		end
	end
	if succ then
		self.m_bOptLock = true
		if self:IsStandalone() then
			GameUtil.AddGlobalTimer(0, true, function()
				local s2cMsg = {}
				s2cMsg.retcode = 0
				s2cMsg.op = msg.op
				s2cMsg.oper_data = { multi_put = msg.multi_put }
				self:on_hometown_op(s2cMsg)
			end)
		end
	end
	return succ
end

---@param self ECHomeManager
---@param multi_put pb.Message.PB.home_multi_put_t
---@return void
def.method("table").S2C_MultiPut = function (self, multi_put)
	_warn(("S2C_MultiPut++++++++ undo[%d] rel_compress[%d] len[%d] srclen[%d]"):format(
			multi_put.undo and 1 or 0, multi_put.relation_compress and 1 or 0, multi_put.relation:len(), multi_put.relation_sourcelen or 0))

	local rel_decompressed = multi_put.relation
	if multi_put.relation_compress then
		local decompressed = ECHomeData.DecompressData(multi_put.relation, multi_put.relation_sourcelen)
		if not decompressed then
			MsgBox.ShowMsgBox(nil, StringTable.Get(91090), nil, MsgBoxType.MBBT_OK)
			return
		end
		rel_decompressed = decompressed
	end

	ECHomeData.Instance():UnserializeRelationData(rel_decompressed)

	local update_links = {}

	for i=1, #multi_put.puts do
		local put = multi_put.puts[i]

		-- 更新节点的数据
		local node = ECHomeData.Instance():GetNodeByPutIndex(put.put_index)
		node.tid = put.tid
		node.count = put.count
		node:Unserialize(put.data)

		if node.is_temp then
			node.is_temp = false
		end

		ECHomeData.Instance():RemoveTempUsedID(put.tid, put.put_index, node:GetDataTable())

		if node and node.type == _G.ECHOME_ELEMENT_TYPE_ENUM.LINK then
			ECHomeSpaceUtil.Instance():AddOrUpdateLinkPosData(put.put_index)
			table.insert(update_links, put.put_index)
		elseif node and node.type == _G.ECHOME_ELEMENT_TYPE_ENUM.ITEM then
			ECHomeSpaceUtil.Instance():AddOrUpdateItemGridData(put.put_index)
		end
	end

	ECHomeView.Instance():UpdateViewTree(false, nil)

	for i=1, #update_links do
		ECHomeView.Instance():UpdateLinkCorner(update_links[i])
	end

	local ECPanelMainHomeEdit = require "GUI.Home.ECPanelMainHomeEdit"
	if ECPanelMainHomeEdit.Instance():IsValid() then
		ECPanelMainHomeEdit.Instance():OnUpdateUI()
	end

	if self.m_bInDesignMode then
		self:SaveDesignData()
	end
end

---@param self ECHomeManager
---@return boolean
def.method("=>", "boolean").C2S_HomeLevelUp = function(self)
	if not self:OperationCheck(false) then
		return false
	end

	---@type pb.Message.PB.gp_home_op_req
	local msg = client_msg.gp_home_op_req()
	msg.op = CONSTANT_DEFINE.HOME_OP_TYPE.HOME_OP_UPGRADE
	msg.home_owner = globalGame:GetHostPlayer():GetID()
	local succ = pb_helper.Send(msg)
	if succ then
		self.m_bOptLock = true
	end

	return succ
end

---@param self ECHomeManager
---@param home_owner string
---@param info pb.Message.PB.home_info_t
---@return void
def.method("string", "table").S2C_HomeLevelUp = function(self, home_owner, info)
	local homeInfo = self:GetHomeInfo(home_owner)

	homeInfo.cur_level = info.cur_level
	homeInfo.is_upgrading = info.is_upgrading
	homeInfo.upgrade_end_ts = info.upgrade_end_ts
	-- 废弃
	--homeInfo.is_daily_reward_done = info.is_daily_reward_done

	homeInfo.repus = {}
	for tid, repu in pairs(info.repu.repus) do
		homeInfo.repus[tid] = LuaUInt64.ToDouble(repu.value)
	end

	ECGame.EventManager:raiseEvent(nil, HomeEvents.HomeInfoEvent.new(home_owner))
end

---@param self ECHomeManager
---@param type number
---@param put_index number
---@param tid number
---@return boolean
def.method("number", "number", "number", "=>", "boolean").C2S_StageDisplayByTid = function(self, type, put_index, tid)
	return self:C2S_StageDisplay(type, put_index, tid, LuaUInt64.FromDouble(tid))
end

local DisplayType = db_msg.home_display_t.TYPE
---@type pb.Enum.PB.home_display_t.TYPE
def.const("table").DisplayType = DisplayType
---@param self ECHomeManager
---@param type number
---@param put_index number
---@param tid number
---@param id string
---@return boolean
def.method("number", "number", "number", "string", "=>", "boolean").C2S_StageDisplay = function(self, type, put_index, tid, id)
	if not self:OperationCheck(false) then
		return false
	end
	
	-- 服务器用id做key，如果没有，以tid为key
	if tid ~= 0 and id == ZeroUInt64 then
		id = LuaUInt64.FromDouble(tid)
	end
	
	---@type pb.Message.PB.gp_home_op_req
	local msg = client_msg.gp_home_op_req()
	msg.op = CONSTANT_DEFINE.HOME_OP_TYPE.HOME_OP_DISPLAY
	msg.transfer_type = self:GetHomeType()
	msg.home_owner = globalGame:GetHostPlayerID()
	msg.display.type = type
	msg.display.put_index = put_index
	msg.display.disp_tid = tid
	msg.display.disp_id = id
	local succ = pb_helper.Send(msg)
	if succ then
		self.m_bOptLock = true
	end

	return succ
end

---@param self ECHomeManager
---@param homeType number
---@param info pb.Message.PB.home_display_t
---@return void
def.method("number", "table").S2C_StageDisplay = function(self, homeType, info)
	ECHomeStageMan.Instance():OnStageDisplay(homeType, info)
end

---@param self ECHomeManager
---@param homeType number
---@param putIndexList table
---@return void
def.method("number", "table").S2C_DelStageDisplay = function(self, homeType, putIndexList)
	ECHomeStageMan.Instance():DelDisplayByList(homeType, putIndexList)
end

---@param self ECHomeManager
---@param room_put_index number
---@return boolean
def.method("number", "=>", "boolean").C2S_UnlockRoom = function(self, room_put_index)
	if not self:OperationCheck(false) then
		return false
	end

	---@type pb.Message.PB.gp_home_op_req
	local msg = client_msg.gp_home_op_req()
	msg.op = CONSTANT_DEFINE.HOME_OP_TYPE.HOME_OP_UNLOCK_ROOM
	msg.unlock_room.put_index = room_put_index
	local succ = pb_helper.Send(msg)
	if succ then
		self.m_bOptLock = true
	end

	--[[
	GameUtil.AddGlobalTimer(0.1, true, function()
		local s2cMsg = {}
		s2cMsg.retcode = 0
		s2cMsg.op = msg.op
		s2cMsg.oper_data = {}
		s2cMsg.oper_data.unlock_room = {roomid = room_id}
		self:on_hometown_op(s2cMsg)
	end)]]

	return true
end

---@param self ECHomeManager
---@param info pb.Message.PB.home_unlock_room_t
---@return void
def.method("table").S2C_UnlockRoom = function(self, info)
	local ECHomeRoomUnlock = require "Home.Misc.ECHomeRoomUnlock"
	ECHomeRoomUnlock.Instance():OnHomeRoomUnlock(info)
end

---@param self ECHomeManager
---@param multi_buy table
---@param multi_sell table
---@param multi_cancel table
---@param multi_put table
---@param multi_data table
---@param param number
---@param undo_relation table
---@param bUndo boolean
---@return boolean
def.method("table", "table", "table", "table", "table", "number", "table", "boolean", "=>", "boolean").C2S_MultiOperation = function (self, multi_buy, multi_sell, multi_cancel, multi_put, multi_data, param, undo_relation, bUndo)
	_warn(("C2S_MultiOperation+++++++ bUndo[%d]"):format(bUndo and 1 or 0))

	local curTime = GameUtil.GetTimeSeconds()
	if not self.m_bInDesignMode and #multi_buy > 0 and self.m_last_BuyOperation >0 and self.m_last_BuyOperation + CD_TIME > curTime then
		FlashTipMan.FlashTip(StringTable.Get(91013))
		return false
	end

	---@type pb.Message.PB.gp_home_op_req
	local msg = client_msg.gp_home_op_req()
	msg.op = CONSTANT_DEFINE.HOME_OP_TYPE.HOME_OP_OBJ_MULTI_OPER
	msg.transfer_type = self:GetHomeType()
	msg.multi_oper.undo = bUndo

	--buy
	if multi_buy then
		for i=1,#multi_buy do
			if multi_buy[i].count > 0 then
				---@type pb.Message.PB.home_multi_oper_t.operation_t
				local buy = msg.multi_oper.operations:add()
				buy.op = CONSTANT_DEFINE.HOME_OP_TYPE.HOME_OP_OBJ_BUY
				buy.tid = multi_buy[i].obj_type	--模板id
				buy.count = multi_buy[i].count	--数量
			end
		end
	end

	--cancel
	local checkok = 0
	---@type table<number, ECHomeNode>
	local e_table = {}
	local exclude_tab = {} --不校验
	if multi_cancel then
		for i=1, #multi_cancel do
			local node = ECHomeData.Instance():GetNodeByPutIndex(multi_cancel[i].put_index)
			if node then
				node.enable_marshal = false --临时不许marshal这个e用来模拟未来删除后的relation
				e_table[node.put_index] = node
			else
				checkok = 1
				break
			end
			exclude_tab[multi_cancel[i].put_index] = 1

			---@type pb.Message.PB.home_multi_oper_t.operation_t
			local oneCancel = msg.multi_oper.operations:add()
			oneCancel.op = CONSTANT_DEFINE.HOME_OP_TYPE.HOME_OP_OBJ_CANCEL
			oneCancel.tid = multi_cancel[i].obj_type
			oneCancel.put_index = multi_cancel[i].put_index
		end
	end

	--obj data count减少
	if multi_data then
		for i=1, #multi_data do
			if multi_data[i].count > 0 and multi_data[i].oldCount and multi_data[i].oldCount > multi_data[i].count then
				---@type pb.Message.PB.home_multi_oper_t.operation_t
				local update_obj_data = msg.multi_oper.operations:add()
				update_obj_data.op = CONSTANT_DEFINE.HOME_OP_TYPE.HOME_OP_UPDATE_OBJ_DATA
				update_obj_data.tid = multi_data[i].obj_type
				update_obj_data.put_index = multi_data[i].put_index
				update_obj_data.data = multi_data[i].data
				update_obj_data.count = multi_data[i].count
			end
		end
	end

	--sell
	if multi_sell then
		for i=1, #multi_sell do
			if multi_sell[i].count > 0 then
				--[[
				---@type pb.Message.PB.home_multi_oper_t.operation_t
				local sell = msg.multi_oper.operations:add()
				sell.op = CONSTANT_DEFINE.HOME_OP_TYPE.HOME_OP_OBJ_SELL
				sell.tid = multi_sell[i].obj_type	--模板id
				sell.count = multi_sell[i].count	--数量
				]]
			end
		end
	end

	--obj data
	if multi_data then
		for i=1, #multi_data do
			if multi_data[i].count > 0 and (not multi_data[i].oldCount or (multi_data[i].oldCount < multi_data[i].count)) then
				---@type pb.Message.PB.home_multi_oper_t.operation_t
				local update_obj_data = msg.multi_oper.operations:add()
				update_obj_data.op = CONSTANT_DEFINE.HOME_OP_TYPE.HOME_OP_UPDATE_OBJ_DATA
				update_obj_data.tid = multi_data[i].obj_type
				update_obj_data.put_index = multi_data[i].put_index
				update_obj_data.data = multi_data[i].data
				update_obj_data.count = multi_data[i].count
			end
		end
	end

	--put
	if multi_put then
		for i=1, #multi_put do
			--[[
			local node = ECHomeData.Instance():GetNodeByPutIndex(multi_put[i].put_index)
			if node then
				warn("Err C2S_MultiOperation put, node exist!", multi_put[i].obj_type, multi_put[i].put_index, node)
				return false
			end]]

			if multi_put[i].count <= 0 then
				warn("Err C2S_MultiOperation multi_put[i].count <= 0", multi_put[i].count)
				return false
			end

			---@type pb.Message.PB.home_multi_oper_t.operation_t
			local onePut = msg.multi_oper.operations:add()
			onePut.op = CONSTANT_DEFINE.HOME_OP_TYPE.HOME_OP_OBJ_PUT
			onePut.tid = multi_put[i].obj_type
			onePut.put_index = multi_put[i].put_index
			onePut.count = multi_put[i].count
			onePut.data = multi_put[i].data

			ECHomeData.Instance():SetTempUsedID(multi_put[i].obj_type, multi_put[i].put_index, multi_put[i].dataTable) --先占用这些id 收到后释放
		end
	end

	--obj data
	if multi_data then
		for i=1, #multi_data do
			if multi_data[i].count < 0 then
				---@type pb.Message.PB.home_multi_oper_t.operation_t
				local update_obj_data = msg.multi_oper.operations:add()
				update_obj_data.op = CONSTANT_DEFINE.HOME_OP_TYPE.HOME_OP_UPDATE_OBJ_DATA
				update_obj_data.tid = multi_data[i].obj_type
				update_obj_data.put_index = multi_data[i].put_index
				update_obj_data.data = multi_data[i].data
				update_obj_data.count = multi_data[i].count
			end
		end
	end

	local ret = true
	if checkok == 0 then
		local succ, relation, bCompressed, relation_origin
		if bUndo and undo_relation then
			succ = true
			relation_origin = undo_relation.data
			bCompressed = undo_relation.compressed
			if bCompressed then
				relation = ECHomeData.CompressData(relation_origin)
			end
		else
			succ, relation, bCompressed, relation_origin = self:SerializeRelationData(true)
			if not self:CheckRelationIsOK(relation_origin, exclude_tab, false) then
				succ = false
			end
		end

		if succ then
			msg.multi_oper.relation = relation
			msg.multi_oper.relation_compress = bCompressed
			msg.multi_oper.relation_sourcelen = relation_origin:len()

			if not self:IsStandalone() then
				local exceedMaxSize
				ret, exceedMaxSize = pb_helper.Send(msg)
				if exceedMaxSize then
					FlashTipMan.FlashTip(StringTable.Get(91008))
				end
			end
			if ret then
				self.m_bOptLock = true
				if #multi_buy > 0 then
					self.m_last_BuyOperation = curTime
				end

				if self:IsStandalone() then
					GameUtil.AddGlobalTimer(0, true, function()
						local s2cMsg = {}
						s2cMsg.retcode = 0
						s2cMsg.op = msg.op
						s2cMsg.oper_data = { multi_oper = msg.multi_oper }
						self:on_hometown_op(s2cMsg)
					end)
				end
			end
		end
		--warn("C2S_MultiOperation+++++++",msg.multi_cancel.relation)
	else
		warn("Err C2S_MultiOperation checkok:",checkok)
		ret = false
	end

	--还原
	for put_index, e in pairs(e_table) do
		e.enable_marshal = true
	end

	return true
end

---@param self ECHomeManager
---@param multi_oper pb.Message.PB.home_multi_oper_t
---@return void
def.method("table").S2C_MultiOperation = function(self, multi_oper)
	_warn(("S2C_MultiOperation++++++++ undo[%d] rel_compress[%d] len[%d] srclen[%d]"):format(
			multi_oper.undo and 1 or 0, multi_oper.relation_compress and 1 or 0,
			multi_oper.relation:len(), multi_oper.relation_sourcelen or 0))

	local updateShowLogic = false
	local bUpdateGrid = false

	local rel_decompressed = multi_oper.relation
	if multi_oper.relation_compress then
		local decompressed = ECHomeData.DecompressData(multi_oper.relation, multi_oper.relation_sourcelen)
		if not decompressed then
			MsgBox.ShowMsgBox(nil, StringTable.Get(91090), nil, MsgBoxType.MBBT_OK)
			return
		end
		rel_decompressed = decompressed
	end

	local operationData = {}
	operationData.multi_buy = {}
	operationData.multi_sell = {}
	operationData.multi_cancel = {}
	operationData.multi_put = {}
	operationData.multi_data = {}

	do
		local _, _, bCompressed, relation_origin = self:SerializeRelationData_LargeLimit(true)
		operationData.old_relation = {
			data = relation_origin,
			compressed = bCompressed,
		}
		operationData.new_relation = {
			data = rel_decompressed,
			compressed = multi_oper.relation_compress,
		}
	end

	local bRelationChanged = rel_decompressed and rel_decompressed:len() > 0
	if bRelationChanged then
		ECHomeData.Instance():UnserializeRelationData(rel_decompressed)
	end

	local update_links = {}

	--先买才能后面的或逻辑
	for i=1, #multi_oper.operations do
		local op = multi_oper.operations[i].op
		if op == CONSTANT_DEFINE.HOME_OP_TYPE.HOME_OP_OBJ_BUY then
			local buy = multi_oper.operations[i]

			if not multi_oper.undo then
				table.insert(operationData.multi_buy, {
					obj_type = buy.tid,
					count = buy.count,
				})
			end

			local config, dataType = ElementData.getConfig(buy.tid)
			local checkOK = false
			if config then
				if dataType == CONSTANT_DEFINE.CONFIG_TYPE.CONFIG_HOME_BUILD then
					checkOK = true
				elseif dataType == CONSTANT_DEFINE.CONFIG_TYPE.CONFIG_HOME_FURNITURE then
					checkOK = true
				else
				end
			end
			if checkOK then
				ECHomeData.Instance():AddItemCount(buy.tid, buy.count)
			end
		end
	end

	--删除占格
	for i=1, #multi_oper.operations do
		local op = multi_oper.operations[i].op
		if op == CONSTANT_DEFINE.HOME_OP_TYPE.HOME_OP_OBJ_CANCEL then
			local cancel = multi_oper.operations[i]
			local node = ECHomeData.Instance():GetNodeByPutIndex(cancel.put_index)
			if node then
				if node.type==_G.ECHOME_ELEMENT_TYPE_ENUM.LINK then
					ECHomeSpaceUtil.Instance():DeleteLinkPosData(cancel.put_index)
				elseif node.type == _G.ECHOME_ELEMENT_TYPE_ENUM.ITEM then
					ECHomeSpaceUtil.Instance():DeleteItemGridData(cancel.put_index)
				end
			end
		end
	end

	local bNeedCheckPlayerPos = false
	--从旧的element中删除
	for i=1, #multi_oper.operations do
		local op = multi_oper.operations[i].op
		if op == CONSTANT_DEFINE.HOME_OP_TYPE.HOME_OP_OBJ_CANCEL then
			local cancel = multi_oper.operations[i]
			local node = ECHomeData.Instance():GetNodeByPutIndex(cancel.put_index)
			if node then
				if not multi_oper.undo then
					local oneOperData = {}
					oneOperData.obj_type = cancel.tid
					oneOperData.put_index = cancel.put_index
					oneOperData.count = node.count
					oneOperData.data = node:Serialize()
					oneOperData.dataTable = node:GetDataTable()
					table.insert(operationData.multi_cancel, oneOperData)
				end

				if not bNeedCheckPlayerPos then
					local floor_index = ECHomeData.Instance():GetFloorIndexOfNode(cancel.put_index)
					--操作地下室的房间和一楼泳池以及一楼下陷家具时需要检查玩家位置
					if node.type == _G.ECHOME_ELEMENT_TYPE_ENUM.LINK and #node.walls > 1 and floor_index == _G.BASEMENT_FLOOR_INDEX then
						bNeedCheckPlayerPos = true
					elseif node.type == _G.ECHOME_ELEMENT_TYPE_ENUM.ITEM and floor_index == 1 then
						---@type pb.Message.PB.HomeFurnitureConfig
						local config = ElementData.getConfig(node.tid)
						if config and config.hole_length and config.hole_length > 0 and config.hole_width and config.hole_width > 0 then
							bNeedCheckPlayerPos = true
						end
					elseif node.type == _G.ECHOME_ELEMENT_TYPE_ENUM.POOL and floor_index == 1 then
						bNeedCheckPlayerPos = true
					elseif node.type == _G.ECHOME_ELEMENT_TYPE_ENUM.STAIR and floor_index == _G.BASEMENT_FLOOR_INDEX then
						bNeedCheckPlayerPos = true
					end
				end

				ECHomeData.Instance():RemoveNodeByPutIndex(cancel.put_index, true)
			end

			if not node then
				warn("Err S2C_MultiOperation no node:", cancel.put_index, node)
			end
		end
	end

	local putLinkCount = 0
	local linkUpdateCount = 0
	local detectLinkInfoList = {}
	--先添加
	for i=1, #multi_oper.operations do
		local op = multi_oper.operations[i].op
		if op == CONSTANT_DEFINE.HOME_OP_TYPE.HOME_OP_OBJ_PUT then
			local put = multi_oper.operations[i]
			local node = ECHomeData.Instance():GetNodeByPutIndex(put.put_index)
			node.tid = put.tid
			node.count = put.count
			node:Unserialize(put.data)

			if not multi_oper.undo then
				local oneOperData = {}
				oneOperData.obj_type = put.tid
				oneOperData.put_index = put.put_index
				oneOperData.count = put.count
				oneOperData.data = node:Serialize()
				oneOperData.dataTable = node:GetDataTable()
				table.insert(operationData.multi_put, oneOperData)
			end

			if node.is_temp then
				node.is_temp = false

				ECHomeData.Instance():UpdateNode(node, false)
			else
				local event = HomeEvents.HomeNodeAddEvent.new(node)
				ECGame.EventManager:raiseEvent(nil, event)
			end

			ECHomeData.Instance():RemoveTempUsedID(put.tid, put.put_index, node:GetDataTable())

			if node.type == _G.ECHOME_ELEMENT_TYPE_ENUM.LINK then
				updateShowLogic = true
				local linkInfo = ECHomeManager.Instance():AddOrUpdateLinkPosData(put.put_index)
				if linkInfo then
					table.insert(detectLinkInfoList, linkInfo)
				end
				table.insert(update_links,put.put_index)
				putLinkCount = putLinkCount + 1
			elseif node.type == _G.ECHOME_ELEMENT_TYPE_ENUM.ITEM then
				ECHomeSpaceUtil.Instance():AddOrUpdateItemGridData(put.put_index)
			end
		elseif op == CONSTANT_DEFINE.HOME_OP_TYPE.HOME_OP_UPDATE_OBJ_DATA then
			local update_obj_data = multi_oper.operations[i]
			local node = ECHomeData.Instance():GetNodeByPutIndex(update_obj_data.put_index)
			if node and node.type==_G.ECHOME_ELEMENT_TYPE_ENUM.LINK then
				linkUpdateCount = linkUpdateCount + 1
			end
		end
	end

	local deleteWallPutIndexs = {}

	for i=1, #multi_oper.operations do
		local op = multi_oper.operations[i].op
		--[[
		if op == CONSTANT_DEFINE.HOME_OP_TYPE.HOME_OP_OBJ_SELL then
			local sell = multi_operation.operations[i]

			if not multi_operation.undo then
				table.insert(operationData.multi_sell, sell)
			end

			if ECHomeRelation.Instance().m_HomeData[sell.obj_type] and ECHomeRelation.Instance().m_HomeData[sell.obj_type].total_count then
				ECHomeRelation.Instance().m_HomeData[sell.obj_type].total_count = ECHomeRelation.Instance().m_HomeData[sell.obj_type].total_count-sell.count
			end]]
		if op == CONSTANT_DEFINE.HOME_OP_TYPE.HOME_OP_UPDATE_OBJ_DATA then
			local update_obj_data = multi_oper.operations[i]
			if self.m_WaitingUpdatePutIndex == update_obj_data.put_index then
				self.m_WaitingUpdatePutIndex = 0
			end
			local node = ECHomeData.Instance():GetNodeByPutIndex(update_obj_data.put_index)
			if node then
				local oldData = node:GetDataTable()
				local oldBytes = node:Serialize()
				node:Unserialize(update_obj_data.data)

				if not multi_oper.undo then
					local oneOperData = {}
					oneOperData.obj_type = update_obj_data.tid
					oneOperData.put_index = update_obj_data.put_index
					oneOperData.count = node.count
					oneOperData.data = oldBytes
					oneOperData.newCount = update_obj_data.count
					oneOperData.newData = update_obj_data.data
					table.insert(operationData.multi_data, oneOperData)
				end

				if update_obj_data.count >= 0 then
					node.count = update_obj_data.count
				end

				if node then
					ECHomeData.Instance():UpdateNode(node, false)

					if not bNeedCheckPlayerPos then
						local floor_index = ECHomeData.Instance():GetFloorIndexOfNode(update_obj_data.put_index)
						--操作地下室的房间和一楼泳池以及一楼下陷家具时需要检查玩家位置
						if node.type == _G.ECHOME_ELEMENT_TYPE_ENUM.LINK and #node.walls > 1 and floor_index == _G.BASEMENT_FLOOR_INDEX then
							bNeedCheckPlayerPos = true
						elseif node.type == _G.ECHOME_ELEMENT_TYPE_ENUM.ITEM and floor_index == 1 then
							---@type pb.Message.PB.HomeFurnitureConfig
							local config = ElementData.getConfig(update_obj_data.put_index)
							if config and config.hole_length and config.hole_length > 0 and config.hole_width and config.hole_width > 0 then
								bNeedCheckPlayerPos = true
							end
						elseif node.type == _G.ECHOME_ELEMENT_TYPE_ENUM.POOL and floor_index == 1 then
							bNeedCheckPlayerPos = true
						elseif node.type == _G.ECHOME_ELEMENT_TYPE_ENUM.STAIR and floor_index == _G.BASEMENT_FLOOR_INDEX then
							bNeedCheckPlayerPos = true
						end
					end

					if node.type == _G.ECHOME_ELEMENT_TYPE_ENUM.LINK then
						updateShowLogic = true
						local linkInfo = ECHomeSpaceUtil.Instance():AddOrUpdateLinkPosData(update_obj_data.put_index)
						if linkInfo then
							local bDetect = ECHomeData.Instance():CheckLinkChangeNeedDetect(oldData, node:GetDataTable())
							if bDetect then
								table.insert(detectLinkInfoList, linkInfo)
							end
						end
						table.insert(update_links, update_obj_data.put_index)
					elseif node.type == _G.ECHOME_ELEMENT_TYPE_ENUM.ITEM then
						ECHomeSpaceUtil.Instance():AddOrUpdateItemGridData(update_obj_data.put_index)
					end
				end
			end
		end
	end

	if not multi_oper.undo then
		ECHomeUndoMan.Instance():RecordOperation(CONSTANT_DEFINE.HOME_OP_TYPE.HOME_OP_OBJ_MULTI_OPER, operationData)
	end

	for i=1, #update_links do
		ECHomeView.Instance():UpdateLinkCorner(update_links[i])
	end

	if #detectLinkInfoList > 0 then
		ECHomeSpaceUtil.Instance():CheckDetect(detectLinkInfoList)
	end

	local ECPanelMainHomeEdit = require "GUI.Home.ECPanelMainHomeEdit"
	if ECPanelMainHomeEdit.Instance():IsValid() then
		ECPanelMainHomeEdit.Instance():OnUpdateUI()
	end

	if updateShowLogic then
		ECShowLogicMan.Instance():ForceUpdateShowLogic(ECShowLogicMan.FORCE_UPDATE_MASK.ROOF_AND_WALL)
	end

	if bUpdateGrid then
		local ECHomeGrid = require "Home.Util.ECHomeGrid"
		ECHomeGrid.Instance():Update()
	end

	if bNeedCheckPlayerPos then
		self:CheckPlayerPos(true)
	end

	if self.m_bInDesignMode then
		self:SaveDesignData()
	end
end

--玩家在地下室 不在室内 移到地面
---@param self ECHomeManager
---@param bMove boolean
---@return boolean
def.method("boolean", "=>", "boolean").CheckPlayerPos = function (self, bMove)
	local hp = ECGame.Instance().m_HostPlayer
	if not hp then return false end

	local bPosValid = true
	---@type ECHomeObj
	local home = ECHomeView.Instance():GetRootViewNode()
	if home and home.OrderFloors and home.OrderFloors[1] then
		local x, y, z = hp:GetPos_UE()

		local firstFloor = home.OrderFloors[1]
		local floorZ = ECHomeView.Instance():GetFloorsZ(1)

		if z < floorZ - homeCfg.underGroundCheckZ then
			bPosValid = false

			local checkPosList = {[1] = {x = x, y = y, z = z}}
			--判断在不在地下室室内
			if not bPosValid and home.Basement and home.Basement:IsPosListInsideClosedLink(checkPosList, false, false, {}) then
				local baseHei = hp:GetCurModelHeight()
				baseHei = baseHei * hp.m_fModelScale

				if z + baseHei*100 - homeCfg.aboveGroundCheckZ > floorZ and not home.Basement:IsPosListInsideStair_Inner(checkPosList, 0, false) then --头在地面上 检查在不在楼梯里
					bPosValid = false
				else
					bPosValid = true
				end
			end

			--判断在不在泳池内
			if not bPosValid and firstFloor:IsPosListInsidePool_Inner(checkPosList, 0, false) then
				bPosValid = true
			end

			--判断在不在下陷家具内
			if not bPosValid and ECHomeSpaceUtil.Instance():IsInsideUndergroundItem({x = x, y = y, z = z}) then
				bPosValid = true
			end

			if not bPosValid and bMove then
				local bOldShow = home.bShowGround
				if not bOldShow then
					home:ShowGround(true)
				end
				hp:InitPosition(posv_to_server({x = x, y = y, z = floorZ}))
				home:ShowGround(bOldShow)
			end
		end
	end

	return bPosValid
end

---@param self ECHomeManager
---@return boolean
def.method("=>", "boolean").C2S_HomeDebugData = function(self)
	if not self:OperationCheck(false) then
		return false
	end

	local succ, relation, bCompressed, relation_origin = self:SerializeRelationData(true)
	if not succ or not self:CheckRelationIsOK(relation_origin, {}, false) then
		return false
	end

	---@type pb.Message.PB.gp_home_op_req
	local msg = client_msg.gp_home_op_req()
	msg.op = CONSTANT_DEFINE.HOME_OP_TYPE.HOME_OP_DEBUG
	msg.transfer_type = self:GetHomeType()
	msg.debug.type = db_msg.home_debug_t.TYPE.INIT
	---@type pb.Message.PB.home_debug_t.init_t
	local data = msg.debug.init:add()
	data.sceneid = globalGame:GetCurrentSceneID()
	data.relation = relation

	local ownedObjMaps = ECHomeData.Instance():GenOwnedObjMaps()
	for tid, owned_obj_info in pairs(ownedObjMaps) do
		---@type pb.Message.PB.owned_obj_info
		local info = data.owned_objs_map:add(tid)
		info.total_cnt = owned_obj_info.total_cnt
		info.put_cnt = owned_obj_info.put_cnt
		for put_index, put_info in pairs(owned_obj_info.put_objs_map) do
			---@type pb.Message.PB.put_obj_t
			local put_obj = info.put_objs_map:add(put_index)
			put_obj.put_index = put_index
			put_obj.count = put_info.count
			put_obj.client_put_data = put_info.client_put_data
		end
	end

	local succ = true
	if not self:IsStandalone() then
		local exceedMaxSize
		succ, exceedMaxSize = pb_helper.Send(msg)
		if exceedMaxSize then
			FlashTipMan.FlashTip(StringTable.Get(91008))
		end
	end
	if succ then
		self.m_bOptLock = true

		if self:IsStandalone() then
			GameUtil.AddGlobalTimer(0, true, function()
				local s2cMsg = {}
				s2cMsg.retcode = 0
				s2cMsg.op = msg.op
				s2cMsg.oper_data = {}
				s2cMsg.oper_data.debug = msg.debug
				self:on_hometown_op(s2cMsg)
			end)
		end
	end
	return succ
end

---@param self ECHomeManager
---@param debug pb.Message.PB.home_debug_t
---@return void
def.method("table").S2C_HomeDebugData = function(self, debug)
	local oldRelLen = 0
	if ECHomeData.Instance():GetHomeRootNode() then
		local succ, relation = self:SerializeRelationData(false)
		if succ then
			oldRelLen = relation:len()
		end
	end

	self:Reset(false)

	self.m_bDuringRebuild = true

	self:SetEditMode(false)

	ECHomeData.Instance():OnDebugData(debug)

	local ECPanelMainHomeEdit = require "GUI.Home.ECPanelMainHomeEdit"
	if ECPanelMainHomeEdit.Instance():IsValid() then
		ECPanelMainHomeEdit.Instance():SetEditMode(self.m_bInEditMode)
	end

	local function afterHomeCreate()
		---@param node ECHomeNode
		local function doAddPosData(node)
			if not node then return end
			if node then
				if node.type == _G.ECHOME_ELEMENT_TYPE_ENUM.LINK then
					ECHomeSpaceUtil.Instance():AddOrUpdateLinkPosData(node.put_index)
				elseif node.type == _G.ECHOME_ELEMENT_TYPE_ENUM.ITEM then
					ECHomeSpaceUtil.Instance():AddOrUpdateItemGridData(node.put_index)
				end
			end

			for child in node:ChildIterator() do
				doAddPosData(child)
			end
		end

		doAddPosData(ECHomeData.Instance():GetHomeRootNode())

		if not self.m_bCreateInComplete then
			--修正下单墙的拐角
			---@type ECHomeObj
			local home = ECHomeView.Instance():GetViewNodeByPutIndex(_G.HOME_ROOT_PUT_INDEX)
			if home then
				for floor_id, floor in pairs(home.Floors) do
					for link_id, link in pairs(floor.Links) do
						-- if link.WallCount==1 then
						for wall_id, wall in pairs(link.Walls) do
							local bUpdate = false
							if wall:GetPreWall(link) then
								bUpdate = true
							end
							if wall:GetNextWall(link) then
								bUpdate = true
							end
							if bUpdate then
								--warn("  __UpdateWallMesh: ", floor_id,link_id,wall_id)
								ECHomeView.Instance():UpdateWallMesh(wall_id)
							end
						end
					end
				end

				_G.gc()
			end
		end

		self.m_bDuringRebuild = false
		ECGame.EventManager:raiseEvent(nil, HomeEvents.HomeDataRebuildReadyEvent())
	end

	-- 更新几何节点树
	ECHomeView.Instance():UpdateViewTree(true, function()
		afterHomeCreate()
	end)
end

---@param self ECHomeManager
---@return boolean
def.method("=>", "boolean").C2S_GetDailyReward = function(self)
	if not self:OperationCheck(false) then
		return false
	end

	---@type pb.Message.PB.gp_home_op_req
	local msg = client_msg.gp_home_op_req()
	msg.op = CONSTANT_DEFINE.HOME_OP_TYPE.HOME_OP_DAILY_REWARD
	local succ = pb_helper.Send(msg)
	if succ then
		self.m_bOptLock = true
	end

	return true
end

---@param self ECHomeManager
---@return void
def.method().S2C_GetDailyReward = function(self)
	local dailyReward = ECHomeProduce.Instance():GetDailyReward()
	local item_list = {}
	local bEmpty = true
	for tid, count in pairs(dailyReward) do
		if count > 0 then
			local repuCfg = ReputationCfg.GetRepuCfg(tid)
			table.insert(item_list, { tid = repuCfg.item_tid, count = count })
			bEmpty = false
		end
	end
	local UICommonRewardShow = require "GUI.Common.UICommonRewardShow"
	UICommonRewardShow.Instance():Popup(item_list, nil)

	if bEmpty then
		FlashTipMan.FlashTip(StringTable.Get(91085))
	end
end

---@param self ECHomeManager
---@param people_tid number
---@return boolean
def.method("number", "=>", "boolean").C2S_ChangeButler = function(self, people_tid)
	if not self:OperationCheck(false) then
		return false
	end

    ---@type pb.Message.PB.gp_home_op_req
    local msg = client_msg.gp_home_op_req()
    msg.home_owner = globalGame:GetHostPlayerID()
    msg.op = CONSTANT_DEFINE.HOME_OP_TYPE.HOME_OP_BUTLER
    msg.butler.people_tid = people_tid
	local succ = pb_helper.Send(msg)
	if succ then
		self.m_bOptLock = true
	end

	return true
end

---@param self ECHomeManager
---@param owner_id string
---@param info pb.Message.PB.home_butler_t
---@return void
def.method("string", "table").S2C_Butler = function(self, owner_id, info)
	if owner_id == ECGame.Instance():GetHostPlayerID() then
		ECHomeHouseKeeper.Instance():OnButlerMsg(info)
	else
		local otherInfo = self.m_HomeInfoMap:Get(owner_id)
		if not otherInfo then
			otherInfo = {}
			self.m_HomeInfoMap:Set(owner_id, otherInfo)
		end
		otherInfo.house_keeper = info.people_tid
	end
end

---@param self ECHomeManager
---@param owner_id string
---@param info pb.Message.PB.db_ref_home.VisitorInfo
---@return void
def.method("string", "table").S2C_VisitInfo = function(self, owner_id, info)
	if owner_id == globalGame:GetHostPlayerID() then
		ECHomeHouseKeeper.Instance():OnNewVisitInfo(info)
	end
end

-- 派遣幻灵
---@param self ECHomeManager
---@param src_room_index number
---@param dst_room_index number
---@param people_tid number
---@return boolean
def.method("number", "number", "number", "=>", "boolean").C2S_DispatchPeople = function(self, src_room_index, dst_room_index, people_tid)
	if not self:OperationCheck(false) then
		return false
	end

	---@type pb.Message.PB.gp_home_op_req
	local msg = client_msg.gp_home_op_req()
	msg.home_owner = globalGame:GetHostPlayerID()
	msg.op = CONSTANT_DEFINE.HOME_OP_TYPE.HOME_OP_DISPATCH
	msg.dispatch.src_room_index = src_room_index
	msg.dispatch.dst_room_index = dst_room_index
	msg.dispatch.people_tid = people_tid
	local succ = pb_helper.Send(msg)
	if succ then
		self.m_bOptLock = true
	end

	return true
end

---@param self ECHomeManager
---@param list table
---@return boolean
def.method("table", "=>", "boolean").C2S_DispatchPeoples = function(self, list)
	if not self:OperationCheck(false) then
		return false
	end

	for _, v in ipairs(list) do
		---@type pb.Message.PB.gp_home_op_req
		local msg = client_msg.gp_home_op_req()
		msg.home_owner = globalGame:GetHostPlayerID()
		msg.op = CONSTANT_DEFINE.HOME_OP_TYPE.HOME_OP_DISPATCH
		msg.dispatch.src_room_index = v.src_room_index
		msg.dispatch.dst_room_index = v.dst_room_index
		msg.dispatch.people_tid = v.people_tid
		pb_helper.Send(msg)
	end

	self.m_bOptLock = true
	return true
end

---@param self ECHomeManager
---@param op number
---@param room_index number
---@param order_tid number
---@param order_index number
---@return boolean
def.method("number", "number", "number", "number", "=>", "boolean").C2S_DispatchOrder = function(self, op, room_index, order_tid, order_index)
	if not self:OperationCheck(false) then
		return false
	end

	---@type pb.Message.PB.gp_home_op_req
	local msg = client_msg.gp_home_op_req()
	msg.home_owner = globalGame:GetHostPlayerID()
	msg.op = CONSTANT_DEFINE.HOME_OP_TYPE.HOME_OP_DISPATCH_ORDER
	msg.dispatch_order.op = op
	msg.dispatch_order.room_index = room_index
	msg.dispatch_order.order_tid = order_tid
	msg.dispatch_order.order_index = order_index
	local succ = pb_helper.Send(msg)
	if succ then
		self.m_bOptLock = true
	end

	return true
end

---@param self ECHomeManager
---@param room_index number
---@param func_type number
---@return boolean
def.method("number", "number", "=>", "boolean").C2S_ReformRoom = function(self, room_index, func_type)
	if not self:OperationCheck(false) then
		return false
	end

	---@type pb.Message.PB.gp_home_op_req
	local msg = client_msg.gp_home_op_req()
	msg.home_owner = globalGame:GetHostPlayerID()
	msg.op = CONSTANT_DEFINE.HOME_OP_TYPE.HOME_OP_ROOM_REFORM
	msg.room_reform.room_index = room_index
	msg.room_reform.func = func_type
	local succ = pb_helper.Send(msg)
	if succ then
		self.m_bOptLock = true
	end

	return true
end

---@param self ECHomeManager
---@param owner_id string
---@param room_map table<number, pb.Message.PB.room_info>
---@return void
def.method("string", "table").S2C_RoomRefresh = function(self, owner_id, room_map)
	if owner_id == globalGame:GetHostPlayerID() then
		ECHomeProduce.Instance():OnRoomInfo(room_map)

		local ECHomeRoomUnlock = require "Home.Misc.ECHomeRoomUnlock"
		for put_index, room_info in pairs(room_map) do
			if not ECHomeRoomUnlock.Instance():IsRoomUnlock(put_index) and room_info.unlocked then
				local info = {}
				info.roomid = room_info.roomid
				info.put_index = put_index
				ECHomeRoomUnlock.Instance():OnHomeRoomUnlock(info)
			end
		end
	end
end

---@param self ECHomeManager
---@param owner_id string
---@param dispatch_param pb.Message.PB.db_ref_home.DispatchParam
---@return void
def.method("string", "table").S2C_DispatchParam = function(self, owner_id, dispatch_param)
	if owner_id == globalGame:GetHostPlayerID() then
		ECHomeProduce.Instance():OnDispatchParam(dispatch_param)
	end
end

-- 幻灵刷新
---@param self ECHomeManager
---@param owner_id string
---@param people_map table<number, pb.Message.PB.db_ref_home.PeopleInfo>
---@param del_people_list number[]
---@return void
def.method("string", "table", "table").S2C_PeopleRefresh = function(self, owner_id, people_map, del_people_list)
	if owner_id == globalGame:GetHostPlayerID() then
		ECHomeProduce.Instance():OnPeopleRefresh(people_map, del_people_list)
	end
end

---@param self ECHomeManager
---@param tech_tid number
---@param op number
---@return boolean
def.method("number", "number", "=>", "boolean").C2S_HomeResearch = function(self, tech_tid, op)
	if not self:OperationCheck(false) then
		return false
	end

	---@type pb.Message.PB.gp_home_op_req
	local msg = client_msg.gp_home_op_req()
	msg.home_owner = globalGame:GetHostPlayerID()
	msg.op = CONSTANT_DEFINE.HOME_OP_TYPE.HOME_OP_RESEARCH
	msg.research.tech_tid = tech_tid
	msg.research.op = op
	local succ = pb_helper.Send(msg)
	if succ then
		self.m_bOptLock = true
	end

	return true
end

---@param self ECHomeManager
---@param home_owner string
---@param research_info pb.Message.PB.db_ref_home.ResearchingInfo
---@param active_research_tids table
---@return void
def.method("string", "table", "table").S2C_ResearchRefresh = function(self, home_owner, research_info, active_research_tids)
	if home_owner == globalGame:GetHostPlayerID() then
		if research_info ~= nil and research_info.tech_tid > 0 and research_info.state == 1 and research_info.end_ts > GameUtil.GetServerGMTTime() then
			self.m_HostHomeInfo.researching_info = research_info
		else
			self.m_HostHomeInfo.researching_info = nil
		end
		ECHomeProduce.Instance():OnResearchRefresh(research_info, active_research_tids)
	end
end

---@param self ECHomeManager
---@param home_owner string
---@param active_order_tids table
---@return void
def.method("string", "table").S2C_ActiveOrderRefresh = function(self, home_owner, active_order_tids)
	if home_owner == globalGame:GetHostPlayerID() then
		ECHomeProduce.Instance():OnActiveOrderRefresh(active_order_tids)
	end
end

---@param self ECHomeManager
---@param home_owner string
---@return void
def.method("string").S2C_SpeedListClear = function(self, home_owner)
	--if home_owner == globalGame:GetHostPlayerID() then
		ECHomeProduce.Instance():OnClearSpeedList()
	--end
end

---@param self ECHomeManager
---@return boolean
def.method("=>", "boolean").C2S_SpeedUp = function(self)
	if not self:OperationCheck(false) then
		return false
	end

	---@type pb.Message.PB.gp_home_op_req
	local msg = client_msg.gp_home_op_req()
	msg.home_owner = self.m_OwnerRoleID
	msg.op = CONSTANT_DEFINE.HOME_OP_TYPE.HOME_OP_SPEED
	local succ = pb_helper.Send(msg)
	if succ then
		self.m_bOptLock = true
	end

	return true
end

---@param self ECHomeManager
---@param home_owner string
---@param speed_up_map table
---@return void
def.method("string", "table").S2C_SpeedUp = function(self, home_owner, speed_up_map)
	FlashTipMan.FlashTip(StringTable.Get(91063))

	--if home_owner == globalGame:GetHostPlayerID() then
		ECHomeProduce.Instance():OnSpeedUpMap(speed_up_map)
	--end
end

---@param self ECHomeManager
---@param home_owner string
---@param repu_map table
---@return void
def.method("string", "table").S2C_Reputation = function(self, home_owner, repu_map)
	local homeInfo = self:GetHomeInfo(home_owner)
	if homeInfo ~= nil then
		for tid, repu in pairs(repu_map) do
			homeInfo.repus[tid] = LuaUInt64.ToDouble(repu.value)
		end
		ECGame.EventManager:raiseEvent(nil, HomeEvents.HomeInfoEvent.new(home_owner))
	end
end

---@param self ECHomeManager
---@param rwd_type number
---@param rwd_map table
---@return void
def.method("number", "table").S2C_RewardInform = function(self, rwd_type, rwd_map)
	local REWARD_TYPE = client_msg.gp_home_op_res.REWARD_TYPE
	-- 订单奖励
	if rwd_type == REWARD_TYPE.RT_DISPATCH_ORDER then
		local reward_tid_list, reward_count_list = {}, {}
		for tid, count in pairs(rwd_map) do
			table.insert(reward_tid_list, tid)
			table.insert(reward_count_list, count)
		end
		require "GUI.Common.ECPanelRewardShowSimple".Instance():ShowWithCommonRewardListAndCountList(reward_tid_list, reward_count_list)
	end
end

-- 获取当前家园场景的序列化后数据
---@param self ECHomeManager
---@return boolean,string
def.method("=>", "boolean", "string").GetHomeSerializedData = function(self)
	local succ, relation, bCompressed, relation_origin = self:SerializeRelationData(false)
	if not succ or not self:CheckRelationIsOK(relation_origin,{}, true) then
		return false, ""
	end

	local homeType = self:GetHomeType()

	local msg = db_msg.db_ref_home()
	if homeType == CONSTANT_DEFINE.HOME_TYPE.HT_INDOOR then
		msg.relation = relation
	else
		msg.out_relation = relation
	end

	local ownedObjMaps = ECHomeData.Instance():GenOwnedObjMaps()
	for tid, owned_obj_info in pairs(ownedObjMaps) do
		---@type pb.Message.PB.owned_obj_info
		local info = msg.owned_objs_map:add(tid)
		info.total_cnt = owned_obj_info.total_cnt
		info.put_cnt = owned_obj_info.put_cnt
		for put_index, put_info in pairs(owned_obj_info.put_objs_map) do
			---@type pb.Message.PB.put_obj_t
			local put_obj
			if homeType == CONSTANT_DEFINE.HOME_TYPE.HT_INDOOR then
				put_obj = info.put_objs_map:add(put_index)
			else
				put_obj = info.out_put_objs_map:add(put_index)
			end
			put_obj.put_index = put_index
			put_obj.count = put_info.count
			put_obj.client_put_data = put_info.client_put_data
		end
	end

	return true, msg:SerializeToString()
end

-- 保存当前家园数据到文件（服务器用模板数据）
---@param self ECHomeManager
---@param empty_template boolean
---@return void
def.method("boolean").SaveHomeDataToTemplateFile = function(self, empty_template)
	local cur_scene_id = globalGame:GetCurrentSceneID()
	local isOK, mapData = self:GetHomeSerializedData()
	if isOK then
		local filename = GameUtil.GetAssetsPath() .. string.format("/userdata/home/%d_%s", cur_scene_id, empty_template and "empty" or "preset")
		WriteToFile(filename, mapData, true)
		print(("Home preset data(scene_id=%d) has been saved to %s!"):format(cur_scene_id, filename))
	else
		warn(("Failed to serialize the home data(scene_id=%d)!"):format(cur_scene_id))
	end
end

-- 将当前所生成的家园模板数据合并到一个服务器配置文件
---@param self ECHomeManager
---@return void
def.method().MergeAllHomeTemplates = function(self)
	local allTemplates = {}
	local home_scene_list = ECHomeConfig.GetHomeSceneList()
	local function readFileContent (path)
		local fin = io.open(path, "rb")
		if not fin then
			return nil
		end
		local content = fin:read("*a")
		fin:close()
		return content
	end
	for _, scene_id in ipairs(home_scene_list) do
		local scene_data = {}
		local empty_file_path = GameUtil.GetAssetsPath() .. string.format("/userdata/home/%d_empty", scene_id)
		local empty_file_content = readFileContent(empty_file_path)
		scene_data.empty = string.toHexString(empty_file_content)
		local preset_file_path = GameUtil.GetAssetsPath() .. string.format("/userdata/home/%d_preset", scene_id)
		local preset_file_content = readFileContent(preset_file_path)
		scene_data.preset = string.toHexString(preset_file_content)
		allTemplates[scene_id] = scene_data
	end

	local file_prefix = [[
-- AUTO-GENERATED BY PROGRAM, DONOT MODIFY MANUALLY!!!
local home_templates =
]]
	local file_postfix = "return home_templates"
	local file_body = table.dump_to_string(allTemplates, false, {no_quotation = true})
	local file_content = file_prefix..file_body.."\n\n"..file_postfix
	local filename = GameUtil.GetAssetsPath().."/userdata/home/home_templates.lua"
	WriteToFile(filename, file_content)
	print("All home template data have been saved to "..filename.."!")
end

---@param self ECHomeManager
---@param templ_file string
---@return void
def.method("string").DumpHomeTemplateFile = function(self, templ_file)
	local file_path = GameUtil.GetAssetsPath() .. string.format("/Configs/common/home_templates/%s", templ_file)
	local f = io.open(file_path, "rb")
	if not f then
		return
	end

	local content = f:read("*a")
	f:close()

	local msg = db_msg.db_ref_home()
	msg:ParseFromString(content)
	print(msg)

	local rel = db_msg.hometown_relation_t()
	rel:ParseFromString(msg.relation)
	print(rel)
end

-- 升级旧版的室外家园模板文件
---@param self ECHomeManager
---@param templ_file string
---@return void
def.method("string").UpgradeOutdoorHomeTemplateFile = function(self, templ_file)
	local file_path = GameUtil.GetAssetsPath() .. string.format("/Userdata/home/%s", templ_file)
	local f = io.open(file_path, "rb")
	if not f then
		return
	end

	local content = f:read("*a")
	f:close()

	---@type pb.Message.PB.db_ref_home
	local msg = db_msg.db_ref_home()
	msg:ParseFromString(content)

	if msg.out_relation ~= "" then
		print("The data is already new!")
		return
	end

	local relation, relation_sourcelen, relation_compress = msg.relation, msg.relation_sourcelen, msg.relation_compress
	msg.out_relation = relation
	msg.out_relation_sourcelen = relation_sourcelen
	msg.out_relation_compress = relation_compress
	msg.relation = ""
	msg.relation_sourcelen = 0
	msg.relation_compress = false

	for _, owned_objs in pairs(msg.owned_objs_map) do
		for put_index, put_obj in pairs(owned_objs.put_objs_map) do
			---@type pb.Message.PB.put_obj_t
			local new_put_obj = owned_objs.out_put_objs_map:add(put_index)
			new_put_obj.put_index = put_obj.put_index
			new_put_obj.count = put_obj.count
			new_put_obj.client_put_data = put_obj.client_put_data
		end
		owned_objs:ClearField("put_objs_map")
	end

	--print(msg)

	local filename = file_path .. "_new"
	WriteToFile(filename, msg:SerializeToString(), true)
	print(("Home preset data(%s) has been upgrade to %s!"):format(templ_file, filename))
end

---@param self ECHomeManager
---@param tmpl_file string
---@return void
def.method("string").LoadHomeTemplateFromFile = function(self, tmpl_file)
	local file_path = GameUtil.GetAssetsPath() .. string.format("/Userdata/home/%s", tmpl_file)
	local f = io.open(file_path, "rb")
	if not f then
		return
	end

	local content = f:read("*a")
	f:close()

	---@type pb.Message.PB.db_ref_home
	local msg = db_msg.db_ref_home()
	msg:ParseFromString(content)

	local homeType = self:GetHomeType()
	self:S2C_HomeData(msg, homeType, false)
end

---@param self ECHomeManager
---@param relation string
---@param exclude_tab table
---@param checkView boolean
---@return boolean
def.method("string", "table", "boolean", "=>", "boolean").CheckRelationIsOK = function(self, relation, exclude_tab, checkView)
	local element = ECHomeElementRel.CreateFromBytes(relation)

	-- 检查是否有基本的节点
	if not element then
		warn("CheckRelationIsOK_Ex, root node is nil!!!")
		FlashTipMan.FlashTip(homeCfg.tips[9] or "")
		return false
	else
		-- 检查每一层
		for i=1, ECHomeData.Instance().m_TotalFloors do
			local floorPutIndex = _G.HOME_ROOT_PUT_INDEX + i
			if not element.children[floorPutIndex] then
				warn(("CheckRelationIsOK_Ex, floor (%d) node is nil!!!"):format(i))
				FlashTipMan.FlashTip(homeCfg.tips[9] or "")
				return false
			end
		end

		-- 地下室
		local floorPutIndex = _G.BASEMENT_PUT_INDEX
		if not element.children[floorPutIndex] then
			warn("CheckRelationIsOK_Ex, basement floor node is nil!!!")
			FlashTipMan.FlashTip(homeCfg.tips[9] or "")
			return false
		end
	end

	return self:CheckRelationIsOK_Element(element, exclude_tab, checkView)
end

---@param self ECHomeManager
---@param e ECHomeElementRel
---@param exclude_tab table
---@param checkView boolean
---@return boolean
def.method(ECHomeElementRel, "table", "boolean", "=>", "boolean").CheckRelationIsOK_Element = function(self, e, exclude_tab, checkView)
	if not e or exclude_tab[e.put_index] then
		return true
	end

	local dataNode = ECHomeData.Instance():GetNodeByPutIndex(e.put_index)
	if not dataNode then
		warn(("CheckRelationIsOK_Element: cannot find data node by put_index(%d)!!!"):format(e.put_index))
		FlashTipMan.FlashTip(homeCfg.tips[9] or "")
		return false
	end

	local viewNode = ECHomeView.Instance():GetViewNodeByPutIndex(e.put_index)
	if not viewNode and checkView then
		warn(("CheckRelationIsOK_Element: cannot find view node by put_index(%d)!!!"):format(e.put_index))
		FlashTipMan.FlashTip(homeCfg.tips[9] or "")
		return false
	end

	if e.type == _G.ECHOME_ELEMENT_TYPE_ENUM.HOME then
		if checkView then
			local ECHomeObj = require "Home.View.ECHomeObj"
			if not viewNode:is(ECHomeObj) then
				warn(("CheckRelationIsOK_Element: root node (%d) is not ECHomeObj!!!"):format(e.put_index))
				FlashTipMan.FlashTip(homeCfg.tips[9] or "")
				return false
			end
		end
	elseif e.type == _G.ECHOME_ELEMENT_TYPE_ENUM.FLOOR then
		if checkView then
			local ECFloorObj = require "Home.View.ECFloorObj"
			if not viewNode:is(ECFloorObj) then
				warn(("CheckRelationIsOK_Element: floor node (%d) is not a ECFloorObj!!!"):format(e.put_index))
				FlashTipMan.FlashTip(homeCfg.tips[9] or "")
				return false
			end

			---@type ECHomeObj
			local home = viewNode.Parent
			---@type ECFloorObj
			local floor = viewNode
			if floor ~= home.OrderFloors[floor.Index] then
				warn(("CheckRelationIsOK_Element: (%d) floor ~= home.OrderFloors[floor.Index]!!!"):format(e.put_index))
				FlashTipMan.FlashTip(homeCfg.tips[9] or "")
				return false
			end
		end
	elseif e.type == _G.ECHOME_ELEMENT_TYPE_ENUM.BASEMENT then
		if checkView then
			local ECFloorObj = require "Home.View.ECFloorObj"
			if not viewNode:is(ECFloorObj) then
				warn(("CheckRelationIsOK_Element: floor node (%d) is not a ECFloorObj!!!"):format(e.put_index))
				FlashTipMan.FlashTip(homeCfg.tips[9] or "")
				return false
			end

			---@type ECHomeObj
			local home = viewNode.Parent
			---@type ECFloorObj
			local floor = viewNode
			if floor ~= home.Basement then
				warn(("CheckRelationIsOK_Element: (%d) floor ~= home.Basement!!!"):format(e.put_index))
				FlashTipMan.FlashTip(homeCfg.tips[9] or "")
				return false
			end
		end
	elseif e.type == _G.ECHOME_ELEMENT_TYPE_ENUM.LINK then
		if checkView then
			---@type ECHomeNodeLink
			local dataLink = dataNode
			---@type ECLinkBaseObj
			local link = viewNode
			if #dataLink.walls ~= link.WallCount then
				warn(("CheckRelationIsOK_Element: (%d) #dataLink.walls ~= link.WallCount!!!"):format(e.put_index, #dataLink.walls, link.WallCount))
				FlashTipMan.FlashTip(homeCfg.tips[9] or "")
				return false
			end
		end
	elseif e.type == _G.ECHOME_ELEMENT_TYPE_ENUM.ITEM then
		---@type ECHomeNodeItem
		local item = dataNode
		local parent_e = e.parent
		if parent_e.put_index ~= item.parent_put_index then
			warn(("CheckRelationIsOK_Element: (%d) parent_e.put_index ~= item.parent_put_index!!!"):format(e.put_index, parent_e.put_index, item.parent_put_index))
			FlashTipMan.FlashTip(homeCfg.tips[9] or "")
			return false
		end
	end

	for _, child in pairs(e.children) do
		if not self:CheckRelationIsOK_Element(child, exclude_tab, checkView) then
			return false
		end
	end

	return true
end

---@param self ECHomeManager
---@param ownerID string
---@param merchant_data table
---@return void
def.method("string", "table").S2C_MerchantInfo = function(self, ownerID, merchant_data)
	local data = self:GetHomeInfo(ownerID)
	if data == nil then
		return
	end

	local different = data.merchant_tid ~= merchant_data.merchant_tid or data.merchant_leave_ts ~= merchant_data.merchant_leave_ts
	data.merchant_tid = merchant_data.merchant_tid
	data.merchant_leave_ts = merchant_data.merchant_leave_ts
	data.merchant_position = merchant_data.real_pos
	if different then
		ECGame.EventManager:raiseEvent(nil, HomeEvents.MerchantUpdateEvent.New(ownerID, merchant_data.merchant_tid, merchant_data.merchant_leave_ts))
	end
end

---@param self ECHomeManager
---@param ownerID string
---@param npc_tid number
---@param leave_time number
---@return void
def.method("string", "number", "number").UpdateMerchantInfo = function(self, ownerID, npc_tid, leave_time)
	local data = self:GetHomeInfo(ownerID)
	if data == nil then
		return
	end

	local different = data.merchant_tid ~= npc_tid or data.merchant_leave_ts ~= leave_time
	data.merchant_tid = npc_tid
	data.merchant_leave_ts = leave_time
	if different then
		ECGame.EventManager:raiseEvent(nil, HomeEvents.MerchantUpdateEvent.New(ownerID, npc_tid, leave_time))
	end
end

---@param self ECHomeManager
---@param ownerID string
---@return number,number
def.method("string", "=>", "number", "number").GetMerchantInfo = function(self, ownerID)
	local data = self:GetHomeInfo(ownerID)
	if data == nil then
		return 0, 0
	end
	local merchant_tid = data.merchant_tid or 0
	local merchant_leave_ts = data.merchant_leave_ts or 0
	return merchant_tid, merchant_leave_ts
end

---@param self ECHomeManager
---@param ownerID string
---@return table
def.method("string", "=>", "table").GetMerchantPosition = function(self, ownerID)
	local data = self:GetHomeInfo(ownerID)
	if data == nil then
		return nil
	end
	return data.merchant_position
end

---@param self ECHomeManager
---@return void
def.method().TalkToMerchant = function(self)
	if not self:IsInHome() then
		return
	end
	if ECHomeManager.Instance():GetHomeType() == CONSTANT_DEFINE.HOME_TYPE.HT_OUTDOOR then
		local unlock_indoor = false
		local enter_roleId
		if self:IsInMyHome() then
			unlock_indoor = ECHomeManager.Instance():GetSceneUnlockStatus()
		else
			enter_roleId = ECHomeManager.Instance():GetHomeOwnerID()
			local home_info = ECHomeManager.Instance():GetHomeInfo(ECHomeManager.Instance():GetHomeOwnerID())
			unlock_indoor = home_info ~= nil and home_info.unlock_indoor or false
		end
		-- 没解锁室内的话不会有商人
		if unlock_indoor then
			MsgBox.ShowMsgBox(nil, StringTable.Get(91106), "", MsgBox.MsgBoxType.MBBT_OKCANCEL, function(sender, result)
				if result ~= MsgBox.MsgBoxRetT.MBRT_OK then
					return
				end
				local Task = require "Utility.Task"
				local ECPanelDoorOpen = require "GUI.Misc.ECPanelDoorOpen"
				local ECAsyncTask = require "Utility.ECAsyncTask"
				local task = Task.createStepsEx(function(task, step)
					if step == 1 then
						if not enter_roleId then
							ECHomeManager.Instance():EnterMyHome(true)
						else
							ECHomeManager.Instance():EnterOtherHome(enter_roleId, true)
						end
						return "continue"
					elseif step == 2 then
						return function(task, resumeEntry)
							ECPanelDoorOpen.Instance():OpenPanel(1, function(finish)
								if finish then
									resumeEntry()
								end
							end)
						end
					elseif step == 3 then
						self:TalkToMerchant()
						return "continue"
					else
						return "end"
					end
				end, function(task)
					ECPanelDoorOpen.Instance():DestroyPanel()
					return "stop"
				end)
				ECAsyncTask.AddTimeLimit(task, 20)
				task:start()
			end)
		end
		return
	end
	local tid, leave_time = self:GetMerchantInfo(self.m_OwnerRoleID)
	if tid <= 0 or leave_time <= GameUtil.GetServerGMTTime() then
		return
	end
	local position = self:GetMerchantPosition(self.m_OwnerRoleID)
	if position == nil then
		local npc = globalGame:GetCurWorld():GetNPCMan():FindNearestNPCByTid(tid, false)
		if npc == nil then
			return
		end
		position = npc:GetPos()
	end
	local npcTalkDistanceConfig = require "Configs.DistanceConfig".GetNPCTalkDistanceConfigById(tid)
	---@type ECAutoMoveParam
	local ECAutoMoveParam = Lplus.ForwardDeclare("ECAutoMoveParam")
	local amParam = ECAutoMoveParam.New()
	amParam.afterFindRouteFailed = ECAutoMoveParam.AfterFindRouteFailed.DirectMoveToPosInCurrentScene
	amParam.afterFindWayFailedDestMark = false
	local task = require "Players.ECHostAsyncTask".AutoMoveToPosInCurrentScene(position.x, position.y, position.z, npcTalkDistanceConfig.NPC_TALK_STOP_DISTANCE, npcTalkDistanceConfig.NPC_TALK_STOP_DISTANCE, amParam)
	task:continueWith(function ()
		local npc = globalGame:GetCurWorld():GetNPCMan():FindNearestNPCByTid(tid, false)
		if npc == nil or npc:GetDistToHost() > 5 then
			return
		end

		globalGame:SendGameData(require "C2S.service_hello".new(npc:GetID()))
		require "BehaviorRecords.BehaviorRecordsManager".Instance():RecordBehavior("NpcSayHello", { id = tid })

		local S2CManager = require "S2C.S2CManager"
		local npc_greeting = require "S2C.npc_greeting"
		local function onNpcGreeting (sender, cmd)
			S2CManager.RemoveHandler(npc_greeting, onNpcGreeting)
			---@type ECHostPlayer
			local hostPlayer = globalGame:GetHostPlayer()
			if hostPlayer == nil or hostPlayer.HostOpHdl == nil then
				return
			end
			hostPlayer.HostOpHdl:EndNPCService(true)
			---@type ECWorld
			local world = globalGame:GetCurWorld()
			if world ~= nil and world:FindObject(cmd.idObject) ~= nil then
				hostPlayer.HostOpHdl:StartNPCService(cmd.idObject, true, nil)
			end
		end
		S2CManager.AddHandler(npc_greeting, onNpcGreeting)
		GameUtil.AddGlobalTimer(3, true, function () S2CManager.RemoveHandler(npc_greeting, onNpcGreeting) end)
	end)
	task:start()
end

---@param self ECHomeManager
---@param ownerID string
---@param unlock_indoor_info table
---@return void
def.method("string", "table").S2C_UnlockIndoorInfo = function(self, ownerID, unlock_indoor_info)
	local data = self:GetHomeInfo(ownerID)
	if data == nil then
		return
	end

	data.unlock_indoor_info = unlock_indoor_info
	ECGame.EventManager:raiseEvent(nil, HomeEvents.UnlockIndoorUpdateEvent.New(ownerID))
end

---@param self ECHomeManager
---@param ownerID string
---@param obj_unlock_info pb.Message.PB.home_obj_unlock_t
---@return void
def.method("string", "table").S2C_ObjUnlock = function(self, ownerID, obj_unlock_info)
	local data = self:GetHomeInfo(ownerID)
	if data == nil then
		return
	end

    local objHomeData = ECHomeData.Instance():GetHomeDataByTid(obj_unlock_info.tid)
	if objHomeData then
		objHomeData.unlock_count = objHomeData.unlock_count + 1
	end
end

---@param self ECHomeManager
---@return number
def.method("=>", "number").GetUnlockIndoorRemainTime = function(self)
	local remain = 0
	local unlock_indoor_info = self.m_HostHomeInfo.unlock_indoor_info
	if unlock_indoor_info ~= nil and type(unlock_indoor_info.unlock_indoor_end_ts) == "number" and unlock_indoor_info.unlock_indoor_end_ts ~= 0 then
		remain = math.max(unlock_indoor_info.unlock_indoor_end_ts - GameUtil.GetServerGMTTime(), 0)
	else
		local tmpl = ECHomeConfig.GetHomeConfig()
		for i, phase in ipairs(tmpl.unlock_indoor_phases) do
			remain = remain + phase.cost_seconds
		end
	end
	return remain
end

---@param self ECHomeManager
---@return boolean
def.method("=>", "boolean").CheckTaskPageNeedActive = function(self)
	local isUnlocked = self:IsUnlocked()
	if not isUnlocked then
		return false
	end

	return self:GetTaskCount() >0
end

---@param self ECHomeManager
---@return number
def.method("=>", "number").GetTaskCount = function(self)
	---@type pb.Message.PB.HomeConfig
	local cfg = ElementData.getConfig(homeCfg.homeConfigTid)
	if not cfg then
		return 0
	end

	local curLevel = self:GetHostHomeLevel()

	if not cfg.level_param[curLevel] then
		return 0
	end

	return cfg.level_param[curLevel].people_task_count
end
---@param self ECHomeManager
---@return number
def.method("=>", "number").GetTaskCountRemain = function(self)
	if not globalGame:GetHostPlayer() then
		return 0
	end
	local repu = globalGame:GetHostPlayer():GetReputation(homeCfg.TaskRepu)
	local remain = math.max(repu - 1, 0)
	return remain
end

---@param self ECHomeManager
---@return table
def.method("=>", "table").GetExtendCfgNpcInfoList = function(self)
	local list = {}
	local npcList
	npcList = homeCfg.map.roomCfg.npcList
	if npcList then
		local ECObjGenDatabase = require "Scene.ECObjGenDatabase"
		for npcTid, v in pairs(npcList) do
			local hasGenData, scene_tag, x, y, z = ECObjGenDatabase.Instance():GetPosByNPCTid(npcTid)
			if hasGenData then
				---@type ECHomeDynamicNPCPosData.NpcData
				local itemInfo = {}
				itemInfo.tid = npcTid
				itemInfo.pos = _Vector3Ctor_(x, y, z)
				itemInfo.service_state_mask = 0
				table.insert(list, itemInfo)
			end
		end
	end

	return list
end

---@param self ECHomeManager
---@return table
def.method("=>", "table").GetMerchantPosInfo = function(self)
	--if ECHomeManager.Instance():GetHomeType() == CONSTANT_DEFINE.HOME_TYPE.HT_OUTDOOR then return nil end

	local npcTid =  self:GetMerchantInfo(self:GetHomeOwnerID())
	---@type ECHomeDynamicNPCPosData.NpcData
	local npcPosInfo
	if npcTid and npcTid ~= 0 then
		local pos = self:GetMerchantPosition(self:GetHomeOwnerID())
		if pos then
			npcPosInfo = {}
			npcPosInfo.tid = npcTid
			npcPosInfo.pos = A3dPosToVector3(pos)
			npcPosInfo.service_state_mask = 0
		end
	end
	return npcPosInfo
end

---@param self ECHomeManager
---@param npcTid number
---@return number,any
def.method("number", "=>", "number", "dynamic").CalcTaskIcon = function (self, npcTid)
	local ECTaskUtility = require "Task.ECTaskUtility"
	local TaskListItem = require "Task.TaskListItem"
	local npcEss = ElementData.getDataByConfigType(CONSTANT_DEFINE.CONFIG_TYPE.CONFIG_NPC, npcTid)
	if not npcEss then
		return TaskListItem.FunctionType.INVALID, 0
	end

	local iconType, funcType = ECTaskUtility.GetNPCTaskIcon(npcEss, nil)
	if funcType == TaskListItem.FunctionType.INVALID then
		return TaskListItem.FunctionType.INVALID, 0
	end
	local atlas, sprite = ECTaskUtility.GetTaskMarkIcon(iconType, funcType)
	return funcType, {atlas=atlas, sprite=sprite}
end

---@param self ECHomeManager
---@return table
def.method("=>", "table").GetAllTaskNPCList = function(self)
	local caches_dict = {}
	local function cacheAllTask(info)
		if info.tid ~= 0 then
			if not caches_dict[info.tid] then
				caches_dict[info.tid] = info --key is npc tid
			end
		end
	end

	for _, info in ipairs(self:GetExtendCfgNpcInfoList()) do
		cacheAllTask(info)
	end
	local ECHomeDynamicNPCPosData = require "Home.Misc.ECHomeDynamicNPCPosData"
	for _, info in ipairs(ECHomeDynamicNPCPosData.Get():GetPosList()) do
		cacheAllTask(info)
	end

	local merchantPosInfo = self:GetMerchantPosInfo()
	if merchantPosInfo then
		cacheAllTask(merchantPosInfo)
	end

	if _G.LogDef.lidengfeng.value then
		print_r(caches_dict)
	end

	local ECTaskInterface = require "Task.ECTaskInterface"
	local TaskListItem = require "Task.TaskListItem"

	local results = {}
	for i, v in ipairs(home_task) do
		local task_id = v.task_id
		local taskCfg = ECTaskInterface.GetTaskConfig(task_id)
		if ECTaskInterface.HasTask(task_id) then --任务已经接取了
			local finish_task_npc = taskCfg.property.finish_task_npc
			local d = _G.DeepCopyTable(v)
			d.sort_index = i
			local info = caches_dict[finish_task_npc]
			if info then
				d.pos = info.pos
			end
			table.insert(results, d)
		else
			local recive_stask_npc = taskCfg.property.recive_stask_npc
			local info = caches_dict[recive_stask_npc]
			if info then
				local taskFuncType, taskIcon = ECHomeManager.Instance():CalcTaskIcon(recive_stask_npc)
				local hasTask = taskFuncType ~= TaskListItem.FunctionType.INVALID and bit.band(info.service_state_mask, NPC_SERVICE_STATE_MASK.Forbid_Task_Out) == 0
				if hasTask then
					local d = _G.DeepCopyTable(v)
					d.sort_index = i
					d.pos = info.pos
					table.insert(results, d)
				end
			end
		end
	end

	return results
end

---@param task_id number
---@return boolean
def.static("number", "=>", "boolean").FilterTaskFromConfig = function(task_id)
	return not not __all_tasks[task_id]
end





return ECHomeManager.Commit()