if _G.MarkReloadAfterUpdate then _G.MarkReloadAfterUpdate() end

local g_szPckDir = -- 同步修改 AzureEngine/Azure/Patcher/elementpckdir.h
{
	["automove"]	=	"package/automove.png",
	["configs"]		=	"package/configs.png",
	["data"]		=	"package/data.png",
	["effects"]		=	"package/effects.png",
	["lua"]			=	"package/lua.png",
	["maps"]		=	"package/maps.png",
	["buildings"]   =   "package/buildings.png",
	["models"]		=	"package/models.png",
	["miscs"]		=	"package/miscs.png",
	["scenes"]		=	"package/scenes.png",
	["sound"]		=	"package/sound.png",
	["ui"]			=	"package/ui.png",
	["cinematics"]	=	"package/cinematics.png",
	["shadercode"]	=	"package/shadercode.png",
	["engine"]		=	"package/engine.png",
	["localization"]		=	"package/localization.png",
}

--if GameUtil.GetPlatformName() == "Windows" then
--	g_szPckDir["procedural_ecosystem"] = "package/procedural_ecosystem.png"
--	g_szPckDir["templates"] = "package/templates.png"
--	g_szPckDir["watermill"] = "package/watermill.png"
--end

return g_szPckDir