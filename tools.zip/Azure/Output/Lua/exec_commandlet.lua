--[[
	EntryPoint for lua command-line applet
]]

package.loaded.Lplus_config =
{
	reflection = false,
	declare_checking = true,
	accessing_checking = true,
	calling_checking = true,
	reload = false,
}

function _G.IsEvaluation()
    return false
end

function _G.IsGovEvaluation()
    return false
end

function _G.IsWindowsSimuMobile()
    return true
end

local function Preload ()
	require "Utility.NativePatch"	--早于其他模块，以免其他模块缓存了错误的函数
	require "Utility.LuaPatch"
	require "Main.ECConfigs"	--早于其他模块，以免 Lplus 设置不对
	require "Lplus"		--早于其他模块，以免无法 reload
	require "Utility.BranchUtil"
	require "Core.preload"
	require "Utility.UE4Related"
	require "Utility.LogHelper"
	require "Utility.GlobalHook"
	require "Common.ECResPath"
	require "Utility.ProtoUtils"
	
	require "PB.constant"
	require "Common.CommonDef"
	require "Utility.ECUtility"
	require "Utility.UEEnumDefine"
	
	require "Common.ECClientDef"
	require "Common.ECSkillDef"
	require "Common.BehaviorDef"
	require "Common.QualityDef"
	require "Common.AnimDef"
	require "Common.PlayerDef"
	require "Common.WeaponDef"
	require "Common.VehicleDef"
	
	require "Commandlets.Preload"
end

local function main(entryPointParams)
	print("lua command-line applet start!")
	
	--在任何代码调用之前，设置全局环境
	_G.LuaCommandletEntryPointParams = entryPointParams
	
	Preload()

	if datapath.load_data_path("data/path.data") then
		print("load datapath ok!")
	else
		Debug.LogError("failed to load datapath")
	end

	if datatext.load_data_text("data/text.data") then
		print("load datatext ok!")
	else
		Debug.LogError("failed to load datatext")
	end

	local appletName = entryPointParams.params.LuaAppletName
	if appletName then
		local CommandletMan = require "Commandlets.CommandletMan"
		CommandletMan.Exec(appletName, entryPointParams.tokens, entryPointParams.switches,
			entryPointParams.params)
	end

	datapath.release_data_path()
	datatext.release_data_text()

	print("lua command-line applet end!")
end

local EntryPointParams = require "_EntryPointParams"
if not EntryPointParams.tokens then
	EntryPointParams.tokens = {}
end
if not EntryPointParams.switches then
	EntryPointParams.switches = {}
end
if not EntryPointParams.params then
	EntryPointParams.params = {}
end
main(EntryPointParams)