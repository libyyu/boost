local function ios_mem_1G_or_less(gen)
	return gen < _G.EIOSDevice.IOS_IPhone6S
			and gen ~= _G.EIOSDevice.IOS_IPadAir2
			and gen ~= _G.EIOSDevice.IOS_IPadMini4
end

function _G.require_config(path)
	local ret = {dofile(path)}
	return unpack(ret)
end

local  function config_engine()
	print("config_engine: execute begin")

	local config_from_designer = dofile("Configs/config_engine_for_designer.lua")
	-- def first
	dofile("Configs/PlatformDef.lua")

	local curCppVersion = 1
	if ConfigEngine.GetCurConfigCppVersion then
		curCppVersion = ConfigEngine.GetCurConfigCppVersion()
	end

	warn("curCppVersion", curCppVersion)

	local platform_name = ConfigEngine.GetPlatformName()
	print(("config_engine: platform = %s (simulate mobile: %s)"):format(platform_name, tostring(_G.IsWindowsSimuMobile())))

	--默认不启用，luajit 本身的分配器更好点
	--ConfigEngine.InitWluaCustomAllocFunc(
	--	1024 * 1024 * 24,
	--	1024 * 1024 * 1,
	--	1024 * 1024 * 36,
	--	1024 * 1024 * 1,
	--	0.1,
	--	0.1)

	dofile("Configs/ECSimulator.lua")
	_G.InitSimulatorHelper()

	-- when r.Streaming.LimitPoolSizeToVRAM is set to 1, AvailableMemoryForStreaming is limited to FPlatformMemoryStats::TotalGraphicsMemory*PoolSizeVRAMPercentage
	-- 1.for IOS metal TotalGraphicsMemory depends on available physical memory on startup, in some cases is very low (i.e. 60MB), but will increase under the scheduling of the operationg system
	-- 2.for Android non-vulkan, it's 0 and will not be considered
	-- 3.for Windows/Linux FOpenGL4, for Vulkan, for Windows D3D, it's properly evaluated
	-- so, it's a better choice to directly use r.Streaming.PoolSize
	-- r.Streaming.LimitPoolSizeToVRAM is set here, r.Streaming.PoolSize is to set later in game
	ConfigEngine.SetConsoleVariable("r.Streaming.LimitPoolSizeToVRAM", "0")
	ConfigEngine.SetConsoleVariable("r.Streaming.MaxTempMemoryAllowed", "16")

	-- 异步加载在主线程的时间消耗(ms)
	ConfigEngine.SetConsoleVariable("s.AsyncLoadingTimeLimit", 50)

	ConfigEngine.SetConsoleVariable("wwise.LowerEnginePoolSize", "4194304")--4MB
	ConfigEngine.SetConsoleVariable("wwise.DefaultPoolSize", "6291456")--6MB
	ConfigEngine.SetConsoleVariable("wwise.SpatialAudioPoolSize", "524288")--0.5MB
	ConfigEngine.SetConsoleVariable("wwise.DefaultPoolRatioThreshold", "1")
	ConfigEngine.SetConsoleVariable("wwise.LowerEnginePoolRatioThreshold", "1")
	ConfigEngine.SetConsoleVariable("wwise.EnableGameSyncPrepare", "0")
	ConfigEngine.SetConsoleVariable("wwise.MaxPoolNum", "256")
	--ConfigEngine.SetConsoleVariable("wwise.Language", "Japanese")
	ConfigEngine.SetConsoleVariable("Slate.EnableLayoutCaching", "1")
	ConfigEngine.SetConsoleVariable("r.Streaming.PoolSize", "1024")
	--开启shaderCache
	ConfigEngine.SetConsoleVariable("r.ProgramBinaryCache.Enable", "0")		--ProgramBinaryCache 已被 ProgramBinaryCookie 替换，如不关闭，ShaderPipelineCache 生效时有 bug 会崩溃
	ConfigEngine.SetConsoleVariable("r.ShaderPipelineCache.Enabled", "1")
	ConfigEngine.SetConsoleVariable("r.EyeAdaptationQuality", 0)	--kirin980、kirin990 等手机自动曝光有 bug，因此完全关闭此功能

	ConfigEngine.SetConsoleVariable("r.DisableNavigationDataDuringRuntime", "1")
	ConfigEngine.SetConsoleVariable("foliage.MinVertsToSplitNode", "8192")
	ConfigEngine.SetConsoleVariable("r.EnableUpdateSkyLight", "0")
	ConfigEngine.SetConsoleVariable("r.EnableUpdateReflectionCapture", "0")
	ConfigEngine.SetConsoleVariable("r.NeedReleaseDistortionRT", "1")
	ConfigEngine.SetConsoleVariable("r.EnableCustomStencil", "0")
	ConfigEngine.SetConsoleVariable("r.FreeSkeletalMeshBuffers", "1")
	--ConfigEngine.SetConsoleVariable("Slate.ForceBackgroundBlurLowQualityOverride", "0")	--需要为默认值，即 Android 为 1，其他为 0
	ConfigEngine.SetConsoleVariable("PlanarReflection.NeedReleaseRenderTarget", "1")
	ConfigEngine.SetConsoleVariable("r.EnableUIStencilTest", "0")
	ConfigEngine.SetConsoleVariable("r.Dof.ReleaseRenderTarget", "1")
	ConfigEngine.SetConsoleVariable("r.CustomDepth", "0")
	ConfigEngine.SetConsoleVariable("imgMedia.enable", "0")
	ConfigEngine.SetConsoleVariable("a.SafeZone.HorizontalSymmetry", 1)

	ConfigEngine.SetConsoleVariable("p.AnimBaseVelNormal", "600")
	ConfigEngine.SetConsoleVariable("p.AnimBaseVelThreshold", "1600")
	
	--未使用 UE netConnection，设置一下避免浪费内存
	ConfigEngine.SetConsoleVariable("net.MaxChannelSize", "16")

	--使动画更新频率优化功能可用 (不一定激活)
	--ConfigEngine.SetConsoleVariable("a.URO.ForceEnableInAsset", "1")
	--ConfigEngine.SetConsoleVariable("r.SkinnedAnimUpdateRate.Enable", "1")
	--需要UE原生的声音， 播放视频
	
	local forceMobileScaleFactor = nil
	
	if platform_name == "Android" then
		ConfigEngine.AppendCommandLineText(" -nosound")
		local maxCameraSpaceDepth = 1024 * 1024
		ConfigEngine.SetConsoleVariable("Slate.CameraSpaceDepth", tostring(maxCameraSpaceDepth))
		--ConfigEngine.SetConsoleVariable("r.Mobile.AzureMSAADepthResolve", "1")

		ZLUtil.init()
		
		local DISABLE_DOF_DEVICE =
		{
			"oppo r9s", --r9s 实现了opengles的一个扩展，但景深被阉割了。。会花屏
			"vivo y66",
			"vivo y79",
			"vivo x9s",
			"redmi note 4x"
		}
		
		local DISABLE_TEXTURESTREAMING_DEVICE =
		{
			"mp1605",
			"mi pad 3",
			"mi pad3",
			"pro 7 plus",
			"pro 7-h",
			"pro 7-s",
			"e3c6"
		}
		
		local DISABLE_DISCARDFRAMEBUFFER_DEVICE = 
		{
			"oppo r9s",
			"oppo r9st",
			"oppo r9sk",
			"oppo a57",
			"mla-al10",
			"vivo y66",
			"le x82"
		}
		
		local DISABLE_PROGRAMBINARYCOOKIE_DEVICE = 
		{
			"oppo r9s",
			"oppo r9st",
			"oppo r9sk",
			"oppo a57",
		}

		local REPLACE_SCENEDEPTHNODEMATERIAL_DEVICE = 
		{
			"oppo r9 plustm a",
			"vivo x9s",
			"MI 6"
		}
		
		local REPLACE_WINDOWSIZEDESIRED_DEVICE = 
		{
			--{"oppo r9st",1920,1080 },
		}
		
		local DISABLE_AUTO_EXPOSURE_DEVICE = {
			-- TODO: 目前不知道什么机型需要禁用自动曝光，列表中暂无内容
		}
		
		--按机型禁掉景深
		local deviceModel = SystemInfo.get_deviceModel():lower()
		for i=1, #DISABLE_DOF_DEVICE do
			if deviceModel:find(DISABLE_DOF_DEVICE[i]) then
				ConfigEngine.SetConsoleVariable("r.OpenGL.DisableFrameBufferFetch", "1")
				break
			end
		end
		
		--按机型禁掉Texture Streaming
		local deviceModel = SystemInfo.get_deviceModel():lower()
		for i=1, #DISABLE_TEXTURESTREAMING_DEVICE do
			if deviceModel:find(DISABLE_TEXTURESTREAMING_DEVICE[i]) then
				ConfigEngine.SetConsoleVariable("r.TextureStreaming", "0")
				break
			end
		end
		
		--按机型禁掉discard framebuffer
		for i=1, #DISABLE_DISCARDFRAMEBUFFER_DEVICE do
			if deviceModel:find(DISABLE_DISCARDFRAMEBUFFER_DEVICE[i]) then
				pcall(ConfigEngine.SetConsoleVariable,"r.OpenGL.DisableDiscardFrameBuffer", "1")
				break
			end
		end
		
		--按机型禁掉ProgramBinaryCookie
		for i=1, #DISABLE_PROGRAMBINARYCOOKIE_DEVICE do
			if deviceModel:find(DISABLE_PROGRAMBINARYCOOKIE_DEVICE[i]) then
				pcall(ConfigEngine.SetConsoleVariable,"r.ProgramBinaryCookie.Enable", "0")
				break
			end
		end

		--按机型替换掉带SceneDepth的材质
		for i=1, #REPLACE_SCENEDEPTHNODEMATERIAL_DEVICE do
			if deviceModel:find(REPLACE_SCENEDEPTHNODEMATERIAL_DEVICE[i]) then
				_G.UseSceneDepthNode = false
				break
			end
		end
		
		--按机型强制设置窗口尺寸
		for i=1, #REPLACE_WINDOWSIZEDESIRED_DEVICE do
			local deviceInfo = REPLACE_WINDOWSIZEDESIRED_DEVICE[i]
			if deviceModel == deviceInfo[1] then
				ConfigEngine.UseSurfaceViewWorkaround()
				ConfigEngine.SetOverrideResolution(deviceInfo[2],deviceInfo[3])
				break
			end
		end
		
		--按机型禁掉自动曝光
		local deviceModel = SystemInfo.get_deviceModel():lower()
		for i=1, #DISABLE_AUTO_EXPOSURE_DEVICE do
			if deviceModel:find(DISABLE_AUTO_EXPOSURE_DEVICE[i]) then
				ConfigEngine.SetConsoleVariable("r.Mobile.EyeAdaptation", "0")
				break
			end
		end
		
		--按机型开启屏幕resize
		local device_cfg = config_from_designer.RESIZE_WINDOW_ON_SURFACE_CHANGED_DEVICE[deviceModel]
		if device_cfg ~= nil then
			ConfigEngine.SetConsoleVariable("Android.ResizeWindow", "1")
			if device_cfg == true then	--设置 forceMobileScaleFactor 为 0，以免 resize 后变糊
				--ConfigEngine.SetMobileContentScaleFactor(forceMobileScaleFactor)	--这里设置会被覆盖掉
				forceMobileScaleFactor = 0
			end
		end

	elseif platform_name == "IOS" then
		--local format = 2
		--print("r.Mobile.SceneColorFormat = ", format)
		--ConfigEngine.SetConsoleVariable("r.Mobile.SceneColorFormat", tostring(format))
		ConfigEngine.SetConsoleVariable("Slate.ForceBackgroundBlurLowQualityOverride", "1")	
		ConfigEngine.AppendCommandLineText(" -nosound")

		-- IOS add commandLine
		ConfigEngine.AppendCommandLineText(" -metalforceseparatedepthstencil")
		print("CommandLineText: ", ConfigEngine.GetCommandLineText())
		
		local gpuFamily =
		{
			f1_v1 = 0,
			f2_v1 = 1,
			f1_v2 = 2,
			f2_v2 = 3,
			f3_v1 = 4,
			f1_v3 = 5,
			f2_v3 = 6,
			f3_v2 = 7,
			f1_v4 = 8,
			f2_v4 = 9,
			f3_v3 = 10,
		}
		
		--if not SystemInfo.IOS_SupportsFeatureSet(gpuFamily.f3_v2) then
		--	ConfigEngine.SetConsoleVariable("r.DisableDistortion", "1")
		--end

	elseif platform_name == "Windows" then
		local maxCameraSpaceDepth = 1024 * 1024
		ConfigEngine.SetConsoleVariable("Slate.CameraSpaceDepth", tostring(maxCameraSpaceDepth))
		ConfigEngine.SetConsoleVariable("r.Mobile.AzureMSAADepthResolve", "1")
		ConfigEngine.SetConsoleVariable("r.Shadow.WholeSceneShadowUnbuiltInteractionThreshold", "1000")
		--Windows 有两个 FeatureLevel，序列化 PostLoad 时丢弃无用的，减小内存峰值
		ConfigEngine.SetConsoleVariable("r.AzureDiscardUnusedFeatureLevels", "1")
		if not _G.IsWindowsSimuMobile() then
			ConfigEngine.SetConsoleVariable("azure.GameAspectRatioMin", tostring(4/3))
			ConfigEngine.SetConsoleVariable("azure.GameAspectRatioMax", tostring(21/9))
		end
		--直接启动PC端exe时添加额外参数
		if not _G.IsWindowsSimuMobile() then
			local currentCommandLineText = ConfigEngine.GetCommandLineText()
			if currentCommandLineText == nil or not currentCommandLineText:find("-opengl") then
				ConfigEngine.AppendCommandLineText(" -d3d11 -FeatureLevelES31 -noailogging")
			end
		end

		ConfigEngine.SetConsoleVariable("Slate.AzureDisableKeyEventForButton", "1")
	end
	
	ConfigEngine.SetConsoleVariable("r.DefaultFeature.AntiAliasing", "3")
	--ConfigEngine.SetConsoleVariable("r.MobileMSAA", tostring(MobileMSAA))--放到Init_Engine_NeedRestart_Funs这里通过策划配置
	ConfigEngine.SetConsoleVariable("r.MaxAnisotropy", "0")

	local QualitySetting = require "Configs.QualitySetting"
	if QualitySetting then
		QualitySetting.InitSettings(QualitySetting.QualityGroupFlag.Init_Engine, QualitySetting.GetCurrentQualitySettingIndex())
	end
	
	if forceMobileScaleFactor then
		ConfigEngine.SetMobileContentScaleFactor(forceMobileScaleFactor)
	end
	
	--令分辨率等设置生效
	ConfigEngine.CallAllConsoleVariableSinks()
	
	print("config_engine: execute finished")
end
config_engine()
