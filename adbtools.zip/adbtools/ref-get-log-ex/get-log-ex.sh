dir=`dirname "$0"`
[ -e "$dir/logs" ] && rm -rf "$dir/logs"
mkdir -p "$dir/logs"

APPID="$1"
if [ ! "$APPID" ]; then
	APPID="com.tencent.ref"
fi

get_one_device_log()
{
	device=$1
	adb_op()
	{
		"$dir/bin/adb" -s $device ${1+"$@"}
	}
	
	echo device: $device
	logfile=/sdcard/Android/data/$APPID/files/UE4Game/Azure/Azure/Saved/Logs/Azure.log
	logexists=`adb_op shell "[ -f $logfile ] && echo true || echo false"`
	
	logdir="$dir/logs/${device//:/_}"
	mkdir "$logdir"
	
	if [ $logexists = true ]; then
		logfiletime=`adb_op shell date -r $logfile +%s`
		devicetime=`adb_op shell date +%s`
		
		fileage=`expr $devicetime - $logfiletime`
		#echo fileage $fileage
		if [ $fileage -gt 600 ]; then
			echo log file too old
		fi
		adb_op pull $logfile "$logdir/Azure.log"
	else
		echo log file not exist
	fi
	
	adb_op logcat -v time -d > "$logdir/systemlog.txt"
	adb_op shell getprop > "$logdir/getprop.txt"
}

has_device=""
has_succeeded_device=""

IFS="
"
for line in $("$dir/bin/adb" devices)
do
	if [ ! "$line" = "" ] && [ `echo $line | awk '{print $2}'` = "device" ]
	then
		device=`echo $line | awk '{print $1}'`
		has_device="true"
		get_one_device_log $device && has_succeeded_device=true
	fi
done

if [ ! $has_device ]; then
	echo "失败：未连接任何设备，请确认 USB 调试开启且手机已授权"
	read -p "Press enter to continue"
	return
fi

if [ ! $has_succeeded_device ]; then
	echo "已连接了设备，但未找到最新游戏日志文件"
	read -p "Press enter to continue"
	return
fi

echo "成功：操作完成，请将 logs 目录打包上报"
read -p "Press enter to continue"
