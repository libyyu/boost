使用前可先修改 setup.bat
	海外版等需要修改 APPID

各工具简介
install-extra-packages.bat
	把 sdcard 目录下的 extra_packages 移动到游戏目录下
uninstall-extra-packages.bat
	把游戏目录下的 extra_packages 移动到 sdcard 目录下
push-pck.bat
	在 pck 目录中放入文件，推分离文件到 android 设备
push-dir.bat
	在 dir 目录中放入文件 (version.xml, version.txt, serverlist.xml)，推 dir 分离文件到 android 设备
push-streamingassets.bat
	在 streamingassets 目录中放入文件，推 streamingassets 分离文件到 android 设备
push-all-packages.bat
	安装全空 apk 时，用此工具推入所有资源，并设置好资源版本，参数为 apk 路径，可以拖 apk 到 bat 上以执行 (apk 所在目录应该有 extra_package)
skip-pv.bat
	令首次安装时可跳过 PV
mem
	显示游戏内存占用
record-pss.bat
	每秒读取游戏 PSS 并记录到文件
pull-profiling (不支持 Android 11)
	拉取 Saved/Profiling 目录
	clear-profiling 可以删除 Saved/Profiling 目录
