apk=$1

if [ ! "$apk" ]; then
	echo "usage: $0 <apk-path>"
	exit 1
fi

dir=$(dirname "$0")
apkdir=$(dirname "$apk")
tmp=$apk.$(basename "$0").tmp

echo "removing old package"
if [ -e "$apkdir/package" ]; then
	rm -rf "$apkdir/package" || exit 1
fi

rm -rf "$tmp"
mkdir -p "$tmp" || exit 1
echo "unzip packages from apk"
unzip "$apk" 'assets/res_base/package/*' -d "$tmp"
mv -f "$tmp/assets/res_base/package" "$apkdir/package" || exit 1
rm -rf "$tmp"
echo "link packages from extra package"
for sourcefile in $apkdir/extra_packages/package/*; do
	destfile=$apkdir/package/$(basename "$sourcefile")
	echo try rm $destfile
	if [ -e $destfile ]; then
		rm -f $destfile || exit 1
	fi
	sourcefile=$(echo $sourcefile | sed -e 's|/|\\|g')
	destfile=$(echo $destfile | sed -e 's|/|\\|g')
	cmd /c "mklink /H $destfile $sourcefile"
done

echo "push packages to device"
ASSETSPATH=/sdcard/Android/data/$APPID/files
"$ADB" shell rm -rf $ASSETSPATH/package || exit 1
"$ADB" push "$apkdir/package" $ASSETSPATH/package || exit 1
