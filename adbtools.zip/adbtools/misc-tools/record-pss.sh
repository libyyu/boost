get_pss()
{
	"$ADB" shell dumpsys meminfo $APPID|grep TOTAL:|sed -E 's/[ \t]*TOTAL:[ \t]*([0-9]+).*/\1/'
}

while true; do
	echo $(get_pss) >> record-pss.txt
	sleep 1
done
