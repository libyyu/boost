sourcePath=/sdcard/extra_packages
assetsPath=/sdcard/Android/data/$APPID/files
destPath=$assetsPath/extra_packages

if ! "$ADB" shell test -e $assetsPath; then
	echo "游戏目录不存在" "$ADB" shell test -e $assetsPath
	exit 1
fi

disable_remote_path ()
{
	path="$1"
	
	if ! "$ADB" shell test -e $path; then
		return 0
	fi

	iTrial=0
	while [ $iTrial -ne 10 ]; do
		iTrial=$(($iTrial+1))
		
		disabled_path=$path-old-$iTrial
		if ! "$ADB" shell test -e $disabled_path; then
			"$ADB" shell mv $path $disabled_path || { echo "移动失败"; return 1; }
			return 0
		fi
	done
	
	echo "重命名目录 $path 失败"
	return 1
}

if "$ADB" shell test -e $sourcePath; then
	#如果由游戏创建了目录，此目录无法删除，重命名之
	disable_remote_path $destPath || { echo "重命名游戏目录 extra_packages 失败"; exit 1; }
	"$ADB" shell mv $sourcePath $destPath || { echo "移动 extra_packages 失败"; exit 1; }
	"$ADB" shell chmod -R 777 $destPath || { echo "为 extra_packages 设置访问权限失败"; exit 1; }
	echo "extra_packages 已安装"
else
	echo "根目录 extra_packages 不存在"
	exit 1
fi
