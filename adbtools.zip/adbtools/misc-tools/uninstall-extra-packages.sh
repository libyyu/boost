ADB=./bin/adb

sourcePath=/sdcard/extra_packages
destPath=/sdcard/Android/data/$APPID/files/extra_packages
if "$ADB" shell test -e $sourcePath; then
	echo "根目录 extra_packages 已存在"
	exit 1
fi

if "$ADB" shell test -e $destPath; then
	destDir=$(dirname $destPath)
	"$ADB" shell mv $destPath $sourcePath || { echo "failed to remove"; exit 1; }
	echo "extra_packages 已卸载"
else
	echo "游戏目录 extra_packages 不存在"
	exit 1
fi
