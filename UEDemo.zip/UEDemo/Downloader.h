#pragma once
#include "CoreMinimal.h"

DECLARE_LOG_CATEGORY_EXTERN(LogDownloader, Log, All);

class UEDEMO_API Downloader
{
	struct DownloadRange
	{
		int32 Begin = 0;
		int32 End = 0;
	};
	
	FString _URL;
	FString _Verb;
	DownloadRange  _Range;
	int32  _Length = -1;
	typedef TFunction<bool(const uint8*, const int32)> FDownloadCompleteCallback;
	typedef TFunction<void(const int32, const FString&)> FDownloadFailedCallback;
	typedef TFunction<void(const int32, const int32)> FDownloadProgressCallback;
	FDownloadCompleteCallback _OnComplete;
	FDownloadFailedCallback _OnFailed;
	FDownloadProgressCallback _OnProgress;
public:
	Downloader& SetURL(const FString& InURL);
	Downloader& SetVerb(const FString& InVerb);
	Downloader& SetRange(const int32 InBegin, const int32 InEnd = -1);
	Downloader& SetFileLength(const int32 InLength);
	
	Downloader& SetCompleteCallback(FDownloadCompleteCallback&& InCallback);
	Downloader& SetFailedCallback(FDownloadFailedCallback&& InCallback);
	Downloader& SetProgressCallback(FDownloadProgressCallback&& InCallback);

	static bool DownloadCompleteDefault(const FString& SavePath, const uint8* InBytes, const int32 InSize);
protected:
	void DownloadImpl(const FString& InUrl) const;
public:
	void Start();
};
