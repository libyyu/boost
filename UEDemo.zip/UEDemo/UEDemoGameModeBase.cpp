// Copyright Epic Games, Inc. All Rights Reserved.


#include "UEDemoGameModeBase.h"
#include "UEDemo.h"
#include "FileDownload.h"

void AUEDemoGameModeBase::BeginPlay()
{
	Super::BeginPlay();
	UE_LOG(LogUEDemo, Log, TEXT("AUEDemoGameModeBase::BeginPlay"));

	auto loader = FileDownload::CreateDownloader();
	loader->SetURL(TEXT("http://www.libyyu.com/static/birth/happy-birthday.mp3"))
	.SetPost(false)
	.SetFilePath(TEXT("/Users/libyyu/Documents/test.mp3"))
	.SetCompleteCallback([](const FString& InFilePath)
	{
		UE_LOG(LogUEDemo, Log, TEXT("Download Finish: %s"), *InFilePath);
	})
	.SetFailedCallback([](const int32 InCode, const FString& InErrorMsg)
	{
		UE_LOG(LogUEDemo, Error, TEXT("Download Error: %d %s"), InCode, *InErrorMsg);
	})
	.SetProgressCallback([](const int32 Progress)
	{
		UE_LOG(LogUEDemo, Log, TEXT("Total Download Progress:%d%%"), Progress);
	})
	.Start();
}
void AUEDemoGameModeBase::EndPlay(const EEndPlayReason::Type EndPlayReason)
{
	Super::EndPlay(EndPlayReason);
	UE_LOG(LogUEDemo, Log, TEXT("AUEDemoGameModeBase::EndPlay Reason = %d"), EndPlayReason);
}

