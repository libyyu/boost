// Copyright Epic Games, Inc. All Rights Reserved.

#include "UEDemo.h"
#include "Modules/ModuleManager.h"

IMPLEMENT_PRIMARY_GAME_MODULE( FDefaultGameModuleImpl, UEDemo, "UEDemo" );

DEFINE_LOG_CATEGORY(LogUEDemo);
