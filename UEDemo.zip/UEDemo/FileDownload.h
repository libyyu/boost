#pragma once
#include "CoreMinimal.h"
#include "HAL/Runnable.h"
#include "HAL/RunnableThread.h"

DECLARE_LOG_CATEGORY_EXTERN(LogFileDownloader, Log, All);

class UEDEMO_API FileDownload
{
	FString _FilePath;
	FString _URL;
	bool _post = false;
	bool _EnableMultiThread = false;
	bool _EnableMultiThreadFromServer = false;
	typedef TFunction<void(const FString&)> FFileDownloadCompleteCallback;
	typedef TFunction<void(const int32, const FString&)> FFileDownloadFailedCallback;
	typedef TFunction<void(const int32)> FFileDownloadProgressCallback;
	FFileDownloadCompleteCallback _OnComplete;
	FFileDownloadFailedCallback _OnFailed;
	FFileDownloadProgressCallback _OnProgress;
	
	int32 content_length = 0; //完整文件大小
	int32 download_total_size = 0; //已经下载的大小
	int32 download_progress = 0;
	int32 download_total_thread_cnt = 0; //线程数
	FCriticalSection writefile_cs; //写文件互斥量
	FILE* fw = nullptr;
	bool b_finished = false;
	TMap<TSharedPtr<FRunnableThread>, FRunnable*> download_tasks;
	friend class FFileDownloadChunkRunnable;

	FileDownload();
public:
	static TSharedPtr<FileDownload> CreateDownloader();
	~FileDownload();
	FileDownload& SetFilePath(const FString& InPath);
	FileDownload& SetURL(const FString& InURL);
	FileDownload& SetPost(const bool InPost);
	FileDownload& SetEnableMultiThread(const bool InEnable);
	FileDownload& SetCompleteCallback(FFileDownloadCompleteCallback&& InCallback);
	FileDownload& SetFailedCallback(FFileDownloadFailedCallback&& InCallback);
	FileDownload& SetProgressCallback(FFileDownloadProgressCallback&& InCallback);
public:
	void Start();

protected:
	void DownloadImpl(const FString& InRealUrl);
	bool OnCompleteFunc(FRunnable* thread, const uint8* InBytes, const int32 InSize);
	void OnFailedFunc(FRunnable* thread, const int32 InCode, const FString& InErrorMsg);
	void OnProgressFunc(FRunnable* thread, const int32 InBytesReceived);

private:
	void CallOnFailed(const int32 InCode, const FString& InErrorMsg);
	void CallOnSuccess(const FString& InFilePath);
	void CallOnProgress(const int32 InProgress);
};
