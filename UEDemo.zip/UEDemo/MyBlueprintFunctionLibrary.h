// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Kismet/BlueprintFunctionLibrary.h"
#include "MyBlueprintFunctionLibrary.generated.h"

/**
 * 
 */
DECLARE_DYNAMIC_DELEGATE_TwoParams(FDownloadResultDelegate, bool, bSuccessed, const FString&, URL);
DECLARE_DYNAMIC_DELEGATE_TwoParams(FDownloadProgressDelegate, int, Progress, const FString&, URL);


UCLASS()
class UEDEMO_API UMyBlueprintFunctionLibrary : public UBlueprintFunctionLibrary
{
	GENERATED_BODY()
	
    UFUNCTION(BlueprintCallable, Category = "MyFunction")
    static void TestBlueprintFunctionLibrary();
    
    
    UFUNCTION(BlueprintCallable, Category = "MyFunction")
    static void TestDownload(const FString& URL, const FString& FilePath, FDownloadResultDelegate Result, FDownloadProgressDelegate Progress);
};
