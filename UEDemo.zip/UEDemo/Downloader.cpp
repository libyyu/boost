#include "Downloader.h"
#include "HttpRequest.h"
#include "Misc/FileHelper.h"

DEFINE_LOG_CATEGORY(LogDownloader);

Downloader& Downloader::SetURL(const FString& InURL)
{
	_URL = InURL;
	return *this;
}
Downloader& Downloader::SetVerb(const FString& InVerb)
{
	_Verb = InVerb;
	return *this;
}
Downloader& Downloader::SetFileLength(const int32 InLength)
{
	_Length = InLength;
	return *this;
}

Downloader& Downloader::SetCompleteCallback(FDownloadCompleteCallback&& InCallback)
{
	_OnComplete = MoveTemp(InCallback);
	return *this;
}
Downloader& Downloader::SetFailedCallback(FDownloadFailedCallback&& InCallback)
{
	_OnFailed = MoveTemp(InCallback);
	return *this;
}
Downloader& Downloader::SetProgressCallback(FDownloadProgressCallback&& InCallback)
{
	_OnProgress = MoveTemp(InCallback);
	return *this;
}

Downloader& Downloader::SetRange(const int32 InBegin, const int32 InEnd)
{
	_Range.Begin = InBegin;
	_Range.End = InEnd;
	return *this;
}

void Downloader::Start()
{
	UE_LOG(LogDownloader, Log, TEXT("Begin Download"));
	
	if(_Length <= 0)
	{//自动获取文件长度
		UE_LOG(LogDownloader, Log, TEXT("Request File Content-Length"));

		HttpRequest::RequestContentLengthAndURL(_URL, [this](const FString& InRealURL, const int32 InLength, FHttpResponsePtr InHttpResponse)
		{
			_Length = InLength;
			DownloadImpl(InRealURL);
		}, [this](const int32 InCode, const FString& InErrorMsg)
		{
			UE_LOG(LogDownloader, Error, TEXT("Content Length is not valid"));
			if(_OnFailed) _OnFailed(InCode, InErrorMsg);
		});
	}
	else
	{
		DownloadImpl(_URL);
	}
}

void Downloader::DownloadImpl(const FString& InUrl) const
{
	UE_LOG(LogDownloader, Log, TEXT("DownloadImpl"));

	int32 start = _Range.Begin;
	int32 end = _Range.End;

	if (start < 0)
		start += _Length;
	if (start < 0)
		start = 0;
	
	if (end < 0)
		end += _Length;
	if (end == 0)
		end = _Length;

	if(start >= _Length || start >= end || end > _Length)
	{
		UE_LOG(LogDownloader, Error, TEXT("Download Failed. Range(%d-%d) not valid"), start, end);
		if(_OnFailed) _OnFailed(-2, TEXT("Download Range not valid"));
		return;
	}

	const int32 content_length = end - start;
	UE_LOG(LogDownloader, Log, TEXT("Download Range(%d-%d), partial content-length:%d, total content-length:%d"), start, end, content_length, _Length);
	
	TSharedPtr<HttpRequest> request = HttpRequest::CreateRequest();
	request->SetVerb(_Verb)
	.SetURL(InUrl)
	.SetRequestHeader(TEXT("Range"), FString::Printf(TEXT("%d-%d"), start, end))
	.SetCompleteCallback([this](FHttpRequestPtr InHttpRequest, FHttpResponsePtr InHttpResponse)
	{
		if(_OnComplete && !_OnComplete(InHttpResponse->GetContent().GetData(), InHttpResponse->GetContentLength()))
		{
			UE_LOG(LogDownloader, Error, TEXT("Download Failed. Failed to Save Bytes"));
			if(_OnFailed) _OnFailed(-2, TEXT("Failed to Save Bytes"));
		}
		else
		{
			UE_LOG(LogDownloader, Log, TEXT("Download Successed"));
		}
	})
	.SetFailedCallback([this](const int32 InCode, const FString& InErrorMsg)
	{
		UE_LOG(LogDownloader, Error, TEXT("Download Failed. Code = %d"), InCode);
		if(_OnFailed) _OnFailed(InCode, InErrorMsg);
	})
	.SetProgressCallback([this, content_length](const int32 InBytesSent, const int32 InBytesReceived)
	{
		if(_OnProgress)
		{
			const float percent = InBytesReceived * 1.0 / content_length;
			const int32 v = percent * 100;
			_OnProgress(v, InBytesReceived);
		}
	})
	.Start();
}

bool Downloader::DownloadCompleteDefault(const FString& SavePath, const uint8* InBytes, const int32 InSize)
{
	IFileManager* FileManager= &IFileManager::Get();
	TUniquePtr<FArchive> Ar = TUniquePtr<FArchive>( FileManager->CreateFileWriter( *SavePath, 0 ) );
	if( !Ar )
	{
		UE_LOG(LogDownloader, Error, TEXT("Download Failed. Failed to CreateFileWriter. %s"), *SavePath);
		return false;
	}
	Ar->Serialize(const_cast<uint8*>(InBytes), InSize);

	// Always explicitly close to catch errors from flush/close
	Ar->Close();

	if(Ar->IsError() || Ar->IsCriticalError())
	{
		UE_LOG(LogDownloader, Error, TEXT("Download Failed. Failed to SaveData To %s"), *SavePath);
		return false;
	}

	return true;
}

