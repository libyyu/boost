// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Http.h"
/**
 * 
 */
class UEDEMO_API HttpRequest
{
    TSharedPtr<IHttpRequest> _Request;    
    FString _URL;
    FString _Verb;
    TMap<FString, FString> _RequestHeader;
    TMap<FString, FString> _RespondHeader;
    typedef TFunction<void(FHttpRequestPtr, FHttpResponsePtr)> FRequestCompleteCallback;
    typedef TFunction<void(const int32, const FString&)> FRequestFailedCallback;
    typedef TFunction<void(const int32, const int32)> FRequestProgressCallback;
    FRequestCompleteCallback _OnComplete;
    FRequestFailedCallback _OnFailed;
    FRequestProgressCallback _OnProgress;
    
    HttpRequest();
protected:
    void OnRequestComplete(FHttpRequestPtr InHttpRequest, FHttpResponsePtr InHttpResponse, bool bSucceeded);
    void OnRequestProgress(FHttpRequestPtr InHttpRequest, int32 BytesSent, int32 BytesReceived) const;
    void OnHeaderReceived(FHttpRequestPtr InHttpRequest, const FString& InHeaderName, const FString& InHeaderValue);
public:
	~HttpRequest();
    static TSharedPtr<HttpRequest> CreateRequest();
public:
    HttpRequest& SetURL(const FString& InURL);
    HttpRequest& SetVerb(const FString& InVerb);
    HttpRequest& SetRequestHeader(const FString& InName, const FString& InValue);
    HttpRequest& SetCompleteCallback(FRequestCompleteCallback&& InCallback);
    HttpRequest& SetFailedCallback(FRequestFailedCallback&& InCallback);
    HttpRequest& SetProgressCallback(FRequestProgressCallback&& InCallback);

    bool GetRespondHeader(const FString& InHeaderName, FString& OutHeaderValue) const;
    
    void Start();

    static void RequestContentLengthAndURL(const FString& InUrl,
        const TFunction<void(const FString&, const int32, FHttpResponsePtr)>& OnComplete,
        const TFunction<void(const int32, const FString&)>& OnFailed);
};

DECLARE_LOG_CATEGORY_EXTERN(LogHttpRequest, Log, All);
