// Fill out your copyright notice in the Description page of Project Settings.


#include "MyBlueprintFunctionLibrary.h"

void UMyBlueprintFunctionLibrary::TestBlueprintFunctionLibrary()
{
    UE_LOG(LogTemp, Log, TEXT("TestBlueprintFunctionLibrary"));
}

void UMyBlueprintFunctionLibrary::TestDownload(const FString& URL, const FString& FilePath, FDownloadResultDelegate Result, FDownloadProgressDelegate Progress)
{
    Progress.ExecuteIfBound(100, URL);
    Result.ExecuteIfBound(true, URL);
}
