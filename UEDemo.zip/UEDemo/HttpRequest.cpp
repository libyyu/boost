// Fill out your copyright notice in the Description page of Project Settings.


#include "HttpRequest.h"
#include <memory>
#include <mutex>
#include <thread>

DEFINE_LOG_CATEGORY(LogHttpRequest);

class FRequestHolder
{
    TMap<HttpRequest*, TSharedPtr<HttpRequest> > holder;
    FCriticalSection cs;

    static TUniquePtr<FRequestHolder> instance;
    FRequestHolder()
    {}
public:
    void Register(const TSharedPtr<HttpRequest>& sp)
    {
        FScopeLock lock(&cs);
        holder.Add(sp.Get(), sp);
    }
    void UnRegister(HttpRequest* p)
    {
        FScopeLock lock(&cs);
        holder.Remove(p);
    }
    ~FRequestHolder()
    {
        FScopeLock lock(&cs);
        holder.Empty();
        UE_LOG(LogHttpRequest, Log, TEXT("FRequestHolder::~FRequestHolder"));
    }
    static FRequestHolder* Get()
    {
        if(!instance){
            static std::once_flag flag;//注意flag是static
            std::call_once(flag, [&](){
                std::cout <<"call_once FRequestHolder" <<std::endl;
                instance.Reset(new FRequestHolder());
            });//只调用一次
        }
        
        return instance.Get();
    }
};

TUniquePtr<FRequestHolder> FRequestHolder::instance;


TSharedPtr<HttpRequest> HttpRequest::CreateRequest()
{
    TSharedPtr<HttpRequest> p(new HttpRequest);
    FRequestHolder::Get()->Register(p);
    return p;
}

HttpRequest::HttpRequest()
{
}

HttpRequest::~HttpRequest()
{
    UE_LOG(LogHttpRequest, Log, TEXT("HttpRequest::~HttpRequest"));
}

HttpRequest& HttpRequest::SetURL(const FString& InURL)
{
    _URL = InURL;
    return *this;
}
HttpRequest& HttpRequest::SetVerb(const FString& InVerb)
{
    _Verb = InVerb;
    return *this;
}
HttpRequest& HttpRequest::SetRequestHeader(const FString& InName, const FString& InValue)
{
    for(TPair<FString, FString>& element : _RequestHeader)
    {
        if(element.Key.Equals(InName, ESearchCase::IgnoreCase))
        {
            element.Value = InValue;
            return *this;
        }
    }
    _RequestHeader.Add(InName, InValue);
    return *this;
}

HttpRequest& HttpRequest::SetCompleteCallback(FRequestCompleteCallback&& InCallback)
{
    _OnComplete = MoveTemp(InCallback);
    return *this;
}

HttpRequest& HttpRequest::SetFailedCallback(FRequestFailedCallback&& InCallback)
{
    _OnFailed = MoveTemp(InCallback);
    return *this;
}
HttpRequest& HttpRequest::SetProgressCallback(FRequestProgressCallback&& InCallback)
{
    _OnProgress = MoveTemp(InCallback);
    return *this;
}

void HttpRequest::Start()
{
    FHttpModule& Http = FHttpModule::Get();
    _Request = Http.CreateRequest();
    _Request->OnProcessRequestComplete().BindRaw(this, &HttpRequest::OnRequestComplete);
    _Request->OnRequestProgress().BindRaw(this, &HttpRequest::OnRequestProgress);
    _Request->OnHeaderReceived().BindRaw(this, &HttpRequest::OnHeaderReceived);
    _Request->SetURL(_URL);
    _Request->SetVerb(_Verb);
    for(const TPair<FString, FString>& element : _RequestHeader)
    {
        _Request->SetHeader(element.Key, element.Value);
    }
    _Request->ProcessRequest();
}

void HttpRequest::OnRequestProgress(FHttpRequestPtr InHttpRequest, int32 BytesSent, int32 BytesReceived) const
{
    if(_OnProgress) _OnProgress(BytesSent, BytesReceived);
}

void HttpRequest::OnRequestComplete(FHttpRequestPtr InHttpRequest, FHttpResponsePtr InHttpResponse, bool bWasSuccessful)
{
    if (bWasSuccessful
        && InHttpResponse.IsValid())
    {
        UE_LOG(LogHttpRequest, Log, TEXT("OnRequestComplete: Success"));
        if(_OnComplete) _OnComplete(InHttpRequest, InHttpResponse);
    }
    else
    {
        FString ErrorMessage = TEXT("Unknow error");
        int32 Code = -1;
        if(InHttpResponse.IsValid())
        {
            Code = InHttpResponse->GetResponseCode();
            ErrorMessage = InHttpResponse->GetContentAsString();
        }
        UE_LOG(LogHttpRequest, Warning, TEXT("OnRequestComplete: Failed. Code = %d. %s"), Code, *ErrorMessage);
        if(_OnFailed) _OnFailed(Code, ErrorMessage);
    }
    
    FRequestHolder::Get()->UnRegister(this);
}

void HttpRequest::OnHeaderReceived(FHttpRequestPtr InHttpRequest, const FString& InHeaderName, const FString& InHeaderValue)
{
    UE_LOG(LogHttpRequest, Log, TEXT("OnHeaderReceived: %s = %s"), *InHeaderName, *InHeaderValue);
    _RespondHeader.Add(InHeaderName, InHeaderValue);
}

bool HttpRequest::GetRespondHeader(const FString& InHeaderName, FString& OutHeaderValue) const
{
    for(const TPair<FString, FString>& element : _RespondHeader)
    {
        if(InHeaderName.Equals(element.Key, ESearchCase::IgnoreCase))
        {
            OutHeaderValue = element.Value;
            return true;
        }
    }
    return false;
}

void HttpRequest::RequestContentLengthAndURL(const FString& InUrl,
        const TFunction<void(const FString&, const int32, FHttpResponsePtr)>& OnComplete,
        const TFunction<void(const int32, const FString&)>& OnFailed)
{
    auto request = HttpRequest::CreateRequest();
    request->SetVerb(TEXT("HEAD"))
    .SetURL(InUrl)
    .SetCompleteCallback([InUrl, OnComplete, OnFailed](FHttpRequestPtr InHttpRequest, FHttpResponsePtr InHttpResponse)
    {
        const int32 Code = InHttpResponse->GetResponseCode();
        const FString LocationURL = InHttpResponse->GetHeader(TEXT("Location"));
        const int32 Length = InHttpResponse->GetContentLength();

        bool bRedirect = false;
        FString NewURL;
        if(Code == EHttpResponseCodes::Ok)
        {
            if(!LocationURL.IsEmpty())
            {
                bRedirect = true;
                NewURL = LocationURL;
            }
            else
            {
                OnComplete(InUrl, Length, InHttpResponse);
                return;
            }
        }
        else if(Code == EHttpResponseCodes::Redirect)
        {
            if(!LocationURL.IsEmpty())
            {
                bRedirect = true;
                NewURL = LocationURL;
            }
        }
        
        if(bRedirect)
        {
            RequestContentLengthAndURL(NewURL, OnComplete, OnFailed);
        }
        else
        {
            OnFailed(-1, TEXT("Failed to get Content-Length"));
        }
    })
    .SetFailedCallback([OnFailed](const int32 InCode, const FString& InErrorMsg)
    {
        OnFailed(InCode, InErrorMsg);
    })
    .Start();
}