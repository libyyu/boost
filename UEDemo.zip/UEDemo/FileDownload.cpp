#include "FileDownload.h"
#include "HttpRequest.h"
#include "Downloader.h"
#include "Misc/FileHelper.h"
#include <regex>
DEFINE_LOG_CATEGORY(LogFileDownloader);

class FileDownloadHolder
{
	TMap<FileDownload*, TSharedPtr<FileDownload> > holder;
	FCriticalSection cs;

	static TUniquePtr<FileDownloadHolder> instance;
	FileDownloadHolder()
	{}
public:
	void Register(const TSharedPtr<FileDownload>& sp)
	{
		FScopeLock lock(&cs);
		holder.Add(sp.Get(), sp);
	}
	void UnRegister(FileDownload* p)
	{
		FScopeLock lock(&cs);
		holder.Remove(p);
	}
	~FileDownloadHolder()
	{
		FScopeLock lock(&cs);
		holder.Empty();
		UE_LOG(LogHttpRequest, Log, TEXT("FileDownloadHolder::~FileDownloadHolder"));
	}
	static FileDownloadHolder* Get()
	{
		if(!instance){
			static std::once_flag flag;//注意flag是static
			std::call_once(flag, [&](){
				std::cout <<"call_once FileDownloadHolder" <<std::endl;
				instance.Reset(new FileDownloadHolder());
			});//只调用一次
		}
        
		return instance.Get();
	}
};

TUniquePtr<FileDownloadHolder> FileDownloadHolder::instance;

/**
 * @brief 
 * @return
 */
TSharedPtr<FileDownload> FileDownload::CreateDownloader()
{
	TSharedPtr<FileDownload> p(new FileDownload);
	FileDownloadHolder::Get()->Register(p);
	return p;
}

FileDownload& FileDownload::SetFilePath(const FString& InPath)
{
	_FilePath = InPath;
	return *this;
}

FileDownload& FileDownload::SetURL(const FString& InURL)
{
	_URL = InURL;
	return *this;
}

FileDownload& FileDownload::SetPost(const bool InPost)
{
	_post = InPost;
	return *this;
}

FileDownload& FileDownload::SetEnableMultiThread(const bool InEnable)
{
	_EnableMultiThread = InEnable;
	return *this;
}

FileDownload& FileDownload::SetCompleteCallback(FFileDownloadCompleteCallback&& InCallback)
{
	_OnComplete = MoveTemp(InCallback);
	return *this;
}
FileDownload& FileDownload::SetFailedCallback(FFileDownloadFailedCallback&& InCallback)
{
	_OnFailed = MoveTemp(InCallback);
	return *this;
}
FileDownload& FileDownload::SetProgressCallback(FFileDownloadProgressCallback&& InCallback)
{
	_OnProgress = MoveTemp(InCallback);
	return *this;
}

void FileDownload::Start()
{
	if(_URL.IsEmpty())
	{
		UE_LOG(LogFileDownloader, Error, TEXT("URL is empty"));
		CallOnFailed(-1, TEXT("URL is empty"));
		return;
	}

	if(_FilePath.IsEmpty())
	{
		
	}
	
	//先获取文件信息（总大小，修改时间等）
	HttpRequest::RequestContentLengthAndURL(_URL, [this](const FString& InNewURL, const int32 InLength, FHttpResponsePtr InHttpResponse)
	{
		UE_LOG(LogFileDownloader, Log, TEXT("Location: %s, Content-Length:%d"), *InNewURL, InLength);
		_EnableMultiThreadFromServer = false;
		FString range = InHttpResponse->GetHeader(TEXT("CONTENT-RANGE"));
		if(!range.IsEmpty())
		{
			try
			{
				//匹配"Content-Range: bytes 2-1449/26620" 则证明支持多线程下载
				std::regex pattern("\\w+\\s*(\\d+)-(\\d*)/(\\d+)", std::regex::icase);
				_EnableMultiThreadFromServer = std::regex_search(TCHAR_TO_UTF8(*range), pattern);
			}
			catch(std::exception e)
			{
			}
		}
		UE_LOG(LogFileDownloader, Log, TEXT("EnableMultiThreadFromServer: %d"), _EnableMultiThreadFromServer);

		//文件存在，判断是否需要下载:
		if(FPaths::FileExists(*_FilePath))
		{
			//TODO:
		}
		
		content_length = InLength;
		DownloadImpl(InNewURL);
		
	}, [this](const int32 InCode, const FString& InErrorMsg)
	{
		UE_LOG(LogFileDownloader, Error, TEXT("Get Content Length Failed"));
		CallOnFailed(InCode, InErrorMsg);
	});
}

class FFileDownloadChunkRunnable : public FRunnable
{
	int32 chunk_index;
	FILE* fp = nullptr;
	FString url;
	int32 start = 0;
	int32 end = 0;
	FileDownload* outer = nullptr;
	Downloader* loader = nullptr;
	friend class FileDownload;

	int32 LastBytesReceived = 0;
public:
	virtual ~FFileDownloadChunkRunnable()
	{
		delete loader;
		loader = nullptr;
		UE_LOG(LogFileDownloader, Log, TEXT("~FFileDownloadChunkRunnable:%d"), chunk_index);
	}
	explicit FFileDownloadChunkRunnable(int32 index, FILE* f, const FString& u, int32 s, int32 e, FileDownload* o)
		: chunk_index(index)
		, fp(f)
		, url(u)
		, start(s)
		, end(e)
		, outer(o)
	{
		
	}
	// FRunnable methods.
	virtual uint32 Run() override
	{
		loader = new Downloader();
		loader->SetURL(url)
		.SetVerb(outer->_post ? TEXT("POST") : TEXT("GET"))
		.SetRange(start, end)
		.SetFileLength(outer->content_length)
		.SetCompleteCallback([this](const uint8* InBytes, const int32 InSize)->bool
		{
			UE_LOG(LogDownloader, Log, TEXT("FFileDownloadChunkRunnable:%d Finished."), chunk_index);
			const bool ret = outer->OnCompleteFunc(this, InBytes, InSize);
			return ret;
		})
		.SetProgressCallback([this](const int32 percent, const int32 InBytesReceived)
		{
			int32 NewReceived = InBytesReceived - LastBytesReceived;
			LastBytesReceived = InBytesReceived;
			outer->OnProgressFunc(this, NewReceived);
		})
		.SetFailedCallback([this](const int32 InCode, const FString& InErrorMsg)
		{
			outer->OnFailedFunc(this, InCode, InErrorMsg);
		})
		.Start();
		
		while (!outer->b_finished)
		{
			FPlatformProcess::Sleep(0.1);
		}
		
		return 0;
	}
	virtual void Stop() override
	{
		UE_LOG(LogFileDownloader, Log, TEXT("FFileDownloadChunkRunnable:%d Stop"), chunk_index);
		delete loader;
		loader = nullptr;
	}

	virtual void Exit() override
	{
		UE_LOG(LogFileDownloader, Log, TEXT("FFileDownloadChunkRunnable:%d Exit"), chunk_index);
	}
};




void FileDownload::DownloadImpl(const FString& InRealUrl)
{
	UE_LOG(LogFileDownloader, Log, TEXT("Start DownloadImpl"));
	
	FString out_file_path_temp = _FilePath + TEXT(".dl");
	FILE* fp = fopen(TCHAR_TO_UTF8(*out_file_path_temp), "ab+");
	if(!fp)
	{
		UE_LOG(LogFileDownloader, Error, TEXT("Create File:%s Failed"), *out_file_path_temp);
		CallOnFailed(-2, TEXT("Create File Failed"));
	}
	fw = fp;

	//TODO:
	int32 thread_count = 1;
	int32 download_begin = 0;
	int32 gap = static_cast<int32>(content_length / thread_count);
	download_total_thread_cnt = thread_count;
	UE_LOG(LogFileDownloader, Log, TEXT("Split Thread Num:%d"), thread_count);
	for(int32 i=0; i < thread_count; ++i)
	{
		int32 start = download_begin + i * gap;
		int32 end = start + gap - 1;
		FFileDownloadChunkRunnable* thread_chunk = new FFileDownloadChunkRunnable(i, fp, InRealUrl, start,end,this);
		TSharedPtr<FRunnableThread> thread(FRunnableThread::Create(thread_chunk, *FString::Printf(TEXT("DownloadChunk:%d"), i), 0, TPri_Normal));
		download_tasks.Add(thread, thread_chunk);
	}
}

bool FileDownload::OnCompleteFunc(FRunnable* InRunner, const uint8* InBytes, const int32 InSize)
{
	FScopeLock sc(&writefile_cs);
	UE_LOG(LogFileDownloader, Log, TEXT("FileDownload::OnCompleteFunc: %d"), InSize);
	FFileDownloadChunkRunnable* downloader = static_cast<FFileDownloadChunkRunnable*>(InRunner);
	size_t written = 0;
	size_t real_size = InSize;
	if(downloader->start <= downloader->end)
	{
		if(downloader->start + real_size > downloader->end)
		{
			real_size = downloader->end - downloader->start + 1;
		}
	}
	
	int seek_error = fseek(downloader->fp, downloader->start, SEEK_SET);
	if(seek_error != 0)
	{
		//TODO:
		UE_LOG(LogFileDownloader, Error, TEXT("Seek File Pointer Error: %d"), seek_error);
		return false;
	}
	else
	{
		written = fwrite(InBytes, 1, real_size, downloader->fp);
		if(written != real_size)
		{
			//TODO:
			UE_LOG(LogFileDownloader, Error, TEXT("Write File Error: %d"), written);
			return false;
		}
		
		download_total_thread_cnt -= 1;
		if(download_total_thread_cnt == 0)
		{
			CallOnSuccess(_FilePath);
		}
		
		return true;
	}
}
void FileDownload::OnFailedFunc(FRunnable* InRunner, const int32 InCode, const FString& InErrorMsg)
{
	//TODO:
	UE_LOG(LogFileDownloader, Error, TEXT("Download File Error: %d. %s"), InCode, *InErrorMsg);
	
	CallOnFailed(InCode, InErrorMsg);
}
void FileDownload::OnProgressFunc(FRunnable* InRunner, const int32 InNewReceived)
{
	FScopeLock sc(&writefile_cs);
	download_total_size += InNewReceived;
	UE_LOG(LogFileDownloader, Log, TEXT("InBytesReceived:%d, Total:%d"), InNewReceived, download_total_size);
	const float percent = download_total_size * 1.0 / content_length;
	const int32 progress = percent * 100;
	CallOnProgress(progress);
}

void FileDownload::CallOnProgress(const int32 InProgress)
{
	download_progress = InProgress;
	AsyncTask(ENamedThreads::GameThread, [this]()
	{
		//if(b_finished) return;
		if(_OnProgress) _OnProgress(download_progress);
	});
}

void FileDownload::CallOnFailed(const int32 InCode, const FString& InErrorMsg)
{
	b_finished = true;
	
	if(fw)
	{
		fclose(fw);
		fw = nullptr;
	}
	
	AsyncTask(ENamedThreads::GameThread, [this, InCode, InErrorMsg]()
	{
		for(TPair<TSharedPtr<FRunnableThread>, FRunnable*>& element : download_tasks)
		{
			element.Key->WaitForCompletion();
			FFileDownloadChunkRunnable* runner = static_cast<FFileDownloadChunkRunnable*>(element.Value);
			delete runner;
		}
		download_tasks.Empty();
		
		if(_OnFailed) _OnFailed(InCode, InErrorMsg);
	});
}
void FileDownload::CallOnSuccess(const FString& InFilePath)
{
	b_finished = true;
	
	if(fw)
	{
		fclose(fw);
		fw = nullptr;
	}
	
	AsyncTask(ENamedThreads::GameThread, [this, InFilePath]()
	{
		for(TPair<TSharedPtr<FRunnableThread>, FRunnable*>& element : download_tasks)
		{
			element.Key->WaitForCompletion();
			FFileDownloadChunkRunnable* runner = static_cast<FFileDownloadChunkRunnable*>(element.Value);
			delete runner;
		}
		download_tasks.Empty();
		//download_progress = 100;
		//if(_OnProgress) _OnProgress(download_progress);
		if(_OnComplete) _OnComplete(InFilePath);
	});
}

FileDownload::FileDownload()
{
	
}

FileDownload::~FileDownload()
{
	//清理所有线程
	b_finished = true;
	for(TPair<TSharedPtr<FRunnableThread>, FRunnable*>& element : download_tasks)
	{
		element.Key->WaitForCompletion();
		FFileDownloadChunkRunnable* runner = static_cast<FFileDownloadChunkRunnable*>(element.Value);
		delete runner;
	}
	download_tasks.Empty();
	
	if(fw)
	{
		fclose(fw);
		fw = nullptr;
	}
}
